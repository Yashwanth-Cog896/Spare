-- Get competitor events

select distinct crop.name, ec.event_name, ec.construct_name, ec.regulatory_name_id, 
       co.name
from midas.germplasm g,
     midas.germplasm_event_construct gec,
     midas.event_construct ec,
     midas.product_germplasm pg,
     midas.product p,
     midas.product_name pn,
     midas.brand b,
     midas.company co,
     midas.crop crop
where g.germplasm_id = gec.germplasm_id
  and g.crop_id = ec.crop_id
  and g.crop_id = p.crop_id
  and gec.event_construct_id = ec.event_construct_id
  and g.germplasm_id = pg.germplasm_id
  and pg.product_id = p.product_id
  and p.product_id = pn.product_id
  and pn.brand_id = b.brand_id
  and b.company_id = co.company_id
  and co.ref_active = 'T'
  and b.ref_active = 'T'
  and pn.ref_active = 'T'
  and p.ref_active = 'T'
  and g.is_deleted = 'F'
  and co.name = 'MONSANTO'
  --and ec.event_name not in ('40-3-2', 'RT73', 'MON810', 'NK603', 'EZRA', 'CCR107', 'GA21', 'MON863')
  ;  
