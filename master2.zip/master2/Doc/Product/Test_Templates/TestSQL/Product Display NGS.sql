/*****************************************************************************/
/******** FBS Common Product Xref ********/
/*****************************************************************************/
SELECT  PX.lexicon_product_pubkey AS "Product Pubkey",
        PX.midas_product_id AS "Midas Product Id"
  FROM  FBS_Prod_Xref PX
  WHERE  PX.lexicon_product_pubkey in /*Place Product Pubkey Betwen Quotes*/  ('35630309')
--where px.midas_product_id in (1350961397760,2466719268864,3304050130944)
;
SELECT  PX.lexicon_product_pubkey AS "Product Pubkey",
        PX.midas_product_id AS "Midas Product Id"
  FROM  FBS_Prod_Xref PX
WHERE  PX.lexicon_product_pubkey in /*Place Product Pubkey Betwen Quotes*/  ('4196702')  
;
select * from Lexicon.product_gp_action where product_pubkey = '383602';

-- run for Monsanto products
select p.product_pubkey, p.logical_delete, pn.product_stage_pubkey, pn.logical_delete
from lexicon.pre_coml_product p, lexicon.product_stage pn
where p.product_id = pn.product_id and p.product_pubkey in  ('36152009');
 
 -- run for Competitor products
select p.product_pubkey, p.product_id, p.logical_delete, pn.product_name_pubkey, pn.logical_delete,  pn.is_active
from lexicon.product p, lexicon.product_name pn
where p.product_id = pn.product_id and p.product_pubkey  in  ('4196702') 
order by pn.logical_delete, p.product_pubkey;
/*****************************************************************************/
/******** FBS Common Product Name Xref ********/
/*****************************************************************************/
SELECT  PNX.lexicon_product_name_pubkey AS "Name Pubkey",
		PNX.midas_product_name_id AS "Midas Name Id",
		PNX.mirage_product_id AS "Seed Product Id"
  FROM  FBS_Prod_Name_Xref PNX
 --where pnx.lexicon_product_name_pubkey in ('77925312')
 where pnx.lexicon_product_name_pubkey in ('74965412')  

--where pnx.midas_product_name_id in (3390837161984)
 --where pnx.lexicon_product_name_pubkey in ('2484307') 
--where pnx.mirage_product_id in (1584522, 1585349) --1685116

order by pnx.lexicon_product_name_pubkey
;
select * from lexicon.brand b where b.brand_name = 'MONSANTO';
select * from lexicon.stage s where s.stage_abbr = 'PS4';
/*****************************************************************************/
/******** Midas Product ********/
/*****************************************************************************/
SELECT  P.product_id AS "Product Id",
	    Crop.Crop_id as "crop id",
		Crop.name as "Crop",
        P.ref_active AS "Ref Active"
  FROM  Midas_Product P, midas.crop@prem crop
 WHERE  p.crop_id = crop.crop_id and P.product_id /*Place Midas Product Id After This*/ 
 in (3275941412864)
;

Select * from midas.crop@prem;
/*****************************************************************************/
-- checking for germplasm in MIDAS
/*****************************************************************************/
SELECT  PGP.product_id AS "Product Id",
        crop.name as "crop",
        GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        lt.line_type_ref_id as "Line Type",
        lt.line_type_id as "line type id",
        gm.genetic_material_id, GM.source_str 
  FROM  Midas_Product_Germplasm PGP,
        Midas_Germplasm GP,
        Midas.Crop@prem crop,
        Midas.line_type@prem lt,
        Midas.Genetic_Material@prem gm  
 WHERE PGP.product_id in  (2462645354496)
-- where gp.germplasm_id = 2454670868480
--gp.line_code = 'CST17004'
-- where gm.genetic_material_id in ( 2457985089536, 2454473932800)
  and PGP.germplasm_id = GP.germplasm_id
  and gp.crop_id = crop.crop_id
  and gp.line_type_id = lt.line_type_id
  and  gp.germplasm_id = gm.germplasm_id
   ;
-- Check for MIDAS trials
   SELECT  PGP.product_id AS "Product Id",
        crop.name as "crop",
		--pn.name as "Product Name"
        GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        lt.line_type_ref_id as "Line Type",
        gm.genetic_material_id, GM.source_str,
        brp.br_prog_ref_id, brp.name
  FROM  Midas_Product_Germplasm PGP,
        Midas_Germplasm GP,
        Midas.Crop@prem crop,
        Midas.line_type@prem lt,
        Midas.Genetic_Material@prem gm,
        midas.inventory@prem inv,
        midas.br_prog@prem brp
 WHERE PGP.product_id /*Place Midas Product Id After This*/  in (2462349787136)
--gm.genetic_material_id in (2723543384064)
--  PGP.germplasm_id (+) = GP.germplasm_id and pgp.product_id is null
and PGP.germplasm_id = GP.germplasm_id
  and gp.crop_id = crop.crop_id 
  and gp.line_type_id = lt.line_type_id --and lt.line_type_ref_id in ('FINISHED')
   and  gp.germplasm_id = gm.germplasm_id
   and gm.genetic_material_id = inv.genetic_material_id
   and inv.br_prog_id = brp.br_prog_id
   ;
   

/*****************************************************************************/
/******** Midas Product Name ********/
/*****************************************************************************/
SELECT  PN.product_name_id AS "Product Name Id", 
        PN.product_id AS "Product Id",
        PN.name AS "Product Name",
        Cr.name AS "Crop Name",
        Cr.crop_id,
        Co.name AS "Country Name", 
        co.country_id,
        B.name AS "Brand Name",
        b.brand_id,
        p.ref_active as "product",
        PN.ref_active AS "prodname"
  FROM  Midas_Product_Name PN,
        Midas_Product P,
        Midas_Crop Cr,
        Midas_Country Co, 
        Midas_Brand B
    
 WHERE --PN.product_name_id   /*Place Midas Name Id List Between Parens*/  in (1352177811456)
	p.product_id in  (3168982269952)
	
--pn.name in ( 'DK312','EXP438') 
   and  PN.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PN.country_id = Co.country_id
   AND  PN.brand_id = B.brand_id
ORDER BY p.product_id, pn.name;

select * from Midas.Brand@prem b, midas.company@prem c where b.name = 'MONSANTO' and c.company_id = b.company_id;

select * from Mirage2.companies@ceregn where company_name = 'DEKALB';
-- Check Mirage

SELECT  SP.product_id AS "Seed Product Id",
        SP.product_name AS "Product Name",
        SP.crop_bayer_code AS "Bayer Code",
        Co.country_name AS "Country Name",
        B.company_name AS "Brand Name",
        SP.enabled AS "Enabled",
        sp.audit_insert_date,
        sp.audit_update_date, sp.audit_userid,
        sp.trait_characteristic_code, kw.value, m.maturity_rating,
        sp.equivalent_product_id
        
FROM  Mirage_Seed_Product SP,
        Mirage_Country Co,
        Mirage_Company B,
        Mirage2.kw@ceregn kw,
        Mirage2.seed_products_maturity@ceregn m
--WHERE SP.product_id IN (18968)
where sp.product_name in ('MON810')

   AND  SP.country_code = Co.country_code
   AND  SP.company_id = B.company_id
   and sp.trait_characteristic_code = kw.code (+)
   and sp.product_id = m.product_id (+)
ORDER BY sp.product_name;


-- Emily's, check for trials.

SELECT DISTINCT T.EXPERIMENT_NUMBER, U.MAIL_ADDRESS, 
P.PRODUCT_NAME, MIRAGE2.KW.NAME, C.COUNTRY_NAME, p.product_id			  									  			
FROM MIRAGE2.EXPERIMENTS@ceregn E
, MIRAGE2.TREATMENT_LIST@ceregn T
, MIRAGE2.SEED_PRODUCTS@ceregn P
, MIRAGE2.USERS@ceregn U
, MIRAGE2.KW@ceregn KW
, MIRAGE2.COUNTRIES@ceregn C
WHERE T.SEED_PRODUCT_ID (+) = P.PRODUCT_ID 
AND T.EXPERIMENT_NUMBER = E.EXPERIMENT_NUMBER 
AND E.INVESTIGATOR_NUMBER = U.INVESTIGATOR_NUMBER 
AND E.STATUS_CODE = MIRAGE2.KW.CODE 
AND T.SEED_PRODUCT_ID in (1381348,
1381347,
3072
)
AND U.COUNTRY_CODE = C.COUNTRY_CODE
ORDER BY P.PRODUCT_NAME;


select * from mirage2.companies@ceregn where company_name = 'MONSANTO';
--Select * from Yldstg.MAP_CROP_MIRAGE@prem mcm;

/*****************************************************************************/
/******** Map Product Mirage ********/
/*****************************************************************************/
SELECT  MPM.seed_product_id AS "Seed Product Id",
        MPM.mirage_name AS "Product Name",
        MPM.product_pk AS "Midas Product Id",
        MPM.genetic_material_pk AS "Genetic Material Id"
  FROM  Map_Product_Mirage MPM
 WHERE MPM.seed_product_id IN /*Place Seed Product Id List Between Parens*/  (29996)
--mpm.genetic_material_pk in (2452067647488,2452066009088);

	--	MPM.mirage_name in ('NSL0181','SAVANNAH' )

;

/*****************************************************************************/
/******** Lexicon Product Name/Product Stage ********/
/*****************************************************************************/
SELECT p.product_pubkey as "Product Pubkey",
       Cr.crop_name AS "Crop",
        P.pre_coml_name AS "Pre Commercial Name",
        PS.product_stage_pubkey AS "Name Pubkey",
        B.brand_name AS "Brand Name",
		PS.commercial_name AS "Commercial Name",
        Co.country_name AS "Country",
        CTS.stack_abbr as "trait", cts.td_name as "td name",
        PS.is_active AS "Is Active"
 FROM  Lexicon.Product_Stage PS,
       Lexicon.Pre_Coml_Product P,
       Lexicon.Crop Cr,
        Lexicon.Country Co,
       Lexicon.Brand B,
       Lexicon.Coml_Trait_Stack2 CTS
--WHERE --b.brand_name <> 'MONSANTO' and co.country_abbr = 'USA' and cr.crop_name = 'CORN'
-- where P.product_pubkey in  ('36708409')
--where p.pre_coml_name in ('SF08OL')
where --ps.commercial_name in ('AG7010','DK752','DK834','AG2002', 'AG7010')
 PS.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
  AND  PS.country_id = Co.country_id
  AND  PS.brand_id = B.brand_id
 and ps.coml_trait_stack_id = cts.coml_trait_stack_id (+)
 and p.logical_delete = 'n' and ps.logical_delete = 'n' and ps.is_active = 'y'
and p.product_pubkey in ('36152009',
'35637009',
'35637609',
'36152109',
'36155909',
'36151109',
'36078809',
'35627809',
'35641709',
'36156509',
'35998309',
'36034809',
'35594609',
'36050309',
'36067409',
'36067509',
'36067609',
'36067709',
'36067809',
'35602009',
'36067209',
'36067309',
'36073309',
'36073409',
'36073509',
'35566009',
'36074009',
'36074109',
'36074209',
'36074309',
'36074409',
'36074709',
'35616409',
'36075409',
'36079009',
'36079109',
'35614909',
'36077609',
'36077709',
'36077909',
'36078409',
'36078509',
'36078609',
'36078709',
'35566409',
'36078909',
'35614209',
'35567609',
'36094409',
'35614309',
'36094509',
'36094609',
'35614409',
'36094709',
'35614509',
'36094809',
'36094909',
'35614609',
'36095109',
'35614709',
'35612609',
'35567409',
'36092009',
'35612709',
'36092109',
'35612809',
'36092209',
'36092309',
'35612909',
'36092409',
'36092509',
'35613009',
'36092609',
'35613109',
'36092709',
'36092809',
'35613209',
'36092909',
'36093009',
'35613309',
'36093109',
'35613409',
'35567509',
'36093209',
'35613509',
'36093309',
'35613709',
'36093609',
'36093709',
'35613809',
'36093809',
'35613909',
'36093909',
'36094009',
'35614009',
'36094109',
'36094209',
'35614109',
'36094309',
'36089009',
'36089109',
'35611709',
'36090609',
'36090709',
'36090809',
'35611909',
'36090909',
'35612009',
'36091009',
'36091109',
'35612109',
'36091209',
'36091309',
'35612209',
'36091409',
'35612309',
'36091509',
'35612409',
'36091709',
'36091809',
'35612509',
'36091909',
'36085409',
'36085509',
'36085609',
'36085709',
'35566909',
'36085809',
'36085909',
'36086009',
'36086109',
'36086409',
'36086609',
'36086709',
'36086809',
'36086909',
'35567009',
'36087009',
'36087109',
'35610809',
'36104809',
'35610909',
'36104909',
'36105009',
'35611009',
'36105109',
'36105209',
'35611109',
'36105309',
'35611209',
'35568509',
'36105409',
'35611309',
'36105509',
'35611409',
'35611509',
'36105809',
'36105909',
'36084909',
'36085009',
'36085109',
'36085209',
'36085309',
'36101609',
'36101809',
'35609009',
'36102309',
'35609509',
'36099509',
'36099809',
'36100209',
'36100709',
'36097809',
'36097909',
'35567909',
'36098109',
'36098209',
'36098409',
'36098509',
'36098609',
'36098709',
'36098809',
'35568009',
'36099209',
'36096409',
'36096509',
'36096609',
'35567809',
'36097109',
'36097209',
'36097309',
'36097409',
'36097509',
'36097609',
'36097709',
'36115609',
'35625709',
'36115709',
'35625809',
'35569409',
'36115909',
'35626009',
'35626109',
'36116309',
'36116509',
'36095509',
'35567709',
'36095609',
'36095709',
'36095809',
'36095909',
'36096009',
'36096109',
'36096209',
'36113809',
'36113909',
'35624609',
'36114009',
'36114109',
'35624709',
'36114209',
'35624809',
'36114309',
'36114409',
'35624909',
'36114509',
'36114609',
'35625009',
'35569309',
'35625109',
'36114709',
'36114809',
'35625209',
'36114909',
'35625309',
'36115009',
'36115109',
'35625409',
'36115209',
'36115309',
'35625509',
'36115409',
'35625609',
'36115509',
'35623209',
'36111909',
'36112009',
'35623309',
'36112109',
'35623409',
'36112209',
'35569109',
'35623509',
'36112309',
'36112409',
'35623609',
'36112509',
'35623709',
'36112609',
'36112709',
'35623809',
'36112809',
'35623909',
'36112909',
'36113009',
'35624009',
'36113109',
'36113209',
'35624109',
'36113309',
'35624209',
'36113409',
'35569209',
'35624309',
'36113509',
'36113609',
'35624409',
'36113709',
'35624509',
'36109809',
'36109909',
'36110209',
'36110309',
'36110409',
'36110509',
'35622909',
'36111409',
'36111509',
'35623009',
'36111609',
'35623109',
'36111709',
'36111809',
'36109509',
'36109609',
'36109709',
'35568909',
'36126209',
'36124009',
'36123109',
'36123809',
'35620709',
'35620809',
'36123909',
'36120809',
'36120909',
'36121209',
'36119309',
'36119409',
'36119509',
'36119609',
'36119709',
'36119909',
'36120109',
'36120209',
'36120609',
'36117809',
'36118809',
'36134609',
'35617509',
'35617609',
'36134809',
'36133009',
'36133109',
'36133209',
'35633809',
'35633909',
'36133409',
'36127809',
'36127909',
'35632109',
'36146509',
'36146609',
'35630009',
'35630209',
'36142109',
'35630309',
'35630409',
'36142309',
'36142409',
'36142609',
'36142709',
'35631109',
'35629309',
'36138209',
'36138509',
'36138609',
'36139009',
'35559609',
'36140009',
'36140209',
'36140409',
'36140509',
'36140609',
'36140709',
'36140809',
'36140909',
'36141209',
'35629509',
'35629609',
'36153809',
'36154209',
'35628509',
'36154309',
'35628609',
'36154409',
'35628709',
'36154609',
'35628809',
'36154709',
'36151209',
'36151309',
'36151409',
'35642009',
'35642109',
'36151609',
'36151809',
'35642309',
'36151909',
'35642409',
'35626609',
'35626709',
'36152209',
'35626809',
'36152309',
'35626909',
'36152409',
'35627009',
'36152509',
'36152609',
'35627109',
'35627509',
'36153209',
'35627609',
'36153309',
'35627709',
'36153409',
'36147309',
'36147409',
'36147509',
'36147609',
'36147709',
'36147809',
'36148009',
'36148109',
'36148209',
'35560109',
'36148309',
'36148409',
'36148609',
'36148709',
'36149009',
'36149109',
'36149209',
'36149309',
'36149509',
'36149609',
'36149809',
'36149909',
'36150109',
'36150209',
'36150309',
'36150409',
'36150509',
'35560209',
'36150609',
'36150709',
'36150809',
'36150909',
'36151009',
'35641809',
'36162109',
'35640209',
'36162309',
'35640309',
'35560909',
'36162409',
'35640409',
'36162509',
'36162609',
'35640509',
'36162709',
'36162809',
'36162909',
'36163009',
'35640709',
'36163109',
'36163209',
'35640809',
'36163309',
'35640909',
'36163409',
'36163509',
'35641009',
'36163609',
'35561009',
'35641109',
'36163709',
'36163809',
'35641209',
'36163909',
'36164009',
'35641309',
'36164109',
'36164209',
'35641409',
'36164309',
'36164409',
'35641509',
'36164509',
'35641609',
'36146709',
'36146809',
'36146909',
'36147009',
'36147109',
'36147209',
'35639209',
'36160509',
'36160609',
'35639309',
'36160709',
'36160809',
'35639409',
'36160909',
'36161009',
'35639509',
'36161109',
'35639709',
'35639809',
'36161509',
'36161609',
'35639909',
'36161809',
'35640009',
'36161909',
'36162009',
'35640109',
'36157509',
'36157609',
'36157709',
'36157809',
'36157909',
'35560609',
'36158109',
'36158209',
'36158309',
'36158509',
'36158609',
'35638109',
'35638309',
'36158909',
'36159109',
'36159209',
'36159409',
'35638609',
'36159509',
'36159609',
'35560709',
'35638809',
'36159909',
'36160009',
'35639009',
'36160109',
'36160209',
'35639109',
'36160309',
'36160409',
'36171609',
'35637209',
'36171709',
'35637309',
'36171809',
'35637409',
'36171909',
'35637509',
'36172009',
'36172109',
'36172209',
'35637709',
'36172309',
'35637809',
'36172409',
'35637909',
'35561609',
'36155309',
'36155409',
'36155609',
'36155709',
'36155809',
'36156009',
'36156109',
'35560509',
'36156609',
'36156709',
'36156909',
'36157109',
'36157209',
'36157309',
'36169409',
'35635209',
'36169509',
'35635309',
'36169609',
'35635409',
'36169709',
'36169909',
'35635609',
'36170009',
'35635709',
'36170109',
'35635809',
'36170209',
'35635909',
'36170509',
'36170609',
'35636209',
'36170709',
'35636309',
'36170809',
'35636409',
'35561509',
'35636509',
'36170909',
'36171009',
'35636609',
'36171109',
'35636709',
'36171209',
'35636809',
'36171309',
'36171409',
'36171509',
'35637109',
'36166909',
'36167109',
'36167209',
'36168009',
'35561309',
'35649809',
'36168209',
'35649909',
'36168309',
'35650009',
'36168409',
'35650109',
'36168509',
'35650209',
'36168609',
'35650309',
'36168709',
'35650409',
'36168809',
'35650509',
'36168909',
'35634709',
'36169009',
'35634809',
'36169109',
'35634909',
'36169209',
'35648709',
'36181209',
'35648809',
'36181309',
'36181409',
'35648909',
'35562309',
'35649009',
'35647409',
'36179209',
'36179309',
'36180409',
'35648109',
'36177409',
'36177509',
'36177609',
'36177709',
'35646709',
'36178609',
'35647109',
'36179009',
'36175109',
'36175209',
'36175309',
'36175409',
'36175509',
'36175609',
'36175709',
'36175809',
'36176209',
'36176409',
'36176909',
'36173709',
'36173809',
'36174309',
'36174409',
'35561809',
'36174609',
'36175009',
'36191009',
'36191209',
'36192009',
'35563109',
'36192109',
'35646609',
'36172709',
'35645709',
'36188209',
'36187409',
'36188109',
'36478809',
'36478909',
'35538509',
'36479209',
'36478209',
'36479109',
'35747709',
'36477209',
'36477309',
'36477409',
'35747909',
'35539309',
'36520709',
'35771809',
'35771909',
'36520609',
'36521609',
'36521809',
'36522109',
'36522209',
'36470009',
'36470109',
'35751309',
'36470309',
'35751409',
'36468209',
'36469709',
'35749409',
'36480209',
'35751609',
'36470809',
'35751709',
'36468009',
'36468109',
'36463609',
'35541909',
'36521009',
'35772109',
'36521409',
'35772209',
'36520409',
'35791309',
'35790009',
'36559709',
'36558509',
'36552209',
'36688709',
'36708009',
'35837009',
'35473009',
'35714809',
'35714909',
'35731109',
'36417909',
'35714109',
'36417109',
'36417709',
'35745509',
'37110109',
'37110509',
'37110609',
'37111109',
'37111309',
'37111509',
'37111809',
'37111909',
'37112009',
'37112309',
'37257309',
'37259209',
'37257609',
'37257709',
'37257909',
'37258009',
'37258709',
'37258809',
'37258909',
'37259109',
'37259309',
'37259409',
'37672409',
'38315909',
'38480909',
'38481309',
'38481809')

order by "Commercial Name";

   
SELECT  --PN.product_name_id AS "Product Name Id",
        
        PN.product_id AS "Product Id",
        p.product_pubkey as "Product Pubkey",
        Cr.crop_name AS "Crop Name",
      --  p.logical_delete as "prod is deleted",
     --   NULL AS "Pre Commercial Name",
         PN.product_name_pubkey AS "Name Pubkey",
		 B.brand_name AS "Brand Name",
		 PN.product_name AS "Commercial Name",
         Co.country_name AS "Country Name",
    --    'CP' AS "Stage Abbr",
        PN.is_active AS "Is Active",
        PN.logical_delete AS "pn is deleted",
        p.logical_delete as "prod is deleted"
  FROM  Lexicon.Product_Name PN,
        Lexicon.Product P,
        Lexicon.Bayer_Code BC,
        Lexicon.Crop Cr,
        Lexicon.Country Co,
        Lexicon.Brand B
 --WHERE  PN.product_name_pubkey in   ('7507')
-- where p.product_pubkey = '3171402'
 where PN.product_name in ('GARRA')
   and  PN.product_id = P.product_id
   AND  P.bayer_code_id = BC.bayer_code_id
   AND  BC.crop_id = Cr.crop_id
   AND  PN.country_id = Co.country_id
   AND  PN.brand_id = B.brand_id
   --and p.logical_delete = 'n' and pn.logical_delete = 'n'
Order by "Brand Name", "Commercial Name", "Country Name";

-- Run to get all the manf names with a version of "SAME".
select pr.manufacturing_name, pcp.pre_coml_name, prx.trait_version, ps.production_status_name
from Lexicon.product_relationship pr, 
     lexicon.pre_coml_product pcp, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps
where pcp.product_id = prx.product_id 
and prx.product_relationship_id = pr.product_relationship_id 
and prx.production_status_id = ps.production_status_id
and prx.trait_version = 'SAME'
order by pr.manufacturing_name; 

-- 

select distinct pr.manufacturing_name, pcp.pre_coml_name, pst.commercial_name
from Lexicon.product_relationship pr, 
     lexicon.pre_coml_product pcp, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps,
     lexicon.product_stage pst
where pcp.product_id = prx.product_id 
and pcp.product_id = pst.product_id
and prx.product_relationship_id = pr.product_relationship_id 
and prx.production_status_id = ps.production_status_id
and pr.manufacturing_name like '%+HCL421BT1'  
--pr.manufacturing_name like 'HCL312CRW2+%' or 
--pr.manufacturing_name like 'HCL312RR2+%')
;

select distinct pr.product_relationship_id, pr.manufacturing_name, pcp.product_id, pcp.pre_coml_name, prx.trait_version, ps.production_status_name, pst.commercial_name
from Lexicon.product_relationship pr, 
     lexicon.pre_coml_product pcp, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps,
     lexicon.product_stage pst
where pcp.product_id = prx.product_id 
and pcp.product_id = pst.product_id
and prx.product_relationship_id = pr.product_relationship_id 
and prx.production_status_id = ps.production_status_id
and pr.manufacturing_name like '%HCL312CRW2%'  ;




-- Display pre-com'l name, manf name, trait version and production status for corn inbreds

select distinct pcp.pre_coml_name, pr.manufacturing_name, st.commercial_name, prx.trait_version, ps.production_status_name
from lexicon.pre_coml_product pcp,
     lexicon.product_relationship pr, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps,
     lexicon.crop c,
     lexicon.product_stage st,
     lexicon.country ct,
     midas.product_germplasm@prem pg,
     midas.germplasm@prem g,
     fbs_common.product_xref@prem px,
     midas.line_type@prem lt
     
where pcp.product_id = prx.product_id (+)
and prx.product_relationship_id = pr.product_relationship_id (+)
and prx.production_status_id = ps.production_status_id(+)
and pcp.crop_id = c.crop_id and c.crop_name = 'CORN'
and pcp.product_id = st.product_id 
and pcp.product_pubkey = px.lexicon_product_pubkey
and px.midas_product_id = pg.product_id
and pg.germplasm_id = g.germplasm_id
and g.line_type_id = lt.line_type_id and lt.line_type_ref_id = 'HYBRID'
and st.country_id = ct.country_id and ct.country_abbr = 'USA'
and pcp.logical_delete = 'n' and st.is_active = 'y'
and pcp.pre_coml_name not like '%+%' 
and pr.manufacturing_name is not null
and st.commercial_name is null
order by pr.manufacturing_name;


select distinct pcp.pre_coml_name, pr.manufacturing_name, --st.commercial_name, 
prx.trait_version, ps.production_status_name, pcp.logical_delete
from lexicon.pre_coml_product pcp,
     lexicon.product_relationship pr, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps,
     lexicon.crop c
  --   lexicon.product_stage st,
 --    lexicon.country ct,
  --   midas.product_germplasm@prem pg,
  --   midas.germplasm@prem g,
  --   fbs_common.product_xref@prem px,
  --   midas.line_type@prem lt
     
where pcp.product_id = prx.product_id (+)
and prx.product_relationship_id = pr.product_relationship_id (+)
and prx.production_status_id = ps.production_status_id(+)
and pcp.crop_id = c.crop_id and c.crop_name = 'CORN'
--and pcp.product_id = st.product_id 
--and pcp.product_pubkey = px.lexicon_product_pubkey
--and px.midas_product_id = pg.product_id
--and pg.germplasm_id = g.germplasm_id
--and g.line_type_id = lt.line_type_id and lt.line_type_ref_id = 'HYBRID'
--and st.country_id = ct.country_id and ct.country_abbr = 'USA'
--and pcp.logical_delete = 'n' and st.is_active = 'y'
and pr.manufacturing_name in (
'HCL118RR2',
'HCL212CRW2RR2',
'HCL317RR2-3',
'HCL4008BT1',
'HCL443BT1CRW2',
'HCL5001BT1',
'HCL502BT1',
'HCL6008BT1',
'HCL6046BT1',
'HCL610BT1-2',
'HCL617CRW2-3',
'HCL624CRW2',
'HCL626BT1CRW2',
'HCL626CRW2',
'HOI001LY038A',
'LH167BT1',
'LH177CCR1+LH295CCR1',
'LH242RR2',
'LH283BT1WX',
'LH287ALS2',
'LH287BT1WX',
'LH311CCR1+LH310CCR1',
'LH312BT1CRW2-1',
'LH313CCR1',
'LH313RR2',
'LH324WX',
'LH327BT1',
'LH333BT1RR2',
'LH334BT1CRW2',
'LH352BT1',
'LH354BT1',
'LH363RR2',
'LH371BT1',
'LH382RR2',
'LH401BT1RR2',
'MBS1236RR2',
'MO17RFELVGHT100 50 100',
'SGI917BT1CRW2')
order by pr.manufacturing_name;

-- find line codes matching in MIDAS

select distinct g.line_code, g.origin
from midas.germplasm@prem g, midas.crop@prem c
where g.crop_id = c.crop_id and c.name = 'Corn'
and (g.line_code like 'EX5642%'
or g.line_code like '17QFB1%'
or g.line_code like 'FBLL' 
or g.line_code like '87DUD3'
or g.line_code like 'HCL317'
or g.line_code like '94ISI29'
or g.line_code like '01IKH07'
or g.line_code like '93IFI6'
or g.line_code like '3168'
or g.line_code like '80IDM2'
or g.line_code like '64CBI1'
or g.line_code like 'HOI001'
or g.line_code like 'LH167'
or g.line_code like 'LH242'
or g.line_code like 'LH283'
or g.line_code like 'LH287'
or g.line_code like 'LH312'
or g.line_code like 'GADE208'
or g.line_code like 'LH324'
or g.line_code like 'GAMI020'
or g.line_code like 'LH333'
or g.line_code like 'LH334'
or g.line_code like 'JAGO009'
or g.line_code like 'GAGO802'
or g.line_code like 'GADE016'
or g.line_code like 'LH371'
or g.line_code like 'GADE856'
or g.line_code like 'COME711'
or g.line_code like '4448'
or g.line_code like 'MO17'
or g.line_code like '17INI20'
or g.origin like 'LH177+LH295' 
or g.origin like 'LH311+LH310')
;


select distinct g.line_code, g.origin
from midas.germplasm@prem g, midas.crop@prem c
where g.crop_id = c.crop_id and c.name = 'Corn'
and g.line_code in (
'HCL502BT1',
'SGI917BT1CRW2',
'HCL610BT1-2',
'MBS1236RR2',
'HCL624CRW2',
'HCL617CRW2-3',
'HCL212CRW2RR2',
'HC35RR2-1',
'HOI001LY038A',
'LH167BT1',
'LH242RR2',
'LH283BT1WX',
'LH287ALS2',
'LH287BT1WX',
'LH324WX',
'LH371BT1',
'HCL6046BT1',
'HCL443BT1CRW2',
'LH401BT1RR2',
'LH363RR2',
'LH313CCR1',
'LH313RR2',
'LH382RR2',
'LH354BT1',
'LH327BT1',
'HCL317RR2-3',
'LH352BT1',
'LH312BT1CRW2-1',
'LH333BT1RR2',
'LH334BT1CRW2')
;
    
    
where pcp.product_id = prx.product_id (+)
and prx.product_relationship_id = pr.product_relationship_id (+)
and prx.production_status_id = ps.production_status_id(+)
and pcp.crop_id = c.crop_id and c.crop_name = 'CORN'
and pcp.product_id = st.product_id 
and pcp.product_pubkey = px.lexicon_product_pubkey
and px.midas_product_id = pg.product_id
and pg.germplasm_id = g.germplasm_id
and g.line_type_id = lt.line_type_id and lt.line_type_ref_id = 'HYBRID'
and st.country_id = ct.country_id and ct.country_abbr = 'USA'
and pcp.logical_delete = 'n' and st.is_active = 'y'
and pcp.pre_coml_name not like '%+%' 
and pr.manufacturing_name is null
and st.commercial_name is null
order by pr.manufacturing_name;




select count(*) 
from lexicon.pre_coml_product pcp,
     lexicon.crop c
 where pcp.crop_id = c.crop_id
 and logical_delete = 'n' and c.crop_name = 'CORN' and pcp.pre_coml_name like 'E%';
 
 select count(*)
 from lexicon.product_stage ps, 
      lexicon.pre_coml_product pcp,
      lexicon.crop c
where pcp.crop_id = c.crop_id
     and pcp.product_id = ps.product_id
     and ps.logical_delete = 'n' and ps.is_active = 'y' and ps.commercial_name is null
     and pcp.logical_delete = 'n' and c.crop_name = 'CORN';

-- Find null trait versions in inbred lines

select pr.manufacturing_name, pcp.pre_coml_name, prx.trait_version, ps.production_status_name
from Lexicon.product_relationship pr, 
     lexicon.pre_coml_product pcp, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps
where pcp.product_id = prx.product_id 
and prx.product_relationship_id = pr.product_relationship_id 
and prx.production_status_id = ps.production_status_id
--and prx.trait_version is null
--and (pr.manufacturing_name like '%BT%' or 
--     pr.manufacturing_name like '%RR%' or
 --    pr.manufacturing_name like '%CRW%' or
 --    pr.manufacturing_name like '%CCR%')
and pr.manufacturing_name not like '%+%';


select * --from Lexicon.product_relationship pr, 
From lexicon.pre_coml_product pcp  --, lexicon.product_relationship_xref prx
where --pcp.product_id = prx.product_id and prx.product_relationship_id = pr.product_relationship_id 
pcp.pre_coml_name = '91DUQ1MON863-NK603T1J' 
order by pcp.pre_coml_name;


select count(*) 
from Lexicon.product_relationship pr;


Select * from lexicon.bayer_code where bayer_code_name in ( 'GLXMA');


select * from Lexicon.coml_trait_stack2 s where s.stack_abbr like 'YGCB';
select * from Lexicon.coml_trait_stack2 where stack_desc like '%Ready 2%';

select * from lexicon.brand where brand_name = 'INTERSTATE';

 
select ctn.trait_abbr, ctt.coml_trait_type_abbr 
from Lexicon.coml_trait_name2 ctn, 
lexicon.coml_trait_type_xref2 tx, 
lexicon.coml_trait_type ctt
where ctn.coml_trait_name_id = tx.coml_trait_name_id 
and tx.coml_trait_type_id = ctt.coml_trait_type_id 
and ctt.coml_trait_type_abbr in ('QUALITY', 'DISEASE');

select * from Lexicon.coml_trait_stack_xref2 ctsx where ctsx.coml_trait_name_id in 
('1722',
'1781',
'1691',
'1690',
'1663',
'1752',
'1664',
'1673',
'1733',
'1674',
'1734',
'1662');

select * 
from lexicon.product_stage pn, lexicon.pre_coml_product p, lexicon.crop c, lexicon.coml_trait_stack2 cts
where p.product_id = pn.product_id and p.crop_id = c.crop_id 
and pn.coml_trait_stack_id = cts.coml_trait_stack_id and cts.coml_trait_stack_id in 
('1697',
'1706',
'1726',
'1756',
'1763',
'1763',
'1696',
'1815',
'1725',
'1695');

select * 
from lexicon.product_stage pn, lexicon.pre_coml_product p, lexicon.crop c, lexicon.coml_trait_stack2 cts
where p.product_id = pn.product_id and p.crop_id = c.crop_id 
and pn.coml_trait_stack_id = cts.coml_trait_stack_id
and cts.stack_abbr in ('RR') and c.crop_name = 'ALFALFA';

select *
from lexicon.coml_trait_name2
where coml_trait_name_id in ('1664',
'1673',
'1674',
'1691',
'1722',
'1733',
'1734',
'1752',
'1781',
'1690',
'1662');

select * 
from lexicon.coml_trait_stack2
where coml_trait_stack_id in ('1697',
'1706',
'1726',
'1756',
'1763',
'1763',
'1696',
'1815',
'1725',
'1695');

select *
from lexicon.coml_trait_stack_xref2
where coml_trait_stack_id in ('1697',
'1706',
'1726',
'1756',
'1763',
'1763',
'1696',
'1815',
'1725',
'1695');
Select * from lexicon.coml_trait_name2 where trait_abbr like 'ZAT%';
Select * from lexicon.coml_trait_stack2 where stack_abbr like 'ZAT%';

select * from lexicon.coml_trait_type;

select * from lexicon.company ;
select * from lexicon.crop where crop_name in ('CORN', 'SOYBEANS');


select * from mirage2.kw@ceregn where kw.type = 'TRAIT CHARACTERISTIC';


Select * from yldstg.map_crop_mirage@prem;


