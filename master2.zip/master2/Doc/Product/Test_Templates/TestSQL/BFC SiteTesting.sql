-- Site Testing

-- active sites

select * 
from Regulatory.Site s
where s.status = 0
and s.country = 'Canada';
and s.country = 'Argentina';
and s.country not in ('Canada','USA', 'U.S.A.', 'U.S.A');

-- inactive sites
select * 
from Regulatory.Site s
where s.status <> 0;
 
-- select on USA and FL - only active sites are returned in service. 
select * 
from Regulatory.Site s
--where s.state = 'FL'  
--where s.state in ('FL', 'ME')
where s.state in ('MB', 'AB')
and s.status = 0
and  s.country = 'Canada';

-- select on USA and an island/township
select * 
from Regulatory.Site s
where --s.state = 'HI'
--and  s.country = 'USA'
s.status = 0
and s.company like 'Holden%'
and s.township_island = 'Molokai';

-- select on USA and states 
select * 
from Regulatory.Site s
--where s.state  in ('AL') and s.city not like ('Auburn%') and s.city not like ('Court%')
where s.city <> 'Freeville' and s.county like 'Tom%'
and s.status = 0;
--and  s.country = 'USA';

-- search on zip code
select * 
from Regulatory.Site s
where s.status = 0
--and s.zip_code = '33458';
and s.zip_code like '95%' and s.city not like 'Davis%'
and s.company like '%Research%';
--and s.zip_code = '32495' ;

-- Search on company name.
select * 
from Regulatory.Site s
where s.country = 'USA'
and  s.status = 0
and (s.company like '%Education Center%' or s.company like '%Extension Center%');

-- Search on Partial City name.
select * 
from Regulatory.Site s
where s.country = 'USA'
and s.status = 0
--and s.city in ('Biggs', 'Fresno') ;
and s.city like 'Casa%';
-- search on partial county names
select * 
from Regulatory.Site s
where s.country = 'USA'
and s.status = 0
and s.county in ('Adams', 'Tipton');

--search on city and partial company name
select * 
from Regulatory.Site s
where s.country = 'USA'
and s.status = 0
and s.city = 'Elwood'
and s.company like '%Farm';

--search on partial address line
select * 
from Regulatory.Site s
where s.address like '%Highway'
and s.status = 0
-- s.site_id = '7767'
;
