select c.country_id, c.country_abbr, c.name, sc.sub_country_id, sc.name, ssc.sub_sub_country_id, ssc.name,
    lc.country_pubkey
from midas.country c,
     midas.sub_country sc,
     midas.sub_sub_country ssc,
     lexicon.country@dsbreed_tst lc,
     fbs_common.country_xref cx
where c.country_id = sc.country_id
  and sc.sub_country_id = ssc.sub_country_id
  and cx.MIDAS_country_id = c.country_id
  and cx.Lexicon_country_pubkey = lc.country_pubkey
  and c.country_abbr in ('USA') --, 'CAN')
  and sc.name in ('Missouri')
 --and ssc.name = 'Molokai'
  order by c.country_abbr, sc.name, ssc.name
  ;

