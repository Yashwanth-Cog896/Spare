Select mu.login_id, mu.first_name, mu.last_name, bp.br_prog_ref_id, crop.name
from midas.BR_Prog_User bpu, 
midas.br_prog bp,
midas.midas_user mu,
midas.crop crop
where bpu.br_prog_id = bp.br_prog_id
and mu.midas_user_id = bpu.midas_user_id
and bp.br_prog_ref_id in ('OX', '17')
and bp.crop_id = crop.crop_id
and mu.last_name = 'Henderson'
order by bp.br_prog_ref_id, mu.last_name, mu.login_id
;

select *
from midas.midas_user@prem_tst
where login_id in ('NGSCHO','KMNYBE');

