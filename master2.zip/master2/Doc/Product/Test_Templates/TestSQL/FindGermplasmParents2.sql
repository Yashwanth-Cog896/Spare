
-- Run query below to get the MIDAS product id.

SELECT  PX.lexicon_product_pubkey AS "Product Pubkey",
        PX.midas_product_id AS "Midas Product Id"
  FROM  FBS_COMMON.Product_Xref@prem PX
WHERE  PX.lexicon_product_pubkey in /*Place Product Pubkey Betwen Quotes*/  ('37288309')
--WHERE PX.MIDAS_PRODUCT_ID IN (123427095105)
;

-- Run query below using product_id to get the MIDAS germplasm, genetic material and parent associations.
-- Run query below using origin to get the MIDAS female or male parent germplasm.

select pg.product_id as "Product _id",
       GP.germplasm_id AS "Germplasm Id",
       gp.pedigree_name as "Pedigree",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        lt.line_type_ref_id as "Line Type",
     --   GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id, --GM.source_str,
        pa.parent_genetic_material_id, pr.name,
        pargp.origin as "parent origin",
        pargp.line_code as "parent line code",
        pargp.germplasm_id as "parent gp",
        pargp.is_finished_or_finished_child as "parent fin",
        pargp.is_deleted as "parent del?"
        
  FROM  Midas.Germplasm@prem GP,
        Midas.Product_Germplasm@prem PG,
        Midas.Line_type@prem lt,
		Midas.Genetic_Material@prem gm,
        Midas.Parentage@prem pa,
        Midas.Parental_role@prem pr,
        midas.genetic_material@prem pargm,
        midas.germplasm@prem pargp
       
 WHERE  pg.product_id in /*Place MIDAS Product Id after */  (3216284385280)
-- gp.germplasm_id = 123427095105
--gp.line_code = '87DUA5NK603T1F'

 -- use to get germplasm with parents
 --gp.origin in /* Place MIDAS origin in quotes */ ('91DZB3MON88017A+91IDI6EZRAT1E')  
 --  and lt.line_type_ref_id in ('HYBRID')  --('CODED', 'FINISHED')

  and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id --(+)
   and gp.line_type_id = lt.line_type_id
   and gm.genetic_material_id = pa.genetic_material_id --(+)
   and pa.parental_role_id = pr.parental_role_id
   and pa.parent_genetic_material_id = pargm.genetic_material_id
   and pargm.germplasm_id  = pargp.germplasm_id
   and gp.is_deleted = 'F'
--   and rownum < 1000
 --  order by pg.product_id, gp.germplasm_id
   
   ;
   select gp.origin, gp.line_code
   from midas.germplasm@prem gp
   where gp.germplasm_id = 2462645354496;
-- Run this query if no results above, this query displays germplasm without parents

select pg.product_id as "Product _id",
       GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id 

  FROM  Midas.Germplasm@prem GP,
        Midas.Product_Germplasm@prem PG,
		Midas.Genetic_Material@prem gm
       
 WHERE  --gp.origin in /* Place MIDAS origin in quotes */ ('02-426-10+286D184E') --++GF9117+NL054B')  --'P56+P57'  -- insert the origin you are looking for --
  pg.product_id =  2462643191808  -- or insert the product_id
--gp.line_code in ('%EZRA%')
--and lt.line_type_ref_id in ('CODED', 'FINISHED')
   and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+)
   ;
   
 -- Run this query to get the product linkages for the parent germplasm_ids
  
   select pg.product_id, gp.germplasm_id
   from midas.germplasm@prem gp, midas.product_germplasm@prem pg
   where gp.germplasm_id = pg.germplasm_id
   and pg.germplasm_id in (123427095105,162126627589); 
20906312024

   

SELECT 
   PX.lexicon_product_pubkey AS LexProductPubkey, 
   PR.parental_role_ref_id AS Sex, 
   ChildGeneticMaterial.genetic_material_id AS ChildGeneticMaterialId 
FROM 
   Midas.Genetic_Material@PREM GM, 
   Midas.Parentage@PREM P, 
   Midas.Parental_Role@PREM PR, 
   Midas.Product_Germplasm@PREM PGP, 
   FBS_Common.Product_Xref@PREM PX, 
   (SELECT GM.genetic_material_id FROM Midas.Genetic_Material@PREM GM WHERE GM.germplasm_id = 338428567) ChildGeneticMaterial 
WHERE 
   P.genetic_material_id = ChildGeneticMaterial.genetic_material_id 
AND   
   P.parent_genetic_material_id = GM.genetic_material_id 
AND   
   GM.germplasm_id = PGP.germplasm_id 
AND  
   PGP.product_id = PX.midas_product_id 
AND   
   P.parental_role_id = PR.parental_role_id 
AND   
   (PR.parental_role_ref_id = 'M' OR PR.parental_role_ref_id = 'F');

select *
from Lexicon.product_stage ps,
lexicon.pre_coml_product p
where ps.product_id = p.product_id
and p.product_pubkey = '2770602';

-- Use to find corn hybrids that don't have a pc-name

select GP.germplasm_id AS "Germplasm Id",
       gp.pedigree_name as "Pedigree",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        lt.line_type_ref_id as "Line Type",
        GP.is_finished_or_finished_child as "is Fin",
        gm.genetic_material_id, --GM.source_str,
        pa.parent_genetic_material_id, pr.name,
        pargp.origin as "parent origin",
        pargp.line_code as "parent line code",
        pargp.germplasm_id as "parent gp",
        pargp.is_finished_or_finished_child as "parent fin",
        pargp.is_deleted as "parent del?"
        
  FROM  Midas.Germplasm@prem GP,
        Midas.Product_Germplasm@prem PG,
        Midas.Line_type@prem lt,
		Midas.Genetic_Material@prem gm,
        Midas.Parentage@prem pa,
        Midas.Parental_role@prem pr,
        midas.genetic_material@prem pargm,
        midas.germplasm@prem pargp
       
 WHERE  lt.line_type_ref_id in ('HYBRID')  --('CODED', 'FINISHED')
 and GP.is_finished_or_finished_child = 'T'
 and gp.event_display is not null
  and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+) and pg.product_id is null
   and gp.line_type_id = lt.line_type_id
   and gm.genetic_material_id = pa.genetic_material_id --(+)
   and pa.parental_role_id = pr.parental_role_id
   and pa.parent_genetic_material_id = pargm.genetic_material_id
   and pargm.germplasm_id  = pargp.germplasm_id
   and gp.is_deleted = 'F'
   and rownum < 1000
 order by gp.origin
   
   ;
