
-- To get the approved regulated acres.

SELECT clg.monsanto_id, cs.site_id, cs.person_id, cs.altsite_id, cs.altperson_id, cs.addresstype,
           per1.person_id, per1.last_name, per1.first_name,
           per2.person_id, per2.last_name, per2.first_name
FROM regulatory.compliance_log clg,  
  	   regulatory.compliance_sites cs,
  	   regulatory.permit_releasesite rs,
  	   regulatory.permit p,
  	   regulatory.person per1,
  	   regulatory.person per2
where clg.comp_id = cs.comp_id
  and rs.permit_id = p.permit_id
  and rs.site_id = cs.site_id
  and cs.person_id = per1.person_id (+)
  and cs.altperson_id = per2.person_id (+)
--  and nvl(cs.altperson_id, cs.person_id) = per.person_id
  and cs.canceled = 0 and cs.dropped = 0 
  and clg.monsanto_id in ('2006-39PR') ; --, '2006-38XRAB');
  
  select p.requested_by
  from regulatory.permit p
  where p.monsanto_id in ('2006-37XRAB') ;
  
select * 
from regulatory.person p
where p.person_id = '2500012550';
-- run to get the construct or pmon for a permit/notification

select p.monsanto_id, pct.details, pct.trans_code, ncppp.pmon_id
from regulatory.permit_const_trans pct, regulatory.permit p, 
regulatory.new_construct_per_plant_pmon ncppp
where pct.permit_id = p.permit_id
and p.crop_id = ncppp.crop_id
and pct.trans_code = ncppp.trans_code
and p.monsanto_id = '2006-39PR';

-- run to get a permit/notification for a particular event or construct.

select p.monsanto_id, p.submission_type,  pct.details, pct.trans_code, ncppp.pmon, ncppp.crop_id
from regulatory.permit_const_trans pct, regulatory.permit p, 
regulatory.new_construct_per_plant_pmon ncppp
where pct.permit_id = p.permit_id
and p.crop_id = ncppp.crop_id
and pct.trans_code = ncppp.trans_code
 --and p.monsanto_id like '2005%'
 --and ncppp.pmon in ('pMON55200','pMON55206')
--and pct.details like '%AT_G3792%'
and pct.trans_code like '%CTB%'

;

-- Run to get a Monsanto_Id, a Site_id. and Crop_name

select            p.submission_type
,                 c.midas_crop_name
,                 cs.site_id
,                 cs.altsite_id
,                 cs.person_id
,                 cs.altperson_id
,                 cs.addresstype
,                 cs.dropped
,                 cs.canceled
,                 cs.status
,                 per.last_name
,                 per.first_name
,                 per.user_id
,                 pct.details AS "events"
,                 p.requested_by
,                 s.company
,                 s.city
,                 s.state
,                 p.monsanto_id
,                 p.agency_id
,                 p.effective
,                 p.expired
,                 p.status
,                 cl.packet_sent
,                 p.eup                                                              
,                 rs.acres AS "Approved Regulated Acres"
from              regulatory.permit p
,                 regulatory.compliance_log cl
,                 regulatory.compliance_sites cs
,                 regulatory.person per
,                 regulatory.crop c
,                 regulatory.site s
,                 regulatory.permit_releasesite rs
,                 regulatory.permit_const_trans pct
,                 regulatory.new_construct_per_plant_pmon cppp
where             p.monsanto_id = cl.monsanto_id
and               cl.comp_id = cs.comp_id
and               nvl(cs.altperson_id, cs.person_id) = per.person_id
and               p.crop_id = c.crop_id
and               nvl(cs.altsite_id, cs.site_id) = s.site_id
and               p.permit_id = rs.permit_id 
and               nvl(cs.altsite_id, cs.site_id) = rs.site_id
and               nvl(cs.altperson_id, cs.person_id) = rs.person_id 
and               cs.releasesite_id = rs.releasesite_id 
and               p.permit_id = pct.permit_id
and               pct.trans_code = cppp.trans_code           
and               p.monsanto_id = '2006-39PR'
--and cs.site_id = 2147305960
  -- use when a specific Monsanto_id is needed.
--and              p.status <> 'USDA Approved'    -- test 6, test 19 and test 26
--and               cs.status = 0   -- ????  what tests?
--and               cs.dropped = 0  -- change to -1 for tests 3, 17, and 23
--and               cs.addresstype = 'S' --('R', 'RS')   -- change to not in for tests 10, 16, 22
--and               cs.canceled = 0    -- change to -1 for tests 2, 18, and 24
--and               p.eup = 'true'                                                         -- need for test 12
--and               sysdate > p.effective and sysdate < p.expired -- this is for an effective, non-expired permit 
--and               sysdate < p.effective   -- uncomment for test 10 and 16-21 and comment out the line above
--and                r sysdate < p.expired  -- uncomment for test 1 and 16-21 and comment out the line 2 above
--and               sysdate < cl.packet_sent            -- test 7 to fail
--and             per.last_name = 'Claywell'
order by site_id
;
-- run this query for EUP data fields test 12
select * 
from regulatory.compliance_sites cs,
     regulatory.compliance_log cl
where cs.comp_id = cl.comp_id
and cl.monsanto_id in ('2006-37XRAB','2006-38XRAB');

select            c.midas_crop_name
,                 cs.site_id
,                 cs.altsite_id
,                 cs.person_id
,                 cs.altperson_id
,                 cs.addresstype
,                 per.last_name
,                 per.first_name
,                 per.user_id
,                 pct.details AS "events"
,                 s.company
,                 s.city
,                 s.state
,                 p.monsanto_id
,                 p.agency_id
,                 p.effective
,                 p.expired
,                 p.status
,                 p.EUP_docname
,                 cl.packet_sent
,                 rs.acres AS "Approved Regulated Acres"
,                 pp.protocol_EUP_acres
,                 ref.value
from              regulatory.permit p
,                 regulatory.compliance_log cl
,                 regulatory.compliance_sites cs
,                 regulatory.person per
,                 regulatory.crop c
,                 regulatory.site s
,                 regulatory.permit_protocol pp
,                 regulatory.reference ref                                       
,                 regulatory.permit_releasesite rs                           
,                 regulatory.permit_const_trans pct
,                 regulatory.new_construct_per_plant_pmon cppp
where             p.monsanto_id = cl.monsanto_id
and               cl.comp_id = cs.comp_id
and               nvl(cs.altperson_id, cs.person_id) = per.person_id
and               p.crop_id = c.crop_id
and               nvl(cs.altsite_id, cs.site_id) = s.site_id
and               p.permit_id = pp.protocol_permit_id                                  -- need for test 12
and               nvl(cs.altsite_id, cs.site_id) = pp.protocol_site_id                 -- need for test 12
and               nvl(cs.altperson_id, cs.person_id) = pp.protocol_person_id           -- need for test 12
and               cs.releasesite_id = pp.releasesite_id                                -- need for test 12
and               pp.protocol_code = ref.code and ref.type = '18'  and pp.status = 0   -- need for test 12
and               p.permit_id = rs.permit_id 
and               nvl(cs.altsite_id, cs.site_id) = rs.site_id 
and               nvl(cs.altperson_id, cs.person_id) = rs.person_id 
and               cs.releasesite_id = rs.releasesite_id 
and               p.permit_id = pct.permit_id
and               pct.trans_code = cppp.trans_code           
and               p.monsanto_id = '2006-38XRAB' -- use when a specific Monsanto_id is needed.
--and              p.status <> 'USDA Approved'    -- test 6, test 19 and test 26
and               cs.status = 0   -- ????  what tests?
and               cs.dropped = 0  -- change to -1 for tests 3, 17, and 23
and               cs.addresstype not in ('R', 'RS')   -- change to not in for tests 10, 16, 22
and               cs.canceled = 0    -- change to -1 for tests 2, 18, and 24                                                 
and               sysdate > p.effective and sysdate < p.expired -- this is for an effective, non-expired permit 
--and               sysdate < p.effective   -- uncomment for test 10 and 16-21 and comment out the line above
--and               sysdate < p.expired  -- uncomment for test 1 and 16-21 and comment out the line 2 above
--and               sysdate < cl.packet_sent            -- test 7 to fail
;
select * from regulatory.person where person_id = 
2500012550;
-- Use this query to test for SITEs using a site_id.



select p.monsanto_id, p.effective, p.expired, p.status, p.agency_id, p.submission_type, p.application_type, clg.packet_sent
from regulatory.permit p,
     regulatory.compliance_log clg
where p.monsanto_id = clg.monsanto_id
and p.monsanto_id in ('2006-37XRAB', '2006-38XRAB', '2006-40XRAB', 
'2006-39PR', '2006-41PR', '2006-42XRAB', '2006-43XR')
;
