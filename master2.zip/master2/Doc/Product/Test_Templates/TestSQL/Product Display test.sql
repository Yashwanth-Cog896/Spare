/*****************************************************************************/
/******** FBS Common Product Xref ********/
/*****************************************************************************/
SELECT  PX.lexicon_product_pubkey AS "Product Pubkey",
        PX.midas_product_id AS "Midas Product Id"
  FROM  FBS_Prod_Xref PX
where  PX.lexicon_product_pubkey in /*Place Product Pubkey Betwen Quotes*/  ('38086109');
 --where PX.midas_product_id in (1350970834944);

-- run for Monsanto products
select p.product_pubkey, p.logical_delete, pn.product_stage_pubkey, pn.logical_delete
from lexicon.pre_coml_product p, lexicon.product_stage pn
where p.product_id = pn.product_id and p.product_pubkey in ('38086109');
 
 -- run for Competitor products
select p.product_pubkey, p.product_id, p.logical_delete, pn.product_name_pubkey, pn.logical_delete
from lexicon.product p, lexicon.product_name pn
where p.product_id = pn.product_id and p.product_pubkey  in   ('35999809')
order by pn.logical_delete, p.product_pubkey;
/*****************************************************************************/
/******** FBS Common Product Name Xref ********/
/*****************************************************************************/
SELECT  PNX.lexicon_product_name_pubkey AS "Name Pubkey",
		PNX.midas_product_name_id AS "Midas Name Id",
		PNX.mirage_product_id AS "Seed Product Id"
  FROM  FBS_Prod_Name_Xref PNX
 where pnx.lexicon_product_name_pubkey in ('79603612', '79603712')
-- where pnx.lexicon_product_name_pubkey in ('2485007','4209607')
-- where pnx.mirage_product_id in (1714779,1714784)
 --where pnx.midas_product_name_id = 2462733041664
order by pnx.lexicon_product_name_pubkey
;



select * from lexicon.brand b, lexicon.company c where b.company_id = c.company_id and b.brand_name = 'AGAR CROSS';
select * from fbs_common.brand_xref@prem_tst bx where bx.lexicon_brand_pubkey = 643701;   --2462415257600
Select * from midas.brand@prem_tst mb, midas.company@prem_tst c 
where mb.company_id = c.company_id and mb.brand_id = 2460701491200; --= and mb.name = 'CHAMPION';
-- WHERE  PNX.lexicon_product_name_pubkey IN /*Place Name Pubkey List Between Parens*/ ('210207',
--'2147507','2147607','2147807','2148007','3318007','4030207','3171807','2147907','2147707','369907');
/*****************************************************************************/
/******** Midas Product ********/
/*****************************************************************************/
SELECT  *
  FROM  Midas_Product P, midas.crop@prem_tst crop
 WHERE  p.crop_id = crop.crop_id and P.product_id /*Place Midas Product Id After This*/ 
 in (3450105561088)
;

select * from yldstg.map_crop_mirage@prem_tst;

/*****************************************************************************/
/******** Midas Germplasm (by Product) ********/
/*****************************************************************************/
SELECT  PGP.product_id AS "Product Id",
        crp.name as "Crop",
		GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        GP.is_transgenic,
        lt.line_type_ref_id,
        gm.genetic_material_id, GM.source_str
 --       brp.br_prog_ref_id, brp.name
  FROM  Midas_Product_Germplasm PGP,
        Midas_Germplasm GP,
        Midas.Genetic_Material@prem_tst gm,
        Midas.Line_Type@prem_tst lt,
        Midas.crop@prem_tst crp
	--	,
    --    midas.inventory@prem inv,
    --    midas.br_prog@prem brp
 WHERE  PGP.product_id /*Place Midas Product Id After This*/  in (2333422911488)

-- gm.source_str = 'PRE-COMMERCIAL PRODUCT IMPORT 11/29/2005 MIRAGE USE ONLY'
--gm.genetic_material_id =1384881913856

  --   PGP.germplasm_id (+) = GP.germplasm_id and pgp.product_id is null
   and pgp.germplasm_id = gp.germplasm_id
   and gp.crop_id = crp.crop_id
   and gp.germplasm_id = gm.germplasm_id
   and gp.line_type_id = lt.line_type_id
 --  and lt.line_type_ref_id in ('CODED', 'FINISHED')
 --  and crp.name = 'Soybeans'
--   and gm.genetic_material_id = inv.genetic_material_id
 --  and inv.br_prog_id = brp.br_prog_id
 --  and gp.crop_id = 65929216 -- canola
 --   and gp.crop_id =65863680 -- wheat
--   and pgp.product_id = 2462383734784
 --   AND gp.origin like '%H5269%';
-- and rownum < 500
    ;
    
    select * from midas.line_type@prem_tst;
    
  --  select * from Midas.Crop@prem Crop;
    
 --  Select gp.germplasm_id, gm.genetic_material_id, gm.source_str
 --  from Midas_Germplasm gp, Midas_Genetic_Material gm
  -- where gp.germplasm_id = gm.germplasm_Id and gp.germplasm_id in ;

    
    



/*****************************************************************************/
/******** Midas Product Name ********/
/*****************************************************************************/
SELECT  PN.product_name_id AS "Product Name Id", 
        PN.product_id AS "Product Id",
        PN.name AS "Product Name",
        Cr.name AS "Crop Name",
        Co.name AS "Country Name", 
        B.name AS "Brand Name",
        PN.ref_active AS "Ref Active"
  FROM  Midas_Product_Name PN,
        Midas_Product P,
        Midas_Crop Cr,
        Midas_Country Co, 
        Midas_Brand B
    
 WHERE  
--	pn.product_name_id in (3449517637632)

P.product_id in (3450105561088)

--p.ref_active = 'F' and cr.name = 'Corn'
   --PN.name in ('NC4801NRR2')
   and  PN.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PN.country_id = Co.country_id
   AND  PN.brand_id = B.brand_id
--   and rownum < 50
ORDER BY pn.product_name_id;


-- Check Mirage

SELECT 
 SP.product_id AS "Seed Product Id",
        SP.product_name AS "Product Name",
        SP.crop_bayer_code AS "Bayer Code",
        Co.country_name AS "Country Name",
        B.company_name AS "Brand Name",
        SP.enabled AS "Enabled",
      sp.audit_insert_date, sp.audit_update_date, sp.audit_userid,
  sp.trait_characteristic_code, kw.value, kw.name,
  spm.maturity_rating
    
  FROM  Mirage_Seed_Product SP,
        Mirage_Country Co,
        Mirage_Company B,
        Mirage2.kw@ceregn_tst kw,
        mirage2.seed_products_maturity@ceregn_tst spm
     
where
SP.product_id IN /*Place Seed Product Id List Between Parens*/   (1715180,1715183,1715187)

--sp.product_name in ('NC5808NRR1','DKC5808X')
   AND  SP.country_code = Co.country_code
   AND  SP.company_id = B.company_id
   and sp.trait_characteristic_code = kw.code (+)
   and sp.product_id = spm.product_id (+)
ORDER BY sp.product_name;

-- Emily's, check for trials.

SELECT DISTINCT T.EXPERIMENT_NUMBER, U.MAIL_ADDRESS, 
P.PRODUCT_NAME, MIRAGE2.KW.NAME, C.COUNTRY_NAME, p.product_id			  									  			
FROM MIRAGE2.EXPERIMENTS@ceregn_tst E
, MIRAGE2.TREATMENT_LIST@ceregn_tst T
, MIRAGE2.SEED_PRODUCTS@ceregn_tst P
, MIRAGE2.USERS@ceregn_tst U
, MIRAGE2.KW@ceregn_tst KW
, MIRAGE2.COUNTRIES@ceregn_tst C
WHERE T.SEED_PRODUCT_ID (+) = P.PRODUCT_ID 
AND T.EXPERIMENT_NUMBER = E.EXPERIMENT_NUMBER 
AND E.INVESTIGATOR_NUMBER = U.INVESTIGATOR_NUMBER 
AND E.STATUS_CODE = MIRAGE2.KW.CODE 
AND T.SEED_PRODUCT_ID in (1243596,
1314347,
1314348,
1314350,
1314349,
1715084
)
AND U.COUNTRY_CODE = C.COUNTRY_CODE
ORDER BY U.MAIL_ADDRESS, P.PRODUCT_NAME;

--Select * from Yldstg.MAP_CROP_MIRAGE@prem mcm;

/*****************************************************************************/
/******** Map Product Mirage ********/
/*****************************************************************************/
SELECT  MPM.seed_product_id AS "Seed Product Id",
        MPM.mirage_name AS "Product Name",
        MPM.product_pk AS "Midas Product Id",
        MPM.genetic_material_pk AS "Genetic Material Id"
  FROM  Map_Product_Mirage MPM
 WHERE  MPM.seed_product_id IN /*Place Seed Product Id List Between Parens*/  (1715180,1715183,1715187);
	--	MPM.mirage_name = 'NC6613' ;



/*****************************************************************************/
/******** Lexicon Product Name Monsanto Product ********/
/*****************************************************************************/
SELECT  PS.product_stage_id AS "Product Name Id",
        PS.product_stage_pubkey AS "Name Pubkey",
        PS.product_id AS "Product Id",
        p.product_pubkey as "product pubkey",
        P.pre_coml_name AS "Pre Commercial Name",
        PS.commercial_name AS "Commercial Name",
        Cr.crop_name AS "Crop Name",
        Co.country_name AS "Country Name",
        B.brand_name AS "Brand Name",
        S.stage_abbr AS "Stage Abbr",
       PS.is_active AS "Is Active",
        PS.logical_delete AS "Is Deleted"
  FROM  Lexicon.Product_Stage PS,
        Lexicon.Pre_Coml_Product P,
        Lexicon.Crop Cr,
        Lexicon.Country Co,
        Lexicon.Brand B,
        Lexicon.Stage S
 WHERE  ps.product_stage_pubkey IN /*Place Name Pubkey List Between Parens*/  ('77179012','77179112')

   AND  PS.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PS.country_id = Co.country_id
   AND  PS.brand_id = B.brand_id
   AND  PS.stage_id = S.stage_id
   ;
   select * from lexicon.crop;
   select * 
   from lexicon.pre_coml_product p
   where Ps.product_stage_pubkey IN  ('74955412');
   
   select *
   from lexicon.product_stage ps
   where ps.product_id = '71979';

--Product Name - Competitive Product
   
SELECT  PN.product_name_id AS "Product Name Id",
        PN.product_name_pubkey AS "Name Pubkey",
        PN.product_id AS "Product Id",
        NULL AS "Pre Commercial Name",
        PN.product_name AS "Commercial Name",
        Cr.crop_name AS "Crop Name",
        Co.country_name AS "Country Name",
        B.brand_name AS "Brand Name",
        'CP' AS "Stage Abbr",
        PN.is_active AS "Is Active",
        PN.logical_delete AS "Is Deleted"
  FROM  Lexicon.Product_Name PN,
        Lexicon.Product P,
        Lexicon.Bayer_Code BC,
        Lexicon.Crop Cr,
        Lexicon.Country Co,
        Lexicon.Brand B
 WHERE  Pn.product_name_pubkey IN /*Place Name Pubkey List Between Parens*/ 
('75363512')
 --pn.product_name = 'ZCT7076'

   AND  PN.product_id = P.product_id
   AND  P.bayer_code_id = BC.bayer_code_id
   AND  BC.crop_id = Cr.crop_id
   AND  PN.country_id = Co.country_id
   AND  PN.brand_id = B.brand_id
ORDER BY "Country Name", "Brand Name";

-- Run to get products that are in Lexicon, and not in Mirage for testing that product flows 
-- to Mirage when editing in Lexicon.

SELECT  PS.product_stage_id AS "Product Name Id",
        PS.product_stage_pubkey AS "Name Pubkey",
        PS.product_id AS "Product Id",
        p.product_pubkey as "product pubkey",
        P.pre_coml_name AS "Pre Commercial Name",
        PS.commercial_name AS "Commercial Name",
        Cr.crop_name AS "Crop Name",
        Co.country_name AS "Country Name",
        B.brand_name AS "Brand Name",
        S.stage_abbr AS "Stage Abbr",
        PS.is_active AS "Is Active",
        PS.logical_delete AS "Is Deleted"
  FROM  Lexicon.Product_Stage PS,
        Lexicon.Pre_Coml_Product P,
        Lexicon.Crop Cr,
        Lexicon.Country Co,
        Lexicon.Brand B,
        Lexicon.Stage S,
        FBS_COMMON.Product_Name_Xref@prem_tst PNX
       
 WHERE  ps.product_stage_pubkey = pnx.Lexicon_product_name_pubkey
   and  PNX.Mirage_product_id is null
   and  b.brand_name = 'MONSANTO' and s.stage_abbr <> 'INBR'
   and  p.pre_coml_name like 'NC%'
   AND  PS.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PS.country_id = Co.country_id
   AND  PS.brand_id = B.brand_id
   AND  PS.stage_id = S.stage_id
   ;


-- Run to get all the manf names with a version of "SAME".
select pr.manufacturing_name, pcp.pre_coml_name, prx.trait_version, ps.production_status_name
from Lexicon.product_relationship pr, 
     lexicon.pre_coml_product pcp, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps
where pcp.product_id = prx.product_id 
and prx.product_relationship_id = pr.product_relationship_id 
and prx.production_status_id = ps.production_status_id
and prx.trait_version = 'SAME'
order by pr.manufacturing_name; 

-- Lists all the trait versions with one being "SAME".

select pr.manufacturing_name, pcp.pre_coml_name, prx.trait_version, ps.production_status_name
from Lexicon.product_relationship pr, 
     lexicon.pre_coml_product pcp, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps
where pcp.product_id = prx.product_id 
and prx.product_relationship_id = pr.product_relationship_id 
and prx.production_status_id = ps.production_status_id
and pr.manufacturing_name in (
'AXN1006RR',
'HC33',
'HC33CRW2-2',
'HC33RR2-2',
'HC34BT1RR2-1',
'HC37CRW2-1',
'HC37RR2-1',
'HC50RR2-1',
'HC51RR2-1',
'HC53RR2-1',
'HC60',
'HC60BT1-1',
'HC60RR2-1',
'LH198CCR1',
'LH244CRW2RR2-1',
'LH277CCR1',
'LH283CCR1',
'LH283CRW2-1',
'LH287BT1CRW2-1',
'LH287CCR1',
'LH295CCR1',
'LH295CRW2-1',
'LH311CRW2-1',
'LH324RR2-1',
'LH332RR2-1');

-- Display pre-com'l name, manf name, trait version and production status for corn inbreds

select distinct pcp.pre_coml_name, pr.manufacturing_name, st.commercial_name, prx.trait_version, ps.production_status_name
from lexicon.pre_coml_product pcp,
     lexicon.product_relationship pr, 
     lexicon.product_relationship_xref prx,
     lexicon.production_status ps,
     lexicon.crop c,
     lexicon.product_stage st,
     lexicon.country ct,
     midas.product_germplasm@prem pg,
     midas.germplasm@prem g,
     fbs_common.product_xref@prem px,
     midas.line_type@prem lt
     
where pcp.product_id = prx.product_id (+)
and prx.product_relationship_id = pr.product_relationship_id (+)
and prx.production_status_id = ps.production_status_id(+)
and pcp.crop_id = c.crop_id and c.crop_name = 'CORN'
and pcp.product_id = st.product_id 
and pcp.product_pubkey = px.lexicon_product_pubkey
and px.midas_product_id = pg.product_id
and pg.germplasm_id = g.germplasm_id
and g.line_type_id = lt.line_type_id and lt.line_type_ref_id = 'HYBRID'
and st.country_id = ct.country_id and ct.country_abbr = 'USA'
and pcp.logical_delete = 'n' and st.is_active = 'y'
and pcp.pre_coml_name not like '%+%' 
and pr.manufacturing_name is not null
and st.commercial_name is null
order by pr.manufacturing_name;

------------------------------------------------------------------------

select * 
from lexicon.Pre_coml_product pcp, lexicon.product_relationship_xref prx, lexicon.product_relationship pr
where pcp.product_id = prx.product_id and prx.product_relationship_id = pr.product_relationship_id
and pcp.pre_coml_name in ('NE5678EZD1','2FP45-5NK603B','3MZN-1EZRAC');

select * 
from lexicon.Pre_coml_product pcp
where pcp.pre_coml_name like '91DUQ1MON863-NK603T1%';
select * 
from lexicon.Pre_coml_product pcp, lexicon.product_relationship_xref prx, lexicon.product_relationship pr
where pcp.product_id = prx.product_id and prx.product_relationship_id = pr.product_relationship_id
and pcp.pre_coml_name like '418NK603%';

select * 
from Midas.product_name@prem_tst pn
where pn.name = '418NK603C';

select * 
from lexicon.product_relationship_xref;

select *
from lexicon.product_relationship;

