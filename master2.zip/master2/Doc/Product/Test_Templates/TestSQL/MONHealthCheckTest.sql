-- Monsanto Product Health Check
-- Test 1:  Product in Lexicon, not in FBS_COMMON

select p.product_Pubkey, ps.product_stage_pubkey
from lexicon.pre_coml_product p,
     lexicon.product_stage ps,
     fbs_common.product_xref@prem_tst px     
where p.product_pubkey = px.lexicon_product_pubkey (+)
  and px.lexicon_product_pubkey is null
  and ps.logical_delete = 'n' and p.logical_delete = 'n'
  and p.product_id = ps.product_id;

  
-- Test 2: Product_stage in Lexicon, not in FBS_COMMON

select ps.product_stage_pubkey, ps.commercial_name
from lexicon.product_stage ps,
     fbs_common.product_name_xref@prem_tst px     
where ps.product_stage_pubkey = px.lexicon_product_name_pubkey (+)
  and px.lexicon_product_name_pubkey is null
  and ps.logical_delete = 'n'
  and rownum < 1000;
  
-- Test 3: Com'l name has 2 pre-com'l product names

select ps.product_stage_pubkey, ps.commercial_name
from lexicon.product_stage ps,
(
    select q1.commercial_name
    from
    (
        select ps.commercial_name, p.product_id
        from lexicon.product_stage ps,
             lexicon.pre_coml_product p
        where ps.product_id = p.product_id 
        and ps.logical_delete = 'n' and p.logical_delete = 'n'
        group by ps.commercial_name, p.product_id
    ) q1
    group by q1.commercial_name
    having count(*) > 1
)q2
where ps.commercial_name = q2.commercial_name;


-- Test 4: Find a product where product_stage has different transgenic traits.
-- Ask Katie, what is this test?  Different by country?  or different than Mirage?

-- To test, get into Lexicon and make a product with several countries have transgenic traits that don't match.
-- For instance, for corn, 1st country make the trait RR2, 2nd country make the trait YGCB.  This should display
-- on the report if they've captured this edit.


-- Test 5: Find a pre-com'l product with invalid characters.

select p.product_pubkey, ps.product_stage_pubkey, p.pre_coml_name
from lexicon.pre_coml_product p,
     lexicon.product_stage ps     
where p.product_id = ps.product_id 
  and ps.logical_delete = 'n' and p.logical_delete = 'n'
  and p.pre_coml_name like '% %'
  and rownum < 500;

-- Test 6:  Find a commercial product with invalid characters.
-- Need to add a commercial name with invalid characters.  I add product names with "%', '$', and '^' to test with.
-- Don't fix these.

select *
from lexicon.product_stage ps 
where ps.logical_delete = 'n' and ps.commercial_name like '%$%';

-- Test 7: Find product that is not logically deleted and doesn't have product stages.

select p.product_pubkey, ps.product_stage_pubkey, p.pre_coml_name
from lexicon.pre_coml_product p,
     lexicon.product_stage ps     
where p.product_id = ps.product_id (+) and ps.product_stage_id is null
  and p.logical_delete = 'n';
  
-- Test 8:  Not on Katie's list is that the product_stage records exist, and are all logically deleted.

select p.product_pubkey, ps.product_stage_pubkey, p.pre_coml_name, ps.logical_delete
from lexicon.pre_coml_product p,
     lexicon.product_stage ps     
where p.product_id = ps.product_id 
  and ps.logical_delete = 'y' 
  and p.logical_delete = 'n';

-- find the not-logically deleted product, and delete it to get a good test.
select p.product_pubkey, ps.product_stage_pubkey, p.pre_coml_name, ps.logical_delete
from lexicon.pre_coml_product p,
     lexicon.product_stage ps     
where p.product_id = ps.product_id 
  and ps.logical_delete = 'n' 
  and p.product_pubkey = '37204309';
  
  
-- This query isn't working, I need all the product_stages to be logically deleted.
select ps.product_stage_pubkey, ps.commercial_name
from lexicon.product_stage ps,
(
    select q1.commercial_name
    from
    (
        select ps.commercial_name, p.product_id
        from lexicon.product_stage ps,
             lexicon.pre_coml_product p
        where ps.product_id = p.product_id 
        and ps.logical_delete = 'y' and p.logical_delete = 'n'
        group by ps.commercial_name, p.product_id
    ) q1
    group by q1.commercial_name
    having count(*) > 1
)q2
where ps.commercial_name = q2.commercial_name;
