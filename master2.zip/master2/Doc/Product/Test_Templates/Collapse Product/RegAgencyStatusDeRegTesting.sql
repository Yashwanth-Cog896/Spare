-- queries to test de-regulated event service

Select rr.regulatory_region_abbr as "Region",--rr.regulatory_region_name, 
       c.country_abbr as "Ctry", --c.country_name,
       a.regulatory_agency_name as "Agency", 
       cts.stack_abbr as "Trait Stk", cts.reporting_name as "Rpt Name", 
       rst.status_name "Status", rst.is_deregulated "Dereg?", 
       ras.notification_date "Notify Date",
       tn.trait_abbr "Trt Name", 
       ex.event_pubkey "Event", 
       crop.crop_name "Crop"
from lexicon.regulatory_region rr,
     lexicon.ctry_reg_region_xref rx,
     lexicon.country c,
     lexicon.regulatory_agency a,
     lexicon.regulatory_agency_status ras,
     lexicon.coml_trait_stack2 cts,
     lexicon.regulatory_status_type rst,
     lexicon.coml_trait_stack_xref2 cx,
     lexicon.coml_trait_name2 tn,
     lexicon.event_coml_trait_xref ex,
     lexicon.crop crop
where rr.regulatory_region_id = rx.regulatory_region_id
and c.country_id = rx.country_id
and rr.regulatory_region_id = a.regulatory_region_id
and a.regulatory_agency_id = ras.regulatory_agency_id
and ras.coml_trait_stack_id = cts.coml_trait_stack_id
and ras.status_type_id = rst.status_type_id
and cts.coml_trait_stack_id = cx.coml_trait_stack_id
and cx.coml_trait_name_id = tn.coml_trait_name_id
and tn.coml_trait_name_id = ex.coml_trait_name_id
and ex.crop_id = crop.crop_id
and cts.crop_id = crop.crop_id
and c.country_abbr = 'USA'
order by cts.stack_abbr, ex.event_pubkey;
