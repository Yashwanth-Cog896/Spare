-- Test 2:  brand does match in Lexicon and Mirage
select ps.product_stage_pubkey
from lexicon.product_stage ps, 
lexicon.brand b, 
mirage2.companies@ceregn_tst c, 
mirage2.seed_products@ceregn_tst  sp,
fbs_common.product_name_xref@prem_tst pnx,
fbs_common.brand_xref@prem_tst bx
where b.brand_id = ps.brand_id
and c.company_id = bx.mirage_company_id
and b.brand_pubkey = bx.lexicon_brand_pubkey
and ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and sp.product_id = pnx.mirage_product_id
and b.brand_name <> c.company_name;

--country does match in Lexicon and Mirage
select ps.product_stage_pubkey
from lexicon.product_stage ps, 
lexicon.country c, 
mirage2.countries@ceregn_tst mc, 
mirage2.seed_products@ceregn_tst  sp,
fbs_common.product_name_xref@prem_tst pnx,
fbs_common.country_xref@prem_tst bx
where c.country_id = ps.country_id
and mc.country_code = bx.mirage_country_code
and c.country_pubkey = bx.lexicon_country_pubkey
and ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and sp.product_id = pnx.mirage_product_id
and c.country_name <> mc.country_name;


--coml product name does not match in Lexicon and Mirage
select ps.product_stage_pubkey, ps.commercial_name
from lexicon.product_stage ps, 
mirage2.seed_products@ceregn_tst  sp,
fbs_common.product_name_xref@prem_tst pnx
where ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and sp.product_id = pnx.mirage_product_id
and ps.logical_delete = 'n'
and ps.commercial_name <> sp.product_name;

--pre-coml product does not match Lexicon and Mirage
select p.product_pubkey, p.pre_coml_name
from lexicon.pre_coml_product p,
lexicon.product_stage ps,  
mirage2.seed_products@ceregn_tst sp,
fbs_common.product_name_xref@prem_tst pnx
where ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and p.product_id = ps.product_id
and sp.product_id = pnx.mirage_product_id
and ps.logical_delete = 'n'
and p.logical_delete = 'n'
and p.pre_coml_name <> sp.product_name;

--Mirage product not in YldStg mapping table
select ps.product_stage_pubkey
from lexicon.product_stage ps,
mirage2.seed_products@ceregn_tst sp,
fbs_common.product_name_xref@prem_tst px,
yldstg.map_product_mirage@prem_tst mpm
where ps.product_stage_pubkey = px.lexicon_product_name_pubkey
and sp.product_id = px.mirage_product_id
and sp.product_id = mpm.seed_product_id
and ps.logical_delete = 'n'
and mpm.seed_product_id is null;

--Maturity does not match in Lexicon and Mirage
select ps.product_stage_pubkey
from lexicon.product_stage ps, 
mirage2.seed_products@ceregn_tst sp,
fbs_common.product_name_xref@prem_tst pnx,
mirage2.seed_products_maturity@ceregn_tst m
where m.product_id = sp.product_id
and ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and sp.product_id = pnx.mirage_product_id
and ps.logical_delete = 'n'
and ps.commercial_maturity <> m.maturity_rating;

--Lexicon active_flag does not match Mirage enabled flag
select ps.product_stage_pubkey
from lexicon.product_stage ps, 
mirage2.seed_products@ceregn_tst sp,
fbs_common.product_name_xref@prem_tst pnx
where ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and sp.product_id = pnx.mirage_product_id
and ps.logical_delete = 'n'
and pnx.mirage_product_id is not null
and ps.is_active = 'y'
and sp.enabled = 'N';

select ps.product_stage_pubkey
from lexicon.product_stage ps, 
mirage2.seed_products@ceregn_tst sp,
fbs_common.product_name_xref@prem_tst pnx
where ps.product_stage_pubkey = pnx.lexicon_product_name_pubkey
and sp.product_id = pnx.mirage_product_id
and ps.logical_delete = 'n'
and pnx.mirage_product_id is not null
and ps.is_active = 'n'
and sp.enabled = 'Y';


