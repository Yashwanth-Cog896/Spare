SELECT distinct a.it_construct, a.it_event, a.it_generation
  FROM virgo_tst.genetic_item a
 -- where rownum < 500;
 --where a.it_event in ( 'LY061' );
where a.it_event like '30048';

  
  
SELECT distinct a.it_construct, a.it_event, a.it_generation
  FROM virgo_tst.genetic_item a
  where a.it_event = ('LAJ136,ZM_S1090');
 
 (TR002,ZM_S1090); (TR002,ZM_S1093); (TR006,ZM_S1090); (TR012,TR044,ZM_S1090); (TR012,ZM_S1090); (TR089,ZM_S1090); (TR091,ZM_S1090); (TR093,ZM_S1090); (TR094,ZM_S1090); (TR097,TR146,ZM_S1090)

  
  SELECT distinct a.it_construct, a.it_event
  FROM virgo.genetic_item a
  where a.it_construct in ( 'pMON55221,pMON36136', 'pMON36136,pMON55221')
  --and a.it_generation = 'R0';


