-- Test 1:  Test using 'and' feature by entering a stack.  
-- On the screen enter RR2, YGCB, YGRW, and USA in the country, and compare to the query below.

SELECT  P.product_pubkey as "Product Pubkey",
        PS.product_id AS "Product Id",
        P.pre_coml_name AS "Pre Commercial Name",
        PS.product_stage_pubkey AS "Name Pubkey",
        B.brand_name AS "Brand Name",
		PS.commercial_name AS "Commercial Name",
        CO.country_abbr AS "Country",
        PS.is_active AS "Is Active",
        CTS.stack_abbr as "Com'l trait"
        
 FROM  Lexicon.Product_Stage PS,
       Lexicon.Pre_Coml_Product P,
       Lexicon.Country Co,
       Lexicon.Brand B,
       Lexicon.Coml_Trait_Stack2 CTS

WHERE  PS.product_id = P.product_id
  AND  PS.country_id = CO.country_id
  AND  PS.brand_id = B.brand_id
  AND  PS.coml_trait_stack_id = CTS.coml_trait_stack_id
  AND  CTS.stack_abbr like '%RR2/YGCB/YGRW%'
  AND  CO.country_abbr = 'USA'
AND ps.logical_delete = 'n'
  
ORDER BY "Brand Name", "Commercial Name", "Country"
 ;
 
-- Test 2:  Test using 'or' feature by entering a list of traits, and verifying a product with any of 
-- the traits listed displays. 
-- On the screen enter HOLEIC,LOWLIN and USA in the country, and compare to the query below.

SELECT  P.product_pubkey as "Product Pubkey",
        PS.product_id AS "Product Id",
        P.pre_coml_name AS "Pre Commercial Name",
        PS.product_stage_pubkey AS "Name Pubkey",
        B.brand_name AS "Brand Name",
		PS.commercial_name AS "Commercial Name",
        CO.country_abbr AS "Country",
        PS.is_active AS "Is Active",
        CTS.stack_abbr as "Com'l trait"
        
 FROM  Lexicon.Product_Stage PS,
       Lexicon.Pre_Coml_Product P,
       Lexicon.Country Co,
       Lexicon.Brand B,
       Lexicon.Coml_Trait_Stack2 CTS

WHERE  PS.product_id = P.product_id
  AND  PS.country_id = CO.country_id
  AND  PS.brand_id = B.brand_id
  AND  PS.coml_trait_stack_id = CTS.coml_trait_stack_id
  AND  (CTS.stack_abbr like '%HOLEIC%' or CTS.stack_abbr like '%LOWLIN%')
  AND  CO.country_abbr = 'USA'
AND ps.logical_delete = 'n'
  
ORDER BY "Brand Name", "Commercial Name", "Country"
 ;

