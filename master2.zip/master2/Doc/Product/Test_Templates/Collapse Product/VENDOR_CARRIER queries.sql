SELECT vc.vendor_carrier_id, vc.vendor_id, vu.vendor_unique_name
  FROM lexicon.vendor_carrier vc, lexicon.vendor_unique vu
  where vc.vendor_id = vu.vendor_unique_id;
  
SELECT vc.vendor_carrier_id, vc.vendor_id, vu.vendor_unique_id, vu.vendor_unique_name
  FROM lexicon.vendor_carrier vc, lexicon.vendor_unique vu, lexicon.vendor_unique_map vum
  where vc.vendor_carrier_id = vum.vendor_id
  and vum.vendor_unique_id = vu.vendor_unique_id;
  
  
  select * from lexicon.vendor_unique;
  
  select * from lexicon.vendor_carrier vc;
  
  
  
  
  

