BEGIN
    DECLARE
        productName Midas.Germplasm.origin%TYPE := 'CPT4B-DEST';
        cropName Midas.Crop.name%TYPE := 'CORN';
        lineTypeRefId Midas.Line_Type.line_type_ref_id%TYPE := 'HYBRID';
        programRefId Midas.BR_Prog.br_prog_ref_id%TYPE := '13';
        isTransgenic Midas.Germplasm.is_transgenic%TYPE := 'F';
        isFinished Midas.Germplasm.is_finished_or_finished_child%TYPE := 'T';
        eventDisplay Midas.Germplasm.event_display%TYPE := null;

        germplasmID Midas.Germplasm.germplasm_id%TYPE;
        cropID Midas.Germplasm.crop_id%TYPE;
        lineTypeID Midas.Germplasm.line_type_id%TYPE;
        programID Midas.Germplasm.owner_br_prog_id%TYPE;
    
    BEGIN
        SELECT  Midas.Get_NextId
          INTO  germplasmID
          FROM  DUAL;
          
        SELECT  crop_id
          INTO  cropID
          FROM  Midas.Crop
         WHERE  UPPER(name) = UPPER(cropName)
           AND  ref_active = 'T';
           
        SELECT  line_type_id
          INTO  lineTypeID
          FROM  Midas.Line_Type
         WHERE  line_type_ref_id = lineTypeRefID
           AND  ref_active = 'T';
           
        SELECT  br_prog_id
          INTO  programID
          FROM  Midas.BR_Prog
         WHERE  br_prog_ref_id = programRefID
           AND  ref_active = 'T';
           
        INSERT 
          INTO  Midas.Germplasm
                (
                    germplasm_id, origin, line_code, pedigree_name,
                    line_type_id, owner_br_prog_id, is_transgenic,
                    crop_id, is_finished_or_finished_child, event_display
                )
        VALUES (
                    germplasmID, productName, productName, productName,
                    lineTypeID, programID, isTransgenic, 
                    cropID, isFinished, eventDisplay
                );
                
        DBMS_OUTPUT.put_line('Germplasm ID: ' || germplasmID);
    END;
END;
