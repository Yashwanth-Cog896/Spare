--Uncomment if you need to link to event, but products that do not have an event will not display.
select --cr.crop_name, etx.event_pubkey, 
ts.stack_abbr, t.trait_abbr,
r.regulatory_region_name, a.regulatory_agency_name,
st.status_name, ts.coml_trait_stack_id, st.status_type_id, S.regulatory_agency_status_id
from lexicon.country c, lexicon.ctry_reg_region_xref crx, lexicon.regulatory_region r, lexicon.regulatory_agency a,
lexicon.regulatory_agency_status s, lexicon.coml_trait_stack2 ts, lexicon.coml_trait_stack_xref2 tsx,
lexicon.coml_trait_name2 t,lexicon.regulatory_status_type st --, lexicon.event_coml_trait_xref etx, lexicon.crop cr
where c.country_id = crx.country_id
and crx.regulatory_region_id = r.regulatory_region_id
and r.regulatory_region_id = a.regulatory_region_id
and a.regulatory_agency_id = s.regulatory_agency_id
and s.coml_trait_stack_id = ts.coml_trait_stack_id
and s.status_type_id = st.status_type_id
and ts.coml_trait_stack_id = tsx.coml_trait_stack_id 
and tsx.coml_trait_name_id = t.coml_trait_name_id
--and t.coml_trait_name_id = etx.coml_trait_name_id
--and etx.crop_id = cr.crop_id
and ts.stack_abbr = 'CCR'
order by t.trait_abbr, r.regulatory_region_name;


update lexicon.regulatory_agency_status s
set s.status_type_id = '1001'
where s.regulatory_agency_status_id = '1351';

begin 
  lexicon.audit_pkg.initialize_staging_p('25160', 'Manual','Creating test date for dereg event service','');
end;

begin
lexicon.audit_pkg.delete_staging_record_p;
end;
