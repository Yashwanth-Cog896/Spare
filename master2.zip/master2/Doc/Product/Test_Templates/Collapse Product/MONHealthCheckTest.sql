-- Monsanto Product Health Check
-- Test 1:  Product in Lexicon, not in FBS_COMMON

select *
from lexicon.pre_coml_product p,
     fbs_common.product_xref@prem_tst px     
where p.product_pubkey = px.lexicon_product_pubkey (+)
  and px.lexicon_product_pubkey is null;

  
-- Test 2: Product_stage in Lexicon, not in FBS_COMMON

select *
from lexicon.product_stage ps,
     fbs_common.product_name_xref@prem_tst px     
where ps.product_stage_pubkey = px.lexicon_product_name_pubkey (+)
  and px.lexicon_product_name_pubkey is null;
  
-- Test 3: Com'l name has 2 pre-com'l product names

--select ps.product_stage_pubkey, q.commercial_name q.foo --, ps.commercial_name, p.pre_coml_name, p.product_pubkey

select ps.product_stage_pubkey, ps.commercial_name
from lexicon.product_stage ps,
(
    select q1.commercial_name
    from
    (
        select ps.commercial_name, p.product_id
        from lexicon.product_stage ps,
             lexicon.pre_coml_product p
        where ps.product_id = p.product_id 
        and ps.logical_delete = 'n' and p.logical_delete = 'n'
        group by ps.commercial_name, p.product_id
    ) q1
    group by q1.commercial_name
    having count(*) > 1
)q2
where ps.commercial_name = q2.commercial_name;




-- plug in a product name from the above query results where a product has > 1 in the precoml column.

select ps.product_stage_pubkey, ps.commercial_name, p.pre_coml_name, p.product_pubkey
from lexicon.product_stage ps,
     lexicon.pre_coml_product p
where p.product_id = ps.product_id 
and ps.commercial_name = '0386CMS';

-- Test 4: 
