-- Test data in header before and after collapse

SELECT h.header_id, h.entry_date, h.src_product_pubkey,
       h.src_product_level_name, h.is_src_competitive,
       h.dst_product_pubkey, h.dst_product_level_name,
       h.is_dst_competitive, h.crop_name, h.remove_src,
       h.audit_requestor, h.audit_comment, h.user_name
  FROM lexicon.product_collapse_audit_header h
  where h.src_product_level_name = 'insert old product name here - pre-coml';
  
  -- Test data in detail before and after collapse
  
  SELECT d.detail_id, d.header_id, d.product_pubkey,
       d.product_name_pubkey, d.product_name, d.brand_name,
       d.country_abbr, d.action
  FROM lexicon.product_collapse_audit_detail d
  where d.product_name = 'insert commercial/product name here';
 
