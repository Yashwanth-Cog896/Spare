BEGIN
	DECLARE
		srceProductPubkey VARCHAR2(20) := '10831809';
		destProductPubkey VARCHAR2(20) := '10832109';
	BEGIN
	    DBMS_OUTPUT.put_line('SOURCE PRODUCT');
	    Test_Pkg.get_product_associations(srceProductPubkey);
	    DBMS_OUTPUT.put_line('');
	    DBMS_OUTPUT.put_line('DEST PRODUCT');
	    Test_Pkg.get_product_associations(destProductPubkey);
	END;
END;


