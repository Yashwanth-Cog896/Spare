
-- Run query below to get the MIDAS product id.

SELECT  PX.lexicon_product_pubkey AS "Product Pubkey",
        PX.midas_product_id AS "Midas Product Id"
  FROM  FBS_Prod_Xref PX
WHERE  PX.lexicon_product_pubkey in /*Place Product Pubkey Betwen Quotes*/  ('36298909')
;

-- Run query below using product_id to get the MIDAS germplasm, genetic material and parent associations.
-- Run query below using origin to get the MIDAS female or male parent germplasm.

select pg.product_id as "Product _id",
       GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        lt.line_type_ref_id as "Line Type",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id, --GM.source_str,
        pa.parent_genetic_material_id, pr.name,
        pargp.origin as "parent origin",
        pargp.line_code as "parent line code",
        pargp.is_finished_or_finished_child as "parent fin"
        
  FROM  Midas.Germplasm@prem GP,
        Midas.Product_Germplasm@prem PG,
        Midas.Line_type@prem lt,
		Midas.Genetic_Material@prem gm,
        Midas.Parentage@prem pa,
        Midas.Parental_role@prem pr,
        midas.genetic_material@prem pargm,
        midas.germplasm@prem pargp
       
 WHERE  pg.product_id = /*Place MIDAS Product Id after */  2333583343616 -- use to get germplasm with parents
-- gp.origin in /* Place MIDAS origin in quotes */ ('02-426-10+286D184E') --++GF9117+NL054B')  --++'  -- use to get female or male origin (missing from hybrid)
--gp.line_code in ('%EZRA%')
 --  and lt.line_type_ref_id in ('HYBRID')  --('CODED', 'FINISHED')
   and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+)
   and gp.line_type_id = lt.line_type_id
   and gm.genetic_material_id = pa.genetic_material_id (+)
   and pa.parental_role_id = pr.parental_role_id
   and pa.parent_genetic_material_id = pargm.genetic_material_id
   and pargm.germplasm_id  = pargp.germplasm_id
--   and rownum < 1000
 --  order by pg.product_id, gp.germplasm_id
   
   ;
   
-- Run this query if no results above, this query displays germplasm without parents

select pg.product_id as "Product _id",
       GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id 

  FROM  Midas.Germplasm@prem GP,
        Midas.Product_Germplasm@prem PG,
		Midas.Genetic_Material@prem gm
       
 WHERE  gp.origin in /* Place MIDAS origin in quotes */ ('02-426-10+286D184E') --++GF9117+NL054B')  --'P56+P57'  -- insert the origin you are looking for --
 -- pg.product_id =  1349205032960  -- or insert the product_id
--gp.line_code in ('%EZRA%')
--and lt.line_type_ref_id in ('CODED', 'FINISHED')
   and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+)
   ;
   
   
   
   select pg.product_id as "Product _id",
       GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        lt.line_type_ref_id as "Line Type",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id, --GM.source_str,
        pa.parent_genetic_material_id, pr.name,
        pargp.origin as "parent origin",
        pargp.line_code as "parent line code",
        pargp.is_finished_or_finished_child as "parent fin"
        
  FROM  Midas.Germplasm@prem GP,
        Midas.Product_Germplasm@prem PG,
        Midas.Line_type@prem lt,
		Midas.Genetic_Material@prem gm,
        Midas.Parentage@prem pa,
        Midas.Parental_role@prem pr,
        midas.genetic_material@prem pargm,
        midas.germplasm@prem pargp
       
 WHERE -- pg.product_id = /*Place MIDAS Product Id after */  1349205032960 -- use to get germplasm with parents
-- gp.origin in /* Place MIDAS origin in quotes */ ('P56', 'P57','4IBZ1A','85DGD1MLMS')  
--++'  -- use to get female or male origin (missing from hybrid)
--and lt.line_type_ref_id in ('CODED', 'FINISHED')
   and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+)
   and gp.line_type_id = lt.line_type_id
   and gm.genetic_material_id = pa.genetic_material_id (+)
   and pa.parental_role_id = pr.parental_role_id
   and pa.parent_genetic_material_id = pargm.genetic_material_id
   and pargm.germplasm_id  = pargp.germplasm_id
   
   
   
   -- Run query below to find germplasm that hasn't been named.

select  GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        lt.line_type_ref_id as "Line Type",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id, GM.source_str,
cr.name as "crop"
      
        
  FROM  Midas.Germplasm@prem_tst GP,
        Midas.Product_Germplasm@prem_tst PG,
        Midas.Line_type@prem_tst lt,
	Midas.Genetic_Material@prem_tst gm,
        Midas.crop@prem_tst cr
       
 WHERE  

   lt.line_type_ref_id in   ('CODED', 'FINISHED') -- ('HYBRID')
   and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+) and pg.product_id is NULL
   and gp.line_type_id = lt.line_type_id
   and gp.crop_id = cr.crop_id
and cr.name= 'Corn'
and rownum <1000;


-- Run query below to find HYBRID that doesn't have a product AND has parents

select 

       GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        lt.line_type_ref_id as "Line Type",
        GP.is_deleted AS "Is Deleted",
        GP.is_finished_or_finished_child,
        gm.genetic_material_id, --GM.source_str,
        pa.parent_genetic_material_id, pr.name,
        pargp.origin as "parent origin",
        pargp.line_code as "parent line code",
        pargp.is_finished_or_finished_child as "parent fin",
        cr.name as "crop"
  FROM  Midas.Germplasm@prem_tst GP,
        Midas.Product_Germplasm@prem_tst PG,
        Midas.Line_type@prem_tst lt,
		Midas.Genetic_Material@prem_tst gm,
        Midas.Parentage@prem_tst pa,
        Midas.Parental_role@prem_tst pr,
        midas.genetic_material@prem_tst pargm,
        midas.germplasm@prem_tst pargp,
midas.crop@prem_tst cr
       
 WHERE  
   lt.line_type_ref_id in ('HYBRID')  --('CODED', 'FINISHED')
   and  gp.germplasm_id = gm.germplasm_id
   and gp.germplasm_id = pg.germplasm_id (+) and pg.product_id is NULL
   and gp.line_type_id = lt.line_type_id
   and gm.genetic_material_id = pa.genetic_material_id (+)
   and pa.parental_role_id = pr.parental_role_id
   and pa.parent_genetic_material_id = pargm.genetic_material_id
   and pargm.germplasm_id  = pargp.germplasm_id
   and rownum < 1000
and gp.crop_id = cr.crop_id
and cr.name= 'Corn'
 --  order by pg.product_id, gp.germplasm_id
