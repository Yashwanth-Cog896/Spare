
-- 1st Service - use to get test data
select a.monsanto_id, a.agency_id, a.effective, a.expired, b.common_name, a.status, a.application_type
from regulatory.permit a, regulatory.crop b
where a.crop_id = b.crop_id 
and a.application_type in ('Interstate Movement and Release', 'Release') --and a.monsanto_id = '2004-4XRAB' 
and (a.status = 'USDA Pending' 
  or (a.status = 'USDA Approved' 
   and  TO_DATE('03/01/2006', 'MM/DD/YYYY') < a.expired)
  )
 ;
   
-- comparing sysdate to effective and expiration dates, replacing 03/30/2006 with system date.


-- 2nd service
-- After Kathi adds Release_County to Permit_releasesite, then we need to replace the county below with the 
-- Release_County.

select a.monsanto_id, a.agency_id, a.effective, a.expired, b.common_name, d.compsite_id, e.company, e.address, e.state, 
 e.city, e.county, e.township_island, e.country, f.user_id
from regulatory.permit a, regulatory.crop b, compliance_log c, compliance_sites d, site e, person f
where a.crop_id = b.crop_id and a.monsanto_id = c.monsanto_id and c.comp_id = d.comp_id 
and ((d.altsite_id is null and d.altsite_id = e.site_id) or (d.altsite_id is not null and d.site_id = e.site_id))
and ((d.altperson_id is null and d.altperson_id = f.person_id) or (d.altperson_id is not null and d.altperson_id = f.person_id))
-- Site Validation
and d.status = 0 and d.canceled = 0 and d.dropped = 0
-- Permit Validation
and a.application_type in ('Interstate Movement and Release', 'Release')
and ((a.status = 'USDA Pending' and d.altsite_id is null) 
		or (a.status = 'USDA Approved' and TO_DATE('03/01/2006', 'MM/DD/YYYY') < a.expired)
   );

--  EXPIRED-10  use this for PACKET_SENT+2 
-- in code, use to_char... instead of to_date...
-- ALT_CC is the alternate compliance coordinator
--(COMPLIANCE_LOG.ALT_CC IS NULL AND PERMIT.PERSON_ID = PERSON.PERSON_ID OR COMPLIANCE_LOG.ALT_CC IS NOT NULL AND COMPLIANCE_LOG.ALT_CC=PERSON.PERSON_ID) 

--and to_char(sysdate,'MM-DD-YYYY') = to_char(EXPIRED-10,'MM-DD-YYYY'

-- New as of April 5, use below for service 2.

--This is the sql for POS2 � added additional criteria for you such as dropped/canceled.  I still do not 
--think the date is correct.

select a.monsanto_id, a.agency_id, a.effective, a.expired, b.common_name, d.site_id, e.company, e.address, e.state, 
 e.city, e.county, e.township_island, e.country, f.user_id
from regulatory.permit a, regulatory.crop b, compliance_log c, compliance_sites d, site e, person f
where a.crop_id = b.crop_id and a.monsanto_id = c.monsanto_id and c.comp_id = d.comp_id 
and ((d.altsite_id is null and d.altsite_id = e.site_id) or (d.altsite_id is not null and d.site_id = e.site_id))
and ((d.altperson_id is null and d.altperson_id = f.person_id) or (d.altperson_id is not null and d.altperson_id = f.person_id))

-- Site Validation

and d.status = 0 and d.canceled = 0 and d.dropped = 0 
--pulls only Planting (release) sites
and d.releasesite_id is not null
-- Permit Validation
and a.application_type in ('Interstate Movement and Release', 'Release')
and ((a.status = 'USDA Pending'))
       or (a.status = 'USDA Approved' and
            (TO_DATE('03/01/2006','MM/DD/YYYY') >= a.effective and  TO_DATE('03/01/2006', 'MM/DD/YYYY') < a.expired)
                  )
   );

 
--As for POS3 � that cannot be accomplished with just one query pull. Here is a basis:

select --a.monsanto_id, 
a.agency_id, a.effective, a.expired, X.event, XX.construct, b.common_name, d.site_id, 
--e.company, e.address, e.state, e.city, e.county, e.township_island, e.country, 
g.acres as "Approved Regulated Acreage",  f.user_id,
 c.packet_sent, h.protocol_eup_acres, a.eup_docname
 
 -- Link Permit_Protocol with Type = 18 in Reference table to get the description for the Protocol_Code, 
 -- which is EUP.Permit_Protocol in the requirements document.

from regulatory.permit a, regulatory.crop b, compliance_log c, compliance_sites d, site e, person f, 
      permit_releasesite g, permit_protocol h
where a.crop_id = b.crop_id and a.monsanto_id = c.monsanto_id and c.comp_id = d.comp_id 
      and d.releasesite_id = g.releasesite_id and g.releasesite_id = h.releasesite_id (+)
and ((d.altsite_id is null and d.altsite_id = e.site_id) or (d.altsite_id is not null and d.site_id = e.site_id))
and ((d.altperson_id is null and d.altperson_id = f.person_id) or (d.altperson_id is not null and d.altperson_id = f.person_id))
-- Site Validation
and d.status = 0 and d.canceled = 0 and d.dropped = 0 and 
--pulls only Planting (release) sites
 d.releasesite_id is not null
 
-- Above result set gives you everything, then start validation 

-- Permit Validation
and a.application_type in ('Interstate Movement and Release', 'Release')
and ((a.status = 'USDA Approved' and
       (TO_DATE('03/01/2006','MM/DD/YYYY') >= a.effective and  TO_DATE('03/01/2006', 'MM/DD/YYYY') < a.expired)
        ));
           
-- Packet Sent Date
and to_char(sysdate,'MM-DD-YYYY') >= to_char(c.packet_sent+2,'MM-DD-YYYY')

-- Event  (submission_type = Notification)
-- Use MIDAS Event and compare to Permit_Trans_Const.details, just like the other service.

-- Construct  (submission_type = Permit)
select distinct c.pmon
            
from regulatory.permit a, regulatory.permit_const_trans b, 
			regulatory.new_construct_per_plant_pmon c, regulatory.crop crp
            
where a.permit_id = b.permit_id and b.trans_code = c.trans_code
            and crp.crop_id = c.crop_id
            and UPPER(c.pmon) = UPPER(Midas.construct))
            and crp.common_name = 'Corn';


--Since you indicated your team did not or does not like to parse through the Monsanto Id, I am implementing 
--a new field called SUBMISSION_TYPE in the PERMIT table.  The value will be either Permit or Notification.  
--I am hoping to get this out by the April 14th.


--  address
SELECT distinct a.state, a.county, a.country
  FROM regulatory.site a
  where a.status = 0;












-- Old stuff from service we did for Novus.

