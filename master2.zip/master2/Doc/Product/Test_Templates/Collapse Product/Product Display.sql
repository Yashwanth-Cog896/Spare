/*****************************************************************************/
/******** FBS Common Product Xref ********/
/*****************************************************************************/
SELECT  PX.lexicon_product_pubkey AS "Product Pubkey",
        PX.midas_product_id AS "Midas Product Id"
  FROM  FBS_Prod_Xref PX
 WHERE  PX.lexicon_product_pubkey = /*Place Product Pubkey Between Quotes*/  '';


 
/*****************************************************************************/
/******** FBS Common Product Name Xref ********/
/*****************************************************************************/
SELECT  PNX.lexicon_product_name_pubkey AS "Name Pubkey",
		PNX.midas_product_name_id AS "Midas Name Id",
		PNX.mirage_product_id AS "Seed Product Id"
  FROM  FBS_Prod_Name_Xref PNX
 WHERE  PNX.lexicon_product_name_pubkey IN /*Place Name Pubkey List Between Parens*/ ();


 
/*****************************************************************************/
/******** Midas Product ********/
/*****************************************************************************/
SELECT  P.product_id AS "Product Id",
        P.ref_active AS "Ref Active"
  FROM  Midas_Product P
 WHERE  P.product_id = /*Place Midas Product Id After This*/;


 
/*****************************************************************************/
/******** Midas Germplasm (by Product) ********/
/*****************************************************************************/
SELECT  PGP.product_id AS "Product Id",
        GP.germplasm_id AS "Germplasm Id",
        GP.origin AS "Origin",
        GP.line_code AS "Line Code",
        GP.is_deleted AS "Is Deleted"
  FROM  Midas_Product_Germplasm PGP,
        Midas_Germplasm GP
 WHERE  PGP.product_id = /*Place Midas Product Id After This*/
   AND  PGP.germplasm_id = GP.germplasm_id;



/*****************************************************************************/
/******** Midas Product Name ********/
/*****************************************************************************/
SELECT  PN.product_name_id AS "Product Name Id", 
        PN.product_id AS "Product Id",
        PN.name AS "Product Name",
        Cr.name AS "Crop Name",
        Co.name AS "Country Name", 
        B.name AS "Brand Name",
        PN.ref_active AS "Ref Active"
  FROM  Midas_Product_Name PN,
        Midas_Product P,
        Midas_Crop Cr,
        Midas_Country Co, 
        Midas_Brand B
 WHERE  PN.product_name_id IN /*Place Midas Name Id List Between Parens*/ () 
--		P.product_id = 
--      PN.name = ''
   AND  PN.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PN.country_id = Co.country_id
   AND  PN.brand_id = B.brand_id
ORDER BY Co.name, B.name;



/*****************************************************************************/
/******** Mirage Seed Product ********/
/*****************************************************************************/
SELECT  SP.product_id AS "Seed Product Id",
        SP.product_name AS "Product Name",
        SP.crop_bayer_code AS "Bayer Code",
        Co.country_name AS "Country Name",
        B.company_name AS "Brand Name",
        SP.enabled AS "Enabled",
        SP.disabled_date AS "Disabled Date"
  FROM  Mirage_Seed_Product SP,
        Mirage_Country Co,
        Mirage_Company B
 WHERE  SP.product_id IN /*Place Seed Product Id List Between Parens*/ ()
--		SP.product_name = ''
   AND  SP.country_code = Co.country_code
   AND  SP.company_id = B.company_id
ORDER BY Co.country_name, B.company_name;



/*****************************************************************************/
/******** Map Product Mirage ********/
/*****************************************************************************/
SELECT  MPM.seed_product_id AS "Seed Product Id",
        MPM.mirage_name AS "Product Name",
        MPM.product_pk AS "Midas Product Id",
        MPM.genetic_material_pk AS "Genetic Material Id"
  FROM  Map_Product_Mirage MPM
 WHERE  MPM.seed_product_id IN /*Place Seed Product Id List Between Parens*/ ();
--		MPM.mirage_name = '' 



/*****************************************************************************/
/******** Lexicon Product Name/Product Stage ********/
/*****************************************************************************/
SELECT  PS.product_stage_id AS "Product Name Id",
        PS.product_stage_pubkey AS "Name Pubkey",
        PS.product_id AS "Product Id",
        P.pre_coml_name AS "Pre Commercial Name",
        PS.commercial_name AS "Commercial Name",
        Cr.crop_name AS "Crop Name",
        Co.country_name AS "Country Name",
        B.brand_name AS "Brand Name",
        S.stage_abbr AS "Stage Abbr",
        PS.is_active AS "Is Active",
        PS.logical_delete AS "Is Deleted"
  FROM  Lexicon.Product_Stage PS,
        Lexicon.Pre_Coml_Product P,
        Lexicon.Crop Cr,
        Lexicon.Country Co,
        Lexicon.Brand B,
        Lexicon.Stage S
 WHERE  PS.product_stage_pubkey IN /*Place Name Pubkey List Between Parens*/ ()
   AND  PS.product_id = P.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PS.country_id = Co.country_id
   AND  PS.brand_id = B.brand_id
   AND  PS.stage_id = S.stage_id

UNION
   
SELECT  PN.product_name_id AS "Product Name Id",
        PN.product_name_pubkey AS "Name Pubkey",
        PN.product_id AS "Product Id",
        NULL AS "Pre Commercial Name",
        PN.product_name AS "Commercial Name",
        Cr.crop_name AS "Crop Name",
        Co.country_name AS "Country Name",
        B.brand_name AS "Brand Name",
        'CP' AS "Stage Abbr",
        PN.is_active AS "Is Active",
        PN.logical_delete AS "Is Deleted"
  FROM  Lexicon.Product_Name PN,
        Lexicon.Product P,
        Lexicon.Bayer_Code BC,
        Lexicon.Crop Cr,
        Lexicon.Country Co,
        Lexicon.Brand B
 WHERE  PN.product_name_pubkey IN /*Place Name Pubkey List Between Parens*/ ()
   AND  PN.product_id = P.product_id
   AND  P.bayer_code_id = BC.bayer_code_id
   AND  BC.crop_id = Cr.crop_id
   AND  PN.country_id = Co.country_id
   AND  PN.brand_id = B.brand_id
ORDER BY "Country Name", "Brand Name";

