SELECT a.audit_header_id, a.audit_operation_type, a.user_party_id,
       a.table_name, a.entry_date, a.primary_key_field1, a.process_name,
       a.audit_comment, a.audit_requestor, d.audit_detail_id, d.column_name, d.new_value, d.old_value
  FROM lexicon.audit_header a, lexicon.audit_detail d
  where a.audit_header_id = d.audit_header_id
  and a.table_name = 'PRODUCT_STAGE'
--  and d.column_name = 'PRE_COML>_PRODUCT'
--  and d.new_value = 'ND4608EZA2'
--  and a.audit_requestor = 'Christelle Etienne'
--  and a.audit_comment like ('%collapse%')
--  and d.old_value = 'cccc'
-- and a.user_party_id = '23228'  -- nancy
and a.audit_operation_type = 'D'
--  and a.entry_date > TO_DATE('04/07/2006', 'MM/DD/YYYY') 
 order by a.entry_date desc
  ;
  
  select a.audit_operation_type, count(*)
  FROM lexicon.audit_header a
  group by a.audit_operation_type;
