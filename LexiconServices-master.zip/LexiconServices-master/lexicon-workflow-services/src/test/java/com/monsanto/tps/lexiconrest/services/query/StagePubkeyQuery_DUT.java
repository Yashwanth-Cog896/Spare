package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.StageDTO;
import com.monsanto.tps.lexiconrest.service.query.StagePubkeyQuery;
import junit.framework.TestCase;

import java.util.*;

/**
 * nbwald - Mar 6, 2008 2:10:36 PM
 */
public class StagePubkeyQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {
        String[] stageRequest = new String[1];
        stageRequest[0] = "dummy";

        StagePubkeyQuery query = new StagePubkeyQuery(stageRequest);
        List<StageDTO> stages = query.find();

        assertEquals(0, stages.size());
    }

    public void testQuery_WithResults()
            throws Exception {
        String[] stageRequest = new String[1];
        stageRequest[0] = "PS1";

        StagePubkeyQuery query = new StagePubkeyQuery(stageRequest);
        List<StageDTO> stages = query.find();

        assertEquals(1, stages.size());
        assertEquals("100", stages.get(0).getStagePubkey());
        assertEquals("PS1", stages.get(0).getStageName());
    }


}
