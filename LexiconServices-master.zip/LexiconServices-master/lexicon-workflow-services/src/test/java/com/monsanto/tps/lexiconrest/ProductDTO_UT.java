package com.monsanto.tps.lexiconrest;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ProductDTO_UT {
    @Test
    public void testBean() throws Exception {
        ProductDTO productDTO = new ProductDTO("test", "1");
        new BeanGetterSetterTester().testBean(productDTO);
    }

}