package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.ProductDTO;
import com.monsanto.tps.lexiconrest.service.query.ProductPubkeyQuery;
import junit.framework.TestCase;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:10:36 PM
 */
public class ProductPubkeyQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {
        String[] productRequest = new String[1];
        productRequest[0] = "dummy";

        ProductPubkeyQuery query = new ProductPubkeyQuery(productRequest);
        List<ProductDTO> products = query.find();

        assertEquals(0, products.size());
    }

    public void testQuery_WithResults()
            throws Exception {
        String[] productRequest = new String[1];
        productRequest[0] = "94IYI3B";

        ProductPubkeyQuery query = new ProductPubkeyQuery(productRequest);
        List<ProductDTO> productDTOs = query.find();

        assertEquals(1, productDTOs.size());
        assertEquals("37034109", productDTOs.get(0).getProductPubkey());
        assertEquals("94IYI3B", productDTOs.get(0).getPreCommercialName());
    }


}
