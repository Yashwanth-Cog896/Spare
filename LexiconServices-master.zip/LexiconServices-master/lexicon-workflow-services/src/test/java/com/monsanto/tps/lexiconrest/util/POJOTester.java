package com.monsanto.tps.lexiconrest.util;

/**
 * Created with IntelliJ IDEA.
 * User: PSETH
 * Time: 12:18 PM
 */

import junit.framework.TestCase;
import org.apache.log4j.Logger;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Created May 25, 2010.
 *
 * @author
 */

public class POJOTester {
    private Logger logger = Logger.getLogger(POJOTester.class);
    private List<String> fieldsToIgnore = new ArrayList<String>();
    private Map<Class, Object> defaultInstanceMap = new HashMap<Class, Object>();

    public POJOTester() {
        initializeDefaultInstanceMap();
    }

    private void initializeDefaultInstanceMap() {
        defaultInstanceMap.put(boolean.class, true);
        defaultInstanceMap.put(byte.class, (byte) 0);
        defaultInstanceMap.put(char.class, '0');
        defaultInstanceMap.put(short.class, (short) 0);
        defaultInstanceMap.put(int.class, 0);
        defaultInstanceMap.put(long.class, (long) 0);
        defaultInstanceMap.put(float.class, 0f);
        defaultInstanceMap.put(double.class, 0d);
        defaultInstanceMap.put(List.class, new ArrayList());
    }

    public POJOTester(List<String> fieldsToIgnore) {
        this.fieldsToIgnore = fieldsToIgnore;
        initializeDefaultInstanceMap();
    }

    public void testInstance(final Object instance) throws Exception {

        List<Field> fields = Arrays.asList(instance.getClass()
                .getDeclaredFields());

        for (Field field : fields) {
            if (hasGetterAndSetter(field)) {
                testGetterAndSetter(field, instance);
            } else {
                if (hasGetter(field)) {
                    testGetter(field, instance);
                }
                if (hasSetter(field)) {
                    testSetter(field, instance);
                }
            }
        }
    }

    public void testInstanceByMethods(final Object instance) throws Exception {

        List<Method> methods = Arrays.asList(instance.getClass()
                .getDeclaredMethods());

        for (Method method : methods) {

            if (!method.isAccessible()) {
                continue;
            }

//            System.out.println(method.getName());

            if (method.getName().startsWith("get")) {

                method.invoke(instance);
            } else if (method.getName().startsWith("set")) {

                Class[] clazz = method.getParameterTypes();

                if (clazz[0].isAssignableFrom(List.class)) {
                    System.out.println("clazz = " + method);
                    method.invoke(instance, new ArrayList());
                } else {

                    method.invoke(instance, clazz[0].newInstance());
                }
            }
        }
    }

    private Method getSetter(final Field field) {
        if (ignoreField(field)) {
            return null;
        }

        Class<?> theClass = field.getDeclaringClass();
        try {
            return theClass.getMethod("set" + nameWithCapital(field), field.getType());
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    private boolean ignoreField(Field field) {
        return field.getName().contains("$") || fieldsToIgnore.contains(field.getName());
    }

    private Method getGetter(final Field field) {
        Class<?> theClass = field.getDeclaringClass();
        if (ignoreField(field)) {
            return null;
        }

        Method theMethod;
        try {
            String s = "get" + nameWithCapital(field);
            theMethod = theClass.getMethod(s);
        } catch (NoSuchMethodException e) {
            try {
                theMethod = theClass.getMethod("is" + nameWithCapital(field));
            } catch (NoSuchMethodException e1) {
                return null;
            }
        }

        if (theMethod != null && !theMethod.getReturnType()
                .equals(field.getType())) {
            theMethod = null;
        }
        return theMethod;
    }

    private String nameWithCapital(final Field field) {
        String result = field.getName();
        return result.replaceFirst("" + result.charAt(0), "" + Character.toUpperCase(result.charAt(0)));
    }

    private boolean hasGetter(final Field field) {
        return getGetter(field) != null;
    }

    private boolean hasSetter(final Field field) {
        return getSetter(field) != null;
    }

    private boolean hasGetterAndSetter(final Field field) {
        return hasGetter(field) && hasSetter(field);
    }

    private void testGetterAndSetter(final Field field, final Object instance) throws Exception {
        Object value = getInstance(field.getType());
        Method getter = getGetter(field);
        Method setter = getSetter(field);

        try {
            setter.invoke(instance, value);
            assertEquals("Failed getter and setter test of field " + field.getName() + " on class " +
                    field.getDeclaringClass().getName(), value, getter.invoke(instance));
        } catch (Exception e) {
            logger.error(e.getMessage());
            TestCase.fail(" exception thrown on field: " + field.getName());
        }
    }

    private void testSetter(final Field field, final Object instance) throws Exception {
        Object value = getInstance(field.getType());
        Method setter = getSetter(field);

        try {
            setter.invoke(instance, value);

            field.setAccessible(true);

            assertEquals("Failed setter test of field " + field.getName() + " on class " +
                    field.getDeclaringClass().getName(), value, field.get(instance));
        } catch (Exception e) {
            logger.error(e.getMessage());
            TestCase.fail("exception thrown on field:" + field.getName());
        }
    }

    private void testGetter(final Field field, final Object instance) throws Exception {
        Object value = getInstance(field.getType());
        Method getter = getGetter(field);

        try {

            field.setAccessible(true);

            field.set(instance, value);
            assertEquals("Failed getter test of field " + field.getName() + " on class " +
                    field.getDeclaringClass().getName(), value, getter.invoke(instance));
        } catch (Exception e) {
            fail("exception thrown on field: " + field.getName());
        }
    }

    @SuppressWarnings({"LoopStatementThatDoesntLoop"})
    private Object getInstance(final Class<?> aClass) throws Exception {
        Object instance = defaultInstanceMap.get(aClass);
        if (instance != null) {
            return instance;
        }

        if (aClass.isEnum()) {
            return aClass.getEnumConstants()[0];
        }

        try {
            return aClass.newInstance();
        } catch (Exception e) {
            Constructor<?>[] constructors = aClass.getDeclaredConstructors();
            for (int i = 0, constructorsLength = constructors.length; i < constructorsLength; i++) {
                Constructor<?> current = constructors[i];
                current.setAccessible(true);

                Class[] parameterTypes = current.getParameterTypes();

                Object[] parameters = new Object[parameterTypes.length];
                for (int j = 0; j < parameterTypes.length; j++) {
                    parameters[j] = getInstance(parameterTypes[j]);
                }
                try {
                    return current.newInstance(parameters);
                } catch (Exception e1) {
                    // continue until valid constructor is found
                }
            }
        }

        return null;
    }
}