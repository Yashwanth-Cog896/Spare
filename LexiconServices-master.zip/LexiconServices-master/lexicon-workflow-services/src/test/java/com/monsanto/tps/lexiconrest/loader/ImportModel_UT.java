/*
$Log$
*/
package com.monsanto.tps.lexiconrest.loader;

import com.monsanto.tps.lexiconrest.util.POJOTester;
import com.monsanto.tps.lexiconrest.util.POJOTester;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 */
public class ImportModel_UT {

    @Test
    public void testPojo() throws Exception {
        new POJOTester().testInstance(new ImportModel());
    }

    @Test
    public void testImportModelConstructor() throws Exception {
        ImportProductModel importProductModel = new ImportProductModel();
        ImportModel importModel = new ImportModel("precommName", importProductModel);
        assertThat(importModel.getPrecommercialName(), is("precommName"));
    }
}
