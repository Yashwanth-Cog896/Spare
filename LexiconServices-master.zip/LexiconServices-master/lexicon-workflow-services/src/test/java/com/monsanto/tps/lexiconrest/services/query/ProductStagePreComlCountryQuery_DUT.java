package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.service.query.ProductStagePreComlCountryQuery;
import junit.framework.TestCase;
import org.junit.Ignore;

/**
 * Created with IntelliJ IDEA.
 * User: pseth
 * Date: 1/19/15
 * Time: 11:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStagePreComlCountryQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {

        String preComlName = "dummy";
        String countryName = "dummy";
        String brandName= "dummy";
        ProductStagePreComlCountryQuery query = new ProductStagePreComlCountryQuery(preComlName, brandName, countryName);
        boolean entryExits = query.entityExists();

        assertEquals(false, entryExits);
    }

//    public void testQuery_WithResults_False()
//            throws Exception {
//
//        String preComlName = "EG5511JRM1";
//        String countryName = "United States of America";
//        ProductStagePreComlCountryQuery query = new ProductStagePreComlCountryQuery(preComlName, countryName);
//        boolean entryExits = query.entityExists();
//
//        assertEquals(false, entryExits);
//
//
//    }

    @Ignore
    public void testQuery_WithResults_True() throws Exception {
        String preComlName = "EG5511JRM1";
        String countryName = "USA";
        String brandName= "MONSANTO";
        ProductStagePreComlCountryQuery query = new ProductStagePreComlCountryQuery(preComlName, brandName, countryName);
        boolean entryExits = query.entityExists();

        assertEquals(false, entryExits);
    }
}
