package com.monsanto.tps.lexiconrest;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class BrandDTO_UT {
    @Test
    public void testBean() throws Exception {
        BrandDTO brandDTO = new BrandDTO("1", "India");
        new BeanGetterSetterTester().testBean(brandDTO);
    }

}