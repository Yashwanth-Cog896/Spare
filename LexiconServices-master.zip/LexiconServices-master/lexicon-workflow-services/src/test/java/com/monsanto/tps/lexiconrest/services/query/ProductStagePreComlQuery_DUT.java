package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.service.query.ProductStagePreComlQuery;
import junit.framework.TestCase;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/19/15
 * Time: 11:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStagePreComlQuery_DUT extends TestCase {

  public void testQuery_NoResults()
    throws Exception {

    String preComlName="dummy";
    String countryName="dummy";
    String brandName="dummy";
    String commercialName="dummy";
    ProductStagePreComlQuery query = new ProductStagePreComlQuery(preComlName,brandName,countryName,commercialName);
    boolean entryExits = query.entityExists();

    assertEquals(false, entryExits);
  }

  public void testQuery_WithResults_False()
    throws Exception {

    String preComlName="NJ3634BJW1";
    String countryName="USA";
    ProductStagePreComlQuery query = new ProductStagePreComlQuery(preComlName,"CHANNEL",countryName,"216-55VT3PRIB");
    boolean entryExits = query.entityExists();

    assertEquals(false, entryExits);

  }

  public void testQuery_WithResults_True() throws Exception {
    String preComlName="EXP267CBPY4";
    String countryName="USA";
    ProductStagePreComlQuery query = new ProductStagePreComlQuery(preComlName,"CHANNEL",countryName,"216-55VT3PRIB");
    boolean entryExits = query.entityExists();

    assertEquals(true, entryExits);
  }
}
