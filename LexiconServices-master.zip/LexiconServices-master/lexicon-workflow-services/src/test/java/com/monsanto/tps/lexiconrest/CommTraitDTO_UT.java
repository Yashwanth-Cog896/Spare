package com.monsanto.tps.lexiconrest;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CommTraitDTO_UT {
    @Test
    public void testBean() throws Exception {
        CommTraitDTO commTraitDTO = new CommTraitDTO("1", "GENVT2PRIB");
        new BeanGetterSetterTester().testBean(commTraitDTO);
    }

}