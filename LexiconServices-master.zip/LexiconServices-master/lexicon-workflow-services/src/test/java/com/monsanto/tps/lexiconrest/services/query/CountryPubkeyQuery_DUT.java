package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.CountryDTO;
import com.monsanto.tps.lexiconrest.service.query.CountryPubkeyQuery;
import junit.framework.TestCase;

import java.util.*;

/**
 * nbwald - Mar 6, 2008 2:10:36 PM
 */
public class CountryPubkeyQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {
        String[] country = new String[1];
        country[0] = "dummy";

        CountryPubkeyQuery query = new CountryPubkeyQuery(country);
        List<CountryDTO> countries = query.find();

        assertEquals(0, countries.size());
    }

    public void testQuery_WithResults()
            throws Exception {
        String[] country = new String[1];
        country[0] = "USA";

        CountryPubkeyQuery query = new CountryPubkeyQuery(country);
        List<CountryDTO> countries = query.find();

        assertEquals(1, countries.size());
        assertEquals("26804", countries.get(0).getCountryPubkey());
        assertEquals("USA", countries.get(0).getCountryName());
    }

}
