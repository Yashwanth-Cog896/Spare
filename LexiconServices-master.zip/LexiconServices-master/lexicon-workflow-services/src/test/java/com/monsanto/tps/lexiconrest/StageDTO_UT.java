package com.monsanto.tps.lexiconrest;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class StageDTO_UT {
    @Test
    public void testBean() throws Exception {
        StageDTO stageDTO = new StageDTO("PS1", "2");
        new BeanGetterSetterTester().testBean(stageDTO);
    }


}