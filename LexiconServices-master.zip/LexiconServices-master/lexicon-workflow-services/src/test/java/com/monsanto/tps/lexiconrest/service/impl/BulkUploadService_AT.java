package com.monsanto.tps.lexiconrest.service.impl;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.lexiconrest.ExcelDTO;
import com.monsanto.tps.lexiconrest.service.BulkUpload;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.ContentDisposition;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;


/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 * \
 *
 * @author PSETH
 * @version $Revision$
 */
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/lexiconservices/application-context.xml",
        "classpath:/com/monsanto/tps/logging/transaction/logging-transaction-context.xml",
        "classpath:/context/test-datasource-context.xml"
})
@RunWith(SpringJUnit4ClassRunner.class)
public class BulkUploadService_AT implements ApplicationContextAware {

    ApplicationContext applicationContext;

    @Resource(name = "bulkUpload")
    BulkUpload bulkUpload;

    @Resource
    BulkUploadDataSheetParserImpl bulkUploadDataSheetParserImpl;

    @Before
    public void setUp() throws Exception {
        UserProfile userProfile = (UserProfile) applicationContext.getBean("userProfile");
        userProfile.setUserName("TEST");
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Ignore
    @Test
    public void test_UploadProductsInformation_ReadsAllData() throws Exception {
        String fileName = "com/monsanto/tps/lexiconrest/loader/bulk_upload_scenarios.xlsx";
        assertNotNull(bulkUploadDataSheetParserImpl);
        MultipartBody multiPartBody = new MultipartBody(new Attachment("application/vnd.ms-excel", getInputStream_ForDifferentScenarios(fileName), new ContentDisposition("attachment; filename=\"bulk_upload_scenarios.xlsx\"")));
        List<ExcelDTO> excelDTOList = bulkUpload.uploadProductsInformation(multiPartBody, true, "NA1000SVC-Lexicon");
        assertNotNull(excelDTOList);
        assertTrue(excelDTOList.size() > 0);
    }

    @Ignore
    @Test(expected = IOException.class)
    public void test_bulkUploadCheckForAppropriateColumnNames() throws Exception {
        String fileName = "com/monsanto/tps/lexiconrest/loader/bulk_upload_file_column_check.xlsx";
        assertNotNull(bulkUploadDataSheetParserImpl);
        MultipartBody multiPartBody = new MultipartBody(new Attachment("application/vnd.ms-excel", getInputStream_ForDifferentScenarios(fileName), new ContentDisposition("attachment; filename=\"bulk_upload_file_column_check.xlsx\"")));
        bulkUpload.uploadProductsInformation(multiPartBody, true, "NA1000SVC-Lexicon");
    }

    @Ignore
    @Test(expected = IOException.class)
    public void test_bulkUploadCheckForSheetName() throws Exception {
        String fileName = "com/monsanto/tps/lexiconrest/loader/bulk_upload_worksheet_name_check.xlsx";
        assertNotNull(bulkUploadDataSheetParserImpl);
        MultipartBody multiPartBody = new MultipartBody(new Attachment("application/vnd.ms-excel", getInputStream_ForDifferentScenarios(fileName), new ContentDisposition("attachment; filename=\"bulk_upload_worksheet_name_check.xlsx\"")));
        bulkUpload.uploadProductsInformation(multiPartBody, true, "NA1000SVC-Lexicon");
    }

    private InputStream getInputStream_ForDifferentScenarios(String fileName) throws FileNotFoundException {
        InputStream inputStream = new FileInputStream(getClass().getClassLoader().getResource(".").getPath() + fileName);
        return inputStream;
    }
}