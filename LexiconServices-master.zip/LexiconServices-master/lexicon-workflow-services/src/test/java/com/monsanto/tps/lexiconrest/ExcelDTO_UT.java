package com.monsanto.tps.lexiconrest;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ExcelDTO_UT {
    @Test
    public void testBean() throws Exception {
        ExcelDTO excelDTO1 = new ExcelDTO();
      excelDTO1.setCountryName("countryName");
      excelDTO1.setStageName("stageName");
      excelDTO1.setPreCommercialName("preCommercialName");
      excelDTO1.setBatchId(0);
      excelDTO1.setBrand("brandName");
      excelDTO1.setCommercialName("commercialName");
      excelDTO1.setCommercialMaturity(100l);
      excelDTO1.setCommercialTrait("commercialTriat");
      excelDTO1.setSuccess("success");
        excelDTO1.setProductKind("BLEND");
        excelDTO1.setErrorMessage(null);
        new BeanGetterSetterTester().testBean(excelDTO1);
    }

}