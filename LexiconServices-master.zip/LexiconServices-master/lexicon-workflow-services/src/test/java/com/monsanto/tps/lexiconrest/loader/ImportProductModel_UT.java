/*
$Log$
*/
package com.monsanto.tps.lexiconrest.loader;

import com.monsanto.tps.lexiconrest.util.POJOTester;
import org.junit.Test;

/**
 */
public class ImportProductModel_UT {
    @Test
    public void testPojo() throws Exception {
        new POJOTester().testInstance(new ImportProductModel());
    }

}
