package com.monsanto.tps.lexiconrest;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CountryDTO_UT {
    @Test
    public void testBean() throws Exception {
        CountryDTO countryDTO = new CountryDTO("1", "India");
        new BeanGetterSetterTester().testBean(countryDTO);
    }

}