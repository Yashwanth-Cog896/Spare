package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.CommTraitDTO;
import com.monsanto.tps.lexiconrest.service.query.CommercialTraitQuery;
import junit.framework.TestCase;

import java.util.*;

/**
 * nbwald - Mar 6, 2008 2:10:36 PM
 */
public class CommercialTraitPubkeyQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {
        String[] request = new String[1];
        request[0] = "dummy";
        CommercialTraitQuery query = new CommercialTraitQuery(request, null);
        List<CommTraitDTO> commTrait = query.find();

        assertEquals(0, commTrait.size());
    }

    public void testQuery_WithResults()
            throws Exception {
        String[] commTraitList = new String[1];
        commTraitList[0] = "GENSSRIB";

        String[] preCommercialNames = new String[1];
        preCommercialNames[0] = "EG5511JRM1";

        CommercialTraitQuery query = new CommercialTraitQuery(commTraitList, preCommercialNames);
        List<CommTraitDTO> commTraitDTOs = query.find();

        assertEquals(1, commTraitDTOs.size());
        assertEquals("160623", commTraitDTOs.get(0).getCommercialTraitStackPubkey());
        assertEquals("GENSSRIB", commTraitDTOs.get(0).getStackAbbr());
    }


}
