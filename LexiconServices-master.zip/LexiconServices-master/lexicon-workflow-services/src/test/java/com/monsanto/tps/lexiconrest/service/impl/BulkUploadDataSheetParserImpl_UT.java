/*
$Log$
*/
package com.monsanto.tps.lexiconrest.service.impl;

import com.monsanto.tps.lexiconrest.loader.ImportModel;
import com.monsanto.tps.lexiconrest.service.BulkUploadDataSheetParser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

/**
 */
public class BulkUploadDataSheetParserImpl_UT {
    private BulkUploadDataSheetParser bulkUploadDataSheetParser = new BulkUploadDataSheetParserImpl();
    private InputStream testInputStream = null;

    @Before
    public void setUp() throws Exception {
        testInputStream = getTestInputStream();
    }

    @After
    public void tearDown() throws Exception {
        if (testInputStream != null) {
            testInputStream.close();
        }
    }

    @Test
    public void testCreateWorkBook() throws Exception {
        assertNotNull(bulkUploadDataSheetParser);
        assertNotNull(testInputStream);
        List<ImportModel> workBook = bulkUploadDataSheetParser.createWorkBook(testInputStream);
        assertThat("testPrecommName", is(workBook.get(0).getProductModel().getPrecommercialName()));
        assertThat("testCommercialName", is(workBook.get(0).getProductModel().getCommercialName()));
        assertThat("testBrand", is(workBook.get(0).getProductModel().getBrand()));
        assertThat("testStage", is(workBook.get(0).getProductModel().getStage()));
        assertThat("testCountry", is(workBook.get(0).getProductModel().getCountry()));
        assertThat(111, is(workBook.get(0).getProductModel().getCommercialMaturity()));
        assertThat("testTrait", is(workBook.get(0).getProductModel().getCommercialTrait()));
        assertThat("BRAND", is(workBook.get(0).getProductModel().getProductKind()));


    }


    private InputStream getTestInputStream() {
        String fileName = "/com/monsanto/tps/lexiconrest/loader/bulk_upload_file.xlsx";
        InputStream inputStream = this.getClass().getResourceAsStream(fileName);
        return inputStream;
    }
}
