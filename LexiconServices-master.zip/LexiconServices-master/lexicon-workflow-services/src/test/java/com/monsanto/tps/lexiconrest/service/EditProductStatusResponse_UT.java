package com.monsanto.tps.lexiconrest.service;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconrest.service.dto.EditProductStatusResponse;
import org.junit.Test;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class EditProductStatusResponse_UT {

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
    EditProductStatusResponse editProductStatusResponse = new EditProductStatusResponse("abbr", "brand", "coml", 1,
            new ArrayList<String>(), new ArrayList<String>(), "100", "200", "300", Boolean.TRUE, "BLEND");

    @Test
    public void test_getterSetter() throws Exception {

        beanGetterSetterTester.testBean(editProductStatusResponse);
    }

}