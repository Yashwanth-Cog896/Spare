package com.monsanto.tps.lexiconrest.service;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconrest.service.dto.AddProductStatusResponse;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class AddProductStatusResponse_UT {

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
    AddProductStatusResponse addProductStatusResponse = new AddProductStatusResponse(1, null, null,
            "testPubkey", "testStage", "testExceptionCode", Boolean.TRUE, "BLEND");

    @Test
    public void test_getterSetter() throws Exception {

        beanGetterSetterTester.testBean(addProductStatusResponse);
    }

}