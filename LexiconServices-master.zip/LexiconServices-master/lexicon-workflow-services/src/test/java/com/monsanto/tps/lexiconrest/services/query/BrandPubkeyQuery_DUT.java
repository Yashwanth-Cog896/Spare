package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.BrandDTO;
import com.monsanto.tps.lexiconrest.service.query.BrandPubkeyQuery;
import junit.framework.TestCase;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:10:36 PM
 */
public class BrandPubkeyQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {
        String[] request = new String[1];
        request[0] = "dummy";
        BrandPubkeyQuery query = new BrandPubkeyQuery(request);
        List<BrandDTO> brands = query.find();

        assertEquals(0, brands.size());
    }

    public void testQuery_WithResults()
            throws Exception {
        String[] request = new String[2];
        request[0] = "AGRIGOLD";
        request[1] = "AGRIPRO";
        BrandPubkeyQuery query = new BrandPubkeyQuery(request);
        List<BrandDTO> brands = query.find();

        assertEquals(2, brands.size());
        assertEquals("4001", brands.get(0).getBrandPubkey());
        assertEquals("AGRIGOLD", brands.get(0).getBrandName());
    }


    public void testQuery_SpecialChar()
            throws Exception {
        String[] request = new String[2];
        request[0] = "AGRIGOLD";
        request[1] = "CROW'S";
        BrandPubkeyQuery query = new BrandPubkeyQuery(request);
        List<BrandDTO> brands = query.find();

        assertEquals(2, brands.size());
        assertEquals("4001", brands.get(0).getBrandPubkey());
        assertEquals("AGRIGOLD", brands.get(0).getBrandName());
        assertEquals("5801", brands.get(1).getBrandPubkey());
        assertEquals("CROW'S", brands.get(1).getBrandName());
    }

}
