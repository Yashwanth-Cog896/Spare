package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.service.query.ProductStageCommercialQuery;
import junit.framework.TestCase;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/19/15
 * Time: 10:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStageCommercialQuery_DUT extends TestCase {

  public void testQuery_NoResults()
    throws Exception {

    String commercialName="dummy";
    String brandName="dummy";
    String countryName="dummy";
    ProductStageCommercialQuery query = new ProductStageCommercialQuery(commercialName,brandName,countryName);
    boolean entryExits = query.entityExists();

    assertEquals(false, entryExits);
  }

  public void testQuery_WithResults()
    throws Exception {

    String commercialName="4D242RIB";
    String brandName="CHANNEL";
    String countryName="USA";
    ProductStageCommercialQuery query = new ProductStageCommercialQuery(commercialName,brandName,countryName);
    boolean entryExits = query.entityExists();

    assertEquals(true, entryExits);


  }

}
