package com.monsanto.tps.lexiconrest.service;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse;
import org.junit.Test;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ProductStageServiceBatchResponse_UT {

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
    ProductStageServiceBatchResponse productStageServiceBatchResponse = new ProductStageServiceBatchResponse();

    @Test
    public void test_getterSetter() throws Exception {

        beanGetterSetterTester.testBean(productStageServiceBatchResponse);
    }

}