package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.service.query.ProductStagePreComlBrandCountryQuery;
import junit.framework.TestCase;
import org.junit.Ignore;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/19/15
 * Time: 11:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStagePreComlBrandCountryQuery_DUT extends TestCase{

  public void testQuery_NoResults()
    throws Exception {

    String preComlName="dummy";
    String countryName="dummy";
    String brandName= "dummy";
    ProductStagePreComlBrandCountryQuery query = new ProductStagePreComlBrandCountryQuery(preComlName,brandName,countryName);
    boolean entryExits = query.entityExists();

    assertEquals(false, entryExits);
  }

  public void testQuery_WithResults_False()
    throws Exception {

    String preComlName="NJ3634BJW1";
    String countryName="USA";
    String brandName = "CHANNEL";
    ProductStagePreComlBrandCountryQuery query = new ProductStagePreComlBrandCountryQuery(preComlName,brandName,countryName);
    boolean entryExits = query.entityExists();

    assertEquals(true, entryExits);


  }

@Ignore
  public void testQuery_WithResults_True() throws Exception {
    String preComlName="NL6135MYP2";
    String brandName = "CORN STATES";
    String countryName="United States of America";
    ProductStagePreComlBrandCountryQuery query = new ProductStagePreComlBrandCountryQuery(preComlName,brandName,countryName);
    boolean entryExits = query.entityExists();

    assertEquals(false, entryExits);
  }
}
