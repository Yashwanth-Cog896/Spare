package com.monsanto.tps.lexiconrest;

import com.monsanto.tps.lexiconrest.loader.ImportModel;
import com.monsanto.tps.lexiconrest.service.BatchResponse;
import com.monsanto.tps.lexiconrest.service.impl.BulkUploadImpl;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.apache.cxf.jaxrs.impl.MetadataMap;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import javax.activation.DataHandler;
import javax.ws.rs.core.MultivaluedMap;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.*;

import static junit.framework.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class BulkUploadImpl_UT {

    private MultipartBody multipartBody;
    private DataHandler dataHandler = mock(DataHandler.class);
    private List<ExcelDTO> excelDTOs = new ArrayList<ExcelDTO>();

    @Before
    public void setUp() throws Exception {
        StageDTO stageDTO = new StageDTO("1100", "1");
        CountryDTO countryDTO = new CountryDTO("2", "26804");
        ExcelDTO excelDTO = new ExcelDTO();
      excelDTO.setCountryName("26804");
      excelDTO.setStageName("1100");
      excelDTO.setPreCommercialName("42628109");
      excelDTO.setBatchId(0);
      excelDTO.setBrand("6601");
      excelDTO.setCommercialName("DKC61-49NEW");
      excelDTO.setCommercialMaturity(100l);
      excelDTO.setCommercialTrait("49123");
      excelDTO.setSuccess("success");
      excelDTO.setErrorMessage(null);

        excelDTOs.add(excelDTO);
        List<Attachment> attachmentList = new ArrayList<Attachment>();

        MultivaluedMap<String, String> header = new MetadataMap<String, String>();
        header.putSingle("Content-Disposition", "name=uploadFile;filename=test.xls");
        Attachment attachment = mock(Attachment.class);// new Attachment("uploadFile", dataHandler, header);
        attachmentList.add(attachment);
        multipartBody = new MultipartBody(attachmentList);
        when(attachment.getDataHandler()).thenReturn(dataHandler);
        byte[] b = {'1', '2', '3'};
        InputStream inputStream = new ByteArrayInputStream(b);

        when(dataHandler.getInputStream()).thenReturn(inputStream);
    }


    @Ignore
    @Test
    public void testUploadProductsInformation() throws Exception {
        BulkUploadImpl bulkUpload = new BulkUploadImpl();
        bulkUpload.uploadProductsInformation(multipartBody, true, "NA1000SVC-Lexicon");
    }

    @Ignore
    @Test
    public void testUploadProducts() throws Exception {
        BulkUploadImpl bulkUpload = new BulkUploadImpl();
        bulkUpload.uploadProducts(excelDTOs, true, "NA1000SVC-Lexicon");
    }

    @Test
    public void testCreateBatch() throws Exception {
        BulkUploadImpl bulkUpload = new BulkUploadImpl();
        List<ImportModel> importModelList = new ArrayList<ImportModel>();
        for(int i = 0;i<50;i++){
            ImportModel importModel = new ImportModel();
            importModelList.add(importModel);
        }
        List<BatchResponse> responseBatches = bulkUpload.createBatches(importModelList);
        assertEquals(3, responseBatches.size());
//        assertEquals(20, responseBatches.get(0).getImportModelList().size());
//        assertEquals(20, responseBatches.get(1).getImportModelList().size());
//        assertEquals(10, responseBatches.get(2).getImportModelList().size());
    }
}