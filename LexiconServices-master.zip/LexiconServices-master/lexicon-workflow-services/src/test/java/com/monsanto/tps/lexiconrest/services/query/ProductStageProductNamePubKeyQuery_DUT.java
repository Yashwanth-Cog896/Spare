package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.service.query.ProductStageProductNamePubKeyQuery;
import junit.framework.TestCase;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/12/15
 * Time: 12:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStageProductNamePubKeyQuery_DUT extends TestCase {

  public void testQuery_NoResults()
    throws Exception {
    String[] productRequest = new String[1];
      String[] countryNames = new String[1];
    productRequest[0] = "dummy";
      countryNames[0] = "dummy";

    ProductStageProductNamePubKeyQuery query = new ProductStageProductNamePubKeyQuery(productRequest, countryNames);
    List<String> products = query.find();

    assertEquals(0, products.size());
  }

  public void testQuery_WithResults()
    throws Exception {
    String[] productRequest = new String[1];
      String[] countryNames = new String[1];
    productRequest[0] = "8270013";
      countryNames[0] = "CHN";

    ProductStageProductNamePubKeyQuery query = new ProductStageProductNamePubKeyQuery(productRequest, countryNames);
    List<String> strings = query.find();

    assertEquals(1, strings.size());
    assertTrue(strings.contains("78856512"));
//        assertEquals("94IYI3B", strings.get(0).getPreCommercialName());
  }


}