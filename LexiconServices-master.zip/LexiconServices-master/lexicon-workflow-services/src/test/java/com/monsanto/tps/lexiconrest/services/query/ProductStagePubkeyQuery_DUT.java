package com.monsanto.tps.lexiconrest.services.query;

import com.monsanto.tps.lexiconrest.ProductDTO;
import com.monsanto.tps.lexiconrest.service.query.ProductPubkeyQuery;
import com.monsanto.tps.lexiconrest.service.query.ProductStagePubkeyQuery;
import junit.framework.TestCase;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:10:36 PM
 */
public class ProductStagePubkeyQuery_DUT extends TestCase {

    public void testQuery_NoResults()
            throws Exception {
        String[] productRequest = new String[1];
        productRequest[0] = "dummy";

        ProductStagePubkeyQuery query = new ProductStagePubkeyQuery(productRequest);
        List<String> products = query.find();

        assertEquals(0, products.size());
    }

    public void testQuery_WithResults()
            throws Exception {
        String[] productRequest = new String[1];
        productRequest[0] = "8270013";

        ProductStagePubkeyQuery query = new ProductStagePubkeyQuery(productRequest);
        List<String> strings = query.find();

        assertEquals(2, strings.size());
        assertTrue(strings.contains("ALLROUNDER"));
//        assertEquals("94IYI3B", strings.get(0).getPreCommercialName());
    }


}
