package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class TraitVerGivenManfNameGivenRule
        extends SimpleValidationRule {
    private final String traitVersion;
    private final String manfName;

    public TraitVerGivenManfNameGivenRule(String traitVersion, String manfName) {
        this.traitVersion = traitVersion;
        this.manfName = manfName;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return (!StringUtils.isNullOrEmpty(traitVersion) && StringUtils.isNullOrEmpty(manfName));
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TRAIT_VER_SPEC_MANF_NOT_CODE);
    }
}
