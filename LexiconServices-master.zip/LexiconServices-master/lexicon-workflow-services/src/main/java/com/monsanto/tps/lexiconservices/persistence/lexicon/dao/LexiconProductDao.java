package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.LexiconMonsantoProductDTO;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/27/13
 * Time: 4:29 PM
 */
public interface LexiconProductDao extends GenericDao<LexiconProductEntity, Long> {

  int updateRelationshipProductsVarietyNames(String manufacturingName, String varietyName);

  LexiconProductEntity getProductByPreCommercialName(String preCommercialName);

  List<String> getPubkeysByTagVarietyName(String tagVarietyName, Long cropID);

  LexiconProductEntity insertLexiconPreCommercialProduct(LexiconMonsantoProductDTO lexiconMonsantoProductDTO);

  int unDeleteLexiconProduct(String productPubKey);

  String getNextProductPubkey();

  String getNextVarietyName();

  ProductRelationshipDTO getMatchingLexiconProduct(String preCommercialName);

  LexiconProductEntity getProductByProductPubKey(String pubKey);

  List<String> getTagVarietyNamesByREGEXAndCrop(String tagVarietyNameREGEX, Long cropId);

  LexiconProductEntity updateLexiconProductByPubKey(String productPubkey, String preCommercialName, String productClassificationCode,String tagVarietyName,String supplyChainOwner);
}
