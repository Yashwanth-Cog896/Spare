package com.monsanto.tps.lexiconservices.product.common.rule.existingproduct;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class LinkedMidasProdNotInactiveRule
        extends SimpleValidationRule {
    private final MidasProductEntity linkedMidasProduct;

    public LinkedMidasProdNotInactiveRule(MidasProductEntity linkedMidasProduct) {
        this.linkedMidasProduct = linkedMidasProduct;
    }

    protected boolean preConditionsMet() {
        return linkedMidasProduct != null;
    }

    public boolean criteriaViolated() {
        return !linkedMidasProduct.isRefActive();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.LINKED_MIDAS_PROD_INACTIVE_CODE);
    }
}
