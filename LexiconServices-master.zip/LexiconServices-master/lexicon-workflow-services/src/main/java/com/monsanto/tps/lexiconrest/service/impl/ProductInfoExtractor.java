package com.monsanto.tps.lexiconrest.service.impl;

import com.monsanto.tps.lexiconrest.loader.ImportProductModel;
import com.monsanto.tps.lexiconrest.utilities.XSSFCellConverter;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;

import java.io.IOException;

public class ProductInfoExtractor
        extends XSSFCellConverter {

    private Logger logger = Logger.getLogger(ProductInfoExtractor.class);

    public static final int CommercialMaturity = 6;
    public static final int COMMERCIALTRAIT = 5;
    public static final int COUNTRY = 4;
    public static final int STAGE = 3;
    public static final int BRAND = 2;
    public static final int COMMERCIALNAME_PH = 1;
    public static final int PRECOMMERCIALNAME_PH = 0;
    public static final int PRODUCT_KIND_PH = 7;

    public ImportProductModel extractProduct(Row rowValue) throws IOException {
        logger.info("Parsing the excel columns");
        ImportProductModel importProductModel = new ImportProductModel();
        String precommercialName = getConvertedValue(rowValue, PRECOMMERCIALNAME_PH);
        importProductModel.setPrecommercialName(precommercialName);
        String commercialName = getConvertedValue(rowValue, COMMERCIALNAME_PH);
        importProductModel.setCommercialName(commercialName);
        String brand = getConvertedValue(rowValue, BRAND);
        importProductModel.setBrand(brand);
        String stage = getConvertedValue(rowValue, STAGE);
        importProductModel.setStage(stage);
        String country = getConvertedValue(rowValue, COUNTRY);
        importProductModel.setCountry(country);
        String commercialTrait = getConvertedValue(rowValue, COMMERCIALTRAIT);
        importProductModel.setCommercialTrait(commercialTrait);
        String commercialMaturity = getConvertedValue(rowValue, CommercialMaturity);
        importProductModel.setCommercialMaturity(Integer.parseInt(commercialMaturity.trim()));
        String productKind = getConvertedValue(rowValue, PRODUCT_KIND_PH);
        importProductModel.setProductKind(productKind);
        return importProductModel;
    }
}