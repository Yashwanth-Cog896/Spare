package com.monsanto.tps.lexiconservices.persistence.midas.dao.domain;

import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.LineTypeRef;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/7/14
 * Time: 2:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductGermplasmDTO {
    private static final String BASE_SOURCE = "PRE-COMMERCIAL PRODUCT IMPORT";
    private static final String FINISHED_GENERATION = "INBRED";
    private static final String HYBRID_GENERATION = "F1";

    private String TRUE = "true";
    private String FALSE = "false";
    private Long productId;
    private Long relativeMaturity;
    private String preferred;
    private Long germplasmId;
    private String origin;
    private String lineCode;
    private String pedigree;
    private String lineType;
    private String cropName;
    private String progRefId;
    private String eventDisplay;
    private String transgenic;
    private String deleted;
    private String finished;
    private InbredHybridEnum inbredHybridType;
    private String productName;

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getRelativeMaturity() {
        return relativeMaturity;
    }

    public void setRelativeMaturity(Long relativeMaturity) {
        this.relativeMaturity = relativeMaturity;
    }

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getProgRefId() {
        return progRefId;
    }

    public void setProgRefId(String progRefId) {
        this.progRefId = progRefId;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getPreferred() {
        return ("T".equalsIgnoreCase(preferred)) ? TRUE : FALSE;
    }

    public boolean isPreferred() {
        return ("T".equalsIgnoreCase(preferred)) ? true : false;
    }

    public void setPreferred(String preferred) {
        this.preferred = preferred;
    }

    public String getTransgenic() {
        return ("T".equalsIgnoreCase(transgenic)) ? TRUE : FALSE;
    }

    public void setTransgenic(String transgenic) {
        this.transgenic = transgenic;
    }

    public String getDeleted() {
        return ("T".equalsIgnoreCase(deleted)) ? TRUE : FALSE;

    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public String getFinished() {
        return ("T".equalsIgnoreCase(finished)) ? TRUE : FALSE;

    }

    public void setFinished(String finished) {
        this.finished = finished;
    }

    public boolean getFinishedFlag() {
        return ("T".equalsIgnoreCase(finished)) ? true : false;

    }

    public boolean isFinished() {
        return (LineTypeRef.HYBRID.equals(lineType)) ?
                getFinishedFlag() : LineTypeRef.FINISHED.equals(lineType);
    }

    public boolean isTransgenic() {
        return ("T".equalsIgnoreCase(transgenic)) ? true : false;
    }

    public String getMaterialSource() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        return BASE_SOURCE + " " + formatter.format(new Date()) + " MIRAGE USE ONLY";

    }

    public String getGeneration() {
            return (InbredHybridEnum.INBRED_TYPE.equals(inbredHybridType)) ? FINISHED_GENERATION : HYBRID_GENERATION;
    }

    public InbredHybridEnum getInbredHybridType() {
        return inbredHybridType;
    }

    public void setInbredHybridType(InbredHybridEnum inbredHybridType) {
        this.inbredHybridType = inbredHybridType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
