package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.LexiconMonsantoProductDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNProductAssignmentRichRequest;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 9:39 AM
 */
@Component(value = "syncProductLexiconProductWriter")
public class SyncProductLexiconProductWriter {

    @Resource
    private LexiconProductDao lexiconProductDao;

    public LexiconProductEntity write(LexiconProductEntity existingLexProduct, APCNProductAssignmentRichRequest request, String existingVarietyName) {
        LexiconProductEntity returnedProduct = existingLexProduct;
        if (existingLexProduct == null) {
            String productPubkey = lexiconProductDao.getNextProductPubkey();
            String tagVarietyName = getTagVarietyName(request.isParentProduct(), request.getRequestedCrop().isVarietyNameGenerated(), existingVarietyName);
            LexiconMonsantoProductDTO lexiconMonsantoProductDTO = new LexiconMonsantoProductDTO(productPubkey, request.getRequestedPCName(), request.getRequestedCrop().getLexiconCropName(),
                    tagVarietyName, request.isParentProduct(), request.getProductClassificationCode(), request.getSupplyChainOwner(), request.getOwnerRegion());
            returnedProduct = lexiconProductDao.insertLexiconPreCommercialProduct(lexiconMonsantoProductDTO);
        } else if (existingLexProduct.isLogicalDelete()) {
            lexiconProductDao.unDeleteLexiconProduct(existingLexProduct.getPubkey());
            returnedProduct = lexiconProductDao.get(existingLexProduct.getId());
        }
        return returnedProduct;
    }

    private String getTagVarietyName(boolean parentProduct, boolean generateTagVarietyName, String existingVarietyName) {
        String returnedVarietyName = null;
        if (!StringUtils.isNullOrEmpty(existingVarietyName)) {
            returnedVarietyName = existingVarietyName;
        } else if (generateTagVarietyName) {
            if (parentProduct) {
                returnedVarietyName = null;
            } else {
                returnedVarietyName = lexiconProductDao.getNextVarietyName();
            }
        }
        return returnedVarietyName;
    }
}
