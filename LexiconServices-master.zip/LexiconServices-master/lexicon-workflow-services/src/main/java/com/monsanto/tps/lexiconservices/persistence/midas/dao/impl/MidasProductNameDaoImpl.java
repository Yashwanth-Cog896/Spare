package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductNameDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.ProductNameDTO;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/6/14
 * Time: 10:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductNameDaoImpl extends GenericDaoImpl<MidasProductNameEntity, Long> implements MidasProductNameDao {


  public static final String MIDAS_BRAND_NAME = "MONSANTO";

  private static final String INSERT_MIDAS_PRODUCT_NAME = "MidasProductNameDao.insertMidasProductName";

  private static final String DELETE_MIDAS_PRODUCT_NAME = "MidasProductNameDao.deleteMidasProductName";

  public MidasProductNameDaoImpl(Class entityClass) {
    super(entityClass);
  }

  @Override
  public List<MidasProductNameEntity> findMatchingMidasNamesByProductName(String pcName) {
    return getSessionFactory().getCurrentSession().createCriteria(MidasProductNameEntity.class, "midasProductName").
      createAlias("midasProductName.midasProduct", "midasProduct").
      createAlias("midasProductName.midasBrand", "midasBrand").
      createAlias("midasProduct.midasCrop", "midasCrop").
      createAlias("midasProductName.midasCountry", "midasCountry").
      add(Restrictions.ne("midasProductName.refActive", false)).add(Restrictions.eq("midasBrand.name", MIDAS_BRAND_NAME)).add(Restrictions.eq("midasProductName.name", pcName)).list();

  }

  @Override
  public List<MidasProductNameEntity> findGlobalPCNamesByProductID(Long productId) {
    return getSessionFactory().getCurrentSession().createCriteria(MidasProductNameEntity.class, "midasProductName").
      createAlias("midasProductName.midasProduct", "midasProduct").
      createAlias("midasProductName.midasBrand", "midasBrand").
      createAlias("midasProduct.midasCrop", "midasCrop").
      createAlias("midasProductName.midasCountry", "midasCountry").
      add(Restrictions.eq("midasBrand.name", MIDAS_BRAND_NAME)).add(Restrictions.eq("midasProduct.id", productId)).list();
  }

  public MidasProductNameEntity getMidasNameByCriteria(long midasProductID, String brandName, long countryID) {
    return (MidasProductNameEntity) getSessionFactory().getCurrentSession().createCriteria(MidasProductNameEntity.class, "productName").
      createAlias("productName.midasBrand", "brand").
      createAlias("productName.midasProduct", "product").
      createAlias("productName.midasCountry", "country").
      add(Restrictions.eq("product.id", midasProductID)).
      add(Restrictions.eq("brand.name", brandName)).
      add(Restrictions.eq("country.id", countryID)).uniqueResult();
  }

  public int insertMidasProductName(ProductNameDTO productNameDTO) {
    return getSessionFactory().getCurrentSession().getNamedQuery(INSERT_MIDAS_PRODUCT_NAME).
      setParameter("productNameID", productNameDTO.getProductNameID()).
      setParameter("productID", productNameDTO.getProductID()).
      setParameter("productName", productNameDTO.getProductName()).
      setParameter("countryID", productNameDTO.getCountryID()).
      setParameter("brandName", productNameDTO.getBrandName()).
      setParameter("preferredName", productNameDTO.getPreferredName()).
      executeUpdate();
  }

  public void reuseMidasProductName(String name, long id) {
    MidasProductNameEntity productName = get(id);
    productName.setName(name);
    productName.setRefActive(true);
  }

  public int deleteMidasProductName(Long midasProductNameID) {
    return getSessionFactory().getCurrentSession().getNamedQuery(DELETE_MIDAS_PRODUCT_NAME).
      setParameter("midasProductNameID", midasProductNameID).
      executeUpdate();
  }

  public int updateMidasProductName(long productNameId, String productName, String brandName, long countryId, boolean preferredName, boolean refActive) {
    return getSessionFactory().getCurrentSession().getNamedQuery("MidasProductNameDao.updateMidasProductName").
      setParameter("productNameId", productNameId).setParameter("productName", productName).setParameter("brandName", brandName).
      setParameter("countryId", countryId).setParameter("preferredName", preferredName ? "T" : "F").setParameter("refActive", refActive ? "T" : "F").executeUpdate();
  }
}
