package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipHelper;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/26/13
 * Time: 6:22 PM
 */
public interface ProductRelationshipDao extends GenericDao<ProductRelationshipEntity, Long> {

    int updateManufacturingName(String newManufacturingName, String oldManufacturingName);

    int updateRelationshipVarietyName(String varietyName, String manufacturingName);

    @DynamicDaoMethod(queryName = "ProductRelationshipDao.findManufacturingAttributesByManufacturingName",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public ProductRelationshipEntity findManufacturingAttributesByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);

    @DynamicDaoMethod(queryName = "ProductRelationshipDao.findManufacturingAttributesByVarietyName",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public ProductRelationshipEntity findManufacturingAttributesByVarietyName(@DynamicDaoParameter(name = "varietyName") String varietyName);

    @DynamicDaoMethod(queryName = "ProductRelationshipDao.findProductRelationshipProductsByManufacturingName",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<ProductRelationshipEntity> findProductRelationshipProductsByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);

    @DynamicDaoMethod(queryName = "ProductRelationshipDao.findManufacturingLineByManufacturingName", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    ProductRelationshipEntity findManufacturingLineByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);

    ProductRelationshipEntity findProductRelationshipByProductPubkey(String productPubKey);

    List<ProductRelationshipDTO> findProductRelationshipByProductID(Long productRelationshipID);

    //todo should go into  ProductRelationshipXrefDao
    int insertProductRelationship(ProductRelationshipDTO productRelationshipDTO);

    int insertProductRelationshipXref(String traitVersion, Long productId, Long productionStatusId, Long productRelationshipId);

    //todo should go into  ProductRelationshipXrefDao
    ProductRelationshipHelper getRelationshipByProductPubkey(String productPubKey);


}
