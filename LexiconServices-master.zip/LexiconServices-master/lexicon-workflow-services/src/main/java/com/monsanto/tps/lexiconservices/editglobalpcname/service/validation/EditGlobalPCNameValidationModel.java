package com.monsanto.tps.lexiconservices.editglobalpcname.service.validation;

import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.productpcname.richrequest.TagVarietyNameRequest;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/12/14
 * Time: 9:50 AM
 * To change this template use File | Settings | File Templates.
 */
public interface EditGlobalPCNameValidationModel
  extends EGPCNExistingProductValidationModel, TagVarietyNameRequest {

  public String getNewPreComlName();

  public ProductRelationshipDTO getMatchingLexProd();

  boolean isVegetableProduct();

  String getProductClassificationCode();

}
