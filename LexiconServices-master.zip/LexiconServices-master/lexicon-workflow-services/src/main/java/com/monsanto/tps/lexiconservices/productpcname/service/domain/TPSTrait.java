package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.CommercialTraitStackEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 9:44 AM
 */
public class TPSTrait {

    private final CommercialTraitStackEntity lexStack;
    private final long mirageTraitID;


    public TPSTrait(CommercialTraitStackEntity lexStack, long mirageTraitID) {
        this.lexStack = lexStack;
        this.mirageTraitID = mirageTraitID;
    }

    public CommercialTraitStackEntity getLexStack() {
        return lexStack;
    }

    public long getMirageTraitID() {
        return mirageTraitID;
    }
}
