package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/31/14
 * Time: 11:56 AM
 */
public class APCNProductAssignmentRichRequest {


    private String requestedPCName;
    private TPSCrop requestedCrop;
    private String productClassificationCode;
    private String supplyChainOwner;
    private String ownerRegion;
    private boolean vegetableProduct;
    private boolean parentProduct;
    private boolean anyAssigningGermplasmAttachedToProduct;
    private boolean containsPreferredPedigree;
    private String cropByProductClassification;
    private String tagVarietyName;
    private boolean tagVarietyNameInUse;
    private List<Long> traitStackIdsForGermplasms;
    private ProductGermplasmCollection assigningGermplasm;

    public void setRequestedPCName(String requestedPCName) {
        this.requestedPCName = requestedPCName;
    }

    public void setRequestedCrop(TPSCrop requestedCrop) {
        this.requestedCrop = requestedCrop;
    }

    public void setProductClassificationCode(String productClassificationCode) {
        this.productClassificationCode = productClassificationCode;
    }

    public void setSupplyChainOwner(String supplyChainOwner) {
        this.supplyChainOwner = supplyChainOwner;
    }

    public void setOwnerRegion(String ownerRegion) {
        this.ownerRegion = ownerRegion;
    }

    public void setVegetableProduct(boolean vegetableProduct) {
        this.vegetableProduct = vegetableProduct;
    }

    public void setParentProduct(boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    public void setAnyAssigningGermplasmAttachedToProduct(boolean anyAssigningGermplasmAttachedToProduct) {
        this.anyAssigningGermplasmAttachedToProduct = anyAssigningGermplasmAttachedToProduct;
    }

    public void setContainsPreferredPedigree(boolean containsPreferredPedigree) {
        this.containsPreferredPedigree = containsPreferredPedigree;
    }

    public String getRequestedPCName() {
        return requestedPCName;
    }

    public TPSCrop getRequestedCrop() {
        return requestedCrop;
    }

    public String getProductClassificationCode() {
        return productClassificationCode;
    }

    public String getSupplyChainOwner() {
        return supplyChainOwner;
    }

    public String getOwnerRegion() {
        return ownerRegion;
    }

    public boolean isVegetableProduct() {
        return vegetableProduct;
    }

    public boolean isParentProduct() {
        return parentProduct;
    }

    public boolean isAnyAssigningGermplasmAttachedToProduct() {
        return anyAssigningGermplasmAttachedToProduct;
    }

    public boolean isContainsPreferredPedigree() {
        return containsPreferredPedigree;
    }

    public void setCropByProductClassification(String cropByProductClassification) {
        this.cropByProductClassification = cropByProductClassification;
    }

    public void setTagVarietyName(String tagVarietyName) {
        this.tagVarietyName = tagVarietyName;
    }

    public String getCropByProductClassification() {
        return cropByProductClassification;
    }

    public String getTagVarietyName() {
        return tagVarietyName;
    }

    public void setTagVarietyNameInUse(boolean tagVarietyNameInUse) {
        this.tagVarietyNameInUse = tagVarietyNameInUse;
    }

    public void setTraitStackIdsForGermplasms(List<Long> traitStackIdsForGermplasms) {
        this.traitStackIdsForGermplasms = traitStackIdsForGermplasms;
    }

    public void setAssigningGermplasm(ProductGermplasmCollection assigningGermplasm) {
        this.assigningGermplasm = assigningGermplasm;
    }

    public boolean isTagVarietyNameInUse() {
        return tagVarietyNameInUse;
    }

    public List<Long> getTraitStackIdsForGermplasms() {
        return traitStackIdsForGermplasms;
    }

    public ProductGermplasmCollection getAssigningGermplasm() {
        return assigningGermplasm;
    }

}
