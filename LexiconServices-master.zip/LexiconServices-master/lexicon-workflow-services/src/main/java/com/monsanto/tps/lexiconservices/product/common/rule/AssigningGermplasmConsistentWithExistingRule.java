package com.monsanto.tps.lexiconservices.product.common.rule;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;


/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jul 17, 2006
 * Time: 12:14:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class AssigningGermplasmConsistentWithExistingRule
        extends SimpleValidationRule {
    private final InbredHybridEnum existingInbredHybridType;
    private final InbredHybridEnum assigningInbredHybridType;

    public AssigningGermplasmConsistentWithExistingRule(
            InbredHybridEnum inbredHybrid, ProductGermplasmCollection assigningGermplasm) {
        this.existingInbredHybridType = inbredHybrid;
        assigningInbredHybridType = getAssigningInbredHybridType(assigningGermplasm);
    }

    private InbredHybridEnum getAssigningInbredHybridType(ProductGermplasmCollection assigningGermplasm) {
        return assigningGermplasm.getGermplasmCollection().getInbredHybridType();
    }

    protected boolean preConditionsMet() {
        return existingInbredHybridType != null && assigningInbredHybridType != null;
    }

    protected boolean criteriaViolated() {
        return !existingInbredHybridType.isConsistant(assigningInbredHybridType);
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ASSIGNING_GP_DIFF_TYPE_CODE);
    }
}
