package com.monsanto.tps.lexiconservices.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageAuditEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/24/14
 * Time: 10:52 AM
 */
public interface AuditDao extends GenericDao<MirageAuditEntity,Long>{
    MirageAuditEntity save(String auditEvent);
}
