package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.*;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidBrandException;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidCountryException;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 12:03 PM
 */
@Component(value = "defaultStageAttributesLoader")
public class DefaultStageAttributesLoader {


    @Resource
    private LexiconStageDao lexiconStageDao;

    @Resource
    private SyncProductNameLoader syncProductNameLoader;

    @Resource
    private TPSTraitLookup traitLookup;

    public APCNDefaultStageAttributesRichRequest loadDefaultStageAttributes(AssignPCNameRequest request, MutableSyncProduct syncProduct){

        if (shouldCreateDefaultStage(request, syncProduct)) {
            APCNDefaultStageAttributesRichRequest defaultStageAttributes = new APCNDefaultStageAttributesRichRequest();
            setPreComlBrand(defaultStageAttributes);
            setRequestedCountries(defaultStageAttributes, request);
            setRequestedTraitStack(defaultStageAttributes, request);
            setRequestedStageType(defaultStageAttributes, request);
            setRequestedMaturity(defaultStageAttributes, request);
            setSyncProductNames(defaultStageAttributes, syncProduct);
            setIndividualStagesAttributes(defaultStageAttributes, request);
            return defaultStageAttributes;
        }
        return null;
    }

    private void setIndividualStagesAttributes(APCNDefaultStageAttributesRichRequest defaultStageAttributes, AssignPCNameRequest request) {
        List<APCNIndividualStageAttributesByCriteria> apcnIndividualStageAttributes = new ArrayList<APCNIndividualStageAttributesByCriteria>();
        List<String> countryPubkeys = request.getCountryPubkeys();
        for (String countryPubkey : countryPubkeys) {
            APCNIndividualStageAttributesByCriteria individualStageAttributes = loadIndividualStageAttributes(countryPubkey, request.getTraitStackPubkey());
            apcnIndividualStageAttributes.add(individualStageAttributes);
        }
        defaultStageAttributes.setIndividualStagesAttributes(apcnIndividualStageAttributes);
    }

    private APCNIndividualStageAttributesByCriteria loadIndividualStageAttributes(String countryPubkey, String traitStackPubkey) {

        TPSCountry countryByPubkey = getCountryByPubkey(countryPubkey);
        TPSTrait requestedTraitStack = traitLookup.getTraitByPubkeyAndCountry(traitStackPubkey, countryPubkey);
        return new APCNIndividualStageAttributesByCriteria(countryByPubkey, requestedTraitStack);
    }


    private void setSyncProductNames(APCNDefaultStageAttributesRichRequest defaultStageAttributes, MutableSyncProduct syncProduct) {
        List<MutableSyncProductName> syncProductNames = new ArrayList<MutableSyncProductName>();
        for (TPSCountry country : defaultStageAttributes.getRequestedCountries()) {
            MutableSyncProductName productName = syncProductNameLoader.loadSyncProductName(syncProduct, defaultStageAttributes.getPreComlBrand(), country, null);
            syncProductNames.add(productName);
        }
        defaultStageAttributes.setSyncProductNames(syncProductNames);
    }

    private void setRequestedMaturity(APCNDefaultStageAttributesRichRequest defaultStageAttributes, AssignPCNameRequest request) {
        defaultStageAttributes.setRequestedMaturity(request.getCommercialMaturity());
    }

    private void setRequestedStageType(APCNDefaultStageAttributesRichRequest defaultStageAttributes, AssignPCNameRequest request) {
        LexiconStageEntity requestedStage = lexiconStageDao.getStageTypeByPubkey(request.getStageTypePubkey());
        defaultStageAttributes.setRequestedStageType(requestedStage);
    }

    private void setRequestedTraitStack(APCNDefaultStageAttributesRichRequest defaultStageAttributes, AssignPCNameRequest request) {
        TPSTrait traitByPubkey = traitLookup.getTraitByPubkey(request.getTraitStackPubkey());
        defaultStageAttributes.setRequestedTraitStack(traitByPubkey);
    }



    private void setRequestedCountries(APCNDefaultStageAttributesRichRequest defaultStageAttributes, AssignPCNameRequest request) {
        List<TPSCountry> countries = new ArrayList<TPSCountry>();
        for (String countryPubKey : request.getCountryPubkeys()) {
            countries.add(getCountryByPubkey(countryPubKey));
        }
        defaultStageAttributes.setRequestedCountries(countries);
    }

    private TPSCountry getCountryByPubkey(String countryPubKey) {
        try {
            TPSCountryLookup lookup = TPSCountryLookup.instance();
            return lookup.getCountry(countryPubKey);
        } catch (InvalidCountryException e) {
            return null;
        }
    }

    private void setPreComlBrand(APCNDefaultStageAttributesRichRequest defaultStageAttributes) {
        TPSBrand preComlBrand;
        try {
            TPSBrandLookup lookup = TPSBrandLookup.getInstance();
            preComlBrand = lookup.getBrandByName(TPSBrand.PRE_COML_BRAND);
        } catch (InvalidBrandException e) {
            preComlBrand = null;
        }
        defaultStageAttributes.setPreComlBrand(preComlBrand);
    }

    private boolean shouldCreateDefaultStage(AssignPCNameRequest request, MutableSyncProduct syncProduct) {
        return request.hasDefaultStage() && !syncProduct.getLexiconProductNames().hasNonDeletedStages();
    }
}
