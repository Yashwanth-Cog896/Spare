package com.monsanto.tps.lexiconservices.product.common.condition;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 19, 2006
 * Time: 9:55:05 AM
 */
public interface ProductAssignmentCodes {
    ValidationConditionCode DEL_PROD_CONTAINS_NON_LD_STAGES_CODE = new ValidationConditionCode("DeletedProductContainsNonLDStages");
    ValidationConditionCode EXIST_LEX_CROP_DIFFER_CODE = new ValidationConditionCode("ExistingLexCropDiffers");
    ValidationConditionCode INVALID_PC_NAME_CODE = new ValidationConditionCode("InvalidPreComlName");
    ValidationConditionCode MATCH_MIDAS_PN_MULT_PRODID_CODE = new ValidationConditionCode("MatchingMidasPNWithDiffProdID");
    ValidationConditionCode MATCH_MIDAS_PN_DIFF_CROPID_CODE = new ValidationConditionCode("MatchingMidasPNWithDiffCropID");
    ValidationConditionCode BOTH_LINKED_AND_MATCH_MIDAS_PROD_CODE = new ValidationConditionCode("BothLinkedAndMatchingMidasProdFound");
    ValidationConditionCode LINKED_MIDAS_PROD_CROP_MISMATCH_CODE = new ValidationConditionCode("LinkedMidasProdDiffCropID");
    ValidationConditionCode GLOBAL_PC_NAME_MISMATCH_CODE = new ValidationConditionCode("GlobalPCNameMismatch");
    ValidationConditionCode TAG_VARIETY_NAME_IN_USE_CODE = new ValidationConditionCode("TagVarietyNameInUse");
    ValidationConditionCode NUMERICAL_VALUE_IN_USE_CODE = new ValidationConditionCode("NumericalValueInUse");
    ValidationConditionCode TAG_VARIETY_NAME_FORMAT_CODE = new ValidationConditionCode("TagVarietyFormat");
    ValidationConditionCode ASSIGNING_GP_INCONSISTANT_CODE = new ValidationConditionCode("AssigningGPInconsistent");
    ValidationConditionCode ASSIGNING_GP_DIFF_TYPE_CODE = new ValidationConditionCode("AssignGPDiffType");
    ValidationConditionCode ASSIGNING_GP_MULTIPLE_PREFERRED = new ValidationConditionCode("AssignGPMultiplePreferred");
    ValidationConditionCode ASSIGNING_GP_INVALID_LINE_TYPE_CODE = new ValidationConditionCode("AssignGPInvalidLineType");
    ValidationConditionCode COML_MATURITY_IGNORED_CODE = new ValidationConditionCode("ComlMaturityIgnored");
    ValidationConditionCode TRAIT_STACK_IGNORED_CODE = new ValidationConditionCode("TraitStackIgnored");
    ValidationConditionCode PARENT_PRODUCT_FLAG_DIFFER_CODE = new ValidationConditionCode("ExistingParentProductFlagDiffers");
    ValidationConditionCode ASSIGNING_GP_ATTACHED_TO_PRODUCT_CODE = new ValidationConditionCode("AssigningGPAttachedToProduct");
    ValidationConditionCode INVALID_CROP = new ValidationConditionCode("InvalidCrop");
    ValidationConditionCode VEGE_PROD_MISSING_PROD_CLASSIFICATION_CODE = new ValidationConditionCode("VegeProdMissingProdClassification");
    ValidationConditionCode ROW_PROD_HAS_PROD_CLASSIFICATION_CODE = new ValidationConditionCode("RowProdHasProdClassification");
    ValidationConditionCode CROP_AND_PRODUCT_HIERARCHY_DO_NOT_MATCH = new ValidationConditionCode("CropAndProductHierarchyDoNotMatch");
}
