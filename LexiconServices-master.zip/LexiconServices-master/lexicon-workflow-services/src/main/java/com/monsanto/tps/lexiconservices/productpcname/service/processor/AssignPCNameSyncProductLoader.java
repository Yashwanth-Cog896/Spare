package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.product.common.processor.SyncProductLoader;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import org.springframework.stereotype.Component;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/5/14
 * Time: 12:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "assignPCNameSyncProductLoader")
public class AssignPCNameSyncProductLoader extends SyncProductLoader {

  public MutableSyncProduct loadSyncProduct(String preComlName, String cropName, boolean isParentProduct) {
    MutableSyncProduct mutableSyncProduct = new MutableSyncProduct();
    mutableSyncProduct.setPreComlName(preComlName);
    mutableSyncProduct.setCropName(cropName);
    mutableSyncProduct.setParentProduct(isParentProduct);
    setLexiconProductByPreComlName(mutableSyncProduct);
    setLexProductNames(mutableSyncProduct);
    setCrop(mutableSyncProduct);
    setRequestedVegetableProduct(mutableSyncProduct);
    setProductXref(mutableSyncProduct);
    setLinkedMidasProduct(mutableSyncProduct);
    setMatchingMidasPN(mutableSyncProduct);
    setProductRelationship(mutableSyncProduct);
    setGlobalPCNameRecords(mutableSyncProduct);
    setProductGermplasm(mutableSyncProduct);
    setMirageGeneticMaterial(mutableSyncProduct);
    setProductsExceptionCodes(mutableSyncProduct);
    return mutableSyncProduct;
  }
}
