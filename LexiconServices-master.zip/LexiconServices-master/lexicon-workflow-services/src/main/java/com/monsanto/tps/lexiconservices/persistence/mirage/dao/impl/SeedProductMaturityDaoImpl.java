package com.monsanto.tps.lexiconservices.persistence.mirage.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductMaturityEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductMaturityPK;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.SeedProductMaturityDao;
import org.hibernate.SessionFactory;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: pgang
 * Date: 1/23/14
 * Time: 12:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class SeedProductMaturityDaoImpl extends GenericDaoImpl<MirageSeedProductMaturityEntity, MirageSeedProductMaturityPK> implements SeedProductMaturityDao {

    private final String DELETE_BY_PRODUCT_ID = "SeedProductMaturityDao.deleteByProductId";
    @Resource
    private SessionFactory sessionFactory;

    public SeedProductMaturityDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public int deleteByProductId(Long productId) {
        return sessionFactory.getCurrentSession().getNamedQuery(DELETE_BY_PRODUCT_ID).setParameter("productId", productId).executeUpdate();
    }

    public MirageSeedProductMaturityEntity save(long seedProductId, String maturityRating, long auditId) {
        sessionFactory.getCurrentSession().getNamedQuery("SeedProductMaturityDao.save").setParameter("seedProductId", seedProductId)
                .setParameter("maturityRating", maturityRating).setParameter("auditId", auditId).executeUpdate();
        return getInsertedEntity(seedProductId);
    }

    private MirageSeedProductMaturityEntity getInsertedEntity(long seedProductId) {
        return (MirageSeedProductMaturityEntity) getSessionFactory().getCurrentSession().getNamedQuery("SeedProductMaturityDao.getInsertedEntity").
                setParameter("seedProductId",seedProductId).uniqueResult();
    }
}
