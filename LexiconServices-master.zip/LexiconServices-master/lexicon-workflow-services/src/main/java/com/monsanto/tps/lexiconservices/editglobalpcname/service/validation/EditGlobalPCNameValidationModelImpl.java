package com.monsanto.tps.lexiconservices.editglobalpcname.service.validation;

import com.monsanto.tps.lexiconservices.editglobalpcname.service.domain.EditGlobalPCNameRichRequest;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/12/14
 * Time: 10:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameValidationModelImpl implements EditGlobalPCNameValidationModel {
  private final EditGlobalPCNameRichRequest richRequest;

  public EditGlobalPCNameValidationModelImpl(EditGlobalPCNameRichRequest richRequest) {
    this.richRequest = richRequest;
  }

  public String getNewPreComlName() {
    return richRequest.getNewPreComlName();
  }

  public ProductRelationshipDTO getMatchingLexProd() {
    return richRequest.getMatchingLexProd();
  }

  public LexiconProductEntity getLexProduct() {
    return getSyncProduct().getLexProduct();
  }

  public FbsCommonProductXrefEntity getProductXref() {
    return getSyncProduct().getProductXref();
  }

  public MidasProductEntity getMidasProduct() {
    return getSyncProduct().getMidasProduct();
  }

  private MutableSyncProduct getSyncProduct() {
    return richRequest.getSyncProduct();
  }

  @Override
  public boolean isVegetableProduct() {
    return richRequest.isVegetableProduct();
  }

  @Override
  public String getProductClassificationCode() {
    return richRequest.getProductClassificationCode();
  }

  @Override
  public String getTagVarietyName() {
    return richRequest.getTagVarietyName();
  }

  @Override
  public boolean isTagVarietyNameInUse() {
    return richRequest.isTagVarietyNameInUse();
  }

  @Override
  public boolean isTagVarietyNumberInUse() {
    return richRequest.isTagVarietyNumberInUse();
  }

}
