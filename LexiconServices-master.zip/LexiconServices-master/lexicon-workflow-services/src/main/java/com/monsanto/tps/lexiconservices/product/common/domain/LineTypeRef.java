package com.monsanto.tps.lexiconservices.product.common.domain;

public class LineTypeRef {
    public static final String SEGPOP = "SEGPOP";
    public static final String HYBRID = "HYBRID";
    public static final String OP_VAR = "OP_VAR";
    public static final String CODED = "CODED";
    public static final String FINISHED = "FINISHED";

}