package com.monsanto.tps.lexiconservices.productpcname.service.exception;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 2:19 PM
 */
public class InvalidCountryException extends Exception{

    public InvalidCountryException(String message) {
        super(message);
    }
}
