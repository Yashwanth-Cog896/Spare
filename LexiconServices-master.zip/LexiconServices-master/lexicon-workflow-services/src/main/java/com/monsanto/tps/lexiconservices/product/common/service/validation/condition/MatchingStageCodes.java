package com.monsanto.tps.lexiconservices.product.common.service.validation.condition;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 20, 2006
 * Time: 4:52:44 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MatchingStageCodes {
    ValidationConditionCode MATCHING_LEX_STAGE_EXISTS_CODE = new ValidationConditionCode("MatchLexStageExists");
    ValidationConditionCode MATCHING_LD_LEX_STAGE_EXISTS_CODE = new ValidationConditionCode("LDMatchLexStageExists");
    ValidationConditionCode NAME_XREF_EXISTS_CODE = new ValidationConditionCode("NameXrefExists");
    ValidationConditionCode MATCHING_MIDAS_COML_PN_EXISTS_CODE = new ValidationConditionCode("MatchingActiveMidasComlPNExists");
    ValidationConditionCode MATCHING_INACTIVE_MIDAS_COML_PN_EXISTS_CODE = new ValidationConditionCode("MatchingInActiveMidasComlPNExists");
    ValidationConditionCode MATCHING_MIRAGE_EXISTS_CODE = new ValidationConditionCode("MatchingEnabledMirageExists");
    ValidationConditionCode MATCHING_DISABLED_MIRAGE_EXISTS_CODE = new ValidationConditionCode("MatchingDisabledMirageExists");
}
