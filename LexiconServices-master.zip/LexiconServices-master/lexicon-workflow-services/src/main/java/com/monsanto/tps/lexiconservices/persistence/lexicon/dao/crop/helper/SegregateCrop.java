/*
 SegregateCrop was created on Jun 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper;

import com.monsanto.tps.lexiconservices.crop.domain.BaseCrop;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/18/13
 * Time: 5:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SegregateCrop extends BaseCrop {

  private SegregateBayerCode bayerCode;

  public SegregateBayerCode getBayerCode() {
    return bayerCode;
  }

  public void setBayerCode(SegregateBayerCode bayerCode) {
    this.bayerCode = bayerCode;
  }
}
