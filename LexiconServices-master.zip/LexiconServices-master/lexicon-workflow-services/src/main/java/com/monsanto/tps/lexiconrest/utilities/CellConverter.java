/*
$Log$
*/
package com.monsanto.tps.lexiconrest.utilities;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DateUtil;

import java.io.IOException;

/**
 */
public class CellConverter {
    private final CellValueConverter valueConverter = new CellValueConverter();
    public static final short MIN_HSSF_CELL_DATE_FORMAT_DDMMMYYYY_STYLE = 165;
    public static final short MAX_HSSF_CELL_DATE_FORMAT_DDMMMYYYY_STYLE = 167;

    public String convert(Cell cell) throws IOException {
        int cellType = cell.getCellType();
        switch (cellType) {
            case Cell.CELL_TYPE_BLANK:
                return "";
            case Cell.CELL_TYPE_BOOLEAN:
                return valueConverter.convert(cell.getBooleanCellValue());
            case Cell.CELL_TYPE_ERROR:
                throw new IOException("Unsupported cell type 'ERROR'");
            case Cell.CELL_TYPE_FORMULA:
                throw new IOException("Unsupported cell type 'FORMULA'");
            case Cell.CELL_TYPE_NUMERIC:
                return convertNumericCell(cell);
            case Cell.CELL_TYPE_STRING:
                return cell.getStringCellValue();
            default:
                throw new IOException("Unexpected cell type " + cellType);
        }
    }

    private String convertNumericCell(Cell cell) throws IOException {
        if (isDateTypeCell(cell)) {
            return valueConverter.convert(cell.getDateCellValue());
        } else {
            return valueConverter.convert(cell.getNumericCellValue());
        }
    }

    private boolean isDateTypeCell(Cell cell) throws IOException {
        return isGeneralDateTypeCell(cell) || isHyphenatedDateWithTextMonthFullYear(cell);
    }

    private boolean isHyphenatedDateWithTextMonthFullYear(Cell cell) throws IOException {
        CellStyle style = cell.getCellStyle();
        return (style.getDataFormat() >= MIN_HSSF_CELL_DATE_FORMAT_DDMMMYYYY_STYLE && style.getDataFormat() <= MAX_HSSF_CELL_DATE_FORMAT_DDMMMYYYY_STYLE);
    }

    private boolean isGeneralDateTypeCell(Cell cell) {
        return DateUtil.isCellDateFormatted(cell);
    }
}
