package com.monsanto.tps.lexiconservices.persistence.yldstg.dao.domain;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/3/14
 * Time: 10:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class MapCropMirageDto {

  private Long midasCropId;
  private String midasCropName;
  private String mirageBayerCode;

  public Long getMidasCropId() {
    return midasCropId;
  }

  public void setMidasCropId(Long midasCropId) {
    this.midasCropId = midasCropId;
  }

  public String getMidasCropName() {
    return midasCropName;
  }

  public void setMidasCropName(String midasCropName) {
    this.midasCropName = midasCropName;
  }

  public String getMirageBayerCode() {
    return mirageBayerCode;
  }

  public void setMirageBayerCode(String mirageBayerCode) {
    this.mirageBayerCode = mirageBayerCode;
  }
}
