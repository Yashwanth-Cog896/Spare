package com.monsanto.tps.lexiconservices.manufacturing.line.edit.service.impl;

import com.monsanto.tps.aop.exception.RootCauseWebExceptionWrapper;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain.EditManufacturingLineRichRequest;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions.EditManufacturingLineException;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.EditManufacturingLineService;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineResponse;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.validator.EditManufacturingLineRichRequestValidator;
import org.apache.cxf.feature.Features;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/13/13
 * Time: 11:16 AM
 */
@Component(value = "editManufacturingLineServiceImpl")
@Transactional(propagation = Propagation.REQUIRED)
@Features(features = "org.apache.cxf.feature.LoggingFeature")
public class EditManufacturingLineServiceImpl implements EditManufacturingLineService {
  private Logger logger = Logger.getLogger(EditManufacturingLineServiceImpl.class);

  @Resource
  private EditManufacturingLineRichRequestValidator editManufacturingLineRichRequestValidator;

  @Resource
  private EditManufacturingLineRichRequestProcessor editManufacturingLineRichRequestProcessor;

  @Resource
  private EditManufacturingLineWriter editManufacturingLineWriter;

  @RootCauseWebExceptionWrapper(exceptionClass = EditManufacturingLineException.class)
  public List<EditManufacturingLineResponse> processEditManufacturingLine(List<EditManufacturingLineRequest> editManufacturingLineRequestList) throws EditManufacturingLineException {

    if (editManufacturingLineRequestList.isEmpty()) {
      return new ArrayList<EditManufacturingLineResponse>();
    }
    return processRequest(editManufacturingLineRequestList);
  }

  private List<EditManufacturingLineResponse> processRequest(List<EditManufacturingLineRequest> editManufacturingLineRequestList) throws EditManufacturingLineException {
    logger.info("Processing EditManufacturingLineService request");
    List<EditManufacturingLineResponse> editManufacturingLineResponseList = new ArrayList<EditManufacturingLineResponse>();
    for (EditManufacturingLineRequest request : editManufacturingLineRequestList) {
      EditManufacturingLineRichRequest editManufacturingLineRichRequest = editManufacturingLineRichRequestProcessor.createEditManufacturingLineRichRequest(request);
      List<String> messages = editManufacturingLineRichRequestValidator.validate(editManufacturingLineRichRequest);
      editManufacturingLineWriter.writeIfValid(messages, editManufacturingLineRichRequest);
      EditManufacturingLineResponse editManufacturingLineResponse = new EditManufacturingLineResponse();
      editManufacturingLineResponse.setMessages(messages);
      editManufacturingLineResponseList.add(editManufacturingLineResponse);
    }
    return editManufacturingLineResponseList;
  }

}
