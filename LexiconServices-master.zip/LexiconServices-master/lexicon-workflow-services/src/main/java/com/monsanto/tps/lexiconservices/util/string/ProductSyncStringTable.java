package com.monsanto.tps.lexiconservices.util.string;

import com.monsanto.tcc.lexiconcommon.string.StringTable;

public class ProductSyncStringTable
        extends StringTable {
    protected String getFilename() {
        return "ProductSyncStringTable.properties";
    }
}
