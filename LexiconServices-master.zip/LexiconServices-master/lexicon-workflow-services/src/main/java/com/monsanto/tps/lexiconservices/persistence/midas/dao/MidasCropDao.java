package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCropEntity;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/30/14
 * Time: 10:20 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasCropDao extends GenericDao<MidasCropEntity,Long> {

  MidasCropEntity getMidasCropByCropID(Long cropID);
}
