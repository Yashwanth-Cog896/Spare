/*
 ProductStageResponseStatus was created on Dec 14, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconrest.external;

/**
 * nbwald Dec 14, 2006 5:56:45 PM
 */
public interface ProductStageResponseStatus extends ResponseStatus
{
   String getProductPubkey();
   String getProductNamePubkey();
   String getExceptionKey();
   String getAutoProductStageTypeAbbr();
   String getAutoBrandName();
   String getAutoComlName();
}