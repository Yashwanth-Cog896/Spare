package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ExceptionCodeEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CropDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconExceptionCodeDao;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 4:26 PM
 */
@Component(value = "exceptionCodeWriter")
public class ExceptionCodeWriter {

    @Resource
    private LexiconExceptionCodeDao exceptionCodeDao;

    @Resource
    private CropDao cropDao;

    public ExceptionCodeEntity write(boolean vegetable, long lexiconCropId, String productName, String requestedProductName, boolean primary) {
        ExceptionCodeEntity updatedExceptionCode = null;
        ExceptionCodeEntity requestedExceptionCode = null;
        if (vegetable && productName != null && requestedProductName != null) {
            updatedExceptionCode = exceptionCodeDao.findByCropAndProductName(lexiconCropId, productName);
            requestedExceptionCode = exceptionCodeDao.findByCropAndProductName(lexiconCropId, requestedProductName);

            if (requestedExceptionCode != null && !requestedExceptionCode.equals(updatedExceptionCode)) {
                updatedExceptionCode = requestedExceptionCode;
            } else if (updatedExceptionCode == null) {
                updatedExceptionCode = new ExceptionCodeEntity();
                updatedExceptionCode.setExceptionCode(exceptionCodeDao.getNextExceptionCodePubkey());
                updatedExceptionCode.setLexiconCrop(cropDao.get(lexiconCropId));
                updatedExceptionCode.setProductName(productName);
            }

            updateExceptionCodeAttributes(updatedExceptionCode, primary, productName, requestedProductName);
            exceptionCodeDao.saveOrUpdate(updatedExceptionCode);
        }
        return updatedExceptionCode;
    }

    private void updateExceptionCodeAttributes(ExceptionCodeEntity exceptionCode, boolean primary, String productName, String requestedProductName) {
        exceptionCode.setPrimary(primary);
        if (!productName.equalsIgnoreCase(requestedProductName)) {
            exceptionCode.setProductName(requestedProductName);
        }
    }
}
