package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tcc.lexiconcommon.product.model.lexicon.ProductRelationshipProduct;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductionStatusEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductionStatusDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNRelationshipAssignmentRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 10:55 AM
 */
@Component(value = "syncProductLexRelationshipWriter")
public class SyncProductLexRelationshipWriter {

    @Resource
    private ProductRelationshipDao productRelationshipDao;

    @Resource
    private LexiconProductionStatusDao lexiconProductionStatusDao;

    public ProductRelationshipObject write(MutableSyncProduct syncProduct, APCNRelationshipAssignmentRichRequest relationshipAssignmentData) {
        String manfName = relationshipAssignmentData.getRequestedManfName(), traitVersion = relationshipAssignmentData.getRequestedTraitVersion();
        if (manfName != null && !manfName.isEmpty()) {
            return processRelationshipProductLevel(relationshipAssignmentData, syncProduct, manfName, traitVersion);
        } else {
            return relationshipAssignmentData.getExistingManfNameRelationship();
        }
    }

    private ProductRelationshipObject processRelationshipProductLevel(APCNRelationshipAssignmentRichRequest relationshipAssignmentData,
                                                                      MutableSyncProduct syncProduct, String manfName, String traitVersion) {

        ProductRelationshipObject existingProdRel = syncProduct.getProductRelationship();
        ProductRelationshipObject existingManfRel = relationshipAssignmentData.getExistingManfNameRelationship();
        if (existingProdRel == null) {
            ProductRelationshipDTO product = new ProductRelationshipDTO(syncProduct.getLexProduct(), traitVersion);
            product.setManfName(manfName);
            LexiconProductionStatusEntity lexiconProductionStatus = lexiconProductionStatusDao.getByStatus(ProductRelationshipProduct.ACTIVE_PRODUCTION_STATUS);
            ProductRelationshipEntity productRelationEntity = productRelationshipDao.findManufacturingLineByManufacturingName(manfName);
            productRelationshipDao.insertProductRelationshipXref(traitVersion, syncProduct.getLexProduct().getId(), lexiconProductionStatus.getId(), productRelationEntity.getId());
            existingManfRel.addRelationshipProduct(product);
        }
        return existingManfRel;
    }


}
