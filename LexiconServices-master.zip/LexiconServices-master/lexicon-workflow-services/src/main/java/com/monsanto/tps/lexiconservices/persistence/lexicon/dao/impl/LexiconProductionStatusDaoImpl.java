package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductionStatusEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductionStatusDao;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 3/18/14
 * Time: 11:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductionStatusDaoImpl extends GenericDaoImpl<LexiconProductionStatusEntity, Long> implements LexiconProductionStatusDao {

    public LexiconProductionStatusDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public LexiconProductionStatusEntity getByStatus(String status) {
        return (LexiconProductionStatusEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconProductionStatusEntity.class, "productionStatus").
                add(Restrictions.eq("productionStatus.productionStatusName", status)).uniqueResult();

    }
}
