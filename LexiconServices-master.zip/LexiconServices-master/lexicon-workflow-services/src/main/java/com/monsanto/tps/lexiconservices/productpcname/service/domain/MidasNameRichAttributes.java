package com.monsanto.tps.lexiconservices.productpcname.service.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/11/14
 * Time: 11:31 AM
 */
public class MidasNameRichAttributes {

    private ACPNRichStageAttributes stageAttributes;

    public MidasNameRichAttributes(ACPNRichStageAttributes stageAttributes) {

        this.stageAttributes = stageAttributes;
    }

    public String getComlName() {
        return stageAttributes.getCommercialName();
    }

    public boolean isCommercialStage() {
        return stageAttributes.isCommercialStage();
    }

    public TPSBrand getBrand() {
        return stageAttributes.getBrand();
    }

    public TPSCountry getCountry() {
        return stageAttributes.getCountry();
    }

    public boolean isPreferredName() {
        return stageAttributes.isPreferredName();
    }
}
