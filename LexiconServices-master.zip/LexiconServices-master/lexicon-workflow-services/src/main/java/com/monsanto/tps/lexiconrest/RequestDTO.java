package com.monsanto.tps.lexiconrest;

import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class RequestDTO {
    private List<ExcelDTO> excelDTOList;

    public RequestDTO() {
    }

    public List<ExcelDTO> getExcelDTOList() {
        return excelDTOList;
    }

    public void setExcelDTOList(List<ExcelDTO> excelDTOList) {
        this.excelDTOList = excelDTOList;
    }
}