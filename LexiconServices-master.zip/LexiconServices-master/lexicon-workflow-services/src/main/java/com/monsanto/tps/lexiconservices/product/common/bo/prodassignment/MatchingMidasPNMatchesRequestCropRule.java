package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;

public class MatchingMidasPNMatchesRequestCropRule
        extends SimpleValidationRule {
    private final MidasProductNamesCollection matchingMidasPN;
    private final TPSCrop crop;

    public MatchingMidasPNMatchesRequestCropRule(MidasProductNamesCollection matchingMidasPN, TPSCrop crop) {
        this.matchingMidasPN = matchingMidasPN;
        this.crop = crop;
    }

    protected boolean preConditionsMet() {
        return crop != null;
    }

    protected boolean criteriaViolated() {
      return !matchingMidasPN.cropMatches(crop);
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.MATCH_MIDAS_PN_DIFF_CROPID_CODE);
    }
}
