package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:34 PM
 */
public class NewManufacturingAttributesDoNotExistViolation {

    private final ProductRelationshipEntity requestedManufacturingLine;
    private final ProductRelationshipEntity newManufacturingAttributes;

    public NewManufacturingAttributesDoNotExistViolation(ProductRelationshipEntity requestedManufacturingLine, ProductRelationshipEntity newManufacturingAttributes) {
        this.requestedManufacturingLine = requestedManufacturingLine;
        this.newManufacturingAttributes = newManufacturingAttributes;
    }

    protected boolean preconditionsMet() {
        return requestedManufacturingLine != null;
    }

    protected boolean criteriaViolated() {
        return newManufacturingAttributesExist() && newManufacturingAttributesAreReallyNew();
    }

    private boolean newManufacturingAttributesExist() {
        return newManufacturingAttributes != null;
    }

    private boolean newManufacturingAttributesAreReallyNew() {
        return !StringUtils.areEqual(requestedManufacturingLine.getManufacturingName(), newManufacturingAttributes.getManufacturingName());
    }
}
