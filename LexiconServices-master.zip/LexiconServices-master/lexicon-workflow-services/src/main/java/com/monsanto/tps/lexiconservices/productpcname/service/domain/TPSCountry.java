package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCountryEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 2:16 PM
 */
public class TPSCountry {

    private final LexiconCountryEntity lexCountry;
    private final long midasID;
    private final String mirageID;

    public TPSCountry(LexiconCountryEntity lexiconCountryEntity, long midasID, String mirageID) {
        this.lexCountry = lexiconCountryEntity;
        this.midasID = midasID;
        this.mirageID = mirageID;
    }


    public String getPublicKey() {
        return lexCountry.getPubkey();
    }

    public String getName() {
        return lexCountry.getName();
    }

    public long getMidasID() {
        return midasID;
    }

    public String getMirageID() {
        return mirageID;
    }

    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        TPSCountry other = (TPSCountry) obj;
        return this.getMidasID() == other.getMidasID()
                && this.getMirageID() != null
                && this.getMirageID().equals(other.getMirageID());
    }

    public boolean existsInFieldBreedingSystems() {
        return midasID != 0 && mirageID != null;
    }

    public LexiconCountryEntity getLexCountry() {
        return lexCountry;
    }

}
