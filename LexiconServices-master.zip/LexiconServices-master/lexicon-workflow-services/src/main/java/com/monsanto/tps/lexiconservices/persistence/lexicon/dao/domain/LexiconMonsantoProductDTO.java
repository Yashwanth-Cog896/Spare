package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain;

/**
 * Created with IntelliJ IDEA.
 * User: PSETH
 * Date: 1/8/14
 * Time: 3:48 PM
 */
public class LexiconMonsantoProductDTO {

  public static final String YES = "y";
  public static final String NO = "n";

  private String productPubkey;
  private String preComlName;
  private String cropName;
  private String tagVarietyName;
  private boolean isParentProduct;
  private String productClassificationCode;
  private String supplyChainOwner;
  private String ownerRegion;

  public LexiconMonsantoProductDTO(String productPubkey, String preComlName, String cropName, String tagVarietyName,
                                   boolean parentProduct, String productClassificationCode, String supplyChainOwner, String ownerRegion) {
    this.productPubkey = productPubkey;
    this.preComlName = preComlName;
    this.cropName = cropName;
    this.tagVarietyName = tagVarietyName;
    isParentProduct = parentProduct;
    this.productClassificationCode = productClassificationCode;
    this.supplyChainOwner = supplyChainOwner;
    this.ownerRegion = ownerRegion;
  }

  public String getProductPubkey() {
    return productPubkey;
  }

  public String getPreComlName() {
    return preComlName;
  }

  public String getCropName() {
    return cropName;
  }

  public String getTagVarietyName() {
    return tagVarietyName;
  }

  public boolean isParentProduct() {
    return isParentProduct;
  }

  public String getProductClassificationCode() {
    return productClassificationCode;
  }

  public String getSupplyChainOwner() {
    return supplyChainOwner;
  }

  public String getOwnerRegion() {
    return ownerRegion;
  }

  public String getParentProduct() {
    return ((this.isParentProduct()) ? YES : NO);
  }
}
