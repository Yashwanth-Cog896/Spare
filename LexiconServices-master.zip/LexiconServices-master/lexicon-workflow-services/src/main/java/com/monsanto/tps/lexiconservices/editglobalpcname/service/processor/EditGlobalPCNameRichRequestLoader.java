package com.monsanto.tps.lexiconservices.editglobalpcname.service.processor;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.editglobalpcname.domain.EditGlobalPCNameRequest;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.domain.EditGlobalPCNameRichRequest;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.validation.TagVarietyNameValidation;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.LexiconProductNames;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCountry;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/10/14
 * Time: 1:03 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "editGlobalPCNameRichRequestLoader")
public class EditGlobalPCNameRichRequestLoader {

  @Resource
  private EditGlobalPCNameSyncProductLoader editGlobalPCNameSyncProductLoader;

  @Resource
  private LexiconProductDao lexiconProductDao;

  private MutableSyncProduct syncProduct;

  private static String tagVarietyName;

  private static boolean tagVarietyNameInUse;

  private TagVarietyNameValidation tagVarietyNameValidation = new TagVarietyNameValidation();

  public EditGlobalPCNameRichRequest getRichRequest(EditGlobalPCNameRequest request) throws WrappingException {
    EditGlobalPCNameRichRequest editGlobalPCNameRichRequest = new EditGlobalPCNameRichRequest();
    editGlobalPCNameRichRequest.setSyncProduct(editGlobalPCNameSyncProductLoader.loadSyncProduct(request.getProductPubKey()));
    editGlobalPCNameRichRequest.setMatchingLexProd(lexiconProductDao.getMatchingLexiconProduct(request.getPreComlName()));
    editGlobalPCNameRichRequest.setNewPreComlName(request.getPreComlName());
    editGlobalPCNameRichRequest.setSupplyChainOwner(request.getSupplyChainOwner());
    editGlobalPCNameRichRequest.setTagVarietyName(request.getTagVarietyName());
    editGlobalPCNameRichRequest.setProductClassificationCode(request.getProductClassificationCode());
    editGlobalPCNameRichRequest.setDefaultCountry(loadDefaultCountry(editGlobalPCNameRichRequest.getSyncProduct()));
    syncProduct = editGlobalPCNameRichRequest.getSyncProduct();
    tagVarietyName = request.getTagVarietyName();
    if ((tagVarietyName != null && syncProduct.getLexProduct() != null && syncProduct.getLexProduct().getTagVarietyName() != null && !syncProduct.getLexProduct().getTagVarietyName().equals(tagVarietyName)) || (syncProduct.getLexProduct() != null && syncProduct.getLexProduct().getTagVarietyName() == null)) {
      editGlobalPCNameRichRequest.setTagVarietyNameInUse(determineTagVarietyNameUsed(request.getProductPubKey()));
    }
    tagVarietyNameInUse = editGlobalPCNameRichRequest.isTagVarietyNameInUse();
    if (!tagVarietyNameInUse) {
      editGlobalPCNameRichRequest.setTagVarietyNumberInUse(determineTagVarietyNumberUser());
    }

    return editGlobalPCNameRichRequest;
  }

  private TPSCountry loadDefaultCountry(MutableSyncProduct syncProduct) {
    LexiconProductNames lexiconProductNames = syncProduct.getLexiconProductNames();
    LexiconProductStageEntity lexStage = lexiconProductNames.getFirstNonDeletedStage();
    return (lexStage != null) ? editGlobalPCNameSyncProductLoader.getCountryByPubkey(lexStage.getLexiconCountry().getPubkey()) : null;
  }

  private boolean determineTagVarietyNameUsed(String productPubkey) throws WrappingException {
    boolean tagVarietyNameUsed = false;

    List<String> pubKeys = getPubkeysByTagVarietyName();
    if (!StringUtils.isNullOrEmpty(productPubkey)) {
      pubKeys.remove(productPubkey);
    }
    tagVarietyNameUsed = (pubKeys.size() > 0);

    return tagVarietyNameUsed;
  }

  private List<String> getPubkeysByTagVarietyName() throws WrappingException {
    TPSCrop crop = syncProduct.getCrop();
    List<String> pubKeys = new ArrayList<String>();
    if ((crop != null) && (doValidateTagVarietyName())) {
      pubKeys = lexiconProductDao.getPubkeysByTagVarietyName(tagVarietyName, crop.getLexiconCropID());
    }
    return pubKeys;
  }

  private boolean doValidateTagVarietyName() {
    ProductRelationshipObject relationship = syncProduct.getProductRelationship();
    boolean hasManfName = (relationship != null) && (!StringUtils.isNullOrEmpty(relationship.getManufacturingName()));
    boolean hasTagVarietyName = !StringUtils.isNullOrEmpty(tagVarietyName);
    return (!hasManfName) && hasTagVarietyName;
  }

  private boolean determineTagVarietyNumberUser() throws WrappingException {
    boolean tagVarietyNumberUsed = false;
    String tagVarietyNumber;
    TPSCrop crop = syncProduct.getCrop();
    if ((crop != null) && (doValidateTagVarietyName())) {
      if (tagVarietyNameValidation.checkTagVarietyNamePattern(tagVarietyName)) {
        tagVarietyNumber = tagVarietyNameValidation.getNumericalFromTagVarietyName(tagVarietyName);
        List<String> existingTagVarietyNumbers = getAllVarietyNamesWithoutBrandCodeAndVarietyCode(crop.getLexiconCropID());
        tagVarietyNumberUsed = existingTagVarietyNumbers.contains(tagVarietyNumber);
      }
    }

    return tagVarietyNumberUsed;
  }

  private List<String> getAllVarietyNamesWithoutBrandCodeAndVarietyCode(Long cropId) throws WrappingException {
    List<String> excludedVarietyNames = lexiconProductDao.getTagVarietyNamesByREGEXAndCrop(tagVarietyNameValidation.getTagVarietyPatternRegex(), cropId);
    List<String> excludedProductNameDigits = new ArrayList<String>();
    if (!excludedVarietyNames.isEmpty()) {
      for (String varietyName : excludedVarietyNames) {
        excludedProductNameDigits.add(tagVarietyNameValidation.getNumericalFromTagVarietyName(varietyName));
      }
    }
    return excludedProductNameDigits;
  }

}
