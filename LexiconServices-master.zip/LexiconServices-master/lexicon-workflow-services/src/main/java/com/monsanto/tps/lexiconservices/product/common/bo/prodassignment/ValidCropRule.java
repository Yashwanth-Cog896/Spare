/*
 ValidCropRule was created on Dec 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;


public class ValidCropRule
        extends SimpleValidationRule {
    private final TPSCrop crop;

    public ValidCropRule(TPSCrop crop) {
        this.crop = crop;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return crop == null;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.INVALID_CROP);
    }
}