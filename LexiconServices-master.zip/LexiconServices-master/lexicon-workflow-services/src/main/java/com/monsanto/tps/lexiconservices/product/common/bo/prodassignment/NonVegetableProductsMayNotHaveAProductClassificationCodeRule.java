package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

/**
 * nbwald - Jan 15, 2010 3:02:36 PM
 */
public class NonVegetableProductsMayNotHaveAProductClassificationCodeRule
        extends SimpleValidationRule {
    private final boolean vegetableProduct;
    private final String productClassificationCode;

    public NonVegetableProductsMayNotHaveAProductClassificationCodeRule(boolean vegetableProduct, String productClassificationCode) {
        this.vegetableProduct = vegetableProduct;
        this.productClassificationCode = productClassificationCode;
    }

    @Override
    protected boolean preConditionsMet() {
        return !vegetableProduct;
    }

    @Override
    protected boolean criteriaViolated() {
        return productClassificationCode != null;
    }

    @Override
    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ROW_PROD_HAS_PROD_CLASSIFICATION_CODE);
    }
}
