package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.tps.lexiconservices.common.rule.Rule;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:56 PM
 */
public class ValidManufacturingNameRule implements Rule {
    private final String manufacturingName;

    public ValidManufacturingNameRule(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public boolean isViolated() {
        ManufacturingNameValidationChecks manfNameValidator = new ManufacturingNameValidationChecks(manufacturingName);
        return !manfNameValidator.isValid();
    }

    public String getViolation() {
        return "The manufacturing name must be 50 characters or less in length and contain only letters, numbers, dashes, underscores, or plus sign.";
    }
}