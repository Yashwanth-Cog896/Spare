/*
$Log$
*/
package com.monsanto.tps.lexiconrest.utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 */
public class CellValueConverter {

    private final DateFormat dateFormatter = new SimpleDateFormat("yyyy/MM/dd");

    public String convert(Double value) {
        if (value.doubleValue() % 1 == 0 && value >= Long.MIN_VALUE &&
                value <= Long.MAX_VALUE) {
            return String.valueOf(value.longValue());
        } else {
            return String.valueOf(value);
        }
    }

    public String convert(Date value) {
        return dateFormatter.format(value);
    }

    public String convert(Boolean value) {
        return value.toString().toUpperCase();
    }


}