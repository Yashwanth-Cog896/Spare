package com.monsanto.tps.lexiconservices.productpcname.service.impl;

import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatus;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatusImpl;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexiconservices.lexicon.audit.LexiconAuditorService;
import com.monsanto.tps.lexiconservices.product.common.service.validation.impl.AssignPCNameValidatorImpl;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameResponse;
import com.monsanto.tps.lexiconservices.productpcname.service.AssignPCNameService;
import com.monsanto.tps.lexiconservices.productpcname.service.AssignPCNameServiceException;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.AssignPCNameRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.AssignPCNameProductWriter;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.AssignPCNameRichRequestLoader;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.PreComlNameAssignment;
import com.monsanto.tps.lexiconservices.productpcname.validation.AssignPCNameValidationModelImpl;
import org.apache.cxf.feature.Features;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.jws.WebParam;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 1:11 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "assignPCNameServiceImpl")
@Transactional(propagation = Propagation.REQUIRED)
@Features(features = "org.apache.cxf.feature.LoggingFeature")
public class AssignPCNameServiceImpl implements AssignPCNameService {

    private Logger logger = Logger.getLogger(AssignPCNameServiceImpl.class);

    @Resource
    private PreComlNameAssignment preComlNameAssignment;

    @Resource
    private AssignPCNameRichRequestLoader assignPCNameRichRequestLoader;

    @Resource
    private LexiconAuditorService lexiconAuditorService;

    @PerformanceMetric(task = "AssignPCNameService.assignPrecommercialName", comment = "assignPrecommercialName")
    public List<AssignPCNameResponse> assignPreCommercialName(@WebParam(name = "assignPCNameRequest") List<AssignPCNameRequest> assignPCNameRequestList) throws AssignPCNameServiceException {
        logger.info("Processing Assign Pre Commercial Name Request");
        List<AssignPCNameResponse> responses = new ArrayList<AssignPCNameResponse>();
        for (AssignPCNameRequest assignPCNameRequest : assignPCNameRequestList) {

            AssignPCNameRichRequest richRequest = assignPCNameRichRequestLoader.getRichRequest(assignPCNameRequest);
            AssignPCNameValidatorImpl validator = new AssignPCNameValidatorImpl(new AssignPCNameValidationModelImpl(richRequest));
            ValidationStatus validationStatus = validator.validate();
            if (!assignPCNameRequest.isValidationOnly() && !validationStatus.hasSeverity(ValidationConditionSeverity.ERROR)) {
                preComlNameAssignment.write(richRequest);
            }
            AssignPCNameResponse response = new AssignPCNameResponse();
            if (validationStatus.hasSeverity(ValidationConditionSeverity.ERROR)) {
                response.setErrors(getMsgsFromValidations(Arrays.asList(validationStatus.getConditions(ValidationConditionSeverity.ERROR))));
            }
            if (validationStatus.hasSeverity(ValidationConditionSeverity.INFO)) {
                response.setNotes(getMsgsFromValidations(Arrays.asList(validationStatus.getConditions(ValidationConditionSeverity.INFO))));
            }
            response.setPreComlName(assignPCNameRequest.getPreComlName());
            response.setProductPubkey(richRequest.getSyncProduct().getProductPubkey());
            responses.add(response);
        }
        return responses;
    }

    private List<String> getMsgsFromValidations(List<ValidationCondition> validationConditions) {
        List<String> msgs = new ArrayList<String>();
        for (ValidationCondition validationCondition : validationConditions) {
            msgs.add(validationCondition.getError());
        }
        return msgs;
    }


    @PerformanceMetric(task = "AssignPCNameService.validateAssignPreCommercialNameRequests", comment = "validateAssignPreCommercialNameRequests")
    public List<AssignPCNameResponse> validateAssignPreCommercialNameRequests(@WebParam(name = "validateAssignPCNameRequest") List<AssignPCNameRequest> assignPCNameRequestList) throws AssignPCNameServiceException {
        List<AssignPCNameResponse> responses = new ArrayList<AssignPCNameResponse>();
        for (AssignPCNameRequest assignPCNameRequest : assignPCNameRequestList) {
            AssignPCNameRichRequest richRequest = assignPCNameRichRequestLoader.getRichRequest(assignPCNameRequest);
            AssignPCNameValidatorImpl validator = new AssignPCNameValidatorImpl(new AssignPCNameValidationModelImpl(richRequest));
            ValidationStatus validationStatus = validator.validate();
            AssignPCNameResponse response = new AssignPCNameResponse();
            if (validationStatus.hasSeverity(ValidationConditionSeverity.ERROR)) {
                response.setErrors(getMsgsFromValidations(Arrays.asList(validationStatus.getConditions(ValidationConditionSeverity.ERROR))));
            }
            if (validationStatus.hasSeverity(ValidationConditionSeverity.INFO)) {
                response.setNotes(getMsgsFromValidations(Arrays.asList(validationStatus.getConditions(ValidationConditionSeverity.INFO))));
            }
            response.setPreComlName(assignPCNameRequest.getPreComlName());
            response.setProductPubkey(richRequest.getSyncProduct().getProductPubkey());
            responses.add(response);
        }
        return responses;
    }
}
