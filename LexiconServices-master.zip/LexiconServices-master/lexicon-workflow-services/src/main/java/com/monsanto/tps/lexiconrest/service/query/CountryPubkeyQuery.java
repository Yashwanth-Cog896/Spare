package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.CountryDTO;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;

import java.util.*;

/**
 * nbwald - Mar 6, 2008 2:11:25 PM
 */
public class CountryPubkeyQuery
        extends AbstractPersistentStoreMultiRowQuery {
    private String[] countryName;
    private String selectCountryQuery = "select country_abbr,country_pubkey from lexicon.country where country_abbr in ( ";

    public CountryPubkeyQuery(String[] countryName) {
        this.countryName = countryName;
    }

    public List<CountryDTO> find()
            throws WrappingException {
        return getList();
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return getCountryObject(row);
    }

    private Object getCountryObject(PersistentStoreResultSetRow row) throws WrappingException {
        CountryDTO countryDTO = new CountryDTO(getNonNull(row.getString("country_pubkey")), row.getString("country_abbr"));
        return countryDTO;
    }

    private String getNonNull(String string) {
        return string == null ? "" : string;
    }

    protected String getSQL()
            throws WrappingException {
        return selectCountryQuery + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(countryName) + " ) or country_name in (" + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(countryName) + " )";
    }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
