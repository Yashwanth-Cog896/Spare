package com.monsanto.tps.lexiconservices.product.common.rule.existingproduct;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class ExistingLexProdHasProdXrefRule
        extends SimpleValidationRule {
    private final LexiconProductEntity lexiconProduct;
    private final FbsCommonProductXrefEntity productXref;

    public ExistingLexProdHasProdXrefRule(LexiconProductEntity lexiconProduct, FbsCommonProductXrefEntity productXref) {
        this.lexiconProduct = lexiconProduct;
        this.productXref = productXref;
    }

    public boolean preConditionsMet() {
        return lexiconProduct != null && !lexiconProduct.isLogicalDelete();
    }

    public boolean criteriaViolated() {
        return productXref == null;
    }

    public ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.LEX_PROD_FOUND_NO_XREF_CODE);
    }
}
