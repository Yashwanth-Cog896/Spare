package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 4:07 PM
 */
public class ACPNRichStageAttributes {

    private final APCNDefaultStageAttributesRichRequest defaultStageAttibutes;

    public APCNDefaultStageAttributesRichRequest getDefaultStageAttibutes() {
        return defaultStageAttibutes;
    }

    public APCNIndividualStageAttributesByCriteria getIndividualStageAttributes() {
        return individualStageAttributes;
    }

    private final APCNIndividualStageAttributesByCriteria individualStageAttributes;

    public ACPNRichStageAttributes(APCNDefaultStageAttributesRichRequest defaultStageAttibutes, APCNIndividualStageAttributesByCriteria individualStageAttributes) {
        this.defaultStageAttibutes = defaultStageAttibutes;
        this.individualStageAttributes = individualStageAttributes;
    }


    public TPSCountry getCountry() {
        return individualStageAttributes.getRequestedCountry();
    }

    public String getCountryPubkey() {
        return getCountry().getPublicKey();
    }

    public String getBrandPubkey() {
        return getBrand().getLexiconBrandPubkey();
    }

    public TPSBrand getBrand() {
        return defaultStageAttibutes.getPreComlBrand();
    }

    public String getStageTypePubkey() {
        return getStageType().getPubkey();
    }

    public LexiconStageEntity getStageType() {
        return defaultStageAttibutes.getRequestedStageType();
    }

    public String getComlTraitPubkey() {
        return getTraitStack() == null ? null : getTraitStack().getLexStack().getPubkey();
    }

    public TPSTrait getTraitStack() {
        return individualStageAttributes.getRequestedTraitStack();
    }

    public String getCommercialName() {
        return null;
    }

    public Double getComlMaturity() {
        return StringUtils.isNullOrEmpty(defaultStageAttibutes.getRequestedMaturity()) ?
                null : new Double(defaultStageAttibutes.getRequestedMaturity());
    }

    public String getOECDReqdName() {
        return null;
    }

    public boolean isActive() {
        return true;
    }

    public boolean isDeleted() {
        return false;
    }

    public boolean isPreferredName() {
        return false;
    }

    public boolean isVerifiedName() {
        return false;
    }

    public boolean isCommercialStage() {
        return false;
    }

    public String getMaturity() {
        return defaultStageAttibutes.getRequestedMaturity();
    }

}
