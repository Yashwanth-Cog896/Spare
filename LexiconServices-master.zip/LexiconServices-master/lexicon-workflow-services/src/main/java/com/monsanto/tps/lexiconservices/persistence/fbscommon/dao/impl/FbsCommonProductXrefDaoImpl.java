package com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonProductXrefDao;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/21/14
 * Time: 9:41 AM
 */
public class FbsCommonProductXrefDaoImpl extends GenericDaoImpl<FbsCommonProductXrefEntity, String> implements FbsCommonProductXrefDao {

    public FbsCommonProductXrefDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public FbsCommonProductXrefEntity findProductXrefByPubKey(@DynamicDaoParameter(name = "productPubKey") String productPubKey) {
        return null;
    }

    public FbsCommonProductXrefEntity save(FbsCommonProductXrefEntity productXref) {
        String save = (String) getSessionFactory().getCurrentSession().save(productXref);
        return get(save);
    }

    public int update(long midasProductId, String lexiconPubKey) {
        return getSessionFactory().getCurrentSession().getNamedQuery("FbsCommonProductXrefDao.update").setParameter("midasProductId",midasProductId).
                setParameter("lexiconPubKey",lexiconPubKey).executeUpdate();
    }
}
