package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCropEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasCropDao;
import org.hibernate.criterion.Restrictions;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/30/14
 * Time: 10:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasCropDaoImpl extends GenericDaoImpl<MidasCropEntity, Long> implements MidasCropDao {
  public MidasCropDaoImpl(Class entityClass) {
    super(entityClass);
  }

  @Override
  public MidasCropEntity getMidasCropByCropID(Long cropID) {
    return (MidasCropEntity) getSessionFactory().getCurrentSession().createCriteria(MidasCropEntity.class, "midasCrop").
      add(Restrictions.eq("midasCrop.id", cropID)).uniqueResult();
  }
}
