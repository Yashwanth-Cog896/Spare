package com.monsanto.tps.lexiconservices.persistence.midas.dao.domain;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ProductNameDTO {
  private long productNameID;
  private long productID;
  private String productName;
  private String brandName;
  private long countryID;
  private boolean preferredName;

  public ProductNameDTO(long productNameID, long productID, String productName, String brandName, long countryID, boolean preferredName) {
    this.productNameID = productNameID;
    this.productID = productID;
    this.productName = productName;
    this.brandName = brandName;
    this.countryID = countryID;
    this.preferredName = preferredName;
  }

  public long getProductNameID() {
    return productNameID;
  }

  public long getProductID() {
    return productID;
  }

  public String getProductName() {
    return productName;
  }

  public String getBrandName() {
    return brandName;
  }

  public long getCountryID() {
    return countryID;
  }

  public boolean isPreferredName() {
    return preferredName;
  }

  public String getPreferredName() {
    return new MidasBoolean(preferredName).getDatabaseRepresentation();
  }

  public class MidasBoolean {
    private final String databaseRepresentation;
    private final boolean value;

    public MidasBoolean(boolean value) {
      this.databaseRepresentation = value ? "T" : "F";
      this.value = value;
    }

    public MidasBoolean(String databaseRepresentation) {
      this.databaseRepresentation = databaseRepresentation;
      this.value = "T".equals(databaseRepresentation);
    }

    public String getDatabaseRepresentation() {
      return databaseRepresentation;
    }

    public boolean getValue() {
      return value;
    }

  }
}