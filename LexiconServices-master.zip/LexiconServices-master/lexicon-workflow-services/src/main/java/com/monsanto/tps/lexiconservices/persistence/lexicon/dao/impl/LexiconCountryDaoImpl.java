package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;


import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconCountryDao;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 1/6/14
 * Time: 5:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconCountryDaoImpl extends GenericDaoImpl<LexiconCountryEntity, Long> implements LexiconCountryDao {

    public LexiconCountryDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public LexiconCountryEntity getCountryByPubkey(String pubkey) {
        return (LexiconCountryEntity) getSessionFactory().getCurrentSession().
                createCriteria(LexiconCountryEntity.class).add(Restrictions.eq("pubkey", pubkey)).uniqueResult();
    }
}
