package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 2, 2007
 * Time: 5:57:12 PM
 */
public interface APCNDefaultStageAttributesValidationModel {
    TPSCrop getRequestedCrop();

    LexiconStageEntity getRequestedStageType();

    List<TPSTrait> getRequestedTraitStacks();

    String getRequestedMaturity();

    boolean isParentProduct();

    boolean shouldCreateDefaultStage();

    boolean isRequestedVegetableProduct();

    List<Long> getTraitStackIdsForGermplasm();
}
