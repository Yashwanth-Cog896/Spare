package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.validator.impl;

import com.monsanto.tps.lexiconservices.common.rule.Rule;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain.EditManufacturingLineRichRequest;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl.*;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.validator.EditManufacturingLineRichRequestValidator;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:12 PM
 */
@Component("editManufacturingLineRichRequestValidator")
public class EditManufacturingLineRichRequestValidatorImpl implements EditManufacturingLineRichRequestValidator {
    public List<String> validate(EditManufacturingLineRichRequest richRequest) {
        List<String> errors = new ArrayList<String>();
        accumulateErrors(errors, richRequest);
        return errors;
    }

    private void accumulateErrors(List<String> errors, EditManufacturingLineRichRequest richRequest) {
        for (Rule rule : getRules(richRequest)) {
            if (rule.isViolated()) {
                errors.add(rule.getViolation());
            }
        }
    }

    private Rule[] getRules(EditManufacturingLineRichRequest richRequest) {
        return new Rule[]{
                new ManufacturingLineExistsRule(richRequest.getRequestedManufacturingLine()),
                new NewManufacturingNameDoesNotExistRule(richRequest.getRequestedManufacturingLine(), richRequest.getNewManufacturingNamesManufacturingAttributes()),
                new NewVarietyNameNotAssignedToManufacturingNameRule(richRequest.getRequestedManufacturingLine(), richRequest.getNewVarietyNamesManufacturingAttributes()),
                new NonparentBaseProductHasVarietyNameRule(richRequest.getRequestedBaseProduct(), richRequest.getNewVarietyName(), richRequest.getRequestedManufacturingLine()),
                new ParentBaseProductHasNoVarietyNameRule(richRequest.getRequestedBaseProduct(), richRequest.getNewVarietyName()),
                new ValidManufacturingNameRule(richRequest.getNewManufacturingName()),
                new ValidVarietyNameRule(richRequest.getNewVarietyName()),
        };

    }

}
