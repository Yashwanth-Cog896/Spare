package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class TraitVersNameValidRule
        extends SimpleValidationRule {
    public static final int MAX_SIZE = 10;
    private final String traitVersName;

    public TraitVersNameValidRule(String traitVersName) {
        this.traitVersName = traitVersName;
    }

    protected boolean preConditionsMet() {
        return !StringUtils.isNullOrEmpty(traitVersName);
    }

    protected boolean criteriaViolated() {
        return valueTooLarge() || hasInvalidCharacters();
    }

    private boolean valueTooLarge() {
        return traitVersName.length() > MAX_SIZE;
    }

    private boolean hasInvalidCharacters() {
        return !traitVersName.matches("[\\w|\\-|\\+]+");
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TRAIT_VERS_INVALID_CODE);
    }
}
