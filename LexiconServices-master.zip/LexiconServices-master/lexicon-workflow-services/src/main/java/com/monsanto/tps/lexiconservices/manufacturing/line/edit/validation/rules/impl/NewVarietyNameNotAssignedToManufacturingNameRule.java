package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.tps.lexiconservices.common.rule.ConditionalRule;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:47 PM
 */
public class NewVarietyNameNotAssignedToManufacturingNameRule extends ConditionalRule {

    private final NewManufacturingAttributesDoNotExistViolation violation;

    public NewVarietyNameNotAssignedToManufacturingNameRule(ProductRelationshipEntity requestedManufacturingLine, ProductRelationshipEntity newVarietyNamesManufacturingAttributes) {
        violation = new NewManufacturingAttributesDoNotExistViolation(requestedManufacturingLine, newVarietyNamesManufacturingAttributes);
    }

    protected boolean preconditionsMet() {
        return violation.preconditionsMet();
    }

    protected boolean criteriaViolated() {
        return violation.criteriaViolated();
    }

    public String getViolation() {
        return "Variety name is already assigned to a manufacturing name.";
    }
}
