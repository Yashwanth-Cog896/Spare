package com.monsanto.tps.lexiconservices.productpcname.validation;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.*;

import java.util.ArrayList;
import java.util.List;

public class AssignPCNameValidationModelImpl
        implements AssignPCNameValidationModel {
    private final MutableSyncProduct syncProduct;
    private final APCNProductAssignmentRichRequest productAssignmentData;
    private final APCNRelationshipAssignmentRichRequest relationshipAssignmentData;
    private final APCNDefaultStageAttributesRichRequest stageAttributes;

    public AssignPCNameValidationModelImpl(AssignPCNameRichRequest request) {
        syncProduct = request.getSyncProduct();
        productAssignmentData = request.getProductAssignmentData();
        relationshipAssignmentData = request.getRelationshipAssignmentData();
        stageAttributes = request.getDefaultStageAttributes();
    }

    public String getRequestedPCName() {
        return productAssignmentData.getRequestedPCName();
    }

    public TPSCrop getRequestedCrop() {
        return productAssignmentData.getRequestedCrop();
    }

    public boolean getRequestedParentProductFlag() {
        return productAssignmentData.isParentProduct();
    }

    public String getRequestedProductClassificationCode() {
        return productAssignmentData.getProductClassificationCode();
    }

    public boolean isRequestedVegetableProduct() {
        return productAssignmentData.isVegetableProduct();
    }

    public ProductGermplasmCollection getAssigningGermplasm() {
        return productAssignmentData.getAssigningGermplasm();
    }

    public boolean isAnyAssigningGermplasmAttachedToProduct() {
        return productAssignmentData.isAnyAssigningGermplasmAttachedToProduct();
    }

    public String getRequestedManfName() {
        return relationshipAssignmentData.getRequestedManfName();
    }

    public String getRequestedTraitVersion() {
        return relationshipAssignmentData.getRequestedTraitVersion();
    }

    public ProductRelationshipObject getExistingManfNameRelationship() {
        return relationshipAssignmentData.getExistingManfNameRelationship();
    }

    public BaseProductEntity getExistingManfNameBaseProduct() {
        return relationshipAssignmentData.getBaseProduct();
    }

    public ProductRelationshipEntity getExistingManfNameManfLine() {
        return relationshipAssignmentData.getExistingManfNameManfLine();
    }

    public boolean shouldCreateDefaultStage() {
        return stageAttributes != null;
    }

    public LexiconStageEntity getRequestedStageType() {
        return stageAttributes.getRequestedStageType();
    }

    public List<TPSTrait> getRequestedTraitStacks() {
        List<APCNIndividualStageAttributesByCriteria> individualStageAttributes = stageAttributes.getIndividualStagesAttributes();
        List<TPSTrait> requestedTraitStacks = new ArrayList<TPSTrait>();
        if(individualStageAttributes!=null)  {
        for (APCNIndividualStageAttributesByCriteria individualStageAttribute : individualStageAttributes) {
            requestedTraitStacks.add(individualStageAttribute.getRequestedTraitStack());
        }
        }
        return requestedTraitStacks;
    }

    public String getRequestedMaturity() {
        return stageAttributes.getRequestedMaturity();
    }

    public boolean isParentProduct() {
        return syncProduct.isParentProduct();
    }

    public LexiconProductEntity getLexProduct() {
        return syncProduct.getLexProduct();
    }

    public LexiconProductNames getLexProductNames() {
        return syncProduct.getLexiconProductNames();
    }

    public FbsCommonProductXrefEntity getProductXref() {
        return syncProduct.getProductXref();
    }

    public MidasProductEntity getLinkedMidasProduct() {
        return syncProduct.getLinkedMidasProduct();
    }

    public MidasProductNamesCollection getMatchingMidasPN() {
        return syncProduct.getMatchingMidasPN();
    }

    public MidasProductNamesCollection getGlobalPCNameRecords() {
        return syncProduct.getGlobalPCNameRecords();
    }

    public ProductRelationshipObject getProductRelationship() {
        return syncProduct.getProductRelationship();
    }

    public InbredHybridEnum getInbredHybridType() {
        return syncProduct.getProductGermplasm().getGermplasmCollection().getInbredHybridType();
    }

    public boolean isContainsPreferredPedegree() {
        return productAssignmentData.isContainsPreferredPedigree();
    }

    public String getCropByProductClassification() {
        return productAssignmentData.getCropByProductClassification();
    }


    public String getTagVarietyName() {
        return productAssignmentData.getTagVarietyName();
    }


    public boolean isTagVarietyNameInUse() {
        return productAssignmentData.isTagVarietyNameInUse();
    }

    public List<Long> getTraitStackIdsForGermplasm() {
        return productAssignmentData.getTraitStackIdsForGermplasms();
    }


    public boolean isTagVarietyNumberInUse() {
        return productAssignmentData.isTagVarietyNameInUse();
    }
}
