package com.monsanto.tps.lexiconservices.editglobalpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCountry;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/10/14
 * Time: 1:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameRichRequest {

  private String newPreComlName;
  private String productClassificationCode;
  private ProductRelationshipDTO matchingLexProd;
  private MutableSyncProduct syncProduct;
  private String supplyChainOwner;
  private TPSCountry defaultCountry;
  private boolean vegetableProduct;
  private String tagVarietyName;
  private boolean tagVarietyNameInUse = false;
  private boolean tagVarietyNumberInUse = false;

  public String getNewPreComlName() {
    return newPreComlName;
  }

  public void setNewPreComlName(String newPreComlName) {
    this.newPreComlName = newPreComlName;
  }

  public String getProductClassificationCode() {
    return productClassificationCode;
  }

  public void setProductClassificationCode(String productClassificationCode) {
    this.productClassificationCode = productClassificationCode;
  }

  public ProductRelationshipDTO getMatchingLexProd() {
    return matchingLexProd;
  }

  public void setMatchingLexProd(ProductRelationshipDTO matchingLexProd) {
    this.matchingLexProd = matchingLexProd;
  }

  public MutableSyncProduct getSyncProduct() {
    return syncProduct;
  }

  public void setSyncProduct(MutableSyncProduct syncProduct) {
    this.syncProduct = syncProduct;
  }

  public String getSupplyChainOwner() {
    return supplyChainOwner;
  }

  public void setSupplyChainOwner(String supplyChainOwner) {
    this.supplyChainOwner = supplyChainOwner;
  }

  public TPSCountry getDefaultCountry() {
    return defaultCountry;
  }

  public void setDefaultCountry(TPSCountry defaultCountry) {
    this.defaultCountry = defaultCountry;
  }

  public boolean isVegetableProduct() {
    return vegetableProduct;
  }

  public void setVegetableProduct(boolean vegetableProduct) {
    this.vegetableProduct = vegetableProduct;
  }

  public String getTagVarietyName() {
    return tagVarietyName;
  }

  public void setTagVarietyName(String tagVarietyName) {
    this.tagVarietyName = tagVarietyName;
  }

  public boolean isTagVarietyNameInUse() {
    return tagVarietyNameInUse;
  }

  public void setTagVarietyNameInUse(boolean tagVarietyNameInUse) {
    this.tagVarietyNameInUse = tagVarietyNameInUse;
  }

  public boolean isTagVarietyNumberInUse() {
    return tagVarietyNumberInUse;
  }

  public void setTagVarietyNumberInUse(boolean tagVarietyNumberInUse) {
    this.tagVarietyNumberInUse = tagVarietyNumberInUse;
  }
}
