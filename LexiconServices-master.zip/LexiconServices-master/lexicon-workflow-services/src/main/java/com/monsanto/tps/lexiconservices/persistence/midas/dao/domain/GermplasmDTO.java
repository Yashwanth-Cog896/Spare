package com.monsanto.tps.lexiconservices.persistence.midas.dao.domain;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.LineTypeEntity;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class GermplasmDTO {
    private String TRUE = "T";
    private String FALSE = "F";
    private Long ID;
    private String origin;
    private String lineCode;
    private String pedigree;
    private String lineType;
    private String cropName;
    private String ownerProgRefID;
    private String eventDisplay;
    private String transgenic;
    private String finishedFlag;
    private String deleted;
    private InbredHybridEnum inbredHyridType;
    private String productName;

    public GermplasmDTO() {
    }

    public GermplasmDTO(long germplasmID, String preComlName, TPSCrop crop, ProductGermplasmCollection productGermplasm) {
        this.ID = germplasmID;
        this.productName = preComlName;
        this.cropName = crop.getMidasCropName();
        this.inbredHyridType = productGermplasm.getInbredHybridType();
        this.ownerProgRefID = productGermplasm.getAOwnerProgRefID();
        this.eventDisplay = productGermplasm.getAnyEventDisplay();
        this.transgenic = productGermplasm.isAnyTransgenic() ? TRUE : FALSE;
        this.ownerProgRefID = productGermplasm.getAOwnerProgRefID();
        MidasProductGermplasmDTO germplasm = productGermplasm.getGermplasmCollection().getGermplasms().iterator().next();
        this.origin = germplasm.getOrigin();
        this.lineCode = germplasm.getLineCode();
        this.pedigree = germplasm.getPedigree();
        this.lineType = germplasm.getLineType();
        this.finishedFlag = germplasm.getFinished();
        this.deleted = germplasm.getDeleted();
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public void setOwnerProgRefID(String ownerProgRefID) {
        this.ownerProgRefID = ownerProgRefID;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getOrigin() {
        return origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public String getPedigree() {
        return pedigree;
    }

    public String getLineType() {
        return lineType;
    }

    public String getCropName() {
        return cropName;
    }

    public String getOwnerProgRefID() {
        return ownerProgRefID;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public String getTransgenic() {
        return ("T".equalsIgnoreCase(transgenic)) ? TRUE : FALSE;
    }

    public void setTransgenic(String transgenic) {
        this.transgenic = transgenic;
    }

    public String getFinishedFlag() {
        return ("T".equalsIgnoreCase(finishedFlag)) ? TRUE : FALSE;
    }

    public void setFinishedFlag(String finishedFlag) {
        this.finishedFlag = finishedFlag;
    }

    public String getDeleted() {
        return ("T".equalsIgnoreCase(deleted)) ? TRUE : FALSE;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public boolean isFinishedFlag() {
        return (LineTypeEntity.HYBRID.equals(lineType)) ?
                Boolean.valueOf(getFinishedFlag()) : LineTypeEntity.FINISHED.equals(lineType);
    }


}