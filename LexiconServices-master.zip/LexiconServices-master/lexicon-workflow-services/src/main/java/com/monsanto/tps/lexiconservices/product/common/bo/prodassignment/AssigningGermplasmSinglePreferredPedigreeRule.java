package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;

public class AssigningGermplasmSinglePreferredPedigreeRule extends SimpleValidationRule {

    private final ProductGermplasmCollection assigningGermplasm;
    private final boolean hasPreferredGermplasm;

    public AssigningGermplasmSinglePreferredPedigreeRule(ProductGermplasmCollection assigningGermplasm, boolean hasPreferredGermplasm) {
        this.assigningGermplasm = assigningGermplasm;
        this.hasPreferredGermplasm = hasPreferredGermplasm;
    }

    @Override
    public boolean criteriaViolated() {
        boolean criteriaViolated = false;
        int preferredCount = assigningGermplasm.getPreferredCount();
        if ((preferredCount > 1) || (preferredCount > 0 && hasPreferredGermplasm)) {
            criteriaViolated = true;
        }
        return criteriaViolated;
    }

    @Override
    public boolean preConditionsMet() {
        return assigningGermplasm != null;
    }

    @Override
    public ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ASSIGNING_GP_MULTIPLE_PREFERRED);
    }
}
