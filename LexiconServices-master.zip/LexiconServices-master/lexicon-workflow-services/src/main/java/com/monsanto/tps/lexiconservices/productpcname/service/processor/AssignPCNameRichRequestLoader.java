package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNDefaultStageAttributesRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNProductAssignmentRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNRelationshipAssignmentRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.AssignPCNameRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/29/14
 * Time: 1:08 PM
 */
@Component(value = "assignPCNameRichRequestLoader")
public class AssignPCNameRichRequestLoader {

    @Resource
    private AssignPCNameSyncProductLoader assignPCNameSyncProductLoader;

    @Resource
    private ProductAssignmentDataLoader productAssignmentDataLoader;

    @Resource
    private RelationshipAssignmentRichRequestLoader relationshipAssignmentRichRequestLoader;

    @Resource
    private DefaultStageAttributesLoader defaultStageAttributesLoader;


    public AssignPCNameRichRequest getRichRequest(AssignPCNameRequest request) {
        AssignPCNameRichRequest richRequest = new AssignPCNameRichRequest();

        MutableSyncProduct syncProduct = assignPCNameSyncProductLoader.loadSyncProduct(request.getPreComlName(), request.getCropName(), request.isParentProduct());
        APCNProductAssignmentRichRequest productAssignmentData = productAssignmentDataLoader.loadProductAssignmentData(request, syncProduct);
        APCNRelationshipAssignmentRichRequest relationshipAssignmentData = relationshipAssignmentRichRequestLoader.loadRelationshipAssignmentData(request);
        APCNDefaultStageAttributesRichRequest defaultStageAttributesRichRequest = defaultStageAttributesLoader.loadDefaultStageAttributes(request, syncProduct);


        richRequest.setProductAssignmentData(productAssignmentData);
        richRequest.setSyncProduct(syncProduct);
        richRequest.setRelationshipAssignmentData(relationshipAssignmentData);
        richRequest.setDefaultStageAttributes(defaultStageAttributesRichRequest);
        return richRequest;
    }


}
