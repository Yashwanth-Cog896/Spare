/*
$Log$
*/
package com.monsanto.tps.lexiconrest.loader;

/**
 */
public class ImportModel {
    private String precommercialName;
    private ImportProductModel productModel;

    public ImportModel(String precommercialName, ImportProductModel productModel) {
        this.precommercialName = precommercialName;
        this.productModel = productModel;
    }

    public ImportModel() {

    }

    public String getPrecommercialName() {
        return precommercialName;
    }

    public void setPrecommercialName(String precommercialName) {
        this.precommercialName = precommercialName.trim();
    }

    public ImportProductModel getProductModel() {
        return productModel;
    }

    public void setProductModel(ImportProductModel productModel) {
        this.productModel = productModel;
    }
}
