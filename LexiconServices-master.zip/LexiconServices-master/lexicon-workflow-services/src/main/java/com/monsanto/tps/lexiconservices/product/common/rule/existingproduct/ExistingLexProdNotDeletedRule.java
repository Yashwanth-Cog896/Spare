package com.monsanto.tps.lexiconservices.product.common.rule.existingproduct;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class ExistingLexProdNotDeletedRule
        extends SimpleValidationRule {
    private final LexiconProductEntity lexiconProduct;

    public ExistingLexProdNotDeletedRule(LexiconProductEntity lexiconProduct) {
        this.lexiconProduct = lexiconProduct;
    }

    protected boolean preConditionsMet() {
        return lexiconProduct != null;
    }

    public boolean criteriaViolated() {
        return lexiconProduct.isLogicalDelete();
    }

    public ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.EXIST_LEX_PROD_DEL_CODE);
    }
}
