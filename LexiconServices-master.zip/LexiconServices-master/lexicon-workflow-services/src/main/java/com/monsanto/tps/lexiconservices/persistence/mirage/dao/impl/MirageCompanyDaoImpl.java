package com.monsanto.tps.lexiconservices.persistence.mirage.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCompanyEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.MirageCompanyDao;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/8/14
 * Time: 10:16 AM
 */
public class MirageCompanyDaoImpl extends GenericDaoImpl<MirageCompanyEntity,Long>implements MirageCompanyDao {
    public MirageCompanyDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public MirageCompanyEntity getMirageCompanyForPubKey(String lexiconBrandPubKey){
        return (MirageCompanyEntity) getSessionFactory().getCurrentSession().getNamedQuery("MirageCompanyDao.getMirageCompanyForPubKey")
                .setParameter("lexiconBrandPubkey",lexiconBrandPubKey).uniqueResult();
    }
}
