package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;


public class ExistingBaseProdSameCropAsRequestRule
        extends SimpleValidationRule {
    private TPSCrop requestedCrop;
    private BaseProductEntity existingManfNameBaseProduct;

    public ExistingBaseProdSameCropAsRequestRule(TPSCrop requestedCrop, BaseProductEntity existingManfNameBaseProduct) {
        this.requestedCrop = requestedCrop;
        this.existingManfNameBaseProduct = existingManfNameBaseProduct;
    }

    protected boolean preConditionsMet() {
        return requestedCrop != null && existingManfNameBaseProduct != null;
    }

    protected boolean criteriaViolated() {
        LexiconCropEntity crop = existingManfNameBaseProduct.getLexiconCrop();
        return !requestedCrop.getLexiconPubkey().equals(crop.getPubkey());
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.REQUESTED_CROP_DIFFERS_FROM_BASE_PRODUCTS);
    }
}