package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNRelationshipAssignmentRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.AssignPCNameRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 9:26 AM
 */
@Component(value = "assignPCNameProductWriter")
public class AssignPCNameProductWriter {

    @Resource
    private SyncProductLexiconProductWriter syncProductLexiconProductWriter;

    @Resource
    private SyncProductMidasProductWriter syncProductMidasProductWriter;

    @Resource
    private SyncProductFBSProductXrefWriter syncProductFBSProductXrefWriter;

    @Resource
    private SyncProductLexRelationshipWriter syncProductLexRelationshipWriter;

    @Resource
    private SyncProductGermplasmAssignmentWriter syncProductGermplasmAssignmentWriter;

    @Resource
    private SyncProductMirageGeneticMaterialWriter syncProductMirageGeneticMaterialWriter;

    public void write(AssignPCNameRichRequest request) {
        MutableSyncProduct syncProduct = request.getSyncProduct();

        syncProduct.setLexProduct(syncProductLexiconProductWriter.write(syncProduct.getLexProduct(),
                request.getProductAssignmentData(), determineVarietyName(request)));
        syncProduct.setLinkedMidasProduct(syncProductMidasProductWriter.write(syncProduct.getMidasProduct(), request.getProductAssignmentData().getRequestedCrop(),
                syncProduct.getLexProduct().getTagVarietyName()));
        syncProduct.setProductXref(syncProductFBSProductXrefWriter.write(syncProduct.getProductXref(), syncProduct.getLexProduct(), syncProduct.getMidasProduct()));
        syncProduct.setProductRelationship(syncProductLexRelationshipWriter.write(syncProduct, request.getRelationshipAssignmentData()));
        syncProduct.getProductGermplasm().addGermplasms(syncProductGermplasmAssignmentWriter.write(syncProduct.getMidasProduct(),
                request.getProductAssignmentData().getAssigningGermplasm()));
        syncProduct.setMirageGeneticMaterial(syncProductMirageGeneticMaterialWriter.write(syncProduct.getMidasProduct(), syncProduct.getMirageGeneticMaterial(),
                syncProduct.getProductGermplasm(), request.getProductAssignmentData().getRequestedPCName(), request.getProductAssignmentData().getRequestedCrop()));
    }


    private String determineVarietyName(AssignPCNameRichRequest request) {
        String requestedVarietyName = request.getProductAssignmentData().getTagVarietyName();
        APCNRelationshipAssignmentRichRequest relationshipAssignmentData = request.getRelationshipAssignmentData();
        String varietyName = null;
        if ((relationshipAssignmentData != null) &&
                (!StringUtils.isNullOrEmpty(relationshipAssignmentData.getExistingManfNameVarietyName()))) {
            varietyName = relationshipAssignmentData.getExistingManfNameVarietyName();
        }
        if ((varietyName == null) && (!request.getProductAssignmentData().getRequestedCrop().isVarietyNameGenerated())) {
            varietyName = StringUtils.isNullOrEmpty(requestedVarietyName) ? null : requestedVarietyName;
        }
        return varietyName;
    }
}
