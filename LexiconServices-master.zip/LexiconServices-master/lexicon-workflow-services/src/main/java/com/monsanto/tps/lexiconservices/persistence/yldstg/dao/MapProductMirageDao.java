package com.monsanto.tps.lexiconservices.persistence.yldstg.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.yldstg.domain.MapProductMirageEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/23/14
 * Time: 11:29 AM
 */
public interface MapProductMirageDao extends GenericDao<MapProductMirageEntity,Long> {

    MapProductMirageEntity save(MapProductMirageEntity entity);
}
