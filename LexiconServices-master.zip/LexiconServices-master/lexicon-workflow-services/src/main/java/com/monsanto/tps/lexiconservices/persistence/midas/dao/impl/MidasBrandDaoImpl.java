package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasBrandEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasBrandDao;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/7/14
 * Time: 2:57 PM
 */
public class MidasBrandDaoImpl extends GenericDaoImpl<MidasBrandEntity, Long> implements MidasBrandDao {

    public MidasBrandDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public MidasBrandEntity getMidasBrandForPubKey(String lexiconBrandPubkey) {
        return (MidasBrandEntity) getSessionFactory().getCurrentSession().getNamedQuery("MidasBrandDao.getMidasBrandForPubKey")
                .setParameter("lexiconBrandPubkey",lexiconBrandPubkey).uniqueResult();
    }
}
