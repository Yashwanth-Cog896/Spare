package com.monsanto.tps.lexiconservices.productpcname.service.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 12:13 PM
 */
public class APCNIndividualStageAttributesByCriteria {
    private TPSCountry requestedCountry;
    private TPSTrait requestedTraitStack;

    public APCNIndividualStageAttributesByCriteria(TPSCountry countryByPubkey, TPSTrait requestedTraitStack) {
        this.requestedCountry = countryByPubkey;
        this.requestedTraitStack = requestedTraitStack;

    }

    public TPSCountry getRequestedCountry() {
        return requestedCountry;
    }

    public TPSTrait getRequestedTraitStack() {
        return requestedTraitStack;
    }
}
