package com.monsanto.tps.lexiconservices.editglobalpcname.service.processor;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.domain.EditGlobalPCNameRichRequest;
import com.monsanto.tps.lexiconservices.externalservice.externalservice.SupportCenterLogger;
import com.monsanto.tps.lexiconservices.lexicon.audit.LexiconAuditorService;
import com.monsanto.tps.lexiconservices.lexicon.audit.domain.AuditStaging;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.AssignPCNameRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/18/14
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "globalPCNameUpdate")
public class GlobalPCNameUpdate {

  @Resource
  private LexiconAuditorService lexiconAuditorService;

  @Resource
  private AuditStagingDao auditStagingDao;

  @Resource
  private UserProfile userProfile;

  @Resource
  private EditGlobalPCNameProductWriter editGlobalPCNameProductWriter;

  @Resource
  private SupportCenterLogger supportCenterLogger;


  public void write(EditGlobalPCNameRichRequest richRequest) {
    AuditStaging auditStagingData = getAuditStagingData();
    MutableSyncProduct syncProduct;
    try {
      lexiconAuditorService.saveAuditStagingData(auditStagingData);
      syncProduct = editGlobalPCNameProductWriter.write(richRequest);
    } finally {
      lexiconAuditorService.deleteAuditStagingData(auditStagingData.getOracleSID());
    }
    String productPubkey = syncProduct.getProductPubkey();
    supportCenterLogger.updatePrecommercials(Arrays.asList(productPubkey));
  }

  private AuditStaging getAuditStagingData() {
    AuditStaging auditStaging = new AuditStaging();
    auditStaging.setAuditComment("");
    auditStaging.setAuditRequestor("");
    auditStaging.setUserLoginID(userProfile.getUserName());
    auditStaging.setProcessName("PRE_COML_NAME_ASSIGNMENT");
    auditStaging.setCreationTimestamp(new Date());
    auditStaging.setMachine(auditStagingDao.getSessionMachine());
    auditStaging.setOracleSID(auditStagingDao.getSessionId().longValue());
    auditStaging.setOsUser(auditStagingDao.getSessionOsUser());
    return auditStaging;
  }
}
