package com.monsanto.tps.lexiconservices.product.common.domain;


/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jul 16, 2006
 * Time: 11:43:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class InbredHybridEnum {

    private static final int HYBRID = 1;
    private static final int INBRED = 2;
    private static final int UNKNOWN = 0;

    public static final InbredHybridEnum HYBRID_TYPE = new InbredHybridEnum(HYBRID);
    public static final InbredHybridEnum INBRED_TYPE = new InbredHybridEnum(INBRED);

    private final int code;

    public InbredHybridEnum() {
        code = UNKNOWN;
    }

    protected InbredHybridEnum(int code) {
        this.code = code;
    }

    public InbredHybridEnum(String lineTypeRef) {
        if (LineTypeRef.HYBRID.equals(lineTypeRef)) {
            code = HYBRID;
        } else if (LineTypeRef.CODED.equals(lineTypeRef) || LineTypeRef.FINISHED.equals(lineTypeRef)) {
            code = INBRED;
        } else {
            code = UNKNOWN;
        }
    }

    public boolean isConsistant(String lineTypeRef) {
        return isConsistant(new InbredHybridEnum(lineTypeRef));
    }

    public boolean isConsistant(InbredHybridEnum inbredHybridType) {
        if (code == HYBRID) {
            return (inbredHybridType.code != INBRED);
        } else if (code == INBRED) {
            return (inbredHybridType.code != HYBRID);
        } else {
            return true;
        }
    }

    public boolean isUnknown() {
        return code == UNKNOWN;
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        } else if (getClass().isAssignableFrom(other.getClass())) {
            InbredHybridEnum type = (InbredHybridEnum) other;
            if (type == null) {
                return false;
            }
            return ((code == type.code) && !(code == UNKNOWN && type.code == UNKNOWN));
        } else {
            return false;
        }
    }
}
