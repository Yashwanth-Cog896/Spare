package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;

public class RequestedTraitVersUniqueForExistingManfRule
        extends SimpleValidationRule {
    private final ProductRelationshipObject productRelationship;
    private final String traitVersion;

    public RequestedTraitVersUniqueForExistingManfRule(
            ProductRelationshipObject productRelationship, String traitVersion) {
        this.productRelationship = productRelationship;
        this.traitVersion = traitVersion;
    }

    protected boolean preConditionsMet() {
        return (productRelationship != null);
    }

    protected boolean criteriaViolated() {
        return productRelationship.getRelationshipProductByTraitVersion(traitVersion) != null;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TRAIT_VERS_EXISTS_CODE);
    }

    protected ProductRelationshipObject getProductRelationship() {
        return productRelationship;
    }

    protected String getTraitVersion() {
        return traitVersion;
    }
}