package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 12:01 PM
 */
public class APCNDefaultStageAttributesRichRequest {

    private TPSBrand preComlBrand;
    private List<TPSCountry> requestedCountries;
    private TPSTrait requestedTraitStack;
    private LexiconStageEntity requestedStageType;
    private String requestedMaturity;
    private List<MutableSyncProductName> syncProductNames;
    private List<APCNIndividualStageAttributesByCriteria> individualStagesAttributes;

    public void setPreComlBrand(TPSBrand preComlBrand) {
        this.preComlBrand = preComlBrand;
    }

    public void setRequestedCountries(List<TPSCountry> requestedCountries) {
        this.requestedCountries = requestedCountries;
    }

    public void setRequestedTraitStack(TPSTrait requestedTraitStack) {
        this.requestedTraitStack = requestedTraitStack;
    }

    public void setRequestedStageType(LexiconStageEntity requestedStageType) {
        this.requestedStageType = requestedStageType;
    }

    public void setRequestedMaturity(String requestedMaturity) {
        this.requestedMaturity = requestedMaturity;
    }

    public TPSBrand getPreComlBrand() {
        return preComlBrand;
    }

    public List<TPSCountry> getRequestedCountries() {
        return requestedCountries;
    }

    public TPSTrait getRequestedTraitStack() {
        return requestedTraitStack;
    }

    public LexiconStageEntity getRequestedStageType() {
        return requestedStageType;
    }

    public String getRequestedMaturity() {
        return requestedMaturity;
    }

    public void setSyncProductNames(List<MutableSyncProductName> syncProductNames) {
        this.syncProductNames = syncProductNames;
    }

    public void setIndividualStagesAttributes(List<APCNIndividualStageAttributesByCriteria> individualStagesAttributes) {
        this.individualStagesAttributes = individualStagesAttributes;
    }

    public List<MutableSyncProductName> getSyncProductNames() {
        return syncProductNames;
    }

    public List<APCNIndividualStageAttributesByCriteria> getIndividualStagesAttributes() {
        return individualStagesAttributes;
    }
}
