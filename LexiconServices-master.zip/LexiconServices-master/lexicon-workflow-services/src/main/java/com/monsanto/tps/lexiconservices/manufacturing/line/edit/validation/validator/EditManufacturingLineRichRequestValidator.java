package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.validator;

import com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain.EditManufacturingLineRichRequest;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:08 PM
 */
public interface EditManufacturingLineRichRequestValidator {

    public List<String> validate(EditManufacturingLineRichRequest richRequest);
}
