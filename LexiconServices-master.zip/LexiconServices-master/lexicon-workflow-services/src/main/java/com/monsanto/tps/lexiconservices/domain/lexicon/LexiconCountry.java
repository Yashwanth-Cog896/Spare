package com.monsanto.tps.lexiconservices.domain.lexicon;

public interface LexiconCountry
        extends GeographicEntity {
    long getLexiconID();

    String getPublicKey();

    String getName();

    String getUNCodeStr();

    String getISOCode();

    int getUNCode();

    String getSubCountryDescription();

    String getSubSubCountryDescription();
}
