package com.monsanto.tps.lexiconservices.manufacturing.line.edit.service.impl;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.lexiconservices.lexicon.audit.LexiconAuditorService;
import com.monsanto.tps.lexiconservices.lexicon.audit.domain.AuditStaging;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain.EditManufacturingLineRichRequest;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions.EditManufacturingLineException;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductDao;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Component(value = "editManufacturingLineWriter")
public class EditManufacturingLineWriter {

    private Logger logger = Logger.getLogger(EditManufacturingLineWriter.class);

    @Resource
    ProductRelationshipDao productRelationshipDao;

    @Resource
    BaseProductDao baseProductDao;


    @Resource
    MidasProductDao midasProductDao;

    @Resource
    LexiconProductDao lexiconProductDao;

    @Resource
    private AuditStagingDao auditStagingDao;

    @Resource
    private UserProfile userProfile;

    @Resource
    private LexiconAuditorService lexiconAuditorService;

    public void writeIfValid(List<String> messages, EditManufacturingLineRichRequest richRequest) throws EditManufacturingLineException {
        if (messages.isEmpty()) {
            write(richRequest);
        }
    }

    private void write(EditManufacturingLineRichRequest richRequest) throws EditManufacturingLineException {
        logger.info("Processing EditManufacturingLineWriter request");
        AuditStaging auditStagingData = null;
        try {
            auditStagingData = getAuditStagingData();
            lexiconAuditorService.saveAuditStagingData(auditStagingData);
            updateManufacturingName(richRequest.getNewManufacturingName(), richRequest.getTargetManufacturingName());
            if (!richRequest.getRequestedManufacturingLine().getBlendProduct()) {
                updateVarietyName(richRequest.getRequestedManufacturingLinesProducts(), richRequest.getNewManufacturingName(), richRequest.getNewVarietyName());
            }
        } finally {
            lexiconAuditorService.deleteAuditStagingData(auditStagingData.getOracleSID());
        }
    }

    private void updateManufacturingName(String newManufacturingName, String oldManufacturingName) {
        productRelationshipDao.updateManufacturingName(newManufacturingName, oldManufacturingName);
    }

    private void updateVarietyName(List<ProductRelationshipEntity> relationshipProducts, String newManufacturingName, String varietyName) {
        updateRelationshipVarietyName(varietyName, newManufacturingName);
        updateRelationshipProductsVarietyNames(newManufacturingName, varietyName);
        updateDenominationByPublicKey(varietyName, relationshipProducts);
    }

    private void updateRelationshipVarietyName(String varietyName, String newManufacturingName) {
        productRelationshipDao.updateRelationshipVarietyName(varietyName, newManufacturingName);
    }

    private void updateRelationshipProductsVarietyNames(String newManufacturingName, String varietyName) {
        lexiconProductDao.updateRelationshipProductsVarietyNames(newManufacturingName, varietyName);
    }

    private void updateDenominationByPublicKey(String varietyName, List<ProductRelationshipEntity> relationshipProducts) {
        for (ProductRelationshipEntity relationshipProduct : relationshipProducts) {
            midasProductDao.updateDenominationByPublicKey(varietyName, relationshipProduct.getProductRelationshipPubkey());
        }
    }

    private AuditStaging getAuditStagingData() {
        AuditStaging auditStaging = new AuditStaging();
        auditStaging.setAuditComment("");
        auditStaging.setAuditRequestor("");
        auditStaging.setUserLoginID(userProfile.getUserName());
        auditStaging.setProcessName("EditManufacturingLine");
        auditStaging.setCreationTimestamp(new Date());
        auditStaging.setMachine(auditStagingDao.getSessionMachine());
        auditStaging.setOracleSID(auditStagingDao.getSessionId().longValue());
        auditStaging.setOsUser(auditStagingDao.getSessionOsUser());
        return auditStaging;
    }
}