package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.ProductGermplasmEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductGermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.GermplasmDTO;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 1:53 PM
 */
@Component(value = "syncProductMirageSourceGermplasmWriter")
public class SyncProductMirageSourceGermplasmWriter {
    @Resource
    private GermplasmDao germplasmDao;

    @Resource
    private MidasProductGermplasmDao midasProductGermplasmDao;

    public MidasProductGermplasmDTO write(MidasProductEntity existingProduct, String preComlName, TPSCrop crop, ProductGermplasmCollection productGermplasm) {
        MidasProductGermplasmDTO germplasm = productGermplasm.getFinishedGermplasm();
        if (germplasm == null && productGermplasm.numGermplasm() > 0) {
            germplasm = createDummyGermplasm(preComlName, crop, productGermplasm);
            addDummyToProductGermplasm(existingProduct, productGermplasm, germplasm);
        }
        return germplasm;
    }

    private void addDummyToProductGermplasm(MidasProductEntity existingProduct, ProductGermplasmCollection productGermplasm, MidasProductGermplasmDTO germplasm) {
        addGermplasmToCollection(productGermplasm, germplasm);
        ProductGermplasmEntity productGermplasmEntity = new ProductGermplasmEntity();
        productGermplasmEntity.setMidasProduct(existingProduct);
        productGermplasmEntity.setPreferred(false); //TODO:Should this default to false or true?
        productGermplasmEntity.setGermplasm(germplasmDao.get(germplasm.getGermplasmId()));
        midasProductGermplasmDao.save(productGermplasmEntity);
    }

    private void addGermplasmToCollection(ProductGermplasmCollection productGermplasm, MidasProductGermplasmDTO germplasm) {
        productGermplasm.addGermplasm(germplasm);
    }


    private MidasProductGermplasmDTO createDummyGermplasm(String preComlName, TPSCrop crop, ProductGermplasmCollection productGermplasm) {
        long germplasmID = germplasmDao.getNextMidasId();
        GermplasmDTO germplasmDto = new GermplasmDTO(germplasmID, preComlName, crop, productGermplasm);
        MidasProductGermplasmDTO germplasm = germplasmDao.insertGermplasm(germplasmDto);
        germplasm.setInbredHybridType(productGermplasm.getInbredHybridType());
        germplasm.setProductName(preComlName);
        return germplasm;
    }
}
