package com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:27 PM
 */
public class ManufacturingLine {

    private String manufacturingName;

    public ManufacturingLine(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }
}
