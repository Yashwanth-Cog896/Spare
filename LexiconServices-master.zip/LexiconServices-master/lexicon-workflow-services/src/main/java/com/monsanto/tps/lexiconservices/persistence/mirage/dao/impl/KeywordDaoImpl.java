package com.monsanto.tps.lexiconservices.persistence.mirage.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.KeywordEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.KeywordDao;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 9:27 AM
 */
public class KeywordDaoImpl extends GenericDaoImpl<KeywordEntity,Long> implements KeywordDao {
    public static final String TRAIT_CHARACTERISTIC = "TRAIT CHARACTERISTIC";

    public KeywordDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public List<KeywordEntity> getActiveTraitCharacteristics() {
        return getSessionFactory().getCurrentSession().createCriteria(KeywordEntity.class, "keyword")
                .add(Restrictions.eq("keyword.type",TRAIT_CHARACTERISTIC)).add(Restrictions.eq("keyword.enabled",true))
                .list();
    }
}
