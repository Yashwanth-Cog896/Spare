package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.mirage.domain.KeywordEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.KeywordDao;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 9:21 AM
 */
@Component(value = "mirageTraitCharacteristicsLookup")
public class MirageTraitCharacteristicsLookup implements ApplicationContextAware {

    public static final String NON_TRANS_STRING = "NON-TRANSGENIC";

    private static MirageTraitCharacteristicsLookup instance;

    private Map traitCharacteristics;
    private Map traitsByCode;

    private static ApplicationContext context;

    @Resource
    private KeywordDao keywordDao;

    public static void resetInstance() {
        setInstance(null);
    }

    protected static void setInstance(MirageTraitCharacteristicsLookup lookup) {
        instance = lookup;
    }

    public static MirageTraitCharacteristicsLookup getInstance() {
        if (instance == null) {
            MirageTraitCharacteristicsLookup lookup = (MirageTraitCharacteristicsLookup) context.getBean("mirageTraitCharacteristicsLookup");
            setInstance(lookup);
        }
        return instance;
    }

    public KeywordEntity getTraitCharacteristics(String name) {
        initializeMaps();
        String lookupName = (null == name || name.trim().length() == 0) ? NON_TRANS_STRING : name;
        return (KeywordEntity) traitCharacteristics.get(lookupName);
    }

    protected void initializeMaps() {
        if (traitCharacteristics == null) {
            traitCharacteristics = new HashMap<String, KeywordEntity>();
            traitsByCode = new HashMap<Long, KeywordEntity>();
            List<KeywordEntity> characteristics = keywordDao.getActiveTraitCharacteristics();
            for (KeywordEntity characteristic : characteristics) {
                traitCharacteristics.put(characteristic.getName(), characteristic);
                traitsByCode.put(characteristic.getCode(), characteristic);
            }
        }
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    static void setApplicationContextForUT(ApplicationContext applicationContext) {
        context = applicationContext;
    }
}
