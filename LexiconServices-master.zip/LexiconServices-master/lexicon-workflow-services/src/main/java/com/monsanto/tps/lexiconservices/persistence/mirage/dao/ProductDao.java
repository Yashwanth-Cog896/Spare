package com.monsanto.tps.lexiconservices.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageAuditEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/8/14
 * Time: 10:14 AM
 */
public interface ProductDao extends GenericDao<MirageSeedProductEntity, Long> {
    ProductDTO findMirageProductById(long seedProductId);

    ProductDTO getMirageProductByCriteria(String productName, String mirageBayerCode, long mirageCompanyID, String mirageCountryCode);

    MirageSeedProductEntity save(MirageSeedProductEntity seedProduct);

    int reuseMirageSeedProduct(long traitCharacteristicCode, boolean enabled, long auditId, long productId);

    void disableMirageSeedProduct(MirageAuditEntity audit, long productId);

    int updateMirageSeedProduct(long companyId, String productName, String cropBayerCode, String countryCode,
                                long traitCharacteristicCode, boolean enabled, long auditId, long productId);

    int updateMirageSeedProductPrecommercialName(String newPrecommercialName ,String oldPrecommercialName ,String mirageBayerCode, long auditId);



}
