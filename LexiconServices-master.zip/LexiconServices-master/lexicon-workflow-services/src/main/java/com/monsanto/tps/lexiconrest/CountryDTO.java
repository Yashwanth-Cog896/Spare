package com.monsanto.tps.lexiconrest;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CountryDTO {

    private String countryPubkey;
    private String countryName;

    public CountryDTO(String countryPubkey, String countryName) {
        this.countryPubkey = countryPubkey;
        this.countryName = countryName;
    }

    public String getCountryPubkey() {
        return countryPubkey;
    }

    public String getCountryName() {
        return countryName;
    }
}