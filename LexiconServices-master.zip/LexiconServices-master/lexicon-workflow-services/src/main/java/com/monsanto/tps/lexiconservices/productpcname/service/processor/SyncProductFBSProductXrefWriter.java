package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonProductXrefDao;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 10:33 AM
 */
@Component(value = "syncProductFBSProductXrefWriter")
public class SyncProductFBSProductXrefWriter {

    @Resource
    private FbsCommonProductXrefDao fbsCommonProductXrefDao;


    public FbsCommonProductXrefEntity write(FbsCommonProductXrefEntity existingProductXref, LexiconProductEntity lexProduct, MidasProductEntity midasProduct) {
        FbsCommonProductXrefEntity returnedProductXref = new FbsCommonProductXrefEntity();
        returnedProductXref.setLexiconPubkey(lexProduct.getPubkey());
        returnedProductXref.setMidasProduct(midasProduct);
        if (existingProductXref == null) {
            returnedProductXref = fbsCommonProductXrefDao.save(returnedProductXref);
        } else if (existingDiffers(existingProductXref, midasProduct)) {
            fbsCommonProductXrefDao.update(midasProduct.getId(), lexProduct.getPubkey());
            returnedProductXref = fbsCommonProductXrefDao.get(lexProduct.getPubkey());
        }
        return returnedProductXref;
    }

    private boolean existingDiffers(FbsCommonProductXrefEntity existingProductXref, MidasProductEntity midasProduct) {
        return existingProductXref.getMidasProduct().getId() != midasProduct.getId();
    }
}
