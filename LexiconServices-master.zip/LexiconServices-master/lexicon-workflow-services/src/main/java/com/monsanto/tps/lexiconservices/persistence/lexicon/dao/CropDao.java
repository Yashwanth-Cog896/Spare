package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.crop.domain.CropPublicKeyTypeEnum;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductClassificationEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper.SegregateCrop;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/18/13
 * Time: 2:42 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CropDao extends GenericDao<LexiconCropEntity, Long> {

    List<SegregateCrop> findByPublicKeysAndScientificName(List<String> publicKeys, String scientificName, CropPublicKeyTypeEnum publicKey);

    boolean isVegetableCrop(String cropName);

    ProductClassificationEntity getCropByProductClassification(String productClassificationCode);

    LexiconCropEntity getCropByCropName(String cropName);

    boolean isVegetableCropByProductPubkey(String pubkey);
}
