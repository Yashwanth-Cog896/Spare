package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.ExistingLexLDProdHasNoNonLDStagesRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.LinkedAndMatchingMidasProdCantExistRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.MatchingActiveMidasPNHaveCommonProdRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.ExistingLexProdHasProdXrefRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.ExistingLexProdNotDeletedRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.LinkedMidasProdNotInactiveRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.ProdXrefFoundMidasProdFoundRule;


public class APCNExistingSyncProductRules
        extends RulesValidatorCollection {
    private final APCNExistingSyncProductValidationModel model;

    public APCNExistingSyncProductRules(APCNExistingSyncProductValidationModel model) {
        this.model = model;
    }

    protected RulesValidator[] getRulesValidators() {
        return new RuleSeverityPair[]{
                new RuleSeverityPair(new ExistingLexLDProdHasNoNonLDStagesRule(model.getLexProduct(), model.getLexProductNames()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingLexProdNotDeletedRule(model.getLexProduct()), ValidationConditionSeverity.INFO),
                new RuleSeverityPair(new ExistingLexProdHasProdXrefRule(model.getLexProduct(), model.getProductXref()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ProdXrefFoundMidasProdFoundRule(model.getProductXref(), model.getLinkedMidasProduct()), ValidationConditionSeverity.INFO),
                new RuleSeverityPair(new LinkedMidasProdNotInactiveRule(model.getLinkedMidasProduct()), ValidationConditionSeverity.INFO),
                new RuleSeverityPair(new LinkedAndMatchingMidasProdCantExistRule(model.getLinkedMidasProduct(), model.getMatchingMidasPN()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new MatchingActiveMidasPNHaveCommonProdRule(model.getMatchingMidasPN()), ValidationConditionSeverity.ERROR),
        };
    }
}
