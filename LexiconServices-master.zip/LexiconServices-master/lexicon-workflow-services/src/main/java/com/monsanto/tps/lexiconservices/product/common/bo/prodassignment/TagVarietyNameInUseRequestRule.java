package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.richrequest.TagVarietyNameRequest;

public class TagVarietyNameInUseRequestRule
        extends SimpleValidationRule {

    private final TagVarietyNameRequest model;

    public TagVarietyNameInUseRequestRule(TagVarietyNameRequest model) {

        this.model = model;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return model.isTagVarietyNameInUse();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TAG_VARIETY_NAME_IN_USE_CODE);
    }
}
