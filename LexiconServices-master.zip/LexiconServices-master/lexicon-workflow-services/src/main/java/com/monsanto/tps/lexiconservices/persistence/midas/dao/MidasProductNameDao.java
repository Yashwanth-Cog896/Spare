package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.ProductNameDTO;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/6/14
 * Time: 10:20 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasProductNameDao extends GenericDao<MidasProductNameEntity, Long> {

  List<MidasProductNameEntity> findMatchingMidasNamesByProductName(String pcName);

  List<MidasProductNameEntity> findGlobalPCNamesByProductID(Long productId);

  MidasProductNameEntity getMidasNameByCriteria(long midasProductID, String brandName, long countryID);

  int insertMidasProductName(ProductNameDTO productNameDTO);

  void reuseMidasProductName(String name, long id);

  int deleteMidasProductName(Long midasProductNameID);

    int updateMidasProductName(long productNameId, String productName, String brandName,
                               long countryId, boolean preferredName, boolean refActive);
}
