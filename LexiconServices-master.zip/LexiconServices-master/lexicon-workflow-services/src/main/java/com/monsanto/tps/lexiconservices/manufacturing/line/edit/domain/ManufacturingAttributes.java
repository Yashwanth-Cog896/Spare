package com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:38 PM
 */
public class ManufacturingAttributes {

    private String manufacturingName;

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }
}
