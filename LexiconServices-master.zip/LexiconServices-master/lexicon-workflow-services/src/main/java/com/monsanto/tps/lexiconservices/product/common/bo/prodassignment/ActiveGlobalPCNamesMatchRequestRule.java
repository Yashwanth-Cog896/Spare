package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 19, 2006
 * Time: 4:31:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActiveGlobalPCNamesMatchRequestRule
        extends SimpleValidationRule {
    private final String preComlName;
    private final MidasProductNamesCollection globalPCNameRecords;

    public ActiveGlobalPCNamesMatchRequestRule(String preComlName, MidasProductNamesCollection globalPCNameRecords) {
        this.preComlName = preComlName;
        this.globalPCNameRecords = globalPCNameRecords;
    }

    protected boolean preConditionsMet() {
        return globalPCNameRecords.getFirstActiveRecord() != null;
    }

    protected boolean criteriaViolated() {
        return !globalPCNameRecords.nameValueMatches(preComlName);
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.GLOBAL_PC_NAME_MISMATCH_CODE);
    }
}
