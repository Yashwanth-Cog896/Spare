package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.common.rule.ConditionalRule;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:55 PM
 */
public class ParentBaseProductHasNoVarietyNameRule extends ConditionalRule {
    private final BaseProductEntity baseProduct;
    private final String varietyName;

    public ParentBaseProductHasNoVarietyNameRule(BaseProductEntity baseProduct, String varietyName) {
        this.baseProduct = baseProduct;
        this.varietyName = varietyName;
    }

    protected boolean preconditionsMet() {
        return baseProduct != null  && baseProduct.getParentProduct();
    }

    protected boolean criteriaViolated() {
        return !StringUtils.isNullOrEmpty(varietyName);
    }

    public String getViolation() {
        return "May not assign a variety name to a parent manufacturing name.";
    }
}
