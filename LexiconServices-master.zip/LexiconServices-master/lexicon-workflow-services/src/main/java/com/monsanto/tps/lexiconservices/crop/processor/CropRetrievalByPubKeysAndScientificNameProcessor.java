package com.monsanto.tps.lexiconservices.crop.processor;

import com.monsanto.tps.lexiconservices.crop.domain.Crop;
import com.monsanto.tps.lexiconservices.crop.domain.CropRetrievalByPubKeysAndScientificNameRequest;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CropDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper.SegregateCrop;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 12/20/13
 * Time: 2:11 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "cropRetrievalByPubKeysAndScientificNameProcessor")
public class CropRetrievalByPubKeysAndScientificNameProcessor {

  private Logger logger = Logger.getLogger(CropRetrievalByPubKeysAndScientificNameProcessor.class);

  @Resource
  private CropDao cropDao;

  public List<Crop> findByPublicKeysAndScientificName(CropRetrievalByPubKeysAndScientificNameRequest cropRetrievalByPubKeysAndScientificNameRequest) {
    logger.info("In CropRetrievalByPubKeysAndScientificNameProcessor");
    List<SegregateCrop> segregateCropList = cropDao.findByPublicKeysAndScientificName(cropRetrievalByPubKeysAndScientificNameRequest.getPublickeys(),
      cropRetrievalByPubKeysAndScientificNameRequest.getScientificName(), cropRetrievalByPubKeysAndScientificNameRequest.getPublicKeyTypeEnum());
    logger.info("Performing Desegregator for the segregate crops");
    return new CropDesegregator(segregateCropList).desegregate();
  }

}
