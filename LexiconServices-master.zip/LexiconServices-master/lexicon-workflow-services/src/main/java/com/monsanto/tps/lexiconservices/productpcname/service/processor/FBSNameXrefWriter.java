package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/11/14
 * Time: 2:13 PM
 */
@Component(value = "fBSNameXrefWriter")
public class FBSNameXrefWriter {
    @Resource
    private FbsCommonProductNameXrefDao nameXrefDao;

    @Resource
    private ProductDao productDao;

    public FbsCommonProductNameXrefEntity write(LexiconProductStageEntity lexStage, MidasProductNameEntity midasProductName, ProductDTO mirageProduct) {
        FbsCommonProductNameXrefEntity newNameXref = createNewNameXrefObject(lexStage, midasProductName, mirageProduct);
        return nameXrefDao.merge(newNameXref);
    }

    private FbsCommonProductNameXrefEntity createNewNameXrefObject(LexiconProductStageEntity lexStage, MidasProductNameEntity midasProductName, ProductDTO mirageProduct) {
        FbsCommonProductNameXrefEntity entity = new FbsCommonProductNameXrefEntity();
        entity.setLexiconPubkey(lexStage.getPubkey());
        entity.setMidasProductName(midasProductName);
        if (null != mirageProduct) {
            entity.setMirageSeedProduct(productDao.get(mirageProduct.getProductID()));
        }
        return entity;
    }
}
