package com.monsanto.tps.lexiconrest;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class BrandDTO {

    private String brandPubkey;
    private String brandName;

    public BrandDTO(String brandPubkey, String brandName) {
        this.brandPubkey = brandPubkey;
        this.brandName = brandName;
    }

    public String getBrandPubkey() {
        return brandPubkey;
    }

    public String getBrandName() {
        return brandName;
    }
}