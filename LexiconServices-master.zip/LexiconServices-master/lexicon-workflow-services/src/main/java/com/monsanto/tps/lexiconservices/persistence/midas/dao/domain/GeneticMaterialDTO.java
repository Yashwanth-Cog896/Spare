package com.monsanto.tps.lexiconservices.persistence.midas.dao.domain;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class GeneticMaterialDTO {
  private long geneticMaterialID;
  private long germplasmID;
  private String source;
  private String generation;
  private String lineage;

  public GeneticMaterialDTO(long geneticMaterialID, long germplasmID, String source, String generation, String lineage) {
    this.geneticMaterialID = geneticMaterialID;
    this.germplasmID = germplasmID;
    this.source = source;
    this.generation = generation;
    this.lineage = lineage;
  }

  public long getGeneticMaterialID() {
    return geneticMaterialID;
  }

  public long getGermplasmID() {
    return germplasmID;
  }

  public String getSource() {
    return source;
  }

  public String getGeneration() {
    return generation;
  }

  public String getLineage() {
    return lineage;
  }
}