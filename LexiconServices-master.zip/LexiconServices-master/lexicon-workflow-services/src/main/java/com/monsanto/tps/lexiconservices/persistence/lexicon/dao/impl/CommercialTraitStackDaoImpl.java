package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.CommercialTraitStackDTO;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/8/14
 * Time: 3:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommercialTraitStackDaoImpl extends GenericDaoImpl<CommercialTraitStackEntity, Long> implements CommercialTraitStackDao {

    private static final String FIND_TRAIT_STACK_BY_PUBKEY_AND_COUNTRY = "CommercialTraitStackDao.getTraitStackByPubkeyAndCountry";

    public CommercialTraitStackDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public CommercialTraitStackDTO getTraitStackByPubkeyAndCountry(String triatStackPubKey, String countryPubKey) {
        Query query = getSessionFactory().getCurrentSession().getNamedQuery(FIND_TRAIT_STACK_BY_PUBKEY_AND_COUNTRY);
        query.setResultTransformer(Transformers.aliasToBean(CommercialTraitStackDTO.class));
        query.setParameter("triatStackPubKey", triatStackPubKey);
        query.setParameter("countryPubKey", countryPubKey);
        return (CommercialTraitStackDTO) query.uniqueResult();
    }

    @Override
    public CommercialTraitStackEntity getTraitStackByPubkey(String traitStackPubKey) {
        return (CommercialTraitStackEntity) getSessionFactory().getCurrentSession().createCriteria(CommercialTraitStackEntity.class, "commercialTraitStack").
                createAlias("commercialTraitStack.lexiconCrop", "crop").
                add(Restrictions.eq("commercialTraitStack.pubkey", traitStackPubKey)).uniqueResult();
    }
}
