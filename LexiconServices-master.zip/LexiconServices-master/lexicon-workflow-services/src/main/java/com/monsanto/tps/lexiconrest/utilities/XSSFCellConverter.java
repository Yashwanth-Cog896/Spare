/*
$Log$
*/
package com.monsanto.tps.lexiconrest.utilities;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.IOException;

/**
 */
public class XSSFCellConverter {
    protected String getConvertedValue(Row rowValue, int index) throws IOException {
        CellConverter cellConverter = new CellConverter();
        Cell cell1 = rowValue.getCell(index);
        if(cell1 != null)
            return cellConverter.convert(cell1);
        else
            return null;
    }

    protected int getNumericValue(Row rowValue, final int index) throws IOException {
        String countStr = getConvertedValue(rowValue, index);
        return Integer.parseInt(countStr);
    }
}
