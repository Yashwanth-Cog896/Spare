package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;


public class CommercialProductsMayNotHavePrecommercialTraitsRule
        extends SimpleValidationRule {
    private final boolean commercialProduct;
    private final TPSTrait traitStack;

    public CommercialProductsMayNotHavePrecommercialTraitsRule(boolean commercialProduct, TPSTrait traitStack) {
        this.commercialProduct = commercialProduct;
        this.traitStack = traitStack;
    }

    protected boolean preConditionsMet() {
        return traitStack != null;
    }


    protected boolean criteriaViolated() {
        return commercialProduct && traitStack.getLexStack().isPreCommercial();
    }


    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.COML_PROD_WITH_PRECOML_TRAIT);
    }
}
