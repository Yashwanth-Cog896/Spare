package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class ExistingManfLineMustNotBeLogicallyDeletedRule
        extends SimpleValidationRule {
    private final ProductRelationshipEntity manfLine;

    public ExistingManfLineMustNotBeLogicallyDeletedRule(ProductRelationshipEntity manfLine) {
        this.manfLine = manfLine;
    }

    protected boolean preConditionsMet() {
        return manfLine != null;
    }

    protected boolean criteriaViolated() {
        return manfLine.getLogicalDelete();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.MANF_LINE_IS_LOGICALLY_DELETED);
    }
}