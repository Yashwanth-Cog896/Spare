package com.monsanto.tps.lexiconrest.service.dto;

import com.monsanto.tcc.lexiconcommon.productsync.EditProductStageResponse;

import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ProductStageServiceBatchResponse {
    private List<EditProductStatusResponse> editProductStageResponseList;
    private List<AddProductStatusResponse> addProductStageResponseList;

    public List<EditProductStatusResponse> getEditProductStageResponseList() {
        return editProductStageResponseList;
    }

    public void setEditProductStageResponseList(List<EditProductStatusResponse> editProductStageResponseList) {
        this.editProductStageResponseList = editProductStageResponseList;
    }

    public List<AddProductStatusResponse> getAddProductStageResponseList() {
        return addProductStageResponseList;
    }

    public void setAddProductStageResponseList(List<AddProductStatusResponse> addProductStageResponseList) {
        this.addProductStageResponseList = addProductStageResponseList;
    }
}