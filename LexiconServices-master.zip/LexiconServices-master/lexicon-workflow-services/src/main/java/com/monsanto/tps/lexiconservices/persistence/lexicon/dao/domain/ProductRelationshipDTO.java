package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ProductRelationshipDTO {
    private String TRUE = "true";
    private String FALSE = "false";
    private String traitVersion;
    private String productionStatus;
    private String productPubkey;
    private Long cropID;
    private String cropPubKey;
    private String cropName;
    private String cropAbbreviation;
    private String productDeleted;
    private String preComlName;
    private String tagVarietyName;
    private String supplyChainOwner;
    private String productClassificationCode;
    private String regulatoryCrop;
    private String parentProductFlag;
    private String manfName;
    private String ownerRegion;
    private Long productId;

    public ProductRelationshipDTO(LexiconProductEntity lexProduct, String traitVersion) {
        this.traitVersion = traitVersion;
        productClassificationCode = (lexProduct.getProductClassification() != null) ? lexProduct.getProductClassification().getProductClassificationCode() : null;
        tagVarietyName = lexProduct.getTagVarietyName();
        parentProductFlag = lexProduct.isParentProduct() ? "Y" : "N";
        supplyChainOwner = (lexProduct.getSupplyChainOwnerGroup() != null) ? lexProduct.getSupplyChainOwnerGroup().getCode() : null;
        ownerRegion = (lexProduct.getOwningMarketingRegion() != null) ? lexProduct.getOwningMarketingRegion().getName() : null;
        productPubkey = lexProduct.getPubkey();
        cropPubKey = lexProduct.getLexiconCrop().getPubkey();
        cropName = lexProduct.getLexiconCrop().getName();
        preComlName = lexProduct.getPreCommercialName();
        cropAbbreviation = lexProduct.getLexiconCrop().getAbbreviation();
        productDeleted = lexProduct.isLogicalDelete() ? "Y" : "N";
        productId = lexProduct.getId();

    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public void setProductionStatus(String productionStatus) {
        this.productionStatus = productionStatus;
    }

    public String getParentProductFlag() {
        return ("Y".equalsIgnoreCase(parentProductFlag)) ? TRUE : FALSE;
    }

    public void setParentProductFlag(String parentProductFlag) {
        this.parentProductFlag = parentProductFlag;
    }

    public ProductRelationshipDTO() {
    }

    public ProductRelationshipDTO(String productPubkey, String traitVersion, String productionStatus, String manfName) {
        this.productPubkey = productPubkey;
        this.traitVersion = traitVersion;
        this.productionStatus = productionStatus;
        this.manfName = manfName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public String getTraitVersion() {
        return StringUtils.toUpperCaseNull(traitVersion);
    }

    public String getProductionStatus() {
        return productionStatus;
    }

    public String getManfName() {
        return StringUtils.toUpperCaseNull(manfName);
    }

    public Long getCropID() {
        return cropID;
    }

    public void setCropID(Long cropID) {
        this.cropID = cropID;
    }

    public String getCropPubKey() {
        return cropPubKey;
    }

    public void setCropPubKey(String cropPubKey) {
        this.cropPubKey = cropPubKey;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getCropAbbreviation() {
        return cropAbbreviation;
    }

    public void setCropAbbreviation(String cropAbbreviation) {
        this.cropAbbreviation = cropAbbreviation;
    }

    public String getProductDeleted() {
        return ("Y".equalsIgnoreCase(productDeleted)) ? TRUE : FALSE;
    }

    public void setProductDeleted(String productDeleted) {
        this.productDeleted = productDeleted;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public String getTagVarietyName() {
        return tagVarietyName;
    }

    public void setTagVarietyName(String tagVarietyName) {
        this.tagVarietyName = tagVarietyName;
    }

    public String getSupplyChainOwner() {
        return supplyChainOwner;
    }

    public void setSupplyChainOwner(String supplyChainOwner) {
        this.supplyChainOwner = supplyChainOwner;
    }

    public String getProductClassificationCode() {
        return productClassificationCode;
    }

    public void setProductClassificationCode(String productClassificationCode) {
        this.productClassificationCode = productClassificationCode;
    }

    public String getRegulatoryCrop() {
        return ("Y".equalsIgnoreCase(regulatoryCrop)) ? TRUE : FALSE;
    }

    public void setRegulatoryCrop(String regulatoryCrop) {
        this.regulatoryCrop = regulatoryCrop;
    }

    public void setManfName(String manfName) {
        this.manfName = manfName;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getProductId() {
        return this.productId;
    }
}