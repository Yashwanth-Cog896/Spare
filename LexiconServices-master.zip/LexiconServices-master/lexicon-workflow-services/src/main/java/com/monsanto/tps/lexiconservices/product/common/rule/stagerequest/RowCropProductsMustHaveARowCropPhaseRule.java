package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class RowCropProductsMustHaveARowCropPhaseRule
        extends SimpleValidationRule {
    private final boolean vegetableProduct;
    private final LexiconStageEntity stage;

    public RowCropProductsMustHaveARowCropPhaseRule(boolean vegetableProduct, LexiconStageEntity stage) {
        this.vegetableProduct = vegetableProduct;
        this.stage = stage;
    }

    @Override
    protected boolean preConditionsMet() {
        return stage != null && !vegetableProduct;
    }

    @Override
    protected boolean criteriaViolated() {
        return !stage.getStageCategories().iterator().next().getName().equals("Non-Vegetable");
    }

    @Override
    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ROW_CROP_PRODUCT_WITH_VEGETABLE_PHASE_CODE);
    }
}
