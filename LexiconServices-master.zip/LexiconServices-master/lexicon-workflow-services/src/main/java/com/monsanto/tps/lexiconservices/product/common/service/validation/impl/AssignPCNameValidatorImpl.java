package com.monsanto.tps.lexiconservices.product.common.service.validation.impl;

import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tps.lexiconservices.productpcname.validation.AssignPCNameValidationModel;
import com.monsanto.tps.lexiconservices.productpcname.validation.rule.*;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 2/6/14
 * Time: 10:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPCNameValidatorImpl extends RulesValidatorCollection {

    private final AssignPCNameValidationModel model;

    public AssignPCNameValidatorImpl(AssignPCNameValidationModel model) {
        this.model = model;
    }

    @Override
    protected RulesValidator[] getRulesValidators() {
        return new RulesValidator[]{
                new APCNExistingSyncProductRules(model),
                new APCNProductAssignmentRules(model),
                new APCNRelationshipAssignmentRules(model),
                new APCNAssigningGermplasmRules(model.getAssigningGermplasm(), model.getInbredHybridType(), model.isContainsPreferredPedegree()),
                new APCNDefaultStageValidationRules(model),

        };
    }
}
