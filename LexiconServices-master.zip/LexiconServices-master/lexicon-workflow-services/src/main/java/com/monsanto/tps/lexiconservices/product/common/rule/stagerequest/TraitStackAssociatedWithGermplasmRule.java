package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;

import java.util.List;

public class TraitStackAssociatedWithGermplasmRule extends SimpleValidationRule {

    private List<Long> traitStackIdsForGermplasm;
    private TPSTrait tpsTrait;

    public TraitStackAssociatedWithGermplasmRule(TPSTrait tpsTrait, List<Long> traitStackIdsForGermplasm) {
        this.tpsTrait = tpsTrait;
        this.traitStackIdsForGermplasm = traitStackIdsForGermplasm;
    }

    @Override
    protected boolean criteriaViolated() {
        return tpsTrait != null ? !traitStackIdsForGermplasm.contains(tpsTrait.getLexStack().getId()) : false;
    }

    @Override
    protected boolean preConditionsMet() {
        return true;
    }

    @Override
    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TRAIT_STACK_NOT_ASSOCIATED_WITH_GERMPLASM_CODE);
    }
}
