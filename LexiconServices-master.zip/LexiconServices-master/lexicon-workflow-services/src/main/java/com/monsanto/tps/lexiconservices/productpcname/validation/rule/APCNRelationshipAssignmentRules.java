package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.PCNameValueValidRule;
import com.monsanto.tps.lexiconservices.product.common.bo.relassignment.*;

public class APCNRelationshipAssignmentRules
        extends RulesValidatorCollection {
    private final APCNRelationshipAssignmentValidationModel model;

    public APCNRelationshipAssignmentRules(APCNRelationshipAssignmentValidationModel model) {
        this.model = model;
    }

    protected RulesValidator[] getRulesValidators() {
        return new RuleSeverityPair[]{
                new RuleSeverityPair(new PCNameValueValidRule(model.getRequestedPCName()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ManfNameValidRule(model.getRequestedManfName()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TraitVersNameValidRule(model.getRequestedTraitVersion()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TraitVerGivenManfNameGivenRule(model.getRequestedTraitVersion(), model.getRequestedManfName()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingProdRelProdFoundTraitVerGivenRule(model.getExistingManfNameRelationship(), model.getRequestedTraitVersion(), model.getLexProduct()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new RequestedTraitVersUniqueForExistingManfAndNewLexProdRule(model.getExistingManfNameRelationship(), model.getRequestedTraitVersion(), model.getLexProduct()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistLexProdSameManfNameAsRequestRule(model.getLexProduct(), model.getProductRelationship(), model.getRequestedManfName()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistLexProdSameTraitVerAsRequestRule(model.getLexProduct(), model.getProductRelationship(), model.getRequestedTraitVersion()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new RequestedManufacturingNameExistsRule(model.getRequestedManfName(), model.getExistingManfNameRelationship()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingBaseProdSameParentFlagAsRequestRule(model.getExistingManfNameBaseProduct(), model.getRequestedParentProductFlag()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingBaseProdSameCropAsRequestRule(model.getRequestedCrop(), model.getExistingManfNameBaseProduct()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingManfLineMustNotBeLogicallyDeletedRule(model.getExistingManfNameManfLine()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new BaseProductExistsRule(model.getExistingManfNameBaseProduct(), model.getRequestedManfName()), ValidationConditionSeverity.ERROR),
        };
    }
}
