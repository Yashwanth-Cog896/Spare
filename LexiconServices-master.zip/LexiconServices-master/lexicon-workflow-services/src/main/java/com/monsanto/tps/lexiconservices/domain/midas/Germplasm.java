package com.monsanto.tps.lexiconservices.domain.midas;

public interface Germplasm {
    long getMidasGermplasmID();

    String getOrigin();

    String getLineCode();

    String getPedigree();

    String getLineType();

    String getCropName();

    String getOwnerProgRefID();

    String getEventDisplay();

    boolean isTransgenic();

    boolean isDeleted();

    boolean isFinished();
}
