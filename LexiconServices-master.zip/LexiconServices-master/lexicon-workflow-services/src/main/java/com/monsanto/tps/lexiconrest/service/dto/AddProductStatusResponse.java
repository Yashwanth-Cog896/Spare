package com.monsanto.tps.lexiconrest.service.dto;

import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class AddProductStatusResponse {
    private int batchID;
     private List<String> infoMessages;
     private List<String> errorMessages;
     private String productPubkey;
     private String stagePubkey;
     private String exceptionCodePubkey;
     private Boolean status;
    private String productKind;

    public AddProductStatusResponse(int batchID, List<String> infoMessages, List<String> errorMessages, String productPubkey, String stagePubkey,
                                    String exceptionCodePubkey, Boolean status, String productKind) {
        this.batchID = batchID;
        this.infoMessages = infoMessages;
        this.errorMessages = errorMessages;
        this.productPubkey = productPubkey;
        this.stagePubkey = stagePubkey;
        this.exceptionCodePubkey = exceptionCodePubkey;
        this.status = status;
        this.productKind = productKind;
    }

    public String getProductKind() {
        return productKind;
    }

    public Boolean getStatus() {
         return status;
     }

     public void setStatus(Boolean status) {
         this.status = status;
     }

     public int getBatchID() {
         return batchID;
     }

     public List<String> getErrorMessages() {
         return errorMessages;
     }

     public void setErrorMessages(List<String> errorMessages) {
         this.errorMessages = errorMessages;
     }

     public void setBatchID(int batchID) {
         this.batchID = batchID;
     }

     public List<String> getInfoMessages() {
         return infoMessages;
     }

     public void setInfoMessages(List<String> infoMessages) {
         this.infoMessages = infoMessages;
     }

     public String getProductPubkey() {
         return productPubkey;
     }

     public void setProductPubkey(String productPubkey) {
         this.productPubkey = productPubkey;
     }

     public String getStagePubkey() {
         return stagePubkey;
     }

     public void setStagePubkey(String stagePubkey) {
         this.stagePubkey = stagePubkey;
     }

     public String getExceptionCodePubkey() {
         return exceptionCodePubkey;
     }

     public void setExceptionCodePubkey(String exceptionCodePubkey) {
         this.exceptionCodePubkey = exceptionCodePubkey;
     }

}