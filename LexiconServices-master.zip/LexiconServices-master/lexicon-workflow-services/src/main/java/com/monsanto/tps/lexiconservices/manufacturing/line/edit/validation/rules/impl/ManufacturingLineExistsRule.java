package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.tps.lexiconservices.common.rule.Rule;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:18 PM
 */
public class ManufacturingLineExistsRule implements Rule {

    private final ProductRelationshipEntity manufacturingLine;

    public ManufacturingLineExistsRule(ProductRelationshipEntity manufacturingLine) {
        this.manufacturingLine = manufacturingLine;
    }

    public boolean isViolated() {
        return manufacturingLine == null;
    }

    public String getViolation() {
        return "The requested manufacturing name does not exist.";
    }
}
