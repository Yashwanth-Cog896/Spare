package com.monsanto.tps.lexiconservices.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCompanyEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/8/14
 * Time: 10:14 AM
 */
public interface MirageCompanyDao extends GenericDao<MirageCompanyEntity,Long> {
    MirageCompanyEntity getMirageCompanyForPubKey(String lexiconBrandPubKey);
}
