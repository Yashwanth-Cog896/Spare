package com.monsanto.tps.lexiconservices.persistence.fbscommon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonCountryXrefEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 2:44 PM
 */
public interface FbsCommonCountryXrefDao extends GenericDao<FbsCommonCountryXrefEntity,String> {
}
