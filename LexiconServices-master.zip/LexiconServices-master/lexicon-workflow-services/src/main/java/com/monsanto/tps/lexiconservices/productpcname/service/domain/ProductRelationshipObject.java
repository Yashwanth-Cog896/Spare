package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 11:36 AM
 */
public class ProductRelationshipObject {

    private final String manufacturingName;
    private final String relationshipPubkey;
    private final List<ProductRelationshipDTO> products;

    public ProductRelationshipObject(ProductRelationshipEntity productRelationshipEntity, List<ProductRelationshipDTO> products) {
        this.manufacturingName = productRelationshipEntity.getManufacturingName();
        this.relationshipPubkey = productRelationshipEntity.getProductRelationshipPubkey();
        this.products = products;
    }

    public ProductRelationshipObject(String manufacturingName, String relationshipPubkey, List<ProductRelationshipDTO> products) {
        this.manufacturingName = manufacturingName;
        this.relationshipPubkey = relationshipPubkey;
        this.products = products;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public String getRelationshipPubkey() {
        return relationshipPubkey;
    }

    public List getProducts() {
        return products;
    }

    public void addRelationshipProduct(ProductRelationshipDTO product) {
        products.add(product);
    }

    public ProductRelationshipDTO getRelationshipProductByTraitVersion(String traitVersion) {
        return (ProductRelationshipDTO)
                ((StringUtils.isNullOrEmpty(traitVersion)) ?
                        CollectionUtils.find(products, new RelProductHasNullTraitVersionPredicate()) :
                        CollectionUtils.find(products, new RelProductHasGivenTraitVersionPredicate(traitVersion)));
    }

    class RelProductHasNullTraitVersionPredicate
            implements Predicate {
        public boolean evaluate(Object object) {
            ProductRelationshipDTO product = (ProductRelationshipDTO) object;
            return (StringUtils.isNullOrEmpty(product.getTraitVersion()));
        }
    }

    class RelProductHasGivenTraitVersionPredicate
            implements Predicate {
        private final String traitVersion;

        public RelProductHasGivenTraitVersionPredicate(String traitVersion) {
            this.traitVersion = traitVersion;
        }

        public boolean evaluate(Object object) {
            ProductRelationshipDTO product = (ProductRelationshipDTO) object;
            return (traitVersion.equals(product.getTraitVersion()));
        }
    }

    public ProductRelationshipDTO getRelationshipProductByPubkey(String productPubkey) {
        return (ProductRelationshipDTO) CollectionUtils.find(
                products, new RelProductHasGivenProdPubkeyPredicate(productPubkey));
    }


    class RelProductHasGivenProdPubkeyPredicate
            implements Predicate {
        private final String productPubkey;

        public RelProductHasGivenProdPubkeyPredicate(String productPubkey) {
            this.productPubkey = productPubkey;
        }

        public boolean evaluate(Object object) {
            ProductRelationshipDTO product = (ProductRelationshipDTO) object;
            return (product.getProductPubkey().equals(productPubkey));
        }
    }
}
