package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.common.rule.ConditionalRule;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:51 PM
 */
public class NonparentBaseProductHasVarietyNameRule extends ConditionalRule {
    private final BaseProductEntity baseProduct;
    private final String varietyName;
    private final ProductRelationshipEntity requestedManufacturingLine;


    public NonparentBaseProductHasVarietyNameRule(BaseProductEntity baseProduct, String varietyName, ProductRelationshipEntity requestedManufacturingLine) {
        this.baseProduct = baseProduct;
        this.varietyName = varietyName;
        this.requestedManufacturingLine = requestedManufacturingLine;
    }

    protected boolean preconditionsMet() {
        return baseProduct != null && !baseProduct.getParentProduct();
    }

    protected boolean criteriaViolated() {
        if (requestedManufacturingLine != null && requestedManufacturingLine.getBlendProduct()) {
            return false;
        }
        return StringUtils.isNullOrEmpty(varietyName);
    }

    public String getViolation() {
        return "Must have a variety name for a non-parent manufacturing name.";
    }
}
