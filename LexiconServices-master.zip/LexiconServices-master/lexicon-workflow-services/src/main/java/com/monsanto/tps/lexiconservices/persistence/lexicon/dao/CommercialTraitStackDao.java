package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.CommercialTraitStackDTO;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/8/14
 * Time: 3:11 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CommercialTraitStackDao extends GenericDao<CommercialTraitStackEntity,Long> {

  CommercialTraitStackDTO getTraitStackByPubkeyAndCountry(String triatStackPubKey , String countryPubKey);

  CommercialTraitStackEntity getTraitStackByPubkey(String triatStackPubKey);

}
