package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;

import java.util.Iterator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/30/14
 * Time: 3:03 PM
 */
public class MidasProductNamesCollection {
    List<MidasProductNameEntity> nameRecords;

    public MidasProductNamesCollection(List<MidasProductNameEntity> midasProductNames) {
        nameRecords = midasProductNames;
    }

    public MidasProductNameEntity getFirstActiveRecord() {
        return (MidasProductNameEntity) CollectionUtils.find(nameRecords, new NameRecIsActivePredicate());
    }

    public boolean hasActiveRecords() {
        return CollectionUtils.exists(nameRecords, new NameRecIsActivePredicate());
    }

    public boolean isEmpty() {
        return nameRecords.isEmpty();

    }

    public MidasProductNameEntity getFirstRecord() {
        return (isEmpty()) ? null : nameRecords.get(0);
    }

    public MidasProductNameEntity getCommonProduct() {
        MidasProductNameEntity nameRecord = getFirstActiveRecord();
        return (nameRecord == null || CollectionUtils.exists(nameRecords,
                new NameRecDoesntMatchGivenProdIDPredicate(nameRecord.getMidasProduct().getId())))
                ? null : nameRecord;
    }

    public boolean cropMatches(TPSCrop crop) {
        return !CollectionUtils.exists(nameRecords, new NameRecDoesntMatchGivenCropPredicate(crop));
    }

    class NameRecDoesntMatchGivenCropPredicate
            extends NameRecIsActivePredicate {
        private final TPSCrop crop;

        public NameRecDoesntMatchGivenCropPredicate(TPSCrop crop) {
            this.crop = crop;
        }

        public boolean evaluate(Object object) {
            MidasProductNameEntity nameRecord = (MidasProductNameEntity) object;
            return (super.evaluate(nameRecord) && nameRecord.getMidasProduct().getMidasCrop().getId() != crop.getMidasCropID());
        }
    }

    class NameRecDoesntMatchGivenProdIDPredicate
            extends NameRecIsActivePredicate {
        private long productID;

        public NameRecDoesntMatchGivenProdIDPredicate(long productID) {
            this.productID = productID;
        }

        public boolean evaluate(Object object) {
            MidasProductNameEntity nameRecord = (MidasProductNameEntity) object;
            return (super.evaluate(nameRecord) && productID != nameRecord.getMidasProduct().getId());
        }
    }

    public void updateCollection(MidasProductNameEntity midasProductName) {
        Iterator iter = nameRecords.iterator();
        while (iter.hasNext()) {
            MidasProductNameEntity proudctName = (MidasProductNameEntity) iter.next();
            if (proudctName.getId() == midasProductName.getId()) {
                iter.remove();
                break;
            }
        }
        nameRecords.add(midasProductName);
    }


    public int getSize() {
        return nameRecords.size();
    }

    class NameRecIsActivePredicate implements Predicate {
        public boolean evaluate(Object object) {
            return evaluate((MidasProductNameEntity) object);
        }

        protected boolean evaluate(MidasProductNameEntity nameRecord) {
            return (nameRecord.isRefActive());
        }
    }

    public boolean nameValueMatches(String productName) {
        return !CollectionUtils.exists(nameRecords, new NameRecDoesntMatchGivenNamePredicate(productName));
    }

    class NameRecDoesntMatchGivenNamePredicate
            extends NameRecIsActivePredicate
    {
        private final String productName;
        public NameRecDoesntMatchGivenNamePredicate(String productName) {
            this.productName = productName;
        }

        public boolean evaluate(Object object) {
            MidasProductNameEntity nameRecord = (MidasProductNameEntity)object;
            return (super.evaluate(nameRecord) && !productName.equalsIgnoreCase(nameRecord.getName()));
        }
    }

}
