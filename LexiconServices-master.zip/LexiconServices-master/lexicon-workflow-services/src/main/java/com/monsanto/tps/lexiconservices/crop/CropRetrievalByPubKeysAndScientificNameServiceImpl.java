package com.monsanto.tps.lexiconservices.crop;

import com.monsanto.tps.aop.exception.RootCauseWebExceptionWrapper;
import com.monsanto.tps.lexiconservices.crop.domain.Crop;
import com.monsanto.tps.lexiconservices.crop.domain.CropRetrievalByPubKeysAndScientificNameRequest;
import com.monsanto.tps.lexiconservices.crop.processor.CropRetrievalByPubKeysAndScientificNameProcessor;
import com.monsanto.tps.lexiconservices.crop.service.CropRetrievalByPubKeyAndScientificNameException;
import com.monsanto.tps.lexiconservices.crop.service.CropRetrievalByPubKeyAndScientificNameService;
import org.apache.cxf.feature.Features;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.jws.WebParam;
import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
@Component(value = "cropRetrievalByPubKeysAndScientificNameServiceImpl")
@Transactional(propagation = Propagation.REQUIRED)
@Features(features = "org.apache.cxf.feature.LoggingFeature")
public class CropRetrievalByPubKeysAndScientificNameServiceImpl implements CropRetrievalByPubKeyAndScientificNameService {

  private Logger logger = Logger.getLogger(CropRetrievalByPubKeysAndScientificNameServiceImpl.class);

  @Resource
  private CropRetrievalByPubKeysAndScientificNameProcessor cropRetrievalByPubKeysAndScientificNameProcessor;

  @RootCauseWebExceptionWrapper(exceptionClass = CropRetrievalByPubKeyAndScientificNameException.class)
  public List<Crop> findByPublicKeysAndScientificName(@WebParam(name = "cropRetrievalByPubKeysAndScientificNameRequest") CropRetrievalByPubKeysAndScientificNameRequest cropRetrievalByPubKeysAndScientificNameRequest) throws CropRetrievalByPubKeyAndScientificNameException {
    logger.info("Processing CropRetrievalByPubKeysAndScientificNameService request for findByPublicKeysAndScientificName");
    return cropRetrievalByPubKeysAndScientificNameProcessor.findByPublicKeysAndScientificName(cropRetrievalByPubKeysAndScientificNameRequest);
  }
}