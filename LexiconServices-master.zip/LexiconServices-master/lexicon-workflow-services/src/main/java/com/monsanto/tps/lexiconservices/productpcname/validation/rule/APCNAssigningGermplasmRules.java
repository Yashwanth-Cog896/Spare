package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.AssigningGermplasmSinglePreferredPedigreeRule;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.product.common.rule.AssigningGermplasmConsistentRule;
import com.monsanto.tps.lexiconservices.product.common.rule.AssigningGermplasmConsistentWithExistingRule;
import com.monsanto.tps.lexiconservices.product.common.rule.AssigningGermplasmHaveHybridCodedOrFinishedLineTypeRule;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;

public class APCNAssigningGermplasmRules
        extends RulesValidatorCollection {
    private final ProductGermplasmCollection assigningGermplasm;
    private final InbredHybridEnum inbredHybridType;
    private final boolean containsPreferredPedigree;

    public APCNAssigningGermplasmRules(ProductGermplasmCollection assigningGermplasm,
                                       InbredHybridEnum inbredHybridType, boolean containsPreferredPedigree) {
        this.assigningGermplasm = assigningGermplasm;
        this.inbredHybridType = inbredHybridType;
        this.containsPreferredPedigree = containsPreferredPedigree;
    }

    protected RulesValidator[] getRulesValidators() {
        return new RuleSeverityPair[]{
                new RuleSeverityPair(new AssigningGermplasmHaveHybridCodedOrFinishedLineTypeRule(assigningGermplasm), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new AssigningGermplasmConsistentRule(assigningGermplasm), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new AssigningGermplasmConsistentWithExistingRule(inbredHybridType, assigningGermplasm), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new AssigningGermplasmSinglePreferredPedigreeRule(assigningGermplasm, containsPreferredPedigree), ValidationConditionSeverity.ERROR)

        };
    }
}
