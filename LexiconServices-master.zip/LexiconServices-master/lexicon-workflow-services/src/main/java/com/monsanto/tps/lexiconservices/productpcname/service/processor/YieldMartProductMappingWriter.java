package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.yldstg.domain.MapProductMirageEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.MapProductMirageDao;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/11/14
 * Time: 1:20 PM
 */
@Component(value = "yieldMartProductMappingWriter")
public class YieldMartProductMappingWriter {

    @Resource
    private MapProductMirageDao mapProductMirageDao;

    @Resource
    private ProductDao productDao;

    public MapProductMirageEntity write(ProductDTO mirageProduct, MidasProductEntity midasProduct, GeneticMaterialEntity geneticMaterial) {
        if (compositePiecesDontExist(mirageProduct, geneticMaterial, midasProduct)) {
            return null;
        } else {
            MapProductMirageEntity product = createProductObject(mirageProduct, midasProduct, geneticMaterial);
            return mapProductMirageDao.saveOrUpdate(product);
        }
    }

    private MapProductMirageEntity createProductObject(ProductDTO mirageProduct, MidasProductEntity midasProduct, GeneticMaterialEntity geneticMaterial) {

        MapProductMirageEntity entity = new MapProductMirageEntity();
        entity.setGeneticMaterial(geneticMaterial);
        entity.setMidasProduct(midasProduct);
        entity.setMirageName(mirageProduct.getProductName());
        entity.setMirageSeedProduct(productDao.get(mirageProduct.getProductID()));
        return entity;
    }

    private boolean compositePiecesDontExist(ProductDTO mirageProduct, GeneticMaterialEntity geneticMaterial, MidasProductEntity midasProduct) {
        return mirageProduct == null || geneticMaterial == null || midasProduct == null;
    }
}
