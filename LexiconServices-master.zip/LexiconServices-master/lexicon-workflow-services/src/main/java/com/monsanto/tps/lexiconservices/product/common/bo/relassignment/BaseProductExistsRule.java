package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class BaseProductExistsRule
        extends SimpleValidationRule {
    private final BaseProductEntity baseProduct;
    private final String requestedManfName;

    public BaseProductExistsRule(BaseProductEntity baseProduct, String requestedManfName) {
        this.baseProduct = baseProduct;
        this.requestedManfName = requestedManfName;
    }

    protected boolean preConditionsMet() {
        return !StringUtils.isNullOrEmpty(requestedManfName);
    }

    protected boolean criteriaViolated() {
        return baseProduct == null;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.BASE_PRODUCT_DOES_NOT_EXIST);
    }
}