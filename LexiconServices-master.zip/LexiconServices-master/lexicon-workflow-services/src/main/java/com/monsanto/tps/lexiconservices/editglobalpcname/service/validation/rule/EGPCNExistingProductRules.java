package com.monsanto.tps.lexiconservices.editglobalpcname.service.validation.rule;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.validation.EGPCNExistingProductValidationModel;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.ExistingLexProdHasProdXrefRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.ExistingLexProdNotDeletedRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.LexiconProductExistsRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.LinkedMidasProdNotInactiveRule;
import com.monsanto.tps.lexiconservices.product.common.rule.existingproduct.ProdXrefFoundMidasProdFoundRule;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/12/14
 * Time: 9:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class EGPCNExistingProductRules extends RulesValidatorCollection
{
  private final EGPCNExistingProductValidationModel model;

  public EGPCNExistingProductRules(EGPCNExistingProductValidationModel model) {
    this.model = model;
  }

  protected RulesValidator[] getRulesValidators() {
    return new RuleSeverityPair[] {
      new RuleSeverityPair(new LexiconProductExistsRule(model.getLexProduct()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new ExistingLexProdNotDeletedRule(model.getLexProduct()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new ExistingLexProdHasProdXrefRule(model.getLexProduct(), model.getProductXref()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new ProdXrefFoundMidasProdFoundRule(model.getProductXref(), model.getMidasProduct()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new LinkedMidasProdNotInactiveRule(model.getMidasProduct()), ValidationConditionSeverity.ERROR),
    };
  }
}
