package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/14/15
 * Time: 4:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStageCommercialQuery extends AbstractPersistentStoreEntityExistsQuery {

  private String commercialName;
  private String brandName;
  private String countryName;


  public ProductStageCommercialQuery(String commercialName,String brandName,String countryName) {
    this.commercialName = commercialName;
    this.brandName = brandName;
    this.countryName = countryName;
  }

  protected String getSQL()
    throws WrappingException {
    checkForSpecialChar();
    return "select * from lexicon.product_stage where commercial_name in " +"'" +commercialName + "'" +" and brand_id in (select brand_id from lexicon.brand where brand_name IN " + "'"+ brandName + "'" +")" +
      " and country_id in (select country_id from lexicon.country where country_abbr IN " + "'"+countryName +"'"+ " )" ;
  }

    private void checkForSpecialChar() {
     if (brandName.contains("'")) {
         int index = brandName.indexOf("'");
         brandName = new StringBuilder(brandName).insert(index, "'").toString();
     }
    }

  protected Object[] getBindVariables() throws WrappingException {
    return new Object[0];
  }

  protected ConnectionFactoryProperties getConnectionFactoryProperties() {
    return new LexiconConnectionFactoryProperties();
  }
}

