package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit.AuditStagingEntity;
import org.hibernate.Session;

import java.math.BigDecimal;


public class AuditStagingDaoImpl extends GenericDaoImpl<AuditStagingEntity,Long> implements AuditStagingDao {


    public AuditStagingDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public BigDecimal getSessionId() {
      return null;//Return nothing aop gets this
    }

    @Override
    public String getSessionMachine() {
        return null; //Return nothing aop gets this
    }

    @Override
    public String getSessionOsUser() {
        return null;  //Return nothing aop gets this
    }
    public void saveAndFlush(AuditStagingEntity auditStagingEntity){
        Session session = getSession();
        session.save(auditStagingEntity);
        session.flush();
    }

    @Override
    public void delete(AuditStagingEntity auditStagingEntity) {
        getSession().flush();
        super.delete(auditStagingEntity);   
    }
}
