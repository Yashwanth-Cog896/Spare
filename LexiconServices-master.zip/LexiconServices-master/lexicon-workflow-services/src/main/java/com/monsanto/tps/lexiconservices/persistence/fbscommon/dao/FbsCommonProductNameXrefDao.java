package com.monsanto.tps.lexiconservices.persistence.fbscommon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.GermplasmDTO;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public interface FbsCommonProductNameXrefDao extends GenericDao<FbsCommonProductNameXrefEntity, Long> {

  @DynamicDaoMethod(queryName = "FbsCommonProductXrefDao.findProductNameXrefByPubKey",
    parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
  FbsCommonProductNameXrefEntity findProductXrefByPubKey(@DynamicDaoParameter(name = "lexiconPubkey") String lexiconPubkey);
}