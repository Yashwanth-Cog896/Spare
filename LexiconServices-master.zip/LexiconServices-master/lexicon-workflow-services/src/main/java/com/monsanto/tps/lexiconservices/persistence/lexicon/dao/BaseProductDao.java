package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/27/13
 * Time: 12:22 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BaseProductDao extends GenericDao<BaseProductEntity,Long> {
  @DynamicDaoMethod(queryName = "BaseProductDao.findBaseProductByManufacturingName", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
  BaseProductEntity findBaseProductByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);

}
