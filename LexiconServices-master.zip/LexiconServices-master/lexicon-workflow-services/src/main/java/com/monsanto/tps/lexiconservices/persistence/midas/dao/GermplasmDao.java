package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GermplasmEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.GermplasmDTO;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public interface GermplasmDao extends GenericDao<GermplasmEntity, Long> {

    MidasProductGermplasmDTO findGermplasmByGermplasmID(Long germplasmID);

    Boolean validateGermplasmAttachedToProduct(Long germplasmID);

    MidasProductGermplasmDTO insertGermplasm(GermplasmDTO germplasmDTO);
     //Todo should go in common dao
    long getNextMidasId();
}