package com.monsanto.tps.lexiconservices.externalservice.externalservice.impl;

import com.monsanto.tps.lexicon.eventtraitservice.GermplasmEventTraitService;
import com.monsanto.tps.lexiconservices.externalservice.externalservice.GermplasmEventTraitServiceInvoker;

import javax.annotation.Resource;
import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class GermplasmEventTraitServiceInvokerImpl implements GermplasmEventTraitServiceInvoker {

  @Resource
  private GermplasmEventTraitService germplasmEventTraitService;

  public List<Long> fetchTraitStackIdsForGermplasms(List<Long> germplasmKeys) {
    List<Long> traitStackIdsForGermplasms = new ArrayList<Long>();
    for (Long germplasmId : germplasmKeys) {
      List<Long> traitStackIdsForGermplasm = germplasmEventTraitService.getComTraitStackIdByEventConstructs(germplasmId);
      if (traitStackIdsForGermplasm != null) {
        traitStackIdsForGermplasms.addAll(traitStackIdsForGermplasm);
      }
    }
    return traitStackIdsForGermplasms;
  }
}