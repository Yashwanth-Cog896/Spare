package com.monsanto.tps.lexiconservices.externalservice.externalservice;

import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public interface SupportCenterLogger {
  void updatePrecommercials(List<String> productPubkeys);
}