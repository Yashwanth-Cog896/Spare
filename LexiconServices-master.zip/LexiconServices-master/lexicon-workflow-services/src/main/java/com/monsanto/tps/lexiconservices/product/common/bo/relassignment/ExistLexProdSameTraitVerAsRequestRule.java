package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.product.model.lexicon.ProductRelationshipProduct;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;


public class ExistLexProdSameTraitVerAsRequestRule
        extends SimpleValidationRule {
    private final LexiconProductEntity lexProduct;
    private final ProductRelationshipObject productRelationship;
    private final String traitVersionName;

    public ExistLexProdSameTraitVerAsRequestRule(LexiconProductEntity lexProduct,
                                                 ProductRelationshipObject productRelationship, String traitVersionName) {
        this.lexProduct = lexProduct;
        this.productRelationship = productRelationship;
        this.traitVersionName = traitVersionName;
    }

    protected boolean preConditionsMet() {
        return lexProduct != null && !lexProduct.isLogicalDelete() &&
                !StringUtils.isNullOrEmpty(lexProduct.getPubkey());
    }

    protected boolean criteriaViolated() {
        if (productRelationship == null) {
            return !StringUtils.isNullOrEmpty(traitVersionName);
        } else if (StringUtils.isNullOrEmpty(traitVersionName)) {
            return !StringUtils.isNullOrEmpty(getProductTraitVersionName());
        } else {
            return !traitVersionName.equals(getProductTraitVersionName());
        }
    }

    private String getProductTraitVersionName() {
        ProductRelationshipDTO relProd =
                productRelationship.getRelationshipProductByPubkey(lexProduct.getPubkey());
        return (relProd == null) ? null : relProd.getTraitVersion();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.EXIST_LEX_PROD_DIFF_MANF_VER);
    }

}
