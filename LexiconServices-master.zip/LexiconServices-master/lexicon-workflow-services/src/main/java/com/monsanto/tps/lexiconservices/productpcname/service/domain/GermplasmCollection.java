package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.domain.midas.Germplasm;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.product.common.domain.LineTypeRef;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.Closure;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 2:31 PM
 */
public class GermplasmCollection {
    private final Set<MidasProductGermplasmDTO> germplasms = new TreeSet<MidasProductGermplasmDTO>(new AscendingGermplasmComparator());

    public GermplasmCollection() {
    }

    public GermplasmCollection(List<MidasProductGermplasmDTO> productGermplasms) {
        this.germplasms.addAll(productGermplasms);
    }

    public Set<MidasProductGermplasmDTO> getGermplasms() {
        return germplasms;
    }

    public InbredHybridEnum getInbredHybridType() {
        MidasProductGermplasmDTO germplasm = (MidasProductGermplasmDTO) CollectionUtils.find(germplasms, new LineTypeIsKnownTypePredicate());
        InbredHybridEnum inbredHybridType = germplasm == null ? new InbredHybridEnum() : new InbredHybridEnum(germplasm.getLineType());
        return CollectionUtils.exists(germplasms, new LineTypeInconsistentPredicate(inbredHybridType)) ? null : inbredHybridType;
    }

    public boolean hasOnlyHybridCodedOrFinishedTypes() {
        Collection nonHybridCodedAndFinishedGermplasm = CollectionUtils.selectRejected(germplasms, new GermplasmHybridCodedOrFinished());
        return nonHybridCodedAndFinishedGermplasm.isEmpty();
    }

    public boolean hasConsistentType() {
        return getInbredHybridType() != null;
    }

    public void addGermplasms(Set<MidasProductGermplasmDTO> germplasms) {
        CollectionUtils.forAllDo(Arrays.asList(germplasms.toArray()), new AddGermplasmToCollectionFunctor());

    }

    public void addGermplasm(MidasProductGermplasmDTO germplasm) {
        germplasms.add(germplasm);
    }

    public MidasProductGermplasmDTO getFinishedGermplasm() {
        return (MidasProductGermplasmDTO) CollectionUtils.find(germplasms, new GermplasmFinishedPredicate());

    }

    public int numGermplasm() {
        return germplasms.size();
    }

    public String getAOwnerProgRefID() {
        MidasProductGermplasmDTO germplasm = (MidasProductGermplasmDTO)CollectionUtils.find(germplasms, new NonEmptyOwnerPrefIDPredicate());
        return germplasm == null ? null : germplasm.getProgRefId();
    }

    public String getAnyEventDisplay() {
        MidasProductGermplasmDTO germplasm = (MidasProductGermplasmDTO)CollectionUtils.find(germplasms, new NonEmptyEventDisplayPredicate());
        return germplasm == null ? null : germplasm.getEventDisplay();
    }

    public boolean isAnyTransgenic() {
        return CollectionUtils.exists(germplasms, new GermplasmTransgenicPredicate());

    }

    public MidasProductGermplasmDTO getGermplasmByID(long germplasmID) {
        return (MidasProductGermplasmDTO)CollectionUtils.find(germplasms, new GermplasmHasGivenIDPredicate(germplasmID));

    }

    class LineTypeIsKnownTypePredicate
            extends GermplasmPredicate {
        protected boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return !new InbredHybridEnum(germplasm.getLineType()).isUnknown();
        }
    }

    abstract class GermplasmPredicate
            implements Predicate {
        protected abstract boolean evaluate(MidasProductGermplasmDTO germplasm);

        public boolean evaluate(Object object) {
            return evaluate((MidasProductGermplasmDTO) object);
        }
    }

    class LineTypeInconsistentPredicate
            extends GermplasmPredicate {
        private final InbredHybridEnum inbredHybridType;

        public LineTypeInconsistentPredicate(InbredHybridEnum inbredHybridType) {
            this.inbredHybridType = inbredHybridType;
        }

        protected boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return !inbredHybridType.isConsistant(germplasm.getLineType());
        }
    }

    class GermplasmHybridCodedOrFinished
            extends GermplasmPredicate {
        protected boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return LineTypeRef.HYBRID.equals(germplasm.getLineType())
                    || LineTypeRef.CODED.equals(germplasm.getLineType())
                    || LineTypeRef.FINISHED.equals(germplasm.getLineType());
        }
    }

    class AddGermplasmToCollectionFunctor
            implements Closure {
        public void execute(Object object) {
            addGermplasm((MidasProductGermplasmDTO) object);
        }
    }

    class GermplasmFinishedPredicate
            extends GermplasmPredicate
    {
        public boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return germplasm.isFinished();
        }
    }

    class NonEmptyOwnerPrefIDPredicate
            extends GermplasmPredicate
    {
        public boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return !StringUtils.isNullOrEmpty(germplasm.getProgRefId());
        }
    }

    class NonEmptyEventDisplayPredicate
            extends GermplasmPredicate
    {
        public boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return !StringUtils.isNullOrEmpty(germplasm.getEventDisplay());
        }
    }

    class GermplasmTransgenicPredicate
            extends GermplasmPredicate
    {
        public boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return germplasm.isTransgenic();
        }
    }

    class GermplasmHasGivenIDPredicate
            extends GermplasmPredicate
    {
        private final long germplasmID;
        public GermplasmHasGivenIDPredicate(long germplasmID) {
            this.germplasmID = germplasmID;
        }

        protected boolean evaluate(MidasProductGermplasmDTO germplasm) {
            return germplasmID == germplasm.getGermplasmId();
        }
    }
}
