package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/12/15
 * Time: 12:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStageProductNamePubKeyQuery extends AbstractPersistentStoreMultiRowQuery {
  private String[] preCommercialName;
    private String[] countryName;
  private String selectProductStageProductNamePubkey = "select PRODUCT_STAGE_PUBKEY from lexicon.product_stage where product_id in (" +
    "select product_id from lexicon.pre_coml_product where pre_coml_name in ( ";

    private String selectCountry = " and country_id in (select country_id from lexicon.country where country_abbr in ( ";

  public ProductStageProductNamePubKeyQuery(String[] preCommercialName, String[] countryName) {
    this.preCommercialName = preCommercialName;
      this.countryName = countryName;
  }

  public List<String> find()
    throws WrappingException {
    return getList();
  }

  protected Object createObjectFromRow(PersistentStoreResultSetRow row)
    throws WrappingException {
    return getProductStagePubKey(row);
  }

  private String getProductStagePubKey(PersistentStoreResultSetRow row) throws WrappingException {
    return row.getString("PRODUCT_STAGE_PUBKEY");
  }

  private String getNonNull(String string) {
    return string == null ? "" : string;
  }

  protected String getSQL()
    throws WrappingException {
    return selectProductStageProductNamePubkey + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(preCommercialName) + ")" + selectCountry +
            new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(countryName) + " ) or country_name in (" + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(countryName) + " )))";
  }

  protected Object[] getBindVariables()
    throws WrappingException {
    return new Object[0];
  }

  protected ConnectionFactoryProperties getConnectionFactoryProperties() {
    return new LexiconConnectionFactoryProperties();
  }
}
