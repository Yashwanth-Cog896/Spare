package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ExceptionCodeEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconExceptionCodeDao;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 1/8/14
 * Time: 12:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconExceptionCodeDaoImpl extends GenericDaoImpl<ExceptionCodeEntity, Long> implements LexiconExceptionCodeDao {

  private final String UPDATE_BY_PUBKEY_PRODUCTNAME = "ExceptionCodeDao.updateByPubkeyandProductName";
  private final String GET_NEXT_EXCEPTIONCODE_PUBKEY = "ExceptionCodeDao.getNextPubkey";
  private final String INSERT_EXCEPTIONCODE = "ExceptionCodeDao.insertExceptionCode";

  public LexiconExceptionCodeDaoImpl(Class entityClass) {
    super(entityClass);
  }

  public List<ExceptionCodeEntity> getProductsExceptionCodes(String pubkey) {
    List<ExceptionCodeEntity> exceptionCodeEntityList = new ArrayList<ExceptionCodeEntity>();
    List<LexiconProductEntity> lexiconProductList = (List<LexiconProductEntity>) getSessionFactory().getCurrentSession().
      createCriteria(LexiconProductEntity.class, "lexiconProduct").
      createAlias("lexiconProduct.lexiconProductStages", "lexiconProductStages").
      createAlias("lexiconProduct.exceptionCode", "exceptionCode").
      createAlias("exceptionCode.lexiconCrop", "lexiconCrop").
      add(Restrictions.eq("lexiconProduct.pubkey", pubkey)).
      add(Restrictions.eq("lexiconProduct.logicalDelete", false)).
      add(Restrictions.eq("lexiconProductStages.logicalDelete", false)).
      list();
    if (lexiconProductList.size() > 0) {
      for (LexiconProductEntity lexiconProductEntity : lexiconProductList) {
        exceptionCodeEntityList.add(lexiconProductEntity.getExceptionCode());
      }
    }
    return exceptionCodeEntityList;

  }

  public ExceptionCodeEntity findByCropAndProductName(Long cropId, String productName) {
    return (ExceptionCodeEntity) getSessionFactory().getCurrentSession().createCriteria(ExceptionCodeEntity.class, "exceptionCode").
      createAlias("exceptionCode.lexiconCrop", "lexiconCrop").
      add(Restrictions.eq("lexiconCrop.id", cropId)).
      add(Restrictions.eq("exceptionCode.productName", productName)).uniqueResult();
  }

  public String getNextExceptionCodePubkey() {
    return getSessionFactory().getCurrentSession().getNamedQuery(GET_NEXT_EXCEPTIONCODE_PUBKEY).uniqueResult().toString();
  }

  public int insertExceptionCode(String pubkey, Long cropId, String productName, char isPrimaryInd) {
    return getSessionFactory().getCurrentSession().getNamedQuery(INSERT_EXCEPTIONCODE).setParameter("pubkey", pubkey).
      setParameter("cropId", cropId).setParameter("productName", productName).setParameter("isPrimaryInd", isPrimaryInd)
      .executeUpdate();
  }

  public int updateByPubkeyAndProductName(String pubkey, String productName, boolean isPrimaryInd) {
    return getSessionFactory().getCurrentSession().getNamedQuery(UPDATE_BY_PUBKEY_PRODUCTNAME).setParameter("pubkey", pubkey).
      setParameter("productName", productName).setParameter("isPrimaryInd", isPrimaryInd)
      .executeUpdate();
  }
}
