package com.monsanto.tps.lexiconservices.productpcname.service.exception;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/30/14
 * Time: 12:00 PM
 */
public class InvalidCropException extends Exception {

    public InvalidCropException(String message) {
        super(message);
    }
    public InvalidCropException(String message,Throwable cause) {
        super(message,cause);
    }
}
