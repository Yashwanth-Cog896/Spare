package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconStageDao;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 1/7/14
 * Time: 10:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconStageDaoImpl extends GenericDaoImpl<LexiconCountryEntity, Long> implements LexiconStageDao {

    public LexiconStageDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public LexiconStageEntity getStageTypeByPubkey(String pubkey) {
        return (LexiconStageEntity) getSessionFactory().getCurrentSession().
                createCriteria(LexiconStageEntity.class, "lexiconStage").
                createAlias("lexiconStage.stageCategories", "stageCategories").
                add(Restrictions.eq("lexiconStage.pubkey", pubkey)).uniqueResult();
    }
}