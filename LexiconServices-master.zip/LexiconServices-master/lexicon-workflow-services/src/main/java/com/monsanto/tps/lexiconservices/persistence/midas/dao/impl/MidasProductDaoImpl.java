package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductDao;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/27/13
 * Time: 3:13 PM
 */
public class MidasProductDaoImpl extends GenericDaoImpl<MidasProductEntity,Long> implements MidasProductDao {

    public MidasProductDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public int updateDenominationByPublicKey(String denomination, String pubKey) {
        return getSessionFactory().getCurrentSession().getNamedQuery("MidasProductDao.updateDenominationByPublicKey").
                setParameter("denomination", denomination).
                setParameter("pubKey", pubKey).executeUpdate();
    }


    @Override
    public MidasProductEntity save(MidasProductEntity product) {
        Long id = (Long) getSessionFactory().getCurrentSession().save(product);
        return get(id);
    }

    @Override
    public void updateDenominationAndRefActive(long id, String denomination, boolean refActive) {
        MidasProductEntity entity = get(id);
        entity.setDenomination(denomination);
        entity.setRefActive(refActive);
    }


}
