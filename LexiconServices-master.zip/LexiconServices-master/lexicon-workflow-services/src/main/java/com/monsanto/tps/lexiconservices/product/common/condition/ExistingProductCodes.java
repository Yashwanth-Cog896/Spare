package com.monsanto.tps.lexiconservices.product.common.condition;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 19, 2006
 * Time: 9:54:54 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ExistingProductCodes {
    ValidationConditionCode LEX_PROD_NOT_EXIST_CODE = new ValidationConditionCode("LexProdNotExists");
    ValidationConditionCode EXIST_LEX_PROD_DEL_CODE = new ValidationConditionCode("ExistingLexProdDeleted");
    ValidationConditionCode LEX_PROD_FOUND_NO_XREF_CODE = new ValidationConditionCode("LexProdFoundWithNoXref");
    ValidationConditionCode PROD_XREF_EXIST_MIDAS_PROD_DOESNT_CODE = new ValidationConditionCode("ProdXrefExistMidasProdDoesnt");
    ValidationConditionCode LINKED_MIDAS_PROD_INACTIVE_CODE = new ValidationConditionCode("LinkedMidasProdInactive");
    ValidationConditionCode NO_PRODUCT_GERMPLASM_CODE = new ValidationConditionCode("NoProductGermplasm");
    ValidationConditionCode NO_FINISHED_GERMPLASM_CODE = new ValidationConditionCode("NoFinishedGermplasm");
    ValidationConditionCode NO_MIDAS_GLOBAL_PC_NAME_CODE = new ValidationConditionCode("NoMidasGlobalPCName");
    ValidationConditionCode NO_MIRAGE_GM_CODE = new ValidationConditionCode("NoMirageGMExists");
}
