package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.KeywordEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.CommercialTraitStackDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 12:28 PM
 */
@Component(value = "TPSTraitLookup")
public class TPSTraitLookup {

    @Resource
    private CommercialTraitStackDao commercialTraitStackDao;

    public TPSTrait getTraitByPubkey(String traitStackPubkey) {
        CommercialTraitStackEntity traitStackEntity = commercialTraitStackDao.getTraitStackByPubkey(traitStackPubkey);
        if (traitStackEntity != null) {
            KeywordEntity mirageTrait = findMirageTraitCharacteristics(traitStackEntity.getTechDevName());
            long mirageCode = (mirageTrait == null) ? 0 : mirageTrait.getCode();
            return new TPSTrait(traitStackEntity, mirageCode);
        } else {
            return null;
        }
    }

    private KeywordEntity findMirageTraitCharacteristics(String techDevName) {
        MirageTraitCharacteristicsLookup lookup = MirageTraitCharacteristicsLookup.getInstance();
        return lookup.getTraitCharacteristics(techDevName);

    }

    public TPSTrait getTraitByPubkeyAndCountry(String traitStackPubkey, String countryPubkey) {
        CommercialTraitStackEntity traitStackEntity = commercialTraitStackDao.getTraitStackByPubkey(traitStackPubkey);
        if (traitStackEntity != null) {
            CommercialTraitStackDTO alternateTraitStack = commercialTraitStackDao.getTraitStackByPubkeyAndCountry(traitStackPubkey, countryPubkey);
            String traitCharacteristic = determineTraitCharacteristic(traitStackEntity, alternateTraitStack);
            long traitCharactersticsCode = lookupMirageTraitCharacteristicCode(traitCharacteristic);
            return new TPSTrait(traitStackEntity, traitCharactersticsCode);

        } else {
            return null;
        }
    }

    private long lookupMirageTraitCharacteristicCode(String traitCharacteristic) {
        KeywordEntity traitCharacteristics = findMirageTraitCharacteristics(traitCharacteristic);
        return traitCharacteristics == null ? 0 : traitCharacteristics.getCode();

    }

    private String determineTraitCharacteristic(CommercialTraitStackEntity baseTraitStack, CommercialTraitStackDTO alternateTraitStack) {
        return alternateTraitStack == null ? baseTraitStack.getTechDevName() : alternateTraitStack.getTraitStackReportingName();
    }
}
