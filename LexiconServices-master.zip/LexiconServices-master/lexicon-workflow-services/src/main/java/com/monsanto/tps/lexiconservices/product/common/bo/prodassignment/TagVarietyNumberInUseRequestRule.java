package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.richrequest.TagVarietyNameRequest;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 10/21/13
 * Time: 2:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class TagVarietyNumberInUseRequestRule extends SimpleValidationRule {

    private final TagVarietyNameRequest model;

    public TagVarietyNumberInUseRequestRule(TagVarietyNameRequest model) {

        this.model = model;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return model.isTagVarietyNumberInUse();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.NUMERICAL_VALUE_IN_USE_CODE);
    }
}
