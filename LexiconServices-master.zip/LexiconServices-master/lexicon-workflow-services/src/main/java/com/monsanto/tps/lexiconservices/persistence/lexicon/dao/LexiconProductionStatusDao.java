package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductionStatusEntity;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 3/18/14
 * Time: 11:53 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductionStatusDao extends GenericDao<LexiconProductionStatusEntity, Long> {

    LexiconProductionStatusEntity getByStatus(String status);
}
