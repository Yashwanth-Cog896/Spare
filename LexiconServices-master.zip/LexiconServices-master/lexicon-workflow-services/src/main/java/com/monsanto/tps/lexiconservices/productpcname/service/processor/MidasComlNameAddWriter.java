package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductNameDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.ProductNameDTO;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasNameRichAttributes;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/11/14
 * Time: 11:30 AM
 */
@Component(value = "midasComlNameAddWriter")
public class MidasComlNameAddWriter {

    @Resource
    private MidasProductNameDao midasProductNameDao;

    @Resource
    private GermplasmDao midasDao;

    public MidasProductNameEntity write(MidasProductNameEntity existingRecord, MidasProductEntity midasProduct, MidasNameRichAttributes stageAttributes) {

        return (existingRecord != null) ?
                reuseExistingRecord(existingRecord, stageAttributes.getComlName()) :
                null;
    }

    private MidasProductNameEntity reuseExistingRecord(MidasProductNameEntity existingRecord, String commercialName) {
        midasProductNameDao.reuseMidasProductName(commercialName, existingRecord.getId());
        return midasProductNameDao.get(existingRecord.getId());
    }
}
