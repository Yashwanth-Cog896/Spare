package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl.ManufacturingNameValidationChecks;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class ManfNameValidRule
        extends SimpleValidationRule {
    private ManufacturingNameValidationChecks manfuacturingNameChecks;

    public ManfNameValidRule(String manfName) {
        this.manfuacturingNameChecks = new ManufacturingNameValidationChecks(manfName);
    }

    protected boolean preConditionsMet() {
        return !manfuacturingNameChecks.isNullOrEmpty();
    }

    protected boolean criteriaViolated() {
        return manfuacturingNameChecks.valueTooLarge() || manfuacturingNameChecks.hasInvalidCharacters();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.MANF_NAME_INVALID_CODE);
    }
}
