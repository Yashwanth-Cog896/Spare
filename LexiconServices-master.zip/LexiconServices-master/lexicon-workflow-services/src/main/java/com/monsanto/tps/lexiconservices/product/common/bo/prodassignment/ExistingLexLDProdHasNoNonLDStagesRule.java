package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.LexiconProductNames;

public class ExistingLexLDProdHasNoNonLDStagesRule
        extends SimpleValidationRule {
    private final LexiconProductEntity existingLexProduct;
    private final LexiconProductNames lexProductNames;

    public ExistingLexLDProdHasNoNonLDStagesRule(LexiconProductEntity existingLexProduct,
                                                 LexiconProductNames lexProductNames) {
        this.existingLexProduct = existingLexProduct;
        this.lexProductNames = lexProductNames;
    }

    protected boolean preConditionsMet() {
        return existingLexProduct != null && lexProductNames != null;
    }

    protected boolean criteriaViolated() {
        return existingLexProduct.isLogicalDelete() && lexProductNames.hasNonDeletedStages();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.DEL_PROD_CONTAINS_NON_LD_STAGES_CODE);
    }
}
