package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonCountryXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonCountryXrefDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconCountryDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCountry;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidCountryException;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 2:18 PM
 */
@Component(value = "tPSCountryLookup")
public class TPSCountryLookup implements ApplicationContextAware {

    public static final String COUNTRY_NOT_VALID_ERROR = "The country is not valid in Field Breeding Systems";

    private static ApplicationContext context;

    @Resource
    private LexiconCountryDao lexiconCountryDao;

    @Resource
    private FbsCommonCountryXrefDao fbsCommonCountryXrefDao;

    private static TPSCountryLookup instance;
    private Map countries = new HashMap();
    private Map countriesByName = new HashMap();

    public static void resetInstance() {
        instance = null;
    }

    protected static void setInstance() {
        instance = (TPSCountryLookup) context.getBean("tPSCountryLookup");
    }

    public static TPSCountryLookup instance() {
        if (instance == null) {
            setInstance();
        }
        return instance;
    }

    public TPSCountry getCountry(String pubkey) throws InvalidCountryException {
        TPSCountry country = null;
        if (!countries.containsKey(pubkey)) {
            LexiconCountryEntity lexiconCountryEntity = lexiconCountryDao.getCountryByPubkey(pubkey);
            if (lexiconCountryEntity != null) {
                country = getCountry(lexiconCountryEntity);
            }
            cacheCountry(country, pubkey, true);
        }

        country = (TPSCountry) countries.get(pubkey);
        if (country == null || !country.existsInFieldBreedingSystems()) {
            throw new InvalidCountryException(COUNTRY_NOT_VALID_ERROR);
        }
        return country;
    }

    private TPSCountry getCountry(LexiconCountryEntity lexiconCountryEntity) {
        TPSCountry country = null;
        FbsCommonCountryXrefEntity countryXrefEntity = fbsCommonCountryXrefDao.get(lexiconCountryEntity.getPubkey());
        if (null != countryXrefEntity) {
            country = new TPSCountry(lexiconCountryEntity, countryXrefEntity.getMidasCountry().getId(), countryXrefEntity.getMirageCountry().getCode());
        }
        return country;
    }

    private void cacheCountry(TPSCountry country, String requestKey, boolean byPubkey) {
        if (country != null) {
            countries.put(country.getPublicKey(), country);
            countriesByName.put(country.getName(), country);
        } else if (byPubkey) {
            countries.put(requestKey, country);
        }
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    public static void setApplicationContextForUT(ApplicationContext applicationContext) {
        context = applicationContext;
    }
}
