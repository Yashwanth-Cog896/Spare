package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.LexiconProductNames;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;


/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 3, 2006
 * Time: 5:14:27 PM
 * To change this template use File | Settings | File Templates.
 */
public interface APCNExistingSyncProductValidationModel {
    LexiconProductEntity getLexProduct();

    LexiconProductNames getLexProductNames();

    FbsCommonProductXrefEntity getProductXref();

    MidasProductEntity getLinkedMidasProduct();

    MidasProductNamesCollection getMatchingMidasPN();

    MidasProductNamesCollection getGlobalPCNameRecords();
}
