package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/31/14
 * Time: 1:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductRelationshipHelper {
    //TODO Rename class
    private String manufacturingName;
    private String relationshipPubkey;
    private List<ProductRelationshipDTO> productRelationshipDTOList = new ArrayList<ProductRelationshipDTO>();

    public ProductRelationshipHelper() {
    }

    public ProductRelationshipHelper(String manufacturingName, String relationshipPubkey, List<ProductRelationshipDTO> productRelationshipDTOList) {
        this.manufacturingName = manufacturingName;
        this.relationshipPubkey = relationshipPubkey;
        this.productRelationshipDTOList = productRelationshipDTOList;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getRelationshipPubkey() {
        return relationshipPubkey;
    }

    public void setRelationshipPubkey(String relationshipPubkey) {
        this.relationshipPubkey = relationshipPubkey;
    }

    public List<ProductRelationshipDTO> getProductRelationshipDTOList() {
        return productRelationshipDTOList;
    }

    public void setProductRelationshipDTOList(List<ProductRelationshipDTO> productRelationshipDTOList) {
        this.productRelationshipDTOList = productRelationshipDTOList;
    }
}
