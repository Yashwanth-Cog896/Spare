package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasBrandEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/7/14
 * Time: 2:54 PM
 */
public interface MidasBrandDao extends GenericDao<MidasBrandEntity,Long> {
    MidasBrandEntity getMidasBrandForPubKey(String lexiconBrandPubkey);
}
