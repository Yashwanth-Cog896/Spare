package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import org.apache.commons.collections.comparators.ComparableComparator;

import java.util.Collection;
import java.util.Comparator;
import java.util.SortedSet;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 2:35 PM
 */
public class AscendingGermplasmComparator implements Comparator<MidasProductGermplasmDTO> {

    public int compare(MidasProductGermplasmDTO a, MidasProductGermplasmDTO b) {
        Long idA = a.getGermplasmId();
        Long idB = b.getGermplasmId();
        return ComparableComparator.getInstance().compare(idA, idB);
    }
}
