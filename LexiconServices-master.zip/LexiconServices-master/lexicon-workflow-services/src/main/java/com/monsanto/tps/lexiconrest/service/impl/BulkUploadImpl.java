package com.monsanto.tps.lexiconrest.service.impl;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.productstage.EditProductStageService;
import com.monsanto.tps.lexicon.productstage.EditProductStageServiceRequest;
import com.monsanto.tps.lexicon.productstage.EditProductStageServiceResponse;
import com.monsanto.tps.lexicon.productstage.ProductStageRequest;
import com.monsanto.tps.lexicon.productstage.ProductStageServiceBatchResponse;
import com.monsanto.tps.lexicon.productstage.add.AddProductStageService;
import com.monsanto.tps.lexicon.productstage.add.AddProductStageServiceRequest;
import com.monsanto.tps.lexicon.productstage.add.AddProductStageServiceResponse;
import com.monsanto.tps.lexiconrest.BrandDTO;
import com.monsanto.tps.lexiconrest.CommTraitDTO;
import com.monsanto.tps.lexiconrest.CountryDTO;
import com.monsanto.tps.lexiconrest.ExcelDTO;
import com.monsanto.tps.lexiconrest.ProductDTO;
import com.monsanto.tps.lexiconrest.StageDTO;
import com.monsanto.tps.lexiconrest.loader.ImportModel;
import com.monsanto.tps.lexiconrest.loader.ImportProductModel;
import com.monsanto.tps.lexiconrest.loader.MonsantoProductBean;
import com.monsanto.tps.lexiconrest.service.BatchResponse;
import com.monsanto.tps.lexiconrest.service.BulkUpload;
import com.monsanto.tps.lexiconrest.service.dto.AddProductStatusResponse;
import com.monsanto.tps.lexiconrest.service.dto.EditProductStatusResponse;
import com.monsanto.tps.lexiconrest.service.query.*;
import org.apache.cxf.feature.Features;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

/**
 * Created by SMALA on 11/6/2014.
 */
@Component("bulkUpload")
@Transactional(propagation = Propagation.REQUIRED)
@Features(features = "org.apache.cxf.feature.LoggingFeature")
public class BulkUploadImpl implements BulkUpload {

    private static final String EMPTY_STRING = " ";
    public static final String REVALIDATE_COMMIT = "revalidate/commit";
    public static final String EXCEL_UPLOAD = "excelUpload";
    private Logger logger = Logger.getLogger(BulkUploadImpl.class);
    private Timestamp timestamp1;
    private Timestamp timestamp5;


    @Resource
    BulkUploadDataSheetParserImpl bulkUploadDataSheetParserImpl;

    @Resource
    private EditProductStageService editProductStageService;

    @Resource
    private AddProductStageService addProductStageService;

    @Override
    public List<ExcelDTO> uploadProductsInformation(@Multipart MultipartBody multipartBody, Boolean validate, String userName) throws Exception {
        Timestamp timestamp1 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("Before handleFileUpload" + timestamp1);
        List<Attachment> allAttachments = multipartBody.getAllAttachments();
        List<ImportModel> productModel = handleFileUpload(allAttachments.get(0), validate);
        Timestamp timestamp2 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("Before loadPubkeys" + timestamp2);
        MonsantoProductBean[] products = loadPubkeys(productModel, EXCEL_UPLOAD);
        Timestamp timestamp3 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("Before callLexiconCXFService" + timestamp3);
        com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse responseStatuses = callLexiconCXFService(validate, products, userName);
        Timestamp timestamp4 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("Before mapResponse" + timestamp4);
        return mapResponse(products, responseStatuses);
    }

    @Override
    @ResponseBody
    public List<ExcelDTO> uploadProducts(@RequestBody List<ExcelDTO> excelData, Boolean validate, String userName) throws Exception {
        logger.info("$BulkUpload$ Total number of products processed = " + excelData.size());
        timestamp1 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("$BulkUpload$ Before uploadProducts" + timestamp1);
        List<ImportModel> productModel = buildProductModel(excelData);
        Timestamp timestamp2 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("$BulkUpload$ Before LoadPubKeys" + timestamp2 + "timeDifference " + (timestamp2.getTime()-timestamp1.getTime()));
        MonsantoProductBean[] products = loadPubkeys(productModel,REVALIDATE_COMMIT);
        Timestamp timestamp3 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("$BulkUpload$ Before callLexiconCXFService" + timestamp3 + "timeDifference " + (timestamp3.getTime() - timestamp2.getTime()));
        com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse responseStatuses = callLexiconCXFService(validate, products, userName);
        Timestamp timestamp4 = new Timestamp(Calendar.getInstance().getTime().getTime());
        logger.info("$BulkUpload$ After callLexiconCXFService" + timestamp4+ "timeDifference " + (timestamp4.getTime()-timestamp3.getTime()));
        return mapResponse(products, responseStatuses);
    }

    private List<ImportModel> buildProductModel(List<ExcelDTO> excelData) {
        List<ImportModel> productModel = new ArrayList<ImportModel>();
        for (ExcelDTO excelDTO : excelData) {
            ImportProductModel importProductModel = new ImportProductModel();
            importProductModel.setBatchId(excelDTO.getBatchId());
            importProductModel.setBrand(excelDTO.getBrand());
            importProductModel.setCommercialMaturity(excelDTO.getCommercialMaturity().intValue());
            importProductModel.setCommercialName(excelDTO.getCommercialName());
            importProductModel.setCountry(excelDTO.getCountryName());
            importProductModel.setStage(excelDTO.getStageName());
            importProductModel.setPrecommercialName(excelDTO.getPreCommercialName());
            importProductModel.setCommercialTrait(excelDTO.getCommercialTrait());
            importProductModel.setProductKind(excelDTO.getProductKind());
            ImportModel importModel = new ImportModel(excelDTO.getPreCommercialName(), importProductModel);
            productModel.add(importModel);
        }
        return productModel;
    }

    private List<ExcelDTO> mapResponse(MonsantoProductBean[] products, com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse responseStatuses) {
        Map<Integer, MonsantoProductBean> resultMap = new HashMap<Integer, MonsantoProductBean>();
        for (MonsantoProductBean productBea : products) {
            resultMap.put(productBea.getBatchId(), productBea);
        }
        List<ExcelDTO> excelDTOList = new ArrayList<ExcelDTO>();
        if (responseStatuses.getEditProductStageResponseList() != null) {
            for (EditProductStatusResponse editProductStatusResponse : responseStatuses.getEditProductStageResponseList()) {
                MonsantoProductBean res = resultMap.get(editProductStatusResponse.getBatchID());
                excelDTOList.add(createExcelDTO(res, editProductStatusResponse));
            }
        }
        if (responseStatuses.getAddProductStageResponseList() != null) {
            for (AddProductStatusResponse addProductStatusResponse : responseStatuses.getAddProductStageResponseList()) {
                MonsantoProductBean res = resultMap.get(addProductStatusResponse.getBatchID());
                excelDTOList.add(createExcelDTO(res, addProductStatusResponse));
            }
        }
        sortProductsBasedOnBatchId(excelDTOList);
        return excelDTOList;
    }

    private void sortProductsBasedOnBatchId(List<ExcelDTO> excelDTOList) {
        Collections.sort(excelDTOList, new Comparator<ExcelDTO>() {
            @Override
            public int compare(ExcelDTO o1, ExcelDTO o2) {
                return o1 != null ?
                        (o2 != null ? o1.getBatchId() - o2.getBatchId() : o1.getBatchId())
                        : (o2 != null ? o2.getBatchId() : 0);
            }
        });
    }

    private com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse callLexiconCXFService
            (Boolean validate, MonsantoProductBean[] products, String userLoginId) throws Exception {
        MonsantoProductBean[] productBeansForAdd = new MonsantoProductBean[products.length];
        MonsantoProductBean[] productBeansForEdit = new MonsantoProductBean[products.length];
        com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse productStageServiceBatchResponse = new com.monsanto.tps.lexiconrest.service.dto.ProductStageServiceBatchResponse();
        int i = 0;
        int j = 0;
        for (MonsantoProductBean monsantoProductBean : products) {
            String brandName = monsantoProductBean.getBrandDTO().getBrandName();
            String countryName = monsantoProductBean.getCountryDTO().getCountryName();
            String commercialName = monsantoProductBean.getCommercialName();
            boolean isCommercialNameExists = new ProductStageCommercialQuery(commercialName, brandName, countryName).entityExists();
            String preCommercialName = monsantoProductBean.getProductDTO().getPreCommercialName();
            boolean isPreComlNameWithBrandMonsantoExists = new ProductStagePreComlCountryQuery(preCommercialName, "MONSANTO", countryName).entityExists();

          if (isCommercialNameExists) {
                boolean isPreComlNameExistsForMonsantoBrandExits = new ProductStagePreComlQuery(preCommercialName, brandName,countryName,commercialName).entityExists();
                if (isPreComlNameExistsForMonsantoBrandExits) {
                    productBeansForEdit[i++] = monsantoProductBean;
                }else if (isPreComlNameWithBrandMonsantoExists) {
                  productBeansForEdit[i++] = monsantoProductBean;
                } else {
                    productBeansForAdd[j++] = monsantoProductBean;
                }
            } else {
                boolean isPreComlNameWithBrandCountryExists = new ProductStagePreComlBrandCountryQuery(preCommercialName, brandName, countryName).entityExists();

                if (isPreComlNameWithBrandCountryExists) {
                    productBeansForEdit[i++] = monsantoProductBean;
                } else if (isPreComlNameWithBrandMonsantoExists) {
                    productBeansForEdit[i++] = monsantoProductBean;
                } else {
                    productBeansForAdd[j++] = monsantoProductBean;
                }
            }
        }
        if (productBeansForAdd[0] != null) {
            productStageServiceBatchResponse.setAddProductStageResponseList(callLexiconAddCXFService(validate, productBeansForAdd, userLoginId));
        }
        if (productBeansForEdit[0] != null) {
            productStageServiceBatchResponse.setEditProductStageResponseList(callLexiconEditCXFService(validate, productBeansForEdit, userLoginId));
        }
        return productStageServiceBatchResponse;
    }

    private List<EditProductStatusResponse> callLexiconEditCXFService(Boolean validate, MonsantoProductBean[] products, String userLoginId) throws Exception {
        EditProductStageServiceRequest editProductStageServiceRequest = mapRequestForEdit(validate, products, userLoginId);
        ProductStageServiceBatchResponse productStageServiceResponse = editProductStageService.editProduct(editProductStageServiceRequest);
        List<EditProductStatusResponse> productStageResponseStatus = mapEditResponse(productStageServiceResponse);
        return productStageResponseStatus;
    }

    private ExcelDTO createExcelDTO(MonsantoProductBean productBeanResponse, EditProductStatusResponse editProductStatusResponse) {
        ExcelDTO resultantExcelDTO = new ExcelDTO();
        resultantExcelDTO.setPreCommercialName(productBeanResponse.getProductDTO().getPreCommercialName());
        resultantExcelDTO.setCommercialName(productBeanResponse.getCommercialName());
        resultantExcelDTO.setBrand(productBeanResponse.getBrandDTO().getBrandName());
        resultantExcelDTO.setStageName(productBeanResponse.getStageDTO().getStageName());
        resultantExcelDTO.setCountryName(productBeanResponse.getCountryDTO().getCountryName());
        resultantExcelDTO.setCommercialTrait(productBeanResponse.getCommTraitDTO().getStackAbbr());
        resultantExcelDTO.setCommercialMaturity(Long.valueOf(productBeanResponse.getCommercialMaturity()));
        resultantExcelDTO.setBatchId(editProductStatusResponse.getBatchID());
        resultantExcelDTO.setSuccess(editProductStatusResponse.getStatus().toString());
        resultantExcelDTO.setErrorMessage(editProductStatusResponse.getErrorMessages());
        resultantExcelDTO.setInfoMessage(editProductStatusResponse.getInfoMessages());
        resultantExcelDTO.setProductKind(editProductStatusResponse.getProductKind());
        return resultantExcelDTO;
    }

    private ExcelDTO createExcelDTO(MonsantoProductBean productBeanResponse, AddProductStatusResponse addProductStatusResponse) {
        ExcelDTO resultantExcelDTO = new ExcelDTO();
        resultantExcelDTO.setPreCommercialName(productBeanResponse.getProductDTO().getPreCommercialName());
        resultantExcelDTO.setCommercialName(productBeanResponse.getCommercialName());
        resultantExcelDTO.setBrand(productBeanResponse.getBrandDTO().getBrandName());
        resultantExcelDTO.setStageName(productBeanResponse.getStageDTO().getStageName());
        resultantExcelDTO.setCountryName(productBeanResponse.getCountryDTO().getCountryName());
        resultantExcelDTO.setCommercialTrait(productBeanResponse.getCommTraitDTO().getStackAbbr());
        resultantExcelDTO.setCommercialMaturity(Long.valueOf(productBeanResponse.getCommercialMaturity()));
        resultantExcelDTO.setBatchId(addProductStatusResponse.getBatchID());
        resultantExcelDTO.setSuccess(addProductStatusResponse.getStatus().toString());
        resultantExcelDTO.setErrorMessage(addProductStatusResponse.getErrorMessages());
        resultantExcelDTO.setInfoMessage(addProductStatusResponse.getInfoMessages());
        resultantExcelDTO.setProductKind(addProductStatusResponse.getProductKind());
        return resultantExcelDTO;
    }

    private List<ImportModel> handleFileUpload(Attachment attachment, Boolean validate)
            throws Exception {
        InputStream inputStream = null;
        try {

            inputStream = attachment.getDataHandler().getInputStream();
            return bulkUploadDataSheetParserImpl.createWorkBook(inputStream);
        } catch (IOException e) {
            throw new IOException(e.getMessage());
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new IOException(e.getMessage());
                }
            }
        }
    }

    private List<AddProductStatusResponse> callLexiconAddCXFService(Boolean validate, MonsantoProductBean[] products, String userLoginId) throws Exception {
        AddProductStageServiceRequest addProductStageServiceRequest = mapRequestForAdd(validate, products, userLoginId);
        ProductStageServiceBatchResponse productStageServiceResponse = addProductStageService.addProduct(addProductStageServiceRequest);
        List<AddProductStatusResponse> productStageResponseStatus = mapAddResponse(productStageServiceResponse);
        return productStageResponseStatus;
    }

    private List<EditProductStatusResponse> mapEditResponse(ProductStageServiceBatchResponse productStageServiceResponse) {
        List<EditProductStatusResponse> responseList = new ArrayList<EditProductStatusResponse>();
        for (EditProductStageServiceResponse response : productStageServiceResponse.getEditProductStageResponseList()) {
            responseList.add(new EditProductStatusResponse(response.getAutoProductStageTypeAbbr(), response.getAutoBrandName(), response.getAutoComlName(),
                    response.getBatchID(), response.getInfoMessages(), response.getErrorMessages(), response.getProductPubkey(),
                    response.getStagePubkey(), response.getExceptionCodePubkey(), response.getStatus(), response.getProductKindName()));
        }
        return responseList;
    }


    private List<AddProductStatusResponse> mapAddResponse(ProductStageServiceBatchResponse productStageServiceResponse) {
        List<AddProductStatusResponse> responseList = new ArrayList<AddProductStatusResponse>();
        for (AddProductStageServiceResponse response : productStageServiceResponse.getAddProductStageResponseList()) {
            responseList.add(new AddProductStatusResponse(response.getBatchID(), response.getInfoMessages(), response.getErrorMessages(),
                    response.getProductPubkey(), response.getStagePubkey(), response.getExceptionCodePubkey(), response.getStatus(), response.getProductKindName()));
        }
        return responseList;
    }

    //TODO - Fix this. We need to have the abstract class and extend the Edit/Addd request from that
    private AddProductStageServiceRequest mapRequestForAdd(Boolean validate, MonsantoProductBean[] products, String userLoginId) throws Exception {
        AddProductStageServiceRequest addProductStageServiceRequest = new AddProductStageServiceRequest();
        if (!(products.length > 0)) {
            throw new Exception("No records to process");
        }
        addProductStageServiceRequest.setUserLoginId(userLoginId);
        List<ProductStageRequest> productStageRequestList = new ArrayList<ProductStageRequest>();
        for (MonsantoProductBean productBean : products) {
            if (productBean != null) {
                ProductStageRequest productStageRequest = new ProductStageRequest();
                productStageRequest.setActive(productBean.isActive());
                productStageRequest.setBatchId(productBean.getBatchId());
                productStageRequest.setBrandPubkey(productBean.getBrandDTO().getBrandPubkey());
                productStageRequest.setCommercialMaturity(productBean.getCommercialMaturity());
                productStageRequest.setCommercialName(productBean.getCommercialName());
                productStageRequest.setCountryPubkey(productBean.getCountryDTO().getCountryPubkey());
                productStageRequest.setOecdName(productBean.getOecdName());
                productStageRequest.setPreferredName(false);
                productStageRequest.setPrimary(productBean.isPrimary());
                productStageRequest.setProductNamePubkey(productBean.getProductNamePubkey());
                productStageRequest.setProductPubkey(productBean.getProductPubkey());
                productStageRequest.setStageTypePubkey(productBean.getStageDTO().getStagePubkey());
                productStageRequest.setTraitStackPubkey(productBean.getCommTraitDTO().getCommercialTraitStackPubkey());
                productStageRequest.setValidationOnly(validate);
                productStageRequest.setProductKindName(productBean.getProductKind());
                productStageRequestList.add(productStageRequest);
                addProductStageServiceRequest.setRequests(productStageRequestList);
            }
        }
        return addProductStageServiceRequest;
    }

    private EditProductStageServiceRequest mapRequestForEdit(Boolean validate, MonsantoProductBean[] products, String userLoginId) throws Exception {
        EditProductStageServiceRequest editProductStageServiceRequest = new EditProductStageServiceRequest();
        if (!(products.length > 0)) {
            throw new Exception("No records to process");
        }

        editProductStageServiceRequest.setUserLoginId(userLoginId);
        List<ProductStageRequest> productStageRequestList = new ArrayList<ProductStageRequest>();
        for (MonsantoProductBean productBean : products) {
            if (productBean != null) {
                ProductStageRequest productStageRequest = new ProductStageRequest();
                productStageRequest.setActive(productBean.isActive());
                productStageRequest.setBatchId(productBean.getBatchId());
                productStageRequest.setBrandPubkey(productBean.getBrandDTO().getBrandPubkey());
                productStageRequest.setCommercialMaturity(productBean.getCommercialMaturity());
                productStageRequest.setCommercialName(productBean.getCommercialName());
                productStageRequest.setCountryPubkey(productBean.getCountryDTO().getCountryPubkey());
                productStageRequest.setOecdName(productBean.getOecdName());
                productStageRequest.setPreferredName(false);
                productStageRequest.setPrimary(productBean.isPrimary());
                productStageRequest.setProductNamePubkey(productBean.getProductNamePubkey());
                productStageRequest.setProductPubkey(productBean.getProductPubkey());
                productStageRequest.setStageTypePubkey(productBean.getStageDTO().getStagePubkey());
                productStageRequest.setTraitStackPubkey(productBean.getCommTraitDTO().getCommercialTraitStackPubkey());
                productStageRequest.setProductKindName(productBean.getProductKind());
                productStageRequest.setValidationOnly(validate);
                productStageRequestList.add(productStageRequest);
                editProductStageServiceRequest.setRequests(productStageRequestList);
            }
        }
        return editProductStageServiceRequest;
    }

    private MonsantoProductBean[] loadPubkeys(List<ImportModel> productModels,String action) throws WrappingException {
        MonsantoProductBean[] products = new MonsantoProductBean[productModels.size()];
        int counter = 0;
        int batchId = 1;
        for (ImportModel model : productModels) {
            List<BrandDTO> brandDTOs = new BrandPubkeyQuery(new String[]{model.getProductModel().getBrand()}).find();
            List<CommTraitDTO> commTraitDTOs = new CommercialTraitQuery(new String[]{model.getProductModel().getCommercialTrait()},
                    new String[]{model.getProductModel().getPrecommercialName()}).find();
            List<CountryDTO> countryDTOs = new CountryPubkeyQuery(new String[]{model.getProductModel().getCountry()}).find();
            List<ProductDTO> productDTOs = new ProductPubkeyQuery(new String[]{model.getProductModel().getPrecommercialName()}).find();
            List<StageDTO> stageDTOs = new StagePubkeyQuery(new String[]{model.getProductModel().getStage()}).find();
            List<String> associatedCommercialNamesWithProductId = new ProductStagePubkeyQuery(new String[]{model.getProductModel().getPrecommercialName()}).find();
            List<String> productNamePubKeyList = new ProductStageProductNamePubKeyQuery(new String[]{model.getProductModel().getPrecommercialName()}, new String[]{model.getProductModel().getCountry()}).find();
            MonsantoProductBean monsantoProductBean = new MonsantoProductBean();
            monsantoProductBean.setActive(true);
            if (productDTOs.isEmpty()) {
                monsantoProductBean.setProductPubkey(EMPTY_STRING);
                monsantoProductBean.setProductDTO(new ProductDTO(model.getProductModel().getPrecommercialName(), EMPTY_STRING));
            } else {
                monsantoProductBean.setProductPubkey(productDTOs.get(0).getProductPubkey());
                monsantoProductBean.setProductDTO(productDTOs.get(0));
            }
            if (brandDTOs.isEmpty()) {
                monsantoProductBean.setBrandDTO(new BrandDTO(EMPTY_STRING, model.getProductModel().getBrand()));
            } else {
                monsantoProductBean.setBrandDTO(brandDTOs.get(0));
            }
            if (stageDTOs.isEmpty()) {
                monsantoProductBean.setStageDTO(new StageDTO(model.getProductModel().getStage(), EMPTY_STRING));
            } else {
                monsantoProductBean.setStageDTO(stageDTOs.get(0));
            }
            if (countryDTOs.isEmpty()) {
                monsantoProductBean.setCountryDTO(new CountryDTO(EMPTY_STRING, model.getProductModel().getCountry()));
            } else {
                monsantoProductBean.setCountryDTO(countryDTOs.get(0));
            }

            if (commTraitDTOs.isEmpty()) {
                monsantoProductBean.setCommTraitDTO(new CommTraitDTO(EMPTY_STRING, model.getProductModel().getCommercialTrait()));
            } else {
                monsantoProductBean.setCommTraitDTO(commTraitDTOs.get(0));
            }
            if (productNamePubKeyList.isEmpty()) {
                monsantoProductBean.setProductNamePubkey(EMPTY_STRING);
            } else {
                monsantoProductBean.setProductNamePubkey(productNamePubKeyList.get(0));
            }
            monsantoProductBean.setCommercialName(model.getProductModel().getCommercialName());
            monsantoProductBean.setAssociatedCommercialNameWithProductId(associatedCommercialNamesWithProductId);
            monsantoProductBean.setCommercialMaturity(String.valueOf(model.getProductModel().getCommercialMaturity()));
            monsantoProductBean.setProductKind(model.getProductModel().getProductKind());
            if (action.equals(EXCEL_UPLOAD)) {
                monsantoProductBean.setBatchId(batchId);
                batchId++;
            } else {
                monsantoProductBean.setBatchId(model.getProductModel().getBatchId());
            }

            products[counter++] = monsantoProductBean;

        }
        return products;
    }

    public void setEditProductStageService(EditProductStageService editProductStageService) {
        this.editProductStageService = editProductStageService;
    }


    public List<BatchResponse> createBatchRequest(@Multipart MultipartBody multipartBody, Boolean validate, String userName) throws Exception {
        List<Attachment> allAttachments = multipartBody.getAllAttachments();
        List<ImportModel> productModel = handleFileUpload(allAttachments.get(0), validate);

        List<BatchResponse> response = createBatches(productModel);
        return response;
    }

    public List<BatchResponse> createBatches(List<ImportModel> productModel) {
        List<BatchResponse> response = new ArrayList<BatchResponse>();
        BigDecimal sizeOfList = new BigDecimal(productModel.size());
        BigDecimal constant = new BigDecimal(20);
        double batches = Math.ceil(sizeOfList.divide(constant).floatValue());

        int firstElementInSubList = 0;
        int lastElementInSublist = 0;
        int i;
        for (i = 1; i < batches; i++) {
            lastElementInSublist = 20 + firstElementInSubList;
            List<ImportModel> productModelSubList = productModel.subList(firstElementInSubList, lastElementInSublist);
            BatchResponse batchResponse = new BatchResponse(i - 1, productModelSubList);
            response.add(batchResponse);
            firstElementInSubList = lastElementInSublist;
        }
        BatchResponse batchResponse = new BatchResponse(i - 1, productModel.subList(lastElementInSublist, productModel.size()));
        response.add(batchResponse);
        return response;
    }

}

