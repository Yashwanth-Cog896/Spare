package com.monsanto.tps.lexiconservices.manufacturing.line.edit.service.impl;

import com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain.EditManufacturingLineRichRequest;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions.EditManufacturingLineException;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.ProductRelationshipDao;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;

@Component(value = "editManufacturingLineRichRequestProcessor")
public class EditManufacturingLineRichRequestProcessor {

  private Logger logger = Logger.getLogger(EditManufacturingLineRichRequestProcessor.class);

  @Resource
  private ProductRelationshipDao productRelationshipDao;

  @Resource
  private BaseProductDao baseProductDao;

  protected EditManufacturingLineRichRequest createEditManufacturingLineRichRequest(EditManufacturingLineRequest request) throws EditManufacturingLineException {
    try {
      logger.info("Processing EditManufacturingLineRichRequestProcessor request");
      EditManufacturingLineRichRequest editManufacturingLineRichRequest = new EditManufacturingLineRichRequest();
      String targetManufacturingName = request.getTargetManufacturingName();
      String newManufacturingName = request.getNewManufacturingName();
      String newVarietyName = request.getNewVarietyName();
      BaseProductEntity requestedBaseProduct = baseProductDao.findBaseProductByManufacturingName(targetManufacturingName);
      ProductRelationshipEntity requestedManufacturingLine = productRelationshipDao.findManufacturingLineByManufacturingName(targetManufacturingName);
      ProductRelationshipEntity newManufacturingNamesManufacturingAttributes = productRelationshipDao.findManufacturingAttributesByManufacturingName(newManufacturingName);
      ProductRelationshipEntity newVarietyNamesManufacturingAttributes = productRelationshipDao.findManufacturingAttributesByVarietyName(newVarietyName);
      List<ProductRelationshipEntity> requestedManufacturingLinesProducts = productRelationshipDao.findProductRelationshipProductsByManufacturingName(targetManufacturingName);
      editManufacturingLineRichRequest.setTargetManufacturingName(targetManufacturingName);
      editManufacturingLineRichRequest.setNewManufacturingName(newManufacturingName);
      editManufacturingLineRichRequest.setNewManufacturingNamesManufacturingAttributes(newManufacturingNamesManufacturingAttributes);
      editManufacturingLineRichRequest.setNewVarietyName(newVarietyName);
      editManufacturingLineRichRequest.setNewVarietyNamesManufacturingAttributes(newVarietyNamesManufacturingAttributes);
      editManufacturingLineRichRequest.setRequestedBaseProduct(requestedBaseProduct);
      editManufacturingLineRichRequest.setRequestedManufacturingLine(requestedManufacturingLine);
      editManufacturingLineRichRequest.setRequestedManufacturingLinesProducts(requestedManufacturingLinesProducts);
      return editManufacturingLineRichRequest;
    } catch (Exception e) {
      logger.error("Error while processing EditManufacturingLineRichRequestProcessor request",e);
      throw new EditManufacturingLineException(e.getMessage(), e.getCause());
    }
  }
}