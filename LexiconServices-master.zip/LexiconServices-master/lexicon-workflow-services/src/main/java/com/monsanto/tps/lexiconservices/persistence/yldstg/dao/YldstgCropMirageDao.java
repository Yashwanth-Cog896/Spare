package com.monsanto.tps.lexiconservices.persistence.yldstg.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCropEntity;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.domain.MapCropMirageDto;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/3/14
 * Time: 10:22 AM
 * To change this template use File | Settings | File Templates.
 */
public interface YldstgCropMirageDao extends GenericDao<MidasCropEntity,Long> {
  public MapCropMirageDto findByCropInMapCropMirage(String midasName);
}