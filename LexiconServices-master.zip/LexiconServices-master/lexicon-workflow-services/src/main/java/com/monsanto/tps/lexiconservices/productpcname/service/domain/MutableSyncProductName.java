package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ExceptionCodeEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistance.yldstg.domain.MapProductMirageEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 10:09 AM
 */
public class MutableSyncProductName {
    private MutableSyncProduct product;
    private TPSBrand brand;
    private TPSCountry country;
    private String comlName;
    private FbsCommonProductNameXrefEntity nameXref;
    private MidasProductNameEntity midasComlPN;
    private ProductDTO mirageProduct;
    private MapProductMirageEntity yieldMartProduct;
    private LexiconProductStageEntity lexProdStage;
    private ExceptionCodeEntity exceptionCode;

    public void setProduct(MutableSyncProduct syncProduct) {
        this.product = syncProduct;
    }

    public void setBrand(TPSBrand brand) {
        this.brand = brand;
    }

    public void setCountry(TPSCountry country) {
        this.country = country;
    }

    public void setComlName(String comlName) {
        this.comlName = comlName;
    }

    public MutableSyncProduct getProduct() {
        return product;
    }

    public TPSBrand getBrand() {
        return brand;
    }

    public TPSCountry getCountry() {
        return country;
    }

    public String getComlName() {
        return comlName;
    }

    public void setNameXref(FbsCommonProductNameXrefEntity nameXref) {
        this.nameXref = nameXref;
    }

    public void setMidasComlPN(MidasProductNameEntity midasComlPN) {
        this.midasComlPN = midasComlPN;
    }

    public String getPreComlName() {
        return product.getPreComlName();
    }

    public String getMirageProductName() {
        return (StringUtils.isNullOrEmpty(getComlName()) ? getPreComlName() : getComlName());
    }

    public void setMirageProduct(ProductDTO mirageProduct) {
        this.mirageProduct = mirageProduct;
    }

    public FbsCommonProductNameXrefEntity getNameXref() {
        return nameXref;
    }

    public MidasProductNameEntity getMidasComlPN() {
        return midasComlPN;
    }

    public ProductDTO getMirageProduct() {
        return mirageProduct;
    }

    public void setYieldMartProduct(MapProductMirageEntity yieldMartProduct) {
        this.yieldMartProduct = yieldMartProduct;
    }

    public MapProductMirageEntity getYieldMartProduct() {
        return yieldMartProduct;
    }

    public void setLexProdStage(LexiconProductStageEntity lexProdStage) {
        this.lexProdStage = lexProdStage;
    }

    public LexiconProductStageEntity getLexProdStage() {
        return lexProdStage;
    }

    public boolean isRequestedVegetableProduct() {
        return product.isRequestedVegetableProduct();
    }

    public TPSCrop getCrop() {
        return product.getCrop();
    }

    public void setExceptionCode(ExceptionCodeEntity exceptionCode) {
        this.exceptionCode = exceptionCode;
    }


    public LexiconProductEntity getLexProduct() {
        return product.getLexProduct();
    }

    public boolean isParentProduct() {
        return product.isParentProduct();
    }

    public MidasProductEntity getMidasProduct() {
        return product.getMidasProduct();
    }

    public MidasProductNamesCollection getGlobalPCNameRecords() {
        return product.getGlobalPCNameRecords();
    }

    public GeneticMaterialEntity getMirageGeneticMaterial() {
        return product.getMirageGeneticMaterial();
    }

    public ProductGermplasmCollection getProductGermplasm() {
        return product.getProductGermplasm();
    }
}
