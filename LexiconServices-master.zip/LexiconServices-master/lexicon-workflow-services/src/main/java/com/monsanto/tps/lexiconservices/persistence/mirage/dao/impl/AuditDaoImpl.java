package com.monsanto.tps.lexiconservices.persistence.mirage.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageAuditEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.AuditDao;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/24/14
 * Time: 10:55 AM
 */
public class AuditDaoImpl extends GenericDaoImpl<MirageAuditEntity, Long> implements AuditDao {
    public static final String LEX_USER = "LexiconServices";

    public AuditDaoImpl(Class entityClass) {
        super(entityClass);
    }


    public MirageAuditEntity save(String auditEvent) {
        MirageAuditEntity entity = new MirageAuditEntity();
        entity.setDate(new Date());
        entity.setUser(LEX_USER);
        entity.setClient(LEX_USER);
        entity.setEvent(auditEvent);
        entity.setEventRemark(auditEvent);
        entity.setEventTag(auditEvent);
        Long id = (Long) getSessionFactory().getCurrentSession().save(entity);
        return get(id);
    }
}
