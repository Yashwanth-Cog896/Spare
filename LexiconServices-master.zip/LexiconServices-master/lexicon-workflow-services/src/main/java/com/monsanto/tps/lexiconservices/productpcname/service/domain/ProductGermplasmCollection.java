package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignedGermplasm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/31/14
 * Time: 9:51 AM
 */
public class ProductGermplasmCollection {

    private final GermplasmCollection germplasmCollection;

    private final Map<Long, Boolean> preferredMap;

    public ProductGermplasmCollection() {
        this.germplasmCollection = new GermplasmCollection();
        preferredMap = new HashMap();
    }

    public ProductGermplasmCollection(List<MidasProductGermplasmDTO> productGermplasms) {
        this.germplasmCollection = new GermplasmCollection(productGermplasms);
        preferredMap = new HashMap();
        for (MidasProductGermplasmDTO productGermplasm : productGermplasms) {
            preferredMap.put(productGermplasm.getGermplasmId(), productGermplasm.isPreferred());
        }
    }

    public ProductGermplasmCollection(List<MidasProductGermplasmDTO> germplasms, List<AssignedGermplasm> assignedGermplasms) {
        this.germplasmCollection = new GermplasmCollection(germplasms);
        preferredMap = new HashMap();
        for (AssignedGermplasm assignedGermplasm : assignedGermplasms) {
            preferredMap.put(assignedGermplasm.getGermplasmId(), assignedGermplasm.isPreferred());
        }
    }

    public GermplasmCollection getGermplasmCollection() {
        return germplasmCollection;
    }

    public Map<Long, Boolean> getPreferredMap() {
        return preferredMap;
    }

    public int getPreferredCount() {
        int preferredCount = 0;
        for (Map.Entry<Long, Boolean> entry : preferredMap.entrySet()) {
            if (entry.getValue().booleanValue()) {
                preferredCount++;
            }
        }
        return preferredCount;
    }

    public void addGermplasms(ProductGermplasmCollection productGermplasmCollection) {
        germplasmCollection.addGermplasms(productGermplasmCollection.germplasmCollection.getGermplasms());
        preferredMap.putAll(productGermplasmCollection.preferredMap);
    }

    public boolean isPreferred(Long germplasmId) {
        Boolean isPreferred = preferredMap.get(germplasmId);
        if (isPreferred == null) {
            isPreferred = Boolean.FALSE;
        }
        return isPreferred;
    }


    public MidasProductGermplasmDTO getFinishedGermplasm() {
        return germplasmCollection.getFinishedGermplasm();

    }

    public int numGermplasm() {
        return germplasmCollection.numGermplasm();
    }

    public InbredHybridEnum getInbredHybridType() {
        return germplasmCollection.getInbredHybridType();
    }

    public String getAOwnerProgRefID() {
        return germplasmCollection.getAOwnerProgRefID();

    }

    public String getAnyEventDisplay() {
        return germplasmCollection.getAnyEventDisplay();
    }

    public boolean isAnyTransgenic() {
        return germplasmCollection.isAnyTransgenic();

    }

    public void addGermplasm(MidasProductGermplasmDTO germplasm) {
        germplasmCollection.addGermplasm(germplasm);
    }

    public MidasProductGermplasmDTO getGermplasmByID(long germplasmID) {
        return germplasmCollection.getGermplasmByID(germplasmID);
    }
}
