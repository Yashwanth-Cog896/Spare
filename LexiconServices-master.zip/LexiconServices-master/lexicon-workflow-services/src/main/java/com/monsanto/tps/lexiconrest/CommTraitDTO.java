package com.monsanto.tps.lexiconrest;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CommTraitDTO {

    private String commercialTraitStackPubkey;
    private String stackAbbr;

    public CommTraitDTO(String commercialTraitStackPubkey, String stackAbbr) {
        this.commercialTraitStackPubkey = commercialTraitStackPubkey;
        this.stackAbbr = stackAbbr;
    }

    public String getCommercialTraitStackPubkey() {
        return commercialTraitStackPubkey;
    }

    public String getStackAbbr() {
        return stackAbbr;
    }
}