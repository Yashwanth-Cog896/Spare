package com.monsanto.tps.lexiconservices.crop.processor;

import com.monsanto.tps.lexiconservices.crop.domain.BayerCode;
import com.monsanto.tps.lexiconservices.crop.domain.Crop;
import com.monsanto.tps.lexiconservices.crop.domain.ScientificName;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper.SegregateCrop;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 12/20/13
 * Time: 10:24 AM
 */
public class CropDesegregator {

  private final Map<String, Crop> cropMap = new LinkedHashMap<String, Crop>();
  private final Map<String, BayerCode> bayercodeMap = new HashMap<String, BayerCode>();
  private final Map<String, List<ScientificName>> scientificNameMap = new HashMap<String, List<ScientificName>>();
  private final List<SegregateCrop> segregateCrops;

  public CropDesegregator(List<SegregateCrop> segregateCrops) {
    this.segregateCrops = segregateCrops;
  }

  public List<Crop> desegregate() {
    for (SegregateCrop segregateCrop : segregateCrops) {
      desegregateScientificName(segregateCrop);
      desegregateBayerCode(segregateCrop);
      desegregateCrop(segregateCrop);
    }
    return new ArrayList<Crop>(cropMap.values());
  }

  private void desegregateCrop(SegregateCrop segregateCrop) {
    Crop crop = cropMap.containsKey(segregateCrop.getPublicKey()) ? updateCrop(segregateCrop) : createCrop(segregateCrop);
    cropMap.put(segregateCrop.getPublicKey(), crop);
  }

  private void desegregateBayerCode(SegregateCrop segregateCrop) {
    String bayerPubKey = segregateCrop.getBayerCode().getPublicKey();
    if (!bayercodeMap.containsKey(bayerPubKey)) {
      bayercodeMap.put(bayerPubKey, new BayerCode(segregateCrop.getBayerCode().getCode(), bayerPubKey, scientificNameMap.get(bayerPubKey)));
    }
  }

  private void desegregateScientificName(SegregateCrop segregateCrop) {
    String bayerPubKey = segregateCrop.getBayerCode().getPublicKey();
    List<ScientificName> scientificNames = scientificNameMap.containsKey(bayerPubKey) ? scientificNameMap.get(bayerPubKey) : new ArrayList<ScientificName>();
    scientificNames.add(segregateCrop.getBayerCode().getScientificName());
    scientificNameMap.put(bayerPubKey, scientificNames);
  }

  private Crop createCrop(SegregateCrop segregateCrop) {
    List<BayerCode> bayerCodes = new ArrayList<BayerCode>();
    bayerCodes.add(bayercodeMap.get(segregateCrop.getBayerCode().getPublicKey()));
    Crop crop = new Crop(segregateCrop.getPublicKey(), segregateCrop.getName(), segregateCrop.getAbbreviation(), segregateCrop.getShippingStatement(), bayerCodes);
    return crop;
  }

  private Crop updateCrop(SegregateCrop segregateCrop) {
    Crop crop = cropMap.get(segregateCrop.getPublicKey());
    updateBayerCode(segregateCrop, crop);
    return crop;
  }

  private void updateBayerCode(SegregateCrop segregateCrop, Crop crop) {
    for (BayerCode bayerCode : crop.getBayerCodes()) {
      if (segregateCrop.getBayerCode().getPublicKey().equals(bayerCode.getPublicKey())) {
        return;
      }
    }
    crop.getBayerCodes().add(bayercodeMap.get(segregateCrop.getBayerCode().getPublicKey()));
  }
}
