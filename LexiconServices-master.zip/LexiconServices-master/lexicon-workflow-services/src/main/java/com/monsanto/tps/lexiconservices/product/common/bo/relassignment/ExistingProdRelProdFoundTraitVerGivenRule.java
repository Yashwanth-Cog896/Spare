package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;


public class ExistingProdRelProdFoundTraitVerGivenRule
        extends SimpleValidationRule {
    private final ProductRelationshipObject productRelationship;
    private final String traitVersion;
    private final LexiconProductEntity existingLexProduct;

    public ExistingProdRelProdFoundTraitVerGivenRule(
            ProductRelationshipObject relationship, String traitVersion, LexiconProductEntity existingLexProduct) {
        this.productRelationship = relationship;
        this.traitVersion = traitVersion;
        this.existingLexProduct = existingLexProduct;
    }

    protected boolean preConditionsMet() {
        return existingLexProduct == null && productRelationship != null;
    }

    protected boolean criteriaViolated() {
        return (productRelationship.getProducts().size() >= 1 && StringUtils.isNullOrEmpty(traitVersion));
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.PROD_REL_PROD_EXISTS_VERS_NOT_SPEC_CODE);
    }
}
