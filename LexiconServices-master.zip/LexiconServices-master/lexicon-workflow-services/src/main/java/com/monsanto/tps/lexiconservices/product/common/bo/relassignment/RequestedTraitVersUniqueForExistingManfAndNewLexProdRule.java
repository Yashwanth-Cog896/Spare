package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;


import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;

public class RequestedTraitVersUniqueForExistingManfAndNewLexProdRule extends RequestedTraitVersUniqueForExistingManfRule {
    private final LexiconProductEntity existingLexProduct;

    public RequestedTraitVersUniqueForExistingManfAndNewLexProdRule(
            ProductRelationshipObject productRelationship, String traitVersion, LexiconProductEntity existingLexProduct) {
        super(productRelationship, traitVersion);
        this.existingLexProduct = existingLexProduct;
    }

    protected boolean preConditionsMet() {
        return (getProductRelationship() != null && existingLexProduct == null && getTraitVersion() != null);
    }
}
