package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductNameDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 10:03 AM
 */
@Component(value = "syncProductNameLoader")
public class SyncProductNameLoader {

    @Resource
    private FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao;

    @Resource
    private MidasProductNameDao midasProductNameDao;

    @Resource
    private ProductDao mirageProductDao;

    @Resource
    private LexiconProductStageDao lexiconProductStageDao;

    public MutableSyncProductName loadSyncProductName(MutableSyncProduct syncProduct, TPSBrand brand,
                                                      TPSCountry country, String comlName) {
        MutableSyncProductName productName = new MutableSyncProductName();
        setValuesFromRequest(productName, syncProduct, brand, country, comlName);
        setLexProdStage(productName);
        setNameXref(productName);
        setMidasComlPN(productName);
        setMirageProduct(productName);
        setYieldMartProduct(productName);
        return productName;
    }

    private void setYieldMartProduct(MutableSyncProductName productName) {
       productName.setYieldMartProduct(null);
    }

    private void setMirageProduct(MutableSyncProductName productName) {
        TPSBrand brand = productName.getBrand();
        TPSCountry country = productName.getCountry();
        TPSCrop crop = productName.getProduct().getCrop();
        String prodName = productName.getMirageProductName();
        if (!doLoadMirageProduct(crop, brand, country, prodName)){
           productName.setMirageProduct(null);
        }else{
            ProductDTO mirageProduct = mirageProductDao.getMirageProductByCriteria(prodName, crop.getMirageBayerCode(), brand.getMirageCompanyID(), country.getMirageID());
            productName.setMirageProduct(mirageProduct);
        }

    }

    private boolean doLoadMirageProduct(TPSCrop crop, TPSBrand brand, TPSCountry country, String prodName) {
        return crop != null && brand != null && country != null && !StringUtils.isNullOrEmpty(prodName);
    }

    private void setMidasComlPN(MutableSyncProductName productName) {
        MidasProductEntity midasProduct = productName.getProduct().getMidasProduct();
        TPSCountry tpsCountry = productName.getCountry();
        TPSBrand tpsBrand = productName.getBrand();
        if (!doLoadMidasComlPN(tpsCountry, tpsBrand, midasProduct)) {
            productName.setMidasComlPN(null);
        } else {
            MidasProductNameEntity productNameEntity = midasProductNameDao.getMidasNameByCriteria(midasProduct.getId(), tpsBrand.getBrandName(), tpsCountry.getMidasID());
            productName.setMidasComlPN(productNameEntity);
        }
    }

    private boolean doLoadMidasComlPN(TPSCountry country, TPSBrand brand, MidasProductEntity midasProduct) {
        return country != null && brand != null && midasProduct != null;
    }

    private void setNameXref(MutableSyncProductName productName) {
        LexiconProductStageEntity lexProdStage = productName.getLexProdStage();
        if (lexProdStage != null) {
            FbsCommonProductNameXrefEntity productXref = fbsCommonProductNameXrefDao.findProductXrefByPubKey(lexProdStage.getPubkey());
            productName.setNameXref(productXref);
        }

    }

    private void setLexProdStage(MutableSyncProductName productName) {
        LexiconProductEntity lexProduct = productName.getProduct().getLexProduct();
        TPSBrand brand = productName.getBrand();
        TPSCountry country = productName.getCountry();
        if (!doLoadLexProdStage(lexProduct, brand, country)) {
            productName.setLexProdStage(null);
        } else {
            LexiconProductStageEntity lexProductStage = lexiconProductStageDao.
                    findByProductBrandCountryPubkeys(lexProduct.getPubkey(), brand.getLexiconBrandPubkey(), country.getPublicKey());
            productName.setLexProdStage(lexProductStage);
        }
    }

    private boolean doLoadLexProdStage(LexiconProductEntity lexProduct, TPSBrand brand, TPSCountry country) {
        return lexProduct != null && brand != null && country != null;
    }

    private void setValuesFromRequest(MutableSyncProductName productName, MutableSyncProduct syncProduct,
                                      TPSBrand brand, TPSCountry country, String comlName) {
        productName.setProduct(syncProduct);
        productName.setBrand(brand);
        productName.setCountry(country);
        productName.setComlName(comlName);
    }


}
