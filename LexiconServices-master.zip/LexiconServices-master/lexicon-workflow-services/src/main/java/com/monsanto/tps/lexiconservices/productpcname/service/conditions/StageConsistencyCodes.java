/*
 StageConsistencyCodes was created on Jan 8, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconservices.productpcname.service.conditions;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * nbwald Jan 8, 2007 12:57:58 PM
 */
public interface StageConsistencyCodes {
    ValidationConditionCode REQ_COUNTRYS_BRANDS_INCONSISTENT_CODE = new ValidationConditionCode("RequestedCountrysBrandsInconsistent");
    ValidationConditionCode SIM_COML_NAME_EXISTS_FOR_DIFF_PROD_CODE = new ValidationConditionCode("SimilarComlNameExistForDifferentProduct");
    ValidationConditionCode COML_NAME_EXISTS_FOR_DIFF_PROD_CODE = new ValidationConditionCode("ComlNameExistForDifferentProduct");
    ValidationConditionCode ONLY_ONE_PREFERRED_NAME_ALLOWED = new ValidationConditionCode("OnlyOnePreferredNameAllowed");
    ValidationConditionCode ONLY_ONE_EXCEPTION_CODE_MAY_BE_PRIMARY_CODE = new ValidationConditionCode("OnlyOneExceptionCodeMayBePrimary");
    ValidationConditionCode VEGETABLE_PROD_REQ_SAME_ATTR_CODE = new ValidationConditionCode("VegetableProductsRequireSameAttributes");
}