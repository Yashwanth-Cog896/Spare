package com.monsanto.tps.lexiconservices.persistence.mirage.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageAuditEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/8/14
 * Time: 10:16 AM
 */
public class ProductDaoImpl extends GenericDaoImpl<MirageSeedProductEntity, Long> implements ProductDao {

  public static final String MIRAGE_PRODUCT_BY_ID = "MirageProductDao.getMirageProductById";
  public static final String MIRAGE_PRODUCT_BY_CRITERIA = "MirageProductDao.getMirageProductByCriteria";
  public static final String MIRAGE_UPDATE_PRODUCT_PRECOMMERICAL_NAME = "MirageProductDao.updateMirageSeedProductPrecommercialName";
  public static final String MIRAGE_UPDATE_MIRAGE_SEED_PRODUCT = "MirageProductDao.updateMirageSeedProduct";
  public static final String MIRAGE_REUSE_MIRAGE_SEED_PRODUCT = "MirageProductDao.reuseMirageSeedProduct";

  public ProductDaoImpl(Class entityClass) {
    super(entityClass);
  }

  public ProductDTO findMirageProductById(long seedProductId) {
    Query query = getSessionFactory().getCurrentSession().getNamedQuery(MIRAGE_PRODUCT_BY_ID);
    query.setResultTransformer(Transformers.aliasToBean(ProductDTO.class));
    query.setParameter("productId", seedProductId);
    return (ProductDTO) query.uniqueResult();
  }

  public ProductDTO getMirageProductByCriteria(String productName, String mirageBayerCode, long mirageCompanyID, String mirageCountryCode) {
    Query query = getSessionFactory().getCurrentSession().getNamedQuery(MIRAGE_PRODUCT_BY_CRITERIA);
    query.setResultTransformer(Transformers.aliasToBean(ProductDTO.class));
    query.setParameter("productName", productName);
    query.setParameter("bayerCode", mirageBayerCode);
    query.setParameter("companyId", mirageCompanyID);
    query.setParameter("countryCode", mirageCountryCode);
    return (ProductDTO) query.uniqueResult();
  }

  public MirageSeedProductEntity save(MirageSeedProductEntity seedProduct) {
    Long id = (Long) getSessionFactory().getCurrentSession().save(seedProduct);
    getSessionFactory().getCurrentSession().flush();
    return get(id);
  }

  public int reuseMirageSeedProduct(long traitCharacteristicCode, boolean enabled, long auditId, long productId) {
    return getSessionFactory().getCurrentSession().getNamedQuery(MIRAGE_REUSE_MIRAGE_SEED_PRODUCT).
      setParameter("traitCharacteristicCode", traitCharacteristicCode).setParameter("enabled", enabled ? "Y" : "N").
      setParameter("disabledDate", enabled ? "Y" : "N").setParameter("auditId", auditId).setParameter("productId", productId).executeUpdate();
  }

  public void disableMirageSeedProduct(MirageAuditEntity audit, long productId) {
    MirageSeedProductEntity seedProduct = get(productId);
    seedProduct.setAudit(audit);
    seedProduct.setEnabled(false);
    seedProduct.setDisabledDate(new Date());
  }

  public int updateMirageSeedProduct(long companyId, String productName, String cropBayerCode, String countryCode, long traitCharacteristicCode,
                                     boolean enabled, long auditId, long productId) {

    return getSessionFactory().getCurrentSession().getNamedQuery(MIRAGE_UPDATE_MIRAGE_SEED_PRODUCT).setParameter("companyId", companyId).
      setParameter("productName", productName).setParameter("cropBayerCode", cropBayerCode).setParameter("countryCode", countryCode).
      setParameter("traitCharacteristicCode", traitCharacteristicCode).setParameter("enabled", enabled ? "Y" : "N").
      setParameter("disabledDate", enabled ? "Y" : "N").setParameter("auditId", auditId).setParameter("productId", productId).executeUpdate();
  }

  @Override
  public int updateMirageSeedProductPrecommercialName(String newPrecommercialName, String oldPrecommercialName, String mirageBayerCode, long auditId) {
    return getSessionFactory().getCurrentSession().getNamedQuery(MIRAGE_UPDATE_PRODUCT_PRECOMMERICAL_NAME).
      setParameter("newPrecommercialName", newPrecommercialName).
      setParameter("auditID", auditId).
      setParameter("oldPrecommercialName", oldPrecommercialName).
      setParameter("mirageBayerCode", mirageBayerCode).executeUpdate();
  }
}
