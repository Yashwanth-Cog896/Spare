package com.monsanto.tps.lexiconservices.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductMaturityEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductMaturityPK;

/**
 * Created by IntelliJ IDEA.
 * User: pgang
 * Date: 1/23/14
 * Time: 12:33 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SeedProductMaturityDao extends GenericDao<MirageSeedProductMaturityEntity, MirageSeedProductMaturityPK> {
    int deleteByProductId(Long productId);

    MirageSeedProductMaturityEntity save(long seedProductId, String maturityRating, long auditId);
}
