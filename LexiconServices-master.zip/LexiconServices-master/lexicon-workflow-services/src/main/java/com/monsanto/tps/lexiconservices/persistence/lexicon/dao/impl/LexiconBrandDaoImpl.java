package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconBrandDao;
import org.hibernate.criterion.Restrictions;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/8/14
 * Time: 2:16 PM
 */
public class LexiconBrandDaoImpl extends GenericDaoImpl<LexiconBrandEntity, Long> implements LexiconBrandDao {
    public LexiconBrandDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public LexiconBrandEntity getLexiconBrandForPubKey(String pubKey) {
        return (LexiconBrandEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconBrandEntity.class, "brand").
               createAlias("brand.lexiconCompany" ,"company").
                add(Restrictions.eq("brand.active", true)).
                add(Restrictions.eq("company.active",true)).
                add(Restrictions.eq("brand.pubkey",pubKey)).uniqueResult();
    }

    public LexiconBrandEntity getLexiconBrandForName(String name) {
        return (LexiconBrandEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconBrandEntity.class, "brand").
                add(Restrictions.eq("brand.name",name)).uniqueResult();
    }
}
