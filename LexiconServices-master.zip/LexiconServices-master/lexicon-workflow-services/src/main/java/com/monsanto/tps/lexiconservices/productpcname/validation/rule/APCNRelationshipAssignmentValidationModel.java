package com.monsanto.tps.lexiconservices.productpcname.validation.rule;


import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;

public interface APCNRelationshipAssignmentValidationModel {
    String getRequestedManfName();

    String getRequestedTraitVersion();

    com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject getExistingManfNameRelationship();

    BaseProductEntity getExistingManfNameBaseProduct();

    ProductRelationshipEntity getExistingManfNameManfLine();

    String getRequestedPCName();

    TPSCrop getRequestedCrop();

    boolean getRequestedParentProductFlag();

    LexiconProductEntity getLexProduct();

    ProductRelationshipObject getProductRelationship();
}
