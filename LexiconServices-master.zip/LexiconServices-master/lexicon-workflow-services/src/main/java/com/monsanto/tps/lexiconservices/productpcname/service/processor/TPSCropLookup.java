package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCropEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CropDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasCropDao;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.YldstgCropMirageDao;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.domain.MapCropMirageDto;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidCropException;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/29/14
 * Time: 4:22 PM
 */
@Component(value = "TPSCropLookup")
public class TPSCropLookup implements ApplicationContextAware {

    private final TPSCropLookupErrorFormatter tpsCropLookupErrorFormatter = new TPSCropLookupErrorFormatter();

    @Resource
    private YldstgCropMirageDao yldstgCropMirageDao;

    @Resource
    private CropDao lexiconCropDao;

    @Resource
    private MidasCropDao midasCropDao;

    private static TPSCropLookup tpsCropLookupInstance;

    private static ApplicationContext context;


    public static TPSCropLookup instance() {
        if (tpsCropLookupInstance == null) {
            TPSCropLookup lookup = (TPSCropLookup) context.getBean("TPSCropLookup");
            setTpsCropLookupInstance(lookup);
        }
        return tpsCropLookupInstance;
    }

    public static void resetInstance() {
        setTpsCropLookupInstance(null);
    }

    protected static void setTpsCropLookupInstance(TPSCropLookup lookup) {
        tpsCropLookupInstance = lookup;
    }

    private final Map<String, TPSCrop> cropsByCropName = new HashMap<String, TPSCrop>();

    public TPSCrop getCropByCropName(String cropName) throws InvalidCropException {
        TPSCrop tpsCrop = null;
        if (!cropsByCropName.containsKey(cropName)) {
            tpsCrop = setCropMirageMap(cropName);
            setLexiconAttributes(cropName, tpsCrop);
            setMaturity(tpsCrop);
            cacheCrop(cropName, tpsCrop);
        }
        tpsCrop = cropsByCropName.get(cropName);
        if (tpsCrop == null) {
            throw new InvalidCropException(tpsCropLookupErrorFormatter.formatCropNameError(cropName));
        }
        return tpsCrop;
    }

    private void cacheCrop(String cropName, TPSCrop tpsCrop) {
        cropsByCropName.put(cropName, tpsCrop);
    }

    private void setMaturity(TPSCrop tpsCrop) {

        if (tpsCrop != null && tpsCrop.existsInMidas()) {
            MidasCropEntity midasCrop = midasCropDao.getMidasCropByCropID(tpsCrop.getMidasCropID());
            tpsCrop.setRelativeMaturityRange(midasCrop.getRmMin(), midasCrop.getRmMax(), midasCrop.getRmIncrement());
        }
    }

    private TPSCrop setCropMirageMap(String cropName) {
        MapCropMirageDto mapCropMirageDto = lookupCropByCropName(cropName);
        if (mapCropMirageDto != null) {
            return new TPSCrop(mapCropMirageDto.getMidasCropId(),
                    mapCropMirageDto.getMidasCropName(), mapCropMirageDto.getMirageBayerCode());
        }
        return null;
    }

    private void setLexiconAttributes(String cropName, TPSCrop tpsCrop) throws InvalidCropException {
        if (tpsCrop != null) {
            LexiconCropEntity lexCrop = lexiconCropDao.getCropByCropName(cropName);
            if (lexCrop == null) {
                throw new InvalidCropException(tpsCropLookupErrorFormatter.formatCropNameError(cropName));
            } else {
                tpsCrop.setLexiconAttributes(lexCrop.getId(), lexCrop.getPubkey(), lexCrop.getName(),
                        lexCrop.getAbbreviation(), lexCrop.getStageCategory().getId(), lexCrop.getAutoGenerateTagVarietyName());
            }
        }
    }


    private MapCropMirageDto lookupCropByCropName(String cropName) {
        String tpsCropName = new LexiconCropNameToTPSCropNameTranslator().translate(cropName);
        return yldstgCropMirageDao.findByCropInMapCropMirage(tpsCropName);
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    public static void setApplicationContextForUT(ApplicationContext applicationContext) {
        context = applicationContext;
    }
}
