package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasGeneticMaterialDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 3:40 PM
 */
@Component(value = "syncProductGeneticMaterialRepointingWriter")
public class SyncProductGeneticMaterialRepointingWriter {

    @Resource
    private MidasGeneticMaterialDao midasGeneticMaterialDao;

    public GeneticMaterialEntity write(GeneticMaterialEntity existingMaterial, ProductGermplasmCollection productGermplasm) {
        if (materialNeedsRepointing(existingMaterial, productGermplasm)) {
            MidasProductGermplasmDTO finishedGermplasm = productGermplasm.getFinishedGermplasm();
            if (finishedGermplasm != null) {
                return repointGeneticMaterial(existingMaterial, finishedGermplasm);
            }
        }
        return existingMaterial;
    }

    private GeneticMaterialEntity repointGeneticMaterial(GeneticMaterialEntity existingMaterial, MidasProductGermplasmDTO finishedGermplasm) {
        midasGeneticMaterialDao.updateGermplasm(finishedGermplasm.getGermplasmId(),existingMaterial.getId());
        return midasGeneticMaterialDao.get(existingMaterial.getId());
    }

    private boolean materialNeedsRepointing(GeneticMaterialEntity existingMaterial, ProductGermplasmCollection productGermplasm) {
        MidasProductGermplasmDTO containingGermplasm = getContainingGermplasm(existingMaterial, productGermplasm);
        return (containingGermplasm != null && !containingGermplasm.isFinished());
    }

    private MidasProductGermplasmDTO getContainingGermplasm(GeneticMaterialEntity existingMaterial, ProductGermplasmCollection productGermplasm) {
        return productGermplasm.getGermplasmByID(existingMaterial.getGermplasm().getId());
    }
}
