package com.monsanto.tps.lexiconservices.product.common.rule;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;

public class AssigningGermplasmConsistentRule
        extends SimpleValidationRule {
    private final ProductGermplasmCollection assignGermplasms;

    public AssigningGermplasmConsistentRule(ProductGermplasmCollection assignGermplasms) {
        this.assignGermplasms = assignGermplasms;
    }

    protected boolean preConditionsMet() {
        return assignGermplasms != null;
    }

    protected boolean criteriaViolated() {
        return !assignGermplasms.getGermplasmCollection().hasConsistentType();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ASSIGNING_GP_INCONSISTANT_CODE);
    }
}
