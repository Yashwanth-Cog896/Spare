package com.monsanto.tps.lexiconservices.common.rule;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:31 PM
 */
public abstract class ConditionalRule
        implements Rule {
    protected abstract boolean preconditionsMet();

    protected abstract boolean criteriaViolated();

    public boolean isViolated() {
        return preconditionsMet() && criteriaViolated();
    }
}
