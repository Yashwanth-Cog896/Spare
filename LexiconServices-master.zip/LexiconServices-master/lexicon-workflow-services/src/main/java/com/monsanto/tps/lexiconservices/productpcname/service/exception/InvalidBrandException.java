package com.monsanto.tps.lexiconservices.productpcname.service.exception;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 12:48 PM
 */
public class InvalidBrandException extends Exception {
    public InvalidBrandException(String msg) {
        super(msg);
    }
}
