package com.monsanto.tps.lexiconrest.service;

import com.monsanto.tps.lexiconrest.loader.ImportModel;

import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author pseth
 * @version $Revision$
 */
public class BatchResponse {
    private int counter;
    private List<ImportModel> importModelList;

    public BatchResponse() {
    }

    public BatchResponse(int counter, List<ImportModel> importModelList) {
        this.counter = counter;
        this.importModelList = importModelList;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public List<ImportModel> getImportModelList() {
        return importModelList;
    }

    public void setImportModelList(List<ImportModel> importModelList) {
        this.importModelList = importModelList;
    }
}