package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasBrandEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCompanyEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasBrandDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.MirageCompanyDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSBrand;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidBrandException;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 12:30 PM
 */
@Component(value = "tpsBrandLookup")
public class TPSBrandLookup implements ApplicationContextAware {
    public static final String NOT_FOUND_IN_COMMON = "The brand is not valid in FBS Common and/or Lexicon";
    public static final String NOT_FOUND_IN_MIRAGE = "The brand is not valid in Mirage";
    public static final String NOT_FOUND_IN_MIDAS = "The brand is not valid in Midas";

    @Resource
    private LexiconBrandDao lexiconBrandDao;

    @Resource
    private MidasBrandDao midasBrandDao;

    @Resource
    private MirageCompanyDao mirageCompanyDao;

    private static ApplicationContext context;

    private static TPSBrandLookup instance;

    private final Map<String, TPSBrand> brandsByName = new HashMap<String, TPSBrand>();
    private final Map<String, TPSBrand> brands = new HashMap<String, TPSBrand>();

    public static TPSBrandLookup getInstance() {
        if (instance == null) {
            setInstance();
        }
        return instance;
    }

    protected static void setInstance() {
        instance = (TPSBrandLookup) context.getBean("tpsBrandLookup");
    }

    public TPSBrand getBrandByName(String name) throws InvalidBrandException {
        if (!brandsByName.containsKey(name)) {
            String pubkey = lexiconBrandDao.getLexiconBrandForName(name).getPubkey();
            if (null == pubkey) {
                brandsByName.put(name, null);
                throw new InvalidBrandException(NOT_FOUND_IN_COMMON);
            }
            return getTPSBrand(pubkey, false);
        }

        TPSBrand brand = (TPSBrand) brandsByName.get(name);
        if (brand == null) {
            throw new InvalidBrandException(NOT_FOUND_IN_COMMON);
        }
        return brand;
    }

    public TPSBrand getTPSBrand(String pubkey, boolean notMidasBrand) throws InvalidBrandException {
        TPSBrand brand = null;
        if (!brands.containsKey(pubkey)) {
            MidasBrandEntity midasBrand = midasBrandDao.getMidasBrandForPubKey(pubkey);
            MirageCompanyEntity mirageBrand = mirageCompanyDao.getMirageCompanyForPubKey(pubkey);
            LexiconBrandEntity lexiconBrand = lexiconBrandDao.getLexiconBrandForPubKey(pubkey);

            brand = createTPSBrand(midasBrand, mirageBrand, lexiconBrand, pubkey);
            brands.put(pubkey, brand);
            if (midasBrand != null) {
                brandsByName.put(midasBrand.getName(), brand);
            }
        }
        brand = (TPSBrand) brands.get(pubkey);
        if (notMidasBrand) {
            handleNonMidasBrand(brand);
        } else {
            handleMidasBrand(brand);
        }
        return brand;
    }

    private void handleNonMidasBrand(TPSBrand brand) throws InvalidBrandException {
        if (!brand.isLexiconBrand()) {
            throw new InvalidBrandException(NOT_FOUND_IN_COMMON);
        } else if (!brand.isMirageBrand()) {
            throw new InvalidBrandException(NOT_FOUND_IN_MIRAGE);
        }
    }

    private void handleMidasBrand(TPSBrand brand) throws InvalidBrandException {
        if (isBrandFoundInCommon(brand)) {
            throw new InvalidBrandException(NOT_FOUND_IN_COMMON);
        } else if (isBrandFoundInMirage(brand)) {
            throw new InvalidBrandException(NOT_FOUND_IN_MIRAGE);
        } else if (isBrandFoundInMidas(brand)) {
            throw new InvalidBrandException(NOT_FOUND_IN_MIDAS);
        }
    }

    private TPSBrand createTPSBrand(MidasBrandEntity midasBrand, MirageCompanyEntity mirageBrand, LexiconBrandEntity lexiconBrand, String pubkey) {
        String midasName = "", midasCompanyName = "", lexiconName = "", lexiconCompanyName = "";
        long midasBrandID = 0, midasCompanyID = 0, lexiconBrandID = 0, lexiconCompanyID = 0;
        int mirageCompanyID = 0;
        boolean lexiconTDRestricted = false;

        if (null != midasBrand) {
            midasName = midasBrand.getName();
            midasBrandID = midasBrand.getId();
            midasCompanyID = midasBrand.getMidasCompany().getId();
            midasCompanyName = midasBrand.getMidasCompany().getName();
        }
        if (null != mirageBrand) {
            mirageCompanyID = (int) mirageBrand.getId();
        }
        if (null != lexiconBrand) {
            lexiconName = lexiconBrand.getName();
            lexiconBrandID = lexiconBrand.getId();
            lexiconCompanyID = lexiconBrand.getLexiconCompany().getId();
            lexiconCompanyName = lexiconBrand.getLexiconCompany().getName();
            lexiconTDRestricted = lexiconBrand.isTechDevRestricted();
        }
        return new TPSBrand(midasName, midasBrandID, midasCompanyID, midasCompanyName, mirageCompanyID,
                lexiconName, lexiconBrandID, lexiconCompanyID, lexiconCompanyName, pubkey, lexiconTDRestricted);
    }

    private boolean isBrandFoundInMidas(TPSBrand brand) {
        return !brand.isMidasBrand() && brand.isMirageBrand();
    }

    private boolean isBrandFoundInMirage(TPSBrand brand) {
        return brand.isMidasBrand() && !brand.isMirageBrand() && !brand.isTdRestricted();
    }

    private boolean isBrandFoundInCommon(TPSBrand brand) {
        return !brand.isLexiconBrand() || (!brand.isMidasBrand() && !brand.isMirageBrand());
    }

    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    static void setApplicationContextForUT(ApplicationContext applicationContext) {
        context = applicationContext;
    }

    public static void resetInstance() {
        instance = null;
    }
}
