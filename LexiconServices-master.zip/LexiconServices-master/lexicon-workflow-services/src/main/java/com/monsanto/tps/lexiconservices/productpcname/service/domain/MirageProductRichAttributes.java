package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.Util.StringUtils;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 10:16 PM
 */
public class MirageProductRichAttributes {
    private final ACPNRichStageAttributes stageAttributes;
    private final MutableSyncProductName syncProductName;

    public MirageProductRichAttributes(ACPNRichStageAttributes stageAttributes, MutableSyncProductName syncProductName) {
        this.stageAttributes = stageAttributes;
        this.syncProductName = syncProductName;
    }

    public boolean isTDRestricted() {
        return ((getTPSBrand() != null && getTPSBrand().isTdRestricted()) || syncProductName.isParentProduct());
    }
    private TPSBrand getTPSBrand() {
        return stageAttributes.getBrand();
    }

    public String getBayerCode() {
        return (syncProductName.getCrop() != null) ? syncProductName.getCrop().getMirageBayerCode() : null;
    }
    public long getBrandId() {
        return (getTPSBrand() != null) ? getTPSBrand().getMirageCompanyID() : 0;
    }

    public String getCountryCode() {
        return (stageAttributes.getCountry() != null) ? stageAttributes.getCountry().getMirageID() : null;
    }
    public long getTraitCharacteristicsId() {
        return (stageAttributes.getTraitStack() != null) ?  stageAttributes.getTraitStack().getMirageTraitID() : 0;
    }

    public boolean isActive() {
        return stageAttributes.isActive();
    }
    public boolean isCommercialStage() {
        return stageAttributes.isCommercialStage();
    }


    public String getProductName() {
        return (StringUtils.isNullOrEmpty(stageAttributes.getCommercialName())) ?
                syncProductName.getPreComlName() : stageAttributes.getCommercialName();
    }

    public boolean isProductEnabled() {
        return stageAttributes.isActive();
    }


    public String getMaturityRating() {
        return stageAttributes.getMaturity();
    }
}
