package com.monsanto.tps.lexiconservices.productpcname.service.conditions;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 19, 2006
 * Time: 11:51:42 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ExistingLinkedStageCodes {
    ValidationConditionCode EXIST_LEX_STAGE_LD_CODE = new ValidationConditionCode("ExistLexStageLD");
    ValidationConditionCode EXIST_LEX_STAGE_NOT_FOUND_CODE = new ValidationConditionCode("ExistLexStageNotFound");
    ValidationConditionCode LEX_STAGE_ADV_AUTO_NAME_EXSIT = new ValidationConditionCode("LexStageAutoNameExist");
    ValidationConditionCode NAME_XREF_NOT_EXISTS_CODE = new ValidationConditionCode("NameXrefNotExist");
    ValidationConditionCode MIDAS_COML_PN_NOT_EXIST_CODE = new ValidationConditionCode("MidasComlPNNotExist");
    ValidationConditionCode MIRAGE_PROD_NOT_EXIST_CODE = new ValidationConditionCode("MirageProdNotExist");
}
