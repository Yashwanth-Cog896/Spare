package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class PCNameValueValidRule
        extends SimpleValidationRule {
    public static final int MAX_SIZE = 30;
    private final String pcNameValue;

    public PCNameValueValidRule(String value) {
        this.pcNameValue = value;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return valueIsEmpty() || valueTooLarge() || hasInvalidCharacters();
    }

    private boolean valueIsEmpty() {
        return StringUtils.isNullOrEmpty(pcNameValue);
    }

    private boolean valueTooLarge() {
        return pcNameValue.length() > MAX_SIZE;
    }

    private boolean hasInvalidCharacters() {
        return !pcNameValue.matches("[a-zA-Z0-9\\-]+");
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.INVALID_PC_NAME_CODE);
    }

}
