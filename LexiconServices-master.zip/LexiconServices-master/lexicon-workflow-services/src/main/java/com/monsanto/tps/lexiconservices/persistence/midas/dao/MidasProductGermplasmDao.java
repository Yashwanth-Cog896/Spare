package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.ProductGermplasmEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;

import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/7/14
 * Time: 12:48 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasProductGermplasmDao extends GenericDao<ProductGermplasmEntity,Long> {

  List<MidasProductGermplasmDTO> findMidasProductGermplasmByProductID(Long productID);

   ProductGermplasmEntity save(ProductGermplasmEntity productGermplasm);
}
