package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.LexiconProductStageDTO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pgang
 * Date: 1/3/14
 * Time: 12:39 PM
 */
public interface LexiconProductStageDao extends GenericDao<LexiconProductStageEntity, Long> {
    List<LexiconProductStageEntity> getMonsantoProductNames(String lexiconProductPubkey);

    List<LexiconProductStageEntity> findByProductPubkey(String lexiconProductPubkey);

    LexiconProductStageEntity insertLexiconProductStage(LexiconProductStageDTO lexiconProductStageDTO);

    int updateLexiconProductStage(LexiconProductStageDTO lexiconProductStageDTO);

    String getNextLexStagePubkey();

    LexiconProductStageEntity findByProductBrandCountryPubkeys(String lexiconProductPubkey, String brandPubkey, String countryPubkey);
}
