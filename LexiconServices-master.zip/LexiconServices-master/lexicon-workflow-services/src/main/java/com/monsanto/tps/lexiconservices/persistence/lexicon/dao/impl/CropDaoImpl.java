package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.crop.domain.CropPublicKeyTypeEnum;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductClassificationEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CropDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper.CropDTO;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper.SegregateCrop;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper.SegregateCropBuilder;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.AliasToBeanResultTransformer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/18/13
 * Time: 5:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropDaoImpl extends GenericDaoImpl<LexiconCropEntity, Long> implements CropDao {

    private static final String FIND_BY_PUBLIC_KEY_AND_SCIENTIFIC_NAME = "cropDao.findByPublicKeysAndScientificName";
    private static final String EMPTY_DB_STRING = "''";
    public static final String CROP_NAME = "name";
    public static final String CROP_PUB_KEY = "publicKey";
    public static final String CROP_ABBREVIATION = "abbreviation";
    public static final String CROP_SHIPPING_STATEMENT = "shippingStatement";
    public static final String CROP_BAYER_CODE = "cropBayerCode";
    public static final String CROP_BAYER_CODE_PUB_KEY = "cropBayerCodePubKey";
    public static final String CROP_SCIENTIFIC_PUB_KEY = "cropScientificPubKey";
    public static final String CROP_SCIENTIFIC_NAME = "cropScientificName";
    public static final String SCIENTIFIC_NAME = "scientificName";
    private static final Long VEGETABLE_CATEGORY_ID = 1l;
    public static final String CROP_DAO_IS_VEGETABLE_CROP = "cropDao.isVegetableCrop";


    public CropDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public List<SegregateCrop> findByPublicKeysAndScientificName(List<String> publicKeys, String scientificName, CropPublicKeyTypeEnum publicKey) {
        String wildCardEntry = getWildCardStringForScientificName(scientificName);
        CropPublicKeyTypeEnum publicKeyType = (null == publicKey) ? CropPublicKeyTypeEnum.CROP : publicKey;
        List<CropDTO> cropDTOList = getCropDTOList(publicKeys, wildCardEntry, publicKeyType);
        List<SegregateCrop> segregateCropList = getSegregateCropList(cropDTOList);

        return segregateCropList;
    }

    public boolean isVegetableCrop(String cropName) {
        LexiconCropEntity crop = (LexiconCropEntity) getSessionFactory().getCurrentSession().getNamedQuery(CROP_DAO_IS_VEGETABLE_CROP).setParameter("cropName", cropName).uniqueResult();
        return crop!=null && null != crop.getStageCategory() && crop.getStageCategory().getId().equals(VEGETABLE_CATEGORY_ID);
    }

    private List<SegregateCrop> getSegregateCropList(List<CropDTO> cropDTOList) {
        List<SegregateCrop> segregateCropList = new ArrayList<SegregateCrop>();
        for (CropDTO cropDTO : cropDTOList) {
            SegregateCrop segregateCrop = new SegregateCropBuilder().build(cropDTO);
            segregateCropList.add(segregateCrop);
        }
        return segregateCropList;
    }


    private List<CropDTO> getCropDTOList(List<String> publicKeys, String scientificName, CropPublicKeyTypeEnum publicKeyType) {
        Session session = getSessionFactory().getCurrentSession();
        String query = getQueryString(publicKeys, publicKeyType, session);
        SQLQuery sqlQuery = session.createSQLQuery(query);
        sqlQuery.setParameter(SCIENTIFIC_NAME, scientificName);
        sqlQuery.addScalar(CROP_NAME, Hibernate.STRING);
        sqlQuery.addScalar(CROP_PUB_KEY, Hibernate.STRING);
        sqlQuery.addScalar(CROP_ABBREVIATION, Hibernate.STRING);
        sqlQuery.addScalar(CROP_SHIPPING_STATEMENT, Hibernate.STRING);
        sqlQuery.addScalar(CROP_BAYER_CODE, Hibernate.STRING);
        sqlQuery.addScalar(CROP_BAYER_CODE_PUB_KEY, Hibernate.STRING);
        sqlQuery.addScalar(CROP_SCIENTIFIC_PUB_KEY, Hibernate.STRING);
        sqlQuery.addScalar(CROP_SCIENTIFIC_NAME, Hibernate.STRING);
        sqlQuery.setResultTransformer(new AliasToBeanResultTransformer(CropDTO.class));
        return sqlQuery.list();
    }

    private String getQueryString(List<String> publicKeys, CropPublicKeyTypeEnum publicKeyType, Session session) {
        String query = session.getNamedQuery(FIND_BY_PUBLIC_KEY_AND_SCIENTIFIC_NAME).getQueryString();
        query = query + " AND UPPER(" + publicKeyType.getType() + ") IN (" + buildPublicKeys(publicKeys) + ") ORDER BY " + publicKeyType.getType();
        return query;
    }

    private String getWildCardStringForScientificName(String scientificName) {
        scientificName = (null == scientificName) ? EMPTY_DB_STRING : scientificName;
        String wildCarEntry = scientificName.toUpperCase().replace('*', '%');
        return wildCarEntry;
    }

    private String buildPublicKeys(List<String> strings) {
        return null == strings ? EMPTY_DB_STRING : buildString(strings);
    }

    private String buildString(List<String> strings) {
        StringBuffer sb = new StringBuffer();
        for (String s : strings) {
            sb.append("'").append(getEmptyStringIfNull(s).toUpperCase()).append("', ");
        }
        return sb.toString().substring(0, sb.length() - 2);
    }

    private static String getEmptyStringIfNull(String s) {
        return null == s ? EMPTY_DB_STRING : s;
    }

    public ProductClassificationEntity getCropByProductClassification(String productClassificationCode) {
        return (ProductClassificationEntity) getSessionFactory().getCurrentSession().
                createCriteria(ProductClassificationEntity.class, "productClassification").
                createAlias("productClassification.materialGroup", "materialGroup").
                createAlias("materialGroup.lexiconCrop", "lexiconCrop").
                add(Restrictions.eq("productClassificationCode", productClassificationCode)).uniqueResult();

    }

    public LexiconCropEntity getCropByCropName(String cropName) {
        return (LexiconCropEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconCropEntity.class, "lexiconCrop").
                add(Restrictions.eq("lexiconCrop.name", cropName.toUpperCase().trim())).uniqueResult();
    }

    public boolean isVegetableCropByProductPubkey(String pubkey) {
        LexiconProductEntity product = (LexiconProductEntity) getSessionFactory().getCurrentSession().
                createCriteria(LexiconProductEntity.class, "lexiconProduct").
                createAlias("lexiconProduct.lexiconCrop", "lexiconCrop").
                createAlias("lexiconCrop.stageCategory", "stageCategory").
                add(Restrictions.eq("lexiconProduct.pubkey", pubkey)).uniqueResult();

        return null != product.getLexiconCrop().getStageCategory() && product.getLexiconCrop().getStageCategory().getId().equals(VEGETABLE_CATEGORY_ID);

    }
}
