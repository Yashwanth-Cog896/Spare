package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconBrandEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/8/14
 * Time: 2:13 PM
 */
public interface LexiconBrandDao extends GenericDao<LexiconBrandEntity, Long> {
    LexiconBrandEntity getLexiconBrandForPubKey(String pubKey);

    LexiconBrandEntity getLexiconBrandForName(String name);
}
