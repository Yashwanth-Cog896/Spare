package com.monsanto.tps.lexiconservices.externalservice.externalservice;

import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public interface GermplasmEventTraitServiceInvoker {
  List<Long> fetchTraitStackIdsForGermplasms(List<Long> germplasmKeys);
}