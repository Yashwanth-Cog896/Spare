package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.Util.StringUtils;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:58 PM
 */
public class ManufacturingNameValidationChecks {

    private final String manfName;

    public static final int MAX_SIZE = 50;

    public ManufacturingNameValidationChecks(String manfName) {
        this.manfName = manfName;
    }

    public boolean isNullOrEmpty() {
        return StringUtils.isNullOrEmpty(manfName);
    }

    public boolean valueTooLarge() {
        return manfName.length() > MAX_SIZE;
    }

    public boolean hasInvalidCharacters() {
        if (manfName.startsWith("+")){
            return true;
        }
        if (manfName.endsWith("+")){
            return true;
        }
        if (manfName.contains("+++")){
            return true;
        }
        if (!manfName.matches("[\\w\\-\\+]+")){
            return true;
        }
        return false;
    }

    public boolean isValid() {
        if (isNullOrEmpty()){
            return false;
        }
        if (valueTooLarge()){
            return false;
        }
        if (hasInvalidCharacters()){
            return false;
        }
        return true;
    }
}
