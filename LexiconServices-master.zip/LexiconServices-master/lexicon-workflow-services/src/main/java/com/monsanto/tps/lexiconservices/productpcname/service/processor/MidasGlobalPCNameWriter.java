package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductNameDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.ProductNameDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSBrand;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCountry;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/11/14
 * Time: 12:36 PM
 */
@Component(value = "midasGlobalPCNameWriter")
public class MidasGlobalPCNameWriter {

    @Resource
    private MidasProductNameDao midasProductNameDao;

    @Resource
    private GermplasmDao midasDao;

    public MidasProductNameEntity write(MidasProductNamesCollection globalPCNameRecords, String preComlName, TPSCountry country, MidasProductEntity midasProduct) {
        MidasProductNameEntity pcNameRecord = null;
        if (!globalPCNameRecords.hasActiveRecords() && !preComlName.startsWith("UNKNOWN")) {
            pcNameRecord = (globalPCNameRecords.isEmpty()) ?
                    createGlobalPCName(preComlName, country, midasProduct) :
                    reactivateAGlobalPCName(preComlName, globalPCNameRecords.getFirstRecord());
            globalPCNameRecords.updateCollection(pcNameRecord);
        }
        return pcNameRecord;
    }

    private MidasProductNameEntity reactivateAGlobalPCName(String preComlName, MidasProductNameEntity firstRecord) {
        midasProductNameDao.reuseMidasProductName(preComlName, firstRecord.getId());
        return midasProductNameDao.get(firstRecord.getId());
    }

    private MidasProductNameEntity createGlobalPCName(String preComlName, TPSCountry country, MidasProductEntity midasProduct) {
        Long productNameId = midasDao.getNextMidasId();
        ProductNameDTO productNameDTO = new ProductNameDTO(productNameId, midasProduct.getId(), preComlName, TPSBrand.PRE_COML_BRAND,
                country.getMidasID(), false);
        midasProductNameDao.insertMidasProductName(productNameDTO);
        return midasProductNameDao.get(productNameId);
    }
}
