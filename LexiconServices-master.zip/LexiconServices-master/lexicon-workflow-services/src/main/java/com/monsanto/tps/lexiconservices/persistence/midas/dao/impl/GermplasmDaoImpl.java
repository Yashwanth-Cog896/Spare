package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GermplasmEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.GermplasmDTO;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;

import javax.annotation.Resource;
import java.math.BigDecimal;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class GermplasmDaoImpl extends GenericDaoImpl<GermplasmEntity, Long> implements GermplasmDao {

    public static final String MIDAS_GERMPLASM_BY_GERMPLASM_ID = "GermplasmDao.getGermplasmByGermplasmID";
    public static final String IS_GERMPLASM_ATTACHED_TO_PRODUCT = "GermplasmDao.isGermplasmAttachedToProduct";
    public static final String INSERT_GERMPLASM = "GermplasmDao.insertGermplasm";

    public GermplasmDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public MidasProductGermplasmDTO findGermplasmByGermplasmID(Long germplasmID) {
        Query query = getSessionFactory().getCurrentSession().getNamedQuery(MIDAS_GERMPLASM_BY_GERMPLASM_ID);
        query.setResultTransformer(Transformers.aliasToBean(MidasProductGermplasmDTO.class));
        query.setParameter("germplasmID", germplasmID);
        return (MidasProductGermplasmDTO) query.uniqueResult();
    }

    public Boolean validateGermplasmAttachedToProduct(Long germplasmID) {
        Query query = getSessionFactory().getCurrentSession().getNamedQuery(IS_GERMPLASM_ATTACHED_TO_PRODUCT);
        query.setParameter("germplasmID", germplasmID);
        BigDecimal productID = (BigDecimal) query.uniqueResult();
        if (productID != null) {
            return true;
        }
        return false;
    }

    public MidasProductGermplasmDTO insertGermplasm(GermplasmDTO germplasmDTO) {
        getSessionFactory().getCurrentSession().getNamedQuery(INSERT_GERMPLASM).
                setParameter("germplasmID", germplasmDTO.getID()).
                setParameter("origin", germplasmDTO.getOrigin()).
                setParameter("lineCode", germplasmDTO.getLineCode()).
                setParameter("pedigreeName", germplasmDTO.getPedigree()).
                setParameter("lineTypeRefID", germplasmDTO.getLineType()).
                setParameter("cropName", germplasmDTO.getCropName()).
                setParameter("brProgRefID", germplasmDTO.getOwnerProgRefID()).
                setParameter("eventDisplay", germplasmDTO.getEventDisplay()).
                setParameter("isTransgenic", germplasmDTO.getTransgenic()).
                setParameter("isFinished", germplasmDTO.getFinishedFlag()).executeUpdate();

        return findGermplasmByGermplasmID(germplasmDTO.getID());
    }

    public long getNextMidasId() {

        BigDecimal nextMidasId = (BigDecimal) getSessionFactory().getCurrentSession().getNamedQuery("getNextMidasId").uniqueResult();
        return nextMidasId.longValue();
    }
}