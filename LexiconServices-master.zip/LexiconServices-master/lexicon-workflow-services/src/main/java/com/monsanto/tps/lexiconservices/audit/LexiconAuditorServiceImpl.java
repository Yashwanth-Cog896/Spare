package com.monsanto.tps.lexiconservices.audit;

import com.monsanto.tps.architecture.transformer.DozerObjectTransformer;
import com.monsanto.tps.lexiconservices.lexicon.audit.LexiconAuditorService;
import com.monsanto.tps.lexiconservices.lexicon.audit.domain.AuditStaging;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit.AuditStagingEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.AuditStagingDao;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 12/24/13
 * Time: 4:41 PM
 */

public class LexiconAuditorServiceImpl implements LexiconAuditorService {

    @Resource
    private AuditStagingDao auditStagingDao;

//    @Resource(name = "auditStagingTransformer")
//    private DozerObjectTransformer transformer;

    public void saveAuditStagingData(AuditStaging auditStaging) {
        AuditStagingEntity entity = getAuditStagingEntity(auditStaging);
        auditStagingDao.saveAndFlush(entity);
    }

    private AuditStagingEntity getAuditStagingEntity(AuditStaging auditStaging) {

        AuditStagingEntity entity = new AuditStagingEntity();
        entity.setUserLoginID(auditStaging.getUserLoginID());
        entity.setAuditComment(auditStaging.getAuditComment());
        entity.setAuditRequestor(auditStaging.getAuditRequestor());
        entity.setCreationTimestamp(auditStaging.getCreationTimestamp());
        entity.setMachine(auditStaging.getMachine());
        entity.setOracleSID(auditStaging.getOracleSID());
        entity.setOsUser(auditStaging.getOsUser());
        entity.setProcessName(auditStaging.getProcessName());
        entity.setUserPartyID(auditStaging.getUserPartyID());
        return entity;
    }

    public void deleteAuditStagingData(long oracleSID) {
        AuditStagingEntity entity = auditStagingDao.load(oracleSID);
        auditStagingDao.delete(entity);
    }
}
