package com.monsanto.tps.lexiconrest;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ProductDTO {
    private String preCommercialName;
    private String productPubkey;

    public ProductDTO(String preCommercialName, String productPubkey) {
        this.preCommercialName = preCommercialName;
        this.productPubkey = productPubkey;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }
}