package com.monsanto.tps.lexiconservices.persistence.yldstg.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.yldstg.domain.MapProductMirageEntity;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.MapProductMirageDao;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/23/14
 * Time: 11:32 AM
 */
public class MapProductMirageDaoImpl extends GenericDaoImpl<MapProductMirageEntity, Long> implements MapProductMirageDao {

    public MapProductMirageDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public MapProductMirageEntity saveOrUpdate(MapProductMirageEntity entity) {
        MapProductMirageEntity mapProductMirageEntity = get(entity.getMirageSeedProduct().getProductId());
        if (null == mapProductMirageEntity) {
            return save(entity);
        } else {
            mapProductMirageEntity.setGeneticMaterial(entity.getGeneticMaterial());
            mapProductMirageEntity.setMidasProduct(entity.getMidasProduct());
            mapProductMirageEntity.setMirageName(entity.getMirageName());
            return mapProductMirageEntity;
        }
    }

    @Override
    public MapProductMirageEntity save(MapProductMirageEntity entity) {
        Long id = (Long) getSessionFactory().getCurrentSession().save(entity);
        return get(id);
    }


}
