package com.monsanto.tps.lexiconservices.product.common.condition;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 19, 2006
 * Time: 9:55:24 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ComlNameRuleCodes {
    ValidationConditionCode INVALID_COML_NAME = new ValidationConditionCode("InvalidComlName");
    ValidationConditionCode COML_NAME_TOO_LONG_NON_TDR_CODE = new ValidationConditionCode("ComlNameTooLongNonTDRBrand");
    ValidationConditionCode COML_NAME_TOO_LONG_TDR_BRAND_CODE = new ValidationConditionCode("ComlNameTooLongTDRBrand");
    ValidationConditionCode COML_NAME_FOR_PC_STAGE_CODE = new ValidationConditionCode("ComlNameGivenForPCStage");
    ValidationConditionCode COML_NAME_REQ_COML_STAGE_CODE = new ValidationConditionCode("ComlNameRequiredForComlStage");
}
