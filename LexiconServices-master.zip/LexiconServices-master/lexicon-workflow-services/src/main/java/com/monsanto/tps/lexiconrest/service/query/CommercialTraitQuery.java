package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.CommTraitDTO;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;

import java.util.*;

/**
 * nbwald - Mar 6, 2008 2:11:25 PM
 */
public class CommercialTraitQuery
        extends AbstractPersistentStoreMultiRowQuery {
    private String[] commercialTrait;
    private String[] preCommercialName;
    private String selectCommercialTraitStackPubkey = "select COML_TRAIT_STACK_PUBKEY,  COALESCE(REPORTING_NAME,STACK_ABBR) AS STACK_ABBR from LEXICON.COML_TRAIT_STACK2 where REPORTING_NAME  in (";// +
//            "?) and IS_ACTIVE = 'Y' and \n" +
//            "crop_id in (select CROP_ID from lexicon.pre_coml_product where pre_coml_name in (?)) ";

    public CommercialTraitQuery(String[] commercialTrait, String[] preCommercialName) {
        this.commercialTrait = commercialTrait;
        this.preCommercialName = preCommercialName;
    }

    public List<CommTraitDTO> find()
            throws WrappingException {
        return getList();
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return createCommercialTraitObject(row);
    }

    private Object createCommercialTraitObject(PersistentStoreResultSetRow row) throws WrappingException {
        CommTraitDTO commercialTrait = new CommTraitDTO(getNonNull(row.getString("COML_TRAIT_STACK_PUBKEY")), row.getString("STACK_ABBR"));
        return commercialTrait;
    }

    private String getNonNull(String string) {
        return string == null ? "" : string;
    }

  protected String getSQL()
    throws WrappingException {
    return selectCommercialTraitStackPubkey  + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(commercialTrait) +")" +
      " OR STACK_ABBR IN (" + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(commercialTrait) +" )and IS_ACTIVE = 'Y' and \n" +
      "crop_id in (select CROP_ID from lexicon.pre_coml_product where pre_coml_name in ( " +
      new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(preCommercialName) + "))";
  }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
