package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 12:15 PM
 */
public class LexiconProductNames implements Iterable<LexiconProductStageEntity>{

    private List<LexiconProductStageEntity> lexiconProductNames;

    public LexiconProductNames(List<LexiconProductStageEntity> lexiconProductNames) {
        if (lexiconProductNames == null) {
            throw new NullPointerException();
        }
        this.lexiconProductNames = lexiconProductNames;
    }

    public boolean hasNonDeletedStages() {
        return CollectionUtils.exists(lexiconProductNames, new NonDeletedStagePredicate());
    }

    public Iterator<LexiconProductStageEntity> iterator() {
        return lexiconProductNames.iterator();
    }

    class NonDeletedStagePredicate
            extends LexiconNamePredicate
    {
        protected boolean evaluate(LexiconProductStageEntity stage) {
            return !stage.isLogicalDelete();
        }
    }

    abstract class LexiconNamePredicate
            implements Predicate
    {
        protected abstract boolean evaluate(LexiconProductStageEntity stage);

        public boolean evaluate(Object object) {
            return evaluate((LexiconProductStageEntity) object);
        }
    }

  public LexiconProductStageEntity getFirstNonDeletedStage() {
    return (LexiconProductStageEntity) CollectionUtils.find(lexiconProductNames, new NonDeletedStagePredicate());
  }
}
