package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit.AuditStagingEntity;

import java.math.BigDecimal;


public interface AuditStagingDao extends GenericDao<AuditStagingEntity,Long> {
    @DynamicDaoMethod(queryName = "AuditStagingDao.selectSessionMachine")
    public String getSessionMachine();
    @DynamicDaoMethod(queryName = "AuditStagingDao.selectSessionOsUser")
    String getSessionOsUser();
    @DynamicDaoMethod(queryName = "AuditStagingDao.selectSessionId")
    public BigDecimal getSessionId();
    public void saveAndFlush(AuditStagingEntity auditStagingEntity);
}
