package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.ProductGermplasmEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductGermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 12:52 PM
 */
@Component(value = "syncProductGermplasmAssignmentWriter")
public class SyncProductGermplasmAssignmentWriter {

    @Resource
    private MidasProductGermplasmDao midasProductGermplasmDao;

    @Resource
    private GermplasmDao germplasmDao;

    public ProductGermplasmCollection write(MidasProductEntity midasProduct, ProductGermplasmCollection assigningGermplasm) {
        Set<MidasProductGermplasmDTO> germplasms = assigningGermplasm.getGermplasmCollection().getGermplasms();
        for (MidasProductGermplasmDTO germplasm : germplasms) {
            assignGermplasm(midasProduct, germplasm, assigningGermplasm.isPreferred(germplasm.getGermplasmId()));
        }
        return assigningGermplasm;
    }

    private void assignGermplasm(MidasProductEntity midasProduct, MidasProductGermplasmDTO germplasm, boolean preferred) {
        ProductGermplasmEntity productGermplasm = new ProductGermplasmEntity();
        productGermplasm.setMidasProduct(midasProduct);
        productGermplasm.setPreferred(preferred);
        productGermplasm.setGermplasm(germplasmDao.get(germplasm.getGermplasmId()));
        midasProductGermplasmDao.save(productGermplasm);
    }
}
