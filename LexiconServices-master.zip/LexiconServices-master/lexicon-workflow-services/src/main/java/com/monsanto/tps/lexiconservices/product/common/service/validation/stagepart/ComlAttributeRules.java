package com.monsanto.tps.lexiconservices.product.common.service.validation.stagepart;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.product.common.rule.stagerequest.*;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;

import java.util.List;


public class ComlAttributeRules
        extends RulesValidatorCollection {
    private final TPSCrop crop;
    private final TPSTrait traitStack;
    private final String maturity;
    private final boolean isActiveStage;
    private final boolean isCommercialStage;
    private final boolean isParentProduct;
    private List<Long> traitStackIdsForGermplasm;

    public ComlAttributeRules(TPSCrop crop, TPSTrait traitStack, String maturity,
                              boolean isActiveStage, boolean isCommercialStage, boolean isParentProduct, List<Long> traitStackIdsForGermplasm) {
        this.crop = crop;
        this.traitStack = traitStack;
        this.maturity = maturity;
        this.isActiveStage = isActiveStage;
        this.isCommercialStage = isCommercialStage;
        this.isParentProduct = isParentProduct;
        this.traitStackIdsForGermplasm = traitStackIdsForGermplasm;
    }

    protected RulesValidator[] getRulesValidators() {
        return (isActiveStage && (!isParentProduct || isCommercialStage)) ?
                getRulesWhenActiveNonPreComlParent() :
                getRulesWhenInactiveOrPreComlParent();
    }

    private RuleSeverityPair[] getRulesWhenInactiveOrPreComlParent() {
        return new RuleSeverityPair[]{
                new RuleSeverityPair(new TraitStackValidRule(traitStack), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TraitStackAssociatedWithGermplasmRule(traitStack, traitStackIdsForGermplasm), ValidationConditionSeverity.INFO),
                new RuleSeverityPair(new CommercialProductsMayNotHavePrecommercialTraitsRule(isCommercialStage, traitStack), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TraitStackMatchCropRule(traitStack, crop), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ComlMaturityInRangeRule(maturity, crop), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ValidTraitStackHasMirageCodeRule(traitStack), ValidationConditionSeverity.ERROR),
        };
    }

    private RuleSeverityPair[] getRulesWhenActiveNonPreComlParent() {
        return new RuleSeverityPair[]{
                new RuleSeverityPair(new TraitStackValidRule(traitStack), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TraitStackAssociatedWithGermplasmRule(traitStack, traitStackIdsForGermplasm), ValidationConditionSeverity.INFO),
                new RuleSeverityPair(new TraitStackMatchCropRule(traitStack, crop), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new CommercialProductsMayNotHavePrecommercialTraitsRule(isCommercialStage, traitStack), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ComlMaturityRequiredRule(maturity, crop), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ComlMaturityInRangeRule(maturity, crop), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ValidTraitStackHasMirageCodeRule(traitStack), ValidationConditionSeverity.ERROR),
        };
    }
}
