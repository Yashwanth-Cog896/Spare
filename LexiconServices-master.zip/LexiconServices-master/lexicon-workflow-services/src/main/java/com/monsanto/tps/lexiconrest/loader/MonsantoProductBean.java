package com.monsanto.tps.lexiconrest.loader;

import com.monsanto.tps.lexiconrest.*;

import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class MonsantoProductBean {
    private String productPubkey;
    private String commercialName;
    private BrandDTO brandDTO;
    private StageDTO stageDTO;
    private CountryDTO countryDTO;
    private CommTraitDTO commTraitDTO;
    private ProductDTO productDTO;
    private int batchId;
    private String commercialMaturity;
    private String oecdName;
    private boolean isActive;
    private boolean isPreferredName;
    private boolean isPrimary;
    private boolean isVerifiedName;
    private String auditRequester;
    private String auditComment;
    private List<String> associatedCommercialNameWithProductId;
    private String productNamePubkey;
    private String productKind;

    public String getProductKind() {
        return productKind;
    }

    public void setProductKind(String productKind) {
        this.productKind = productKind;
    }

    public String getProductNamePubkey() {
        return productNamePubkey;
    }

    public void setProductNamePubkey(String productNamePubkey) {
        this.productNamePubkey = productNamePubkey;
    }

    public List<String> getAssociatedCommercialNameWithProductId() {
        return associatedCommercialNameWithProductId;
    }

    public void setAssociatedCommercialNameWithProductId(List<String> associatedCommercialNameWithProductId) {
        this.associatedCommercialNameWithProductId = associatedCommercialNameWithProductId;
    }

    public String getAuditRequester() {
        return auditRequester;
    }

    public void setAuditRequester(String auditRequester) {
        this.auditRequester = auditRequester;
    }

    public String getAuditComment() {
        return auditComment;
    }

    public void setAuditComment(String auditComment) {
        this.auditComment = auditComment;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public boolean isPreferredName() {
        return isPreferredName;
    }

    public void setPreferredName(boolean preferredName) {
        isPreferredName = preferredName;
    }

    public boolean isPrimary() {
        return isPrimary;
    }

    public void setPrimary(boolean primary) {
        isPrimary = primary;
    }

    public boolean isVerifiedName() {
        return isVerifiedName;
    }

    public void setVerifiedName(boolean verifiedName) {
        isVerifiedName = verifiedName;
    }

    public String getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(String commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public String getOecdName() {
        return oecdName;
    }

    public void setOecdName(String oecdName) {
        this.oecdName = oecdName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public void setCommercialName(String commercialName) {
        this.commercialName = commercialName;
    }

    public BrandDTO getBrandDTO() {
        return brandDTO;
    }

    public void setBrandDTO(BrandDTO brandDTO) {
        this.brandDTO = brandDTO;
    }

    public StageDTO getStageDTO() {
        return stageDTO;
    }

    public void setStageDTO(StageDTO stageDTO) {
        this.stageDTO = stageDTO;
    }

    public CountryDTO getCountryDTO() {
        return countryDTO;
    }

    public void setCountryDTO(CountryDTO countryDTO) {
        this.countryDTO = countryDTO;
    }

    public CommTraitDTO getCommTraitDTO() {
        return commTraitDTO;
    }

    public void setCommTraitDTO(CommTraitDTO commTraitDTO) {
        this.commTraitDTO = commTraitDTO;
    }

    public ProductDTO getProductDTO() {
        return productDTO;
    }

    public void setProductDTO(ProductDTO productDTO) {
        this.productDTO = productDTO;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }
}