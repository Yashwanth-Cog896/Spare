package com.monsanto.tps.lexiconservices.productpcname.validation;

import com.monsanto.tps.lexiconservices.productpcname.validation.rule.APCNDefaultStageAttributesValidationModel;
import com.monsanto.tps.lexiconservices.productpcname.validation.rule.APCNExistingSyncProductValidationModel;
import com.monsanto.tps.lexiconservices.productpcname.validation.rule.APCNProductAssignmentValidationModel;
import com.monsanto.tps.lexiconservices.productpcname.validation.rule.APCNRelationshipAssignmentValidationModel;


public interface AssignPCNameValidationModel
        extends APCNProductAssignmentValidationModel,
        APCNExistingSyncProductValidationModel,
        APCNRelationshipAssignmentValidationModel,
        APCNDefaultStageAttributesValidationModel {
}
