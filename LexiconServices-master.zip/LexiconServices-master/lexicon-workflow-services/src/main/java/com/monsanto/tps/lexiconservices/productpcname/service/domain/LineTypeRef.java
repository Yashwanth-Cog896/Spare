package com.monsanto.tps.lexiconservices.productpcname.service.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 2:17 PM
 */
public interface LineTypeRef {
    public static final String SEGPOP = "SEGPOP";
    public static final String HYBRID = "HYBRID";
    public static final String OP_VAR = "OP_VAR";
    public static final String CODED = "CODED";
    public static final String FINISHED = "FINISHED";

}
