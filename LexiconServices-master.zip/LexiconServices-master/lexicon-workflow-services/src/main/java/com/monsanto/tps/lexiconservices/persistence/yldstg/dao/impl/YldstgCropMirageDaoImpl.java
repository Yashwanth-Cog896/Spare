package com.monsanto.tps.lexiconservices.persistence.yldstg.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCropEntity;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.YldstgCropMirageDao;
import com.monsanto.tps.lexiconservices.persistence.yldstg.dao.domain.MapCropMirageDto;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/3/14
 * Time: 10:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class YldstgCropMirageDaoImpl extends GenericDaoImpl<MidasCropEntity,Long> implements YldstgCropMirageDao {

  public static final String SWEET_CORN = "SWEET CORN";
  public static final String TPS_CORN = "CORN";

  private String translate(String lexiconCropName) {
    return SWEET_CORN.equalsIgnoreCase(lexiconCropName) ? TPS_CORN : lexiconCropName;
  }

  public static final String YLDSTG_CROP_DAO_FIND_MAP_CROP_MIRAGE = "YldstgCropMirageDao.findByCropInMapCropMirage";


  public YldstgCropMirageDaoImpl(Class entityClass) {
    super(entityClass);
  }

  @Override
  public MapCropMirageDto findByCropInMapCropMirage(String midasName) {
    Query query = getSessionFactory().getCurrentSession().getNamedQuery(YLDSTG_CROP_DAO_FIND_MAP_CROP_MIRAGE);
    query.setResultTransformer(Transformers.aliasToBean(MapCropMirageDto.class));
    query.setParameter("midasName",translate(midasName.trim().toUpperCase()));
    return (MapCropMirageDto)query.uniqueResult();
  }

}
