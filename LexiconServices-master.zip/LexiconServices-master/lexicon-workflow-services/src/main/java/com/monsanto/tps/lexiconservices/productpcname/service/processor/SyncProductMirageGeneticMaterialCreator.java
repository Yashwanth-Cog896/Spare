package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasGeneticMaterialDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 3:12 PM
 */
@Component(value = "syncProductMirageGeneticMaterialCreator")
public class SyncProductMirageGeneticMaterialCreator {

    @Resource
    private MidasGeneticMaterialDao geneticMaterialDao;

    @Resource
    private GermplasmDao germplasmDao;

    public GeneticMaterialEntity write(MidasProductGermplasmDTO germplasmDTO, InbredHybridEnum inbredHybridType) {
        GeneticMaterialEntity geneticMaterialEntity = new GeneticMaterialEntity();
        geneticMaterialEntity.setGermplasm(germplasmDao.get(germplasmDTO.getGermplasmId()));
        geneticMaterialEntity.setSource(germplasmDTO.getMaterialSource());
        geneticMaterialEntity.setGeneration(germplasmDTO.getGeneration());
        return geneticMaterialDao.save(geneticMaterialEntity);
    }
}
