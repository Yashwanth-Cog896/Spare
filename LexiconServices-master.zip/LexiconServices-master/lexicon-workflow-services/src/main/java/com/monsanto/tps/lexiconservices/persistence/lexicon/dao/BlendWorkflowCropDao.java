package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BlendWorkflowCropEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit.AuditStagingEntity;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 4/28/14
 * Time: 2:13 PM
 */
public interface BlendWorkflowCropDao extends GenericDao<BlendWorkflowCropEntity,Long> {

    List<BlendWorkflowCropEntity> getAllBlendWorkflowCrops();
}
