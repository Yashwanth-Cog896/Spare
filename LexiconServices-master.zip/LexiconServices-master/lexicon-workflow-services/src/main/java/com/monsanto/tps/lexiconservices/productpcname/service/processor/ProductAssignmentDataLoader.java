package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.externalservice.externalservice.GermplasmEventTraitServiceInvoker;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductClassificationEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.CropDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.GermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductGermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignedGermplasm;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNProductAssignmentRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/31/14
 * Time: 12:01 PM
 */
@Component(value = "productAssignmentDataLoader")
public class ProductAssignmentDataLoader {

    @Resource
    private CropDao cropDao;

    @Resource
    private GermplasmDao germplasmDao;

    @Resource
    private MidasProductGermplasmDao midasProductGermplasmDao;

    @Resource
    private LexiconProductDao lexiconProductDao;

    @Resource
    private GermplasmEventTraitServiceInvoker germplasmEventTraitServiceInvoker;

    public APCNProductAssignmentRichRequest loadProductAssignmentData(AssignPCNameRequest request, MutableSyncProduct syncProduct) {
        APCNProductAssignmentRichRequest productAssignmentData = new APCNProductAssignmentRichRequest();

        setDataFromRequest(request, syncProduct, productAssignmentData);
        setIsVegetableProduct(request, productAssignmentData);
        List<Long> germplasmKeys = getGermplasmKeys(request);
        setAssigningGermplasm(productAssignmentData, request, germplasmKeys);
        setAnyAssigningGermplasmAttachedToProduct(productAssignmentData, germplasmKeys);
        setContainsPreferredPedigree(productAssignmentData, syncProduct);
        setCropByProductClassification(productAssignmentData);
        setTagVarietyNameInUse(productAssignmentData, request, syncProduct);
        setTraitStackIdsForGermplasms(productAssignmentData, germplasmKeys);
        return productAssignmentData;
    }

    private void setTraitStackIdsForGermplasms(APCNProductAssignmentRichRequest productAssignmentData, List<Long> germplasmKeys) {
        List<Long> traitStackIdsForGermplasms = germplasmEventTraitServiceInvoker.fetchTraitStackIdsForGermplasms(germplasmKeys);
        productAssignmentData.setTraitStackIdsForGermplasms(traitStackIdsForGermplasms);
    }

    private void setTagVarietyNameInUse(APCNProductAssignmentRichRequest productAssignmentData, AssignPCNameRequest request, MutableSyncProduct syncProduct) {
        boolean tagVarietyNameUse = determineTagVarietyNameUsed(syncProduct, productAssignmentData.getTagVarietyName(),
                productAssignmentData.getRequestedCrop(), request.getManufacturingName());
        productAssignmentData.setTagVarietyNameInUse(tagVarietyNameUse);
    }

    private boolean determineTagVarietyNameUsed(MutableSyncProduct syncProduct, String tagVarietyName, TPSCrop crop, String manufacturingName) {
        boolean tagVarietyNameUsed = false;
        if (crop != null) {
            long cropId = crop.getLexiconCropID();
            if (isTagVarietyNameNotGenerated(tagVarietyName, manufacturingName, crop)) {
                List<String> pubkeys = lexiconProductDao.getPubkeysByTagVarietyName(tagVarietyName, cropId);
                if (pubkeys.size() > 0 && syncProduct.getLexProduct() != null && !StringUtils.isNullOrEmpty(syncProduct.getLexProduct().getPubkey())) {
                    pubkeys.remove(syncProduct.getLexProduct().getPubkey());
                }
                tagVarietyNameUsed = (pubkeys.size() > 0);
            }
        }
        return tagVarietyNameUsed;
    }

    private boolean isTagVarietyNameNotGenerated(String tagVarietyName, String manufacturingName, TPSCrop requestedCrop) {
        return (StringUtils.isNullOrEmpty(manufacturingName) && ((requestedCrop == null) ||
                ((!requestedCrop.isVarietyNameGenerated()) &&
                        (!StringUtils.isNullOrEmpty(tagVarietyName)))));
    }

    private void setContainsPreferredPedigree(APCNProductAssignmentRichRequest productAssignmentData, MutableSyncProduct syncProduct) {
        boolean preferredPedigree = loadContainsPreferredPedigree(syncProduct);
        productAssignmentData.setContainsPreferredPedigree(preferredPedigree);
    }

    private void setCropByProductClassification(APCNProductAssignmentRichRequest productAssignmentData) {
        String productClassification = loadCropByProductClassification(productAssignmentData.getProductClassificationCode(),
                productAssignmentData.isVegetableProduct());
        productAssignmentData.setCropByProductClassification(productClassification);
    }

    private void setAnyAssigningGermplasmAttachedToProduct(APCNProductAssignmentRichRequest productAssignmentData, List<Long> germplasmKeys) {
        productAssignmentData.setAnyAssigningGermplasmAttachedToProduct(gpAttachedToProduct(germplasmKeys));
    }


    private void setDataFromRequest(AssignPCNameRequest request, MutableSyncProduct syncProduct, APCNProductAssignmentRichRequest productAssignmentData) {
        productAssignmentData.setRequestedPCName(syncProduct.getPreComlName());
        productAssignmentData.setRequestedCrop(syncProduct.getCrop());
        productAssignmentData.setProductClassificationCode(request.getProductClassificationCode());
        productAssignmentData.setSupplyChainOwner(request.getSupplyChainOwner());
        productAssignmentData.setOwnerRegion(request.getOwnerRegion());
        productAssignmentData.setParentProduct(request.isParentProduct());
        productAssignmentData.setTagVarietyName(request.getTagVarietyName());
    }

    private String loadCropByProductClassification(String productClassificationCode, boolean vegetableProduct) {
        if (vegetableProduct) {
            ProductClassificationEntity productClassificationEntity = cropDao.getCropByProductClassification(productClassificationCode);
            if (productClassificationEntity == null) {
                return null;
            } else {
                return productClassificationEntity.getMaterialGroup().getLexiconCrop().getName();
            }
        } else {
            return null;
        }
    }

    private boolean loadContainsPreferredPedigree(MutableSyncProduct syncProduct) {
        boolean hasPreferredPedigree = false;
        FbsCommonProductXrefEntity productXref = syncProduct.getProductXref();
        if (productXref != null) {
            long productId = productXref.getMidasProduct().getId();
            List<MidasProductGermplasmDTO> productGermplasms = midasProductGermplasmDao.findMidasProductGermplasmByProductID(productId);
            for (MidasProductGermplasmDTO germplasm : productGermplasms) {
                if (germplasm.isPreferred()) {
                    hasPreferredPedigree = true;
                    break;
                }
            }
        }
        return hasPreferredPedigree;
    }

    private boolean gpAttachedToProduct(List<Long> germplasmKeys) {
        for (Long id : germplasmKeys) {
            if (germplasmDao.validateGermplasmAttachedToProduct(id)) {
                return true;
            }
        }
        return false;
    }

    private List<Long> getGermplasmKeys(AssignPCNameRequest request) {
        List<AssignedGermplasm> germplasms = request.getAssignedGermplasm();
        List<Long> germplasmKeys = new ArrayList<Long>();
        for (AssignedGermplasm germplasm : germplasms) {
            germplasmKeys.add(germplasm.getGermplasmId());
        }
        return germplasmKeys;
    }

    private void setAssigningGermplasm(APCNProductAssignmentRichRequest productAssignmentData, AssignPCNameRequest request, List<Long> germplasmKeys) {
        List<MidasProductGermplasmDTO> germplasms = new ArrayList<MidasProductGermplasmDTO>();
        for (Long id : germplasmKeys) {
            MidasProductGermplasmDTO germplasm = germplasmDao.findGermplasmByGermplasmID(id);
            germplasms.add(germplasm);
        }
        productAssignmentData.setAssigningGermplasm(new ProductGermplasmCollection(germplasms, request.getAssignedGermplasm()));
    }

    private void setIsVegetableProduct(AssignPCNameRequest request, APCNProductAssignmentRichRequest productAssignmentData) {
        boolean vegetableCrop = cropDao.isVegetableCrop(request.getCropName());
        productAssignmentData.setVegetableProduct(vegetableCrop);
    }
}
