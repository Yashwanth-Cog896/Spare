package com.monsanto.tps.lexiconservices.domain.lexicon;

public interface LexiconCrop {
    int getId();

    String getName();

    String getPubkey();
}
