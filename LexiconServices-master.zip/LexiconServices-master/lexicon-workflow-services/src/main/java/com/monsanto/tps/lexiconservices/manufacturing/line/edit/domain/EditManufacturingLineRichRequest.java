package com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:11 PM
 */
public class EditManufacturingLineRichRequest {

  private ProductRelationshipEntity requestedManufacturingLine;
  private ProductRelationshipEntity newManufacturingNamesManufacturingAttributes;
  private ProductRelationshipEntity newVarietyNamesManufacturingAttributes;
  private BaseProductEntity requestedBaseProduct;
  private String newVarietyName;
  private String newManufacturingName;
  private List<ProductRelationshipEntity> requestedManufacturingLinesProducts;
  private String targetManufacturingName;


  public ProductRelationshipEntity getRequestedManufacturingLine() {
    return requestedManufacturingLine;
  }

  public ProductRelationshipEntity getNewManufacturingNamesManufacturingAttributes() {
    return newManufacturingNamesManufacturingAttributes;
  }

  public ProductRelationshipEntity getNewVarietyNamesManufacturingAttributes() {
    return newVarietyNamesManufacturingAttributes;
  }

  public BaseProductEntity getRequestedBaseProduct() {
    return requestedBaseProduct;
  }

  public String getNewVarietyName() {
    return newVarietyName;
  }

  public String getNewManufacturingName() {
    return newManufacturingName;
  }

  public void setRequestedManufacturingLine(ProductRelationshipEntity requestedManufacturingLine) {
    this.requestedManufacturingLine = requestedManufacturingLine;
  }

  public void setNewManufacturingNamesManufacturingAttributes(ProductRelationshipEntity newManufacturingNamesManufacturingAttributes) {
    this.newManufacturingNamesManufacturingAttributes = newManufacturingNamesManufacturingAttributes;
  }

  public void setNewVarietyNamesManufacturingAttributes(ProductRelationshipEntity newVarietyNamesManufacturingAttributes) {
    this.newVarietyNamesManufacturingAttributes = newVarietyNamesManufacturingAttributes;
  }

  public void setRequestedBaseProduct(BaseProductEntity requestedBaseProduct) {
    this.requestedBaseProduct = requestedBaseProduct;
  }

  public void setNewVarietyName(String newVarietyName) {
    this.newVarietyName = newVarietyName;
  }

  public void setNewManufacturingName(String newManufacturingName) {
    this.newManufacturingName = newManufacturingName;
  }

  public void setRequestedManufacturingLinesProducts(List<ProductRelationshipEntity> requestedManufacturingLinesProducts) {
    this.requestedManufacturingLinesProducts = requestedManufacturingLinesProducts;
  }

  public List<ProductRelationshipEntity> getRequestedManufacturingLinesProducts() {
    return requestedManufacturingLinesProducts;
  }

  public String getTargetManufacturingName() {
    return targetManufacturingName;
  }

  public void setTargetManufacturingName(String targetManufacturingName) {
    this.targetManufacturingName = targetManufacturingName;
  }
}
