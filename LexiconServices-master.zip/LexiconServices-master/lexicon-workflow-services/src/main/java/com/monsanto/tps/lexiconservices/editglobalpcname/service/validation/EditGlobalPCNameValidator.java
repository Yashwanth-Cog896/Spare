package com.monsanto.tps.lexiconservices.editglobalpcname.service.validation;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.validation.rule.EGPCNExistingProductRules;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.NonVegetableProductsMayNotHaveAProductClassificationCodeRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.PCNameValueValidRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.TagVarietyNameFormatRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.TagVarietyNameInUseRequestRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.TagVarietyNumberInUseRequestRule;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.VegetableProductsRequireProductClassificationCodeRule;
import com.monsanto.tps.lexiconservices.product.common.rule.MatchingLexProdNotExistRule;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/12/14
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameValidator extends RulesValidatorCollection
{
  private final EditGlobalPCNameValidationModel model;

  public EditGlobalPCNameValidator(EditGlobalPCNameValidationModel model) {
    this.model = model;
  }

  protected RulesValidator[] getRulesValidators() {
    return new RulesValidator[]{
      new EGPCNExistingProductRules(model),
      new RuleSeverityPair(new PCNameValueValidRule(model.getNewPreComlName()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new MatchingLexProdNotExistRule(model.getMatchingLexProd(), model.getLexProduct()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new VegetableProductsRequireProductClassificationCodeRule(model.isVegetableProduct(), model.getProductClassificationCode()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new NonVegetableProductsMayNotHaveAProductClassificationCodeRule(model.isVegetableProduct(), model.getProductClassificationCode()), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new TagVarietyNameInUseRequestRule(model), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new TagVarietyNameFormatRule(model), ValidationConditionSeverity.ERROR),
      new RuleSeverityPair(new TagVarietyNumberInUseRequestRule(model), ValidationConditionSeverity.ERROR)
    };
  }
}
