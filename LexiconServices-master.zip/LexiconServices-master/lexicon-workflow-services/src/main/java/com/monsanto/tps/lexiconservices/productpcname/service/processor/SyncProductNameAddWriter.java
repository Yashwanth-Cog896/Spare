package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistance.yldstg.domain.MapProductMirageEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 4:04 PM
 */
@Component(value = "syncProductNameAddWriter")
public class SyncProductNameAddWriter {

    @Resource
    private ExceptionCodeWriter exceptionCodeWriter;

    @Resource
    private LexiconStageAddWriter lexiconStageAddWriter;

    @Resource
    private MirageProductAddWriter mirageProductAddWriter;

    @Resource
    private MidasComlNameAddWriter midasComlNameAddWriter;

    @Resource
    private MidasGlobalPCNameWriter midasGlobalPCNameWriter;

    @Resource
    private SyncProductMirageGeneticMaterialWriter syncProductMirageGeneticMaterialWriter;

    @Resource
    private YieldMartProductMappingWriter yieldMartProductMappingWriter;

    @Resource
    private FBSNameXrefWriter fbsNameXrefWriter;

    public MutableSyncProductName write(ACPNRichStageAttributes stageAttributes, MutableSyncProductName syncProductName) {
        setExceptionCode(syncProductName);
        setLexProdStage(stageAttributes, syncProductName);
        setMirageProduct(stageAttributes, syncProductName);
        setMidasComlPN(stageAttributes, syncProductName);
        writeMidasGlobalPCName(stageAttributes.getCountry(), syncProductName);
        GeneticMaterialEntity geneticMaterial = writeMirageGeneticMaterial(syncProductName);
        setYieldMartProduct(geneticMaterial, syncProductName);
        setNameXref(syncProductName);
        return syncProductName;
    }

    private void setNameXref(MutableSyncProductName syncProductName) {
        LexiconProductStageEntity lexProdStage = syncProductName.getLexProdStage();
        MidasProductNameEntity midasComlPN = syncProductName.getMidasComlPN();
        ProductDTO mirageProduct = syncProductName.getMirageProduct();
        FbsCommonProductNameXrefEntity nameXref = fbsNameXrefWriter.write(lexProdStage, midasComlPN, mirageProduct);
        syncProductName.setNameXref(nameXref);
    }

    private void setYieldMartProduct(GeneticMaterialEntity geneticMaterial, MutableSyncProductName syncProductName) {
        ProductDTO mirageProduct = syncProductName.getMirageProduct();
        MidasProductEntity midasProduct = syncProductName.getMidasProduct();
        MapProductMirageEntity mapProductMirageEntity = yieldMartProductMappingWriter.write(mirageProduct, midasProduct, geneticMaterial);
        syncProductName.setYieldMartProduct(mapProductMirageEntity);
    }

    private GeneticMaterialEntity writeMirageGeneticMaterial(MutableSyncProductName syncProductName) {
        MidasProductEntity midasProduct = syncProductName.getMidasProduct();
        GeneticMaterialEntity mirageGeneticMaterial = syncProductName.getMirageGeneticMaterial();
        ProductGermplasmCollection productGermplasm = syncProductName.getProductGermplasm();
        String preComlName = syncProductName.getPreComlName();
        TPSCrop crop = syncProductName.getCrop();
        return syncProductMirageGeneticMaterialWriter.write(midasProduct, mirageGeneticMaterial, productGermplasm, preComlName, crop);
    }

    private void writeMidasGlobalPCName(TPSCountry country, MutableSyncProductName syncProductName) {
        MidasProductNamesCollection globalPCNameRecords = syncProductName.getGlobalPCNameRecords();
        String preComlName = syncProductName.getPreComlName();
        MidasProductEntity existingMidasProduct = syncProductName.getMidasProduct();
        midasGlobalPCNameWriter.write(globalPCNameRecords, preComlName, country, existingMidasProduct);
    }

    private void setMidasComlPN(ACPNRichStageAttributes stageAttributes, MutableSyncProductName syncProductName) {
        MidasProductNameEntity existingComlPN = syncProductName.getMidasComlPN();
        MidasProductEntity mirageProduct = syncProductName.getMidasProduct();
        MidasNameRichAttributes richAttributes = new MidasNameRichAttributes(stageAttributes);
        midasComlNameAddWriter.write(existingComlPN, mirageProduct, richAttributes);
    }

    private void setMirageProduct(ACPNRichStageAttributes stageAttributes, MutableSyncProductName syncProductName) {
        ProductDTO existingMirageProduct = syncProductName.getMirageProduct();
        ProductDTO mirageProduct = mirageProductAddWriter.write(existingMirageProduct, new MirageProductRichAttributes(stageAttributes, syncProductName));
        syncProductName.setMirageProduct(mirageProduct);
    }

    private void setLexProdStage(ACPNRichStageAttributes stageAttributes, MutableSyncProductName syncProductName) {
        LexiconProductStageEntity lexProdStage = syncProductName.getLexProdStage();
        LexiconProductEntity lexProduct = syncProductName.getLexProduct();
        syncProductName.setLexProdStage(lexiconStageAddWriter.write(lexProdStage, lexProduct, stageAttributes));
    }

    private void setExceptionCode(MutableSyncProductName syncProductName) {
        String productName = null;
        String requestedProductName = null;
        boolean vegetable = syncProductName.isRequestedVegetableProduct();
        long lexiconCropId = syncProductName.getCrop().getLexiconCropID();
        productName = syncProductName.getPreComlName();
        requestedProductName = syncProductName.getPreComlName();
        boolean primary = false;
        syncProductName.setExceptionCode(exceptionCodeWriter.write(vegetable, lexiconCropId, productName, requestedProductName, primary));
    }


}
