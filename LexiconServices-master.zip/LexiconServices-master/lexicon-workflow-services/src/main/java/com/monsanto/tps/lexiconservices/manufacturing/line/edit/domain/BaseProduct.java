package com.monsanto.tps.lexiconservices.manufacturing.line.edit.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:52 PM
 */
public class BaseProduct {

    private boolean parentProduct;

    public BaseProduct(boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    public boolean isParentProduct() {
        return parentProduct;
    }

    public void setParentProduct(boolean parentProduct) {
        this.parentProduct = parentProduct;
    }
}
