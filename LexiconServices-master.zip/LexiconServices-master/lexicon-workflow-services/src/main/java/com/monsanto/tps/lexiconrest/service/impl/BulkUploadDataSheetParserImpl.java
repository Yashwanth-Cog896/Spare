package com.monsanto.tps.lexiconrest.service.impl;

import com.monsanto.tps.lexiconrest.loader.ImportModel;
import com.monsanto.tps.lexiconrest.loader.ImportProductModel;
import com.monsanto.tps.lexiconrest.service.BulkUploadDataSheetParser;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@Component("bulkUploadDataSheetParserImpl")
public class BulkUploadDataSheetParserImpl implements BulkUploadDataSheetParser {

  private Logger logger = Logger.getLogger(BulkUploadDataSheetParserImpl.class);
  public static final String PRECOMMERCIAL_NAME = "Precommercial Name";
  public static final String COMMERCIAL_NAME = "Commercial Name";
  public static final String BRAND = "Brand";
  public static final String STAGE = "Stage";
  public static final String COUNTRY = "Country";
  public static final String COML_TRAIT = "Coml Trait";
  public static final String COMMERCIAL_MATURITY = "Commercial Maturity";
    public static final String PRODUCT_KIND = "Product Kind";
  @Override
  public List<ImportModel> createWorkBook(InputStream fileData) throws IOException {
    try {
      List<ImportModel> excelData = new ArrayList<ImportModel>();
      logger.info("Reading workbook");

      XSSFWorkbook workbook = new XSSFWorkbook(fileData);
      XSSFSheet sheet = workbook.getSheet("bulk_upload");
      if (sheet == null) {
        throw new IOException("bulk_upload data sheet is not present");
      }
      StringBuilder isErrorExists = checkIfExcelHasAppropriateColumnsAndData(sheet);
      if(isErrorExists.length()>0){
              throw new IOException(isErrorExists.toString());
            }
      Iterator<Row> rowIterator = sheet.rowIterator();
      rowIterator.next();
      int rows = 0;
      while (rowIterator.hasNext()) {
        ImportModel importModel = extractProductDetails(rowIterator.next());
        if(null == importModel) {
          rows++;
        }else  {
          excelData.add(importModel);
          rows++;
        }
      }
      return excelData;
    } catch (IOException e) {
      logger.error("Exception thrown when parsing excel : " + e);
    } finally {
      fileData.close();
    }
    return new ArrayList<ImportModel>();
  }

  private ImportModel extractProductDetails(Row rowValue) throws IOException{
    boolean nullCheck= checkIfAllRowValuesAreNull(rowValue);
    ImportModel importModel = null ;
    if(!nullCheck){
      ProductInfoExtractor projectInfoExtractor = new ProductInfoExtractor();
      ImportProductModel productModel = projectInfoExtractor.extractProduct(rowValue);
      importModel = new ImportModel();
      importModel.setPrecommercialName(productModel.getPrecommercialName());
      importModel.setProductModel(productModel);
    }
    return importModel;
  }

  private boolean checkIfAllRowValuesAreNull(Row rowValue) {
    boolean nullCheck = false;
    if((rowValue.getCell(0) == null || rowValue.getCell(1) == null
      || rowValue.getCell(2) == null || rowValue.getCell(3) == null || rowValue.getCell(4) == null
      || rowValue.getCell(5) == null || rowValue.getCell(6) == null)
            ||
            ((rowValue.getCell(0) == null || rowValue.getCell(1) == null
                  || rowValue.getCell(2) == null || rowValue.getCell(3) == null || rowValue.getCell(4) == null
                  || rowValue.getCell(5) == null || rowValue.getCell(6) == null) && rowValue.getCell(7) == null)) {
      nullCheck = true;
    }
    return nullCheck;
  }

  private StringBuilder checkIfExcelHasAppropriateColumnsAndData(XSSFSheet sheet) throws IOException {
    Iterator<Row> rowIterator = sheet.rowIterator();
    Row firstRowValues = rowIterator.next();
    LinkedHashMap<Integer,String> columnNames = new LinkedHashMap<Integer,String>();
    int cells = 0;
    Iterator<Cell> cellIterator = firstRowValues.cellIterator();
    while (cellIterator.hasNext()){
      columnNames.put(cells,cellIterator.next().getStringCellValue().trim());
      cells++;
    }
    StringBuilder errorMessage = new StringBuilder();
    if(!columnNames.get(0).contentEquals(PRECOMMERCIAL_NAME)){
      errorMessage.append("FIRST column in bulk_upload sheet should be " + PRECOMMERCIAL_NAME);
    }
    if(!columnNames.get(1).contentEquals(COMMERCIAL_NAME)){
      errorMessage.append(" SECOND column in bulk_upload sheet should be " + COMMERCIAL_NAME);

    }
    if(!columnNames.get(2).contentEquals(BRAND)){
      errorMessage.append(" THIRD column in bulk_upload sheet should be "+BRAND);
    }
    if(!columnNames.get(3).contentEquals(STAGE)){
      errorMessage.append(" FOURTH column in bulk_upload sheet should be "+STAGE);
    }

    if(!columnNames.get(4).contentEquals(COUNTRY)){
      errorMessage.append(" FIFTH column in bulk_upload sheet should be "+COUNTRY);
    }
    if(!columnNames.get(5).contentEquals(COML_TRAIT)){
      errorMessage.append(" SIXTH column in bulk_upload sheet should be "+COML_TRAIT);
    }
    if(!columnNames.get(6).contentEquals(COMMERCIAL_MATURITY)){
      errorMessage.append(" SEVENTH column in bulk_upload sheet should be "+COMMERCIAL_MATURITY);
    }
      if(!columnNames.get(7).contentEquals(PRODUCT_KIND)){
        errorMessage.append(" EIGTH column in bulk_upload sheet should be "+ PRODUCT_KIND);
      }
    return errorMessage;
  }


}
