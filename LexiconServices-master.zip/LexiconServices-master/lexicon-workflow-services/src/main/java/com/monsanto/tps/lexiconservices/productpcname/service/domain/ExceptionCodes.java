package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ExceptionCodeEntity;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/31/14
 * Time: 11:35 AM
 */
public class ExceptionCodes {

    private List<ExceptionCodeEntity> exceptionCodes;

    public ExceptionCodes(List<ExceptionCodeEntity> exceptionCodes) {
        this.exceptionCodes = exceptionCodes;

    }

    public List<ExceptionCodeEntity> getExceptionCodes() {
        return exceptionCodes;
    }
}
