package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.tps.lexiconservices.common.rule.ConditionalRule;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:30 PM
 */
public class NewManufacturingNameDoesNotExistRule extends ConditionalRule {

    private final NewManufacturingAttributesDoNotExistViolation violation;

    public NewManufacturingNameDoesNotExistRule(ProductRelationshipEntity requestedManufacturingLine, ProductRelationshipEntity newManufacturingNamesAttributes) {
        violation = new NewManufacturingAttributesDoNotExistViolation(requestedManufacturingLine, newManufacturingNamesAttributes);
    }

    protected boolean preconditionsMet() {
        return violation.preconditionsMet();
    }

    protected boolean criteriaViolated() {
        return violation.criteriaViolated();
    }

    public String getViolation() {
        return "Manufacturing name already exists.";
    }
}