package com.monsanto.tps.lexiconservices.editglobalpcname.service.impl;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatus;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexiconservices.editglobalpcname.domain.EditGlobalPCNameRequest;
import com.monsanto.tps.lexiconservices.editglobalpcname.domain.EditGlobalPCNameResponse;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.EditGlobalPCNameService;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.EditGlobalPCNameServiceException;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.domain.EditGlobalPCNameRichRequest;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.processor.EditGlobalPCNameRichRequestLoader;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.processor.GlobalPCNameUpdate;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.validation.EditGlobalPCNameValidationModelImpl;
import com.monsanto.tps.lexiconservices.editglobalpcname.service.validation.EditGlobalPCNameValidator;
import org.apache.cxf.feature.Features;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.jws.WebParam;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 3:18 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "editGlobalPCNameServiceImpl")
@Transactional(propagation = Propagation.REQUIRED)
@Features(features = "org.apache.cxf.feature.LoggingFeature")
public class EditGlobalPCNameServiceImpl implements EditGlobalPCNameService {

  private Logger logger = Logger.getLogger(EditGlobalPCNameServiceImpl.class);

  @Resource
  private EditGlobalPCNameRichRequestLoader editGlobalPCNameRichRequestLoader;

  @Resource
  private GlobalPCNameUpdate globalPCNameUpdate;

  @Override
  @PerformanceMetric(task = "EditGlobalPCNameService.processEditGlobalPCName", comment = "processEditGlobalPCName")
  public List<EditGlobalPCNameResponse> processEditGlobalPCName(@WebParam(name = "editGlobalPCName") List<EditGlobalPCNameRequest> editGlobalPCNameRequestList) throws EditGlobalPCNameServiceException {
    logger.info("Processing Edit Global Pre Commercial Name Request");
    List<EditGlobalPCNameResponse> responses = new ArrayList<EditGlobalPCNameResponse>();
    for (EditGlobalPCNameRequest request : editGlobalPCNameRequestList) {
      EditGlobalPCNameRichRequest richRequest;
      try {
        richRequest = editGlobalPCNameRichRequestLoader.getRichRequest(request);
      } catch (WrappingException e) {
        logger.error("Error while processing EditGlobalPCNameRichRequestLoader request", e);
        throw new EditGlobalPCNameServiceException(e.getMessage(), e.getCause());
      }
      EditGlobalPCNameValidator validator = new EditGlobalPCNameValidator(new EditGlobalPCNameValidationModelImpl(richRequest));
      ValidationStatus validationStatus = validator.validate();
      if (!request.isValidationOnly() && !validationStatus.hasSeverity(ValidationConditionSeverity.ERROR)) {
        globalPCNameUpdate.write(richRequest);
      }
      EditGlobalPCNameResponse response = new EditGlobalPCNameResponse();
      if (validationStatus.hasSeverity(ValidationConditionSeverity.ERROR)) {
        response.setErrors(getMsgsFromValidations(Arrays.asList(validationStatus.getConditions(ValidationConditionSeverity.ERROR))));
      }
      if (validationStatus.hasSeverity(ValidationConditionSeverity.INFO)) {
        response.setNotes(getMsgsFromValidations(Arrays.asList(validationStatus.getConditions(ValidationConditionSeverity.INFO))));
      }
      responses.add(response);
    }
    return responses;
  }

  private List<String> getMsgsFromValidations(List<ValidationCondition> validationConditions) {
    List<String> msgs = new ArrayList<String>();
    for (ValidationCondition validationCondition : validationConditions) {
      msgs.add(validationCondition.getError());
    }
    return msgs;
  }
}
