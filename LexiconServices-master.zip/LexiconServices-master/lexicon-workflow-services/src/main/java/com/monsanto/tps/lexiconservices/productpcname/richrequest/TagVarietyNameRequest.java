package com.monsanto.tps.lexiconservices.productpcname.richrequest;

public interface TagVarietyNameRequest {
    public String getTagVarietyName();

    public boolean isTagVarietyNameInUse();

    public boolean isTagVarietyNumberInUse();
}
