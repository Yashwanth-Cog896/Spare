package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper;

import com.monsanto.tps.lexiconservices.crop.domain.BaseCrop;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/18/13
 * Time: 3:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropDTO extends BaseCrop {

  private String cropBayerCode;
  private String cropBayerCodePubKey;
  private String cropScientificPubKey;
  private String cropScientificName;

  public String getCropBayerCode() {
    return cropBayerCode;
  }

  public void setCropBayerCode(String cropBayerCode) {
    this.cropBayerCode = cropBayerCode;
  }

  public String getCropBayerCodePubKey() {
    return cropBayerCodePubKey;
  }

  public void setCropBayerCodePubKey(String cropBayerCodePubKey) {
    this.cropBayerCodePubKey = cropBayerCodePubKey;
  }

  public String getCropScientificPubKey() {
    return cropScientificPubKey;
  }

  public void setCropScientificPubKey(String cropScientificPubKey) {
    this.cropScientificPubKey = cropScientificPubKey;
  }

  public String getCropScientificName() {
    return cropScientificName;
  }

  public void setCropScientificName(String cropScientificName) {
    this.cropScientificName = cropScientificName;
  }
}
