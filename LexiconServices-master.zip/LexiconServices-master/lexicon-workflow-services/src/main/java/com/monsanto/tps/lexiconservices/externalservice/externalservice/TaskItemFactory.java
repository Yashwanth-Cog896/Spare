package com.monsanto.tps.lexiconservices.externalservice.externalservice;

import com.monsanto.Util.Exceptions.ExceptionAsString;
import com.monsanto.tps.support.service.TaskItem;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class TaskItemFactory {
  public static final String APPLICATION_NAME = "lexicon-pos";

  public static final String SAP_ROW_CROP_FLOW = "SapRowCropFlow";
  public static final String INVENTORY_PRODUCT_NAME_LINKAGE = "inventoryProductNameLinkage";

  public static final int MAX_ERROR_MESSAGE_LENGTH = 4000;

  public TaskItem createTaskItem(String taskName, String itemId, boolean success, String errorMessage) {
    return new TaskItem(APPLICATION_NAME, taskName, itemId, success, errorMessage);
  }

  public TaskItem createTaskItem(String taskName, String itemId, Exception exception) {
    return new TaskItem(APPLICATION_NAME, taskName, itemId, false, createThrowableErrorMessage(exception));
  }

  private String truncateIfNecessary(String errorMessage) {
    String truncatedMessage = null;
    if (errorMessage != null) {
      truncatedMessage = errorMessage.substring(0, Math.min(errorMessage.length(), MAX_ERROR_MESSAGE_LENGTH));
    }
    return truncatedMessage;
  }

  private String createThrowableErrorMessage(Exception exception) {
    return truncateIfNecessary(exception.getMessage() + "\n" + new ExceptionAsString().getStackTraceAsString(exception));
  }
}