package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.ProductGermplasmEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductGermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/7/14
 * Time: 2:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductGermplasmDaoImpl extends GenericDaoImpl<ProductGermplasmEntity, Long> implements MidasProductGermplasmDao {

    private static final String MIDAS_PRODUCT_GERMPLASM_BY_PRODUCT_ID = "midasProductGermplasmDao.findMidasProductGermplasmByProductID";

    public MidasProductGermplasmDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<MidasProductGermplasmDTO> findMidasProductGermplasmByProductID(Long productID) {
        Query query = getSessionFactory().getCurrentSession().getNamedQuery(MIDAS_PRODUCT_GERMPLASM_BY_PRODUCT_ID);
        query.setResultTransformer(Transformers.aliasToBean(MidasProductGermplasmDTO.class));
        query.setParameter("productId", productID);
        return (List<MidasProductGermplasmDTO>) query.list();
    }


    @Override
    public ProductGermplasmEntity save(ProductGermplasmEntity productGermplasm) {
        Long id = (Long) getSessionFactory().getCurrentSession().save(productGermplasm);
        return get(id);
    }


}
