package com.monsanto.tps.lexiconrest;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class StageDTO {
    private String stageName;
    private String stagePubkey;

    public StageDTO(String stageName, String stagePubkey) {
        this.stageName = stageName;
        this.stagePubkey = stagePubkey;
    }

    public String getStageName() {
        return stageName;
    }

    public String getStagePubkey() {
        return stagePubkey;
    }
}