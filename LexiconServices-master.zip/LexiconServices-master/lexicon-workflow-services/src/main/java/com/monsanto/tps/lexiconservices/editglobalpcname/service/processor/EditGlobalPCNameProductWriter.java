package com.monsanto.tps.lexiconservices.editglobalpcname.service.processor;

import com.monsanto.tps.lexiconservices.editglobalpcname.service.domain.EditGlobalPCNameRichRequest;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageAuditEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.AuditDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCountry;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.ExceptionCodeWriter;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.MidasGlobalPCNameWriter;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/18/14
 * Time: 10:57 AM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "editGlobalPCNameProductWriter")
public class EditGlobalPCNameProductWriter {

  public static final String UPDATE_SP_EVENT = "UPDATE SEED PRODUCT";

  @Resource
  private ExceptionCodeWriter exceptionCodeWriter;

  @Resource
  private AuditDao mirageAuditDao;

  @Resource
  private ProductDao productDao;

  @Resource
  private MidasProductDao midasProductDao;

  @Resource
  private MidasGlobalPCNameWriter midasGlobalPCNameWriter;

  @Resource
  private LexiconProductDao lexiconProductDao;


  public MutableSyncProduct write(EditGlobalPCNameRichRequest request) {
    MutableSyncProduct syncProduct = request.getSyncProduct();
    String newPreComlName = request.getNewPreComlName();
    String oldPreComlName = getOldPreComlName(request.getSyncProduct());
    updateExceptionKey(request,syncProduct,newPreComlName,oldPreComlName);
    updateMatchingMiragePCProduct(request,syncProduct,newPreComlName,oldPreComlName);
    updateMidasGlobalPCNames(syncProduct , request.getDefaultCountry(), newPreComlName,request.getTagVarietyName());
    syncProduct.setLexProduct(updateLexiconProduct(syncProduct.getLexProduct(),request));
    return syncProduct;
  }

  private LexiconProductEntity updateLexiconProduct(LexiconProductEntity lexProduct, EditGlobalPCNameRichRequest request) {
    String pubKey = lexProduct.getPubkey();
    LexiconProductEntity updatedProduct = lexiconProductDao.updateLexiconProductByPubKey(pubKey, request.getNewPreComlName(), request.getProductClassificationCode(), request.getTagVarietyName(), request.getSupplyChainOwner());
    return updatedProduct;
  }

  private void updateMidasGlobalPCNames(MutableSyncProduct syncProduct, TPSCountry defaultCountry, String newPreComlName, String tagVarietyName) {
    MidasProductNamesCollection globalPCNameRecords = syncProduct.getGlobalPCNameRecords();
    MidasProductEntity existingMidasProduct = syncProduct.getMidasProduct();
    midasGlobalPCNameWriter.write(globalPCNameRecords, newPreComlName, defaultCountry, existingMidasProduct);
    midasProductDao.updateDenominationByPublicKey(tagVarietyName,syncProduct.getProductPubkey());
  }

  private void updateMatchingMiragePCProduct(EditGlobalPCNameRichRequest request,MutableSyncProduct syncProduct, String newPreComlName, String oldPreComlName) {
    MirageAuditEntity auditEntity = mirageAuditDao.save(UPDATE_SP_EVENT);
    String mirageBayerCode = syncProduct.getCrop().getMirageBayerCode();
    productDao.updateMirageSeedProductPrecommercialName(newPreComlName,oldPreComlName,mirageBayerCode,auditEntity.getId());
  }

  private void updateExceptionKey(EditGlobalPCNameRichRequest request,MutableSyncProduct syncProduct,String newPreComlName, String oldPreComlName) {
    long lexiconCropId = request.getSyncProduct().getCrop().getLexiconCropID();
    boolean vegetable = syncProduct.isRequestedVegetableProduct();
    boolean primary =false ;
    exceptionCodeWriter.write(vegetable, lexiconCropId, oldPreComlName, newPreComlName, primary);
  }

  private String getOldPreComlName(MutableSyncProduct syncProduct) {
    LexiconProductEntity product = syncProduct.getLexProduct();
    return (product == null) ? null : product.getPreCommercialName();
  }
}
