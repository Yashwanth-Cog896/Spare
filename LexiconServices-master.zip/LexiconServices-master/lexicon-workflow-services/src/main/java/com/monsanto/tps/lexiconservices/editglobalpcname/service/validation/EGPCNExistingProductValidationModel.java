package com.monsanto.tps.lexiconservices.editglobalpcname.service.validation;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/12/14
 * Time: 9:30 AM
 * To change this template use File | Settings | File Templates.
 */
public interface EGPCNExistingProductValidationModel {
  LexiconProductEntity getLexProduct();
  FbsCommonProductXrefEntity getProductXref();
  MidasProductEntity getMidasProduct();
}
