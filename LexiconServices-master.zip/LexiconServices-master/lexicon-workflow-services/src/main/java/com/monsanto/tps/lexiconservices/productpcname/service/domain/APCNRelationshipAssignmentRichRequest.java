package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 11:03 AM
 */
public class APCNRelationshipAssignmentRichRequest {

    private String requestedManfName;
    private String requestedTraitVersion;
    private ProductRelationshipObject existingManfNameRelationship;
    private String existingManfNameVarietyName;
    private BaseProductEntity baseProduct;
    private ProductRelationshipEntity existingManfNameManfLine;

    public String getRequestedManfName() {
        return requestedManfName;
    }

    public void setRequestedManfName(String requestedManfName) {
        this.requestedManfName = requestedManfName;
    }

    public String getRequestedTraitVersion() {
        return requestedTraitVersion;
    }

    public void setRequestedTraitVersion(String requestedTraitVersion) {
        this.requestedTraitVersion = requestedTraitVersion;
    }


    public void setExistingManfNameRelationship(ProductRelationshipObject existingManfNameRelationship) {
        this.existingManfNameRelationship = existingManfNameRelationship;
    }

    public void setExistingManfNameVarietyName(String existingManfNameVarietyName) {
        this.existingManfNameVarietyName = existingManfNameVarietyName;
    }

    public void setBaseProduct(BaseProductEntity baseProduct) {
        this.baseProduct = baseProduct;
    }

    public void setExistingManfNameManfLine(ProductRelationshipEntity existingManfNameManfLine) {
        this.existingManfNameManfLine = existingManfNameManfLine;
    }

    public ProductRelationshipObject getExistingManfNameRelationship() {
        return existingManfNameRelationship;
    }

    public String getExistingManfNameVarietyName() {
        return existingManfNameVarietyName;
    }

    public BaseProductEntity getBaseProduct() {
        return baseProduct;
    }

    public ProductRelationshipEntity getExistingManfNameManfLine() {
        return existingManfNameManfLine;
    }
}
