package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasCropDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 10:15 AM
 */
@Component(value = "syncProductMidasProductWriter")
public class SyncProductMidasProductWriter {

    @Resource
    private MidasProductDao midasProductDao;

    @Resource
    private MidasCropDao midasCropDao;

    public MidasProductEntity write(MidasProductEntity existingProduct, TPSCrop requestedCrop, String denomination) {
        MidasProductEntity returnedProduct = existingProduct;
        if (existingProduct == null) {
            MidasProductEntity product = new MidasProductEntity();
            product.setMidasCrop(midasCropDao.get(requestedCrop.getMidasCropID()));
            product.setDenomination(denomination);
            product.setRefActive(true);
            returnedProduct = midasProductDao.save(product);
        } else if (!existingProduct.isRefActive()) {
            midasProductDao.updateDenominationAndRefActive(existingProduct.getId(), denomination, true);
            returnedProduct = midasProductDao.get(existingProduct.getId());
        }
        return returnedProduct;
    }
}
