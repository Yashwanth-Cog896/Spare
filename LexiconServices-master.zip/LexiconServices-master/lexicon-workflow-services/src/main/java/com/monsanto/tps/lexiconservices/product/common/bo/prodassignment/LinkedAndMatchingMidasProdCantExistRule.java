package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;

public class LinkedAndMatchingMidasProdCantExistRule
        extends SimpleValidationRule {
    private final MidasProductEntity linkedMidasProduct;
    private final MidasProductNamesCollection matchingMidasPN;

    public LinkedAndMatchingMidasProdCantExistRule(MidasProductEntity linkedMidasProduct,
                                                   MidasProductNamesCollection matchingMidasPN) {
        this.linkedMidasProduct = linkedMidasProduct;
        this.matchingMidasPN = matchingMidasPN;
    }

    protected boolean preConditionsMet() {
        return matchingMidasPN != null && matchingMidasPN.getCommonProduct() != null;
    }

    protected boolean criteriaViolated() {
        return linkedMidasProduct != null &&
                linkedMidasProduct.getId() != matchingMidasPN.getCommonProduct().getMidasProduct().getId();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.BOTH_LINKED_AND_MATCH_MIDAS_PROD_CODE);
    }
}
