package com.monsanto.tps.lexiconservices.product.common.condition;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 19, 2006
 * Time: 9:55:37 AM
 */
public interface StageRequestCodes {
    ValidationConditionCode INVALID_BRAND_CODE = new ValidationConditionCode("InvalidBrand");
    ValidationConditionCode BRAND_NOT_IN_MIRAGE_CODE = new ValidationConditionCode("BrandNotInMirage");
    ValidationConditionCode BRAND_NOT_IN_MIDAS_CODE = new ValidationConditionCode("BrandNotInMidas");
    ValidationConditionCode BRAND_NOT_MON_COMPANY_CODE = new ValidationConditionCode("BrandNotMonCompany");
    ValidationConditionCode BRAND_FOR_VEGGIE_COML_STAGE_CODE = new ValidationConditionCode("BrandForVeggieComlStage");
    ValidationConditionCode COML_BRAND_FOR_PC_STAGE_CODE = new ValidationConditionCode("ComlBrandForPCStage");
    ValidationConditionCode PC_BRAND_FOR_COML_STAGE_CODE = new ValidationConditionCode("PCBrandForComlStage");
    ValidationConditionCode INVALID_COUNTY_CODE = new ValidationConditionCode("InvalidCountry");
    ValidationConditionCode COUNTRY_NOT_IN_M_OR_M_CODE = new ValidationConditionCode("CountryNotInMidasOrMirage");
    ValidationConditionCode INVALID_TRAIT_STACK_CODE = new ValidationConditionCode("InvalidTraitStack");
    ValidationConditionCode TRAIT_STACK_NOT_ASSOCIATED_WITH_GERMPLASM_CODE = new ValidationConditionCode("TraitStackNotAssociatedWithGermplasm");
    ValidationConditionCode COML_PROD_WITH_PRECOML_TRAIT = new ValidationConditionCode("ComlStageWithPrecomlTrait");
    ValidationConditionCode TRAIT_STACK_CROP_MISMATCH_CODE = new ValidationConditionCode("TraitCropMismatch");
    ValidationConditionCode MIRAGE_TRAIT_CODE_NOTFOUND_CODE = new ValidationConditionCode("MirageTraitCodeNotFound");
    ValidationConditionCode INVALID_STAGE_PUBKEY_CODE = new ValidationConditionCode("InvalidStageName");
    ValidationConditionCode NON_NUMERIC_COML_MATURITY_CODE = new ValidationConditionCode("ComlMatNotNumeric");
    ValidationConditionCode COML_MATRUITY_REQ_CODE = new ValidationConditionCode("ComlMatRequired");
    ValidationConditionCode COML_MATRUITY_OUT_OF_RANGE_CODE = new ValidationConditionCode("ComlMatOutOfRange");
    ValidationConditionCode PREFERRED_NAME_IS_COML_CODE = new ValidationConditionCode("PreferredNameIsComl");
    ValidationConditionCode VEGETABLE_PRODUCT_WITH_ROW_CROP_STAGE_CODE = new ValidationConditionCode("VegetableProductWithRowCropStage");
    ValidationConditionCode ROW_CROP_PRODUCT_WITH_VEGETABLE_PHASE_CODE = new ValidationConditionCode("RowCropProductWithVegetablePhase");
    ValidationConditionCode PRE_COML_STAGE_WITH_PRIMARY_EXCEPTION_CODE_CODE = new ValidationConditionCode("PreComlStageWithPrimaryExceptionCode");
}
