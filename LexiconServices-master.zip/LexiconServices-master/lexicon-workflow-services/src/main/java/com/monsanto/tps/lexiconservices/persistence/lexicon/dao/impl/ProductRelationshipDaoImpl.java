package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductionStatusEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipXrefEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipHelper;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/26/13
 * Time: 7:42 PM
 */
public class ProductRelationshipDaoImpl extends GenericDaoImpl<ProductRelationshipEntity, Long> implements ProductRelationshipDao {

    private static final String UPDATE_RELATIONSHIP_VARIETY_NAME_QUERY = "ProductRelationshipDao.updateRelationshipVarietyName";
    private static final String UPDATE_MANUFACTURING_NAME_QUERY = "ProductRelationshipDao.updateManufacturingName";
    private static final String INSERT_PRODUCT_RELATIONSHIP = "ProductRelationshipDao.insertProductRelationship";
    public static final String FIND_PRODUCT_RELATIONSHIP_BY_PRODUCT_PUBKEY_QUERY = "ProductRelationshipDao.findProductRelationshipByProductID";


    public ProductRelationshipDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public int updateManufacturingName(String newManufacturingName, String oldManufacturingName) {
        return getSessionFactory().getCurrentSession().getNamedQuery(UPDATE_MANUFACTURING_NAME_QUERY).
                setParameter("newManufacturingName", newManufacturingName).
                setParameter("oldManufacturingName", oldManufacturingName).executeUpdate();
    }

    public ProductRelationshipEntity findManufacturingAttributesByManufacturingName(String manufacturingName) {
        return null;
    }

    public ProductRelationshipEntity findManufacturingAttributesByVarietyName(String varietyName) {
        return null;
    }

    @Override
    public int updateRelationshipVarietyName(String varietyName, String manufacturingName) {
        return getSessionFactory().getCurrentSession().getNamedQuery(UPDATE_RELATIONSHIP_VARIETY_NAME_QUERY).
                setParameter("varietyName", varietyName).
                setParameter("manufacturingName", manufacturingName).executeUpdate();
    }

    public List<ProductRelationshipEntity> findProductRelationshipProductsByManufacturingName(String manufacturingName) {
        return null;
    }

    public ProductRelationshipEntity findManufacturingLineByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<ProductRelationshipDTO> findProductRelationshipByProductID(Long productRelationshipID) {
        Query query = getSessionFactory().getCurrentSession().getNamedQuery(FIND_PRODUCT_RELATIONSHIP_BY_PRODUCT_PUBKEY_QUERY);
        query.setResultTransformer(Transformers.aliasToBean(ProductRelationshipDTO.class));
        query.setParameter("productRelationshipID", productRelationshipID);
        return (List<ProductRelationshipDTO>) query.list();
    }

    public int insertProductRelationship(ProductRelationshipDTO productRelationshipDTO) {

        return getSessionFactory().getCurrentSession().getNamedQuery(INSERT_PRODUCT_RELATIONSHIP).
                setParameter("manfName", productRelationshipDTO.getManfName()).
                setParameter("productPubkey", productRelationshipDTO.getProductPubkey()).
                setParameter("traitVersion", productRelationshipDTO.getTraitVersion()).
                setParameter("productionStatus", productRelationshipDTO.getProductionStatus()).executeUpdate();
    }

    public int insertProductRelationshipXref(String traitVersion, Long productId, Long productionStatusId, Long productRelationshipId) {
        ProductRelationshipXrefEntity entity = new ProductRelationshipXrefEntity();
        entity.setTraitVersion(traitVersion);
        LexiconProductEntity lexProduct = new LexiconProductEntity();
        lexProduct.setId(productId);
        entity.setLexiconProduct(lexProduct);
        LexiconProductionStatusEntity lexiconProductionStatusEntity = new LexiconProductionStatusEntity();
        lexiconProductionStatusEntity.setId(productionStatusId);
        entity.setProductionStatus(lexiconProductionStatusEntity);
        ProductRelationshipEntity productRelationshipEntity = new ProductRelationshipEntity();
        productRelationshipEntity.setId(productRelationshipId);
        entity.setProductRelationship(productRelationshipEntity);
        Serializable object = getSessionFactory().getCurrentSession().save(entity);
        return 0;

    }

    @Override
    public ProductRelationshipEntity findProductRelationshipByProductPubkey(String productPubKey) {
        Criteria queryCriteria = getSessionFactory().getCurrentSession().createCriteria(ProductRelationshipEntity.class, "productRelationship");
        queryCriteria.createAlias("productRelationship.productRelationshipXRefs", "productRelationshipXref").
                createAlias("productRelationshipXref.lexiconProduct", "lexiconProduct").
                add(Restrictions.isNotNull("productRelationship.manufacturingName")).
                add(Restrictions.eq("lexiconProduct.pubkey", productPubKey)).
                addOrder(Order.asc("productRelationship.manufacturingName"));
        queryCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        ProductRelationshipEntity productRelationShip = (ProductRelationshipEntity) queryCriteria.uniqueResult();

        return productRelationShip;
    }

    @Override
    public ProductRelationshipHelper getRelationshipByProductPubkey(String productPubKey) {
        ProductRelationshipEntity productRelationshipEntity = findProductRelationshipByProductPubkey(productPubKey);
        ProductRelationshipHelper productRelationshipHelper = new ProductRelationshipHelper();
        List<ProductRelationshipDTO> productRelationshipDTOList = new ArrayList<ProductRelationshipDTO>();
        if (null != productRelationshipEntity) {
            productRelationshipDTOList = findProductRelationshipByProductID(productRelationshipEntity.getId());
        }
        if (productRelationshipDTOList.size() > 0) {
            productRelationshipHelper = new ProductRelationshipHelper(productRelationshipEntity.getManufacturingName(), productRelationshipEntity.getProductRelationshipPubkey(), productRelationshipDTOList);
        }
        return productRelationshipHelper;
    }
}
