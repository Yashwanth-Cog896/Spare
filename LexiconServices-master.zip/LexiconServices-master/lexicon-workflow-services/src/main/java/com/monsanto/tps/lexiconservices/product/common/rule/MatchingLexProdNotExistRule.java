package com.monsanto.tps.lexiconservices.product.common.rule;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/12/14
 * Time: 10:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class MatchingLexProdNotExistRule  extends SimpleValidationRule
{
  private final ProductRelationshipDTO matchingLexProd;
  private final LexiconProductEntity syncLexProd;

  public MatchingLexProdNotExistRule(ProductRelationshipDTO matchingLexProd, LexiconProductEntity syncLexProd) {
    this.matchingLexProd = matchingLexProd;
    this.syncLexProd = syncLexProd;
  }

  protected boolean preConditionsMet() {
    return syncLexProd != null;
  }

  protected boolean criteriaViolated() {
    return (matchingLexProd != null &&
      !(matchingLexProd.getProductPubkey().equalsIgnoreCase(syncLexProd.getPubkey())));
  }

  protected ValidationCondition getViolationCondition() {
    return new ProductSyncValidationCondition(ProductSyncValidationCondition.MATCHING_LEX_PROD_EXIST);
  }
}
