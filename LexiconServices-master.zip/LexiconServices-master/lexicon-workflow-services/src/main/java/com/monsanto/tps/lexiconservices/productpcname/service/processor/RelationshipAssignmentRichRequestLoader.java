package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNRelationshipAssignmentRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 11:05 AM
 */
@Component(value = "relationshipAssignmentRichRequestLoader")
public class RelationshipAssignmentRichRequestLoader {

    @Resource
    private ProductRelationshipDao productRelationshipDao;

    @Resource
    private BaseProductDao baseProductDao;

    public APCNRelationshipAssignmentRichRequest loadRelationshipAssignmentData(AssignPCNameRequest request) {
        APCNRelationshipAssignmentRichRequest relationshipAssignment = new APCNRelationshipAssignmentRichRequest();
        setDataFromRequest(request, relationshipAssignment);
        if (!StringUtils.isNullOrEmpty(relationshipAssignment.getRequestedManfName())) {
            setExistingManfNameRelationshipAndVarietyName(relationshipAssignment);
            setBaseProduct(relationshipAssignment);
            setExistingManfNameManfLine(relationshipAssignment);
        }

        return relationshipAssignment;
    }

    private void setExistingManfNameManfLine(APCNRelationshipAssignmentRichRequest relationshipAssignment) {
        ProductRelationshipEntity manufacturingLine = productRelationshipDao.findManufacturingLineByManufacturingName(relationshipAssignment.getRequestedManfName());
        relationshipAssignment.setExistingManfNameManfLine(manufacturingLine);
    }

    private void setBaseProduct(APCNRelationshipAssignmentRichRequest relationshipAssignment) {
        BaseProductEntity baseProductEntity = baseProductDao.findBaseProductByManufacturingName(relationshipAssignment.getRequestedManfName());
        relationshipAssignment.setBaseProduct(baseProductEntity);
    }


    private void setExistingManfNameRelationshipAndVarietyName(APCNRelationshipAssignmentRichRequest relationshipAssignment) {
        ProductRelationshipEntity productRelationshipEntity = productRelationshipDao.findManufacturingAttributesByManufacturingName(relationshipAssignment.getRequestedManfName());
        if (productRelationshipEntity != null) {
            relationshipAssignment.setExistingManfNameVarietyName(productRelationshipEntity.getVarietyName());
            List<ProductRelationshipDTO> products = productRelationshipDao.findProductRelationshipByProductID(productRelationshipEntity.getId());
            relationshipAssignment.setExistingManfNameRelationship(new ProductRelationshipObject(productRelationshipEntity, products));
        }
    }


    private void setDataFromRequest(AssignPCNameRequest request, APCNRelationshipAssignmentRichRequest relationshipAssignment) {
        relationshipAssignment.setRequestedManfName(request.getManufacturingName());
        relationshipAssignment.setRequestedTraitVersion(request.getTraitVersion());
    }
}
