package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.GeneticMaterialDTO;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/6/14
 * Time: 3:23 PM
 */
public interface MidasGeneticMaterialDao extends GenericDao<GeneticMaterialEntity, Long> {

    GeneticMaterialEntity getGeneticMaterial(long productID);

    int insertGeneticMaterial(GeneticMaterialDTO geneticMaterialDTO);

    int updateGermplasm(long germplasmId, long geneticMaterialId);

    GeneticMaterialEntity save(GeneticMaterialEntity entity);
}
