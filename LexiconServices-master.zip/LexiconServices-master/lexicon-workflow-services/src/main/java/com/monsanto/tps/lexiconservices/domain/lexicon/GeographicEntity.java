package com.monsanto.tps.lexiconservices.domain.lexicon;


public interface GeographicEntity {
}
