package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;

public class ValidTraitStackHasMirageCodeRule
        extends SimpleValidationRule {
    private final TPSTrait traitStack;

    public ValidTraitStackHasMirageCodeRule(TPSTrait traitStack) {
        this.traitStack = traitStack;
    }

    protected boolean preConditionsMet() {
        return traitStack != null;
    }

    protected boolean criteriaViolated() {
        return traitStack.getMirageTraitID() == 0;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.MIRAGE_TRAIT_CODE_NOTFOUND_CODE);
    }
}
