package com.monsanto.tps.lexiconrest.service;

import com.monsanto.tps.lexiconrest.loader.ImportModel;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public interface BulkUploadDataSheetParser {

    List<ImportModel> createWorkBook(InputStream fileData) throws IOException;
}