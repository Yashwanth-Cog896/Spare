package com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonCountryXrefEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonCountryXrefDao;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 2:45 PM
 */
public class FbsCommonCountryXrefDaoImpl extends GenericDaoImpl<FbsCommonCountryXrefEntity,String> implements FbsCommonCountryXrefDao {

    public FbsCommonCountryXrefDaoImpl(Class entityClass) {
        super(entityClass);
    }
}
