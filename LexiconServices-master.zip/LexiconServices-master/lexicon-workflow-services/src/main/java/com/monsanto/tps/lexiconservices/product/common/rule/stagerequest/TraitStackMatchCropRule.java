package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;


public class TraitStackMatchCropRule
        extends SimpleValidationRule {
    private final TPSTrait traitStack;
    private final TPSCrop crop;

    public TraitStackMatchCropRule(TPSTrait traitStack, TPSCrop crop) {
        this.traitStack = traitStack;
        this.crop = crop;
    }

    protected boolean preConditionsMet() {
        return crop != null && traitStack != null;
    }

    protected boolean criteriaViolated() {
        return !traitStack.getLexStack().getLexiconCrop().getName().equalsIgnoreCase(crop.getLexiconCropName());
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TRAIT_STACK_CROP_MISMATCH_CODE);
    }
}
