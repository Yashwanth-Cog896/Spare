/*
 StringsCriteriaBuilder was created on Jun 6, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconrest.utilities;

import java.util.List;

/**
 * @author GGSHIV - Jun 6, 2008 12:07:16 PM
 */
public class StringsCriteriaBuilder {

    public static final String EMPTY_DB_STRING = "''";

    public String build(String[] strings) {
        return null == strings ? EMPTY_DB_STRING : buildCriteria(strings);
    }

    public String buildWithoutConvertingToUpperCase(String[] strings) {
        return null == strings ? EMPTY_DB_STRING : buildCriteriaWithoutConvertingToUpperCase(strings);
    }


    private String buildCriteria(String[] strings) {
        StringBuffer sb = new StringBuffer();
        for (String s : strings) {
            sb.append("'").append(getEmptyStringIfNull(s).trim().toUpperCase()).append("', ");
        }
        return sb.toString().substring(0, sb.length() - 2);
    }

    private String buildCriteriaWithoutConvertingToUpperCase(String[] strings) {
        StringBuffer sb = new StringBuffer();
        for (String s : strings) {
            sb.append("'").append(getEmptyStringIfNull(s).trim()).append("', ");
        }
        return sb.toString().substring(0, sb.length() - 2);
    }

    private static String getEmptyStringIfNull(String s) {
        return null == s ? EMPTY_DB_STRING : s;
    }
}
