package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.product.common.domain.InbredHybridEnum;
import com.monsanto.tps.lexiconservices.productpcname.richrequest.TagVarietyNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;


public interface APCNProductAssignmentValidationModel extends TagVarietyNameRequest {
    String getRequestedPCName();

    TPSCrop getRequestedCrop();

    boolean getRequestedParentProductFlag();

    String getRequestedProductClassificationCode();

    boolean isRequestedVegetableProduct();

    ProductGermplasmCollection getAssigningGermplasm();

    boolean isAnyAssigningGermplasmAttachedToProduct();

    LexiconProductEntity getLexProduct();

    MidasProductEntity getLinkedMidasProduct();

    MidasProductNamesCollection getMatchingMidasPN();

    MidasProductNamesCollection getGlobalPCNameRecords();

    InbredHybridEnum getInbredHybridType();

    boolean isContainsPreferredPedegree();

    String getCropByProductClassification();

    boolean isTagVarietyNameInUse();
}
