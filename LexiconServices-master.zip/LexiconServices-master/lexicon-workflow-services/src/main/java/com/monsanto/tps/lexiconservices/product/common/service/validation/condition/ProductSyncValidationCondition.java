package com.monsanto.tps.lexiconservices.product.common.service.validation.condition;

import com.monsanto.tcc.lexiconcommon.validation.StringTableBasedValidationCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;
import com.monsanto.tps.lexiconservices.product.common.condition.*;
import com.monsanto.tps.lexiconservices.productpcname.service.conditions.ExistingLinkedStageCodes;
import com.monsanto.tps.lexiconservices.productpcname.service.conditions.StageConsistencyCodes;
import com.monsanto.tps.lexiconservices.util.string.ProductSyncStringTable;

public class ProductSyncValidationCondition
        extends StringTableBasedValidationCondition
        implements ExistingProductCodes,
        ProductAssignmentCodes,
        RelationshipAssignmentCodes,
        ComlNameRuleCodes,
        StageRequestCodes,
        MatchingStageCodes,
        ExistingLinkedStageCodes,
        StageConsistencyCodes {
    public ProductSyncValidationCondition(ValidationConditionCode code) {
        super(new ProductSyncStringTable(), code);
    }

    public ProductSyncValidationCondition(ValidationConditionCode code, String[] dynamicValues) {
        super(new ProductSyncStringTable(), code, dynamicValues);
    }
}


