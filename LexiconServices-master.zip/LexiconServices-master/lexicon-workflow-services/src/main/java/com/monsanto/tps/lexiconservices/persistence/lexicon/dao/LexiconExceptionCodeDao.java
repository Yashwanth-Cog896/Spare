package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ExceptionCodeEntity;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 1/8/14
 * Time: 12:44 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconExceptionCodeDao extends GenericDao<ExceptionCodeEntity, Long> {
     List<ExceptionCodeEntity> getProductsExceptionCodes(String pubkey);

    ExceptionCodeEntity findByCropAndProductName(Long cropId, String productName);

    String getNextExceptionCodePubkey();

    int insertExceptionCode(String pubkey, Long cropId, String productName, char isPrimaryInd);

    int updateByPubkeyAndProductName(String pubkey, String productName, boolean isPrimaryInd);
}
