package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;

public class ExistLexProdSameManfNameAsRequestRule
        extends SimpleValidationRule {
    private final LexiconProductEntity lexProduct;
    private final ProductRelationshipObject productRelationship;
    private final String manfName;

    public ExistLexProdSameManfNameAsRequestRule(LexiconProductEntity lexProduct,
                                                 ProductRelationshipObject productRelationship, String manfName) {
        this.lexProduct = lexProduct;
        this.productRelationship = productRelationship;
        this.manfName = manfName;
    }

    protected boolean preConditionsMet() {
        return lexProduct != null && !lexProduct.isLogicalDelete();
    }

    protected boolean criteriaViolated() {
        return (productRelationship == null || manfName==null) ? !StringUtils.isNullOrEmpty(manfName) :
                !((manfName).equals(productRelationship.getManufacturingName()));
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.EXIST_LEX_PROD_DIFF_MANF_CODE);
    }
}
