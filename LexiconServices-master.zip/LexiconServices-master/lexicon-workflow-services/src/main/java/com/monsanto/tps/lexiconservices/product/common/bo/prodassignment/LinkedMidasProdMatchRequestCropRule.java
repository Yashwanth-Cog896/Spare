package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 19, 2006
 * Time: 3:29:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class LinkedMidasProdMatchRequestCropRule
        extends SimpleValidationRule {
    private final MidasProductEntity linkedMidasProduct;
    private final TPSCrop crop;

    public LinkedMidasProdMatchRequestCropRule(MidasProductEntity linkedMidasProduct, TPSCrop crop) {
        this.linkedMidasProduct = linkedMidasProduct;
        this.crop = crop;
    }

    protected boolean preConditionsMet() {
        return linkedMidasProduct != null && crop != null;
    }

    protected boolean criteriaViolated() {
        return crop.getMidasCropID() != linkedMidasProduct.getMidasCrop().getId();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.LINKED_MIDAS_PROD_CROP_MISMATCH_CODE);
    }
}
