package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 1:15 PM
 */
@Component(value = "syncProductMirageGeneticMaterialWriter")
public class SyncProductMirageGeneticMaterialWriter {

    @Resource
    private SyncProductMirageSourceGermplasmWriter syncProductMirageSourceGermplasmWriter;

    @Resource
    private SyncProductMirageGeneticMaterialCreator syncProductMirageGeneticMaterialCreator;

    @Resource
    private SyncProductGeneticMaterialRepointingWriter syncProductGeneticMaterialRepointingWriter;


    public GeneticMaterialEntity write(MidasProductEntity midasProduct, GeneticMaterialEntity existingMaterial, ProductGermplasmCollection productGermplasm,
                                       String preComlName, TPSCrop crop) {

        if (existingMaterial == null) {
            MidasProductGermplasmDTO germplasmDTO = syncProductMirageSourceGermplasmWriter.write(midasProduct, preComlName, crop, productGermplasm);
            return (germplasmDTO == null) ? null : syncProductMirageGeneticMaterialCreator.write(germplasmDTO, productGermplasm.getInbredHybridType());
        } else {
            return syncProductGeneticMaterialRepointingWriter.write(existingMaterial, productGermplasm);
        }
    }

}
