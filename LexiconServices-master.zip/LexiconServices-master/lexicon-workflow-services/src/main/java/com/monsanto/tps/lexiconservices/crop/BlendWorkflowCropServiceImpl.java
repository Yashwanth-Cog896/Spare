package com.monsanto.tps.lexiconservices.crop;

import com.monsanto.tps.lexiconservices.crop.service.BlendWorkflowCropService;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BlendWorkflowCropEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.BlendWorkflowCropDao;
import org.apache.cxf.feature.Features;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 4/28/14
 * Time: 11:45 AM
 */
@Component(value = "blendWorkflowCropServiceImpl")
@Transactional(propagation = Propagation.REQUIRED)
@Features(features = "org.apache.cxf.feature.LoggingFeature")
public class BlendWorkflowCropServiceImpl implements BlendWorkflowCropService {

    @Resource
    private BlendWorkflowCropDao blendWorkflowCropDao;

    @Override
    public List<String> getBlendWorkflowCropNames() {
        List<BlendWorkflowCropEntity> blendWorkflowCrops = blendWorkflowCropDao.getAllBlendWorkflowCrops();
        List<String> blendWorkflowCropNames = new ArrayList<String>();
        for (BlendWorkflowCropEntity blendWorkflowCrop : blendWorkflowCrops) {
            blendWorkflowCropNames.add(blendWorkflowCrop.getLexiconCrop().getName());
        }
        return blendWorkflowCropNames;
    }

  @Override
     public List<String> getBlendWorkflowCropPubKeys() {
         List<BlendWorkflowCropEntity> blendWorkflowPubKeys = blendWorkflowCropDao.getAllBlendWorkflowCrops();
         List<String> blendWorkflowCropPubKeys = new ArrayList<String>();
         for (BlendWorkflowCropEntity blendWorkflowCrop : blendWorkflowPubKeys) {
           blendWorkflowCropPubKeys.add(blendWorkflowCrop.getLexiconCrop().getPubkey());
         }
         return blendWorkflowCropPubKeys;
     }
}
