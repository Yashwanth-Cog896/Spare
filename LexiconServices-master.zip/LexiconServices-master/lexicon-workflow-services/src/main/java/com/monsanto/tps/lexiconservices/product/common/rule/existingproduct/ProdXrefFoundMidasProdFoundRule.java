package com.monsanto.tps.lexiconservices.product.common.rule.existingproduct;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class ProdXrefFoundMidasProdFoundRule
        extends SimpleValidationRule {
    private final FbsCommonProductXrefEntity productXref;
    private final MidasProductEntity linkedMidasProduct;

    public ProdXrefFoundMidasProdFoundRule(FbsCommonProductXrefEntity productXref, MidasProductEntity linkedMidasProduct) {
        this.productXref = productXref;
        this.linkedMidasProduct = linkedMidasProduct;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return productXref != null && linkedMidasProduct == null;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.PROD_XREF_EXIST_MIDAS_PROD_DOESNT_CODE);
    }
}
