package com.monsanto.tps.lexiconservices.product.common.processor;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.ExceptionCodeEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistence.fbscommon.dao.FbsCommonProductXrefDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.*;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipHelper;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasGeneticMaterialDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductGermplasmDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasProductNameDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.MidasProductGermplasmDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.*;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidCropException;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.TPSCropLookup;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/5/14
 * Time: 12:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "syncProductLoader")
public class SyncProductLoader {

    @Resource
    private LexiconProductDao lexiconProductDao;

    @Resource
    private LexiconProductStageDao lexiconProductStageDao;

    @Resource
    private CropDao lexiconCropDao;

    @Resource
    private FbsCommonProductXrefDao fbsCommonProductXrefDao;

    @Resource
    private MidasProductDao midasProductDao;

    @Resource
    private MidasProductNameDao midasProductNameDao;

    @Resource
    private MidasProductGermplasmDao midasProductGermplasmDao;

    @Resource
    private MidasGeneticMaterialDao midasGeneticMaterialDao;

    @Resource
    private LexiconExceptionCodeDao lexiconExceptionCodeDao;

    @Resource
    private ProductRelationshipDao productRelationshipDao;

    public void setProductsExceptionCodes(MutableSyncProduct mutableSyncProduct) {
        LexiconProductEntity lexProduct = mutableSyncProduct.getLexProduct();
        if (lexProduct == null) {
            mutableSyncProduct.setProductsExceptionCodes(new ExceptionCodes(new ArrayList<ExceptionCodeEntity>()));
        } else {
            List<ExceptionCodeEntity> exceptionCodes = lexiconExceptionCodeDao.getProductsExceptionCodes(lexProduct.getPubkey());
            mutableSyncProduct.setProductsExceptionCodes(new ExceptionCodes(exceptionCodes));
        }
    }

    public void setMirageGeneticMaterial(MutableSyncProduct mutableSyncProduct) {
        long midasProductID = mutableSyncProduct.determineMidasProductID();
        if (midasProductID != 0) {
            mutableSyncProduct.setMirageGeneticMaterial(midasGeneticMaterialDao.getGeneticMaterial(midasProductID));
        }

    }

    public void setProductGermplasm(MutableSyncProduct mutableSyncProduct) {

        long productID = mutableSyncProduct.determineMidasProductID();
        if (productID == 0) {
            mutableSyncProduct.setProductGermplasm(new ProductGermplasmCollection());

        } else {
            List<MidasProductGermplasmDTO> productGermplasms = midasProductGermplasmDao.findMidasProductGermplasmByProductID(productID);
            mutableSyncProduct.setProductGermplasm(new ProductGermplasmCollection(productGermplasms));
        }
    }

    public void setLinkedMidasProduct(MutableSyncProduct mutableSyncProduct) {
        if (mutableSyncProduct.getProductXref() != null) {
            mutableSyncProduct.setLinkedMidasProduct(mutableSyncProduct.getProductXref().getMidasProduct());
        }
    }

    public void setGlobalPCNameRecords(MutableSyncProduct mutableSyncProduct) {
        long productID = mutableSyncProduct.determineMidasProductID();
        List<MidasProductNameEntity> globalPCNames = midasProductNameDao.findGlobalPCNamesByProductID(productID);
        mutableSyncProduct.setGlobalPCNameRecords(new MidasProductNamesCollection(globalPCNames));
    }

    public void setProductRelationship(MutableSyncProduct mutableSyncProduct) {
        LexiconProductEntity lexProduct = mutableSyncProduct.getLexProduct();
        ProductRelationshipObject relationship = null;

        if (lexProduct != null) {
            //TODO change dao interface later to return ProductRelationshipObject
            ProductRelationshipHelper relationshipHelper = productRelationshipDao.getRelationshipByProductPubkey(lexProduct.getPubkey());
            relationship = new ProductRelationshipObject(relationshipHelper.getManufacturingName(), relationshipHelper.getRelationshipPubkey(),
                    relationshipHelper.getProductRelationshipDTOList());
        }
        mutableSyncProduct.setProductRelationship(relationship);
    }

    public void setMatchingMidasPN(MutableSyncProduct mutableSyncProduct) {
        List<MidasProductNameEntity> midasProductNames = new ArrayList<MidasProductNameEntity>();
        if (mutableSyncProduct.getPreComlName() != null) {
            midasProductNames = midasProductNameDao.findMatchingMidasNamesByProductName(mutableSyncProduct.getPreComlName());
        }
        mutableSyncProduct.setMatchingMidasPN(new MidasProductNamesCollection(midasProductNames));
    }

    public void setProductXref(MutableSyncProduct mutableSyncProduct) {
        if (mutableSyncProduct.getLexProduct() != null) {
            FbsCommonProductXrefEntity productXref = fbsCommonProductXrefDao.findProductXrefByPubKey(mutableSyncProduct.getLexProduct().getPubkey());
            mutableSyncProduct.setProductXref(productXref);
        }
    }

    public void setRequestedVegetableProduct(MutableSyncProduct mutableSyncProduct) {
        boolean vegetableCrop = lexiconCropDao.isVegetableCrop(mutableSyncProduct.getCropName());
        mutableSyncProduct.setRequestedVegetableProduct(vegetableCrop);
    }

    public void setCrop(MutableSyncProduct mutableSyncProduct) {
        TPSCrop crop = loadCrop(mutableSyncProduct.getCropName());
        mutableSyncProduct.setCrop(crop);

    }

    public TPSCrop loadCrop(String cropName) {
        try {
            TPSCropLookup lookup = TPSCropLookup.instance();
            return lookup.getCropByCropName(cropName);
        } catch (InvalidCropException e) {
            return null;
        }
    }

    public void setLexProductNames(MutableSyncProduct mutableSyncProduct) {
        List<LexiconProductStageEntity> lexiconProductNames = new ArrayList<LexiconProductStageEntity>();
        if (mutableSyncProduct.getLexProduct() != null) {
            lexiconProductNames = lexiconProductStageDao.findByProductPubkey(mutableSyncProduct.getLexProduct().getPubkey());
        }
        mutableSyncProduct.setLexiconProductNames(new LexiconProductNames(lexiconProductNames));
    }

    public void setLexiconProductByPubKey(MutableSyncProduct mutableSyncProduct) {
        LexiconProductEntity lexiconProduct = lexiconProductDao.getProductByProductPubKey(mutableSyncProduct.getPubKey());
        if (lexiconProduct != null) {
            mutableSyncProduct.setParentProduct(lexiconProduct.isParentProduct());
        }
        mutableSyncProduct.setLexProduct(lexiconProduct);
    }

    public void setLexiconProductByPreComlName(MutableSyncProduct mutableSyncProduct) {
        LexiconProductEntity lexiconProduct = lexiconProductDao.getProductByPreCommercialName(mutableSyncProduct.getPreComlName());
        if (lexiconProduct != null) {
            mutableSyncProduct.setParentProduct(lexiconProduct.isParentProduct());
        }
        mutableSyncProduct.setLexProduct(lexiconProduct);
    }
}
