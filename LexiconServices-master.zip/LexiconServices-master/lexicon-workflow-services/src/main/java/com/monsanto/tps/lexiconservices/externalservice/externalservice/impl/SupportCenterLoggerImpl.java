package com.monsanto.tps.lexiconservices.externalservice.externalservice.impl;

import com.monsanto.tcc.inventorycommon.service.InventoryProductNameLinkageService;
import com.monsanto.tcc.inventorycommon.transferobject.PreCommercialLinkageResponse;
import com.monsanto.tps.lexiconservices.externalservice.externalservice.SupportCenterLogger;
import com.monsanto.tps.lexiconservices.externalservice.externalservice.TaskItemFactory;
import com.monsanto.tps.support.service.SupportCenterClient;
import com.monsanto.tps.support.service.TaskItem;
import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class SupportCenterLoggerImpl implements SupportCenterLogger {

  public static final String PRECOMMERCIAL_PRODUCT = "precommercial";

  private static final org.apache.log4j.Logger log = Logger.getLogger(SupportCenterLoggerImpl.class);

  @Resource
  private InventoryProductNameLinkageService inventoryProductNameLinkageService;

  @Resource
  private TaskItemFactory taskItemFactory;

  @Resource
  private SupportCenterClient supportCenterClient;

  public void updatePrecommercials(List<String> productPubkeys) {
    if (!productPubkeys.isEmpty()) {
      try {
        List<PreCommercialLinkageResponse> responses = inventoryProductNameLinkageService.updatePreCommercialInventoryProductNameLinkage(productPubkeys);
        supportCenterLogPreCommercial(responses);
        supportCenterLogException(PRECOMMERCIAL_PRODUCT);
      } catch (RuntimeException e) {
        supportCenterLogException(PRECOMMERCIAL_PRODUCT, e);
        log.error(e.getMessage(), e);
      }
    }
  }

  private void supportCenterLogException(String itemId, RuntimeException e) {
    supportCenterClient.reportIssues(Arrays.asList(taskItemFactory.createTaskItem(TaskItemFactory.INVENTORY_PRODUCT_NAME_LINKAGE, itemId, e)));
  }

  private void supportCenterLogException(String itemId) {
    supportCenterClient.reportIssues(Arrays.asList(taskItemFactory.createTaskItem(TaskItemFactory.INVENTORY_PRODUCT_NAME_LINKAGE, itemId, true, null)));
  }

  private void supportCenterLogPreCommercial(List<PreCommercialLinkageResponse> responses) {
    List<TaskItem> taskItems = new ArrayList<TaskItem>(responses.size());
    for (PreCommercialLinkageResponse response : responses) {
      TaskItem taskItem = taskItemFactory.createTaskItem(TaskItemFactory.INVENTORY_PRODUCT_NAME_LINKAGE, PRECOMMERCIAL_PRODUCT + ":" + response.getProductPublicKey(),
        !hasErrors(response.getErrorMessages()), buildErrorText(PRECOMMERCIAL_PRODUCT, response.getErrorMessages(), response.getProductPublicKey()));
      taskItems.add(taskItem);
      if (!taskItem.isSuccess()) {
        log.error(taskItem.getErrorMessage());
      }
    }
    supportCenterClient.reportIssues(taskItems);
  }

  private boolean hasErrors(List<String> errorMessages) {
    return !CollectionUtils.isEmpty(errorMessages);
  }

  private String buildErrorText(String typeOfPublicKey, List<String> errorMessages, String publicKey) {
    StringBuffer errorText = new StringBuffer();
    if (hasErrors(errorMessages)) {
      errorText.append("Error for ").append(typeOfPublicKey).append(" pubkey '").append(publicKey).append("':").append("\n");
      for (String errorMessage : errorMessages) {
        errorText.append("    - ").append(errorMessage).append("\n");
      }
      errorText.append("\n\n");
    }
    return errorText.toString();
  }

  public void setInventoryProductNameLinkageService(InventoryProductNameLinkageService inventoryProductNameLinkageService) {
    this.inventoryProductNameLinkageService = inventoryProductNameLinkageService;
  }

  public void setTaskItemFactory(TaskItemFactory taskItemFactory) {
    this.taskItemFactory = taskItemFactory;
  }

  public void setSupportCenterClient(SupportCenterClient supportCenterClient) {
    this.supportCenterClient = supportCenterClient;
  }
}