package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;

/**
 * Created with IntelliJ IDEA.
 * User: pseth
 * Date: 1/19/15
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStagePreComlCountryQuery extends AbstractPersistentStoreEntityExistsQuery {

    private String preComlName;
    private String brandName;
    private String countryName;


    public ProductStagePreComlCountryQuery(String preComlName,String brandName, String countryName) {
        this.preComlName = preComlName;
        this.brandName = brandName;
        this.countryName = countryName;
    }

    protected String getSQL()
            throws WrappingException {
        return "select * from lexicon.product_stage where product_id in (select PRODUCT_ID from lexicon.pre_coml_product where PRE_COML_NAME in " +
                "'" + preComlName + "')" +
                "and brand_id in (select brand_id from lexicon.brand where brand_name IN " + "'"+ brandName + "'" +")" +
                " and country_id in (select country_id from lexicon.country where country_abbr IN " + "'" + countryName + "'" + " )";
    }

    protected Object[] getBindVariables() throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
