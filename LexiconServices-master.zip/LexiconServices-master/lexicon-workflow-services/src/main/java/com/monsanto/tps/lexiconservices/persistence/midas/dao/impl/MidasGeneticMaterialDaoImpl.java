package com.monsanto.tps.lexiconservices.persistence.midas.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.MidasGeneticMaterialDao;
import com.monsanto.tps.lexiconservices.persistence.midas.dao.domain.GeneticMaterialDTO;
import org.hibernate.criterion.Restrictions;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/6/14
 * Time: 3:27 PM
 */
public class MidasGeneticMaterialDaoImpl extends GenericDaoImpl<GeneticMaterialEntity, Long> implements MidasGeneticMaterialDao {

  public static final String INSERT_GENETIC_MATERIAL = "GeneticMaterialDao.insertGeneticMaterial";

  public MidasGeneticMaterialDaoImpl(Class entityClass) {
    super(entityClass);
  }

  public GeneticMaterialEntity getGeneticMaterial(long productID) {
    return (GeneticMaterialEntity) getSessionFactory().getCurrentSession().createCriteria(GeneticMaterialEntity.class, "geneticMaterial").
      createAlias("geneticMaterial.germplasm", "germplasm").
      createAlias("germplasm.productGermplasms", "productGermplasms").
      createAlias("productGermplasms.midasProduct", "midasProduct").
      add(Restrictions.eq("midasProduct.id", productID)).add(Restrictions.eq("germplasm.deleted", false)).
      add(Restrictions.ilike("geneticMaterial.source", "%MIRAGE%")).setFetchSize(1).uniqueResult();

  }

  public int insertGeneticMaterial(GeneticMaterialDTO geneticMaterialDTO) {
    return getSessionFactory().getCurrentSession().getNamedQuery(INSERT_GENETIC_MATERIAL).
      setParameter("geneticMaterialID", geneticMaterialDTO.getGeneticMaterialID()).
      setParameter("germplasmID", geneticMaterialDTO.getGermplasmID()).
      setParameter("sourcsStr", geneticMaterialDTO.getSource()).
      setParameter("generation", geneticMaterialDTO.getGeneration()).
      setParameter("lineage", geneticMaterialDTO.getLineage()).executeUpdate();
  }

    @Override
    public int updateGermplasm(long germplasmId, long geneticMaterialId) {
        return getSessionFactory().getCurrentSession().getNamedQuery("MidasGeneticMaterialDao.updateGermplasm")
                .setParameter("germplasmId",germplasmId).setParameter("geneticMaterialId",geneticMaterialId).executeUpdate();
    }

    public GeneticMaterialEntity save(GeneticMaterialEntity entity) {
        Long id = (Long) getSessionFactory().getCurrentSession().save(entity);
        return get(id) ;
    }


}
