package com.monsanto.tps.lexiconservices.productpcname.service.domain;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/3/14
 * Time: 12:54 PM
 */
public class TPSBrand {

    public static final String PRE_COML_BRAND = "MONSANTO";

    private final String brandName;
    private final long midasBrandID;
    private final long midasCompanyID;
    private final String midasCompanyName;
    private final long mirageCompanyID;
    private final String lexiconBrandName;
    private final long lexiconBrandID;
    private final long lexiconCompanyID;
    private final String lexiconCompanyName;
    private final String lexiconBrandPubkey;
    private final boolean lexiconTdRestricted;

    public TPSBrand(
            String brandName,
            long midasBrandID,
            long midasCompanyID,
            String midasCompanyName,
            int mirageCompanyID,
            String lexiconBrandName,
            long lexiconBrandID,
            long lexiconCompanyID,
            String lexiconCompanyName,
            String lexiconBrandPubkey,
            boolean lexiconTdRestricted)
    {
        this.brandName = brandName;
        this.midasBrandID = midasBrandID;
        this.midasCompanyID = midasCompanyID;
        this.midasCompanyName = midasCompanyName;
        this.mirageCompanyID = mirageCompanyID;
        this.lexiconBrandName = lexiconBrandName;
        this.lexiconBrandID = lexiconBrandID;
        this.lexiconCompanyID = lexiconCompanyID;
        this.lexiconCompanyName = lexiconCompanyName;
        this.lexiconBrandPubkey = lexiconBrandPubkey;
        this.lexiconTdRestricted = lexiconTdRestricted;
    }

    public String getBrandName() {
        return brandName;
    }

    public long getMidasBrandID() {
        return midasBrandID;
    }

    public long getMidasCompanyID() {
        return midasCompanyID;
    }

    public String getMidasCompanyName() {
        return midasCompanyName;
    }

    public long getMirageCompanyID() {
        return mirageCompanyID;
    }

    public String getLexiconBrandName() {
        return lexiconBrandName;
    }

    public long getLexiconBrandID() {
        return lexiconBrandID;
    }

    public long getLexiconCompanyID() {
        return lexiconCompanyID;
    }

    public String getLexiconCompanyName() {
        return lexiconCompanyName;
    }

    public String getLexiconBrandPubkey() {
        return lexiconBrandPubkey;
    }

    public boolean isLexiconTdRestricted() {
        return lexiconTdRestricted;
    }

    public boolean isMidasBrand() {
        return midasBrandID != 0 && midasCompanyID != 0;
    }

    public boolean isMirageBrand() {
        return mirageCompanyID != 0;
    }

    public boolean isLexiconBrand() {
        return lexiconBrandID != 0 && lexiconCompanyID != 0;
    }

    public boolean isPreComlBrand() {
        return (PRE_COML_BRAND.equals(brandName));
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TPSBrand tpsBrand = (TPSBrand)o;

        if (midasBrandID != tpsBrand.midasBrandID) {
            return false;
        }
        if (midasCompanyID != tpsBrand.midasCompanyID) {
            return false;
        }
        if (mirageCompanyID != tpsBrand.mirageCompanyID) {
            return false;
        }

        return true;
    }

    public int hashCode() {
        int result;
        result = (int)(midasBrandID ^ (midasBrandID >>> 32));
        result = 31 * result + (int)(midasCompanyID ^ (midasCompanyID >>> 32));
        result = (int) (31 * result + mirageCompanyID);
        return result;
    }

    public boolean isTdRestricted() {
        return lexiconTdRestricted;
    }

}
