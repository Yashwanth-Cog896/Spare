package com.monsanto.tps.lexiconservices.productpcname.validation;

import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tps.lexiconservices.productpcname.validation.rule.*;


/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 15, 2006
 * Time: 4:37:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPCNameValidation
        extends RulesValidatorCollection {
    private final AssignPCNameValidationModel model;

    public AssignPCNameValidation(AssignPCNameValidationModel model) {
        this.model = model;
    }

    protected RulesValidator[] getRulesValidators() {
        return new RulesValidator[]{
                new APCNExistingSyncProductRules(model),
                new APCNProductAssignmentRules(model),
                new APCNRelationshipAssignmentRules(model),
                new APCNAssigningGermplasmRules(model.getAssigningGermplasm(), model.getInbredHybridType(), model.isContainsPreferredPedegree()),
                new APCNDefaultStageValidationRules(model),

        };
    }
}
