package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.product.common.rule.stagerequest.RowCropProductsMustHaveARowCropPhaseRule;
import com.monsanto.tps.lexiconservices.product.common.rule.stagerequest.StageTypeValidRule;
import com.monsanto.tps.lexiconservices.product.common.rule.stagerequest.ValidTraitStackHasMirageCodeRule;
import com.monsanto.tps.lexiconservices.product.common.rule.stagerequest.VegetableProductsMustHaveAVegetablePhaseRule;
import com.monsanto.tps.lexiconservices.product.common.service.validation.stagepart.ComlAttributeRules;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSTrait;
import com.monsanto.tps.lexiconservices.productpcname.validation.AssignPCNameValidationModel;

import java.util.ArrayList;
import java.util.List;

public class APCNDefaultStageValidationRules
        extends RulesValidatorCollection {
    private final AssignPCNameValidationModel model;

    public APCNDefaultStageValidationRules(AssignPCNameValidationModel model) {
        this.model = model;
    }

    protected RulesValidator[] getRulesValidators() {
        return model.shouldCreateDefaultStage() ? getCreatingDefaultStageRules() : new RulesValidator[0];
    }

    private RulesValidator[] getCreatingDefaultStageRules() {
        List<RulesValidator> rulesValidators = new ArrayList<RulesValidator>();
        rulesValidators.add(new RuleSeverityPair(new StageTypeValidRule(model.getRequestedStageType()), ValidationConditionSeverity.ERROR));
        rulesValidators.add(new RuleSeverityPair(new VegetableProductsMustHaveAVegetablePhaseRule(model.isRequestedVegetableProduct(), model.getRequestedStageType()), ValidationConditionSeverity.ERROR));
        rulesValidators.add(new RuleSeverityPair(new RowCropProductsMustHaveARowCropPhaseRule(model.isRequestedVegetableProduct(), model.getRequestedStageType()), ValidationConditionSeverity.ERROR));
        rulesValidators.add(new ComlAttributeRules(model.getRequestedCrop(), getFirstTraitStack(), model.getRequestedMaturity(), true, false, model.isParentProduct(), model.getTraitStackIdsForGermplasm()));
        rulesValidators.addAll(rulesForRemainingTraits());
        return rulesValidators.toArray(new RulesValidator[rulesValidators.size()]);
    }

    private List<RulesValidator> rulesForRemainingTraits() {
        List<TPSTrait> remainingTraits = getRemainingTraitStacks();
        List<RulesValidator> rulesForRemainingTraits = new ArrayList<RulesValidator>();
        for (TPSTrait remainingTrait : remainingTraits) {
            rulesForRemainingTraits.add(getValidTraitStackHasMirageCodeRule(remainingTrait));
        }
        return rulesForRemainingTraits;
    }

    private RuleSeverityPair getValidTraitStackHasMirageCodeRule(TPSTrait traitStack) {
        return new RuleSeverityPair(new ValidTraitStackHasMirageCodeRule(traitStack), ValidationConditionSeverity.ERROR);
    }

    private TPSTrait getFirstTraitStack() {
        List<TPSTrait> traitStacks = model.getRequestedTraitStacks();
        return (traitStacks != null && traitStacks.isEmpty()) ? null : traitStacks.get(0);
    }

    private List<TPSTrait> getRemainingTraitStacks() {
        List<TPSTrait> traitStacks = model.getRequestedTraitStacks();
        if (traitStacks == null || traitStacks.size() <= 1) {
            return new ArrayList<TPSTrait>();
        } else {
            traitStacks.remove(1);
            return traitStacks;
        }
    }

}
