package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class AssigningGermplasmNotAttachedToProductRule
        extends SimpleValidationRule {
    private final boolean assigningGermplasmAttachedToProduct;

    public AssigningGermplasmNotAttachedToProductRule(boolean assigningGermplasmAttachedToProduct) {
        this.assigningGermplasmAttachedToProduct = assigningGermplasmAttachedToProduct;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {
        return assigningGermplasmAttachedToProduct;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ASSIGNING_GP_ATTACHED_TO_PRODUCT_CODE);
    }
}