package com.monsanto.tps.lexiconservices.product.common.condition;

import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 19, 2006
 * Time: 9:55:13 AM
 */
public interface RelationshipAssignmentCodes {
    ValidationConditionCode MANF_NAME_INVALID_CODE = new ValidationConditionCode("ManfNameInvalid");
    ValidationConditionCode TRAIT_VERS_INVALID_CODE = new ValidationConditionCode("TraitVersInvalid");
    ValidationConditionCode TRAIT_VER_SPEC_MANF_NOT_CODE = new ValidationConditionCode("TraitVerSpecManfNot");
    ValidationConditionCode PROD_REL_PROD_EXISTS_VERS_NOT_SPEC_CODE = new ValidationConditionCode("ProdRelProdExistsTraitVersNotSpec");
    ValidationConditionCode HYBRID_MANF_NAME_NOT_FOUND_CODE = new ValidationConditionCode("HybridManfNameNotFound");
    ValidationConditionCode TRAIT_VERS_EXISTS_CODE = new ValidationConditionCode("TraitVersExists");
    ValidationConditionCode EXIST_LEX_PROD_DIFF_MANF_CODE = new ValidationConditionCode("ExistLexProdDiffManf");
    ValidationConditionCode EXIST_LEX_PROD_DIFF_MANF_VER = new ValidationConditionCode("ExistLexProdDiffTraitVer");
    ValidationConditionCode MATCHING_LEX_PROD_EXIST = new ValidationConditionCode("MatchingLexProdExists");

    ValidationConditionCode REQUESTED_PARENT_FLAG_DIFFERS_FROM_BASE_PRODUCTS = new ValidationConditionCode("RequestedParentFlagDiffersFromBaseProductsParentFlag");
    ValidationConditionCode REQUESTED_CROP_DIFFERS_FROM_BASE_PRODUCTS = new ValidationConditionCode("RequestedCropDiffersFromBaseProductsCrop");
    ValidationConditionCode SPEC_MANUFACTURING_NAME_DOES_NOT_EXIST = new ValidationConditionCode("SpecifiedManufacturingNameDoesNotExist");
    ValidationConditionCode MANF_LINE_IS_LOGICALLY_DELETED = new ValidationConditionCode("ManufacturingLineIsLogicallyDeleted");
    ValidationConditionCode BASE_PRODUCT_DOES_NOT_EXIST = new ValidationConditionCode("BaseProductDoesNotExist");
    ValidationConditionCode MATCHING_PRECOMLPROD_DOES_EXIST = new ValidationConditionCode("LexProdNotExists");
    ValidationConditionCode IMAGE_PIXELS_EXCEED_LIMIT = new ValidationConditionCode("imagePixelsExceedLimit");
    ValidationConditionCode IMAGE_FORMAT_INVALID = new ValidationConditionCode("imageFormatInvalid");
    ValidationConditionCode IMAGE_DISPLAY_NAME_EXISTS = new ValidationConditionCode("imageDisplayNameExists");
    ValidationConditionCode IMAGE_DISPLAY_NAME_EXCEEDS_MAX_LENGTH = new ValidationConditionCode("imageDisplayNameExceedsMaxLength");

    ValidationConditionCode MATCHING_ROYALTY_CONTRACT_ALREADY_EXISTS = new ValidationConditionCode("MatchingRoyaltyContractAlreadyExists");
    ValidationConditionCode MATCHING_ROYALTY_CONTRACT_DOES_NOT_EXIST = new ValidationConditionCode("MatchingRoyaltyContractDoesNotExist");
    ValidationConditionCode CONTRACT_NUMBER_EXCEEDS_THE_MAX_LENGTH = new ValidationConditionCode("ContractNumberExceedsTheMaxLength");
    ValidationConditionCode EXT_GERMPLASM_NAME_EXCEEDS_MAX_LENGTH = new ValidationConditionCode("ExtGermplasmNameExceedsMaxLength");
    ValidationConditionCode COMMENTS_EXCEED_MAX_LENGTH = new ValidationConditionCode("CommentsExceedMaxLength");
    ValidationConditionCode MISSING_COMPANY = new ValidationConditionCode("MissingCompany");
    ValidationConditionCode DUPLICATE_CONTRACT = new ValidationConditionCode("DuplicateContract");
    ValidationConditionCode MATCHING_CONTRACT_COMMENTS = new ValidationConditionCode("ExternalGermplasmAndComments");
}
