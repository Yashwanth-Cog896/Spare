package com.monsanto.tps.lexiconservices.persistence.midas.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/27/13
 * Time: 3:12 PM
 */
public interface MidasProductDao extends GenericDao<MidasProductEntity, Long> {

    int updateDenominationByPublicKey(String denomination, String pubKey);

    MidasProductEntity save(MidasProductEntity product);

    void updateDenominationAndRefActive(long id, String denomination, boolean refActive);
}
