package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/29/14
 * Time: 1:05 PM
 */
public class AssignPCNameRichRequest {

    private MutableSyncProduct syncProduct;
    private APCNProductAssignmentRichRequest productAssignmentData;
    private APCNRelationshipAssignmentRichRequest relationshipAssignmentData;
    private APCNDefaultStageAttributesRichRequest defaultStageAttributes;


    public MutableSyncProduct getSyncProduct() {
        return syncProduct;
    }

    public void setSyncProduct(MutableSyncProduct syncProduct) {
        this.syncProduct = syncProduct;
    }

    public APCNProductAssignmentRichRequest getProductAssignmentData() {
        return productAssignmentData;
    }

    public void setProductAssignmentData(APCNProductAssignmentRichRequest productAssignmentData) {
        this.productAssignmentData = productAssignmentData;
    }

    public APCNRelationshipAssignmentRichRequest getRelationshipAssignmentData() {
        return relationshipAssignmentData;
    }

    public void setRelationshipAssignmentData(APCNRelationshipAssignmentRichRequest relationshipAssignmentData) {
        this.relationshipAssignmentData = relationshipAssignmentData;
    }

    public APCNDefaultStageAttributesRichRequest getDefaultStageAttributes() {
        return defaultStageAttributes;
    }

    public void setDefaultStageAttributes(APCNDefaultStageAttributesRichRequest defaultStageAttributes) {
        this.defaultStageAttributes = defaultStageAttributes;
    }
}
