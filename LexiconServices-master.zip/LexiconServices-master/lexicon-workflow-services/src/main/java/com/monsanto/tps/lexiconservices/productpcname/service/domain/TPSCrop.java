package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.Util.statistics.RangeCheck;

import java.math.BigDecimal;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/30/14
 * Time: 10:14 AM
 */
public class TPSCrop {
    //TODO Move to common folder
    private static final long VEGETABLE_CROP = 1;
    private final long midasCropID;
    private final String midasCropName;
    private final String mirageBayerCode;
    private BigDecimal relativeMaturityMin;
    private BigDecimal relativeMaturityMax;
    private BigDecimal relativeMaturityIncrement;
    private long lexiconCropID;
    private String lexiconAbbreviation;
    private String lexiconPubkey;
    private String lexiconCropName;
    private boolean vegetable;
    private boolean varietyNameGenerated;

    public TPSCrop(long midasCropID, String midasCropName, String mirageBayerCode) {
        this.midasCropID = midasCropID;
        this.midasCropName = (null == midasCropName) ? null : midasCropName.trim().toUpperCase();
        this.mirageBayerCode = (null == mirageBayerCode) ? null : mirageBayerCode.trim().toUpperCase();
    }

    public void setLexiconAttributes(long cropID, String pubkey, String cropName, String abbreviation, long lexiconStageCategoryId, boolean varietyNameGenerated) {
        this.lexiconCropID = cropID;
        this.lexiconPubkey = pubkey;
        this.lexiconCropName = cropName;
        this.lexiconAbbreviation = abbreviation;
        this.varietyNameGenerated = varietyNameGenerated;
        this.vegetable = (lexiconStageCategoryId == VEGETABLE_CROP);
    }

    public void setRelativeMaturityRange(BigDecimal min, BigDecimal max, BigDecimal increment) {
        this.relativeMaturityMin = min;
        this.relativeMaturityMax = max;
        this.relativeMaturityIncrement = increment;
    }

    public boolean existsInMidas() {
        return midasCropID != 0;
    }

    public long getMidasCropID() {
        return midasCropID;
    }

    public String getMidasCropName() {
        return midasCropName;
    }

    public String getMirageBayerCode() {
        return mirageBayerCode;
    }

    public BigDecimal getRelativeMaturityMin() {
        return relativeMaturityMin;
    }

    public void setRelativeMaturityMin(BigDecimal relativeMaturityMin) {
        this.relativeMaturityMin = relativeMaturityMin;
    }

    public BigDecimal getRelativeMaturityMax() {
        return relativeMaturityMax;
    }

    public void setRelativeMaturityMax(BigDecimal relativeMaturityMax) {
        this.relativeMaturityMax = relativeMaturityMax;
    }

    public BigDecimal getRelativeMaturityIncrement() {
        return relativeMaturityIncrement;
    }

    public void setRelativeMaturityIncrement(BigDecimal relativeMaturityIncrement) {
        this.relativeMaturityIncrement = relativeMaturityIncrement;
    }

    public long getLexiconCropID() {
        return lexiconCropID;
    }

    public void setLexiconCropID(long lexiconCropID) {
        this.lexiconCropID = lexiconCropID;
    }

    public String getLexiconAbbreviation() {
        return lexiconAbbreviation;
    }

    public void setLexiconAbbreviation(String lexiconAbbreviation) {
        this.lexiconAbbreviation = lexiconAbbreviation;
    }

    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public String getLexiconCropName() {
        return lexiconCropName;
    }

    public void setLexiconCropName(String lexiconCropName) {
        this.lexiconCropName = lexiconCropName;
    }

    public boolean isVegetable() {
        return vegetable;
    }

    public void setVegetable(boolean vegetable) {
        this.vegetable = vegetable;
    }

    public boolean isVarietyNameGenerated() {
        return varietyNameGenerated;
    }

    public void setVarietyNameGenerated(boolean varietyNameGenerated) {
        this.varietyNameGenerated = varietyNameGenerated;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || !getClass().isAssignableFrom(o.getClass())) {
            return false;
        }

        TPSCrop tpsCrop = (TPSCrop) o;

        if (lexiconCropID != tpsCrop.lexiconCropID) {
            return false;
        }
        if (midasCropID != tpsCrop.midasCropID) {
            return false;
        }
        if (mirageBayerCode != null ? !mirageBayerCode.equals(tpsCrop.mirageBayerCode) : tpsCrop.mirageBayerCode != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (midasCropID ^ (midasCropID >>> 32));
        result = 31 * result + (mirageBayerCode != null ? mirageBayerCode.hashCode() : 0);
        result = 31 * result + (int) (lexiconCropID ^ (lexiconCropID >>> 32));
        return result;
    }

    public boolean isValidMaturity(double maturity) {
        if (existsInMidas()) {
            if (relativeMaturityMin.compareTo(relativeMaturityMax) > -1) {
                return false;
            } else {
                RangeCheck rangeCheck = new RangeCheck(relativeMaturityMin.doubleValue(), relativeMaturityMax.doubleValue(), relativeMaturityIncrement.doubleValue());
                return rangeCheck.inRange(maturity);
            }
        } else {
            return true;
        }
    }

}
