package com.monsanto.tps.lexiconservices.productpcname.service.processor;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/30/14
 * Time: 12:31 PM
 */
public class TPSCropLookupErrorFormatter {
    public static final String INVALID_CROP_ERROR = " is not a valid crop for associating with a Product";
    public static final String INVALID_BAYER_ERROR = " is not a valid bayer code for associating with a Product";


    public String formatCropNameError(String requestName) {
        return requestName + INVALID_CROP_ERROR;
    }
}