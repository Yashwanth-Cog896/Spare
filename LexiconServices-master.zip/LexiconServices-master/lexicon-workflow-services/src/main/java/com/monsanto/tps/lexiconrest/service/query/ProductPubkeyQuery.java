package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.BrandDTO;
import com.monsanto.tps.lexiconrest.ProductDTO;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:11:25 PM
 */
public class ProductPubkeyQuery
        extends AbstractPersistentStoreMultiRowQuery {
    private String[] preCommercialName;
    private String selectProductPubkey = "select PRODUCT_PUBKEY, pre_coml_name from lexicon.pre_coml_product where pre_coml_name in ( ";

    public ProductPubkeyQuery(String[] preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public List<ProductDTO> find()
            throws WrappingException {
        return getList();
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return createProductObject(row);
    }

    private Object createProductObject(PersistentStoreResultSetRow row) throws WrappingException {
        ProductDTO brandDTO = new ProductDTO(row.getString("pre_coml_name"), getNonNull(row.getString("PRODUCT_PUBKEY")));
        return brandDTO;
    }

    private String getNonNull(String string) {
        return string == null ? "" : string;
    }

    protected String getSQL()
            throws WrappingException {
        return selectProductPubkey + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(preCommercialName) + ")";
    }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
