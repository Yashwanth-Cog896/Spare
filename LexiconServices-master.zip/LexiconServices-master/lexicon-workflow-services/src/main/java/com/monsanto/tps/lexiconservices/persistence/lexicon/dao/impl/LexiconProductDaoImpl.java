package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.LexiconMonsantoProductDTO;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.ProductRelationshipDTO;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: skuma
 * Date: 11/28/13
 * Time: 10:39 AM
 */
public class LexiconProductDaoImpl extends GenericDaoImpl<LexiconProductEntity, Long> implements LexiconProductDao {

    public static final String UPDATE_RELATIONSHIP_PRODUCTS_VARIETY_NAMES = "LexiconProductDao.updateRelationshipProductsVarietyNames";
    public static final String INSERT_LEXICON_PRODUCT = "LexiconProductDao.insertLexiconProduct";
  public static final String GET_MATCHING_LEXICON_PRODUCT = "LexiconProductDao.getMatchingLexiconProduct";
  public static final String GET_TAG_VARIETY_NAMES_BY_REGEXAND_CROP = "LexiconProductDao.getTagVarietyNamesByREGEXAndCrop";
  public static final String UPDATE_LEXICON_PRODUCT_BY_PUB_KEY = "LexiconProductDao.updateLexiconProductByPubKey";
  private final String GET_NEXT_PRODUCT_PUBKEY = "LexiconProductDao.getNextPubkeySeq";
    private final String UNDELETE_LEXICON_PRODUCT = "LexiconProductDao.unDeleteLexiconProduct";
    private final String GET_NEXT_VARIETY_NAME = "LexiconProductDao.getNextVarietyNameSeq";

    public LexiconProductDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public int updateRelationshipProductsVarietyNames(String manufacturingName, String varietyName) {
        return getSessionFactory().getCurrentSession().getNamedQuery(UPDATE_RELATIONSHIP_PRODUCTS_VARIETY_NAMES).
                setParameter("varietyName", varietyName).
                setParameter("manufacturingName", manufacturingName).executeUpdate();
    }

    @Override
    public LexiconProductEntity getProductByPreCommercialName(String preCommercialName) {

        return (LexiconProductEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconProductEntity.class, "product").
                createAlias("product.lexiconCrop", "crop").
                createAlias("product.supplyChainOwnerGroup", "supplyChainOwnerGroup", CriteriaSpecification.LEFT_JOIN).
                createAlias("product.productClassification", "productClassification", CriteriaSpecification.LEFT_JOIN)
                .add(Restrictions.eq("product.preCommercialName", preCommercialName)).uniqueResult();
    }

    @Override
    public List<String> getPubkeysByTagVarietyName(String tagVarietyName, Long cropID) {
        List<String> pubkeys = new ArrayList<String>();
        Criteria queryCriteria = getSessionFactory().getCurrentSession().createCriteria(LexiconProductEntity.class, "product");
        queryCriteria.createAlias("product.lexiconCrop", "crop").
                add(Restrictions.ne("product.logicalDelete", true)).
                add(Restrictions.eq("product.tagVarietyName", tagVarietyName)).
                add(Restrictions.eq("crop.id", cropID));
        queryCriteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        List<LexiconProductEntity> lexiconProductEntityList = (List<LexiconProductEntity>) queryCriteria.list();
        if (!lexiconProductEntityList.isEmpty()) {
            for (LexiconProductEntity lexiconProductEntity : lexiconProductEntityList) {
                pubkeys.add(lexiconProductEntity.getPubkey());
            }
        }
        return pubkeys;
    }

    @Override
    public int unDeleteLexiconProduct(String productPubKey) {
        return getSessionFactory().getCurrentSession().getNamedQuery(UNDELETE_LEXICON_PRODUCT).
                setParameter("pubKey", productPubKey).executeUpdate();
    }

  public LexiconProductEntity insertLexiconPreCommercialProduct(LexiconMonsantoProductDTO lexiconMonsantoProductDTO) {
    getSessionFactory().getCurrentSession().getNamedQuery(INSERT_LEXICON_PRODUCT).
      setParameter("productPubkey", lexiconMonsantoProductDTO.getProductPubkey()).
      setParameter("preCommercialName", lexiconMonsantoProductDTO.getPreComlName()).
      setParameter("cropName", lexiconMonsantoProductDTO.getCropName()).
      setParameter("tagVarietyName", lexiconMonsantoProductDTO.getTagVarietyName()).
      setParameter("parentProduct", lexiconMonsantoProductDTO.getParentProduct()).
      setParameter("productClassificationCode", lexiconMonsantoProductDTO.getProductClassificationCode()).
      setParameter("marketingRegionName", lexiconMonsantoProductDTO.getOwnerRegion()).
      setParameter("groupDescription", lexiconMonsantoProductDTO.getSupplyChainOwner()).executeUpdate();

    return getProductByPreCommercialName(lexiconMonsantoProductDTO.getPreComlName());
  }
    public String getNextProductPubkey() {
        return getSessionFactory().getCurrentSession().getNamedQuery(GET_NEXT_PRODUCT_PUBKEY).uniqueResult().toString();
    }

    public String getNextVarietyName() {
        return getSessionFactory().getCurrentSession().getNamedQuery(GET_NEXT_VARIETY_NAME).uniqueResult().toString();
    }

  @Override
  public ProductRelationshipDTO getMatchingLexiconProduct(String preCommercialName) {
    Query query = getSessionFactory().getCurrentSession().getNamedQuery(GET_MATCHING_LEXICON_PRODUCT);
    query.setResultTransformer(Transformers.aliasToBean(ProductRelationshipDTO.class));
    query.setParameter("preCommercialName", preCommercialName);
    return (ProductRelationshipDTO)query.uniqueResult();
  }

  @Override
  public LexiconProductEntity getProductByProductPubKey(String pubKey) {
    return  (LexiconProductEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconProductEntity.class, "product").
      createAlias("product.lexiconCrop", "crop").
      createAlias("product.supplyChainOwnerGroup", "supplyChainOwnerGroup", CriteriaSpecification.LEFT_JOIN).
      createAlias("product.productClassification", "productClassification", CriteriaSpecification.LEFT_JOIN)
      .add(Restrictions.eq("product.pubkey", pubKey)).uniqueResult();
  }

  @Override
  public List<String> getTagVarietyNamesByREGEXAndCrop(String tagVarietyNameREGEX, Long cropID) {
    Query query = getSessionFactory().getCurrentSession().getNamedQuery(GET_TAG_VARIETY_NAMES_BY_REGEXAND_CROP);
    query.setParameter("tagVarietyRegex" , tagVarietyNameREGEX);
    query.setParameter("cropID" , cropID);
    return (List<String>) query.list();
  }

  @Override
  public LexiconProductEntity updateLexiconProductByPubKey(String productPubkey, String preCommercialName, String productClassificationCode, String tagVarietyName, String supplyChainOwner) {
    Query query = getSessionFactory().getCurrentSession().getNamedQuery(UPDATE_LEXICON_PRODUCT_BY_PUB_KEY);
    query.setParameter("preCommercialName",preCommercialName);
    query.setParameter("productClassificationCode",productClassificationCode);
    query.setParameter("tagVarietyName",tagVarietyName);
    query.setParameter("supplyChainOwner",supplyChainOwner);
    query.setParameter("productPubkey",productPubkey);
    query.executeUpdate();
    return getProductByProductPubKey(productPubkey) ;
  }

}

