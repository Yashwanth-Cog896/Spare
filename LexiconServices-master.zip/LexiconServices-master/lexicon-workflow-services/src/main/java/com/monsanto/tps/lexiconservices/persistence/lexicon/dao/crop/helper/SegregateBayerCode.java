/*
 SegregateBayerCode was created on Jun 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper;

import com.monsanto.tps.lexiconservices.crop.domain.ScientificName;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/18/13
 * Time: 5:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SegregateBayerCode {

   private String code;
   private String publicKey;
   private ScientificName scientificName;

   public SegregateBayerCode(String code, String publicKey, ScientificName scientificName) {
      this.code = code;
      this.publicKey = publicKey;
      this.scientificName = scientificName;
   }

   public String getCode() {
      return code;
   }

   public String getPublicKey() {
      return publicKey;
   }

   public ScientificName getScientificName() {
      return scientificName;
   }
}
