/*
 AssigningGermplasmHaveHybridCodedOrFinishedLineTypeRule was created on Feb 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconservices.product.common.rule;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductGermplasmCollection;

public class AssigningGermplasmHaveHybridCodedOrFinishedLineTypeRule
        extends SimpleValidationRule {
    private final ProductGermplasmCollection assigningGermplasm;

    public AssigningGermplasmHaveHybridCodedOrFinishedLineTypeRule(ProductGermplasmCollection assigningGermplasm) {
        this.assigningGermplasm = assigningGermplasm;
    }

    public boolean preConditionsMet() {
        return assigningGermplasm != null;
    }

    public boolean criteriaViolated() {
        return !assigningGermplasm.getGermplasmCollection().hasOnlyHybridCodedOrFinishedTypes();
    }

    public ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.ASSIGNING_GP_INVALID_LINE_TYPE_CODE);
    }
}