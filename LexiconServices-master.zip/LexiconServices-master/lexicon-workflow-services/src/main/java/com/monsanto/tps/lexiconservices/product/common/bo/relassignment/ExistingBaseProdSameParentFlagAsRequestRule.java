package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class ExistingBaseProdSameParentFlagAsRequestRule
        extends SimpleValidationRule {
    private BaseProductEntity existingManfNameBaseProduct;
    private boolean requestedParentFlag;

    public ExistingBaseProdSameParentFlagAsRequestRule(BaseProductEntity existingManfNameBaseProduct,
                                                       boolean requestedParentFlag) {
        this.existingManfNameBaseProduct = existingManfNameBaseProduct;
        this.requestedParentFlag = requestedParentFlag;
    }

    protected boolean preConditionsMet() {
        return existingManfNameBaseProduct != null;
    }

    protected boolean criteriaViolated() {
        return requestedParentFlag != existingManfNameBaseProduct.getParentProduct();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.REQUESTED_PARENT_FLAG_DIFFERS_FROM_BASE_PRODUCTS);
    }
}