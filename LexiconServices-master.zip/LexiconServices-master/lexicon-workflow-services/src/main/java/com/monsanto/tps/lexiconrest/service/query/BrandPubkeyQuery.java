package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.BrandDTO;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:11:25 PM
 */
public class BrandPubkeyQuery
        extends AbstractPersistentStoreMultiRowQuery {
    private String[] brandNames;
    private String selectBrandQuery = "select brand_pubkey, brand_name from lexicon.brand where brand_name in ( ";

    public BrandPubkeyQuery(String[] brandNames) {
        this.brandNames = brandNames;
    }

    public List<BrandDTO> find()
            throws WrappingException {
        return getList();
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return buildBrandObject(row);
    }

    private Object buildBrandObject(PersistentStoreResultSetRow row) throws WrappingException {
        BrandDTO brandDTO = new BrandDTO(getNonNull(row.getString("brand_pubkey")), row.getString("brand_name"));
        return brandDTO;
    }

    private String getNonNull(String string) {
        return string == null ? "" : string;
    }

    protected String getSQL()
            throws WrappingException {
        checkForSpecialChar();
        return selectBrandQuery + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(brandNames) + ") ";
    }

    private void checkForSpecialChar() {
        for (int i = 0; i < brandNames.length; i++) {
            if (brandNames[i].contains("'")) {
                int index = brandNames[i].indexOf("'");
                brandNames[i] = new StringBuilder(brandNames[i]).insert(index, "'").toString();
            }
        }

    }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
