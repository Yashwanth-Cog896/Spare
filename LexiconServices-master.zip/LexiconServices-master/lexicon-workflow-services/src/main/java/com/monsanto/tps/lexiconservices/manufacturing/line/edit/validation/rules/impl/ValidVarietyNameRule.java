package com.monsanto.tps.lexiconservices.manufacturing.line.edit.validation.rules.impl;

import com.monsanto.tps.lexiconservices.common.rule.ConditionalRule;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 7:08 PM
 */
public class ValidVarietyNameRule extends ConditionalRule {
    public static final int VARIETY_NAME_SIZE = 10;
    private final String varietyName;

    public ValidVarietyNameRule(String varietyName) {
        this.varietyName = varietyName;
    }

    protected boolean preconditionsMet() {
        return varietyName != null;
    }

    protected boolean criteriaViolated() {
        return varietyName.length() > VARIETY_NAME_SIZE;
    }

    public String getViolation() {
        return "The variety name must be 10 characters or less.";
    }
}
