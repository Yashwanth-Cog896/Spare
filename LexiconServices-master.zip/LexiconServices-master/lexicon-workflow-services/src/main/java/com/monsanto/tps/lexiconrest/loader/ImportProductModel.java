/*
$Log$
*/
package com.monsanto.tps.lexiconrest.loader;

/**
 */
public class ImportProductModel {
    private String precommercialName;
    private String commercialName;
    private String brand;
    private String stage;
    private String country;
    private String commercialTrait;
    private int commercialMaturity;
    private String productKind;

    private int batchId;

    public String getPrecommercialName() {
        return precommercialName;
    }

    public void setPrecommercialName(String precommercialName) {
        this.precommercialName = precommercialName;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public void setCommercialName(String commercialName) {
        this.commercialName = commercialName.trim();
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand.trim();
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage.trim();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country.trim();
    }

    public String getCommercialTrait() {
        return commercialTrait;
    }

    public void setCommercialTrait(String commercialTrait) {
        this.commercialTrait = commercialTrait.trim();
    }

    public int getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(int commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public int getBatchId() {
        return batchId;
    }

    public void setBatchId(int batchId) {
        this.batchId = batchId;
    }

    public String getProductKind() {
        return productKind;
    }

    public void setProductKind(String productKind) {
        this.productKind = productKind;
    }
}
