package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageAuditEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.AuditDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.MirageCompanyDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.ProductDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.SeedProductMaturityDao;
import com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain.ProductDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MirageProductRichAttributes;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 10:09 PM
 */
@Component(value = "mirageProductAddWriter")
public class MirageProductAddWriter {

    @Resource
    private ProductDao productDao;

    @Resource
    private MirageCompanyDao mirageCompanyDao;

    @Resource
    private AuditDao mirageAuditDao;

    @Resource
    private SeedProductMaturityDao seedProductMaturityDao;

    public static final String INSERT_SP_EVENT = "CREATE SEED PRODUCT";
    public static final String INSERT_MAT_EVENT = "CREATE SEED PRODUCT MATURITY";
    public static final String UPDATE_SP_EVENT = "UPDATE SEED PRODUCT";


    public ProductDTO write(ProductDTO existingMirageProduct, MirageProductRichAttributes stageAttributes) {
        if (stageAttributes.isTDRestricted()) {
            return null;
        } else if (existingMirageProduct == null) {
            return createMirageProduct(stageAttributes);
        } else {
            return reuseMirageProduct(existingMirageProduct, stageAttributes);
        }
    }

    private ProductDTO reuseMirageProduct(ProductDTO existingMirageProduct, MirageProductRichAttributes stageAttributes) {
        seedProductMaturityDao.deleteByProductId(existingMirageProduct.getProductID());
        long auditId = mirageAuditDao.save(UPDATE_SP_EVENT).getId();
        productDao.reuseMirageSeedProduct(stageAttributes.getTraitCharacteristicsId(), stageAttributes.isActive()
                , auditId, existingMirageProduct.getProductID());
        createProductMaturity(stageAttributes.getMaturityRating(), existingMirageProduct.getProductID());
        existingMirageProduct.setMaturity(stageAttributes.getMaturityRating());
        existingMirageProduct.setTraitCode(stageAttributes.getTraitCharacteristicsId());
        existingMirageProduct.setEnabled(stageAttributes.isActive() ? "Y" : "N");
        return existingMirageProduct;
    }

    private ProductDTO createMirageProduct(MirageProductRichAttributes stageAttributes) {
        MirageSeedProductEntity productEntity = productDao.save(getMirageProduct(stageAttributes));
        ProductDTO productDTO = new ProductDTO(productEntity);
        createProductMaturity(stageAttributes.getMaturityRating(), productEntity.getProductId());
        productDTO.setMaturity(stageAttributes.getMaturityRating());
        return productDTO;
    }

    private void createProductMaturity(String maturity, long productId) {
        if (!StringUtils.isNullOrEmpty(maturity)) {
            MirageAuditEntity auditEntity = mirageAuditDao.save(INSERT_MAT_EVENT);
            seedProductMaturityDao.save(productId, maturity, auditEntity.getId());
        }
    }

    private MirageSeedProductEntity getMirageProduct(MirageProductRichAttributes stageAttributes) {
        MirageSeedProductEntity entity = new MirageSeedProductEntity();
        entity.setName(stageAttributes.getProductName());
        entity.setMirageCompany(mirageCompanyDao.get(stageAttributes.getBrandId()));
        entity.setBayerCode(stageAttributes.getBayerCode());
        entity.setCountryCode(stageAttributes.getCountryCode());
        entity.setTraitCharacteristicCode(stageAttributes.getTraitCharacteristicsId());
        entity.setEnabled(stageAttributes.isProductEnabled());
        entity.setAudit(mirageAuditDao.save(INSERT_SP_EVENT));
        return entity;
    }


}
