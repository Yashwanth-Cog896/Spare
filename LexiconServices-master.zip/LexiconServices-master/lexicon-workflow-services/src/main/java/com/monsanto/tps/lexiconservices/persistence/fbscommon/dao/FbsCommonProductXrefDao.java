package com.monsanto.tps.lexiconservices.persistence.fbscommon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/3/14
 * Time: 12:24 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FbsCommonProductXrefDao extends GenericDao<FbsCommonProductXrefEntity, String> {

  @DynamicDaoMethod(queryName = "FbsCommonProductXrefDao.findProductXrefByPubKey",
    parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
  FbsCommonProductXrefEntity findProductXrefByPubKey(@DynamicDaoParameter(name = "productPubKey") String productPubKey);

    FbsCommonProductXrefEntity save(FbsCommonProductXrefEntity productXref);

    int update(long midasProductId, String lexiconPubKey);

}
