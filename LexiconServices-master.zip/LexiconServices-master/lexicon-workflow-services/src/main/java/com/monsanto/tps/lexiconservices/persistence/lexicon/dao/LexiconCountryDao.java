package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCountryEntity;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 1/6/14
 * Time: 5:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconCountryDao {
    LexiconCountryEntity getCountryByPubkey(String pubkey);
}
