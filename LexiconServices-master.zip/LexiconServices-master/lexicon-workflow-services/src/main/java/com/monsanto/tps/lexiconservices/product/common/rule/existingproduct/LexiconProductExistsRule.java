package com.monsanto.tps.lexiconservices.product.common.rule.existingproduct;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/10/14
 * Time: 12:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductExistsRule  extends SimpleValidationRule
{
  private final LexiconProductEntity lexiconProduct;

  public LexiconProductExistsRule(LexiconProductEntity lexiconProduct) {
    this.lexiconProduct = lexiconProduct;
  }

  protected boolean preConditionsMet() {
    return true;
  }

  protected boolean criteriaViolated() {
    return lexiconProduct == null;
  }

  protected ValidationCondition getViolationCondition() {
    return new ProductSyncValidationCondition(ProductSyncValidationCondition.LEX_PROD_NOT_EXIST_CODE);
  }
}
