package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.BlendWorkflowCropEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.BlendWorkflowCropDao;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 4/28/14
 * Time: 2:15 PM
 */
public class BlendWorkflowCropDaoImpl extends GenericDaoImpl<BlendWorkflowCropEntity,Long> implements BlendWorkflowCropDao {

    public BlendWorkflowCropDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<BlendWorkflowCropEntity> getAllBlendWorkflowCrops() {
       return loadAll();
    }
}
