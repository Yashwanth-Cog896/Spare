package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/8/14
 * Time: 3:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommercialTraitStackDTO {

  private String TRUE = "true";
  private String FALSE = "false";
  private Long traitStackId;
  private String traitStackPubKey;
  private String traitStackAbbr;
  private String traitStackDesc;
  private String traitStackReportingName;
  private String traitStackTdName;
  private String cropName;
  private String traitStackPrecommercial;

  public Long getTraitStackId() {
    return traitStackId;
  }

  public void setTraitStackId(Long traitStackId) {
    this.traitStackId = traitStackId;
  }

  public String getTraitStackPubKey() {
    return traitStackPubKey;
  }

  public void setTraitStackPubKey(String traitStackPubKey) {
    this.traitStackPubKey = traitStackPubKey;
  }

  public String getTraitStackAbbr() {
    return traitStackAbbr;
  }

  public void setTraitStackAbbr(String traitStackAbbr) {
    this.traitStackAbbr = traitStackAbbr;
  }

  public String getTraitStackDesc() {
    return traitStackDesc;
  }

  public void setTraitStackDesc(String traitStackDesc) {
    this.traitStackDesc = traitStackDesc;
  }

  public String getTraitStackReportingName() {
    return traitStackReportingName;
  }

  public void setTraitStackReportingName(String traitStackReportingName) {
    this.traitStackReportingName = traitStackReportingName;
  }

  public String getTraitStackTdName() {
    return traitStackTdName;
  }

  public void setTraitStackTdName(String traitStackTdName) {
    this.traitStackTdName = traitStackTdName;
  }

  public String getCropName() {
    return cropName;
  }

  public void setCropName(String cropName) {
    this.cropName = cropName;
  }

  public String getTraitStackPrecommercial() {
    return ("Y".equalsIgnoreCase(traitStackPrecommercial)) ? TRUE : FALSE;
  }

  public void setTraitStackPrecommercial(String traitStackPrecommercial) {
    this.traitStackPrecommercial = traitStackPrecommercial;
  }
}
