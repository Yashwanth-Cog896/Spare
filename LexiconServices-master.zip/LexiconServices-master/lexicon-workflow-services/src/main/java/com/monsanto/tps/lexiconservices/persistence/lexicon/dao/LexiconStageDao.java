package com.monsanto.tps.lexiconservices.persistence.lexicon.dao;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 1/7/14
 * Time: 10:55 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconStageDao {
    LexiconStageEntity getStageTypeByPubkey(String pubkey);
}
