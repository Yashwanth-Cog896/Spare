package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class ExistingParentProductFlagMatchesRequestRule
        extends SimpleValidationRule {
    private final LexiconProductEntity existingLexProduct;
    private final boolean requestedParentProductFlag;

    public ExistingParentProductFlagMatchesRequestRule(LexiconProductEntity existingLexProduct, boolean requestedParentProductFlag) {
        this.existingLexProduct = existingLexProduct;
        this.requestedParentProductFlag = requestedParentProductFlag;
    }

    protected boolean preConditionsMet() {
        return existingLexProduct != null;
    }

    protected boolean criteriaViolated() {
        return requestedParentProductFlag != existingLexProduct.isParentProduct();
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.PARENT_PRODUCT_FLAG_DIFFER_CODE);
    }
}
