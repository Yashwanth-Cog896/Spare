package com.monsanto.tps.lexiconservices.product.common.bo.relassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ProductRelationshipObject;


public class RequestedManufacturingNameExistsRule
        extends SimpleValidationRule {
    private String requestedManfName;
    private ProductRelationshipObject existingManfNameRelationship;

    public RequestedManufacturingNameExistsRule(String requestedManfName, ProductRelationshipObject existingManfNameRelationship) {
        this.requestedManfName = requestedManfName;
        this.existingManfNameRelationship = existingManfNameRelationship;
    }

    protected boolean preConditionsMet() {
        return !StringUtils.isNullOrEmpty(requestedManfName);
    }

    protected boolean criteriaViolated() {
        return existingManfNameRelationship == null;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(
                ProductSyncValidationCondition.SPEC_MANUFACTURING_NAME_DOES_NOT_EXIST);
    }
}