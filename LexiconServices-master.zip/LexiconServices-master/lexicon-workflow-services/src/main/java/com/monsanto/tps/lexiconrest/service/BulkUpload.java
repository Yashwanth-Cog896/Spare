package com.monsanto.tps.lexiconrest.service;

import com.monsanto.tps.lexiconrest.ExcelDTO;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.apache.cxf.jaxrs.ext.multipart.MultipartBody;
import org.springframework.web.bind.annotation.RequestBody;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import java.util.*;
//import javax.ws.rs.core.Response;

/**
 * Created by SMALA on 11/6/2014.
 */
@Path("/bulkUploadService")
public interface BulkUpload {

    @POST
    @Path("/uploadProductsInformation/{validate}/{userName}")
    @Produces("application/json")
    @Consumes("multipart/form-data")
    List<ExcelDTO> uploadProductsInformation(@Multipart MultipartBody multipartBody, @PathParam("validate") Boolean validate, @PathParam("userName") String userName) throws Exception;


  @POST
    @Path("/uploadProducts/{validate}/{userName}")
    @Produces("application/json")
    @Consumes("application/json")
    List<ExcelDTO> uploadProducts(@RequestBody List<ExcelDTO> productsInformation, @PathParam("validate") Boolean validate, @PathParam("userName") String userName) throws Exception;

    @POST
    @Path("/createBatchRequest/{validate}/{userName}")
    @Produces("application/json")
    @Consumes("multipart/form-data")
    List<BatchResponse> createBatchRequest(@Multipart MultipartBody multipartBody, @PathParam("validate") Boolean validate, @PathParam("userName") String userName) throws Exception;

}
