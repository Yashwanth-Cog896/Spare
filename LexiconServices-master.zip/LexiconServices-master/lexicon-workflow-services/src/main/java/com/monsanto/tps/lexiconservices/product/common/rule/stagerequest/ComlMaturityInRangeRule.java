package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;


public class ComlMaturityInRangeRule
        extends SimpleValidationRule {
    private final String commercialMaturity;
    private final TPSCrop crop;
    private boolean valueNotNumeric = false;

    public ComlMaturityInRangeRule(String commercialMaturity, TPSCrop crop) {
        this.commercialMaturity = commercialMaturity;
        this.crop = crop;
    }

    protected boolean preConditionsMet() {
        return !StringUtils.isNullOrEmpty(commercialMaturity) && crop != null;
    }

    protected boolean criteriaViolated() {
        try {
            return !crop.isValidMaturity(getNumericMaturity());
        } catch (NumberFormatException e) {
            valueNotNumeric = true;
            return true;
        }
    }

    private double getNumericMaturity()
            throws NumberFormatException {
        return Double.parseDouble(commercialMaturity);
    }

    protected ValidationCondition getViolationCondition() {
        return (valueNotNumeric) ?
                new ProductSyncValidationCondition(ProductSyncValidationCondition.NON_NUMERIC_COML_MATURITY_CODE) :
                new ProductSyncValidationCondition(ProductSyncValidationCondition.COML_MATRUITY_OUT_OF_RANGE_CODE,
                        getMaturityRangeValuesArray());
    }

    private String[] getMaturityRangeValuesArray() {
        return new String[]{
                crop.getRelativeMaturityMin().toString(),
                crop.getRelativeMaturityMax().toString(),
                crop.getRelativeMaturityIncrement().toString()
        };
    }
}
