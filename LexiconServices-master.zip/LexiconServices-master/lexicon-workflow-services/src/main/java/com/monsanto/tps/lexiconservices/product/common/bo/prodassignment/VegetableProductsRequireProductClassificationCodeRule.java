package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;

public class VegetableProductsRequireProductClassificationCodeRule
        extends SimpleValidationRule {
    private final boolean vegetableProduct;
    private final String productClassificationCode;

    public VegetableProductsRequireProductClassificationCodeRule(boolean vegetableProduct, String productClassificationCode) {
        this.vegetableProduct = vegetableProduct;
        this.productClassificationCode = productClassificationCode;
    }

    @Override
    protected boolean preConditionsMet() {
        return vegetableProduct;
    }

    @Override
    protected boolean criteriaViolated() {
        return productClassificationCode == null;
    }

    @Override
    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.VEGE_PROD_MISSING_PROD_CLASSIFICATION_CODE);
    }
}
