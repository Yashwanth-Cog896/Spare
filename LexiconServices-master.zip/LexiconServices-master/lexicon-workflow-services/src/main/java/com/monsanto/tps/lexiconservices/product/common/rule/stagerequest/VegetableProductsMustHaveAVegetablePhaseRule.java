package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;


public class VegetableProductsMustHaveAVegetablePhaseRule
        extends SimpleValidationRule {
    //TODO verify criteria violated
    private final boolean vegetableProduct;
    private final LexiconStageEntity stage;

    public VegetableProductsMustHaveAVegetablePhaseRule(boolean vegetableProduct, LexiconStageEntity stage) {
        this.vegetableProduct = vegetableProduct;
        this.stage = stage;
    }

    @Override
    protected boolean preConditionsMet() {
        return vegetableProduct && stage != null;
    }

    @Override
    protected boolean criteriaViolated() {
        return !stage.getStageCategories().iterator().next().getName().equals("Vegetable");
    }

    @Override
    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.VEGETABLE_PRODUCT_WITH_ROW_CROP_STAGE_CODE);
    }
}
