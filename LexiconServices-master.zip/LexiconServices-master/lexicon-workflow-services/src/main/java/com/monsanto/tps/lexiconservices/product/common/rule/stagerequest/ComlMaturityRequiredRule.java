package com.monsanto.tps.lexiconservices.product.common.rule.stagerequest;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.LexiconCropNameToTPSCropNameTranslator;

public class ComlMaturityRequiredRule
        extends SimpleValidationRule {
    private static final String SOYBEANS_NAME = "SOYBEANS";
    private static final String CORN_NAME = LexiconCropNameToTPSCropNameTranslator.TPS_CORN;
    private static final String SWEET_CORN_NAME = LexiconCropNameToTPSCropNameTranslator.SWEET_CORN;

    private final String commercialMaturity;
    private final TPSCrop crop;
    private final boolean hasDefaultStage;

    public ComlMaturityRequiredRule(String commercialMaturity, TPSCrop crop) {
        this(commercialMaturity, crop, true);
    }

    public ComlMaturityRequiredRule(String commercialMaturity, TPSCrop crop, boolean hasDefaultStage) {
        this.commercialMaturity = commercialMaturity;
        this.crop = crop;
        this.hasDefaultStage = hasDefaultStage;
    }

    protected boolean preConditionsMet() {
        return crop != null && hasDefaultStage;
    }

    protected boolean criteriaViolated() {
        return isMaturityRequred() && StringUtils.isNullOrEmpty(commercialMaturity);
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.COML_MATRUITY_REQ_CODE);
    }

    private boolean isMaturityRequred() {
        return CORN_NAME.equals(crop.getLexiconCropName())
                || SWEET_CORN_NAME.equals(crop.getLexiconCropName())
                || SOYBEANS_NAME.equals(crop.getLexiconCropName());
    }
}
