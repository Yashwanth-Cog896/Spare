package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;


public class ExistingLexProdMatchesRequestCropRule
        extends SimpleValidationRule {
    private final LexiconProductEntity existingLexProduct;
    private final TPSCrop crop;

    public ExistingLexProdMatchesRequestCropRule(LexiconProductEntity existingLexProduct, TPSCrop crop) {
        this.existingLexProduct = existingLexProduct;
        this.crop = crop;
    }

    protected boolean preConditionsMet() {
        return existingLexProduct != null && !existingLexProduct.isLogicalDelete() && crop != null;
    }

    protected boolean criteriaViolated() {
        return !crop.getLexiconCropName().equals(existingLexProduct.getLexiconCrop().getName());
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.EXIST_LEX_CROP_DIFFER_CODE);
    }
}
