package com.monsanto.tps.lexiconservices.productpcname.service.domain;

import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/29/14
 * Time: 2:36 PM
 */
public class MutableSyncProduct {

    private boolean isParentProduct;
    private LexiconProductEntity lexProduct;
    private LexiconProductNames lexiconProductNames;
    private String cropName;
    private String preComlName;
    private String pubKey;
    private TPSCrop crop;
    private boolean requestedVegetableProduct;
    private FbsCommonProductXrefEntity productXref;
    private MidasProductNamesCollection matchingMidasPN;
    private MidasProductEntity linkedMidasProduct;
    private MidasProductNamesCollection globalPCNameRecords;
    private GeneticMaterialEntity mirageGeneticMaterial;
    private ExceptionCodes productsExceptionCodes;
    private ProductGermplasmCollection productGermplasm;
    private ProductRelationshipObject productRelationship;

    public boolean isParentProduct() {
        return isParentProduct;
    }

    public void setParentProduct(boolean parentProduct) {
        isParentProduct = parentProduct;
    }

    public LexiconProductEntity getLexProduct() {
        return lexProduct;
    }

    public void setLexProduct(LexiconProductEntity lexiconProduct) {
        this.lexProduct = lexiconProduct;
    }

    public LexiconProductNames getLexiconProductNames() {
        return lexiconProductNames;
    }

    public void setLexiconProductNames(LexiconProductNames lexiconProductNames) {
        this.lexiconProductNames = lexiconProductNames;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }


    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setCrop(TPSCrop crop) {
        this.crop = crop;
    }

    public TPSCrop getCrop() {
        return crop;
    }

    public String getPubKey() {
        return pubKey;
    }

    public void setPubKey(String pubKey) {
       this.pubKey = pubKey;
    }

  public void setRequestedVegetableProduct(boolean requestedVegetableProduct) {
        this.requestedVegetableProduct = requestedVegetableProduct;
    }

    public boolean isRequestedVegetableProduct() {
        return requestedVegetableProduct;
    }

    public FbsCommonProductXrefEntity getProductXref() {
        return productXref;
    }

    public void setProductXref(FbsCommonProductXrefEntity productXref) {
        this.productXref = productXref;
    }

    public void setMatchingMidasPN(MidasProductNamesCollection matchingMidasPN) {
        this.matchingMidasPN = matchingMidasPN;
    }

    public void setLinkedMidasProduct(MidasProductEntity linkedMidasProduct) {
        this.linkedMidasProduct = linkedMidasProduct;
    }

    public MidasProductNamesCollection getMatchingMidasPN() {
        return matchingMidasPN;
    }

    public MidasProductEntity getLinkedMidasProduct() {
        return linkedMidasProduct;
    }

    public long determineMidasProductID() {
        return (getMidasProduct() == null) ? 0 : getMidasProduct().getId();

    }

    public MidasProductEntity getMidasProduct() {
        if (getLinkedMidasProduct() != null) {
            return getLinkedMidasProduct();
        } else {
            MidasProductNameEntity firstActiveRecord = getMatchingMidasPN().getFirstActiveRecord();
            return (firstActiveRecord != null) ? firstActiveRecord.getMidasProduct() : null;
        }
    }

    public void setGlobalPCNameRecords(MidasProductNamesCollection globalPCNameRecords) {
        this.globalPCNameRecords = globalPCNameRecords;
    }

    public void setMirageGeneticMaterial(GeneticMaterialEntity mirageGeneticMaterial) {
        this.mirageGeneticMaterial = mirageGeneticMaterial;
    }

    public void setProductsExceptionCodes(ExceptionCodes productsExceptionCodes) {
        this.productsExceptionCodes = productsExceptionCodes;
    }

    public void setProductGermplasm(ProductGermplasmCollection productGermplasm) {
        this.productGermplasm = productGermplasm;
    }

    public void setProductRelationship(ProductRelationshipObject productRelationship) {
        this.productRelationship = productRelationship;
    }

    public MidasProductNamesCollection getGlobalPCNameRecords() {
        return globalPCNameRecords;
    }

    public GeneticMaterialEntity getMirageGeneticMaterial() {
        return mirageGeneticMaterial;
    }

    public ExceptionCodes getProductsExceptionCodes() {
        return productsExceptionCodes;
    }

    public ProductGermplasmCollection getProductGermplasm() {
        return productGermplasm;
    }

    public ProductRelationshipObject getProductRelationship() {
        return productRelationship;
    }

    public String getProductPubkey() {
        return (getLexProduct() == null) ? null : getLexProduct().getPubkey();
    }
}
