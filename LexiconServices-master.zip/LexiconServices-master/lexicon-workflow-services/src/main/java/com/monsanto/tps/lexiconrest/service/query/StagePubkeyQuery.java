package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.BrandDTO;
import com.monsanto.tps.lexiconrest.StageDTO;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:11:25 PM
 */
public class StagePubkeyQuery
        extends AbstractPersistentStoreMultiRowQuery {
    private String[] stageAbbr;
    private String selectStageQuery = "select stage_pubkey, stage_abbr from lexicon.stage where stage_abbr in ( ";

    public StagePubkeyQuery(String[] stageAbbr) {
        this.stageAbbr = stageAbbr;
    }

    public List<StageDTO> find()
            throws WrappingException {
        return getList();
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return createStageObject(row);
    }

    private Object createStageObject(PersistentStoreResultSetRow row) throws WrappingException {
        StageDTO stageDTO = new StageDTO(row.getString("stage_abbr"), getNonNull(row.getString("stage_pubkey")));
        return stageDTO;
    }

    private String getNonNull(String string) {
        return string == null ? "" : string;
    }

    protected String getSQL()
            throws WrappingException {
        return selectStageQuery + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(stageAbbr) + " )";
    }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
