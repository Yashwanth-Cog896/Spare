package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.impl;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.LexiconProductStageDTO;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pgang
 * Date: 1/3/14
 * Time: 12:39 PM
 */
public class LexiconProductStageDaoImpl extends GenericDaoImpl<LexiconProductStageEntity, Long> implements LexiconProductStageDao {
    private final String GET_NEXT_LEXICON_STAGE_PUBKEY = "LexiconProductStageDao.getNextPubkeySeq";

    public static final String INSERT_LEXICON_PRODUCT_STAGE = "LexiconProductStageDao.insertLexiconProductStage";

    public static final String UPDATE_LEXICON_PRODUCT_STAGE = "LexiconProductStageDao.updateLexiconProductStage";

    public LexiconProductStageDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public List<LexiconProductStageEntity> getMonsantoProductNames(String lexiconProductPubkey) {
        return getSessionFactory().getCurrentSession().
                createCriteria(LexiconProductStageEntity.class, "lexiconProductStage").
                createAlias("lexiconProductStage.lexiconProduct", "lexiconProduct").
                createAlias("lexiconProductStage.commercialTraitStack", "commercialTraitStack").
                createAlias("lexiconProductStage.lexiconBrand", "lexiconBrand").
                createAlias("lexiconProductStage.lexiconStage", "lexiconStage").
                createAlias("lexiconProductStage.lexiconCountry", "lexiconCountry").
                createAlias("lexiconProduct.lexiconCrop", "lexiconCrop").
                createAlias("lexiconProduct.supplyChainOwnerGroup", "supplyChainOwnerGroup").
                add(Restrictions.eq("lexiconProduct.pubkey", lexiconProductPubkey)).list();
    }

    public List<LexiconProductStageEntity> findByProductPubkey(String lexiconProductPubkey) {
        return getSessionFactory().getCurrentSession().
                createCriteria(LexiconProductStageEntity.class, "lexiconProductStage").
                createAlias("lexiconProductStage.lexiconProduct", "lexiconProduct").
                add(Restrictions.eq("lexiconProduct.pubkey", lexiconProductPubkey)).list();
    }


    public LexiconProductStageEntity insertLexiconProductStage(LexiconProductStageDTO lexiconProductStageDTO) {
        int result = getSessionFactory().getCurrentSession().getNamedQuery(INSERT_LEXICON_PRODUCT_STAGE).
                setParameter("stagePubkey", lexiconProductStageDTO.getStagePubkey()).
                setParameter("productPubkey", lexiconProductStageDTO.getProductPubkey()).
                setParameter("countryPubkey", lexiconProductStageDTO.getCountryPubkey()).
                setParameter("brandPubkey", lexiconProductStageDTO.getBrandPubkey()).
                setParameter("stageTypePubkey", lexiconProductStageDTO.getStageTypePubkey()).
                setParameter("traitStackPubkey", lexiconProductStageDTO.getTraitStackPubkey()).
                setParameter("comlName", lexiconProductStageDTO.getComlName()).
                setParameter("comlMaturity", lexiconProductStageDTO.getComlMaturity()).
                setParameter("oecdName", lexiconProductStageDTO.getOecdName()).
                setParameter("isActive", lexiconProductStageDTO.getActive()).
                setParameter("isDeleted", lexiconProductStageDTO.getDeleted()).
                setParameter("preferredName", lexiconProductStageDTO.getPreferredName()).
                setParameter("verifiedName", lexiconProductStageDTO.getVerifiedName()).
                executeUpdate();
        getSessionFactory().getCurrentSession().flush();
        return getLexiconProductStageByPubKey(lexiconProductStageDTO.getStagePubkey());
    }

    private LexiconProductStageEntity getLexiconProductStageByPubKey(String stagePubkey) {
        return (LexiconProductStageEntity) getSessionFactory().getCurrentSession().createCriteria(LexiconProductStageEntity.class, "prodStage").
                add(Restrictions.eq("prodStage.pubkey", stagePubkey)).uniqueResult();
    }

    public int updateLexiconProductStage(LexiconProductStageDTO lexiconProductStageDTO) {
        return getSessionFactory().getCurrentSession().getNamedQuery(UPDATE_LEXICON_PRODUCT_STAGE).
                setParameter("countryPubkey", lexiconProductStageDTO.getCountryPubkey()).
                setParameter("brandPubkey", lexiconProductStageDTO.getBrandPubkey()).
                setParameter("stageTypePubkey", lexiconProductStageDTO.getStageTypePubkey()).
                setParameter("comlTraitPubkey", lexiconProductStageDTO.getTraitStackPubkey()).
                setParameter("commercialName", lexiconProductStageDTO.getComlName()).
                setParameter("comlMaturity", lexiconProductStageDTO.getComlMaturity()).
                setParameter("oecdName", lexiconProductStageDTO.getOecdName()).
                setParameter("active", lexiconProductStageDTO.getActive()).
                setParameter("deleted", lexiconProductStageDTO.getDeleted()).
                setParameter("preferredName", lexiconProductStageDTO.getPreferredName()).
                setParameter("verifiedName", lexiconProductStageDTO.getVerifiedName()).
                setParameter("stagePubkey", lexiconProductStageDTO.getStagePubkey()).
                executeUpdate();
    }

    public String getNextLexStagePubkey() {
        return getSessionFactory().getCurrentSession().getNamedQuery(GET_NEXT_LEXICON_STAGE_PUBKEY).uniqueResult().toString();
    }

    public LexiconProductStageEntity findByProductBrandCountryPubkeys(String lexiconProductPubkey, String brandPubkey, String countryPubkey) {
        return (LexiconProductStageEntity) getSessionFactory().getCurrentSession().
                createCriteria(LexiconProductStageEntity.class, "lexiconProductStage").
                createAlias("lexiconProductStage.lexiconProduct", "lexiconProduct").
                createAlias("lexiconProductStage.lexiconBrand", "lexiconBrand").
                createAlias("lexiconProductStage.lexiconCountry", "lexiconCountry").
                add(Restrictions.eq("lexiconProduct.pubkey", lexiconProductPubkey)).
                add(Restrictions.eq("lexiconBrand.pubkey", brandPubkey)).
                add(Restrictions.eq("lexiconCountry.pubkey", countryPubkey)).
                uniqueResult();
    }
}
