package com.monsanto.tps.lexiconservices.editglobalpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.product.common.processor.SyncProductLoader;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProduct;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCountry;
import com.monsanto.tps.lexiconservices.productpcname.service.exception.InvalidCountryException;
import com.monsanto.tps.lexiconservices.productpcname.service.processor.TPSCountryLookup;
import org.springframework.stereotype.Component;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/5/14
 * Time: 1:02 PM
 * To change this template use File | Settings | File Templates.
 */
@Component(value = "editGlobalPCNameSyncProductLoader")
public class EditGlobalPCNameSyncProductLoader extends SyncProductLoader {


  public MutableSyncProduct loadSyncProduct(String pubKey) {
    MutableSyncProduct mutableSyncProduct = new MutableSyncProduct();

    mutableSyncProduct.setPubKey(pubKey);

    setLexiconProductByPubKey(mutableSyncProduct);
    setLexProductNames(mutableSyncProduct);
    setCropByLexiconProduct(mutableSyncProduct);
    setRequestedVegetableProduct(mutableSyncProduct);
    setProductXref(mutableSyncProduct);
    setLinkedMidasProduct(mutableSyncProduct);
    setMatchingMidasPN(mutableSyncProduct);
    setProductRelationship(mutableSyncProduct);
    setGlobalPCNameRecords(mutableSyncProduct);
    setProductGermplasm(mutableSyncProduct);
    setMirageGeneticMaterial(mutableSyncProduct);
    setProductsExceptionCodes(mutableSyncProduct);
    return mutableSyncProduct;
  }

  private void setCropByLexiconProduct(MutableSyncProduct mutableSyncProduct) {
    LexiconProductEntity product = mutableSyncProduct.getLexProduct();
    String cropName = (product == null) ? null : product.getLexiconCrop().getName();
    mutableSyncProduct.setCropName(cropName);
    setCrop(mutableSyncProduct);
  }

  public TPSCountry getCountryByPubkey(String countryPubKey) {
    try {
      TPSCountryLookup lookup = TPSCountryLookup.instance();
      return lookup.getCountry(countryPubKey);
    } catch (InvalidCountryException e) {
      return null;
    }
  }



}
