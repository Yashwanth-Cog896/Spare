/*
 Messages was created on Aug 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconrest.external;

/**
 * Filename:    $RCSfile: Messages.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: nbwald $    	 On:	$Date: 2007-03-22 16:16:38 $
 *
 * @author nbwald
 * @version $Revision: 1.1 $
 */
public interface Messages {
   //Code Review: Definitely Should not be in dao package
   //Consider implementing ValidationStatus
   public String[] getMessagesOfSeverity(String severity);
}