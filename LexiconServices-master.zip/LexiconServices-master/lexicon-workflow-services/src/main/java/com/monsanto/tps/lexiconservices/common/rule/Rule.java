package com.monsanto.tps.lexiconservices.common.rule;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 11/11/13
 * Time: 6:17 PM
 */
public interface Rule {

    boolean isViolated();

    String getViolation();
}
