package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain;

import com.monsanto.dbdataservices.SQLUtil;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class LexiconProductStageDTO {
  private String stagePubkey;
  private String productPubkey;
  private String countryPubkey;
  private String brandPubkey;
  private String stageTypePubkey;
  private String traitStackPubkey;
  private String comlName;
  private Double comlMaturity;
  private String oecdName;
  private boolean isActive;
  private boolean isDeleted;
  private boolean preferredName;
  private boolean verifiedName;

  public LexiconProductStageDTO(String stagePubkey, String productPubkey, String countryPubkey, String brandPubkey, String stageTypePubkey, String traitStackPubkey,
                                String comlName, Double comlMaturity, String oecdName, boolean active, boolean deleted, boolean preferredName, boolean verifiedName) {
    this.stagePubkey = stagePubkey;
    this.productPubkey = productPubkey;
    this.countryPubkey = countryPubkey;
    this.brandPubkey = brandPubkey;
    this.stageTypePubkey = stageTypePubkey;
    this.traitStackPubkey = traitStackPubkey;
    this.comlName = comlName;
    this.comlMaturity = comlMaturity;
    this.oecdName = oecdName;
    isActive = active;
    isDeleted = deleted;
    this.preferredName = preferredName;
    this.verifiedName = verifiedName;
  }

  public LexiconProductStageDTO(String stagePubkey, String countryPubkey, String brandPubkey, String stageTypePubkey, String traitStackPubkey,
                                String comlName, Double comlMaturity, String oecdName, boolean active, boolean deleted, boolean preferredName, boolean verifiedName) {
    this.stagePubkey = stagePubkey;
    this.countryPubkey = countryPubkey;
    this.brandPubkey = brandPubkey;
    this.stageTypePubkey = stageTypePubkey;
    this.traitStackPubkey = traitStackPubkey;
    this.comlName = comlName;
    this.comlMaturity = comlMaturity;
    this.oecdName = oecdName;
    isActive = active;
    isDeleted = deleted;
    this.preferredName = preferredName;
    this.verifiedName = verifiedName;
  }

  public String getStagePubkey() {
    return stagePubkey;
  }

  public String getProductPubkey() {
    return productPubkey;
  }

  public String getCountryPubkey() {
    return countryPubkey;
  }

  public String getBrandPubkey() {
    return brandPubkey;
  }

  public String getStageTypePubkey() {
    return stageTypePubkey;
  }

  public String getTraitStackPubkey() {
    return traitStackPubkey;
  }

  public String getComlName() {
    return comlName;
  }

  public Double getComlMaturity() {
    if (comlMaturity == null) {
      //TODO - check the impact on business of this.
      this.comlMaturity = new Double(0);
    }
    return comlMaturity;
  }

  public String getOecdName() {
    return oecdName;
  }

  public String getActive() {
    return SQLUtil.booleanToString(this.isActive);
  }

  public String getDeleted() {
    return SQLUtil.booleanToString(this.isDeleted);
  }

  public String getPreferredName() {
    return SQLUtil.booleanToString(this.preferredName);
  }

  public String getVerifiedName() {
    return SQLUtil.booleanToString(this.verifiedName);
  }
}