package com.monsanto.tps.lexiconrest;

import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ExcelDTO {
  private String preCommercialName;
  private String commercialName;
  private String brand;
  private String stageName;
  private String countryName;
  private String commercialTrait;
  private Long commercialMaturity;
  private int batchId;
  private String success;
  private List<String> errorMessage;
  private List<String> infoMessage;
    private String productKind;

    public String getProductKind() {
        return productKind;
    }

    public void setProductKind(String productKind) {
        this.productKind = productKind;
    }

    public String getPreCommercialName() {
    return preCommercialName;
  }

  public void setPreCommercialName(String preCommercialName) {
    this.preCommercialName = preCommercialName;
  }

  public String getCommercialName() {
    return commercialName;
  }

  public void setCommercialName(String commercialName) {
    this.commercialName = commercialName;
  }

  public String getBrand() {
    return brand;
  }

  public void setBrand(String brand) {
    this.brand = brand;
  }

  public String getStageName() {
    return stageName;
  }

  public void setStageName(String stageName) {
    this.stageName = stageName;
  }

  public String getCountryName() {
    return countryName;
  }

  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }

  public String getCommercialTrait() {
    return commercialTrait;
  }

  public void setCommercialTrait(String commercialTrait) {
    this.commercialTrait = commercialTrait;
  }

  public Long getCommercialMaturity() {
    return commercialMaturity;
  }

  public void setCommercialMaturity(Long commercialMaturity) {
    this.commercialMaturity = commercialMaturity;
  }

  public int getBatchId() {
    return batchId;
  }

  public void setBatchId(int batchId) {
    this.batchId = batchId;
  }

  public String getSuccess() {
    return success;
  }

  public void setSuccess(String success) {
    this.success = success;
  }

  public List<String> getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(List<String> errorMessage) {
    this.errorMessage = errorMessage;
  }

  public List<String> getInfoMessage() {
    return infoMessage;
  }

  public void setInfoMessage(List<String> infoMessage) {
    this.infoMessage = infoMessage;
  }
}