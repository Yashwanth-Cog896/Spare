package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/19/15
 * Time: 11:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStagePreComlQuery extends AbstractPersistentStoreEntityExistsQuery {

  private String preComlName;
  private String brandName;
  private String countryName;
  private String commercialName;


  public ProductStagePreComlQuery(String preComlName,String brandName,String countryName,String commercialName) {
    this.preComlName = preComlName;
    this.brandName = brandName;
    this.countryName = countryName;
    this.commercialName = commercialName;
  }

  protected String getSQL()
    throws WrappingException {
    return "select * from lexicon.product_stage where product_id in (select PRODUCT_ID from LEXICON.PRE_COML_PRODUCT where pre_coml_name in " + "'"+preComlName+"')"
      +"and brand_id in (select brand_id from lexicon.brand where brand_name IN " + "'"+ brandName + "'" +")"
      +" and country_id in (select country_id from lexicon.country where country_abbr IN " + "'"+countryName +"'"+ " )"
      +" and commercial_name in" + "'"+ commercialName +"'"+ " ";
  }
  protected Object[] getBindVariables() throws WrappingException {
    return new Object[0];
  }

  protected ConnectionFactoryProperties getConnectionFactoryProperties() {
    return new LexiconConnectionFactoryProperties();
  }
}
