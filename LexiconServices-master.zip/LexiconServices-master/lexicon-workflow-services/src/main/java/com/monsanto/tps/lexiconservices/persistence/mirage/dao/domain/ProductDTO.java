package com.monsanto.tps.lexiconservices.persistence.mirage.dao.domain;

import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductEntity;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 1, 2005
 * Time: 6:14:09 PM
 */
public class ProductDTO {
    private long productID;
    private String productName;
    private String bayerCode;
    private long companyID;
    private String companyName;
    private String countryCode;
    private long traitCode;
    private String maturity;
    private String enabled;
    private Date disabledDate;

    public ProductDTO() {
    }

    public ProductDTO(MirageSeedProductEntity productEntity) {
        this.productID = productEntity.getProductId();
        this.productName = productEntity.getName();
        this.bayerCode = productEntity.getBayerCode();
        this.companyID = productEntity.getMirageCompany().getId();
        this.companyName = productEntity.getMirageCompany().getName();
        this.countryCode = productEntity.getCountryCode();
        this.traitCode = productEntity.getTraitCharacteristicCode();
        this.enabled = productEntity.isEnabled() ? "Y" : "N";
        this.disabledDate = productEntity.getDisabledDate();
    }

    public long getProductID() {
        return productID;
    }

    public void setProductID(long productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getBayerCode() {
        return bayerCode;
    }

    public void setBayerCode(String bayerCode) {
        this.bayerCode = bayerCode;
    }

    public long getCompanyID() {
        return companyID;
    }

    public void setCompanyID(long companyID) {
        this.companyID = companyID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public long getTraitCode() {
        return traitCode;
    }

    public void setTraitCode(long traitCode) {
        this.traitCode = traitCode;
    }

    public String getMaturity() {
        return maturity;
    }

    public void setMaturity(String maturity) {
        this.maturity = maturity;
    }

    public String isProductEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    public Date getDisabledDate() {
        return disabledDate;
    }

    public void setDisabledDate(Date disabledDate) {
        this.disabledDate = disabledDate;
    }

    public boolean isEnabled() {
        return "Y".equalsIgnoreCase(this.enabled) ? Boolean.TRUE : Boolean.FALSE;
    }
}
