package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.TPSCrop;

public class ProductClassificationCodeMatchesCrop
        extends SimpleValidationRule {

    private final String cropByProductClassification;
    private final TPSCrop requestedCrop;
    private final boolean isVegetable;
    private final String productClassificationCode;

    public ProductClassificationCodeMatchesCrop(boolean isVegetable,
                                                String cropByProductClassification,
                                                TPSCrop requestedCrop,
                                                String productClassificationCode) {
        this.cropByProductClassification = cropByProductClassification;
        this.requestedCrop = requestedCrop;
        this.isVegetable = isVegetable;
        this.productClassificationCode = productClassificationCode;
    }

    @Override
    protected boolean preConditionsMet() {
        return isVegetable;
    }

    @Override
    protected boolean criteriaViolated() {
        return !StringUtils.isNullOrEmpty(productClassificationCode) && (StringUtils.isNullOrEmpty(cropByProductClassification) ||
                !requestedCrop.getLexiconCropName().equalsIgnoreCase(cropByProductClassification));
    }

    @Override
    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.CROP_AND_PRODUCT_HIERARCHY_DO_NOT_MATCH);
    }
}
