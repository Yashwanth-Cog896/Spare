/*
 SegregateCropBuilder was created on Jun 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconservices.persistence.lexicon.dao.crop.helper;

import com.monsanto.tps.lexiconservices.crop.domain.ScientificName;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/18/13
 * Time: 5:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SegregateCropBuilder {

   public SegregateCrop build(CropDTO cropDTO) {
      SegregateCrop crop = new SegregateCrop();
      crop.setPublicKey(cropDTO.getPublicKey());
      crop.setName(cropDTO.getName());
      crop.setAbbreviation(cropDTO.getAbbreviation());
      crop.setShippingStatement(cropDTO.getShippingStatement());
      crop.setBayerCode(getBayerCode(cropDTO));
      return crop;
   }

   private SegregateBayerCode getBayerCode(CropDTO cropDTO) {
      return new SegregateBayerCode(cropDTO.getCropBayerCode(),cropDTO.getCropBayerCodePubKey(), getScientificName(cropDTO));
   }

   private ScientificName getScientificName(CropDTO cropDTO){
      return new ScientificName(cropDTO.getCropScientificName(),cropDTO.getCropScientificPubKey());
   }


}
