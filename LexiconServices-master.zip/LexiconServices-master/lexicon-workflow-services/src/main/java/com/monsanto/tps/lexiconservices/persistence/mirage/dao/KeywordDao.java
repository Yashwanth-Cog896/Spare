package com.monsanto.tps.lexiconservices.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.KeywordEntity;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/4/14
 * Time: 9:25 AM
 */
public interface KeywordDao extends GenericDao<KeywordEntity,Long> {

    List<KeywordEntity> getActiveTraitCharacteristics();
}
