package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MidasProductNamesCollection;

public class MatchingActiveMidasPNHaveCommonProdRule
        extends SimpleValidationRule {
    private final MidasProductNamesCollection matchingMidasPN;

    public MatchingActiveMidasPNHaveCommonProdRule(MidasProductNamesCollection matchingMidasPN) {
        this.matchingMidasPN = matchingMidasPN;
    }

    protected boolean preConditionsMet() {
        return matchingMidasPN.hasActiveRecords();
    }

    protected boolean criteriaViolated() {
        return matchingMidasPN.getCommonProduct() == null;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.MATCH_MIDAS_PN_MULT_PRODID_CODE);
    }
}
