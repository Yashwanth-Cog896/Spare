package com.monsanto.tps.lexiconservices.productpcname.service.processor;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/30/14
 * Time: 10:25 AM
 */
public class LexiconCropNameToTPSCropNameTranslator {
    public static final String SWEET_CORN = "SWEET CORN";
    public static final String TPS_CORN = "CORN";

    public String translate(String lexiconCropName) {
        return SWEET_CORN.equalsIgnoreCase(lexiconCropName) ? TPS_CORN : lexiconCropName;
    }
}
