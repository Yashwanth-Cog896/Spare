package com.monsanto.tps.lexiconrest.external;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 29, 2007
 * Time: 11:11:31 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ResponseStatus {
    int getBatchID();

    String getStatus();

    Messages getMessages();
}
