package com.monsanto.tps.lexiconservices.productpcname.validation.rule;

import com.monsanto.tcc.lexiconcommon.validation.RuleSeverityPair;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidator;
import com.monsanto.tcc.lexiconcommon.validation.RulesValidatorCollection;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tps.lexiconservices.product.common.bo.prodassignment.*;


public class APCNProductAssignmentRules
        extends RulesValidatorCollection {
    private final APCNProductAssignmentValidationModel model;

    public APCNProductAssignmentRules(APCNProductAssignmentValidationModel model) {
        this.model = model;
    }

    protected RulesValidator[] getRulesValidators() {
        return new RuleSeverityPair[]{
                new RuleSeverityPair(new ValidCropRule(model.getRequestedCrop()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingLexProdMatchesRequestCropRule(model.getLexProduct(), model.getRequestedCrop()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ExistingParentProductFlagMatchesRequestRule(model.getLexProduct(), model.getRequestedParentProductFlag()), ValidationConditionSeverity.INFO),
                new RuleSeverityPair(new LinkedMidasProdMatchRequestCropRule(model.getLinkedMidasProduct(), model.getRequestedCrop()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new MatchingMidasPNMatchesRequestCropRule(model.getMatchingMidasPN(), model.getRequestedCrop()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ActiveGlobalPCNamesMatchRequestRule(model.getRequestedPCName(), model.getGlobalPCNameRecords()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new AssigningGermplasmNotAttachedToProductRule(model.isAnyAssigningGermplasmAttachedToProduct()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new VegetableProductsRequireProductClassificationCodeRule(model.isRequestedVegetableProduct(), model.getRequestedProductClassificationCode()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new NonVegetableProductsMayNotHaveAProductClassificationCodeRule(model.isRequestedVegetableProduct(), model.getRequestedProductClassificationCode()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new ProductClassificationCodeMatchesCrop(model.isRequestedVegetableProduct(), model.getCropByProductClassification(), model.getRequestedCrop(),
                        model.getRequestedProductClassificationCode()), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TagVarietyNameInUseRequestRule(model), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TagVarietyNameFormatRule(model), ValidationConditionSeverity.ERROR),
                new RuleSeverityPair(new TagVarietyNumberInUseRequestRule(model), ValidationConditionSeverity.ERROR)
        };
    }
}
