package com.monsanto.tps.lexiconservices.product.common.bo.prodassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.SimpleValidationRule;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tps.lexiconservices.product.common.service.validation.condition.ProductSyncValidationCondition;
import com.monsanto.tps.lexiconservices.productpcname.richrequest.TagVarietyNameRequest;

public class TagVarietyNameFormatRule
        extends SimpleValidationRule {
    public static final int MAX_SIZE = 50;
    private final TagVarietyNameRequest model;

    public TagVarietyNameFormatRule(TagVarietyNameRequest model) {
        this.model = model;
    }

    protected boolean preConditionsMet() {
        return true;
    }

    protected boolean criteriaViolated() {

        boolean criteriaViolated = false;

        String tagVarietyName = model.getTagVarietyName();
        if (!StringUtils.isNullOrEmpty(tagVarietyName)) {
            if (tagVarietyName.length() > 50) {
                criteriaViolated = true;
            } else if (!tagVarietyName.matches("[a-zA-Z0-9\\- ]+")) {
                criteriaViolated = true;
            }
        }
        return criteriaViolated;
    }

    protected ValidationCondition getViolationCondition() {
        return new ProductSyncValidationCondition(ProductSyncValidationCondition.TAG_VARIETY_NAME_FORMAT_CODE);
    }
}
