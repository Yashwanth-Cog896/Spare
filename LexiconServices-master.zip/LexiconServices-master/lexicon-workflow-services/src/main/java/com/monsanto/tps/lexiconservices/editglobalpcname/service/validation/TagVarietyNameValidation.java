package com.monsanto.tps.lexiconservices.editglobalpcname.service.validation;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/11/14
 * Time: 9:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class TagVarietyNameValidation {

  private final static String TAG_VARIETY_PATTERN_REGEX = "^[A-Z][A-Z][0-9][0-9][0-9][0-9][A-Z][A-Z]$";

  public boolean checkTagVarietyNamePattern(String tagVarietyName) {
    if (tagVarietyName.matches(TAG_VARIETY_PATTERN_REGEX)) {
      return true;
    }
    return false;

  }

  public String getNumericalFromTagVarietyName(String tagVarietyName) {
    String tagVarietyNumber = tagVarietyName.substring(2, 6);
    return tagVarietyNumber;
  }

  public String getTagVarietyPatternRegex(){
    return TAG_VARIETY_PATTERN_REGEX;
  }
}
