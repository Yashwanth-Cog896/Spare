package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.lexiconservices.externalservice.externalservice.SupportCenterLogger;
import com.monsanto.tps.lexiconservices.lexicon.audit.LexiconAuditorService;
import com.monsanto.tps.lexiconservices.lexicon.audit.domain.AuditStaging;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.AssignPCNameRichRequest;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/11/14
 * Time: 2:37 PM
 */
@Component(value = "preComlNameAssignment")
public class PreComlNameAssignment {

    @Resource
    private LexiconAuditorService lexiconAuditorService;

    @Resource
    private AuditStagingDao auditStagingDao;

    @Resource
    private UserProfile userProfile;

    @Resource
    private AssignPCNameProductWriter assignPCNameProductWriter;

    @Resource
    private DefaultStageWriter defaultStageWriter;

    @Resource
    private SupportCenterLogger supportCenterLogger;

    public void write(AssignPCNameRichRequest richRequest) {
        AuditStaging auditStagingData = getAuditStagingData();
        try {
            lexiconAuditorService.saveAuditStagingData(auditStagingData);
            assignPCNameProductWriter.write(richRequest);
            writeDefaultStages(richRequest);
        } finally {
            lexiconAuditorService.deleteAuditStagingData(auditStagingData.getOracleSID());
        }
        String productPubkey = richRequest.getSyncProduct().getProductPubkey();
        supportCenterLogger.updatePrecommercials(Arrays.asList(productPubkey));
    }

    private void writeDefaultStages(AssignPCNameRichRequest richRequest) {

        if (richRequest.getDefaultStageAttributes() != null) {
            defaultStageWriter.write(richRequest.getDefaultStageAttributes());
        }
    }

    private AuditStaging getAuditStagingData() {
        AuditStaging auditStaging = new AuditStaging();

        auditStaging.setAuditComment("");
        auditStaging.setAuditRequestor("");
        auditStaging.setUserLoginID(userProfile.getUserName());
        auditStaging.setProcessName("PRE_COML_NAME_ASSIGNMENT");
        auditStaging.setCreationTimestamp(new Date());
        auditStaging.setMachine(auditStagingDao.getSessionMachine());
        auditStaging.setOracleSID(auditStagingDao.getSessionId().longValue());
        auditStaging.setOsUser(auditStagingDao.getSessionOsUser());

        return auditStaging;
    }
}
