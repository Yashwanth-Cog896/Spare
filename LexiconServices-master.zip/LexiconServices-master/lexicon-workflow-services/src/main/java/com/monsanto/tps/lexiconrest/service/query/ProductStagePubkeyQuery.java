package com.monsanto.tps.lexiconrest.service.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconrest.ProductDTO;
import com.monsanto.tps.lexiconrest.utilities.StringsCriteriaBuilder;

import java.util.List;

/**
 * nbwald - Mar 6, 2008 2:11:25 PM
 */
public class ProductStagePubkeyQuery
        extends AbstractPersistentStoreMultiRowQuery {
    private String[] preCommercialName;
    private String selectProductPubkey = "select commercial_name from lexicon.product_stage where product_id in (" +
            "select product_id from lexicon.pre_coml_product where pre_coml_name in ( ";

    public ProductStagePubkeyQuery(String[] preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public List<String> find()
            throws WrappingException {
        return getList();
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return getCommercialNameList(row);
    }

    private String getCommercialNameList(PersistentStoreResultSetRow row) throws WrappingException {
        return row.getString("commercial_name");
    }

    private String getNonNull(String string) {
        return string == null ? "" : string;
    }

    protected String getSQL()
            throws WrappingException {
        return selectProductPubkey + new StringsCriteriaBuilder().buildWithoutConvertingToUpperCase(preCommercialName) + "))";
    }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[0];
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new LexiconConnectionFactoryProperties();
    }
}
