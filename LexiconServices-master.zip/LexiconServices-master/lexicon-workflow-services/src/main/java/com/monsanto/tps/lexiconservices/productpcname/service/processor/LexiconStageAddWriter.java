package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.lexiconservices.persistence.lexicon.dao.domain.LexiconProductStageDTO;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.ACPNRichStageAttributes;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 4:46 PM
 */
@Component(value = "lexiconStageAddWriter")
public class LexiconStageAddWriter {

    @Resource
    private LexiconProductStageDao productStageDao;

    public LexiconProductStageEntity write(LexiconProductStageEntity lexProdStage, LexiconProductEntity lexProduct, ACPNRichStageAttributes stageAttributes) {
        if (lexProdStage == null) {
            String stagePubkey = productStageDao.getNextLexStagePubkey();
            LexiconProductStageDTO lexiconProductStageDTO = new LexiconProductStageDTO(stagePubkey, lexProduct.getPubkey(),
                    stageAttributes.getCountryPubkey(), stageAttributes.getBrandPubkey(), stageAttributes.getStageTypePubkey(), stageAttributes.getComlTraitPubkey(),
                    stageAttributes.getCommercialName(), stageAttributes.getComlMaturity(), stageAttributes.getOECDReqdName(), stageAttributes.isActive(),
                    stageAttributes.isDeleted(), stageAttributes.isPreferredName(), stageAttributes.isVerifiedName());

           return productStageDao.insertLexiconProductStage(lexiconProductStageDTO);
        } else if (lexProdStage.isLogicalDelete()) {
            LexiconProductStageDTO lexiconProductStageDTO = new LexiconProductStageDTO(lexProdStage.getPubkey(), lexProdStage.getLexiconCountry().getPubkey(),
                    lexProdStage.getLexiconBrand().getPubkey(), lexProdStage.getLexiconStage().getPubkey(), lexProdStage.getCommercialTraitStack().getPubkey(),
                    lexProdStage.getCommercialName(), lexProdStage.getCommercialMaturity(), lexProdStage.getOecdRegistrationName(), lexProdStage.isActive(),
                    lexProdStage.isLogicalDelete(), lexProdStage.isPreferredName(), lexProdStage.isVerifiedName());

            productStageDao.updateLexiconProductStage(lexiconProductStageDTO);
            return productStageDao.get(lexProdStage.getId());
        } else {
            return lexProdStage;
        }
    }
}
