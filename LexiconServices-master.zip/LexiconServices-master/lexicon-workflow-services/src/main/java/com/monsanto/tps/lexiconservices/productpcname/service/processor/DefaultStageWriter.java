package com.monsanto.tps.lexiconservices.productpcname.service.processor;

import com.monsanto.tps.lexiconservices.productpcname.service.domain.ACPNRichStageAttributes;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.APCNDefaultStageAttributesRichRequest;
import com.monsanto.tps.lexiconservices.productpcname.service.domain.MutableSyncProductName;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 2/10/14
 * Time: 4:00 PM
 */
@Component(value = "defaultStageWriter")
public class DefaultStageWriter {
    @Resource
    private SyncProductNameAddWriter syncProductNameAddWriter;

    public void write(APCNDefaultStageAttributesRichRequest stageAttributes) {
        List<MutableSyncProductName> syncProductNames = stageAttributes.getSyncProductNames();
        int i = 0;
        for (MutableSyncProductName productName : syncProductNames) {
            syncProductNameAddWriter.write(new ACPNRichStageAttributes(stageAttributes, stageAttributes.getIndividualStagesAttributes().get(i)), productName);
            i = i + 1;
        }
    }

}
