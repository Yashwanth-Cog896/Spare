package com.monsanto.tps.lexiconservices.crop.service;

import javax.xml.ws.WebFault;
import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
@WebFault
public class CropRetrievalByPubKeyAndScientificNameException extends RuntimeException {
  private List<String> infoList = new ArrayList<String>();

  public CropRetrievalByPubKeyAndScientificNameException() {
  }

  public CropRetrievalByPubKeyAndScientificNameException(String message, Throwable cause) {
    super(message, cause);
  }

  @Override
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.getMessage());
    for (String info : infoList) {
      stringBuilder.append(info);
    }
    return stringBuilder.toString();
  }
}