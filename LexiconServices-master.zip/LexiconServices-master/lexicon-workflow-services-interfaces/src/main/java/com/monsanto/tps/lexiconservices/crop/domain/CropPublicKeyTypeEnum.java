package com.monsanto.tps.lexiconservices.crop.domain;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public enum CropPublicKeyTypeEnum {
  CROP("C.CROP_PUBKEY"), BAYER_CODE("BC.BAYER_CODE_PUBKEY"), SCIENTIFIC("BCGS.BAYER_CODE_GENUS_SP_PUBKEY");

  private String type;

  CropPublicKeyTypeEnum(String type) {
    this.type = type;
  }

  public String getType() {
    return type;
  }

}