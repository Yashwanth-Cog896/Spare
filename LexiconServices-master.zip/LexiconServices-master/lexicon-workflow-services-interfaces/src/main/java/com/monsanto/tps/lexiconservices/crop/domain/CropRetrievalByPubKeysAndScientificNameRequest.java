package com.monsanto.tps.lexiconservices.crop.domain;

import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CropRetrievalByPubKeysAndScientificNameRequest {
  private List<String> publickeys;
  private String scientificName;
  private CropPublicKeyTypeEnum publicKeyTypeEnum;

  public CropRetrievalByPubKeysAndScientificNameRequest() {
  }

  public CropRetrievalByPubKeysAndScientificNameRequest(List<String> publickeys, String scientificName, CropPublicKeyTypeEnum publicKeyTypeEnum) {
    this.publickeys = publickeys;
    this.scientificName = scientificName;
    this.publicKeyTypeEnum = publicKeyTypeEnum;
  }

  public List<String> getPublickeys() {
    return publickeys;
  }

  public String getScientificName() {
    return scientificName;
  }

  public CropPublicKeyTypeEnum getPublicKeyTypeEnum() {
    return publicKeyTypeEnum;
  }

  public void setPublickeys(List<String> publickeys) {
    this.publickeys = publickeys;
  }

  public void setScientificName(String scientificName) {
    this.scientificName = scientificName;
  }

  public void setPublicKeyTypeEnum(CropPublicKeyTypeEnum publicKeyTypeEnum) {
    this.publicKeyTypeEnum = publicKeyTypeEnum;
  }
}