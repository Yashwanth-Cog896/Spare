package com.monsanto.tps.lexiconservices.crop.domain;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public abstract class BaseCrop {
  private String publicKey;
  private String name;
  private String abbreviation;
  private String shippingStatement;

  public BaseCrop() {
  }

  public BaseCrop(String publicKey, String name, String abbreviation, String shippingStatement) {
    this.publicKey = publicKey;
    this.name = name;
    this.abbreviation = abbreviation;
    this.shippingStatement = shippingStatement;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public void setPublicKey(String publicKey) {
    this.publicKey = publicKey;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getAbbreviation() {
    return abbreviation;
  }

  public void setAbbreviation(String abbreviation) {
    this.abbreviation = abbreviation;
  }

  public String getShippingStatement() {
    return shippingStatement;
  }

  public void setShippingStatement(String shippingStatement) {
    this.shippingStatement = shippingStatement;
  }

}