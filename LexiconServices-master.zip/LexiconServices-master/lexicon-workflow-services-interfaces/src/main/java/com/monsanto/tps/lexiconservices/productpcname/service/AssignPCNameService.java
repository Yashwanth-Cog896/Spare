package com.monsanto.tps.lexiconservices.productpcname.service;

import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameRequest;
import com.monsanto.tps.lexiconservices.productpcname.domain.AssignPCNameResponse;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 10:46 AM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface AssignPCNameService {

  @WebMethod
  List<AssignPCNameResponse> assignPreCommercialName(@WebParam(name="assignPCNameRequest") List<AssignPCNameRequest> assignPCNameRequestList) throws AssignPCNameServiceException;
  @WebMethod
  List<AssignPCNameResponse> validateAssignPreCommercialNameRequests(@WebParam(name="validateAssignPCNameRequest") List<AssignPCNameRequest> assignPCNameRequestList)throws AssignPCNameServiceException;
}
