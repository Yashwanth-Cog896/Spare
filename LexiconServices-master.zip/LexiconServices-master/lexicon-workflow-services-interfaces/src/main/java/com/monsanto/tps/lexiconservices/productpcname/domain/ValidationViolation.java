package com.monsanto.tps.lexiconservices.productpcname.domain;



/**
 * Created with IntelliJ IDEA.
 * User: rlcasw
 * Date: 1/28/13
 * Time: 11:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationViolation {
    private ValidationCondition condition;
    private ValidationSeverity severity;

    public ValidationCondition getCondition() {
        return condition;
    }

    public void setCondition(ValidationCondition condition) {
        this.condition = condition;
    }

    public ValidationSeverity getSeverity() {
        return severity;
    }

    public void setSeverity(ValidationSeverity severity) {
        this.severity = severity;
    }
}
