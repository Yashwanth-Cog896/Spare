package com.monsanto.tps.lexiconservices.lexicon.audit;

import com.monsanto.tps.lexiconservices.lexicon.audit.domain.AuditStaging;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 12/24/13
 * Time: 4:33 PM
 */
public interface LexiconAuditorService {
//    these methods should be used together, once staging data committed should be deleted in finally block.
//    ex
//    try{
//        saveAuditStagingData(auditStaging);
//        --other update methods which needs audit staging data to be present
//       }finally{
//        deleteAuditStagingData(oracleSID);
//    }
    void saveAuditStagingData(AuditStaging auditStaging);
    void deleteAuditStagingData(long oracleSID);
}
