package com.monsanto.tps.lexiconservices.editglobalpcname.domain;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 2:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameResponse {

  private List<String> errors = new ArrayList<String>();
  private List<String> notes = new ArrayList<String>();

  public List<String> getErrors() {
    return errors;
  }

  public void setErrors(List<String> errors) {
    this.errors = errors;
  }

  public List<String> getNotes() {
    return notes;
  }

  public void setNotes(List<String> notes) {
    this.notes = notes;
  }
}
