package com.monsanto.tps.lexiconservices.crop.domain;

import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class BayerCode {
  String code;
  String publicKey;
  List<ScientificName> scientificNames;

  public BayerCode() {
  }

  public BayerCode(String code, String publicKey, List<ScientificName> scientificNames) {
    this.code = code;
    this.publicKey = publicKey;
    this.scientificNames = scientificNames;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public void setPublicKey(String publicKey) {
    this.publicKey = publicKey;
  }

  public List<ScientificName> getScientificNames() {
    return scientificNames;
  }

  public void setScientificNames(List<ScientificName> scientificNames) {
    this.scientificNames = scientificNames;
  }
}