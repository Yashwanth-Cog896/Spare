package com.monsanto.tps.lexiconservices.lexicon.audit.domain;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 12/24/13
 * Time: 4:34 PM
 */
public class AuditStaging {

    private Long oracleSID;
    private Long userPartyID;
    private String processName;
    private String auditComment;
    private String auditRequestor;
    private Date creationTimestamp;
    private String osUser;
    private String machine;
    private String userLoginID;

    public Long getOracleSID() {
        return oracleSID;
    }

    public void setOracleSID(Long oracleSID) {
        this.oracleSID = oracleSID;
    }

    public Long getUserPartyID() {
        return userPartyID;
    }

    public void setUserPartyID(Long userPartyID) {
        this.userPartyID = userPartyID;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getAuditComment() {
        return auditComment;
    }

    public void setAuditComment(String auditComment) {
        this.auditComment = auditComment;
    }

    public String getAuditRequestor() {
        return auditRequestor;
    }

    public void setAuditRequestor(String auditRequestor) {
        this.auditRequestor = auditRequestor;
    }

    public Date getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(Date creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

    public String getOsUser() {
        return osUser;
    }

    public void setOsUser(String osUser) {
        this.osUser = osUser;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public String getUserLoginID() {
        return userLoginID;
    }

    public void setUserLoginID(String userLoginID) {
        this.userLoginID = userLoginID;
    }
}
