package com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/3/13
 * Time: 11:24 AM
 * To change this template use File | Settings | File Templates.
 */
  public class EditManufacturingLineException extends RuntimeException {

  private List<String> infoList = new ArrayList<String>();

  public EditManufacturingLineException() {
  }

  public EditManufacturingLineException(String message, Throwable cause) {
    super(message, cause);
  }

  public EditManufacturingLineException(String message) {
    super(message);
  }

  @Override
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.getMessage());
    for (String info : infoList) {
      stringBuilder.append(info);
    }
    return stringBuilder.toString();
  }

}
