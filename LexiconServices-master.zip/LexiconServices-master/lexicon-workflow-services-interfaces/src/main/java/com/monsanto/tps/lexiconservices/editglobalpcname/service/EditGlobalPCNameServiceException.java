package com.monsanto.tps.lexiconservices.editglobalpcname.service;

import javax.xml.ws.WebFault;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 2:40 PM
 * To change this template use File | Settings | File Templates.
 */
@WebFault
public class EditGlobalPCNameServiceException extends RuntimeException {

  private List<String> infoList = new ArrayList<String>();

  public EditGlobalPCNameServiceException() {
  }

  public EditGlobalPCNameServiceException(String message, Throwable cause) {
    super(message, cause);
  }

  @Override
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.getMessage());
    for (String info : infoList) {
      stringBuilder.append(info);
    }
    return stringBuilder.toString();
  }
}
