package com.monsanto.tps.lexiconservices.editglobalpcname.service;

import com.monsanto.tps.lexiconservices.editglobalpcname.domain.EditGlobalPCNameRequest;
import com.monsanto.tps.lexiconservices.editglobalpcname.domain.EditGlobalPCNameResponse;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 2:39 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface EditGlobalPCNameService {

  @WebMethod
  List<EditGlobalPCNameResponse> processEditGlobalPCName(@WebParam(name="editGlobalPCName") List<EditGlobalPCNameRequest> editGlobalPCNameRequestList) throws EditGlobalPCNameServiceException;
}
