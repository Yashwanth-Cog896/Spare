package com.monsanto.tps.lexiconservices.crop.service;

import com.monsanto.tps.lexiconservices.crop.domain.Crop;
import com.monsanto.tps.lexiconservices.crop.domain.CropRetrievalByPubKeysAndScientificNameRequest;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.*;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
@WebService
public interface CropRetrievalByPubKeyAndScientificNameService {

  @WebMethod
  public List<Crop> findByPublicKeysAndScientificName(@WebParam(name = "cropRetrievalByPubKeysAndScientificNameRequest")
                                                        CropRetrievalByPubKeysAndScientificNameRequest cropRetrievalByPubKeysAndScientificNameRequest) throws CropRetrievalByPubKeyAndScientificNameException;
}