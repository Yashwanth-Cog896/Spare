package com.monsanto.tps.lexiconservices.manufacturing.line.edit.services;

import com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions.EditManufacturingLineException;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineResponse;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/13/13
 * Time: 11:13 AM
 */
@WebService
public interface EditManufacturingLineService {

    @WebMethod
    List<EditManufacturingLineResponse> processEditManufacturingLine(@WebParam(name = "editManufacturingLineRequestList") List<EditManufacturingLineRequest> editManufacturingLineRequestList)
            throws EditManufacturingLineException;

}
