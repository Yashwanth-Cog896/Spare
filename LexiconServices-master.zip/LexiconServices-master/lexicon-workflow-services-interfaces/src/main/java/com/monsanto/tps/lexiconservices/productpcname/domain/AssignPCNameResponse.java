package com.monsanto.tps.lexiconservices.productpcname.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 12:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPCNameResponse {

    private List<String> errors = new ArrayList<String>();
    private List<String> notes = new ArrayList<String>();
    private String preComlName;
    private String productPubkey;

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

    public List<String> getNotes() {
        return notes;
    }

    public void setNotes(List<String> notes) {
        this.notes = notes;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }
}
