package com.monsanto.tps.lexiconservices.productpcname.service;

import javax.xml.ws.WebFault;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 12:34 PM
 * To change this template use File | Settings | File Templates.
 */
@WebFault
public class AssignPCNameServiceException extends RuntimeException {

  private List<String> infoList = new ArrayList<String>();

  public AssignPCNameServiceException() {
  }

  public AssignPCNameServiceException(String message, Throwable cause) {
    super(message, cause);
  }

  @Override
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.getMessage());
    for (String info : infoList) {
      stringBuilder.append(info);
    }
    return stringBuilder.toString();
  }
}
