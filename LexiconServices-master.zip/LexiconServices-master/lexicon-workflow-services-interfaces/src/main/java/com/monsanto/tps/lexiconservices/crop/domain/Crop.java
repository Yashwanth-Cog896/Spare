package com.monsanto.tps.lexiconservices.crop.domain;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 12/23/13
 * Time: 2:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class Crop extends BaseCrop {

  private List<BayerCode> bayerCodes;

  public Crop(String publicKey, String name, String abbreviation, String shippingStatement, List<BayerCode> bayerCodes) {
    super(publicKey, name, abbreviation, shippingStatement);
    this.bayerCodes = bayerCodes;
  }

  public Crop() {
    super();
  }

  public List<BayerCode> getBayerCodes() {
    return bayerCodes;
  }

  public void setBayerCodes(List<BayerCode> bayerCodes) {
    this.bayerCodes = bayerCodes;
  }
}
