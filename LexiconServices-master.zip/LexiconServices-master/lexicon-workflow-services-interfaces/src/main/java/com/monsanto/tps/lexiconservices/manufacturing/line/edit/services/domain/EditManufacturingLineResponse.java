package com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain;


import java.io.Serializable;
import java.util.*;

public class EditManufacturingLineResponse implements Serializable {

  private List<String> messages = new ArrayList<String>();

  public List<String> getMessages() {
    return normalize(messages);
  }

  public void setMessages(List<String> messages) {
    this.messages = messages;
  }

  private List<String> normalize(List<String> messages) {
    return messages == null ? new ArrayList<String>() : messages;
  }
}