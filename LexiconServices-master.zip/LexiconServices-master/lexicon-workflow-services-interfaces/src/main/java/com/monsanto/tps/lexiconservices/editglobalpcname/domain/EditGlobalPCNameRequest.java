package com.monsanto.tps.lexiconservices.editglobalpcname.domain;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 2:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameRequest {

  private String productPubKey;
  private String preComlName;
  private String tagVarietyName;
  private String supplyChainOwner;
  private String productClassificationCode;
  private boolean validationOnly;

  public String getProductPubKey() {
    return productPubKey;
  }

  public void setProductPubKey(String productPubKey) {
    this.productPubKey = productPubKey;
  }

  public String getPreComlName() {
    return preComlName;
  }

  public void setPreComlName(String preComlName) {
    this.preComlName = preComlName;
  }

  public String getTagVarietyName() {
    return tagVarietyName;
  }

  public void setTagVarietyName(String tagVarietyName) {
    this.tagVarietyName = tagVarietyName;
  }

  public String getSupplyChainOwner() {
    return supplyChainOwner;
  }

  public void setSupplyChainOwner(String supplyChainOwner) {
    this.supplyChainOwner = supplyChainOwner;
  }

  public String getProductClassificationCode() {
    return productClassificationCode;
  }

  public void setProductClassificationCode(String productClassificationCode) {
    this.productClassificationCode = productClassificationCode;
  }

  public boolean isValidationOnly() {
    return validationOnly;
  }

  public void setValidationOnly(boolean validationOnly) {
    this.validationOnly = validationOnly;
  }

}
