package com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain;

import com.monsanto.Util.StringUtils;

public class EditManufacturingLineRequest
{
   private String targetManufacturingName;
   private String newManufacturingName;
   private String newVarietyName;

  public String getTargetManufacturingName() {
      return normalizeOnGetSoReflectivelySetFieldsWillBeCorrect(targetManufacturingName);
   }

   public void setTargetManufacturingName(String targetManufacturingName) {
      this.targetManufacturingName = targetManufacturingName;
   }

   public String getNewManufacturingName() {
      return normalizeOnGetSoReflectivelySetFieldsWillBeCorrect(newManufacturingName);
   }

   public void setNewManufacturingName(String newManufacturingName) {
      this.newManufacturingName = newManufacturingName;
   }

   public String getNewVarietyName() {
      return normalizeOnGetSoReflectivelySetFieldsWillBeCorrect(newVarietyName);
   }

   public void setNewVarietyName(String newVarietyName) {
      this.newVarietyName = (null==newVarietyName) ? "" : newVarietyName;
   }

   private String normalizeOnGetSoReflectivelySetFieldsWillBeCorrect(String value) {
      return normalize(value);
   }

   private String normalize(String value) {
      return StringUtils.trimNullable(StringUtils.toUpperCaseNull(value));
   }
}