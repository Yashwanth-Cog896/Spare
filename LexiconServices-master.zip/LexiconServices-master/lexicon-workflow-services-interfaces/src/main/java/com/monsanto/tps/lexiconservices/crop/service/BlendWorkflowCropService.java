package com.monsanto.tps.lexiconservices.crop.service;

import javax.jws.WebMethod;
import javax.jws.WebService;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 4/28/14
 * Time: 11:44 AM
 */
@WebService
public interface BlendWorkflowCropService {

    @WebMethod
    List<String> getBlendWorkflowCropNames();

     @WebMethod
     List<String> getBlendWorkflowCropPubKeys();

}
