package com.monsanto.tps.lexiconservices.productpcname.domain;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 11:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class AssignedGermplasm {

  private long germplasmId;
  private boolean preferred;

  public long getGermplasmId() {
    return germplasmId;
  }

  public void setGermplasmId(long germplasmId) {
    this.germplasmId = germplasmId;
  }

  public boolean isPreferred() {
    return preferred;
  }

  public void setPreferred(boolean preferred) {
    this.preferred = preferred;
  }
}
