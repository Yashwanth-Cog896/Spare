package com.monsanto.tps.lexiconservices.productpcname.domain;

public class ValidationCondition {
    private String code;
    private String error;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
