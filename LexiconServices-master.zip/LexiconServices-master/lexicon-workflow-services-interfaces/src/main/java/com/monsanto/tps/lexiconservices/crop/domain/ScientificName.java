package com.monsanto.tps.lexiconservices.crop.domain;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ScientificName {
  private String name;
  private String publicKey;

  public ScientificName() {
  }

  public ScientificName(String name, String publicKey) {
    this.name = name;
    this.publicKey = publicKey;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public void setPublicKey(String publicKey) {
    this.publicKey = publicKey;
  }
}