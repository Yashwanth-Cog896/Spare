package com.monsanto.tps.lexiconservices.productpcname.domain;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 15, 2006
 * Time: 6:41:51 PM
 * To change this template use File | Settings | File Templates.
 */
public enum ValidationSeverity
{
    INFO,ERROR;
}
