package com.monsanto.tps.lexiconservices.productpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 1:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationCondition_UT {

  private ValidationCondition validationCondition;

  @Before
  public void init() {
    validationCondition = new ValidationCondition();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(validationCondition);
  }
}
