package com.monsanto.tps.lexiconservices.editglobalpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 2:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameRequest_UT {

  public static final String PRE_COML_NAME = "PreComlName";
  public static final String PRODUCT_CLASSIFICATION_CODE = "ProductClassificationCode";
  public static final String PRODUCT_PUB_KEY = "ProductPubKey";
  public static final boolean VALIDATION_ONLY = true;
  public static final String SUPPLY_CHAIN_OWNER = "SupplyChainOwner";
  public static final String TAG_VARIETY_NAME = "TagVarietyName";
  private EditGlobalPCNameRequest editGlobalPCNameRequest ;

  @Before
  public void init() {
    editGlobalPCNameRequest = new EditGlobalPCNameRequest();
  }

  @Test
  public void testBeanGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(editGlobalPCNameRequest);
  }

  @Test
  public void testGetterSetters() throws Exception {
    editGlobalPCNameRequest.setPreComlName(PRE_COML_NAME);
    editGlobalPCNameRequest.setProductClassificationCode(PRODUCT_CLASSIFICATION_CODE);
    editGlobalPCNameRequest.setProductPubKey(PRODUCT_PUB_KEY);
    editGlobalPCNameRequest.setValidationOnly(VALIDATION_ONLY);
    editGlobalPCNameRequest.setSupplyChainOwner(SUPPLY_CHAIN_OWNER);
    editGlobalPCNameRequest.setTagVarietyName(TAG_VARIETY_NAME);
    assertEquals(editGlobalPCNameRequest.getPreComlName(),PRE_COML_NAME);
    assertEquals(editGlobalPCNameRequest.getProductClassificationCode(),PRODUCT_CLASSIFICATION_CODE);
    assertEquals(editGlobalPCNameRequest.getProductPubKey(),PRODUCT_PUB_KEY);
    assertEquals(editGlobalPCNameRequest.getTagVarietyName(),TAG_VARIETY_NAME);
    assertEquals(editGlobalPCNameRequest.getSupplyChainOwner(),SUPPLY_CHAIN_OWNER);
    assertEquals(editGlobalPCNameRequest.isValidationOnly(),VALIDATION_ONLY);

  }
}
