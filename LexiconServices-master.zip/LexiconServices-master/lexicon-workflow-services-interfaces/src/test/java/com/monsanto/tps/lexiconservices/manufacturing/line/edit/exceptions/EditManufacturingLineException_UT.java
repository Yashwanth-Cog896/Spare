package com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions;

import junit.framework.Assert;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 12/11/13
 * Time: 10:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class EditManufacturingLineException_UT {
  @Test
  public void test() throws Exception {

    Exception cause = new Exception("test exception");
    EditManufacturingLineException exception = new EditManufacturingLineException("An Exception Occurred", cause);

    Assert.assertEquals("An Exception Occurred", exception.getMessage());
    Assert.assertEquals(cause, exception.getCause());
    assertNotNull(exception.getMessage());

  }

  @Test
  public void testEmptyConstructor() throws Exception {
    EditManufacturingLineException e = new EditManufacturingLineException();
    Assert.assertNotNull(e);
  }

}
