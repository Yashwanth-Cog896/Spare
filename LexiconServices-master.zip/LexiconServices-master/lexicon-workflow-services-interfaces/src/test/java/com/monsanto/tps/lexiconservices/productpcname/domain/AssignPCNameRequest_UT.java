package com.monsanto.tps.lexiconservices.productpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 1:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPCNameRequest_UT {

  public static final long GERMPLASM_ID = 1L;
  public static final boolean PREFERRED = Boolean.FALSE.booleanValue();
  private AssignPCNameRequest assignPCNameRequest;

  @Before
  public void init() {
    assignPCNameRequest = new AssignPCNameRequest();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(assignPCNameRequest);
  }

  @Test
  public void testOverloadedConstructor() {
    List<String> countryPubkeys = new ArrayList<String>();
    countryPubkeys.add("testPubKey");
    List<AssignedGermplasm> assignedGermplasmList = new ArrayList<AssignedGermplasm>();
    AssignedGermplasm assignedGermplasm = new AssignedGermplasm();
    assignedGermplasm.setGermplasmId(GERMPLASM_ID);
    assignedGermplasm.setPreferred(PREFERRED);
    assignedGermplasmList.add(assignedGermplasm);
    assignPCNameRequest.setCountryPubkeys(countryPubkeys);
    assignPCNameRequest.setAssignedGermplasm(assignedGermplasmList);
    assertEquals(countryPubkeys, assignPCNameRequest.getCountryPubkeys());
    assertEquals(GERMPLASM_ID, assignPCNameRequest.getAssignedGermplasm().get(0).getGermplasmId());
    assertEquals(PREFERRED, assignPCNameRequest.getAssignedGermplasm().get(0).isPreferred());
  }
}
