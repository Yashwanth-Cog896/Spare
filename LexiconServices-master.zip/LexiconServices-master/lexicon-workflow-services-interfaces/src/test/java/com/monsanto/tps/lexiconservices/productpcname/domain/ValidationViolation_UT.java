package com.monsanto.tps.lexiconservices.productpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 3:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationViolation_UT {

  public static final String ERROR_CODE = "ErrorCode";
  public static final String ERROR = "Error";
  public static final ValidationSeverity SEVERITY = ValidationSeverity.ERROR;
  private ValidationViolation validationViolation;

  @Before
  public void init() {
    validationViolation = new ValidationViolation();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(validationViolation);
  }

  @Test
  public void testOverloadedConstructor() {
    ValidationCondition condition = new ValidationCondition();
    condition.setCode(ERROR_CODE);
    condition.setError(ERROR);
    validationViolation.setCondition(condition);
    validationViolation.setSeverity(SEVERITY);
    assertEquals(ERROR_CODE, validationViolation.getCondition().getCode());
    assertEquals(ERROR, validationViolation.getCondition().getError());
    assertEquals(SEVERITY, validationViolation.getSeverity());
  }
}
