package com.monsanto.tps.lexiconservices.crop.domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CropPublicKeyTypeEnum_UT {

  @Test
  public void test() {
    assertEquals("C.CROP_PUBKEY", CropPublicKeyTypeEnum.CROP.getType());
    assertEquals("BC.BAYER_CODE_PUBKEY", CropPublicKeyTypeEnum.BAYER_CODE.getType());
    assertEquals("BCGS.BAYER_CODE_GENUS_SP_PUBKEY", CropPublicKeyTypeEnum.SCIENTIFIC.getType());
  }
}