package com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain;

import junit.framework.TestCase;

import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/14/13
 * Time: 2:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditManufacturingLineResponse_UT extends TestCase {

  public void testGetMessages()
    throws Exception {
    List<String> expectedMessages = new ArrayList<String>();
    expectedMessages.add("This is a test message");
    EditManufacturingLineResponse response = new EditManufacturingLineResponse();
    response.setMessages(expectedMessages);
    assertSame(expectedMessages, response.getMessages());
  }

  public void testGetMessages_NullMessages_ReturnsEmptyArray()
    throws Exception {
    List<String> expectedMessages = null;
    EditManufacturingLineResponse response = new EditManufacturingLineResponse();
    response.setMessages(expectedMessages);
    assertNotNull(response.getMessages());
    assertEquals(0, response.getMessages().size());
  }
}
