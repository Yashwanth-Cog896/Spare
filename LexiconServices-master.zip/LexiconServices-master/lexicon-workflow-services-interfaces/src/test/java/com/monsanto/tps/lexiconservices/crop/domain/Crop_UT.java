package com.monsanto.tps.lexiconservices.crop.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertEquals;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class Crop_UT {
  private String name = "testName";
  private String publicKey = "testPubKey";
  private String abbreviation = "testAbbreviation";
  private String shippingStatement = "shippingStatement";
  private List<BayerCode> bayerCodes = new ArrayList<BayerCode>();

  @Test
  public void testBean() throws Exception {
    Crop crop = new Crop();
    new BeanGetterSetterTester().testBean(crop);
  }

  @Test
  public void testOverloadedConstructor() throws Exception {
    BayerCode bayerCode = new BayerCode("testCode", publicKey, null);
    bayerCodes.add(bayerCode);
    Crop crop = new Crop(publicKey, name, abbreviation, shippingStatement, bayerCodes);
    assertEquals(publicKey, crop.getPublicKey());
    assertEquals(name, crop.getName());
    assertEquals(abbreviation, crop.getAbbreviation());
    assertEquals(shippingStatement, crop.getShippingStatement());
    assertEquals(1, crop.getBayerCodes().size());
    assertEquals(publicKey, crop.getBayerCodes().get(0).getPublicKey());
  }
}