package com.monsanto.tps.lexiconservices.productpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 1:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignedGermplasm_UT {

  private AssignedGermplasm assignedGermplasm;
  public static final long GERMPLASM_ID = 1L;
  public static final boolean PREFERRED = Boolean.FALSE.booleanValue();

  @Before
  public void init() {
    assignedGermplasm = new AssignedGermplasm();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(assignedGermplasm);
  }

  @Test
  public void testOverloadedConstructor() {
    assignedGermplasm = new AssignedGermplasm();
    assignedGermplasm.setGermplasmId(GERMPLASM_ID);
    assignedGermplasm.setPreferred(PREFERRED);
    assertEquals(GERMPLASM_ID, assignedGermplasm.getGermplasmId());
    assertEquals(PREFERRED, assignedGermplasm.isPreferred());
  }
}
