package com.monsanto.tps.lexiconservices.crop.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CropRetrievalByPubKeyAndScientificNameRequest_UT {

  private CropRetrievalByPubKeysAndScientificNameRequest cropRetrievalByPubKeyAndScientificNameRequest;

  @Before
  public void init() {
    cropRetrievalByPubKeyAndScientificNameRequest = new CropRetrievalByPubKeysAndScientificNameRequest();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(cropRetrievalByPubKeyAndScientificNameRequest);
  }

  @Test
  public void testOverloadedConstructor() {
    List<String> publickeys = new ArrayList<String>();
    publickeys.add("testPubKey");
    String scientificName = "testScientificName";
    cropRetrievalByPubKeyAndScientificNameRequest = new CropRetrievalByPubKeysAndScientificNameRequest(publickeys, scientificName, null);
    assertEquals(publickeys, cropRetrievalByPubKeyAndScientificNameRequest.getPublickeys());
    assertEquals(scientificName, cropRetrievalByPubKeyAndScientificNameRequest.getScientificName());
    assertEquals(null, cropRetrievalByPubKeyAndScientificNameRequest.getPublicKeyTypeEnum());
  }
}