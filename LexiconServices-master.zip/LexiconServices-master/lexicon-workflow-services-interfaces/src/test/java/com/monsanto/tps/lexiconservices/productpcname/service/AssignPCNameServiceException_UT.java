package com.monsanto.tps.lexiconservices.productpcname.service;

import junit.framework.Assert;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 1:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPCNameServiceException_UT {

  @Test
  public void test() throws Exception {

    Exception cause = new Exception("test exception");
    AssignPCNameServiceException exceptionRetrieval = new AssignPCNameServiceException("Carp", cause);

    Assert.assertEquals("Carp", exceptionRetrieval.getMessage());
    Assert.assertEquals(cause, exceptionRetrieval.getCause());
    assertNotNull(exceptionRetrieval.getMessage());

  }

  @Test
  public void testEmptyConstructor() throws Exception {
    AssignPCNameServiceException e = new AssignPCNameServiceException();
    Assert.assertNotNull(e);
  }
}
