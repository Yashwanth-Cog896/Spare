package com.monsanto.tps.lexiconservices.productpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 1/28/14
 * Time: 1:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPCNameResponse_UT {

    public static final String ERROR_CODE = "ErrorCode";
    public static final String ERROR = "Error";
    public static final ValidationSeverity SEVERITY = ValidationSeverity.ERROR;
    private AssignPCNameResponse assignPCNameResponse;

    @Before
    public void init() {
        assignPCNameResponse = new AssignPCNameResponse();
    }

    @Test
    public void testGetterSetter() throws Exception {
        new BeanGetterSetterTester().testBean(assignPCNameResponse);
    }

    @Test
    public void testOverloadedConstructor() {
        List<ValidationViolation> validationViolations = new ArrayList<ValidationViolation>();
        ValidationViolation violation = new ValidationViolation();
        ValidationCondition condition = new ValidationCondition();
        condition.setCode(ERROR_CODE);
        condition.setError(ERROR);
        violation.setCondition(condition);
        violation.setSeverity(SEVERITY);
        validationViolations.add(violation);
        /*assignPCNameResponse.setValidationViolations(validationViolations);
        assertEquals(ERROR_CODE,assignPCNameResponse.getValidationViolations().get(0).getCondition().getCode());
        assertEquals(ERROR,assignPCNameResponse.getValidationViolations().get(0).getCondition().getError());
        assertEquals(SEVERITY,assignPCNameResponse.getValidationViolations().get(0).getSeverity());*/
    }
}
