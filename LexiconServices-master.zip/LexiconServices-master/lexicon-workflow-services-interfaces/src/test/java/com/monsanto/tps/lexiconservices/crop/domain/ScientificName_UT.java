package com.monsanto.tps.lexiconservices.crop.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class ScientificName_UT {
  private String name = "testName";
  private String publicKey = "testPubKey";

  @Test
  public void testBean() throws Exception {
    ScientificName scientificName = new ScientificName();
    new BeanGetterSetterTester().testBean(scientificName);
  }

  @Test
  public void testOverloadedConstructor() throws Exception {
    ScientificName scientificName = new ScientificName(name, publicKey);
    assertEquals(name, scientificName.getName());
    assertEquals(publicKey, scientificName.getPublicKey());
  }

  @Test
  public void testGetterSetter() throws Exception {
    ScientificName scientificName = new ScientificName();
    scientificName.setName(name);
    scientificName.setPublicKey(publicKey);
    assertEquals(name, scientificName.getName());
    assertEquals(publicKey, scientificName.getPublicKey());
  }
}