package com.monsanto.tps.lexiconservices.crop.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertEquals;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class BayerCode_UT {
  private String code = "testCode";
  private String publicKey = "testPubKey";
  private List<ScientificName> scientificNameList = new ArrayList<ScientificName>();

  @Test
  public void testBean() throws Exception {
    BayerCode bayerCode = new BayerCode();
    new BeanGetterSetterTester().testBean(bayerCode);
  }

  @Test
  public void testOverloadedConstructor() throws Exception {
    ScientificName scientificName = new ScientificName("testName", publicKey);
    scientificNameList.add(scientificName);
    BayerCode bayerCode = new BayerCode(code, publicKey, scientificNameList);
    assertEquals(code, bayerCode.getCode());
    assertEquals(publicKey, bayerCode.getPublicKey());
    assertEquals(1, bayerCode.getScientificNames().size());
    assertEquals(publicKey, bayerCode.getScientificNames().get(0).getPublicKey());
  }

  @Test
  public void testSetterGetter() throws Exception {
    ScientificName scientificName = new ScientificName("testName", publicKey);
    scientificNameList.add(scientificName);
    BayerCode bayerCode = new BayerCode();
    bayerCode.setCode(code);
    bayerCode.setPublicKey(publicKey);
    bayerCode.setScientificNames(scientificNameList);
    assertEquals(code, bayerCode.getCode());
    assertEquals(publicKey, bayerCode.getPublicKey());
    assertEquals(1, bayerCode.getScientificNames().size());
    assertEquals(publicKey, bayerCode.getScientificNames().get(0).getPublicKey());
  }
}