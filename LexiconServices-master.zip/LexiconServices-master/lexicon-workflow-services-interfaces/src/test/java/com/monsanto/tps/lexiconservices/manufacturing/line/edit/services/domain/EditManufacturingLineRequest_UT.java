package com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;
/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/14/13
 * Time: 2:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditManufacturingLineRequest_UT {

  private EditManufacturingLineRequest editManufacturingLineRequest;

  @Before
  public void init() {
    editManufacturingLineRequest = new EditManufacturingLineRequest();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(editManufacturingLineRequest);
  }
}
