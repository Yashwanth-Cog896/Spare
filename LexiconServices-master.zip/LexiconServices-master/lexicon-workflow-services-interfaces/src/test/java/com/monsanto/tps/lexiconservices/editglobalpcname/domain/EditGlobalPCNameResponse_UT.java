package com.monsanto.tps.lexiconservices.editglobalpcname.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertSame;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 3/10/14
 * Time: 12:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameResponse_UT {

  private EditGlobalPCNameResponse editGlobalPCNameResponse;


  @Before
  public void init() {
    editGlobalPCNameResponse = new EditGlobalPCNameResponse();
  }

  @Test
  public void testGetterSetter() throws Exception {
    new BeanGetterSetterTester().testBean(editGlobalPCNameResponse);
  }

  @Test
  public void testOverloadedConstructors() throws Exception {
    List<String> errors = new ArrayList<String>();
    errors.add("Error");
    List<String> notes = new ArrayList<String>();
    notes.add("Notes");
    editGlobalPCNameResponse.setErrors(errors);
    editGlobalPCNameResponse.setNotes(notes);
    assertSame(editGlobalPCNameResponse.getErrors(),errors);
    assertSame(editGlobalPCNameResponse.getNotes(),notes);
  }
}
