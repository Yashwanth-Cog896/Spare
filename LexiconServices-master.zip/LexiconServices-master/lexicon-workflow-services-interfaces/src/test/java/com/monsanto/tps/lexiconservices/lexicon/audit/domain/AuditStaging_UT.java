package com.monsanto.tps.lexiconservices.lexicon.audit.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 12/26/13
 * Time: 9:44 AM
 */
public class AuditStaging_UT {

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

    @Test
    public void test_getterSetter() throws Exception {

        AuditStaging auditStaging = new AuditStaging();
        beanGetterSetterTester.testBean(auditStaging);
    }
}
