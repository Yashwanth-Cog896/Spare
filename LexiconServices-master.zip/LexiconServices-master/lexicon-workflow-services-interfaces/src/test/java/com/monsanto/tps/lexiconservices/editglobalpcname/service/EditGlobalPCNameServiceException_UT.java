package com.monsanto.tps.lexiconservices.editglobalpcname.service;

import com.monsanto.tps.lexiconservices.productpcname.service.AssignPCNameServiceException;
import junit.framework.Assert;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/7/14
 * Time: 2:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditGlobalPCNameServiceException_UT {

  public static final String ANYCAUSE = "ANYCAUSE";

  @Test
  public void test() throws Exception {

    Exception cause = new Exception("test exception");
    EditGlobalPCNameServiceException exceptionRetrieval = new EditGlobalPCNameServiceException(ANYCAUSE, cause);

    Assert.assertEquals(ANYCAUSE, exceptionRetrieval.getMessage());
    Assert.assertEquals(cause, exceptionRetrieval.getCause());
    assertNotNull(exceptionRetrieval.getMessage());

  }

  @Test
  public void testEmptyConstructor() throws Exception {
    AssignPCNameServiceException e = new AssignPCNameServiceException();
    Assert.assertNotNull(e);
  }
}
