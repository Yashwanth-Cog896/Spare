package com.monsanto.tps.lexiconservices.crop.service;

import junit.framework.Assert;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$    	 On:	$Date$
 *
 * @author PSETH
 * @version $Revision$
 */
public class CropRetrievalByPubKeyScientificNameException_UT {
  @Test
  public void test() throws Exception {

    Exception cause = new Exception("test exception");
    CropRetrievalByPubKeyAndScientificNameException exceptionRetrieval = new CropRetrievalByPubKeyAndScientificNameException("Carp", cause);

    Assert.assertEquals("Carp", exceptionRetrieval.getMessage());
    Assert.assertEquals(cause, exceptionRetrieval.getCause());
    assertNotNull(exceptionRetrieval.getMessage());

  }

  @Test
  public void testEmptyConstructor() throws Exception {
    CropRetrievalByPubKeyAndScientificNameException e = new CropRetrievalByPubKeyAndScientificNameException();
    Assert.assertNotNull(e);
  }
}