<%@ page import="com.monsanto.tcc.breedinglabservices.common.utilities.memory.MemoryStatus" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ page import="java.util.Date" %>
<%@ page import="java.util.Properties" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<%
  MemoryStatus memoryStatus = (MemoryStatus) application.getAttribute("MemoryUsageStatus");
  if (memoryStatus == null) {
    memoryStatus = new MemoryStatus(true);
    application.setAttribute("MemoryUsageStatus", memoryStatus);
  }
  memoryStatus.logMemoryUsage();
  DecimalFormat fmt = new DecimalFormat("#0.00");

  String environment = System.getProperty("lsi.function");

  Properties appProp = new Properties();
    appProp.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("application.properties"));
  String version = appProp.getProperty("application.version");

  String systemTime = new Date().toString();
//  InitialContext context = new InitialContext();
%>

<html>
<head>
    <title>${project.name} Statistics</title>

    <style type="text/css">
    body {
      font-family: "Arial", sans-serif;
      font-size: 10pt;
      background-color: white;
    }

    td {
      text-align: right;
    }

    .label {
      background-color: #ccccff;
      font-weight: bold;
    }

    .data {
      background-color: white;
    }
  </style>
</head>

<body>

<div class="content-page">
    <h1>Lexicon Services</h1>
    <table>
        <tr>
            <td>
                <table cellspacing="1" cellpadding="4">
                    <tr>
                        <td bgcolor="#eeeeee" colspan="3" align="center">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">System Time:</td>
                        <td class="data"><%= systemTime %></td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Version:</td>
                        <td class="data"><%= version %></td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Environment:</td>
                        <td class="data"><%= environment %></td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Max memory:</td>
                        <td class="data"><%= fmt.format(memoryStatus.getMaxAsMeg()) %> M</td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Total Memory:</td>
                        <td class="data"><%= fmt.format(memoryStatus.getTotalAsMeg()) %> M</td>
                        <td class="data">(<%= fmt.format(memoryStatus.getTotalAsPercent()) %> %)</td>
                    </tr>
                    <tr>
                        <td class="label">Used:</td>
                        <td class="data"><%= fmt.format(memoryStatus.getUsedAsMeg()) %> M</td>
                        <td class="data">(<%= fmt.format(memoryStatus.getUsedAsPercent()) %> %)</td>
                    </tr>
                    <tr>
                        <td class="label">Free:</td>
                        <td class="data"><%= fmt.format(memoryStatus.getFreeMemoryAsMeg()) %> M</td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Java Vendor:</td>
                        <td class="data"><%= System.getProperty("java.vendor") %></td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Java Version:</td>
                        <td class="data"><%= System.getProperty("java.version") %></td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td class="label">Java Home:</td>
                        <td class="data"><%= System.getProperty("java.home") %></td>
                        <td class="data">&nbsp;</td>
                    </tr>
                    <tr>
                        <td>Service Endpoints:</td>
                        <td>
                            <a href="services">Service Endpoints</a></li>
                        </td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Logging Console:</td>
                        <td><a href="log-viewer/">Logging Console</a></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>App Status:</td>
                        <td><a href="AppStatus">Application Status</a></td>
                        <td></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>

</body>
</html>