package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

public class MirageSeedProductMaturityPK implements Serializable {

    @Id
    @Column(name = "PRODUCT_ID", nullable = false)
    private long productId;

    @Id
    @Column(name = "MATURITY_UNIT", nullable = false, length = EntityConstant.LENGTH_8)
    private long maturityUnit;

    public MirageSeedProductMaturityPK() {
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public long getProductId() {
        return productId;
    }

    public long getMaturityUnit() {
        return maturityUnit;
    }

    public void setMaturityUnit(long maturityUnit) {
        this.maturityUnit = maturityUnit;
    }
}