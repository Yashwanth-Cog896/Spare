package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCTION_STATUS", schema = "Lexicon")
public class LexiconProductionStatusEntity  implements Serializable {
    @Id
    @Column(name = "PRODUCTION_STATUS_ID")
    private long id;
    @Column(name="PRODUCTION_STATUS_NAME",nullable = true,length = EntityConstant.LENGTH_20)
    private String productionStatusName;
    @Column(name = "SOURCE_SYSTEM", nullable = false, length = EntityConstant.LENGTH_100)
    private String sourceSystem;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getProductionStatusName() {
        return productionStatusName;
    }

    public void setProductionStatusName(String productionStatusName) {
        this.productionStatusName = productionStatusName;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }
}
