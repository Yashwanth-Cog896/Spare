package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 22, 2011
 * Time: 10:08:39 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "commercialTraitNameIdGenerator",allocationSize = 1,sequenceName = "Lexicon.COML_TRAIT_ID_SEQ")
@Table(name = "COML_TRAIT_NAME2", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)

public class CommercialTraitNameEntity {
    @Id
    @GeneratedValue(generator = "commercialTraitNameIdGenerator")
    @Column(name="COML_TRAIT_NAME_ID")
    private long id;
    @Column(name="TRAIT_ABBR",length = EntityConstant.LENGTH_15,nullable = false)
    private  String abbreviation;
    @Column(name="TRAIT_DESC",length= EntityConstant.LENGTH_50,nullable = false)
    private String description;
    @Type(type = "boolean-yn")
    @Column(name="IS_ACTIVE",nullable = false)
    private boolean active;

    @ManyToOne(optional = true)
    @JoinColumn(name = "COMPANY_ID",nullable = true)
    private LexiconCompanyEntity lexiconCompany;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCompanyEntity getLexiconCompany() {
        return lexiconCompany;
    }

    public void setLexiconCompany(LexiconCompanyEntity lexiconCompany) {
        this.lexiconCompany = lexiconCompany;
    }
}
