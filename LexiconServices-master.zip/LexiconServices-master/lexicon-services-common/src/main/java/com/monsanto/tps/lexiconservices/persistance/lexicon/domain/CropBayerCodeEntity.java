package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/17/13
 * Time: 12:44 PM
 * To change this template use File | Settings | File Templates.
 */
@Filterable
@Entity
@SequenceGenerator(name = "cropBayerCodeIdGenerator", allocationSize = 1, sequenceName = "Lexicon.CROP_BAYER_CODE_ID_SEQ")
@Table(name = "CROP_BAYER_CODE", schema = "Lexicon")
public class CropBayerCodeEntity {

    @EmbeddedId
    private CropBayerCodeComposite cropBayerCodeComposite;

    @FilterableProperty(filterKey = "auditId")
    @Column(name = "AUDIT_ID", nullable = false, length = EntityConstant.LENGTH_20)
    private long auditId;

    public CropBayerCodeComposite getCropBayerCodeComposite() {
        return cropBayerCodeComposite;
    }

    public void setCropBayerCodeComposite(CropBayerCodeComposite cropBayerCodeComposite) {
        this.cropBayerCodeComposite = cropBayerCodeComposite;
    }

    public long getAuditId() {
        return auditId;
    }

    public void setAuditId(long auditId) {
        this.auditId = auditId;
    }

}
