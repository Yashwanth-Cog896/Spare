package com.monsanto.tps.lexiconservices.persistance.constant;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EntityConstant {

  public static final int LENGTH_2 = 2;
  public static final int LENGTH_3 = 3;
  public static final int LENGTH_10 = 10;
  public static final int LENGTH_15 = 15;
  public static final int LENGTH_20 = 20;
  public static final int LENGTH_22 = 22;
  public static final int LENGTH_30 = 30;
  public static final int LENGTH_32 = 32;
  public static final int LENGTH_40 = 40;
  public static final int LENGTH_50 = 50;
  public static final int LENGTH_64 = 64;
  public static final int LENGTH_80 = 80;
  public static final int LENGTH_100 = 100;
  public static final int LENGTH_200 = 200;
  public static final int LENGTH_255 = 255;
  public static final int LENGTH_2000 = 2000;
  public static final int LENGTH_3200 = 3200;
  public static final int LENGTH_4000 = 4000;
  public static final int LENGTH_128 = 128;
  public static final int LENGTH_4 = 4;
  public static final int LENGTH_12 = 12;
  public static final int LENGTH_35 = 35;
  public static final int LENGTH_6 = 6;
  public static final int LENGTH_8 = 8;

  public static final int PRECISION_CONSTANT_22=22;
  public static final int PRECISION_CONSTANT_20=20;
  public static final int PRECISION_CONSTANT_8=8;
  public static final int PRECISION_CONSTANT_7=7;
  public static final int PRECISION_CONSTANT_6=6;

  public static final int HASH_CODE_CONSTANT = 31;
}
