package com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 9:32 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "AUDIT_STAGING", schema = "LEXICON")
public class AuditStagingEntity implements Serializable {

  @Id
  @Column(name = "ORACLE_SID")
  private Long oracleSID;

  @Column(name = "USER_PARTY_ID", nullable = true)
  private Long userPartyID;

  @Column(name = "PROCESS_NAME", nullable = false, length = EntityConstant.LENGTH_50)
  private String processName;

  @Column(name = "AUDIT_COMMENT", nullable = true, length = EntityConstant.LENGTH_4000)
  private String auditComment;

  @Column(name = "AUDIT_REQUESTOR", nullable = true, length = EntityConstant.LENGTH_50)
  private String auditRequestor;

  @Column(name = "CREATION_TIMESTAMP", nullable = false)
  private Date creationTimestamp;

  @Column(name = "OSUSER", nullable = false, length = EntityConstant.LENGTH_30)
  private String osUser;

  @Column(name = "MACHINE", nullable = false, length = EntityConstant.LENGTH_64)
  private String machine;

  @Column(name = "USER_LOGIN_ID", nullable = false, length = EntityConstant.LENGTH_32)
  private String userLoginID;


  public Long getOracleSID() {
    return oracleSID;
  }

  public void setOracleSID(Long oracleSID) {
    this.oracleSID = oracleSID;
  }

  public Long getUserPartyID() {
    return userPartyID;
  }

  public void setUserPartyID(Long userPartyID) {
    this.userPartyID = userPartyID;
  }

  public String getProcessName() {
    return processName;
  }

  public void setProcessName(String processName) {
    this.processName = processName;
  }

  public String getAuditComment() {
    return auditComment;
  }

  public void setAuditComment(String auditComment) {
    this.auditComment = auditComment;
  }

  public String getAuditRequestor() {
    return auditRequestor;
  }

  public void setAuditRequestor(String auditRequestor) {
    this.auditRequestor = auditRequestor;
  }

  public Date getCreationTimestamp() {
    return creationTimestamp;
  }

  public void setCreationTimestamp(Date creationTimestamp) {
    this.creationTimestamp = creationTimestamp;
  }

  public String getOsUser() {
    return osUser;
  }

  public void setOsUser(String osUser) {
    this.osUser = osUser;
  }

  public String getMachine() {
    return machine;
  }

  public void setMachine(String machine) {
    this.machine = machine;
  }

  public String getUserLoginID() {
    return userLoginID;
  }

  public void setUserLoginID(String userLoginID) {
    this.userLoginID = userLoginID;
  }
}

