package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Filterable
@Entity
@SequenceGenerator(name = "cropIdGenerator",allocationSize = 1,sequenceName = "Lexicon.CROP_ID_SEQ")
@Table(name = "CROP", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class LexiconCropEntity implements Serializable {
  @Id
  @Column(name="CROP_ID")
  @GeneratedValue(generator = "cropIdGenerator")
  private long id;

  @Column(name = "CROP_NAME", nullable = false,length = EntityConstant.LENGTH_50)
  private String name;

  @Type(type="boolean-yn")
  @Column(name = "MAJOR_CROP", nullable = true)
  private boolean majorCrop;

  @FilterableProperty(filterKey="cropPubkey")
  @Column(name="CROP_PUBKEY",nullable = false,length= EntityConstant.LENGTH_20)
  private String pubkey;

  @Type(type="boolean-yn")
  @Column(name="REGULATORY_CROP",nullable = false)
  private boolean regulatory;

  @Column(name="COMPLIANCE_SHIPPING_STATEMENT",nullable = true, length= EntityConstant.LENGTH_255)
  private String complianceShippingStatement;

  @Column(name="ABBREVIATION", nullable = true, length= EntityConstant.LENGTH_2)
  private String abbreviation;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name="STAGE_CATEGORY_ID",nullable = false)
  private StageCategoryEntity stageCategory;

  //Family reference

  @Type(type="boolean-yn")
  @Column(name="AUTO_GENERATE_TAG_NM_IND",nullable = true)
  private Boolean autoGenerateTagVarietyName=false;

  public String getAbbreviation() {
    return abbreviation;
  }

  public void setAbbreviation(String abbreviation) {
    this.abbreviation = abbreviation;
  }

  public Boolean getAutoGenerateTagVarietyName() {
    return autoGenerateTagVarietyName;
  }

  public void setAutoGenerateTagVarietyName(Boolean autoGenerateTagVarietyName) {
    this.autoGenerateTagVarietyName = autoGenerateTagVarietyName;
  }

  public String getComplianceShippingStatement() {
    return complianceShippingStatement;
  }

  public void setComplianceShippingStatement(String complianceShippingStatement) {
    this.complianceShippingStatement = complianceShippingStatement;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public boolean isMajorCrop() {
    return majorCrop;
  }

  public void setMajorCrop(boolean majorCrop) {
    this.majorCrop = majorCrop;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPubkey() {
    return pubkey;
  }

  public void setPubkey(String pubkey) {
    this.pubkey = pubkey;
  }

  public boolean isRegulatory() {
    return regulatory;
  }

  public void setRegulatory(boolean regulatory) {
    this.regulatory = regulatory;
  }

  public StageCategoryEntity getStageCategory() {
    return stageCategory;
  }

  public void setStageCategory(StageCategoryEntity stageCategory) {
    this.stageCategory = stageCategory;
  }
}
