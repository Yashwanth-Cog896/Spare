package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:54:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PARENTAGE", schema = "MIDAS")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class GeneticMaterialParentEntity implements Serializable {
    @Id
    @Column(name = "PARENTAGE_ID", nullable = false)
    @GeneratedValue(generator="midas_generator")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PARENT_GENETIC_MATERIAL_ID")
    private GeneticMaterialEntity parent;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="GENETIC_MATERIAL_ID")
    private GeneticMaterialEntity child;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PARENTAL_ROLE_ID")
    private ParentalRoleEntity parentalRole;

    @Column(name="IS_TESTER",nullable = false)
    @Type(type="true_false")
    private boolean tester;

    public GeneticMaterialEntity getChild() {
        return child;
    }

    public void setChild(GeneticMaterialEntity child) {
        this.child = child;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public GeneticMaterialEntity getParent() {
        return parent;
    }

    public void setParent(GeneticMaterialEntity parent) {
        this.parent = parent;
    }

    public ParentalRoleEntity getParentalRole() {
        return parentalRole;
    }

    public void setParentalRole(ParentalRoleEntity parentalRole) {
        this.parentalRole = parentalRole;
    }

    public boolean isTester() {
        return tester;
    }

    public void setTester(boolean tester) {
        this.tester = tester;
    }
}
