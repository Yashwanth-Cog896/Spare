package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/18/13
 * Time: 2:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class CropBayerCodeComposite implements Serializable {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private LexiconCropEntity lexiconCrop;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "BAYER_CODE_ID", nullable = false)
    private BayerCodeEntity bayerCode;

    public CropBayerCodeComposite() {
    }

    public CropBayerCodeComposite(LexiconCropEntity lexiconCrop, BayerCodeEntity bayerCode) {
        this.lexiconCrop = lexiconCrop;
        this.bayerCode = bayerCode;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public BayerCodeEntity getBayerCode() {
        return bayerCode;
    }

    public void setBayerCode(BayerCodeEntity bayerCode) {
        this.bayerCode = bayerCode;
    }
}
