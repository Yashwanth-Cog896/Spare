package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCompanyEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasBrandEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCompanyEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name = "BRAND_XREF", schema = "FBS_COMMON")
public class FbsCommonBrandXrefEntity implements Serializable{

    @Id
    @Column(name="LEXICON_BRAND_PUBKEY",length = EntityConstant.LENGTH_20)
    private String lexiconBrandPubkey;

    @ManyToOne
    @JoinColumn(name = "MIDAS_BRAND_ID", nullable = true)
    private MidasBrandEntity midasBrand;

    @ManyToOne
    @JoinColumn(name = "MIRAGE_COMPANY_ID", nullable = true)
    private MirageCompanyEntity mirageCompany;

    @ManyToOne
    @JoinColumn(name = "LEXICON_COMPANY_PUBKEY",referencedColumnName = "COMPANY_PUBKEY",nullable = true)
    private LexiconCompanyEntity lexiconCompany;

    public String getLexiconBrandPubkey() {
        return lexiconBrandPubkey;
    }

    public void setLexiconBrandPubkey(String lexiconBrandPubkey) {
        this.lexiconBrandPubkey = lexiconBrandPubkey;
    }

    public LexiconCompanyEntity getLexiconCompany() {
        return lexiconCompany;
    }

    public void setLexiconCompany(LexiconCompanyEntity lexiconCompany) {
        this.lexiconCompany = lexiconCompany;
    }

    public MidasBrandEntity getMidasBrand() {
        return midasBrand;
    }

    public void setMidasBrand(MidasBrandEntity midasBrand) {
        this.midasBrand = midasBrand;
    }

    public MirageCompanyEntity getMirageCompany() {
        return mirageCompany;
    }

    public void setMirageCompany(MirageCompanyEntity mirageCompany) {
        this.mirageCompany = mirageCompany;
    }

}
