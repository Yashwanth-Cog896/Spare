/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

/* vvkalu - 6/23/11 */
@Entity
@Table(name = "CROP", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasCropEntity implements Serializable {
  public static final int PRECISION_6 = 6;
  public static final int PRECISION_7 = 7;
  public static final int SCALE_1 = 1;
  public static final int SCALE_2 = 2;
  @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "CROP_ID", precision = 0, length = EntityConstant.LENGTH_22)
    private long id;
    @Column(name = "NAME", length = EntityConstant.LENGTH_50, nullable = true)
    private String cropName;
    @Type(type="true_false")
    @Column(name = "REF_ACTIVE", nullable = false)
    private boolean refActive;

    @Column(name = "REM_CROP_ID", nullable = false, length = EntityConstant.LENGTH_2)
    private String remCropId;
    @Column(name = "GENUS_SPECIES", nullable = false, length = EntityConstant.LENGTH_2)
    private String genusSpecies;
    @Column(name = "RM_MIN", nullable = false, precision = EntityConstant.PRECISION_CONSTANT_6, scale = SCALE_1)
    private BigDecimal rmMin;
    @Column(name = "RM_MAX", nullable = false, precision = EntityConstant.PRECISION_CONSTANT_6, scale = SCALE_1)
    private BigDecimal rmMax;
    @Column(name = "RM_INCREMENT", nullable = false, precision = EntityConstant.PRECISION_CONSTANT_7, scale = SCALE_2)
    private BigDecimal rmIncrement;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getRemCropId() {
        return remCropId;
    }

    public void setRemCropId(String remCropId) {
        this.remCropId = remCropId;
    }

    public String getGenusSpecies() {
        return genusSpecies;
    }

    public void setGenusSpecies(String genusSpecies) {
        this.genusSpecies = genusSpecies;
    }

    public BigDecimal getRmMin() {
        return rmMin;
    }

    public void setRmMin(BigDecimal rmMin) {
        this.rmMin = rmMin;
    }

    public BigDecimal getRmMax() {
        return rmMax;
    }

    public void setRmMax(BigDecimal rmMax) {
        this.rmMax = rmMax;
    }

    public BigDecimal getRmIncrement() {
        return rmIncrement;
    }

    public void setRmIncrement(BigDecimal rmIncrement) {
        this.rmIncrement = rmIncrement;
    }
}