package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.JoinColumnOrFormula;
import org.hibernate.annotations.JoinColumnsOrFormulas;
import org.hibernate.annotations.JoinFormula;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:05:08 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "lexiconProductStageIdGenerator", allocationSize = 1, sequenceName = "Lexicon.PRODUCT_STAGE_ID_SEQ")
@Table(name = "PRODUCT_STAGE", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class LexiconProductStageEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "lexiconProductStageIdGenerator")
    @Column(name = "PRODUCT_STAGE_ID")
    private long id;

    @Column(name = "PRODUCT_STAGE_PUBKEY", nullable = false, length = EntityConstant.LENGTH_20)
    private String pubkey;

    @Column(name = "COMMERCIAL_NAME", nullable = true, unique = false, length = EntityConstant.LENGTH_50)
    private String commercialName;

    @Column(name = "TEST_NAME", nullable = true, unique = false, length = EntityConstant.LENGTH_40)
    private String testname;

    @Column(name = "OECD_REQD_NAME", nullable = true, unique = false, length = EntityConstant.LENGTH_40)
    private String oecdRegistrationName;

    @Column(name = "COMMERCIAL_MATURITY", nullable = true, precision = EntityConstant.PRECISION_CONSTANT_7, scale = EntityConstant.LENGTH_2)
    private Double commercialMaturity;

    @Type(type = "boolean-yn")
    @Column(name = "IS_ACTIVE", nullable = false)
    private boolean active;

    @Type(type = "boolean-yn")
    @Column(name = "NAME_IS_VERIFIED", nullable = false)
    private boolean verifiedName;

    @Type(type = "boolean-yn")
    @Column(name = "LOGICAL_DELETE", nullable = false)
    private boolean logicalDelete;

    @Type(type = "boolean-yn")
    @Column(name = "PREFERRED_NAME_FLAG", nullable = false)
    private boolean preferredName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private LexiconProductEntity lexiconProduct;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "COUNTRY_ID", nullable = false)
    private LexiconCountryEntity lexiconCountry;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "STAGE_ID", nullable = false)
    private LexiconStageEntity lexiconStage;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @JoinColumn(name = "LEXICON_PRODUCT_NAME_PUBKEY", referencedColumnName = "PRODUCT_STAGE_PUBKEY", updatable = false)
    private List<FbsCommonProductNameXrefEntity> fbsCommonProductNameXrefs = new ArrayList<FbsCommonProductNameXrefEntity>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COML_TRAIT_STACK_ID", nullable = true)
    private CommercialTraitStackEntity commercialTraitStack;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BRAND_ID", nullable = false)
    private LexiconBrandEntity lexiconBrand;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumnsOrFormulas(value = {@JoinColumnOrFormula(formula = @JoinFormula(value = "( SELECT PCP.CROP_ID from Lexicon.PRE_COML_PRODUCT PCP where PCP.PRODUCT_ID=PRODUCT_ID )", referencedColumnName = "CROP_ID")),
            @JoinColumnOrFormula(formula = @JoinFormula(value = "( SELECT NVL(COMMERCIAL_NAME,PCP.PRE_COML_NAME) from Lexicon.PRE_COML_PRODUCT PCP where PCP.PRODUCT_ID=PRODUCT_ID )", referencedColumnName = "PRODUCT_NAME"))
    })
    private ExceptionCodeEntity exceptionCode;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Double getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(Double commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public void setCommercialName(String commercialName) {
        this.commercialName = commercialName;
    }

    public CommercialTraitStackEntity getCommercialTraitStack() {
        return commercialTraitStack;
    }

    public void setCommercialTraitStack(CommercialTraitStackEntity commercialTraitStack) {
        this.commercialTraitStack = commercialTraitStack;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconBrandEntity getLexiconBrand() {
        return lexiconBrand;
    }

    public void setLexiconBrand(LexiconBrandEntity lexiconBrand) {
        this.lexiconBrand = lexiconBrand;
    }

    public LexiconCountryEntity getLexiconCountry() {
        return lexiconCountry;
    }

    public void setLexiconCountry(LexiconCountryEntity lexiconCountry) {
        this.lexiconCountry = lexiconCountry;
    }

    public LexiconProductEntity getLexiconProduct() {
        return lexiconProduct;
    }

    public void setLexiconProduct(LexiconProductEntity lexiconProduct) {
        this.lexiconProduct = lexiconProduct;
    }

    public LexiconStageEntity getLexiconStage() {
        return lexiconStage;
    }

    public void setLexiconStage(LexiconStageEntity lexiconStage) {
        this.lexiconStage = lexiconStage;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getOecdRegistrationName() {
        return oecdRegistrationName;
    }

    public void setOecdRegistrationName(String oecdRegistrationName) {
        this.oecdRegistrationName = oecdRegistrationName;
    }

    public boolean isPreferredName() {
        return preferredName;
    }

    public void setPreferredName(boolean preferredName) {
        this.preferredName = preferredName;
    }

    public String getTestname() {
        return testname;
    }

    public void setTestname(String testname) {
        this.testname = testname;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    @Transient
    public FbsCommonProductNameXrefEntity getFbsCommonProductNameXref() {
        if (!fbsCommonProductNameXrefs.isEmpty()) {
            return fbsCommonProductNameXrefs.get(0);
        } else {
            return null;
        }
    }

    public void setFbsCommonProductNameXref(FbsCommonProductNameXrefEntity fbsCommonProductNameXref) {
        fbsCommonProductNameXrefs.clear();
        if (fbsCommonProductNameXref != null) {
            fbsCommonProductNameXrefs.add(fbsCommonProductNameXref);
        }
    }

    public List<FbsCommonProductNameXrefEntity> getFbsCommonProductNameXrefs() {
        return fbsCommonProductNameXrefs;
    }

    public void setFbsCommonProductNameXrefs(List<FbsCommonProductNameXrefEntity> fbsCommonProductNameXrefs) {
        this.fbsCommonProductNameXrefs = fbsCommonProductNameXrefs;
    }

    public ExceptionCodeEntity getExceptionCode() {
        return exceptionCode;
    }

    public void setExceptionCode(ExceptionCodeEntity exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    public boolean isVerifiedName() {
        return verifiedName;
    }

    public void setVerifiedName(boolean verifiedName) {
        this.verifiedName = verifiedName;
    }
}
