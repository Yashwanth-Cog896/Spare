package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableAlias;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "productRelationShipXrefGenerator",allocationSize = 1,sequenceName = "Lexicon.Product_Relationship_Xref_Seq")
@Table(name = "PRODUCT_RELATIONSHIP_XREF", schema = "Lexicon")
@Filterable
public class ProductRelationshipXrefEntity implements Serializable {
    @Id
    @Column(name="PRODUCT_RELATIONSHIP_XREF_ID")
    @GeneratedValue(generator = "productRelationShipXrefGenerator")
    private long id;

    @FilterableAlias(alias = "lexiconProduct")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_ID",nullable = false)
    private LexiconProductEntity lexiconProduct;
    @FilterableAlias(alias = "productRelationship")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_RELATIONSHIP_ID",nullable = false)
    private ProductRelationshipEntity productRelationship;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCTION_STATUS_ID",nullable = false)
    private LexiconProductionStatusEntity productionStatus;
    @FilterableProperty(filterKey = "traitVersion")
    @Column(name="TRAIT_VERSION",nullable = true, length = EntityConstant.LENGTH_10)
    private String traitVersion;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconProductEntity getLexiconProduct() {
        return lexiconProduct;
    }

    public void setLexiconProduct(LexiconProductEntity lexiconProduct) {
        this.lexiconProduct = lexiconProduct;
    }

    public ProductRelationshipEntity getProductRelationship() {
        return productRelationship;
    }

    public void setProductRelationship(ProductRelationshipEntity productRelationship) {
        this.productRelationship = productRelationship;
    }

    public LexiconProductionStatusEntity getProductionStatus() {
        return productionStatus;
    }

    public void setProductionStatus(LexiconProductionStatusEntity productionStatus) {
        this.productionStatus = productionStatus;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

 }
