package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableAlias;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Filterable
@Entity
@SequenceGenerator(name = "baseProductIdGenerator", allocationSize = 1, sequenceName = "Lexicon.BASE_PRODUCT_ID_SEQ")
@Table(name = "BASE_PRODUCT", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class BaseProductEntity implements Serializable {
    @Id
    @Column(name = "BASE_PRODUCT_ID")
    @GeneratedValue(generator = "baseProductIdGenerator")
    private Long id;
    @FilterableProperty(filterKey = "baseManufacturingName")
    @Column(name = "BASE_MANUFACTURING_NAME", nullable = false, length = EntityConstant.LENGTH_50)
    private String baseManufacturingName;
    @FilterableAlias(alias = "lexiconCrop")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private LexiconCropEntity lexiconCrop;
    @Type(type = "boolean-yn")
    @Column(name = "PARENT_PRODUCT", nullable = true)
    private Boolean parentProduct;
    @Type(type = "boolean-yn")
    @Column(name = "LOGICAL_DELETE", nullable = true)
    private Boolean logicalDelete;
    @OneToMany(mappedBy = "baseProduct", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<ProductRelationshipEntity> productRelationships = new ArrayList<ProductRelationshipEntity>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public void setBaseManufacturingName(String baseManufacturingName) {
        this.baseManufacturingName = baseManufacturingName;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public boolean getParentProduct() {
        return (parentProduct == null) ? false : parentProduct;
    }

    public void setParentProduct(Boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    public boolean getLogicalDelete() {
        return (logicalDelete == null) ? false : logicalDelete;
    }

    public void setLogicalDelete(Boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public List<ProductRelationshipEntity> getProductRelationships() {
        return productRelationships;
    }

    public void setProductRelationships(List<ProductRelationshipEntity> productRelationships) {
        this.productRelationships = productRelationships;
    }
}
