package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 27, 2011
 * Time: 11:22:33 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "KW", schema = "Mirage2")
public class KeywordEntity implements Serializable {
    @Id
    @Column(name="CODE",precision = 8,scale = 0)
    private long code;
    @Column(name="TYPE",length=80,nullable=false)
    private String type;
    @Column(name="NAME",length=80,nullable = false)
    private String name;
    @Column(name="VALUE",length = 80,nullable = false)
    private String value;
    @Column(name="REMARK", length = 80, nullable = false)
    private String remark;
    @Column(name="ENABLED")
    @Type(type = "yes_no")
    private boolean enabled;

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
    
}
