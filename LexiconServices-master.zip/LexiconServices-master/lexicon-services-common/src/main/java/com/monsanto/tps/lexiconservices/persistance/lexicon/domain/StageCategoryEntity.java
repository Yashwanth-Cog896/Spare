package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "STAGE_CATEGORY", schema = "Lexicon")
public class StageCategoryEntity  implements Serializable {
  public static final String VEGETABLE="Vegetable";
  public static final String NON_VEGETABLE = "Non-Vegetable";
  @Id
  @Column(name="STAGE_CATEGORY_ID",nullable = false)
  private Long id;

  @Column(name="STAGE_CATEGORY_NAME",nullable = false,length= EntityConstant.LENGTH_50)
  private String  name;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
