package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "COUNTRY", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasCountryEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "COUNTRY_ID", precision = 0, length = EntityConstant.LENGTH_22)
    private long id;
    @Column(name="NAME",length = EntityConstant.LENGTH_80,nullable=false)
    private String name;
    @Type(type="true_false")
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean refActive;

    @Column(name="COUNTRY_ABBR",length= EntityConstant.LENGTH_3,nullable = true)
    private String abbreviation;

    @Column(name="MIRAGE_COUNTRY_REF_ID",length= EntityConstant.LENGTH_10,nullable = true)
    private String mirageCountryRefId;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMirageCountryRefId() {
        return mirageCountryRefId;
    }

    public void setMirageCountryRefId(String mirageCountryRefId) {
        this.mirageCountryRefId = mirageCountryRefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }
}
