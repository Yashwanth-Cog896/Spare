package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCountryEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCountryEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name = "COUNTRY_XREF", schema = "FBS_COMMON")
public class FbsCommonCountryXrefEntity implements Serializable{
     @Id
     @Column(name="LEXICON_COUNTRY_PUBKEY",length = EntityConstant.LENGTH_20)
     private String lexiconPubkey;

    @ManyToOne
    @JoinColumn(name = "MIDAS_COUNTRY_ID", nullable = true)
     private MidasCountryEntity midasCountry;

    @ManyToOne
    @JoinColumn(name = "MIRAGE_COUNTRY_CODE", nullable = true)
    private MirageCountryEntity mirageCountry;

    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public MidasCountryEntity getMidasCountry() {
        return midasCountry;
    }

    public void setMidasCountry(MidasCountryEntity midasCountry) {
        this.midasCountry = midasCountry;
    }

    public MirageCountryEntity getMirageCountry() {
        return mirageCountry;
    }

    public void setMirageCountry(MirageCountryEntity mirageCountry) {
        this.mirageCountry = mirageCountry;
    }

}
