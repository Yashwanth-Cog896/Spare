package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/17/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
@Filterable
@Entity
@SequenceGenerator(name = "bayerCodeIdGenerator", allocationSize = 1, sequenceName = "Lexicon.BAYER_CODE_ID_SEQ")
@Table(name = "BAYER_CODE", schema = "Lexicon")
public class BayerCodeEntity implements Serializable {

    @Id
    @Column(name = "BAYER_CODE_ID")
    @GeneratedValue(generator = "bayerCodeIdGenerator")
    private Long id;

    @FilterableProperty(filterKey = "bayerCodeName")
    @Column(name = "BAYER_CODE_NAME", nullable = false, length = EntityConstant.LENGTH_50)
    private String bayerCodeName;

    @FilterableProperty(filterKey = "bayerCodeDesc")
    @Column(name = "BAYER_CODE_DESC", nullable = false, length = EntityConstant.LENGTH_100)
    private String bayerCodeDesc;

    @FilterableProperty(filterKey = "bayerCodePubkey")
    @SequenceGenerator(name = "lexiconBrandCodePubkeyIdGenerator", allocationSize = 1, sequenceName = "Lexicon.BAYER_CODE_PUBKEY_SEQ")
    @Column(name = "BAYER_CODE_PUBKEY", nullable = false, length = EntityConstant.LENGTH_20)
    private String bayerCodePubkey;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBayerCodeName() {
        return bayerCodeName;
    }

    public void setBayerCodeName(String bayerCodeName) {
        this.bayerCodeName = bayerCodeName;
    }

    public String getBayerCodeDesc() {
        return bayerCodeDesc;
    }

    public void setBayerCodeDesc(String bayerCodeDesc) {
        this.bayerCodeDesc = bayerCodeDesc;
    }

    public String getBayerCodePubkey() {
        return bayerCodePubkey;
    }

    public void setBayerCodePubkey(String bayerCodePubkey) {
        this.bayerCodePubkey = bayerCodePubkey;
    }

}
