package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:10:55 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "productClassificationIdGenerator",allocationSize = 1,sequenceName = "Lexicon.PRODUCT_CLASSIFICATION_ID_SEQ")
@Table(name = "PRODUCT_CLASSIFICATION", schema = "Lexicon")
public class ProductClassificationEntity implements Serializable {

    @Id
    @Column(name="PRODUCT_CLASSIFICATION_ID")
    @GeneratedValue(generator = "productClassificationIdGenerator")
    private long id;

    @Column(name="PRODUCT_CLASSIFICATION_CODE",nullable = false,length= EntityConstant.LENGTH_20)
    private String  productClassificationCode;
    @Column(name="PRODUCT_CLASSIFICATION_PUBKEY",nullable = false, length= EntityConstant.LENGTH_20)
    private String  pubkey;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "FAMILY_ID",nullable = false)
    private FamilyEntity family;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MATERIAL_PRICING_GROUP_ID",nullable = false)
    private MaterialPricingGroupEntity materialPricingGroup;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="MATERIAL_GROUP_ID",nullable = false)
    private MaterialGroupEntity materialGroup;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCTION_ENVIRONMENT_ID",nullable = false)
    private ProductionEnvironmentEntity productionEnvironment;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_TYPE_ID",nullable = false)
    private ProductTypeEntity productType;

    public FamilyEntity getFamily() {
        return family;
    }

    public void setFamily(FamilyEntity family) {
        this.family = family;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MaterialGroupEntity getMaterialGroup() {
        return materialGroup;
    }

    public void setMaterialGroup(MaterialGroupEntity materialGroup) {
        this.materialGroup = materialGroup;
    }

    public MaterialPricingGroupEntity getMaterialPricingGroup() {
        return materialPricingGroup;
    }

    public void setMaterialPricingGroup(MaterialPricingGroupEntity materialPricingGroup) {
        this.materialPricingGroup = materialPricingGroup;
    }

    public String getProductClassificationCode() {
        return productClassificationCode;
    }

    public void setProductClassificationCode(String productClassificationCode) {
        this.productClassificationCode = productClassificationCode;
    }

    public ProductionEnvironmentEntity getProductionEnvironment() {
        return productionEnvironment;
    }

    public void setProductionEnvironment(ProductionEnvironmentEntity productionEnvironment) {
        this.productionEnvironment = productionEnvironment;
    }

    public ProductTypeEntity getProductType() {
        return productType;
    }

    public void setProductType(ProductTypeEntity productType) {
        this.productType = productType;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
