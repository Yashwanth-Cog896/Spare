package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:43:21 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCT", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasProductEntity implements Serializable {
  public static final int SCALE_0 = 1;
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name="PRODUCT_ID", precision = EntityConstant.PRECISION_CONSTANT_22, scale = SCALE_0)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="CROP_ID",nullable = false)
    private MidasCropEntity midasCrop;
    @Type(type="true_false")
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean refActive;

    @Column(name="DENOMINATION",nullable = true, length = EntityConstant.LENGTH_255)
    private String denomination;
    
    @OneToMany(mappedBy = "midasProduct",fetch = FetchType.LAZY)
    private List<MidasProductNameEntity> midasProductNames = new ArrayList<MidasProductNameEntity>();
  
    @OneToMany(mappedBy = "midasProduct",fetch = FetchType.LAZY)

    private Set<ProductGermplasmEntity> productGermplasms = new HashSet<ProductGermplasmEntity>();

    @OneToMany(mappedBy = "midasProduct",fetch = FetchType.LAZY)
    private Set<FbsCommonProductXrefEntity> fbsCommonProductXrefs=new HashSet<FbsCommonProductXrefEntity>();
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasCropEntity getMidasCrop() {
        return midasCrop;
    }

    public void setMidasCrop(MidasCropEntity midasCrop) {
        this.midasCrop = midasCrop;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public Set<ProductGermplasmEntity> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(Set<ProductGermplasmEntity> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public List<MidasProductNameEntity> getMidasProductNames() {
        return midasProductNames;
    }

    public void setMidasProductNames(List<MidasProductNameEntity> midasProductNames) {
        this.midasProductNames = midasProductNames;
    }

    public Set<FbsCommonProductXrefEntity> getFbsCommonProductXrefs() {
        return fbsCommonProductXrefs;
    }

    public void setFbsCommonProductXrefs(Set<FbsCommonProductXrefEntity> fbsCommonProductXrefs) {
        this.fbsCommonProductXrefs = fbsCommonProductXrefs;
    }

    public String getDenomination() {
        return denomination;
    }

    public void setDenomination(String denomination) {
        this.denomination = denomination;
    }
}
