package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.SQLInsert;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:18:03 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "STAGE", schema = "Lexicon")
@SequenceGenerator(name = "stageIdGenerator",sequenceName = "Lexicon.stage_id_seq",allocationSize = 1)
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class LexiconStageEntity  implements Serializable {
      @Id
      @GeneratedValue(generator = "stageIdGenerator")
      @Column(name="STAGE_ID")
      private long id;

    
      @Column(name="STAGE_ABBR",nullable = false,length = EntityConstant.LENGTH_4)
      private String abbreviation;

      @Column(name="STAGE_PUBKEY",nullable = false,length= EntityConstant.LENGTH_20)
      private String pubkey;

      @Column(name="STAGE_DESC",nullable=false,length= EntityConstant.LENGTH_50)
      private String description;

      @Column(name="ORDER_BY_NUM",nullable = false)
      private long orderBy;

      @Type(type = "boolean-yn")
      @Column(name="IS_COML_STAGE",nullable = false)
      private boolean commercial;

    @ManyToMany
    @JoinTable(name = "STAGE_CATEGORY_XREF",schema = "Lexicon",joinColumns = @JoinColumn(name = "STAGE_ID"),
              inverseJoinColumns = @JoinColumn(name="STAGE_CATEGORY_ID")  )
    @SQLInsert(sql = "INSERT INTO LEXICON.STAGE_CATEGORY_XREF (STAGE_CATEGORY_XREF_ID, STAGE_ID, STAGE_CATEGORY_ID) values ( Lexicon.STAGE_CATEGORY_XREF_ID_SEQ.nextval, ?, ?)" )
    private Set<StageCategoryEntity> stageCategories = new HashSet<StageCategoryEntity>();

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public boolean isCommercial() {
        return commercial;
    }

    public void setCommercial(boolean commercial) {
        this.commercial = commercial;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(long orderBy) {
        this.orderBy = orderBy;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public Set<StageCategoryEntity> getStageCategories() {
        return stageCategories;
    }

    public void setStageCategories(Set<StageCategoryEntity> stageCategories) {
        this.stageCategories = stageCategories;
    }
}
