package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/17/13
 * Time: 4:08 PM
 * To change this template use File | Settings | File Templates.
 */


@Filterable
@Entity
@SequenceGenerator(name = "bayerCodeGenusSpeciesIdGenerator", allocationSize = 1, sequenceName = "Lexicon.BAYER_CODE_GENUS_SPECIES_ID_SEQ")
@Table(name = "BAYER_CODE_GENUS_SPECIES", schema = "Lexicon")
public class BayerCodeGenusSpeciesEntity implements Serializable {

    @EmbeddedId
    private BayerCodeGenusSpeciesComposite bayerCodeGenusSpeciesComposite;

    @Column(name = "BAYER_CODE_GENUS_SP_PUBKEY", nullable = false, length = EntityConstant.LENGTH_20)
    private String bayerCodeGenusSpPubkey;

    @Column(name = "AUDIT_ID", nullable = false, length = EntityConstant.LENGTH_20)
    private long auditId;


    public BayerCodeGenusSpeciesComposite getBayerCodeGenusSpeciesComposite() {
        return bayerCodeGenusSpeciesComposite;
    }

    public void setBayerCodeGenusSpeciesComposite(BayerCodeGenusSpeciesComposite bayerCodeGenusSpeciesComposite) {
        this.bayerCodeGenusSpeciesComposite = bayerCodeGenusSpeciesComposite;
    }

    public String getBayerCodeGenusSpPubkey() {
        return bayerCodeGenusSpPubkey;
    }

    public void setBayerCodeGenusSpPubkey(String bayerCodeGenusSpPubkey) {
        this.bayerCodeGenusSpPubkey = bayerCodeGenusSpPubkey;
    }

    public long getAuditId() {
        return auditId;
    }

    public void setAuditId(long auditId) {
        this.auditId = auditId;
    }
}
