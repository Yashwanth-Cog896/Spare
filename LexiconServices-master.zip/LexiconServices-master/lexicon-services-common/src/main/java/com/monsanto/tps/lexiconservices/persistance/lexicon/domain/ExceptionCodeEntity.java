package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:35:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "exceptionCodeIdGenerator",allocationSize = 1,sequenceName = "Lexicon.EXCEPTION_CODE_ID_SEQ")
@Table(name = "EXCEPTION_CODE", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)

public class ExceptionCodeEntity implements Serializable {
    @Id
    @Column(name = "EXCEPTION_CODE_ID")
    @GeneratedValue(generator = "exceptionCodeIdGenerator" )
    private long id;
  
    @Column(name="EXCEPTION_CODE_PUBKEY",nullable = false,length= EntityConstant.LENGTH_20)
    private String exceptionCode;

    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    @JoinColumn(name = "CROP_ID",nullable = false)
    private LexiconCropEntity lexiconCrop;

    @Column(name="PRODUCT_NAME",nullable = false,length = EntityConstant.LENGTH_40)
    private String productName;



    @Type(type = "boolean-yn")
    @Column(name="IS_PRIMARY_IND",nullable = false)
    private boolean primary;

    public String getExceptionCode() {
        return exceptionCode;
    }

    public void setExceptionCode(String exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true;}
        if (o == null || !o.getClass().isAssignableFrom(getClass())){ return false;}

        ExceptionCodeEntity that = (ExceptionCodeEntity) o;

        if (!exceptionCode.equals(that.exceptionCode)){ return false;}

        return true;
    }

}
