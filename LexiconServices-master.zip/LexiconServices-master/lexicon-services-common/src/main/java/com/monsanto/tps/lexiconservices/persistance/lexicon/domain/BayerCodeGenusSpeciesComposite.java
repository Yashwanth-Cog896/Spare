package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/18/13
 * Time: 2:37 PM
 * To change this template use File | Settings | File Templates.
 */
@Embeddable
public class BayerCodeGenusSpeciesComposite implements Serializable {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "BAYER_CODE_ID", nullable = false)
    private BayerCodeEntity bayerCode;

    @Column(name = "GENUS", nullable = false, length = EntityConstant.LENGTH_80)
    private String genus;

    @Column(name = "SPECIES", nullable = false, length = EntityConstant.LENGTH_80)
    private String species;

    public BayerCodeEntity getBayerCode() {
        return bayerCode;
    }

    public void setBayerCode(BayerCodeEntity bayerCode) {
        this.bayerCode = bayerCode;
    }

    public String getGenus() {
        return genus;
    }

    public void setGenus(String genus) {
        this.genus = genus;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
}
