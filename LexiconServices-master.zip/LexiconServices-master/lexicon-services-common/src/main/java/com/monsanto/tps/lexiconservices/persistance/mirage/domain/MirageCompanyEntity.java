package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@SequenceGenerator(name = "mirageCompanyIdGenerator",allocationSize = 1,sequenceName = "Mirage2.AUDIT_ID_SEQ")
@Table(name = "COMPANIES", schema = "Mirage2")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class MirageCompanyEntity implements Serializable {
  @Id
    @Column(name="COMPANY_ID")
    @GeneratedValue(generator = "mirageCompanyIdGenerator")
    private long id;
    @Column(name="COMPANY_NAME",nullable = true,length = EntityConstant.LENGTH_80)
    private String name;
    @Column(name="COMPANY_ABBREV",nullable = false,length= EntityConstant.LENGTH_3)
    private String abbreviation;
    @Type(type = "yes_no")
    @Column(name="SEED_FLAG",nullable = true)
    private Boolean seed;
     @Type(type = "yes_no")
    @Column(name="CHEMICAL_FLAG",nullable = true)
    private Boolean chemical;
     @Type(type = "yes_no")
    @Column(name="PROGRAMS_FLAG",nullable = true)
    private Boolean programs;
     @Type(type = "yes_no")
    @Column(name="MONSANTO_FLAG",nullable = true)
    private Boolean monsanto;


    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }



    public Boolean getChemical() {
        return chemical;
    }

    public void setChemical(Boolean chemical) {
        this.chemical = chemical;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Boolean getMonsanto() {
        return monsanto;
    }

    public void setMonsanto(Boolean monsanto) {
        this.monsanto = monsanto;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getPrograms() {
        return programs;
    }

    public void setPrograms(Boolean programs) {
        this.programs = programs;
    }

    public Boolean getSeed() {
        return seed;
    }

    public void setSeed(Boolean seed) {
        this.seed = seed;
    }
}
