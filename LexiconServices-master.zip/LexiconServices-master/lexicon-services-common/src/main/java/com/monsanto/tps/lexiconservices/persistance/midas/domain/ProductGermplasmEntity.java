package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:48:26 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCT_GERMPLASM", schema = "MIDAS")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class ProductGermplasmEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name="PRODUCT_GERMPLASM_ID", precision = EntityConstant.PRECISION_CONSTANT_22, scale = 0)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private MidasProductEntity midasProduct;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GERMPLASM_ID", nullable = false)
    private GermplasmEntity germplasm;
    @Type(type="true_false")
    @Column(name="IS_PREFERRED", nullable = true)
    private Boolean preferred;

     

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasProductEntity getMidasProduct() {
        return midasProduct;
    }

    public void setMidasProduct(MidasProductEntity midasProduct) {
        this.midasProduct = midasProduct;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public Boolean getPreferred() {
        return preferred;
    }

    public void setPreferred(Boolean preferred) {
        this.preferred = preferred;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
          return true;
        }
        if (o == null || !getClass().isAssignableFrom(o.getClass())) {
          return false;
        }

        ProductGermplasmEntity that = (ProductGermplasmEntity) o;

        if (germplasm.getId()!=that.germplasm.getId()) {
          return false;
        }
        if (midasProduct.getId()!=that.midasProduct.getId()){
          return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = ((Long)midasProduct.getId()).hashCode();
        result = EntityConstant.HASH_CODE_CONSTANT * result + ((Long)germplasm.getId()).hashCode();
        return result;
    }
}
