package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 26, 2011
 * Time: 1:06:42 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "CHAR_TRAIT_VALUE", schema = "Midas")
@GenericGenerator(
  name = "midas_generator",
  strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
public class TraitValueEntity {
  public static final int SCALE_6 = 6;
  @Id
  @GeneratedValue(generator = "midas_generator")
  @Column(name = "CHAR_TRAIT_VALUE_ID", precision = EntityConstant.PRECISION_CONSTANT_22, scale = 0)
  private long id;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "GERMPLASM_ID", nullable = false)
  private GermplasmEntity germplasm;

  @Column(name = "NUM_VALUE", nullable = true, precision = EntityConstant.PRECISION_CONSTANT_20, scale = SCALE_6)
  private Double numValue;

  @Column(name = "STR_VALUE", nullable = true, length = EntityConstant.LENGTH_255)
  private String strValue;

  @Column(name = "NUM_UOM_ID", nullable = true)
  private Long uomId;

  @Column(name = "GENERATION_TRAIT_VAL_OBSERVED", length = EntityConstant.LENGTH_255, nullable = true)
  private String generationObserved;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "TRAIT_ID", nullable = true)
  private MidasTraitEntity midasTrait;

  public GermplasmEntity getGermplasm() {
    return germplasm;
  }

  public void setGermplasm(GermplasmEntity germplasm) {
    this.germplasm = germplasm;
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public MidasTraitEntity getMidasTrait() {
    return midasTrait;
  }

  public void setMidasTrait(MidasTraitEntity midasTrait) {
    this.midasTrait = midasTrait;
  }

  public Double getNumValue() {
    return numValue;
  }

  public void setNumValue(Double numValue) {
    this.numValue = numValue;
  }

  public String getStrValue() {
    return strValue;
  }

  public void setStrValue(String strValue) {
    this.strValue = strValue;
  }

  public Long getUomId() {
    return uomId;
  }

  public void setUomId(Long uomId) {
    this.uomId = uomId;
  }

  public String getGenerationObserved() {
    return generationObserved;
  }

  public void setGenerationObserved(String generationObserved) {
    this.generationObserved = generationObserved;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || (!getClass().isAssignableFrom(o.getClass()))) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    int result = germplasm.hashCode();
    result = EntityConstant.HASH_CODE_CONSTANT * result + (numValue != null ? numValue.hashCode() : 0);
    result = EntityConstant.HASH_CODE_CONSTANT * result + (strValue != null ? strValue.hashCode() : 0);
    result = EntityConstant.HASH_CODE_CONSTANT * result + (uomId != null ? uomId.hashCode() : 0);
    result = EntityConstant.HASH_CODE_CONSTANT * result + (generationObserved != null ? generationObserved.hashCode() : 0);
    result = EntityConstant.HASH_CODE_CONSTANT * result + (midasTrait != null ? midasTrait.hashCode() : 0);
    return result;
  }
}
