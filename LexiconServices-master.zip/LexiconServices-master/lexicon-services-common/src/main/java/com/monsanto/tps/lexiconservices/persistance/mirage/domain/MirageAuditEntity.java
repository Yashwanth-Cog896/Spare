package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "mirageAuditIdGenerator",allocationSize = 1,sequenceName = "Mirage2.AUDIT_ID_SEQ")
@Table(name = "AUDIT_HISTORY", schema = "Mirage2")
public class MirageAuditEntity implements Serializable {
    @Id
    @Column(name="AUDIT_ID")
    @GeneratedValue(generator = "mirageAuditIdGenerator")
    private long id;
    @Temporal(TemporalType.DATE)
    @Column(name="AUDIT_DATE",nullable = false)
    private Date date;
    @Column(name="AUDIT_USER",nullable=false,length = EntityConstant.LENGTH_35)
    private String user;
    @Column(name="AUDIT_CLIENT",nullable=false,length= EntityConstant.LENGTH_40)
    private String client;
    @Column(name="AUDIT_EVENT",nullable=false,length= EntityConstant.LENGTH_80)
    private String event;
    @Column(name="EVENT_TAG",nullable=false,length= EntityConstant.LENGTH_80)
    private String eventTag;
    @Column(name="EVENT_REMARK",nullable = false,length= EntityConstant.LENGTH_2000)
    private String eventRemark;


    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getEventRemark() {
        return eventRemark;
    }

    public void setEventRemark(String eventRemark) {
        this.eventRemark = eventRemark;
    }

    public String getEventTag() {
        return eventTag;
    }

    public void setEventTag(String eventTag) {
        this.eventTag = eventTag;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
