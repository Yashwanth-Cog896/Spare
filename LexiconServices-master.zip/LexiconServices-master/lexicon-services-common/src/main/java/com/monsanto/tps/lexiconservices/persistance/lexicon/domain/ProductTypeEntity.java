package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:29:54 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "productTypeIdGenerator",allocationSize = 1,sequenceName = "Lexicon.PRODUCT_TYPE_ID_SEQ")
@Table(name = "PRODUCT_TYPE", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class ProductTypeEntity implements Serializable {
    @Id
    @Column(name="PRODUCT_TYPE_ID")
    @GeneratedValue(generator = "productTypeIdGenerator")
    private long id;
    @Column(name="PRODUCT_TYPE_NAME",nullable = false, length = EntityConstant.LENGTH_50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Column(name="PRODUCT_TYPE_CODE",nullable = false,length= EntityConstant.LENGTH_10)
    private String code;
    @Column(name="PRODUCT_TYPE_PUBKEY",nullable = false, length= EntityConstant.LENGTH_20)
    private String pubkey;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
