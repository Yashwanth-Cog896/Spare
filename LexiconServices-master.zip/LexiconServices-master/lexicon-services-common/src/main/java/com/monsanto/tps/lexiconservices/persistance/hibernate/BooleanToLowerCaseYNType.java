package com.monsanto.tps.lexiconservices.persistance.hibernate;

import org.hibernate.type.CharBooleanType;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/28/13
 * Time: 1:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class BooleanToLowerCaseYNType
  extends CharBooleanType {
  public BooleanToLowerCaseYNType() {
    super('y', 'n');
  }
}