package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/9/14
 * Time: 10:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "commercialTraitStackCountryAltNameIdGenerator", allocationSize = 1, sequenceName = "Lexicon.cml_tt_stk_cty_alt_nme_id_seq")
@Table(name = "COML_TRT_STK_CNTRY_ALT_NAME", schema = "Lexicon")
public class CommercialTraitStackCountryAlternateNameEntity {

  @Id
  @GeneratedValue(generator = "commercialTraitStackCountryAltNameIdGenerator")
  @Column(name = "COML_TRT_STK_CNTRY_ALT_NAME_ID")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "COML_TRAIT_STACK_ALT_NAME_ID", nullable = false)
  private CommercialTraitStackAlternateNameEntity commercialTraitStackAlternateName;

  @ManyToOne
  @JoinColumn(name = "COUNTRY_ID", nullable = false)
  private LexiconCountryEntity lexiconCountry;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public CommercialTraitStackAlternateNameEntity getCommercialTraitStackAlternateName() {
    return commercialTraitStackAlternateName;
  }

  public void setCommercialTraitStackAlternateName(CommercialTraitStackAlternateNameEntity commercialTraitStackAlternateName) {
    this.commercialTraitStackAlternateName = commercialTraitStackAlternateName;
  }

  public LexiconCountryEntity getLexiconCountry() {
    return lexiconCountry;
  }

  public void setLexiconCountry(LexiconCountryEntity lexiconCountry) {
    this.lexiconCountry = lexiconCountry;
  }

}
