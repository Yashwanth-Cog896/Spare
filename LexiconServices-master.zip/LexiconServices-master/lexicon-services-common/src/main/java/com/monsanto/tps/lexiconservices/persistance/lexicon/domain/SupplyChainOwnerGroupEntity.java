package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:13:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "SUPPLY_CHAIN_OWNER_GROUP", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class SupplyChainOwnerGroupEntity implements Serializable {
    @Id
    @Column(name = "SUPPLY_CHAIN_OWNER_GROUP_ID")
    private long id;
    @Column(name="GROUP_CODE",nullable = false,length= EntityConstant.LENGTH_12)
    private String code;
    @Column(name="GROUP_DESCRIPTION",nullable=false,length= EntityConstant.LENGTH_50)
    private String description;
    @Column(name="GROUP_CODE_IN_SAP",nullable=false,length= EntityConstant.LENGTH_12)
    private String codeInSap;
    @Type(type = "boolean-yn")
    @Column(name="IS_ACTIVE")
    private boolean active;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCodeInSap() {
        return codeInSap;
    }

    public void setCodeInSap(String codeInSap) {
        this.codeInSap = codeInSap;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
