package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "lexiconProductIdGenerator",allocationSize = 1,sequenceName = "Lexicon.UNIQUE_PRODUCT_ID_SEQ")
@Table(name = "PRE_COML_PRODUCT", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
@Filterable
public class LexiconProductEntity implements Serializable{

    @Id
    @Column(name="PRODUCT_ID")
    @GeneratedValue(generator = "lexiconProductIdGenerator")
    private long id;
    @Column(name="PRODUCT_PUBKEY",nullable = false,length = EntityConstant.LENGTH_20)
    private String pubkey;
    @FilterableProperty(filterKey = "preCommercialName")
    @Column(name="PRE_COML_NAME",nullable = false,length = EntityConstant.LENGTH_40)
    private String preCommercialName;
    @Column(name="TAG_VARIETY_NAME", nullable = true, length= EntityConstant.LENGTH_50)
    private String tagVarietyName;
    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Type(type = "boolean-yn")
    @Column(name="PARENT_PRODUCT",nullable = false)
    private boolean parentProduct;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID",nullable = false)
    private LexiconCropEntity lexiconCrop;

    @Column(name="PATENT_PVP_INFO_COMMENTS",nullable=true,length = EntityConstant.LENGTH_4000)
    private String additionalComments;

    @OneToMany(mappedBy = "lexiconProduct",cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY)
    private Set<LexiconProductStageEntity> lexiconProductStages = new HashSet<LexiconProductStageEntity>();

    @OneToMany(mappedBy = "lexiconProduct",fetch = FetchType.LAZY)
    private Set<ProductRelationshipXrefEntity> lexiconProductRelationshipXrefs = new HashSet<ProductRelationshipXrefEntity>();

    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private List<LexiconProductPictureEntity>  lexiconProductPictures = new ArrayList<LexiconProductPictureEntity>();
    
    @ManyToOne
    @JoinColumn(name="PRODUCT_CLASSIFICATION_ID",nullable = true)
    private ProductClassificationEntity productClassification;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="OWNING_MARKETING_REGION_ID",nullable = true)
    private MarketingRegionEntity owningMarketingRegion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="SUPPLY_CHAIN_OWNER_GROUP_ID",nullable = true)
    private SupplyChainOwnerGroupEntity supplyChainOwnerGroup;


    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_PUBKEY",referencedColumnName="PRODUCT_PUBKEY", updatable = false)
    private Set<FbsCommonProductXrefEntity> fbsCommonProductXrefs = new HashSet<FbsCommonProductXrefEntity>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns(value={
            @JoinColumn( name= "CROP_ID", referencedColumnName="CROP_ID", updatable = false,insertable = false),
            @JoinColumn( name= "PRE_COML_NAME", referencedColumnName="PRODUCT_NAME", updatable = false,insertable = false)}
                         )
    private ExceptionCodeEntity exceptionCode;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public String getTagVarietyName() {
        return tagVarietyName;
    }

    public void setTagVarietyName(String tagVarietyName) {
        this.tagVarietyName = tagVarietyName;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public boolean isParentProduct() {
        return parentProduct;
    }

    public void setParentProduct(boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    @Transient
    public FbsCommonProductXrefEntity getFbsCommonProductXref() {
        if(!fbsCommonProductXrefs.isEmpty()){
            return fbsCommonProductXrefs.iterator().next();
        }
        else {
            return null;
        }
    }

    public void setFbsCommonProductXref(FbsCommonProductXrefEntity fbsCommonProductXref) {
        fbsCommonProductXrefs.clear();
        if(fbsCommonProductXref!=null){
           fbsCommonProductXrefs.add(fbsCommonProductXref);
        }
    }

    public Set<FbsCommonProductXrefEntity> getFbsCommonProductXrefs() {
        return fbsCommonProductXrefs;
    }

    public void setFbsCommonProductXrefs(Set<FbsCommonProductXrefEntity> fbsCommonProductXrefs) {
        this.fbsCommonProductXrefs = fbsCommonProductXrefs;
    }

    public List<LexiconProductPictureEntity> getLexiconProductPictures() {
        return lexiconProductPictures;
    }

    public void setLexiconProductPictures(List<LexiconProductPictureEntity> lexiconProductPictures) {
        this.lexiconProductPictures = lexiconProductPictures;
    }

    public Set<LexiconProductStageEntity> getLexiconProductStages() {
        return lexiconProductStages;
    }

    public void setLexiconProductStages(Set<LexiconProductStageEntity> lexiconProductStages) {
        this.lexiconProductStages = lexiconProductStages;
    }

    public MarketingRegionEntity getOwningMarketingRegion() {
        return owningMarketingRegion;
    }

    public void setOwningMarketingRegion(MarketingRegionEntity owningMarketingRegion) {
        this.owningMarketingRegion = owningMarketingRegion;
    }

    public ProductClassificationEntity getProductClassification() {
        return productClassification;
    }

    public void setProductClassification(ProductClassificationEntity productClassification) {
        this.productClassification = productClassification;
    }

    public SupplyChainOwnerGroupEntity getSupplyChainOwnerGroup() {
        return supplyChainOwnerGroup;
    }

    public void setSupplyChainOwnerGroup(SupplyChainOwnerGroupEntity supplyChainOwnerGroup) {
        this.supplyChainOwnerGroup = supplyChainOwnerGroup;
    }

    public Set<ProductRelationshipXrefEntity> getLexiconProductRelationshipXrefs() {
        return lexiconProductRelationshipXrefs;
    }

    public void setLexiconProductRelationshipXrefs(Set<ProductRelationshipXrefEntity> lexiconProductRelationshipXrefs) {
        this.lexiconProductRelationshipXrefs = lexiconProductRelationshipXrefs;
    }

    public ExceptionCodeEntity getExceptionCode() {
        return exceptionCode;
    }

    public void setExceptionCode(ExceptionCodeEntity exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

}
