package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "COUNTRIES", schema = "Mirage2")
public class MirageCountryEntity implements Serializable {
  @Id
  @Column(name="COUNTRY_CODE",length= EntityConstant.LENGTH_3)
  private String code;
  @Column(name="COUNTRY_NAME",length= EntityConstant.LENGTH_80,nullable = false)
  private String name;
  @Column(name="REGION_CODE",precision = EntityConstant.PRECISION_CONSTANT_8,scale = 0,nullable = true)
  private long regionCode;
  @Column(name="SUBCOUNTRY_LABEL",length= EntityConstant.LENGTH_15,nullable = true)
  private String subCountryLabel;
  @Column(name="SUBSUBCOUNTRY_LABEL",length= EntityConstant.LENGTH_15,nullable = true)
  private String subSubCountryLabel;
  @Column(name="COUNTRY_ABBREV",length= EntityConstant.LENGTH_3,nullable = false)
  private String abbreviation;
  @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
  @JoinColumn(name="AUDIT_ID",nullable=false)
  private MirageAuditEntity audit;

  public String getAbbreviation() {
    return abbreviation;
  }

  public void setAbbreviation(String abbreviation) {
    this.abbreviation = abbreviation;
  }

  public MirageAuditEntity getAudit() {
    return audit;
  }

  public void setAudit(MirageAuditEntity audit) {
    this.audit = audit;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public long getRegionCode() {
    return regionCode;
  }

  public void setRegionCode(long regionCode) {
    this.regionCode = regionCode;
  }

  public String getSubCountryLabel() {
    return subCountryLabel;
  }

  public void setSubCountryLabel(String subCountryLabel) {
    this.subCountryLabel = subCountryLabel;
  }

  public String getSubSubCountryLabel() {
    return subSubCountryLabel;
  }

  public void setSubSubCountryLabel(String subSubCountryLabel) {
    this.subSubCountryLabel = subSubCountryLabel;
  }

}
