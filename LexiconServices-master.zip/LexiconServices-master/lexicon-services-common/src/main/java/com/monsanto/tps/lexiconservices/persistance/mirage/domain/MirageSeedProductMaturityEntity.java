package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 27, 2011
 * Time: 9:58:52 AM
 */

@Entity
@Table(name = "SEED_PRODUCTS_MATURITY", schema = "Mirage2")
@IdClass(MirageSeedProductMaturityPK.class)
public class MirageSeedProductMaturityEntity implements Serializable {
    @Id
    @Column(name = "PRODUCT_ID", nullable = false)
    private long productId;
    @Id
    @Column(name = "MATURITY_UNIT", nullable = false, length = EntityConstant.LENGTH_8)
    private long maturityUnit;

    @Column(name = "MATURITY_RATING", nullable = false, length = EntityConstant.LENGTH_8)
    private String maturityRating;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "AUDIT_ID", nullable = true)
    private MirageAuditEntity audit;

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public long getMaturityUnit() {
        return maturityUnit;
    }

    public void setMaturityUnit(long maturityUnit) {
        this.maturityUnit = maturityUnit;
    }

    public String getMaturityRating() {
        return maturityRating;
    }

    public void setMaturityRating(String maturityRating) {
        this.maturityRating = maturityRating;
    }

    public MirageAuditEntity getAudit() {
        return audit;
    }

    public void setAudit(MirageAuditEntity audit) {
        this.audit = audit;
    }
}
