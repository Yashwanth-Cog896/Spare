package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 26, 2011
 * Time: 12:56:21 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "TRAIT", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasTraitEntity {
    public static final String RELATIVE_MATURITY_NAME = "Relative Maturity";
    public static final String BOOLEAN_TRUE_FALSE = "true_false";
  @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name="TRAIT_ID", precision = EntityConstant.PRECISION_CONSTANT_22, scale = 0)
    private long id;
    @Column(name="NAME",nullable = true,length = EntityConstant.LENGTH_255)
    private String name;

    @Type(type= BOOLEAN_TRUE_FALSE)
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean active;
    @Type(type=BOOLEAN_TRUE_FALSE)
    @Column(name="CALCULATED",nullable = false)
    private boolean calculated;
    @Type(type=BOOLEAN_TRUE_FALSE)
    @Column(name="IS_PRE_HARVEST_TRAIT",nullable = false)
    private boolean preHarvest;
    @Type(type=BOOLEAN_TRUE_FALSE)
    @Column(name="APPLY_25PCT",nullable = false)
    private boolean applyTwentyFivePercentRule;
    @Type(type=BOOLEAN_TRUE_FALSE)
    @Column(name="IS_DSR",nullable = false)
    private boolean dsr;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID")
    private MidasCropEntity midasCrop;

    @OneToMany(mappedBy = "midasTrait",fetch = FetchType.LAZY)
    private List<TraitValueEntity> traitValueEntity;
    
    @Column(name="TRAIT_TYPE",nullable = true)
    private String traitType;
    public static final String C_TRAIT_TYPE = "C";

    public boolean isApplyTwentyFivePercentRule() {
        return applyTwentyFivePercentRule;
    }

    public void setApplyTwentyFivePercentRule(boolean applyTwentyFivePercentRule) {
        this.applyTwentyFivePercentRule = applyTwentyFivePercentRule;
    }

    public boolean isCalculated() {
        return calculated;
    }

    public void setCalculated(boolean calculated) {
        this.calculated = calculated;
    }

    public boolean isDsr() {
        return dsr;
    }

    public void setDsr(boolean dsr) {
        this.dsr = dsr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasCropEntity getMidasCrop() {
        return midasCrop;
    }

    public void setMidasCrop(MidasCropEntity midasCrop) {
        this.midasCrop = midasCrop;
    }

    public boolean isPreHarvest() {
        return preHarvest;
    }

    public void setPreHarvest(boolean preHarvest) {
        this.preHarvest = preHarvest;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getTraitType() {
        return traitType;
    }

    public void setTraitType(String traitType) {
        this.traitType = traitType;
    }

    public List<TraitValueEntity> getTraitValueEntity() {
        return traitValueEntity;
    }

    public void setTraitValueEntity(List<TraitValueEntity> traitValueEntity) {
        this.traitValueEntity = traitValueEntity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
