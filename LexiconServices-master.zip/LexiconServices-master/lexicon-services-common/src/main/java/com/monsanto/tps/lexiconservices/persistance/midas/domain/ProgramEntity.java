/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/* vvkalu - 6/23/11 */
@Entity
@Table(name = "BR_PROG", schema = "Midas")
public class ProgramEntity implements Serializable {
    @Id
    @Column(name="BR_PROG_ID", precision = EntityConstant.PRECISION_CONSTANT_22, scale = 0)
    private long id;
    @Column(name="BR_PROG_REF_ID",nullable = false, length = EntityConstant.LENGTH_3)
    private String refId;
    @Column(name="NAME",nullable = false, length = EntityConstant.LENGTH_50)
    private String name;
    @Type(type="true_false")
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean refActive;
    @Type(type="true_false")
    @Column(name="MIDAS_PROGRAM",nullable = false)
    private boolean midasProgram;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="CROP_ID",nullable = false)
    private MidasCropEntity midasCrop;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public boolean isMidasProgram() {
        return midasProgram;
    }

    public void setMidasProgram(boolean midasProgram) {
        this.midasProgram = midasProgram;
    }

    public MidasCropEntity getMidasCrop() {
        return midasCrop;
    }

    public void setMidasCrop(MidasCropEntity midasCrop) {
        this.midasCrop = midasCrop;
    }
}