package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:28:36 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "materialGroupIdGenerator",allocationSize = 1,sequenceName = "Lexicon.MATERIAL_GROUP_ID_SEQ")
@Table(name = "MATERIAL_GROUP", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
public class MaterialGroupEntity  implements Serializable {
    @Id
    @Column(name="MATERIAL_GROUP_ID")
    @GeneratedValue(generator = "materialGroupIdGenerator")
    private long id;
    @Column(name="MATERIAL_GROUP_NAME",nullable = false, length = EntityConstant.LENGTH_50)
    private String name;
    
    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Column(name="MATERIAL_GROUP_CODE",nullable = false,length= EntityConstant.LENGTH_10)
    private String code;
    @Column(name="MATERIAL_GROUP_PUBKEY",nullable = false, length= EntityConstant.LENGTH_20)
    private String pubkey;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID",nullable = true)
    private LexiconCropEntity lexiconCrop;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
