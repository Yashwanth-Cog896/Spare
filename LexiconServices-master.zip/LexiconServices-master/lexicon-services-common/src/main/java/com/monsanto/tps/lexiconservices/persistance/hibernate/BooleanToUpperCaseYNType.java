package com.monsanto.tps.lexiconservices.persistance.hibernate;

import org.hibernate.type.CharBooleanType;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 3/20/14
 * Time: 11:19 AM
 * To change this template use File | Settings | File Templates.
 */
public class BooleanToUpperCaseYNType extends CharBooleanType {

  public BooleanToUpperCaseYNType() {
    super('Y', 'N');
  }
}
