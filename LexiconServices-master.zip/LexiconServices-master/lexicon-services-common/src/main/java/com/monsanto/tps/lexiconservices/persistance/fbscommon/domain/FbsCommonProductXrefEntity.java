package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.CompetitiveProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:15:20 PM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@Table(name = "PRODUCT_XREF", schema = "FBS_COMMON")
public class FbsCommonProductXrefEntity implements Serializable {
    @Id
    @Column(name="LEXICON_PRODUCT_PUBKEY",length = EntityConstant.LENGTH_20)
    private String lexiconPubkey;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name="midas_product_id")
    private MidasProductEntity midasProduct;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_PUBKEY",referencedColumnName = "PRODUCT_PUBKEY",updatable = false,insertable = false)
    private LexiconProductEntity lexiconProduct;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_PUBKEY",referencedColumnName = "PRODUCT_PUBKEY",updatable = false,insertable = false)
    private CompetitiveProductEntity competitiveProduct;


    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public MidasProductEntity getMidasProduct() {
        return midasProduct;
    }

    public void setMidasProduct(MidasProductEntity midasProduct) {
        this.midasProduct = midasProduct;
    }

    public LexiconProductEntity getLexiconProduct() {
        return lexiconProduct;
    }

    public void setLexiconProduct(LexiconProductEntity lexiconProduct) {
        this.lexiconProduct = lexiconProduct;
    }

    public CompetitiveProductEntity getCompetitiveProduct() {
        return competitiveProduct;
    }

    public void setCompetitiveProduct(CompetitiveProductEntity competitiveProduct) {
        this.competitiveProduct = competitiveProduct;
    }

}
