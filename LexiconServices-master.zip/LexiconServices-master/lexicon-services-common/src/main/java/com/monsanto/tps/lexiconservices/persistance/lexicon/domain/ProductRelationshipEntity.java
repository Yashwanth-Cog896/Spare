package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableAlias;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import com.monsanto.tps.lexiconservices.persistance.constant.EntityConstant;
import com.monsanto.tps.lexiconservices.persistance.hibernate.BooleanToLowerCaseYNType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:33 PM
 * To change this template use File | Settings | File Templates.
 */

@Entity
@SequenceGenerator(name = "productRelationshipIdGenerator", allocationSize = 1, sequenceName = "Lexicon.Product_Relationship_Seq")
@Table(name = "PRODUCT_RELATIONSHIP", schema = "Lexicon")
@TypeDef(name = "boolean-yn", typeClass = BooleanToLowerCaseYNType.class)
@Filterable
public class ProductRelationshipEntity implements Serializable {
    @Id
    @Column(name = "PRODUCT_RELATIONSHIP_ID")
    @GeneratedValue(generator = "productRelationshipIdGenerator")
    private long id;
    @Column(name = "PRODUCT_RELATIONSHIP_PUBKEY", nullable = false, length = EntityConstant.LENGTH_20)
    private String productRelationshipPubkey;
    @FilterableProperty(filterKey = "manufacturingName")
    @Column(name = "MANUFACTURING_NAME", nullable = false, length = EntityConstant.LENGTH_50)
    private String manufacturingName;
    @FilterableAlias(alias = "baseProduct")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BASE_PRODUCT_ID", nullable = false
    )
    private BaseProductEntity baseProduct;
    @Type(type = "boolean-yn")
    @Column(name = "LOGICAL_DELETE", nullable = true)
    private Boolean logicalDelete;
    @FilterableProperty(filterKey = "productRelationshipVarietyName")
    @Column(name = "VARIETY_NAME", nullable = true, length = EntityConstant.LENGTH_10)
    private String varietyName;
    @Type(type = "boolean-yn")
    @Column(name = "BLEND_PRODUCT_FLAG", nullable = false)
    private Boolean blendProduct;
    @OneToMany(mappedBy = "productRelationship", fetch = FetchType.LAZY)
    private List<ProductRelationshipXrefEntity> productRelationshipXRefs = new ArrayList<ProductRelationshipXrefEntity>();

    public long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductRelationshipPubkey() {
        return productRelationshipPubkey;
    }

    public void setProductRelationshipPubkey(String productRelationshipPubkey) {
        this.productRelationshipPubkey = productRelationshipPubkey;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public BaseProductEntity getBaseProduct() {
        return baseProduct;
    }

    public void setBaseProduct(BaseProductEntity baseProduct) {
        this.baseProduct = baseProduct;
    }

    public Boolean getLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(Boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public List<ProductRelationshipXrefEntity> getProductRelationshipXRefs() {
        return productRelationshipXRefs;
    }

    public void setProductRelationshipXRefs(List<ProductRelationshipXrefEntity> productRelationshipXRefs) {
        this.productRelationshipXRefs = productRelationshipXRefs;
    }

    public Boolean getBlendProduct() {
        return blendProduct;
    }

    public void setBlendProduct(Boolean blendProduct) {
        this.blendProduct = blendProduct;
    }
}
