package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import javax.persistence.*;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 4/28/14
 * Time: 11:53 AM
 */
@Entity
@Table(name = "BLEND_WORKFLOW_CROP", schema = "LEXICON")
public class BlendWorkflowCropEntity {

    @Id
    @Column(name = "BLEND_WORKFLOW_CROP_ID")
    private Long id;

    @OneToOne
    @JoinColumn(name = "CROP_ID", nullable = false)
    private LexiconCropEntity lexiconCrop;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }
}
