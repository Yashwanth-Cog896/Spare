package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProgramEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    ProgramEntity programEntity = new ProgramEntity();
    beanGetterSetterTester.testBean(programEntity);

      MidasCropEntity crop = new MidasCropEntity();
      programEntity.setMidasCrop(crop);
      assertEquals(programEntity.getMidasCrop(),crop);
  }
}
