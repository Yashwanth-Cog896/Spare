package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasCountryEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCountryEntity;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class FbsCommonCountryXrefEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  FbsCommonCountryXrefEntity fbsCommonCountryXrefEntity = new FbsCommonCountryXrefEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(fbsCommonCountryXrefEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    fbsCommonCountryXrefEntity.setMidasCountry(new MidasCountryEntity());
    fbsCommonCountryXrefEntity.setMirageCountry(new MirageCountryEntity());
    assertNotNull(fbsCommonCountryXrefEntity.getMidasCountry());
    assertNotNull(fbsCommonCountryXrefEntity.getMirageCountry());
  }
}
