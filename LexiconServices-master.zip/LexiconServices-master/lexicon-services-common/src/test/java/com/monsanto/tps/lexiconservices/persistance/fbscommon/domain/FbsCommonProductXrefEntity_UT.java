package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.CompetitiveProductEntity;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class FbsCommonProductXrefEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  FbsCommonProductXrefEntity fbsCommonProductXrefEntity = new FbsCommonProductXrefEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(fbsCommonProductXrefEntity);
  }
  @Test
  public void testCustomObjects() throws Exception {
    fbsCommonProductXrefEntity.setCompetitiveProduct(new CompetitiveProductEntity());
    fbsCommonProductXrefEntity.setLexiconProduct(new LexiconProductEntity());
    fbsCommonProductXrefEntity.setMidasProduct(new MidasProductEntity());
    assertNotNull(fbsCommonProductXrefEntity.getCompetitiveProduct());
    assertNotNull(fbsCommonProductXrefEntity.getLexiconProduct());
    assertNotNull(fbsCommonProductXrefEntity.getMidasProduct());
  }
}
