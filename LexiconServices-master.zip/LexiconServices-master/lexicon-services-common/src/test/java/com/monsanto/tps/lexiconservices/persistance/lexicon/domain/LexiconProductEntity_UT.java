package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconProductEntity lexiconProductEntity = new LexiconProductEntity();

  @Test
  public void test_getterSetter() throws Exception {


    beanGetterSetterTester.testBean(lexiconProductEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    lexiconProductEntity.setLexiconCrop(new LexiconCropEntity());
    lexiconProductEntity.setLexiconProductPictures(new ArrayList<LexiconProductPictureEntity>());
    lexiconProductEntity.setLexiconProductRelationshipXrefs(new HashSet<ProductRelationshipXrefEntity>());
    lexiconProductEntity.setLexiconProductStages(new HashSet<LexiconProductStageEntity>());
    lexiconProductEntity.setExceptionCode(new ExceptionCodeEntity());
    lexiconProductEntity.setFbsCommonProductXrefs(new HashSet<FbsCommonProductXrefEntity>());
    lexiconProductEntity.setProductClassification(new ProductClassificationEntity());
    lexiconProductEntity.setSupplyChainOwnerGroup(new SupplyChainOwnerGroupEntity());
    assertNotNull(lexiconProductEntity.getLexiconCrop());
    assertNotNull(lexiconProductEntity.getLexiconProductPictures());
    assertNotNull(lexiconProductEntity.getLexiconProductRelationshipXrefs());
    assertNotNull(lexiconProductEntity.getLexiconProductStages());
    assertNotNull(lexiconProductEntity.getExceptionCode());
    assertNotNull(lexiconProductEntity.getFbsCommonProductXrefs());
    assertNotNull(lexiconProductEntity.getProductClassification());
    assertNotNull(lexiconProductEntity.getSupplyChainOwnerGroup());


  }
}
