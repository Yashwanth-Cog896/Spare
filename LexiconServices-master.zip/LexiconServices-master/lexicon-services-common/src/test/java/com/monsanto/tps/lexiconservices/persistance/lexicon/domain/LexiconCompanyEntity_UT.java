package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconCompanyEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    LexiconCompanyEntity lexiconCompany = new LexiconCompanyEntity();
    beanGetterSetterTester.testBean(lexiconCompany);
  }
}
