package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/17/13
 * Time: 4:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class BayerCodeEntity_UT {

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
    BayerCodeEntity bayerCodeEntity = new BayerCodeEntity();

    @Test
    public void test_getterSetter() throws Exception {
        beanGetterSetterTester.testBean(bayerCodeEntity);
    }

}
