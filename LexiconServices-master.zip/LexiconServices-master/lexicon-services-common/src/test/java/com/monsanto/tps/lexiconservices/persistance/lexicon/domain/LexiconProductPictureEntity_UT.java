package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 3:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductPictureEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    LexiconProductPictureEntity productPictureEntity = new LexiconProductPictureEntity();
    beanGetterSetterTester.testBean(productPictureEntity);
  }
}
