package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmEventConstructEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    GermplasmEventConstructEntity germplasmEventConstructEntity = new GermplasmEventConstructEntity();
    beanGetterSetterTester.testBean(germplasmEventConstructEntity);

      EventConstructEntity event = new EventConstructEntity();
      germplasmEventConstructEntity.setEventConstruct(event);
      assertEquals(germplasmEventConstructEntity.getEventConstruct(),event);

      GermplasmEntity germplasm = new GermplasmEntity();
      germplasmEventConstructEntity.setGermplasm(germplasm);
      assertEquals(germplasmEventConstructEntity.getGermplasm(),germplasm);
  }
}
