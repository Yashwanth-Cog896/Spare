package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/27/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageSeedProductEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  MirageSeedProductEntity mirageSeedProductEntity = new MirageSeedProductEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(mirageSeedProductEntity);
  }


  @Test
  public void testCustomObjects() throws Exception {
    mirageSeedProductEntity.setAudit(new MirageAuditEntity());
    mirageSeedProductEntity.setMirageCompany(new MirageCompanyEntity());
    assertNotNull(mirageSeedProductEntity.getAudit());
    assertNotNull(mirageSeedProductEntity.getMirageCompany());
  }

}
