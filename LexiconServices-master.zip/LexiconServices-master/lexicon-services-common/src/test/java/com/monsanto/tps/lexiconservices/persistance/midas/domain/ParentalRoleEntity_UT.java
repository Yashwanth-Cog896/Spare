package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ParentalRoleEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    ParentalRoleEntity parentalRoleEntity = new ParentalRoleEntity();
    beanGetterSetterTester.testBean(parentalRoleEntity);
  }
}
