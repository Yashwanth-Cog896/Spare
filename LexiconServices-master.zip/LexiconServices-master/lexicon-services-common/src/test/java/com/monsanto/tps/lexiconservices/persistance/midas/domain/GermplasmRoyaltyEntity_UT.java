package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 11:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmRoyaltyEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    GermplasmRoyaltyEntity germplasmRoyaltyEntity = new GermplasmRoyaltyEntity();
    beanGetterSetterTester.testBean(germplasmRoyaltyEntity);

      GermplasmEntity germplasm = new GermplasmEntity();
      germplasmRoyaltyEntity.setGermplasm(germplasm);
      assertEquals(germplasmRoyaltyEntity.getGermplasm(),germplasm);
  }

    @Test
    public void testEquals() throws Exception {

        GermplasmRoyaltyEntity entity = new GermplasmRoyaltyEntity();
        GermplasmRoyaltyEntity sameObject = entity;

        assertTrue(entity.equals(sameObject));

        GermplasmRoyaltyEntity nullObject = null;
        assertFalse(entity.equals(nullObject));

        GermplasmRoyaltyEntity entity1 = new GermplasmRoyaltyEntity();
        long royalContractId1 = 1L;
        long royalContractId2 = 2L;
        entity.setRoyaltyContractId(royalContractId1);
        entity1.setRoyaltyContractId(royalContractId2);
        assertFalse(entity.equals(entity1));

        entity1.setRoyaltyContractId(royalContractId1);
        GermplasmEntity germplasm1 = new GermplasmEntity();
        GermplasmEntity germplasm2 = new GermplasmEntity();
        entity.setGermplasm(germplasm1);
        entity1.setGermplasm(germplasm2);

        assertFalse(entity.equals(entity1));

        entity1.setGermplasm(germplasm1);

        assertTrue(entity.equals(entity1));

    }

    @Test
     public void testHashcode() throws Exception {
        GermplasmRoyaltyEntity entity = new GermplasmRoyaltyEntity();
        GermplasmEntity germplasm =new GermplasmEntity();
        entity.setGermplasm(germplasm);
        int hashcode = entity.hashCode();
        assertEquals(entity.hashCode(),hashcode);
    }
}
