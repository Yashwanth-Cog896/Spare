package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductTypeEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    ProductTypeEntity productTypeEntity = new ProductTypeEntity();
    beanGetterSetterTester.testBean(productTypeEntity);
  }
}
