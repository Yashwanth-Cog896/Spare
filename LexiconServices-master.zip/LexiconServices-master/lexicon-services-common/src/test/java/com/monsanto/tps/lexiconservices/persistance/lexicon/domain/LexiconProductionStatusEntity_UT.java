package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 3:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductionStatusEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    LexiconProductionStatusEntity lexiconProductionStatusEntity = new LexiconProductionStatusEntity();
    beanGetterSetterTester.testBean(lexiconProductionStatusEntity);
  }
}
