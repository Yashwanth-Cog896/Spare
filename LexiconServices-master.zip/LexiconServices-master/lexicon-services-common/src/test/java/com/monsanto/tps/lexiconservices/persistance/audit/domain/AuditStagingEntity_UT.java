package com.monsanto.tps.lexiconservices.persistance.audit.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit.AuditStagingEntity;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 9:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class AuditStagingEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    AuditStagingEntity auditStagingEntity = new AuditStagingEntity();
    beanGetterSetterTester.testBean(auditStagingEntity);
  }
}
