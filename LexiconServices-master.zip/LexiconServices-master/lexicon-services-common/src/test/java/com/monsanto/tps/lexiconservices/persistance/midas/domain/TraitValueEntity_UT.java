package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class TraitValueEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    TraitValueEntity traitValueEntity = new TraitValueEntity();
    beanGetterSetterTester.testBean(traitValueEntity);

      GermplasmEntity germplasm = new GermplasmEntity();
      traitValueEntity.setGermplasm(germplasm);
      assertEquals(traitValueEntity.getGermplasm(),germplasm);


      MidasTraitEntity trait = new MidasTraitEntity();
      traitValueEntity.setMidasTrait(trait);
      assertEquals(traitValueEntity.getMidasTrait(),trait);

  }

    @Test
    public void testEquals() throws Exception {

        TraitValueEntity entity = new TraitValueEntity();
        TraitValueEntity sameObject = entity;

        assertTrue(entity.equals(sameObject));

        TraitValueEntity nullObject = null;
        assertFalse(entity.equals(nullObject));

        TraitValueEntity entity1 = new TraitValueEntity();
        long id1 = 1L;
        entity.setId(id1);
        entity1.setId(id1);

        assertTrue(entity.equals(entity1));

    }

    @Test
    public void testHashcode() throws Exception {
        TraitValueEntity entity = new TraitValueEntity();
        long id = 2L;
        GermplasmEntity germplasm = new GermplasmEntity();
        entity.setGermplasm(germplasm);
        int hashcode = entity.hashCode();
        assertEquals(entity.hashCode(),hashcode);
    }

}
