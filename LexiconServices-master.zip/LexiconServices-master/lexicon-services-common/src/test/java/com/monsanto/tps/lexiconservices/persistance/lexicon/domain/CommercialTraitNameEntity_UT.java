package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommercialTraitNameEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  CommercialTraitNameEntity commercialTraitNameEntity = new CommercialTraitNameEntity();


  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(commercialTraitNameEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    commercialTraitNameEntity.setLexiconCompany(new LexiconCompanyEntity());
    assertNotNull(commercialTraitNameEntity.getLexiconCompany());
  }
}
