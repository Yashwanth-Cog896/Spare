package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class EventConstructEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    EventConstructEntity eventConstructEntity = new EventConstructEntity();
    beanGetterSetterTester.testBean(eventConstructEntity);
      MidasCropEntity crop = new MidasCropEntity();
      eventConstructEntity.setCrop(crop);
      assertEquals(eventConstructEntity.getCrop(),crop);
  }
}
