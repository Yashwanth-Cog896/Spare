package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class GeneticMaterialEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    GeneticMaterialEntity geneticMaterialEntity = new GeneticMaterialEntity();
    beanGetterSetterTester.testBean(geneticMaterialEntity);

      GermplasmEntity germplasm = new GermplasmEntity();
      geneticMaterialEntity.setGermplasm(germplasm);
      assertEquals(geneticMaterialEntity.getGermplasm(),germplasm);

      Set<GeneticMaterialParentEntity> parents = new HashSet<GeneticMaterialParentEntity>();
      geneticMaterialEntity.setParents(parents);
      assertEquals(geneticMaterialEntity.getParents(),parents);

  }

    @Test
    public void testEquals() throws Exception {

        GeneticMaterialEntity entity = new GeneticMaterialEntity();
        GeneticMaterialEntity sameObject = entity;

        assertTrue(entity.equals(sameObject));

        GeneticMaterialEntity nullObject = null;
        assertFalse(entity.equals(nullObject));

        GeneticMaterialEntity entity1 = new GeneticMaterialEntity();
        long id1 = 1L;
        long id2 = 2L;
        entity.setId(id1);
        entity1.setId(id2);
        assertFalse(entity.equals(entity1));

        entity1.setId(id1);

        assertTrue(entity.equals(entity1));

    }

    @Test
    public void testHashcode() throws Exception {
        GeneticMaterialEntity entity = new GeneticMaterialEntity();
        long id = 2L;
        entity.setId(id);
        int hashcode = entity.hashCode();
        assertEquals(entity.hashCode(),hashcode);
    }
}
