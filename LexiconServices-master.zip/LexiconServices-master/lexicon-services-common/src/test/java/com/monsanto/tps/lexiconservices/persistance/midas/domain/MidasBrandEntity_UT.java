package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasBrandEntity_UT {
    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

    @Test
    public void test_getterSetter() throws Exception {

        MidasBrandEntity midasBrandEntity = new MidasBrandEntity();
        beanGetterSetterTester.testBean(midasBrandEntity);
        MidasCompanyEntity midasCompany = new MidasCompanyEntity();
        midasBrandEntity.setMidasCompany(midasCompany);
        assertEquals(midasBrandEntity.getMidasCompany(), midasCompany);
    }
}
