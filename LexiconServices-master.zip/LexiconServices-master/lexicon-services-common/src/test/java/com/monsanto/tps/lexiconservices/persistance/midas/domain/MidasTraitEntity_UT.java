package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasTraitEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    MidasTraitEntity midasTraitEntity = new MidasTraitEntity();
    beanGetterSetterTester.testBean(midasTraitEntity);

      MidasCropEntity crop = new MidasCropEntity();
      midasTraitEntity.setMidasCrop(crop);
      assertEquals(midasTraitEntity.getMidasCrop(),crop);

      List<TraitValueEntity> traitValue = new ArrayList<TraitValueEntity>();
      midasTraitEntity.setTraitValueEntity(traitValue);
      assertEquals(midasTraitEntity.getTraitValueEntity(),traitValue);
  }
}
