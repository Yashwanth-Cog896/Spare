package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconStageEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconStageEntity lexiconStageEntity = new LexiconStageEntity();


  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(lexiconStageEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    lexiconStageEntity.setStageCategories(new HashSet<StageCategoryEntity>());
    assertNotNull(lexiconStageEntity.getStageCategories());
  }
}
