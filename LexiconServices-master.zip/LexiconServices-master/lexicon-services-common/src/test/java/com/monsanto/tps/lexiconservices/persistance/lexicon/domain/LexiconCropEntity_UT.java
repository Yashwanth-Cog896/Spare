package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconCropEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconCropEntity lexiconCropEntity = new LexiconCropEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(lexiconCropEntity);
  }
  @Test
  public void testCustomObjects() throws Exception {
    lexiconCropEntity.setStageCategory(new StageCategoryEntity());
    assertNotNull(lexiconCropEntity.getStageCategory());
  }
}
