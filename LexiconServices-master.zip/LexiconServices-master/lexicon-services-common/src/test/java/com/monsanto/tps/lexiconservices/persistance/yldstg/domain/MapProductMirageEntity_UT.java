package com.monsanto.tps.lexiconservices.persistance.yldstg.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.GeneticMaterialEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.lexiconservices.persistance.yldstg.domain.MapProductMirageEntity;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 1/23/14
 * Time: 11:23 AM
 */
public class MapProductMirageEntity_UT {

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

    @Test
    public void test_getterSetter() throws Exception {

        MapProductMirageEntity mapProductMirageEntity = new MapProductMirageEntity();
        beanGetterSetterTester.testBean(mapProductMirageEntity);
        GeneticMaterialEntity geneticMaterial = new GeneticMaterialEntity();
        MidasProductEntity midasProduct = new MidasProductEntity();
        MirageSeedProductEntity mirageSeedProduct = new MirageSeedProductEntity();
        mapProductMirageEntity.setGeneticMaterial(geneticMaterial);
        mapProductMirageEntity.setMidasProduct(midasProduct);
        mapProductMirageEntity.setMirageSeedProduct(mirageSeedProduct);

        assertThat(mapProductMirageEntity.getGeneticMaterial(),is(geneticMaterial));
        assertThat(mapProductMirageEntity.getMidasProduct(),is(midasProduct));
        assertThat(mapProductMirageEntity.getMirageSeedProduct(),is(mirageSeedProduct));
    }
}
