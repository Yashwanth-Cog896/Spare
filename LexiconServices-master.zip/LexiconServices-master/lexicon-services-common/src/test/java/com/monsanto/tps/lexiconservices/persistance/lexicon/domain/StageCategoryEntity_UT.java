package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class StageCategoryEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    StageCategoryEntity stageCategoryEntity = new StageCategoryEntity();
    beanGetterSetterTester.testBean(stageCategoryEntity);
  }
}
