package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonBrandXrefEntity;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconBrandEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconBrandEntity lexiconBrandEntity = new LexiconBrandEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(lexiconBrandEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    lexiconBrandEntity.setLexiconCompany(new LexiconCompanyEntity());
    lexiconBrandEntity.setFbsCommonBrandXrefs(new HashSet<FbsCommonBrandXrefEntity>() );
    assertNotNull(lexiconBrandEntity.getLexiconCompany());
    assertNotNull(lexiconBrandEntity.getFbsCommonBrandXrefs());

  }
}
