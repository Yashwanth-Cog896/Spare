package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductClassificationEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  ProductClassificationEntity productClassificationEntity = new ProductClassificationEntity();

  @Test
  public void test_getterSetter() throws Exception {
    beanGetterSetterTester.testBean(productClassificationEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    productClassificationEntity.setFamily(new FamilyEntity());
    productClassificationEntity.setMaterialGroup(new MaterialGroupEntity());
    productClassificationEntity.setProductionEnvironment(new ProductionEnvironmentEntity());
    productClassificationEntity.setMaterialPricingGroup(new MaterialPricingGroupEntity());
    productClassificationEntity.setProductType(new ProductTypeEntity());
    assertNotNull(productClassificationEntity.getFamily());
    assertNotNull(productClassificationEntity.getMaterialGroup());
    assertNotNull(productClassificationEntity.getMaterialPricingGroup());
    assertNotNull(productClassificationEntity.getProductionEnvironment());
  }
}
