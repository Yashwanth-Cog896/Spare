package com.monsanto.tps.lexiconservices.persistance.config;

import com.monsanto.tps.lexiconservices.persistance.testtools.HibernateTestCase;
import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.metadata.ClassMetadata;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;

import static org.junit.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 9:29 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:context/test-datasource-context.xml"
})
public class HibernateConfigurationTest_UT extends HibernateTestCase {

  @Test
  public void test_loadAllEntitiesToCheckORM() throws Exception {

    Map<String,ClassMetadata> allClassMetadata = sessionFactory.getAllClassMetadata();
    for (ClassMetadata classMetadata:allClassMetadata.values()){
      Class mappedClass = classMetadata.getMappedClass(EntityMode.POJO);
      assertNotNull(getFirstRowOfTableByClass(mappedClass));
    }
  }
}
