package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialGroupEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  MaterialGroupEntity materialGroupEntity = new MaterialGroupEntity();


  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(materialGroupEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    materialGroupEntity.setLexiconCrop(new LexiconCropEntity());
    assertNotNull(materialGroupEntity.getLexiconCrop());

  }
}
