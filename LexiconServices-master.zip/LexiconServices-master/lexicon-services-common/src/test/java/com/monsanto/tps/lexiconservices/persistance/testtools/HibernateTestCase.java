package com.monsanto.tps.lexiconservices.persistance.testtools;

import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.audit.AuditStagingEntity;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/21/13
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(value = SpringJUnit4ClassRunner.class)
@ContextConfiguration(value = {
        "classpath:/context/test-datasource-context.xml",
        "classpath:/context/test-transaction-context.xml",
        "classpath:/com/monsanto/tps/lexiconservices/persistance/contexts/hibernate-context.xml"
})
@Transactional(propagation = Propagation.REQUIRED)
@TransactionConfiguration(defaultRollback = true)
public class HibernateTestCase {

    @Resource
    protected DataSource dataSource;

    protected SimpleJdbcTemplate jdbcTemplate;

    @Resource
    protected SessionFactory sessionFactory;

    protected Session currentSession;

    protected BigDecimal bdSessionId;


    @Before
    public void setupAudit() {
        currentSession = sessionFactory.getCurrentSession();
        jdbcTemplate = new SimpleJdbcTemplate(dataSource);

        bdSessionId = (BigDecimal) currentSession.createSQLQuery("select lexicon.audit_pkg.Get_Session_Id_F() from dual").uniqueResult();
        long oracleSid = bdSessionId.longValueExact();
        String sessionOSuser = (String) currentSession.createSQLQuery("select lexicon.audit_pkg.Get_Session_OSUser_F() from dual").uniqueResult();
        String machine = (String) currentSession.createSQLQuery("select lexicon.audit_pkg.Get_Session_Machine_F() from dual").uniqueResult();

        AuditStagingEntity auditStaging = new AuditStagingEntity();
        auditStaging.setOracleSID(oracleSid);
        auditStaging.setProcessName("DUT");
        auditStaging.setAuditComment("DUT");
        auditStaging.setAuditRequestor("junit");
        long currentTimeMillis = System.currentTimeMillis();
        Date creationTimestamp = new Date(currentTimeMillis - (currentTimeMillis % 1000));
        auditStaging.setCreationTimestamp(creationTimestamp);
        auditStaging.setMachine(machine);
        auditStaging.setOsUser(sessionOSuser);
        auditStaging.setUserLoginID("junit");
        mergeFlushAndClear(auditStaging);
    }

    private void mergeFlushAndClear(AuditStagingEntity auditStaging) {
        currentSession.merge(auditStaging);
        flushAndClearSession();
    }

    protected Object saveFlushAndClear(Object entity) {
        Serializable save = currentSession.save(entity);
        Object fromDb = getById(entity.getClass(), save);
        flushAndClearSession();
        return fromDb;
    }

    protected Object mergeFlushAndClear(Object entity) {
        Object fromDb = currentSession.merge(entity);
        flushAndClearSession();
        return fromDb;
    }

    protected void flushAndClearSession() {
        currentSession.flush();
        currentSession.clear();
    }

    protected <T> T getById(Class<T> clazz, Serializable id) {
        return (T) currentSession.get(clazz, id);
    }


    protected <T> T getFirstRowOfTableByClass(Class<T> clazz) {
        int start = 0;
        int end = 1;
        Criteria criteria = currentSession.createCriteria(clazz).setFirstResult(start).setMaxResults(end);
        return (T) criteria.list().get(0);
    }

    protected long getRowCountByClass(Class clazz) {
        return new Long(currentSession.createCriteria(clazz).setProjection(Projections.rowCount()).uniqueResult().toString());
    }

    protected void deleteObjectById(Class entity, Serializable id) {
        Object entityObject = getById(entity, id);
        currentSession.delete(entityObject);
    }
}
