package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductNameEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    MidasProductNameEntity midasProductNameEntity = new MidasProductNameEntity();
    beanGetterSetterTester.testBean(midasProductNameEntity);

      MidasBrandEntity brand = new MidasBrandEntity();
      midasProductNameEntity.setMidasBrand(brand);
      assertEquals(midasProductNameEntity.getMidasBrand(),brand);

      MidasCountryEntity country = new MidasCountryEntity();
      midasProductNameEntity.setMidasCountry(country);
      assertEquals(midasProductNameEntity.getMidasCountry(),country);

      MidasProductEntity product = new MidasProductEntity();
      midasProductNameEntity.setMidasProduct(product);
      assertEquals(midasProductNameEntity.getMidasProduct(),product);
  }
}
