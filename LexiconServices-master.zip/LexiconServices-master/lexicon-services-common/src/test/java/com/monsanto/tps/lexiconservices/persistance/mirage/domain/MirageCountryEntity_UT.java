package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageCountryEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  MirageCountryEntity mirageCountryEntity = new MirageCountryEntity();


  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(mirageCountryEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    mirageCountryEntity.setAudit(new MirageAuditEntity());
    assertNotNull(mirageCountryEntity.getAudit());
  }
}
