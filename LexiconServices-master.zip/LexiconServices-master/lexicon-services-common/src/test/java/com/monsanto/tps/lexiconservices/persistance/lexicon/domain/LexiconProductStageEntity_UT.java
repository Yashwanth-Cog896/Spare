package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 3:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductStageEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconProductStageEntity lexiconProductStageEntity = new LexiconProductStageEntity();


  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(lexiconProductStageEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    lexiconProductStageEntity.setFbsCommonProductNameXrefs(new ArrayList<FbsCommonProductNameXrefEntity>());
    lexiconProductStageEntity.setFbsCommonProductNameXref(new FbsCommonProductNameXrefEntity());
    lexiconProductStageEntity.setCommercialTraitStack(new CommercialTraitStackEntity());
    lexiconProductStageEntity.setLexiconBrand(new LexiconBrandEntity());
    lexiconProductStageEntity.setLexiconCountry(new LexiconCountryEntity());
    lexiconProductStageEntity.setLexiconProduct(new LexiconProductEntity());
    lexiconProductStageEntity.setExceptionCode(new ExceptionCodeEntity());
    lexiconProductStageEntity.setLexiconStage(new LexiconStageEntity());
    assertNotNull(lexiconProductStageEntity.getFbsCommonProductNameXrefs());
    assertNotNull(lexiconProductStageEntity.getFbsCommonProductNameXref());
    assertNotNull(lexiconProductStageEntity.getCommercialTraitStack());
    assertNotNull(lexiconProductStageEntity.getLexiconBrand());
    assertNotNull(lexiconProductStageEntity.getLexiconCountry());
    assertNotNull(lexiconProductStageEntity.getLexiconProduct());
    assertNotNull(lexiconProductStageEntity.getLexiconStage());
    assertNotNull(lexiconProductStageEntity.getExceptionCode());

  }
}
