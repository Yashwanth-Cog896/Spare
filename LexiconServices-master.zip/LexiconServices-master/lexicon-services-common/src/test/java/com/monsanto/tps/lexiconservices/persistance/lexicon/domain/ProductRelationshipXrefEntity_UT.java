package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 3:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductRelationshipXrefEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  ProductRelationshipXrefEntity productRelationshipXrefEntity = new ProductRelationshipXrefEntity();

  @Test
  public void test_getterSetter() throws Exception {


    beanGetterSetterTester.testBean(productRelationshipXrefEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    productRelationshipXrefEntity.setLexiconProduct(new LexiconProductEntity());
    productRelationshipXrefEntity.setProductionStatus(new LexiconProductionStatusEntity());
    productRelationshipXrefEntity.setProductRelationship(new ProductRelationshipEntity());
    assertNotNull(productRelationshipXrefEntity.getLexiconProduct());
    assertNotNull(productRelationshipXrefEntity.getProductionStatus());
    assertNotNull(productRelationshipXrefEntity.getProductRelationship());
  }
}
