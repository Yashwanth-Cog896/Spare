package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonCountryXrefEntity;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconCountryEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconCountryEntity lexiconCountryEntity = new LexiconCountryEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(lexiconCountryEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    lexiconCountryEntity.setFbsCommonCountryXrefs(new HashSet<FbsCommonCountryXrefEntity>());
    assertNotNull(lexiconCountryEntity.getFbsCommonCountryXrefs());
  }
}
