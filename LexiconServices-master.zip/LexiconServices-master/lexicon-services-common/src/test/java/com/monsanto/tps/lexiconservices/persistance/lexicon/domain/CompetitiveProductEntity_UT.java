package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompetitiveProductEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  CompetitiveProductEntity competitiveProductEntity = new CompetitiveProductEntity();


  @Test
  public void test_getterSetter() throws Exception {
    beanGetterSetterTester.testBean(competitiveProductEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    competitiveProductEntity.setFbsCommonProductXrefs(new ArrayList<FbsCommonProductXrefEntity>());
    competitiveProductEntity.setFbsCommonProductXref(new FbsCommonProductXrefEntity());
    competitiveProductEntity.setLexiconProductNames(new ArrayList<LexiconProductNameEntity>());
    assertNotNull(competitiveProductEntity.getFbsCommonProductXrefs());
    assertNotNull(competitiveProductEntity.getFbsCommonProductXref());
    assertNotNull(competitiveProductEntity.getLexiconProductNames());
  }
}
