package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 1/9/14
 * Time: 10:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommercialTraitStackCountryAlternateNameEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  CommercialTraitStackCountryAlternateNameEntity commercialTraitStackCountryAlternateNameEntity = new CommercialTraitStackCountryAlternateNameEntity();


  @Test
  public void test_getterSetter() throws Exception {
    beanGetterSetterTester.testBean(commercialTraitStackCountryAlternateNameEntity);
    commercialTraitStackCountryAlternateNameEntity.setCommercialTraitStackAlternateName(new CommercialTraitStackAlternateNameEntity());
    commercialTraitStackCountryAlternateNameEntity.setLexiconCountry(new LexiconCountryEntity());
    assertNotNull(commercialTraitStackCountryAlternateNameEntity.getCommercialTraitStackAlternateName());
    assertNotNull(commercialTraitStackCountryAlternateNameEntity.getLexiconCountry());
  }
}
