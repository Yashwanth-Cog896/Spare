package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    GermplasmEntity germplasmEntity = new GermplasmEntity();
    beanGetterSetterTester.testBean(germplasmEntity);

      LineTypeEntity lineType = new LineTypeEntity();
      germplasmEntity.setLineType(lineType);
      assertEquals(germplasmEntity.getLineType(),lineType) ;

      ProgramEntity ownerProgram = new ProgramEntity();
      germplasmEntity.setOwnerProgram(ownerProgram);
      assertEquals(germplasmEntity.getOwnerProgram(),ownerProgram);

      MidasCropEntity crop = new MidasCropEntity();
      germplasmEntity.setMidasCrop(crop);
      assertEquals(germplasmEntity.getMidasCrop(),crop);

      Set<GermplasmRoyaltyEntity> royalty = new HashSet<GermplasmRoyaltyEntity>();
      germplasmEntity.setGermplasmRoyalties(royalty);
      assertEquals(germplasmEntity.getGermplasmRoyalties(),royalty);

      Set<ProductGermplasmEntity> germplasms =  new HashSet<ProductGermplasmEntity>();
      germplasmEntity.setProductGermplasms(germplasms);
      assertEquals(germplasmEntity.getProductGermplasms(),germplasms);

      Set<TraitValueEntity> traitValues = new HashSet<TraitValueEntity>();
      germplasmEntity.setTraitValues(traitValues);
      assertEquals(traitValues,germplasmEntity.getTraitValues());

      Set<GeneticMaterialEntity> geneticMaterials = new HashSet<GeneticMaterialEntity>();
      germplasmEntity.setGeneticMaterials(geneticMaterials);
      assertEquals(germplasmEntity.getGeneticMaterials(),geneticMaterials);

      Set<GermplasmEventConstructEntity> events = new HashSet<GermplasmEventConstructEntity>();
      germplasmEntity.setGermplasmEventConstructs(events);
      assertEquals(germplasmEntity.getGermplasmEventConstructs(),events);
  }
}
