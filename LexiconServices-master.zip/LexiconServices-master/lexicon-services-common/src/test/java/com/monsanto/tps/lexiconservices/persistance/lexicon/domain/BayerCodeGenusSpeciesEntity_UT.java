package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/17/13
 * Time: 6:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class BayerCodeGenusSpeciesEntity_UT {

    private long bayerCodeId = 123l;
    private String genus = "genus";
    private String species = "species";

    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
    BayerCodeGenusSpeciesEntity bayerCodeGenusSpeciesEntity = new BayerCodeGenusSpeciesEntity();

    @Test
    public void test_getterSetter() throws Exception {
        beanGetterSetterTester.testBean(bayerCodeGenusSpeciesEntity);
    }

    @Test
    public void testCustomObjects() throws Exception {
        BayerCodeGenusSpeciesComposite bayerCodeGenusSpeciesComposite = new BayerCodeGenusSpeciesComposite();
        BayerCodeEntity bayerCodeEntity = new BayerCodeEntity();
        bayerCodeEntity.setId(bayerCodeId);
        bayerCodeGenusSpeciesComposite.setBayerCode(bayerCodeEntity);
        bayerCodeGenusSpeciesComposite.setGenus(genus);
        bayerCodeGenusSpeciesComposite.setSpecies(species);
        bayerCodeGenusSpeciesEntity.setBayerCodeGenusSpeciesComposite(bayerCodeGenusSpeciesComposite);
        assertEquals(bayerCodeId, bayerCodeGenusSpeciesEntity.getBayerCodeGenusSpeciesComposite().getBayerCode().getId().longValue());
        assertEquals(genus, bayerCodeGenusSpeciesEntity.getBayerCodeGenusSpeciesComposite().getGenus());
        assertEquals(species, bayerCodeGenusSpeciesEntity.getBayerCodeGenusSpeciesComposite().getSpecies());


    }

}
