package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductNameXrefEntity;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductNameEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  LexiconProductNameEntity lexiconProductNameEntity = new LexiconProductNameEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(lexiconProductNameEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    lexiconProductNameEntity.setFbsCommonProductNameXrefs(new ArrayList<FbsCommonProductNameXrefEntity>());
    lexiconProductNameEntity.setFbsCommonProductNameXref(new FbsCommonProductNameXrefEntity());
    lexiconProductNameEntity.setLexiconBrand(new LexiconBrandEntity());
    lexiconProductNameEntity.setLexiconCountry(new LexiconCountryEntity());
    lexiconProductNameEntity.setCompetitiveProduct(new CompetitiveProductEntity());
    assertNotNull(lexiconProductNameEntity.getFbsCommonProductNameXrefs());
    assertNotNull(lexiconProductNameEntity.getFbsCommonProductNameXref());
    assertNotNull(lexiconProductNameEntity.getLexiconBrand());
    assertNotNull(lexiconProductNameEntity.getLexiconCountry());
    assertNotNull(lexiconProductNameEntity.getCompetitiveProduct());

  }
}
