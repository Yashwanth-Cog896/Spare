package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageCompanyEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    MirageCompanyEntity mirageCompanyEntity = new MirageCompanyEntity();
    beanGetterSetterTester.testBean(mirageCompanyEntity);
  }
}
