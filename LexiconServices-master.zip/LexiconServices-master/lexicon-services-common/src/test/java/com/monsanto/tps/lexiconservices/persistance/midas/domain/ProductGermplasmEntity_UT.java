package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductGermplasmEntity_UT {
    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

    @Test
    public void test_getterSetter() throws Exception {

        ProductGermplasmEntity productGermplasmEntity = new ProductGermplasmEntity();
        beanGetterSetterTester.testBean(productGermplasmEntity);

        MidasProductEntity product = new MidasProductEntity();
        productGermplasmEntity.setMidasProduct(product);
        assertEquals(productGermplasmEntity.getMidasProduct(), product);

        GermplasmEntity germplasm = new GermplasmEntity();
        productGermplasmEntity.setGermplasm(germplasm);
        assertEquals(productGermplasmEntity.getGermplasm(), germplasm);
    }

    @Test
    public void testEquals() throws Exception {

        ProductGermplasmEntity entity = new ProductGermplasmEntity();
        ProductGermplasmEntity sameObject = entity;

        assertTrue(entity.equals(sameObject));

        ProductGermplasmEntity nullObject = null;
        assertFalse(entity.equals(nullObject));

        ProductGermplasmEntity entity1 = new ProductGermplasmEntity();

        GermplasmEntity germplasm1 = new GermplasmEntity();
        long id1 = 1l;
        germplasm1.setId(id1);
        GermplasmEntity germplasm2 = new GermplasmEntity();
        long id2 =2l;
        germplasm2.setId(id2);
        entity.setGermplasm(germplasm1);
        entity1.setGermplasm(germplasm2);

        assertFalse(entity.equals(entity1));

        entity1.setGermplasm(germplasm1);

        MidasProductEntity product1 = new MidasProductEntity();
        MidasProductEntity product2 = new MidasProductEntity();
        product1.setId(id1);
        product2.setId(id2);
        entity.setMidasProduct(product1);
        entity1.setMidasProduct(product2);

        assertFalse(entity.equals(entity1));
        entity1.setMidasProduct(product1);

        assertTrue(entity.equals(entity1));

    }

    @Test
    public void testHashcode() throws Exception {
        ProductGermplasmEntity entity = new ProductGermplasmEntity();
        GermplasmEntity germplasm = new GermplasmEntity();
        MidasProductEntity product = new MidasProductEntity();
        entity.setGermplasm(germplasm);
        entity.setMidasProduct(product);
        int hashcode = entity.hashCode();
        assertEquals(entity.hashCode(), hashcode);
    }
}
