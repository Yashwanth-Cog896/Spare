package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/17/13
 * Time: 5:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropBayerCodeEntity_UT {

    private long bayerCodeId = 123l;
    private long cropId = 5123l;
    private long auditId = 545l;


    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
    CropBayerCodeEntity cropBayerCodeEntity = new CropBayerCodeEntity();

    @Test
    public void test_getterSetter() throws Exception {
        beanGetterSetterTester.testBean(cropBayerCodeEntity);
    }

    @Test
    public void testCustomObjects() throws Exception {
        CropBayerCodeComposite cropBayerCodeComposite = new CropBayerCodeComposite();
        BayerCodeEntity bayerCodeEntity = new BayerCodeEntity();
        bayerCodeEntity.setId(bayerCodeId);
        cropBayerCodeComposite.setBayerCode(bayerCodeEntity);
        LexiconCropEntity lexiconCropEntity = new LexiconCropEntity();
        lexiconCropEntity.setId(cropId);
        cropBayerCodeComposite.setLexiconCrop(lexiconCropEntity);
        cropBayerCodeEntity.setCropBayerCodeComposite(cropBayerCodeComposite);
        cropBayerCodeEntity.setAuditId(auditId);
        assertEquals(bayerCodeId, cropBayerCodeEntity.getCropBayerCodeComposite().getBayerCode().getId().longValue());
        assertEquals(cropId, cropBayerCodeEntity.getCropBayerCodeComposite().getLexiconCrop().getId());
        assertEquals(auditId, cropBayerCodeEntity.getAuditId());
    }
}
