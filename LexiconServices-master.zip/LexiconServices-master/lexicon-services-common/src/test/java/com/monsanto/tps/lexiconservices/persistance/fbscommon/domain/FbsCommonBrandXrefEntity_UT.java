package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.lexicon.domain.LexiconCompanyEntity;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasBrandEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageCompanyEntity;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class FbsCommonBrandXrefEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  FbsCommonBrandXrefEntity fbsCommonBrandXrefEntity = new FbsCommonBrandXrefEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(fbsCommonBrandXrefEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    fbsCommonBrandXrefEntity.setLexiconCompany(new LexiconCompanyEntity());
    fbsCommonBrandXrefEntity.setMidasBrand(new MidasBrandEntity());
    fbsCommonBrandXrefEntity.setMirageCompany(new MirageCompanyEntity());
    assertNotNull(fbsCommonBrandXrefEntity.getLexiconCompany());
    assertNotNull(fbsCommonBrandXrefEntity.getMidasBrand());
    assertNotNull(fbsCommonBrandXrefEntity.getMirageCompany());
  }
}
