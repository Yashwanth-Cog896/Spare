package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: PSETH
 * Date: 11/27/13
 * Time: 9:47 AM
 */
public class MirageSeedProductMaturiyEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  MirageSeedProductMaturityEntity mirageSeedProductMaturityEntity = new MirageSeedProductMaturityEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(mirageSeedProductMaturityEntity);
  }


  @Test
  public void testCustomObjects() throws Exception {
    mirageSeedProductMaturityEntity.setAudit(new MirageAuditEntity());
    assertNotNull(mirageSeedProductMaturityEntity.getAudit());
  }

}
