package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/22/13
 * Time: 3:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class BaseProductEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  BaseProductEntity baseProductEntity = new BaseProductEntity();


  @Test
  public void test_getterSetter() throws Exception {
    beanGetterSetterTester.testBean(baseProductEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    baseProductEntity.setLexiconCrop(new LexiconCropEntity());
    baseProductEntity.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
    assertNotNull(baseProductEntity.getLexiconCrop());
    assertNotNull(baseProductEntity.getProductRelationships());

  }
}
