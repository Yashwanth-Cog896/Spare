package com.monsanto.tps.lexiconservices.persistance.fbscommon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.midas.domain.MidasProductNameEntity;
import com.monsanto.tps.lexiconservices.persistance.mirage.domain.MirageSeedProductEntity;
import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class FbsCommonProductNameXrefEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  FbsCommonProductNameXrefEntity fbsCommonProductNameXrefEntity = new FbsCommonProductNameXrefEntity();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(fbsCommonProductNameXrefEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    fbsCommonProductNameXrefEntity.setMidasProductName(new MidasProductNameEntity());
    fbsCommonProductNameXrefEntity.setMirageSeedProduct(new MirageSeedProductEntity());
    assertNotNull(fbsCommonProductNameXrefEntity.getMidasProductName());
    assertNotNull(fbsCommonProductNameXrefEntity.getMirageSeedProduct());
  }
}
