package com.monsanto.tps.lexiconservices.persistance.constant;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/26/13
 * Time: 3:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class EntityConstant_UT {

  @Test
  public void testStaticLengthConstants() throws Exception {
    Assert.assertEquals(EntityConstant.LENGTH_2,2);
    Assert.assertEquals(EntityConstant.LENGTH_3,3);
    Assert.assertEquals(EntityConstant.LENGTH_10,10);
    Assert.assertEquals(EntityConstant.LENGTH_15,15);
    Assert.assertEquals(EntityConstant.LENGTH_20,20);
    Assert.assertEquals(EntityConstant.LENGTH_22,22);
    Assert.assertEquals(EntityConstant.LENGTH_30,30);
    Assert.assertEquals(EntityConstant.LENGTH_32,32);
    Assert.assertEquals(EntityConstant.LENGTH_40,40);
    Assert.assertEquals(EntityConstant.LENGTH_50,50);
    Assert.assertEquals(EntityConstant.LENGTH_40,40);
    Assert.assertEquals(EntityConstant.LENGTH_64,64);
    Assert.assertEquals(EntityConstant.LENGTH_80,80);
    Assert.assertEquals(EntityConstant.LENGTH_100,100);
    Assert.assertEquals(EntityConstant.LENGTH_200,200);
    Assert.assertEquals(EntityConstant.LENGTH_255,255);
    Assert.assertEquals(EntityConstant.LENGTH_2000,2000);
    Assert.assertEquals(EntityConstant.LENGTH_3200,3200);
    Assert.assertEquals(EntityConstant.LENGTH_4000,4000);
    Assert.assertEquals(EntityConstant.LENGTH_128,128);
    Assert.assertEquals(EntityConstant.LENGTH_4,4);
    Assert.assertEquals(EntityConstant.LENGTH_12,12);
    Assert.assertEquals(EntityConstant.LENGTH_35,35);
    Assert.assertEquals(EntityConstant.LENGTH_6,6);

    Assert.assertEquals(EntityConstant.PRECISION_CONSTANT_22,22);
    Assert.assertEquals(EntityConstant.PRECISION_CONSTANT_20,20);
    Assert.assertEquals(EntityConstant.PRECISION_CONSTANT_8,8);
    Assert.assertEquals(EntityConstant.PRECISION_CONSTANT_7,7);
    Assert.assertEquals(EntityConstant.PRECISION_CONSTANT_6,6);

    Assert.assertEquals(EntityConstant.HASH_CODE_CONSTANT,31);

  }
}
