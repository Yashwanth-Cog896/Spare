package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: PSETH
 * Date: 11/25/13
 * Time: 9:40 AM
 */
public class KeywordEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    KeywordEntity keywordEntity = new KeywordEntity();
    beanGetterSetterTester.testBean(keywordEntity);
  }
}
