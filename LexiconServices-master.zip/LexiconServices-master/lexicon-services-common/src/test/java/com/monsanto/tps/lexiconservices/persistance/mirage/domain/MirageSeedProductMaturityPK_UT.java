package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: VRAMA1
 * Date: 11/27/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageSeedProductMaturityPK_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  MirageSeedProductMaturityPK mirageSeedProductMaturityPK = new MirageSeedProductMaturityPK();

  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(mirageSeedProductMaturityPK);
  }

}
