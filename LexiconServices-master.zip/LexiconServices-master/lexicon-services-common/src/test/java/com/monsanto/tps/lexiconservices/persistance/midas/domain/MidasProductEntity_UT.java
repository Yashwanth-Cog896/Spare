package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import com.monsanto.tps.lexiconservices.persistance.fbscommon.domain.FbsCommonProductXrefEntity;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 12:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductEntity_UT {
    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

    @Test
    public void test_getterSetter() throws Exception {

        MidasProductEntity midasProductEntity = new MidasProductEntity();
        beanGetterSetterTester.testBean(midasProductEntity);

        MidasCropEntity crop = new MidasCropEntity();
        midasProductEntity.setMidasCrop(crop);
        assertEquals(midasProductEntity.getMidasCrop(), crop);

        Set<ProductGermplasmEntity> productGermplsams = new HashSet<ProductGermplasmEntity>();
        midasProductEntity.setProductGermplasms(productGermplsams);
        assertEquals(midasProductEntity.getProductGermplasms(), productGermplsams);

        List<MidasProductNameEntity> names = new ArrayList<MidasProductNameEntity>();
        midasProductEntity.setMidasProductNames(names);
        assertEquals(midasProductEntity.getMidasProductNames(), names);

        Set<FbsCommonProductXrefEntity> xrefs = new HashSet<FbsCommonProductXrefEntity>();
        midasProductEntity.setFbsCommonProductXrefs(xrefs);
        assertEquals(midasProductEntity.getFbsCommonProductXrefs(), xrefs);

    }
}
