package com.monsanto.tps.lexiconservices.persistance.mirage.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 9:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageAuditEntity_UT {

  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

  @Test
  public void test_getterSetter() throws Exception {

    MirageAuditEntity mirageAuditEntity = new MirageAuditEntity();
    beanGetterSetterTester.testBean(mirageAuditEntity);
  }
}
