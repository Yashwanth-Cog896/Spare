package com.monsanto.tps.lexiconservices.persistance.midas.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class GeneticMaterialParentEntity_UT {
    private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();

    @Test
    public void test_getterSetter() throws Exception {

        GeneticMaterialParentEntity geneticMaterialParentEntity = new GeneticMaterialParentEntity();
        beanGetterSetterTester.testBean(geneticMaterialParentEntity);
        GeneticMaterialEntity child = new GeneticMaterialEntity();
        geneticMaterialParentEntity.setChild(child);
        assertEquals(geneticMaterialParentEntity.getChild(), child);

        GeneticMaterialEntity parent = new GeneticMaterialEntity();
        geneticMaterialParentEntity.setParent(parent);
        assertEquals(geneticMaterialParentEntity.getParent(), parent);

        ParentalRoleEntity parentalRole = new ParentalRoleEntity();
        geneticMaterialParentEntity.setParentalRole(parentalRole);
        assertEquals(geneticMaterialParentEntity.getParentalRole(), parentalRole);


    }
}
