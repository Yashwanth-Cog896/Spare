package com.monsanto.tps.lexiconservices.persistance.lexicon.domain;

import com.monsanto.tcc.breedinglabservices.common.test.BeanGetterSetterTester;
import org.junit.Test;

import java.util.*;

import static junit.framework.Assert.assertNotNull;

/**
 * Created with IntelliJ IDEA.
 * User: vrama1
 * Date: 11/25/13
 * Time: 10:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class CommercialTraitStackEntity_UT {
  private BeanGetterSetterTester beanGetterSetterTester = new BeanGetterSetterTester();
  CommercialTraitStackEntity commercialTraitStackEntity = new CommercialTraitStackEntity();


  @Test
  public void test_getterSetter() throws Exception {

    beanGetterSetterTester.testBean(commercialTraitStackEntity);
  }

  @Test
  public void testCustomObjects() throws Exception {
    commercialTraitStackEntity.setLexiconCrop(new LexiconCropEntity());
    commercialTraitStackEntity.setAlternateNames(new ArrayList<CommercialTraitStackAlternateNameEntity>());
    commercialTraitStackEntity.setCommercialTraitNames(new ArrayList<CommercialTraitNameEntity>());
    assertNotNull(commercialTraitStackEntity.getLexiconCrop());
    assertNotNull(commercialTraitStackEntity.getAlternateNames());
    assertNotNull(commercialTraitStackEntity.getCommercialTraitNames());

  }
}
