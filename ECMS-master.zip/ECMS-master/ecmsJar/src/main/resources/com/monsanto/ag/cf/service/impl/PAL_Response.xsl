<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:pal="http://www.monsanto.com/PAL/response"
xmlns="urn:ecms:schema:pal:response:1:0" xmlns:ecms="urn:ecms:schema:pal:response:1:0" xmlns:cidx="urn:cidx:names:specification:ces:schema:all:4:0" exclude-result-prefixes="pal">
<xsl:template match="/" >
		<PriceAndAvailabilityResponse xmlns="urn:ecms:schema:pal:response:1:0" xmlns:ecms="urn:ecms:schema:pal:response:1:0" xmlns:cidx="urn:cidx:names:specification:ces:schema:all:4:0" Version="1.0">
		<xsl:apply-templates select="/ProductAvailabilityListResponse/Header" />	
		<xsl:apply-templates select="/ProductAvailabilityListResponse/Body" />		
		</PriceAndAvailabilityResponse>
	</xsl:template>
	<xsl:template match="Header">
		<cidx:Header>
			<cidx:ThisDocumentIdentifier>
			<cidx:DocumentIdentifier><xsl:value-of select="ThisDocumentIdentifier/DocumentIdentifier"/></cidx:DocumentIdentifier>
		</cidx:ThisDocumentIdentifier>
		<cidx:ThisDocumentDateTime>
					<cidx:DateTime DateTimeQualifier="On">
						<xsl:value-of select="ThisDocumentDateTime/DateTime"/>
					</cidx:DateTime>
				</cidx:ThisDocumentDateTime>
				<cidx:From>
			<cidx:PartnerInformation>
				<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>
				<cidx:PartnerIdentifier Agency="AGIIS-EBID">0062668030000</cidx:PartnerIdentifier>
			</cidx:PartnerInformation>
		</cidx:From>
		<cidx:To>
			<cidx:PartnerInformation>
				<cidx:PartnerName><xsl:value-of select="/ProductAvailabilityListResponse/Body/Partners/Dealer/PartnerIdentifier"/></cidx:PartnerName>
				<cidx:PartnerIdentifier Agency="AssignedByPapiNet"><xsl:value-of select="/ProductAvailabilityListResponse/Body/Partners/Dealer/PartnerIdentifier"/></cidx:PartnerIdentifier>
			</cidx:PartnerInformation>
		</cidx:To>
			</cidx:Header>
	</xsl:template>
	<xsl:template match="Body">
	<PriceAndAvailabilityResponseBody>
	<xsl:apply-templates select="Properties"/>
	<xsl:apply-templates select="Partners"/>
	<xsl:apply-templates select="Details"/>
	</PriceAndAvailabilityResponseBody>
	</xsl:template>	
	
	<xsl:template match="Details">
	<PriceAndAvailabilityResponseDetails>
	<xsl:apply-templates select="LineItem" />
	</PriceAndAvailabilityResponseDetails>
	</xsl:template>	
	
	<xsl:template match="Properties">
	<PriceAndAvailabilityResponseProperties>
			<cidx:RequisitionNumber>
				<cidx:DocumentIdentifier>a</cidx:DocumentIdentifier>
			</cidx:RequisitionNumber>
			<RequisitionTypeCode Domain="ANSI-ASC-X12-92"><xsl:value-of select="CallType"/></RequisitionTypeCode>
			<cidx:LanguageCode Domain="ISO-639-2T">eng</cidx:LanguageCode>
			<cidx:CurrencyCode Domain="ISO-4217">USD</cidx:CurrencyCode>			
		</PriceAndAvailabilityResponseProperties>
	</xsl:template>
	<xsl:template match="Partners">
	<PriceAndAvailabilityResponsePartners>	
	<!-- need to handle empty elements as following are required -->
	<cidx:Buyer>
				<cidx:PartnerInformation>
					<cidx:PartnerName><xsl:value-of select="Dealer/PartnerIdentifier"/></cidx:PartnerName>
					<cidx:PartnerIdentifier Agency="AssignedByPapiNet"><xsl:value-of select="Dealer/PartnerIdentifier"/></cidx:PartnerIdentifier>
				</cidx:PartnerInformation>
			</cidx:Buyer>
			<cidx:Seller>
				<cidx:PartnerInformation>
					<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>
					<cidx:PartnerIdentifier Agency="AGIIS-EBID">0062668030000</cidx:PartnerIdentifier>
				</cidx:PartnerInformation>
			</cidx:Seller>
			<cidx:ShipTo>
				<cidx:PartnerInformation>
					<cidx:PartnerName><xsl:value-of select="ShipTo/PartnerIdentifier"/></cidx:PartnerName>
					<cidx:PartnerIdentifier Agency="AssignedByPapiNet"><xsl:value-of select="ShipTo/PartnerIdentifier"/></cidx:PartnerIdentifier>
				</cidx:PartnerInformation>
			</cidx:ShipTo>
			<cidx:Payer>
				<cidx:PartnerInformation>
					<cidx:PartnerName><xsl:value-of select="Dealer/PartnerIdentifier"/></cidx:PartnerName>
					<cidx:PartnerIdentifier Agency="AssignedByPapiNet"><xsl:value-of select="Dealer/PartnerIdentifier"/></cidx:PartnerIdentifier>
				</cidx:PartnerInformation>
			</cidx:Payer>	
	</PriceAndAvailabilityResponsePartners>
	</xsl:template>	
	<xsl:template match="LineItem">	
			<PriceAndAvailabilityResponseProductLineItem>						
			<cidx:LineNumber><xsl:value-of select="position()"/></cidx:LineNumber>
				<cidx:RequisitionLineItemNumber><xsl:value-of select="position()"/></cidx:RequisitionLineItemNumber>
				<cidx:ProductIdentification>
					<cidx:ProductIdentifier Agency="UPC"><xsl:value-of select="UPCCode"/></cidx:ProductIdentifier>
					<xsl:if test="string-length(LegalDescription) != 0">
						<cidx:ProductName><xsl:value-of select="LegalDescription"/></cidx:ProductName>
					</xsl:if>
					<!-- Legal Description-->
					<xsl:if test="string-length(TraitCode) != 0">
						<cidx:Trademark><xsl:value-of select="TraitCode"/></cidx:Trademark>
					</xsl:if>
					<!-- TraitCode-->
					<xsl:if test="string-length(SpecieDescription) != 0">
						<cidx:ProductDescription><xsl:value-of select="SpecieDescription"/></cidx:ProductDescription>
					</xsl:if>
					<!-- Specie Description-->
					<xsl:if test="string-length(AcronymName) != 0">
					<cidx:ProductGradeDescription><xsl:value-of select="AcronymName"/></cidx:ProductGradeDescription>
					</xsl:if>
				<!-- AcronymName-->
					<xsl:if test="string-length(SpecieCode) != 0">
						<cidx:ProductClassification><xsl:value-of select="SpecieCode"/></cidx:ProductClassification>
					</xsl:if>
					<!-- Specie Code-->
				</cidx:ProductIdentification>
				<ProductQuantityInformation>
					<cidx:Measurement>
						<cidx:MeasurementValue><xsl:value-of select="AvailableQuantity"/></cidx:MeasurementValue>
						<cidx:UnitOfMeasureCode Domain="UN-Rec-20"><xsl:value-of select="UnitOfMeasureStandardCode"/></cidx:UnitOfMeasureCode>
					</cidx:Measurement>
				</ProductQuantityInformation>
				<xsl:if test="string-length(ATPOrAllocationIndicator) != 0">
					<ProductCharacteristics Agency="ATPOrAllocationIndicator"><xsl:value-of select="ATPOrAllocationIndicator"/></ProductCharacteristics>
				</xsl:if>
				<xsl:if test="string-length(NextDayDeliveryIndicator) != 0">
					<ProductCharacteristics Agency="NexDayDeliveryIndicator"><xsl:value-of select="NextDayDeliveryIndicator"/></ProductCharacteristics>
				</xsl:if>
				<xsl:if test="string-length(WinterProductionIndicator) != 0">
					<ProductCharacteristics Agency="WinterProductionIndicator"><xsl:value-of select="WinterProductionIndicator"/></ProductCharacteristics>
				</xsl:if>
				<xsl:if test="string-length(GrowerOrderRequiredIndicator) != 0">
					<ProductCharacteristics Agency="GrowerOrderRequiredIndicator"><xsl:value-of select="GrowerOrderRequiredIndicator"/></ProductCharacteristics>
				</xsl:if>
				<xsl:if test="string-length(RelativeMaturityValue) != 0">
				<ProductCharacteristics Agency="Maturity"><xsl:value-of select="RelativeMaturityValue"/></ProductCharacteristics>
				</xsl:if>
        <xsl:if test="string-length(ProductAllocationObject) != 0">
					<ProductCharacteristics Agency="ProductAllocation"><xsl:value-of select="ProductAllocationObject"/></ProductCharacteristics>
				</xsl:if>
				<cidx:ScheduleDateTimeInformation ScheduleType="RequestedDelivery">
					<cidx:DateTimeInformation>
						<cidx:DateTime DateTimeQualifier="On"><xsl:value-of select="/ProductAvailabilityListResponse/Header/ThisDocumentDateTime/DateTime"/></cidx:DateTime>
					</cidx:DateTimeInformation>
				</cidx:ScheduleDateTimeInformation>				
			</PriceAndAvailabilityResponseProductLineItem>		
	</xsl:template>	
</xsl:stylesheet>