<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:cidx="urn:cidx:names:specification:ces:schema:all:4:0"
  xmlns:ecms="urn:ecms:schema:pal:request:1:0"
  xmlns="http://www.monsanto.com/PAL/request"
  exclude-result-prefixes="cidx ecms">
  <xsl:template match="/">
    <ProductAvailabilityListRequest xmlns="http://www.monsanto.com/PAL/request"
      xmlns:pal="http://www.monsanto.com/PAL/request" Version="1.0">
      <xsl:apply-templates
        select="/ecms:PriceAndAvailabilityRequest/cidx:Header"/>
      <xsl:apply-templates
        select="/ecms:PriceAndAvailabilityRequest/ecms:PriceAndAvailabilityRequestBody"/>
    </ProductAvailabilityListRequest>
  </xsl:template>
  <xsl:template match="cidx:Header">
    <Header>
      <ThisDocumentIdentifier>
        <DocumentIdentifier>
          <xsl:value-of
            select="cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier"/>
        </DocumentIdentifier>
      </ThisDocumentIdentifier>
      <ThisDocumentDateTime>
        <DateTime>
          <xsl:value-of select="cidx:ThisDocumentDateTime/cidx:DateTime"/>
        </DateTime>
      </ThisDocumentDateTime>
      <From>
        <SystemName>SeedTrak
        </SystemName>
      </From>
      <To>
        <SystemName>SAP
        </SystemName>
      </To>
    </Header>
  </xsl:template>
  <xsl:template match="ecms:PriceAndAvailabilityRequestBody">
    <Body>
      <xsl:apply-templates select="ecms:PriceAndAvailabilityRequestProperties"/>
      <xsl:apply-templates select="ecms:PriceAndAvailabilityRequestPartners"/>
      <xsl:apply-templates select="ecms:PriceAndAvailabilityRequestDetails"/>
    </Body>
  </xsl:template>
  <xsl:template match="ecms:PriceAndAvailabilityRequestProperties">
    <Properties>
      <CallType>
        <xsl:value-of select="ecms:RequisitionTypeCode"/>
      </CallType>
      <OrderNumber>
        <xsl:value-of select="cidx:RequisitionNumber"/>
      </OrderNumber>
      <GrowerOrderRequiredIndicator>
        <xsl:value-of
          select="cidx:SpecialInstructions[@InstructionType='RequiredNotice']"/>
      </GrowerOrderRequiredIndicator>
      <UPCOrGTINIndicator>
        <xsl:value-of
          select="/ecms:PriceAndAvailabilityRequest/ecms:PriceAndAvailabilityRequestBody/ecms:PriceAndAvailabilityRequestDetails/ecms:PriceAndAvailabilityRequestProductLineItem/ecms:ProductSelection/cidx:ProductIdentification/cidx:ProductIdentifier/@Agency"/>
      </UPCOrGTINIndicator>
    </Properties>
  </xsl:template>
  <xsl:template match="ecms:PriceAndAvailabilityRequestPartners">
    <Partners>
      <xsl:apply-templates select="cidx:Buyer"/>
      <xsl:apply-templates select="cidx:ShipTo"/>
    </Partners>
  </xsl:template>
  <xsl:template match="cidx:Buyer">
    <Dealer>
      <PartnerIdentifier SystemTypeCode="SAP">
        <xsl:value-of select="cidx:PartnerInformation/cidx:PartnerIdentifier"/>
      </PartnerIdentifier>
    </Dealer>
  </xsl:template>
  <xsl:template match="cidx:ShipTo">
    <ShipTo>
      <PartnerIdentifier SystemTypeCode="SAP">
        <xsl:value-of select="cidx:PartnerInformation/cidx:PartnerIdentifier"/>
      </PartnerIdentifier>
    </ShipTo>
  </xsl:template>
  <xsl:template match="ecms:PriceAndAvailabilityRequestDetails">
    <Details>
      <xsl:apply-templates
        select="ecms:PriceAndAvailabilityRequestProductLineItem"/>
    </Details>
  </xsl:template>
  <xsl:template match="ecms:PriceAndAvailabilityRequestProductLineItem">
    <LineItem>
      <xsl:apply-templates select="ecms:ProductSelection"/>
      <xsl:apply-templates select="cidx:ProductQuantity"/>
    </LineItem>
  </xsl:template>
  <xsl:template match="cidx:ProductQuantity">
    <RequestedQuantity>
      <xsl:value-of select="cidx:Measurement/cidx:MeasurementValue"/>
    </RequestedQuantity>
    <UnitOfMeasure>
      <xsl:value-of select="cidx:Measurement/cidx:UnitOfMeasureCode"/>
    </UnitOfMeasure>
  </xsl:template>
  <xsl:template match="ecms:ProductSelection">
    <xsl:apply-templates select="ecms:ProductHierarchy"/>
    <xsl:apply-templates select="cidx:ProductIdentification"/>
  </xsl:template>
  <xsl:template match="ecms:ProductHierarchy">
    <xsl:if test="string-length(cidx:ProductGradeDescription) != 0">
      <AcronymName>
        <xsl:value-of select="cidx:ProductGradeDescription"/>
      </AcronymName>
    </xsl:if>
    <xsl:if test="string-length(cidx:ProductClassification) != 0">
      <SpecieCode>
        <xsl:value-of select="cidx:ProductClassification"/>
      </SpecieCode>
    </xsl:if>
    <xsl:if test="string-length(cidx:Trademark) != 0">
      <TraitCode>
        <xsl:value-of select="cidx:Trademark"/>
      </TraitCode>
    </xsl:if>
    <xsl:if test="string-length(cidx:ProductName) != 0">
      <LegalDescription>
        <xsl:value-of select="cidx:ProductName"/>
      </LegalDescription>
    </xsl:if>
  </xsl:template>
  <xsl:template match="cidx:ProductIdentification">
    <UPCCode>
      <xsl:value-of select="cidx:ProductIdentifier"/>
    </UPCCode>
    <SpecieCode>
      <xsl:value-of select="cidx:ProductClassification"/>
    </SpecieCode>
  </xsl:template>
</xsl:stylesheet>