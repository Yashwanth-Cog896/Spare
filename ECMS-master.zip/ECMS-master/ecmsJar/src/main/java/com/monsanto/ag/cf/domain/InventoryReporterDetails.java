package com.monsanto.ag.cf.domain;

/**
 * Created by JTMURR on 5/20/2016.
 */
public class InventoryReporterDetails {
    private String reporterName;
    private String reporterIdQualifier;
    private String reporterId;
    private String ownerName;
    private String ownerIdQualifier;
    private String ownerId;

    public InventoryReporterDetails(String reporterName, String reporterIdQualifier, String reporterId,
                                    String ownerName, String ownerIdQualifier, String ownerId) {
        this.reporterName = reporterName;
        this.reporterIdQualifier = reporterIdQualifier;
        this.reporterId = reporterId;
        this.ownerName = ownerName;
        this.ownerIdQualifier = ownerIdQualifier;
        this.ownerId = ownerId;
    }

    public String getReporterName() {
        return reporterName;
    }

    public void setReporterName(String reporterName) {
        this.reporterName = reporterName;
    }

    public String getReporterIdQualifier() {
        return reporterIdQualifier;
    }

    public void setReporterIdQualifier(String reporterIdQualifier) {
        this.reporterIdQualifier = reporterIdQualifier;
    }

    public String getReporterId() {
        return reporterId;
    }

    public void setReporterId(String reporterId) {
        this.reporterId = reporterId;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerIdQualifier() {
        return ownerIdQualifier;
    }

    public void setOwnerIdQualifier(String ownerIdQualifier) {
        this.ownerIdQualifier = ownerIdQualifier;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }
}
