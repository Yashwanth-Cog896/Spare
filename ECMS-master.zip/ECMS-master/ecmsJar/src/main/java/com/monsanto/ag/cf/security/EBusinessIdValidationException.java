/*
 * EBusinessIdValidationException was created on Apr 20, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.security;

/**
 * Represents a failure of the EBID validation.
 * 
 * @author Gareth Davies
 * @version $Id: EBusinessIdValidationException.java,v 1.1 2005-04-20 17:21:51 ggdavi Exp $
 */
public class EBusinessIdValidationException extends Exception {

  /**
   * @param message
   */
  public EBusinessIdValidationException(String message) {
    super(message);
  }
}

/*
 * $Log: not supported by cvs2svn $
 */