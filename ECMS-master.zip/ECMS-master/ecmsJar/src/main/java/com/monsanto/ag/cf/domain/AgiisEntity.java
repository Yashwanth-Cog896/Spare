/*
 * AgiisEntity was created on Jul 2, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.monsanto.ag.xml.XmlElement;

/**
 * Represents generic properties and operations of entities related to AGIIS
 * information, such as Products.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method. The XML
 * conforms to elements and types defined in the AGIISNamespacedSchema.xsd XML
 * schema document.
 * 
 * @author Gareth Davies
 * @version $Id: AgiisEntity.java,v 1.1 2008-07-18 21:28:18 gjkell Exp $
 */
public abstract class AgiisEntity implements Serializable, Cloneable {

  protected static final String UOM_DOMAIN_UN_REC_20 = "Un-Rec-20";

  public static final String ACTIVE_FLAG_FALSE = "Inactive";
  public static final String ACTIVE_FLAG_TRUE = "Active";
  public static final String ACTION_REQUEST_ADD = "Add";
  public static final String ACTION_REQUEST_UPDATE = "Replace";
  public static final String ACTION_REQUEST_DELETE = "Delete";

  private boolean active;
  private Date addedDate;
  private Date lastModifiedDate;

  protected AgiisEntity() {
  }

  protected AgiisEntity(boolean active, Date addedDate, Date lastModifiedDate) {
    this.active = active;
    setAddedDate(addedDate);
    setLastModifiedDate(lastModifiedDate);
  }

  /**
   * @see java.lang.Object#clone()
   */
  public abstract Object clone() throws CloneNotSupportedException;

  /**
   * Dispose of any resources currently used by this object.
   * <p>
   * TODO Is this really necessary?
   */
  public void dispose() {
  }

  protected boolean isActive() {
    return active;
  }

  protected Date getAddedDate() {
    return addedDate;
  }

  private void setAddedDate(Date addedDate) {
    if (addedDate != null) {
      this.addedDate = addedDate;
    } else {
      throw new IllegalArgumentException("Added Date is a required field");
    }
  }

  protected Date getLastModifiedDate() {
    return lastModifiedDate;
  }

  private void setLastModifiedDate(Date lastModifiedDate) {
    if (lastModifiedDate != null) {
      this.lastModifiedDate = lastModifiedDate;
    } else {
      throw new IllegalArgumentException(
          "Last Modified Date is a required field");
    }
  }

  /**
   * Append the XML representation of the object to the specified XML document
   * element.
   * 
   * @param baseXmlElement
   *          XML document element to which to append the object's XML
   */
  public abstract void appendXmlToElement(XmlElement baseXmlElement);

  /**
   * Adds an ActiveFlag attribute to the specified element with a value of
   * "Active" or "Inactive".
   * 
   * @param element
   *          Element to which the attribute will be added
   */
  protected void setActiveFlagAttribute(XmlElement element) {
    String activeFlag = (active) ? ACTIVE_FLAG_TRUE : ACTIVE_FLAG_FALSE;
    element.setAttribute("ActiveFlag", activeFlag);
  }

  /**
   * Adds an ActionRequest attribute to the specified element with a value of
   * "Add" or "Replace".
   * 
   * @param element
   *          Element to which the attribute will be added
   */
  protected void setActionRequestAttribute(XmlElement element) {
    if (ObjectUtils.equals(addedDate, lastModifiedDate)) {
      element.setAttribute("ActionRequest", ACTION_REQUEST_ADD);
    } else {
      element.setAttribute("ActionRequest", ACTION_REQUEST_UPDATE);
    }
  }

  /**
   * Converts the specified boolean value to a standard text representation.
   * 
   * @param booleanValue
   *          Value to convert
   * @return Text representation
   */
  protected String convertToFlagValue(boolean booleanValue) {
    return (booleanValue) ? "Y" : "N";
  }

  /**
   * Adds an element conforming to the AGIIS XML schema UnitOfMeasureCodeType.
   * 
   * @param baseElement
   *          Element to which the unit of measure element will be added
   * @param elementName
   *          Name of the unit of measure element
   * @param elementValue
   *          Unit of measure value
   * @param domain
   *          Domain to which this unit of measure value belongs
   * @return Unit of measure element
   */
  protected XmlElement addUnitOfMeasureElement(XmlElement baseElement,
      String elementName, String elementValue, String domain) {
    if (elementValue == null) {
      return null;
    }

    XmlElement uomElement = baseElement.addChildElement(elementName,
        elementValue);
    uomElement.setAttribute("Domain", domain);
    return uomElement;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof AgiisEntity)) {
      return false;
    }
    AgiisEntity rhs = (AgiisEntity) obj;
    return new EqualsBuilder().append(active, rhs.active).append(addedDate,
        rhs.addedDate).append(lastModifiedDate, rhs.lastModifiedDate)
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 1).append(active).append(addedDate).append(
        lastModifiedDate).hashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.9  2005/12/01 19:55:37  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.8  2005/08/26 16:31:37  ggdavi
 * Javadoc corrections
 *
 * Revision 1.7  2005/08/19 15:14:34  ggdavi
 * Modified to support different types of products
 * Revision 1.6 2005/08/05 22:58:21 ggdavi Fixed
 * ActionRequest attribute values
 * 
 * Revision 1.5 2005/07/28 15:47:50 ggdavi Added ActionRequest attribute to
 * various Product document elements; mapped the PackageLevelCode and CheckDigit
 * elements to the GTIN database column; only send one error email per
 * ProductUpdate document, containing all product-specific errors Revision 1.4
 * 2005/07/21 22:23:39 ggdavi Added com.monsanto.ag.util.IdTranslator object to
 * translate numeric Ids (such as Account, EBusiness and SAP Ids) back and forth
 * between their numeric and zero-padded textual representations; enhanced and
 * refactored XML abstraction in com.monsanto.ag.util Revision 1.3 2005/07/06
 * 22:10:17 ggdavi Handled the refactoring com.monsanto.ag.util, including
 * breaking out XmlDocument from XmlElement and adding XmlNamespace Revision 1.2
 * 2005/07/05 21:02:43 ggdavi Added ACTIVE_FLAG_* constants
 * 
 * Revision 1.1 2005/07/05 19:26:08 ggdavi Initial version
 * 
 */