/*
 * ProductLightImpl was created on Oct 1, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;


import java.text.ParseException;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.dao.ProductLightDao;
import com.monsanto.ag.cf.dao.jdbc.OtherSeedBrandsDao;
import com.monsanto.ag.cf.domain.AGIISSubscriberResults;
import com.monsanto.ag.cf.service.ProductLightSerializer;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamListAppender;

/**
 * Service Implementation of Product Light web service.
 * This is version 2 of the product light service.  This service was created to 
 * handle other seed branded products retrieved from AGIIS.
 * 
 */
public class ProductLightImpl_2 implements SecureService, Identifiable {

  private static final String XPATH_REQUEST_PARMS = "/ecms:ProductExtractRequest/ecms:ProductExtractRequestBody/ecms:ProductExtractRequestDetails";

  public static final String ACTIVE_FLAG_FALSE = "Inactive";
  public static final String ACTIVE_FLAG_TRUE = "Active";
  public static final String ACTION_REQUEST_ADD = "Add";
  public static final String ACTION_REQUEST_UPDATE = "Replace";

  protected static final XmlNamespace NAMESPACE_PROD_LIGHT_RESPONSE = new XmlNamespace("ecms",
  "urn:ecms:schema:products:response:2:0");
  
  private XmlDocumentBuilder xmlDocumentBuilder;
  private ProductLightDao productLightDao;
  private IdMapperDao idMapperDao;
  private OtherSeedBrandsDao otherSeedBrandsDao;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private ProductLightSerializer productLightSerializer;
  private AGIISIsSubscriberProxy agiisIsSubscriberProxy;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "PRODLT";
  }
  
  public boolean isValidationRequired() {
    return true;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();

    Logger.log(new LoggableInfo("Processing Product Light request with conversation Id: " + conversationId));
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
   
    List productList;
	AGIISSubscriberResults agiisResults = null;    
    try {
    	productList = getRequestedProductsFromRepository(inputDocument);
		IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
		long dealerAccountId = getAccountIdFromRequestOrByConvertingEBIDToAccountId(inputDocument, idPrincipal);
		String agiisCustomerId = otherSeedBrandsDao.getAgiisIdForDealer(dealerAccountId);
		
		Set brandsBasedOnDealer = getOtherSeedBrandsForDealer(dealerAccountId);
		if (brandsBasedOnDealer != null && !brandsBasedOnDealer.isEmpty()) {
		  agiisResults = agiisIsSubscriberProxy.checkIsSubscriberValid(agiisCustomerId);
	        if (agiisResults.isCustomerAbleToReceiveOtherSeedBrands()) {
	            productList.addAll(getRequestedProductsFromRepositoryForOtherSeedBrands(inputDocument, dealerAccountId));           
	        }
		}
		
    } catch (WrappingException e) {
      throw new ServiceException("Cannot process Product Light Version 2:" + e.getMessage());
    }

    XmlChunks outputXmlChunks = buildProductLightDocuments(productList, agiisResults);
    output.getXmlChunks().addChunks(outputXmlChunks);
    
    output.setConversationId(conversationId);

    return output;
  }

  private Set getOtherSeedBrandsForDealer(long dealerAccountId) {
    Set brandsBasedOnDealer = otherSeedBrandsDao.getOtherSeedBrandsForDealer(dealerAccountId);
    return brandsBasedOnDealer;
  }

  private long getAccountIdFromRequestOrByConvertingEBIDToAccountId(XmlDocument inputDocument,IdentityPrincipal identityPrincipal)
  	throws ServiceException {
	long accountId;
	XmlElement partnerIdAccountIdNode = inputDocument.selectElementByXPath(inputXmlMessageInformer.getXpathAccountId());
	XmlElement partnerIdEBIDNode = inputDocument.selectElementByXPath(inputXmlMessageInformer.getXpathEBusinessId());
	if (!XmlElement.NULL.equals(partnerIdAccountIdNode)) {
	  accountId = Long.parseLong(partnerIdAccountIdNode.getText());
	} else if (!XmlElement.NULL.equals(partnerIdEBIDNode)) {
	  String ebid = partnerIdEBIDNode.getText();
	  try {
		  accountId = idMapperDao.findAccountIdByEBID(ebid);
	  } catch (Exception e) {
		  String msg = "Error converting EBID Id: " + ebid + " to account id";
		  Logger.log(new LoggableInfo(msg));
		  throw new ServiceException(msg);
	  }
	} else
	  accountId = identityPrincipal.getAccountId();
	return accountId;
  }
  
  private List getRequestedProductsFromRepository(XmlDocument inputDocument) throws WrappingException {
    Date lastModifiedDate = getLastModifiedDateToFilterByFromInputDocument(inputDocument);
    String category = getCategoryToFilterByFromInputDocument(inputDocument);
    Set brands = getBrandsToFilterByFromInputDocument(inputDocument);
    Boolean activeFlag = getActiveFlagToFilterByFromInputDocument(inputDocument);
    return productLightDao.findProductsLightByDateCategoryBrand(lastModifiedDate, category, brands, activeFlag);
  }

  private List getRequestedProductsFromRepositoryForOtherSeedBrands(XmlDocument inputDocument, long accountId) throws WrappingException {
	Date lastModifiedDate = getLastModifiedDateToFilterByFromInputDocument(inputDocument);	  
	Set brandsForDealer = getOtherSeedBrandsForDealer(accountId);			
	Set brandsForDealerSinceLastDxDate = otherSeedBrandsDao.getOtherSeedBrandsForDealerSinceLastDXDate(accountId, lastModifiedDate);	
	String category = getCategoryToFilterByFromInputDocument(inputDocument);
	Boolean activeFlag = getActiveFlagToFilterByFromInputDocument(inputDocument);
	return productLightDao.findProductsLightByDateCategoryBrandForOtherSeedBrands(lastModifiedDate, category,
																				  brandsForDealer, brandsForDealerSinceLastDxDate, activeFlag);
  }  
  
  private XmlChunks buildProductLightDocuments(List productList, final AGIISSubscriberResults agiisSubscriberResults) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
   
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(productList, chunkSize,
        new XmlStreamListAppender() {
          public XmlStream buildXmlStream(List domainItems) {
            return productLightSerializer.buildProductLightDocument(domainItems, agiisSubscriberResults);
          }

        });

    return outputXmlChunks;
  }

  private Date getLastModifiedDateToFilterByFromInputDocument(XmlDocument inputDocument) {
    Date lastModifiedDate = null;

    try {
      String xpathFromDate = XPATH_REQUEST_PARMS + "/cidx:FromDateTime";
      String fromDateText = inputDocument.getNodeValueByXPath(xpathFromDate);
      lastModifiedDate = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(fromDateText);
    } catch (ParseException pe) {
      Logger.log(new LoggableWarning(pe.getMessage()));
    }

    return lastModifiedDate;
  }

  private String getCategoryToFilterByFromInputDocument(XmlDocument inputDocument) {
    String xpathCategory = buildAttributeNodeXpath("PrimaryProductSegmentCode");
    return inputDocument.getNodeValueByXPath(xpathCategory);
  }
 
  private Set getBrandsToFilterByFromInputDocument(XmlDocument inputDocument) {
    Set brands = new HashSet();

    String xpathBrandName = buildAttributeNodeXpath("BrandName");
    List brandNodes = inputDocument.selectElementsByXPath(xpathBrandName);
    for (Iterator itBrandNode = brandNodes.iterator(); itBrandNode.hasNext();) {
      XmlElement brandNode = (XmlElement) itBrandNode.next();
      String brand = brandNode.getText();
      if (StringUtils.isNotBlank(brand)) {
        brands.add(brand);
      }
    }

    return brands;
  }

  private Boolean getActiveFlagToFilterByFromInputDocument(XmlDocument inputDocument) {
    String xpathActiveFlag = buildAttributeNodeXpath("ProductInformationActiveFlag");
    String activeFlag = inputDocument.getNodeValueByXPath(xpathActiveFlag);

    if (ACTIVE_FLAG_TRUE.equals(activeFlag)) {
      return Boolean.TRUE;
    } else if (ACTIVE_FLAG_FALSE.equals(activeFlag)) {
      return Boolean.FALSE;
    } else {
      return null;
    }
  }

  private String buildAttributeNodeXpath(String attributeName) {
    return XPATH_REQUEST_PARMS + "/ecms:ProductFeatures/ecms:ProductAttribute[ecms:ProductAttributeName='"
        + attributeName + "']/ecms:ProductAttributeValue";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setProductLightDao(ProductLightDao productLightDao) {
    this.productLightDao = productLightDao;
  }
  

  public void setOtherSeedBrandsDao(OtherSeedBrandsDao otherSeedBrandsDao) {
	this.otherSeedBrandsDao = otherSeedBrandsDao;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setProductLightSerializer(ProductLightSerializer productLightSerializer) {
    this.productLightSerializer = productLightSerializer;
  }

	public void setAgiisIsSubscriberProxy(AGIISIsSubscriberProxy agiisIsSubscriberProxy) {
		this.agiisIsSubscriberProxy = agiisIsSubscriberProxy;
	}

	public void setIdMapperDao(IdMapperDao idMapperDao) {
		this.idMapperDao = idMapperDao;
	}  

}
