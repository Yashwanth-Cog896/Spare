/*
 * JdbcFarmManagerDao was created on May 26, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.object.MappingSqlQuery;

import com.monsanto.ag.cf.dao.FarmManagerDao;
import com.monsanto.ag.cf.domain.FarmManager;

/**
 * Spring JDBC implemenation of the FarmManager DAO.
 * 
 * @author caggarw
 * @version $Id: JdbcFarmManagerDao.java,v 1.6 2005-09-28 19:12:55 ggdavi Exp $
 */
public class JdbcFarmManagerDao extends BaseJdbcDao implements FarmManagerDao {

  /**
   * Maps the results from database queries to FarmManager objects.
   */
  public class FarmManagerMappingQuery extends MappingSqlQuery {
    private static final String FARM_MANAGER_SQL = "SELECT active_flag, sap_id, "
        + "short_name, addr_line_1, city, state_code, zip, acct_id, acct_role_code"
        + " FROM farm_manager_list_vw ORDER BY short_name";

    private FarmManagerMappingQuery() {
      super(getDataSource(), FARM_MANAGER_SQL);
      compile();
    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      FarmManager farmManager = new FarmManager(rs.getString("short_name"), rs
          .getLong("acct_id"), rs.getLong("sap_id"), rs
          .getString("addr_line_1"), rs.getString("city"), rs
          .getString("state_code"), rs.getString("zip"), rs
          .getString("acct_role_code"), FLAG_TRUE.equalsIgnoreCase(rs
          .getString("active_flag")));
      return farmManager;
    }

  }

  /**
   * @see com.monsanto.ag.cf.dao.FarmManagerDao#getFarmManagers()
   */
  public List getFarmManagers() {
    FarmManagerMappingQuery farmManagerQuery = new FarmManagerMappingQuery();
    return farmManagerQuery.execute();
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.5 2005/06/01 15:58:39 ajbaldw
 * made a change to the roles Revision 1.4 2005/05/31 17:32:06 ajbaldw flipped
 * the .equalsIgnorCase. Revision 1.3 2005/05/31 17:22:26 ajbaldw Changed to
 * reflect the Y/N Monsanto boolean convention.
 * 
 * Revision 1.2 2005/05/26 20:40:47 ggdavi Cleaned up imports and formatting
 * Revision 1.1 2005/05/26 20:30:31 caggarw Jdbc code for FarmManagerDao
 * 
 */