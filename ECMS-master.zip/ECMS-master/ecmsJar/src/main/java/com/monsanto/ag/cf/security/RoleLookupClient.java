package com.monsanto.ag.cf.security;

import javax.security.auth.login.LoginException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jun 1, 2010
 * Time: 2:48:30 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RoleLookupClient {
    String DEFAULT_ERROR_MESSAGE = "The security token could not be authorized";
    String REQUEST_ERROR_MESSAGE = "The authorization request cannot be completed at this time";

    javax.security.auth.Subject findRoles(String userId) throws LoginException;
}
