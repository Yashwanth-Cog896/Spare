/*
 * FarmsourcePopupServiceProxy was created on May 20, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.proxy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.domain.BroadcastMessage;
import com.monsanto.ag.cf.service.BroadcastMessageReader;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;

/**
 * Proxy for the Farmsource Popup Service.
 * 
 * @author Gareth Davies
 * @version $Id: FarmsourcePopupServiceProxy.java,v 1.4 2005/06/13 21:03:08
 *          ggdavi Exp $
 * @see SeedTrakInsourcingScope FC72
 */
public class FarmsourcePopupServiceProxy extends ServiceProxySupport implements
    BroadcastMessageReader {

  private static final String FARMSOURCE_APP_ID = "WS_BM";

  private String newMessagesServiceId;
  private String acknowledgementsServiceId;
  private XmlDocumentBuilder xmlDocumentBuilder;

  /**
   * @see com.monsanto.ag.cf.service.BroadcastMessageReader#getNewMessages(java.lang.String,
   *      java.lang.String)
   */
  public List getNewMessages(String userId, String seedYear) {
    Logger.log(new LoggableInfo("Getting new broadcast messages for user '"
        + userId + "' and seed year: " + seedYear));
    verifyGetNewMessagesInputParameters(userId, seedYear);
    XmlDocument inputDoc = buildGetNewMessagesInputDocument(userId, seedYear);
    XmlDocument outputDoc = getServiceResponse(newMessagesServiceId, inputDoc,
        "/popupidresponse/popup");

    List messages = getBroadcastMessagesFromOutputDocument(outputDoc);
    return messages;
  }

  private void verifyGetNewMessagesInputParameters(String userId,
      String seedYear) {
    if (StringUtils.isBlank(userId) || StringUtils.isBlank(seedYear)) {
      throw new ServiceException(BroadcastMessageReader.REQUEST_ERROR_MESSAGE);
    }
  }

  private XmlDocument buildGetNewMessagesInputDocument(String userId,
      String seedYear) {
    XmlDocument inputDoc = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = inputDoc.addRootElement("popupidrequest");

    rootElement.addChildElement("appdescr", FARMSOURCE_APP_ID);
    rootElement.addChildElement("user-id", userId);
    rootElement.addChildElement("seed-year", seedYear);

    return inputDoc;
  }

  private XmlDocument getServiceResponse(String serviceId,
      XmlDocument inputDoc, String xpathRepeatingElement) {
    try {
      ServiceInput input = new ServiceInput(inputDoc);
      ServiceOutput output = soaClient.call(serviceId, input);

      XmlChunks outputXmlChunks = output.getXmlChunks();
      outputXmlChunks.setXpathRepeatingElement(xpathRepeatingElement);
      XmlDocument outputDoc = outputXmlChunks
          .getXmlDocument(xmlDocumentBuilder);
      return outputDoc;
    } catch (ServiceException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException(BroadcastMessageReader.REQUEST_ERROR_MESSAGE);
    }
  }

  private List getBroadcastMessagesFromOutputDocument(XmlDocument outputDoc) {
    List messages = new ArrayList();

    Logger.log(new DebugLogEvent("GetNewMessages response document: "
        + outputDoc.toString()));
    if (XmlElement.NULL.equals(outputDoc
        .selectElementByXPath("/popupidresponse"))) {
      throw new ServiceException(BroadcastMessageReader.REQUEST_ERROR_MESSAGE);
    }

    List popupElements = outputDoc
        .selectElementsByXPath("/popupidresponse/popup");
    for (Iterator itPopup = popupElements.iterator(); itPopup.hasNext();) {
      XmlElement popupElement = (XmlElement) itPopup.next();

      String id = popupElement.getChild("id").getText();
      String title = popupElement.getChild("name").getText();
      String text = popupElement.getChild("message").getText();

      messages.add(new BroadcastMessage(id, title, text));
    }

    return messages;
  }

  /**
   * @see com.monsanto.ag.cf.service.BroadcastMessageReader#acknowledge(java.lang.String,
   *      java.util.List)
   */
  public void acknowledge(String userId, List receivedMessageIds) {
    Logger.log(new LoggableInfo(
        "Acknowledging received broadcast messages for user '" + userId
            + "' with Ids: " + receivedMessageIds));
    verifyAcknowledgeInputParameters(userId, receivedMessageIds);
    XmlDocument inputDoc = buildAcknowledgeInputDocument(userId,
        receivedMessageIds);
    XmlDocument outputDoc = getServiceResponse(acknowledgementsServiceId,
        inputDoc, "/popupvisitedresponse/*");

    Logger.log(new DebugLogEvent("Acknowledge response document: "
        + outputDoc.toString()));
    if (XmlElement.NULL.equals(outputDoc
        .selectElementByXPath("/popupvisitedresponse"))) {
      throw new ServiceException(BroadcastMessageReader.REQUEST_ERROR_MESSAGE);
    }
  }

  private void verifyAcknowledgeInputParameters(String userId,
      List receivedMessageIds) {
    if (StringUtils.isBlank(userId) || receivedMessageIds == null) {
      throw new ServiceException(BroadcastMessageReader.REQUEST_ERROR_MESSAGE);
    }
  }

  private XmlDocument buildAcknowledgeInputDocument(String userId,
      List receivedMessageIds) {
    XmlDocument inputDoc = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = inputDoc.addRootElement("popupvisitedrequest");

    XmlElement popupElement = rootElement.addChildElement("popup");
    for (Iterator itMessageId = receivedMessageIds.iterator(); itMessageId
        .hasNext();) {
      String messageId = (String) itMessageId.next();
      popupElement.addChildElement("id", messageId);
    }

    rootElement.addChildElement("user-id", userId);

    return inputDoc;
  }

  public void setNewMessagesServiceId(String popupIdServiceId) {
    this.newMessagesServiceId = popupIdServiceId;
  }

  public void setAcknowledgementsServiceId(String popupVisitedServiceId) {
    this.acknowledgementsServiceId = popupVisitedServiceId;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }
}

/*
 * $Log: not supported by cvs2svn $ Revision 1.9 2005/11/08 21:00:31
 * ggdavi Updated after adding XmlStream (and StAX implementation) to the
 * com.monsanto.ag.util package and refactoring the ServiceInput and
 * ServiceOutput classes to expose both XmlStream and XmlDocument objects
 * 
 * Revision 1.8 2005/08/23 17:12:48 ggdavi Moved ServiceInput and ServiceOutput
 * from ag.soa.client to ag.soa
 * 
 * Revision 1.7 2005/08/05 18:35:22 ggdavi SoaClient.call method now returns a
 * ServiceOutput object; use XmlDocument objects instead of DOM Document objects
 * (via injected xmlDocumentBuilder) Revision 1.6 2005/07/21 14:48:57 ggdavi
 * Fleshed out and refactored com.monsanto.ag.util to make more object-oriented,
 * in that most functionality has been pushed to the XmlDocument and XmlElement
 * objects
 * 
 * Revision 1.5 2005/06/15 15:48:46 ggdavi Added logging statements to
 * facilitate debugging Revision 1.4 2005/06/13 21:03:08 ggdavi Use
 * getDocumentElement instead of getFirstChild to get document root node
 * 
 * Revision 1.3 2005/05/23 18:22:55 ggdavi Added traceability javadoc
 * 
 * Revision 1.2 2005/05/23 15:34:26 ggdavi Renamed serviceId properties
 * 
 * Revision 1.1 2005/05/20 20:51:36 ggdavi Initial version
 * 
 */