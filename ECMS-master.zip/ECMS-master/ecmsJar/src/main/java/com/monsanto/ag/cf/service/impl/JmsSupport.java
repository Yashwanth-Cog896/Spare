/*
 * JmsSupport was created on Jul 8, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import org.springframework.jms.JmsException;
import org.springframework.jms.core.MessagePostProcessor;
import org.springframework.jms.core.support.JmsGatewaySupport;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.domain.Conversation;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;

import com.monsanto.ag.security.IdentityPrincipal;

/**
 * Provides convenience methods for services that produce or synchronously
 * consume JMS messages.
 * 
 * @author Gareth Davies
 * @version $Id: JmsSupport.java,v 1.12 2008-05-27 16:02:59 na1000app-ec Exp $
 */
public abstract class JmsSupport extends JmsGatewaySupport implements Identifiable {

  protected XmlDocumentBuilder xmlDocumentBuilder;
  protected IdTranslator idTranslator;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public abstract String getId();

  protected IdentityPrincipal getValidIdentityPrincipalFromSubject(Subject subject) {
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(idPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    }
    return idPrincipal;
  }

  protected void enqueueInputDocument(String destinationName, XmlDocument xmlDocument, Conversation conversation) {
    Logger.log(new LoggableInfo("Sending message to queue " + destinationName + " with attributes " + conversation));
    MessagePostProcessor postProcessor = new ConversationMessagePostProcessor(conversation);

    try {
      getJmsTemplate().convertAndSend(destinationName, xmlDocument, postProcessor);
    } catch (JmsException e) {
      throw new ServiceException("Unable to process " + getId() + " data at this time", e);
    }
  }

  protected XmlDocument buildAcknowledgementDocument(String conversationId, Subject subject) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement(CidxConstants.HEADER_NODE_NAME,
        XmlNamespace.NAMESPACE_CIDX_40, null);

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    return outputDocument;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.11  2006/05/08 14:11:10  caggarw
 * moved files from package jaxrpc into a common package called endpoint
 * Revision 1.10 2006/01/24 18:36:56 ggdavi Factored
 * out the ag.util.MessageParticant class from ag.security.IdentityPrincipal
 * (which delegates to it) so that the ag.xml.CidxDocumentHelper class no longer
 * depends on the ag.security package Revision 1.9 2005/12/01 19:34:30 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks
 * 
 * Revision 1.8 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.7 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.6 2005/08/24 16:48:34 ggdavi Added logging statements Revision 1.5
 * 2005/08/02 20:57:37 ggdavi Modified service interfaces, implementations and
 * advice to support message/document chunking
 * 
 * Revision 1.4 2005/07/25 20:58:45 ggdavi Moved setter methods together
 * 
 * Revision 1.3 2005/07/21 22:14:11 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations Revision 1.2 2005/07/21 14:48:57 ggdavi
 * Fleshed out and refactored com.monsanto.ag.util to make more object-oriented,
 * in that most functionality has been pushed to the XmlDocument and XmlElement
 * objects Revision 1.1 2005/07/14 21:27:31 ggdavi Renamed BaseMessageProducer
 * to JmsSupport Revision 1.4 2005/07/11 21:39:31 ggdavi Removed
 * Utilities.buildMemoryUsageMessage
 * 
 * Revision 1.3 2005/07/08 22:22:07 ggdavi Added call to
 * Utilities.buildMemoryUsageMessage in logDebugMessage Revision 1.2 2005/07/08
 * 20:57:51 ggdavi Added logDebugMessage method to
 * ConversationMessagePostProcessor to write the memory usage of the message to
 * the application log Revision 1.1 2005/07/08 17:04:24 ggdavi Initial version
 * 
 */