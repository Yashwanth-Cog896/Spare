/*
 * CustomerReviewDao was created on Aug 9, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import java.util.Date;
import java.util.List;

/**
 * Data Access Object for Customer Review.
 * 
 * @author Chetna Aggarwal
 * @version $Id: CustomerReviewDao.java,v 1.2 2008-07-02 20:23:08 dddoni Exp $
 */
public interface CustomerReviewDao {

  public List getCustomerInformation(long accountId, Date fromDate);
  public List getCustomerInformationFmgr(long accountId, Date fromDate);

}
