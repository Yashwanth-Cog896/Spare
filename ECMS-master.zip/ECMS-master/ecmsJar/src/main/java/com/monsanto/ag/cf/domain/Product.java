/*
 * Product was created on Jun 20, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.monsanto.ag.xml.XmlElement;

/**
 * Represents a commercial seed or chemical product (including packaging and
 * equipment).
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method. This XML
 * conforms to the AGIISProductUpdate element of the AGIISNamespacedSchema.xsd
 * XML schema document.
 * 
 * @author Gareth Davies
 * @version $Id: Product.java,v 1.1 2008-07-18 21:28:18 gjkell Exp $
 */
public abstract class Product extends AgiisEntity {

    public static final String SEGMENT_CHEMICAL = "Chemical";
    public static final String SEGMENT_SEED = "Seed";
    public static final String SEGMENT_ALL = "All";

    public static final String ACTIVE_EC_LIST_MATERIAL_FALSE = "Inactive";
    public static final String ACTIVE_EC_LIST_MATERIAL_TRUE = "Active";

    private String id;
    private List packagings;
    private boolean ecListMaterial;
    private ProductXmlElementBuilder xmlElementBuilder;

    protected Product() {

        super();

        this.packagings = new ArrayList();
        xmlElementBuilder = new ProductXmlElementBuilder();
    }

    protected Product( boolean ecListMaterial, boolean active, Date addedDate, Date lastModifiedDate, String id ) {

        super( active, addedDate, lastModifiedDate );

        this.ecListMaterial = ecListMaterial;
        this.packagings = new ArrayList();
        xmlElementBuilder = new ProductXmlElementBuilder();
    }

  /**
   * @see java.lang.Object#clone()
   */
    public Object clone() throws CloneNotSupportedException {

        Product clone = shallowCloneImplementation();

        clone.setEcListMaterial( this.ecListMaterial );
        Iterator itPackaging = packagings.iterator();
        while( itPackaging.hasNext() ) {

            Packaging packaging = ( Packaging ) itPackaging.next();
            clone.addPackaging( ( Packaging ) packaging.clone() );
        }
        return clone;
    }

    /**
     * Return a shallow clone of the implementation object.
     *
     * @return Clone of the implementation object without packagings
    */
    protected abstract Product shallowCloneImplementation();

    /**
     * @see com.monsanto.ag.ecg.domain.AgiisEntity#dispose()
     */
    public void dispose() {

        Iterator itPackaging = packagings.iterator();
        while ( itPackaging.hasNext() ) {

            Packaging packaging = ( Packaging ) itPackaging.next();
            packaging.dispose();
        }
        packagings.clear();

        super.dispose();
    }

    protected String getId() {

        return id;
    }

  /**
   * Adds information about a specific way of packaging this product to the list
   * of possibilities.
   * 
   * @param packaging
   *          Information about the packaging
   */
    public void addPackaging( Packaging packaging ) {

        if ( packaging != null ) {

            packagings.add( packaging );
        }
    }

    public List getPackagings() {

        return packagings;
    }

    public boolean isEcListMaterial(){

        return ecListMaterial;
    }

    public void setEcListMaterial( boolean ecListMaterial ){

        this.ecListMaterial = ecListMaterial;
    }

    /**
     * @see com.monsanto.ag.ecg.domain.AgiisEntity#appendXmlToElement(com.monsanto.ag.util.XmlElement)
     */
    public void appendXmlToElement( XmlElement baseXmlElement ) {

        xmlElementBuilder.appendXmlToElement( this, baseXmlElement );
    }

    /**
     * Add product type-specific child elements to the ProductInformation element.
     *
     * @param rootElement
     *          ProductInformation element
     */
    protected abstract void addTypeSpecificChildElements( XmlElement rootElement );
  
    /**
     * Gets the AGIIS-compliant identifier for this product.
     *
     * @return AGIIS-compliant product identifier
     */
    protected abstract String getAGIISIdentifier();
  
    /**
     * Gets the AGIIS-compliant name for this product.
     *
     * @return AGIIS-compliant product name
     */
    protected abstract String getAGIISName();

    public boolean equals( Object obj ) {

        if ( !( obj instanceof Product ) ) {

            return false;
        }
        Product rhs = ( Product ) obj;

        return new EqualsBuilder()
                   .appendSuper( super.equals( obj ) )
                   .append( id, rhs.id )
                   .append( packagings, rhs.packagings )
                   .append( ecListMaterial, rhs.ecListMaterial )
                   .isEquals();
    }

    public int hashCode() {

        return new HashCodeBuilder( 17, 3 )
                   .appendSuper( super.hashCode() )
                   .append( id )
                   .append( packagings )
                   .append( ecListMaterial )
                   .hashCode();
    }

    public String toString() {

        return new ReflectionToStringBuilder( this ).toString();
    }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.14  2005/12/01 19:55:37  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.13  2005/08/26 16:31:37  ggdavi
 * Javadoc corrections
 *
 * Revision 1.12  2005/08/19 15:14:34  ggdavi
 * Modified to support different types of products
 * Revision 1.11 2005/08/05 23:00:15 ggdavi Fixed
 * ProductName, ProductTreament values Revision 1.10 2005/07/28 15:47:50 ggdavi
 * Added ActionRequest attribute to various Product document elements; mapped
 * the PackageLevelCode and CheckDigit elements to the GTIN database column;
 * only send one error email per ProductUpdate document, containing all
 * product-specific errors Revision 1.9 2005/07/21 22:23:39 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations; enhanced and refactored XML abstraction
 * in com.monsanto.ag.util Revision 1.8 2005/07/05 19:35:28 ggdavi Now extends
 * AgiisEntity instead of implementing ExtractXML, which enforces use of
 * XmlDocumentBuilder implementations to generate the XML, as well as providing
 * clone and dispose methods Revision 1.7 2005/06/30 21:31:23 ggdavi Use
 * node.getOwnerDocument instead of helper.getDocument(node)
 * 
 * Revision 1.6 2005/06/30 16:44:04 ggdavi Modified insertXml so that it simply
 * adds elements to the baseElement parameter, rather than importing the
 * Document node from the toXML method Revision 1.5 2005/06/29 21:48:21 ggdavi
 * Modified crop description of "sudangrass" to "Sudangrass"
 * 
 * Revision 1.4 2005/06/27 22:02:11 ggdavi Tweaks in an effort to hit the moving
 * anaysis target... Revision 1.3 2005/06/22 21:53:59 ggdavi Moved
 * AgiisDocumentHelper from ag.ecg.domain to ag.util Revision 1.2 2005/06/22
 * 17:21:48 ggdavi Added packagings field and addPackaging method Revision 1.1
 * 2005/06/20 20:11:52 ggdavi Initial version
 * 
 */