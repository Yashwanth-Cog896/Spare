package com.monsanto.ag.cf.service.impl;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.TextTools;
import com.monsanto.ag.cf.dao.InventoryReportingDao;
import com.monsanto.ag.cf.domain.AppConstants;
import com.monsanto.ag.cf.domain.InventoryDetails;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.UOMConverter;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.*;

import javax.security.auth.Subject;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * POJO Implementation of the InventoryReporting web service.
 *
 * @version $Id: InventoryReportingImpl.java,v 1.4 2008-08-06 22:49:40 mkuchip Exp $
 */

public class InventoryReportingImpl implements SecureService, Identifiable {

    private InventoryReportingDao inventoryReportingDao;

    //Inventory Partners Attributes
    private static final String OWNER_ID_ATTRIBUTE_NAME = "OwnerID";
    private static final String OWNER_QUALIFIER_ATTRIBUTE_NAME = "OwnerQual";
    //Inventory Detail Attributes
    private static final String PHYSICAL_COUNT_IND_ATTRIBUTE_NAME = "PhysicalCountIND";
    private static final String PRODUCT_UOM_ATTRIBUTE_NAME = "ProductUOM";
    private static final String LOCATION_QUALIFIER_ATTRIBUTE_NAME = "LocationQual";
    private static final String LOCATION_ID_ATTRIBUTE_NAME = "LocationID";
    private static final String GTIN_ATTRIBUTE_NAME = "GTIN";
    private static final String AS_OF_DATE_ATTRIBUTE_NAME = "AsOFDate";
    private static final String QUANTITY_ATTRIBUTE_NAME = "Quantity";
    private static final String LOT_NUMBER_ATTRIBUTE_NAME = "LotNumber";
    private static final String AGENCY_ATTRIBUTE_NAME = "Agency";
    private static final String SOLDNOTDEL_ATTRIBUTE_NAME = "SoldNotDel";
    private static final String DATECHANGED_ATTRIBUTE_NAME = "DateChanged";

    private static final String XPATH_REQUEST_PARMS_CIDX_HEADER = "/ecms:InventoryMobile/cidx:Header";
    private static final String XPATH_REQUEST_PARMS_INVENTORY_PARTNERS = "/ecms:InventoryMobile/ecms:InventoryPartners";
    private static final String XPATH_REQUEST_PARMS_INVENTORY_DETAILS = "/ecms:InventoryMobile/ecms:InventoryDetails";
    private static final String XPATH_REQUEST_PARMS_INVENTORY_DETAIL = XPATH_REQUEST_PARMS_INVENTORY_DETAILS + "/ecms:InventoryDetail";
    //CIDX Header From To Details
    private static final String XPATH_CIDX_HEADER_DOC_IDENTIFIER = XPATH_REQUEST_PARMS_CIDX_HEADER + "/cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier";
    private static final String XPATH_CIDX_HEADER_DOC_DATE_TIME = XPATH_REQUEST_PARMS_CIDX_HEADER + "/cidx:ThisDocumentDateTime/cidx:DateTime";
    private static final String XPATH_CIDX_HEADER_FROM_PARTNER_NAME = XPATH_REQUEST_PARMS_CIDX_HEADER + "/cidx:From/cidx:PartnerInformation/cidx:PartnerName";
    private static final String XPATH_CIDX_HEADER_FROM_PARTNER_IDENTIFIER = XPATH_REQUEST_PARMS_CIDX_HEADER + "/cidx:From/cidx:PartnerInformation/cidx:PartnerIdentifier";

    //Data Source and Software Version, OwerName XPath
    private static final String XPATH_FROM_CONTACT_INFORMATION_FOR_DS_SV = XPATH_REQUEST_PARMS_CIDX_HEADER + "/cidx:From/cidx:PartnerInformation/cidx:ContactInformation";
    private static final String XPATH_INVENTORYPARTNERS_OWNERNAME = XPATH_REQUEST_PARMS_INVENTORY_PARTNERS + "/ecms:OwnerName";

    private XmlDocumentBuilder xmlDocumentBuilder;
    private XmlMessageInformer inputXmlMessageInformer;
    private XmlMessageInformer outputXmlMessageInformer;
    private String conversationId = null;

    /**
     * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
     *      javax.security.auth.Subject)
     */
    public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
        ServiceOutput output = new ServiceOutput();
        conversationId = Utilities.generateConversationId();
        output.setConversationId(conversationId);
        Logger.log(new LoggableInfo("Processing inventory reporting request with conversation Id: " + conversationId));

        XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
        List inventoryListForDao = getInventoryReportingDetailsFromInputDocument(inputDocument);

        try {
            int storeStatus = inventoryReportingDao.storeInventoryReportingDetails(inventoryListForDao);
            Logger.log(new LoggableInfo("Number of Records Inserted/Insert Status in Inventory Reporting Impl Service = " + storeStatus));
        } catch (SQLException sqe) {
            Logger.log(new LoggableInfo("Database Exception:" + sqe.getMessage()));
            throw new ServiceException("Database Exception:" + sqe.getMessage());
        }
        output.getXmlChunks().addChunk(buildInventoryReportingResponseDocument());
        return output;
    }

    public boolean isValidationRequired() {
        return true;
    }

    private XmlDocument buildInventoryReportingResponseDocument() {
        XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
        XmlNamespace xmlNamespace = new XmlNamespace("ecms", "urn:ecms:schema:inventory:response:1:0");
        XmlElement xmlElement = outputDocument.addRootElement("InventoryReportingResponse", xmlNamespace, "1.0");
        xmlElement.addChildElement("Status", "Success");
        return outputDocument;
    }

    private List getInventoryReportingDetailsFromInputDocument(XmlDocument inputDocument) {
        InventoryDetails inventoryDetails = null;
        UOMConverter converter = new UOMConverter();
        List InventoryDomainsList = new ArrayList();

        //Get All element and attribute values from input xml document
        String ownerName = getTextValueForXQueryPath(inputDocument, XPATH_INVENTORYPARTNERS_OWNERNAME);
        ownerName = getTruncatedValue(ownerName, 30);
        String ownerId = getInventoryDetailOrPartnersAttributeValue(inputDocument, XPATH_REQUEST_PARMS_INVENTORY_PARTNERS, OWNER_ID_ATTRIBUTE_NAME);
        ownerId = getTruncatedValue(ownerId, 25);
        String ownerQualifier = getInventoryDetailOrPartnersAttributeValue(inputDocument, XPATH_REQUEST_PARMS_INVENTORY_PARTNERS, OWNER_QUALIFIER_ATTRIBUTE_NAME);
        String docIdentifier = getTextValueForXQueryPath(inputDocument, XPATH_CIDX_HEADER_DOC_IDENTIFIER);
        String docDateTime = getTextValueForXQueryPath(inputDocument, XPATH_CIDX_HEADER_DOC_DATE_TIME);
        String fromPartnerName_ReporterName = getTextValueForXQueryPath(inputDocument, XPATH_CIDX_HEADER_FROM_PARTNER_NAME);
        fromPartnerName_ReporterName = getTruncatedValue(fromPartnerName_ReporterName, 30);
        String fromPartnerIdentifier_ReporterId = getTextValueForXQueryPath(inputDocument, XPATH_CIDX_HEADER_FROM_PARTNER_IDENTIFIER);
        fromPartnerIdentifier_ReporterId = getTruncatedValue(fromPartnerIdentifier_ReporterId, 25);
        String fromPartnerAgencyName = getInventoryDetailOrPartnersAttributeValue(inputDocument, XPATH_CIDX_HEADER_FROM_PARTNER_IDENTIFIER, AGENCY_ATTRIBUTE_NAME);

        //Iterate Contact Information from CIDX header for Data Source n Software Version
        List ContactInfListForDataSourcSoftVer = inputDocument.selectElementsByXPath(XPATH_FROM_CONTACT_INFORMATION_FOR_DS_SV);
        XmlElement dataSource = (XmlElement) ContactInfListForDataSourcSoftVer.get(0);
        String dataSourceAttribute = dataSource.getChild("cidx:ContactDescription").getText();
        String dataSourceValue = dataSource.getChild("cidx:ContactName").getText();
        String fileName = generateFileName(dataSourceValue);

        // If OwnerID is NULL, set OwnerID = Reporter ID,If Owner Name is NULL, set Owner Name = Reporter Name
        if (TextTools.isEmpty(ownerId))
            ownerId = fromPartnerIdentifier_ReporterId;
        if (TextTools.isEmpty(ownerName))
            ownerName = fromPartnerName_ReporterName;
        if (TextTools.isEmpty(ownerQualifier))
            ownerQualifier = fromPartnerAgencyName;

        Logger.log(new LoggableInfo("From Partner Name_Reporter Name=" + fromPartnerName_ReporterName + " ,From Partner Identifier_Reporter Id=" + fromPartnerIdentifier_ReporterId + " ,From Partner Agency Name_Reporter Qualifier=" + fromPartnerAgencyName + " ,Owner Id=" + ownerId + " ,Owner Name=" + ownerName + ", Owner Qualifier=" + ownerQualifier));
        Logger.log(new LoggableInfo("Document Identifier=" + docIdentifier + " ,Document Date Time=" + docDateTime + " ,Data Source Attribute=" + dataSourceAttribute + " ,Data Source Value=" + dataSourceValue + " ,File Name=" + fileName));

        //Iterate Inventory Details
        List inventoryDetailList = inputDocument.selectElementsByXPath(XPATH_REQUEST_PARMS_INVENTORY_DETAIL);
        for (Iterator inventoryDetailNode = inventoryDetailList.iterator(); inventoryDetailNode.hasNext();) {
            inventoryDetails = new InventoryDetails();

            XmlElement inventoryDetail = (XmlElement) inventoryDetailNode.next();
            String locationName = inventoryDetail.getChild("LocationName").getText();
            locationName = getTruncatedValue(locationName, 30);
            String physicalCountInd = inventoryDetail.getAttributeValue(PHYSICAL_COUNT_IND_ATTRIBUTE_NAME);
            String productUOM = inventoryDetail.getAttributeValue(PRODUCT_UOM_ATTRIBUTE_NAME);
            String locationQualifier = inventoryDetail.getAttributeValue(LOCATION_QUALIFIER_ATTRIBUTE_NAME);
            String locationId = inventoryDetail.getAttributeValue(LOCATION_ID_ATTRIBUTE_NAME);
            locationId = getTruncatedValue(locationId, 25);
            String GTIN = inventoryDetail.getAttributeValue(GTIN_ATTRIBUTE_NAME);
            GTIN = getTruncatedValue(GTIN, 14);
            String asOfDate = inventoryDetail.getAttributeValue(AS_OF_DATE_ATTRIBUTE_NAME);
            String quantity = inventoryDetail.getAttributeValue(QUANTITY_ATTRIBUTE_NAME);
            String lotNumber = inventoryDetail.getAttributeValue(LOT_NUMBER_ATTRIBUTE_NAME);
            lotNumber = getTruncatedValue(lotNumber, 12);

            // If LocationID is NULL, set LocationID = Reporter ID, If Location Name is NULL, set Location Name = Reporter Name
            if (TextTools.isEmpty(locationId))
                locationId = fromPartnerIdentifier_ReporterId;
            if (TextTools.isEmpty(locationName))
                locationName = fromPartnerName_ReporterName;
            if (TextTools.isEmpty(locationQualifier))
                locationQualifier = fromPartnerAgencyName;

            //Product UOM Converter and  parse the date
            Date dateAsOfDate = null;
            try {
                productUOM = converter.findIRDCode(productUOM);
                dateAsOfDate = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(asOfDate);
            } catch (ParseException pe) {
                Logger.log(new LoggableInfo("As Of Date Parsing Exception : " + pe.getMessage()));
                throw new ServiceException("As Of Date Parsing Exception : " + pe.getMessage());
            } catch (Exception e) {
                Logger.log(new LoggableInfo("UOM Converter Exception:" + e.getMessage()));
                throw new ServiceException("UOM Converter Exception:" + e.getMessage());
            }

            //Logger.log(new LoggableInfo("Date AsOfDate = "+dateAsOfDate+" ,Owner Id = "+ownerId+" ,Owner Qualifier = "+ownerQualifier+" ,Owner Name = "+ownerName+" ,Location Name = "+locationName+" ,Physical Count Ind = "+physicalCountInd+" ,Product UOM = "+productUOM+" ,Location Qualifier = "+locationQualifier+" ,Location Id = "+locationId+" ,GTIN = "+GTIN+" ,AsOfDate = "+asOfDate+" ,Quantity = "+quantity+" ,Lot Number = "+lotNumber));

            //Set values to Inventory Object
            inventoryDetails.setFileName(fileName);
            inventoryDetails.setCustomerType(AppConstants.CUST_TYPE_ST_TYPE);
            inventoryDetails.setReportType(AppConstants.REPORT_TYPE);
            inventoryDetails.setDsType(AppConstants.DS_TYPE);
            inventoryDetails.setSfType(AppConstants.SF_TYPE);
            inventoryDetails.setInvoiceDateQualifier(AppConstants.INVOICE_DATE_QUALIFIER);
            inventoryDetails.setShipDateQualifier(AppConstants.SHIP_DATE_QUALIFIER);
            inventoryDetails.setTransactionStatus(AppConstants.TRANSACTION_STATUS);
            inventoryDetails.setConversationId(conversationId);
            inventoryDetails.setReporterIdQualifier(getQualifierIdForQualName(fromPartnerAgencyName));
            inventoryDetails.setReporterId(fromPartnerIdentifier_ReporterId);
            inventoryDetails.setReporterName(fromPartnerName_ReporterName);
            inventoryDetails.setDataSource(dataSourceValue.toUpperCase());
            inventoryDetails.setOwnerId(ownerId);
            inventoryDetails.setOwnerQualifier(getQualifierIdForQualName(ownerQualifier));
            inventoryDetails.setOwnerName(ownerName);
            inventoryDetails.setLocationId(locationId);
            inventoryDetails.setLocationQualifier(getQualifierIdForQualName(locationQualifier));
            inventoryDetails.setLocationName(locationName);
            inventoryDetails.setAsOfDate(dateAsOfDate);
            inventoryDetails.setGTINQualifier(AppConstants.LINE_ID_QUAL_FOR_GTIN);
            inventoryDetails.setGTIN(GTIN);
            inventoryDetails.setQuantity(getQuantityWithNoSign(quantity));
            inventoryDetails.setQuantityQualifier(getQuantityQualifier(quantity));
            inventoryDetails.setOrderType(getOrderTypeForQuantity(quantity));
            inventoryDetails.setProductUOM(productUOM);
            inventoryDetails.setPhysicalCountIND(translateToYN(physicalCountInd));
            inventoryDetails.setLotNumber(lotNumber);
            inventoryDetails.setDateChanged(extractDateChanged(inventoryDetail));
            inventoryDetails.setSoldNotDelivered(inventoryDetail.getAttributeValue(SOLDNOTDEL_ATTRIBUTE_NAME));

            InventoryDomainsList.add(inventoryDetails);
        }
        return InventoryDomainsList;
    }

    private Date extractDateChanged(XmlElement inventoryDetail) {
        Date dateChanged_SoldNotDeliveredAsOfDate = null;
        try {
            dateChanged_SoldNotDeliveredAsOfDate = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(
                    inventoryDetail.getAttributeValue(DATECHANGED_ATTRIBUTE_NAME));
        } catch (ParseException pe) {
            Logger.log(new LoggableInfo("DateChanged Parsing Exception : " + pe.getMessage()));
            throw new ServiceException("DateChanged Parsing Exception : " + pe.getMessage());
        }
        return dateChanged_SoldNotDeliveredAsOfDate;
    }

    private String getTruncatedValue(String strOriginal, int requiredLength) {
        String strModified = strOriginal;
        if (strOriginal != null && strOriginal != " " && strOriginal != "")
            if (strOriginal.length() >= requiredLength) {
                strModified = strOriginal.substring(0, requiredLength);
            }
        return strModified;
    }

    private String getQuantityWithNoSign(String quantity) {
        String quantityNoSign = null;
        if (quantity.startsWith("-"))
            quantityNoSign = quantity.substring(1);
        else
            quantityNoSign = quantity;

        return quantityNoSign;
    }

    private String translateToYN(String physicalCountInd) {
        if (physicalCountInd.equals("true"))
            physicalCountInd = "Y";
        else
            physicalCountInd = "N";

        return physicalCountInd;
    }

    private String generateFileName(String dataSourceValue) {
        //  Generate File Name (Data Source_Date_Time)
        SimpleDateFormat sdfForyyyyMMdd = new SimpleDateFormat("yyyyMMdd");
        String yyyyMMdd = sdfForyyyyMMdd.format(new java.util.Date());
        SimpleDateFormat sdfForHHmmss = new SimpleDateFormat("HHmmss");
        String HHmmss = sdfForHHmmss.format(new java.util.Date());
        return dataSourceValue.toUpperCase() + "_" + yyyyMMdd + "_" + HHmmss;
    }

    private String getOrderTypeForQuantity(String quantity) {
        String orderType = null;
        double dblQty = Double.parseDouble(quantity);
        if (dblQty >= 0)
            orderType = AppConstants.ZERO_POSITIVE_QTY_VAL_ORDER_TYPE;
        else
            orderType = AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE;

        return orderType;
    }

    private String getQuantityQualifier(String quantity) {
        String quantityQualifier = null;
        double dblQty = Double.parseDouble(quantity);
        if (dblQty >= 0)
            quantityQualifier = AppConstants.ZERO_POSITIVE_VAL_QTY_QUALIFIER;
        else
            quantityQualifier = AppConstants.NEGATIVE_VAL_QTY_QUALIFIER;

        return quantityQualifier;
    }

    private String getQualifierIdForQualName(String ownerQualifier) {
        String qualifierId = null;
        if (ownerQualifier.equalsIgnoreCase(AppConstants.QUALIFIER_NAME_FOR_AGIIS_EBID))
            qualifierId = AppConstants.QUALIFIER_ID_FOR_AGIIS_EBID;
        else if (ownerQualifier.equalsIgnoreCase(AppConstants.QUALIFIER_NAME_AGIIS_NAPD))
            qualifierId = AppConstants.QUALIFIER_ID_AGIIS_NAPD;
        else if (ownerQualifier.equalsIgnoreCase(AppConstants.QUALIFIER_NAME_AssignedByBuyer))
            qualifierId = AppConstants.QUALIFIER_ID_AssignedByBuyer;
        else if (ownerQualifier.equalsIgnoreCase(AppConstants.QUALIFIER_NAME_AssignedBySeller))
            qualifierId = AppConstants.QUALIFIER_ID_AssignedBySeller;

        return qualifierId;
    }

    private String getTextValueForXQueryPath(XmlDocument inputDocument, String xPathForValExtraction) {
        XmlElement xmlElementTag = inputDocument.selectElementByXPath(xPathForValExtraction);
        return xmlElementTag.getText();
    }

    private String getInventoryDetailOrPartnersAttributeValue(XmlDocument inputDocument, String XQueryPath, String attributeName) {
        XmlElement invRepPartnersXmlTag = inputDocument.selectElementByXPath(XQueryPath);
        return invRepPartnersXmlTag.getAttributeValue(attributeName);
    }

    /*public XmlDocumentBuilder getXmlDocumentBuilder() {
      return xmlDocumentBuilder;
    }*/

    public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
        this.xmlDocumentBuilder = xmlDocumentBuilder;
    }

    /**
     * @see com.monsanto.ag.util.Identifiable#getId()
     */
    public String getId() {
        return "INV";
    }

    public XmlMessageInformer getInputXmlMessageInformer() {
        return inputXmlMessageInformer;
    }

    public void setInputXmlMessageInformer(
            XmlMessageInformer inputXmlMessageInformer) {
        this.inputXmlMessageInformer = inputXmlMessageInformer;
    }

    public XmlMessageInformer getOutputXmlMessageInformer() {
        return outputXmlMessageInformer;
    }

    public void setOutputXmlMessageInformer(
            XmlMessageInformer outputXmlMessageInformer) {
        this.outputXmlMessageInformer = outputXmlMessageInformer;
    }

    public XmlMessageInformer getXmlMessageInformer() {
        return null;
    }

    public InventoryReportingDao getInventoryReportingDao() {
        return inventoryReportingDao;
    }

    public void setInventoryReportingDao(InventoryReportingDao inventoryReportingDao) {
        this.inventoryReportingDao = inventoryReportingDao;
    }
}
