package com.monsanto.ag.cf.dao;

import com.monsanto.ag.cf.domain.SeedProduct;
import com.monsanto.ag.xml.XmlElement;

import java.util.Date;

/**
 * Created by jtmurr on 4/21/2015.
 */
public class SeedTreatmentProduct extends SeedProduct {
    public static final String SEED_TREATMENT_DESCRIPTION = "Class A Seed Treatment";

    public SeedTreatmentProduct(boolean ecListMaterial, boolean active, Date addedDate,
                                Date lastModifiedDate, String id, String brand, String variety,
                                String biotechTrait, String treatmentCode, String treatmentDesc, String traits,
                                String speciesCode, boolean licenseRequired, int licenseTraitGroup,
                                boolean insectResistanceManagement) {
        super(ecListMaterial, active, addedDate, lastModifiedDate, id, brand, variety, biotechTrait, treatmentCode,
                treatmentDesc, traits, speciesCode, licenseRequired, licenseTraitGroup, insectResistanceManagement);
        primaryProductSegmentCode = "Other";
    }

    @Override
    protected void addTypeSpecificChildElements(XmlElement rootElement) {
        primaryProductSegmentCode = "Other";
        super.addTypeSpecificChildElements(rootElement);
    }

    @Override
    protected void setSpeciesCode(String speciesCode) {
        super.setSpeciesCode("O");
    }

    @Override
    public String getCropDescription() {
        return SEED_TREATMENT_DESCRIPTION;
    }

    @Override
    protected void setVariety(String variety) {
        this.variety = variety;
    }

    @Override
    protected void setTreatmentCode(String treatmentCode) {
        this.treatmentCode = treatmentCode;
    }
}
