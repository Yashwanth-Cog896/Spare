/*
 * UserActivityIncompleteException was created on Mar 29, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

/**
 * Thrown if a UserActivity object does not contain all required user activity
 * information.
 * 
 * @author Gareth Davies
 * @version $Id: UserActivityIncompleteException.java,v 1.3 2005-04-13 16:28:37 ggdavi Exp $
 */
public class UserActivityIncompleteException extends RuntimeException {

  public UserActivityIncompleteException(String message) {
    super(message);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/04/08 18:09:49  ggdavi
 * Renamed UserActivityIncompleteException to UserActivityIncompleteException
 *
 * Revision 1.3  2005/04/01 16:41:04  ajbaldw
 * Moved UserActivityIncompleteException to ag/cf/logging package.
 *
 * Revision 1.1  2005/03/29 23:08:27  ggdavi
 * Moved from logging to domain
 *
 * Revision 1.1  2005/03/29 20:03:33  ggdavi
 * Initial version
 *
 */