package com.monsanto.ag.cf.dao;

import com.monsanto.ag.cf.domain.InventoryDetails;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;

/**
 * Created by JTMURR on 10/12/2016.
 */
public class InventoryPreparedStatementBuilder {
    public void prepare(PreparedStatement ps, InventoryDetails inventoryDetail) throws SQLException {
        ps.setString(1, inventoryDetail.getFileName());
        ps.setString(2, inventoryDetail.getCustomerType());
        ps.setString(3, inventoryDetail.getReportType());
        ps.setString(4, inventoryDetail.getDsType());
        ps.setString(5, inventoryDetail.getSfType());
        ps.setString(6, inventoryDetail.getInvoiceDateQualifier());
        ps.setString(7, inventoryDetail.getShipDateQualifier());
        ps.setString(8, inventoryDetail.getTransactionStatus());
        ps.setString(9, inventoryDetail.getConversationId());
        ps.setString(10, inventoryDetail.getReporterIdQualifier());
        ps.setString(11, inventoryDetail.getReporterId());
        ps.setString(12, inventoryDetail.getReporterName());
        ps.setString(13, inventoryDetail.getDataSource());
        ps.setString(14, inventoryDetail.getOwnerId());
        ps.setString(15, inventoryDetail.getOwnerQualifier());
        ps.setString(16, inventoryDetail.getOwnerName());
        ps.setString(17, inventoryDetail.getLocationId());
        ps.setString(18, inventoryDetail.getLocationQualifier());
        ps.setString(19, inventoryDetail.getLocationName());
        ps.setTimestamp(20, new Timestamp(inventoryDetail.getAsOfDate().getTime()));
        ps.setString(21, inventoryDetail.getGTINQualifier());
        ps.setString(22, inventoryDetail.getGTIN());
        ps.setString(23, inventoryDetail.getQuantity());
        ps.setString(24, inventoryDetail.getQuantityQualifier());
        ps.setString(25, inventoryDetail.getOrderType());
        ps.setString(26, inventoryDetail.getProductUOM());
        ps.setString(27, inventoryDetail.getPhysicalCountIND());
        ps.setString(28, inventoryDetail.getLotNumber());
        ps.setString(29, inventoryDetail.getSoldNotDelivered());
        setCommitAsOfDate(ps, inventoryDetail);
    }

    private void setCommitAsOfDate(PreparedStatement ps, InventoryDetails inventoryDetail) throws SQLException {
        if (inventoryDetail.getDateChanged() == null) {
            ps.setNull(30, Types.TIMESTAMP);
        } else {
            ps.setTimestamp(30, new Timestamp(inventoryDetail.getDateChanged().getTime()));
        }
    }
}
