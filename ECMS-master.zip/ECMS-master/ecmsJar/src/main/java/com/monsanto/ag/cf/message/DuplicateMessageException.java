/*
 * DuplicateMessageException was created on May 10, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message;

/**
 * Represents the case where a duplicate message has been received, presumably
 * when not desired.
 * 
 * @author Gareth Davies
 * @version $Id: DuplicateMessageException.java,v 1.1 2005-06-30 17:43:26 ggdavi Exp $
 */
public class DuplicateMessageException extends RuntimeException {

  public DuplicateMessageException(String message) {
    super(message);
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/11 19:20:48  ggdavi
 * Initial version
 *
 */