package com.monsanto.ag.cf.security;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.RolePrincipal;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocument;
import org.w3c.dom.Document;

import javax.security.auth.Subject;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;
import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: May 28, 2010
 * Time: 12:08:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class RoleLookupClientImpl extends ServiceProxySupport implements RoleLookupClient {

    private XmlDocumentBuilder xmlDocumentBuilder;
    private IdTranslator idTranslator;

    private static final String AUTH_RESPONSE_NAMESPACE = "ns2:";
    private static final String AUTH_REQUEST_NAMESPACE = "";

    private static final String XPATH_SOAP_WRAPPER = "/soapenv:Envelope/soapenv:Body";
    private static final String XPATH_SOAP_FAULT = XPATH_SOAP_WRAPPER + "/soapenv:Body/S:Fault/detail";
    private static final String NODE_AUTH_RESPONSE = AUTH_RESPONSE_NAMESPACE + "GetAuthorizationResponse";
    private static final String NODE_AUTH_RESPONSE_BODY = AUTH_RESPONSE_NAMESPACE + "GetAuthorizationResponseBody";

    private static final String TAG_AUTH_RESPONSE_FAULT = AUTH_RESPONSE_NAMESPACE + "AuthorizationFault";
    private static final String TAG_AUTH_RESPONSE_FAULT_CODE = AUTH_RESPONSE_NAMESPACE + "faultCode";
    private static final String TAG_AUTH_RESPONSE_FAULT_MESSAGE = AUTH_REQUEST_NAMESPACE + "faultMessage";

    private static final String NODE_ACCT_ID = AUTH_RESPONSE_NAMESPACE + "AcctID";
    private static final String NODE_SAP_ID = AUTH_RESPONSE_NAMESPACE + "SapId";
    private static final String NODE_EB_ID = AUTH_RESPONSE_NAMESPACE + "EbId";
    private static final String NODE_ACCT_NAME = AUTH_RESPONSE_NAMESPACE + "AcctName";
    private static final String TAG_ROLES = AUTH_RESPONSE_NAMESPACE + "Roles";

    public javax.security.auth.Subject findRoles(String userId) throws LoginException {

        Logger.log(new LoggableInfo("Authorizing user " + userId
                + " with authorization service"));
        verifyCredentialsPresent(userId);
        XmlDocument authDoc = getAuthenticatorServiceResponseDocument(userId);
        Subject subject = buildSubjectFromServiceResponse(authDoc, userId);

        Logger.log(new LoggableInfo("Returning subject"));

        return subject;
    }

    private void verifyCredentialsPresent(String userId)
            throws FailedLoginException {
        if (userId == null) {
            Logger.log(new LoggableWarning("No credentials passed to loginUser"));
            throw new FailedLoginException(DEFAULT_ERROR_MESSAGE);
        }
    }

    private XmlDocument getAuthenticatorServiceResponseDocument(String userId) throws LoginException {
        try {
            XmlDocument inputDoc = buildInputDocument(userId);
            ServiceInput input = new ServiceInput(inputDoc);

            ServiceOutput output = soaClient.call(serviceId, input);

            XmlDocument outputDoc = XmlDocument.NULL;
            XmlChunks outputXmlChunks = output.getXmlChunks();
            if (!outputXmlChunks.isEmpty()) {
                outputDoc = outputXmlChunks.getXmlDocumentChunk(xmlDocumentBuilder, 0);
            }

            return outputDoc;
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log(new LoggableWarning("The user " + userId + " could not be authorized"));
            Logger.log(new LoggableWarning("Message: " + e.getMessage()));
            throw new LoginException(DEFAULT_ERROR_MESSAGE);
        }
    }

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private static final String TIME_FORMAT = "HH:mm:ss";

    private static String currentTime() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(TIME_FORMAT);
        return sdf.format(cal.getTime());
    }

    private static String currentDate() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.format(cal.getTime());
    }


    private XmlDocument buildInputDocument(String userId) throws IOException, ParserException {

        String timestamp = currentDate() + "T" + currentTime();

        String message =
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                        "   <soapenv:Header/>\n" +
                        "   <soapenv:Body>\n" +
                        "      <urn:GetAuthorizationRequest xmlns:urn=\"urn:monsanto:serviceadmin:services:authorization\">\n" +
                        "         <urn1:Header xmlns:urn1=\"urn:monsanto:uscomm:service:header\">\n" +
                        "            <urn1:DocumentIdentifier>32434545</urn1:DocumentIdentifier>\n" +
                        "            <urn1:DocumentDateTime>" + timestamp + "</urn1:DocumentDateTime>\n" +
                        "            <urn1:From>\n" +
                        "               <urn1:PartnerName>ECMS</urn1:PartnerName>\n" +
                        "            </urn1:From>\n" +
                        "         </urn1:Header>\n" +
                        "         <urn:GetAuthorizationRequestBody>\n" +
                        "            <urn:UserId>" + userId + "</urn:UserId>\n" +
                        "            <urn:AuthorizationRequestType>\n" +
                        "               <urn:RequestType>Acct</urn:RequestType>\n" +
                        "               <urn:RequestType>Role</urn:RequestType>\n" +
                        "            </urn:AuthorizationRequestType>\n" +
                        "         </urn:GetAuthorizationRequestBody>\n" +
                        "      </urn:GetAuthorizationRequest>\n" +
                        "   </soapenv:Body>\n" +
                        "</soapenv:Envelope>";

        Document doc = DOMUtil.newDocument(new StringReader(message));
        return new DOMUtilXmlDocument(doc);

    }

    private Subject buildSubjectFromServiceResponse(XmlDocument authDoc,
                                                    String userId) throws LoginException,
            FailedLoginException {

        Subject subject = new Subject();
        XmlElement bodyElement = getResponseBodyElement(authDoc);

        if (XmlElement.NULL.equals(bodyElement)) {
            checkError(authDoc);
        } else {
            addIdentityPrincipal(subject, authDoc, userId);
            addRolePrincipals(subject, authDoc);
        }

        return subject;
    }

    private void checkError(XmlDocument authDoc)
            throws LoginException {

        XmlElement soapBodyElement = authDoc.selectElementByXPath(XPATH_SOAP_FAULT);
        XmlElement faultElement = soapBodyElement.getChild(TAG_AUTH_RESPONSE_FAULT);
        if (XmlElement.NULL.equals(faultElement)) {
            throw new FailedLoginException(DEFAULT_ERROR_MESSAGE);
        } else {

            String errorCode = faultElement.getChild(TAG_AUTH_RESPONSE_FAULT_CODE).getText();
            Logger.log(new LoggableWarning(errorCode));

            String errorMessage = faultElement.getChild(TAG_AUTH_RESPONSE_FAULT_MESSAGE).getText();
//            Logger.log(new LoggableWarning("Server exception returned: " + errorMessage));

            throw new FailedLoginException(DEFAULT_ERROR_MESSAGE + ": " + errorCode);
        }
    }

    private void addIdentityPrincipal(Subject subject, XmlDocument authDoc,
                                      String userId) throws FailedLoginException {

        XmlElement bodyElement = getResponseBodyElement(authDoc);

        String accountIdNodeValue = bodyElement.getChild(NODE_ACCT_ID).getText();

        String ebid = bodyElement.getChild(NODE_EB_ID).getText();

        String accountName = bodyElement.getChild(NODE_ACCT_NAME).getText();

        long accountId = idTranslator.parseAccountId(accountIdNodeValue);
        IdentityPrincipal principal = new IdentityPrincipal(userId, accountId,
                ebid, accountName);
        subject.getPrincipals().add(principal);

        String sapId = bodyElement.getChild(NODE_SAP_ID).getText();
        if(sapId != null) {
            SapPrincipal sapPrincipal = new SapPrincipal(sapId);
            subject.getPrincipals().add(sapPrincipal);
        }

    }

    private static XmlElement getResponseBodyElement(XmlDocument authDoc) {
        XmlElement soapBodyElement = authDoc.selectElementByXPath(XPATH_SOAP_WRAPPER);
        return soapBodyElement.getChild(NODE_AUTH_RESPONSE).getChild(NODE_AUTH_RESPONSE_BODY);
    }

    private void addRolePrincipals(Subject subject, XmlDocument authDoc)
            throws FailedLoginException {

        XmlElement rolesElement = getResponseBodyElement(authDoc).getChild(TAG_ROLES);
        List roles = rolesElement.getChildren();

        if (roles.isEmpty()) {
            throw new FailedLoginException(DEFAULT_ERROR_MESSAGE);
        } else {
            for (Iterator itRole = roles.iterator(); itRole.hasNext();) {
                XmlElement roleElement = (XmlElement) itRole.next();
                String roleName = roleElement.getText();
                RolePrincipal principal = new RolePrincipal(roleName.toUpperCase());
                subject.getPrincipals().add(principal);
            }
        }
    }

    public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
        this.xmlDocumentBuilder = xmlDocumentBuilder;
    }

    public void setIdTranslator(IdTranslator idTranslator) {
        this.idTranslator = idTranslator;
    }
}
