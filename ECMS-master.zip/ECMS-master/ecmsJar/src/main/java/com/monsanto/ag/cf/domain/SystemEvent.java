/*
 * SystemEvent was created on May 6, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Represents information about a system event, typically one that occurs in
 * response to a user-initiated activity.
 * 
 * @author Gareth Davies
 * @version $Id: SystemEvent.java,v 1.8 2005-08-26 16:10:56 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC74
 */
public class SystemEvent extends Conversation {

  private Date eventTime;
  private String statusCode;
  private String statusMessage;

  public SystemEvent() {
  }

  public SystemEvent(String userId, long accountId, String conversationId,
      Date eventTime, String statusCode, String statusMessage) {
    setUserId(userId);
    setAccountId(accountId);
    setConversationId(conversationId);
    this.eventTime = eventTime;
    this.statusCode = statusCode;
    this.statusMessage = statusMessage;
  }

  public Date getEventTime() {
    return eventTime;
  }

  public String getStatusCode() {
    return statusCode;
  }

  public String getStatusMessage() {
    return statusMessage;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof SystemEvent)) {
      return false;
    }
    SystemEvent rhs = (SystemEvent) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(eventTime,
        rhs.getEventTime()).append(statusCode, rhs.getStatusCode()).append(
        statusMessage, rhs.getStatusMessage()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 13).appendSuper(super.hashCode()).append(
        eventTime).append(statusCode).append(statusMessage).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(
        super.toString()).append("eventTime", eventTime).append("statusCode",
        statusCode).append("statusMessage", statusMessage).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.7  2005/07/08 17:14:24  ggdavi
 * Added accountId to the constructor
 * Revision 1.6 2005/06/20 17:12:36 ggdavi Moved
 * Entity and Identifiable back to ag.cf.domain from ag.domain (sorry about
 * that...)
 * 
 * Revision 1.5 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.4 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.3 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.2 2005/05/09 18:08:01 ggdavi Now extends Conversation Revision 1.1
 * 2005/05/06 17:41:13 ggdavi Initial version
 * 
 */