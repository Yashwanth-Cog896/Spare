/*
 * COSImpl was created on Jun 8, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import com.monsanto.ag.cf.service.SecureServiceBase;
import com.monsanto.ag.cf.service.SoaClientInvoker;
import com.monsanto.ag.soa.client.SoaClient;

import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * Service Implementation of the COS web service.
 * 
 * @author caggarw
 * @version $Id: COSImpl.java,v 1.29 2008-06-05 20:18:39 mkuchip Exp $
 */
public class COSImpl extends SecureServiceBase implements Identifiable {

    public static final String CONVERSATION_ID_MESSAGE = "Processing customer order summary request with Conversation Id: ";
    private static final String KEY_CONVERSATION_ID = "ConversationID";
    private IdMapperDao idMapperDao;
    private XmlDocumentBuilder xmlDocumentBuilder;

    public COSImpl(){}

    public COSImpl( SoaClientInvoker soaClientInvoker, XmlMessageInformer inputXmlMessageInformer, XmlMessageInformer outputXmlMessageInformer, XmlDocumentBuilder xmlDocumentBuilder, IdMapperDao idMapperDao) {
        super( soaClientInvoker, inputXmlMessageInformer, outputXmlMessageInformer);
        this.xmlDocumentBuilder = xmlDocumentBuilder;
        this.idMapperDao = idMapperDao;
    }

    public String getId() {
        return "COS";
    }

    protected ServiceInput processInput( ServiceInput input, Subject subject ){
        IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
        XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
        COSHelper.updateInputDocumentIfDocumentDoesNotContainEBID(inputDocument, idPrincipal, idMapperDao);
        return COSHelper.prepareInputDocument(inputDocument, getConversationId(), getOutputXmlMessageInformer());
    }

    protected ServiceOutput processOutput( ServiceInput input ){
        ServiceOutput output = getSoaClientInvoker().callSoaClient(input);
        output.setConversationId(input.getParameter( KEY_CONVERSATION_ID ) );
        return output;
    }

    protected String getConversationIdMessage(){
        return CONVERSATION_ID_MESSAGE;
    }
}