/*
 * EcomMonitorDao was created on Jul 25, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao;

/**
 * Data Access Object for ECOM Monitor.
 * @author Chetna Aggarwal
 * @version $Id: EcomMonitorDao.java,v 1.1 2005-07-29 20:14:33 caggarw Exp $
 */
public interface EcomMonitorDao {
  
  public int getDatabaseStatus();
  
}


/*
 * $Log: not supported by cvs2svn $
 */