
package com.monsanto.ag.cf.service.impl;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.XMLUtil.ValidationException;
import com.monsanto.ag.cf.dao.AtfCoeProductDao;
import com.monsanto.ag.cf.dao.ProductDao;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.*;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocumentBuilder;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.*;

/**
 * Retrieves commercial product information in an AGIIS-compliant format.
 * <p>
 * The default implementation of
 * {@link com.monsanto.ag.ecg.dao.ProductDao ProductDao}is
 * {@link com.monsanto.ag.ecg.dao.atfcoe.AtfCoeProductDao AtfCoeProductDao},
 * which can be overridden via an alternative constructor. Similarly, the
 * default implementation of
 * {@link com.monsanto.ag.util.XmlDocumentBuilder XmlDocumentBuilder}is
 * {@link com.monsanto.ag.util.DOMUtilXmlDocumentBuilder DOMUtilXmlDocumentBuilder}.
 * This isn't as clean as the Spring approach (or even an AbstractFactory) but
 * is better than nothing.
 * 
 * @author Gareth Davies
 * @version $Id: AGIISProductUpdateController.java,v 1.2 2005/06/17 20:57:32
 *          ggdavi Exp $
 */
public class AGIISProductUpdateController_2 extends BasePOSController {

  private static final String XPATH_REQUEST_PARMS = "/ecms:ProductExtractRequest/ecms:ProductExtractRequestBody/ecms:ProductExtractRequestDetails";
  private static final String XPATH_FROM_PARTNER_INFO = "/ecms:ProductExtractRequest/cidx:Header/cidx:From/cidx:PartnerInformation";
  private static final String XPATH_CONVERSATION_ID = "/ecms:ProductExtractRequest/cidx:Header/cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier";

  private ProductDao productDao;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  
  public AGIISProductUpdateController_2(ProductDao productListDao) {
	  productDao = productListDao ;

	    this.xmlDocumentBuilder = new DOMUtilXmlDocumentBuilder();

	    this.idTranslator = new IdTranslator();
	    this.idTranslator.setAccountIdLength(13);
	    this.idTranslator.setEbusinessIdLength(13);
	    this.idTranslator.setSapIdLength(10);
	  
	  
  }
  public AGIISProductUpdateController_2() {
    this.productDao = new AtfCoeProductDao();
    this.xmlDocumentBuilder = new DOMUtilXmlDocumentBuilder();

    this.idTranslator = new IdTranslator();
    this.idTranslator.setAccountIdLength(13);
    this.idTranslator.setEbusinessIdLength(13);
    this.idTranslator.setSapIdLength(10);
  }

  public AGIISProductUpdateController_2(ProductDao productDao, XmlDocumentBuilder xmlDocumentBuilder,
      IdTranslator idTranslator) {
    this.productDao = productDao;
    this.xmlDocumentBuilder = xmlDocumentBuilder;
    this.idTranslator = idTranslator;
  }

  /**
   * @see com.monsanto.POSServlet.BasePOSController#authorizeUser(com.monsanto.ServletFramework.UCCHelper,
   *      org.w3c.dom.Document)
   */
  protected LoginBrief authorizeUser(UCCHelper helper, Document inputDocument) throws LogonFailedException,
      NoLogonInformationException {
    return null;
  }

  /**
   * @see com.monsanto.POSServlet.BasePOSController#getXMLSchemaRelativeToServletContext()
   */
  protected String getXMLSchemaRelativeToServletContext() {
    return null;
  }

  /**
   * Do <b>not </b> attempt to validate against a schema, since that should have
   * already been done in the client. Besides, the
   * {@link DOMUtil#newDocument(InputStream, String) DOMUtil.newDocument}method
   * apparently has some issues with schemas that import other schemas with
   * alternative namespaces.
   * 
   * @see com.monsanto.POSServlet.BasePOSController#validateChildDocument(org.w3c.dom.Document)
   */
  protected Document validateChildDocument(Document inputDocument) throws ValidationException, IOException,
      SAXException, TransformerException, ParserConfigurationException, ParserException {
    Logger.traceEntry(new Object[] { inputDocument });

    return (Document) Logger.traceExit(makeChildDocumentFromParentDocument(inputDocument));
  }

  /**
   * @see com.monsanto.POSServlet.BasePOSController#runImplementation(com.monsanto.ServletFramework.UCCHelper,
   *      org.w3c.dom.Document)
   */
  public void runImplementation(UCCHelper uccHelper, Document inputDocument) throws IOException {
    Logger.traceEntry();

    List products = null;
    XmlDocument inputXmlDocument = xmlDocumentBuilder.createXmlDocument(inputDocument);
    try {
      products = getRequestedProductsFromRepository(inputXmlDocument);

      Logger.log(new LoggableInfo("Building AGIISProductUpdate2 output document from retrieved products"));
      Document outputDocument = buildProductUpdateDocument(inputXmlDocument, products);
      uccHelper.writeXMLDocument(outputDocument);
    } catch (WrappingException e) {
      uccHelper.writeXMLDocument(e.toXML());
    } finally {
      if (products != null) {
        products.clear();
        products = null;
      }
    }

    Logger.traceExit();
  }

    public Document runImplementation(XmlDocument inputDocument) {
        Logger.traceEntry();
        List products = null;
        Document outputDocument = null;
        try {
            products = getRequestedProductsFromRepository(inputDocument);
            Logger.log(new LoggableInfo("Building AGIISProductUpdate2 output document from retrieved products"));
            outputDocument = buildProductUpdateDocument(inputDocument, products);
            return outputDocument;
        } catch (WrappingException e) {
            Logger.log(new LoggableInfo(
                    "Exception in Getting Products in runImplementation of AGIISProductUpdateController_2"));
            Logger.log(new LoggableInfo(e.getMessage()));
            return outputDocument;
        } finally {
            if (products != null) {
                products.clear();
                products = null;
            }
            Logger.traceExit();
        }
    }
  
  private List getRequestedProductsFromRepository(XmlDocument inputDocument) throws WrappingException {
    Date lastModifiedDate = getLastModifiedDateToFilterByFromInputDocument(inputDocument);
    String category = getCategoryToFilterByFromInputDocument(inputDocument);
    Set brands = getBrandsToFilterByFromInputDocument(inputDocument);
    String requestingEntity =  getDataSourceFromInputDocument(inputDocument);

    return productDao.findProductsByDateCategoryBrand(requestingEntity, lastModifiedDate, category, brands);
  }

  private Date getLastModifiedDateToFilterByFromInputDocument(XmlDocument inputDocument) {
    Date lastModifiedDate = null;

    try {
      String xpathFromDate = XPATH_REQUEST_PARMS + "/cidx:FromDateTime";
      String fromDateText = inputDocument.getNodeValueByXPath(xpathFromDate);
      lastModifiedDate = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(fromDateText);
    } catch (ParseException pe) {
      Logger.log(new LoggableWarning(pe.getMessage()));
    }

    return lastModifiedDate;
  }

  private String getCategoryToFilterByFromInputDocument(XmlDocument inputDocument) {
    String xpathCategory = buildAttributeNodeXpath("PrimaryProductSegmentCode");
    return inputDocument.getNodeValueByXPath(xpathCategory);
  }

  private String getDataSourceFromInputDocument(XmlDocument inputDocument) {
    String xpathCategory = buildContactNameNodeXpath("DataSource");
    return inputDocument.getNodeValueByXPath(xpathCategory);
  }  

  private Set getBrandsToFilterByFromInputDocument(XmlDocument inputDocument) {
    Set brands = new HashSet();

    String xpathBrandName = buildAttributeNodeXpath("BrandName");
    List brandNodes = inputDocument.selectElementsByXPath(xpathBrandName);
    for (Iterator itBrandNode = brandNodes.iterator(); itBrandNode.hasNext();) {
      XmlElement brandNode = (XmlElement) itBrandNode.next();
      String brand = brandNode.getText();
      if (StringUtils.isNotBlank(brand)) {
        brands.add(brand);
      }
    }

    return brands;
  }

  private String buildAttributeNodeXpath(String attributeName) {
    return XPATH_REQUEST_PARMS + "/ecms:ProductFeatures/ecms:ProductAttribute[ecms:ProductAttributeName='"
        + attributeName + "']/ecms:ProductAttributeValue";
  }

  private String buildContactNameNodeXpath(String contactDescription) {
    return XPATH_FROM_PARTNER_INFO + "/cidx:" + CidxConstants.CONTACT_INFORMATION_NODE_NAME  + "[cidx:"
            + CidxConstants.CONTACT_DESCRIPTION_NODE_NAME + "='" + contactDescription + "']/cidx:" + CidxConstants.CONTACT_NAME_NODE_NAME;

  }  

  private Document buildProductUpdateDocument(final XmlDocument inputDocument, List products) {
    XmlDocument outputDocument = XmlDocument.NULL;

      outputDocument = buildProductUpdateXmlDocument(inputDocument, products);
    return outputDocument.getDOMDocument();
  }


  private XmlDocument buildProductUpdateXmlDocument(XmlDocument inputDocument, List products) {
	if(xmlDocumentBuilder == null)
	{	
		xmlDocumentBuilder = new DOMUtilXmlDocumentBuilder();
	}	
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument
        .addRootElement("AGIISProductUpdate", XmlNamespace.NAMESPACE_AGIIS_20, "2.0");

    addHeaderNode(inputDocument, rootElement);
    XmlElement companyInfoElement = addCompanyInformationNode(rootElement);
    addProductInformationNodes(companyInfoElement, products);
    return outputDocument;
  }

  private void addHeaderNode(XmlDocument inputDocument, XmlElement baseElement) {
    String conversationId = inputDocument.getNodeValueByXPath(XPATH_CONVERSATION_ID);
    IdentityPrincipal identityPrincipal = getIdentityPrincipalFromInputDocument(inputDocument);

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_50_DRAFT14);
    helper.addHeaderNode(baseElement, conversationId, identityPrincipal.getMessageParticipant(), idTranslator);
  }

  private IdentityPrincipal getIdentityPrincipalFromInputDocument(XmlDocument inputDocument) {
    String accountIdText = inputDocument.getNodeValueByXPath(XPATH_FROM_PARTNER_INFO + "/cidx:PartnerIdentifier[@"
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.ACCOUNT_ID_AGENCY + "']");
    long accountId = idTranslator.parseAccountId(accountIdText);

    String eBusinessIdText = inputDocument.getNodeValueByXPath(XPATH_FROM_PARTNER_INFO + "/cidx:PartnerIdentifier[@"
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.EBID_AGENCY + "']");

    String accountName = inputDocument.getNodeValueByXPath(XPATH_FROM_PARTNER_INFO + "/cidx:PartnerName");

    IdentityPrincipal identityPrincipal = new IdentityPrincipal(StringUtils.EMPTY, accountId, eBusinessIdText,
        accountName);
    return identityPrincipal;
  }

  private XmlElement addCompanyInformationNode(XmlElement baseElement) {
    XmlElement companyInfoElement = null;

    XmlElement bodyNode = baseElement.addChildElement("Body");
    XmlElement detailsNode = bodyNode.addChildElement("AGIISProductUpdateDetails");
    companyInfoElement = detailsNode.addChildElement("CompanyInformation");
    companyInfoElement.setAttribute("ActiveFlag", "Active");

    companyInfoElement.addChildElement("PartnerName", "MONSANTO AGRICULTURAL CO");
    XmlElement partnerIdElement = companyInfoElement.addChildElement("PartnerIdentifier", "0062668030000");
    partnerIdElement.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, "EBID");
    
    // Adding UserDefinedLabels tags
    XmlElement userDefinedLabelsElement = companyInfoElement.addChildElement("UserDefinedLabels");
    userDefinedLabelsElement.addChildElement("PkgSizeLabel1", "Processor Code");    
    userDefinedLabelsElement.addChildElement("PkgSizelabel2", "Treatment Code");
    userDefinedLabelsElement.addChildElement("PkgSizeLabel3", "Dealer Treated");
    userDefinedLabelsElement.addChildElement("PkgCfgLabel2", "Unit Quantity");
    
    return companyInfoElement;
  }

  private void addProductInformationNodes(XmlElement baseElement, List products) {
    int productCounter = 0;
    for (Iterator itProduct = products.iterator(); itProduct.hasNext();) {
    	++productCounter;
    	
      if (++productCounter % 100 == 1) {
        Logger.log(new DebugLogEvent("Adding ProductInformation element for products " + productCounter + " - "
            + (productCounter + 99)));
        
      }
      Product product = (Product) itProduct.next();

      product.appendXmlToElement(baseElement);
      product.dispose();
    }
  }


}

/*
 * $Log: AGIISProductUpdateController_2.java,v $
 * Revision 1.4  2009/07/21 20:03:03  mkuchip
 * Adding new fields for Acceleron Treated products in Productlist_2 and ProductLite_2 versions
 *
 * Revision 1.3  2008/07/29 22:27:12  dddoni
 * ECG Service code Migrated  to ECMS. - Controller.
 *
 * Revision 1.2  2008/07/29 22:09:00  dddoni
 * ECG Service code Migrated  to ECMS. - Controller.
 *
 * Revision 1.1  2008/07/18 21:31:07  gjkell
 * from ECG
 *
 * Revision 1.1  2008/06/19 13:05:27  gjkell
 * GOA II
 *
 * Revision 1.29  2006/07/13 21:52:30  caggarw
 * Changed the Agency for AccountId from Other to AssignedBySeller. Refactored to use CidxConstants for Agency Attributes.
 * Revision 1.28 2006/03/11 07:27:18
 * mecoru WrappingException import changed from dataservices to Util.Exceptions:
 * Done by automated script
 * 
 * Revision 1.27 2006/01/31 13:38:01 ggdavi Refactored
 * com.monsanto.ag.soa.client package by separating POS and HttpClient
 * implementation classes into two subpackages, for easier exclusion of one or
 * the other Revision 1.26 2005/12/01 19:55:37 ggdavi Refactored
 * com.monsanto.ag.util package, moving all XML-specific classes and tests into
 * the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class
 * replaces the java.util.List interface as the primary representation of a
 * collection of XML chunks
 * 
 * Revision 1.25 2005/11/29 22:38:50 caggarw changed EBID to String
 * 
 * Revision 1.24 2005/11/21 21:14:44 caggarw Add the AccountName from the
 * inputDocument to the IdentityPrincipal. Also Add the AccountId/EBID if
 * applicable
 * 
 * Revision 1.23 2005/11/09 18:58:11 ggdavi Adjusted to recent changes in the
 * CPITCommon ag.util package
 * 
 * Revision 1.22 2005/09/13 14:46:09 ggdavi Fixed runtime NumberFormatException
 * when no EBusiness ID exists in the request XML CIDX Header element Revision
 * 1.21 2005/08/26 16:31:37 ggdavi Javadoc corrections Revision 1.20 2005/08/26
 * 14:45:14 ggdavi CidxDocumentHelper is now an instantiable class that takes an
 * XmlNamespace in its constructor - for the current service implementations,
 * this is the XmlNamespace.NAMESPACE_CIDX_40 object Revision 1.19 2005/08/23
 * 21:28:17 ggdavi LoggableWarning instances now just log the error message, not
 * the exception itself
 * 
 * Revision 1.18 2005/08/05 23:01:28 ggdavi Enabled chunking of output documents
 * by wrapping in a chunk-wrapper element Revision 1.17 2005/07/26 18:09:53
 * ggdavi Renamed IdTranslator eBusinessIdLength field to ebusinessIdLength
 * 
 * Revision 1.16 2005/07/21 22:23:39 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations; enhanced and refactored XML abstraction
 * in com.monsanto.ag.util Revision 1.15 2005/07/06 22:10:17 ggdavi Handled the
 * refactoring com.monsanto.ag.util, including breaking out XmlDocument from
 * XmlElement and adding XmlNamespace
 * 
 * Revision 1.14 2005/07/05 22:29:04 ggdavi Added XmlElement parameter to
 * XmlDocumentBuilder.getDOMDocument
 * 
 * Revision 1.13 2005/07/05 21:01:39 ggdavi Added an activeFlag parameter to
 * findProductsByDateCategoryBrand Revision 1.12 2005/07/05 19:33:17 ggdavi
 * Documents are now created using XmlDocumentBuilder implementations Revision
 * 1.11 2005/06/30 21:31:38 ggdavi Use node.getOwnerDocument instead of
 * helper.getDocument(node)
 * 
 * Revision 1.10 2005/06/30 17:48:45 ggdavi Fixed loop debug statements
 * 
 * Revision 1.9 2005/06/30 16:44:46 ggdavi Added debugging statements every 100
 * items Revision 1.8 2005/06/27 22:03:21 ggdavi Added test for
 * WrappingException thrown from DAO Revision 1.7 2005/06/23 17:00:35 ggdavi
 * Override validateChildDocument to NOT validate request XML against a schema
 * Revision 1.6 2005/06/23 16:15:49 ggdavi Added code to extract DAO parameters
 * from request document; refactored Revision 1.5 2005/06/22 21:53:59 ggdavi
 * Moved AgiisDocumentHelper from ag.ecg.domain to ag.util Revision 1.4
 * 2005/06/22 17:23:57 ggdavi Leverage AgiisDocumentHelper to build XML document
 * Revision 1.3 2005/06/20 20:11:14 ggdavi Added productDao, used in
 * runImplementation to get list of products, with alternative constructors
 * Revision 1.2 2005/06/17 20:57:32 ggdavi Added javadoc
 * 
 * Revision 1.1 2005/06/17 20:53:39 ggdavi Initial version
 * 
 */