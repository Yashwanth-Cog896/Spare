/*
 Copyright:  Copyright � 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.domain;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.commercial.growercreditlist.domain.ClientInfo;
import com.monsanto.commercial.growercreditlist.util.EnvironmentEnum;

public class GrowerCreditInfoClientInfo extends ClientInfo {
    private static final String PARTNER_INFO_XPATH = "/ecms:AGIISEntityInquiry/cidx:Header/cidx:From/cidx:PartnerInformation";
    private static final String PARTNER_NAME_XPATH = PARTNER_INFO_XPATH + "/cidx:PartnerName";
    private static final String PARTNER_ID_XPATH = PARTNER_INFO_XPATH + "/cidx:PartnerIdentifier";
    private static final String DOC_IDENTIFIER_XPATH = "/ecms:AGIISEntityInquiry/cidx:Header/cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier";
    private static final String PARTNER_ID_TYPE = "AGIIS-EBID";

    public GrowerCreditInfoClientInfo(XmlDocument inputDocument, String lsiFunction) {
        super();
        setPartnerIdType(PARTNER_ID_TYPE);
        setPartnerId(inputDocument.getNodeValueByXPath(PARTNER_ID_XPATH));
        setPartnerName(inputDocument.getNodeValueByXPath(PARTNER_NAME_XPATH));
        setDocIdentifier(inputDocument.getNodeValueByXPath(DOC_IDENTIFIER_XPATH));
        setEnvironment(EnvironmentEnum.fromValue(lsiFunction.toUpperCase()));
        Logger.log(new LoggableInfo("Client environment: " + getEnvironment()));
    }
}
