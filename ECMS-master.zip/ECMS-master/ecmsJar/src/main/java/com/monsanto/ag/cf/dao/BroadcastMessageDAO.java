package com.monsanto.ag.cf.dao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: svadlam
 * Date: May 18, 2010
 * Time: 3:19:44 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BroadcastMessageDAO {
    public List getMessages(String userId,String seedYear,String appDescr);
    public boolean checkPopupIdValidAndNotVisited(String userId,String popupId);
    public int insertPopupVisited(String userId,String popupId);
}
