package com.monsanto.ag.cf.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.ag.cf.domain.Measurement;
import com.monsanto.ag.cf.domain.PackageConfiguration;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/21/13
 * Time: 12:16 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractListAdder {

    private static final String FLAG_TRUE = "Y";

    public abstract Product addProductToList( List products, PersistentStoreResultSetFwdIterator iter,
                                                     Product lastProductRetrieved ) throws WrappingException;

    protected PackageConfiguration mapRowToPackageConfiguration( PersistentStoreResultSetFwdIterator iter )
        throws WrappingException {

        Measurement basePackageQuantity = mapRowToMeasurement( iter, "quantity_of_base_package", getUnRec20RrUomCode( iter ) );
        Measurement childPackageQuantity = mapRowToMeasurement( iter, "quantity_of_child_package", getUnRec20RrUomCode( iter ) );
        Measurement squareFeet = mapRowToMeasurement( iter, "square_feet", PackageConfiguration.AREA_UOM );
        Measurement cubicDimension = mapRowToMeasurement( iter, "cubic_feet", PackageConfiguration.VOLUME_UOM );

        return new PackageConfiguration( getBoolean( iter, "pkgcnfg_active_flag" ),
                                         getAddedDate( iter ),
                                         getLastModifiedDate( iter ),
                                         iter.getString( "product_class_id" ),
                                         iter.getString( "gtin" ),
                                         getUpc( iter ),
                                         getUnRec20RrUomCode( iter ),
                                         basePackageQuantity,
                                         childPackageQuantity,
                                         getFloat( iter, "calculated_volume" ),
                                         getFloat( iter, "gross_weight" ),
                                         getFloat( iter, "tare_weight" ),
                                         getFloat( iter, "net_weight" ),
                                         getFloat( iter, "length" ),
                                         getFloat( iter, "width" ),
                                         getFloat( iter, "height" ),
                                         squareFeet,
                                         cubicDimension,
                                         iter.getINTEGER( "stacking_height" ),
                                         iter.getINTEGER( "unit_qty" ) );
    }

    protected Measurement mapRowToMeasurement( PersistentStoreResultSetFwdIterator iter, String quantityColumnName, String uomCode )
        throws WrappingException {

        Float quantity = getFloat( iter, quantityColumnName );
        return new Measurement( quantity, uomCode );
    }

    protected boolean getEcListMaterial( PersistentStoreResultSetFwdIterator iter ) throws WrappingException{

        return getBoolean( iter, "ec_list_flag" );
    }

    protected boolean getBoolean( PersistentStoreResultSetFwdIterator iter, String columnName ) throws WrappingException {

        return FLAG_TRUE.equalsIgnoreCase( iter.getString( columnName ) );
    }

    protected Float getFloat( PersistentStoreResultSetFwdIterator iter, String columnName ) throws WrappingException {

        if ( iter.getString( columnName ) == null ) {

            return null;
        }

        return new Float( iter.getString( columnName ) );
    }

    protected boolean getActiveFlag( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return getBoolean( iter, "prod_active_flag" );
    }

    protected Date getAddedDate( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return iter.getTimestamp( "row_entry_date" );
    }

    protected Date getLastModifiedDate( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return iter.getTimestamp( "update_date" );
    }

    protected String getProductId( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return Integer.toString( iter.getInt( "prod_id" ) );
    }

    protected String getUnRec20RrUomCode( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return iter.getString( "unrec20_rr_uom_code" );
    }

    protected String getUpc( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return iter.getString( "universal_prod_code" );
    }

    protected Measurement getBaseQuantity( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return mapRowToMeasurement( iter, "base_quantity", iter.getString( "unrec20_base_uom_code" ) );
    }
}