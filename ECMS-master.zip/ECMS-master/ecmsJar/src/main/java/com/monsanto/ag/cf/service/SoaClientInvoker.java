package com.monsanto.ag.cf.service;

import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.SoaClient;

public class SoaClientInvoker {
    private String soaServiceId;
    private SoaClient soaClient;

    public SoaClientInvoker(){}

    public SoaClientInvoker(String soaServiceId, SoaClient soaClient) {
        this.soaServiceId = soaServiceId;
        this.soaClient = soaClient;
    }

    public ServiceOutput callSoaClient(ServiceInput serviceInput) {
        return soaClient.call(soaServiceId, serviceInput);
    }
}