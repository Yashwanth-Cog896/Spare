/*
 * DealerPreferencesImpl was created on Apr 19, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

import javax.security.auth.Subject;

import com.monsanto.ag.cf.security.SapPrincipal;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.DealerPreferencesDao;
import com.monsanto.ag.cf.dao.SpecialInstructionsDao;
import com.monsanto.ag.cf.domain.Device;
import com.monsanto.ag.cf.domain.SpecialInstructions;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;

import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.RolePrincipal;

/**
 * POJO implementation of the Dealer Preferences service.
 * 
 * @author Gareth Davies
 * @version $Id: DealerPreferencesImpl.java,v 1.12 2005/05/17 17:53:23 ggdavi
 *          Exp $
// * @see SeedTrakInsourcingScope FC56, FC76
 */
public class DealerPreferencesImpl implements SecureService, Identifiable {

  private static final String XPATH_HANDHELD_DEVICE_APP = "/cidx:preferences-request/cidx:handheld/cidx:devices/cidx:device/cidx:applications/cidx:application";
  private static final String XPATH_FROM_PARTNER_INFO = "//cidx:Header/cidx:From/cidx:PartnerInformation";
  private static final String XPATH_TO_PARTNER_INFO = "//cidx:Header/cidx:To/cidx:PartnerInformation";

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private SpecialInstructionsDao specialInstructionsDao;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;
  private DealerPreferencesDao dealerPreferencesDao; 
  private Device device;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "PREF";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo("Processing dealer preferences request with conversation Id: " + conversationId));
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
    Set instructionsSet = getSpecialInstructionsList(subject, inputDocument);

    storeVersionInformationAndGetLatestVersionIfApplicable(subject, inputDocument);

    XmlDocument outputDocument = buildPreferencesDocument(subject, instructionsSet, conversationId);
    output.getXmlChunks().addChunk(outputDocument);
    

    return output;
  }

  private void storeVersionInformationAndGetLatestVersionIfApplicable(Subject subject, XmlDocument inputDocument) {

    XmlElement deviceNode = inputDocument.selectElementByXPath(XPATH_HANDHELD_DEVICE_APP);
    if (!XmlElement.NULL.equals(deviceNode)) {
      device = new Device();
      String appName = deviceNode.getAttributeValue("name");
      device.setAppName(appName);
      String version = deviceNode.getAttributeValue("version");
      IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
      long accountId = getAccountIdFromInputDocumentOrAuthenicatedUser(inputDocument, idPrincipal);
      
      try {
        dealerPreferencesDao.storeVersion(accountId, version, appName);
        if (appName !=null && StringUtils.isNotBlank(appName)) {
          device.setLatestVersion(dealerPreferencesDao.getLatestVersion(appName));
        }
      } catch (IncorrectResultSizeDataAccessException e) {
        Logger.log(new DebugLogEvent(e.getMessage()));
      }
      device.setEnabledFlag(dealerPreferencesDao.getEnabledFlag(accountId));      
    }

  }
  
  public boolean isValidationRequired() {
    return true;
  }

  private long getAccountIdFromInputDocumentOrAuthenicatedUser(XmlDocument inputDocument,
      IdentityPrincipal identityPrincipal) {
    long accountId;
    String xpathAccountId = XPATH_FROM_PARTNER_INFO + "/cidx:PartnerIdentifier[@"
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.ACCOUNT_ID_AGENCY + "']";
    XmlElement partnerIdAccountIdNode = inputDocument.selectElementByXPath(xpathAccountId);
    if (!XmlElement.NULL.equals(partnerIdAccountIdNode)) {
      accountId = Long.parseLong(partnerIdAccountIdNode.getText());
      Logger.log(new LoggableInfo("AccountId for handheld information from request XML: " + accountId));
    } else
      accountId = identityPrincipal.getAccountId();    
    return accountId;
  }

  private Set getSpecialInstructionsList(Subject subject, XmlDocument inputDocument) {
    long accountId = getUserAccountId(subject, inputDocument);
    return specialInstructionsDao.findInstructionsByDealer(accountId);
  }

  private long getUserAccountId(Subject subject, XmlDocument inputDocument) {
    long accountId = SecurityUtil.getIdentityPrincipal(subject).getAccountId();
    if (accountId == 0) {
      accountId = inputXmlMessageInformer.getAccountId(inputDocument, idTranslator);
    }
    return accountId;
  }

  private XmlDocument buildPreferencesDocument(Subject subject, Set instructionsSet, String conversationId) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement("preferences", XmlNamespace.NAMESPACE_CIDX_40, "4.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    addRolesNode(rootElement, subject);
    addSpecialInstructionsNode(rootElement, instructionsSet);
    addHandHeldNodeIfNeeded(rootElement);
    addSeedTrakVersionAvailableForDownload(outputDocument);

    addAccountAndSapId(outputDocument, subject);

    return outputDocument;
  }

    private void addAccountAndSapId(XmlDocument outputDocument, Subject subject) {
        XmlElement toPartnerInformation = outputDocument.selectElementByXPath(XPATH_TO_PARTNER_INFO);
        Set sapPrincipalSet = subject.getPrincipals(SapPrincipal.class);
        SapPrincipal sapPrincipal = null;
        IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
        if (sapPrincipalSet != null) {
            Iterator it = sapPrincipalSet.iterator();
            if (it.hasNext()) {
                sapPrincipal = (SapPrincipal) it.next();
            }
        }
        if (toPartnerInformation != null && sapPrincipal != null) {
            XmlElement toContactInformation = toPartnerInformation.addChildElement(CidxConstants.CONTACT_INFORMATION_NODE_NAME);
            toContactInformation.addChildElement(CidxConstants.CONTACT_NAME_NODE_NAME, sapPrincipal.getName());
            toContactInformation.addChildElement(CidxConstants.CONTACT_DESCRIPTION_NODE_NAME, "SapId" );
        }
        if (toPartnerInformation != null && identityPrincipal != null) {
            XmlElement toContactInformation = toPartnerInformation.addChildElement(CidxConstants.CONTACT_INFORMATION_NODE_NAME);
            toContactInformation.addChildElement(CidxConstants.CONTACT_NAME_NODE_NAME, identityPrincipal.getAccountId());
            toContactInformation.addChildElement(CidxConstants.CONTACT_DESCRIPTION_NODE_NAME, "AccountId" );
        }
    }

    private void addHandHeldNodeIfNeeded(XmlElement rootNode) {
    if (device != null) {
      XmlElement handheldNode = rootNode.addChildElement("handheld");
      handheldNode.setAttribute("isEnabled", "Y".equalsIgnoreCase(device.getEnabledFlag())? "Y":"N");
      XmlElement applicationsNode = handheldNode.addChildElement("applications");
      XmlElement applicationNode = applicationsNode.addChildElement("application");
      applicationNode.setAttribute("name", device.getAppName());
      applicationNode.setAttribute("currentVersion", device.getLatestVersion());
    }
    
  }

  protected void addSeedTrakVersionAvailableForDownload(XmlDocument outputDocument) {
	  XmlElement partnerInformation = outputDocument.selectElementByXPath(XPATH_FROM_PARTNER_INFO);
	  if (partnerInformation != null && dealerPreferencesDao != null) {
	 	  String seedTrakVersionAvailableForDownload = dealerPreferencesDao.getSeedTrakVersionAvailableForDownload();
		  XmlElement fromContactInformation = partnerInformation.addChildElement(CidxConstants.CONTACT_INFORMATION_NODE_NAME);
		  fromContactInformation.addChildElement(CidxConstants.CONTACT_NAME_NODE_NAME, seedTrakVersionAvailableForDownload);
		  fromContactInformation.addChildElement(CidxConstants.CONTACT_DESCRIPTION_NODE_NAME, "SeedTrakVersionAvailableForDownload");
	  }
  }

  
  
  private void addRolesNode(XmlElement rootNode, Subject subject) {
    XmlElement rolesNode = rootNode.addChildElement("roles");
    for (Iterator itRole = getUserRoles(subject).iterator(); itRole.hasNext();) {
      RolePrincipal role = (RolePrincipal) itRole.next();
      rolesNode.addChildElement("role-name", role.getName());
    }
  }

  private Set getUserRoles(Subject subject) {
    return (subject == null) ? Collections.EMPTY_SET : subject.getPrincipals(RolePrincipal.class);
  }

  private void addSpecialInstructionsNode(XmlElement rootNode, Set instructionsSet) {
    XmlElement insNode = rootNode.addChildElement("special-instructions");
    for (Iterator itInstructions = instructionsSet.iterator(); itInstructions.hasNext();) {
      SpecialInstructions instructions = (SpecialInstructions) itInstructions.next();
      addSpecialInstructionsServiceNode(insNode, instructions);
    }
  }

  private void addSpecialInstructionsServiceNode(XmlElement insNode, SpecialInstructions instructions) {
    String serviceNodeName = getServiceNodeName(instructions);
    if (StringUtils.isNotBlank(serviceNodeName)) {
      XmlElement serviceNode = insNode.addChildElement(serviceNodeName);
      for (Iterator itInstruction = instructions.getIterator(); itInstruction.hasNext();) {
        String instruction = (String) itInstruction.next();
        serviceNode.addChildElement("instruction", instruction);
      }
    }
  }

  private String getServiceNodeName(SpecialInstructions instructions) {
    String serviceId = instructions.getServiceId();
    return (serviceId == null) ? null : serviceId.toLowerCase();
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setSpecialInstructionsDao(SpecialInstructionsDao specialInstructionsDao) {
    this.specialInstructionsDao = specialInstructionsDao;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

  public void setDealerPreferencesDao(DealerPreferencesDao dealerPreferencesDao) {
    this.dealerPreferencesDao = dealerPreferencesDao;
  }  
  
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.47  2008/09/18 20:18:21  caggarw
 * Added log statements
 *
 * Revision 1.46  2008/08/06 22:49:40  mkuchip
 * Customize Schema validation behavior for GOAII services
 *
 * Revision 1.45  2008/08/05 18:54:15  rwspeh
 * Moved setEnabledFlag line outside of try/catch block.
 *
 * Revision 1.44  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.43  2008/05/01 19:54:21  rwspeh
 * *** empty log message ***
 *
 * Revision 1.42  2008/05/01 19:22:37  rwspeh
 * *** empty log message ***
 *
 * Revision 1.41  2008/05/01 18:58:54  rwspeh
 * Added SeedTrakVersionAvailableForDownload to Header Information of Dealer Preferences response XML.
 *
 * Revision 1.40  2008/04/23 15:17:59  rwspeh
 * Add logging back into code.
 *
 * Revision 1.39  2008/04/15 18:17:05  rwspeh
 * Backed out Logging changes for Data source column
 *
 * Revision 1.38  2008/04/10 15:40:30  rwspeh
 * Added funcitonaliy to update source name column in USER_XREF t able and DATA_EXCHANGE_LOG table
 *
 * Revision 1.37  2007/10/22 21:18:21  caggarw
 * Changed Dealer perfs to log software version and device information for handheld users
 * Revision 1.36 2006/06/21 21:58:27
 * caggarw Refactoring to store input/output documents in the data_exchange
 * respository as well as the root node name of the document. We now have
 * separate messageinformers for input and output.
 * 
 * Revision 1.35 2006/01/24 18:56:18 ggdavi Moved ChunkableServiceEndpoint,
 * SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to
 * com.monsanto.ag.soa.server. This will simplify the class exclusion process
 * for consumer classes only interested in ag.soa.client classes.
 * 
 * Revision 1.34 2006/01/24 18:36:56 ggdavi Factored out the
 * ag.util.MessageParticant class from ag.security.IdentityPrincipal (which
 * delegates to it) so that the ag.xml.CidxDocumentHelper class no longer
 * depends on the ag.security package Revision 1.33 2005/12/01 19:34:30 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks Revision 1.32
 * 2005/11/21 20:41:38 caggarw Look for the AccountId in the request for STT's
 * 
 * Revision 1.31 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and
 * StAX implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects
 * 
 * Revision 1.30 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.29 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.28 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.27 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.26 2005/08/05
 * 18:37:01 ggdavi Removed deprecated executeSecure method based on DOM
 * documents Revision 1.24 2005/07/21 22:14:11 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations Revision 1.23 2005/07/21 14:48:57 ggdavi
 * Fleshed out and refactored com.monsanto.ag.util to make more object-oriented,
 * in that most functionality has been pushed to the XmlDocument and XmlElement
 * objects Revision 1.22 2005/07/08 17:18:38 ggdavi Removed unused variables
 * 
 * Revision 1.21 2005/07/06 21:12:15 ggdavi Added xmlDocumentBuilder field, used
 * to build output XML documents Revision 1.20 2005/06/30 20:24:07 ggdavi Use
 * helper.addChildElement instead of DOMUtil.addChildElement
 * 
 * Revision 1.19 2005/06/20 17:12:36 ggdavi Moved Entity and Identifiable back
 * to ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.18 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.17 2005/06/17 18:20:45 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security; moved CidxDocumentHelper from
 * ag.cf.service.impl to ag.util
 * 
 * Revision 1.16 2005/05/31 20:38:42 ggdavi Throw SOAPFaultExceptions instead of
 * creating SOAPFault documents Revision 1.15 2005/05/26 17:26:47 ggdavi In
 * CidxDocumentHelper, removed Document parameter from createRootNode and added
 * getDocument method Revision 1.14 2005/05/25 22:25:55 ggdavi Use
 * CidxDocumentHelper to create standard CIDX root node (with namespaces) and
 * header Revision 1.13 2005/05/17 20:25:03 ggdavi Converted XmlMessageInformer
 * from an interface with accessors only to a fully-fledged bean class Revision
 * 1.12 2005/05/17 17:53:23 ggdavi All AOP advice classes targeted at service
 * implementations now extend the ServiceAdvice abstract class
 * 
 * Revision 1.11 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.10 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.9 2005/05/12 21:27:29 ggdavi Replaced pos-reporting-flag element
 * with roles and special-instructions elements Revision 1.8 2005/05/10 16:01:18
 * ggdavi Added ebusiness-id element to the return document Revision 1.7
 * 2005/04/27 21:10:18 ggdavi Pulled up getCurrentSystemTime to BaseServiceImpl
 * 
 * Revision 1.6 2005/04/26 21:29:13 ggdavi Added conversation-id element to
 * return document
 * 
 * Revision 1.5 2005/04/25 17:33:12 ggdavi Added getXPathConversationId and
 * getXPathStartTime methods to XPathDefiner; return server-time element
 * Revision 1.4 2005/04/22 16:16:07 ggdavi Now extends BaseServiceImpl to
 * simplify interface implementation and to provide a default XPathDefiner
 * 
 * Revision 1.3 2005/04/21 19:17:47 ggdavi Now implements Identifiable and
 * XPathExporter
 * 
 * Revision 1.2 2005/04/20 19:12:32 ggdavi Added DealerPreferencesImpl Revision
 * 1.1 2005/04/20 17:28:19 ggdavi Initial version
 * 
 */