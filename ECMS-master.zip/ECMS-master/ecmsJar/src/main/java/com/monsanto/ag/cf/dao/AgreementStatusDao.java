/*
 * AgreementStatusDao was created on Apr 16, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import java.util.List;

/**
 * Data Access Object for AgreementStatus.
 * 
 * @author Chetna Aggarwal
 * @version $Id: AgreementStatusDao.java,v 1.1 2007-04-19 20:04:05 caggarw Exp $
 */
public interface AgreementStatusDao {

  List getAgreementStatusDetails(long accountId);
}
