/*
 * JdbcPriceSheetDao was created on Jun 22, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.PriceSheetDao;
import com.monsanto.ag.cf.dao.PriceSheetQueryBuilder;
import com.monsanto.ag.cf.domain.PriceSheet;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;

/**
 * Spring JDBC implemenation of the PriceSheet DAO.
 * 
 * @author caggarw
 * @version $Id: JdbcPriceSheetDao.java,v 1.17 2007-08-17 18:32:29 caggarw Exp $
 */
public class JdbcPriceSheetDao extends BaseJdbcDao implements PriceSheetDao {

  /**
   * Map the results from database queries (price details for price_region) to
   * PriceSheet Objects.
   */
  public class PriceSheetMappingQuery extends MappingSqlQuery {

    public PriceSheetMappingQuery(String sql) {
      super(getDataSource(), sql);
      super.declareParameter(new SqlParameter("PRICE_REGION", Types.VARCHAR));
      compile();
    }

    public PriceSheetMappingQuery(String sql, Date fromDateTime) {
      super(getDataSource(), sql);
      super.declareParameter(new SqlParameter("PRICE_REGION", Types.VARCHAR));
      super.declareParameter(new SqlParameter("ROW_MODIFY_DATE", Types.DATE));
      compile();
    }

    protected Object mapRow(ResultSet rs, int arg1) throws SQLException {
      PriceSheet priceSheet = new PriceSheet(rs.getString("UPC_CODE"), rs.getString("PRICE_REGION"), rs
          .getString("NET_RATE"), rs.getString("UOM_ID"), new java.util.Date(rs.getTimestamp("ROW_ENTRY_DATE")
          .getTime()), new java.util.Date(rs.getTimestamp("ROW_MODIFY_DATE").getTime()), rs.getString("RRA_RATE_SD"),
          rs.getString("RRA_RATE_TF"));
      return priceSheet;
    }
  }

  /**
   * Map the results from database queries (account_to_price_zone) to PriceSheet
   * Objects.
   */
  public class PriceZoneMappingQuery extends MappingSqlQuery {

    private static final String ACCT_TO_PRICE_ZONE_SQL = "SELECT PRICE_REGION,APPROVED_DATE,FULL_REFRESH_FLAG,"
        + "PARTIAL_LIST_FLAG FROM ACCT_TO_PRICE_ZONE WHERE ACCT_ID=? AND ACTIVE_FLAG IN ('Y','y')";

    public PriceZoneMappingQuery() {
      super(getDataSource(), ACCT_TO_PRICE_ZONE_SQL);
      super.declareParameter(new SqlParameter("ACCT_ID", Types.NUMERIC));
      compile();
    }

    protected Object mapRow(ResultSet rs, int arg1) throws SQLException {
      PriceSheet priceSheet = new PriceSheet();
      priceSheet.setPriceRegion(rs.getString("PRICE_REGION"));
      priceSheet.setApprovedDate(new Date(rs.getTimestamp("APPROVED_DATE").getTime()));
      priceSheet.setFullRefreshFlag(rs.getString("FULL_REFRESH_FLAG"));
      priceSheet.setPartialListFlag(rs.getString("PARTIAL_LIST_FLAG"));
      return priceSheet;
    }

  }

    public class ZoneIdsMappingQuery extends MappingSqlQuery {
        public ZoneIdsMappingQuery(final String sql) {
            super(getDataSource(), sql);
            compile();
        }

        @Override
        protected Object mapRow(ResultSet rs, int arg1) throws SQLException {
            final java.util.Date modifydate = new java.util.Date(rs.getTimestamp("row_eff_date").getTime());
            final java.util.Date entrydate = new java.util.Date(rs.getTimestamp("pricing_date").getTime());
            final String zoneCode = rs.getString("zone_code");

            return new PriceSheet(rs.getString("upc_code"), (zoneCode.equals("*") ? "No Zone" : zoneCode),
                    rs.getString("uom_code_bag"), entrydate, rs.getString("alfalfa_trait_price"), modifydate,
                    rs.getString("srp_unit_price_bag"));
        }
    }

  @Override
  public List getPriceSheet(long accountId, String category, Set brands, Date fromDateTime) {
    List priceZoneInformationList = null;
    PriceZoneMappingQuery priceZoneInformationQuery = new PriceZoneMappingQuery();
    Object[] queryParmsForAcctToPriceZone = new Object[] { new Long(accountId) };
    priceZoneInformationList = priceZoneInformationQuery.execute(queryParmsForAcctToPriceZone);
    updateFullRefreshFlagForZone(accountId);
    List results = getPriceInformationForRegion(priceZoneInformationList, brands, category, fromDateTime);
    return results;
  }

    @Override
    public List getPriceSheet(long accountId, Date fromDateTime, final Map<String, List<String>> zoneIdsMap) {
        if (fromDateTime == null) {
            zoneIdsMap.get("new").add("*");
            //fromDateTime = new Date();
        }
        final ZoneIdsMappingQuery query = new ZoneIdsMappingQuery(
                new PriceSheetQueryBuilder().build(zoneIdsMap, fromDateTime));
        return query.execute();
    }

  public List getPriceInformationForRegion(List priceZoneInformationList, Set brands, String category, Date fromDateTime) {
    List results = new ArrayList();
    boolean ignoreDate;

    if (priceZoneInformationList != null) {
      for (Iterator itr = priceZoneInformationList.iterator(); itr.hasNext();) {
        ignoreDate = false;
        PriceSheet currentPriceSheet = (PriceSheet) itr.next();
        String currentPriceZone = currentPriceSheet.getPriceRegion();
        String currentPriceZoneFullRefreshFlag = currentPriceSheet.getFullRefreshFlag();
        String partialListFlag = currentPriceSheet.getPartialListFlag();
        if (currentPriceZone != null) {
          if (fromDateTime == null || FLAG_TRUE.equalsIgnoreCase(currentPriceZoneFullRefreshFlag)) {
            ignoreDate = true;
          }
            
          PriceSheetMappingQuery priceSheetMappingQuery;
          String sql = createPriceSheetSql(category, brands, ignoreDate, partialListFlag);
          Object[] queryParametersForPriceSheet = new Object[(ignoreDate ? 1 : 2 )];
          queryParametersForPriceSheet[0] = currentPriceZone;

          if (!ignoreDate) {
            priceSheetMappingQuery = new PriceSheetMappingQuery(sql, fromDateTime);
            queryParametersForPriceSheet[1] = new java.sql.Date(fromDateTime.getTime());             
          } else {
            priceSheetMappingQuery = new PriceSheetMappingQuery(sql);
          }

          results.addAll(priceSheetMappingQuery.execute(queryParametersForPriceSheet));
        }
      }
    }
    return results;
  }

  private String createPriceSheetSql(String category, Set brands, boolean ignoreDateInQuery, String partialListFlag) {
    StringBuffer sb = new StringBuffer();
    sb.append("SELECT PRICE_REGION,UPC_CODE,NET_RATE,UOM_ID,EFF_START_DATE, ");
    sb.append("EFF_END_DATE,ROW_ENTRY_DATE,ROW_MODIFY_DATE,RRA_RATE_SD,RRA_RATE_TF");
    sb.append(" FROM SEED_PRODUCT_PRICE WHERE PRICE_REGION = ?");
    addDateClause(ignoreDateInQuery, sb);
    addCategoryClause(category, sb);
    addBrandAndClause(brands, sb);
    addPartialListAndClause(partialListFlag, sb);
    return sb.toString();
  }

  private void addPartialListAndClause(String partialListFlag, StringBuffer sb) {
    if("Y".equalsIgnoreCase(partialListFlag))  {
      sb.append(" AND PARTIAL_LIST IN ('y','Y')");
    }
  }

  private void addDateClause(boolean ignoreDateInQuery, StringBuffer sb) {
    if (!ignoreDateInQuery) {
      sb.append(" AND ROW_MODIFY_DATE > ?");
    }
  }

  private void addCategoryClause(String category, StringBuffer sb) {
    if (StringUtils.isNotBlank(category)) {
      if (category.equalsIgnoreCase("seed")) {
        sb.append(" AND PROD_CLASS_CODE IN ('D','N') AND MKTSGMT ='ST'");
      } else if (category.equalsIgnoreCase("chemical")) {
        sb.append(" AND PROD_CLASS_CODE IN ('H','N') AND MKTSGMT ='CH'");
      } else {
        sb.append(" AND PROD_CLASS_CODE = 'X' AND MKTSGMT = 'XX'");
      }
    }
  }

  private void addBrandAndClause(Set brands, StringBuffer sb) {
    if (brands != null && !brands.isEmpty()) {
      sb.append(" AND BRAND IN (");
      int count = 0;
      for (Iterator itr = brands.iterator(); itr.hasNext();) {
        String currentBrandName = (String) itr.next();
        if (count > 0) {
          sb.append(",");
        }
        sb.append("'" + currentBrandName + "'");
        count++;
      }
      sb.append(")");
    }
  }

  public void updateFullRefreshFlagForZone(long accountId) {
    String sql = "UPDATE ACCT_TO_PRICE_ZONE SET FULL_REFRESH_FLAG = 'N' "
        + "WHERE ACCT_ID=? AND FULL_REFRESH_FLAG IN ('Y','y') AND ACTIVE_FLAG IN ('Y','y')";
    Object[] updateParms = new Object[] { new Long(accountId) };
    getJdbcTemplate().update(sql, updateParms);
  }
}

/*
 * $Log: not supported by cvs2svn $ Revision 1.16 2006/09/06 19:51:17 caggarw
 * select from synonym versus table.
 * 
 * Revision 1.15 2006/06/12 21:41:41 caggarw added fields to select query
 * Revision 1.14 2005/09/28 19:12:55 ggdavi Moved Farm Manager role business
 * logic out of DAO and into domain object Revision 1.13 2005/09/06 17:09:03
 * caggarw fixed bug with full refresh logic to get the full refresh of only the
 * zones with full_refresh_flag of Y
 * 
 * Revision 1.12 2005/08/23 21:19:58 ggdavi Cleaned up imports
 * 
 * Revision 1.11 2005/08/16 15:03:01 caggarw Added property fullRefreshFlag to
 * PriceSheet domain object. This value is set from the FULL_REFRESH_FLAG column
 * (set to 'Y' initially) in the ACCT_TO_PRICE_ZONE table, indicating whether a
 * new zone has been assigned to a dealer. The PriceSheetDao sets this flag to
 * 'N' after it gets the Price information the first time.
 * 
 * Revision 1.10 2005/08/11 21:40:12 caggarw changed the acct_to_price_zone_sql
 * to look for price_regions with active flag of "y" or "Y"
 * 
 * Revision 1.9 2005/08/10 17:14:18 ggdavi Modified to return data if no
 * category or brands are specified
 * 
 * Revision 1.8 2005/07/21 23:36:06 caggarw format Revision 1.7 2005/07/21
 * 23:30:47 caggarw added modifyDate to query as per request # 00067
 * 
 * Revision 1.6 2005/06/28 16:00:28 caggarw refactored to add method calls
 * 
 * Revision 1.5 2005/06/27 17:16:41 caggarw remove iterator for brand
 * 
 * Revision 1.4 2005/06/27 16:55:47 caggarw added comment
 * 
 * Revision 1.3 2005/06/27 16:49:25 caggarw refactored to use mappingsqlquery
 * Revision 1.2 2005/06/27 13:37:24 caggarw removed print statement Revision 1.1
 * 2005/06/27 03:44:57 caggarw dao for pricesheet
 */