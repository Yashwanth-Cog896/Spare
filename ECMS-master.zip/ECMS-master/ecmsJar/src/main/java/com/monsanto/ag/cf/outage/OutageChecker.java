/*
 * OutageChecker was created on Apr 8, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.outage;

/**
 * Defines operations for checking whether or not an application or service is
 * in an outage.
 * 
 * @author ajbaldw
 * @version $Id: OutageChecker.java,v 1.1 2005-04-11 21:45:24 ggdavi Exp $
 */
public interface OutageChecker {

  /**
   * Error message for when the service is unavailable or not working right
   */
  public static final String REQUEST_ERROR_MESSAGE = "Unable to determine service outages";

  /**
   * Returns any current outage information for the specified application.
   * 
   * @param appId
   *          Unique identifier of the application
   * @return Outage object representing outage information
   */
  public Outage checkOutage(String appId);

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.1 2005/04/08 21:54:55 ajbaldw Initial
 * Version
 *  
 */