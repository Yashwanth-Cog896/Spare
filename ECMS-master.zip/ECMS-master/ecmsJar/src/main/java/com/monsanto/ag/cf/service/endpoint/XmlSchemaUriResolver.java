package com.monsanto.ag.cf.service.endpoint;

import com.monsanto.ag.soa.ServiceException;

/**
 * Defines operations for resolving XML Schema URIs from an arbitrary registry.
 * 
 * @author Chetna Aggarwal
 * @version $Id: XmlSchemaUriResolver.java,v 1.1 2006-05-08 14:19:30 caggarw Exp $
 */
public interface XmlSchemaUriResolver {

  /**
   * Retrieves the URI of the XML Schema document whose target namespace URI
   * matches the specified namespace URI from an arbitrary registry.
   * 
   * @param schemaRegistrySpec
   *          Location of the XML schema registry
   * @param namespaceUri
   *          URI of the XML schema to retrieve
   * @return URI of the XML schema
   * @throws ServiceException
   *           If the XML Schema URI could not be resolved
   */
  public String resolve(String schemaRegistrySpec, String namespaceUri)
      throws ServiceException;

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/11/09 18:45:44  ggdavi
 * Initial version
 *
 * Revision 1.1  2005/11/07 20:41:03  ggdavi
 * Moved from soapint.axis to soapint, since shared functionality with XFire implementation
 * Revision 1.1 2005/10/27 20:37:30 caggarw
 * Replaced DocumentValidators with SchemaUriResolvers Revision 1.1 2005/10/20
 * 21:47:04 caggarw Initial Version
 * 
 * Revision 1.3 2005/09/06 21:09:07 ggdavi XmlSchemaUriResolver is now an
 * interface with two implementations, WsdlDocumentValidator (the original
 * class, renamed) and AlwaysTrueDocumentValidator (essentially a Null Object,
 * skipping validation). JaxRpcEndpoint pulls the implementation from the Spring
 * application context and passes the current MessageContext as an argument to
 * the validateXmlDocument method along with the XmlDocument.
 * 
 */