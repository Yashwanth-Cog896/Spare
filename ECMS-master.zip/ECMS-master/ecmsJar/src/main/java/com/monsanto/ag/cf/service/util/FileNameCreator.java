package com.monsanto.ag.cf.service.util;

/**
 * Created by jtmurr on 2/4/2016.
 */
public interface FileNameCreator {
    String createFileName();
}
