package com.monsanto.ag.cf.service.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by JTMURR on 8/9/2016.
 */
public class CheckInventoryActualUsagePayload {
    private InputStream inputStream;

    public CheckInventoryActualUsagePayload(String payload) {
        inputStream = this.getClass().getResourceAsStream(payload);
    }

    public void execute(String startElement, String endElement, int maxStringLength) throws IOException {
        if (inputStream == null) {
            System.out.println("No input stream.");
            return;
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder out = new StringBuilder();
        String line;
        int lineNumber = 0;
        while ((line = reader.readLine()) != null) {
            lineNumber++;
            if (line.contains(startElement)) {
                line = line.trim().replace(startElement, "").replace(endElement, "");
                if (line.length() > maxStringLength) {
                    out.append("Line ").append(lineNumber).append(" has ").append(line.length()).append(" characters: ").append(line).append("\n");
                }
            }
        }
        System.out.println(out.toString());
        reader.close();
    }

    public static void main(String[] args) { // something like this...
        String startElement = "<PartnerName>";
        String endElement = "</PartnerName>";
        int maxStringLength = 30;

        if (args.length == 0) {
            System.err.println("Please provide a payload.");
            return;
        }
        try {
            for (String arg : args) {
                System.out.println("Checking payload '" + arg + "'.");
                new CheckInventoryActualUsagePayload(arg).execute(startElement, endElement, maxStringLength);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
