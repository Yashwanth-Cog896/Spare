/*
 * JdbcShipNoticePublicationDao was created on Jul 25, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import com.monsanto.ag.cf.dao.ShipNoticePublicationDao;
import com.monsanto.ag.cf.domain.Conversation;

/**
 * Spring JDBC implementation of the Ship Notice Publication DAO.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcShipNoticePublicationDao.java,v 1.1 2005/07/25 20:55:45
 *          ggdavi Exp $
 */
public class JdbcShipNoticePublicationDao extends BaseJdbcDao implements
    ShipNoticePublicationDao {

  private class ShipNoticePublicationMappingQuery extends MappingSqlQuery {

    private static final String SHIP_NOTICE_PUBLICATION_SQL = "SELECT "
        + "Ship_Notice_Pub_ID, Acct_ID, Conversation_ID, Row_User_ID "
        + "FROM Ship_Notice_Publication "
        + "WHERE Acct_ID = ? AND Consumption_Flag = 'N'";

    private ShipNoticePublicationMappingQuery() {
      super(getDataSource(), SHIP_NOTICE_PUBLICATION_SQL);
      super.declareParameter(new SqlParameter("Acct_ID", Types.INTEGER));
      compile();
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      Conversation publication = new Conversation(rs.getString("Row_User_ID"),
          rs.getLong("Acct_ID"), rs.getString("Conversation_ID"));
      publication.setId(rs.getString("Ship_Notice_Pub_ID"));

      return publication;
    }

  }

  /**
   * @see com.monsanto.ag.cf.dao.ShipNoticePublicationDao#findShipNoticePublicationsByDealer(long)
   */
  public List findShipNoticePublicationsByDealer(long accountId) {
    ShipNoticePublicationMappingQuery query = new ShipNoticePublicationMappingQuery();
    Object[] queryParms = new Object[] { new Long(accountId) };
    return query.execute(queryParms);
  }

  /**
   * @see com.monsanto.ag.cf.dao.ShipNoticePublicationDao#removeShipNoticePublication(com.monsanto.ag.cf.domain.Conversation)
   */
  public void removeShipNoticePublication(Conversation conversation) {
    String sql = "UPDATE Ship_Notice_Publication SET Consumption_Flag = 'Y' "
        + "WHERE Ship_Notice_Pub_Id = ?";
    Object[] updateParms = new Object[] { conversation.getId() };
    getJdbcTemplate().update(sql, updateParms);
  }

  /**
   * @see com.monsanto.ag.cf.dao.ShipNoticePublicationDao#storeShipNoticePublication(com.monsanto.ag.cf.domain.Conversation)
   */
  public void storeShipNoticePublication(Conversation publication,
      String deliveryId) {
    publication.setId(getNextSequenceValue());

    // TODO Feature envy? Consider iBATIS... At least, externalize SQL!
    String sql = "INSERT INTO Ship_Notice_Publication "
        + "(Ship_Notice_Pub_ID, Acct_ID, Conversation_ID, Consumption_Flag, Delivery_ID, "
        + "Row_User_ID, Row_Task_Id) "
        + "VALUES (?, ?, ?, 'N', ?, ?, 'JdbcShipNoticePublicationDao')";
    Object[] values = new Object[] { publication.getId(),
        new Long(publication.getAccountId()), publication.getConversationId(),
        deliveryId, publication.getUserId() };
    getJdbcTemplate().update(sql, values);
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.1 2005/07/25 20:55:45
 * ggdavi Initial version
 * 
 */