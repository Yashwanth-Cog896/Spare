/*
 * GrowerOrderImpl was created on Jun 10, 2008 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import com.monsanto.ag.cf.service.SecureServiceBase;
import com.monsanto.ag.cf.service.SoaClientInvoker;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.util.ConversationIdUtil;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.xml.XmlDocumentBuilder;

/**
 * Service Implementation of the Grower Order web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: GrowerOrderImpl.java,v 1.2 2008-08-04 21:43:00 caggarw Exp $
 */
public class GrowerOrderImpl extends SecureServiceBase implements Identifiable {

    private static final String CONVERSATION_ID_MESSAGE = "Processing Grower Order request with Conversation Id: ";
    private XmlDocumentBuilder xmlDocumentBuilder;


    public GrowerOrderImpl(){}

    public GrowerOrderImpl( SoaClientInvoker soaClientInvoker, XmlDocumentBuilder xmlDocumentBuilder, XmlMessageInformer inputXmlMessageInformer, XmlMessageInformer outputXmlMessageInformer ){

        super( soaClientInvoker, inputXmlMessageInformer, outputXmlMessageInformer );
        this.xmlDocumentBuilder = xmlDocumentBuilder;
    }

    protected ServiceInput processInput(ServiceInput input, Subject subject) {
        return input;
    }

    protected ServiceOutput processOutput( ServiceInput input ) {
        String conversationId = getConversationId();
        ServiceOutput output = getSoaClientInvoker().callSoaClient(input);
        output.setConversationId( conversationId );
        ConversationIdUtil.substituteDocumentIdentifier( output.getXmlChunks().getXmlDocument( xmlDocumentBuilder ),
                                                         conversationId );
        return output;
    }

    protected String getConversationIdMessage(){
        return CONVERSATION_ID_MESSAGE;
    }

    public String getId() {
        return "GO";
    }
}