package com.monsanto.ag.cf.management;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: SEPPA
 * Date: 4/11/12
 * Time: 4:30 PM
 */
public class StatusMonitorServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) {

        try {
            HttpSession session = request.getSession();
            ServletContext context = session.getServletContext();
            String destination = "/monitor.jsp";
            RequestDispatcher dispatcher = context.getRequestDispatcher(destination);
            dispatcher.forward(request, response);
        } catch (ServletException e) {
            Logger.log(new LoggableError("Servlet Exception " + e));
        } catch (IOException e) {
            Logger.log(new LoggableError("IO Exception " + e));
        }
    }
}
