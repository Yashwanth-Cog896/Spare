/*
 * ProductLight was created on Oct 1, 2007 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Represents the basic information in a Product.
 * 
 * @author Chetna Aggarwal
 * @version $Id: ProductLight.java,v 1.4 2009/07/21 20:03:03 mkuchip Exp $
 */
public class ProductLight {

  private String gtin;
  private String legalDescr1;
  private String legalDescr2;
  private String prodClassId;
  private String baseUom;
  private String specieDescr;
  private String useSSU;
  private String displayDescr;
  private String seedBrandName;
  private String stUOMCode;
  
  private String seedCompanyEBID;
  private String brandName;
  private String otherSeedBrandFlag;
  private String gposReportFlag;
  private String irmFlag;
  private String treatmentCode;
  private String treatmentDescr;
  
  
  private PackageStructure package1;

  public ProductLight(String gtin, String legalDescr1, String legalDescr2, String prodClassId, String baseUom,
      String specieDescr, String useSSU, String displayDescr, String seedBrandName, String stUOMCode, PackageStructure package1) {
    this.gtin = gtin;
    this.legalDescr1 = legalDescr1;
    this.legalDescr2 = legalDescr2;
    this.prodClassId = prodClassId;
    this.baseUom = baseUom;
    this.specieDescr = specieDescr;
    this.useSSU = useSSU;
    this.displayDescr = displayDescr;
    this.seedBrandName = seedBrandName;
    this.stUOMCode = stUOMCode;
    this.package1 = package1;
  }
  public ProductLight(String gtin, String legalDescr1, String legalDescr2, String prodClassId, String baseUom,
	      String specieDescr, String useSSU, String displayDescr, String seedBrandName, String stUOMCode, PackageStructure package1,
	      String seedCompanyEBID, String brandName, String otherSeedBrandFlag, String gposReportFlag, String irmFlag, String trmtCode, String trmtDescr) {
	    this.gtin = gtin;
	    this.legalDescr1 = legalDescr1;
	    this.legalDescr2 = legalDescr2;
	    this.prodClassId = prodClassId;
	    this.baseUom = baseUom;
	    this.specieDescr = specieDescr;
	    this.useSSU = useSSU;
	    this.displayDescr = displayDescr;
	    this.seedBrandName = seedBrandName;
	    this.stUOMCode = stUOMCode;
	    this.package1 = package1;
	    this.seedCompanyEBID = seedCompanyEBID;
	    this.brandName = brandName;
	    this.otherSeedBrandFlag = otherSeedBrandFlag;
	    this.gposReportFlag = gposReportFlag;
	    this.irmFlag = irmFlag;
        this.treatmentCode = trmtCode;
        this.treatmentDescr = trmtDescr;
	  }
  
  
  public String getBaseUom() {
    return baseUom;
  }

  public String getDisplayDescr() {
    return displayDescr;
  }

  public String getGtin() {
    return gtin;
  }

  public String getLegalDescr1() {
    return legalDescr1;
  }

  public String getLegalDescr2() {
    return legalDescr2;
  }

  public PackageStructure getPackage1() {
    return package1;
  }

  public String getProdClassId() {
    return prodClassId;
  }

  public String getSeedBrandName() {
    return seedBrandName;
  }

  public String getSpecieDescr() {
    return specieDescr;
  }

  public String getStUOMCode() {
    return stUOMCode;
  }
  
  public String getUseSSU() {
    return useSSU;
  }
  
  

  public String getTreatmentCode() {
    return treatmentCode;
  }
  public String getTreatmentDescr() {
    return treatmentDescr;
  }
  
  public boolean equals(Object obj) {
    if (!(obj instanceof ProductLight)) {
      return false;
    }
    ProductLight rhs = (ProductLight) obj;
    return new EqualsBuilder().append(gtin, rhs.getGtin()).append(legalDescr1, rhs.getLegalDescr1()).append(
        legalDescr2, rhs.getLegalDescr2()).append(prodClassId, rhs.getProdClassId()).append(baseUom, rhs.getBaseUom())
        .append(specieDescr, rhs.getSpecieDescr()).append(useSSU, rhs.getUseSSU()).append(displayDescr,
            rhs.getDisplayDescr()).append(seedBrandName, rhs.getSeedBrandName()).append(stUOMCode, rhs.getStUOMCode()).append(package1, rhs.getPackage1())
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(11, 33).append(gtin).append(legalDescr1).append(legalDescr2).append(prodClassId).append(
        baseUom).append(specieDescr).append(useSSU).append(displayDescr).append(seedBrandName).append(stUOMCode).append(package1)
        .toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).append(gtin).append(legalDescr1).append(legalDescr2)
        .append(prodClassId).append(baseUom).append(specieDescr).append(useSSU).append(displayDescr).append(
            seedBrandName).append(stUOMCode).append(package1).toString();
  }

	public String getSeedCompanyEBID() {
		return seedCompanyEBID;
	}
	
	public String getBrandName() {
		return brandName;
	}
	
	public String getOtherSeedBrandFlag() {
		return otherSeedBrandFlag;
	}
	
	public String getGposReportFlag() {
		return gposReportFlag;
	}
	
	public String getIrmFlag() {
		return irmFlag;
	}
}