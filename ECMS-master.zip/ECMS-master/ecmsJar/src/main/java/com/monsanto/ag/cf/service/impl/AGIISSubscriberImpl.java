package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.cf.domain.AGIISSubscriberResults;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;

public class AGIISSubscriberImpl extends ServiceProxySupport implements	SecureService, Identifiable {
	private XmlDocumentBuilder xmlDocumentBuilder;
	private AGIISIsSubscriberProxy subscriberProxy;

	public ServiceOutput executeSecure(ServiceInput input, Subject subject)	throws ServiceException {
		String subscriberId = getSubscriberId(input);
		AGIISSubscriberResults results = subscriberProxy.checkIsSubscriberValid(subscriberId);
		XmlDocument outputDocument = buildOutputDocument(results);
	    XmlChunks outputXmlChunks = new XmlChunks();
	    outputXmlChunks.addChunk(outputDocument);
	    ServiceOutput serviceOutput = new ServiceOutput(outputXmlChunks);
		return serviceOutput;		
	}

	/**
	 * Get id from request.
	 * @param input
	 * @return
	 */
	private String getSubscriberId(ServiceInput input) {
		String subscriberId = "";
		XmlDocument doc = input.getXmlChunks().getXmlDocumentChunk(xmlDocumentBuilder, 0);
		NodeList nodeList = DOMUtil.getNodeListByTagNameNS(doc.getDOMDocument(), "IdentifierValue", "http://www.monsanto.com/AGIIS/Services/SubscriberRequest/");
		if(nodeList.getLength() > 0){
			Node node = nodeList.item(0);
			 subscriberId = node.getNodeValue();
		}
		return subscriberId;
	}

	private XmlDocument buildOutputDocument(AGIISSubscriberResults results) {
		XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
		XmlElement rootElement = outputDocument.addRootElement("AGIISSubscriberResponse");
		XmlElement isActiveSubscriberElement = rootElement.addChildElement("ActiveSubscriber");
		if (!results.isServiceAvailable()) {
			rootElement.addChildElement("SvcNotAvail");
		}
		isActiveSubscriberElement.setText(String.valueOf(results.isActiveSubscriber()));
		return outputDocument;
	}

	public XmlMessageInformer getInputXmlMessageInformer() {
		return null;
	}

	public XmlMessageInformer getOutputXmlMessageInformer() {
		return null;
	}

    public boolean isValidationRequired() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public XmlMessageInformer getXmlMessageInformer() {
		return null;
	}

	public String getId() {
		return "AGIISSubscriber";
	}

	public void setSubscriberProxy(AGIISIsSubscriberProxy subscriberProxy) {
		this.subscriberProxy = subscriberProxy;
	}
	  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
		    this.xmlDocumentBuilder = xmlDocumentBuilder;
	  }
}