package com.monsanto.ag.cf.service.impl;

import java.util.Date;
import java.util.List;

import javax.security.auth.Subject;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Service Implementation of Customer Review 2 web service for GOAII project.
 * 
 * @author dddoni
 * @version $Id: CustomerReview2Impl.java,v 1.3 2008-08-12 18:02:51 dddoni Exp $
 */
public class CustomerReview2Impl extends CustomerReviewImpl{
	
	private boolean validationRequired = true;

	  public boolean isValidationRequired() {
		return validationRequired;
	}

	public void setValidationRequired(boolean validationRequired) {
		this.validationRequired = validationRequired;
	}

	public static final XmlNamespace NAMESPACE_CUST_REVIEW_RESPONSE = new XmlNamespace("ecms",
      "urn:ecms:schema:growerid:response:2:0");

	  /**
	   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
	   *      javax.security.auth.Subject)
	   */
	  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
	    ServiceOutput output = new ServiceOutput();

	    String conversationId = Utilities.generateConversationId();
	    output.setConversationId(conversationId);

	    Logger.log(new LoggableInfo("Processing Customer Review request with conversation Id: " + conversationId));
	    IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
	    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);

	    Date fromDate = getFromDateFromInputDocument(inputDocument);
	    long accountId = getAccountIdFromInputDocumentOrAuthenicatedUser(inputDocument, identityPrincipal);
	    List customerList = customerReviewDao.getCustomerInformationFmgr(accountId, fromDate);

	    XmlChunks outputXmlChunks = buildCustomerReviewDocuments(conversationId, identityPrincipal, customerList, accountId);
	    output.getXmlChunks().addChunks(outputXmlChunks);
	    
	    return output;
	  }

	  public String getId() {
		    return "CUSTRW2";
		  }

}

