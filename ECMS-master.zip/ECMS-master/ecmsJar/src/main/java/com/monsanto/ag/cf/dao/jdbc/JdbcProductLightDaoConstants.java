package com.monsanto.ag.cf.dao.jdbc;


public class JdbcProductLightDaoConstants {

    public static final String ALL_PRODUCTS_QUERY = "SELECT DISTINCT p.prod_id, " +
            "  pbms.mkt_seg_code, " +
            "  p.prod_class_code product_class_id, " +
            "  uomxref_rr.alias_unrec20_uom_code unrec20_rr_uom_code, " +
            "  pps.universal_prod_code, " +
            "  pps.upc_scc_code gtin, " +
            "  scb.descr seed_company_brand_name, " +
            "  p.acronym_name acronym, " +
            "  t.sdescr biotech_trait, " +
            "  smc.special_treatment_code treatment_code, " +
            "  tr.descr treatment_descr, " +
            "  decode(p.prod_class_code,   'H',   pc.descr,   'D',   tc.display_descr,   'N',   'N/A') display_descr, " +
            "  p.species_code, " +
            "  tl.license_required license_req_flag, " +
            "  tg.trait_group_id license_trait_grp_id, " +
            "  decode(tolerance.trait_code,   NULL,   'N',   'Y') irm_flag, " +
            "  decode(p.prod_status_code,   'AC',   'Y',   'N') prod_active_flag, " +
            "  greatest(p.row_modify_date,   pps.row_modify_date,   nvl(mpl.row_modify_date,   p.row_modify_date)) update_date, " +
            "  p.row_entry_date row_entry_date, " +
            "  p.legal_descr_1, " +
            "  p.legal_descr_2, " +
            "  pkg.descr description_text, " +
            "  p.base_quantity, " +
            "  uomxref_base.alias_unrec20_uom_code unrec20_base_uom_code, " +
            "  p.use_ssu, " +
            "  smc.grade_size_desc, " +
            "  decode(p.prod_status_code,   'AC',   'Y',   'N') pkg_active_flag, " +
            "  pps.quantity_of_base_package, " +
            "  pps.quantity_of_child_package, " +
            "  pps.calculated_volume, " +
            "  pps.gross_weight, " +
            "  pps.tare_weight, " +
            "  pps.net_weight, " +
            "  pps.LENGTH, " +
            "  pps.width, " +
            "  pps.height, " +
            "  pps.square_feet, " +
            "  pps.cubic_feet, " +
            "  pps.stacking_height, " +
            "  decode(p.prod_status_code,   'AC',   'Y',   'N') pkgcnfg_active_flag, " +
            "  nvl(prssr.processor_code,   'N') processor_code, " +
            "  CASE " +
            "WHEN mpl.mat_group_code = 'GT010' " +
            " AND mpl.species_code = 'T' " +
            " AND mpl.package_size_code = 'DV' " +
            " AND mpl.package_type_code = '30' THEN " +
            "  '38' " +
            "WHEN mpl.mat_group_code = 'GS010' " +
            " AND mpl.species_code = 'S' " +
            " AND mpl.package_size_code = '87' " +
            " AND mpl.package_type_code = '15' THEN " +
            "  '50' " +
            "WHEN mpl.mat_group_code = 'GL012' " +
            " AND mpl.species_code = 'L' " +
            " AND mpl.package_size_code = 'CZ' " +
            " AND mpl.package_type_code = '15' THEN " +
            "  '45' " +
            "WHEN mpl.mat_group_code = 'GL010' " +
            " AND mpl.species_code = 'L' " +
            " AND mpl.package_type_code = '06' THEN " +
            "  '20' " +
            "WHEN mpl.mat_group_code = 'GC010' " +
            " AND mpl.species_code = 'C' " +
            " AND mpl.package_size_code = 'CZ' " +
            " AND mpl.package_type_code = '15' THEN " +
            "  '45' " +
            "WHEN mpl.mat_group_code = 'GC010' " +
            " AND mpl.species_code = 'C' " +
            " AND mpl.package_size_code = '87' " +
            " AND mpl.package_type_code = '15' THEN " +
            "  '50' " +
            "WHEN mpl.mat_group_code = 'GC010' " +
            " AND mpl.species_code = 'C' " +
            " AND mpl.package_size_code = '29' " +
            " AND mpl.package_type_code = '15' THEN " +
            "  '40' " +
            "WHEN mpl.mat_group_code = 'GB010' " +
            " AND mpl.species_code = 'B' " +
            " AND mpl.package_size_code = 'EB' " +
            " AND mpl.package_type_code = '06' THEN " +
            "  '40' " +
            "WHEN mpl.mat_group_code = 'GB010' " +
            " AND mpl.species_code = 'B' " +
            " AND mpl.package_size_code = '87' " +
            " AND mpl.package_type_code = '15' THEN " +
            "  '50' " +
            "WHEN mpl.mat_group_code = 'GB010' " +
            " AND mpl.species_code = 'B' " +
            " AND mpl.package_size_code = '29' " +
            " AND mpl.package_type_code = '06' THEN " +
            "  '40' " +
            "WHEN mpl.mat_group_code = 'GB010' " +
            " AND mpl.package_type_code = '06' THEN " +
            "  '40' " +
            "ELSE " +
            "  '1' " +
            "END unit_qty, " +
            "  spd.order_uom_id, " +
            "  b.brand_code, " +
            "  b.descr brand_descr, " +
            "  p.epa_reg_num, " +
            "  s.descr specie_descr, " +
            "  spd.seed_co_name brand_name, " +
            "  ax.alias_id ebid, " +
            "  decode(p.prod_class_code,   'E',   'Y',   'N') other_seed_brand_flag, " +
            "  p.base_quantity *pps.quantity_of_base_package prod_unit_conv, " +
            "  decode(gposflag.prod_id,   NULL,   'N',   'Y') gpos_report_flag " +
            "FROM s_prod p, " +
            "  s_prod_xref px, " +
            "  s_prod_package_struct pps, " +
            "  s_package pkg, " +
            "  s_prod_acct_usage pau, " +
            "    (SELECT prod_id, " +
            "     mkt_seg_code " +
            "   FROM s_prod_by_mkt_seg " +
            "   WHERE mkt_seg_code IN('ST',    'CH')) " +
            "pbms, " +
            "  s_trait t, " +
            "  s_prod_to_trait_license ptl, " +
            "  s_trait_license tl, " +
            "  s_trait_license_group tlg, " +
            "  s_trait_group tg, " +
            "  s_trait_category tc, " +
            "  s_seed_mat_char smc, " +
            "  s_treatment tr, " +
            "  s_seed_company_brand scb, " +
            "  s_master_prod_list mpl, " +
            "    (SELECT tta.trait_code, " +
            "     MAX(ta.processor_type_code) processor_code " +
            "   FROM s_trait_to_trait_attr tta, " +
            "     s_trait_attr ta " +
            "   WHERE ta.trait_attr_id = tta.trait_attr_id " +
            "   GROUP BY tta.trait_code) " +
            "prssr, " +
            "    (SELECT DISTINCT bp.prod_id, " +
            "     bp.active_flag, " +
            "     bp.eff_end_date, " +
            "     bp.base_rate " +
            "   FROM cdw.base_price_mv bp, " +
            "     s_prod p " +
            "   WHERE p.prod_id = bp.prod_id " +
            "   AND p.prod_class_code = 'H') " +
            "bp, " +
            "  s_ird_parameter ip, " +
            "  dsrbase.material m, " +
            "  s_prod_chem pc, " +
            "  s_brand b, " +
            "  s_chem_family cf, " +
            "  s_seed_species_to_base_uom ssbu, " +
            "  dm_seed_product_dim spd, " +
            "    (SELECT DISTINCT uom_code, " +
            "     alias_unrec20_uom_code " +
            "   FROM s_uom_xref) " +
            "uomxref_rr, " +
            "    (SELECT DISTINCT uom_code, " +
            "     alias_unrec20_uom_code " +
            "   FROM s_uom_xref) " +
            "uomxref_base, " +
            "    (SELECT DISTINCT tta.trait_code, " +
            "     tolerance_code " +
            "   FROM s_trait_to_trait_attr tta, " +
            "     s_trait_attr ta " +
            "   WHERE tta.trait_attr_id = ta.trait_attr_id " +
            "   AND tolerance_code = 'I') " +
            "tolerance, " +
            "  s_seed_species s, " +
            "  s_acct_xref ax, " +
            "    (SELECT prod_id " +
            "   FROM s_prod " +
            "   WHERE prod_class_code = 'D' " +
            "   AND legal_descr_1 NOT LIKE '%PROMO%' " +
            "   UNION " +
            "   SELECT prod_id " +
            "   FROM s_prod_attr " +
            "   WHERE prod_attr_type_code = 'GPOSRPT') " +
            "gposflag " +
            "WHERE prod_status_code = 'AC' " +
            " AND p.prod_id = px.prod_id " +
            " AND px.system_type_code IN('SAP',   'AGIIS') " +
            " AND px.active_flag = 'Y' " +
            " AND px.alias_prod_code = m.material_id(+) " +
            " AND(px.uom_code = pps.uom_code OR px.uom_code = p.base_uom_code) " +
            " AND p.prod_id = pps.prod_id " +
            " AND pps.uom_code = uomxref_rr.uom_code " +
            " AND p.base_uom_code = uomxref_base.uom_code " +
            " AND p.prod_id = pau.prod_id(+) " +
            " AND pau.rank(+) = 1 " +
            " AND pau.acct_id = ax.acct_id(+) " +
            " AND ax.active_flag(+) = 'Y' " +
            " AND ax.system_type_code(+) = 'IC' " +
            " AND(pps.universal_prod_code IS NOT NULL OR pps.upc_scc_code IS NOT NULL) " +
            " AND p.package_code = pkg.package_code " +
            " AND p.prod_id = pbms.prod_id(+) " +
            " AND p.brand_code = b.brand_code " +
            " AND b.major_prod_chem_code = pc.prod_chem_code " +
            " AND pc.chem_family_code = cf.chem_family_code " +
            " AND p.prod_id = ptl.prod_id(+) " +
            " AND ptl.trait_license_id = tl.trait_license_id(+) " +
            " AND ptl.trait_license_id = tlg.trait_license_id(+) " +
            " AND tlg.trait_group_id = tg.trait_group_id(+) " +
            " AND tl.trait_code = t.trait_code(+) " +
            " AND t.trait_code = prssr.trait_code(+) " +
            " AND t.trait_code = tolerance.trait_code(+) " +
            " AND t.trait_category_id = tc.trait_category_id(+) " +
            " AND px.alias_prod_code = smc.seed_mat_char_id(+) " +
            " AND smc.special_treatment_code = tr.treatment_code(+) " +
            " AND pau.seed_company_brand_id = scb.seed_company_brand_id(+) " +
            " AND p.prod_id = spd.product_id(+) " +
            " AND p.base_uom_code = ssbu.base_uom_code(+) " +
            " AND p.species_code = ssbu.species_code(+) " +
            " AND ssbu.order_uom_code(+) = 'SS' " +
            " AND p.prod_id = mpl.prod_id(+) " +
            " AND p.prod_id = bp.prod_id(+) " +
            " AND ip.ird_parameter_code = 'SEED_YEAR' ";

} // end of class
