/*
 * JdbcActivityDocumentDao was created on May 6, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.zip.GZIPInputStream;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.LobRetrievalFailureException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.ActivityDocumentDao;
import com.monsanto.ag.util.GZipStreamHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

/**
 * Spring JDBC implemenation of the Activity Document DAO.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcActivityDocumentDao.java,v 1.1 2005/05/09 18:05:29 ggdavi
 *          Exp $
 * @see SeedTrakInsourcingScope FC84e
 */
public class JdbcActivityDocumentDao extends BaseJdbcDao implements
    ActivityDocumentDao {

  private LobHandler lobHandler;
  private XmlDocumentBuilder xmlDocumentBuilder;

  /**
   * Maps the results from database queries to XML Document objects.
   */
  private abstract class ActivityDocumentMappingQuery extends MappingSqlQuery {

    public ActivityDocumentMappingQuery(DataSource dataSource, String sql) {
      super(dataSource, sql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      InputStream rsStream = lobHandler.getBlobAsBinaryStream(rs, "Xml_Msg");
      try {
        GZIPInputStream gzipStream = new GZIPInputStream(rsStream);
        Reader reader = new InputStreamReader(gzipStream);
        return xmlDocumentBuilder.createXmlDocument(reader);
      } catch (IOException e) {
        Logger.log(new LoggableWarning(e));
        throw new LobRetrievalFailureException(e.getMessage());
      }
    }

  }

  /**
   * Extends the base mapping query class by defining a conversationId-based SQL
   * statement that will map to a single XML Document object.
   */
  private class ConversationIdMappingQuery extends ActivityDocumentMappingQuery {

    private static final String ACTIVITY_DOCUMENT_SQL = "SELECT der.Xml_Msg "
        + "FROM Data_Exchange_Repository der, Data_Exchange_Log del "
        + "WHERE der.Data_Exchange_Id = del.Data_Exchange_Id "
        + "AND del.Conversation_Id = ? AND der.Root_Node_Name = ?";

    private ConversationIdMappingQuery() {
      super(getDataSource(), ACTIVITY_DOCUMENT_SQL);
      super
          .declareParameter(new SqlParameter("Conversation_Id", Types.VARCHAR));
      super
      .declareParameter(new SqlParameter("Root_Node_Name", Types.VARCHAR));
      compile();
    }

  }

  /**
   * Extends the base mapping query class by defining a SQL statement based on
   * dealer, service and seed year that will map to potentiall multiple XML
   * Document objects.
   */
  private class DealerServiceSeedYearMappingQuery extends
      ActivityDocumentMappingQuery {

    private static final String ACTIVITY_DOCUMENT_SQL = "SELECT der.Xml_Msg "
        + "FROM Data_Exchange_Repository der, Data_Exchange_Log del "
        + "WHERE der.Data_Exchange_Id = del.Data_Exchange_Id "
        + "AND del.Acct_Id = ? AND del.Data_Exchange_Type_Code = ? AND der.Root_Node_Name = ? AND Seed_Year = ? "
        + "ORDER BY der.Data_Exchange_Id";

    private DealerServiceSeedYearMappingQuery() {
      super(getDataSource(), ACTIVITY_DOCUMENT_SQL);
      super.declareParameter(new SqlParameter("Acct_Id", Types.INTEGER));
      super.declareParameter(new SqlParameter("Data_Exchange_Type_Code",
          Types.VARCHAR));
      super.declareParameter(new SqlParameter("Root_Node_Name",
          Types.VARCHAR));
      super.declareParameter(new SqlParameter("Seed_Year", Types.VARCHAR));
      compile();
    }

  }

  /**
   * @see com.monsanto.ag.cf.dao.ActivityDocumentDao#findActivityDocumentByConversation(java.lang.String, String)
   */
  public XmlDocument findActivityDocumentByConversation(String conversationId, String rootNodeName) {
    ConversationIdMappingQuery documentQuery = new ConversationIdMappingQuery();
    Object[] parameters = new Object[] { conversationId, rootNodeName };
    return (XmlDocument) documentQuery.findObject(parameters);
  }

  /**
   * @see com.monsanto.ag.cf.dao.ActivityDocumentDao#findActivityDocumentsByDealerServiceSeedYear(long,
   *      java.lang.String, String, java.lang.String)
   */
  public List findActivityDocumentsByDealerServiceSeedYear(long accountId,
      String serviceId, String rootNodeName, String seedYear) {
    DealerServiceSeedYearMappingQuery documentQuery = new DealerServiceSeedYearMappingQuery();
    Object[] parameters = new Object[] { new Long(accountId), serviceId, rootNodeName, 
        seedYear };
    return documentQuery.execute(parameters);
  }

  /**
   * @see com.monsanto.ag.cf.dao.ActivityDocumentDao#removeActivityDocuments(java.lang.String,
   *      long, String)
   */
  public void removeActivityDocuments(String serviceId, long accountId, String rootNodeName) {
    String sql = "DELETE FROM Data_Exchange_Repository WHERE Data_Exchange_Id IN "
        + "(SELECT Data_Exchange_Id FROM Data_Exchange_Log "
        + "WHERE Data_Exchange_Type_Code = ? AND Acct_Id = ? AND Root_Node_Name = ?)";
    Object[] parameters = new Object[] { serviceId, new Long(accountId), rootNodeName };
    getJdbcTemplate().update(sql, parameters);
  }

  /**
   * @see com.monsanto.ag.cf.dao.ActivityDocumentDao#storeActivityDocument(String,
   *      XmlDocument, String)
   */
  public void storeActivityDocument(final String userActivityId,
      final XmlDocument xmlDocument, final String rootNodeName) {
    if (xmlDocument == null) {
      throw new DataIntegrityViolationException("XML document cannot be null");
    }
    
    String sql = "INSERT INTO Data_Exchange_Repository "
        + "(Data_Exchange_ID, Xml_Msg, Root_Node_Name) VALUES (?, ?, ?)";
    AbstractLobCreatingPreparedStatementCallback lobCallback = new AbstractLobCreatingPreparedStatementCallback(
        lobHandler) {

      protected void setValues(PreparedStatement ps, LobCreator lobCreator)
          throws SQLException, DataAccessException {
        ps.setString(1, userActivityId);

        GZipStreamHelper helper = new GZipStreamHelper();
        InputStream rsStream = helper.compressStream(xmlDocument
            .getInputStream());
        lobCreator.setBlobAsBinaryStream(ps, 2, rsStream, 0);
        ps.setString(3, rootNodeName);
      }

    };
    getJdbcTemplate().execute(sql, lobCallback);
  }

  public void setLobHandler(LobHandler lobHandler) {
    this.lobHandler = lobHandler;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.11  2005/12/01 19:34:31  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.10  2005/11/15 17:19:16  ggdavi
 * Use GZipStreamHelper for compression
 * Revision 1.9 2005/08/09 17:07:42
 * ggdavi Removed extraneous to do comment
 * 
 * Revision 1.8 2005/07/25 20:57:37 ggdavi XML documents now stored as
 * compressed bytes in BLOB column
 * 
 * Revision 1.7 2005/07/21 14:48:57 ggdavi Fleshed out and refactored
 * com.monsanto.ag.util to make more object-oriented, in that most functionality
 * has been pushed to the XmlDocument and XmlElement objects
 * 
 * Revision 1.6 2005/07/15 17:39:58 ggdavi Added xmlDocumentProcessor field;
 * implemented the findActivityDocument* methods; added several MappingSqlQuery
 * nested subclasses Revision 1.5 2005/07/14 21:33:45 ggdavi Added
 * findActivityDocument* methods
 * 
 * Revision 1.4 2005/05/26 21:56:37 ggdavi Added removeActivityDocument method
 * Revision 1.3 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.2 2005/05/09 20:29:36 ggdavi Added exception test cases, including
 * checks for null documents Revision 1.1 2005/05/09 18:05:29 ggdavi Initial
 * version
 * 
 */