/*
 * Log4JLoggingConfigurer was created on Mar 28, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.config;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.monsanto.AbstractLogging.CompositeLogDevice;
import com.monsanto.AbstractLogging.IDebugLog;
import com.monsanto.AbstractLogging.IErrorLog;
import com.monsanto.AbstractLogging.IInfoLog;
import com.monsanto.AbstractLogging.ITraceLog;
import com.monsanto.AbstractLogging.IWarningLog;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.I_Log4JParameters;
import com.monsanto.Log4JLogging.Log4JDebugLog;
import com.monsanto.Log4JLogging.Log4JErrorLog;
import com.monsanto.Log4JLogging.Log4JInfoLog;
import com.monsanto.Log4JLogging.Log4JMidnightRollingFileLogDevice;
import com.monsanto.Log4JLogging.Log4JTraceLog;
import com.monsanto.Log4JLogging.Log4JWarningLog;
import com.monsanto.Log4JLogging.Log4J_XML_FileLogDevice;
import com.monsanto.ag.logging.Log4JSmtpLogDevice;

/**
 * Configures application logging from a Spring bean factory using the ATF
 * Logging packages.
 * 
 * @author Gareth Davies
 * @version $Id: Log4JLoggingConfigurer.java,v 1.1 2005/04/07 15:40:32 ggdavi
 *          Exp $
 */
public class Log4JLoggingConfigurer implements InitializingBean, DisposableBean {

  private static final Level DEFAULT_LOGGING_LEVEL = Level.INFO;

  private String appName;
  private String logFolder;
  private boolean useXmlLogDevice;
  private String errorEmailSmtpHost;
  private int errorEmailSmtpPort;
  private String errorEmailRecipientList;
  private String defaultLevel;
  private List defaultLevelPackages;
  private boolean tracingOn;

  /**
   * Registers loggers with log devices and sets default logging levels.
   * 
   * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
   */
  public void afterPropertiesSet() throws Exception {
    CompositeLogDevice compositeLogDevice = new CompositeLogDevice();
    compositeLogDevice.add(new Log4JMidnightRollingFileLogDevice(logFolder
        + File.separator + appName + ".log"));
    if (useXmlLogDevice) {
      compositeLogDevice.add(new Log4J_XML_FileLogDevice(logFolder
          + File.separator + appName + ".xml"));
    }
    if (StringUtils.isNotBlank(errorEmailRecipientList)) {
      compositeLogDevice.add(new Log4JSmtpLogDevice(getErrorEmailSmtpHost(),
          getErrorEmailSmtpPort(), appName, errorEmailRecipientList,
          I_Log4JParameters.sf_cstrDEFAULT_RECORD_FORMAT));
    }

    Logger.register(new Log4JDebugLog(appName, compositeLogDevice));
    Logger.register(new Log4JInfoLog(appName, compositeLogDevice));
    Logger.register(new Log4JWarningLog(appName, compositeLogDevice));
    Logger.register(new Log4JErrorLog(appName, compositeLogDevice));
    Logger.register(new Log4JTraceLog(appName, compositeLogDevice));

    setDefaultLevelsForSpecifiedLoggers();
    
    if (tracingOn) {
      Logger.enableTrace();
    }
  }

  private void setDefaultLevelsForSpecifiedLoggers() {
    if (defaultLevelPackages != null) {
      Level level = getDefaultLevel();

      for (Iterator itPackage = defaultLevelPackages.iterator(); itPackage
          .hasNext();) {
        String defaultLevelPackage = (String) itPackage.next();
        org.apache.log4j.Logger logger = org.apache.log4j.Logger
            .getLogger(defaultLevelPackage);
        logger.setLevel(level);
      }
    }
  }

  /**
   * Deregister loggers and stop the logging.
   * <p>
   * FIXME Make this last bean destroyed, else other bean destruction not logged
   * 
   * @see org.springframework.beans.factory.DisposableBean#destroy()
   */
  public void destroy() throws Exception {
//    Logger.disableTrace();
//    
//    Logger.register((IDebugLog) null);
//    Logger.register((IErrorLog) null);
//    Logger.register((IInfoLog) null);
//    Logger.register((IWarningLog) null);
//    Logger.register((ITraceLog) null);
//
//    Logger.closeLogging();
  }

  public void setAppName(String appName) {
    this.appName = appName;
  }

  public void setLogFolder(String logFolder) {
    this.logFolder = logFolder;
  }

  public void setUseXmlLogDevice(boolean useXmlLogDevice) {
    this.useXmlLogDevice = useXmlLogDevice;
  }

  private String getErrorEmailSmtpHost() {
    if (StringUtils.isEmpty(errorEmailSmtpHost)) {
      return Log4JSmtpLogDevice.DEFAULT_SMTP_HOST;
    } else {
      return errorEmailSmtpHost;
    }
  }

  public void setErrorEmailSmtpHost(String errorEmailSmtpHost) {
    this.errorEmailSmtpHost = errorEmailSmtpHost;
  }

  private int getErrorEmailSmtpPort() {
    if (errorEmailSmtpPort == 0) {
      return Log4JSmtpLogDevice.DEFAULT_SMTP_PORT;
    } else {
      return errorEmailSmtpPort;
    }
  }

  public void setErrorEmailSmtpPort(int errorEmailSmtpPort) {
    this.errorEmailSmtpPort = errorEmailSmtpPort;
  }

  public void setErrorEmailRecipientList(String errorEmailRecipientList) {
    this.errorEmailRecipientList = errorEmailRecipientList;
  }

  private Level getDefaultLevel() {
    if (StringUtils.isEmpty(defaultLevel)) {
      return DEFAULT_LOGGING_LEVEL;
    } else {
      Level level = Level.toLevel(defaultLevel);
      if (!defaultLevel.equals(level.toString())) {
        level = DEFAULT_LOGGING_LEVEL;
      }

      return level;
    }
  }

  public void setDefaultLevel(String defaultLoggingLevel) {
    this.defaultLevel = defaultLoggingLevel;
  }

  public void setDefaultLevelPackages(List defaultLevelPackages) {
    this.defaultLevelPackages = defaultLevelPackages;
  }

  public void setTracingOn(boolean tracingOn) {
    this.tracingOn = tracingOn;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.8  2005/12/21 15:40:21  ggdavi
 * Use StringUtils to simplify code
 *
 * Revision 1.7  2005/08/26 15:33:01  ggdavi
 * Added tracingOn property to the Log4JLoggingConfigurer to enable and disable AbstractLogging tracing
 *
 * Revision 1.6  2005/08/02 20:57:38  ggdavi
 * Modified service interfaces, implementations and advice to support message/document chunking
 *
 * Revision 1.5  2005/07/28 18:12:58  ggdavi
 * Removed XML log device
 *
 * Revision 1.4  2005/06/30 17:43:26  ggdavi
 * Moved ag.aop, ag.config and ag.message packages under the ag.cf package
 *
 * Revision 1.2  2005/06/28 16:48:57  ggdavi
 * Use StringUtils where it makes sense
 *
 * Revision 1.1  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.2  2005/04/08 18:12:09  ggdavi
 * Added patternLayout constructor argument to Log4JSmtpLogAppender
 * Revision 1.1 2005/04/07 15:40:32 ggdavi
 * Moved from web to config package
 * 
 * Revision 1.1 2005/03/28 19:26:38 ggdavi Initial version
 *  
 */