package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

/**
 * POJO implementation of the GOPPOS web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: GOPPOSImpl.java,v 1.4 2006-06-21 21:58:27 caggarw Exp $
 */
public class GOPPOSImpl extends ServiceProxySupport implements SecureService, Identifiable {

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  
  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "GOPPOS";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

    public boolean isValidationRequired() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    String conversationId = Utilities.generateConversationId();
    Logger.log(new LoggableInfo("Processing GOPPOS data with conversation Id: " + conversationId));
    XmlDocument fullInputDocument = validateInputDocument(input);
    ServiceOutput output = delegateRequestToPreliminaryValidationService(fullInputDocument, conversationId);
    output.setConversationId(conversationId);
    return output;
  }

  private XmlDocument validateInputDocument(ServiceInput input) {
    XmlChunks inputXmlChunks = input.getXmlChunks();
    if (inputXmlChunks.getCount() == 0) {
      throw new ServiceException("No XML document was provided for the GOPPOS service");
    } else {
      String xpathTransaction = inputXmlMessageInformer.getXpathTransaction();
      inputXmlChunks.setXpathRepeatingElement(xpathTransaction);
      return inputXmlChunks.getXmlDocument(xmlDocumentBuilder);
    }
  }

  private ServiceOutput delegateRequestToPreliminaryValidationService(XmlDocument inputDocument, String conversationId) {
    ServiceInput input = new ServiceInput(inputDocument);
    input.addParameter("messageID", conversationId);
    ServiceOutput output = soaClient.call(serviceId, input);
    return output;
  }  

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }  

}
