package com.monsanto.ag.cf.service.util;

import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

/**
 * Created by JTMURR on 2/2/2016.
 */
public interface ResponseBuilder {
    XmlDocument build(XmlDocumentBuilder xmlDocumentBuilder, String message);
}
