/*
 * ActivityDocumentDao was created on May 6, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import java.util.List;

import com.monsanto.ag.xml.XmlDocument;

/**
 * Data Access Object for the XML message associated with a user activity.
 * 
 * @author Gareth Davies
 * @version $Id: ActivityDocumentDao.java,v 1.7 2006-06-21 21:58:27 caggarw Exp $
 * @see SeedTrakInsourcingScope FC84e
 */
public interface ActivityDocumentDao {

  public XmlDocument findActivityDocumentByConversation(String conversationId, String rootNodeName);

  public List findActivityDocumentsByDealerServiceSeedYear(long accountId, String serviceId, String rootNodeName,
      String seedYear);

  public void removeActivityDocuments(String serviceId, long accountId, String rootNodeName);

  public void storeActivityDocument(String userActivityId, XmlDocument xmlDocument, String rootNodeName);

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.6 2005/12/01 19:34:31 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks
 * 
 * Revision 1.5 2005/07/21 14:48:57 ggdavi Fleshed out and refactored
 * com.monsanto.ag.util to make more object-oriented, in that most functionality
 * has been pushed to the XmlDocument and XmlElement objects
 * 
 * Revision 1.4 2005/07/14 21:33:33 ggdavi Added findActivityDocument* methods
 * Revision 1.3 2005/05/26 21:56:37 ggdavi Added removeActivityDocument method
 * 
 * Revision 1.2 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.1 2005/05/06 17:41:13 ggdavi Initial version
 * 
 */