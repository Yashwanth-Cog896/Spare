/*
 * ProductDao was created on Jun 20, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Defines persistence-related operations for commercial product information.
 * 
 * @author Gareth Davies
 * @version $Id: ProductDao.java,v 1.1 2008-07-18 21:30:01 gjkell Exp $
 */
public interface ProductDao {

  public List findProductsByDateCategoryBrand(String requestingEntity, Date lastModifiedDate,
      String category, Set brands) throws WrappingException;

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.5  2006/03/11 07:27:08  mecoru
 * WrappingException import changed from dataservices to Util.Exceptions: Done by automated script
 *
 * Revision 1.4  2005/07/05 21:01:39  ggdavi
 * Added an activeFlag parameter to findProductsByDateCategoryBrand
 * Revision 1.3 2005/06/27 22:01:37 ggdavi Methods now
 * throw a WrappingException
 * 
 * Revision 1.2 2005/06/23 16:15:16 ggdavi Replaced getProducts method with
 * findProductsByDateCategoryBrand Revision 1.1 2005/06/20 20:11:52 ggdavi
 * Initial version
 *  
 */