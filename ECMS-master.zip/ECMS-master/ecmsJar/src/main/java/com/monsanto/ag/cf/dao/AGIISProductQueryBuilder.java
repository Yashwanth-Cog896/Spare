package com.monsanto.ag.cf.dao;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.domain.Product;

import java.util.Date;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: PPVASI
 * Date: Jul 11, 2011
 * Time: 9:18:24 AM
 */
public class AGIISProductQueryBuilder extends ProductQueryBuilder {

    private Date lastModifiedDate;
    private String category;
    private Set brands;

    public AGIISProductQueryBuilder(Date lastModifiedDate, String category, Set brands) {
        this.lastModifiedDate = lastModifiedDate;
        this.category = category;
        this.brands = brands;
    }

    @Override
    public void buildQuery() {
        String query = staticQuery + getLastModifiedDateTimeWhereClause(lastModifiedDate) + getCategoryWhereClause(category)
                + getOrderByClause();
        Logger.log(new DebugLogEvent("Product Query:"+query));
        productQuery.setQuery(query);
    }

    private String getCategoryWhereClause(String category) {
        if(Product.SEGMENT_SEED.equalsIgnoreCase(category)) {
            return getSeedCategoryWhereClause();
        }else if(Product.SEGMENT_CHEMICAL.equalsIgnoreCase(category)){
            return getChemicalCategoryWhereClause();
        }else if(Product.SEGMENT_ALL.equalsIgnoreCase(category)) {
            return getAllCategoryWhereClause();
        }else {
            throw new IllegalArgumentException("Invalid category :" + category);
        }
    }

    private String getSeedCategoryWhereClause() {
        return " AND ((" + getClassCodeDWhereClause() + ") OR (" + getClassCodeNWhereClause() +") OR (" + getClassCodeD2WhereClause()+")"+")" +
                " AND " + getMktSegmentSTWhereClause();
    }

    protected String getChemicalCategoryWhereClause() {
        return " AND "+ getClassCodeHWhereClause() +
                "-- AND " + getMktSegmentCHWhereClause() + "\n";
    }

    protected String getAllCategoryWhereClause() {
        //Mkt Seg Code condition is not required, because in the static query only ST, CH are considered
        return " AND ((" + getClassCodeDWhereClause() + ") OR (" + getClassCodeHWhereClause() + ") OR ("
                + getClassCodeNWhereClause() +"))";
    }
}
