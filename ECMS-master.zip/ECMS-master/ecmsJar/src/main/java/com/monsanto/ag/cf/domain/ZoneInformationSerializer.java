package com.monsanto.ag.cf.domain;

import com.monsanto.ag.cf.domain.ZoneInformation;
import com.monsanto.ag.xml.XmlElement;
import org.apache.commons.lang.StringUtils;

import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JTMURR
 * Date: Jun 30, 2011
 * Time: 11:08:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class ZoneInformationSerializer {
    public void addZoneInformationToTransactionNode(final XmlElement transactionNode, final List zones) {
        for (Iterator zoneItr = zones.iterator(); zoneItr.hasNext();) {
            ZoneInformation zone = (ZoneInformation) zoneItr.next();
            if (zone != null) {
                addChildElementsToTransactionNode(transactionNode, zone);
            }
        }
    }

    private void addChildElementsToTransactionNode(final XmlElement transactionNode, final ZoneInformation zone) {
        XmlElement zoneNode = transactionNode.addChildElement("AgronomicZone");
        addChildElementsToZoneNode(zoneNode, zone);
    }

    public void addZoneInformationToResponseNode(final XmlElement responseNode, final List zones) {
        if (zones != null) {
            for (Iterator zoneItr = zones.iterator(); zoneItr.hasNext();) {
                ZoneInformation zone = (ZoneInformation) zoneItr.next();
                if (zone != null) {
                    addChildElementsToResponseNode(responseNode, zone);
                }
            }
        }
    }

    private void addChildElementsToResponseNode(final XmlElement responseNode, final ZoneInformation zone) {
        XmlElement zoneNode = responseNode.addChildElement("AgronomicZone");
        addChildElementsToZoneNode(zoneNode, zone);
    }

    private void addChildElementsToZoneNode(final XmlElement zoneNode, final ZoneInformation zone) {
        if (StringUtils.isNotBlank(zone.getZoneCode())) {
            zoneNode.addChildElement("ZoneCode", zone.getZoneCode());
        }
        if (StringUtils.isNotBlank(zone.getCropCode())) {
            zoneNode.addChildElement("CropCode", zone.getCropCode());
        }
        if (StringUtils.isNotBlank(zone.getAZRDescr())) {
            zoneNode.addChildElement("Crop", zone.getAZRDescr());
        }
        if (StringUtils.isNotBlank(zone.getZoneDescr())) {
            zoneNode.addChildElement("ZoneDescription", zone.getZoneDescr());
        }
        if (StringUtils.isNotBlank(zone.getZoneYear())) {
            zoneNode.addChildElement("SeedYear", zone.getZoneYear());
        }
    }
}
