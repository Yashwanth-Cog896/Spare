/*
FarmManagerDao was created on May 24, 2005 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao;

import java.util.List;

/**
 * Data Access Object for FarmManagerList
 * @author CAGGARW
 * @version $Id: FarmManagerDao.java,v 1.1 2005-05-24 22:14:07 caggarw Exp $
 */
public interface FarmManagerDao {
  
  public List getFarmManagers();
  
}


/*
 * $Log: not supported by cvs2svn $
*/