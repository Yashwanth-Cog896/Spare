/*
 * Device was created on Oct 3, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.domain;

/**
 * Represents the information inside a Device.
 * @author Chetna Aggarwal
 * @version $Id: Device.java,v 1.1 2007-10-22 21:18:21 caggarw Exp $
 */
public class Device {

  private String appName;
  private String latestVersion;
  private String enabledFlag;

  public void setAppName(String appName) {
    this.appName = appName;
    
  }

  public void setLatestVersion(String latestVersion) {
    this.latestVersion = latestVersion;
  }

  public void setEnabledFlag(String enabledFlag) {
    this.enabledFlag = enabledFlag;
  }

  public String getAppName() {
    return appName;
  }

  public String getEnabledFlag() {
    return enabledFlag;
  }

  public String getLatestVersion() {
    return latestVersion;
  }

  
}
