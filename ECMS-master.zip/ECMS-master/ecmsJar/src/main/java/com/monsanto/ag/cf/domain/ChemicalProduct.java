/*
 * ChemicalProduct was created on July 27, 2011 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import com.monsanto.ag.xml.XmlElement;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.util.Date;

/**
 * Represents a commercial chemical product.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(com.monsanto.ag.xml.XmlElement) appendXmlToElement} method. This XML
 * conforms to the AGIISProductUpdate element of the AGIISNamespacedSchema.xsd
 * XML schema document.
 * 
 * User: PPVASI
 * Date: Jul 27, 2011
 * Time: 9:33:53 AM
 */
public class ChemicalProduct extends Product {

  private String brandCode;
  private String brandDesc;
  private String epaRegNum;


  public ChemicalProduct( boolean ecListMaterial, boolean active, Date addedDate, Date lastModifiedDate,
      String id, String brandCode, String brandDesc, String epaRegNum) {
    super( ecListMaterial, active, addedDate, lastModifiedDate, id );

    this.brandCode = brandCode;
    this.brandDesc = brandDesc;
    this.epaRegNum = epaRegNum;
  }

  /**
   * @see com.monsanto.ag.cf.domain.Product#shallowCloneImplementation()
   */
  protected Product shallowCloneImplementation() {
    return new ChemicalProduct( isEcListMaterial(), isActive(), getAddedDate(), getLastModifiedDate(),
        getId(), brandCode, brandDesc, epaRegNum);
  }

  /**
   * @see com.monsanto.ag.cf.domain.Product#addTypeSpecificChildElements(com.monsanto.ag.xml.XmlElement)
   */
  protected void addTypeSpecificChildElements(XmlElement rootElement) {
    rootElement.addChildElement("EPARegistrationNumber", epaRegNum);
    rootElement.addChildElement("BuyingCompanyEBID", "0062668030000");
    rootElement.addChildElement("PrimaryProductSegmentCode","Chemical");
  }

  /**
   * Gets the AGIIS-compliant identifier for this product.
   * 
   * @return AGIIS-compliant product identifier
   * @see com.monsanto.ag.cf.domain.Product#getAGIISIdentifier()
   */
   public String getAGIISIdentifier() {
    return brandCode;
  }

  /**
   * Gets the AGIIS-compliant name for this product.
   * 
   * @return AGIIS-compliant product identifier
   * @see com.monsanto.ag.cf.domain.Product#getAGIISName()
   */
  public String getAGIISName() {
    return brandDesc;
  }

  public String getBrandCode() {
        return brandCode;
  }

  public String getBrandDesc() {
        return brandDesc;
  }

  public String getEpaRegNum() {
        return epaRegNum;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof ChemicalProduct)) {
      return false;
    }
    ChemicalProduct rhs = (ChemicalProduct) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(brandCode,
        rhs.brandCode).append(brandDesc, rhs.brandDesc).append(epaRegNum,
        rhs.epaRegNum).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 11).appendSuper(super.hashCode()).append(
        brandCode).append(brandDesc).append(epaRegNum).hashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}