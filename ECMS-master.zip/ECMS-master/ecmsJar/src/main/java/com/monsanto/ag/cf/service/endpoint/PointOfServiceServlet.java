package com.monsanto.ag.cf.service.endpoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;

public class PointOfServiceServlet extends GatewayServlet {
  
  private static final int MAX_POST_SIZE = 8192 * 1024;

  public UCCHelper createHelper(HttpServletRequest request, HttpServletResponse response) {
    UCCHelper helper = super.createHelper(request, response);
    helper.setMaxImportFileSize(MAX_POST_SIZE);
    return helper;
  }

}
