/*
 * JdbcProductLightDao was created on Oct 1, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.dao.ProductLightDao;
import com.monsanto.ag.cf.domain.PackageStructure;
import com.monsanto.ag.cf.domain.ProductLight;

/**
 * Spring JDBC implemenation of the ProductLight DAO.
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcProductLightDao.java,v 1.17 2009/07/21 20:03:03 mkuchip Exp $
 */
public class JdbcProductLightDao extends BaseJdbcDao implements ProductLightDao {

  public class ProductLightMappingQuery extends MappingSqlQuery {
	    public ProductLightMappingQuery(String sql) {super(getDataSource(), sql);}
	    public ProductLightMappingQuery(String sql, Date fromDateTime) {
	      super(getDataSource(), sql);
	      super.declareParameter(new SqlParameter("UPDATE_DATE", Types.TIMESTAMP));
	      compile();
	    }
	    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
	      return new ProductLight(
                  rs.getString("GTIN"),
                  rs.getString("LEGAL_DESCR_1"),
                  rs.getString("LEGAL_DESCR_2"),
                  rs.getString("PRODUCT_CLASS_ID"),
                  rs.getString("UNREC20_BASE_UOM_CODE"),
                  rs.getString("specie_descr"),
                  rs.getString("USE_SSU"),
                  rs.getString("DISPLAY_DESCR"),
                  rs.getString("SEED_COMPANY_BRAND_NAME"),
                  "ST_UOM_CODE", //rs.getString("ST_UOM_CODE"),
                  new PackageStructure(
                          rs.getLong("prod_unit_conv"),
                          rs.getString("GTIN"),
                          rs.getString("UNREC20_RR_UOM_CODE"),
                          rs.getLong("UNIT_QTY"),
                          rs.getString("ORDER_UOM_ID")),
                  rs.getString("EBID"),
                  rs.getString("brand_name"),
                  rs.getString("other_seed_brand_flag"),
                  rs.getString("gpos_report_flag"),
                  rs.getString("IRM_FLAG"),
                  rs.getString("TREATMENT_CODE"),
                  rs.getString("TREATMENT_DESCR"));
	    }
  }  

  private static final String CLASS_CODE_EQUIPMENT = "N";
  private static final String CLASS_CODE_OTHER_SEED_BRANDS = "E";
  private static final String CLASS_CODE_SEED = "D";
  private static final String MARKET_SEGMENT_CHEMICAL = "CH";
  private static final String MARKET_SEGMENT_SEED = "ST";

  private static final Map CATEGORY_WHERE_CLAUSE_MAP;
  private static final Map CATEGORY_OTHER_SEED_BRANDS_WHERE_CLAUSE_MAP;  

  static {
    Map categoryWhereClauseMap = new HashMap();
    Map categoryOtherSeedBrandsWhereClauseMap = new HashMap();    

    categoryWhereClauseMap.put("Chemical", " and pbms.MKT_SEG_CODE(+)='" + MARKET_SEGMENT_CHEMICAL + "' " +
            " AND p.prod_class_code='"+ CLASS_CODE_EQUIPMENT + "' " +
            " AND p.ec_list_flag = 'Y' "+
            " AND m.material_type = 'VERP' ");
    categoryWhereClauseMap.put("Seed", " and pbms.MKT_SEG_CODE(+)='" + MARKET_SEGMENT_SEED+ "' " +
            " AND p.prod_class_code='" + CLASS_CODE_SEED +"'"
            + " AND p.ec_list_flag = 'Y' "
            + " AND p.prod_id = mpl.prod_id "
            + " AND mpl.year = ip.numeric_value "
            + " AND p.species_code <> 'T' ");

    categoryOtherSeedBrandsWhereClauseMap.put("Chemical", " AND pbms.MKT_SEG_CODE(+)='" + MARKET_SEGMENT_CHEMICAL + "' AND p.prod_class_code='"
            + CLASS_CODE_EQUIPMENT + "' AND m.material_type = 'VERP' ");
    categoryOtherSeedBrandsWhereClauseMap.put("Seed", " AND (p.prod_class_code='" + CLASS_CODE_OTHER_SEED_BRANDS + "') ");
    
    CATEGORY_WHERE_CLAUSE_MAP = Collections.unmodifiableMap(categoryWhereClauseMap);
    CATEGORY_OTHER_SEED_BRANDS_WHERE_CLAUSE_MAP = Collections.unmodifiableMap(categoryOtherSeedBrandsWhereClauseMap);
  }


    public List findProductsLightByDateCategoryBrand(Date lastModifiedDate, String category, Set brands, Boolean activeFlag) throws WrappingException {
        List productLightList;

        String where = "";
        where += getLastModifiedDateTimeWhereClause(lastModifiedDate);
        where += getCategoryWhereClause(category);
        where += getBrandsWhereClause(brands, category);
        where += getActiveFlagWhereClause(activeFlag);
        where += getWhereClause();
        where += getOrderByClause();

        String sql =  JdbcProductLightDaoConstants.ALL_PRODUCTS_QUERY + where;
        Logger.log(new DebugLogEvent("findProductsLightByDateCategoryBrand:" + sql));

        if (lastModifiedDate != null) {
            ProductLightMappingQuery productLightMappingQuery = new ProductLightMappingQuery(sql, lastModifiedDate);
            Object[] queryParamsForPriceSheet = new Object[]{new java.sql.Timestamp(lastModifiedDate.getTime())};
            productLightList = productLightMappingQuery.execute(queryParamsForPriceSheet);
        } else {
            ProductLightMappingQuery productLightMappingQuery = new ProductLightMappingQuery(sql);
            productLightList = productLightMappingQuery.execute();
        }

        return productLightList;
    }

    private String getWhereClause() {
        String result =
                " AND p.species_code = s.species_code(+) " +
                " AND p.prod_id = gposflag.prod_id(+) ";
        return result;
    }

    /* Get Non-Monsanto products for brands tied to Dealer */
    public List findProductsLightByDateCategoryBrandForOtherSeedBrands(Date lastModifiedDate, String category, Set brandsForDealer,
                                                                       Set brandsForDealerAddedSinceLastDxDate,
                                                                       Boolean activeFlag) throws WrappingException {

        List productLightList = null;

        /** The goal of the query is to get all Non-Monsanto products that have been updated since the last
         *  DX of the service by Seedtrak Mobile plus all Non-Monsanto products for brands that have been assigned
         *  to the dealer since the last DX of Seetrak Mobile.
         */
//        String sql = "SELECT DISTINCT LEGAL_DESCR_1,LEGAL_DESCR_2,RR_UOM_CODE,PRODUCT_CLASS_ID,BASE_UOM,PROD_UNIT_CONV,"
//                + "GTIN,SPECIES_DESCR,USE_SSU,DISPLAY_DESCR,SEED_COMPANY_BRAND_NAME,ST_UOM_CODE,"
//                + "SEED_COMPANY_EBID,BRAND_NAME,OTHER_SEED_BRAND_FLAG,GPOS_REPORT_FLAG,IRM_FLAG, UNIT_QTY, ORDER_UOM_ID, TREATMENT_CODE, TREATMENT_DESCR"
//                + " FROM ECG_SEEDTRAK_PRODUCT_LIST"
//                + " WHERE OTHER_SEED_BRAND_FLAG = 'Y' AND SEEDTRAK_FILE_FLAG = '" + FLAG_FALSE + "'" + getLastModifiedDateTimeWhereClause(lastModifiedDate)
//                + getCategoryWhereClauseOtherSeedBrands(category) + getBrandsWhereClause(brandsForDealer, category)
//                + getActiveFlagWhereClause(activeFlag);


        String where = "";
        where += getLastModifiedDateTimeWhereClause(lastModifiedDate);
        where += getCategoryWhereClauseOtherSeedBrands(category);
        where += getBrandsWhereClause(brandsForDealer, category);
        where += getActiveFlagWhereClause(activeFlag);
        where += getWhereClause();
//        where += getOrderByClause();

        String sql = JdbcProductLightDaoConstants.ALL_PRODUCTS_QUERY + where;

        where = "";
        where += getCategoryWhereClauseOtherSeedBrands(category);
        where += getBrandsWhereClause(brandsForDealerAddedSinceLastDxDate, category);
        where += getActiveFlagWhereClause(activeFlag);
        where += getWhereClause();

        String sqlBrandsAddedForDealerSinceLastDXDate = " UNION " + JdbcProductLightDaoConstants.ALL_PRODUCTS_QUERY + where;

        if (lastModifiedDate != null) {
            if (brandsForDealerAddedSinceLastDxDate != null && !brandsForDealerAddedSinceLastDxDate.isEmpty()) {
                sql = sql + sqlBrandsAddedForDealerSinceLastDXDate;
            }

            Logger.log(new DebugLogEvent("findProductsLightByDateCategoryBrand:" + sql));
            ProductLightMappingQuery productLightMappingQuery = new ProductLightMappingQuery(sql, lastModifiedDate);
            Object[] queryParmsForPriceSheet = new Object[]{new java.sql.Timestamp(lastModifiedDate.getTime())};

            productLightList = productLightMappingQuery.execute(queryParmsForPriceSheet);

        } else {
            Logger.log(new DebugLogEvent("findProductsLightByDateCategoryBrand:" + sql));
            ProductLightMappingQuery productLightMappingQuery = new ProductLightMappingQuery(sql);
            productLightList = productLightMappingQuery.execute();
        }

        return productLightList;
    }


  private String getLastModifiedDateTimeWhereClause(Date lastModifiedDate) {
    return (lastModifiedDate == null) ? "" : " AND greatest(p.row_modify_date, pps.row_modify_date, nvl(mpl.row_modify_date,p.row_modify_date)) > ? ";
  }

  private String getCategoryWhereClause(String category) {
    String categoryWhereClause = (String) CATEGORY_WHERE_CLAUSE_MAP.get(category);
    return (categoryWhereClause == null) ? "" : categoryWhereClause;
  }

  private String getCategoryWhereClauseOtherSeedBrands(String category) {
	    String categoryWhereClause = (String) CATEGORY_OTHER_SEED_BRANDS_WHERE_CLAUSE_MAP.get(category);
	    return (categoryWhereClause == null) ? "" : categoryWhereClause;
	  }  
  
  private String getBrandsWhereClause(Set brands, String category) {
    StringBuffer brandsWhereClause = new StringBuffer();
    if (brands != null && !brands.isEmpty()) {
      int count = 0;
      brandsWhereClause.append(" and scb.descr IN (");
      for (Iterator iter = brands.iterator(); iter.hasNext();) {
        String brand = (String) iter.next();
        if (count != 0) {
          brandsWhereClause.append(", ");
        }
        brandsWhereClause.append("'" + brand + "'");
        count++;
      }
      brandsWhereClause.append(")");
    }
    return brandsWhereClause.toString();
  }

  private String getActiveFlagWhereClause(Boolean activeFlag) {
    String aFlag = null;
    if (activeFlag != null) {
      aFlag = (activeFlag.booleanValue()) ? "Y" : "N";
    }
    return (activeFlag == null) ? "" : " and DECODE (p.prod_status_code, 'AC', 'Y', 'N')  = '" + aFlag + "'";
  }

    private String getOrderByClause() {
        return " ORDER BY p.acronym_name, smc.special_treatment_code, b.brand_code, p.prod_id, uomxref_rr.alias_unrec20_uom_code";
    }


}
