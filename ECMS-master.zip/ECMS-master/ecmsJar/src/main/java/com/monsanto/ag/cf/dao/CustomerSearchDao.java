/*
 * EntityInquiryDao was created on Jul 24, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao;

import java.util.List;

import com.monsanto.ag.cf.domain.GrowerCriteria;

/**
 * Data Access Object for Customer Search.
 * @author Chetna Aggarwal
 * @version $Id: CustomerSearchDao.java,v 1.4 2008-07-05 21:54:24 dddoni Exp $
 */
public interface CustomerSearchDao {
  
  List getCustomerDetails(GrowerCriteria grower, String seedYear); 
  List getCustomerDetailsWithAgreementCode(GrowerCriteria criteria, String seedYear);
  List getCustomerDetailsWithGrowerIds(String GrowerIds, String seedYear);
  
}
