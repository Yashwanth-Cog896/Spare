package com.monsanto.ag.cf.service.util;

import com.monsanto.Util.StringUtils;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Created by JTMURR on 2/2/2016.
 */
public class InventoryActualUsageResponseBuilder implements ResponseBuilder {
    @Override
    public XmlDocument build(XmlDocumentBuilder xmlDocumentBuilder, String message) {
        if (message == null || StringUtils.isEmpty(message)) {
            message = "Success";
        }
        XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
        XmlNamespace xmlNamespace = new XmlNamespace("ecms", "urn:ecms:schema:inventory:response:1:0");
        XmlElement xmlElement = outputDocument.addRootElement("InventoryActualUsageResponse", xmlNamespace, "1.0");
        xmlElement.addChildElement("Status", message);
        return outputDocument;
    }
}
