/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.farmflex.domain;

import com.monsanto.commercial.growercreditlist.domain.GrowerCreditInfo;

public class FarmFlexInfo {
    private GrowerCreditInfo growerCreditInfo;

    public FarmFlexInfo(GrowerCreditInfo growerCreditInfo) {
        this.growerCreditInfo = growerCreditInfo;
    }

    public String getGrowerAccountId() {
        return growerCreditInfo == null ? null : growerCreditInfo.getGrowerAccountId();
    }

    public double getFarmFlexApprovedAmount() {
        return growerCreditInfo == null ? 0 : growerCreditInfo.getCreditApproved();
    }

    public double getFarmFlexUsage() {
        return growerCreditInfo == null ? 0 : growerCreditInfo.getCreditAvailable();
    }
}
