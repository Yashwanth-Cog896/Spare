/*
 * EncryptedPropertyPlaceholderConfigurer was created on Mar 29, 2005 using
 * Monsanto resources and is the sole property of Monsanto. Any duplication of
 * the code and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.config;

import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.databasepasswordencryption.AES_Encryptor;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;

/**
 * Extends Spring's PropertyPlaceholderConfigurer to decrypt property values
 * consisting solely of hexadecimal characters (including upper case A-F).
 * 
 * @author Gareth Davies
 * @version $Id: EncryptedPropertyPlaceholderConfigurer.java,v 1.1 2005/03/29
 *          23:10:26 ggdavi Exp $
 */
public class EncryptedPropertyPlaceholderConfigurer extends
    PropertyPlaceholderConfigurer {

  private static final String ENCRYPTION_KEY = "R/\nd0M_pA55w0Rd";
  private static final String DEFAULT_ENV_PREFIX = "default.";
  
  public EncryptedPropertyPlaceholderConfigurer() {
    super();
    setSystemPropertiesMode(SYSTEM_PROPERTIES_MODE_FALLBACK);
    setSearchSystemEnvironment(true);
  }

  public String convertPropertyValue(String encryptedValue) {
    String convertedValue = encryptedValue;
    if (encryptedValue != null && encryptedValue.matches("[0-9A-F]+")) {
      try {
        AES_Encryptor encryptor = new AES_Encryptor(ENCRYPTION_KEY,
            AES_Encryptor.ENCODING_ASCII);
        byte[] decrypted = encryptor.doDecrypt(encryptedValue,
            AES_Encryptor.ENCODING_HEX);
        convertedValue = new String(decrypted);
      } catch (EncryptorException e) {
        Logger.log(new LoggableError(e.getMessage()));
      }
    }

    return convertedValue;
  }

  /**
   * By overriding this method the process of finding a value for a certain "key" (placeHolder) from a properties file is changed.
   * Any placeHolder (KEY) which has a environment specific value is expected to be prefixed with a the value of JVM system property "lsi.function" (for eg win.KEY) 
   * Otherwise it should follow the pattern default.KEY  
   * @see org.springframework.beans.factory.config.PropertyPlaceholderConfigurer#resolvePlaceholder(java.lang.String, java.util.Properties)
   */
  protected String resolvePlaceholder(String placeHolder, Properties props) {
    String value = null;
    try {
      value = props.getProperty(EnvironmentHelper.getPropertyPrefix()+placeHolder);
      if(value==null) {
        value = props.getProperty(DEFAULT_ENV_PREFIX+placeHolder);
      } 
      if(value==null) {
        Logger.log(new LoggableError("Missing required properties "+EnvironmentHelper.getPropertyPrefix()+placeHolder+" or "+DEFAULT_ENV_PREFIX+placeHolder));
      } 
       
    } catch (EnvironmentHelperException e) {
      e.printStackTrace();
      Logger.log(new LoggableError(e.getMessage()));
    }
    return value;
  }


}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/06/30 17:43:26  ggdavi
 * Moved ag.aop, ag.config and ag.message packages under the ag.cf package
 *
 * Revision 1.2  2005/06/02 13:43:40  ggdavi
 * Upgraded to Spring 1.2.1
 * Revision 1.1 2005/05/17
 * 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop,
 * ag.config, ag.util
 * 
 * Revision 1.1 2005/04/07 15:40:32 ggdavi Moved from web to config package
 * 
 * Revision 1.3 2005/04/05 21:39:40 ggdavi Got to work by overriding parseString
 * Revision 1.2 2005/04/01 21:03:00 ajbaldw Added code to decrypt properties
 * from encrypted property files. Revision 1.1 2005/03/29 23:10:26 ggdavi
 * Initial version
 */