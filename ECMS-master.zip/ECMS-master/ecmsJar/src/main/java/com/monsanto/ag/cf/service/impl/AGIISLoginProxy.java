package com.monsanto.ag.cf.service.impl;

import java.io.StringReader;

import org.w3c.dom.Document;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.xml.DocumentBuilderException;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocument;


public class AGIISLoginProxy extends ServiceProxySupport {
	private XmlDocumentBuilder xmlDocumentBuilder;
	private String agiisUserId;
	private String agiisPassword;
	private static final String AGIISLoginSoapHeader = "http://www.agiis.org/Services/Security/Login";

	public boolean loginToAgiis()  {
		Logger.log(new LoggableInfo("Logging in to AGIIS"));
		ServiceInput loginInput = new ServiceInput(buildLoginInputDocument());
		loginInput.setSoapActionHeader(AGIISLoginSoapHeader);
		loginInput.setOverrideResponseChunking(true);
		ServiceOutput output = null;
		try {
			output = soaClient.call(serviceId, loginInput);
			return getResponse(output);			
		} catch (Exception e) {
			//Try a second time if login fails.
			output = soaClient.call(serviceId, loginInput);
			return getResponse(output);			
		}
	}

	private boolean getResponse(ServiceOutput output) {
		XmlDocument loginOutputDoc = output.getXmlChunks().getXmlDocumentChunk(xmlDocumentBuilder, 0);
		XmlElement loginElement = loginOutputDoc.selectElementByXPath("//soap:Envelope/soap:Body");
		XmlElement loginResponse = loginElement.getChild("LoginResponse");
		XmlElement loginResultElement = loginResponse.getChild("LoginResult");		
		String loginResult = loginResultElement.getText();
	    return Boolean.valueOf(loginResult).booleanValue();
	}

	private XmlDocument buildLoginInputDocument(){
		String subscriberLoginMessage =	
		  "<Login xmlns=\"http://www.agiis.org/Services/Security\" xmlns:agiis=\"http://www.agiis.org/Services/Security\">" +
		  "<UserID>" + agiisUserId+"</UserID>" +
		  "<Password>"+agiisPassword+"</Password>" +
		  "</Login>" ;
		
	    try {
	  	  	Document document = DOMUtil.newDocument(new StringReader(subscriberLoginMessage));
	        return new DOMUtilXmlDocument(document);
	      } catch (Exception e) {
	        throw new DocumentBuilderException(e.getMessage());
	      }
	}
	
	public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
		this.xmlDocumentBuilder = xmlDocumentBuilder;
	}

	public void setAgiisUserId(String agiisUserId) {
		this.agiisUserId = agiisUserId;
	}

	public void setAgiisPassword(String agiisPassword) {
		this.agiisPassword = agiisPassword;
	}
	
	
}