/*
 * Monitor was created on Jul 29, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.management;

import org.activemq.spring.TestingConsumer;
import org.springframework.jms.core.JmsTemplate;

import com.monsanto.ag.cf.dao.EcomMonitorDao;
import com.monsanto.ag.cf.message.XmlMessageConverter;
import com.monsanto.ag.cf.outage.OutageChecker;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.xml.XmlDocumentBuilder;

/**
 * Represents the information used by PerformanceMonitor Servlet.
 * @author Chetna Aggarwal
 * @version $Id: Monitor.java,v 1.6 2007-03-07 20:29:53 caggarw Exp $
 */
public class Monitor {
  
  private String farmSourceServiceUrl;
  private String webMethodServiceUrl;
  private String webMethodServiceUrlR1;
  private EcomMonitorDao ecomMonitorDao;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private SoaClient posSoaClient;
  private OutageChecker outageChecker;
  private SoaClient webMethodsSoaClient;
  private JmsTemplate jmsTemplate;
  private TestingConsumer jmsPingListener;
  private XmlMessageConverter messageConverter;
  
  public String getFarmSourceServiceUrl() {
    return farmSourceServiceUrl;
  }
  
  public void setFarmSourceServiceUrl(String farmSourceServiceUrl) {
    this.farmSourceServiceUrl = farmSourceServiceUrl;
  }
  
  public String getWebMethodServiceUrl() {
    return webMethodServiceUrl;
  }
  
  public void setWebMethodServiceUrl(String webMethodServiceUrl) {
    this.webMethodServiceUrl = webMethodServiceUrl;
  }     
  
  public String getWebMethodServiceUrlR1() {
    return webMethodServiceUrlR1;
  }
  
  public void setWebMethodServiceUrlR1(String webMethodServiceUrlR1) {
    this.webMethodServiceUrlR1 = webMethodServiceUrlR1;
  }
  
  public EcomMonitorDao getEcomMonitorDao() {
    return ecomMonitorDao;
  }
  
  public void setEcomMonitorDao(EcomMonitorDao ecomMonitorDao) {
    this.ecomMonitorDao = ecomMonitorDao;
  }

  public XmlDocumentBuilder getXmlDocumentBuilder() {
    return xmlDocumentBuilder;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public OutageChecker getOutageChecker() {
    return outageChecker;
  }

  public void setOutageChecker(OutageChecker outageChecker) {
    this.outageChecker = outageChecker;
  }

  public SoaClient getWebMethodsSoaClient() {
    return webMethodsSoaClient;
  }

  public void setWebMethodsSoaClient(SoaClient webMethodsSoaClient) {
    this.webMethodsSoaClient = webMethodsSoaClient;
  }

  public JmsTemplate getJmsTemplate() {
    return jmsTemplate;
  }

  public void setJmsTemplate(JmsTemplate jmsTemplate) {
    this.jmsTemplate = jmsTemplate;
  }

  public TestingConsumer getJmsPingListener() {
    return jmsPingListener;
  }

  public void setJmsPingListener(TestingConsumer jmsPingListener) {
    this.jmsPingListener = jmsPingListener;
  }

  public XmlMessageConverter getMessageConverter() {
    return messageConverter;
  }

  public void setMessageConverter(XmlMessageConverter messageConverter) {
    this.messageConverter = messageConverter;
  }
  
}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.4  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.3  2005/11/01 22:26:24  caggarw
 * Added properties for the different context bean definitions for Refactoring the PerformanceMonitorServlet. Added beans for the JmsBroker ping test added to PerformanceMonitorServlet.
 *
 * Revision 1.2  2005/09/21 18:24:12  caggarw
 * added url for production box added for webmethod to the monitor bean as a property
 *
 * Revision 1.1  2005/08/06 20:44:33  ggdavi
 * Moved Monitor from ag.cf.domain to ag.cf.management to resolve circular dependency
 *
 * Revision 1.1  2005/07/29 20:16:19  caggarw
 * domain object for storing information to be useful for performance monitoriong
 *
 */