/*
 * PriceSheet was created on Jun 23, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Represents the information inside a PriceSheet.
 * 
 * @author caggarw
 * @version $Id: PriceSheet.java,v 1.9 2007-08-17 18:32:29 caggarw Exp $
 */
public class PriceSheet implements Serializable {

  private String upcCode;
  private String priceRegion;
  private String netRate;
  private String uomId;
  private Date entryDate;
  private Date approvedDate;
  private Date modifydate;
  private String fullRefreshFlag;
  private String roundupWholeSaleDiscount;
  private String roundupTraitFee;
  private String partialListFlag;
  private String zoneCode;

    public PriceSheet() {
  }

  public PriceSheet(String upcCode, String priceRegion, String netRate, String uomId, Date entryDate, Date modifyDate,
      String roundupWholeSaleDiscount, String roundupTraitFee) {
    this.upcCode = upcCode;
    this.priceRegion = priceRegion;
    this.netRate = netRate;
    this.uomId = uomId;
    this.entryDate = entryDate;
    this.modifydate = modifyDate;
    this.roundupWholeSaleDiscount = roundupWholeSaleDiscount;
    this.roundupTraitFee = roundupTraitFee;
  }

  public PriceSheet(String upcCode, String priceRegion, String netRate, String uomId) {
    this.upcCode = upcCode;
    this.priceRegion = priceRegion;
    this.netRate = netRate;
    this.uomId = uomId;
  }

    public PriceSheet(String upcCode, String zoneCode, String uomId, Date entryDate, String roundupTraitFee,
                      Date modifydate, String netRate) {
        this.upcCode = upcCode;
        this.zoneCode = zoneCode;
        this.uomId = uomId;
        this.entryDate = entryDate;
        this.roundupTraitFee = roundupTraitFee;
        this.modifydate = modifydate;
        this.netRate = netRate;
    }

  public Date getApprovedDate() {
    return approvedDate;
  }

  public Date getEntryDate() {
    return entryDate;
  }

  public String getFullRefreshFlag() {
    return fullRefreshFlag;
  }

  public Date getModifydate() {
    return modifydate;
  }

  public String getNetRate() {
    return netRate;
  }

  public String getRoundupTraitFee() {
    return roundupTraitFee;
  }

  public String getRoundupWholeSaleDiscount() {
    return roundupWholeSaleDiscount;
  }

  public String getPriceRegion() {
    return priceRegion;
  }

  public String getUpcCode() {
    return upcCode;
  }

  public String getUomId() {
    return uomId;
  }

  public void setApprovedDate(Date approvedDate) {
    this.approvedDate = approvedDate;
  }

  public void setFullRefreshFlag(String fullRefreshFlag) {
    this.fullRefreshFlag = fullRefreshFlag;
  }

  public void setPriceRegion(String priceRegion) {
    this.priceRegion = priceRegion;
  }

  public String getPartialListFlag() {
    return partialListFlag;
  }

  public void setPartialListFlag(String partialListFlag) {
    this.partialListFlag = partialListFlag;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof PriceSheet)) {
      return false;
    }
    PriceSheet rhs = (PriceSheet) obj;
    return new EqualsBuilder().append(approvedDate, rhs.getApprovedDate()).append(upcCode, rhs.getUpcCode()).append(
        priceRegion, rhs.getPriceRegion()).append(netRate, rhs.getNetRate()).append(uomId, rhs.getUomId()).append(
        entryDate, rhs.getEntryDate()).append(modifydate, rhs.getModifydate()).append(roundupWholeSaleDiscount,
        rhs.getRoundupWholeSaleDiscount()).append(roundupTraitFee, rhs.getRoundupTraitFee()).append(partialListFlag,
        rhs.getPartialListFlag()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 21).append(approvedDate).append(upcCode).append(priceRegion).append(netRate).append(
        uomId).append(entryDate).append(modifydate).append(roundupWholeSaleDiscount).append(roundupTraitFee).append(
        partialListFlag).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).append("approvedDate", approvedDate).append("upcCode",
        upcCode).append("priceRegion", priceRegion).append("netRate", netRate).append("uomId", uomId).append(
        "entryDate", entryDate).append("modifyDate", modifydate).append("roundupWholeSaleDiscount",
        roundupWholeSaleDiscount).append("roundupTraitFee", roundupTraitFee).append("partiallistFlag", partialListFlag)
        .toString();
  }

    public void setZoneCode(final String newZoneCode) {
        zoneCode = newZoneCode;
    }
    public String getZoneCode() {
        return zoneCode;
    }
}

/*
 * $Log: not supported by cvs2svn $ Revision 1.8 2006/06/12 21:44:12 caggarw changes
 * for adding the Royalty pricing for RR Alfalfa in the Price Response XML
 * Revision 1.7 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.6 2005/08/16 15:03:01 caggarw Added property fullRefreshFlag to
 * PriceSheet domain object. This value is set from the FULL_REFRESH_FLAG column
 * (set to 'Y' initially) in the ACCT_TO_PRICE_ZONE table, indicating whether a
 * new zone has been assigned to a dealer. The PriceSheetDao sets this flag to
 * 'N' after it gets the Price information the first time.
 * 
 * Revision 1.5 2005/07/21 23:31:51 caggarw added modifyDate to pricesheetobject
 * for request # 00067 Revision 1.4 2005/06/27 16:50:39 caggarw removed fromDate
 * and Action fields from Object, chnaged constructor
 * 
 * Revision 1.3 2005/06/27 12:04:33 ggdavi Corrected hashCode random value seeds
 * to be unique to project
 * 
 * Revision 1.2 2005/06/27 12:01:27 ggdavi Added equals, hashcode and toString
 * methods Revision 1.1 2005/06/27 03:45:41 caggarw value object for pricesheet
 * 
 */