/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.CreditControlAreaDao;
import org.springframework.jdbc.object.MappingSqlQuery;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class JdbcCreditControlAreaDao extends BaseJdbcDao implements CreditControlAreaDao {
    public static final int INT_CREDIT_CTRL_AREA_CODE = 5180;
    public static final String CREDIT_CTRL_AREA_CODE = "CREDIT_CTRL_AREA_CODE";

    @Override
    public List getGrowerIdsInCreditControlArea(MappingSqlQuery query, int creditControlAreaCode) {
        if (query == null) {
            query = new CustomersInCreditControlAreaQuery(createCreditControlAreaSearchSql(creditControlAreaCode));
        }
        return query.execute();
    }

    private String createCreditControlAreaSearchSql(int creditControlAreaCode) {
        return "SELECT ACCT_ID FROM AGSHARE.ACCT_TO_CREDIT_CTRL_AREA_MV WHERE " + CREDIT_CTRL_AREA_CODE + " = " +
              creditControlAreaCode;
    }

    public class CustomersInCreditControlAreaQuery extends MappingSqlQuery {
        public CustomersInCreditControlAreaQuery(String sql) {
            super(getDataSource(), sql);
        }

        @Override
        protected Object mapRow(ResultSet resultSet, int rowNum) throws SQLException {
            return String.valueOf(resultSet.getInt("ACCT_ID"));
        }
    }
}
