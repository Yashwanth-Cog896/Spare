/*
PriceSheetDao was created on Jun 21, 2005 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao;

import com.monsanto.ag.cf.domain.PriceSheet;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Data Access Object for PriceSheet.
 * @author caggarw
 * @version $Id: PriceSheetDao.java,v 1.1 2005-06-27 03:44:47 caggarw Exp $
 */
public interface PriceSheetDao {

  // TODO: price service updates makes this deprecated?
  List getPriceSheet(long accountId, String category, Set brand, Date fromDateTime);

    List getPriceSheet(long accountId, Date fromDateTime, Map<String, List<String>> zoneIdsMap);

}


/*
 * $Log: not supported by cvs2svn $
*/