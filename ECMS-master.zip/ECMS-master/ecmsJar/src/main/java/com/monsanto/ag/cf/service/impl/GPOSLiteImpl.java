/*
 * GPOSLiteImpl was created on Jan 30, 2008 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.io.IOException;

import javax.xml.rpc.soap.SOAPFaultException;

import org.dom4j.DocumentException;

import com.monsanto.ag.cf.service.endpoint.JaxRpcEndpoint;
import com.monsanto.ag.xml.XmlDocument;

/**
 * POJO implementation of the GPOSLite service.
 * 
 * @author Mark Schechter
 * @version $Id: GPOSLiteImpl.java,v 1.4 2008-02-18 17:09:58 maschec Exp $
 */
public class GPOSLiteImpl extends POSImplBase {
  
  private static final String NEW_LINE = System.getProperty("line.separator");


  /**
   * Transform the Monsanto-specific GPOSLite format into the original CIDX
   * GPOS format so the same WebMethods call that GPOS uses can be called.  
   * 
   * @see com.monsanto.ag.cf.service.impl.POSImplBase#transformRequestAsNeeded(com.monsanto.ag.xml.XmlDocument)
   */
  protected XmlDocument transformRequestAsNeeded(XmlDocument requestDocument) throws SOAPFaultException {
    GPOSLiteTransformer transformer = new GPOSLiteTransformer();
    XmlDocument cidxFormattedRequest = null;
    String transformErrorMsg = null;
    Exception transformException = null;
    try {
      cidxFormattedRequest = transformer.transformToCidx40(requestDocument);
    } catch (SOAPFaultException e) {
      throw e;
    } catch (DocumentException e) {
      transformErrorMsg = "DocumentException thrown by GPOSLiteTransformer: " + e.getMessage();
      transformException = e;
    } catch (IOException e) {
      transformErrorMsg = "IOException thrown by GPOSLiteTransformer: " + e.getMessage();
      transformException = e;
    }
    if (transformErrorMsg != null) {
      if (transformException != null) {
        transformException.printStackTrace();
      }
      String xml = "[Unable to render XML]";    //Default
      if (requestDocument == null) {
        xml = "[requestDocument is null]";
      }
      else {
        try {
          xml = requestDocument.toString();
        } catch (Exception e) {
          //Already set to default above
        }
      }
      throw JaxRpcEndpoint.makeEcmsSoapFault(JaxRpcEndpoint.SERVICE_EXCEPTION_FAULT_CODE, 
          transformErrorMsg + NEW_LINE + "requestDocument = " + NEW_LINE + xml);
    }
    
    return cidxFormattedRequest;
  }


}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2008/02/15 19:54:09  maschec
 * Refactor POSImpl_UT into POSImplUTBase, so that tests can also be run using GPOSLiteImpl
 *
 * Revision 1.2  2008/02/13 16:23:32  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.1.2.5  2008/02/08 21:29:58  maschec
 * Fix bug whereby SoapFault thrown by transformer was swallowed; also implement handling other Transform exceptions.
 *
 * Revision 1.1.2.4  2008/02/02 20:52:46  maschec
 * Save WIP: Get submission to WebMethods working!
 *
 * Revision 1.1.2.3  2008/01/31 16:22:52  maschec
 * Invoke helper class to transfrom GPOSLite format to CIDX 4.0 request format
 *
 * Revision 1.1.2.2  2008/01/30 22:51:39  maschec
 * Get GPOSLite implementation working (without transform and without passing to WebMethods)
 *
 * Revision 1.1.2.1  2008/01/30 20:17:32  maschec
 * Original version
 *
 */