/*
 * ApplicationConnectionFactory was created on May 5, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.broker;

import javax.jms.JMSException;

import org.activemq.ActiveMQConnectionFactory;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.BrokerContainerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

/**
 * Extends ActiveMQConnectionFactory by making it aware of the Spring bean
 * factory in which it is created. This is accomplished by overriding the
 * org.activemq.ActiveMQConnectionFactory.createBrokerContainerFactory method to
 * return a
 * {@link com.monsanto.ag.cf.message.broker.ApplicationBrokerContainerFactory ApplicationBrokerContainerFactory}
 * object.
 * 
 * @author Gareth Davies
 * @version $Id: ApplicationConnectionFactory.java,v 1.1 2005/05/05 19:01:12
 *          ggdavi Exp $
 */
public class ApplicationConnectionFactory extends ActiveMQConnectionFactory
    implements BeanFactoryAware {

  private BeanFactory beanFactory;

  public ApplicationConnectionFactory() {
    super();
  }

  public ApplicationConnectionFactory(String brokerURL) {
    super(brokerURL);
  }

  public ApplicationConnectionFactory(String userName, String password,
      String brokerURL) {
    super(userName, password, brokerURL);
  }

  public ApplicationConnectionFactory(BrokerContainer container) {
    super(container);
  }

  public ApplicationConnectionFactory(BrokerContainer container,
      String brokerURL) {
    super(container, brokerURL);
  }

  /**
   * @see org.springframework.beans.factory.BeanFactoryAware#setBeanFactory(org.springframework.beans.factory.BeanFactory)
   */
  public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
    this.beanFactory = beanFactory;
  }

  /**
   * @see org.activemq.ActiveMQConnectionFactory#createBrokerContainerFactory()
   */
  protected BrokerContainerFactory createBrokerContainerFactory()
      throws JMSException {
    return ApplicationBrokerContainerFactory.newFactory(getBrokerXmlConfig(),
        beanFactory);
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.1 2005/06/30 17:43:26
 * ggdavi Moved ag.aop, ag.config and ag.message packages under the ag.cf
 * package
 * 
 * Revision 1.2 2005/05/09 20:32:11 ggdavi Removed commented getEmbeddedBroker
 * method Revision 1.1 2005/05/05 19:01:12 ggdavi Initial version
 * 
 */