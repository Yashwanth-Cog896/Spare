package com.monsanto.ag.cf.domain;

/**
 * AppConstants
 * @author [Ramesh Kukunarapu]
 * @version $Id: AppConstants.java,v 1.4 2009/08/03 18:32:37 mkuchip Exp $ 1.1
 */
public interface AppConstants {

  // Using these values for Mobile Inventory Reporting web service
  public static final String CUST_TYPE_ST_TYPE = "PX";
  public static final String REPORT_TYPE = "IR";
  public static final String DS_TYPE = "DS";
  public static final String SF_TYPE = "WH";
  public static final String INVOICE_DATE_QUALIFIER = "3";
  public static final String SHIP_DATE_QUALIFIER = "11";
  public static final String TRANSACTION_STATUS = "P";
  public static final String ZERO_POSITIVE_VAL_QTY_QUALIFIER="32";
  public static final String ZERO_POSITIVE_QTY_VAL_ORDER_TYPE="IV";
  public static final String NEGATIVE_VAL_QTY_QUALIFIER="75";
  public static final String NEGATIVE_QTY_VAL_ORDER_TYPE="CM";
  
  public static final String LINE_ID_QUAL_FOR_GTIN="UK";
  
  public static final String QUALIFIER_NAME_FOR_AGIIS_EBID = "AGIIS-EBID";
  public static final String QUALIFIER_ID_FOR_AGIIS_EBID = "9";
  public static final String QUALIFIER_NAME_AGIIS_NAPD = "AGIIS-NAPD";
  public static final String QUALIFIER_ID_AGIIS_NAPD = "C5";
  public static final String QUALIFIER_NAME_AssignedByBuyer = "AssignedByBuyer";
  public static final String QUALIFIER_ID_AssignedByBuyer = "92";
  public static final String QUALIFIER_NAME_AssignedBySeller = "AssignedBySeller";
  public static final String QUALIFIER_ID_AssignedBySeller = "91";

  // Fixed value for Acceleron Treatment Code
  public static final String ACCELERON_TREATMENT_CODE = "A0";
  
}
