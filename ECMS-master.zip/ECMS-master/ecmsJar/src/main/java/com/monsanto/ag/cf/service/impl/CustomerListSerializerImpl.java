/*
 * CustomerListSerializerImpl was created on Aug 6, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.ag.cf.domain.ZoneInformation;
import com.monsanto.ag.cf.service.CustomerListSerializer;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.*;
import org.apache.commons.lang.StringUtils;

import java.util.Iterator;
import java.util.List;


/**
 * Serializer to create the Customer Search Response Document.
 *
 * @author Chetna Aggarwal
 * @version $Id: CustomerListSerializerImpl.java,v 1.2 2007/08/08 20:29:42
 *          caggarw Exp $
 */
public class CustomerListSerializerImpl implements CustomerListSerializer {

  protected XmlDocumentBuilder xmlDocumentBuilder;
  protected IdTranslator idTranslator;

  /**
   // * @see com.monsanto.ag.cf.service.CustomerListSerializer#buildCustomerSearchDocument(java.lang.String,
   // *      com.monsanto.ag.security.IdentityPrincipal, java.util.List)
   */
  public XmlStream buildCustomerSearchDocument(String conversationId, IdentityPrincipal idPrincipal, List customers) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement("AGIISEntityInquiryResponse",
            CustomerSearchImpl.NAMESPACE_CUST_RESPONSE, "1.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    addBodyNode(rootElement, customers);

    return outputDocument;
  }

  protected void addBodyNode(XmlElement rootElement, List customers) {
    XmlElement bodyNode = rootElement.addChildElement("Body");
    XmlElement detailsNode = bodyNode.addChildElement("AGIISEntityInquiryResponseDetails");
    XmlElement inquiryNode = detailsNode.addChildElement("EntityInquiryResponse");

    for (Iterator itCustomers = customers.iterator(); itCustomers.hasNext();) {
      GrowerDetails grower = (GrowerDetails) itCustomers.next();
      addResponseInformation(inquiryNode, grower);
    }
  }

  protected void addResponseInformation(XmlElement inquiryNode, GrowerDetails grower) {
    XmlElement responseNode = inquiryNode.addChildElement("EntityInformationResponse");
    responseNode.setAttribute("ActiveFlag", "Active");

    long accountIdInRequest = 0;
    if (grower.getCustomerIds() != null) {
      accountIdInRequest = grower.getCustomerIds().getAccountId();

      XmlElement accountId = responseNode.addChildElement("IndustryIdentifier");
      accountId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.ACCOUNT_ID_AGENCY);
      accountId.addChildElement("IndustryCode", Long.toString(accountIdInRequest));

      XmlElement SapId = responseNode.addChildElement("IndustryIdentifier");
      SapId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.SAP_ID_AGENCY);
      SapId.addChildElement("IndustryCode", grower.getCustomerIds().getSapId());

      if (StringUtils.isNotBlank(grower.getCustomerIds().getNapdId())) {
        XmlElement napId = responseNode.addChildElement("IndustryIdentifier");
        napId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.NAPD_ID_AGENCY);
        napId.addChildElement("IndustryCode", grower.getCustomerIds().getNapdId());
      }

      if (StringUtils.isNotBlank(grower.getCustomerIds().getGlnId())) {
        XmlElement glnId = responseNode.addChildElement("IndustryIdentifier");
        glnId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.GLN_ID_AGENCY);
        glnId.addChildElement("IndustryCode", grower.getCustomerIds().getGlnId());
      }

    }

    if (StringUtils.isNotBlank(grower.getAccountName())) {
      responseNode.addChildElement("PreferredName", grower.getAccountName());
    }
    if (!(StringUtils.isBlank(grower.getContactFName()) && StringUtils.isBlank(grower.getContactLName()))) {
      XmlElement individualNameNode = responseNode.addChildElement("IndividualName");
      if (StringUtils.isNotBlank(grower.getContactFName())) {
        individualNameNode.addChildElement("FirstName", grower.getContactFName());
      }
      if (StringUtils.isNotBlank(grower.getContactLName())) {
        individualNameNode.addChildElement("LastName", grower.getContactLName());
      }
    }

    if (StringUtils.isNotBlank(grower.getContactPhone())) {
      responseNode.addChildElement("TelephoneNumber", grower.getContactPhone());
    }

    if (StringUtils.isNotBlank(grower.getLicenseStatus())) {
      responseNode.addChildElement("EntityStatus", grower.getLicenseStatus());
    }

    AddressInformation address = grower.getAddressInformation();
    if (address != null) {
      XmlElement mailingAddress = responseNode.addChildElement("MailingAddress");
      mailingAddress.setAttribute("Overidden", "True");

      if (StringUtils.isNotBlank(address.getStreet())) {
        mailingAddress.addChildElement("AddressLine1", address.getStreet());
      }
      if (StringUtils.isNotBlank(address.getCity())) {
        mailingAddress.addChildElement("CityName", address.getCity());
      }
      if (StringUtils.isNotBlank(address.getState())) {
        mailingAddress.addChildElement("StateOrProvince", address.getState());
      }
      if (StringUtils.isNotBlank(address.getZip())) {
        mailingAddress.addChildElement("PostalCode", address.getZip());
      }
      if (StringUtils.isNotBlank(address.getCounty())) {
        mailingAddress.addChildElement("CountyName", address.getCounty());
      }
    }

    if (StringUtils.isNotBlank(grower.getFflxCode()) && (accountIdInRequest == grower.getFflxId())) {

      responseNode.addChildElement("FarmFlexApproved", "Yes");
    } else {

      System.out.println("IN NO *************");
      responseNode.addChildElement("FarmFlexApproved", "No");
    }

    List zones = grower.getZoneInformation();
    if (zones != null) {
      for (Iterator zoneItr = zones.iterator(); zoneItr.hasNext();) {
        ZoneInformation zone = (ZoneInformation) zoneItr.next();
        if (zone != null) {
          XmlElement zoneNode = responseNode.addChildElement("AgronomicZone");
          if (StringUtils.isNotBlank(zone.getZoneCode())) {
            zoneNode.addChildElement("ZoneCode", zone.getZoneCode());
          }
          if (StringUtils.isNotBlank(zone.getAZRDescr())) {
            zoneNode.addChildElement("Crop", zone.getAZRDescr());
          }
          if (StringUtils.isNotBlank(zone.getZoneDescr())) {
            zoneNode.addChildElement("ZoneDescription", zone.getZoneDescr());
          }
          if (StringUtils.isNotBlank(zone.getZoneYear())) {
            zoneNode.addChildElement("SeedYear", zone.getZoneYear());
          }
        }
      }
    }

  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}
