/*
 * JdbcCustomerReviewDao was created on Aug 11, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.CustomerReviewDao;
import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.CustomerIds;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.ag.cf.domain.ZoneInformation;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * JDBC implementation of CustomerReviewDao.
 *
 * @author Chetna Aggarwal
 * @version $Id: JdbcCustomerReviewDao.java,v 1.4 2008-07-09 21:27:43 dddoni Exp $
 */
public class JdbcCustomerReviewDao extends BaseJdbcDao implements CustomerReviewDao {

  /**
   * Maps the results from the database query to Zone information objects
   *
   */
  public class ZoneMappingQuery extends MappingSqlQuery {

    private static final String CUSTOMER_ZONE_SQL = "SELECT DISTINCT AZR_DESCR,ZONE_DESCR,ZONE_CODE,"
            + "ZONE_YEAR FROM GROWER_INQUIRY_VW WHERE GROWER_ID=?";

    public ZoneMappingQuery() {
      super(getDataSource(), CUSTOMER_ZONE_SQL);
      super.declareParameter(new SqlParameter("GROWER_ID", Types.INTEGER));
    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      ZoneInformation zoneInformation = new ZoneInformation(rs.getString("AZR_DESCR"), rs.getString("ZONE_DESCR"), rs
              .getString("ZONE_CODE"), rs.getString("ZONE_YEAR"), StringUtils.EMPTY);
      return zoneInformation;
    }

  }

  /**
   * Map the results from database queries (customer details) to GrowerDetail
   * Objects.
   */
  public class CustomerReviewMappingQuery extends MappingSqlQuery {

    private static final String CUSTOMER_REVIEW_SQL = "SELECT DISTINCT INVOICE,GROWER_ID,ACCT_NAME,"
            + "CONTACT_LAST_NAME,CONTACT_FIRST_NAME,CONTACT_PHONE_NUMBER,MAILING_ADDR_LINE_1,"
            + "MAILING_CITY,MAILING_STATE_CODE,MAILING_ZIP,LICENSE_STATUS,"
            + "COUNTY_DESCR,SAP_ID,NAPD_ID,GLN_ID,FFLX_CODE,FFLX_DLR,MIR_1,MIR_2,MIR_3,"
            + "MIR_4,MIR_5,MIR_6,MIR_7,MIR_8,MIR_9,MIR_10,MAX_EFF_DATE FROM GROWER_INQUIRY_VW WHERE RPT_ID = ?" + " AND MAX_EFF_DATE > ?";

    public CustomerReviewMappingQuery() {
      super(getDataSource(), CUSTOMER_REVIEW_SQL);
      super.declareParameter(new SqlParameter("RPT_ID", Types.NUMERIC));
      super.declareParameter(new SqlParameter("MAX_EFF_DATE", Types.DATE));
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      GrowerDetails growerDetails = new GrowerDetails(rs.getString("INVOICE"), rs.getString("ACCT_NAME"), rs
              .getString("CONTACT_FIRST_NAME"), rs.getString("CONTACT_LAST_NAME"), new CustomerIds(rs.getLong("GROWER_ID"),
              rs.getString("SAP_ID"), rs.getString("NAPD_ID"), rs.getString("GLN_ID")), rs.getString("LICENSE_STATUS"),
              new AddressInformation(rs.getString("MAILING_ADDR_LINE_1"), rs.getString("MAILING_CITY"), rs
                      .getString("MAILING_STATE_CODE"), rs.getString("MAILING_ZIP"), rs.getString("COUNTY_DESCR")), null, rs
              .getLong("FFLX_DLR"), rs.getString("FFLX_CODE"), rs.getString("CONTACT_PHONE_NUMBER"), new java.util.Date(rs.getTimestamp("MAX_EFF_DATE").getTime()),
              null);
      List mirIds = new ArrayList();
      String mirColName = "MIR_";
      long mirId;
      for (int i = 1; i < 10; i++) {
        mirId = rs.getLong(mirColName + i);
        if (mirId != 0) {
          mirIds.add(new Long(mirId));
        }
      }
      growerDetails.setMirIds(mirIds);

      return growerDetails;
    }
  }

  /**
   * Map the results from database queries (customer details) to GrowerDetail
   * Objects.
   */
  public class CustomerReviewMappingFmgrQuery extends MappingSqlQuery {

    private static final String CUSTOMER_REVIEW_SQL = "SELECT DISTINCT INVOICE,GROWER_ID,ACCT_NAME,"
            + "CONTACT_LAST_NAME,CONTACT_FIRST_NAME,CONTACT_PHONE_NUMBER,MAILING_ADDR_LINE_1,"
            + "MAILING_CITY,MAILING_STATE_CODE,MAILING_ZIP,LICENSE_STATUS,"
            + "COUNTY_DESCR,SAP_ID,NAPD_ID,GLN_ID,FMGR_CODE,FFLX_CODE,FFLX_DLR,MIR_1,MIR_2,MIR_3,"
            + "MIR_4,MIR_5,MIR_6,MIR_7,MIR_8,MIR_9,MIR_10,MAX_EFF_DATE FROM GROWER_INQUIRY_VW WHERE RPT_ID = ?" + " AND MAX_EFF_DATE > ?";

    public CustomerReviewMappingFmgrQuery() {
      super(getDataSource(), CUSTOMER_REVIEW_SQL);
      super.declareParameter(new SqlParameter("RPT_ID", Types.NUMERIC));
      super.declareParameter(new SqlParameter("MAX_EFF_DATE", Types.DATE));
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      GrowerDetails growerDetails = new GrowerDetails(rs.getString("INVOICE"), rs.getString("ACCT_NAME"), rs
              .getString("CONTACT_FIRST_NAME"), rs.getString("CONTACT_LAST_NAME"), new CustomerIds(rs.getLong("GROWER_ID"),
              rs.getString("SAP_ID"), rs.getString("NAPD_ID"), rs.getString("GLN_ID")), rs.getString("LICENSE_STATUS"),
              new AddressInformation(rs.getString("MAILING_ADDR_LINE_1"), rs.getString("MAILING_CITY"), rs
                      .getString("MAILING_STATE_CODE"), rs.getString("MAILING_ZIP"), rs.getString("COUNTY_DESCR")), null, rs
              .getLong("FFLX_DLR"), rs.getString("FFLX_CODE"), rs.getString("CONTACT_PHONE_NUMBER"), new java.util.Date(rs.getTimestamp("MAX_EFF_DATE").getTime()),
              null);
      List mirIds = new ArrayList();
      String mirColName = "MIR_";
      long mirId;
      for (int i = 1; i < 10; i++) {
        mirId = rs.getLong(mirColName + i);
        if (mirId != 0) {
          mirIds.add(new Long(mirId));
        }
      }
      growerDetails.setMirIds(mirIds);
      growerDetails.setFmgrApproved(rs.getString("FMGR_CODE"));
//      growerDetails.setFmgrApprovedId(rs.getString("FMGR_ID"));

      return growerDetails;
    }
  }

  /**
   //   * @see com.monsanto.ag.cf.dao.CustomerReviewDao#getCustomerInformation(java.util.List,
   *      java.util.Date)
   */
  public List getCustomerInformationFmgr(long accountId, Date fromDate) {
    CustomerReviewMappingFmgrQuery customerReviewMappingFmgrQuery = new CustomerReviewMappingFmgrQuery();
    Object[] queryParmsForCustomerReview = new Object[] { new Long(accountId), new java.sql.Date(fromDate.getTime()) };
    List details = customerReviewMappingFmgrQuery.execute(queryParmsForCustomerReview);
    addCustomerZoneInformation(details);
    return details;
  }

  /**
   //   * @see com.monsanto.ag.cf.dao.CustomerReviewDao#getCustomerInformation(java.util.List,
   *      java.util.Date)
   */
  public List getCustomerInformation(long accountId, Date fromDate) {
    CustomerReviewMappingQuery customerReviewMappingQuery = new CustomerReviewMappingQuery();
    Object[] queryParmsForCustomerReview = new Object[] { new Long(accountId), new java.sql.Date(fromDate.getTime()) };
    List details = customerReviewMappingQuery.execute(queryParmsForCustomerReview);
    addCustomerZoneInformation(details);
    return details;
  }

  private void addCustomerZoneInformation(List customerDetails) {
    for (Iterator custIterator = customerDetails.iterator(); custIterator.hasNext();) {
      GrowerDetails grower = (GrowerDetails) custIterator.next();
      List zones = getCustomerZoneDetails(grower.getCustomerIds().getAccountId());
      grower.setZoneInformation(zones);
      customerDetails.set(customerDetails.indexOf(grower), grower);
    }
  }

  private List getCustomerZoneDetails(long accountId) {
    ZoneMappingQuery query = new ZoneMappingQuery();
    Object[] queryParms = new Object[] { new Long(accountId) };
    return query.execute(queryParms);

  }
}
