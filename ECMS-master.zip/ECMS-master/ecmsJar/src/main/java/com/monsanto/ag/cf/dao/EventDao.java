/*
 * EventDao was created on May 6, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import java.util.List;

import com.monsanto.ag.cf.domain.SystemEvent;

/**
 * Data Access Object for SystemEvent information.
 * 
 * @author Gareth Davies
 * @version $Id: EventDao.java,v 1.3 2005-05-13 14:00:37 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC74
 */
public interface EventDao {

  public List findEventsByConversationIdAndStatusCode(String conversationId,
      String statusCode);

  public void storeEvent(SystemEvent event);

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/05/11 19:17:17  ggdavi
 * Added findEventsByConversationIdAndStatusCode method
 * Revision 1.1 2005/05/09 18:05:29 ggdavi Initial
 * version
 *  
 */