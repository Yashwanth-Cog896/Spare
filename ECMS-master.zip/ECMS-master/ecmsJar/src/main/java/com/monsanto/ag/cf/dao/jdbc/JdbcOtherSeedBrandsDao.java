package com.monsanto.ag.cf.dao.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowCallbackHandler;

public class JdbcOtherSeedBrandsDao extends BaseJdbcDao implements OtherSeedBrandsDao {
	public String getAgiisIdForDealer(long dealerId) {
		final List agiisIdList = new ArrayList();
		String sql = "select agiis_customer_id from ecom.dealer_product_list where dealer_id = " + dealerId;
		getJdbcTemplate().query(sql, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				agiisIdList.add(rs.getString("agiis_customer_id"));
			}
		});
		return agiisIdList.size() == 0 ? "" : (String) agiisIdList.get(0);
	}
	
	public Set getOtherSeedBrandsForDealer(long dealerId) {
		String sql = "select brand from ecom.dealer_product_list where dealer_id = " + dealerId;
		final Set brands = new HashSet();
		getJdbcTemplate().query(sql, new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
				brands.add(rs.getString("brand"));
			}
		});
		return brands;
	}
	
	public Set getOtherSeedBrandsForDealerSinceLastDXDate(final long dealerId, final Date lastDxDate) {
		String sql = "select brand from ecom.dealer_product_list where dealer_id = ? and row_entry_date > ?";
		final Set brands = new HashSet();
		getJdbcTemplate().query(sql,
			new PreparedStatementSetter() {
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setLong(1, dealerId);
					ps.setTimestamp(2, new java.sql.Timestamp(lastDxDate.getTime()));
				}
			},
			new RowCallbackHandler() {
				public void processRow(ResultSet rs) throws SQLException {
					brands.add(rs.getString("brand"));
				}
		});
		return brands;
	}	
}
