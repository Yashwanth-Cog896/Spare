/*
 * COSHelper was created on Jun 5, 2008 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.service.impl;

import org.springframework.dao.IncorrectResultSizeDataAccessException;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlStreamBuilder;

public class COSHelper {

    private static final String KEY_CONVERSATION_ID = "ConversationID";
    private static final String CHUNKSIZE = "ChunkSize";
    private static final String XPATH_FROM_PARTNER_INFO = "//cidx:Header/cidx:From/cidx:PartnerInformation";

    public static void updateInputDocumentIfDocumentDoesNotContainEBID(XmlDocument document, IdentityPrincipal idPrincipal, IdMapperDao idMapperDao) {
        String xpathAgencyEBIDAttribute = XPATH_FROM_PARTNER_INFO + "/cidx:PartnerIdentifier[@"
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.EBID_AGENCY + "']";
    String xpathAgencyAccountIdAttribute = XPATH_FROM_PARTNER_INFO + "/cidx:PartnerIdentifier[@"
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.ACCOUNT_ID_AGENCY + "']";
    XmlElement partnerIdEBIDNode = document.selectElementByXPath(xpathAgencyEBIDAttribute);
    XmlElement partnerIdAccountIdNode = document.selectElementByXPath(xpathAgencyAccountIdAttribute);
    if (XmlElement.NULL.equals(partnerIdEBIDNode) && !(XmlElement.NULL.equals(partnerIdAccountIdNode))) {
      try {
        String message = "OrderStatusListRequest document does not contain a valid EBusiness Id, so enriching with the authenticated user's SAP Id";
        Logger.log(new DebugLogEvent(message));

        String sapId = idMapperDao.findSAPIdByAccountId(idPrincipal.getAccountId());
        partnerIdAccountIdNode.setText(sapId);
        partnerIdAccountIdNode.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.SAP_ID_AGENCY);
      } catch (IncorrectResultSizeDataAccessException e) {
        throw new ServiceException("Cannot process COS, could not find SAPId for this Account");
      }
    }
  }
  
  public static ServiceInput prepareInputDocument(XmlDocument inputDocument, String conversationId, XmlMessageInformer outputXmlMessageInformer) {
    ServiceInput input = buildServiceInput(inputDocument, conversationId);

    if (outputXmlMessageInformer.getChunkSize() > 0) {
      input.addParameter(CHUNKSIZE, Integer.toString(outputXmlMessageInformer.getChunkSize()));
      input.setOutputXmlChunkParentXpath(XmlStreamBuilder.CHUNK_WRAPPER_ELEMENT_NAME);
    }
    return input;
  }

  private static ServiceInput buildServiceInput(XmlDocument document, String conversationId) {
    String rootNodeName = document.getRootElement().getUnqualifiedName();
    ServiceInput input = new ServiceInput(document, rootNodeName);
    input.addParameter(KEY_CONVERSATION_ID, conversationId);

    return input;
  }

}


/*
 * $Log: not supported by cvs2svn $
 */