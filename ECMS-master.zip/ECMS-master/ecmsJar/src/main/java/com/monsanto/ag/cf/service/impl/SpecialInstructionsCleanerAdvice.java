/*
 * SpecialInstructionsCleanerAdvice was created on May 12, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.lang.reflect.Method;
import java.util.Map;

import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.dao.DataAccessException;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.SpecialInstructionsDao;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.server.ServiceAdvice;

/**
 * Spring Framework after-method-returning advice that can be introduced in a
 * chain to acknowledge as completed any special instructions for the current
 * user's invocation of the target service.
 * 
 * @author Gareth Davies
 * @version $Id: SpecialInstructionsCleanerAdvice.java,v 1.5 2005/05/17 16:31:51
 *          ggdavi Exp $
 * @see SeedTrakInsourcingScope FC56
 */
public class SpecialInstructionsCleanerAdvice extends ServiceAdvice implements
    AfterReturningAdvice {

  //The following are injected by Spring
  private SpecialInstructionsDao specialInstructionsDao;
  /**
   * The following property, alternateServiceIdsToClean, is a Map in
   * which the key is the serviceId of the web service that this advice
   * applies to (i.e. the actual web service that was invoked), and the
   * value is the serviceId of the Special Instructions records that
   * should be removed from the database
   * (i.e. matches ECOM.SPECIAL_INSTRUCTION.DATA_EXCHANGE_TYPE_CODE).
   * <p/>
   * Note that serviceIds are defined by the value of the property "id"
   * for the service implementation beans defined in applicationContext.xml.
   * See the beans with Spring bean IDs of "gpos" and "gposlite" in
   * applicationContext.xml as examples.
   * <p/>
   * An example of the effects of this Map is as follows:  If there was an
   * entry with a key of "GPOSLT" and a value of "GPOS", then when the
   * service with a serviceId of GPOSLT is invoked, this class will remove
   * the Special Instruction records for the serviceId of "GPOS".  This facility
   * is anticipated to be used with the "Lite" versions of various services.
   */
  private Map alternateServiceIdsToClean;

  /**
   * @see org.springframework.aop.AfterReturningAdvice#afterReturning(java.lang.Object,
   *      java.lang.reflect.Method, java.lang.Object[], java.lang.Object)
   */
  public void afterReturning(Object returnValue, Method method, Object[] args,
      Object target) throws Throwable {
    Subject subject = getCurrentUser(args, method);
    long accountId = SecurityUtil.getIdentityPrincipal(subject).getAccountId();
    String serviceId = getServiceId(target);

    if (isReturnValueValidXmlDocumentList(returnValue, method)
        && isAccountIdValid(accountId) && isServiceIdValid(serviceId)) 
    {
      if (alternateServiceIdsToClean != null) {
        /* 
         * MAS 2-21-08: The alternateServiceIdsToClean Map is being implemented
         * to solve the following problem: The existing "Support App" which the
         * user uses to enter Special Instructions in table ECOM.SPECIAL_INSTRUCTION,
         * sets the column DATA_EXCHANGE_TYPE_CODE to "GPOS", which corresponds
         * to a web service serviceId. This class deletes those records. But we
         * want the GPOSLite web service, not just GPOS web service, to delete
         * records where DATA_EXCHANGE_TYPE_CODE to "GPOS".  So to handle this
         * case, the Map should contain a key of "GPOSLT" (GPOSLite serviceId)
         * and a value of "GPOS".
         * 
         * Note a different implementation might be to make this (or similar)
         * Map which provide an ADDITIONAL serviceId versus an ALTERNATE
         * serviceId, but let this run in the real world before guessing at 
         * a more complicated implementation.
         */ 
        String altServiceId = (String) alternateServiceIdsToClean.get(serviceId);
        if (altServiceId != null && altServiceId.trim().length() > 0) {
          serviceId = altServiceId;
        }
      }
      Logger.log(new LoggableInfo("Removing special instructions for account: "
          + accountId + " and service: " + serviceId));
      removeInstructions(accountId, serviceId);
    } else {
      Logger.log(new LoggableInfo(
          "Special instructions will not be removed for account: " + accountId
              + " and service: " + serviceId));
    }
  }

  private boolean isReturnValueValidXmlDocumentList(Object returnValue,
      Method method) {
    return (getOutputXmlChunks(returnValue, method) != null);
  }

  private boolean isAccountIdValid(long accountId) {
    return accountId > 0;
  }

  private boolean isServiceIdValid(String appId) {
    return StringUtils.isNotBlank(appId);
  }

  private void removeInstructions(long accountId, String serviceId) {
    try {
      specialInstructionsDao.removeInstructions(accountId, serviceId);
    } catch (DataAccessException e) {
      Logger.log(new LoggableError(e));
    }
  }

  /** IOC setter */
  public void setSpecialInstructionsDao(
      SpecialInstructionsDao specialInstructionsDao) {
    this.specialInstructionsDao = specialInstructionsDao;
  }

  /** IOC setter */
  public void setAlternateServiceIdsToClean(Map alternateServiceIdsToClean) {
    this.alternateServiceIdsToClean = alternateServiceIdsToClean;
  }

  
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.12  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.11  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.10  2005/08/26 16:10:56  ggdavi
 * Moved the Identifiable and Entity classes to the ag.util package and the ServiceAdvice class to the ag.soa package for better dependency management
 *
 * Revision 1.9  2005/08/02 20:57:37  ggdavi
 * Modified service interfaces, implementations and advice to support message/document chunking
 *
 * Revision 1.8  2005/06/17 18:20:45  ggdavi
 * Refactored ag.cf.security to move common objects to ag.security; moved CidxDocumentHelper from ag.cf.service.impl to ag.util
 *
 * Revision 1.7  2005/05/31 20:38:42  ggdavi
 * Throw SOAPFaultExceptions instead of creating SOAPFault documents
 *
 * Revision 1.6  2005/05/17 17:53:23  ggdavi
 * All AOP advice classes targeted at service implementations now extend the ServiceAdvice abstract class
 * Revision 1.5 2005/05/17
 * 16:31:51 ggdavi Extracted ag.util.XmlDateTimeUtil and ag.soa.ErrorDocument
 * from ag.util.Utilities
 * 
 * Revision 1.4 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.3 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.2 2005/05/12 23:33:43 ggdavi The
 * isReturnValueValidNonErrorDocument method now calls Utilities.isErrorDocument
 * 
 * Revision 1.1 2005/05/12 21:25:55 ggdavi Initial version
 *  
 */