/*
 * EcmsXmlUtils was created on Feb 8, 2008 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf;

import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XmlDocument;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Static utility methods that have something to do with manipulating XML
 * in string or DOM form, including W3C, Dom4j, com.monsanto.ag.xml.XmlDocument,
 * and so on.
 * <p/>
 * This class may need to be refactored later. As of 2/8/08, I am putting
 * miscellaneous methods in here as prove necessary to get JUnit tests passing
 * and/or have visibility into the ECMS code behavior, into this class.
 *
 * @author Mark Schechter
 * @version $Id: EcmsXmlUtils.java,v 1.3 2008-02-13 22:29:53 maschec Exp $
 */
public class EcmsXmlUtils {

  /** Private constructor so class can't be externally instaniated. */
  private EcmsXmlUtils() {
    //Only support static methods
  }

    /** Return the contents of the WebResponse. */
    public static String getResponseContents(WebResponse response) throws IOException {
      if (response == null) {
        throw new IllegalArgumentException("response param cannot be null");
      }

      if (false) {    //Following works, but it appears .getText does the same thing
                      // and is much easier (see below)
        StringBuffer strBuffer = new StringBuffer();
        readStreamIntoStringBuffer(response.getInputStream(), strBuffer);
        return strBuffer.toString();
      }
      else {
        return response.getText();
      }
    }

  /**
   * Returns the dom4j representation of the supplied <code>xml</code>.
   * <p/>
   * Note: If an exception gets thrown regarding non-UTF-8 characters,
   * see {@link com.monsanto.ag.xml.dom4j.test.Dom4jXmlUnit} for how
   * to determine and handle those characters.
   */
  @SuppressWarnings({"JavadocReference"})
  public static Document createDom4jDoc(String xml) {
    if (xml == null) {
      throw new IllegalArgumentException("xml param cannot be null");
    }

    SAXReader reader = new SAXReader();
    try {
      Document dom4jDoc = reader.read(new ByteArrayInputStream(xml.getBytes()));
      return dom4jDoc;
    } catch (DocumentException e) {
      throw new RuntimeException("Got DocumentException: " + e.getMessage(), e);
    }

  }

  /**
   * Format the supplied <code>xml</code> with indentation and line feeds
   * for human readability.  This method is typically only used for debugging,
   * logging, and so on.
   */
  public static String prettyPrintXml(String xml) {
    if (xml == null) {
      throw new IllegalArgumentException("xml param cannot be null");
    }

    Document document = createDom4jDoc(xml);
    return prettyPrintDom4jDoc(document);
  }

  /**
   * Format the supplied <code>xml</code> with indentation and line feeds
   * for human readability.  This method is typically only used for debugging,
   * logging, and so on.
   */
  public static String prettyPrintDom4jDoc(Document dom4jDoc) {
    if (dom4jDoc == null) {
      throw new IllegalArgumentException("dom4jDoc param cannot be null");
    }

    try {
      OutputFormat format = OutputFormat.createPrettyPrint();
      ByteArrayOutputStream outStream = new ByteArrayOutputStream();
      XMLWriter writer = new XMLWriter(outStream, format);
      writer.write(dom4jDoc);
      return outStream.toString(); //Not necessary to close a ByteArrayOutputStream
    } catch (IOException e) {
      throw new RuntimeException("Got IOException: " + e.getMessage(), e);
    }
  }
    /** Read InputStream <code>in</code> into <code>strBuffer</code>. */
    public static void readStreamIntoStringBuffer(InputStream in, StringBuffer strBuffer)
        throws IOException
    {
      int len = 0;
      byte[] read = new byte[8192];
      while ((len = in.read(read)) != -1) {
        strBuffer.append(new String(read, 0, len));
      }
      in.close();
    }

    public static String getSeedYearFromInputDocument(final XmlDocument inputDocument) {
        Integer i = 1;
        String str = inputDocument.getNodeValueByXPath("/ecms:AGIISEntityInquiry/cidx:Header/cidx:From/cidx:PartnerInformation/cidx:ContactInformation[1]/cidx:ContactDescription");
        while (!str.equals("")) {
            if (str.equals("SeedYear")) {
                break;
            }
            i++;
            str = inputDocument.getNodeValueByXPath("/ecms:AGIISEntityInquiry/cidx:Header/cidx:From/cidx:PartnerInformation/cidx:ContactInformation[" + i + "]/cidx:ContactDescription");
        }
        String xpath = "/ecms:AGIISEntityInquiry/cidx:Header/cidx:From/cidx:PartnerInformation/cidx:ContactInformation[" + i + "]/cidx:ContactName";
        return inputDocument.getNodeValueByXPath(xpath);
    }
}
