/*
 * MessageEchoImpl was created on Mar 16, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.Iterator;

import javax.security.auth.Subject;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlStream;

/**
 * POJO implementation of the Message Echo service.
 * 
 * @author ggdavi
 * @version $Id: MessageEchoImpl.java,v 1.27 2008-08-06 22:49:39 mkuchip Exp $
 */
public class MessageEchoImpl implements SecureService, Identifiable {

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "ECHO";
  }
  
  public boolean isValidationRequired() {
    return true;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject)
      throws ServiceException {
    ServiceOutput output = new ServiceOutput();
    output.setConversationId(Utilities.generateConversationId());

    Logger.log(new LoggableInfo("Returning input XML"));
    for (Iterator itInputs = input.getXmlChunks().getIterator(); itInputs
        .hasNext();) {
      XmlStream inputChunk = (XmlStream) itInputs.next();
      output.getXmlChunks().addChunk(inputChunk);
    }

    return output;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }  

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.26  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.25  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.24  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.23  2005/11/08 21:00:31  ggdavi
 * Updated after adding XmlStream (and StAX implementation) to the com.monsanto.ag.util package and refactoring the ServiceInput and ServiceOutput classes to expose both XmlStream and XmlDocument objects
 * Revision 1.22 2005/08/26 16:26:09 ggdavi
 * Javadoc corrections
 * 
 * Revision 1.21 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.20 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.19 2005/08/05
 * 18:37:57 ggdavi Removed deprecated executeSecure method based on DOM
 * documents Revision 1.17 2005/06/20 17:12:36 ggdavi Moved Entity and
 * Identifiable back to ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.16 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.15 2005/05/17 20:25:03 ggdavi Converted XmlMessageInformer from an
 * interface with accessors only to a fully-fledged bean class Revision 1.14
 * 2005/05/11 21:50:33 ggdavi Renamed all Subject method parameters from user to
 * subject for clarity
 * 
 * Revision 1.13 2005/05/06 17:51:44 ggdavi Renamed XPathExporter to
 * XmlMessageInformed and XPathDefiner to XmlMessageInformer
 * 
 * Revision 1.12 2005/04/27 19:18:57 ggdavi Removed to do comment
 * 
 * Revision 1.11 2005/04/25 17:31:20 ggdavi Added getXPathConversationId and
 * getXPathStartTime methods to XmlMessageInformer
 * 
 * Revision 1.10 2005/04/22 16:01:20 ggdavi Renamed
 * XmlMessageInformer.getXPathTransactionCount to getXPathTransaction
 * 
 * Revision 1.9 2005/04/20 17:30:23 ggdavi Look for EBIDs in the XML document
 * instead of Account Ids
 * 
 * Revision 1.8 2005/04/14 16:54:36 ggdavi Moved
 * ag.cf.logging.XmlUserActivityConfigurator to ag.cf.domain.XmlMessageInformer;
 * now implements SecureService Revision 1.7 2005/04/12 19:27:57 ggdavi
 * Implement Service instead of MessageEcho; added setUserId method and userId
 * field
 * 
 * Revision 1.6 2005/04/11 21:49:56 ggdavi Implemented Identifiable interface
 * 
 * Revision 1.5 2005/04/07 15:46:40 ggdavi Stripped out all
 * XmlUserActivity-related code from the echo method Revision 1.4 2005/04/05
 * 21:42:16 ggdavi Got working with inline XmlUserActivity, activityLogger field
 * and XmlMessageInformer interface
 * 
 * Revision 1.3 2005/04/01 21:04:27 ajbaldw Added code to call the
 * ActivityLogger. Revision 1.2 2005/03/21 15:30:40 ggdavi Renamed parameter in
 * echo method Revision 1.1 2005/03/16 20:02:18 ggdavi Initial version
 */