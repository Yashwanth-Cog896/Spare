/*
 * OrderCreateImpl was created on Jan 26, 2009 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.ConversationIdUtil;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlDocumentBuilder;

public class OrderCreateImpl extends ServiceProxySupport implements
SecureService, Identifiable{

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    String conversationId = Utilities.generateConversationId();

    Logger.log(new LoggableInfo(
        "Processing Order Create request with Conversation Id: "
            + conversationId));
    ServiceOutput output = soaClient.call(serviceId, input);
    output.setConversationId(conversationId);
    ConversationIdUtil.substituteDocumentIdentifier(output.getXmlChunks()
        .getXmlDocument(xmlDocumentBuilder), conversationId);
    return output;
  }

  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

    public boolean isValidationRequired() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public String getId() {
    return "ORDERCREATE";
  }

  public void setInputXmlMessageInformer(
      XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(
      XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2009/01/26 23:01:32  caggarw
 * Order Create web service.
 *
 */