/*
 * FarmsourceAuthenticatorServiceProxy was created on Mar 23, 2005 using
 * Monsanto resources and is the sole property of Monsanto. Any duplication of
 * the code and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.proxy;

import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;
import javax.security.auth.login.CredentialExpiredException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;

import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.Authenticator;
import com.monsanto.ag.security.RolePrincipal;


/**
 * Proxy for the Farmsource Authentication Web Service.
 * 
 * @author Gareth Davies
 * @version $Id: FarmsourceAuthenticatorServiceProxy.java,v 1.1 2005/03/24
 *          15:37:42 ggdavi Exp $
 // @see SeedTrakInsourcingScope BR60, FC77
 */
public class FarmsourceAuthenticatorServiceProxy extends ServiceProxySupport
    implements Authenticator {

  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  public Subject loginUser(String userId, String password)
      throws LoginException {
    Logger.log(new LoggableInfo("Authenticating user " + userId
        + " against Farmsource repository"));
    verifyCredentialsPresent(userId, password);
    XmlDocument authDoc = getAuthenticatorServiceResponseDocument(userId,
        password);
    Subject subject = buildSubjectFromServiceResponse(authDoc, userId);
    return subject;
  }

  private void verifyCredentialsPresent(String userId, String password)
      throws FailedLoginException {
    if (userId == null || password == null) {
      Logger.log(new LoggableWarning("No credentials passed to loginUser"));
      throw new FailedLoginException(DEFAULT_ERROR_MESSAGE);
    }
  }

  private XmlDocument getAuthenticatorServiceResponseDocument(String userId,
      String password) throws LoginException {
    try {
      XmlDocument inputDoc = buildInputDocument(userId, password);
      ServiceInput input = new ServiceInput(inputDoc);

      ServiceOutput output = soaClient.call(serviceId, input);

      XmlDocument outputDoc = XmlDocument.NULL;
      XmlChunks outputXmlChunks = output.getXmlChunks();
      if (!outputXmlChunks.isEmpty()) {
        outputDoc = outputXmlChunks.getXmlDocumentChunk(xmlDocumentBuilder, 0);
      }
      return outputDoc;
    } catch (ServiceException e) {
      Logger.log(new LoggableWarning(e.getMessage()));
      throw new LoginException(REQUEST_ERROR_MESSAGE);
    }
  }

  private XmlDocument buildInputDocument(String userId, String password) {
    XmlDocument inputDoc = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootNode = inputDoc.addRootElement("authrequest");
    rootNode.addChildElement("user-id", userId);

    XmlElement passwordElement = rootNode.addChildElement("password");
    passwordElement.setCDATA(password);

    return inputDoc;
  }

  private Subject buildSubjectFromServiceResponse(XmlDocument authDoc,
      String userId) throws CredentialExpiredException, LoginException,
      FailedLoginException {
    Subject subject = new Subject();

    XmlElement rootElement = authDoc.selectElementByXPath("authresponse");
    if (XmlElement.NULL.equals(rootElement)) {
      checkError(authDoc);
    } else {
      addIdentityPrincipal(subject, authDoc, userId);
      addRolePrincipals(subject, authDoc);
    }

    return subject;
  }

  private void checkError(XmlDocument authDoc)
      throws CredentialExpiredException, LoginException {
    XmlElement rootElement = authDoc.selectElementByXPath("error");
    if (XmlElement.NULL.equals(rootElement)) {
      throw new LoginException(REQUEST_ERROR_MESSAGE);
    } else {
      String errorCode = authDoc.getNodeValueByXPath("/error/code");
      if ("CredentialExpiredException".equals(errorCode)) {
        throw new CredentialExpiredException(EXPIRED_PASSWORD_ERROR_MESSAGE);
      } else {
        String errorMessage = authDoc.getNodeValueByXPath("/error/message");
        Logger.log(new LoggableWarning(errorMessage));
        throw new FailedLoginException(DEFAULT_ERROR_MESSAGE);
      }
    }
  }

  private void addIdentityPrincipal(Subject subject, XmlDocument authDoc,
      String userId) throws FailedLoginException {
    String accountIdNodeValue = authDoc
        .getNodeValueByXPath("/authresponse/acct-id");
    String ebid = authDoc.getNodeValueByXPath("/authresponse/eb-id");
    String accountName = authDoc.getNodeValueByXPath("/authresponse/acct-name");

    long accountId = idTranslator.parseAccountId(accountIdNodeValue);
    IdentityPrincipal principal = new IdentityPrincipal(userId, accountId,
        ebid, accountName);
    subject.getPrincipals().add(principal);
  }

  private void addRolePrincipals(Subject subject, XmlDocument authDoc)
      throws FailedLoginException {
    List roles = authDoc.selectElementsByXPath("/authresponse/roles/role-name");
    if (roles.isEmpty()) {
      throw new FailedLoginException(DEFAULT_ERROR_MESSAGE);
    } else {
      for (Iterator itRole = roles.iterator(); itRole.hasNext();) {
        XmlElement roleElement = (XmlElement) itRole.next();
        String roleName = roleElement.getText();
        RolePrincipal principal = new RolePrincipal(roleName.toUpperCase());
        subject.getPrincipals().add(principal);
      }
    }
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.16  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 * Revision 1.15 2005/11/22
 * 22:41:25 caggarw changes for storing EBID as a String within the
 * web-services, as it may contain alpha numeric characters
 * 
 * Revision 1.14 2005/11/21 22:40:07 ggdavi Removed obsolete import
 * 
 * Revision 1.13 2005/11/21 20:35:59 caggarw Changed to store the accountName as
 * well in the IdentityPrincipal
 * 
 * Revision 1.12 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and
 * StAX implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects Revision 1.11 2005/10/17 14:51:51 ggdavi Updated missing
 * credentials test
 * 
 * Revision 1.10 2005/08/24 16:48:34 ggdavi Added logging statements Revision
 * 1.9 2005/08/23 17:12:48 ggdavi Moved ServiceInput and ServiceOutput from
 * ag.soa.client to ag.soa
 * 
 * Revision 1.8 2005/08/05 18:35:22 ggdavi SoaClient.call method now returns a
 * ServiceOutput object; use XmlDocument objects instead of DOM Document objects
 * (via injected xmlDocumentBuilder) Revision 1.7 2005/07/26 17:16:05 ggdavi
 * Added idTranslator field and allow for missing EBIDs in the response Revision
 * 1.6 2005/07/21 14:48:57 ggdavi Fleshed out and refactored
 * com.monsanto.ag.util to make more object-oriented, in that most functionality
 * has been pushed to the XmlDocument and XmlElement objects Revision 1.5
 * 2005/07/05 22:32:00 ggdavi Added private addChildElementAsCData method (for
 * now...)
 * 
 * Revision 1.4 2005/06/30 20:23:40 ggdavi Use node.getOwnerDocument instead of
 * helper.getDocument(node)
 * 
 * Revision 1.3 2005/06/17 18:19:09 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security
 * 
 * Revision 1.2 2005/05/31 20:31:30 ggdavi No longer an ErrorDocument class, so
 * use hardwired error code XPath
 * 
 * Revision 1.1 2005/05/23 16:31:58 ggdavi Moved
 * FarmsourceAuthenticatorServiceProxy and FarmsourceOutageServiceProxy to
 * ag.cf.service.proxy
 * 
 * Revision 1.14 2005/05/18 18:18:39 ggdavi Overhauled ag.soa.client package,
 * replacing Farmsource and WebMethods specific subclasses of BaseSoaClient with
 * XmlHttpSoaClient, whose behavior is parameterized via collaborators
 * 
 * Revision 1.13 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.12 2005/05/03 18:24:49 ggdavi Use Utilities.addChildElementAsCData
 * method for password element
 * 
 * Revision 1.11 2005/05/03 18:15:42 ggdavi Renamed serviceUrl field to
 * serviceId
 * 
 * Revision 1.10 2005/05/02 16:07:40 ggdavi Replaced SoaClient.call(String,
 * SoaRequestCreator) method with simpler call(String, Document) method Revision
 * 1.9 2005/04/21 15:30:02 ggdavi Farmsource Authentication service now returns
 * an acct-id element
 * 
 * Revision 1.8 2005/04/20 17:22:07 ggdavi Added ebusinessId field to
 * IdentityPrincipal
 * 
 * Revision 1.7 2005/04/19 16:24:30 ggdavi More changes to support long account
 * Ids Revision 1.6 2005/04/19 15:33:34 lsdenny converted int account id to long
 * account id
 * 
 * Revision 1.5 2005/04/14 17:05:07 ggdavi Renamed addIdentityPrincipals to
 * addIdentityPrincipal
 * 
 * Revision 1.4 2005/04/13 16:33:34 ggdavi Now extends ServiceProxySupport
 * (which defines and sets fields); build request Document using DOMUtil
 * Revision 1.3 2005/04/11 21:49:41 ggdavi Corrected traceability javadoc
 * 
 * Revision 1.2 2005/04/08 21:57:13 ajbaldw Changed name of error constant.
 * 
 * Revision 1.1 2005/04/08 18:09:13 ggdavi Renamed AuthenticatorServiceProxy to
 * FarmsourceAuthenticatorServiceProxy Revision 1.2 2005/03/24 16:39:59 ggdavi
 * Added Javadoc comments, including traceability references Revision 1.1
 * 2005/03/24 15:37:42 ggdavi Initial version
 */