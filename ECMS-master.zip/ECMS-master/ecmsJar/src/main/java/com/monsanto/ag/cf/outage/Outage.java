/*
 * Outage was created on Apr 11, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.outage;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Represents application outage inforamtion.
 * 
 * @author Gareth Davies
 * @version $Id: Outage.java,v 1.7 2005-11-10 16:50:37 caggarw Exp $
 */
public class Outage implements Serializable {

  private static final DateFormat DATE_TIME_DISPLAY_FORMAT = new SimpleDateFormat(
      "MM/dd/yy hh:mm a");
  private String appId;
  private Date startDate;
  private Date endDate;
  private String description;

  public Outage() {
  }

  public Outage(String appId, Date startDate, Date endDate, String description) {
    this.appId = appId;
    this.startDate = startDate;
    this.endDate = endDate;
    this.description = description;
  }

  public String getAppId() {
    return appId;
  }

  public Date getStartDate() {
    return startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public String getDescription() {
    return description;
  }

  /**
   * Determines whether or not this outage is current by comparing the system
   * time with the outage date range.
   * 
   * @return True if the outage date range brackets the system time
   */
  public boolean isCurrent() {
    Date now = new Date();
    return (outageStartsInPast(startDate, now) && outageEndsInFuture(endDate,
        now));
  }

  /**
   * Gets a human-readable outage message based on this object's field values.
   * 
   * @return Outage message
   */
  public String getMessage() {
    if (endDate == null) {
      return appId + " will be out of service between " + formatDate(startDate)
          + " and the forseeable future: " + description;
    } else {
      return appId + " will be out of service between " + formatDate(startDate)
          + " and " + formatDate(endDate) + ": " + description;
    }
  }

  private boolean outageStartsInPast(Date startDate, Date now) {
    return startDate != null && now.after(startDate);
  }

  private boolean outageEndsInFuture(Date endDate, Date now) {
    return (endDate == null || now.before(endDate));
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof Outage)) {
      return false;
    }
    Outage rhs = (Outage) obj;
    return new EqualsBuilder().appendSuper(super.equals(rhs)).append(appId,
        rhs.getAppId()).append(startDate, rhs.getStartDate()).append(endDate,
        rhs.getEndDate()).append(description, rhs.getDescription()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 11).appendSuper(super.hashCode()).append(
        appId).append(startDate).append(endDate).append(description)
        .toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(
        super.toString()).append("appId", appId).append("startDate", startDate)
        .append("endDate", endDate).append("description", description)
        .toString();
  }

  public static String formatDate(java.util.Date date) {

    return (DATE_TIME_DISPLAY_FORMAT.format(date));
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.6 2005/08/26 16:10:56 ggdavi Moved the
 * Identifiable and Entity classes to the ag.util package and the ServiceAdvice
 * class to the ag.soa package for better dependency management
 * 
 * Revision 1.5 2005/06/20 17:12:36 ggdavi Moved Entity and Identifiable back to
 * ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.4 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.3 2005/05/31 20:41:46 ggdavi Added getMessage method Revision 1.2
 * 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config, ag.cf.util to
 * ag.aop, ag.config, ag.util
 * 
 * Revision 1.1 2005/04/11 21:46:28 ggdavi Initial version
 * 
 */