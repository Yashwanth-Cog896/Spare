/*
 * FarmManagerListImpl was created on May 24, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.FarmManagerDao;
import com.monsanto.ag.cf.service.FarmManagerSerializer;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.*;

import javax.security.auth.Subject;
import java.util.List;


/**
 * The POJO implementation of FarmManagerList service.
 *
 * @author CAGGARW
 * @version $Id: FarmManagerListImpl.java,v 1.38 2008-08-06 22:49:39 mkuchip Exp $
 */
public class FarmManagerListImpl implements Identifiable, SecureService {

  protected static final XmlNamespace NAMESPACE_FMLIST_RESPONSE = new XmlNamespace("ecms",
          "urn:ecms:schema:fmlist:response:1:0");

  private FarmManagerDao farmManagerDao;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private FarmManagerSerializer farmManagerSerializer;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "FM";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public boolean isValidationRequired() {
    return true;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo("Processing farm manager list request with conversation Id: " + conversationId));

    IdentityPrincipal idPrincipal = getIdentityPrincipalOfCurrentUser(subject);
    List farmManagerList = farmManagerDao.getFarmManagers();

    XmlChunks outputXmlChunks = buildFarmManagerListDocuments(conversationId, idPrincipal, farmManagerList);
    output.getXmlChunks().addChunks(outputXmlChunks);

    return output;
  }

  private IdentityPrincipal getIdentityPrincipalOfCurrentUser(Subject subject) {
    IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(identityPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    }
    return identityPrincipal;
  }

  private XmlChunks buildFarmManagerListDocuments(final String conversationId, final IdentityPrincipal idPrincipal,
                                                  List farmManagerList) {
    int chunkSize = outputXmlMessageInformer.getChunkSize() * 2;
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(farmManagerList, chunkSize,
            new XmlStreamListAppender() {

              public XmlStream buildXmlStream(List domainItems) {
                return farmManagerSerializer.buildFarmManagerListDocument(conversationId, idPrincipal, domainItems);
              }

            });

    return outputXmlChunks;
  }

  public void setFarmManagerDao(FarmManagerDao farmManagerDao) {
    this.farmManagerDao = farmManagerDao;
  }

  public void setFarmManagerSerializer(FarmManagerSerializer farmManagerSerializer) {
    this.farmManagerSerializer = farmManagerSerializer;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public FarmManagerDao getFarmManagerDao() {
    return farmManagerDao;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.37  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.36  2006/07/13 18:50:19  caggarw
 * Refactored to Delegate the XML Document creation to a Serializer
 * Revision 1.35 2006/06/21 21:58:27 caggarw
 * Refactoring to store input/output documents in the data_exchange respository
 * as well as the root node name of the document. We now have separate
 * messageinformers for input and output.
 * 
 * Revision 1.34 2006/01/24 18:56:18 ggdavi Moved ChunkableServiceEndpoint,
 * SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to
 * com.monsanto.ag.soa.server. This will simplify the class exclusion process
 * for consumer classes only interested in ag.soa.client classes.
 * 
 * Revision 1.33 2006/01/24 18:36:56 ggdavi Factored out the
 * ag.util.MessageParticant class from ag.security.IdentityPrincipal (which
 * delegates to it) so that the ag.xml.CidxDocumentHelper class no longer
 * depends on the ag.security package Revision 1.32 2005/12/01 19:34:30 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks
 * 
 * Revision 1.31 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and
 * StAX implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects
 * 
 * Revision 1.30 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.29 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.28 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.27 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.26 2005/08/05
 * 18:37:57 ggdavi Removed deprecated executeSecure method based on DOM
 * documents Revision 1.24 2005/07/21 22:14:11 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations
 * 
 * Revision 1.23 2005/07/21 14:48:57 ggdavi Fleshed out and refactored
 * com.monsanto.ag.util to make more object-oriented, in that most functionality
 * has been pushed to the XmlDocument and XmlElement objects Revision 1.22
 * 2005/07/06 21:12:15 ggdavi Added xmlDocumentBuilder field, used to build
 * output XML documents Revision 1.21 2005/06/30 20:24:20 ggdavi Use
 * node.getOwnerDocument instead of helper.getDocument(node)
 * 
 * Revision 1.20 2005/06/23 20:52:09 ggdavi No, actually the Mapping class was
 * in Apache Axis, so reverting to NameSpace...
 * 
 * Revision 1.18 2005/06/22 22:35:04 ggdavi Reflected changes in
 * NamespacedDocumentHelper and subclass addChildElement method usage Revision
 * 1.17 2005/06/20 17:12:36 ggdavi Moved Entity and Identifiable back to
 * ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.16 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.15 2005/06/17 18:20:45 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security; moved CidxDocumentHelper from
 * ag.cf.service.impl to ag.util
 * 
 * Revision 1.14 2005/06/09 21:07:04 ggdavi Namespace constant is now public
 * 
 * Revision 1.13 2005/06/08 20:03:13 ggdavi Added overloaded createRootNode
 * method that also takes the value of the Version attribute
 * 
 * Revision 1.12 2005/06/02 19:16:42 ggdavi addPartnerInformationNode now calls
 * Utilities.leftPadNumber Revision 1.11 2005/06/01 20:16:10 ajbaldw left padded
 * the sap_id's with 3 zeros.
 * 
 * Revision 1.10 2005/06/01 17:21:42 ggdavi Default namespace now matches that
 * specified in the response schema; CIDX-specific elements are added with CIDX
 * namespace prefixes; refactored some methods Revision 1.9 2005/05/31 22:05:28
 * ajbaldw Added the PartnerIdentifier node under PartnerReference to validate
 * against schema. Revision 1.8 2005/05/31 20:38:42 ggdavi Throw
 * SOAPFaultExceptions instead of creating SOAPFault documents Revision 1.7
 * 2005/05/31 17:42:54 ajbaldw changed the body element to FarmManagerListBody
 * 
 * Revision 1.6 2005/05/26 20:40:47 ggdavi Cleaned up imports and formatting
 * 
 * Revision 1.5 2005/05/26 20:30:56 caggarw updated Farm Manager object
 * 
 * Revision 1.4 2005/05/26 17:26:47 ggdavi In CidxDocumentHelper, removed
 * Document parameter from createRootNode and added getDocument method
 * 
 * Revision 1.3 2005/05/25 22:25:55 ggdavi Use CidxDocumentHelper to create
 * standard CIDX root node (with namespaces) and header Revision 1.2 2005/05/25
 * 20:27:42 caggarw added Error Document on RuntimeException Revision 1.1
 * 2005/05/24 22:15:17 caggarw The POJO implementation of FarmManagerList
 * service.
 */