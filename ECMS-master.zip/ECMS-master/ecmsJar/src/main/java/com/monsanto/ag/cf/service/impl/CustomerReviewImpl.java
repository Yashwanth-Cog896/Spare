/*
 * CustomerReviewImpl was created on Aug 13, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.security.auth.Subject;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.CustomerReviewDao;
import com.monsanto.ag.cf.service.CustomerReviewSerializer;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamListAppender;
import com.monsanto.ag.security.IdentityPrincipal;


/**
 * Service Implementation of Customer Review web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: CustomerReviewImpl.java,v 1.5 2008-08-06 22:49:39 mkuchip Exp $
 */
public class CustomerReviewImpl implements SecureService, Identifiable {

  private static final String XPATH_PARTNER_ID = "/ecms:GrowerIDRequest/ecms:GrowerIDRequestBody/ecms:GrowerIDRequestProperties/cidx:PartnerInformation/cidx:PartnerIdentifier";
  private static final String XPATH_FROM_DATE = "/ecms:GrowerIDRequest/ecms:GrowerIDRequestBody/ecms:GrowerIDRequestProperties/cidx:DateTimeInformation/cidx:DateTime[@DateTimeQualifier='After']";
  public static final XmlNamespace NAMESPACE_CUST_REVIEW_RESPONSE = new XmlNamespace("ecms",
      "urn:ecms:schema:growerid:response:1:0");

  protected XmlDocumentBuilder xmlDocumentBuilder;
  protected CustomerReviewDao customerReviewDao;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private CustomerReviewSerializer customerReviewSerializer;

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo("Processing Customer Review request with conversation Id: " + conversationId));
    IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);

    Date fromDate = getFromDateFromInputDocument(inputDocument);
    long accountId = getAccountIdFromInputDocumentOrAuthenicatedUser(inputDocument, identityPrincipal);
    List customerList = customerReviewDao.getCustomerInformation(accountId, fromDate);

    XmlChunks outputXmlChunks = buildCustomerReviewDocuments(conversationId, identityPrincipal, customerList, accountId);
    output.getXmlChunks().addChunks(outputXmlChunks);

    return output;
  }

  protected XmlChunks buildCustomerReviewDocuments(final String conversationId,
      final IdentityPrincipal identityPrincipal, List customerList, final long accountId) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(customerList, chunkSize,
        new XmlStreamListAppender() {

          public XmlStream buildXmlStream(List domainItems) {
            return customerReviewSerializer.buildCustomerReviewDocument(conversationId, identityPrincipal, domainItems,
                accountId);
          }

        });

    return outputXmlChunks;
  }

  protected long getAccountIdFromInputDocumentOrAuthenicatedUser(XmlDocument inputDocument,
      IdentityPrincipal identityPrincipal) {
    long accountId;
    String xpathAccountId = XPATH_PARTNER_ID + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='"
        + CidxConstants.ACCOUNT_ID_AGENCY + "']";
    String xpathEBID = XPATH_PARTNER_ID + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.EBID_AGENCY
        + "']";
    XmlElement partnerIdEBIDNode = inputDocument.selectElementByXPath(xpathAccountId);
    XmlElement partnerIdAccountIdNode = inputDocument.selectElementByXPath(xpathEBID);
    if (!XmlElement.NULL.equals(partnerIdAccountIdNode)) {
      accountId = Long.parseLong(partnerIdAccountIdNode.getText());
    } else if (!XmlElement.NULL.equals(partnerIdEBIDNode)) {
      accountId = Long.parseLong(partnerIdEBIDNode.getText());
    } else
      accountId = identityPrincipal.getAccountId();
    return accountId;
  }
  
  public boolean isValidationRequired() {
    return true;
  }

  protected Date getFromDateFromInputDocument(XmlDocument inputDocument) {
    Date fromDateTime = null;
    try {
      String dateText = inputDocument.getNodeValueByXPath(XPATH_FROM_DATE);
      fromDateTime = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(dateText);
    } catch (ParseException pe) {
      Logger.log(new LoggableWarning(pe));
    }
    return fromDateTime;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "CUSTRW";
  }

  public void setCustomerReviewDao(CustomerReviewDao customerReviewDao) {
    this.customerReviewDao = customerReviewDao;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setCustomerReviewSerializer(CustomerReviewSerializer customerReviewSerializer) {
    this.customerReviewSerializer = customerReviewSerializer;
  }

}
