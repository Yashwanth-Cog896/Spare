/*
 * PALImpl was created on May 24, 2007 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.io.IOException;

import javax.security.auth.Subject;

import org.w3c.dom.Document;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.XSLTUtil;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

import com.monsanto.ag.security.IdentityPrincipal;

/**
 * Service Implementation of the PAL web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: PALImpl.java,v 1.7 2008-06-04 15:03:49 caggarw Exp $
 */
public class PALImpl extends ServiceProxySupport implements SecureService, Identifiable {

  
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdMapperDao idMapperDao;

  public String getId() {
    return "PAL";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    String conversationId = Utilities.generateConversationId();
    Logger.log(new LoggableInfo("Processing PAL request with Conversation Id: " + conversationId));
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    XmlChunks inputXmlChunks = input.getXmlChunks();
    String xpathTransaction = inputXmlMessageInformer.getXpathTransaction();
    inputXmlChunks.setXpathRepeatingElement(xpathTransaction);
    XmlDocument inputDocument = inputXmlChunks.getXmlDocument(xmlDocumentBuilder);
    inputDocument = PALHelper.updateInputDocumentWithBuyerAndShipToSAPId(inputDocument, idPrincipal, idMapperDao);
    ServiceOutput output = delegateRequestToPALService(inputDocument, conversationId);
    return output;
  }

  private ServiceOutput delegateRequestToPALService(XmlDocument inputDocument, String conversationId) {
    XmlDocument transformedinputXML = transformXMLDocument(inputDocument, "PAL_Request.xsl");
    ServiceInput input = new ServiceInput(transformedinputXML, "ProductAvailabilityListRequest");
    ServiceOutput output = soaClient.call(serviceId, input);

    XmlDocument outputDoc = output.getXmlChunks().getXmlDocumentChunk(xmlDocumentBuilder, 0);
    XmlDocument transformedOutputXML = transformXMLDocument(outputDoc, "PAL_Response.xsl");

    XmlChunks outputXmlChunks = new XmlChunks();
    outputXmlChunks.addChunk(transformedOutputXML);

    ServiceOutput transformedOutput = new ServiceOutput(outputXmlChunks);
    transformedOutput.setConversationId(conversationId);
    return transformedOutput;
  }

  private XmlDocument transformXMLDocument(XmlDocument inputDocument, String xsltDocumentPath) {
    XmlDocument transformedinputXML;
    Document transformedInputDocument;

    try {
      transformedInputDocument = XSLTUtil.applyStyleSheet(this, inputDocument.getDOMDocument(), xsltDocumentPath);
      transformedinputXML = xmlDocumentBuilder.createXmlDocument(transformedInputDocument);
      // DOMUtil.outputXML(transformedInputDocument);
    } catch (IOException e) {
      throw new ServiceException("Cannot process PAL, error transforming the document:"
          + inputDocument.getRootElement().getUnqualifiedName());
    }
    return transformedinputXML;
  }

  
  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

    public boolean isValidationRequired() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public void setIdMapperDao(IdMapperDao idMapperDao) {
    this.idMapperDao = idMapperDao;
  }
}
