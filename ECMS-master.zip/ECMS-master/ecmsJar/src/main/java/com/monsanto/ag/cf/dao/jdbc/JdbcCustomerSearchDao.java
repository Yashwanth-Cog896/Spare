/*
 * JdbcEntityInquiryDao was created on Jul 24, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.CustomerSearchDao;
import com.monsanto.ag.cf.domain.*;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Spring JDBC implemenation of the CustomerSearch DAO.
 *
 * @author Chetna Aggarwal
 * @version $Id: JdbcGrowerDetailsInquiryDao.java,v 1.2 2007/07/25 21:54:23
 *          caggarw Exp $
 * 2008/06/05 Doni Added new method for enhancing the service to send agreement_code without filter.
 *
 */
public class JdbcCustomerSearchDao extends BaseJdbcDao implements CustomerSearchDao {

  public class CustomerMappingQuery extends MappingSqlQuery {

    public CustomerMappingQuery(String sql) {
      super(getDataSource(), sql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      GrowerDetails growerDetails = new GrowerDetails(rs.getString("ACCT_NAME"), rs.getString("CONTACT_FIRST_NAME"), rs
              .getString("CONTACT_LAST_NAME"), new CustomerIds(rs.getLong("PURCHASER_ACCT_ID"), "", null, null), rs
              .getString("LICENSE_STATUS"), new AddressInformation(rs.getString("MAILING_ADDR_LINE_1"), rs
              .getString("MAILING_CITY"), rs.getString("MAILING_STATE_CODE"), rs.getString("MAILING_ZIP"), rs
              .getString("COUNTY_DESCR")), null, 0, null, rs.getString("CONTACT_PHONE_NUMBER"), null);
      return growerDetails;
    }

  }

  /**
   * Maps the results from the database query to Zone information objects
   *
   */
  public class CustomerZoneMappingQuery extends MappingSqlQuery {

    private static final String CUSTOMER_ZONE_SQL = "select distinct atza.acct_id,rs.descr azr_descr, "
            + "tzs.species_code as CropCode, "
            + "atza.zone_descr,atza.zone_code,atza.mkt_year_code zone_year "
            + "from agcc.acct_to_zone_mv atza,agcc.trait_to_zone_struct_mv tzs,agcc.region_struct_mv rs "
            + "where atza.zone_struct_code = tzs.zone_struct_code AND atza.zone_struct_code=rs.region_struct_code "
            + "AND tzs.usage_code = 'PR' AND tzs.mkt_year_code=? AND "
            + "atza.mkt_year_code = tzs.mkt_year_code and atza.acct_id=?";

    public CustomerZoneMappingQuery() {
      super(getDataSource(), CUSTOMER_ZONE_SQL);
      super.declareParameter(new SqlParameter("seed_year", Types.VARCHAR));
      super.declareParameter(new SqlParameter("acct_id", Types.INTEGER));
    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      ZoneInformation zoneInformation = new ZoneInformation(rs.getString("AZR_DESCR"), rs.getString("ZONE_DESCR"), rs
              .getString("ZONE_CODE"), rs.getString("ZONE_YEAR"), rs.getString("CropCode"));
      return zoneInformation;
    }

  }

  /**
   * maps the results from the database query to Grower Details objects.
   *
   */
  public class CustomerSearchMappingQuery extends MappingSqlQuery {

    private static final String CUSTOMER_MAPPING_QUERY = "select a.acct_id,sap.alias_id "
            + "SAP_ID,napd.napd_id NAPD_ID,gln.alias_id GLN_ID,agree.agreement_code FFLX_CODE,"
            + "agree.signer_acct_id FFLX_DLR from acct_mv a,acct_xref_mv sap,acct_napd_dnml napd,"
            + "acct_xref_mv gln,acct_to_agreement_mv agree "
            + "where a.acct_id=sap.acct_id(+) AND sap.active_flag(+)='Y' AND sap.system_type_code(+)='SAP' "
            + "AND a.acct_id=napd.acct_id(+) AND a.acct_id=gln.acct_id(+) AND gln.active_flag(+)='Y' "
            + "AND gln.system_type_code(+)='GLN' AND a.acct_id=agree.acct_id(+) AND agree.agreement_code(+)='FFLX' "
            + "AND a.acct_id=?";

    public CustomerSearchMappingQuery() {
      super(getDataSource(), CUSTOMER_MAPPING_QUERY);
      super.declareParameter(new SqlParameter("acct_id", Types.INTEGER));

    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      CustomerIds customerIds = new CustomerIds(rs.getLong("acct_id"), rs.getString("SAP_ID"), rs.getString("NAPD_ID"),
              rs.getString("GLN_ID"));
      GrowerDetails growerDetails = new GrowerDetails();
      growerDetails.setCustomerIds(customerIds);
      growerDetails.setFflxCode(rs.getString("FFLX_CODE"));
      growerDetails.setFflxId(rs.getLong("FFLX_DLR"));
      return growerDetails;
    }

  }


  /**
   * maps the results from the database query to Grower Details objects.
   *
   *
   *
   */
  public class CustomerSearchAgreementCodeMappingQuery extends MappingSqlQuery {


    private static final String CUSTOMER_SEARCH_MAPPING_QUERY = " Select a.acct_id,sap.alias_id SAP_ID, "
            +" napd.napd_id NAPD_ID,gln.alias_id GLN_ID,  NVL(fflx_approved,'No') fflx_approved, fflx_dlr,NVL(fmgr_approved,'No') fmgr_approved"
            +" from  agcc.acct_mv a, agcc.acct_xref_mv sap,agcc.acct_napd_dnml napd,agcc.acct_xref_mv gln, "
            +" (select accgfflx.acct_id,DECODE(accgfflx.agreement_code, 'FFLX','Yes','No') fflx_approved,accgfflx.signer_acct_id FFLX_DLR "
            +" FROM agcc.acct_to_agreement_mv accgfflx where accgfflx.agreement_code='FFLX' AND END_DATE >SYSDATE "
            +" and acct_id= ?  ) ag_fflx, (select accgfmgr.acct_id,DECODE(accgfmgr.agreement_code, 'FMGR','Yes','No') fmgr_approved "
            +" FROM agcc.acct_to_agreement_mv accgfmgr where accgfmgr.agreement_code='FMGR' AND END_DATE >SYSDATE and accgfmgr.acct_id= ? "
            +" ) ag_fmgr where a.acct_id=sap.acct_id(+) AND sap.active_flag(+)='Y' "
            +" AND sap.system_type_code(+)='SAP' AND a.acct_id=napd.acct_id(+) "
            +" AND a.acct_id=gln.acct_id(+) AND gln.active_flag(+)='Y' AND gln.system_type_code(+)='GLN' "
            +" AND a.acct_id=ag_fflx.acct_id(+) AND a.acct_id=ag_fmgr.acct_id(+) AND  a.acct_id= ?";


    public CustomerSearchAgreementCodeMappingQuery() {
      super(getDataSource(), CUSTOMER_SEARCH_MAPPING_QUERY);
      super.declareParameter(new SqlParameter("acct_id", Types.INTEGER));
      super.declareParameter(new SqlParameter("acct_id", Types.INTEGER));
      super.declareParameter(new SqlParameter("acct_id", Types.INTEGER));
    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      CustomerIds customerIds = new CustomerIds(rs.getLong("acct_id"), rs.getString("SAP_ID"), rs.getString("NAPD_ID"),
              rs.getString("GLN_ID"));
      GrowerDetails growerDetails = new GrowerDetails();
      growerDetails.setCustomerIds(customerIds);
      growerDetails.setFflxApproved(rs.getString("FFLX_APPROVED"));
      growerDetails.setFmgrApproved(rs.getString("fmgr_approved"));
      growerDetails.setFflxId(rs.getLong("FFLX_DLR"));

      return growerDetails;
    }

  }

  /*
   * 
   */
  private List getCustomerAccounts(GrowerCriteria grower) {
    String customerSearchSql = createCustomerSearchSql(grower);
    CustomerMappingQuery query = new CustomerMappingQuery(customerSearchSql);
    List customers = query.execute();
    return customers;
  }

  private String createCustomerSearchSql(GrowerCriteria grower) {
    StringBuffer sb = new StringBuffer();

    sb.append("SELECT DISTINCT acct_id PURCHASER_ACCT_ID,ACCT_NAME,MAILING_STATE_CODE," + "DECODE (license_status,"
            + "'PERM INJ', 'Unauthorized'," + "'UNLICENSED', 'Unlicensed'," + "'NOT AUTH', 'Unauthorized',"
            + "'LICENSED', 'Licensed'," + "'LICENSED EXCEPT COTTON', 'Licensed Except Cotton') AS license_status,"
            + "MAILING_ADDR_LINE_1,MAILING_CITY,MAILING_ZIP,COUNTY_DESCR,CONTACT_PHONE_NUMBER,"
            + "CONTACT_LAST_NAME, CONTACT_FIRST_NAME FROM RR_GROWERS");
    addWhereClauseDemograpicSearch(sb, grower);
    return sb.toString();
  }

  private void addWhereClauseDemograpicSearch(StringBuffer sb, GrowerCriteria grower) {
    boolean firstClause = true;

    if (grower.getAccountId() != 0) {
      firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
      sb.append(" ACCT_ID = ").append(grower.getAccountId());
    }
    if (StringUtils.isNotEmpty(grower.getAccountName())) {
      firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
      sb.append(" UPPER(TRIM(ACCT_NAME)) LIKE '");
      formatInputParameterForWhereClause(sb, grower.getAccountName());
    }
    if (StringUtils.isNotEmpty(grower.getFName())) {
      firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
      sb.append(" UPPER(CONTACT_FIRST_NAME) LIKE '");
      formatInputParameterForWhereClause(sb, grower.getFName());
    }
    if (StringUtils.isNotEmpty(grower.getLName())) {
      firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
      sb.append(" UPPER(CONTACT_LAST_NAME) LIKE '");
      formatInputParameterForWhereClause(sb, grower.getLName());
    }
    if (StringUtils.isNotEmpty(grower.getPhone())) {
      firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
      sb.append(" CONTACT_PHONE_NUMBER = '").append(grower.getPhone()).append("'");
    }
    AddressInformation address = grower.getAddressInformation();
    if (address != null) {
      if (StringUtils.isNotEmpty(address.getCity())) {
        firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
        sb.append(" UPPER(MAILING_CITY) LIKE '");
        formatInputParameterForWhereClause(sb, address.getCity());
      }
      if (StringUtils.isNotEmpty(address.getCounty())) {
        firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
        sb.append(" UPPER(COUNTY_DESCR) LIKE '");
        formatInputParameterForWhereClause(sb, address.getCounty());
      }
      if (StringUtils.isNotEmpty(address.getState())) {
        firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
        sb.append(" UPPER(MAILING_STATE_CODE) = '");
        formatInputParameterForWhereClause(sb, address.getState());
      }
      if (StringUtils.isNotEmpty(address.getZip())) {
        firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
        sb.append(" MAILING_ZIP = '").append(address.getZip()).append("'");
      }
    }
    if (StringUtils.isNotEmpty(grower.getStatus()) && "Licensed".equalsIgnoreCase(grower.getStatus())) {
      firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
      sb.append(" UPPER(LICENSE_STATUS) IN ('LICENSED','LICENSED EXCEPT COTTON')");
    }

    firstClause = addWhereOrAndClauseToQuery(sb, firstClause);
    sb.append(" ROWNUM <=").append(grower.getMaxResults() != 0 ? grower.getMaxResults() : 1000);
  }

  private boolean addWhereOrAndClauseToQuery(StringBuffer sb, boolean firstClause) {
    if (!firstClause) {
      sb.append(" AND");
    } else {
      sb.append(" WHERE");
    }
    firstClause = false;
    return firstClause;
  }

  private void formatInputParameterForWhereClause(StringBuffer sb, String parameter) {
    sb.append(StringEscapeUtils.escapeSql(parameter).trim().toUpperCase()).append("'");
  }

  private List getCustomerZoneDetails(String seedyear, long accountId) {
    return new CustomerZoneMappingQuery().execute(new Object[]{seedyear, new Long(accountId)});
  }

  private List getCustomerResults(long accountId) {
    CustomerSearchMappingQuery query = new CustomerSearchMappingQuery();
    Object[] queryParms = new Object[] { new Long(accountId) };
    return query.execute(queryParms);
  }


  private List getCustomerResultsWithAgreementCode(long accountId) {
    CustomerSearchAgreementCodeMappingQuery query = new CustomerSearchAgreementCodeMappingQuery();
    Object[] queryParms = new Object[] { new Long(accountId),new Long(accountId),new Long(accountId) };

    return query.execute(queryParms);
  }

  /**
   * @see com.monsanto.ag.cf.dao.CustomerSearchDao#getCustomerDetails(com.monsanto.ag.cf.domain.GrowerCriteria, String)
   */
  @Override
  public List getCustomerDetails(GrowerCriteria criteria, String seedYear) {
    List customers = new ArrayList();
    customers = getCustomerAccounts(criteria);
    long accountId;
    for (Iterator custIter = customers.iterator(); custIter.hasNext();) {
      GrowerDetails customer = (GrowerDetails) custIter.next();
      accountId = customer.getCustomerIds().getAccountId();

      List searchResults = getCustomerResults(accountId);
      if (searchResults != null && searchResults.size() > 0) {
        GrowerDetails customerPartial = (GrowerDetails) (searchResults.get(0));
        customer.setCustomerIds(customerPartial.getCustomerIds());
        customer.setFflxCode(customerPartial.getFflxCode());
        customer.setFflxId(customerPartial.getFflxId());

        List zones = getCustomerZoneDetails(seedYear, accountId);
        customer.setZoneInformation(zones);

        customers.set(customers.indexOf(customer), customer);
      }

    }
    return customers;
  }

  /**
   * @see com.monsanto.ag.cf.dao.CustomerSearchDao#getCustomerDetailsWithAgreementCode(com.monsanto.ag.cf.domain.GrowerCriteria, String))
   */
  @Override
  public List getCustomerDetailsWithAgreementCode(GrowerCriteria criteria, String seedYear) {
    List customers = new ArrayList();
    customers = getCustomerAccounts(criteria);
    long accountId;

    for (int index=0; index < customers.size(); index++) {
      GrowerDetails customer = (GrowerDetails)customers.get(index);
      accountId = customer.getCustomerIds().getAccountId();

      List searchResults = getCustomerResultsWithAgreementCode(accountId);

      if (searchResults != null && searchResults.size() > 0) {
        GrowerDetails customerPartial = (GrowerDetails) (searchResults.get(0));
        customer.setCustomerIds(customerPartial.getCustomerIds());
        customer.setFflxApproved(customerPartial.getFflxApproved());
        customer.setFmgrApproved(customerPartial.getFmgrApproved());
        customer.setFflxId(customerPartial.getFflxId());

        List zones = getCustomerZoneDetails(seedYear, accountId);
        customer.setZoneInformation(zones);
      }

    }

    return customers;
  }


  /*
   * 
   */
  private List getCustomerAccounts(String GrowerIds) {
    String customerSearchSql = createCustomerSearchSql(GrowerIds);
    CustomerMappingQueryV2 query = new CustomerMappingQueryV2(customerSearchSql);
    List customers = query.execute();
    return customers;
  }
  private String createCustomerSearchSql(String GrowerIds) {
    StringBuffer sb = new StringBuffer();
    sb.append("SELECT DISTINCT acct_id PURCHASER_ACCT_ID,ACCT_NAME,MAILING_STATE_CODE," + "DECODE (license_status,"
            + "'PERM INJ', 'Unauthorized'," + "'UNLICENSED', 'Unlicensed'," + "'NOT AUTH', 'Unauthorized',"
            + "'LICENSED', 'Licensed'," + "'LICENSED EXCEPT COTTON', 'Licensed Except Cotton') AS license_status,"
            + "MAILING_ADDR_LINE_1,MAILING_CITY,MAILING_ZIP,COUNTY_DESCR,CONTACT_PHONE_NUMBER,"
            + "CONTACT_LAST_NAME, CONTACT_FIRST_NAME FROM RR_GROWERS  WHERE ACCT_ID IN ( "+ GrowerIds+" )");

    return sb.toString();
  }

  /**
   * @see com.monsanto.ag.cf.dao.CustomerSearchDao#getCustomerDetailsWithAgreementCode(com.monsanto.ag.cf.domain.GrowerCriteria, String)
   */
  @Override
  public List getCustomerDetailsWithGrowerIds(String GrowerIds, String seedYear)
  {

    List customers = getCustomerAccounts(GrowerIds);
    long accountId;
    for (Iterator custIter = customers.iterator(); custIter.hasNext();) {
      GrowerDetails customer = (GrowerDetails) custIter.next();
      accountId = customer.getCustomerIds().getAccountId();

      List searchResults = getCustomerResultsWithAgreementCode(accountId);

      if (searchResults != null && searchResults.size() > 0) {

        Iterator allCustomers = searchResults.iterator();
        while (allCustomers.hasNext())
        {

          GrowerDetails customerPartial = (GrowerDetails) allCustomers.next();

          customer.setCustomerIds(customerPartial.getCustomerIds());
          customer.setFflxApproved(customerPartial.getFflxApproved());
          customer.setFmgrApproved(customerPartial.getFmgrApproved());
          customer.setFflxId(customerPartial.getFflxId());

          List zones = getCustomerZoneDetails(seedYear, accountId);
          customer.setZoneInformation(zones);
          customers.set(customers.indexOf(customer), customer);
        }
      }

    }
    return customers;
  }


  public class CustomerMappingQueryV2 extends MappingSqlQuery {

    public CustomerMappingQueryV2(String sql) {
      super(getDataSource(), sql);
    }

    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      GrowerDetails growerDetails = new GrowerDetails(rs.getString("ACCT_NAME"), rs.getString("CONTACT_FIRST_NAME"), rs
              .getString("CONTACT_LAST_NAME"), new CustomerIds(rs.getLong("PURCHASER_ACCT_ID"), "", null, null), rs
              .getString("LICENSE_STATUS"), new AddressInformation(rs.getString("MAILING_ADDR_LINE_1"), rs
              .getString("MAILING_CITY"), rs.getString("MAILING_STATE_CODE"), rs.getString("MAILING_ZIP"), rs
              .getString("COUNTY_DESCR")), null, 0, null, rs.getString("CONTACT_PHONE_NUMBER"), null);
      return growerDetails;
    }

  }

}
