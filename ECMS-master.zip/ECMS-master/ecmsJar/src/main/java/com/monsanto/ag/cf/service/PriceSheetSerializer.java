package com.monsanto.ag.cf.service;

import java.util.Date;
import java.util.List;

import com.monsanto.ag.security.IdentityPrincipal;


import com.monsanto.ag.xml.XmlStream;

public interface PriceSheetSerializer {

  XmlStream buildPriceSheetDocument(String conversationId, IdentityPrincipal idPrincipal, Date fromDate, List domainItems);

}
