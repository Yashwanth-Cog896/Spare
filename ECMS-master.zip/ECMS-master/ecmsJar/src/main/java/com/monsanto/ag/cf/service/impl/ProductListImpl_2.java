package com.monsanto.ag.cf.service.impl;

import java.util.Date;

import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.ProductDao;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * POJO implementation of the Product List service.
 * 
 * @author Gareth Davies
 * @version $Id: ProductListImpl_2.java,v 1.4 2008-08-12 18:02:51 dddoni Exp $
 */
public class ProductListImpl_2 extends ServiceProxySupport implements
    SecureService, Identifiable {

  private static final String XPATH_FROM_PARTNER_INFO = "/ecms:ProductExtractRequest/cidx:Header/cidx:From/cidx:PartnerInformation";
  private static final String XPATH_INPUT_PARMS_PARENT = "/ecms:ProductExtractRequest/ecms:ProductExtractRequestBody/ecms:ProductExtractRequestDetails";
  private static final String XPATH_UPDATE_HEADER = "/agiis:AGIISProductUpdate/cidx:Header";
  private static final String XPATH_UPDATE_COMPANY_INFO = "/agiis:AGIISProductUpdate/agiis:Body/agiis:AGIISProductUpdateDetails/agiis:CompanyInformation";

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private ProductDao productListDao = null;
  
  private boolean validationRequired = true;
  
  public boolean isValidationRequired() {
	return validationRequired;
}

public void setValidationRequired(boolean validationRequired) {
	this.validationRequired = validationRequired;
}

/**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "PRODLIST2";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject)
      throws ServiceException {
    String conversationId = Utilities.generateConversationId();

    Logger.log(new LoggableInfo(
        "Processing product list request with conversation Id: "
            + conversationId));
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(
        xmlDocumentBuilder);
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    updateRequestDocument(inputDocument, conversationId, idPrincipal);

    Document outPutDocument = delegateRequestToProductUpdateService2(inputDocument);

    XmlDocument outputXmlDocument = xmlDocumentBuilder.createXmlDocument(outPutDocument);
    outputXmlDocument = buildProductExtractDocument(outputXmlDocument);
    
    ServiceOutput output = new ServiceOutput();
    output.getXmlChunks().addChunk(outputXmlDocument);
    output.setConversationId(conversationId);
    return output;
  }

  private void updateRequestDocument(XmlDocument inputDocument,
      String conversationId, IdentityPrincipal idPrincipal) {
    String message = "Enriching ProductExtractRequest document with conversation attributes - ProductList2";
    Logger.log(new DebugLogEvent(message));

    updateConversationIdWithGeneratedValue(inputDocument, conversationId);
    updateFromPartnerNameWithAccountName(inputDocument, idPrincipal);
    updateFromPartnerIdWithEBusinessId(inputDocument, idPrincipal);
    updateProductAttributeWithChunkSize(inputDocument);
  }

  private void updateConversationIdWithGeneratedValue(
      XmlDocument inputDocument, String conversationId) {
    String xpathConversationId = inputXmlMessageInformer.getXpathConversationId();
    XmlElement conversationIdElement = inputDocument
        .selectElementByXPath(xpathConversationId);

    conversationIdElement.setText(conversationId);
  }

  private void updateFromPartnerNameWithAccountName(XmlDocument inputDocument,
      IdentityPrincipal idPrincipal) {
    String xpath = XPATH_FROM_PARTNER_INFO + "/cidx:PartnerName";
    XmlElement partnerName = inputDocument.selectElementByXPath(xpath);

    String fromPartnerName = idPrincipal.getAccountName();
    if (StringUtils.isNotEmpty(fromPartnerName)) {
      partnerName.setText(fromPartnerName);
    }
  }

  private void updateFromPartnerIdWithEBusinessId(XmlDocument inputDocument,
      IdentityPrincipal idPrincipal) {
    String xpath = XPATH_FROM_PARTNER_INFO + "/cidx:PartnerIdentifier";
    XmlElement partnerIdNode = inputDocument.selectElementByXPath(xpath);

    String eBusinessId = idPrincipal.getEBusinessId();
    if (StringUtils.isNotEmpty(eBusinessId)) {
      partnerIdNode.setText(eBusinessId);
    }
  }

  private void updateProductAttributeWithChunkSize(XmlDocument inputDocument) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
    if (chunkSize > 0) {
      String xpath = XPATH_INPUT_PARMS_PARENT + "/ecms:ProductFeatures";
      XmlElement inputParmsRoot = inputDocument.selectElementByXPath(xpath);
      if (XmlElement.NULL.equals(inputParmsRoot)) {
        XmlElement inputParmsParent = inputDocument
            .selectElementByXPath(XPATH_INPUT_PARMS_PARENT);
        inputParmsRoot = inputParmsParent.addChildElement("ProductFeatures");
      }

      XmlElement inputParm = inputParmsRoot.addChildElement("ProductAttribute");
      XmlElement chunkSizeParmName = inputParm.addChildElement(
          "ProductAttributeName", "ChunkSize");
      chunkSizeParmName.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, "AGIISProductDirectory");
      inputParm.addChildElement("ProductAttributeValue", String
          .valueOf(chunkSize));
    }
  }

  
  private Document delegateRequestToProductUpdateService2(XmlDocument inputDocument) {

	  AGIISProductUpdateController_2 aGIISProductUpdateController = new AGIISProductUpdateController_2(productListDao);
	  Document outPutDocument =  aGIISProductUpdateController.runImplementation(inputDocument);
	  
	  return outPutDocument;
	  }

  private XmlDocument buildProductExtractDocument(XmlDocument productUpdateDoc) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement(
        "AGIISProductExtract", XmlNamespace.NAMESPACE_AGIIS_20, "2.0");

    addHeaderNodeFromUpdateDocument(rootElement, productUpdateDoc);

    XmlElement bodyNode = rootElement.addChildElement("Body");
    XmlElement detailsNode = bodyNode
        .addChildElement("AGIISProductExtractDetails");

    addExtractInformationNode(detailsNode);
    addCompanyInformationNodeFromUpdateDocument(detailsNode, productUpdateDoc);

    return outputDocument;
  }

  private void addHeaderNodeFromUpdateDocument(XmlElement rootNode,
      XmlDocument productUpdateDoc) {
    XmlElement updateHeaderNode = productUpdateDoc
        .selectElementByXPath(XPATH_UPDATE_HEADER);
    rootNode.importElement(updateHeaderNode, true);
  }

  private void addExtractInformationNode(XmlElement detailsNode) {
    XmlElement extractInfoNode = detailsNode
        .addChildElement("ExtractInformation");
    extractInfoNode.addChildElement("Name", "DUMMY");
    extractInfoNode.addChildElement("StartDate", XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()));
    extractInfoNode.addChildElement("Frequency", "Annually");
    extractInfoNode.addChildElement("Type", "Custom");
  }

  private void addCompanyInformationNodeFromUpdateDocument(
      XmlElement detailsNode, XmlDocument productUpdateDoc) {
    XmlElement updateCompanyInfoNode = productUpdateDoc
        .selectElementByXPath(XPATH_UPDATE_COMPANY_INFO);
    detailsNode.importElement(updateCompanyInfoNode, true);
  }  

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

public ProductDao getProductListDao() {
	return productListDao;
}

public void setProductListDao(ProductDao productListDao) {
	this.productListDao = productListDao;
}

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2008/07/29 22:10:00  dddoni
 * Product List Implementor  calls DAO ,not ECG service.
 *
 * Revision 1.2  2008/06/19 12:55:20  gjkell
 * GOA II
 *
 * Revision 1.1  2008/06/13 15:52:16  gjkell
 * GOA II
 *
 * Revision 1.33  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.32  2006/07/13 18:50:46  caggarw
 * Refactored to use CidxConstants to help with changing the Agency attributes for SAPId and AccountId
 *
 * Revision 1.31  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.30  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.29  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 * Revision 1.28 2005/11/22 22:40:09 caggarw
 * changes for storing EBID as a String within the web-services, as it may
 * contain alpha numeric characters
 * 
 * Revision 1.27 2005/11/21 20:40:50 caggarw changes for STT DX. Change the
 * AccountId/AccountName in the request only if it isn't empty/0 Revision 1.26
 * 2005/11/15 17:28:04 ggdavi Output XML chunks are now identified via the
 * unqualified XPath of their parent element Revision 1.25 2005/11/08 21:00:31
 * ggdavi Updated after adding XmlStream (and StAX implementation) to the
 * com.monsanto.ag.util package and refactoring the ServiceInput and
 * ServiceOutput classes to expose both XmlStream and XmlDocument objects
 * 
 * Revision 1.24 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.23 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.22 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.21 2005/08/24 16:48:34 ggdavi Added logging statements Revision
 * 1.20 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure method
 * signature to accept a ServiceInput argument instead of a List and return a
 * ServiceOutput object instead of a List Revision 1.19 2005/08/09 20:44:59
 * ggdavi Added schema-required Agency attribute for ChunkSize
 * ProductAttributeName element Revision 1.18 2005/08/06 20:28:52 ggdavi Added
 * updateProductAttributeWithChunkSize method to correctly add the chunk size
 * from the XmlMessageInformer to the ECGServices request XML document;
 * refactored to clarify request XML document manipulation Revision 1.17
 * 2005/08/05 21:21:38 ggdavi The ServiceInput.setResponseChunkNodeName method
 * is only called if a positive chunk size exists on the XmlMessageInformer
 * 
 * Revision 1.16 2005/08/05 18:45:26 ggdavi SoaClient.call method now returns a
 * ServiceOutput object, which contains multiple chunked output documents;
 * removed deprecated executeSecure method based on DOM documents Revision 1.14
 * 2005/07/21 22:14:11 ggdavi Added com.monsanto.ag.util.IdTranslator object to
 * translate numeric Ids (such as Account, EBusiness and SAP Ids) back and forth
 * between their numeric and zero-padded textual representations Revision 1.13
 * 2005/07/21 14:48:57 ggdavi Fleshed out and refactored com.monsanto.ag.util to
 * make more object-oriented, in that most functionality has been pushed to the
 * XmlDocument and XmlElement objects Revision 1.12 2005/07/06 22:17:13 ggdavi
 * Removed extraneous to do comments
 * 
 * Revision 1.11 2005/07/06 21:12:41 ggdavi Added xmlDocumentBuilder field, used
 * to build output XML documents, and xmlDocumentProcessor field, used to
 * manipulate input document Revision 1.10 2005/06/30 20:24:20 ggdavi Use
 * node.getOwnerDocument instead of helper.getDocument(node) Revision 1.9
 * 2005/06/22 22:35:04 ggdavi Reflected changes in NamespacedDocumentHelper and
 * subclass addChildElement method usage Revision 1.8 2005/06/22 17:17:49 ggdavi
 * Moved importAndAddNode and updateNodeTextValue methods to Utilities Revision
 * 1.7 2005/06/20 17:12:36 ggdavi Moved Entity and Identifiable back to
 * ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.6 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.5 2005/06/17 22:06:28 ggdavi Added updateRequestDocumentFromHeader
 * to add converationId and current user identifiers to request document's From
 * header element Revision 1.4 2005/06/17 18:20:45 ggdavi Refactored
 * ag.cf.security to move common objects to ag.security; moved
 * CidxDocumentHelper from ag.cf.service.impl to ag.util
 * 
 * Revision 1.3 2005/06/10 14:55:43 ggdavi Added balance of unit test methods
 * Revision 1.2 2005/06/09 21:07:42 ggdavi Initial implementatation Revision 1.1
 * 2005/06/08 17:33:53 ggdavi Initial version
 * 
 */