/*
 * AgreementStatusSerializerImpl was created on Apr 18, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.monsanto.ag.cf.domain.AgreementDetails;
import com.monsanto.ag.cf.service.AgreementStatusSerializer;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * Serialize the XML documents for the agreement Status service implementation.
 * 
 * @author Chetna Aggarwal
 * @version $Id: AgreementStatusSerializerImpl.java,v 1.6 2008-05-27 16:02:59 na1000app-ec Exp $
 */
public class AgreementStatusSerializerImpl implements AgreementStatusSerializer {

  private static final XmlNamespace NAMESPACE_AGREEMENT_RESPONSE = new XmlNamespace("ecms",
      "urn:ecms:schema:agreement:response:1:0");

  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  /**
   * @see com.monsanto.ag.cf.service.AgreementStatusSerializer#buildAgreementStatusDocument(java.lang.String,
   *      com.monsanto.ag.security.IdentityPrincipal, java.util.List)
   */
  public XmlStream buildAgreementStatusDocument(String conversationId, IdentityPrincipal idPrincipal, List domainItems) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement root = outputDocument.addRootElement("AgreementStatusResponse", NAMESPACE_AGREEMENT_RESPONSE, "1.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    helper.addHeaderNode(root, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    addBodyNode(domainItems, root);

    return outputDocument;
  }

  private void addBodyNode(List domainItems, XmlElement root) {
    XmlElement body = root.addChildElement("AgreementStatusResponseBody");

    XmlElement details = body.addChildElement("AgreementStatusResponseDetails");

    for (Iterator itDetails = domainItems.iterator(); itDetails.hasNext();) {
      AgreementDetails partnerDetail = (AgreementDetails) itDetails.next();
      addPartnerDetailNodeInformation(details, partnerDetail);
    }

  }

  private void addPartnerDetailNodeInformation(XmlElement details, AgreementDetails partnerDetail) {
    XmlElement partner = details.addChildElement("PartnerDetail");
    String requestedPartnerIdentifier = partnerDetail.getRejectedAccountId() !=null ? partnerDetail.getRejectedAccountId():String.valueOf(partnerDetail
        .getAccountId());
    XmlElement requestedPartnerId = partner.addChildElement("RequestedPartnerIdentifier", requestedPartnerIdentifier);
    requestedPartnerId.setAttribute("Agency", "AssignedBySeller");

    if (StringUtils.isNotEmpty(partnerDetail.getErrorMessage())) {
      XmlElement errorResponse = partner.addChildElement("ErrorResponse");
      errorResponse.addChildElement("ErrorMessage", partnerDetail.getErrorMessage());
      errorResponse.addChildElement("ErrorDescription", partnerDetail.getErrorDecription());
    } else {
      XmlElement detail = partner.addChildElement("Detail");
      XmlElement partnerIdentifier = detail.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier", String
          .valueOf(partnerDetail.getAccountId()));
      partnerIdentifier.setAttribute("Agency", "AssignedBySeller");
 
      if (StringUtils.isNotEmpty(partnerDetail.getProprietaryCode())){
        XmlElement addAttribute = detail.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier", partnerDetail.getProprietaryCode());
        addAttribute.setAttribute("Agency", "AssignedByBuyer");
      }
      
      XmlElement agreement = detail.addChildElement("Agreement");
      agreement.addChildElement("AgreementMessageType", "license");
      agreement.addChildElement("AgreementName", "MTA1");
      String responseLicenseStatus = (partnerDetail.getLicenseStatus() != null)?partnerDetail.getLicenseStatus():"Unlicensed";
      agreement.addChildElement("AgreementStatus", responseLicenseStatus);

      if(StringUtils.isNotBlank(partnerDetail.getCornZone())) {
      XmlElement zone1 = detail.addChildElement("Zone");
      zone1.addChildElement("ZoneID", partnerDetail.getCornZonecode());
      zone1.addChildElement("ZoneType", "Current Corn Rootworm Zone");
      zone1.addChildElement("ZoneName", partnerDetail.getCornZone());
      }

      if(StringUtils.isNotBlank(partnerDetail.getAlfalfaZone())) {
        XmlElement zone2 = detail.addChildElement("Zone");
      zone2.addChildElement("ZoneID", partnerDetail.getAlfalfaZoneCode());
      zone2.addChildElement("ZoneType", "Current Alfalfa Zone");
      zone2.addChildElement("ZoneName", partnerDetail.getAlfalfaZone());
      }
      
      if(StringUtils.isNotBlank(partnerDetail.getAccountName())) {
        detail.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerName", partnerDetail.getAccountName());
      }
      
      if((StringUtils.isNotBlank(partnerDetail.getFirstName()) || (StringUtils.isNotBlank(partnerDetail.getLastName())))) {
        detail.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "ContactName", partnerDetail.getFirstName() + " " + partnerDetail.getLastName());
      }
    }
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}
