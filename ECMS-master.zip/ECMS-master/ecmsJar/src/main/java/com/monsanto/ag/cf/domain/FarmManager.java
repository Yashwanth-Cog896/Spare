/*
 * FarmManager was created on May 24, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;


/**
 * Represents the information inside the FarmManagerList.
 * <p>
 * 
 * @author CAGGARW
 * @version $Id: FarmManager.java,v 1.8 2005-09-28 19:12:55 ggdavi Exp $
 */
public class FarmManager implements Serializable {

  private static final String DEFAULT_COUNTRY = "USA";
  private static final Map ECMS_ROLES;
  
  static {
    Map roles = new HashMap();
    roles.put("FP", "Prepay");
    roles.put("FN", "NonPrepay");
    ECMS_ROLES = Collections.unmodifiableMap(roles);
  }

  private String name;
  private long accountId;
  private long sapId;
  private String street;
  private String city;
  private String state;
  private String zip;
  private String irdRole;
  private boolean active;

  public FarmManager() {
  }

  public FarmManager(String name, long accountId, long sapId, String street,
      String city, String state, String zip, String irdRole,
      boolean active) {
    this.name = name;
    this.accountId = accountId;
    this.sapId = sapId;
    this.street = street;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.active = active;
    this.irdRole = irdRole;
  }

  public String getName() {
    return name;
  }

  public long getAccountId() {
    return accountId;
  }

  public long getSapId() {
    return sapId;
  }

  public String getStreet() {
    return street;
  }

  public String getCity() {
    return city;
  }

  public String getState() {
    return state;
  }

  public String getZip() {
    return zip;
  }

  public String getCountry() {
    return DEFAULT_COUNTRY;
  }

  public boolean isActive() {
    return active;
  }

  public String getIrdRole() {
    return irdRole;
  }

  public String getRole() {
    return (String) ECMS_ROLES.get(irdRole);
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof FarmManager)) {
      return false;
    }
    FarmManager rhs = (FarmManager) obj;
    return new EqualsBuilder().append(name, rhs.getName()).append(accountId,
        rhs.getAccountId()).append(sapId, rhs.getSapId()).append(street,
        rhs.getStreet()).append(city, rhs.getCity()).append(state,
        rhs.getState()).append(zip, rhs.getZip()).append(getCountry(),
        rhs.getCountry()).append(
        active, rhs.isActive()).append(irdRole, rhs.getIrdRole()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 19).append(name).append(accountId).append(
        sapId).append(street).append(city).append(state).append(zip).append(
        getCountry()).append(active).append(irdRole)
        .toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).append("name",
        name).append("accountId", accountId).append("sapId", sapId).append(
        "street", street).append("city", city).append("zip", zip).append(
        "country", getCountry()).append(
        "active", active).append("irdRole", irdRole).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.7  2005/08/26 16:10:56  ggdavi
 * Moved the Identifiable and Entity classes to the ag.util package and the ServiceAdvice class to the ag.soa package for better dependency management
 *
 * Revision 1.6  2005/06/20 17:12:36  ggdavi
 * Moved Entity and Identifiable back to ag.cf.domain from ag.domain (sorry about that...)
 *
 * Revision 1.5  2005/06/20 16:40:27  ggdavi
 * Moved Entity and Identifiable from ag.cf.domain to ag.domain
 *
 * Revision 1.4  2005/05/26 20:35:21  ggdavi
 * Removed unnecessary imports
 *
 * Revision 1.3  2005/05/26 20:02:43  caggarw
 * removed field for role from FarmManager object
 *
 * Revision 1.2  2005/05/25 18:17:25  caggarw
 * added toString, equals and hashCode methods
 * Revision 1.1 2005/05/24 22:14:51 caggarw
 * Represents the information inside the FarmManagerList.
 */