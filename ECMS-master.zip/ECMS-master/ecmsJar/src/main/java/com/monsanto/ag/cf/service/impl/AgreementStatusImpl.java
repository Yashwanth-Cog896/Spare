/*
 * AgreementStatusImpl was created on Apr 18, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.AgreementStatusDao;
import com.monsanto.ag.cf.domain.AgreementDetails;
import com.monsanto.ag.cf.service.AgreementStatusSerializer;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamListAppender;


import com.monsanto.ag.security.IdentityPrincipal;

/**
 * POJO Implementation of the AgreementStatus web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: AgreementStatusImpl.java,v 1.5 2008-08-06 22:49:39 mkuchip Exp $
 */
public class AgreementStatusImpl implements SecureService, Identifiable {

  private static final String XPATH_PARTNER_DETAILS = "/ecms:AgreementStatusRequest/ecms:AgreementStatusRequestBody/ecms:AgreementDetails/ecms:PartnerDetails";

  private AgreementStatusDao agreementStatusDao;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private AgreementStatusSerializer agreementStatusSerializer;
  private List rejects;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "AGRMT";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {

    ServiceOutput output = new ServiceOutput();
    rejects = new ArrayList();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);
    Logger.log(new LoggableInfo("Processing agreement status request with conversation Id: " + conversationId));
    IdentityPrincipal idPrincipal = getIdentityPrincipalOfCurrentUser(subject);

    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
    List requestAccountDetails = getRequestAccountDetailsFromInputDocument(inputDocument);
    List responseAccountDetails = getAgreementDetailsForRequestAccounts(requestAccountDetails);

    addRejectsToResponse(responseAccountDetails);

    XmlChunks outputXmlChunks = buildAgreementStatusDocument(conversationId, idPrincipal, responseAccountDetails);
    output.getXmlChunks().addChunks(outputXmlChunks);

    return output;

  }
  
  public boolean isValidationRequired() {
    return true;
  }

  private void addRejectsToResponse(List responseAccountDetails) {
    for (Iterator rejectAccounts = rejects.iterator(); rejectAccounts.hasNext();) {
      AgreementDetails rejectedAccounts = (AgreementDetails) rejectAccounts.next();
      responseAccountDetails.add(rejectedAccounts);
    }
  }

  private List getAgreementDetailsForRequestAccounts(List requestAccountDetails) {
    List responseAccountDetails = new ArrayList();
    AgreementDetails requestAccount;
    List agreementDetails;
    for (Iterator requestAccounts = requestAccountDetails.iterator(); requestAccounts.hasNext();) {
      requestAccount = (AgreementDetails) requestAccounts.next();
      agreementDetails = agreementStatusDao.getAgreementStatusDetails(requestAccount.getAccountId());
      
      for (Iterator agItr = agreementDetails.iterator(); agItr.hasNext();) {
        AgreementDetails accountAgreementDetails = (AgreementDetails) agItr.next();
        addPropCodeFromRequest(requestAccount, accountAgreementDetails);
        modifyAgreementDetailsforStateMismatch(requestAccount, accountAgreementDetails);
        responseAccountDetails.add(accountAgreementDetails);
      }
    }
    return responseAccountDetails;
  }

  private void addPropCodeFromRequest(AgreementDetails requestAccount, 
      AgreementDetails accountAgreementDetails){
 
    String propCode = requestAccount.getProprietaryCode();
    accountAgreementDetails.setPropCode(propCode);    
  }
  
  private void modifyAgreementDetailsforStateMismatch(AgreementDetails requestAccount,
      AgreementDetails accountAgreementDetails) {
      
    if (!StringUtils.equalsIgnoreCase(requestAccount.getState(), accountAgreementDetails.getState())) {
      accountAgreementDetails.setErrorMessage("State-AccountId mismatch");
      accountAgreementDetails
          .setErrorDecription("State information for Requesting identifier does not match our system records");
    }
  }

  private List getRequestAccountDetailsFromInputDocument(XmlDocument inputDocument) {
    List requestAccountDetails = new ArrayList();
    List partnerDetails = inputDocument.selectElementsByXPath(XPATH_PARTNER_DETAILS);
    String accountId="";
    String propCode="";
    String state="";

    for (Iterator partnerNode = partnerDetails.iterator(); partnerNode.hasNext();) {
      XmlElement partnerDetail = (XmlElement) partnerNode.next();
      List partnerDetailList = partnerDetail.getChildren();

      for (Iterator iter = partnerDetailList.iterator(); iter.hasNext();) {
        XmlElement element = (XmlElement) iter.next();
 
        if("PartnerIdentifier".equals(element.getUnqualifiedName())) {
          String attributeValue = element.getAttributeValue("Agency");
          if (attributeValue.equals(CidxConstants.ACCOUNT_ID_AGENCY)){
            accountId = element.getText();
          }
          if (attributeValue.equals(CidxConstants.PROPRIETARY_CODE)){
            propCode = element.getText();
          }
        }
        if ("StateOrProvince".equals(element.getUnqualifiedName())){
          state = element.getText();
        }
      }
     
      long accountIdValue;
      try {
        accountIdValue = Long.parseLong(accountId.trim());
      } catch (NumberFormatException nfe) {
        AgreementDetails agreementDetailsReject = new AgreementDetails();
        agreementDetailsReject.setRejectedAccountId(accountId);
        agreementDetailsReject.setErrorMessage("Invalid AccountId format");
        agreementDetailsReject.setErrorDecription("Cannot process Agreement Status request for this AccountId");
        rejects.add((agreementDetailsReject));
        continue;
      }
      AgreementDetails requestDetails = new AgreementDetails(accountIdValue, state, propCode);
      requestAccountDetails.add(requestDetails);
    }

    return requestAccountDetails;
  }

  private XmlChunks buildAgreementStatusDocument(final String conversationId, final IdentityPrincipal idPrincipal,
      List agreementDetails) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(agreementDetails, chunkSize,
        new XmlStreamListAppender() {

          public XmlStream buildXmlStream(List domainItems) {
            return agreementStatusSerializer.buildAgreementStatusDocument(conversationId, idPrincipal, domainItems);
          }

        });

    return outputXmlChunks;
  }

  private IdentityPrincipal getIdentityPrincipalOfCurrentUser(Subject subject) {
    IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(identityPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    }
    return identityPrincipal;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public AgreementStatusDao getAgreementStatusDao() {
    return agreementStatusDao;
  }

  public XmlDocumentBuilder getXmlDocumentBuilder() {
    return xmlDocumentBuilder;
  }

  public void setAgreementStatusDao(AgreementStatusDao agreementStatusDao) {
    this.agreementStatusDao = agreementStatusDao;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setAgreementStatusSerializer(AgreementStatusSerializer agreementStatusSerializer) {
    this.agreementStatusSerializer = agreementStatusSerializer;
  }

}
