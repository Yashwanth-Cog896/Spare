/*
 * ProductLightSerializer was created on Oct 1, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service;

import java.util.List;

import com.monsanto.ag.cf.domain.AGIISSubscriberResults;
import com.monsanto.ag.xml.XmlStream;

/**
 * @author Chetna Aggarwal
 * @version $Id: ProductLightSerializer.java,v 1.2 2008-06-20 18:30:35 rwspeh Exp $
 */
public interface ProductLightSerializer {

  public XmlStream buildProductLightDocument(List domainItems);
  public XmlStream buildProductLightDocument(List domainItems, AGIISSubscriberResults agiisSubscriberResults);

}
