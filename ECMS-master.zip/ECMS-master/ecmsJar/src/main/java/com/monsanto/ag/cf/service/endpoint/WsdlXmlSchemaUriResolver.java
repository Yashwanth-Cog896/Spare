/*
 * WsdlXmlSchemaUriResolver was created on Jul 31, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.endpoint;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.wsdl.Definition;
import javax.wsdl.Import;
import javax.wsdl.Types;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaImport;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;

/**
 * Resolves the XML schema URI by matching the default namespace URI of the XML
 * document with the namespace URI used in the WSDL to import the XML schema
 * document.
 * <p>
 * If no WSDL exists at the specified location, no URI will be returned.
 * 
 * @author Chetna Aggarwal
 * @version $Id: WsdlXmlSchemaUriResolver.java,v 1.1 2006/05/08 14:19:30 caggarw
 *          Exp $
 */
public class WsdlXmlSchemaUriResolver implements XmlSchemaUriResolver {

  private WSDLFactory factory;
  private Map schemaUriCache;

  public WsdlXmlSchemaUriResolver() {
    try {
      factory = WSDLFactory.newInstance();
    } catch (WSDLException e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException(e.getMessage());
    }

    schemaUriCache = new Hashtable();
  }

  /**
   * @see com.monsanto.ag.cf.soapint.XmlSchemaUriResolver#resolve(java.lang.String,
   *      java.lang.String)
   */
  public String resolve(String schemaRegistrySpec, String namespaceUri) throws ServiceException {
    String xmlSchemaUri = getXmlSchemaUriFromCache(schemaRegistrySpec, namespaceUri);

    if (StringUtils.isNotBlank(schemaRegistrySpec) && StringUtils.isBlank(xmlSchemaUri)) {
      xmlSchemaUri = getXmlSchemaUriFromRegistry(schemaRegistrySpec, namespaceUri);
    }

    return xmlSchemaUri;
  }

  private String getXmlSchemaUriFromCache(String schemaRegistrySpec, String namespaceUri) {
    String xmlSchemaUri = null;

    if (StringUtils.isNotBlank(schemaRegistrySpec) && StringUtils.isNotBlank(namespaceUri)) {
      Map schemaRegistry = (Map) schemaUriCache.get(schemaRegistrySpec);
      if (schemaRegistry != null) {
        xmlSchemaUri = (String) schemaRegistry.get(namespaceUri);
        Logger.log(new DebugLogEvent("XML Schema URI cache value for namespace '" + namespaceUri + "' is: "
            + xmlSchemaUri));
      }
    }

    return xmlSchemaUri;
  }

  private void addXmlSchemaUriToCache(String schemaRegistrySpec, String namespaceUri, String xmlSchemaUri) {
    if (StringUtils.isNotEmpty(xmlSchemaUri)) {
      Map schemaRegistry = (Map) schemaUriCache.get(schemaRegistrySpec);
      if (schemaRegistry == null) {
        schemaRegistry = new Hashtable();
      }

      schemaRegistry.put(namespaceUri, xmlSchemaUri);
      schemaUriCache.put(schemaRegistrySpec, schemaRegistry);
    }
  }

  private String getXmlSchemaUriFromRegistry(String schemaRegistrySpec, String namespaceUri) {
    String xmlSchemaUri = null;

    try {
      Logger.log(new LoggableInfo("Retrieving XML Schema URI for namespace '" + namespaceUri + "' from WSDL at "
          + schemaRegistrySpec));
      Definition wsdlDef = getWsdlFromRegistrySpec(schemaRegistrySpec);
      xmlSchemaUri = getXmlSchemaUriFromWsdl(wsdlDef, namespaceUri);

      Logger.log(new DebugLogEvent("XML Schema URI retrieved from WSDL for namespace '" + namespaceUri + "' is: "
          + xmlSchemaUri));
      addXmlSchemaUriToCache(schemaRegistrySpec, namespaceUri, xmlSchemaUri);
    } catch (WSDLException e) {
      Logger.log(new LoggableWarning(e.getMessage()));
      throw new ServiceException("The WSDL document defining XML schemas for this service could not be read", e);
    }

    return xmlSchemaUri;
  }

  private Definition getWsdlFromRegistrySpec(String schemaRegistrySpec) throws WSDLException {
    WSDLReader reader = getWsdlReader();
    Definition wsdlDef = reader.readWSDL(null, schemaRegistrySpec);
    return wsdlDef;
  }

  private WSDLReader getWsdlReader() {
    WSDLReader reader = factory.newWSDLReader();
    reader.setFeature("javax.wsdl.verbose", false);
    return reader;
  }

  private String getXmlSchemaUriFromWsdl(Definition wsdlDef, String namespaceUri) {
    String xmlSchemaUri = null;

    Types types = getTypesFromConcreteOrAbstractWsdl(wsdlDef);
    List schemaImports = getSchemaImportsForNamespace(types, namespaceUri);
    if (isNotEmptyList(schemaImports)) {
      SchemaImport schemaImport = (SchemaImport) schemaImports.get(0);
      xmlSchemaUri = schemaImport.getReferencedSchema().getDocumentBaseURI();
    }

    return xmlSchemaUri;
  }

  private boolean isNotEmptyList(List list) {
    return list != null && !list.isEmpty();
  }

  private Types getTypesFromConcreteOrAbstractWsdl(Definition concreteWsdlDef) {
    Types types = concreteWsdlDef.getTypes();

    if (types == null) {
      Definition abstractWsdlDef = getImportedAbstractedWsdl(concreteWsdlDef);
      if (abstractWsdlDef != null) {
        types = abstractWsdlDef.getTypes();
      }
    }

    return types;
  }

  private Definition getImportedAbstractedWsdl(Definition concreteWsdlDef) {
    Definition abstractWsdlDef = null;

    List importList = getAbstractWsdlImportInSameNamespace(concreteWsdlDef);
    if (importList == null) {
      importList = getAbstractWsdlImportInOtherNamespace(concreteWsdlDef);
    }

    if (isNotEmptyList(importList)) {
      Import importItem = (Import) importList.get(0);
      abstractWsdlDef = importItem.getDefinition();
    }

    return abstractWsdlDef;
  }

  private List getAbstractWsdlImportInSameNamespace(Definition concreteWsdlDef) {
    String wsdlNamespaceUri = concreteWsdlDef.getTargetNamespace();
    List importList = concreteWsdlDef.getImports(wsdlNamespaceUri);
    return importList;
  }

  private List getAbstractWsdlImportInOtherNamespace(Definition concreteWsdlDef) {
    List importList = null;

    Map imports = concreteWsdlDef.getImports();
    if (imports != null && !imports.isEmpty()) {
      for (Iterator itImport = imports.values().iterator(); itImport.hasNext();) {
        importList = (List) itImport.next();
        break;
      }
    }

    return importList;
  }

  private List getSchemaImportsForNamespace(Types types, String namespaceUri) {
    List schemaImports = null;

    if (types != null && types.getExtensibilityElements() != null) {
      for (Iterator itExtElem = types.getExtensibilityElements().iterator(); itExtElem.hasNext();) {
        ExtensibilityElement element = (ExtensibilityElement) itExtElem.next();

        if (element instanceof Schema) {
          Schema schema = (Schema) element;
          Map schemaImportMap = schema.getImports();
          schemaImports = (List) schemaImportMap.get(namespaceUri);

          if (!isNotEmptyList(schemaImports)) {
            throw new ServiceException("The WSDL document for this service defines no XML schema for namespace '"
                + namespaceUri + "'");
          }
          break;
        }
      }
    }

    return schemaImports;
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.1 2006/05/08 14:19:30
 * caggarw moved files from package jaxrpc into a common package called endpoint
 * 
 * Revision 1.1 2005/11/09 18:45:44 ggdavi Initial version
 * 
 * Revision 1.1 2005/11/07 20:41:03 ggdavi Moved from soapint.axis to soapint,
 * since shared functionality with XFire implementation Revision 1.1 2005/10/27
 * 20:37:30 caggarw Replaced DocumentValidators with SchemaUriResolvers Revision
 * 1.1 2005/10/20 21:47:05 caggarw Initial Version
 * 
 * Revision 1.1 2005/09/06 21:09:07 ggdavi XmlSchemaUriResolver is now an
 * interface with two implementations, WsdlXmlSchemaUriResolver (the original
 * class, renamed) and AlwaysTrueDocumentValidator (essentially a Null Object,
 * skipping validation). JaxRpcEndpoint pulls the implementation from the Spring
 * application context and passes the current MessageContext as an argument to
 * the validateXmlDocument method along with the XmlDocument. Revision 1.2
 * 2005/08/11 16:31:16 ggdavi Refactored and replaced the checked
 * FileNotFoundException with a generic ServiceException Revision 1.1 2005/08/02
 * 20:57:37 ggdavi Modified service interfaces, implementations and advice to
 * support message/document chunking
 * 
 */