package com.monsanto.ag.cf.dao.jdbc;

import java.util.Date;
import java.util.Set;

public interface OtherSeedBrandsDao {
	public abstract String getAgiisIdForDealer(long dealerId);
	public abstract Set getOtherSeedBrandsForDealer(long dealerId);
	public Set getOtherSeedBrandsForDealerSinceLastDXDate(final long dealerId, final Date lastDxDate);	
}