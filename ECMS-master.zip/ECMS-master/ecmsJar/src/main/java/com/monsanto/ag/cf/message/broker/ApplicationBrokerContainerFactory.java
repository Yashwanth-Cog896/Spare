/*
 * ApplicationBrokerContainerFactory was created on May 5, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.broker;

import org.activemq.broker.BrokerContainer;
import org.activemq.broker.BrokerContainerFactory;
import org.activemq.broker.BrokerContext;
import org.activemq.spring.ActiveMQBeanFactory;
import org.activemq.spring.SpringBrokerContainerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceEditor;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;

/**
 * Extends ActiveMQ's SpringBrokerContainerFactory by providing the Spring bean
 * factory in which the ActiveMQ ConnectionFactory is created.
 * <p>
 * This is necessary in order to reuse any of the beans defined in other bean
 * factory configuration files. Specifically, it allows the embedded broker to
 * reuse the <code>dataSource</code> and <code>lobHandler</code> beans for
 * JDBC persistence of messages, so we don't have to duplicate connectivity
 * information.
 * 
 * @author Gareth Davies
 * @version $Id: ApplicationBrokerContainerFactory.java,v 1.1 2005/06/30
 *          17:43:26 ggdavi Exp $
 */
public class ApplicationBrokerContainerFactory extends
    SpringBrokerContainerFactory {

  private BeanFactory parentBeanFactory;

  public ApplicationBrokerContainerFactory(Resource resource,
      BeanFactory beanFactory) {
    super(resource);
    this.parentBeanFactory = beanFactory;
  }

  /**
   * Factory method for creating a broker container factory.
   * 
   * @param resourceName
   *          Name of the ActiveMQ broker configuration file (using Spring's
   *          resource syntax)
   * @param beanFactory
   *          Bean factory in which the ConnectionFactory was created
   * @return Instance of this class
   */
  public static BrokerContainerFactory newFactory(String resourceName,
      BeanFactory beanFactory) {
    ResourceEditor editor = new ResourceEditor();
    editor.setAsText(resourceName);
    Resource resource = (Resource) editor.getValue();
    if (resource == null) {
      throw new IllegalArgumentException("Could not convert '" + resourceName
          + "' into a Spring Resource");
    }
    Logger
        .log(new LoggableInfo(
            "Creating ActiveMQ broker container factory: ApplicationBrokerContainerFactory"));
    return new ApplicationBrokerContainerFactory(resource, beanFactory);
  }

  /**
   * Creates the ActiveMQ BrokerContainer by including the Spring BeanFactory
   * definitions with the ActiveMQ-specific BeanFactory.
   * 
   * @see org.activemq.broker.BrokerContainerFactory#createBrokerContainer(java.lang.String,
   *      org.activemq.broker.BrokerContext)
   */
  public BrokerContainer createBrokerContainer(String brokerName,
      BrokerContext context) {
    Logger.log(new LoggableInfo(
        "Loading ActiveMQ broker container from configuration: "
            + getResource()));
    ActiveMQBeanFactory beanFactory = new ActiveMQBeanFactory(brokerName,
        getResource(), parentBeanFactory);
    return (BrokerContainer) beanFactory.getBean("broker");
  }
}

/*
 * $Log: not supported by cvs2svn $ Revision 1.1 2005/06/30
 * 17:43:26 ggdavi Moved ag.aop, ag.config and ag.message packages under the
 * ag.cf package
 * 
 * Revision 1.1 2005/05/05 19:01:12 ggdavi Initial version
 * 
 */