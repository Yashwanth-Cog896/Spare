package com.monsanto.ag.cf.service.impl;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.jms.core.MessagePostProcessor;

import com.monsanto.ag.cf.domain.Conversation;

/**
 * JMS Message post processor that adds the conversation Id, the authenticated
 * user's id and the relevant dealer account Id to the message.
 * 
 * @author Gareth Davies
 * @version $Id: ConversationMessagePostProcessor.java,v 1.2 2005-07-19 17:39:54 ggdavi Exp $
 */
public class ConversationMessagePostProcessor implements MessagePostProcessor {

  private Conversation conversation;

  public ConversationMessagePostProcessor(Conversation conversation) {
    this.conversation = conversation;
  }

  public Message postProcessMessage(Message message) throws JMSException {
    message.setJMSCorrelationID(conversation.getConversationId());

    message.setStringProperty(Conversation.USERID_PROPERTY_KEY, conversation
        .getUserId());
    message.setLongProperty(Conversation.ACCOUNTID_PROPERTY_KEY, conversation
        .getAccountId());

    return message;
  }
}