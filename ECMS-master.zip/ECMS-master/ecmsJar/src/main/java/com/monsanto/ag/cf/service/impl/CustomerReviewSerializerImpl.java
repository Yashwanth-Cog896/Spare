/*
 * CustomerReviewSerializerImpl was created on Aug 15, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.ag.cf.domain.ZoneInformation;
import com.monsanto.ag.cf.service.CustomerReviewSerializer;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.*;
import org.apache.commons.lang.StringUtils;

import java.util.Iterator;
import java.util.List;

/**
 * Serializer to create the Customer Review Response Document.
 *
 * @author Chetna Aggarwal
 * @version $Id: CustomerReviewSerializerImpl.java,v 1.1 2007/08/16 19:42:31
 *          caggarw Exp $
 */
public class CustomerReviewSerializerImpl implements CustomerReviewSerializer {

	private XmlDocumentBuilder xmlDocumentBuilder;

	private IdTranslator idTranslator;

	/**
	 /* @see com.monsanto.ag.cf.service.CustomerReviewSerializer#buildCustomerReviewDocument(java.lang.String,
	 / *      com.monsanto.ag.security.IdentityPrincipal, java.util.List)
	 */
	public XmlStream buildCustomerReviewDocument(String conversationId,
												 IdentityPrincipal identityPrincipal, List domainItems,
												 long accountId) {
		XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
		XmlElement rootElement = outputDocument.addRootElement(
				"GrowerIDResponse",
				CustomerReviewImpl.NAMESPACE_CUST_REVIEW_RESPONSE, "1.0");

		CidxDocumentHelper helper = new CidxDocumentHelper(
				XmlNamespace.NAMESPACE_CIDX_40);
		helper.addHeaderNode(rootElement, conversationId, identityPrincipal
				.getMessageParticipant(), idTranslator);

		addBodyNode(rootElement, domainItems, accountId);

		return outputDocument;
	}

	private void addBodyNode(XmlElement rootElement, List domainItems,
							 long accountId) {
		XmlElement bodyNode = rootElement
				.addChildElement("GrowerIDResponseBody");
		XmlElement detailsNode = bodyNode
				.addChildElement("GrowerIDResponseDetails");
		for (Iterator iter = domainItems.iterator(); iter.hasNext();) {
			GrowerDetails grower = (GrowerDetails) iter.next();
			XmlElement transactionNode = detailsNode
					.addChildElement("TransactionDetails");
			XmlElement refInfoNode = transactionNode.addChildElement(
					XmlNamespace.NAMESPACE_CIDX_40, "ReferenceInformation");
			refInfoNode.setAttribute("ReferenceType", "InvoiceNumber");
			XmlElement refDocRefNode = refInfoNode.addChildElement(
					XmlNamespace.NAMESPACE_CIDX_40, "DocumentReference");
			refDocRefNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
					"DocumentIdentifier", grower.getInvoiceNumber());

			if (grower.getCustomerIds() != null) {
				XmlElement partnerId = transactionNode.addChildElement(
						XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier",
						Long.toString(grower.getCustomerIds().getAccountId()));
				partnerId.setAttribute(
						CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
						CidxConstants.ACCOUNT_ID_AGENCY);

				XmlElement SapId = transactionNode.addChildElement(
						XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier",
						grower.getCustomerIds().getSapId());
				SapId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
						CidxConstants.SAP_ID_AGENCY);

				if (StringUtils.isNotBlank(grower.getCustomerIds().getNapdId())) {
					XmlElement napId = transactionNode.addChildElement(
							XmlNamespace.NAMESPACE_CIDX_40,
							"PartnerIdentifier", grower.getCustomerIds()
									.getNapdId());
					napId.setAttribute(
							CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
							CidxConstants.NAPD_ID_AGENCY);
				}

				if (StringUtils.isNotBlank(grower.getCustomerIds().getGlnId())) {
					XmlElement glnId = transactionNode.addChildElement(
							XmlNamespace.NAMESPACE_CIDX_40,
							"PartnerIdentifier", grower.getCustomerIds()
									.getGlnId());
					glnId.setAttribute(
							CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, "Other");
				}

			}

			transactionNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
					"PartnerName", grower.getAccountName());

			AddressInformation address = grower.getAddressInformation();
			if (address != null) {
				if (StringUtils.isNotBlank(address.getStreet())) {
					transactionNode.addChildElement(
							XmlNamespace.NAMESPACE_CIDX_40, "AddressLine",
							address.getStreet());
				}
				transactionNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
						"CityName", address.getCity());
				transactionNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
						"StateOrProvince", address.getState());
				transactionNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
						"PostalCode", address.getZip());
				if (StringUtils.isNotBlank(address.getCounty())) {
					transactionNode.addChildElement("PostalCounty", address
							.getCounty());
				}
			}
			if (grower.getFflxId() == accountId) {
				transactionNode.addChildElement("FarmFlexApproved", "Yes");
			} else {
				transactionNode.addChildElement("FarmFlexApproved", "No");
			}
			if (StringUtils.isNotBlank(grower.getLicenseStatus())) {
				transactionNode.addChildElement("EntityStatus", grower
						.getLicenseStatus());
			}
			List zones = grower.getZoneInformation();
			for (Iterator zoneItr = zones.iterator(); zoneItr.hasNext();) {
				ZoneInformation zone = (ZoneInformation) zoneItr.next();
				if (zone != null) {
					XmlElement zoneNode = transactionNode.addChildElement("AgronomicZone");
					if (StringUtils.isNotBlank(zone.getZoneCode())) {
						zoneNode.addChildElement("ZoneCode", zone.getZoneCode());
					}
					if (StringUtils.isNotBlank(zone.getAZRDescr())) {
						zoneNode.addChildElement("Crop", zone.getAZRDescr());
					}
					if (StringUtils.isNotBlank(zone.getCropCode())) {
						zoneNode.addChildElement("CropCode", zone.getCropCode());
					}
					if (StringUtils.isNotBlank(zone.getZoneDescr())) {
						zoneNode.addChildElement("ZoneDescription", zone.getZoneDescr());
					}
					if (StringUtils.isNotBlank(zone.getZoneYear())) {
						zoneNode.addChildElement("SeedYear", zone.getZoneYear());
					}
				}
			}
			List mirIds = grower.getMirIds();

			if (mirIds != null && mirIds.size() > 0) {
				XmlElement mirNode = transactionNode
						.addChildElement("MIRValues");
				XmlElement mirIdNode;
				for (Iterator iterator = mirIds.iterator(); iterator.hasNext();) {
					Long mirId = (Long) iterator.next();
					mirIdNode = mirNode.addChildElement(
							XmlNamespace.NAMESPACE_CIDX_40,
							"PartnerIdentifier", mirId);
					mirIdNode.setAttribute(
							CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
							CidxConstants.ACCOUNT_ID_AGENCY);
				}
			}

			transactionNode.addChildElement("MaxEffDate", XmlDateTimeUtil
					.formatDateAsXmlUTC(grower.getMaxEffDate()));

		}
	}

	public void setIdTranslator(IdTranslator idTranslator) {
		this.idTranslator = idTranslator;
	}

	public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
		this.xmlDocumentBuilder = xmlDocumentBuilder;
	}

}
