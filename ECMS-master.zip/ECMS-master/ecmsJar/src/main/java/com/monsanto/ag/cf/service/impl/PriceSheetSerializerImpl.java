package com.monsanto.ag.cf.service.impl;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.monsanto.ag.cf.domain.PriceSheet;
import com.monsanto.ag.cf.service.PriceSheetSerializer;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;

import com.monsanto.ag.security.IdentityPrincipal;


public class PriceSheetSerializerImpl implements PriceSheetSerializer {

  public static final XmlNamespace NAMESPACE_PRICE_RESPONSE = new XmlNamespace("ecms",
      "urn:ecms:schema:price:response:1:0");

  private static final String LEGAL_JARGON = "All products and seed sizes subject to availability. Please check current Product Availability List. Prices subject to change without notice. Limitations on Warranty, Damages, and Remedies: Seed and crop performance depends upon many conditions beyond the control of Seed Co. The following warranties, and disclaimers and limitations as to warranties, damages and remedies are (except void where prohibited by law) terms and conditions of sale for this seed and CANNOT BE MODIFIED OR AMENDED AT ANY TIME EXCEPT BY A WRITING SPECIFICALLY AGREEING TO DO SO. Purchaser so acknowledges by acceptance of seed. If these terms and conditions are unacceptable, purchaser must return the unopened bag of seed immediately. WARRANTY AND WARRANTY DISCLAIMER: The SOLE AND EXCLUSIVE WARRANTY of Seed Co is that the seeds are as described on bag and tag within recognized tolerances. Seed Co GIVES NO OTHER WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED, NOR ANY WARRANTY OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE. LIMITATIONS ON DAMAGES AND REMEDY: Purchasers SOLE AND EXCLUSIVE REMEDY for any loss from any breach of warranty, negligence or any other cause, SHALL BE LIMITED TO THE REFUND OF THE SEED PURCHASE PRICE. SEED CO SHALL NOT BE LIABLE for any incidental or consequential damages. Furthermore, as a CONDITION TO ANY LIABILTY of Seed Co, purchaser shall inform Seed Co in writing immediately (and no more than 30 days) after any claim against Seed Co first becomes apparent, and shall cooperate fully in Seed Co's investigation of such claim.";

  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  public XmlStream buildPriceSheetDocument(String conversationId, IdentityPrincipal idPrincipal, Date fromDate,
      List priceSheetList) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement root = outputDocument.addRootElement("PriceSheet", NAMESPACE_PRICE_RESPONSE, "1.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    helper.addHeaderNode(root, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    addBodyNode(priceSheetList, root, fromDate);

    return outputDocument;
  }

  private void addBodyNode(List priceSheetList, XmlElement root, Date fromDate) {
    XmlElement body = root.addChildElement("PriceSheetBody");

    XmlElement properties = body.addChildElement("PriceSheetProperties");
    addPropertiesNodeInformation(properties);

    XmlElement partners = body.addChildElement("PriceSheetPartners");
    addPartnersNodeInformation(partners);

    XmlElement details = body.addChildElement("PriceSheetDetails");
    int lineNumberCount = 0;
    for (Iterator itPriceSheet = priceSheetList.iterator(); itPriceSheet.hasNext();) {
      lineNumberCount++;
      PriceSheet priceSheet = (PriceSheet) itPriceSheet.next();
      addDetailsNodeinformation(details, priceSheet, lineNumberCount, fromDate);
    }
  }

  private void addPartnersNodeInformation(XmlElement partners) {
    XmlElement seller = partners.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "Seller");
    XmlElement partnerInformation = seller.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerInformation");
    partnerInformation.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerName", "MONSANTO AGRICULTURAL CO");
    XmlElement partnerId = partnerInformation.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier",
        "0062668030000");
    partnerId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.EBID_AGENCY);

  }

  private void addPropertiesNodeInformation(XmlElement properties) {
    XmlElement currency = properties.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "CurrencyCode", "USD");
    currency.setAttribute("Domain", "ISO-4217");
    XmlElement language = properties.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "LanguageCode", "eng");
    language.setAttribute("Domain", "ISO-639-2T");
    XmlElement specialInstructions = properties.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "SpecialInstructions",
        LEGAL_JARGON);
    specialInstructions.setAttribute("InstructionType", "RequiredNotice");
  }

  private void addDetailsNodeinformation(XmlElement details, PriceSheet priceSheet, int lineNumberCount,
      Date fromDateTime) {
    XmlElement productLineItem = details.addChildElement("PriceSheetProductLineItem");
    String action = getActionForProductLineItem(fromDateTime, priceSheet);
    productLineItem.setAttribute("Action", action);
    productLineItem.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "LineNumber", String.valueOf(lineNumberCount));
    XmlElement productInformation = productLineItem.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
        "ProductInformation");
    XmlElement productIdentification = productInformation.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
        "ProductIdentification");
    XmlElement productIdentifier = productIdentification.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
        "ProductIdentifier", priceSheet.getUpcCode());
    productIdentifier.setAttribute("Agency", "UPC");

    addPriceSheetPriceDataToProductLineItem(priceSheet, productLineItem);

    if (StringUtils.isNotBlank(priceSheet.getRoundupWholeSaleDiscount())) {
      addPriceSheetPriceDataForRoundupWholesaleDiscountToProductLineItem(priceSheet, productLineItem);
    }
    if (StringUtils.isNotBlank(priceSheet.getRoundupTraitFee())) {
      addPriceSheetAllowanceChargeToProductLineItem(priceSheet, productLineItem);
    }

  }

  private String getActionForProductLineItem(Date fromDateTime, PriceSheet priceSheet) {
    Date rowEntryDate = priceSheet.getEntryDate();
    if (fromDateTime == null || (rowEntryDate != null && rowEntryDate.after(fromDateTime))) {
      return "Add";
    }
    return "Replace";
  }

  private void addPriceSheetPriceDataToProductLineItem(PriceSheet priceSheet, XmlElement productLineItem) {
    XmlElement priceData = addPriceSheetPriceData(priceSheet, productLineItem);

    addListPriceToPriceSheetPriceData(priceSheet, priceData, priceSheet.getNetRate(), "NetPrice");

  }

  private void addPriceSheetPriceDataForRoundupWholesaleDiscountToProductLineItem(PriceSheet priceSheet,
      XmlElement productLineItem) {
    XmlElement priceData = addPriceSheetPriceData(priceSheet, productLineItem);

    addListPriceToPriceSheetPriceData(priceSheet, priceData, priceSheet.getRoundupWholeSaleDiscount(), "GrossPrice");
  }

  private XmlElement addPriceSheetPriceData(PriceSheet priceSheet, XmlElement productLineItem) {
    XmlElement priceData = productLineItem.addChildElement("PriceSheetPriceData");
    XmlElement priceApplicabilityCriteria = priceData.addChildElement("PriceApplicabilityCriteria");
    addOrderFeaturesToPriceApplicabilityCriteria(priceSheet, priceApplicabilityCriteria);
    XmlElement geographicFeatures = priceApplicabilityCriteria.addChildElement("GeographicFeatures");
    XmlElement location = geographicFeatures.addChildElement("Location");
    location.setAttribute("LocationType", "Destination");
    //location.addChildElement("ZoneID", priceSheet.getPriceRegion());
    location.addChildElement("ZoneID", priceSheet.getZoneCode());
    return priceData;
  }

  private void addPriceSheetAllowanceChargeToProductLineItem(PriceSheet priceSheet, XmlElement productLineItem) {
    XmlElement allowanceChargeList = productLineItem.addChildElement("AllowanceChargeList");
    XmlElement allowanceCharge = allowanceChargeList.addChildElement("AllowanceCharge");
    allowanceCharge.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "AllowancesChargeIndicator", "Charge");
    allowanceCharge.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "AllowanceChargeType", "Debit");
    XmlElement allowanceChargeCode = allowanceCharge.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
        "AllowancesChargeCode", "G580");
    allowanceChargeCode.setAttribute("Domain", "ANSI-ASC-X12-1300");
    allowanceCharge
        .addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "AllowancesChargeDescription", "Technology Royalty");
    addAllowanceChargeAmount(priceSheet, allowanceCharge);
  }

  private void addAllowanceChargeAmount(PriceSheet priceSheet, XmlElement allowanceCharge) {
    XmlElement allowanceChargeAmount = allowanceCharge.addChildElement("AllowanceChargeAmount");
    addPricingPerUnit(priceSheet, priceSheet.getRoundupTraitFee(), allowanceChargeAmount);
  }

  private void addOrderFeaturesToPriceApplicabilityCriteria(PriceSheet priceSheet, XmlElement priceApplicabilityCriteria) {
    XmlElement orderFeatures = priceApplicabilityCriteria.addChildElement("OrderFeatures");
    orderFeatures.setAttribute("OrderScope", "LineItem");
    XmlElement priceSheetEffectiveDate = orderFeatures.addChildElement("PriceSheetEffectiveDate");
    priceSheetEffectiveDate.setAttribute("PriceSheetDateType", "OrderDate");
    XmlElement dateTimeInformation = priceSheetEffectiveDate.addChildElement(XmlNamespace.NAMESPACE_CIDX_40,
        "DateTimeInformation");
    XmlElement dateTime = dateTimeInformation.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "DateTime",
        XmlDateTimeUtil.formatDateAsXmlUTC(priceSheet.getModifydate()));
    dateTime.setAttribute("DateTimeQualifier", "On");
  }

  private void addListPriceToPriceSheetPriceData(PriceSheet priceSheet, XmlElement priceData, String rate,
      String priceType) {
    XmlElement listPrice = priceData.addChildElement("ListPrice");
    XmlElement pricing = listPrice.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "Pricing");
    pricing.setAttribute("PriceType", priceType);
    addPricingPerUnit(priceSheet, rate, pricing);
  }

  private void addPricingPerUnit(PriceSheet priceSheet, String rate, XmlElement pricingRootNode) {
    XmlElement pricingPerUnit = pricingRootNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PricingPerUnit");
    XmlElement monetaryAmount = pricingPerUnit.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "MonetaryAmount");
    monetaryAmount.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "MonetaryValue", rate);

    XmlElement currencyCode = monetaryAmount.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "CurrencyCode", "USD");
    currencyCode.setAttribute("Domain", "ISO-4217");

    XmlElement priceBasis = pricingPerUnit.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PriceBasis");
    XmlElement measurement = priceBasis.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "Measurement");
    measurement.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "MeasurementValue", "1");

    XmlElement unitOfMeasureCode = measurement.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "UnitOfMeasureCode",
        priceSheet.getUomId());
    unitOfMeasureCode.setAttribute("Domain", "UN-Rec-20");
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}
