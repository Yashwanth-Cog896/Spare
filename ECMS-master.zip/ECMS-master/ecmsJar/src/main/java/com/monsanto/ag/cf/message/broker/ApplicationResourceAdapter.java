/*
 * ApplicationResourceAdapter was created on Jul 12, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.message.broker;

import java.util.Map;

import javax.jms.JMSException;
import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.spi.ActivationSpec;
import javax.resource.spi.ResourceAdapter;
import javax.resource.spi.endpoint.MessageEndpointFactory;

import org.activemq.ActiveMQConnection;
import org.activemq.ActiveMQConnectionFactory;
import org.activemq.broker.Broker;
import org.activemq.broker.BrokerContainer;
import org.activemq.ra.ActiveMQActivationSpec;
import org.activemq.ra.ActiveMQAsfEndpointWorker;
import org.activemq.ra.ActiveMQBaseEndpointWorker;
import org.activemq.ra.ActiveMQEndpointActivationKey;
import org.activemq.ra.ActiveMQPollingEndpointWorker;
import org.activemq.ra.ActiveMQResourceAdapter;
import org.activemq.service.DeadLetterPolicy;
import org.activemq.service.RedeliveryPolicy;
import org.springframework.aop.TargetSource;
import org.springframework.aop.framework.Advised;

import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;

/**
 * Extends ActiveMQResourceAdapter by injecting the
 * {@link com.monsanto.ag.cf.message.broker.ApplicationConnectionFactory ApplicationConnectionFactory}
 * object and overriding the makeConnection method to use it instead of creating
 * a new ActiveMQConnectionFactory. This ensures that the correct memory manager
 * settings are used and that duplicate consumers are not created.
 * <p>
 * The endpointActivation method has also been modified slightly to create an
 * alternative type of endpoint worker object, namely a
 * {@link com.monsanto.ag.cf.message.broker.BrokerPolicyAwareEndpointWorker BrokerPolicyAwareEndpointWorker}.
 * This worker is aware of any RedeliveryPolicy and DeadLetterPolicy defined for
 * the ActiveMQ broker and acts accordingly.
 * <p>
 * There also appears to be some problems when this object is advised using
 * CGLIB, since section 5.3.3 of the JCA spec requires verification that the
 * resource adapter instance associated with the activation spec matches this
 * object - since the comparison is made based on memory reference and the
 * activationSpec.getResourceAdapter() can return a reference to the CGLIB
 * proxy, the comparison can fail. The private getActivationSpecResourceAdapter
 * method extracts the advised object from the proxy if necessary before the
 * comparison.
 * <p>
 * Finally, because the endpointWorkers instance field is private in the
 * superclass and we have to recreate it here, we copy the endpointDeactivation
 * and stop methods from the superclass.
 * 
 * @author Gareth Davies
 * @version $Id: ApplicationResourceAdapter.java,v 1.1 2005/07/12 18:31:58
 *          ggdavi Exp $
 */
public class ApplicationResourceAdapter extends ActiveMQResourceAdapter {

  private static final String ASF_ENDPOINT_WORKER_TYPE = "asf";
  private static final String POLLING_ENDPOINT_WORKER_TYPE = "polling";
  private static final String BROKER_POLICY_AWARE_ENDPOINT_WORKER_TYPE = "broker-policy-aware";

  private Map endpointWorkers = new ConcurrentHashMap();
  private ApplicationConnectionFactory connectionFactory;

  public ActiveMQConnection makeConnection(ActiveMQActivationSpec activationSpec)
      throws JMSException {
    ActiveMQConnectionFactory connectionFactory = getConnectionFactory();
    String userName = defaultValue(activationSpec.getUserName(), getInfo()
        .getUserName());
    String password = defaultValue(activationSpec.getPassword(), getInfo()
        .getPassword());
    ActiveMQConnection physicalConnection = (ActiveMQConnection) connectionFactory
        .createConnection(userName, password);
    if (activationSpec.isDurableSubscription()) {
      physicalConnection.setClientID(activationSpec.getClientId());
    }

    Logger.log(new LoggableInfo("Made ActiveMQConnection with client Id: "
        + physicalConnection.getClientID()));
    return physicalConnection;
  }

  private ApplicationConnectionFactory getConnectionFactory() {
    return connectionFactory;
  }

  public void setConnectionFactory(
      ApplicationConnectionFactory connectionFactory) {
    this.connectionFactory = connectionFactory;
  }

  /**
   * Copied from superclass.
   */
  private String defaultValue(String value, String defaultValue) {
    if (value != null)
      return value;
    return defaultValue;
  }

  /**
   * Copied from superclass.
   * <p>
   * Modified to call the getActivationSpecResourceAdapter method.
   * <p>
   * Modified to optionally create a new BrokerPolicyAwareEndpointWorker.
   * 
   * @see javax.resource.spi.ResourceAdapter#endpointActivation(javax.resource.spi.endpoint.MessageEndpointFactory,
   *      javax.resource.spi.ActivationSpec)
   */
  public void endpointActivation(MessageEndpointFactory endpointFactory,
      ActivationSpec activationSpec) throws ResourceException {

    // spec section 5.3.3
    if (getActivationSpecResourceAdapter(activationSpec) != this) {
      throw new ResourceException(
          "Activation spec not initialized with this ResourceAdapter instance");
    }

    if (activationSpec.getClass().equals(ActiveMQActivationSpec.class)) {
      ActiveMQEndpointActivationKey key = new ActiveMQEndpointActivationKey(
          endpointFactory, (ActiveMQActivationSpec) activationSpec);
      // This is weird.. the same endpoint activated twice.. must be a
      // container error.
      if (endpointWorkers.containsKey(key)) {
        throw new IllegalStateException("Endpoint previously activated");
      }

      ActiveMQBaseEndpointWorker worker;
      if (POLLING_ENDPOINT_WORKER_TYPE.equals(getEndpointWorkerType())) {
        worker = new ActiveMQPollingEndpointWorker(this, key);
      } else if (ASF_ENDPOINT_WORKER_TYPE.equals(getEndpointWorkerType())) {
        worker = new ActiveMQAsfEndpointWorker(this, key);
      } else if (BROKER_POLICY_AWARE_ENDPOINT_WORKER_TYPE
          .equals(getEndpointWorkerType())) {
        worker = new BrokerPolicyAwareEndpointWorker(this, key,
            getRedeliveryPolicy(), getDeadLetterPolicy());
      } else {
        throw new NotSupportedException(
            "That type of EndpointWorkerType is not supported: "
                + getEndpointWorkerType());
      }

      Logger.log(new LoggableInfo("Starting worker for endpoint: " + key));
      endpointWorkers.put(key, worker);
      worker.start();
    } else {
      throw new NotSupportedException(
          "That type of ActicationSpec not supported: "
              + activationSpec.getClass());
    }
  }

  private ResourceAdapter getActivationSpecResourceAdapter(
      ActivationSpec activationSpec) {
    ResourceAdapter resourceAdapter = activationSpec.getResourceAdapter();
    if (this.getClass().equals(resourceAdapter.getClass())) {
      return resourceAdapter;
    } else {
      try {
        Advised aopConnectionFactory = (Advised) resourceAdapter;
        TargetSource targetSource = aopConnectionFactory.getTargetSource();
        return (ResourceAdapter) targetSource.getTarget();
      } catch (Exception e) {
        e.printStackTrace();
        return null;
      }
    }
  }

  private RedeliveryPolicy getRedeliveryPolicy() {
    BrokerContainer brokerContainer = connectionFactory.getBrokerContainer();
    Broker broker = brokerContainer.getBroker();
    return broker.getRedeliveryPolicy();
  }

  private DeadLetterPolicy getDeadLetterPolicy() {
    BrokerContainer brokerContainer = connectionFactory.getBrokerContainer();
    Broker broker = brokerContainer.getBroker();
    return broker.getDeadLetterPolicy();
  }

  /**
   * Copied from superclass because endpointWorkers field is private
   * 
   * @see javax.resource.spi.ResourceAdapter#endpointDeactivation(javax.resource.spi.endpoint.MessageEndpointFactory,
   *      javax.resource.spi.ActivationSpec)
   */
  public void endpointDeactivation(MessageEndpointFactory endpointFactory,
      ActivationSpec activationSpec) {
    if (activationSpec.getClass().equals(ActiveMQActivationSpec.class)) {
      ActiveMQEndpointActivationKey key = new ActiveMQEndpointActivationKey(
          endpointFactory, (ActiveMQActivationSpec) activationSpec);
      ActiveMQBaseEndpointWorker worker = (ActiveMQBaseEndpointWorker) endpointWorkers
          .remove(key);
      if (worker == null) {
        // This is weird.. that endpoint was not activated.. oh well..
        // this method does not throw exceptions so just return.
        Logger.log(new LoggableWarning("Worker for endpoint '" + key
            + "' was never activated"));
        return;
      }
      try {
        Logger.log(new LoggableInfo("Stopping worker for endpoint: " + key));
        worker.stop();
      } catch (InterruptedException e) {
        // We interrupted.. we won't throw an exception but will stop
        // waiting for the worker to stop.. we tried our best.
        // Keep trying to interrupt the thread.
        Logger.log(new LoggableWarning(e.getMessage()));
        Thread.currentThread().interrupt();
      }

    }
  }

  /**
   * Copied from superclass because endpointWorkers field is private
   * 
   * @see javax.resource.spi.ResourceAdapter#stop()
   */
  public void stop() {
    Logger.log(new LoggableInfo("Stopping resource adapter for broker: "
        + connectionFactory.getBrokerName()));
    while (endpointWorkers.size() > 0) {
      ActiveMQEndpointActivationKey key = (ActiveMQEndpointActivationKey) endpointWorkers
          .keySet().iterator().next();
      endpointDeactivation(key.getMessageEndpointFactory(), key
          .getActivationSpec());
    }

    super.stop();
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.6 2005/11/01 15:54:22
 * ggdavi Minor refactorings and additional Javadoc comments Revision 1.5
 * 2005/10/31 22:22:29 ggdavi Improved comments Revision 1.4 2005/10/28 21:04:27
 * ggdavi Modified the endpointActivation method to instantiate a
 * BrokerPolicyAwareEndpointWorker (for RedeliveryPolicy processing) if the
 * appropriate endpointWorkerType field value is set Revision 1.3 2005/07/12
 * 21:20:27 ggdavi connectionFactory field is now injected via a setter method
 * Revision 1.2 2005/07/12 20:03:54 ggdavi Overrode endpointActivation (and
 * endpointDeactivation) to deal with CGLIB proxies of the ResourceAdapter
 * object, as discussed in the javadoc Revision 1.1 2005/07/12 18:31:58 ggdavi
 * Initial version
 * 
 */