/*
 * OutageCheckerAdvice was created on Apr 8, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.outage;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.server.ServiceAdvice;

/**
 * AOP Alliance MethodInterceptor that can be introduced in a chain to check
 * whether or not the invoked service is currently in an outage.
 * <p>
 * TODO Convert to Before advice?
 * 
 * @author ajbaldw
 * @version $Id: OutageCheckerAdvice.java,v 1.12 2006-01-24 18:56:18 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC78
 */
public class OutageCheckerAdvice extends ServiceAdvice implements
    MethodInterceptor {

  private OutageChecker outageChecker;

  /**
   * @see org.aopalliance.intercept.MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
   */
  public Object invoke(MethodInvocation invocation) throws Throwable {
    String serviceId = getServiceId(invocation.getThis());
    Outage outage = outageChecker.checkOutage(serviceId);
    if (outage.isCurrent()) {
      Logger.log(new LoggableInfo("Service " + serviceId + " is in an outage"));
      throw new OutageException(outage);
    } else {
      return invocation.proceed();
    }
  }

  public void setOutageChecker(OutageChecker outageChecker) {
    this.outageChecker = outageChecker;
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.11  2005/08/26 16:10:56  ggdavi
 * Moved the Identifiable and Entity classes to the ag.util package and the ServiceAdvice class to the ag.soa package for better dependency management
 *
 * Revision 1.10  2005/05/31 20:41:23  ggdavi
 * Use SOAP faults instead of a standard error document
 * Revision 1.9 2005/05/17 17:53:23 ggdavi
 * All AOP advice classes targeted at service implementations now extend the
 * ServiceAdvice abstract class Revision 1.8 2005/05/17 16:31:51 ggdavi
 * Extracted ag.util.XmlDateTimeUtil and ag.soa.ErrorDocument from
 * ag.util.Utilities
 * 
 * Revision 1.7 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.6 2005/04/27 11:24:54 ggdavi Removed conversationId parameter from
 * Utilities.buildErrorDocument
 * 
 * Revision 1.5 2005/04/26 21:25:31 ggdavi Added conversationId parameter to the
 * Utilities.buildErrorDocument method
 * 
 * Revision 1.4 2005/04/25 17:37:24 ggdavi Renamed formatDateInXmlFormat to
 * formatDateAsXmlUTC
 * 
 * Revision 1.3 2005/04/20 17:31:09 ggdavi Refactored to cast invocation targets
 * to interfaces instead of calling methods by reflection Revision 1.2
 * 2005/04/15 18:01:43 ggdavi Changed "message" element to "description"
 * 
 * Revision 1.1 2005/04/11 21:45:48 ggdavi Moved from ag.service to ag.cf.outage
 * Revision 1.1 2005/04/08 21:57:26 ajbaldw Initial Version
 *  
 */