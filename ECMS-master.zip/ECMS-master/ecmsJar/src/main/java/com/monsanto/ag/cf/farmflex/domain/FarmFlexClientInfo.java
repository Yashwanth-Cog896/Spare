/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.farmflex.domain;

import com.monsanto.commercial.growercreditlist.domain.ClientInfo;
import com.monsanto.commercial.growercreditlist.util.EnvironmentEnum;

public class FarmFlexClientInfo extends ClientInfo {
    public FarmFlexClientInfo(String partnerId, String partnerName, String partnerIdType, String docIdentifier,
                              EnvironmentEnum environment) {
        setPartnerId(partnerId);
        setPartnerName(partnerName);
        setPartnerIdType(partnerIdType);
        setDocIdentifier(docIdentifier);
        setEnvironment(environment);
    }

    public FarmFlexClientInfo(String partnerId, String partnerName, String partnerIdType, String docIdentifier) {
        this(partnerId, partnerName, partnerIdType, docIdentifier, EnvironmentEnum.DEV);
    }
}
