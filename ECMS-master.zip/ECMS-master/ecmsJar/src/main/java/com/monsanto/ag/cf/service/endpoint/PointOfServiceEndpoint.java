package com.monsanto.ag.cf.service.endpoint;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

import javax.security.auth.Subject;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.POSServlet.BasePOSController;
import com.monsanto.POSServlet.HelpDisplayer;
import com.monsanto.POSServlet.POSServerException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.XMLUtil.ValidationException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.validator.XmlStreamValidator;
import com.monsanto.ag.xml.validator.XmlValidationException;
import com.monsanto.security.LoginBrief;
import com.monsanto.security.LogonFailedException;
import com.monsanto.security.NoLogonInformationException;

import com.monsanto.ag.security.IdentityPrincipal;

public class PointOfServiceEndpoint extends BasePOSController {

  private static final String XML_DOCUMENT_BUILDER_BEAN = "xmlDocumentBuilder";
  private static final String XML_SCHEMA_URI_RESOLVER_BEAN = "xmlSchemaUriResolver";
  private static final String INPUT_VALIDATOR_BEAN = "inputValidator";
  private static final String OUTPUT_VALIDATOR_BEAN = "outputValidator";
  private SecureService service;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private XmlSchemaUriResolver xmlSchemaUriResolver;
  private XmlStreamValidator inputValidator;
  private XmlStreamValidator outputValidator;
  private String wsdlUri;
  private HashMap initParameters;
  private ApplicationContext appContext;
  private String implBeanName;
  private String wsdlSpec;
  private String userIdForInternal;
  private String accountNameForInternal;

  public void runImplementation(UCCHelper helper, Document inputDocument) throws IOException {

    init(helper);
    Logger.log(new DebugLogEvent("Delegating to service implementation: " + implBeanName));
    Subject subject = createSubject();

    try {
      validateDocument(inputDocument, inputValidator);
      Document outputDocument = delegateToServiceImplementation(inputDocument, subject);
      validateDocument(outputDocument, outputValidator);
      helper.writeXMLDocument(outputDocument);

    } catch (XmlValidationException xve) {
      displayAndLogToError(xve, helper);
    } catch (Exception e) {
      displayAndLogToError(e, helper);
    }

  }

  private void init(UCCHelper helper) {
    appContext = (ApplicationContext) helper
        .getContextAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
    initParameters = helper.getInitParameters();
    implBeanName = (String) initParameters.get("implementationBeadId");
    wsdlSpec = (String) initParameters.get("wsdlSpec");
    userIdForInternal = (String) initParameters.get("userId");
    accountNameForInternal = (String) initParameters.get("accountName");
    wsdlUri = getWsdlUri(helper);
    service = (SecureService) appContext.getBean(implBeanName);
    xmlDocumentBuilder = (XmlDocumentBuilder) appContext.getBean(XML_DOCUMENT_BUILDER_BEAN);
    xmlSchemaUriResolver = (XmlSchemaUriResolver) appContext.getBean(XML_SCHEMA_URI_RESOLVER_BEAN);
    inputValidator = (XmlStreamValidator) appContext.getBean(INPUT_VALIDATOR_BEAN);
    outputValidator = (XmlStreamValidator) appContext.getBean(OUTPUT_VALIDATOR_BEAN);
  }

  private String getWsdlUri(UCCHelper helper) {
    String wsdlUri = "";
    if (StringUtils.isNotEmpty(wsdlSpec)) {
      String wsdlPath = StringUtils.substringBefore(helper.requestedURL(), helper.getContextPath()) + helper.getContextPath();
      wsdlUri = wsdlPath + wsdlSpec;      
    }
    return wsdlUri;
  }

  private Subject createSubject() {
    Subject subject = new Subject();
    IdentityPrincipal principal = new IdentityPrincipal(userIdForInternal, 0, "0", accountNameForInternal);
    subject.getPrincipals().add(principal);
    return subject;
  }

  private Document delegateToServiceImplementation(Document inputDocument, Subject subject)
      throws XmlValidationException {
    ServiceInput serviceInput = createServiceInput(inputDocument);

    ServiceOutput serviceOutput = service.executeSecure(serviceInput, subject);

    XmlDocument outputXmlDocument = serviceOutput.getXmlChunks().getXmlDocumentChunk(xmlDocumentBuilder, 0);
    Document outputDocument = outputXmlDocument.getDOMDocument();
    return outputDocument;
  }

  private ServiceInput createServiceInput(Document inputDocument) {
    ServiceInput serviceInput = new ServiceInput();
    XmlDocument xmlDocument = xmlDocumentBuilder.createXmlDocument(inputDocument);
    serviceInput.getXmlChunks().addChunk(xmlDocument);
    return serviceInput;
  }

  private void validateDocument(Document document, XmlStreamValidator validator) throws XmlValidationException {
    XmlDocument xmlDocument = xmlDocumentBuilder.createXmlDocument(document);
    String xmlSchemaUri = getXmlSchemaUri(xmlDocument);
    if (StringUtils.isNotEmpty(xmlSchemaUri)) {
      validator.validate(xmlDocument, xmlSchemaUri);
    }

  }

  private String getXmlSchemaUri(XmlDocument xmlDocument) {
    String xmlSchemaUri = null;

    String namespaceUri = xmlDocument.getDefaultNamespace().getUri();
    xmlSchemaUri = xmlSchemaUriResolver.resolve(wsdlUri, namespaceUri);

    return xmlSchemaUri;
  }

  /**
   * Do <b>not </b> attempt to validate against a schema, since that should have
   * already been done in the client. Besides, the
   * {@link DOMUtil#newDocument(InputStream, String) DOMUtil.newDocument}method
   * apparently has some issues with schemas that import other schemas with
   * alternative namespaces.
   * 
   * @see com.monsanto.POSServlet.BasePOSController#validateChildDocument(org.w3c.dom.Document)
   */
  protected Document validateChildDocument(Document inputDocument) throws ValidationException, IOException,
      SAXException, TransformerException, ParserConfigurationException, ParserException {
    Logger.traceEntry(new Object[] { inputDocument });

    return (Document) Logger.traceExit(makeChildDocumentFromParentDocument(inputDocument));
  }

  protected String getXMLSchemaRelativeToServletContext() {
    return null;
  }

  protected LoginBrief authorizeUser(UCCHelper helper, Document inputDocument) throws LogonFailedException,
      NoLogonInformationException {
    return null;
  }

  public void run(UCCHelper helper) throws IOException {
    Logger.traceEntry();
    setImportFilePropertiesBeforeMultipartRequestInit(helper);
    try {
      HelpDisplayer helpDisplayer = createHelpDisplayer(helper);
      if (helpDisplayer.helpDisplayRequested()) {
        helpDisplayer.display(getXMLSchemaRelativeToServletContext(), locateHelpStyleSheet(helper),
            createPOSInformationExtractor());
      } else {
        String inputFileName = getInputDocumentPath(helper);
        processInput(helper, inputFileName);
      }

    } catch (EnvironmentHelperException e) {
      displayAndLogToError(e, helper);
    } catch (TransformerException e) {
      displayAndLogToError(e, helper);
    } catch (SAXException e) {
      displayAndLogToError(e, helper);
    } catch (POSServerException e) {
      displayAndLogToError(e, helper);
    } catch (Throwable e) {
      displayAndLogToError(e, helper, "An unexpected Exception thrown!");
    }
    Logger.traceExit();
  }

  private void setImportFilePropertiesBeforeMultipartRequestInit(UCCHelper helper) throws IOException {
    helper.setImportFileDir(System.getProperty(TEMP_DIR), false);
  }

}
