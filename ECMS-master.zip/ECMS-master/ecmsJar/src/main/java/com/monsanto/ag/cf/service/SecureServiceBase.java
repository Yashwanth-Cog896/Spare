package com.monsanto.ag.cf.service;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Utilities;

import javax.security.auth.Subject;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 10/11/13
 * Time: 11:46 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class SecureServiceBase implements SecureService {

    private XmlMessageInformer inputXmlMessageInformer;
    private XmlMessageInformer outputXmlMessageInformer;
    private SoaClientInvoker soaClientInvoker;

    public SecureServiceBase(){}

    public SecureServiceBase( SoaClientInvoker soaClientInvoker, XmlMessageInformer inputXmlMessageInformer, XmlMessageInformer outputXmlMessageInformer ){

        this.soaClientInvoker = soaClientInvoker;
        this.inputXmlMessageInformer = inputXmlMessageInformer;
        this.outputXmlMessageInformer = outputXmlMessageInformer;
    }

    /**
     * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
     *      javax.security.auth.Subject)
     */
    public ServiceOutput executeSecure( ServiceInput input, Subject subject ) throws ServiceException {
        ServiceInput inputDocument = processInput(input, subject);
        return processOutput( inputDocument );
    }

    protected abstract ServiceInput processInput( ServiceInput input, Subject subject );

    protected abstract ServiceOutput processOutput( ServiceInput inputDocument );

    protected abstract String getConversationIdMessage();

    public boolean isValidationRequired() {
        return false;
    }

    protected String getConversationId() {
        String conversationId = Utilities.generateConversationId();
        Logger.log(new LoggableInfo(getConversationIdMessage() + conversationId));
        return conversationId;
    }

    protected SoaClientInvoker getSoaClientInvoker(){
        return soaClientInvoker;
    }

    public XmlMessageInformer getXmlMessageInformer() {
        return null;
    }

    public XmlMessageInformer getInputXmlMessageInformer() {
      return inputXmlMessageInformer;
    }

    public XmlMessageInformer getOutputXmlMessageInformer() {
        return outputXmlMessageInformer;
    }
}