/*
 * InventoryReportingDao was created on Nov 09, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.dao;

import java.sql.SQLException;
import java.util.List;

import com.monsanto.ag.cf.domain.InventoryDetails;

/**
 * Data Access Object for Inventory Reporting.
 * 
 * @author Ramesh Kukunarapu
 * @version $Id: InventoryReportingDao.java,v 1.2 2007-12-21 17:41:41 RRKUKU Exp $
 */
public interface InventoryReportingDao {
  
  /**
   * @param InventoryDetails
   * @return int
   * @throws SQLException 
   */
  int storeInventoryReportingDetails(List inventoryReportingList) throws SQLException;

}
