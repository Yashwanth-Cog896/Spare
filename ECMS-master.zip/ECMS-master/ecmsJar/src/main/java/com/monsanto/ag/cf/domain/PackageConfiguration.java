/*
 * PackageConfiguration was created on Jun 21, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.util.Date;
import java.text.DecimalFormat;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.monsanto.ag.xml.XmlElement;

/**
 * Represents a configuration of packaging for a commercial seed or chemical
 * product.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method.
 * This XML conforms to the PackageConfigurationInformationType element of the
 * AGIISNamespacedSchema.xsd XML schema document.
 * 
 * @author Gareth Davies
 * @version $Id: PackageConfiguration.java,v 1.1 2008-07-18 21:28:18 gjkell Exp $
 */
public class PackageConfiguration extends AgiisEntity {

  private static final String CLASS_CODE_CHEMICAL = "H";

  public static final String DIMENSION_UOM = "INH";
  public static final String AREA_UOM = "FOT";
  public static final String VOLUME_UOM = "FOT";
  public static final String WEIGHT_UOM = "LBR";
  
  private String gtin;
  private String upc;
  private String packageUom;
  private Measurement basePackageQuantity;
  private Measurement childPackageQuantity;
  private Float calculatedVolume;
  private Float grossWeight;
  private Float tareWeight;
  private Float netWeight;
  private Float length;
  private Float width;
  private Float height;
  private Measurement area;
  private Measurement volume;
  private Integer stackingHeight;
  private Integer cumOrderQty;

  private String classCode;

  public PackageConfiguration(boolean active, Date addedDate,
      Date lastModifiedDate, String classCode, String gtin, String upc, String packageUom,
      Measurement basePackageQuantity, Measurement childPackageQuantity,
      Float calculatedVolume, Float grossWeight, Float tareWeight,
      Float netWeight, Float length, Float width, Float height,
      Measurement area, Measurement volume, Integer stackingHeight,
      Integer cumOrderQty) {
    super(active, addedDate, lastModifiedDate);
    this.classCode = classCode;
    setGtin(gtin);
    setUpc(upc);
    setPackageUom(packageUom);
    this.basePackageQuantity = basePackageQuantity;
    this.childPackageQuantity = childPackageQuantity;
    this.calculatedVolume = calculatedVolume;
    this.grossWeight = grossWeight;
    this.tareWeight = tareWeight;
    this.netWeight = netWeight;
    this.length = length;
    this.width = width;
    this.height = height;
    this.area = area;
    this.volume = volume;
    this.stackingHeight = stackingHeight;
    this.cumOrderQty = cumOrderQty;
  }

  /**
   * @see java.lang.Object#clone()
   */
  public Object clone() throws CloneNotSupportedException {
    Measurement basePackageQuantityClone = (Measurement) basePackageQuantity
        .clone();
    Measurement childPackageQuantityClone = (Measurement) childPackageQuantity
        .clone();
    Measurement areaClone = (Measurement) area.clone();
    Measurement volumeClone = (Measurement) volume.clone();
    PackageConfiguration clone = new PackageConfiguration(isActive(),
        getAddedDate(), getLastModifiedDate(), classCode, gtin, upc, packageUom,
        basePackageQuantityClone, childPackageQuantityClone, calculatedVolume,
        grossWeight, tareWeight, netWeight, length, width, height, areaClone,
        volumeClone, stackingHeight, cumOrderQty);
    return clone;
  }

  /**
   * @see com.monsanto.ag.ecg.domain.AgiisEntity#dispose()
   */
  public void dispose() {
    volume.dispose();
    area.dispose();
    childPackageQuantity.dispose();
    basePackageQuantity.dispose();

    super.dispose();
  }

  private void setGtin(String gtin) {
    if (gtin != null && gtin.trim().length() > 0) {
      this.gtin = gtin.trim();
    } else {
      throw new IllegalArgumentException(
          "GTIN must be at least 1 character long");
    }
  }

  private void setUpc(String upc) {
    if (upc != null && upc.trim().length() > 0) {
      this.upc = upc.trim();
    } else if(!isChemicalProduct()){
      throw new IllegalArgumentException(
          "UPC must be at least 1 character long");
    }
  }

  private void setPackageUom(String packageUom) {
    if (StringUtils.isNotBlank(packageUom)) {
      this.packageUom = packageUom;
    } else {
      throw new IllegalArgumentException(
          "Package Unit of Measure is a required field");
    }
  }

  /**
   * @see com.monsanto.ag.ecg.domain.AgiisEntity#appendXmlToElement(com.monsanto.ag.util.XmlElement)
   */
  public void appendXmlToElement(XmlElement baseXmlElement) {
    XmlElement rootElement = baseXmlElement
        .addChildElement("PackageConfigurationInformation");
    setActiveFlagAttribute(rootElement);
    setActionRequestAttribute(rootElement);

    addFirstLevelChildElements(rootElement);
  }

  private void addFirstLevelChildElements(XmlElement rootElement) {
    rootElement.addChildElement("PackageLevelCode", getPackageLevel());
    rootElement.addChildElement("CheckDigit", getCheckDigit());
    rootElement.addChildElement("GTIN", gtin);

    addUnitOfMeasureElement(rootElement, "PackageUnitOfMeasureCode",
        packageUom, UOM_DOMAIN_UN_REC_20);
    rootElement.addChildElement("ReportingIdentifier", upc);

    if (basePackageQuantity != null) {
      XmlElement quantityElement = rootElement
          .addChildElement("BasePackageQuantity");
      basePackageQuantity.appendXmlToElement(quantityElement);
    }
    if (childPackageQuantity != null) {
      XmlElement quantityElement = rootElement
          .addChildElement("ChildPackagingQuantity");
      childPackageQuantity.appendXmlToElement(quantityElement);
    }

    String formatString = "#0.##########";
    DecimalFormat format = new DecimalFormat(formatString);


    rootElement.addChildElement("CalculatedVolumeQuantity", format.format(calculatedVolume));
    rootElement.addChildElement("WeightGross", format.format(grossWeight));
    rootElement.addChildElement("WeightTare", format.format(tareWeight));
    rootElement.addChildElement("WeightNet", format.format(netWeight));
    addUnitOfMeasureElement(rootElement, "WeightUnitOfMeasureCode",
        getWeightUom(), UOM_DOMAIN_UN_REC_20);
    rootElement.addChildElement("DimensionLength", format.format(length));
    rootElement.addChildElement("DimensionWidth", format.format(width));
    rootElement.addChildElement("DimensionHeight", format.format(height));
    addUnitOfMeasureElement(rootElement, "DimensionUnitOfMeasureCode",
        getDimensionUom(), UOM_DOMAIN_UN_REC_20);

    if (area != null) {
      XmlElement quantityElement = rootElement.addChildElement("SquareArea");
      area.appendXmlToElement(quantityElement);
    }
    if (volume != null) {
      XmlElement quantityElement = rootElement
          .addChildElement("CubicDimension");
      volume.appendXmlToElement(quantityElement);
    }

    rootElement.addChildElement("StackingHeight", stackingHeight);
    rootElement.addChildElement("UserDefinedField2", cumOrderQty);
  }

    private boolean isChemicalProduct() {
        return classCode.equals(CLASS_CODE_CHEMICAL);
    }

    private String getWeightUom() {
    return (grossWeight != null && tareWeight != null && netWeight != null) ? WEIGHT_UOM
        : null;
  }

  private String getDimensionUom() {
    return (length != null && width != null && height != null) ? DIMENSION_UOM : null;
  }

  private String getPackageLevel() {
    if (gtin != null && gtin.length() > 0) {
      return gtin.substring(0, 1);
    } else {
      return null;
    }
  }

  private String getCheckDigit() {
    if (gtin != null && gtin.length() > 0) {
      return gtin.substring(gtin.length() - 1, gtin.length());
    } else {
      return null;
    }
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof PackageConfiguration)) {
      return false;
    }
    PackageConfiguration rhs = (PackageConfiguration) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj))
            .append(classCode, rhs.classCode).append(gtin, rhs.gtin)
            .append(upc, rhs.upc).append(packageUom, rhs.packageUom)
        .append(basePackageQuantity, rhs.basePackageQuantity).append(
            childPackageQuantity, rhs.childPackageQuantity).append(
            calculatedVolume, rhs.calculatedVolume).append(grossWeight,
            rhs.grossWeight).append(tareWeight, rhs.tareWeight).append(
            netWeight, rhs.netWeight).append(length, rhs.length).append(width,
            rhs.width).append(height, rhs.height).append(area, rhs.area)
        .append(volume, rhs.volume).append(stackingHeight, rhs.stackingHeight)
        .append(cumOrderQty, rhs.cumOrderQty)
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 7).appendSuper(super.hashCode()).append(classCode)
        .append(gtin).append(upc).append(packageUom)
        .append(basePackageQuantity).append(childPackageQuantity).append(
            calculatedVolume).append(grossWeight).append(tareWeight).append(
            netWeight).append(length).append(width).append(height).append(area)
        .append(volume).append(stackingHeight).append(cumOrderQty).hashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.14  2008/07/10 19:19:27  gjkell
 * GOA II Interstate
 *
 * Revision 1.13  2005/12/01 19:55:37  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.12  2005/08/26 16:31:37  ggdavi
 * Javadoc corrections
 *
 * Revision 1.11  2005/08/19 15:14:34  ggdavi
 * Modified to support different types of products
 *
 * Revision 1.10  2005/08/05 22:59:08  ggdavi
 * Enforced UN-Rec-20 UOM domain
 *
 * Revision 1.9  2005/07/28 15:47:50  ggdavi
 * Added ActionRequest attribute to various Product document elements; mapped the PackageLevelCode and CheckDigit elements to the GTIN database column; only send one error email per ProductUpdate document, containing all product-specific errors
 * Revision 1.8 2005/07/21 22:23:39 ggdavi
 * Added com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such
 * as Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations; enhanced and refactored XML abstraction
 * in com.monsanto.ag.util Revision 1.7 2005/07/05 19:35:28 ggdavi Now extends
 * AgiisEntity instead of implementing ExtractXML, which enforces use of
 * XmlDocumentBuilder implementations to generate the XML, as well as providing
 * clone and dispose methods Revision 1.6 2005/06/30 21:31:23 ggdavi Use
 * node.getOwnerDocument instead of helper.getDocument(node)
 * 
 * Revision 1.5 2005/06/30 16:44:04 ggdavi Modified insertXml so that it simply
 * adds elements to the baseElement parameter, rather than importing the
 * Document node from the toXML method Revision 1.4 2005/06/28 20:46:41 ggdavi
 * All units of measure are required
 * 
 * Revision 1.3 2005/06/27 22:02:11 ggdavi Tweaks in an effort to hit the moving
 * anaysis target... Revision 1.2 2005/06/22 21:53:59 ggdavi Moved
 * AgiisDocumentHelper from ag.ecg.domain to ag.util Revision 1.1 2005/06/22
 * 17:22:09 ggdavi Initial version
 * 
 */