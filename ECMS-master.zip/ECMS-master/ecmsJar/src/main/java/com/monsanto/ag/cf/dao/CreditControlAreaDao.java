/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.dao;

import org.springframework.jdbc.object.MappingSqlQuery;

import java.util.List;

public interface CreditControlAreaDao {
    List getGrowerIdsInCreditControlArea(MappingSqlQuery query, int creditControlAreaCode);
}
