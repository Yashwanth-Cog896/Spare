/*
 * SeedProduct was created on Aug 18, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import com.monsanto.ag.xml.XmlElement;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Represents a commercial seed product.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method. This XML
 * conforms to the AGIISProductUpdate element of the AGIISNamespacedSchema.xsd
 * XML schema document.
 * 
 * @author Gareth Davies
 * @version $Id: SeedProduct.java,v 1.1 2008-07-18 21:28:18 gjkell Exp $
 */
public class SeedProduct extends Product {

  private static final String TREATMENT_CODE_NO_TREATMENT = "0";
  private static final String SPECIES_CODE_CORN = "C";

  private static final Map CROP_MAP;

  static {
    Map cropMap = new HashMap();
    cropMap.put("A", "Alfalfa");
    cropMap.put("B", "Soybeans");
    cropMap.put(SPECIES_CODE_CORN, "Corn");
    cropMap.put("F", "Sunflower");
    cropMap.put("L", "Canola");
    cropMap.put("S", "Sorghum");
    cropMap.put("T", "Cotton");
    cropMap.put("U", "Sudangrass");
    CROP_MAP = Collections.unmodifiableMap(cropMap);
  }
  private String brand;
  protected String variety;
  private String biotechTrait;
  protected String treatmentCode;
  private String treatmentDesc;
  private String traits;
  protected String speciesCode;
  private boolean licenseRequired;
  private int licenseTraitGroup;
  private boolean insectResistanceManagement;
    protected String primaryProductSegmentCode;

    public SeedProduct(boolean ecListMaterial, boolean active, Date addedDate, Date lastModifiedDate, String id,
                       String brand, String variety, String biotechTrait, String treatmentCode, String treatmentDesc,
                       String traits, String speciesCode, boolean licenseRequired, int licenseTraitGroup,
                       boolean insectResistanceManagement) {
        super(ecListMaterial, active, addedDate, lastModifiedDate, id);

        setBrand(brand);
        setVariety(variety);
        this.biotechTrait = biotechTrait;
        setTreatmentCode(treatmentCode);
        this.treatmentDesc = treatmentDesc;
        this.traits = traits;
        setSpeciesCode(speciesCode);
        this.licenseRequired = licenseRequired;
        this.licenseTraitGroup = licenseTraitGroup;
        this.insectResistanceManagement = insectResistanceManagement;
        this.primaryProductSegmentCode = "Seed";
    }

  /**
   * @see com.monsanto.ag.cf.domain.Product#shallowCloneImplementation()
   */
  protected Product shallowCloneImplementation() {
    return new SeedProduct( isEcListMaterial(), isActive(), getAddedDate(), getLastModifiedDate(),
        getId(), brand, variety, biotechTrait, treatmentCode, treatmentDesc,
        traits, speciesCode, licenseRequired, licenseTraitGroup,
        insectResistanceManagement);
  }

  public String getVariety() {
    return variety;
  }

    private void setBrand(String brand) {
        this.brand = brand;
    }

    protected void setSpeciesCode(String speciesCode) {
        this.speciesCode = speciesCode;
    }

    protected void setVariety(String variety) {
        if (StringUtils.isNotBlank(variety)) {
            this.variety = variety;
        } else {
            throw new IllegalArgumentException("Variety is a required field");
        }
    }

    public String getTreatmentCode() {
        return treatmentCode;
    }

    protected void setTreatmentCode(String treatmentCode) {
        if (StringUtils.isNotBlank(treatmentCode)) {
            this.treatmentCode = treatmentCode;
        } else {
            throw new IllegalArgumentException("Treatment Code is a required field");
        }
    }

  /**
   * see com.monsanto.ag.ecg.domain.Product#addTypeSpecificChildElements(com.monsanto.ag.util.XmlElement)
   */
  protected void addTypeSpecificChildElements(XmlElement rootElement) {
    rootElement.addChildElement("BrandName", brand);
    rootElement.addChildElement("ProductVariety", variety);
    rootElement.addChildElement("ProductTraits", traits);
    rootElement.addChildElement("ProductCrop", getCropDescription());
    rootElement.addChildElement("ProductTreatments", getTreatmentDescription());
    rootElement.addChildElement("UserDefinedField1", getLicense());
    rootElement.addChildElement("UserDefinedField2",
        convertToFlagValue(insectResistanceManagement));
    rootElement.addChildElement("UserDefinedField3",
        convertToFlagValue(hasFieldCoordinates()));
    rootElement.addChildElement("PrimaryProductSegmentCode", primaryProductSegmentCode);
  }

  /**
   * Gets the AGIIS-compliant identifier for this product. This is a combination
   * of product variety and treatment code.
   * 
   * @return AGIIS-compliant product identifier
   * @see com.monsanto.ag.cf.domain.Product#getAGIISIdentifier()
   */
  public String getAGIISIdentifier() {
    return variety + " " + treatmentCode;
  }

  /**
   * Gets the AGIIS-compliant name for this product. This is a combination of
   * product variety, biotech trait and product treatment description.
   * 
   * @return AGIIS-compliant product identifier
   * @see com.monsanto.ag.cf.domain.Product#getAGIISName()
   */
  public String getAGIISName() {
    StringBuffer agiisId = new StringBuffer();

    agiisId.append(variety);

    if (isBiotechCorn() && varietyEndsWithTrait(agiisId)) {
      agiisId.append(" (" + biotechTrait + ")");
    }

    String treatmentDescription = getTreatmentDescription();
    if (StringUtils.isNotBlank(treatmentDescription)) {
      agiisId.append(" " + treatmentDescription);
    }

    return agiisId.toString().trim();
  }

  private boolean varietyEndsWithTrait(StringBuffer agiisId) {
    boolean varietyEndsWithTrait = StringUtils.isNotBlank(biotechTrait)
        && !agiisId.toString().endsWith(biotechTrait);
    return varietyEndsWithTrait;
  }

  private boolean isBiotechCorn() {
    boolean biotechCornFlag = SPECIES_CODE_CORN.equals(speciesCode)
        && licenseRequired;
    return biotechCornFlag;
  }

  /**
   * Gets the description of the crop from the code.
   * <p>
   * Shouldn't this be in a database lookup table?!?
   * 
   * @return Crop description
   */
  public String getCropDescription() {
    return (String) CROP_MAP.get(speciesCode);
  }

  /**
   * Gets the treatment description, depending on the value of the treatment
   * code.
   * 
   * @return Treatment description
   */
  private String getTreatmentDescription() {
    return (TREATMENT_CODE_NO_TREATMENT.equals(treatmentCode)) ? null
        : treatmentDesc;
  }

  /**
   * Gets the identifier of the license, based on the trait group, if one
   * applies.
   * 
   * @return License identifier
   */
  private String getLicense() {
    if (licenseRequired) {
      return "MTA" + licenseTraitGroup;
    } else {
      return null;
    }
  }

  /**
   * Determines whether or not field coordinates apply to this product (should
   * only do so for Alfalfa if a license identifier exists).
   * 
   * @return True if field coordinates apply
   */
  private boolean hasFieldCoordinates() {
    return (getLicense() != null && "A".equals(speciesCode));
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof SeedProduct)) {
      return false;
    }
    SeedProduct rhs = (SeedProduct) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(brand,
        rhs.brand).append(variety, rhs.variety).append(biotechTrait,
        rhs.biotechTrait).append(treatmentCode, rhs.treatmentCode).append(
        treatmentDesc, rhs.treatmentDesc).append(traits, rhs.traits).append(
        speciesCode, rhs.speciesCode).append(licenseRequired,
        rhs.licenseRequired).append(licenseTraitGroup, rhs.licenseTraitGroup)
        .append(insectResistanceManagement, rhs.insectResistanceManagement)
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 11).appendSuper(super.hashCode()).append(
        brand).append(variety).append(biotechTrait).append(treatmentCode)
        .append(treatmentDesc).append(traits).append(speciesCode).append(
            licenseRequired).append(licenseTraitGroup).append(
            insectResistanceManagement).hashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/12/01 19:55:37  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.1  2005/08/19 15:13:55  ggdavi
 * Initial version
 *
 */