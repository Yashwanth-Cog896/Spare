package com.monsanto.ag.cf.service.impl;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.ag.cf.dao.InventoryReportingDao;
import com.monsanto.ag.cf.domain.*;
import com.monsanto.ag.cf.service.util.FileNameCreatorForInventoryReporting;
import com.monsanto.ag.cf.service.util.InventoryActualUsageResponseBuilder;
import com.monsanto.ag.cf.service.util.ProductIdentifierValidator;
import com.monsanto.ag.cf.service.util.ResponseBuilder;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.UOMConverter;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;

import javax.security.auth.Subject;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by jtmurr on 1/29/2016.
 */
public class InventoryActualUsageImpl extends ServiceProxySupport implements SecureService, Identifiable {
    private XmlMessageInformer inputXmlMessageInformer;
    private XmlMessageInformer outputXmlMessageInformer;
    private XmlDocumentBuilder xmlDocumentBuilder;
    private InventoryReportingDao inventoryReportingDao;
    private String conversationId;
    private String fileName;
    private String message;
    private int recordsToBeInserted;
    private int recordsToBeIgnored;

    @Override
    public String getId() {
        return "INV";
    }

    @Override
    public ServiceOutput executeSecure(ServiceInput serviceInput, Subject subject) throws ServiceException {
        ResponseBuilder responseBuilder = new InventoryActualUsageResponseBuilder();
        ServiceOutput output = new ServiceOutput();
        conversationId = Utilities.generateConversationId();
        output.setConversationId(conversationId);
        Logger.log(new LoggableInfo("Processing Inventory Actual Usage request with conversation Id: " + conversationId));
        List<InventoryDetails> inventoryDetailsList = createDetailsFromInputDocument(serviceInput.getXmlChunks().getXmlDocument(xmlDocumentBuilder));
        try {
            if (!inventoryDetailsList.isEmpty()) {
                int insertions = inventoryReportingDao.storeInventoryReportingDetails(inventoryDetailsList);
                if (insertions == recordsToBeInserted && recordsToBeIgnored == 0) {
                    message = "Success (" + fileName + ")";
                }
            }
        } catch (Exception e) {
            message += "\nException while inserting data: " + e.getMessage();
        }
        Logger.log(new LoggableInfo("Message: " + message));
        output.getXmlChunks().addChunk(responseBuilder.build(xmlDocumentBuilder, message));
        return output;
    }

    @Override
    public XmlMessageInformer getXmlMessageInformer() {
        return null;
    }

    @Override
    public XmlMessageInformer getInputXmlMessageInformer() {
        return inputXmlMessageInformer;
    }

    @Override
    public XmlMessageInformer getOutputXmlMessageInformer() {
        return outputXmlMessageInformer;
    }

    @Override
    public boolean isValidationRequired() {
        return false;
    }

    public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
        this.inputXmlMessageInformer = inputXmlMessageInformer;
    }

    public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
        this.outputXmlMessageInformer = outputXmlMessageInformer;
    }

    public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
        this.xmlDocumentBuilder = xmlDocumentBuilder;
    }

    public void setInventoryReportingDao(InventoryReportingDao inventoryReportingDao) {
        this.inventoryReportingDao = inventoryReportingDao;
    }

    private static final String AGENCY_ATTRIBUTE = "Agency";
    private static final String REPORTER_NAME = "/InventoryActualUsage/Header/From/PartnerInformation/PartnerName";
    private static final String REPORTER_ID = "/InventoryActualUsage/Header/From/PartnerInformation/PartnerIdentifier";
    private static final String OWNER_NAME = "/InventoryActualUsage/InventoryActualUsageBody/InventoryActualUsagePartners/Buyer/PartnerInformation/PartnerName";
    private static final String OWNER_ID = "/InventoryActualUsage/InventoryActualUsageBody/InventoryActualUsagePartners/Buyer/PartnerInformation/PartnerIdentifier";
    private static final String LINE_ITEM = "/InventoryActualUsage/InventoryActualUsageBody/InventoryActualUsageDetails/InventoryUsageLineItem";
    private static final String SPECIFIED_MEASUREMENT_QUALIFIER = "MeasurementQualifier";
    public static final String DATA_SOURCE = "WS-XML";

    public List<InventoryDetails> createDetailsFromInputDocument(XmlDocument inputDocument) {
        AgencyConverter agencyConverter = new AgencyConverter();
        ProductIdentifierValidator productIdentifierValidator = new ProductIdentifierValidator();
        List<InventoryDetails> inventoryDetailsList = new ArrayList<InventoryDetails>();
        recordsToBeIgnored = 0;
        recordsToBeInserted = 0;

        fileName = getFileNameCreatorForInventoryReporting().createFileName();
        message = "Filename: " + fileName;
        InventoryReporterDetails reporterDetails = new InventoryReporterDetails(
                truncateName(inputDocument.selectElementByXPath(REPORTER_NAME).getText()),
                agencyConverter.convert(inputDocument.selectElementByXPath(REPORTER_ID).getAttributeValue(AGENCY_ATTRIBUTE)),
                inputDocument.selectElementByXPath(REPORTER_ID).getText(),
                truncateName(inputDocument.selectElementByXPath(OWNER_NAME).getText()),
                agencyConverter.convert(inputDocument.selectElementByXPath(OWNER_ID).getAttributeValue(AGENCY_ATTRIBUTE)),
                inputDocument.selectElementByXPath(OWNER_ID).getText());
        List lineItems = inputDocument.selectElementsByXPath(LINE_ITEM);
        if (lineItems == null || lineItems.isEmpty()) {
            message += "\nNo line items were parsed from the payload.";
            Logger.log(new LoggableInfo("inputDocument:\n" + inputDocument.toString()));
            return inventoryDetailsList;
        }
        for (Object lineItem : lineItems) {
            InventoryLocationDetails inventoryLocationDetails = new InventoryLocationDetails();
            List<InventoryProductDetails> inventoryProductDetailsList = new ArrayList<InventoryProductDetails>();
            for (Object inventoryUsageElement : ((XmlElement) lineItem).getChildren()) {
                XmlElement element = (XmlElement) inventoryUsageElement;
                processInventoryUsage(element, agencyConverter, productIdentifierValidator, inventoryLocationDetails, inventoryProductDetailsList);
            }

            for (InventoryProductDetails inventoryProductDetails : inventoryProductDetailsList) {
                if (inventoryProductDetails.isBadData()) {
                    recordsToBeIgnored++;
                    continue;
                }
                recordsToBeInserted++;
                InventoryDetails inventoryDetails = new InventoryDetails(fileName, AppConstants.CUST_TYPE_ST_TYPE,
                        AppConstants.REPORT_TYPE, AppConstants.DS_TYPE, AppConstants.SF_TYPE,
                        AppConstants.INVOICE_DATE_QUALIFIER, AppConstants.SHIP_DATE_QUALIFIER,
                        AppConstants.TRANSACTION_STATUS, conversationId, reporterDetails, DATA_SOURCE,
                        inventoryLocationDetails,
                        inventoryProductDetails, "Y", "");
                inventoryDetailsList.add(inventoryDetails);
            }
        }

        Logger.log(new LoggableInfo("Returning inventoryDetailsList, there are " + recordsToBeInserted + " elements in the list; " + recordsToBeIgnored + " are ignored."));
        return inventoryDetailsList;
    }

    private String truncateName(String name) {
        return StringUtils.truncate(name, 30);
    }

    private void processInventoryUsage(XmlElement element, AgencyConverter agencyConverter, ProductIdentifierValidator productIdentifierValidator, InventoryLocationDetails inventoryLocationDetails, List<InventoryProductDetails> inventoryProductDetailsList) {
        if ("InventoryUsageLocation".equals(element.getUnqualifiedName())) {
            processLocation(element, agencyConverter, inventoryLocationDetails);
        }
        if ("InventoryUsageInformation".equals(element.getUnqualifiedName())) {
            inventoryProductDetailsList.add(processProduct(element, agencyConverter, productIdentifierValidator));
        }
    }

    private void processLocation(XmlElement element, AgencyConverter agencyConverter,
                                 InventoryLocationDetails inventoryLocationDetails) {
        XmlElement location = element.getChild("PartnerInformation");
        String locationId = location.getChild("PartnerIdentifier").getText();
        String locationIdQualifier = agencyConverter.convert(location.getChild("PartnerIdentifier").getAttributeValue(AGENCY_ATTRIBUTE));
        String partnerName = truncateName(location.getChild("PartnerName").getText());
        inventoryLocationDetails.setLocationId(locationId);
        inventoryLocationDetails.setLocationIdQualifier(locationIdQualifier);
        inventoryLocationDetails.setLocationName(partnerName);
    }

    private InventoryProductDetails processProduct(XmlElement element, AgencyConverter agencyConverter, ProductIdentifierValidator productIdentifierValidator) {
        XmlElement productIdentifier = element.getChild("InventoryProduct").getChild("ProductIdentification")
                .getChild("ProductIdentifier");
        XmlElement inventoryLevel = element.getChild("InventoryLevel");
        XmlElement specifiedMeasurement = inventoryLevel.getChild("InventoryOnSite").getChild("InventoryOther")
                .getChild("MeasurementInformation").getChild("SpecifiedMeasurement");
        XmlElement measurement = specifiedMeasurement.getChild("Measurement");
        String productIdentifierAgency = productIdentifier.getAttributeValue(AGENCY_ATTRIBUTE);
        String gtin = productIdentifier.getText();
        String gtinQualifier = agencyConverter.convert(productIdentifier.getAttributeValue(AGENCY_ATTRIBUTE));
        boolean productIdentifierIsInvalid = productIdentifierValidator.isProductIdentifierInvalid(gtin, gtinQualifier);
        Date date = createDateTimeFromLineItemElement(inventoryLevel);
        String quantity = measurement.getChild("MeasurementValue").getText();
        String quantityQualifier = agencyConverter.convert(specifiedMeasurement.getAttributeValue(SPECIFIED_MEASUREMENT_QUALIFIER));
        String orderType = createOrderTypeForQuantity(quantity);
        String productUom = createProductUom(new UOMConverter(), measurement.getChild("UnitOfMeasureCode").getText());
        InventoryProductDetails productDetails = new InventoryProductDetails(date, gtin, gtinQualifier, quantity,
                quantityQualifier, orderType, productUom, agencyConverter);
        if (productIdentifierIsInvalid) {
            message += "\n\tInvalid product: '" + productIdentifierAgency + "': '" + gtin + "'";
            productDetails.setBadData(true);
        }
        return productDetails;
    }

    private FileNameCreatorForInventoryReporting getFileNameCreatorForInventoryReporting() {
        return new FileNameCreatorForInventoryReporting(new Date(), DATA_SOURCE);
    }

    private String createProductUom(UOMConverter converter, String uomCode) {
        String productUom;
        try {
            productUom = converter.findIRDCode(uomCode);
        } catch (Exception e) {
            message += "\n\t" + e.getMessage();
            productUom = null;
        }
        return productUom;
    }

    private Date createDateTimeFromLineItemElement(XmlElement element) {
        Date date;
        try {
            String dateTime = element.getChild("DateTime").getText();
            date = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(dateTime);
        } catch (ParseException parseException) {
            message += "\n\t" + parseException.getMessage();
            date = null;
        }
        return date;
    }

    private String createOrderTypeForQuantity(String quantity) {
        String orderType = null;
        try {
            double dblQty = Double.parseDouble(quantity);
            if (dblQty >= 0) {
                orderType = AppConstants.ZERO_POSITIVE_QTY_VAL_ORDER_TYPE;
            } else {
                orderType = AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE;
            }
        } catch (NumberFormatException numberFormatException) {
            message += "\n\tInvalid quantity: " + numberFormatException.getMessage();
            orderType = null;
        }
        return orderType;
    }

    public String getMessage() {
        return message;
    }
}
