/*
 * CustomerSearchHelper was created on Sep 15, 2008 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import org.apache.commons.lang.StringUtils;

import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.GrowerCriteria;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlDocument;

public class CustomerSearchHelper {

  public static final String XPATH_ENTITY_INFO = "/ecms:AGIISEntityInquiry/ecms:Body/ecms:AGIISEntityInquiryDetails/ecms:EntityInquiry/ecms:EntityInformation";
  public static final String XPATH_ENTITY_INFO_ENTITYINQUIRY = "/ecms:AGIISEntityInquiry/ecms:Body/ecms:AGIISEntityInquiryDetails/ecms:EntityInquiry";

  public static GrowerCriteria getGrowerCriteriaFromInputDocument(
      XmlDocument inputDocument) {
    long accountId = 0;
    String accountIdString = inputDocument
        .getNodeValueByXPath(XPATH_ENTITY_INFO + "/ecms:IndustryIdentifier[@"
            + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='"
            + CidxConstants.ACCOUNT_ID_AGENCY + "']/ecms:IndustryCode");
    if (StringUtils.isNotBlank(accountIdString)
        && StringUtils.isNumeric(accountIdString)) {
      accountId = Long.parseLong(accountIdString);
    }
    String accountName = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:PreferredName");
    String firstName = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:IndividualName/ecms:FirstName");
    String lname = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:IndividualName/ecms:LastName");
    String phone = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:TelephoneNumber");
    String status = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:EntityStatus");
    String city = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:MailingAddress/ecms:CityName");
    String state = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:MailingAddress/ecms:StateOrProvince");
    String zip = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:MailingAddress/ecms:PostalCode");
    String county = inputDocument.getNodeValueByXPath(XPATH_ENTITY_INFO
        + "/ecms:MailingAddress/ecms:CountyName");
    AddressInformation address = new AddressInformation(null, city, state, zip,
        county);
    String maxResultsString = inputDocument
        .getNodeValueByXPath("/ecms:AGIISEntityInquiry/ecms:Body/ecms:AGIISEntityInquiryDetails/ecms:EntityInquiry/ecms:EntityInquiryIdentifier");
    int maxresults = 0;
    if (StringUtils.isNotBlank(maxResultsString)
        && StringUtils.isNumeric(maxResultsString)) {
      maxresults = Integer.parseInt(maxResultsString);
    }
    GrowerCriteria criteria = new GrowerCriteria(accountId, accountName,
        firstName, lname, phone, status, address, maxresults);
    return criteria;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2008/09/15 18:41:25  caggarw
 * Added xpathRepeatingElement to handle chuned requests for CustomerSearch2Impl. Also corrected CustomerSearch2Impl to not extend CustomerSearchImpl, as they are separate services. Created a helper class to handle some common methods.
 *
 */