/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.farmflex.domain;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.commercial.growercreditlist.domain.GrowerCreditInfo;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static java.util.Collections.unmodifiableList;

public class MergeGrowerCreditInfoWithGrowerDetails {
    private List customerList;
    private Map<Long, GrowerCreditInfo> growerCreditInfoMap;
    private IdMapperDao idMapperDao;

    public MergeGrowerCreditInfoWithGrowerDetails(List customerList, Map<Long, GrowerCreditInfo> growerCreditInfoMap,
                                                  IdMapperDao idMapperDao) {
        this.customerList = customerList;
        this.growerCreditInfoMap = growerCreditInfoMap;
        this.idMapperDao = idMapperDao;
    }

    public List buildMergedData() {
        if (growerCreditInfoMap != null && !growerCreditInfoMap.isEmpty()) {
            mergeData();
        }
        rebuildCustomerList();
        return unmodifiableList(customerList);
    }

    private void rebuildCustomerList() {
        List tmp = new ArrayList();
        tmp.addAll(customerList);
        customerList = new ArrayList();
        for (Object growerDetails : tmp) {
            if (growerDetails instanceof GrowerDetails && ((GrowerDetails) growerDetails).getCustomerIds() != null) {
                if (((GrowerDetails) growerDetails).getCustomerIds().getSapId() == null || ((GrowerDetails) growerDetails).getCustomerIds().getSapId().startsWith("999998")) {
                    continue;
                }
                customerList.add(growerDetails);
            }
        }
    }

    private void mergeData() {
        for (Object growerDetails : customerList) {
            if (growerDetails instanceof GrowerDetails && ((GrowerDetails) growerDetails).getCustomerIds() != null) {
                long growerId = ((GrowerDetails) growerDetails).getCustomerIds().getAccountId();
                Logger.log(new LoggableInfo("creating key from " + growerId));
                String key = createKey(growerId);
                Logger.log(new LoggableInfo("created key '" + key + "'"));
                if (key != null && !key.startsWith("999998")) {
                    merge((GrowerDetails) growerDetails, key);
                } else {
                    Logger.log(new LoggableInfo("Skipping merge for " + growerId + " { " + growerDetails + " }\nkey: " + key));
                }
            }
        }
    }

    private void merge(GrowerDetails growerDetails, String key) {
        try {
            growerDetails.setFarmFlexInfo(growerCreditInfoMap.containsKey(Long.valueOf(key)) ?
                    new FarmFlexInfo(growerCreditInfoMap.get(Long.valueOf(key))) : null);
            if (growerDetails.getFarmFlexInfo() != null && growerDetails.getFarmFlexInfo().getFarmFlexApprovedAmount() > 0) {
                Logger.log(new LoggableInfo(
                        "grower '" + growerDetails.getAccountName() + "' is approved for '" +
                                growerDetails.getFarmFlexInfo().getFarmFlexApprovedAmount() + "' (used: '" +
                                growerDetails.getFarmFlexInfo().getFarmFlexUsage() + "')."));
            }
        } catch (IncorrectResultSizeDataAccessException e) {
            Logger.log(new LoggableInfo("Could not get key for grower: " + growerDetails + "; " + e.getMessage()));
        }
    }

    private String createKey(long growerId) {
        String key = null;
        try {
            key = idMapperDao.findSAPIdByAccountId(growerId);
            if (key == null) {
                key = idMapperDao.findSAPIdByAccountId(idMapperDao.findAccountIdByEBID(String.valueOf(growerId)));
            }
            key = key.startsWith("000") ? key.substring(3) : key;
        } catch (IncorrectResultSizeDataAccessException e) {
            Logger.log(new LoggableInfo("Failed to look up SAP ID for " + growerId + ": " + e.getMessage()));
        }
        return key;
    }
}
