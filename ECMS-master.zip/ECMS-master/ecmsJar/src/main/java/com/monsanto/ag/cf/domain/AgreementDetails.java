/*
 * AgreementDetails was created on Apr 16, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Domain Object containing AgreementDetails
 * 
 * @author Chetna Aggarwal
 * @version $Id: AgreementDetails.java,v 1.4 2008-02-12 23:29:03 gjkell Exp $
 */
public class AgreementDetails {

  private long accountId;
  private String accountName;
  private String state;
  private String cornZone;
  private String cornZonecode;
  private String alfalfaZone;
  private String alfalfaZoneCode;
  private String licenseStatus;
  private String errorMessage;
  private String errorDecription;
  private String firstName;
  private String lastName;
  private String rejectedAccountId;
  private String proprietaryCode;

  public AgreementDetails(long accountId, String accountName, String state, String cornZone, String cornZonecode,
      String alfalfaZone, String alfalfaZoneCode, String licenseStatus, String firstName, String lastName) {
    this.accountId = accountId;
    this.accountName = accountName;
    this.state = state;
    this.cornZone = cornZone;
    this.cornZonecode = cornZonecode;
    this.alfalfaZone = alfalfaZone;
    this.alfalfaZoneCode = alfalfaZoneCode;
    this.licenseStatus = licenseStatus;
    this.firstName = firstName;
    this.lastName = lastName;
  }
  
  public AgreementDetails(long accountId, String accountName, String state, String cornZone, String cornZonecode,
      String alfalfaZone, String alfalfaZoneCode, String licenseStatus, String firstName, String lastName, 
      String proprietaryCode) {
    this.accountId = accountId;
    this.accountName = accountName;
    this.state = state;
    this.cornZone = cornZone;
    this.cornZonecode = cornZonecode;
    this.alfalfaZone = alfalfaZone;
    this.alfalfaZoneCode = alfalfaZoneCode;
    this.licenseStatus = licenseStatus;
    this.firstName = firstName;
    this.lastName = lastName;
    this.proprietaryCode = proprietaryCode;
  }

  public AgreementDetails() {
  }

  public AgreementDetails(long accountId, String state, String proprietaryCode) {
    this.accountId = accountId;
    this.state = state;
    this.proprietaryCode = proprietaryCode;
  }

  public long getAccountId() {
    return accountId;
  }

  public String getAccountName() {
    return accountName;
  }

  public String getAlfalfaZone() {
    return alfalfaZone;
  }

  public String getAlfalfaZoneCode() {
    return alfalfaZoneCode;
  }

  public String getCornZone() {
    return cornZone;
  }

  public String getCornZonecode() {
    return cornZonecode;
  }

  public String getLicenseStatus() {
    return licenseStatus;
  }

  public String getState() {
    return state;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }
  
  public String getProprietaryCode() {
    return proprietaryCode;
  }

  public void setErrorDecription(String errorDecription) {
    this.errorDecription = errorDecription;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }
  
  public void setPropCode(String propCode) {
    this.proprietaryCode = propCode;
  }
  
  public String getErrorDecription() {
    return errorDecription;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public String getRejectedAccountId() {
    return rejectedAccountId;
  }

  public void setRejectedAccountId(String rejectedAccountId) {
    this.rejectedAccountId = rejectedAccountId;
  }

  /**
   * @see java.lang.Object#equals(java.lang.Object)
   */
  public boolean equals(Object obj) {
    if (!(obj instanceof AgreementDetails)) {
      return false;
    }
    AgreementDetails rhs = (AgreementDetails) obj;
    return new EqualsBuilder().append(accountId, rhs.getAccountId()).append(accountName, rhs.getAccountName()).append(
        cornZone, rhs.getCornZone()).append(state, rhs.getState()).append(cornZonecode, rhs.getCornZonecode()).append(
        alfalfaZone, rhs.getAlfalfaZone()).append(alfalfaZoneCode, rhs.getAlfalfaZoneCode()).append(licenseStatus,
        rhs.getLicenseStatus()).append(firstName, rhs.getFirstName()).append(lastName, rhs.getLastName()).append(rejectedAccountId, rhs.getRejectedAccountId())
        .append(proprietaryCode, rhs.getProprietaryCode()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 19).append(accountId).append(accountName).append(state).append(cornZone).append(
        cornZonecode).append(alfalfaZone).append(alfalfaZoneCode).append(licenseStatus).append(firstName).append(
        lastName).append(rejectedAccountId).append(proprietaryCode).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).append("accountId", accountId).append("accountName",
        accountName).append("state", state).append("cornZone", cornZone).append("cornZonecode", cornZonecode).append(
        "alfalfaZone", alfalfaZone).append("alfalfaZoneCode", alfalfaZoneCode).append("licenseStatus", licenseStatus)
        .append("firstName", firstName).append("lastName", lastName).append("rejectedAccountId", rejectedAccountId)
        .append("proprietaryCode", proprietaryCode).toString();
  }
}
