/*
 * TraceInterceptor was created on Mar 25, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import com.monsanto.AbstractLogging.Logger;

/**
 * Simple AOP Alliance MethodInterceptor that can be introduced in a chain to
 * display verbose trace information about intercepted method invocations, using
 * the ATF AbstractLogging package.
 * <p>
 * This interceptor differs from the
 * org.springframework.aop.interceptor.TraceInterceptor in that it includes
 * argument values with method entry information and the return value with
 * method exit information.
 * 
 * @author Gareth Davies
 * @version $Id: TraceInterceptor.java,v 1.3 2005-06-30 17:43:25 ggdavi Exp $
 */
public class TraceInterceptor implements MethodInterceptor {

  /**
   * @see org.aopalliance.intercept.MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
   */
  public Object invoke(MethodInvocation invocation) throws Throwable {
    String methodName = invocation.getMethod().toString();
    
    Logger.traceEntry(invocation.getArguments(), methodName);
    return Logger.traceExit(invocation.proceed(), methodName);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/06/28 16:08:24  ggdavi
 * Moved TraceInterceptor from ag.logging to ag.aop
 *
 * Revision 1.1  2005/04/07 15:40:56  ggdavi
 * Moved to ag.logging package
 *
 * Revision 1.1  2005/03/28 19:26:38  ggdavi
 * Initial version
 *
 */