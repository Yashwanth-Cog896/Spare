/*
 * Grower was created on Jul 24, 2007 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

/**
 * Represent the information of a Grower search criteria.
 * 
 * @author Chetna Aggarwal
 * @version $Id: GrowerCriteria.java,v 1.3 2007-08-28 15:42:25 caggarw Exp $
 */
public class GrowerCriteria {

  private long accountId;
  private String accountName;
  private String fName;
  private String lName;
  private String phone;
  private String status;
  private AddressInformation addressInformation;
  private int maxResults;

  public GrowerCriteria() {
  }

  public GrowerCriteria(long accountId, String accountName, String fName, String lName, String phone, String status,
      AddressInformation address, int maxResults) {
    this.accountId = accountId;
    this.accountName = accountName;
    this.fName = fName;
    this.lName = lName;
    this.phone = phone;
    this.status = status;
    this.addressInformation = address;
    this.maxResults = maxResults;
  }

  public long getAccountId() {
    return accountId;
  }

  public String getAccountName() {
    return accountName;
  }

  public AddressInformation getAddressInformation() {
    return addressInformation;
  }

  public String getFName() {
    return fName;
  }

  public String getLName() {
    return lName;
  }

  public String getPhone() {
    return phone;
  }

  public String getStatus() {
    return status;
  }

  public int getMaxResults() {
    return maxResults;
  }

  public void setAccountId(long accountId) {
    this.accountId = accountId;
  }

  public void setAccountName(String accountName) {
    this.accountName = accountName;
  }

  public void setAddressInformation(AddressInformation addressInformation) {
    this.addressInformation = addressInformation;
  }

  public void setFName(String name) {
    fName = name;
  }

  public void setLName(String name) {
    lName = name;
  }

  public void setMaxResults(int maxResults) {
    this.maxResults = maxResults;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public void setStatus(String status) {
    this.status = status;
  }

}
