/*
 * BroadcastMessageReader was created on May 19, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service;

import java.util.List;

/**
 * Defines operations for consuming broadcast messages from an arbitrary source.
 * 
 * @author Gareth Davies
 * @version $Id: BroadcastMessageReader.java,v 1.2 2005-05-23 18:22:55 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC72
 */
public interface BroadcastMessageReader {

  /**
   * Error message for when the service is unavailable or not working right
   */
  public static final String REQUEST_ERROR_MESSAGE = "Unable to process broadcast messages";

  /**
   * Get all broadcast messages for the specified seed year that have not been
   * read by the specified user.
   * 
   * @param userId
   *          Id by which the user authenticates
   * @param seedYear
   *          Seed year
   * @return List of BroadcastMessage objects
   */
  public List getNewMessages(String userId, String seedYear);

  /**
   * Acknowledge that the broadcast messages with the specified Ids have been
   * received by the specified user.
   * 
   * @param userId
   *          Id by which the user authenticates
   * @param receivedMessageIds
   *          List of Ids of messages the user has received
   */
  public void acknowledge(String userId, List receivedMessageIds);

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/20 20:51:36  ggdavi
 * Initial version
 *
 */