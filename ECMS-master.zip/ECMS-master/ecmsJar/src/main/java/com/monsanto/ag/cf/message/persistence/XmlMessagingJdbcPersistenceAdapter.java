/*
 * XmlMessagingJdbcPersistenceAdapter was created on May 19, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.persistence;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.jms.JMSException;
import javax.sql.DataSource;

import org.activemq.io.impl.StatelessDefaultWireFormat;
import org.activemq.store.MessageStore;
import org.activemq.store.TopicMessageStore;
import org.activemq.store.TransactionStore;
import org.activemq.store.jdbc.JDBCAdapter;
import org.activemq.store.jdbc.JDBCPersistenceAdapter;
import org.activemq.store.jdbc.JDBCTopicMessageStore;
import org.activemq.store.vm.VMTransactionStore;
import org.springframework.jdbc.support.lob.LobHandler;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;

/**
 * Custom version of ActiveMQ's JdbcPersistenceAdapter suitable for XML
 * messaging applications relying on an Oracle database.
 * 
 * @author Gareth Davies
 * @version $Id: XmlMessagingJdbcPersistenceAdapter.java,v 1.1 2005-06-30 17:43:25 ggdavi Exp $
 */
public class XmlMessagingJdbcPersistenceAdapter extends JDBCPersistenceAdapter {

  private JDBCAdapter adapter;
  private LobHandler lobHandler;
  private VMTransactionStore transactionStore = new VMTransactionStore();

  public XmlMessagingJdbcPersistenceAdapter(DataSource dataSource,
      LobHandler lobHandler) {
    super(dataSource, new StatelessDefaultWireFormat());
    this.lobHandler = lobHandler;
    Logger.log(new LoggableInfo(
        "ActiveMQ durable messaging is using JDBC persistence adapter "
            + getClass().getName()));
  }

  public MessageStore createQueueMessageStore(String destinationName)
      throws JMSException {
    if (adapter == null) {
      throw new IllegalStateException("Not started");
    }
    try {
      String brokerServerName = InetAddress.getLocalHost().getHostName();
      XmlMessagingJdbcMessageStore messageStore = new XmlMessagingJdbcMessageStore(
          this, destinationName, brokerServerName);
      return transactionStore.proxy(messageStore);
    } catch (UnknownHostException e) {
      throw new JMSException(e.getMessage());
    }
  }

  public TopicMessageStore createTopicMessageStore(String destinationName)
      throws JMSException {
    if (adapter == null) {
      throw new IllegalStateException("Not started");
    }
    return transactionStore.proxy(new JDBCTopicMessageStore(this, adapter,
        getWireFormat().copy(), destinationName));
  }

  public TransactionStore createTransactionStore() throws JMSException {
    if (adapter == null) {
      throw new IllegalStateException("Not started");
    }
    return this.transactionStore;
  }

  public synchronized void start() throws JMSException {
    adapter = new NoDDLOracleJDBCAdapter();
  }

  public JDBCAdapter getAdapter() {
    return adapter;
  }

  public LobHandler getLobHandler() {
    return lobHandler;
  }

  public void setLobHandler(LobHandler lobHandler) {
    this.lobHandler = lobHandler;
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/20 14:53:03  ggdavi
 * Initial version
 *
 */