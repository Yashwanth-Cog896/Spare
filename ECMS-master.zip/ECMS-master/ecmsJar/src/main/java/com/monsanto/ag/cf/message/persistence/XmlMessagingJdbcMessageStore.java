/*
 * XmlMessagingJdbcMessageStore was created on May 19, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.persistence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.jms.JMSException;

import org.activemq.io.WireFormat;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.MessageAck;
import org.activemq.service.MessageIdentity;
import org.activemq.store.MessageStore;
import org.activemq.store.RecoveryListener;
import org.activemq.util.JMSExceptionHelper;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.util.Utilities;

/**
 * ActiveMQ data access object that persists XML messages using an underlying
 * Oracle database.
 * <p>
 * TODO Refactor me!
 * 
 * @author Gareth Davies
 * @version $Id: XmlMessagingJdbcMessageStore.java,v 1.1 2005/05/20 14:53:03
 *          ggdavi Exp $
 */
public class XmlMessagingJdbcMessageStore implements MessageStore {

  private XmlMessagingJdbcPersistenceAdapter persistenceAdapter;
  private String destinationName;
  private String brokerServerName;
  private OracleSequenceMaxValueIncrementer maxValueIncrementer;

  public XmlMessagingJdbcMessageStore(
      XmlMessagingJdbcPersistenceAdapter persistenceAdapter,
      String destinationName, String brokerServerName) {
    this.persistenceAdapter = persistenceAdapter;
    this.destinationName = destinationName;
    this.brokerServerName = brokerServerName;

    maxValueIncrementer = new OracleSequenceMaxValueIncrementer();
    maxValueIncrementer.setDataSource(persistenceAdapter.getDataSource());
    maxValueIncrementer.setIncrementerName("message_queue_seq");
  }

  protected String getNextSequenceValue() {
    if (maxValueIncrementer == null) {
      throw new DataIntegrityViolationException(
          "No incrementer was specified for new records of this type");
    } else {
      return maxValueIncrementer.nextStringValue();
    }
  }

  /**
   * @see org.activemq.store.MessageStore#addMessage(org.activemq.message.ActiveMQMessage)
   */
  public void addMessage(ActiveMQMessage message) throws JMSException {
    String messageID = message.getJMSMessageID();
    String messageQueueId = getNextSequenceValue();

    Logger.log(new DebugLogEvent(
        "Saving JMS message to persistent store with sequence number: "
            + messageQueueId));
    String sql = "INSERT INTO Message_Queue "
        + "(Msg_Queue_ID, Destination, Jms_Msg_ID, Xml_Msg, Conversation_ID, Broker_ID) "
        + "VALUES (?, ?, ?, ?, ?, ?)";

    Connection c = null;
    PreparedStatement ps = null;
    try {
      c = persistenceAdapter.getConnection();

      ps = c.prepareStatement(sql);
      ps.setString(1, messageQueueId);
      ps.setString(2, destinationName);
      ps.setString(3, messageID);
      byte[] messageBytes = persistenceAdapter.getWireFormat().toBytes(message);
      persistenceAdapter.getLobHandler().getLobCreator().setBlobAsBytes(ps, 4,
          messageBytes);
      ps.setString(5, getConversationId(message));
      ps.setString(6, brokerServerName);

      if (ps.executeUpdate() != 1) {
        throw new JMSException("Failed to broker message: " + messageID
            + " in container.");
      }
    } catch (IOException e) {
      throw JMSExceptionHelper.newJMSException("Failed to broker message: "
          + messageID + " in container: " + e, e);
    } catch (SQLException e) {
      throw JMSExceptionHelper.newJMSException("Failed to broker message: "
          + messageID + " in container: " + e, e);
    } finally {
      try {
        if (ps != null) {
          ps.close();
        }
      } catch (SQLException IGNORE) {
      } finally {
        persistenceAdapter.returnConnection(c);
      }
    }
  }

  private String getConversationId(ActiveMQMessage message) {
    return StringUtils.isNotBlank(message.getJMSCorrelationID()) ? message
        .getJMSCorrelationID() : Utilities.generateConversationId();
  }

  /**
   * @see org.activemq.store.MessageStore#getMessage(org.activemq.service.MessageIdentity)
   */
  public ActiveMQMessage getMessage(MessageIdentity identity)
      throws JMSException {
    Object idToSearchBy = null;
    StringBuffer sql = new StringBuffer("SELECT Xml_Msg FROM Message_Queue");
    if (identity.getSequenceNumber() != null) {
      idToSearchBy = identity.getSequenceNumber();
      Logger.log(new DebugLogEvent(
          "Retrieving JMS message from persistent store with sequence number: "
              + idToSearchBy));
      sql.append(" WHERE Msg_Queue_ID = ?");
    } else {
      idToSearchBy = identity.getMessageID();
      Logger.log(new DebugLogEvent(
          "Retrieving JMS message from persistent store with JMS Message Id: "
              + idToSearchBy));
      sql.append(" WHERE Jms_Msg_ID = ?");
    }

    Connection c = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      c = persistenceAdapter.getConnection();

      ps = c.prepareStatement(sql.toString());
      ps.setObject(1, idToSearchBy);

      rs = ps.executeQuery();

      ActiveMQMessage message = null;
      if (rs.next()) {
        byte[] rsBytes = persistenceAdapter.getLobHandler().getBlobAsBytes(rs,
            1);
        WireFormat wireFormat = persistenceAdapter.getWireFormat();
        message = (ActiveMQMessage) wireFormat.fromBytes(rsBytes);
        message.setJMSMessageIdentity(identity);
        message.setJMSMessageID(identity.getMessageID());
      }
      return message;
    } catch (IOException e) {
      throw JMSExceptionHelper.newJMSException("Failed to broker message: "
          + identity.getMessageID() + " in container: " + e, e);
    } catch (SQLException e) {
      throw JMSExceptionHelper.newJMSException("Failed to broker message: "
          + identity.getMessageID() + " in container: " + e, e);
    } finally {
      try {
        if (rs != null)
          rs.close();
        if (ps != null)
          ps.close();
      } catch (SQLException IGNORE) {
      } finally {
        persistenceAdapter.returnConnection(c);
      }
    }
  }

  /**
   * @see org.activemq.store.MessageStore#removeMessage(org.activemq.message.MessageAck)
   */
  public void removeMessage(MessageAck ack) throws JMSException {
    String messageID = ack.getMessageID();

    Logger.log(new DebugLogEvent(
        "Removing JMS message from persistent store with JMS Message Id: "
            + messageID));
    String sql = "DELETE FROM Message_Queue WHERE Jms_Msg_Id = ?";

    Connection c = null;
    PreparedStatement ps = null;
    try {
      c = persistenceAdapter.getConnection();

      ps = c.prepareStatement(sql);
      ps.setString(1, messageID);

      if (ps.executeUpdate() != 1) {
        throw new JMSException("Could not delete message: " + messageID
            + " in container.");
      }
    } catch (SQLException e) {
      throw JMSExceptionHelper.newJMSException("Failed to broker message: "
          + messageID + " in container: " + e, e);
    } finally {
      try {
        if (ps != null) {
          ps.close();
        }
      } catch (SQLException IGNORE) {
      } finally {
        persistenceAdapter.returnConnection(c);
      }
    }
  }

  /**
   * @see org.activemq.store.MessageStore#removeAllMessages()
   */
  public void removeAllMessages() throws JMSException {
    Logger.log(new DebugLogEvent(
        "Removing all JMS messages from persistent store for broker: "
            + brokerServerName));
    String sql = "DELETE FROM Message_Queue WHERE Broker_ID = ?";

    Connection c = null;
    PreparedStatement ps = null;
    try {
      c = persistenceAdapter.getConnection();

      ps = c.prepareStatement(sql);
      ps.setString(1, brokerServerName);

      if (ps.executeUpdate() != 1) {
        throw new JMSException("Could not delete all messages in container.");
      }
    } catch (SQLException e) {
      throw JMSExceptionHelper.newJMSException(
          "Failed to broker remove all messages in container: " + e, e);
    } finally {
      try {
        if (ps != null) {
          ps.close();
        }
      } catch (SQLException IGNORE) {
      } finally {
        persistenceAdapter.returnConnection(c);
      }
    }
  }

  /**
   * @see org.activemq.store.MessageStore#recover(org.activemq.store.RecoveryListener)
   */
  public void recover(RecoveryListener listener) throws JMSException {
    Logger.log(new DebugLogEvent("Retrieving all JMS messages in destination '"
        + destinationName + "' from persistent store for broker: "
        + brokerServerName));
    String sql = "SELECT Msg_Queue_ID, Jms_Msg_ID FROM Message_Queue "
        + "WHERE Destination = ? AND Broker_ID = ? ORDER BY Msg_Queue_ID";

    Connection c = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
      c = persistenceAdapter.getConnection();

      ps = c.prepareStatement(sql);
      ps.setString(1, destinationName);
      ps.setString(2, brokerServerName);

      rs = ps.executeQuery();

      while (rs.next()) {
        long messageQueueId = rs.getLong(1);
        String messageId = rs.getString(2);
        listener.recoverMessage(new MessageIdentity(messageId, new Long(
            messageQueueId)));
      }

    } catch (SQLException e) {
      throw JMSExceptionHelper.newJMSException(
          "Failed to recover container. Reason: " + e, e);
    } finally {
      try {
        if (rs != null)
          rs.close();
        if (ps != null)
          ps.close();
      } catch (SQLException IGNORE) {
      } finally {
        persistenceAdapter.returnConnection(c);
      }
    }
  }

  /**
   * @see org.activemq.service.Service#start()
   */
  public void start() throws JMSException {
  }

  /**
   * @see org.activemq.service.Service#stop()
   */
  public void stop() throws JMSException {
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.1 2005/06/30 17:43:25
 * ggdavi Moved ag.aop, ag.config and ag.message packages under the ag.cf
 * package
 * 
 * Revision 1.4 2005/06/06 21:17:49 ggdavi Upgraded to ActiveMQ 3.1-M2
 * 
 * Revision 1.3 2005/06/02 21:01:39 ggdavi Corrected order of constructor
 * parameters (yeah, they're better than setters...) Revision 1.2 2005/05/20
 * 20:56:14 ggdavi Cleaned up some code after adding the
 * testAddMessageWithMissingConversationId test case Revision 1.1 2005/05/20
 * 14:53:03 ggdavi Initial version
 * 
 */