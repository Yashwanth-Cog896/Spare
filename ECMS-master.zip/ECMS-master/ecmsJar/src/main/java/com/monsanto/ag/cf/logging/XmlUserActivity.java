/*
 * XmlUserActivity was created on Mar 31, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.logging;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;

import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.domain.SystemEvent;
import com.monsanto.ag.cf.domain.UserActivity;
import com.monsanto.ag.cf.domain.UserActivityIncompleteException;
import com.monsanto.ag.security.ApplicationAuthenticator;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.DocumentBuilderException;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlStreamChunkAssembler;

/**
 * Represents loggable information about an XML message-based user activity.
 * 
 * @author ajbaldw
 * @version $Id: XmlUserActivity.java,v 1.35 2006-06-21 21:58:27 caggarw Exp $
 * @see SeedTrakInsourcingScope FC84i, FC84j, FC84k, FC84m
 */
public class XmlUserActivity extends UserActivity {

  public static final String STATUS_CODE_SUCCESS = "UserActivitySuccessful";
  public static final String STATUS_MESSAGE_SUCCESS = "User has successfully completed interaction with ";
  public static final String STATUS_MESSAGE_FAILURE = "An error occurred during user interaction with ";

  private XmlChunks inputXmlChunks;
  private XmlChunks outputXmlChunks;

  /**
   * Initializes the activity with information not found in an XML payload.
   * 
   * @param userId
   *          Authenticated identity of the current user
   * @param exchangeType
   *          Type of service being used
   * @param accountId
   *          Unique identifier of the business represented by the current user
   */
  public XmlUserActivity(String userId, String exchangeType, long accountId) {
    setUserId(userId);
    setExchangeType(exchangeType);
    setAccountId(accountId);
  }

  /**
   * Update UserActivity with values pulled from the request document.
   * 
   * @param inputXmlChunks
   *          Request XML documents
   * @param xmlMessageInformer
   *          XML message information provider
   * @param idTranslator
   *          Translates textual identifiers from the XML document into their
   *          numeric equivalent
   * @param idMapperDao
   *          Data Access Object used to map an SAP Id from the XML document to
   *          a corresponding Account Id (for example, when the user is a
   *          trusted application)
   */
  public void init(XmlChunks inputXmlChunks, XmlMessageInformer xmlMessageInformer, IdTranslator idTranslator,
      IdMapperDao idMapperDao) {
    if (xmlMessageInformer == null) {
      return;
    }

    this.inputXmlChunks = inputXmlChunks;
    XmlDocument inputDocument = (XmlDocument) inputXmlChunks.getLastChunk();

    try {
      updateAccountIdFromInputDocumentForTrustedApplicationUser(inputDocument, xmlMessageInformer, idTranslator,
          idMapperDao);

      String xpathStartTime = xmlMessageInformer.getXpathStartTime();
      String docStartTime = inputDocument.getNodeValueByXPath(xpathStartTime);
      setStartTime(XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(docStartTime));

      String xpathDataSource = xmlMessageInformer.getXpathDataSource();
      String docDataSource = inputDocument.getNodeValueByXPath(xpathDataSource);
      setDataSource(docDataSource);

      String xpathSoftwareVersion = xmlMessageInformer.getXpathSoftwareVersion();
      String docSoftwareVersion = inputDocument.getNodeValueByXPath(xpathSoftwareVersion);
      setSoftwareVersion(docSoftwareVersion);

      String xpathSeedYear = xmlMessageInformer.getXpathSeedYear();
      String docSeedYear = inputDocument.getNodeValueByXPath(xpathSeedYear);
      setSeedYear(docSeedYear);

      int docTransactionCount = countTransactions(inputXmlChunks, xmlMessageInformer);
      setTransactionCount(docTransactionCount);
    } catch (ParseException e) {
      Logger.log(new LoggableWarning(e.getMessage() + " for the Start Time value at position " + e.getErrorOffset()));
      throw new UserActivityIncompleteException(e.getMessage());
    }
  }

  private void updateAccountIdFromInputDocumentForTrustedApplicationUser(XmlDocument inputDocument,
      XmlMessageInformer xmlMessageInformer, IdTranslator idTranslator, IdMapperDao idMapperDao) {
    if (idTranslator == null || idMapperDao == null) {
      return;
    }

    if (isUserATrustedApplication()) {
      long accountId = getValidDealerAccountIdFromInputDocument(inputDocument, xmlMessageInformer, idTranslator,
          idMapperDao);
      if (accountId > 0) {
        setAccountId(accountId);
      }
    }
  }

  private boolean isUserATrustedApplication() {
    return (getAccountId() == ApplicationAuthenticator.TRUSTED_APPLICATION_ACCOUNT_ID);
  }

  private long getValidDealerAccountIdFromInputDocument(XmlDocument inputDocument,
      XmlMessageInformer xmlMessageInformer, IdTranslator idTranslator, IdMapperDao idMapperDao) {
    String xpathAccountId = xmlMessageInformer.getXpathAccountId();
    String dealerAccountId = inputDocument.getNodeValueByXPath(xpathAccountId);
    long accountId = idTranslator.parseAccountId(dealerAccountId);

    if (accountId == 0) {
      accountId = mapInputDocumentSapIdToAccountId(inputDocument, xmlMessageInformer, idTranslator, idMapperDao);
    }

    return accountId;
  }

  private long mapInputDocumentSapIdToAccountId(XmlDocument inputDocument, XmlMessageInformer xmlMessageInformer,
      IdTranslator idTranslator, IdMapperDao idMapperDao) {
    long accountId = 0;

    String xpathSapId = xmlMessageInformer.getXpathSapId();
    String dealerSapId = inputDocument.getNodeValueByXPath(xpathSapId);
    long sapId = idTranslator.parseSapId(dealerSapId);

    if (sapId != 0) {
      try {
        accountId = idMapperDao.findAccountIdBySAPId(dealerSapId);
      } catch (DataAccessException e) {
        Logger.log(new LoggableWarning(e));
      }
    }

    return accountId;
  }

  /**
   * Update UserActivity with values pulled from the response document.
   * 
   * @param outputXmlChunks
   *          Response XML documents
   * @param conversationId
   *          Unique identifier of this service process
   * @param xmlMessageInformer
   *          XML message information provider
   * @param serviceId
   *          Identifier of the service being used in this user-initiated
   *          activity
   */
  public void complete(XmlChunks outputXmlChunks, String conversationId, XmlMessageInformer xmlMessageInformer,
      String serviceId) {
    if (xmlMessageInformer == null) {
      return;
    }

    this.outputXmlChunks = outputXmlChunks;

    setEndTime(new Date());
    setConversationId(conversationId);

    if (getTransactionCount() == 0) {
      int docTransactionCount = countTransactions(outputXmlChunks, xmlMessageInformer);
      setTransactionCount(docTransactionCount);
    }

    String statusMessage = STATUS_MESSAGE_SUCCESS + serviceId;
    SystemEvent userEvent = new SystemEvent(getUserId(), getAccountId(), conversationId, new Date(),
        STATUS_CODE_SUCCESS, statusMessage);
    setEvent(userEvent);
  }

  // TODO Do we want to be able to force counting transactions in all documents?
  private int countTransactions(XmlChunks xmlChunks, XmlMessageInformer xmlMessageInformer) {
    int transactionCount = 0;

    String xpathTransaction = xmlMessageInformer.getXpathTransaction();
    XmlDocument lastXmlDocument = (XmlDocument) xmlChunks.getLastChunk();
    transactionCount = lastXmlDocument.getElementCountByXPath(xpathTransaction);

    if (transactionCount > 0) {
      int transactionCountFromPreviousChunks = (xmlChunks.getCount() - 1) * xmlMessageInformer.getChunkSize();
      transactionCount += transactionCountFromPreviousChunks;
    }

    return transactionCount;
  }

  /**
   * Update UserActivity with values pulled from the exception.
   * 
   * @param error
   *          Exception that occurred during service processing
   * @param serviceId
   *          Identifier of the service being used in this user-initiated
   *          activity
   */
  public void complete(Throwable error, String serviceId) {
    String conversationId = Utilities.generateConversationId();
    setEndTime(new Date());
    setConversationId(conversationId);

    String statusMessage = STATUS_MESSAGE_FAILURE + serviceId + ": " + error.getMessage();
    SystemEvent userEvent = new SystemEvent(getUserId(), getAccountId(), conversationId, new Date(), Utilities
        .getUnqualifiedClassName(error), statusMessage);
    setEvent(userEvent);
  }

  /**
   * Selects the input document to be stored in the log, if any.
   * <p>
   * TODO Return a Stream?
   * 
   * @param xmlMessageInformer
   *          Input XML message information provider
   * @return XML document to be stored, or
   *         {@link XmlDocument#NULL XmlDocument.NULL} if no document is to be
   *         stored
   */
  public XmlDocument getInputDocumentToStore(XmlMessageInformer xmlInformer) {
    return getDocumentToStore(xmlInformer, inputXmlChunks);
  }

  /**
   * Selects the output document to be stored in the log, if any.
   * <p>
   * TODO Return a Stream?
   * 
   * @param xmlMessageInformer
   *          Output XML message information provider
   * @return XML document to be stored, or
   *         {@link XmlDocument#NULL XmlDocument.NULL} if no document is to be
   *         stored
   */
  public XmlDocument getOutputDocumentToStore(XmlMessageInformer xmlInformer) {
    return getDocumentToStore(xmlInformer, outputXmlChunks);
  }

  private XmlDocument getDocumentToStore(XmlMessageInformer xmlMessageInformer, XmlChunks xmlChunks) {
    XmlDocument documentToStore = XmlDocument.NULL;

    String rootNodeName = xmlMessageInformer.getRootNodeNameOfDocumentToStore();
    if (StringUtils.isNotBlank(rootNodeName)) {
      String xpathTransaction = xmlMessageInformer.getXpathTransaction();

      try {
        XmlStreamChunkAssembler chunkAssembler = new XmlStreamChunkAssembler();
        if (rootNodeName.equals(getNameOfXmlChunksRootNode(xmlChunks))) {
          documentToStore = (XmlDocument) chunkAssembler.assemble(xmlChunks, xpathTransaction);
        }
      } catch (DocumentBuilderException e) {
        Logger.log(new LoggableWarning(e.getMessage()));
      }
    }

    return documentToStore;
  }

  private String getNameOfXmlChunksRootNode(XmlChunks xmlChunks) {
    if (xmlChunks == null || xmlChunks.isEmpty()) {
      return null;
    } else {
      XmlDocument xmlDocument = (XmlDocument) xmlChunks.getLastChunk();
      return xmlDocument.getRootElement().getUnqualifiedName();
    }
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.34 2005/12/01 19:34:31 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks
 * 
 * Revision 1.33 2005/11/21 22:40:54 ggdavi Moved ApplicationAuthenticator and
 * BeanAuthorizer (renamed to OperationAuthorizer) from
 * com.monsanto.ag.cf.security to com.monsanto.ag.security
 * 
 * Revision 1.32 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and
 * StAX implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects Revision 1.31 2005/08/26 16:26:09 ggdavi Javadoc
 * corrections
 * 
 * Revision 1.30 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.29 2005/08/12
 * 16:59:28 ggdavi In countTransactions, if no transactions appear in the last
 * document (which should have at least one if chunking succeeded), the method
 * returns 0; in getDocumentToStore, any DocumentBuilderException thrown by the
 * XmlDocument.assembleXmlDocumentFromChunks method is caught and logged, but
 * the method just returns a NULL XmlDocument Revision 1.28 2005/08/02 20:57:37
 * ggdavi Modified service interfaces, implementations and advice to support
 * message/document chunking Revision 1.27 2005/07/26 17:11:53 ggdavi
 * IdMapperDao now treats SAP Ids as text, since that is how the materialized
 * view treats it :-(
 * 
 * Revision 1.26 2005/07/25 21:01:29 ggdavi Added support for mapping between
 * SAP Id and Account Id Revision 1.25 2005/07/21 14:48:57 ggdavi Fleshed out
 * and refactored com.monsanto.ag.util to make more object-oriented, in that
 * most functionality has been pushed to the XmlDocument and XmlElement objects
 * Revision 1.24 2005/07/08 17:29:31 ggdavi Reordered constructor arguments; the
 * init method now uses the accountId value from the XML document, if it exists,
 * or the constructor argument value if it doesn't Revision 1.23 2005/06/13
 * 21:03:08 ggdavi Use getDocumentElement instead of getFirstChild to get
 * document root node Revision 1.22 2005/05/31 20:41:23 ggdavi Use SOAP faults
 * instead of a standard error document Revision 1.21 2005/05/17 20:25:03 ggdavi
 * Converted XmlMessageInformer from an interface with accessors only to a
 * fully-fledged bean class
 * 
 * Revision 1.20 2005/05/17 16:31:51 ggdavi Extracted ag.util.XmlDateTimeUtil
 * and ag.soa.ErrorDocument from ag.util.Utilities
 * 
 * Revision 1.19 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.18 2005/05/09 18:08:33 ggdavi Added userId to SystemEvent Revision
 * 1.17 2005/05/06 17:54:41 ggdavi Boatload of changes to accomodate change to
 * UserActivity (such as addition of SystemEvent field) and storing any
 * appropriate XML document Revision 1.16 2005/04/27 11:24:12 ggdavi complete
 * now calls getValidConversationId to ensure a conversation identifier is
 * generated if one is not found in the document Revision 1.15 2005/04/26
 * 21:27:09 ggdavi Added complete method Revision 1.14 2005/04/25 17:29:37
 * ggdavi Added setConversationId and setStartTime calls in init, based on new
 * XmlMessageInformer methods Revision 1.13 2005/04/22 16:01:20 ggdavi Renamed
 * XmlMessageInformer.getXPathTransactionCount to getXPathTransaction Revision
 * 1.12 2005/04/19 15:33:34 lsdenny converted int account id to long account id
 * 
 * Revision 1.11 2005/04/14 17:36:32 ggdavi Added traceability in Javadocs
 * 
 * Revision 1.10 2005/04/14 16:51:34 ggdavi Moved
 * ag.cf.logging.XmlUserActivityConfigurator to ag.cf.domain.XmlMessageInformer
 * 
 * Revision 1.9 2005/04/13 16:30:13 ggdavi Moved XPath methods to XPathUtil and
 * use superclass setter methods in init Revision 1.8 2005/04/12 19:26:39 ggdavi
 * Added accountId field to UserActivity Revision 1.7 2005/04/11 21:47:57 ggdavi
 * XPathUtil now has static methods
 * 
 * Revision 1.6 2005/04/08 21:56:42 ajbaldw Pulled out getNodeValue into
 * XPathUtils Revision 1.5 2005/04/08 18:10:15 ggdavi Renamed
 * UserActivityIncompleteException to UserActivityIncompleteException
 * 
 * Revision 1.4 2005/04/07 15:46:01 ggdavi Do not attempt to parse the XML
 * document if no configurator present
 * 
 * Revision 1.3 2005/04/05 21:37:18 ggdavi Changed based on use of
 * XmlMessageInformer interface Revision 1.2 2005/04/01 16:41:04 ajbaldw Moved
 * UserActivityIncompleteException to ag/cf/logging package.
 * 
 * Revision 1.1 2005/04/01 16:38:49 ajbaldw Refactored and moved these into
 * ag/cf/logging package.
 * 
 */
