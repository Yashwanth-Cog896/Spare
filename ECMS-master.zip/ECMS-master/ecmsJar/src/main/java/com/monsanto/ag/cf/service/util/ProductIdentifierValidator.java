package com.monsanto.ag.cf.service.util;

import com.monsanto.Util.StringUtils;

/**
 * Created by jtmurr on 11/3/2016.
 */
public class ProductIdentifierValidator {
    public boolean isProductIdentifierInvalid(String productIdentifier, String productIdentifierQualifier) {
        return productIdentifier == null || productIdentifierQualifier == null ||
                StringUtils.isEmpty(productIdentifier) || StringUtils.isEmpty(productIdentifierQualifier) ||
                "ZZ".equals(productIdentifierQualifier) ||
                ("UK".equals(productIdentifierQualifier) && productIdentifier.length() > 14) ||
                ("UP".equals(productIdentifierQualifier) && productIdentifier.length() > 12);
    }
}
