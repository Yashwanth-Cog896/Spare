package com.monsanto.ag.cf.dao;

import java.util.List;

import com.monsanto.ag.cf.domain.Conversation;

/**
 * Data Access Object for Ship Notices.
 * <p>
 * Since the Ship Notice XML documents are already stored in the database, via
 * the Activity Logging "aspect", we don't duplicate this voluminous data in
 * another table. Instead, we mimic the JMS message associating the Account Id
 * with the Conversation Id in a table that can be joined with the Activity
 * tables to retrieve the desired EDNs. The
 * {@link com.monsanto.ag.cf.domain.Conversation Conversation} class is used to
 * represent the Ship Notices publication message.
 * 
 * @author Gareth Davies
 * @version $Id: ShipNoticePublicationDao.java,v 1.1 2005/07/12 18:31:58 ggdavi
 *          Exp $
 */
public interface ShipNoticePublicationDao {

  public List findShipNoticePublicationsByDealer(long accountId);

  public void removeShipNoticePublication(Conversation conversation);

  public void storeShipNoticePublication(Conversation shipNoticePublication, String deliveryId);

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/07/25 20:56:39  ggdavi
 * Added find* and remove* methods
 * Revision 1.1 2005/07/12 18:31:58
 * ggdavi Initial version
 * 
 */