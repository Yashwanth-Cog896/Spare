/*
 * AtfCoeProductDao was created on Jun 20, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.cf.dao.jdbc.BaseJdbcDao;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.PersistentStoreCachedDBConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

/**
 * Implementation of the Product Data Access Object that uses the ATF COE
 * persistence framework.
 * 
 * @author Gareth Davies
 * @version $Id: AtfCoeProductDao.java,v 1.5 2009/07/21 20:03:03 mkuchip Exp $
 */
public class AtfCoeProductDao extends BaseJdbcDao implements ProductDao {

    private static final String TEMPLATE_ERROR_MESSAGE = "Error retrieving product {0}: {1}\n";
    private String requestingEntity;
    private Date lastModifiedDate;
    private String category;
    private Set brands;
    private String sql;
    private HashMap< String, AbstractListAdder > listAdders;

    private static final String CLASS_CODE_CHEMICAL = "H";
    private static final String CLASS_CODE_EQUIPMENT = "N";
    private static final String CLASS_CODE_SEED = "D";
    private static final String CLASS_CODE_SEED_TREATMENT = "A";
  /**
   * see com.monsanto.ag.ecg.dao.ProductDao#findProductsByDateCategoryBrand(Date,
   *      String, Set, Boolean)
   */
    public List findProductsByDateCategoryBrand( String requestingEntity, Date lastModifiedDate, String category, Set brands )
        throws WrappingException {

        Logger.traceEntry(new Object[] { lastModifiedDate, category, brands });

        this.requestingEntity = requestingEntity;
        this.lastModifiedDate = lastModifiedDate;
        this.category = category;
        this.brands = brands;

        ProductQueryBuilder productQueryBuilder = ProductQueryBuilderFactory.createProductQueryBuilder( requestingEntity,
                                                                                                        lastModifiedDate,
                                                                                                        category,
                                                                                                        brands );
        productQueryBuilder.createNewProductQuery();
        productQueryBuilder.buildQuery();

        sql = productQueryBuilder.getProductQuery().getQuery();

        listAdders = new HashMap< String, AbstractListAdder >();
        listAdders.put( CLASS_CODE_SEED, new SeedProductListAdder() );
        listAdders.put( CLASS_CODE_CHEMICAL, new ChemicalProductListAdder() );
        listAdders.put( CLASS_CODE_EQUIPMENT, new EquipmentProductListAdder() );
        listAdders.put(CLASS_CODE_SEED_TREATMENT, new SeedTreatmentProductListAdder());
        PersistentStoreConnection conn = null;
        try {

            Connection connection = getDataSource().getConnection();
            conn = new PersistentStoreCachedDBConnection( connection );

            return find( conn );
        }
        catch( SQLException sQLException ){

            throw new WrappingException( sQLException );
        }
        finally {

            if ( conn != null ) {

                conn.close();
                conn = null;
            }
        }
    }

    private List find( PersistentStoreConnection conn ) throws WrappingException {

        List products = new ArrayList();

        Logger.log( new LoggableInfo( "Retrieving products from the ECG database" ) );
        PersistentStoreResultSet rs = null;
        PersistentStoreStatement ps = null;
        try {

            ps = conn.prepareStatement( sql );
            setPreparedStatementParameterValues( ps );

            rs = ps.executeQuery();
            products = processProductQueryResult( rs );
        }
        finally {

            if ( rs != null ) {

                rs.close();
                rs = null;
            }
            if ( ps != null ) {

                ps.close();
                ps = null;
            }
        }

        Logger.log(new LoggableInfo("Retrieved products from the ECG database: " + products.size()));

        return products;
    }

    private List< Product > processProductQueryResult ( PersistentStoreResultSet rs ) throws WrappingException {

        PersistentStoreResultSetFwdIterator iter = rs.getForwardIterator();
        Product product = null;
        StringBuffer badProductMessages = new StringBuffer();
        List< Product > products = new ArrayList< Product >();
        int rowCounter = 0;

        while( iter.next() ) {

            if ( ++rowCounter % 100 == 1 ) {

                Logger.log( new DebugLogEvent( "Retrieving products " + rowCounter + " - " + ( rowCounter + 99 ) ) );
            }
            String classCode = iter.getString( "product_class_id" );

            try {

                listAdders.get( classCode ).addProductToList( products, iter, product );
            }
            catch ( IllegalArgumentException e ) {

                String errorMessage = MessageFormatter.format( TEMPLATE_ERROR_MESSAGE, getProductId( iter ), e.getMessage() );
                badProductMessages.append( errorMessage );
            }
        }

        if ( badProductMessages.length() > 0 ) {

            Logger.log( new LoggableError( badProductMessages.toString() ) );
        }
        return products;
    }

    private String getProductId( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return new Integer( iter.getInt( "prod_id" ) ).toString();
    }

    private void setPreparedStatementParameterValues( PersistentStoreStatement ps ) throws WrappingException {

        int paramCounter = 1;
        if ( lastModifiedDate != null ) {

            ps.setParam( paramCounter++, lastModifiedDate );
        }
        if ( brands != null ) {

            for ( Iterator itBrand = brands.iterator(); itBrand.hasNext(); ) {

                String brand = ( String ) itBrand.next();
                ps.setParam( paramCounter++, brand.trim().toUpperCase() );
            }
        }
    }
}

/*
 * $Log: AtfCoeProductDao.java,v $
 * Revision 1.5  2009/07/21 20:03:03  mkuchip
 * Adding new fields for Acceleron Treated products in Productlist_2 and ProductLite_2 versions
 *
 * Revision 1.4  2008/09/09 16:25:04  rwspeh
 * *** empty log message ***
 *
 * Revision 1.3  2008/08/28 17:54:12  rwspeh
 * PCR0189657
 *
 * Revision 1.2  2008/07/29 21:30:14  dddoni
 * ECG Service code Migrated  to ECMS.
 *
 * Revision 1.1  2008/07/18 21:30:01  gjkell
 * from ECG
 *
 * Revision 1.25  2008/07/10 19:26:23  gjkell
 * GOA II Interstate
 *
 * Revision 1.24  2006/11/29 23:07:53  caggarw
 * changed prod_code to prod_id (ECG changes)
 *
 * Revision 1.23  2006/09/11 18:44:58  caggarw
 * Changed SELECT query to include order by PROD_CODE, RR_UOM_CODE. It needed to be added after the Oracle 10g upgrade.
 *
 * Revision 1.22  2006/08/07 16:09:59  caggarw
 * Mapping changes- Trait decriptions now may to display_descr field in ECG instead of chemistry_descr
 *
 * Revision 1.21  2006/05/24 18:28:12  caggarw
 * added processor_code to packaging under field userDefinedField1 to Processing
 * Revision 1.20 2006/03/11 07:27:01 mecoru
 * WrappingException import changed from dataservices to Util.Exceptions: Done
 * by automated script
 * 
 * Revision 1.19 2005/09/09 17:59:44 ggdavi Fixed equipment and seed packaging
 * names and descriptions to not append a null if the LEGAL_DESCR_2 column is
 * null (TT00229) Revision 1.18 2005/08/24 14:36:24 ggdavi The
 * getLastModifiedDateTimeWhereClause method now uses greater than instead of
 * greater than or equal to (TT 00169)
 * 
 * Revision 1.17 2005/08/19 15:15:17 ggdavi Modified to support different types
 * of products; retrieve brand from the SEED_COMPANY_BRAND_NAME column instead
 * of the BRAND_NAME column Revision 1.16 2005/08/09 20:48:37 ggdavi Added the
 * value of the prod_code column to the per-row error message for clarity (in
 * case variety and treatment code are null...) Revision 1.15 2005/08/09
 * 18:36:34 ggdavi Fixed error message template to not escape parameter braces!
 * 
 * Revision 1.14 2005/08/05 23:00:55 ggdavi Products are grouped by variety (aka
 * ACRONYM) and treatment code Revision 1.13 2005/07/28 15:47:50 ggdavi Added
 * ActionRequest attribute to various Product document elements; mapped the
 * PackageLevelCode and CheckDigit elements to the GTIN database column; only
 * send one error email per ProductUpdate document, containing all
 * product-specific errors Revision 1.12 2005/07/14 15:16:26 ggdavi Fixed
 * infinite for loop in getBrandsWhereClause...
 * 
 * Revision 1.11 2005/07/08 21:47:48 ggdavi Remove unused variables
 * 
 * Revision 1.10 2005/07/05 21:02:10 ggdavi Added an activeFlag parameter to
 * findProductsByDateCategoryBrand; changed GRADE_SIZE_DESCR column references
 * to GRADE_SIZE_DESC Revision 1.9 2005/06/30 18:28:02 ggdavi Added check for
 * null column value in getFloat
 * 
 * Revision 1.8 2005/06/30 17:48:45 ggdavi Fixed loop debug statements
 * 
 * Revision 1.7 2005/06/30 16:44:46 ggdavi Added debugging statements every 100
 * items Revision 1.6 2005/06/29 17:12:19 ggdavi Modified SQL to convert package
 * and measurement units of measurement codes to Un-Rec-20 format Revision 1.5
 * 2005/06/28 16:47:59 ggdavi Updated SQL statement with full column list; added
 * per-row exception handling that will simply log (and email) errors but
 * continue processing the resultset Revision 1.4 2005/06/27 23:08:50 ggdavi
 * Added bad parameter tests and fixed problem with empty set of brands Revision
 * 1.3 2005/06/27 22:01:51 ggdavi Implemented Revision 1.2 2005/06/23 16:15:16
 * ggdavi Replaced getProducts method with findProductsByDateCategoryBrand
 * Revision 1.1 2005/06/20 20:11:52 ggdavi Initial version
 * 
 */