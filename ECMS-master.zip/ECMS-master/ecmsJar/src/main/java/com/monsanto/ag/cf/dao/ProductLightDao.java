/*
 * ProductLightDao was created on Oct 1, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Data Access Object for ProductLight.
 * @author Chetna Aggarwal
 * @version $Id: ProductLightDao.java,v 1.3 2008-09-11 01:28:00 rwspeh Exp $
 */
public interface ProductLightDao {
  
  public List findProductsLightByDateCategoryBrand(Date lastModifiedDate,
      String category, Set brands, Boolean activeFlag) throws WrappingException;
  
  public List findProductsLightByDateCategoryBrandForOtherSeedBrands(Date lastModifiedDate, String category, Set brandsForDealer,
		    Set brandsForDealerAddedSinceLastDxDate,
		    Boolean activeFlag) throws WrappingException;
}
