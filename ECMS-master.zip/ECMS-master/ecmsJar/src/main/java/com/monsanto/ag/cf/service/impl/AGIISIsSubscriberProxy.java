package com.monsanto.ag.cf.service.impl;

import java.io.StringReader;

import org.w3c.dom.Document;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.cf.domain.AGIISSubscriberResults;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.xml.DocumentBuilderException;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocument;

/**
 * Request and Response for AGISS Is Subscriber service 
 * 
 *POST /Services/Search.asmx HTTP/1.1
 *Host: www.agiis.org
 *Content-Type: text/xml; charset=utf-8
 *Content-Length: length
 *SOAPAction: "http://www.agiis.org/Services/Search/IsAGIISSubscriber"
 *
 *<?xml version="1.0" encoding="utf-8"?>
 *<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 *  <soap:Body>
 *    <IsAGIISSubscriber xmlns="http://www.agiis.org/Services/Search/">
 *     <IdentifierType>EBID or HPID or GLN</IdentifierType>
 *     <IdentifierValue>string</IdentifierValue>
 *     </IsAGIISSubscriber>
 * </soap:Body>
 *</soap:Envelope>
 *
 *
 *HTTP/1.1 200 OK
 *Content-Type: text/xml; charset=utf-8
 *Content-Length: length
 *
 *<?xml version="1.0" encoding="utf-8"?>
 *<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 *  <soap:Body>
 *    <IsAGIISSubscriberResponse xmlns="http://www.agiis.org/Services/Search/">
 *      <IsAGIISSubscriberResult>
 *        <IsSubscriber>boolean</IsSubscriber>
 *        <IsActiveSubscriber>boolean</IsActiveSubscriber>
 *        <IsSubscriberOwnedLocation>boolean</IsSubscriberOwnedLocation>
 *        <IsActiveSubscriberOwnedLocation>boolean</IsActiveSubscriberOwnedLocation>
 *      </IsAGIISSubscriberResult>
 *    </IsAGIISSubscriberResponse>
 *  </soap:Body>
 *</soap:Envelope>
 */

public class AGIISIsSubscriberProxy extends ServiceProxySupport {
	private AGIISLoginProxy loginProxy;
	private AGIISLogoffProxy logoffProxy;	
	private XmlDocumentBuilder xmlDocumentBuilder;
	private static final String AGIISIsSubscriberSoapHeader = "http://www.agiis.org/Services/Search/IsAGIISSubscriber";

	public AGIISSubscriberResults checkIsSubscriberValid(String subscriberId) {
		AGIISSubscriberResults results = new AGIISSubscriberResults();
		results.setServiceAvailable(loginProxy.loginToAgiis());
		if (!results.isServiceAvailable()) {return results;}
		Logger.log(new LoggableInfo("Checking to see if subscriber " + subscriberId + " is a vaild AGIIS subscriber"));
		ServiceInput isSubscriberInput = new ServiceInput(buildInputDocument(subscriberId));
		isSubscriberInput.setSoapActionHeader(AGIISIsSubscriberSoapHeader);
		isSubscriberInput.setOverrideResponseChunking(true);		
		ServiceOutput output = soaClient.call(serviceId, isSubscriberInput);
		XmlDocument loginOutputDoc = output.getXmlChunks().getXmlDocumentChunk(xmlDocumentBuilder, 0);
		setIsSubscriberResults(results, loginOutputDoc);
		logoffProxy.logoffAgiis();
	    return results;		
	}

	private void setIsSubscriberResults(AGIISSubscriberResults results,	XmlDocument loginOutputDoc) {
		XmlElement subscriberSoapElement = loginOutputDoc.selectElementByXPath("//soap:Envelope/soap:Body");
		XmlElement isAGIISSubscriberResponse  = subscriberSoapElement.getChild("IsAGIISSubscriberResponse");
		XmlElement isAGIISSubscriberResult = isAGIISSubscriberResponse.getChild("IsAGIISSubscriberResult");		
		XmlElement isActiveSubscriber = isAGIISSubscriberResult.getChild("IsActiveSubscriber");		
		XmlElement isSubscriber = isAGIISSubscriberResult.getChild("IsSubscriber");
		results.setActiveSubscriber(Boolean.valueOf(isActiveSubscriber.getText()).booleanValue());
		results.setSubscriber(Boolean.valueOf(isSubscriber.getText()).booleanValue());
	}

	private XmlDocument buildInputDocument(String subscriberId) {
		String subscriberLoginMessage = 
			" <IsAGIISSubscriber xmlns=\"http://www.agiis.org/Services/Search/\" xmlns:agiis=\"http://www.agiis.org/Services/Search/\">" +
			"   <IdentifierType>EBID</IdentifierType> " +
			"   <IdentifierValue>" + subscriberId + "</IdentifierValue> " +
			" </IsAGIISSubscriber> ";
	    try {
	  	  	Document document = DOMUtil.newDocument(new StringReader(subscriberLoginMessage));
	        return new DOMUtilXmlDocument(document);
	      } catch (Exception e) {
	        throw new DocumentBuilderException(e.getMessage());
	      }
	}
	
	public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
		this.xmlDocumentBuilder = xmlDocumentBuilder;
	}

	public void setLoginProxy(AGIISLoginProxy loginProxy) {
		this.loginProxy = loginProxy;
	}
	public void setLogoffProxy(AGIISLogoffProxy logoffProxy) {
		this.logoffProxy = logoffProxy;
	}	
}