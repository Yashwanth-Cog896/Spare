package com.monsanto.ag.cf.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.ChemicalEquipment;
import com.monsanto.ag.cf.domain.Packaging;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.ag.cf.domain.SeedEquipment;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/21/13
 * Time: 2:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class EquipmentProductListAdder extends AbstractListAdder {

    private static final String MARKET_SEGMENT_CHEMICAL = "CH";
    private static final String MARKET_SEGMENT_SEED = "ST";

    public Product addProductToList( List products, PersistentStoreResultSetFwdIterator iter,
                                                         Product lastProductRetrieved ) throws WrappingException{

        String marketSegment = iter.getString( "mkt_seg_code" );
        Product product = null;

        if ( MARKET_SEGMENT_SEED.equals( marketSegment ) ) {

            product = new SeedEquipment( getEcListMaterial( iter ),
                                         getActiveFlag( iter ),
                                         getAddedDate( iter ),
                                         getLastModifiedDate( iter ),
                                         getProductId( iter ) );
        }
        else if ( MARKET_SEGMENT_CHEMICAL.equals( marketSegment ) ) {

            product = new ChemicalEquipment( getEcListMaterial( iter ),
                                             getActiveFlag( iter ),
                                             getAddedDate( iter ),
                                             getLastModifiedDate( iter ),
                                             getProductId( iter ) );
        }
        products.add( product );

        if( product != null ){

            addPackagingToProduct( product, iter );
        }

        return product;
    }

    private void addPackagingToProduct( Product product, PersistentStoreResultSetFwdIterator iter ) throws WrappingException{

        Packaging packaging = mapRowToEquipmentPackaging( iter );
        product.addPackaging( packaging );
        if ( packaging != null ) {

            com.monsanto.ag.cf.domain.PackageConfiguration configuration = mapRowToPackageConfiguration( iter );
            packaging.addConfiguration( configuration );
        }
    }

    private Packaging mapRowToEquipmentPackaging( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        String packageName = iter.getString( "legal_descr_1" );
        if ( StringUtils.isNotEmpty( iter.getString( "legal_descr_2" ) ) ) {

            packageName += " " + iter.getString( "legal_descr_2" );
        }

        return new Packaging( getBoolean( iter, "pkg_active_flag" ),
                              getAddedDate( iter ),
                              getLastModifiedDate( iter ),
                              iter.getString( "gtin" ),
                              packageName,
                              packageName,
                              getBaseQuantity( iter ),
                              getUnRec20RrUomCode( iter ),
                              false,
                              iter.getString( "grade_size_desc" ),
                              null,
                              iter.getString( "order_uom_id" ),
                              iter.getString( "treatment_code" ) );
    }
}