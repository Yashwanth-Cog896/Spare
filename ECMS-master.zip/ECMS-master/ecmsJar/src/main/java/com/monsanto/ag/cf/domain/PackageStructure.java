/*
 * PackageStructure was created on Oct 1, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Reprsents the information in a Package.
 * 
 * @author Chetna Aggarwal
 * @version $Id: PackageStructure.java,v 1.3 2008-09-09 16:25:04 rwspeh Exp $
 */
public class PackageStructure {

  private long unitQty;
  private long prodUnitConv;
  private String gtin;
  private String uomCode;
  private String orderUomId;

  public PackageStructure(long prodUnitConv, String gtin, String uomCode, long unitQty, String orderUomId) {
    super();
    this.prodUnitConv = prodUnitConv;
    this.gtin = gtin;
    this.uomCode = uomCode;
    this.unitQty = unitQty;
    this.orderUomId = orderUomId;
  }

  
  public String getGtin() {
    return gtin;
  }

  public long getProdUnitConv() {
    return prodUnitConv;
  }

  public String getUomCode() {
    return uomCode;
  }
  
  public long getUnitQty() {
	return unitQty;
  }

public boolean equals(Object obj) {
    if (!(obj instanceof PackageStructure)) {
      return false;
    }
    PackageStructure rhs = (PackageStructure) obj;
    return new EqualsBuilder().append(prodUnitConv, rhs.getProdUnitConv()).append(gtin, rhs.getGtin()).append(uomCode,
        rhs.getUomCode()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(29, 31).append(prodUnitConv).append(gtin).append(uomCode).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).append(prodUnitConv).append(gtin).append(uomCode)
        .toString();
  }

  public String getOrderUomId() {
		return orderUomId;
  }  
  
}
