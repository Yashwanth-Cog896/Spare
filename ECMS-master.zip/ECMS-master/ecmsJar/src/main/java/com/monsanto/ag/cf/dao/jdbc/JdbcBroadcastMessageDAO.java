package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.BroadcastMessageDAO;
import com.monsanto.ag.cf.domain.BroadcastMessage;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableInfo;

import java.util.List;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.ResultSet;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowCallbackHandler;

/**
 * Created by IntelliJ IDEA.
 * User: svadlam
 * Date: May 18, 2010
 * Time: 3:25:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class JdbcBroadcastMessageDAO extends BaseJdbcDao implements BroadcastMessageDAO{

    public List getMessages(String userId, String seedYear, String appDescr) {
        Logger.log(new LoggableInfo(
        "Retrieving broadcast messages from DB with User Id: '"
            + userId +"' and seedYear: '"+seedYear+"'"));
         String sql = " SELECT popup_id, NAME, page, MESSAGE, POST, EXPIRE " +
                 " FROM agcc.popup_message " +
                 " WHERE popup_id IN (SELECT popup_id " +
                 " FROM agcc.popup_assignment WHERE application_id = " +
                 " (SELECT application_id FROM agcc.application WHERE application_descr = ?)) " +
                 " AND popup_id NOT IN (SELECT popup_id FROM agcc.popup_visited WHERE user_id = ?) " +
                 " AND EXPIRE >= SYSDATE AND POST <= SYSDATE " +
                 " AND popup_id IN (SELECT popup_id FROM agcc.popup_messg_to_seedyear " +
                 " WHERE seed_year = ?)";
    Object[] values = new Object[] {appDescr,userId,seedYear };
        final List<BroadcastMessage> messageList = new ArrayList();
    getJdbcTemplate().query(sql, values,new RowCallbackHandler() {
			public void processRow(ResultSet rs) throws SQLException {
                BroadcastMessage message = new BroadcastMessage(rs.getString("popup_id"),
                        rs.getString("NAME"),rs.getString("MESSAGE"));
                messageList.add(message);
			}
		});
     Logger.log(new LoggableInfo(
        "size of Retrieved broadcast messages from DB: "+messageList.size()));
     return messageList;
    }

    public boolean checkPopupIdValidAndNotVisited(String userId,String popupId) {
        String sql="select count(*) from AGCC.POPUP_MESSAGE MESSAGE where MESSAGE.POPUP_ID = ?" +
                "and popup_id not in(select popup_id from agcc.POPUP_VISITED where user_id = ?)" ;
        Object[] values = new Object[] {popupId,userId };
        int count = getJdbcTemplate().queryForInt(sql,values);
        return count == 0 ? false: true;
    }


    public int insertPopupVisited(String userId,String popupId) {
        String sql = "INSERT INTO agcc.popup_visited" +
                " (popup_id, user_id, row_task_id, row_entry_date, row_modify_date) " +
                " VALUES (?, ?, 'FSWEBSERVICES', SYSDATE, SYSDATE)";
        Object[] values = new Object[] {popupId,userId };
        return getJdbcTemplate().update(sql,values);
    }
}
