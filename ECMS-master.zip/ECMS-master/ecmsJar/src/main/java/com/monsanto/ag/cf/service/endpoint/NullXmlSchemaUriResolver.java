/*
 * NullXmlSchemaUriResolver was created on Sep 6, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.service.endpoint;

import com.monsanto.ag.soa.ServiceException;

/**
 * Null Object implementation of the XmlSchemaUriResolver interface.
 * 
 * @author Chetna Aggarwal
 * @version $Id: NullXmlSchemaUriResolver.java,v 1.1 2006-05-08 14:17:56 caggarw Exp $
 */
public class NullXmlSchemaUriResolver implements XmlSchemaUriResolver {

  /**
   * @see com.monsanto.ag.cf.soapint.XmlSchemaUriResolver#resolve(java.lang.String,
   *      java.lang.String)
   */
  public String resolve(String schemaRegistrySpec, String namespaceUri)
      throws ServiceException {
    return null;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/11/09 18:45:44  ggdavi
 * Initial version
 *
 * Revision 1.1  2005/11/07 20:41:03  ggdavi
 * Moved from soapint.axis to soapint, since shared functionality with XFire implementation
 * Revision 1.1 2005/10/27 20:37:30
 * caggarw Replaced DocumentValidators with SchemaUriResolvers Revision 1.1
 * 2005/10/20 21:47:05 caggarw Initial Version
 * 
 * Revision 1.1 2005/09/06 21:09:07 ggdavi XmlSchemaUriResolver is now an
 * interface with two implementations, WsdlDocumentValidator (the original
 * class, renamed) and AlwaysTrueDocumentValidator (essentially a Null Object,
 * skipping validation). JaxRpcEndpoint pulls the implementation from the Spring
 * application context and passes the current MessageContext as an argument to
 * the validateXmlDocument method along with the XmlDocument.
 * 
 */