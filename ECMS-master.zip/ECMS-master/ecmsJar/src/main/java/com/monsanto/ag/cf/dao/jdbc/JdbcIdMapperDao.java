/*
 * JdbcAccountDao was created on Jul 20, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.IdMapperDao;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

/**
 * Spring JDBC implementation of the IdMapper DAO.
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcIdMapperDao.java,v 1.4 2007-07-06 23:07:40 caggarw Exp $
 */
public class JdbcIdMapperDao extends BaseJdbcDao implements IdMapperDao {

  public String findSAPIdByAccountId(long accountId) throws IncorrectResultSizeDataAccessException {
    String sql = "SELECT DISTINCT ALIAS_ID FROM ACCT_XREF_MV WHERE"
        + " ACCT_ID = ? AND SYSTEM_TYPE_CODE = 'SAP' AND ACTIVE_FLAG = 'Y'";
    Object[] parameters = new Object[] { new Long(accountId) };
    return (String) getJdbcTemplate().queryForObject(sql, parameters, String.class);
  }

  public long findAccountIdByEBID(String EBID) {
    String sql = "SELECT DISTINCT ACCT_ID FROM ACCT_XREF_MV WHERE"
        + " ALIAS_ID = ? AND SYSTEM_TYPE_CODE = 'IC' AND ACTIVE_FLAG = 'Y'";
    Object[] parameters = new Object[] { EBID };
    return getJdbcTemplate().queryForLong(sql, parameters);
  }
  
  public long findAccountIdBySAPId(String sapId) {
    String sql = "SELECT DISTINCT ACCT_ID FROM ACCT_XREF_MV WHERE"
        + " ALIAS_ID = ? AND SYSTEM_TYPE_CODE = 'SAP' AND ACTIVE_FLAG = 'Y'";
    Object[] parameters = new Object[] { sapId };
    return getJdbcTemplate().queryForLong(sql, parameters);
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/07/26 17:11:53  ggdavi
 * IdMapperDao now treats SAP Ids as text, since that is how the materialized view treats it :-(
 * Revision 1.2 2005/07/21 18:21:44 ggdavi The
 * findAccountIdBySAPId method now expects a long parameter
 * 
 * Revision 1.1 2005/07/21 15:58:07 caggarw IdMapperDao to get SAPId and
 * AccountId from acct_xref_mv table
 * 
 */
