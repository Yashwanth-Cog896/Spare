package com.monsanto.ag.cf.domain;

import com.monsanto.ag.util.Entity;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.Date;

/**
 * Created by JTMURR on 5/20/2016.
 */
public class InventoryProductDetails {
    private Date date;
    private String gtin;
    private String gtinQualifier;
    private String quantity;
    private String quantityQualifier;
    private String orderType;
    private String productUom;
    private AgencyConverter agencyConverter;
    private boolean badData;

    public InventoryProductDetails(Date date, String gtin, String gtinQualifier, String quantity,
                                   String quantityQualifier, String orderType, String productUom,
                                   AgencyConverter agencyConverter) {
        this.date = date;
        this.gtin = gtin;
        this.gtinQualifier = gtinQualifier;
        this.quantity = quantity;
        this.quantityQualifier = quantityQualifier;
        this.orderType = orderType;
        this.productUom = productUom;
        this.agencyConverter = agencyConverter;
        checkData();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getGtinQualifier() {
        return gtinQualifier;
    }

    public void setGtinQualifier(String gtinQualifier) {
        this.gtinQualifier = gtinQualifier;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getQuantityQualifier() {
        return quantityQualifier;
    }

    public void setQuantityQualifier(String quantityQualifier) {
        this.quantityQualifier = quantityQualifier;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getProductUom() {
        return productUom;
    }

    public void setProductUom(String productUom) {
        this.productUom = productUom;
    }

    public boolean isBadData() {
        return badData;
    }

    public void setBadData(boolean badData) {
        this.badData = badData;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(
                super.toString()).append("gtin", gtin).append("gtinQualifier", gtinQualifier)
                .append("quantity", quantity).append("quantityQualifier", quantityQualifier)
                .append("date", date).append("orderType", orderType).append("productUom", productUom)
                .toString();
    }

    private void checkData() {
        badData = getOrderType() == null || getProductUom() == null|| getDate() == null;
    }
}
