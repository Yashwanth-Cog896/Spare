/*
 * BroadcastMessage was created on May 19, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;


/**
 * Represents information about a message that is broadcast to the user
 * community.
 * 
 * @author Gareth Davies
 * @version $Id: BroadcastMessage.java,v 1.4 2005-08-26 16:10:56 ggdavi Exp $
 */
public class BroadcastMessage extends Entity {

  private String title;
  private String text;

  public BroadcastMessage() {
  }

  public BroadcastMessage(String id, String title, String text) {
    setId(id);
    this.title = title;
    this.text = text;
  }

  public String getTitle() {
    return title;
  }

  public String getText() {
    return text;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof BroadcastMessage)) {
      return false;
    }
    BroadcastMessage rhs = (BroadcastMessage) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(title,
        rhs.getTitle()).append(text, rhs.getText()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 17).appendSuper(super.hashCode()).append(
        title).append(text).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(
        super.toString()).append("title", title).append("text", text)
        .toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/06/20 17:12:36  ggdavi
 * Moved Entity and Identifiable back to ag.cf.domain from ag.domain (sorry about that...)
 *
 * Revision 1.2  2005/06/20 16:40:27  ggdavi
 * Moved Entity and Identifiable from ag.cf.domain to ag.domain
 *
 * Revision 1.1  2005/05/20 20:51:36  ggdavi
 * Initial version
 *
 */