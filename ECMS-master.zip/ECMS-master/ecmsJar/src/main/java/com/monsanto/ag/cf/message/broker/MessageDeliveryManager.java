package com.monsanto.ag.cf.message.broker;

import javax.jms.JMSException;

import org.activemq.message.ActiveMQMessage;
import org.activemq.service.DeadLetterPolicy;
import org.activemq.service.RedeliveryPolicy;

import EDU.oswego.cs.dl.util.concurrent.SynchronizedBoolean;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;

/**
 * Class to support the BrokerAwareEndpointWorker with Delivery Management.
 * @author Chetna Aggarwal
 * @version $Id: MessageDeliveryManager.java,v 1.2 2006-01-17 21:40:55 caggarw Exp $
 */
public class MessageDeliveryManager {

  private static final int SLEEP_BREAKUP_TIME = 500;
  private RedeliveryPolicy redeliveryPolicy;
  private DeadLetterPolicy deadLetterPolicy;

  public MessageDeliveryManager(DeadLetterPolicy deadLetterPolicy,
      RedeliveryPolicy redeliveryPolicy) {
    this.deadLetterPolicy = deadLetterPolicy;
    this.redeliveryPolicy = redeliveryPolicy;

  }

  public boolean checkMessageDeliverable(ActiveMQMessage message,
      String queueName, SynchronizedBoolean stopping) throws JMSException {
    if (message.getJMSRedelivered()) {
      if (isMessageDead(message)) {
        sendToDeadLetterQueue(message, queueName);
        return false;
      } else {
        return sleepBeforeRedelivery(message, queueName, stopping);
      }
    } else {
      return true;
    }
  }

  private boolean isMessageDead(ActiveMQMessage message) {
    return message.getDeliveryCount() > redeliveryPolicy
        .getMaximumRetryCount();
  }

  private void sendToDeadLetterQueue(ActiveMQMessage message, String queueName)
      throws JMSException {
    Logger.log(new DebugLogEvent("Message to queue '" + queueName
        + "' with correlation Id '" + message.getJMSCorrelationID()
        + "' reached maximum Redelivery Policy retry count "
        + redeliveryPolicy.getMaximumRetryCount()));
    deadLetterPolicy.sendToDeadLetter(message);
  }

  private boolean sleepBeforeRedelivery(ActiveMQMessage message,
      String queueName, SynchronizedBoolean stopping) {
    Logger.log(new DebugLogEvent("Redelivering message with correlation Id '"
        + message.getJMSCorrelationID() + "' to queue '" + queueName
        + "', attempt #" + message.getDeliveryCount()));
    long totalSleepTime = calculateSleepTimeBeforeRedelivery(message
        .getDeliveryCount());

    try {
      Logger.log(new DebugLogEvent("Sleeping for " + totalSleepTime
          + " ms before redelivery attempt #" + message.getDeliveryCount()));
      long currentSleepTime = 0;
      while (!stopping.get() && currentSleepTime < totalSleepTime) {
        Thread.sleep(SLEEP_BREAKUP_TIME);
        currentSleepTime += SLEEP_BREAKUP_TIME;
      }
    } catch (InterruptedException e) {
    }

    return !stopping.get();
  }

  public long calculateSleepTimeBeforeRedelivery(int deliveryCount) {
    long sleepTime = redeliveryPolicy.getInitialRedeliveryTimeout();

    if (redeliveryPolicy.isBackOffMode()) {
      for (int i = 2; i <= deliveryCount; i++) {
        sleepTime *= i * redeliveryPolicy.getBackOffIncreaseRate();
      }
    }

    return sleepTime;
  }

}
