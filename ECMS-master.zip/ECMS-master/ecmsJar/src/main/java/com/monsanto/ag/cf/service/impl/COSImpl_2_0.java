package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.ConversationIdUtil;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;


/**
 * Service Implementation of the COS_2_0 web service.
 * 
 * @author mkuchip
 * @version $Id: COSImpl_2_0.java, 2008/06/02
 */
public class COSImpl_2_0 extends ServiceProxySupport implements SecureService, Identifiable {

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private IdMapperDao idMapperDao;
  private XmlDocumentBuilder xmlDocumentBuilder;

  public String getId() {
    return "COS2";
  }

  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

    public boolean isValidationRequired() {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    String conversationId = Utilities.generateConversationId();
    Logger.log(new LoggableInfo("Processing COS_2-0 request with Conversation Id: " + conversationId));
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);

    COSHelper.updateInputDocumentIfDocumentDoesNotContainEBID(inputDocument, idPrincipal, idMapperDao);

    ServiceOutput output = delegateRequestToCOSService(inputDocument, conversationId);
    ConversationIdUtil.substituteDocumentIdentifier(output.getXmlChunks().getXmlDocument(xmlDocumentBuilder), conversationId);
    return output;
  }

  private ServiceOutput delegateRequestToCOSService(XmlDocument inputDocument, String conversationId) {
    ServiceInput input = COSHelper.prepareInputDocument(inputDocument, conversationId, outputXmlMessageInformer);
    ServiceOutput output = soaClient.call(serviceId, input);
    output.setConversationId(conversationId);    
    return output;
  }


  public void setIdMapperDao(IdMapperDao idMapperDao) {
    this.idMapperDao = idMapperDao;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}
