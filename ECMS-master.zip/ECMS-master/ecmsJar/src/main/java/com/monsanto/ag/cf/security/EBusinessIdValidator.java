/*
 * EBusinessIdValidator was created on Apr 20, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.security;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * Validates a user's E-Business Id (EBID).
 * 
 * @author Gareth Davies
 * @version $Id: EBusinessIdValidator.java,v 1.4 2008-05-27 16:02:58 na1000app-ec Exp $
 */
public interface EBusinessIdValidator {

  /**
   * Validates the EBID associated with the specified user identity against the
   * specified EBID.
   * 
   * @param idPrincipal
   *          Principal containing a user's identities
   * @param eBusinessId
   *          EBID to compare with the user's
   * @return True if the EBID's match
   * @throws EBusinessIdValidationException
   *           If the validation fails
   */
  public boolean validate(IdentityPrincipal idPrincipal, String eBusinessId)
      throws EBusinessIdValidationException;

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/11/22 22:39:07  caggarw
 * changes for storing EBID as a String within the web-services, as it may contain alpha numeric characters
 *
 * Revision 1.2  2005/06/17 18:18:16  ggdavi
 * Refactored ag.cf.security to move common objects to ag.security
 *
 * Revision 1.1  2005/04/20 17:21:51  ggdavi
 * Initial version
 *
 */