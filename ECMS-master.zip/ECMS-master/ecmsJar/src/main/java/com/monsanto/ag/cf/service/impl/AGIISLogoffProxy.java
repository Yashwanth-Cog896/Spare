package com.monsanto.ag.cf.service.impl;

import java.io.StringReader;

import org.w3c.dom.Document;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.xml.DocumentBuilderException;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocument;


public class AGIISLogoffProxy extends ServiceProxySupport {
	private XmlDocumentBuilder xmlDocumentBuilder;
	private static final String AGIISLogoffSoapHeader = "http://www.agiis.org/Services/Security/Logoff";

	public boolean logoffAgiis()  {
		Logger.log(new LoggableInfo("Logging in to AGIIS"));
		ServiceInput loginInput = new ServiceInput(buildLogoffInputDocument());
		loginInput.setSoapActionHeader(AGIISLogoffSoapHeader);
		loginInput.setOverrideResponseChunking(true);
		ServiceOutput output = soaClient.call(serviceId, loginInput);
		return getResponse(output);		
	}

	private boolean getResponse(ServiceOutput output) {
		XmlDocument logoffOutputDoc = output.getXmlChunks().getXmlDocumentChunk(xmlDocumentBuilder, 0);
		try {
			XmlElement logoffElement = logoffOutputDoc.selectElementByXPath("//soap:Envelope/soap:Body");
			XmlElement logoffResponse = logoffElement.getChild("LogoffResponse");
			XmlElement logoffResultElement = logoffResponse.getChild("LogoffResult");		
			String logoffResult = logoffResultElement.getText();
		    return Boolean.valueOf(logoffResult).booleanValue();
		} catch (Exception e) {
		    Logger.log(new LoggableInfo(e.getMessage()));			
		}
		return false;
	}

	private XmlDocument buildLogoffInputDocument(){
		String subscriberLogoffessage =
			"<Logoff xmlns=\"http://www.agiis.org/Services/Security\" />";			
		
	    try {
	  	  	Document document = DOMUtil.newDocument(new StringReader(subscriberLogoffessage));
	        return new DOMUtilXmlDocument(document);
	      } catch (Exception e) {
	        throw new DocumentBuilderException(e.getMessage());
	      }
	}
	
	public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
		this.xmlDocumentBuilder = xmlDocumentBuilder;
	}

}