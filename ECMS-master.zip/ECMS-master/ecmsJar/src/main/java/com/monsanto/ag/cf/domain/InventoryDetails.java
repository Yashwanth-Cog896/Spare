package com.monsanto.ag.cf.domain;

import com.monsanto.ag.cf.dao.InventoryReportingDao;
import com.monsanto.ag.util.Entity;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.Date;

/**
 * InventoryDetails holds the Inventory Reporting Details (Mobile)
 * @author [Ramesh Kukunarapu]
 * @version $Id: InventoryDetails.java,v 1.2 2007-12-21 17:38:22 RRKUKU Exp $ 1.1
 */
public class InventoryDetails {
  
  private String customerType;
  private String reportType;
  private String fileName;
  private String dsType;
  private String sfType;
  private String invoiceDateQualifier;
  private String shipDateQualifier;
  private String shipDate;
  private String transactionStatus;
  private String conversationId;
  private String reporterId;
  private String reporterIdQualifier;
  private String reporterName;
  private Date documentDate;
  private String dataSource;
  private Date loadDate;
  private String ownerId;
  private String ownerQualifier;
  private String ownerName;
  private String locationId;
  private String locationQualifier;
  private String locationName;
  private Date asOfDate;
  private String GTINQualifier;
  private String GTIN;
  private String lotNumber;
  private String quantity;
  private String quantityQualifier;
  private String orderType;
  private String productUOM;
  private String physicalCountIND;
  private String appVersion;
    private Date dateChanged;
    private String soldNotDelivered;
  //32 getter and setter
    
  public InventoryDetails(){
  }

  public InventoryDetails(String fileName, String customerType, String reportType, String dsType, String sfType,
                          String invoiceDateQualifier, String shipDateQualifier, String transactionStatus,
                          String conversationId, InventoryReporterDetails reporterDetails, String dataSource,
                          InventoryLocationDetails locationDetails, InventoryProductDetails productDetails,
                          String physicalCountIND,
                          String lotNumber) {
    this(fileName, customerType, reportType, dsType, sfType, invoiceDateQualifier, shipDateQualifier,
            transactionStatus,conversationId, reporterDetails.getReporterIdQualifier(),
            reporterDetails.getReporterId(), reporterDetails.getReporterName(), dataSource,
            reporterDetails.getOwnerId(), reporterDetails.getOwnerIdQualifier(), reporterDetails.getOwnerName(),
            locationDetails.getLocationId(), locationDetails.getLocationIdQualifier(),
            locationDetails.getLocationName(),
            productDetails.getDate(), productDetails.getGtinQualifier(), productDetails.getGtin(),
            productDetails.getQuantity(), productDetails.getQuantityQualifier(), productDetails.getOrderType(),
            productDetails.getProductUom(), physicalCountIND, lotNumber);

  }
  
  public InventoryDetails(String fileName, String customerType, String reportType, String dsType, String sfType, 
      String invoiceDateQualifier, String shipDateQualifier, String transactionStatus, String conversationId, 
      String reporterIdQualifier, String reporterId, String reporterName, String dataSource, 
      String ownerId, String ownerQualifier, String ownerName, String locationId, String locationQualifier, 
      String locationName, Date asOfDate, String GTINQualifier, String GTIN, String quantity, 
      String quantityQualifier, String orderType, String productUOM, String physicalCountIND, String lotNumber){
   this.fileName = fileName;
   this.customerType = customerType;
   this.reportType = reportType;
   this.dsType = dsType;
   this.sfType = sfType;
   this.invoiceDateQualifier = invoiceDateQualifier;
   this.shipDateQualifier = shipDateQualifier;
   this.transactionStatus = transactionStatus;
   this.conversationId = conversationId;
   this.reporterId = reporterId;
   this.reporterIdQualifier = reporterIdQualifier;
   this.reporterName = reporterName;
   this.dataSource = dataSource;
   this.ownerId = ownerId;
   this.ownerQualifier = ownerQualifier;
   this.ownerName = ownerName;
   this.locationId = locationId;
   this.locationQualifier = locationQualifier;
   this.locationName = locationName;
   this.asOfDate = asOfDate;
   this.GTINQualifier = GTINQualifier;
   this.GTIN = GTIN;
   this.quantity = quantity;
   this.quantityQualifier = quantityQualifier;
   this.orderType = orderType;
   this.productUOM = productUOM;
   this.physicalCountIND = physicalCountIND;
   this.lotNumber = lotNumber;
  }
  
  public Date getAsOfDate() {
    return asOfDate;
  }
  public void setAsOfDate(Date asOfDate) {
    this.asOfDate = asOfDate;
  }
  public String getConversationId() {
    return conversationId;
  }
  public void setConversationId(String conversationId) {
    this.conversationId = conversationId;
  }
  public String getCustomerType() {
    return customerType;
  }
  public void setCustomerType(String customerType) {
    this.customerType = customerType;
  }
  public String getDataSource() {
    return dataSource;
  }
  public void setDataSource(String dataSource) {
    this.dataSource = dataSource;
  }
  public Date getDocumentDate() {
    return documentDate;
  }
  public void setDocumentDate(Date documentDate) {
    this.documentDate = documentDate;
  }
  public String getDsType() {
    return dsType;
  }
  public void setDsType(String dsType) {
    this.dsType = dsType;
  }
  public String getFileName() {
    return fileName;
  }
  public void setFileName(String fileName) {
    this.fileName = fileName;
  }
  public String getGTIN() {
    return GTIN;
  }
  public void setGTIN(String gtin) {
    GTIN = gtin;
  }
  public String getInvoiceDateQualifier() {
    return invoiceDateQualifier;
  }
  public void setInvoiceDateQualifier(String invoiceDateQualifier) {
    this.invoiceDateQualifier = invoiceDateQualifier;
  }
  public Date getLoadDate() {
    return loadDate;
  }
  public void setLoadDate(Date loadDate) {
    this.loadDate = loadDate;
  }
  public String getLocationId() {
    return locationId;
  }
  public void setLocationId(String locationId) {
    this.locationId = locationId;
  }
  public String getLocationName() {
    return locationName;
  }
  public void setLocationName(String locationName) {
    this.locationName = locationName;
  }
  public String getLocationQualifier() {
    return locationQualifier;
  }
  public void setLocationQualifier(String locationQualifier) {
    this.locationQualifier = locationQualifier;
  }
  public String getLotNumber() {
    return lotNumber;
  }
  public void setLotNumber(String lotNumber) {
    this.lotNumber = lotNumber;
  }
  public String getOwnerId() {
    return ownerId;
  }
  public void setOwnerId(String ownerId) {
    this.ownerId = ownerId;
  }
  public String getOwnerName() {
    return ownerName;
  }
  public void setOwnerName(String ownerName) {
    this.ownerName = ownerName;
  }
  public String getOwnerQualifier() {
    return ownerQualifier;
  }
  public void setOwnerQualifier(String ownerQualifier) {
    this.ownerQualifier = ownerQualifier;
  }
  public String getPhysicalCountIND() {
    return physicalCountIND;
  }
  public void setPhysicalCountIND(String physicalCountIND) {
    this.physicalCountIND = physicalCountIND;
  }
  public String getProductUOM() {
    return productUOM;
  }
  public void setProductUOM(String productUOM) {
    this.productUOM = productUOM;
  }
  public String getQuantity() {
    return quantity;
  }
  public void setQuantity(String quantity) {
    this.quantity = quantity;
  }
  public String getQuantityQualifier() {
    return quantityQualifier;
  }
  public void setQuantityQualifier(String quantityQualifier) {
    this.quantityQualifier = quantityQualifier;
  }
  public String getReporterId() {
    return reporterId;
  }
  public void setReporterId(String reporterId) {
    this.reporterId = reporterId;
  }
  public String getReporterName() {
    return reporterName;
  }
  public void setReporterName(String reporterName) {
    this.reporterName = reporterName;
  }
  public String getReportType() {
    return reportType;
  }
  public void setReportType(String reportType) {
    this.reportType = reportType;
  }
  public String getSfType() {
    return sfType;
  }
  public void setSfType(String sfType) {
    this.sfType = sfType;
  }
  public String getShipDateQualifier() {
    return shipDateQualifier;
  }
  public void setShipDateQualifier(String shipDateQualifier) {
    this.shipDateQualifier = shipDateQualifier;
  }
  public String getTransactionStatus() {
    return transactionStatus;
  }
  public void setTransactionStatus(String transactionStatus) {
    this.transactionStatus = transactionStatus;
  }

  public String getAppVersion() {
    return appVersion;
  }

  public void setAppVersion(String appVersion) {
    this.appVersion = appVersion;
  }

  public String getGTINQualifier() {
    return GTINQualifier;
  }

  public void setGTINQualifier(String qualifier) {
    GTINQualifier = qualifier;
  }

  public String getOrderType() {
    return orderType;
  }

  public void setOrderType(String orderType) {
    this.orderType = orderType;
  }

  public String getShipDate() {
    return shipDate;
  }

  public void setShipDate(String shipDate) {
    this.shipDate = shipDate;
  }

  public String getReporterIdQualifier() {
    return reporterIdQualifier;
  }

  public void setReporterIdQualifier(String reporterIdQualifier) {
    this.reporterIdQualifier = reporterIdQualifier;
  }


    public Date getDateChanged() {
        return dateChanged;
    }

    public void setDateChanged(Date dateChanged) {
        this.dateChanged = dateChanged;
    }

    public String getSoldNotDelivered() {
        return soldNotDelivered;
    }

    public void setSoldNotDelivered(String soldNotDelivered) {
        this.soldNotDelivered = soldNotDelivered;
    }

  @Override
  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(super.toString())
            .append("reporterName", reporterName).append("ownerName", ownerName)
            .append("locationName", locationName).append("quantity", quantity)
            .append("GTIN", GTIN).append("asOfDate", asOfDate).append("dataSource", dataSource)
            .toString();
  }
}
