/*
 * JdbcActivityDao was created on Mar 29, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.AbstractLogging.LoggableEvent;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.ActivityDao;
import com.monsanto.ag.cf.domain.UserActivity;

/**
 * Spring JDBC implemenation of the Activity DAO.
 * see SeedTrakInsourcingScope.doc FC84i, FC84j, FC84k, FC84m
 *
 * @author Gareth Davies
 * @version $Id: JdbcActivityDao.java,v 1.17 2008-04-23 15:17:59 rwspeh Exp $
 */
public class JdbcActivityDao extends BaseJdbcDao implements ActivityDao {

    public void storeActivity(UserActivity activity) {
        activity.setId(getNextSequenceValue());

        String sql = "INSERT INTO Data_Exchange_Log "
                + "(Data_Exchange_ID, User_Id, Acct_Id, Data_Exchange_Type_Code, "
                + "Conversation_ID, Data_Exchange_Start_Date, Data_Exchange_End_Date, "
                + "Seed_Year, Software_Version_ID, Transaction_Count, "
                + "Row_User_Id, Source_Name, Row_Task_Id) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
                + "?, ?, 'JdbcActivityDao.storeActivity')";

        getJdbcTemplate().update(sql, createValuesFromActivity(activity));
    }

    private Object[] createValuesFromActivity(UserActivity activity) {
        Logger.log(new LoggableInfo("createValuesFromActivity(): " + activity.toString()));
        return new Object[]{activity.getId(), activity.getUserId(),
                    activity.getAccountId(), activity.getExchangeType(),
                    activity.getConversationId(), activity.getStartTime(),
                    activity.getEndTime(), activity.getSeedYear(),
                    activity.getSoftwareVersion(),
                    activity.getTransactionCount(), activity.getUserId(), activity.getDataSource()};
    }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.16  2008/04/15 18:17:05  rwspeh
 * Backed out Logging changes for Data source column
 *
 * Revision 1.15  2008/04/10 15:40:30  rwspeh
 * Added funcitonaliy to update source name column in USER_XREF t able and DATA_EXCHANGE_LOG table
 *
 * Revision 1.14  2005/05/13 14:00:37  ggdavi
 * Added traceability to javadoc
 *
 * Revision 1.13  2005/05/09 18:06:58  ggdavi
 * Now extends BaseJdbcDao
 *
 * Revision 1.12  2005/05/06 17:45:44  ggdavi
 * Removed error_code and error_message
 *
 * Revision 1.11  2005/04/25 17:29:02  ggdavi
 * Added conversationId field; startTime is no longer auto-populated - it is now set in constructor or via setStartTime
 * Revision 1.10 2005/04/21 15:32:47 ggdavi Added
 * errorCode and errorMessage fields to UserActivity Revision 1.9 2005/04/19
 * 15:33:34 lsdenny converted int account id to long account id
 * 
 * Revision 1.8 2005/04/12 19:26:12 ggdavi Added accountId field to UserActivity
 * Revision 1.7 2005/04/08 21:55:31 ajbaldw Changed sequence value from int to
 * string Revision 1.6 2005/04/07 15:44:08 ggdavi Now use an integer value for
 * the Id Revision 1.5 2005/04/05 21:39:17 ggdavi Incrementer now a field
 * initialized by setSequenceName; added balance of database columns for
 * UserActivity Revision 1.4 2005/04/01 21:06:10 ajbaldw Updated reference to
 * UserActivity abstract class.
 * 
 * Revision 1.3 2005/03/30 17:13:03 ajbaldw removed the explicit date inserts...
 * these will be handled in Oracle by a trigger per Don. Revision 1.2 2005/03/30
 * 17:08:14 ajbaldw Uncommented the code to handle the sequences on the
 * data_exchange_log table. Revision 1.1 2005/03/29 23:08:00 ggdavi Initial
 * version
 */