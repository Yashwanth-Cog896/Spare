/*
 * PriceSheetImpl was created on Jun 15, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.text.ParseException;
import java.util.*;

import javax.security.auth.Subject;

import com.monsanto.ag.cf.domain.PriceSheet;
import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.PriceSheetDao;
import com.monsanto.ag.cf.service.PriceSheetSerializer;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamListAppender;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * POJO Implementation of the PriceSheet web service.
 * 
 * @author caggarw
 * @version $Id: PriceSheetImpl.java,v 1.29 2008-08-06 22:49:39 mkuchip Exp $
 */
public class PriceSheetImpl implements SecureService, Identifiable {

  private static final String XPATH_PRICE_SHEET_REQUEST_DETAILS = "/ecms:PriceSheetRequest/ecms:PriceSheetRequestBody/ecms:PriceSheetRequestDetails";

  private PriceSheetDao priceSheetDao;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;
  private PriceSheetSerializer priceSheetSerializer;
  
  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "PRICE";
  }

  public boolean isValidationRequired() {
    return true;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo("Processing Price Sheet request with conversation Id: " + conversationId));
    IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
    Date fromDate = getFromDateTimeFromInputDocument(inputDocument);

    List priceSheetList = getPriceSheetListFromDao(inputDocument, identityPrincipal, fromDate);

    XmlChunks outputXmlChunks = buildPriceSheetDocuments(conversationId, identityPrincipal, fromDate, priceSheetList);
    output.getXmlChunks().addChunks(outputXmlChunks);

    return output;
  }

  private Date getFromDateTimeFromInputDocument(XmlDocument inputDocument) {
    Date fromDateTime = null;
    try {
      String xpathFromDateTime = XPATH_PRICE_SHEET_REQUEST_DETAILS + "/cidx:FromDateTime";
      String dateText = inputDocument.getNodeValueByXPath(xpathFromDateTime);
      fromDateTime = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(dateText);
    } catch (ParseException pe) {
      Logger.log(new LoggableWarning(pe));
    }
    return fromDateTime;
  }

    private List getPriceSheetListFromDao(XmlDocument inputDocument, IdentityPrincipal identityPrincipal, Date fromDate) {
        long accountId = getAccountIdOfCurrentUser(identityPrincipal);
        if (accountId == 0) {
            accountId = inputXmlMessageInformer.getAccountId(inputDocument, idTranslator);
        }

        final String zoneIdXpath = XPATH_PRICE_SHEET_REQUEST_DETAILS + "/ecms:ZoneID";
        final Map<String, List<String>> zoneIdsMap = buildZoneIdsMap(inputDocument.selectElementsByXPath(zoneIdXpath));

        return priceSheetDao.getPriceSheet(accountId, fromDate, zoneIdsMap);
    }

    private Map<String, List<String>> buildZoneIdsMap(List<XmlElement> elements) {
        final Map<String, List<String>> map = new HashMap<String, List<String>>();
        map.put("new", new ArrayList<String>());
        map.put("not-new", new ArrayList<String>());

        for (XmlElement element : elements) {
            final String newAttribute = element.getAttributeValue("New");
            if (newAttribute != null && newAttribute.equalsIgnoreCase("true")) {
                map.get("new").add(element.getText());
            } else {
                map.get("not-new").add(element.getText());
            }
        }
        return map;
    }

    private long getAccountIdOfCurrentUser(IdentityPrincipal identityPrincipal) {
    if (IdentityPrincipal.UNAUTHENTICATED.equals(identityPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    } else {
      return identityPrincipal.getAccountId();
    }
  }

  private XmlChunks buildPriceSheetDocuments(final String conversationId, final IdentityPrincipal idPrincipal,
      final Date fromDate, List priceSheetList) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(priceSheetList, chunkSize,
        new XmlStreamListAppender() {
          
          public XmlStream buildXmlStream(List domainItems) {
            return priceSheetSerializer.buildPriceSheetDocument(conversationId, idPrincipal, fromDate, domainItems);
          }

        });

    return outputXmlChunks;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setPriceSheetDao(PriceSheetDao priceSheetDao) {
    this.priceSheetDao = priceSheetDao;
  }  
  
  public void setPriceSheetSerializer(PriceSheetSerializer priceSheetSerializer) {
    this.priceSheetSerializer = priceSheetSerializer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.28  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.27  2006/07/13 18:50:27  caggarw
 * Refactored to Delegate the XML Document creation to a Serializer
 *
 * Revision 1.26  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.25  2006/06/12 21:44:12  caggarw
 * changes for adding the Royalty pricing for RR Alfalfa in the Price Response XML
 * Revision 1.24 2006/06/07 23:01:47 ggdavi Fixed
 * NPE when no FromDateTime element is present in the XML request Revision 1.23
 * 2006/01/24 18:56:18 ggdavi Moved ChunkableServiceEndpoint, SecureService,
 * ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to
 * com.monsanto.ag.soa.server. This will simplify the class exclusion process
 * for consumer classes only interested in ag.soa.client classes.
 * 
 * Revision 1.22 2006/01/24 18:36:56 ggdavi Factored out the
 * ag.util.MessageParticant class from ag.security.IdentityPrincipal (which
 * delegates to it) so that the ag.xml.CidxDocumentHelper class no longer
 * depends on the ag.security package Revision 1.21 2005/12/01 19:34:30 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks Revision 1.20
 * 2005/11/21 20:41:28 caggarw Added Legal Jargon to Special Instruction. Look
 * for the AccountId in the request for STT's Revision 1.19 2005/11/08 21:00:31
 * ggdavi Updated after adding XmlStream (and StAX implementation) to the
 * com.monsanto.ag.util package and refactoring the ServiceInput and
 * ServiceOutput classes to expose both XmlStream and XmlDocument objects
 * 
 * Revision 1.18 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.17 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.16 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.15 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.14 2005/08/05
 * 18:37:57 ggdavi Removed deprecated executeSecure method based on DOM
 * documents Revision 1.12 2005/07/21 23:41:02 caggarw added modifyDate to
 * response xml as per request # 00067
 * 
 * Revision 1.11 2005/07/21 22:14:11 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations
 * 
 * Revision 1.10 2005/07/21 14:48:57 ggdavi Fleshed out and refactored
 * com.monsanto.ag.util to make more object-oriented, in that most functionality
 * has been pushed to the XmlDocument and XmlElement objects Revision 1.9
 * 2005/07/12 21:42:18 caggarw variable action was not being used - fixed,
 * thanks to eclipse 3.1
 * 
 * Revision 1.8 2005/07/06 21:12:15 ggdavi Added xmlDocumentBuilder field, used
 * to build output XML documents Revision 1.7 2005/06/30 20:24:20 ggdavi Use
 * node.getOwnerDocument instead of helper.getDocument(node)
 * 
 * Revision 1.6 2005/06/30 15:29:28 ajbaldw Prefixed the XPaths with ecms:
 * 
 * Revision 1.5 2005/06/27 16:51:30 caggarw added logic for action
 * 
 * Revision 1.4 2005/06/27 03:46:23 caggarw added response xml Revision 1.3
 * 2005/06/20 17:12:36 ggdavi Moved Entity and Identifiable back to ag.cf.domain
 * from ag.domain (sorry about that...) Revision 1.2 2005/06/20 16:40:27 ggdavi
 * Moved Entity and Identifiable from ag.cf.domain to ag.domain Revision 1.1
 * 2005/06/15 20:36:52 caggarw Implementation class for PriceSheet
 */