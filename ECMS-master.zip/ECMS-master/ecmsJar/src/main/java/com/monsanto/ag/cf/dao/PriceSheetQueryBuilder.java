package com.monsanto.ag.cf.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class PriceSheetQueryBuilder {
    public String build(final Map<String, List<String>> zoneIdsMap, final Date date) {
        final List<String> notNewZoneIds = zoneIdsMap.get("not-new");
        final List<String> newZoneIds = zoneIdsMap.get("new");
        final StringBuilder sql = new StringBuilder();
        sql.append("select zone_code, upc_code, mkt_yr, srp_unit_price_bag, uom_code_bag, ")
                       .append(" CASE WHEN specie_code = 'A' AND trait_code = 'S80' THEN trait_unit_price_bag ELSE 0 END ")
                       .append(" alfalfa_trait_price, CASE WHEN specie_code = 'A' AND trait_code = 'S80' THEN germ_unit_price_bag ")
                       .append(" ELSE 0 END alfalfa_germ_price, price_change_date, last_run_date, pricing_date, row_eff_date from ")
                       .append(" dm_os_seed_price_c_vw where curr_mkt_yr_offset = 0 and ((zone_code in ('*'");
        if (notNewZoneIds != null && notNewZoneIds.size() > 0) {
            for (String notNewZoneId : notNewZoneIds) {
                sql.append(",'").append(notNewZoneId).append("'");
            }
        }
        sql.append(")");

        if (date != null) {
            sql.append(" and row_eff_date >= to_date('")
                    .append(new SimpleDateFormat("d-MMM-yyyy").format(date))
                    .append("', 'dd-mon-yyyy')");
        }

        sql.append(")");

        if (newZoneIds != null && newZoneIds.size() > 0) {
            Integer i = 0;
            final Integer sz = newZoneIds.size();
            sql.append(" or (zone_code in (");
            for (i = 0; i < sz; i++) {
                sql.append("'").append(newZoneIds.get(i)).append("'");
                if (i < (sz - 1)) {
                    sql.append(",");
                }
            }
            sql.append(")))");
        } else {
            sql.append(")");
        }

        return sql.toString();
    }
}
