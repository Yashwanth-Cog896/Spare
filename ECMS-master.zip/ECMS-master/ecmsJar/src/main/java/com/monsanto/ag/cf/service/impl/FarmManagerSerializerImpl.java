package com.monsanto.ag.cf.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.monsanto.ag.cf.domain.FarmManager;
import com.monsanto.ag.cf.service.FarmManagerSerializer;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.security.IdentityPrincipal;

public class FarmManagerSerializerImpl implements FarmManagerSerializer {

  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  public XmlStream buildFarmManagerListDocument(String conversationId, IdentityPrincipal idPrincipal,
      List farmManagerList) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement("FarmManagerList",
        FarmManagerListImpl.NAMESPACE_FMLIST_RESPONSE, "1.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    addBodyNode(rootElement, farmManagerList);

    return outputDocument;
  }

  private void addBodyNode(XmlElement rootNode, List farmManagerList) {
    XmlElement bodyNode = rootNode.addChildElement("FarmManagerListBody");
    for (Iterator itFarmManager = farmManagerList.iterator(); itFarmManager.hasNext();) {
      FarmManager farmManager = (FarmManager) itFarmManager.next();
      addFarmManagerEntityNode(bodyNode, farmManager);
    }
  }

  private void addFarmManagerEntityNode(XmlElement bodyNode, FarmManager farmManager) {
    XmlElement entityElement = bodyNode.addChildElement("FarmManagerEntity");
    String activeFlag = StringUtils.capitalize(String.valueOf(farmManager.isActive()));
    entityElement.setAttribute("ActiveFlag", activeFlag);

    addPartnerInformationNode(entityElement, farmManager);

    entityElement.addChildElement("FarmManagerRole", farmManager.getRole());
  }

  private void addPartnerInformationNode(XmlElement entityElement, FarmManager farmManager) {
    XmlElement partnerInfoNode = entityElement.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerInformation");

    partnerInfoNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerName", farmManager.getName());
    XmlElement partnerIdElement = partnerInfoNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier",
        idTranslator.formatSapId(farmManager.getSapId()));
    partnerIdElement.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.SAP_ID_AGENCY);

    XmlElement addressNode = partnerInfoNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "AddressInformation");
    addressNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "AddressLine", farmManager.getStreet());
    addressNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "CityName", farmManager.getCity());
    addressNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "StateOrProvince", farmManager.getState());
    addressNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PostalCode", farmManager.getZip());
    addressNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PostalCountry", farmManager.getCountry());

    XmlElement partnerRefElement = partnerInfoNode.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerReference");
    partnerIdElement = partnerRefElement.addChildElement(XmlNamespace.NAMESPACE_CIDX_40, "PartnerIdentifier",
        idTranslator.formatAccountId(farmManager.getAccountId()));
    partnerIdElement.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, CidxConstants.ACCOUNT_ID_AGENCY);
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}
