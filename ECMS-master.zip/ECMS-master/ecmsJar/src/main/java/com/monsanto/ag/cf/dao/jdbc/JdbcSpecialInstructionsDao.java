/*
 * JdbcSpecialInstructionsDao was created on May 12, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.monsanto.ag.cf.dao.SpecialInstructionsDao;
import com.monsanto.ag.cf.domain.SpecialInstructions;

/**
 * Spring JDBC implementation of the SpecialInstructions DAO.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcSpecialInstructionsDao.java,v 1.2 2005/05/13 14:00:37
 *          ggdavi Exp $
 * @see SeedTrakInsourcingScope FC56
 */
public class JdbcSpecialInstructionsDao extends JdbcDaoSupport implements
    SpecialInstructionsDao {

  /**
   * Maps the results from database queries to SpecialInstructions objects,
   * which each include data from one or more rows.
   */
  private final class SpecialInstructionsRowCallbackHandler implements
      RowCallbackHandler {
    private Map instructionsMap;

    private SpecialInstructionsRowCallbackHandler() {
      instructionsMap = new HashMap();
    }

    public void processRow(ResultSet rs) throws SQLException {
      SpecialInstructions serviceInstructions = getSpecialInstructionsForService(
          rs.getLong("Acct_Id"), rs.getString("Data_Exchange_Type_Code"));
      serviceInstructions.addInstruction(rs
          .getString("Special_Instruction_Type_Code"));
    }

    private SpecialInstructions getSpecialInstructionsForService(
        long accountId, String serviceId) {
      SpecialInstructions instructions = (SpecialInstructions) instructionsMap
          .get(serviceId);
      if (instructions == null) {
        instructions = new SpecialInstructions(accountId, serviceId);
        instructionsMap.put(serviceId, instructions);
      }
      return instructions;
    }

    private Set getAllInstructions() {
      return new HashSet(instructionsMap.values());
    }
  }

  /**
   * @see com.monsanto.ag.cf.dao.SpecialInstructionsDao#findInstructionsByDealer(long)
   */
  public Set findInstructionsByDealer(long accountId) {
    String sql = "SELECT Acct_Id, Data_Exchange_Type_Code, Special_Instruction_Type_Code"
        + " FROM Special_Instruction WHERE Acct_Id = ?";
    Object[] parameters = new Object[] { new Long(accountId) };
    return executeSpecialInstructionsQuery(sql, parameters);
  }

  private Set executeSpecialInstructionsQuery(String sql, Object[] parameters) {
    SpecialInstructionsRowCallbackHandler rowCallbackHandler = new SpecialInstructionsRowCallbackHandler();
    getJdbcTemplate().query(sql, parameters, rowCallbackHandler);
    return rowCallbackHandler.getAllInstructions();
  }

  public Set findInstructionsByDealerService(long accountId, String serviceId) {
    String sql = "SELECT Acct_Id, Data_Exchange_Type_Code, Special_Instruction_Type_Code"
        + " FROM Special_Instruction WHERE Acct_Id = ? AND Data_Exchange_Type_Code = ?";
    Object[] parameters = new Object[] { new Long(accountId), serviceId };
    return executeSpecialInstructionsQuery(sql, parameters);
  }

  /**
   * @see com.monsanto.ag.cf.dao.SpecialInstructionsDao#removeInstructions(long,
   *      java.lang.String)
   */
  public void removeInstructions(long accountId, String serviceId) {
    String sql = "DELETE FROM Special_Instruction"
        + " WHERE Acct_Id = ? AND Data_Exchange_Type_Code = ?";
    Object[] parameters = new Object[] { new Long(accountId), serviceId };
    getJdbcTemplate().update(sql, parameters);
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.4 2005/07/14 22:17:35
 * ggdavi Implemented the findInstructionsByDealerService method Revision 1.3
 * 2005/07/14 21:34:54 ggdavi Added findInstructionsByDealerService method
 * Revision 1.2 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.1 2005/05/12 21:25:55 ggdavi Initial version
 * 
 */