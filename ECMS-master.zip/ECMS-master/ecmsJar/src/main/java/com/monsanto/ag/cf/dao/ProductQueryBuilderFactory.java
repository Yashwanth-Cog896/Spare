package com.monsanto.ag.cf.dao;

import java.util.Date;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: PPVASI
 * Date: Jul 11, 2011
 * Time: 10:18:48 AM
 */
public class ProductQueryBuilderFactory {

    public static ProductQueryBuilder createProductQueryBuilder(String requestingEntity, Date lastModifiedDate, String category, Set brand) {
        if(requestingEntity.equalsIgnoreCase("SeedTrak")) {
            return new SeedTrakProductQueryBuilder(lastModifiedDate, category, brand);
        }else if(requestingEntity.equalsIgnoreCase("AGIIS")){
            return new AGIISProductQueryBuilder(lastModifiedDate, category, brand);
        }else {
            throw new IllegalArgumentException("Invalid requestingEntity :" + requestingEntity);
        }
    }
}
