/*
 * CustomerSearchImpl was created on Aug 6, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.List;

import javax.security.auth.Subject;

import com.monsanto.ag.cf.EcmsXmlUtils;
import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.CustomerSearchDao;
import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.GrowerCriteria;
import com.monsanto.ag.cf.service.CustomerListSerializer;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamListAppender;

import com.monsanto.ag.security.IdentityPrincipal;

/**
 * Service implementation of the Customer Search web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: CustomerSearchImpl.java,v 1.8 2008-09-15 18:41:25 caggarw Exp $
 */
public class CustomerSearchImpl implements SecureService, Identifiable {

  public static final XmlNamespace NAMESPACE_CUST_RESPONSE = new XmlNamespace("ecms",
      "urn:ecms:schema:entity:response:1:0");

  private XmlDocumentBuilder xmlDocumentBuilder;
  private CustomerSearchDao customerSearchDao;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private CustomerListSerializer customerListSerializer;
  
  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "CUSTSR";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo("Processing Customer Search request with conversation Id: " + conversationId));
    IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);

    final String seedYear = EcmsXmlUtils.getSeedYearFromInputDocument(inputDocument);
    GrowerCriteria growerCriteria = CustomerSearchHelper.getGrowerCriteriaFromInputDocument(inputDocument);
    List customerList = customerSearchDao.getCustomerDetails(growerCriteria, seedYear);

    XmlChunks outputXmlChunks = buildCustomerSearchDocuments(conversationId, identityPrincipal, customerList);
    output.getXmlChunks().addChunks(outputXmlChunks);

    return output;
  }
   
  public boolean isValidationRequired() {
    return true;
  }

  protected XmlChunks buildCustomerSearchDocuments(final String conversationId,
      final IdentityPrincipal identityPrincipal, List customerList) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(customerList, chunkSize,
        new XmlStreamListAppender() {

          public XmlStream buildXmlStream(List domainItems) {
            return customerListSerializer.buildCustomerSearchDocument(conversationId, identityPrincipal, domainItems);
          }

        });

    return outputXmlChunks;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setCustomerSearchDao(CustomerSearchDao customerSearchDao) {
    this.customerSearchDao = customerSearchDao;
  }

  public void setCustomerListSerializer(CustomerListSerializer customerListSerializer) {
    this.customerListSerializer = customerListSerializer;

  } 

}
