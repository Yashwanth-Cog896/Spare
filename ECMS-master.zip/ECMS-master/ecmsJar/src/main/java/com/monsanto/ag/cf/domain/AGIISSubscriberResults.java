package com.monsanto.ag.cf.domain;

public class AGIISSubscriberResults {
	private boolean serviceAvailable;
	private boolean subscriber;
	private boolean activeSubscriber;
	
	public boolean isServiceAvailable() {
		return serviceAvailable;
	}
	public void setServiceAvailable(boolean serviceAvailable) {
		this.serviceAvailable = serviceAvailable;
	}
	public boolean isSubscriber() {
		return subscriber;
	}
	public void setSubscriber(boolean subscriber) {
		this.subscriber = subscriber;
	}
	public void setActiveSubscriber(boolean activeSubscriber) {
		this.activeSubscriber = activeSubscriber;
	}
	
	public boolean isCustomerAbleToReceiveOtherSeedBrands() {
		return activeSubscriber;
	}
	public boolean isActiveSubscriber() {
		return activeSubscriber;
	}
	
}
