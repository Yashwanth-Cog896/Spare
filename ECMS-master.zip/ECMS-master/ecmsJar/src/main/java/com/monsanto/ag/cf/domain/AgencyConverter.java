package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by JTMURR on 4/4/2016.
 */
public class AgencyConverter {
    private Map<String, String> map;

    public AgencyConverter() {
        map = new HashMap<String, String>();
        map.put("AGIIS-EBID", "9");
        map.put("AssignedBySeller", "91");
        map.put("AGIIS-NAPD", "C5");
        map.put("AssignedByBuyer", "92");
        map.put("AssignedByPapiNet", "91");
        map.put("AssignedByTestingLaboratory", "92");
        map.put("D-U-N-S", "1");
        map.put("Other", "ZZ");
        map.put("SCAC", "2");
        map.put("AssignedByManufacturer", "99");
        map.put("AGIIS-ProductID", "UK");
        map.put("UPC", "UP");
    }

    public String convert(String key) {
        if (StringUtils.isEmpty(key) || !map.containsKey(key)) {
            return map.get("Other");
        }
        return map.get(key);
    }
}
