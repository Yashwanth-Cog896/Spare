package com.monsanto.ag.cf.service.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by jtmurr on 2/4/2016.
 */
public class FileNameCreatorForInventoryReporting implements FileNameCreator {
    private Date date;
    private String dataSource;

    public FileNameCreatorForInventoryReporting(Date date, String dataSource) {
        this.date = date;
        this.dataSource = dataSource;
    }

    @Override
    public String createFileName() {
        return dataSource.toUpperCase() + "_" + new SimpleDateFormat("yyyyMMdd").format(date) + "_" + new SimpleDateFormat("HHmmss").format(date);
    }
}
