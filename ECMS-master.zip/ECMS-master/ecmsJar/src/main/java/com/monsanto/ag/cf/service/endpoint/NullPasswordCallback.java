/*
 * NullPasswordCallback was created on Sep 1, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.service.endpoint;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

/**
 * Null Object WSS4J password callback handler, since the WSDoAllReceiver does
 * not authenticate, but merely retrieves credentials for authentication by
 * other objects.
 * 
 * @author Gareth Davies
 * @version $Id: NullPasswordCallback.java,v 1.1 2006-05-08 14:17:56 caggarw Exp $
 */
public class NullPasswordCallback implements CallbackHandler {

  /**
   * @see javax.security.auth.callback.CallbackHandler#handle(javax.security.auth.callback.Callback[])
   */
  public void handle(Callback[] callbacks) throws IOException,
      UnsupportedCallbackException {
    for (int i = 0; i < callbacks.length; i++) {
      if (callbacks[i] instanceof WSPasswordCallback) {
        WSPasswordCallback pc = (WSPasswordCallback) callbacks[i];
        pc.setPassword("ecms");
      } else {
        throw new UnsupportedCallbackException(callbacks[i],
            "Unrecognized Callback");
      }
    }
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/09/01 21:10:18  ggdavi
 * Updated to official wss4j 1.0 release - this necessitated replacing the value of passwordCallbackClass property of the WSDoAllReceiver in the server-config.wsdd files with a new class (com.monsanto.ag.cf.service.endpoint.NullPasswordCallback)
 *
 */