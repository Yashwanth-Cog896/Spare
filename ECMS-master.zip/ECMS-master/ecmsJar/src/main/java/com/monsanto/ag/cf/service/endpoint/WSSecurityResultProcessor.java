/*
 * WSSecurityResultProcessor was created on Mar 25, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.endpoint;

import java.util.Iterator;
import java.util.Vector;

import javax.xml.rpc.handler.MessageContext;

import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.WSUsernameTokenPrincipal;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;

/**
 * Retrieves the results of WSS4J's processing of WS-Security header
 * information.
 * 
 * @author Gareth Davies
 * @version $Id: WSSecurityResultProcessor.java,v 1.1 2006-05-08 14:19:30 caggarw Exp $
 */
public class WSSecurityResultProcessor {

  private MessageContext messageContext;

  public WSSecurityResultProcessor(MessageContext messageContext) {
    this.messageContext = messageContext;
  }

  /**
   * Retrieve the user credentials from the results of the WS-Security handler
   * processing.
   * 
   * @return Principal representing WS-Security UsernameToken profile
   * @see SeedTrakArchitectureDesign TR206
   */
  public WSUsernameTokenPrincipal getUserPrincipal() {
    WSUsernameTokenPrincipal principal = null;

    Vector results = (Vector) messageContext
        .getProperty(WSHandlerConstants.RECV_RESULTS);
    for (Iterator itHandlerResult = results.iterator(); itHandlerResult
        .hasNext();) {
      WSHandlerResult handlerResult = (WSHandlerResult) itHandlerResult.next();
      principal = getPrincipalFromHandlerResult(handlerResult);
    }

    return principal;
  }

  /**
   * Retrieve the user credentials from a specific WS-Security handler result.
   * <p>
   * Note: An encryption action does not have an associated principal. Only
   * Signature and UsernameToken actions return a principal
   * 
   * @param handlerResult
   *          The WS-Security handler result to check
   * @return Principal representing WS-Security UsernameToken profile, if one
   *         exists
   * @see SeedTrakArchitectureDesign TR206
   */
  private WSUsernameTokenPrincipal getPrincipalFromHandlerResult(
      WSHandlerResult handlerResult) {
    WSUsernameTokenPrincipal principal = null;

    //String actor = handlerResult.getActor();
    Vector wsseResults = handlerResult.getResults();
    for (Iterator itWsseResult = wsseResults.iterator(); itWsseResult.hasNext();) {
      WSSecurityEngineResult wsseResult = (WSSecurityEngineResult) itWsseResult
          .next();
      if (wsseResult.getAction() != WSConstants.ENCR) {
        principal = (WSUsernameTokenPrincipal) wsseResult.getPrincipal();
        Logger.log(new DebugLogEvent(
            "Found WSUsernameTokenPrincipal in WSSecurityEngineResult"));
        break;
      }
    }

    return principal;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/06/02 16:38:14  ggdavi
 * Now logs at the DEBUG level
 *
 * Revision 1.1  2005/04/14 16:53:19  ggdavi
 * Moved from ag.cf.security to ag.cf.service.jaxrpc
 *
 * Revision 1.1  2005/03/28 19:27:59  ggdavi
 * Initial version
 *
 */