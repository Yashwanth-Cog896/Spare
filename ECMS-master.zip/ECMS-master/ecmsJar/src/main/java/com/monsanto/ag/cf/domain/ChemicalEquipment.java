/*
 * ChemicalEquipment was created on Aug 18, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.util.Date;

import com.monsanto.ag.xml.XmlElement;

/**
 * Represents a commercial chemical equipment product.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method. This XML
 * conforms to the AGIISProductUpdate element of the AGIISNamespacedSchema.xsd
 * XML schema document.
 * 
 * @author Gareth Davies
 * @version $Id: ChemicalEquipment.java,v 1.1 2008-07-18 21:28:18 gjkell Exp $
 */
public class ChemicalEquipment extends Equipment {

  public ChemicalEquipment( boolean ecListMaterial, boolean active, Date addedDate,
      Date lastModifiedDate, String id) {
    super( ecListMaterial, active, addedDate, lastModifiedDate, id );
  }

  /**
   * @see com.monsanto.ag.ecg.domain.Product#shallowCloneImplementation()
   */
  protected Product shallowCloneImplementation() {
    return new ChemicalEquipment( isEcListMaterial(), isActive(), getAddedDate(),
        getLastModifiedDate(), getId());
  }

  /**
   * @see com.monsanto.ag.ecg.domain.Product#getAGIISIdentifier()
   */
  protected String getAGIISIdentifier() {
    return "Equipment";
  }

  /**
   * @see com.monsanto.ag.ecg.domain.Product#getAGIISName()
   */
  protected String getAGIISName() {
    return getAGIISIdentifier();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/12/01 19:55:37  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.1  2005/08/19 15:13:55  ggdavi
 * Initial version
 *
 */