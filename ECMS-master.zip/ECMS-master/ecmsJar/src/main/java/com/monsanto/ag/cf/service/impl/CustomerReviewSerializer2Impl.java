/*
 * CustomerReviewSerializerImpl was created on Aug 15, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.ag.cf.domain.ZoneInformation;
import com.monsanto.ag.cf.service.CustomerReviewSerializer;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.xml.*;
import org.apache.commons.lang.StringUtils;

import java.util.Iterator;
import java.util.List;

/**
 * Serializer to create the Customer Review 2 Response Document for GOAII.
 *
 * @author Chetna dddoni
 * @version $Id: CustomerReviewSerializer2Impl.java,v 1.2 2008-07-02 20:23:08 dddoni Exp $
 *
 */
public class CustomerReviewSerializer2Impl extends CustomerReviewSerializerImpl implements CustomerReviewSerializer {

	private XmlDocumentBuilder xmlDocumentBuilder;

	private IdTranslator idTranslator;
	private XmlNamespace xmlNameSpace =XmlNamespace.NAMESPACE_CIDX_50_DRAFT14;

	/**
	 /* @see com.monsanto.ag.cf.service.CustomerReviewSerializer#buildCustomerReviewDocument(java.lang.String,
	 / *      com.monsanto.ag.security.IdentityPrincipal, java.util.List)
	 */
	public XmlStream buildCustomerReviewDocument(String conversationId,
												 IdentityPrincipal identityPrincipal, List domainItems,
												 long accountId) {


		XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
		XmlElement rootElement = outputDocument.addRootElement(
				"GrowerIDResponse",
				CustomerReview2Impl.NAMESPACE_CUST_REVIEW_RESPONSE, "2.0");

		CidxDocumentHelper helper = new CidxDocumentHelper(
				xmlNameSpace);
		helper.addHeaderNode(rootElement, conversationId, identityPrincipal
				.getMessageParticipant(), idTranslator);

		addBodyNode(rootElement, domainItems, accountId);

		return outputDocument;
	}

	private void addBodyNode(XmlElement rootElement, List domainItems,
							 long accountId) {
		XmlElement bodyNode = rootElement
				.addChildElement("GrowerIDResponseBody");
		XmlElement detailsNode = bodyNode
				.addChildElement("GrowerIDResponseDetails");
		for (Iterator iter = domainItems.iterator(); iter.hasNext();) {
			GrowerDetails grower = (GrowerDetails) iter.next();
			XmlElement transactionNode = detailsNode
					.addChildElement("TransactionDetails");
			XmlElement refInfoNode = transactionNode.addChildElement(
					xmlNameSpace, "ReferenceInformation");
			refInfoNode.setAttribute("ReferenceType", "InvoiceNumber");
			XmlElement refDocRefNode = refInfoNode.addChildElement(
					xmlNameSpace, "DocumentReference");
			refDocRefNode.addChildElement(xmlNameSpace,
					"DocumentIdentifier", grower.getInvoiceNumber());

			if (grower.getCustomerIds() != null) {
				XmlElement partnerId = transactionNode.addChildElement(
						xmlNameSpace, "PartnerIdentifier",
						Long.toString(grower.getCustomerIds().getAccountId()));
				partnerId.setAttribute(
						CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
						CidxConstants.ACCOUNT_ID_AGENCY);

				XmlElement SapId = transactionNode.addChildElement(
						xmlNameSpace, "PartnerIdentifier",
						grower.getCustomerIds().getSapId());
				SapId.setAttribute(CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
						CidxConstants.SAP_ID_AGENCY);

				if (StringUtils.isNotBlank(grower.getCustomerIds().getNapdId())) {
					XmlElement napId = transactionNode.addChildElement(
							xmlNameSpace,
							"PartnerIdentifier", grower.getCustomerIds()
									.getNapdId());
					napId.setAttribute(
							CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
							CidxConstants.NAPD_ID_AGENCY);
				}

				if (StringUtils.isNotBlank(grower.getCustomerIds().getGlnId())) {
					XmlElement glnId = transactionNode.addChildElement(
							xmlNameSpace,
							"PartnerIdentifier", grower.getCustomerIds()
									.getGlnId());
					glnId.setAttribute(
							CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE, "Other");
				}

			}

			transactionNode.addChildElement(xmlNameSpace,
					"PartnerName", grower.getAccountName());

			AddressInformation address = grower.getAddressInformation();
			if (address != null) {
				if (StringUtils.isNotBlank(address.getStreet())) {
					transactionNode.addChildElement(
							xmlNameSpace, "AddressLine",
							address.getStreet());
				}
				transactionNode.addChildElement(xmlNameSpace,
						"CityName", address.getCity());
				transactionNode.addChildElement(xmlNameSpace,
						"StateOrProvince", address.getState());
				transactionNode.addChildElement(xmlNameSpace,
						"PostalCode", address.getZip());
				if (StringUtils.isNotBlank(address.getCounty())) {
					transactionNode.addChildElement("PostalCounty", address
							.getCounty());
				}
			}
			if (grower.getFflxId() == accountId) {
				transactionNode.addChildElement("FarmFlexApproved", "Yes");
			} else {
				transactionNode.addChildElement("FarmFlexApproved", "No");
			}

			if (( StringUtils.isNotEmpty(grower.getFmgrApproved()))){
				transactionNode.addChildElement("FarmManagerApproved", "Yes");
			} else {
				transactionNode.addChildElement("FarmManagerApproved", "No");
			}

			if (StringUtils.isNotBlank(grower.getLicenseStatus())) {
				transactionNode.addChildElement("EntityStatus", grower
						.getLicenseStatus());
			}
			List zones = grower.getZoneInformation();
			for (Iterator zoneItr = zones.iterator(); zoneItr.hasNext();) {
				ZoneInformation zone = (ZoneInformation) zoneItr.next();
				if (zone != null) {
					XmlElement zoneNode = transactionNode.addChildElement("AgronomicZone");
					if (StringUtils.isNotBlank(zone.getZoneCode())) {
						zoneNode.addChildElement("ZoneCode", zone.getZoneCode());
					}
					if (StringUtils.isNotBlank(zone.getAZRDescr())) {
						zoneNode.addChildElement("Crop", zone.getAZRDescr());
					}
					if (StringUtils.isNotBlank(zone.getZoneDescr())) {
						zoneNode.addChildElement("ZoneDescription", zone.getZoneDescr());
					}
					if (StringUtils.isNotBlank(zone.getZoneYear())) {
						zoneNode.addChildElement("SeedYear", zone.getZoneYear());
					}
				}
			}
			List mirIds = grower.getMirIds();

			if (mirIds != null && mirIds.size() > 0) {
				XmlElement mirNode = transactionNode
						.addChildElement("MIRValues");
				XmlElement mirIdNode;
				for (Iterator iterator = mirIds.iterator(); iterator.hasNext();) {
					Long mirId = (Long) iterator.next();
					mirIdNode = mirNode.addChildElement(
							xmlNameSpace,
							"PartnerIdentifier", mirId);
					mirIdNode.setAttribute(
							CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
							CidxConstants.ACCOUNT_ID_AGENCY);
				}
			}

			transactionNode.addChildElement("MaxEffDate", XmlDateTimeUtil
					.formatDateAsXmlUTC(grower.getMaxEffDate()));

		}
	}

	public void setIdTranslator(IdTranslator idTranslator) {
		this.idTranslator = idTranslator;
	}

	public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
		this.xmlDocumentBuilder = xmlDocumentBuilder;
	}

}
