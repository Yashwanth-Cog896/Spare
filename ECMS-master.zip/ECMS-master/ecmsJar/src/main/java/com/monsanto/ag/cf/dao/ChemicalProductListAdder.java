package com.monsanto.ag.cf.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.ag.cf.domain.ChemicalProduct;
import com.monsanto.ag.cf.domain.Packaging;
import com.monsanto.ag.cf.domain.PackageConfiguration;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/21/13
 * Time: 12:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChemicalProductListAdder extends AbstractListAdder {

    public Product addProductToList( List products, PersistentStoreResultSetFwdIterator iter,
                                                 Product lastProductRetrieved ) throws WrappingException {

        Product product;
        if ( lastProductRetrieved != null &&
             lastProductRetrieved instanceof ChemicalProduct &&
             !isDifferentChemicalProduct( iter, lastProductRetrieved ) ) {

            product = lastProductRetrieved;
        }
        else {

            product = mapRowToChemicalProduct( iter,
                                               getEcListMaterial( iter ),
                                               getActiveFlag( iter ),
                                               getAddedDate( iter ),
                                               getLastModifiedDate( iter ),
                                               getProductId( iter ) );
            products.add( product );
        }

        if( product != null ){

            addChemicalPackagingToList( product, iter );
        }

        return product;
    }

    private boolean isDifferentChemicalProduct( PersistentStoreResultSetFwdIterator iter, Product lastProductRetrieved )
        throws WrappingException {

        ChemicalProduct chemicalProduct = ( ChemicalProduct ) lastProductRetrieved;
        String rowBrandCode = iter.getString( "brand_code" );
        return !ObjectUtils.equals( rowBrandCode, chemicalProduct.getBrandCode() );
    }

    private Product mapRowToChemicalProduct( PersistentStoreResultSetFwdIterator iter,
                                                 boolean ecListMaterial,
                                                 boolean active,
                                                 Date addedDate,
                                                 Date modifiedDate,
                                                 String productId ) throws WrappingException {

        return new ChemicalProduct( ecListMaterial,
                                    active,
                                    addedDate,
                                    modifiedDate,
                                    productId,
                                    iter.getString( "brand_code" ),
                                    iter.getString( "brand_descr" ),
                                    iter.getString( "EPA_REG_NUM" ) );
    }

    private void addChemicalPackagingToList( Product product, PersistentStoreResultSetFwdIterator iter )
                                                                            throws WrappingException {
        Packaging packaging = null;
        Packaging newPackaging = mapRowToChemicalPackaging( iter );
        List< Packaging > packagings = product.getPackagings();

        for( Packaging existingPackaging:packagings ) {

            if( ObjectUtils.equals( newPackaging.getPackageSizeCode(), existingPackaging.getPackageSizeCode() ) ){

                packaging = existingPackaging;
                break;
            }
        }

        if( packaging == null ) {

            packaging = newPackaging;
            product.addPackaging( packaging );
        }

        PackageConfiguration configuration = mapRowToPackageConfiguration( iter );
        packaging.addConfiguration( configuration );
    }

    private Packaging mapRowToChemicalPackaging( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        String packageName = iter.getString("legal_descr_1");
        if ( StringUtils.isNotEmpty( iter.getString( "legal_descr_2" ) ) ) {

            packageName += " " + iter.getString( "legal_descr_2" );
        }

        return new Packaging( getBoolean( iter, "pkg_active_flag" ),
                              getAddedDate( iter ),
                              getLastModifiedDate( iter ),
                              iter.getString( "gtin" ),
                              packageName,
                              packageName,
                              getBaseQuantity( iter ),
                              getUnRec20RrUomCode( iter ),
                              false,
                              "N/A",
                              null,
                              null,
                              "N/A" );
    }
}