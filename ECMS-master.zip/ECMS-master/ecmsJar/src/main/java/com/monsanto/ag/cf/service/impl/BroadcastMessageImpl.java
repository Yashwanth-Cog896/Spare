/*
 * BroadcastMessageImpl was created on May 19, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.domain.BroadcastMessage;
import com.monsanto.ag.cf.service.BroadcastMessageReader;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * POJO implementation of the Broadcast Message service.
 * 
 * @author Gareth Davies
 * @version $Id: BroadcastMessageImpl.java,v 1.26 2008-08-06 22:49:39 mkuchip Exp $
 */
public class BroadcastMessageImpl implements SecureService, Identifiable {

  private static final String XPATH_READ_BROADCAST_MESSAGE = "/cidx:BroadcastMessageRequest/cidx:BroadcastMessageRequestBody/cidx:MessageDetail/cidx:MessageIdentifier";

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private BroadcastMessageReader broadcastMessageReader;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "BM";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }
  
  public boolean isValidationRequired() {
    return true;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject)
      throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo(
        "Processing broadcast messages request with conversation Id: "
            + conversationId));
    String userId = getUserIdOfCurrentUser(subject);
    XmlDocument inputDocument = input.getXmlChunks().getXmlDocument(
        xmlDocumentBuilder);

    List messages = getNewBroadcastMessages(userId, inputDocument);

    XmlDocument messagesDoc = buildBroadcastMessagesDocument(subject, messages,
        conversationId);
    output.getXmlChunks().addChunk(messagesDoc);

    acknowledgeReceivedMessages(userId, inputDocument);

    return output;
  }

  private String getUserIdOfCurrentUser(Subject subject) {
    IdentityPrincipal identityPrincipal = SecurityUtil
        .getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(identityPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    } else {
      return identityPrincipal.getName().toUpperCase();
    }
  }

  private List getNewBroadcastMessages(String userId, XmlDocument xmlDocument) {
    String seedYear = getSeedYearFromDocument(xmlDocument);
    return broadcastMessageReader.getNewMessages(userId, seedYear);
  }

  private String getSeedYearFromDocument(XmlDocument xmlDocument) {
    String xpathSeedYear = inputXmlMessageInformer.getXpathSeedYear();
    String seedYear = xmlDocument.getNodeValueByXPath(xpathSeedYear);
    if (StringUtils.isNotBlank(seedYear)) {
      return seedYear;
    } else {
      throw new ServiceException("A valid Seed Year must be specified");
    }
  }

  private XmlDocument buildBroadcastMessagesDocument(Subject subject,
      List messages, String conversationId) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement("BroadcastMessage",
        XmlNamespace.NAMESPACE_CIDX_40, "4.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(
        XmlNamespace.NAMESPACE_CIDX_40);
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal
        .getMessageParticipant(), idTranslator);

    XmlElement bodyElement = rootElement
        .addChildElement("BroadcastMessageBody");
    addMessagesNode(bodyElement, messages);

    return outputDocument;
  }

  private void addMessagesNode(XmlElement rootNode, List messages) {
    for (Iterator itMessage = messages.iterator(); itMessage.hasNext();) {
      BroadcastMessage message = (BroadcastMessage) itMessage.next();
      addMessageNode(rootNode, message);
    }
  }

  private void addMessageNode(XmlElement rootNode, BroadcastMessage message) {
    XmlElement messageNode = rootNode.addChildElement("MessageDetail");
    messageNode.addChildElement("MessageIdentifier", message.getId());
    messageNode.addChildElement("MessageDescription", message.getTitle());
    messageNode.addChildElement("MessageText", message.getText());
  }

  private void acknowledgeReceivedMessages(String userId,
      XmlDocument xmlDocument) {
    List receivedMessageIds = getReceivedMessageIds(xmlDocument);
    if (receivedMessageIds.size() > 0) {
      broadcastMessageReader.acknowledge(userId, receivedMessageIds);
    }
  }

  private List getReceivedMessageIds(XmlDocument xmlDocument) {
    List receivedMessageIds = new ArrayList();

    List receivedMessageNodes = xmlDocument
        .selectElementsByXPath(XPATH_READ_BROADCAST_MESSAGE);
    for (Iterator itNode = receivedMessageNodes.iterator(); itNode.hasNext();) {
      XmlElement receivedMessageNode = (XmlElement) itNode.next();
      receivedMessageIds.add(receivedMessageNode.getText());
    }

    return receivedMessageIds;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer xmlMessageInformer) {
    this.inputXmlMessageInformer = xmlMessageInformer;
  }
  
  public void setOutputXmlMessageInformer(XmlMessageInformer xmlMessageInformer) {
    this.outputXmlMessageInformer = xmlMessageInformer;
  }
  
  public void setBroadcastMessageReader(
      BroadcastMessageReader broadcastMessageReader) {
    this.broadcastMessageReader = broadcastMessageReader;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

  
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.25  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.24  2006/07/25 19:33:24  caggarw
 * changed from outputmessageinformer to inputmessageinformer for seedyear
 *
 * Revision 1.23  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.22  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.21  2006/01/24 18:36:56  ggdavi
 * Factored out the ag.util.MessageParticant class from ag.security.IdentityPrincipal (which delegates to it) so that the ag.xml.CidxDocumentHelper class no longer depends on the ag.security package
 * Revision 1.20 2005/12/01 19:34:30 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks Revision 1.19
 * 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and StAX
 * implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects
 * 
 * Revision 1.18 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.17 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.16 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object Revision 1.15 2005/08/23 17:14:38 ggdavi Modified
 * SecureService.executeSecure method signature to accept a ServiceInput
 * argument instead of a List and return a ServiceOutput object instead of a
 * List Revision 1.14 2005/08/05 18:37:01 ggdavi Removed deprecated
 * executeSecure method based on DOM documents Revision 1.12 2005/07/21 22:14:11
 * ggdavi Added com.monsanto.ag.util.IdTranslator object to translate numeric
 * Ids (such as Account, EBusiness and SAP Ids) back and forth between their
 * numeric and zero-padded textual representations Revision 1.11 2005/07/21
 * 14:48:57 ggdavi Fleshed out and refactored com.monsanto.ag.util to make more
 * object-oriented, in that most functionality has been pushed to the
 * XmlDocument and XmlElement objects Revision 1.10 2005/07/06 21:12:15 ggdavi
 * Added xmlDocumentBuilder field, used to build output XML documents Revision
 * 1.9 2005/06/30 20:24:07 ggdavi Use helper.addChildElement instead of
 * DOMUtil.addChildElement Revision 1.8 2005/06/20 17:12:36 ggdavi Moved Entity
 * and Identifiable back to ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.7 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.6 2005/06/17 18:20:45 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security; moved CidxDocumentHelper from
 * ag.cf.service.impl to ag.util
 * 
 * Revision 1.5 2005/06/14 21:30:49 ggdavi Fixed bug with missing cidx prefixes
 * on XPath Revision 1.4 2005/05/31 20:38:42 ggdavi Throw SOAPFaultExceptions
 * instead of creating SOAPFault documents Revision 1.3 2005/05/26 17:26:47
 * ggdavi In CidxDocumentHelper, removed Document parameter from createRootNode
 * and added getDocument method Revision 1.2 2005/05/25 22:25:55 ggdavi Use
 * CidxDocumentHelper to create standard CIDX root node (with namespaces) and
 * header Revision 1.1 2005/05/20 20:51:36 ggdavi Initial version
 * 
 */