/*
 * CustomerSearch2Impl was created on June 6, 2008 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.EcmsXmlUtils;
import com.monsanto.ag.cf.dao.CreditControlAreaDao;
import com.monsanto.ag.cf.dao.CustomerSearchDao;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.dao.jdbc.JdbcCreditControlAreaDao;
import com.monsanto.ag.cf.domain.GrowerCreditInfoClientInfo;
import com.monsanto.ag.cf.domain.GrowerCriteria;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.ag.cf.farmflex.domain.FarmFlexObjectFactory;
import com.monsanto.ag.cf.service.CustomerListSerializer;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.*;
import com.monsanto.commercial.growercreditlist.domain.GrowerCreditInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

import javax.security.auth.Subject;
import java.util.*;

/**
 * Service implementation of the Customer Search V2 web service for GOAII. This
 * service return Response object with new field FarmFlexApproved Yes/No along
 * with existing Customer Search Service V1.
 *
 * @author Devaiah Doni
 * @version $Id: CustomerSearch2Impl.java,v 1.11 2008-09-25 15:06:22 dddoni Exp $
 */
public class CustomerSearch2Impl implements SecureService, Identifiable {

    private XmlDocumentBuilder xmlDocumentBuilder;
    private CustomerSearchDao customerSearchDao;
    private XmlMessageInformer inputXmlMessageInformer;
    private XmlMessageInformer outputXmlMessageInformer;
    private CustomerListSerializer customerListSerializer;
    private FarmFlexObjectFactory farmFlexObjectFactory;
    private IdMapperDao idMapperDao;
    private CreditControlAreaFilter farmFlexCreditControlAreaFilter;
    private CreditControlAreaDao creditControlAreaDao;

    private boolean validationRequired = true;

    public void setFarmFlexObjectFactory(FarmFlexObjectFactory  farmFlexObjectFactory) {
        this.farmFlexObjectFactory = farmFlexObjectFactory;
    }

    public void setIdMapperDao(IdMapperDao idMapperDao) {
        this.idMapperDao = idMapperDao;
    }

    public void setFarmFlexCreditControlAreaFilter(CreditControlAreaFilter farmFlexCreditControlAreaFilter) {
        this.farmFlexCreditControlAreaFilter = farmFlexCreditControlAreaFilter;
    }

    public void setCreditControlAreaDao(CreditControlAreaDao creditControlAreaDao) {
        this.creditControlAreaDao = creditControlAreaDao;
    }

    public boolean isValidationRequired() {
    return validationRequired;
  }

    public void setValidationRequired(boolean validationRequired) {
    this.validationRequired = validationRequired;
  }

    public static final XmlNamespace NAMESPACE_CUST_RESPONSE = new XmlNamespace("ecms", "urn:ecms:schema:entity:response:2:0");

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
    public String getId() {
    return "CUSTSR2";
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
    public ServiceOutput executeSecure( ServiceInput input, Subject subject ) throws ServiceException {

        ServiceOutput output = new ServiceOutput();
        String conversationId = Utilities.generateConversationId();
        IdentityPrincipal identityPrincipal = SecurityUtil.getIdentityPrincipal(subject);
        String xpathTransaction = inputXmlMessageInformer.getXpathTransaction();
        XmlChunks inputXmlChunks = input.getXmlChunks();

        Logger.log(new LoggableInfo( "Processing Customer Search request with conversation Id: " + conversationId ) );
        output.setConversationId( conversationId );
        inputXmlChunks.setXpathRepeatingElement(xpathTransaction);

        XmlDocument inputDocument = inputXmlChunks.getXmlDocument( xmlDocumentBuilder );
        String growerIds = getAccountIdsFromInputDocument( inputDocument );
        List customerList = null;

        final String seedYear = EcmsXmlUtils.getSeedYearFromInputDocument( inputDocument ) + "M";

        if ( StringUtils.isEmpty( growerIds ) ) {

            GrowerCriteria growerCriteria = CustomerSearchHelper.getGrowerCriteriaFromInputDocument( inputDocument );
            customerList = customerSearchDao.getCustomerDetailsWithAgreementCode( growerCriteria, seedYear );
            growerIds = createGrowerIdsFromCustomerList( customerList );
        } else {

            customerList = customerSearchDao.getCustomerDetailsWithGrowerIds( growerIds, seedYear );
        }

        if (!StringUtils.isEmpty(growerIds)) {

            customerList = farmFlexObjectFactory.createMergeGrowerCreditInfoWithGrowerDetails(customerList,
            buildGrowerCreditInfoListFromGrowerIds(growerIds, inputDocument), idMapperDao).buildMergedData();
        }

        XmlChunks outputXmlChunks = buildCustomerSearchDocuments( conversationId, identityPrincipal, customerList );

        Logger.log( new LoggableInfo( "Amount of returned Customers: " + customerList.size() ) );
        output.getXmlChunks().addChunks(outputXmlChunks);

        return output;
    }

    private String createGrowerIdsFromCustomerList(List customerList) {
        StringBuilder ids = new StringBuilder();

        if (customerList.isEmpty()) {
            return "";
        }
        ids.append(customerList.get(0) instanceof GrowerDetails ? ((GrowerDetails) customerList.get(0)).getCustomerIds().getAccountId() : "");
        for (int i = 1; i < customerList.size(); i++) {
            if (customerList.get(i) instanceof GrowerDetails) {
                ids.append(",").append(((GrowerDetails) customerList.get(i)).getCustomerIds().getAccountId());
            }
        }
        return ids.toString();
    }

    private String convertGrowerIdsIntoSapIds(String growerIds) {
        if (StringUtils.isEmpty(growerIds)) {
            return null;
        }
        List<String> growerIdList = Arrays.asList(growerIds.split(","));
        List<String> sapIdList = new ArrayList<String>();

        for (String growerId : growerIdList) {
            try {
                String sapId = idMapperDao.findSAPIdByAccountId(Long.valueOf(growerId));
                if (sapId == null) {
                    sapId = idMapperDao.findSAPIdByAccountId(idMapperDao.findAccountIdByEBID(growerId));
                }
                sapId = sapId.startsWith("000") ? sapId.substring(3) : sapId;
                Logger.log(new LoggableInfo("Adding SAP Id: (" + sapId + "), from Account Id: (" + growerId + ")."));
                sapIdList.add(sapId);
            } catch (IncorrectResultSizeDataAccessException e) {
                Logger.log(new LoggableInfo("Could not get SAP Id from '" + growerId + "'."));
            }
        }

        return convertSapIdListIntoString(sapIdList);
    }

    private String convertSapIdListIntoString(List<String> sapIdList) {
        if (sapIdList == null) {
            return null;
        }
        if (sapIdList.isEmpty()) {
            return "";
        }
        StringBuilder sapIds = new StringBuilder(sapIdList.get(0));
        for (int i = 1; i < sapIdList.size(); i++) {
            sapIds.append(",").append(sapIdList.get(i));
        }
        return sapIds.toString();
    }

    private Map<Long, GrowerCreditInfo> buildGrowerCreditInfoListFromGrowerIds(String growerIds,
                                                                               XmlDocument inputDocument) throws ServiceException {
        Logger.log(new LoggableInfo("--==--==--==--==--"));
        Logger.log(new LoggableInfo("Grower Ids:      " + growerIds));
        String farmFlexGrowerIds = farmFlexCreditControlAreaFilter.filter(creditControlAreaDao, growerIds, farmFlexObjectFactory.createMappingSqlQueryForFarmFlexCreditControlAreaFilter());
        Logger.log(new LoggableInfo("" + JdbcCreditControlAreaDao.INT_CREDIT_CTRL_AREA_CODE + " Grower Ids: " + growerIds));
        String sapGrowerIds = convertGrowerIdsIntoSapIds(farmFlexGrowerIds);
        Logger.log(new LoggableInfo("SAP Grower Ids:  " + sapGrowerIds));
        try {
            Map<Long, GrowerCreditInfo> map = new HashMap<Long, GrowerCreditInfo>();
            if (!StringUtils.isEmpty(sapGrowerIds)) {
                List<GrowerCreditInfo> growersCreditsInfo = farmFlexObjectFactory.createGetCreditInfoServiceInvoker()
                                                                                 .getGrowerCreditInfo( Arrays.asList( sapGrowerIds.split( "," ) ),
                                                                                                       new GrowerCreditInfoClientInfo( inputDocument,
                                                                                                                                       System.getProperty("lsi.function" ) ) );
                for ( GrowerCreditInfo growerCreditInfo : growersCreditsInfo ) {

                    Logger.log(new LoggableInfo( "####Adding growerAccountId: " + growerCreditInfo.getGrowerAccountId() + " growerCreditInfo: " + growerCreditInfo ));
                    map.put(new Long(growerCreditInfo.getGrowerAccountId()), growerCreditInfo);
                }
            }
            Logger.log( new LoggableInfo( "$$$Quantity of info added to map: " + map.size() ) );
            return map;
        } catch (com.monsanto.commercial.growercreditlist.exception.ServiceException serviceException) {
            throw new ServiceException("CustomerSearch2Impl.buildGrowerCreditInfoListGrowerIds(" + growerIds + ");\n" +
                  serviceException.getMessage(), serviceException);
        }
    }

    private XmlChunks buildCustomerSearchDocuments( final String conversationId,
                                                    final IdentityPrincipal identityPrincipal,
                                                    List customerList ) {
        int chunkSize = outputXmlMessageInformer.getChunkSize();
        XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks( customerList, chunkSize, new XmlStreamListAppender() {

            public XmlStream buildXmlStream(List domainItems) {

                return customerListSerializer.buildCustomerSearchDocument(conversationId, identityPrincipal, domainItems);
            }
        });
        return outputXmlChunks;
    }

    protected String getAccountIdsFromInputDocument(XmlDocument inputDocument) {

        XmlElement entityInquiry = null;
        XmlElement entityInformation = null;
        XmlElement industryIdentifier = null;
        XmlElement industryCode = null;

        List entityInformationList = null;
        List industryIdentifierList = null;
        List industryCodeList = null;

        String accountId = null;
        StringBuffer allAccountIds = new StringBuffer();
        int accountIdsCount = 0;
        List aGIISEntityInquiryDetails = inputDocument.selectElementsByXPath(CustomerSearchHelper.XPATH_ENTITY_INFO_ENTITYINQUIRY);

        //To find count to create array of account ids
    int aGIISEntityInquiryCount = inputDocument.getElementCountByXPath(
          CustomerSearchHelper.XPATH_ENTITY_INFO_ENTITYINQUIRY);
    String [] accountIdsWithDuplicate = new String[aGIISEntityInquiryCount];

    for (Iterator entityInquiryList = aGIISEntityInquiryDetails.iterator(); entityInquiryList
        .hasNext();) {
      entityInquiry = (XmlElement) entityInquiryList.next();
      // EntityInquiry
      if ("EntityInquiry".equals(entityInquiry.getUnqualifiedName())) {
        entityInformationList = entityInquiry.getChildren();

        for (Iterator entityInformationIterator = entityInformationList
            .iterator(); entityInformationIterator.hasNext();) {
          entityInformation = (XmlElement) entityInformationIterator.next();
          // EntityInformation
          if ("EntityInformation"
              .equals(entityInformation.getUnqualifiedName())) {
            industryIdentifierList = entityInformation.getChildren();
            for (Iterator industryIdentifierIterator = industryIdentifierList
                .iterator(); industryIdentifierIterator.hasNext();) {
              industryIdentifier = (XmlElement) industryIdentifierIterator
                  .next();
              // IndustryIdentifier
              if ("IndustryIdentifier".equals(industryIdentifier
                  .getUnqualifiedName())) {
                industryCodeList = industryIdentifier.getChildren();
                for (Iterator industryCodeIterator = industryCodeList
                    .iterator(); industryCodeIterator.hasNext();) {
                  industryCode = (XmlElement) industryCodeIterator.next();
                  if ("IndustryCode".equals(industryCode.getUnqualifiedName())) {
                    accountId = industryCode.getText();
                    accountIdsWithDuplicate[accountIdsCount++] =accountId;
                  }
                }
              }
            }
          }
        }
      }
    }
    String accountIds = null;
//  if no account id from request its keeping null in array
	if(accountIdsWithDuplicate[0]!=null)
	{

	    // logic to eliminate duplicate account ids.
	    Arrays.sort(accountIdsWithDuplicate);
	    int uniqueCount = 1;
	    for (int count = 1; count < accountIdsWithDuplicate.length; count++)
	    {
	    	if (! accountIdsWithDuplicate[count].equals(accountIdsWithDuplicate[count -1]))
	    	{
	    		accountIdsWithDuplicate[uniqueCount++] = accountIdsWithDuplicate[count];
	    	}
	    }

	    String[] unique = new String[uniqueCount];
	    System.arraycopy(accountIdsWithDuplicate, 0, unique, 0, uniqueCount);


	    //create account id string buffer with unique account ids
	    for (int count = 0; count < unique.length; count++)
	    {
	    	allAccountIds.append(unique[count]);
	        allAccountIds.append(",");

	    }

	    // removing , at the end
	    accountIds = allAccountIds.toString();
	    int length = accountIds.length();
	    if (length > 0) {
	      if (',' == accountIds.charAt(length - 1)) {
	        accountIds = accountIds.substring(0, length - 1);
	      }
	    }
	}
//    Logger.log(new LoggableInfo("In CustomerSearch2Impl Account Ids : "+ accountIds));

    return accountIds;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setInputXmlMessageInformer(
      XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(
      XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setCustomerSearchDao(CustomerSearchDao customerSearchDao) {
    this.customerSearchDao = customerSearchDao;
  }

  public void setCustomerListSerializer(
      CustomerListSerializer customerListSerializer) {
    this.customerListSerializer = customerListSerializer;

  }
}
