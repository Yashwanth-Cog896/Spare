package com.monsanto.ag.cf.domain;

import com.monsanto.ag.xml.XmlElement;

import java.util.Iterator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/22/13
 * Time: 9:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductXmlElementBuilder {

    public void appendXmlToElement( Product product, XmlElement baseXmlElement ){

        XmlElement rootElement = baseXmlElement.addChildElement( "ProductInformation" );
        setActiveFlagAttribute( product, rootElement);
        setActionRequestAttribute( product, rootElement );

        XmlElement productIdElement = rootElement.addChildElement( "ProductIdentification" );
        productIdElement.addChildElement( "ProductIdentifier", product.getAGIISIdentifier() );
        productIdElement.addChildElement( "ProductName", product.getAGIISName() );

        product.addTypeSpecificChildElements( rootElement );

        Iterator itPackaging = product.getPackagings().iterator();
        while( itPackaging.hasNext() ) {

            Packaging packaging = ( Packaging ) itPackaging.next();
            packaging.appendXmlToElement( rootElement );
        }
    }

    private void setActiveFlagAttribute( Product product, XmlElement rootElement ){

        if( !product.isEcListMaterial() ){

            rootElement.setAttribute( "ActiveFlag", AgiisEntity.ACTIVE_FLAG_FALSE );
        }
        else{

            product.setActiveFlagAttribute( rootElement );
        }
    }

    private void setActionRequestAttribute( Product product, XmlElement rootElement ){

        if( !product.isEcListMaterial() ){

            rootElement.setAttribute( "ActionRequest", AgiisEntity.ACTION_REQUEST_DELETE );
        }
        else{

            product.setActionRequestAttribute( rootElement );
        }
    }
}
