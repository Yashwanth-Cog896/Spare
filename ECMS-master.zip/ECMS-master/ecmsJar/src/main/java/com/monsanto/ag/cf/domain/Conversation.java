/*
 * Conversation was created on May 6, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Identifies a specific conversation between a user and Monsanto.
 * <p>
 * TODO Should this be moved into CPITCommon at some point?
 * 
 * @author Gareth Davies
 * @version $Id: Conversation.java,v 1.7 2005-11-21 20:27:53 caggarw Exp $
 */
public class Conversation extends Entity {

  public static final String USERID_PROPERTY_KEY = "ProducerUserId";
  public static final String ACCOUNTID_PROPERTY_KEY = "DealerAccountId";

  private String userId;
  private long accountId;
  private String conversationId;
  protected String dataSource;

  public Conversation() {
  }

  public Conversation(String userId, long accountId, String conversationId) {
    setUserId(userId);
    setAccountId(accountId);
    setConversationId(conversationId);
  }

  public String getUserId() {
    return userId;
  }

  protected void setUserId(String userId) {
    if (StringUtils.isBlank(userId) && UserActivity.DATA_SOURCE_SEEDTRAK_CLIENT.equals(dataSource)) {
      throw new UserActivityIncompleteException("User Id is required");
    }
      if(StringUtils.isBlank(userId)){
          userId = "dummyUserId";
      }
    this.userId = userId;
  }

  public long getAccountId() {
    return accountId;
  }

  protected void setAccountId(long accountId) {
    this.accountId = accountId;
  }

  public String getConversationId() {
    return conversationId;
  }

  protected void setConversationId(String conversationId) {
    if (StringUtils.isBlank(conversationId)) {
      throw new UserActivityIncompleteException("Conversation Id is required");
    }
    this.conversationId = conversationId;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof Conversation)) {
      return false;
    }
    Conversation rhs = (Conversation) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(userId,
        rhs.getUserId()).append(accountId, rhs.getAccountId()).append(
        conversationId, rhs.getConversationId()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 3).appendSuper(super.hashCode()).append(
        userId).append(accountId).append(conversationId).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(
        super.toString()).append("userId", userId).append("accountId",
        accountId).append("conversationId", conversationId).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.6  2005/08/26 16:10:56  ggdavi
 * Moved the Identifiable and Entity classes to the ag.util package and the ServiceAdvice class to the ag.soa package for better dependency management
 *
 * Revision 1.5  2005/07/08 17:13:58  ggdavi
 * Pulled up accountId from UserActivity
 * Revision 1.4 2005/06/20 17:12:36 ggdavi Moved
 * Entity and Identifiable back to ag.cf.domain from ag.domain (sorry about
 * that...)
 * 
 * Revision 1.3 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.2 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.1 2005/05/09 18:05:29 ggdavi Initial version
 * 
 */