/*
 * ProductLightSerializerImpl was created on Oct 1, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.domain.AGIISSubscriberResults;
import com.monsanto.ag.cf.domain.AppConstants;
import com.monsanto.ag.cf.domain.PackageStructure;
import com.monsanto.ag.cf.domain.ProductLight;
import com.monsanto.ag.cf.service.ProductLightSerializer;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.util.UOMConverter;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlStream;

/**
 * Serializer to create the Product Light Response Document.
 * 
 * @author Chetna Aggarwal
 * @version $Id: ProductLightSerializerImpl.java,v 1.13 2009/07/21 20:15:45 mkuchip Exp $
 */
public class ProductLightSerializerImpl implements ProductLightSerializer {

  private XmlDocumentBuilder xmlDocumentBuilder;

  /**
   * @see com.monsanto.ag.cf.service.ProductLightSerializer#buildProductLightDocument(java.util.List)
   */
  public XmlStream buildProductLightDocument(List domainItems) {
	    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
	    XmlElement rootElement = outputDocument.addRootElement("Products", ProductLightImpl.NAMESPACE_PROD_LIGHT_RESPONSE,
	        "1.0");

	    for (Iterator iter = domainItems.iterator(); iter.hasNext();) {
	      ProductLight product = (ProductLight) iter.next();
	      addProductNode(product, rootElement);
	    }
	    return outputDocument;
  }

  public XmlStream buildProductLightDocument(List domainItems, AGIISSubscriberResults agiisSubscriberResults) {
	    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
	    XmlElement rootElement = outputDocument.addRootElement("Products", ProductLightImpl_2.NAMESPACE_PROD_LIGHT_RESPONSE,
	        "2.0");

	    for (Iterator iter = domainItems.iterator(); iter.hasNext();) {
	      ProductLight product = (ProductLight) iter.next();
	      addProductNodeForOtherSeedBrandsVersion(product, rootElement);
	    }
	    addAGIISSubscriberResults(rootElement, agiisSubscriberResults);
	    return outputDocument;
	  }  
  
  private void addAGIISSubscriberResults(XmlElement rootElement, AGIISSubscriberResults agiisSubscriberResults) {
	  if (agiisSubscriberResults != null) {
		if (!agiisSubscriberResults.isServiceAvailable()) {
			rootElement.addChildElement("SvcNotAvail");		   
		}
		if (!agiisSubscriberResults.isCustomerAbleToReceiveOtherSeedBrands()) {
			rootElement.addChildElement("MbrNotAuthor");		   
		}
	  }
  }
  
  private void addCommonProductNodeFields(ProductLight product, XmlElement productElement) {
	    String descr2 = StringUtils.isNotEmpty(product.getLegalDescr2()) ? " " + product.getLegalDescr2() : "";
	    productElement.setAttribute("name", product.getLegalDescr1() + descr2);
	    String category = (String) PRODUCT_CLASS_MAP.get(product.getProdClassId());
	    productElement.setAttribute("category", category == null ? "" : category);
	    productElement.setAttribute("manufacturer", product.getBrandName());
	    productElement.setAttribute("cropName", product.getSpecieDescr());
	    productElement.setAttribute("traitName", product.getDisplayDescr());

	    PackageStructure package1 = product.getPackage1();
	    long unitQuantity = 0;
	    if (package1 != null) {
		    unitQuantity = package1.getUnitQty();	    	
//	      if (StringUtils.equalsIgnoreCase("SS", product.getStUOMCode())) {
//	        if (StringUtils.equalsIgnoreCase("CORN", product.getSpecieDescr())) {
//	          unitQuantity = package1.getProdUnitConv() / 80;
//	        } else {
//	          unitQuantity = package1.getProdUnitConv() / 50;
//	        }
//	      } else {
//	        unitQuantity = 1;
//	      }
	    }
	    productElement.setAttribute("unitQuant", String.valueOf(unitQuantity));
	    productElement.setAttribute("baseUom", product.getBaseUom());

	    productElement.setAttribute("rptUom", getReportingUnitOfMeasure(product, package1));
	    
	    XmlElement packageElement = productElement.addChildElement("Package");
	    packageElement.setAttribute("convBase", String.valueOf(package1.getProdUnitConv()));
	    packageElement.setAttribute("gtin", package1.getGtin());
	    packageElement.setAttribute("uom", package1.getUomCode());
  }

	private String getReportingUnitOfMeasure(ProductLight product,PackageStructure package1) {
		if (package1.getOrderUomId() == null) {
		    if (StringUtils.equalsIgnoreCase("Y", product.getUseSSU())) {
		      return "UN";
		    } else {
		      return package1.getUomCode();
		    }
		} else {		  
		  if (StringUtils.equalsIgnoreCase("SS", package1.getOrderUomId())) {
            return "UN";
          } 
		  else return package1.getOrderUomId();
		}
	}
 
  private void addProductNodeForOtherSeedBrandsVersion(ProductLight product, XmlElement rootElement) {
	    XmlElement productElement = rootElement.addChildElement("Product");
	    addCommonProductNodeFields(product, productElement);
	    productElement.setAttribute("companyID", product.getSeedCompanyEBID() == null ? "" : product.getSeedCompanyEBID());
	    productElement.setAttribute("brandName", product.getSeedBrandName() == null ? "" : product.getSeedBrandName());
	    productElement.setAttribute("othrBrand", product.getOtherSeedBrandFlag());
	    productElement.setAttribute("gposRpt", product.getGposReportFlag());
	    productElement.setAttribute("irm", product.getIrmFlag());
        productElement.setAttribute("dlrTreated", (AppConstants.ACCELERON_TREATMENT_CODE.equalsIgnoreCase(product.getTreatmentCode()))? "true" : "false");
        productElement.setAttribute("treatmentCde", product.getTreatmentCode());
        productElement.setAttribute("treatmentDesc", product.getTreatmentDescr());
  }
  
  private void addProductNode(ProductLight product, XmlElement rootElement) {
    XmlElement productElement = rootElement.addChildElement("Product");
    addCommonProductNodeFields(product, productElement);
  }

  private String getConvertedUNREC20Code(String IRDuomCode) {
    UOMConverter converter = new UOMConverter();
    String   UNREC20uomCode = null;
    try{
      UNREC20uomCode = converter.findUNREC20Code(IRDuomCode);  
      if ("SS".equalsIgnoreCase(UNREC20uomCode)) {
        return "UN";
      }
    }catch(Exception e){
      Logger.log(new LoggableInfo("Can not convert IRD Code : "+IRDuomCode+" to UNREC20 code. No mapping value exist in mapper"));
      Logger.log(new LoggableInfo("UOM Converter Exception :"+e.getMessage()));
      throw new ServiceException("UOM Converter Exception - From IRD Code to UNREC20 = "+e.getMessage());
    }
    return UNREC20uomCode;
  }

  private static final Map PRODUCT_CLASS_MAP;
  static {
    Map productClassIdMap = new HashMap();
    productClassIdMap.put("D", "SKU Seed");
    productClassIdMap.put("H", "Herbicide");
    productClassIdMap.put("N", "Non-Product");
    productClassIdMap.put("S", "Generic Seed");
    productClassIdMap.put("B", "biotechnology");
    productClassIdMap.put("C", "CSH(Licensee)Seed");
    PRODUCT_CLASS_MAP = Collections.unmodifiableMap(productClassIdMap);
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }
  
}
