/*
 * CustomerIds was created on Jul 24, 2007 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * Represents the customer identifiers for an Entity.
 *
 * @author Chetna Aggarwal
 * @version $Id: CustomerIds.java,v 1.2 2007-08-28 15:42:25 caggarw Exp $
 */
public class CustomerIds {

  private long accountId;
  private String sapId;
  private String napdId;
  private String glnId;

  public CustomerIds(long accountId, String sapId, String napdId, String glnId) {
    super();
    this.accountId = accountId;
    this.sapId = sapId;
    this.napdId = napdId;
    this.glnId = glnId;
  }

  public CustomerIds() {
  }

  public long getAccountId() {
    return accountId;
  }

  public void setAccountId(long accountId) {
    this.accountId = accountId;
  }

  public String getGlnId() {
    return glnId;
  }

  public String getNapdId() {
    return napdId;
  }

  public String getSapId() {
    return sapId;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof CustomerIds)) {
      return false;
    }
    CustomerIds rhs = (CustomerIds) obj;
    return new EqualsBuilder().append(accountId, rhs.getAccountId()).append(sapId, rhs.getSapId()).append(napdId,
            rhs.getNapdId()).append(glnId, rhs.getGlnId()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(11, 17).append(accountId).append(sapId).append(napdId).append(glnId).toHashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}
