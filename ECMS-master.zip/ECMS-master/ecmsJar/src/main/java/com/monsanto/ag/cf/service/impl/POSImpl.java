/*
 * POSImpl was created on Apr 21, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import javax.xml.rpc.soap.SOAPFaultException;

import com.monsanto.ag.xml.XmlDocument;

/**
 * POJO implementation of the various POS services.
 * <p/>
 * As of 2/18/08, code was refactored to move code in common between this
 * class and GPOSLiteImpl into POSImplBase.
 * 
 * @author Gareth Davies
 * @version $Id: POSImpl.java,v 1.20 2008-02-18 17:09:58 maschec Exp $
 */
public class POSImpl extends POSImplBase {


  /**
   * No transformation of incoming request is needed prior to calling WebMethods
   * service, so just return the incoming request.
   * 
   * @see com.monsanto.ag.cf.service.impl.POSImplBase#transformRequestAsNeeded(com.monsanto.ag.xml.XmlDocument)
   */
  protected XmlDocument transformRequestAsNeeded(XmlDocument requestDocument) throws SOAPFaultException {
    return requestDocument;
  }


}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.19  2008/02/15 19:54:09  maschec
 * Refactor POSImpl_UT into POSImplUTBase, so that tests can also be run using GPOSLiteImpl
 *
 * Revision 1.18  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.17  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.16  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.15  2005/11/08 21:00:31  ggdavi
 * Updated after adding XmlStream (and StAX implementation) to the com.monsanto.ag.util package and refactoring the ServiceInput and ServiceOutput classes to expose both XmlStream and XmlDocument objects
 *
 * Revision 1.14  2005/08/26 16:26:09  ggdavi
 * Javadoc corrections
 *
 * Revision 1.13  2005/08/26 16:10:56  ggdavi
 * Moved the Identifiable and Entity classes to the ag.util package and the ServiceAdvice class to the ag.soa package for better dependency management
 *
 * Revision 1.12  2005/08/23 17:14:38  ggdavi
 * Modified SecureService.executeSecure method signature to accept a ServiceInput argument instead of a List and return a ServiceOutput object instead of a List
 *
 * Revision 1.11  2005/08/05 18:37:57  ggdavi
 * Removed deprecated executeSecure method based on DOM documents
 * Revision 1.9 2005/07/21 14:48:57 ggdavi Fleshed out
 * and refactored com.monsanto.ag.util to make more object-oriented, in that
 * most functionality has been pushed to the XmlDocument and XmlElement objects
 * 
 * Revision 1.8 2005/07/14 21:42:13 ggdavi Renamed BaseMessageProducer to
 * JmsSupport
 * 
 * Revision 1.7 2005/07/08 17:31:32 ggdavi Pulled up some methods to JmsSupport,
 * which this class now extends Revision 1.6 2005/07/06 21:12:15 ggdavi Added
 * xmlDocumentBuilder field, used to build output XML documents Revision 1.5
 * 2005/06/30 20:24:20 ggdavi Use node.getOwnerDocument instead of
 * helper.getDocument(node)
 * 
 * Revision 1.4 2005/06/20 17:12:36 ggdavi Moved Entity and Identifiable back to
 * ag.cf.domain from ag.domain (sorry about that...)
 * 
 * Revision 1.3 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.2 2005/06/17 18:20:45 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security; moved CidxDocumentHelper from
 * ag.cf.service.impl to ag.util
 * 
 * Revision 1.1 2005/06/01 20:30:45 ggdavi Renamed GPOSImpl to POSImpl since it
 * is now generic to all POS messages; validated output document against schema
 * Revision 1.16 2005/05/31 20:38:42 ggdavi Throw SOAPFaultExceptions instead of
 * creating SOAPFault documents Revision 1.15 2005/05/18 18:18:39 ggdavi
 * Overhauled ag.soa.client package, replacing Farmsource and WebMethods
 * specific subclasses of BaseSoaClient with XmlHttpSoaClient, whose behavior is
 * parameterized via collaborators
 * 
 * Revision 1.14 2005/05/17 20:25:03 ggdavi Converted XmlMessageInformer from an
 * interface with accessors only to a fully-fledged bean class Revision 1.13
 * 2005/05/17 16:31:51 ggdavi Extracted ag.util.XmlDateTimeUtil and
 * ag.soa.ErrorDocument from ag.util.Utilities
 * 
 * Revision 1.12 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.11 2005/05/16 20:11:11 ggdavi Added cidx prefix to all XPaths
 * 
 * Revision 1.10 2005/05/11 21:50:33 ggdavi Renamed all Subject method
 * parameters from user to subject for clarity
 * 
 * Revision 1.9 2005/05/06 17:51:55 ggdavi Renamed XPathExporter to
 * XmlMessageInformed and XPathDefiner to XmlMessageInformer
 * 
 * Revision 1.8 2005/05/03 18:21:11 ggdavi Added logging step and implicit use
 * of XmlMessageConverter Revision 1.7 2005/05/02 15:00:50 ggdavi Added
 * exception test cases Revision 1.6 2005/04/27 22:14:51 ggdavi Completed
 * initial implementation, successfully sending the XML document to a JMS queue
 * Revision 1.5 2005/04/27 21:10:35 ggdavi Implemented executeSecure Revision
 * 1.4 2005/04/26 21:29:41 ggdavi Updated getXPathConversationId method
 * 
 * Revision 1.3 2005/04/25 17:31:20 ggdavi Added getXPathConversationId and
 * getXPathStartTime methods to XmlMessageInformer Revision 1.2 2005/04/22
 * 16:16:07 ggdavi Now extends BaseServiceImpl to simplify interface
 * implementation and to provide a default XmlMessageInformer Revision 1.1
 * 2005/04/21 19:15:22 ggdavi Initial version
 * 
 */