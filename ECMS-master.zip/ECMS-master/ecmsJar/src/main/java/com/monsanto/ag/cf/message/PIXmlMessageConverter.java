package com.monsanto.ag.cf.message;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import org.apache.commons.lang.StringUtils;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;
import java.io.StringReader;

public class PIXmlMessageConverter implements MessageConverter {

  private XmlDocumentBuilder xmlDocumentBuilder;

  /**
   * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object,
   *      javax.jms.Session)
   */
  public Message toMessage(Object object, Session session) throws JMSException,
          MessageConversionException {
    if (object == null) {
      return session.createTextMessage(StringUtils.EMPTY);
    } else if (object instanceof XmlDocument) {
      XmlDocument xmlDocument = (XmlDocument) object;
      return session.createTextMessage(xmlDocument.toString());
    } else {
      throw new MessageConversionException("Cannot convert object [" + object
          + "] to JMS message");
    }
  }

  /**
   * @see org.springframework.jms.support.converter.MessageConverter#fromMessage(javax.jms.Message)
   */
  public Object fromMessage(Message message) throws JMSException,
      MessageConversionException {
    try {

      String encoding = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
      String messageText =   ((TextMessage) message).getText();

      if(StringUtils.isNotEmpty(messageText)) {
        messageText = encoding + generateHeader(message) +  messageText + generateFooter();
      }
      Logger.log(new LoggableInfo("messageText: " + messageText));
      if (StringUtils.isEmpty(messageText)) {
        return XmlDocument.NULL;
      } else {
        return xmlDocumentBuilder.createXmlDocument(new StringReader(
            messageText));
      }
    } catch (Exception e) {
      Logger.log(new LoggableWarning(e));
      throw new MessageConversionException("Cannot convert JMS message ["
          + message + "] to XML Document");
    }
  }

  private String generateHeader(Message message) throws Exception{
      StringBuffer sb = new StringBuffer();

      sb.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">");
      sb.append("<soapenv:Header>");
      sb.append("<monsh:nexusGatewayMetadata xmlns:monsh=\"urn:ecms:soap:header\">");
      sb.append("<monsh:nexusConversationId>"+message.getJMSCorrelationID()+"</monsh:nexusConversationId>");
      sb.append("</monsh:nexusGatewayMetadata>");
      sb.append("</soapenv:Header>");
      sb.append("<soapenv:Body>");

      return sb.toString();
  }

  private String generateFooter() throws Exception{
      StringBuffer sb = new StringBuffer();

      sb.append("</soapenv:Body>");
      sb.append("</soapenv:Envelope>");

      return sb.toString();
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}