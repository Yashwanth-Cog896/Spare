/*
 * SpecialInstructions was created on May 12, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;


/**
 * Represents a set of special instructions for a user when exchanging data
 * through a specific service.
 * 
 * @author Gareth Davies
 * @version $Id: SpecialInstructions.java,v 1.7 2005-08-26 16:10:56 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC56
 */
public class SpecialInstructions implements Serializable {

  private long accountId;
  private String serviceId;
  private Set instructions;

  public SpecialInstructions() {
    instructions = new HashSet();
  }

  public SpecialInstructions(long accountId, String appId) {
    this();
    this.accountId = accountId;
    this.serviceId = appId;
  }

  public long getAccountId() {
    return accountId;
  }

  public String getServiceId() {
    return serviceId;
  }

  public Iterator getIterator() {
    return instructions.iterator();
  }

  public void addInstruction(String instruction) {
    instructions.add(instruction);
  }

  public boolean contains(String instruction) {
    return instructions.contains(instruction);
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof SpecialInstructions)) {
      return false;
    }
    SpecialInstructions rhs = (SpecialInstructions) obj;
    return new EqualsBuilder().append(accountId, rhs.getAccountId()).append(
        serviceId, rhs.getServiceId()).append(instructions, rhs.instructions)
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 15).append(accountId).append(serviceId)
        .append(instructions).toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).append(
        "accountId", accountId).append("serviceId", serviceId).append(
        "instructions", instructions).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.6  2005/07/14 21:35:06  ggdavi
 * Added contains method
 *
 * Revision 1.5  2005/06/20 17:12:36  ggdavi
 * Moved Entity and Identifiable back to ag.cf.domain from ag.domain (sorry about that...)
 *
 * Revision 1.4  2005/06/20 16:40:27  ggdavi
 * Moved Entity and Identifiable from ag.cf.domain to ag.domain
 *
 * Revision 1.3  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.2  2005/05/13 14:00:37  ggdavi
 * Added traceability to javadoc
 *
 * Revision 1.1  2005/05/12 21:25:55  ggdavi
 * Initial version
 *
 */