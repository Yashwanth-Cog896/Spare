/*
 * NoDDLOracleJDBCAdapter was created on May 5, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.persistence;

import java.sql.Connection;
import java.sql.SQLException;

import org.activemq.store.jdbc.adapter.OracleJDBCAdapter;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;

/**
 * Extends ActiveMQ's OracleJDBCAdapter by preventing the creation and dropping
 * of tables.
 * 
 * @author Gareth Davies
 * @version $Id: NoDDLOracleJDBCAdapter.java,v 1.1 2005-06-30 17:43:25 ggdavi Exp $
 */
public class NoDDLOracleJDBCAdapter extends OracleJDBCAdapter {

  public NoDDLOracleJDBCAdapter() {
    super();
    Logger.log(new LoggableInfo("ActiveMQ durable messaging is using "
        + getClass().getName()));
  }

  public void doCreateTables(Connection c) throws SQLException {
    Logger.log(new LoggableInfo(
        "There will be no attempt to create tables for ActiveMQ!"));
  }

  public void doDropTables(Connection c) throws SQLException {
    Logger.log(new LoggableInfo(
        "There will be no attempt to drop tables for ActiveMQ!"));
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/06 17:41:13  ggdavi
 * Initial version
 *
 */