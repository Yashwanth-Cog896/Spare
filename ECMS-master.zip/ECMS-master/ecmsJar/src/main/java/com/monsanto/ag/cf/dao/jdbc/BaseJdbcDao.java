/*
 * BaseJdbcDao was created on May 6, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer;

/**
 * Provides convenience methods for Spring JDBC DAO implementations.
 * 
 * @author Gareth Davies
 * @version $Id: BaseJdbcDao.java,v 1.3 2008-07-01 15:57:27 rwspeh Exp $
 */
public abstract class BaseJdbcDao extends JdbcDaoSupport {

  protected static final String FLAG_TRUE = "Y";
  protected static final String FLAG_FALSE = "N";  
  private OracleSequenceMaxValueIncrementer maxValueIncrementer;

  protected String getNextSequenceValue() {
    if (maxValueIncrementer == null) {
      throw new DataIntegrityViolationException(
          "No incrementer was specified for new records of this type");
    } else {
      return maxValueIncrementer.nextStringValue();
    }
  }

  public void setSequenceName(String sequenceName) {
    maxValueIncrementer = new OracleSequenceMaxValueIncrementer();
    maxValueIncrementer.setDataSource(getDataSource());
    maxValueIncrementer.setIncrementerName(sequenceName);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/09/28 19:12:55  ggdavi
 * Moved Farm Manager role business logic out of DAO and into domain object
 *
 * Revision 1.1  2005/05/09 18:05:29  ggdavi
 * Initial version
 *
 */