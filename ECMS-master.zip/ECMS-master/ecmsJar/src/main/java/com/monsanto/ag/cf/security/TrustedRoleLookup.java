package com.monsanto.ag.cf.security;

import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.RolePrincipal;
import org.apache.commons.lang.ObjectUtils;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jun 4, 2010
 * Time: 6:51:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class TrustedRoleLookup implements RoleLookupClient {

    private static final long TRUSTED_APPLICATION_ACCOUNT_ID = Long.MAX_VALUE;
    private static final String TRUSTED_APPLICATION_EBUSINESS_ID = "0062668030000";
    private static final String TRUSTED_APPLICATION = "TRUSTED_APPLICATION";

    private String username;

    public javax.security.auth.Subject findRoles(String userId) throws LoginException {

        if (ObjectUtils.equals(username, this.username)) {

            Subject subject = new Subject();

            IdentityPrincipal idPrincipal = new IdentityPrincipal(userId,
                    TRUSTED_APPLICATION_ACCOUNT_ID, TRUSTED_APPLICATION_EBUSINESS_ID);
            subject.getPrincipals().add(idPrincipal);

            RolePrincipal rolePrincipal = new RolePrincipal(TRUSTED_APPLICATION);
            subject.getPrincipals().add(rolePrincipal);

            return subject;
        }

        throw new LoginException(RoleLookupClient.DEFAULT_ERROR_MESSAGE);
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
