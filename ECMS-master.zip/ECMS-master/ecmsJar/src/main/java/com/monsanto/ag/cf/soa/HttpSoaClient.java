package com.monsanto.ag.cf.soa;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.soa.client.httpclient.HttpRequestBuilder;
import com.monsanto.ag.soa.client.httpclient.HttpResponsePostProcessor;
import com.monsanto.ag.soa.client.httpclient.ServiceAuthenticator;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamBuilder;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
* SOA client for services exposed by sending XML messages over HTTP.
 */
public class HttpSoaClient implements SoaClient {

    public static final String HTTP_ERROR_MESSAGE = "The request to the service at {0} returned with an HTTP error: {1} - {2}";
    public static final String DEFAULT_XML_PARAMETER_NAME = "XmlPayload";

    private HttpClient httpClient;
    private XmlStreamBuilder xmlStreamBuilder;
    private boolean ignoreInternalServerErrors;
    private ServiceAuthenticator authenticator;
    private HttpRequestBuilder requestBuilder;
    private HttpResponsePostProcessor responsePostProcessor;

    /**
     * @see com.monsanto.ag.soa.client.SoaClient#call(java.lang.String,
     *      com.monsanto.ag.soa.ServiceInput)
     */
    public ServiceOutput call(String serviceId, ServiceInput input) throws ServiceException {
        String credentials = authenticator.prepareCredentials(serviceId);
        HttpMethod method = requestBuilder.buildRequest(serviceId, input, credentials);

        Logger.log(new LoggableInfo("Making request to service: " + serviceId));
        XmlChunks outputXmlChunks = makeServiceRequest(serviceId, input, method);
        Logger.log(new LoggableInfo("Got response from service: " + serviceId));

        return new ServiceOutput(outputXmlChunks);
    }

    private XmlChunks makeServiceRequest(String serviceId, ServiceInput input, HttpMethod method) {
        String genericErrorMessage = null;
        try {
            genericErrorMessage = MessageFormat.format(ERROR_MESSAGE, new Object[]{method.getURI()});

            invokeService(method);
            XmlChunks outputXmlChunks = buildXmlChunksFromServiceResponse(input, method);
            if (responsePostProcessor != null) {
                outputXmlChunks = responsePostProcessor.postProcess(outputXmlChunks, serviceId);
            }
            return outputXmlChunks;
        } catch (ServiceException e) {
            Logger.log(new LoggableWarning(genericErrorMessage + ": " + e.getMessage()));
            throw e;
        } catch (Exception e) {
            Logger.log(new LoggableWarning(genericErrorMessage + ": " + e.getMessage()));
            throw new ServiceException(genericErrorMessage, e);
        } finally {
            if (method != null) {
                method.releaseConnection();
            }
        }
    }

    protected void invokeService(HttpMethod method) throws IOException, HttpException {
        int responseCode = httpClient.executeMethod(method);
         Logger.log(new LoggableInfo("ResponseCode from Service: " + responseCode));
        if (serviceResultedInError(responseCode) && !(serviceErrorCanBeIgnored(responseCode))) {
            String errorMessage = MessageFormat.format(HTTP_ERROR_MESSAGE, new Object[]{method.getURI(),
                    new Integer(responseCode), method.getStatusText()});
            throw new ServiceException(errorMessage);
        }
    }

    private boolean serviceResultedInError(int responseCode) {
        return responseCode != HttpStatus.SC_OK;
    }

    private boolean serviceErrorCanBeIgnored(int responseCode) {
        return ignoreInternalServerErrors && responseCode == HttpStatus.SC_INTERNAL_SERVER_ERROR;
    }

    private XmlChunks buildXmlChunksFromServiceResponse(ServiceInput input, HttpMethod method) throws IOException {
        return new XmlChunks();
    }

    private InputStream getServiceResponseAsStream(ServiceInput input, HttpMethod method) throws IOException {
        if (input.isDoGzipCompression()) {
            return new GZIPInputStream(method.getResponseBodyAsStream());
        } else {
            return method.getResponseBodyAsStream();
        }
    }

    public void setHttpClient(HttpClient httpClient) {
        this.httpClient = httpClient;
    }

    public void setXmlStreamBuilder(XmlStreamBuilder xmlStreamBuilder) {
        this.xmlStreamBuilder = xmlStreamBuilder;
    }

    public void setIgnoreInternalServerErrors(boolean ignoreInternalServerErrors) {
        this.ignoreInternalServerErrors = ignoreInternalServerErrors;
    }

    public void setAuthenticator(ServiceAuthenticator authenticator) {
        this.authenticator = authenticator;
    }

    public void setRequestBuilder(HttpRequestBuilder requestBuilder) {
        this.requestBuilder = requestBuilder;
    }

    public void setResponsePostProcessor(HttpResponsePostProcessor responsePostProcessor) {
        this.responsePostProcessor = responsePostProcessor;
    }

} // end of class
