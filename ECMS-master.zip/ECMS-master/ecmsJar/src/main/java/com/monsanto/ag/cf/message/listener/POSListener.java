/*
 * POSListener was created on May 2, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.listener;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.commons.lang.StringUtils;
import org.springframework.jms.support.converter.MessageConverter;
import org.xml.sax.SAXException;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.EventDao;
import com.monsanto.ag.cf.domain.Conversation;
import com.monsanto.ag.cf.domain.SystemEvent;
import com.monsanto.ag.cf.message.DuplicateMessageException;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.client.ServiceFaultException;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlDocument;

/**
 * Consumes messages sent to any one of the POS message queues and forwards them
 * on to the appropriate WebMethods service.
 * <p>
 * Logs an event to the event log regardless of success or failure.
 * 
 * @author Gareth Davies
 * @version $Id: POSListener.java,v 1.7 2006-05-24 18:57:04 caggarw Exp $
 */
public class POSListener extends ServiceProxySupport implements MessageListener {

  public static final String KEY_CONVERSATION_ID = "ConversationID";
  public static final String STATUS_CODE_SUCCESS = "POSProcessingSuccessful";
  public static final String USERID_DEFAULT = "UNKNOWN";
  public static final long ACCOUNT_ID_DEFAULT = Long.MIN_VALUE;

  private EventDao eventDao;
  private MessageConverter messageConverter;

  /**
   * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
   */
  public void onMessage(Message message) {
    String conversationId = null;
    try {
      conversationId = getConversationIdOfMessage(message);
      Logger.log(new LoggableInfo("Processing message with Conversation Id: "
          + conversationId));

      checkForDuplicateRedelivery(message, conversationId);
      ServiceInput input = buildServiceInput(message, conversationId);
      soaClient.call(serviceId, input);
      logAndStoreSuccess(message, conversationId);
    } catch (ServiceFaultException e) {
      logAndStoreException(message, conversationId, e);
    } catch (ServiceException e) {
      logAndStoreException(message, conversationId, e);
      throw e;
    } catch (Exception e) {
      logAndStoreException(message, conversationId, e);
    }
  }

  private String getConversationIdOfMessage(Message message)
      throws JMSException {
    String conversationId = message.getJMSCorrelationID();
    return (StringUtils.isBlank(conversationId)) ? Utilities
        .generateConversationId() : conversationId;
  }

  private void checkForDuplicateRedelivery(Message message,
      String conversationId) throws JMSException {
    if (message.getJMSRedelivered()) {
      List events = eventDao.findEventsByConversationIdAndStatusCode(
          conversationId, STATUS_CODE_SUCCESS);
      if (!events.isEmpty()) {
        throw new DuplicateMessageException("Message with Conversation Id "
            + conversationId + " has already been successfully processed: "
            + events.get(0));
      }
    }
  }

  private ServiceInput buildServiceInput(Message message, String conversationId)
      throws JMSException, IOException, SAXException {
    XmlDocument messageDoc = extractXmlDocumentFromMessage(message);
    String rootNodeName = messageDoc.getRootElement().getUnqualifiedName();

    ServiceInput input = new ServiceInput(messageDoc, rootNodeName);
    input.addParameter(KEY_CONVERSATION_ID, conversationId);

    return input;
  }

  private XmlDocument extractXmlDocumentFromMessage(Message message)
      throws JMSException {
    return (XmlDocument) messageConverter.fromMessage(message);
  }

  private void logAndStoreSuccess(Message message, String conversationId) {
    Logger.log(new LoggableInfo(
        "Successfully processed message with Conversation Id: "
            + conversationId + " using service: " + serviceId));
    storeEvent(
        message,
        conversationId,
        STATUS_CODE_SUCCESS,
        "POSListener has successfully completed processing of POS data using the service: "
            + serviceId);
  }

  private void logAndStoreException(Message message, String conversationId,
      Exception e) {
    Logger.log(new LoggableError(e));
    storeEvent(message, conversationId, Utilities.getUnqualifiedClassName(e), e
        .getMessage());
  }

  private void storeEvent(Message message, String conversationId,
      String statusCode, String statusMessage) {
    try {
      String userId = getUserIdOfMessageProducer(message);
      long accountId = getAccountIdOfMessageProducer(message);
      SystemEvent event = new SystemEvent(userId, accountId, conversationId,
          new Date(), statusCode, statusMessage);
      Logger.log(new LoggableInfo("Recording system event " + event));
      eventDao.storeEvent(event);
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
    }
  }

  private long getAccountIdOfMessageProducer(Message message)
      throws JMSException {
    long accountId = 0;
    try {
      accountId = message.getLongProperty(Conversation.ACCOUNTID_PROPERTY_KEY);
    } catch (NumberFormatException e) {
      Logger.log(new LoggableWarning(e));
    }
    return (accountId == 0) ? ACCOUNT_ID_DEFAULT : accountId;
  }

  private String getUserIdOfMessageProducer(Message message)
      throws JMSException {
    String userId = message.getStringProperty(Conversation.USERID_PROPERTY_KEY);
    return (StringUtils.isBlank(userId)) ? USERID_DEFAULT : userId;
  }

  public void setEventDao(EventDao eventDao) {
    this.eventDao = eventDao;
  }

  public void setMessageConverter(MessageConverter messageConverter) {
    this.messageConverter = messageConverter;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.6  2005/12/01 19:34:31  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.5  2005/08/23 17:13:15  ggdavi
 * Moved ServiceInput and ServiceOutput from ag.soa.client to ag.soa
 *
 * Revision 1.4  2005/08/05 18:46:33  ggdavi
 * Use XmlDocument objects instead of DOM Document objects
 * Revision 1.2 2005/07/08 17:30:55 ggdavi Added
 * DealerAccountId message property Revision 1.1 2005/06/30 17:43:26 ggdavi
 * Moved ag.aop, ag.config and ag.message packages under the ag.cf package
 * 
 * Revision 1.4 2005/06/13 21:03:08 ggdavi Use getDocumentElement instead of
 * getFirstChild to get document root node
 * 
 * Revision 1.3 2005/06/07 21:17:54 ggdavi Add log statement before call to
 * eventDao
 * 
 * Revision 1.2 2005/06/03 20:43:22 ggdavi buildServiceInput now uses the name
 * of the document's root node as the name of the input document parameter
 * Revision 1.1 2005/06/01 20:30:07 ggdavi Renamed GPOSListener to POSListener
 * since it is now generic to all POS messages Revision 1.12 2005/05/31 20:41:23
 * ggdavi Use SOAP faults instead of a standard error document
 * 
 * Revision 1.11 2005/05/18 23:49:36 ggdavi Removed to do comments
 * 
 * Revision 1.10 2005/05/18 18:18:39 ggdavi Overhauled ag.soa.client package,
 * replacing Farmsource and WebMethods specific subclasses of BaseSoaClient with
 * XmlHttpSoaClient, whose behavior is parameterized via collaborators Revision
 * 1.9 2005/05/17 20:19:38 ggdavi Added serviceId to the success messages
 * Revision 1.8 2005/05/17 16:31:51 ggdavi Extracted ag.util.XmlDateTimeUtil and
 * ag.soa.ErrorDocument from ag.util.Utilities
 * 
 * Revision 1.7 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.6 2005/05/12 23:43:53 ggdavi Now throws a ServiceException if an
 * error document is returned from the SOA client Revision 1.5 2005/05/11
 * 19:18:13 ggdavi Added checkForDuplicateRedivery method and cleaned up logging
 * and event storing code Revision 1.4 2005/05/09 18:09:20 ggdavi Added code to
 * write to event table Revision 1.3 2005/05/05 19:04:01 ggdavi Moved
 * XmlMessageConverter from ag.cf.message to ag.message
 * 
 * Revision 1.2 2005/05/03 18:23:14 ggdavi Added logging statement Revision 1.1
 * 2005/05/03 18:14:53 ggdavi Initial version
 * 
 */