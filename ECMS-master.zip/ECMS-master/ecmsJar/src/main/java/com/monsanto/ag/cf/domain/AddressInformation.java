/*
 * AddressInformation was created on Jul 24, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * Represent the Address for an Entity.
 * 
 * @author Chetna Aggarwal
 * @version $Id: AddressInformation.java,v 1.1 2007-07-25 21:46:05 caggarw Exp $
 */
public class AddressInformation {

  private String street;
  private String city;
  private String state;
  private String zip;
  private String county;

  public AddressInformation(String street, String city, String state, String zip, String county) {
    super();
    this.street = street;
    this.city = city;
    this.state = state;
    this.zip = zip;
    this.county = county;
  }

  public String getCity() {
    return city;
  }

  public String getCounty() {
    return county;
  }

  public String getState() {
    return state;
  }

  public String getStreet() {
    return street;
  }

  public String getZip() {
    return zip;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof AddressInformation)) {
      return false;
    }
    AddressInformation rhs = (AddressInformation) obj;
    return new EqualsBuilder().append(street, rhs.getStreet()).append(city, rhs.getCity())
        .append(state, rhs.getState()).append(zip, rhs.getZip()).append(county, rhs.getCounty()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(31, 23).append(street).append(city).append(state).append(zip).append(county)
        .toHashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}
