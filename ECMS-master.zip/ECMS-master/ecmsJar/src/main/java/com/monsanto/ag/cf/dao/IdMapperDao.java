/*
 * AccountIdDao was created on Jul 20, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import org.springframework.dao.IncorrectResultSizeDataAccessException;

/**
 * Data Access Object for mapping AccountId and SAPId.
 * 
 * @author Chetna Aggarwal
 * @version $Id: IdMapperDao.java,v 1.4 2007-07-06 23:07:40 caggarw Exp $
 */
public interface IdMapperDao {

  public String findSAPIdByAccountId(long accountId) throws IncorrectResultSizeDataAccessException;

  public long findAccountIdByEBID(String EBID);
  
  public long findAccountIdBySAPId(String sapId);

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/07/26 17:11:53  ggdavi
 * IdMapperDao now treats SAP Ids as text, since that is how the materialized view treats it :-(
 * Revision 1.2 2005/07/21 18:21:44 ggdavi The
 * findAccountIdBySAPId method now expects a long parameter
 * 
 * Revision 1.1 2005/07/21 15:58:07 caggarw IdMapperDao to get SAPId and
 * AccountId from acct_xref_mv table
 * 
 */
