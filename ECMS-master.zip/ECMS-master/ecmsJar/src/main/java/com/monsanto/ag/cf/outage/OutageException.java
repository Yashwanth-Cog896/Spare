/*
 * OutageException was created on May 31, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.outage;

/**
 * Represents a scheduled outage for a particular service.
 * 
 * @author Gareth Davies
 * @version $Id: OutageException.java,v 1.1 2005-05-31 20:41:35 ggdavi Exp $
 */
public class OutageException extends RuntimeException {

  public OutageException(Outage outage) {
    super(outage.getMessage());
  }

}

/*
 * $Log: not supported by cvs2svn $
 */