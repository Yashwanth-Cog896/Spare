/*
 * EDNProducerDaoImpl was created on Jul 11, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import org.springframework.dao.DataAccessException;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.dao.ShipNoticePublicationDao;
import com.monsanto.ag.cf.domain.Conversation;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * POJO implementation of the EDN Producer service, using a data store.
 * 
 * @author Gareth Davies
 * @version $Id: EDNProducerDaoImpl.java,v 1.22 2008-08-06 22:49:39 mkuchip Exp $
 */
public class EDNProducerDaoImpl implements SecureService, Identifiable {

  static final String SERVICE_ID = "SNP";

  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private ShipNoticePublicationDao shipNoticePublicationDao;
  private IdMapperDao idMapperDao;
  private IdTranslator idTranslator;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return SERVICE_ID;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }
  
  public boolean isValidationRequired() {
    return true;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject) throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    String infoMessage = "Received ShipNotice data and finding the Account Id to associate with Conversation Id: "
        + conversationId;
    Logger.log(new LoggableInfo(infoMessage));
    XmlDocument xmlDocument = validateInputDocument(input);
    IdentityPrincipal idPrincipal = getValidIdentityPrincipalFromSubject(subject);
    long accountId = getValidDealerAccountIdFromInputDocument(xmlDocument);
    String deliveryId = getDeliveryIdFromInputDocument(xmlDocument);

    infoMessage = "Sending ShipNotice data with Conversation Id: " + conversationId + " to queue for Account Id '"
        + accountId + "'";
    Logger.log(new LoggableInfo(infoMessage));
    Conversation conversation = new Conversation(idPrincipal.getName(), accountId, conversationId);
    shipNoticePublicationDao.storeShipNoticePublication(conversation, deliveryId);

    XmlDocument outputDocument = buildAcknowledgementDocument(conversationId, subject);
    output.getXmlChunks().addChunk(outputDocument);

    return output;
  }

  private XmlDocument validateInputDocument(ServiceInput input) {
    if (input.getXmlChunks().isEmpty()) {
      throw new ServiceException("No XML document was provided for the " + getId() + " service");
    } else {
      return input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
    }
  }

  private long getValidDealerAccountIdFromInputDocument(XmlDocument inputDocument) {
    String xpathAccountId = inputXmlMessageInformer.getXpathAccountId();
    String dealerAccountId = inputDocument.getNodeValueByXPath(xpathAccountId);
    long accountId = idTranslator.parseAccountId(dealerAccountId);

    if (accountId == 0) {
      accountId = mapInputDocumentSapIdToAccountId(inputDocument);
    }

    if (accountId == 0) {
      throw new ServiceException(
          "Account Id could not be found in the ShipNotice XML document, either directly or via SAP Id");
    }

    return accountId;
  }

  private long mapInputDocumentSapIdToAccountId(XmlDocument inputDocument) {
    long accountId = 0;

    String xpathSapId = inputXmlMessageInformer.getXpathSapId();
    String dealerSapId = inputDocument.getNodeValueByXPath(xpathSapId);
    long sapId = idTranslator.parseSapId(dealerSapId);

    if (sapId != 0) {
      try {
        accountId = idMapperDao.findAccountIdBySAPId(dealerSapId);
      } catch (DataAccessException e) {
        String errorMessage = "Ship Notice was not sent because the system was unable to find a matching Account Id for SAP Id '"
            + dealerSapId + "'\nShip Notice XML was:\n" + inputDocument.toString();
        throw new ServiceException(errorMessage);
      }
    }

    return accountId;
  }

  protected IdentityPrincipal getValidIdentityPrincipalFromSubject(Subject subject) {
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(idPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    }
    return idPrincipal;
  }

  private XmlDocument buildAcknowledgementDocument(String conversationId, Subject subject) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement(CidxConstants.HEADER_NODE_NAME,
        XmlNamespace.NAMESPACE_CIDX_40, null);

    CidxDocumentHelper helper = new CidxDocumentHelper(XmlNamespace.NAMESPACE_CIDX_40);
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal.getMessageParticipant(), idTranslator);

    return outputDocument;
  }

  private String getDeliveryIdFromInputDocument(XmlDocument xmlDocument) {
    String xpathDeliveryId = inputXmlMessageInformer.getXpathDeliveryId();
    String deliveryId = xmlDocument.getNodeValueByXPath(xpathDeliveryId);
    return deliveryId;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setShipNoticePublicationDao(ShipNoticePublicationDao shipNoticeDao) {
    this.shipNoticePublicationDao = shipNoticeDao;
  }

  public void setIdMapperDao(IdMapperDao idMapperDao) {
    this.idMapperDao = idMapperDao;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  } 

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.21  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.20  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.19  2006/05/08 14:11:10  caggarw
 * moved files from package jaxrpc into a common package called endpoint
 * Revision 1.18 2006/01/24 18:56:18 ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and
 * ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This
 * will simplify the class exclusion process for consumer classes only
 * interested in ag.soa.client classes.
 * 
 * Revision 1.17 2006/01/24 18:36:56 ggdavi Factored out the
 * ag.util.MessageParticant class from ag.security.IdentityPrincipal (which
 * delegates to it) so that the ag.xml.CidxDocumentHelper class no longer
 * depends on the ag.security package Revision 1.16 2006/01/17 21:41:52 caggarw
 * get the delivery_id from the input xml and store it in the
 * shipNoticepublication table
 * 
 * Revision 1.15 2005/12/01 19:34:30 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.14 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and
 * StAX implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects
 * 
 * Revision 1.13 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.12 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.11 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.10 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.9 2005/08/09
 * 17:07:27 ggdavi Removed javadoc links to deprecated classes
 * 
 * Revision 1.8 2005/08/05 18:37:01 ggdavi Removed deprecated executeSecure
 * method based on DOM documents Revision 1.6 2005/07/26 17:11:53 ggdavi
 * IdMapperDao now treats SAP Ids as text, since that is how the materialized
 * view treats it :-( Revision 1.5 2005/07/25 21:00:04 ggdavi Added support for
 * mapping between SAP Id and Account Id Revision 1.4 2005/07/21 22:14:11 ggdavi
 * Added com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such
 * as Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations Revision 1.3 2005/07/21 14:48:57 ggdavi
 * Fleshed out and refactored com.monsanto.ag.util to make more object-oriented,
 * in that most functionality has been pushed to the XmlDocument and XmlElement
 * objects Revision 1.2 2005/07/12 20:01:55 ggdavi Updated javadoc Revision 1.1
 * 2005/07/12 18:31:58 ggdavi Initial version
 * 
 */