package com.monsanto.ag.cf.security;

import com.monsanto.ag.security.AbstractSimplePrincipal;

/**
 * Created by IntelliJ IDEA.
 * User:
 * Date: 1/17/12
 * Time: 10:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class SapPrincipal extends AbstractSimplePrincipal {

    public SapPrincipal(String sapId) {
        super(sapId);
    }
}
