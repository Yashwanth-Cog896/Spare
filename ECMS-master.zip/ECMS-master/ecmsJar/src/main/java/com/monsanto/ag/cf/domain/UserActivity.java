/*
 * UserActivity was created on Mar 25, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.monsanto.ag.util.Entity;

/**
 * Represents information about a user-initiated data exchange activity.
 * 
 * @author ajbaldw
 * @version $Id: UserActivity.java,v 1.21 2005-08-26 16:10:56 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC84i, FC84j, FC84k, FC84m
 */
public class UserActivity extends Conversation {

  public static final String DATA_SOURCE_SEEDTRAK_CLIENT = "ST";

  private String exchangeType;
  private Date startTime;
  private Date endTime;
  private String seedYear;
  private String softwareVersion;
  private int transactionCount;
  private SystemEvent event;

  public UserActivity() {
  }

  public UserActivity(String userId, long accountId, String conversationId,
      String exchangeType, Date startTime, Date endTime, String dataSource,
      String seedYear, String softwareVersion, int transactionCount) {
    setUserId(userId);
    setAccountId(accountId);
    setConversationId(conversationId);
    setExchangeType(exchangeType);
    setStartTime(startTime);
    setEndTime(endTime);
    setDataSource(dataSource);
    setSeedYear(seedYear);
    setSoftwareVersion(softwareVersion);
    setTransactionCount(transactionCount);
  }

  public String getExchangeType() {
    return exchangeType;
  }

  protected void setExchangeType(String exchangeType) {
    if (StringUtils.isBlank(exchangeType)) {
      throw new UserActivityIncompleteException("Exchange Type is required");
    }
    this.exchangeType = exchangeType;
  }

  public Date getStartTime() {
    return startTime;
  }

  protected void setStartTime(Date startTime) {
    if (startTime == null) {
      startTime = new Date();
      //throw new UserActivityIncompleteException("Start Time is required");
    }
    this.startTime = startTime;
  }

  public Date getEndTime() {
    return endTime;
  }

  protected void setEndTime(Date endTime) {
    this.endTime = endTime;
  }

  public String getDataSource() {
    return dataSource;
  }

  protected void setDataSource(String dataSource) {
    this.dataSource = dataSource;
  }

  public String getSeedYear() {
    return seedYear;
  }

  protected void setSeedYear(String seedYear) {
    if (DATA_SOURCE_SEEDTRAK_CLIENT.equals(dataSource)
        && StringUtils.isBlank(seedYear)) {
      throw new UserActivityIncompleteException("Seed Year is required");
    }
    this.seedYear = seedYear;
  }

  public String getSoftwareVersion() {
    return softwareVersion;
  }

  protected void setSoftwareVersion(String softwareVersion) {
    if (DATA_SOURCE_SEEDTRAK_CLIENT.equals(dataSource)
        && StringUtils.isBlank(softwareVersion)) {
      throw new UserActivityIncompleteException("Software Version is required");
    }
    this.softwareVersion = softwareVersion;
  }

  public int getTransactionCount() {
    return transactionCount;
  }

  protected void setTransactionCount(int transactionCount) {
    this.transactionCount = transactionCount;
  }

  public SystemEvent getEvent() {
    return event;
  }

  protected void setEvent(SystemEvent event) {
    this.event = event;
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof UserActivity)) {
      return false;
    }
    UserActivity rhs = (UserActivity) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(
        exchangeType, rhs.getExchangeType()).append(startTime,
        rhs.getStartTime()).append(endTime, rhs.getEndTime()).append(seedYear,
        rhs.getSeedYear()).append(softwareVersion, rhs.getSoftwareVersion())
        .append(transactionCount, rhs.getTransactionCount()).append(event,
            rhs.getEvent()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(19, 11).appendSuper(super.hashCode()).append(
        exchangeType).append(startTime).append(endTime).append(seedYear)
        .append(softwareVersion).append(transactionCount).append(event)
        .toHashCode();
  }

  public String toString() {
    return new ToStringBuilder(this, Entity.TOSTRING_STYLE).appendSuper(
        super.toString()).append("exchangeType", exchangeType).append(
        "startTime", startTime).append("endTime", endTime).append("seedYear",
        seedYear).append("softwareVersion", softwareVersion).append(
        "transactionCount", transactionCount).append("event", event).toString();
  }

  public void _setSeedYear(String seedYear) {
    this.seedYear = seedYear;
  }

  public void _setSoftwareVersion(String softwareVersion) {
    this.softwareVersion = softwareVersion;
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.20  2005/07/08 17:13:30  ggdavi
 * Pulled up accountId into Conversation superclass and reordered constructor arguments
 * Revision 1.19 2005/06/20 17:12:36 ggdavi Moved
 * Entity and Identifiable back to ag.cf.domain from ag.domain (sorry about
 * that...)
 * 
 * Revision 1.18 2005/06/20 16:40:27 ggdavi Moved Entity and Identifiable from
 * ag.cf.domain to ag.domain
 * 
 * Revision 1.17 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.16 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.15 2005/05/09 18:08:01 ggdavi Now extends Conversation Revision
 * 1.14 2005/05/06 17:53:28 ggdavi Removed errorCode and errorMessage; added
 * event; extends Entity Revision 1.13 2005/04/27 11:23:38 ggdavi setEndTime,
 * setErrorCode and setErrorMessage are now protected
 * 
 * Revision 1.12 2005/04/26 21:21:38 ggdavi Added endTime to UserActivity
 * constructor and reordered fields Revision 1.11 2005/04/25 17:28:54 ggdavi
 * Added conversationId field; startTime is no longer auto-populated - it is now
 * set in constructor or via setStartTime Revision 1.10 2005/04/21 15:32:47
 * ggdavi Added errorCode and errorMessage fields to UserActivity Revision 1.9
 * 2005/04/19 15:33:34 lsdenny converted int account id to long account id
 * 
 * Revision 1.8 2005/04/14 16:49:05 ggdavi Added dataSource field; if dataSource
 * is present, seedYear, softwareVersion are required Revision 1.7 2005/04/13
 * 16:29:33 ggdavi All fields now private; originally protected fields now have
 * setter methods, some of which check for valid values and throw
 * UserActivityIncompleteException Revision 1.6 2005/04/12 19:26:12 ggdavi Added
 * accountId field to UserActivity Revision 1.5 2005/04/08 21:56:02 ajbaldw
 * Changed sequence value from int to string
 * 
 * added implements Identifiable Revision 1.4 2005/04/07 15:44:27 ggdavi Now use
 * an integer value for the Id; added equals, hashCode and toString methods
 * Revision 1.3 2005/04/05 21:36:37 ggdavi Moved UserActivity back to domain
 * package Revision 1.9 2005/04/01 16:38:49 ajbaldw Refactored and moved these
 * into ag/cf/logging package. Revision 1.1 2005/03/29 23:08:27 ggdavi Moved
 * from logging to domain Revision 1.7 2005/03/29 20:43:02 ajbaldw pulled up the
 * getUserId method. Revision 1.6 2005/03/29 20:03:52 ggdavi In progress for
 * Alan to fool with Revision 1.5 2005/03/29 18:43:02 ajbaldw *** empty log
 * message *** Revision 1.4 2005/03/28 20:49:17 ajbaldw oops, forgot formatting.
 * Revision 1.3 2005/03/28 20:46:13 ajbaldw logging changes for 03/28/2005
 * build. Revision 1.2 2005/03/28 18:35:57 ajbaldw Removed the EComMethod
 * property. Revision 1.1 2005/03/28 15:13:49 ajbaldw *** Initial Version ***
 */