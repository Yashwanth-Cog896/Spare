/*
 * PooledConnectionFactory was created on Jun 7, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message.broker;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.activemq.ActiveMQConnection;
import org.activemq.pool.ConnectionKey;
import org.activemq.pool.PooledConnection;
import org.activemq.service.Service;

/**
 * Provides a pool of ActiveMQ connections to the client application.
 * <p>
 * This is an alternative to org.activemq.pool.PooledConnectionFactory that uses
 * the custom Spring application context-aware extension of
 * org.activemq.ActiveMQConnectionFactory,
 * {@link com.monsanto.ag.cf.message.broker.ApplicationConnectionFactory ApplicationConnectionFactory}.
 * The {@link #start() start} method <b>must</b> be called using the "init-method"
 * attribute of the Spring bean definition element, otherwise the broker 
 * configuration file is not loaded. It is probably also a good idea to call the
 * {@link #stop() stop} method using the "destroy-method" bean attribute to 
 * ensure the connections are all released correctly.
 * 
 * @author Gareth Davies
 * @version $Id: PooledConnectionFactory.java,v 1.1 2005/06/07 16:58:59 ggdavi
 *          Exp $
 */
public class PooledConnectionFactory implements ConnectionFactory, Service {

  private ApplicationConnectionFactory connectionFactory;
  private Map cache = new HashMap();

  public PooledConnectionFactory() {
    this(new ApplicationConnectionFactory());
  }

  public PooledConnectionFactory(String brokerURL) {
    this(new ApplicationConnectionFactory(brokerURL));
  }

  public PooledConnectionFactory(ApplicationConnectionFactory connectionFactory) {
    setConnectionFactory(connectionFactory);
  }

  public ApplicationConnectionFactory getConnectionFactory() {
    return connectionFactory;
  }

  public void setConnectionFactory(
      ApplicationConnectionFactory connectionFactory) {
    this.connectionFactory = (ApplicationConnectionFactory) connectionFactory;
  }

  /**
   * @see javax.jms.ConnectionFactory#createConnection()
   */
  public Connection createConnection() throws JMSException {
    return createConnection(null, null);
  }

  /**
   * @see javax.jms.ConnectionFactory#createConnection(java.lang.String,
   *      java.lang.String)
   */
  public Connection createConnection(String userName, String password)
      throws JMSException {
    ConnectionKey key = new ConnectionKey(userName, password);
    PooledConnection connection = (PooledConnection) cache.get(key);
    if (connection == null) {
      ActiveMQConnection delegate = createConnection(key);
      connection = new PooledConnection(delegate);
      cache.put(key, connection);
    }
    return connection.newInstance();
  }

  protected ActiveMQConnection createConnection(ConnectionKey key)
      throws JMSException {
    if (key.getUserName() == null && key.getPassword() == null) {
      return (ActiveMQConnection) connectionFactory.createConnection();
    } else {
      return (ActiveMQConnection) connectionFactory.createConnection(key
          .getUserName(), key.getPassword());
    }
  }

  /**
   * @see org.activemq.service.Service#start()
   */
  public void start() throws JMSException {
    createConnection();
  }

  /**
   * @see org.activemq.service.Service#stop()
   */
  public void stop() throws JMSException {
    for (Iterator itConn = cache.values().iterator(); itConn.hasNext();) {
      PooledConnection connection = (PooledConnection) itConn.next();
      connection.close();
    }
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/06/16 22:15:58  ggdavi
 * Removed obsolete, commented-out init method
 *
 * Revision 1.2  2005/06/15 17:45:11  ggdavi
 * Removed AOP-related nonsense from setConnectionFactory; added createConnection() call to start method; close all connections in the cache in stop method
 * Revision 1.1 2005/06/07 16:58:59
 * ggdavi Initial version
 *  
 */