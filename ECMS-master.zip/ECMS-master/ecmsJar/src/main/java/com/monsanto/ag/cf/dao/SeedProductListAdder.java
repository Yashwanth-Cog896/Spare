package com.monsanto.ag.cf.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.PackageConfiguration;
import com.monsanto.ag.cf.domain.Packaging;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.ag.cf.domain.SeedProduct;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import org.apache.commons.lang.ObjectUtils;

import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/21/13
 * Time: 11:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class SeedProductListAdder extends AbstractListAdder {

    public Product addProductToList( List products, PersistentStoreResultSetFwdIterator iter, Product lastProductRetrieved )
        throws WrappingException {

        Product product;
        if ( lastProductRetrieved != null &&
             lastProductRetrieved instanceof SeedProduct &&
             !isDifferentSeedProduct( iter, lastProductRetrieved ) ) {

            product = lastProductRetrieved;
        }
        else {

            product = mapRowToSeedProduct( iter,
                                           getEcListMaterial( iter ),
                                           getActiveFlag( iter ),
                                           getAddedDate( iter ),
                                           getLastModifiedDate( iter ),
                                           getProductId( iter ) );
            products.add( product );
        }

        if( product != null ){

            addPackagingToProduct( product, iter );
        }
        return product;
    }

    private boolean isDifferentSeedProduct( PersistentStoreResultSetFwdIterator iter, Product lastProductRetrieved )
        throws WrappingException {

        SeedProduct seedProduct = ( SeedProduct ) lastProductRetrieved;
        String rowVariety = iter.getString( "acronym" );
        String rowTreatmentCode = iter.getString( "treatment_code" );

        return !ObjectUtils.equals( rowVariety, seedProduct.getVariety() )
          || !ObjectUtils.equals( rowTreatmentCode, seedProduct.getTreatmentCode() );
    }

    protected Product mapRowToSeedProduct( PersistentStoreResultSetFwdIterator iter,
                                             boolean ecListMaterial,
                                             boolean active,
                                             Date addedDate,
                                             Date modifiedDate,
                                             String productId ) throws WrappingException {

        return new SeedProduct( ecListMaterial,
                                active,
                                addedDate,
                                modifiedDate,
                                productId,
                                iter.getString( "seed_company_brand_name" ),
                                iter.getString( "acronym" ),
                                iter.getString( "biotech_trait" ),
                                iter.getString( "treatment_code" ),
                                iter.getString( "treatment_descr" ),
                                iter.getString( "display_descr" ),
                                iter.getString( "species_code" ),
                                getBoolean( iter, "license_req_flag" ),
                                iter.getInt( "license_trait_grp_id" ),
                                getBoolean( iter, "irm_flag" ) );
    }

    private void addPackagingToProduct( Product product, PersistentStoreResultSetFwdIterator iter ) throws WrappingException{

        Packaging packaging = mapRowToSeedPackaging( iter );
        product.addPackaging( packaging );

        if ( packaging != null ) {

            PackageConfiguration configuration = mapRowToPackageConfiguration( iter );
            packaging.addConfiguration( configuration );
        }
    }

    private Packaging mapRowToSeedPackaging( PersistentStoreResultSetFwdIterator iter ) throws WrappingException {

        return new Packaging( getBoolean( iter, "pkg_active_flag" ),
                              getAddedDate( iter ),
                              getLastModifiedDate( iter ),
                              iter.getString( "gtin" ),
                              iter.getString( "legal_descr_1" ),
                              iter.getString( "description_text" ),
                              getBaseQuantity( iter ),
                              getUnRec20RrUomCode( iter ),
                              getBoolean( iter, "use_ssu" ),
                              iter.getString( "grade_size_desc" ),
                              iter.getString( "processor_code" ),
                              iter.getString( "order_uom_id" ),
                              iter.getString( "treatment_code" ) );
    }
}