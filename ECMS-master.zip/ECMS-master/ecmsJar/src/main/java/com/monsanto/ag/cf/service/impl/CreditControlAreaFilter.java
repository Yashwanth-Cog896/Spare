/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.service.impl;

import com.monsanto.ag.cf.dao.CreditControlAreaDao;
import org.springframework.jdbc.object.MappingSqlQuery;

public interface CreditControlAreaFilter {
    void setCreditControlAreaCode(int creditControlAreaCode);

    String filter(CreditControlAreaDao creditControlAreaDao, String growerIds, MappingSqlQuery mappingSqlQuery);
}
