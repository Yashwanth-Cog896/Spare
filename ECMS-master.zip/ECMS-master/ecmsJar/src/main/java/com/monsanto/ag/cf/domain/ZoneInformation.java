/*
 * ZoneInformation was created on Jul 24, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * Represents zone information. 
 * 
 * @author Chetna Aggarwal
 * @version $Id: ZoneInformation.java,v 1.1 2007-07-25 21:46:05 caggarw Exp $
 */
public class ZoneInformation {
  private String cropCode;
  private String AZRDescr;
  private String zoneDescr;
  private String zoneCode;
  private String zoneYear;

  public ZoneInformation(String descr, String zoneDescr, String zoneCode, String zoneYear, String cropCode) {
    AZRDescr = descr;
    this.zoneDescr = zoneDescr;
    this.zoneCode = zoneCode;
    this.zoneYear = zoneYear;
    this.cropCode = cropCode;
  }

  public String getAZRDescr() {
    return AZRDescr;
  }

  public String getZoneCode() {
    return zoneCode;
  }

  public String getZoneDescr() {
    return zoneDescr;
  }

  public String getZoneYear() {
    return zoneYear;
  }

  public String getCropCode() {
      return cropCode;
  }
  
  public boolean equals(Object obj) {
    if (!(obj instanceof ZoneInformation)) {
      return false;
    }
    ZoneInformation rhs = (ZoneInformation) obj;
    return new EqualsBuilder().append(AZRDescr, rhs.getAZRDescr()).append(zoneCode, rhs.getZoneCode())
        .append(zoneDescr, rhs.getZoneDescr()).append(zoneYear, rhs.getZoneYear())
        .append(cropCode, rhs.getCropCode()).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(21, 23).append(AZRDescr).append(zoneCode).append(zoneDescr)
        .append(zoneYear).append(cropCode).toHashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }
}
