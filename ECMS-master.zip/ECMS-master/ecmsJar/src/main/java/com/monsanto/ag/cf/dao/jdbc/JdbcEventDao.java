/*
 * JdbcEventDao was created on May 6, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import com.monsanto.ag.cf.dao.EventDao;
import com.monsanto.ag.cf.domain.SystemEvent;

/**
 * Spring JDBC implemenation of the Event DAO.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcEventDao.java,v 1.6 2005-07-08 17:15:39 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC74
 */
public class JdbcEventDao extends BaseJdbcDao implements EventDao {

  /**
   * Maps the results from database queries to SystemEvent objects.
   */
  private class SystemEventMappingQuery extends MappingSqlQuery {

    private static final String SYSTEM_EVENT_SQL = "SELECT "
        + "dee.Data_Exchange_Event_ID, del.Acct_Id, dee.Conversation_ID, "
        + "dee.Event_Date, dee.Status_Code, dee.Status_Msg, dee.Row_User_Id "
        + "FROM Data_Exchange_Event dee, Data_Exchange_Log del "
        + "WHERE dee.Conversation_Id = del.Conversation_Id "
        + "AND dee.Conversation_Id = ? AND dee.Status_Code = ?";

    private SystemEventMappingQuery() {
      super(getDataSource(), SYSTEM_EVENT_SQL);
      super
          .declareParameter(new SqlParameter("Conversation_Id", Types.VARCHAR));
      super.declareParameter(new SqlParameter("Status_Code", Types.VARCHAR));
      compile();
    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      SystemEvent event = new SystemEvent(rs.getString("Row_User_ID"), rs
          .getLong("Acct_Id"), rs.getString("Conversation_Id"), rs
          .getTimestamp("Event_Date"), rs.getString("Status_Code"), rs
          .getString("Status_Msg"));
      event.setId(rs.getString("Data_Exchange_Event_ID"));
      return event;
    }

  }

  /**
   * @see com.monsanto.ag.cf.dao.EventDao#findEventsByConversationIdAndStatusCode(java.lang.String,
   *      java.lang.String)
   */
  public List findEventsByConversationIdAndStatusCode(String conversationId,
      String statusCode) {
    SystemEventMappingQuery eventQuery = new SystemEventMappingQuery();
    Object[] queryParms = new Object[] { conversationId, statusCode };
    return eventQuery.execute(queryParms);
  }

  /**
   * @see com.monsanto.ag.cf.dao.EventDao#storeEvent(com.monsanto.ag.cf.domain.SystemEvent)
   */
  public void storeEvent(SystemEvent event) {
    event.setId(getNextSequenceValue());

    // TODO Feature envy? Consider iBATIS... At least, externalize SQL!
    String sql = "INSERT INTO Data_Exchange_Event "
        + "(Data_Exchange_Event_ID, Conversation_ID, Event_Date, Status_Code, "
        + "Status_Msg, Row_User_Id, Row_Task_Id) "
        + "VALUES (?, ?, ?, ?, ?, ?, 'JdbcEventDao.storeEvent')";
    String statusMessage = StringUtils.substring(event.getStatusMessage(), 0,
        255);
    Object[] values = new Object[] { event.getId(), event.getConversationId(),
        event.getEventTime(), event.getStatusCode(), statusMessage,
        event.getUserId() };
    getJdbcTemplate().update(sql, values);
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.5 2005/07/06 21:49:36 ggdavi Only
 * store the first 255 characters of the status message Revision 1.4 2005/05/13
 * 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.3 2005/05/12 21:26:41 ggdavi SystemEventMappingQuery is a private
 * class
 * 
 * Revision 1.2 2005/05/11 19:17:17 ggdavi Added
 * findEventsByConversationIdAndStatusCode method Revision 1.1 2005/05/09
 * 18:05:29 ggdavi Initial version
 * 
 */