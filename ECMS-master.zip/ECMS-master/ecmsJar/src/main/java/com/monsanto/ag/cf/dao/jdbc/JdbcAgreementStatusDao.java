/*
 * JdbcAgreementStatusDao was created on Apr 16, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import com.monsanto.ag.cf.dao.AgreementStatusDao;
import com.monsanto.ag.cf.domain.AgreementDetails;

/**
 * Spring JDBC implemenation of the AgreementStatus DAO.
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcAgreementStatusDao.java,v 1.2 2007-05-01 18:18:42 caggarw Exp $
 */
public class JdbcAgreementStatusDao extends BaseJdbcDao implements AgreementStatusDao {

  /**
   * Maps the results from database queries to AgreementDetails objects.
   * 
   * @author Chetna Aggarwal
   * @version $Id: JdbcAgreementStatusDao.java,v 1.2 2007-05-01 18:18:42 caggarw Exp $
   */
  public class AgreementStatusMappingQuery extends MappingSqlQuery {

    private static final String AGREEMENT_STATUS_SQL = "SELECT DISTINCT PURCHASER_ACCT_ID,ACCT_NAME,MAILING_STATE_CODE,"
        + "CORN_ZONE,CORN_ZONE_CODE,ALFALFA_ZONE,ALFALFA_ZONE_CODE,LICENSE_STATUS,CONTACT_FIRST_NAME,CONTACT_LAST_NAME"
        + " FROM GROWER_LICENSE_ZONE_VW WHERE PURCHASER_ACCT_ID=?";

    /**
     * 
     */
    public AgreementStatusMappingQuery() {
      super(getDataSource(), AGREEMENT_STATUS_SQL);
      super.declareParameter(new SqlParameter("PURCHASER_ACCT_ID", Types.NUMERIC));
      compile();
    }

    /**
     * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet,
     *      int)
     */
    protected Object mapRow(ResultSet rs, int rowNum) throws SQLException {
      AgreementDetails agreementDetails = new AgreementDetails(rs.getLong("PURCHASER_ACCT_ID"), rs
          .getString("ACCT_NAME"), rs.getString("MAILING_STATE_CODE"), rs.getString("CORN_ZONE"), rs
          .getString("CORN_ZONE_CODE"), rs.getString("ALFALFA_ZONE"), rs.getString("ALFALFA_ZONE_CODE"), rs
          .getString("LICENSE_STATUS"),rs.getString("CONTACT_FIRST_NAME"),rs.getString("CONTACT_LAST_NAME"));
      return agreementDetails;
    }
  }

  /**
   * @see com.monsanto.ag.cf.dao.AgreementStatusDao#getAgreementStatusDetails(long)
   */
  public List getAgreementStatusDetails(long accountId) {
    List agreementDetailsList = new ArrayList();
    AgreementStatusMappingQuery agreementStatusMappingQuery = new AgreementStatusMappingQuery();
    agreementDetailsList = agreementStatusMappingQuery.execute(accountId);
    return agreementDetailsList;
  }

}
