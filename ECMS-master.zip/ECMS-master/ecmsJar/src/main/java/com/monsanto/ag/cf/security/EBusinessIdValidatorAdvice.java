/*
 * EBusinessIdValidatorAdvice was created on Apr 14, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.security;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.Subject;
import javax.xml.transform.TransformerException;

import com.monsanto.ag.cf.service.impl.InventoryActualUsageImpl;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.ServiceAdvice;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;


/**
 * AOP Alliance MethodInterceptor that can be introduced in a chain to verify
 * that the authenticated user's E-Business Id (EBID) matches the E-Business Id
 * specified in the request XML payload.
 * <p>
 * TODO Convert to Before advice?
 * 
 * @author Gareth Davies
 * @version $Id: EBusinessIdValidatorAdvice.java,v 1.3 2005/04/19 16:24:30
 *          ggdavi Exp $
 /* @see SeedTrakInsourcingScope FC84n
 */
public class EBusinessIdValidatorAdvice extends ServiceAdvice implements
    MethodInterceptor {

  private EBusinessIdValidator validator;
  private List excludeList = new ArrayList();
  
  
  protected boolean exclude(MethodInvocation invocation) {
	  if (excludeList.contains(invocation.getMethod().getDeclaringClass().getName())) {
		  return true;
	  }
	  return false;
  }
  
  
  /**
   * @see org.aopalliance.intercept.MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
   */
  public Object invoke(MethodInvocation invocation) throws Throwable {
	if (exclude(invocation)) return invocation.proceed();
    if (invocation.getMethod().getDeclaringClass().getCanonicalName().equals( InventoryActualUsageImpl.class.getCanonicalName())){ return invocation.proceed();}
	
    Subject subject = getCurrentUser(invocation.getArguments(), invocation
        .getMethod());
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(idPrincipal)) {
      Logger.log(new LoggableWarning("User has no identity!"));
      throw new EBusinessIdValidationException("User has no identity!");
    } else {
      try {
        String docEBusinessId = getEBusinessIdFromInputDocument(invocation);
        if (StringUtils.isBlank(docEBusinessId) || StringUtils.isBlank(idPrincipal.getEBusinessId())) {
          Logger.log(new LoggableWarning("User " + idPrincipal.getName()
              + " with E-Business Id " + idPrincipal.getEBusinessId()
              + " submitted a request with E-Business Id " + docEBusinessId));
        }
        else if (!validator.validate(idPrincipal, docEBusinessId)) {
          Logger.log(new LoggableWarning("User " + idPrincipal.getName()
              + " with E-Business Id " + idPrincipal.getEBusinessId()
              + " submitted a request with E-Business Id " + docEBusinessId));
        }
        return invocation.proceed();
      } catch (TransformerException e) {
        Logger.log(new LoggableWarning(
            "Unable to extract E-Business Id from request document"));
        return invocation.proceed();
      }
    }
  }
 
  public void setExcludeList(List excludeList){
	  this.excludeList = excludeList;
  }

  private String getEBusinessIdFromInputDocument(MethodInvocation invocation)
      throws EBusinessIdValidationException {
    XmlChunks inputXmlChunks = getInputXmlChunks(invocation.getArguments(),
        invocation.getMethod());
    int inputDocCount = inputXmlChunks.getCount();
    if (inputDocCount == 0) {
      throw new EBusinessIdValidationException(invocation.getThis().getClass()
          + " does not implement the SecureService interface");
    }

    String xPathEBusinessId = getEBusinessIdXPath(invocation.getThis());
    if (StringUtils.isBlank(xPathEBusinessId)) {
      throw new EBusinessIdValidationException(
          invocation.getThis().getClass()
              + " does not contain an XPath expression to retrieve the E-Business Id");
    }

    XmlDocument xmlDocument = (XmlDocument) inputXmlChunks.getLastChunk();
    String eBusinessId = xmlDocument.getNodeValueByXPath(xPathEBusinessId);
    return eBusinessId;
  }

  private String getEBusinessIdXPath(Object target)
      throws EBusinessIdValidationException {
    XmlMessageInformer xmlInformer = getInputXmlMessageInformer(target);
    if (xmlInformer != null) {
      return xmlInformer.getXpathEBusinessId();
    } else {
      throw new EBusinessIdValidationException(
          target.getClass()
              + " does not contain an XPath expression to retrieve the E-Business Id");
    }
  }

  public void setValidator(EBusinessIdValidator validator) {
    this.validator = validator;
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.24.2.1  2008/06/17 17:50:29  rwspeh
 * AGIIS Subscriber Changes
 *
 * Revision 1.24  2008/05/27 16:02:58  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.23  2007/09/06 16:26:27  caggarw
 * chnaged EBID validation message from error to warning
 *
 * Revision 1.22  2007/07/03 22:43:39  caggarw
 * added check for blank EBID
 *
 * Revision 1.21  2007/05/30 19:55:42  caggarw
 * Changed EBID validation to remove validation on blank EBID in document
 *
 * Revision 1.20  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.19  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.18  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.17  2005/11/22 22:39:07  caggarw
 * changes for storing EBID as a String within the web-services, as it may contain alpha numeric characters
 *
 * Revision 1.16  2005/08/26 16:10:56  ggdavi
 * Moved the Identifiable and Entity classes to the ag.util package and the ServiceAdvice class to the ag.soa package for better dependency management
 *
 * Revision 1.15  2005/08/23 17:14:38  ggdavi
 * Modified SecureService.executeSecure method signature to accept a ServiceInput argument instead of a List and return a ServiceOutput object instead of a List
 *
 * Revision 1.14  2005/08/02 20:57:38  ggdavi
 * Modified service interfaces, implementations and advice to support message/document chunking
 * Revision 1.13 2005/07/21 14:48:57
 * ggdavi Fleshed out and refactored com.monsanto.ag.util to make more
 * object-oriented, in that most functionality has been pushed to the
 * XmlDocument and XmlElement objects Revision 1.12 2005/06/17 18:18:16 ggdavi
 * Refactored ag.cf.security to move common objects to ag.security
 * 
 * Revision 1.11 2005/05/31 20:41:23 ggdavi Use SOAP faults instead of a
 * standard error document Revision 1.10 2005/05/17 20:25:03 ggdavi Converted
 * XmlMessageInformer from an interface with accessors only to a fully-fledged
 * bean class
 * 
 * Revision 1.9 2005/05/17 17:53:23 ggdavi All AOP advice classes targeted at
 * service implementations now extend the ServiceAdvice abstract class Revision
 * 1.8 2005/05/17 16:31:51 ggdavi Extracted ag.util.XmlDateTimeUtil and
 * ag.soa.ErrorDocument from ag.util.Utilities Revision 1.7 2005/05/17 15:24:24
 * ggdavi Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.6 2005/05/12 21:26:52 ggdavi Updated javadoc
 * 
 * Revision 1.5 2005/05/11 21:50:33 ggdavi Renamed all Subject method parameters
 * from user to subject for clarity
 * 
 * Revision 1.4 2005/05/06 17:52:45 ggdavi Renamed XPathExporter to
 * XmlMessageInformed and XPathDefiner to XmlMessageInformer
 * 
 * Revision 1.3 2005/04/27 11:24:54 ggdavi Removed conversationId parameter from
 * Utilities.buildErrorDocument
 * 
 * Revision 1.2 2005/04/26 21:25:38 ggdavi Added conversationId parameter to the
 * Utilities.buildErrorDocument method
 * 
 * Revision 1.1 2005/04/20 17:21:39 ggdavi Renamed AccountIdValidator *to
 * EBusinessIdValidator* Revision 1.3 2005/04/19 16:24:30 ggdavi More changes to
 * support long account Ids
 * 
 * Revision 1.2 2005/04/14 17:36:32 ggdavi Added traceability in Javadocs
 * 
 * Revision 1.1 2005/04/14 16:50:20 ggdavi Initial version
 * 
 */