package com.monsanto.ag.cf.domain;

/**
 * Created by JTMURR on 5/20/2016.
 */
public class InventoryLocationDetails {
    private String locationName;
    private String locationIdQualifier;
    private String locationId;

    public InventoryLocationDetails() {
    }

    public InventoryLocationDetails(String locationName, String locationIdQualifier, String locationId) {
        this.locationName = locationName;
        this.locationIdQualifier = locationIdQualifier;
        this.locationId = locationId;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getLocationIdQualifier() {
        return locationIdQualifier;
    }

    public void setLocationIdQualifier(String locationIdQualifier) {
        this.locationIdQualifier = locationIdQualifier;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }
}
