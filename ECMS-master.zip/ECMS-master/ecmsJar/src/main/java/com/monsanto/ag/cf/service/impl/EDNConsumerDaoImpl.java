/*
 * EDNConsumerDaoImpl was created on Jul 22, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.ActivityDocumentDao;
import com.monsanto.ag.cf.dao.ShipNoticePublicationDao;
import com.monsanto.ag.cf.dao.SpecialInstructionsDao;
import com.monsanto.ag.cf.domain.Conversation;
import com.monsanto.ag.cf.domain.SpecialInstructions;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.CidxDocumentHelper;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.XmlStreamListAppender;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * POJO implementation of the EDN Consumer service, using a data store.
 * 
 * @author Gareth Davies
 * @version $Id: EDNConsumerDaoImpl.java,v 1.21 2008-08-06 22:49:39 mkuchip Exp $
 */
public class EDNConsumerDaoImpl implements Identifiable, SecureService {

  public static final String XPATH_SHIP_NOTICE_STANDALONE = "/cidx:ShipNotice/cidx:ShipNoticeBody";
  private static final String XPATH_SHIP_NOTICE_STANDALONE_ID = XPATH_SHIP_NOTICE_STANDALONE
      + "/cidx:ShipNoticeProperties/cidx:ReferenceInformation[@ReferenceType='DeliveryNoteNumber']/cidx:DocumentReference/cidx:DocumentIdentifier";

  public static final XmlNamespace NAMESPACE_EDNLIST_RESPONSE = new XmlNamespace(
      "ecms", "urn:ecms:schema:shipnotice:response:1:0");
  private static final String DOCUMENT_ROOT_NODE_NAME = "ShipNotice";
  
  private ActivityDocumentDao activityDocumentDao;
  private ShipNoticePublicationDao shipNoticePublicationDao;
  private SpecialInstructionsDao specialInstructionsDao;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;
  private XmlDocumentBuilder xmlDocumentBuilder;
  private IdTranslator idTranslator;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return "EDN";
  }
  
  public boolean isValidationRequired() {
    return true;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject)
      throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo(
        "Processing EDN consumer request with conversation Id: "
            + conversationId));
    XmlDocument xmlDocument = validateInputDocument(input);
    IdentityPrincipal idPrincipal = getValidIdentityPrincipalFromSubject(subject);
    long accountId = idPrincipal.getAccountId();

    List shipNoticePublications = getNewShipNoticePublications(accountId);
    List shipNoticeDocuments = getPublishedShipNoticeDocuments(xmlDocument,
        accountId, shipNoticePublications);

    XmlChunks outputXmlChunks = buildShipNoticeListDocuments(conversationId,
        idPrincipal, shipNoticeDocuments);
    output.getXmlChunks().addChunks(outputXmlChunks);

    removeProcessedShipNoticePublications(accountId, shipNoticePublications);

    return output;
  }

  private XmlDocument validateInputDocument(ServiceInput input) {
    if (input.getXmlChunks().isEmpty()) {
      throw new ServiceException("No XML document was provided for the "
          + getId() + " service");
    } else {
      return input.getXmlChunks().getXmlDocument(xmlDocumentBuilder);
    }
  }

  private List getNewShipNoticePublications(long accountId) {
    try {
      return shipNoticePublicationDao
          .findShipNoticePublicationsByDealer(accountId);
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException(e.getMessage(), e);
    }
  }

  protected IdentityPrincipal getValidIdentityPrincipalFromSubject(
      Subject subject) {
    IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
    if (IdentityPrincipal.UNAUTHENTICATED.equals(idPrincipal)) {
      throw new ServiceException("A valid user must be specified");
    }
    return idPrincipal;
  }

  private List getPublishedShipNoticeDocuments(XmlDocument inputDocument,
      long accountId, List shipNoticePublications) {
    List shipNoticeDocuments = new ArrayList();

    try {
      Set shipNoticeIdsInList = new HashSet();
      List seedYearDocuments = getShipNoticeDocumentsForDealerInSeedYear(
          inputDocument, accountId);
      addUniqueShipNoticeDocumentsToList(shipNoticeDocuments,
          shipNoticeIdsInList, seedYearDocuments);

      List newDocuments = getShipNoticeDocumentsBasedOnNewPublications(
          accountId, shipNoticePublications);
      addUniqueShipNoticeDocumentsToList(shipNoticeDocuments,
          shipNoticeIdsInList, newDocuments);
    } catch (Exception e) {
      Logger.log(new LoggableError(e));
      throw new ServiceException(e.getMessage(), e);
    }

    return shipNoticeDocuments;
  }

  private List getShipNoticeDocumentsForDealerInSeedYear(
      XmlDocument inputDocument, long accountId) {
    List seedYearDocuments = new ArrayList();

    if (doFullRefreshForAccount(accountId)) {
      String xpathSeedYear = inputXmlMessageInformer.getXpathSeedYear();
      String seedYear = inputDocument.getNodeValueByXPath(xpathSeedYear);
      if (StringUtils.isNotBlank(seedYear)) {
        seedYearDocuments = activityDocumentDao
            .findActivityDocumentsByDealerServiceSeedYear(accountId,
                EDNProducerDaoImpl.SERVICE_ID, DOCUMENT_ROOT_NODE_NAME, seedYear);
      }
    }

    return seedYearDocuments;
  }

  private boolean doFullRefreshForAccount(long accountId) {
    Set instructionSet = specialInstructionsDao
        .findInstructionsByDealerService(accountId, getId());
    if (instructionSet != null) {
      for (Iterator itInstructions = instructionSet.iterator(); itInstructions
          .hasNext();) {
        SpecialInstructions instructions = (SpecialInstructions) itInstructions
            .next();
        if (instructions.contains("REFRSH")) {
          String message = "Full EDN refresh will be attempted for account Id: "
              + accountId;
          Logger.log(new DebugLogEvent(message));
          return true;
        }
      }
    }

    return false;
  }

  private void addUniqueShipNoticeDocumentsToList(List shipNoticeDocuments,
      Set shipNoticeIdsInList, List seedYearDocuments) {
    for (Iterator itDocument = seedYearDocuments.iterator(); itDocument
        .hasNext();) {
      XmlDocument shipNoticeDocument = (XmlDocument) itDocument.next();
      String shipNoticeId = shipNoticeDocument
          .getNodeValueByXPath(XPATH_SHIP_NOTICE_STANDALONE_ID);

      if (shipNoticeIdsInList.contains(shipNoticeId)) {
        Logger.log(new LoggableWarning(
            "Duplicate ship notice received with Id: " + shipNoticeId));
      } else {
        shipNoticeDocuments.add(shipNoticeDocument);
        shipNoticeIdsInList.add(shipNoticeId);
      }
    }
  }

  private List getShipNoticeDocumentsBasedOnNewPublications(long accountId,
      List shipNoticePublications) {
    List shipNoticeDocuments = new ArrayList();

    for (Iterator itPublication = shipNoticePublications.iterator(); itPublication
        .hasNext();) {
      Conversation publication = (Conversation) itPublication.next();
      if (publication != null && accountId == publication.getAccountId()) {
        XmlDocument shipNoticeDocument = activityDocumentDao
            .findActivityDocumentByConversation(publication.getConversationId(), DOCUMENT_ROOT_NODE_NAME);
        if (shipNoticeDocument != null) {
          shipNoticeDocuments.add(shipNoticeDocument);
        }
      }
    }

    return shipNoticeDocuments;
  }

  private XmlChunks buildShipNoticeListDocuments(final String conversationId,
      final IdentityPrincipal idPrincipal, List shipNoticeDocuments) {
    int chunkSize = outputXmlMessageInformer.getChunkSize();
    XmlChunks outputXmlChunks = xmlDocumentBuilder.createXmlStreamChunks(
        shipNoticeDocuments, chunkSize, new XmlStreamListAppender() {

          public XmlStream buildXmlStream(List domainItems) {
            return buildShipNoticeListDocument(conversationId, idPrincipal,
                domainItems);
          }

        });

    return outputXmlChunks;
  }

  private XmlDocument buildShipNoticeListDocument(String conversationId,
      IdentityPrincipal idPrincipal, List shipNoticeDocuments) {
    XmlDocument outputDocument = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = outputDocument.addRootElement("ShipNoticeList",
        NAMESPACE_EDNLIST_RESPONSE, "1.0");

    CidxDocumentHelper helper = new CidxDocumentHelper(
        XmlNamespace.NAMESPACE_CIDX_40);
    helper.addHeaderNode(rootElement, conversationId, idPrincipal
        .getMessageParticipant(), idTranslator);

    addBodyNode(rootElement, shipNoticeDocuments);

    return outputDocument;
  }

  private void addBodyNode(XmlElement rootElement, List shipNoticeDocuments) {
    XmlElement bodyElement = rootElement.addChildElement("ShipNoticeListBody");

    bodyElement.addChildElement("ShipNoticeListProperties");
    XmlElement detailsElement = bodyElement
        .addChildElement("ShipNoticeListDetails");

    addShipNoticeNodes(detailsElement, shipNoticeDocuments);
  }

  private void addShipNoticeNodes(XmlElement detailsElement,
      List shipNoticeDocuments) {
    for (Iterator itShipNoticeDoc = shipNoticeDocuments.iterator(); itShipNoticeDoc
        .hasNext();) {
      XmlDocument shipNoticeDocument = (XmlDocument) itShipNoticeDoc.next();

      XmlElement shipNoticeBodyNode = shipNoticeDocument
          .selectElementByXPath(XPATH_SHIP_NOTICE_STANDALONE);
      detailsElement.importElement(shipNoticeBodyNode, true);
    }
  }

  private void removeProcessedShipNoticePublications(long accountId,
      List shipNoticePublications) {
    for (Iterator itPublication = shipNoticePublications.iterator(); itPublication
        .hasNext();) {
      Conversation publication = (Conversation) itPublication.next();
      if (publication != null && accountId == publication.getAccountId()) {
        shipNoticePublicationDao.removeShipNoticePublication(publication);
      }
    }
  }

  public void setActivityDocumentDao(ActivityDocumentDao activityDocumentDao) {
    this.activityDocumentDao = activityDocumentDao;
  }

  public void setShipNoticePublicationDao(ShipNoticePublicationDao shipNoticeDao) {
    this.shipNoticePublicationDao = shipNoticeDao;
  }

  public void setSpecialInstructionsDao(
      SpecialInstructionsDao specialInstructionsDao) {
    this.specialInstructionsDao = specialInstructionsDao;
  }
  
  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.20  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.19  2006/06/26 16:55:33  caggarw
 * root_node_name added to data_exchange_repository as a primary key
 *
 * Revision 1.18  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 *
 * Revision 1.17  2006/03/08 20:37:25  caggarw
 * Added null check for publication activity document
 * Revision 1.16 2006/01/24 18:56:18 ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and
 * ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This
 * will simplify the class exclusion process for consumer classes only
 * interested in ag.soa.client classes.
 * 
 * Revision 1.15 2006/01/24 18:36:56 ggdavi Factored out the
 * ag.util.MessageParticant class from ag.security.IdentityPrincipal (which
 * delegates to it) so that the ag.xml.CidxDocumentHelper class no longer
 * depends on the ag.security package Revision 1.14 2005/12/01 19:34:30 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks
 * 
 * Revision 1.13 2005/11/15 17:28:04 ggdavi Output XML chunks are now identified
 * via the unqualified XPath of their parent element
 * 
 * Revision 1.12 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and
 * StAX implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects
 * 
 * Revision 1.11 2005/08/29 16:31:04 ggdavi Modified the XPath expression for a
 * Ship Notice's unique identifier to use the DeliveryNoteNumber instead of the
 * BillOfLading (TT00166)
 * 
 * Revision 1.10 2005/08/26 16:26:09 ggdavi Javadoc corrections
 * 
 * Revision 1.9 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.8 2005/08/25 16:00:46 ggdavi CidxDocumentHelper is now an
 * instantiable class that takes an XmlNamespace in its constructor - for the
 * current service implementations, this is the XmlNamespace.NAMESPACE_CIDX_40
 * object
 * 
 * Revision 1.7 2005/08/24 16:48:34 ggdavi Added logging statements Revision 1.6
 * 2005/08/24 14:52:18 ggdavi Added log statement for when a duplicate ship
 * notice is encountered Revision 1.5 2005/08/23 17:14:38 ggdavi Modified
 * SecureService.executeSecure method signature to accept a ServiceInput
 * argument instead of a List and return a ServiceOutput object instead of a
 * List Revision 1.4 2005/08/09 17:07:27 ggdavi Removed javadoc links to
 * deprecated classes
 * 
 * Revision 1.3 2005/08/05 18:37:01 ggdavi Removed deprecated executeSecure
 * method based on DOM documents Revision 1.1 2005/07/25 20:55:45 ggdavi Initial
 * version
 * 
 */