package com.monsanto.ag.cf.management;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;

import javax.jms.Message;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activemq.spring.TestingConsumer;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.cf.dao.EcomMonitorDao;
import com.monsanto.ag.cf.message.XmlMessageConverter;
import com.monsanto.ag.cf.outage.Outage;
import com.monsanto.ag.cf.outage.OutageChecker;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;

/**
 * Servlet for monitoring the connections vis ping tests to Webmethod,
 * Farmsource Service, ECOM database and ECG Service. The urls for the ping
 * tests will be built into SiteScope
 * 
 * @author Chetna Aggarwal
 * @version $Id: PerformanceMonitorServlet.java,v 1.2 2005/07/29 20:16:34
 *          caggarw Exp $
 */
public class PerformanceMonitorServlet extends HttpServlet {

  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    boolean success = false;
    String pingType = request.getParameter("pingType");
    Monitor monitor = getMonitorInCurrentContext(request);

    if ("ecom".equals(pingType)) {
      success = pingEComDatabase(monitor);
    } else if ("farmSource".equals(pingType)) {
      success = pingFarmsource(monitor);
    } else if ("webMethods".equals(pingType)) {
      success = pingWebMethods(monitor.getWebMethodServiceUrl(), monitor);
    } else if ("webMethodsR1".equals(pingType)) {
      success = pingWebMethods(monitor.getWebMethodServiceUrlR1(), monitor);
    } else if ("jmsBroker".equals(pingType)) {
      success = pingJMSBroker(monitor);
    }

    displayPingResult(response, success);
  }

  private Monitor getMonitorInCurrentContext(HttpServletRequest request) {
    ServletContext servletContext = request.getSession().getServletContext();
    ApplicationContext appContext = WebApplicationContextUtils
        .getRequiredWebApplicationContext(servletContext);
    Monitor monitor = (Monitor) appContext.getBean("monitor");
    return monitor;
  }

  private boolean pingEComDatabase(Monitor monitor) {
    EcomMonitorDao ecomMonitorDao = monitor.getEcomMonitorDao();
    int status = ecomMonitorDao.getDatabaseStatus();
    if (status == 1) {
      return true;
    } else {
      Logger.log(new LoggableWarning("Could not connect to the ECOM Database"));
      return false;
    }
  }

  private boolean pingFarmsource(Monitor monitor) {
    OutageChecker outageChecker = monitor.getOutageChecker();

    Outage outage = outageChecker
        .checkOutage(monitor.getFarmSourceServiceUrl());

    if (!outage.isCurrent()) {
      return true;
    } else {
      Logger.log(new LoggableWarning(
          "Could not connect to the Farmsource Services"));
      return false;
    }
  }

  private boolean pingWebMethods(String serviceId, Monitor monitor) {
    if (serviceId == null || "".equals(serviceId)) {
      return false;
    }

    XmlDocumentBuilder xmlDocumentBuilder = monitor.getXmlDocumentBuilder();
    XmlDocument inputDocument = xmlDocumentBuilder.createXmlDocument();
    ServiceInput serviceInput = new ServiceInput(inputDocument);

    SoaClient webMethodsSoaClient = monitor.getWebMethodsSoaClient();
    ServiceOutput output = webMethodsSoaClient.call(serviceId, serviceInput);
    XmlDocument outputDocument = output.getXmlChunks().getXmlDocumentChunk(
        xmlDocumentBuilder, 0);

    try {
      checkOutputDocumentAndSetSuccessFlagForWebMethods(outputDocument);
      return true;
    } catch (ServiceException e) {
      Logger.log(new LoggableWarning(e.getMessage()));
      return false;
    }
  }

  private void checkOutputDocumentAndSetSuccessFlagForWebMethods(
      XmlDocument outputDocument) {
    List systemResponses = outputDocument
        .selectElementsByXPath("/Response/ResponseLine");
    for (Iterator itResponseLine = systemResponses.iterator(); itResponseLine
        .hasNext();) {
      XmlElement responseLine = (XmlElement) itResponseLine.next();
      XmlElement responseCode = responseLine.getChild("ResponseCode");

      if (!"success".equalsIgnoreCase(responseCode.getText())) {
        String systemName = responseLine.getAttributeValue("SystemName");
        String errorMessage = responseLine.getChild("ResponseMessage")
            .getText();
        throw new ServiceException(
            "Error connecting to WebMethods while connecting to " + systemName
                + " at " + errorMessage);
      }
    }
  }

  private boolean pingJMSBroker(Monitor monitor) {
    String xml = "<ping>Hello JMS Broker!</ping>";
    XmlDocumentBuilder xmlDocumentBuilder = monitor.getXmlDocumentBuilder();
    XmlDocument inputDocument = xmlDocumentBuilder
        .createXmlDocument(new StringReader(xml));

    JmsTemplate jmsTemplate = monitor.getJmsTemplate();
    jmsTemplate.convertAndSend("ecms.ping", inputDocument);

    TestingConsumer consumer = monitor.getJmsPingListener();
    consumer.waitForMessageToArrive();
    List messages = consumer.flushMessages();

    try {
      Message message = (Message) messages.get(0);
      XmlMessageConverter messageConverter = monitor.getMessageConverter();
      XmlDocument messageDoc = (XmlDocument) messageConverter
          .fromMessage(message);
      return StringUtils
          .equals(inputDocument.toString(), messageDoc.toString());
    } catch (Exception e) {
      Logger.log(new LoggableWarning("Error pinging the JMS broker " + e));
      return false;
    }
  }

  private void displayPingResult(HttpServletResponse response, boolean success)
      throws IOException {
    PrintWriter writer = response.getWriter();
    if (success) {
      writer.write("SUCCESS");
    } else {
      writer.write("FAILURE");
    }
    writer.flush();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.12  2006/07/13 18:44:40  caggarw
 * Refactored to use CidxConstants to help with changing the Agency attributes for SAPId and AccountId
 *
 * Revision 1.11  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 * Revision 1.10 2005/11/08 21:00:31
 * ggdavi Updated after adding XmlStream (and StAX implementation) to the
 * com.monsanto.ag.util package and refactoring the ServiceInput and
 * ServiceOutput classes to expose both XmlStream and XmlDocument objects
 * Revision 1.9 2005/11/01 22:27:02 caggarw Refactoring and added JmsBroker ping
 * test. Revision 1.8 2005/09/27 15:45:04 caggarw changed logging from Error to
 * Warning for the ping tests
 * 
 * Revision 1.7 2005/09/21 18:24:57 caggarw added ping test for the production
 * box added to webmethod
 * 
 * Revision 1.6 2005/08/23 17:13:15 ggdavi Moved ServiceInput and ServiceOutput
 * from ag.soa.client to ag.soa
 * 
 * Revision 1.5 2005/08/08 20:24:09 ggdavi Refactored and corrected bugs in
 * ECGServices and WebMethods checks introduced when converting from DOM
 * Documents to XmlDocuments Revision 1.4 2005/08/06 20:44:33 ggdavi Moved
 * Monitor from ag.cf.domain to ag.cf.management to resolve circular dependency
 * 
 * Revision 1.3 2005/08/05 18:46:49 ggdavi Use XmlDocument objects instead of
 * DOM Document objects Revision 1.2 2005/07/29 20:16:34 caggarw Servlet for
 * monitoring the connections vis ping tests to Webmethod, Farmsource Service,
 * ECOM database and ECG Service. Revision 1.1 2005/07/22 18:38:27 ggdavi
 * Initial version
 * 
 */