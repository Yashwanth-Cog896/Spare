/*
 * EBusinessIdValidatorImpl was created on Apr 20, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.security;

import org.apache.commons.lang.StringUtils;


import com.monsanto.ag.security.IdentityPrincipal;


/**
 * Simple implementation of the E-Business Id (EBID) validator.
 * 
 * @author Gareth Davies
 * @version $Id: EBusinessIdValidatorImpl.java,v 1.3 2005/06/17 18:18:16 ggdavi
 *          Exp $
 */
public class EBusinessIdValidatorImpl implements EBusinessIdValidator {

  /**
   /* @see com.monsanto.ag.cf.security.EBusinessIdValidator#validate(IdentityPrincipal,
   *      long)
   */
  public boolean validate(IdentityPrincipal idPrincipal, String eBusinessId)
      throws EBusinessIdValidationException {
    if (idPrincipal == null) {
      throw new EBusinessIdValidationException("User has no identity!");
    } else {
      return StringUtils.equals(idPrincipal.getEBusinessId(), eBusinessId);
    }
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.5  2005/11/22 22:39:07  caggarw
 * changes for storing EBID as a String within the web-services, as it may contain alpha numeric characters
 *
 * Revision 1.4  2005/08/26 16:26:09  ggdavi
 * Javadoc corrections
 * Revision 1.3 2005/06/17 18:18:16
 * ggdavi Refactored ag.cf.security to move common objects to ag.security
 * 
 * Revision 1.2 2005/05/04 17:38:39 ggdavi No longer throw an exception when the
 * eBusinessId value is 0
 * 
 * Revision 1.1 2005/04/20 17:21:51 ggdavi Initial version
 * 
 */