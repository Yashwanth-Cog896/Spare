/*
 * FarmsourceOutageServiceProxy was created on Apr 8, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.proxy;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.outage.Outage;
import com.monsanto.ag.cf.outage.OutageChecker;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.client.ServiceProxySupport;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlElement;

/**
 * Proxy for the Farmsource Outage Web Service.
 * 
 * @author ajbaldw
 * @version $Id: FarmsourceOutageServiceProxy.java,v 1.1 2005/04/08 21:57:26
 *          ajbaldw Exp $
 * @see SeedTrakInsourcingScope FC78
 */
public class FarmsourceOutageServiceProxy extends ServiceProxySupport implements
    OutageChecker {

  public static final String FARMSOURCE_APP_ID_PREFIX = "WS_";

  private XmlDocumentBuilder xmlDocumentBuilder;

  /**
   * @see com.monsanto.ag.cf.outage.OutageChecker#checkOutage(java.lang.String)
   */
  public Outage checkOutage(String appId) {
    Logger.log(new LoggableInfo("Checking to see if service " + appId
        + " is in a scheduled outage"));
    verifyParametersPresent(appId);
    XmlDocument outageDoc = getOutageCheckerServiceResponseDocument(appId);
    Outage outage = buildOutageFromServiceResponse(outageDoc, appId);
    return outage;
  }

  private void verifyParametersPresent(String appId) {
    if (StringUtils.isEmpty(appId)) {
      Logger.log(new LoggableWarning("No parameters passed to checkOutage"));
      throw new ServiceException(REQUEST_ERROR_MESSAGE);
    }
  }

  private XmlDocument getOutageCheckerServiceResponseDocument(String appId) {
    try {
      XmlDocument inputDoc = buildInputDocument(appId);
      ServiceInput input = new ServiceInput(inputDoc);

      ServiceOutput output = soaClient.call(serviceId, input);

      XmlDocument outputDoc = XmlDocument.NULL;
      XmlChunks outputXmlChunks = output.getXmlChunks();
      if (!outputXmlChunks.isEmpty()) {
        outputDoc = outputXmlChunks.getXmlDocumentChunk(xmlDocumentBuilder, 0);
      }
      return outputDoc;
    } catch (ServiceException e) {
      Logger.log(new LoggableWarning(e.getMessage()));
      throw new ServiceException(REQUEST_ERROR_MESSAGE, e);
    }
  }

  private XmlDocument buildInputDocument(String appId) {
    XmlDocument inputDoc = xmlDocumentBuilder.createXmlDocument();
    XmlElement rootElement = inputDoc.addRootElement("outagerequest");

    String convertedAppId = convertAppId(appId);
    rootElement.addChildElement("appdescr", convertedAppId);

    return inputDoc;
  }

  /**
   * Converts the specified application identifier into one that assures
   * uniqueness for Farmsource.
   * 
   * @param appId
   *          Identifier of the application to be checked for outages
   * @return Converted application identifier
   */
  private String convertAppId(String appId) {
    return FARMSOURCE_APP_ID_PREFIX + appId;
  }

  private Outage buildOutageFromServiceResponse(XmlDocument outageDoc,
      String appId) {
    if (XmlElement.NULL.equals(outageDoc
        .selectElementByXPath("/outageresponse"))) {
      throw new ServiceException(OutageChecker.REQUEST_ERROR_MESSAGE);
    }

    try {
      String startDateText = outageDoc
          .getNodeValueByXPath("/outageresponse/start");
      Date startDate = XmlDateTimeUtil
          .parseTextAsXmlSchemaDateTime(startDateText);

      String endDateText = outageDoc.getNodeValueByXPath("/outageresponse/end");
      Date endDate = XmlDateTimeUtil.parseTextAsXmlSchemaDateTime(endDateText);

      String description = outageDoc
          .getNodeValueByXPath("/outageresponse/message");

      return new Outage(appId, startDate, endDate, description);
    } catch (Exception e) {
      Logger.log(new LoggableWarning(e));
      throw new ServiceException(OutageChecker.REQUEST_ERROR_MESSAGE, e);
    }
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.6 2005/11/08 21:00:31
 * ggdavi Updated after adding XmlStream (and StAX implementation) to the
 * com.monsanto.ag.util package and refactoring the ServiceInput and
 * ServiceOutput classes to expose both XmlStream and XmlDocument objects
 * 
 * Revision 1.5 2005/08/24 16:48:34 ggdavi Added logging statements Revision 1.4
 * 2005/08/23 17:12:48 ggdavi Moved ServiceInput and ServiceOutput from
 * ag.soa.client to ag.soa
 * 
 * Revision 1.3 2005/08/05 18:35:22 ggdavi SoaClient.call method now returns a
 * ServiceOutput object; use XmlDocument objects instead of DOM Document objects
 * (via injected xmlDocumentBuilder) Revision 1.2 2005/07/21 14:48:57 ggdavi
 * Fleshed out and refactored com.monsanto.ag.util to make more object-oriented,
 * in that most functionality has been pushed to the XmlDocument and XmlElement
 * objects Revision 1.1 2005/05/23 16:31:58 ggdavi Moved
 * FarmsourceAuthenticatorServiceProxy and FarmsourceOutageServiceProxy to
 * ag.cf.service.proxy
 * 
 * Revision 1.8 2005/05/18 18:18:39 ggdavi Overhauled ag.soa.client package,
 * replacing Farmsource and WebMethods specific subclasses of BaseSoaClient with
 * XmlHttpSoaClient, whose behavior is parameterized via collaborators
 * 
 * Revision 1.7 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.6 2005/05/09 20:30:30 ggdavi Added WS_ prefix to application Ids
 * when using the Farmsource Outage web service Revision 1.5 2005/05/03 18:15:42
 * ggdavi Renamed serviceUrl field to serviceId
 * 
 * Revision 1.4 2005/05/02 16:07:40 ggdavi Replaced SoaClient.call(String,
 * SoaRequestCreator) method with simpler call(String, Document) method Revision
 * 1.3 2005/04/13 16:33:06 ggdavi Now extends ServiceProxySupport (which defines
 * and sets fields); build request Document using DOMUtil Revision 1.2
 * 2005/04/13 12:24:39 ggdavi Modified outage service request XML
 * 
 * Revision 1.1 2005/04/11 21:45:48 ggdavi Moved from ag.service to ag.cf.outage
 * Revision 1.1 2005/04/08 21:57:26 ajbaldw Initial Version
 * 
 */