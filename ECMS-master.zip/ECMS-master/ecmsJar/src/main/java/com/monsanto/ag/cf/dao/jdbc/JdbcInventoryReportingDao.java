package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.InventoryPreparedStatementBuilder;
import com.monsanto.ag.cf.dao.InventoryReportingDao;
import com.monsanto.ag.cf.domain.InventoryDetails;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.List;

/**
 * JdbcInventoryReportingDao stores the Mobile Inventory Reporring data
 * into ECG DIRECT_STAGING tables (Gateway)
 *
 * @author [Ramesh Kukunarapu]
 * @version $Id: JdbcInventoryReportingDao.java,v 1.3 2007-12-21 17:46:18 RRKUKU Exp $ 1.1
 */
public class JdbcInventoryReportingDao extends BaseJdbcDao implements
        InventoryReportingDao {

    public static final String INSERT_SQL = "INSERT INTO ecg_ld.DIRECT_STAGING(" +
            "FILE_NAME, ST_TYPE, RPT_TYPE, RPT_DATE, DS_TYPE," +
            "SF_TYPE, INV_DATE_QUAL, SHIP_DATE_QUAL, SHIP_DATE, TRANSACTION_STATUS, " +
            "CONVERSATION_ID, DS_ID_QUAL, DS_ID_VALUE, DS_NAME, DATA_SOURCE, PVS_START_DATE, " +
            "ST_ID_VALUE, ST_ID_QUAL, ST_NAME, SF_ID_VALUE, SF_ID_QUAL, " +
            "SF_NAME, AS_OF_DATE, LINE_ID_QUAL, LINE_ID_VALUE, QTY, " +
            "QTY_QUAL, ORDER_TYPE, LINE_UOM, PHYSICAL_COUNT_FLAG, LOT_NBR, COMMIT_QTY, " +
            "COMMIT_AS_OF_DATE) " +
            "VALUES(?,?,?,to_char(sysdate,'YYYYMMDD'),?,?,?,?,to_char(sysdate,'YYYYMMDD'),?," +
            "?,?,?,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    public int storeInventoryReportingDetails(final List inventoryDetailsList) throws SQLException {
        return performUpdate(inventoryDetailsList, INSERT_SQL).length;
    }

    private int[] performUpdate(final List inventoryDetailsList, String insertQuery) {
        return getJdbcTemplate().batchUpdate(insertQuery,
                new BatchPreparedStatementSetter() {
                    public void setValues(PreparedStatement ps, int i) throws SQLException {
                        InventoryPreparedStatementBuilder builder = new InventoryPreparedStatementBuilder();
                        InventoryDetails inventoryDetail = (InventoryDetails) inventoryDetailsList.get(i);
                        Logger.log(new LoggableInfo("batching:\n" + inventoryDetail.toString()));
                        builder.prepare(ps, inventoryDetail);
                    }

                    public int getBatchSize() {
                        return inventoryDetailsList.size();
                    }
                });
    }
}

