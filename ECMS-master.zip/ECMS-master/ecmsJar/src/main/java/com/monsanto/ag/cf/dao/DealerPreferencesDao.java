/*
 * DealerPreferencesDao was created on Oct 3, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao;

/**
 * Data Access Object for DealerPreferences.
 * @author Chetna Aggarwal
 * @version $Id: DealerPreferencesDao.java,v 1.5 2008-05-01 18:58:54 rwspeh Exp $
 */
public interface DealerPreferencesDao {
  
  public void storeVersion(long accountId, String version, String sourceName);  
  
  public String getLatestVersion(String appName);
  
  public String getSeedTrakVersionAvailableForDownload();
  
  public String getEnabledFlag(long acctId);

}
