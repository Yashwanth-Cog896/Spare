/*
 * Packaging was created on Jun 21, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlElement;

/**
 * Represents the specific packaging of a commercial seed or chemical product.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method. This XML
 * conforms to the PackageSizeInformationType element of the
 * AGIISNamespacedSchema.xsd XML schema document.
 * 
 * @author Gareth Davies
 * @version $Id: Packaging.java,v 1.5 2009/07/21 20:15:45 mkuchip Exp $
 */
public class Packaging extends AgiisEntity {

  private String gtin;
  private String name;
  private String description;
  private Measurement baseQuantity;
  private String packageUom;
  private boolean reportWithSsu;
  private String seedSize;
  private String userDefinedField1;
  private List configurations;
  private String orderUomId;
  private String treatmentCode;

  public Packaging(boolean active, Date addedDate, Date lastModifiedDate,
      String gtin, String name, String description, Measurement baseQuantity,
      String packageUom, boolean reportWithSsu, String seedSize,
      String userDefinedField1, String orderUomId, String trmtCode) {
    super(active, addedDate, lastModifiedDate);

    setGtin(gtin);
    this.name = name;
    this.description = description;
    this.baseQuantity = baseQuantity;
    setPackageUom(packageUom);
    this.reportWithSsu = reportWithSsu;
    this.seedSize = seedSize;
    this.userDefinedField1 = userDefinedField1;
    this.orderUomId = orderUomId;

    this.configurations = new ArrayList();
    this.treatmentCode = trmtCode;
  }

  /**
   * @see java.lang.Object#clone()
   */
  public Object clone() throws CloneNotSupportedException {
    Measurement baseQuantityClone = (Measurement) baseQuantity.clone();
    Packaging clone = new Packaging(isActive(), getAddedDate(),
        getLastModifiedDate(), gtin, name, description, baseQuantityClone,
        packageUom, reportWithSsu, seedSize, userDefinedField1, orderUomId,
        treatmentCode);
    for (Iterator itConfig = configurations.iterator(); itConfig.hasNext();) {
      PackageConfiguration configuration = (PackageConfiguration) itConfig
          .next();
      clone.addConfiguration((PackageConfiguration) configuration.clone());
    }
    return clone;
  }

  /**
   * @see com.monsanto.ag.ecg.domain.AgiisEntity#dispose()
   */
  public void dispose() {
    for (Iterator itConfig = configurations.iterator(); itConfig.hasNext();) {
      PackageConfiguration configuration = (PackageConfiguration) itConfig
          .next();
      configuration.dispose();
    }
    configurations.clear();

    baseQuantity.dispose();

    super.dispose();
  }

  private void setGtin(String gtin) {
    if (gtin != null && gtin.trim().length() == 14) {
      this.gtin = gtin.trim();
    } else {
      throw new IllegalArgumentException(
          "GTIN must be 14 characters long");
    }
  }

  private void setPackageUom(String packageUom) {
    if (StringUtils.isNotBlank(packageUom)) {
      this.packageUom = packageUom;
    } else {
      throw new IllegalArgumentException(
          "Package Unit of Measure is a required field");
    }
  }

  /**
   * Adds information about a specific configuration of this packaging to the
   * list of possibilities.
   * 
   * @param configuration
   *          Information about the package configuration
   */
  public void addConfiguration(PackageConfiguration configuration) {
    if (configuration != null) {
      configurations.add(configuration);
    }
  }

  /**
   * @see com.monsanto.ag.ecg.domain.AgiisEntity#appendXmlToElement(com.monsanto.ag.util.XmlElement)
   */
  public void appendXmlToElement(XmlElement baseXmlElement) {
    XmlElement rootElement = baseXmlElement
        .addChildElement("PackageSizeInformation");
    setActiveFlagAttribute(rootElement);
    setActionRequestAttribute(rootElement);

    addFirstLevelChildElements(rootElement);
  }

  private void addFirstLevelChildElements(XmlElement rootElement) {

    rootElement.addChildElement("CompanyPrefixCode", getCompanyPrefixCode());
    rootElement.addChildElement("PackageSizeCode", getPackageSizeCode());
    rootElement.addChildElement("PackageSizeName", name);
    rootElement.addChildElement("ShortDescription", description);

    if (baseQuantity != null) {
      XmlElement quantityElement = rootElement.addChildElement("BaseQuantity");
      baseQuantity.appendXmlToElement(quantityElement);
    }

    addUnitOfMeasureElement(rootElement, "PackageUnitOfMeasureCode",
        packageUom, UOM_DOMAIN_UN_REC_20);
    addUnitOfMeasureElement(rootElement, "ReportingUnitOfMeasureCode",
        getReportingUom(), UOM_DOMAIN_UN_REC_20);
    rootElement.addChildElement("SeedSize", getSeedSize());
    if (StringUtils.isNotEmpty(userDefinedField1)
        && !"N".equals(userDefinedField1)) {
      rootElement.addChildElement("UserDefinedField1", userDefinedField1);
    }

    //For Chem Product the treatment Code is sent as N/A, so the following parameters
    //  should not be added
    if(!"N/A".equals(treatmentCode)) {
        // Adding new UserDefinedFields in PackageSize level per new requirements
        if (!com.monsanto.Util.StringUtils.isNullOrEmpty(treatmentCode)) {
          rootElement.addChildElement("UserDefinedField2", treatmentCode);
        }
        rootElement
            .addChildElement("UserDefinedField3",
                (AppConstants.ACCELERON_TREATMENT_CODE
                    .equalsIgnoreCase(treatmentCode) ? "Y" : "N"));
    }

    rootElement.addChildElement("LastModifiedDateTime",
        getLastModifiedDateUTC());

    for (Iterator itConfig = configurations.iterator(); itConfig.hasNext();) {
      PackageConfiguration configuration = (PackageConfiguration) itConfig
          .next();

      configuration.appendXmlToElement(rootElement);
    }
  }

  private String getCompanyPrefixCode() {
    return gtin.substring(1, 8);
  }

  public String getPackageSizeCode() {
    return gtin.substring(8, 13);
  }

  private String getReportingUom() {
    if (getOrderUomId() == null) {
      return (reportWithSsu) ? "UN" : packageUom;
    } else {
      return getOrderUomId();
    }
  }

  private String getSeedSize() {
    return ("N/A".equals(seedSize)) ? null : seedSize;
  }

  public String getOrderUomId() {
    return orderUomId;
  }

  private String getLastModifiedDateUTC() {
    return XmlDateTimeUtil.formatDateAsXmlUTC(getLastModifiedDate());
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof Packaging)) {
      return false;
    }
    Packaging rhs = (Packaging) obj;
    return new EqualsBuilder().appendSuper(super.equals(obj)).append(gtin,
        rhs.gtin).append(name, rhs.name).append(description, rhs.description)
        .append(baseQuantity, rhs.baseQuantity).append(packageUom,
            rhs.packageUom).append(reportWithSsu, rhs.reportWithSsu).append(
            seedSize, rhs.seedSize).append(userDefinedField1,
            rhs.userDefinedField1).append(configurations, rhs.configurations)
        .isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 5).appendSuper(super.hashCode()).append(gtin)
        .append(name).append(description).append(baseQuantity).append(
            packageUom).append(reportWithSsu).append(seedSize).append(
            userDefinedField1).append(configurations).hashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}

/*
 * $Log: Packaging.java,v $
 * Revision 1.5  2009/07/21 20:15:45  mkuchip
 * Adding A4 as the fixed Acceleron Treatment Code
 * Revision 1.4 2009/07/21 20:03:03 mkuchip Adding new
 * fields for Acceleron Treated products in Productlist_2 and ProductLite_2
 * versions
 * 
 * Revision 1.3 2008/09/09 16:25:04 rwspeh *** empty log message ***
 * 
 * Revision 1.2 2008/08/28 17:54:12 rwspeh PCR0189657
 * 
 * Revision 1.1 2008/07/18 21:28:18 gjkell from ECG
 * 
 * Revision 1.13 2006/05/24 18:27:47 caggarw added processor_code to packaging
 * under field userDefinedField1 Revision 1.12 2005/12/01 19:55:37 ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and
 * tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks
 * 
 * Revision 1.11 2005/08/26 16:31:37 ggdavi Javadoc corrections
 * 
 * Revision 1.10 2005/08/19 15:14:34 ggdavi Modified to support different types
 * of products Revision 1.9 2005/07/28 15:47:50 ggdavi Added ActionRequest
 * attribute to various Product document elements; mapped the PackageLevelCode
 * and CheckDigit elements to the GTIN database column; only send one error
 * email per ProductUpdate document, containing all product-specific errors
 * Revision 1.8 2005/07/21 22:23:39 ggdavi Added
 * com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as
 * Account, EBusiness and SAP Ids) back and forth between their numeric and
 * zero-padded textual representations; enhanced and refactored XML abstraction
 * in com.monsanto.ag.util Revision 1.7 2005/07/05 19:35:28 ggdavi Now extends
 * AgiisEntity instead of implementing ExtractXML, which enforces use of
 * XmlDocumentBuilder implementations to generate the XML, as well as providing
 * clone and dispose methods Revision 1.6 2005/06/30 21:31:23 ggdavi Use
 * node.getOwnerDocument instead of helper.getDocument(node)
 * 
 * Revision 1.5 2005/06/30 16:44:04 ggdavi Modified insertXml so that it simply
 * adds elements to the baseElement parameter, rather than importing the
 * Document node from the toXML method Revision 1.4 2005/06/28 20:46:41 ggdavi
 * All units of measure are required Revision 1.3 2005/06/27 22:02:11 ggdavi
 * Tweaks in an effort to hit the moving anaysis target... Revision 1.2
 * 2005/06/22 21:53:59 ggdavi Moved AgiisDocumentHelper from ag.ecg.domain to
 * ag.util Revision 1.1 2005/06/22 17:22:09 ggdavi Initial version
 * 
 */