package com.monsanto.ag.cf.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;

import java.util.Date;

/**
 * Created by jtmurr on 4/21/2015.
 */
public class SeedTreatmentProductListAdder extends SeedProductListAdder {
    @Override
    protected Product mapRowToSeedProduct(PersistentStoreResultSetFwdIterator iter,
                                          boolean ecListMaterial,
                                          boolean active,
                                          Date addedDate,
                                          Date modifiedDate,
                                          String productId) throws WrappingException {
        return new SeedTreatmentProduct(ecListMaterial,
                active,
                addedDate,
                modifiedDate,
                productId,
                iter.getString("seed_company_brand_name"),
                iter.getString("acronym"),
                iter.getString("biotech_trait"),
                iter.getString("treatment_code"),
                iter.getString("treatment_descr"),
                iter.getString("display_descr"),
                iter.getString("species_code"),
                getBoolean(iter, "license_req_flag"),
                iter.getInt("license_trait_grp_id"),
                getBoolean(iter, "irm_flag"));
    }
}
