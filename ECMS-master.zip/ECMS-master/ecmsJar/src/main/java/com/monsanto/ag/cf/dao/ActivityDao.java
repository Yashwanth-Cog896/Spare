/*
 * ActivityDao was created on Mar 29, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import com.monsanto.ag.cf.domain.UserActivity;

/**
 * Data Access Object for user activity information.
 * 
 * @author Gareth Davies
 * @version $Id: ActivityDao.java,v 1.5 2005-05-13 14:00:37 ggdavi Exp $
 * @see SeedTrakInsourcingScope FC84i, FC84j, FC84k, FC84m
 */
public interface ActivityDao {

  public void storeActivity(UserActivity activity);

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.4  2005/04/05 21:36:07  ggdavi
 * Moved UserActivity back to domain package
 * Revision 1.3 2005/04/01 21:06:36 ajbaldw Updated
 * reference to UserActivity abstract class.
 * 
 * Revision 1.2 2005/03/29 23:09:34 ggdavi Moved UserActivity from logging to
 * domain
 * 
 * Revision 1.1 2005/03/29 20:02:51 ggdavi Initial version
 *  
 */