/*
 * ActivityLoggerAdvice was created on Mar 25, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.logging;

import java.lang.reflect.InvocationTargetException;

import javax.security.auth.Subject;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.dao.DataAccessException;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.ActivityDao;
import com.monsanto.ag.cf.dao.ActivityDocumentDao;
import com.monsanto.ag.cf.dao.EventDao;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.domain.SystemEvent;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.ServiceAdvice;
import com.monsanto.ag.util.IdTranslator;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;


import com.monsanto.ag.security.IdentityPrincipal;


/**
 * AOP Alliance MethodInterceptor that can be introduced in a chain to log
 * information about user-requested web service activities to a repository.
 * <p>
 * The information is partially extracted from the incoming and outgoing XML
 * messages (one of which may itself be stored) and also from the Subject
 * representing the currently authenticated user.
 * 
 * @author ajbaldw
 * @version $Id: ActivityLoggerAdvice.java,v 1.33 2008-05-27 16:02:59 na1000app-ec Exp $
 /* @see SeedTrakInsourcingScope FC74, FC84e, FC84i, FC84j, FC84k, FC84m
 */
public class ActivityLoggerAdvice extends ServiceAdvice implements MethodInterceptor {

  private ActivityDao activityDao;
  private ActivityDocumentDao activityDocumentDao;
  private EventDao eventDao;
  private IdMapperDao idMapperDao;
  private IdTranslator idTranslator;

  /**
   * @see org.aopalliance.intercept.MethodInterceptor#invoke(org.aopalliance.intercept.MethodInvocation)
   */
  public Object invoke(MethodInvocation invocation) throws Throwable {
    Object retVal = null;

    XmlMessageInformer inputXmlInformer = getInputXmlMessageInformer(invocation.getThis());
    XmlUserActivity activity = startUserActivity(invocation, inputXmlInformer);

    try {
      retVal = invocation.proceed();
      return retVal;
    } catch (InvocationTargetException e) {
      Throwable targetException = e.getTargetException();
      retVal = targetException;
      logWarning(activity.getExchangeType(), targetException.getMessage());
      throw targetException;
    } catch (RuntimeException e) {
      retVal = e;
      logWarning(activity.getExchangeType(), e.getMessage());
      throw e;
    } finally {
      XmlMessageInformer outputXmlInformer = getOutputXmlMessageInformer(invocation.getThis());
      endUserActivity(activity, retVal, inputXmlInformer, outputXmlInformer, invocation);
    }
  }

  private void logWarning(String exchangeType, String message) {
    String warning = "The following error occurred in " + exchangeType + ": " + message;
    Logger.log(new LoggableWarning(warning));
  }

  private XmlUserActivity startUserActivity(MethodInvocation invocation, XmlMessageInformer inputXmlInformer) {
    XmlUserActivity activity = null;

    XmlChunks inputXmlChunks = getInputXmlChunks(invocation.getArguments(), invocation.getMethod());

    if (inputXmlChunks != null && inputXmlInformer != null) {
      Subject subject = getCurrentUser(invocation.getArguments(), invocation.getMethod());
      IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal(subject);
      String serviceId = getServiceId(invocation.getThis());

      activity = new XmlUserActivity(idPrincipal.getName(), serviceId, idPrincipal.getAccountId());
      activity.init(inputXmlChunks, inputXmlInformer, idTranslator, idMapperDao);
    }

    return activity;
  }

  private void endUserActivity(XmlUserActivity activity, Object retVal, XmlMessageInformer inputXmlInformer,
      XmlMessageInformer outputXmlInformer, MethodInvocation invocation) {
      String serviceId = Utilities.getUnqualifiedClassName(invocation.getThis());
    if (activity != null && !serviceId.equals("InventoryActualUsageImpl")) {
      if (retVal instanceof Throwable) {
        activity.complete((Throwable) retVal, serviceId);
      } else {
        XmlChunks outputXmlChunks = getOutputXmlChunks(retVal, invocation.getMethod());
        String conversationId = getConversationId(retVal, invocation.getMethod());
        activity.complete(outputXmlChunks, conversationId, outputXmlInformer, serviceId);
      }

      try {
        storeActivity(activity);
        storeActivityDocuments(activity, inputXmlInformer, outputXmlInformer);
        storeEvent(activity.getEvent());
      } catch (DataAccessException e) {
        Logger.log(new LoggableError(e));
      }
    }
  }

  private void storeActivity(XmlUserActivity activity) {
    Logger.log(new LoggableInfo("Recording user activity " + activity));
    activityDao.storeActivity(activity);
  }

  private void storeActivityDocuments(XmlUserActivity activity, XmlMessageInformer inputXmlInformer,
      XmlMessageInformer outputXmlInformer) {
    Logger.log(new LoggableInfo("Recording user activity document for activity " + activity.getId()));
    storeActivityDocument(activity, inputXmlInformer, activity.getInputDocumentToStore(inputXmlInformer));
    storeActivityDocument(activity, outputXmlInformer, activity.getOutputDocumentToStore(outputXmlInformer));
  }

  private void storeActivityDocument(XmlUserActivity activity, XmlMessageInformer xmlInformer, XmlDocument xmlDocument) {
    if (!XmlDocument.NULL.equals(xmlDocument)) {
      String rootNodeName = xmlInformer.getRootNodeNameOfDocumentToStore();
      synchronized ( activityDocumentDao ){
        if (xmlInformer.isOnlyLatestDocumentStoredForAccount()) {
          activityDocumentDao.removeActivityDocuments(activity.getExchangeType(), activity.getAccountId(), rootNodeName);
        }
        activityDocumentDao.storeActivityDocument(activity.getId(), xmlDocument, rootNodeName);
      }
    }
  }

  private void storeEvent(SystemEvent event) {
    Logger.log(new LoggableInfo("Recording system event " + event));
    eventDao.storeEvent(event);
  }

  public void setActivityDao(ActivityDao activityDao) {
    this.activityDao = activityDao;
  }

  public void setActivityDocumentDao(ActivityDocumentDao activityDocumentDao) {
    this.activityDocumentDao = activityDocumentDao;
  }

  public void setEventDao(EventDao eventDao) {
    this.eventDao = eventDao;
  }

  public void setIdMapperDao(IdMapperDao idMapperDao) {
    this.idMapperDao = idMapperDao;
  }

  public void setIdTranslator(IdTranslator idTranslator) {
    this.idTranslator = idTranslator;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.32  2006/06/28 21:58:43  caggarw
 * pass outputXMlMessageInformer to activity.complete
 *
 * Revision 1.31  2006/06/21 21:58:27  caggarw
 * Refactoring to store input/output documents in the data_exchange respository as well as the root node name of the document. We now have separate messageinformers for input and output.
 * Revision 1.30 2006/06/07 17:27:56 ggdavi
 * Modified error handling in invoke to avoid problems caused by null messages
 * Revision 1.29 2006/01/24 18:56:18 ggdavi Moved ChunkableServiceEndpoint,
 * SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to
 * com.monsanto.ag.soa.server. This will simplify the class exclusion process
 * for consumer classes only interested in ag.soa.client classes.
 * 
 * Revision 1.28 2005/12/01 19:34:31 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.27 2005/08/26 16:10:56 ggdavi Moved the Identifiable and Entity
 * classes to the ag.util package and the ServiceAdvice class to the ag.soa
 * package for better dependency management
 * 
 * Revision 1.26 2005/08/23 17:14:38 ggdavi Modified SecureService.executeSecure
 * method signature to accept a ServiceInput argument instead of a List and
 * return a ServiceOutput object instead of a List Revision 1.25 2005/08/12
 * 17:01:57 ggdavi The invoke method now ensures that endUserActivity is called
 * only once, in the finally block - this resolves an issue with it throwing
 * exceptions after the main activity log record is stored (need transactions!),
 * which are caught and then the method is called again with the exception
 * information and an already identified activity
 * 
 * Revision 1.24 2005/08/02 20:57:37 ggdavi Modified service interfaces,
 * implementations and advice to support message/document chunking Revision 1.23
 * 2005/07/25 21:01:29 ggdavi Added support for mapping between SAP Id and
 * Account Id
 * 
 * Revision 1.22 2005/07/21 14:48:57 ggdavi Fleshed out and refactored
 * com.monsanto.ag.util to make more object-oriented, in that most functionality
 * has been pushed to the XmlDocument and XmlElement objects Revision 1.21
 * 2005/07/08 17:28:16 ggdavi Reordered XmlUserActivity constructor arguments
 * Revision 1.20 2005/06/17 18:18:30 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security
 * 
 * Revision 1.19 2005/06/07 21:18:08 ggdavi Move logging statements before calls
 * to DAOs
 * 
 * Revision 1.18 2005/05/31 20:41:23 ggdavi Use SOAP faults instead of a
 * standard error document Revision 1.17 2005/05/26 21:57:55 ggdavi
 * storeActivityDocument now removes any existing service documents for the
 * account Id before saving the new one Revision 1.16 2005/05/17 17:53:23 ggdavi
 * All AOP advice classes targeted at service implementations now extend the
 * ServiceAdvice abstract class Revision 1.15 2005/05/17 16:31:51 ggdavi
 * Extracted ag.util.XmlDateTimeUtil and ag.soa.ErrorDocument from
 * ag.util.Utilities
 * 
 * Revision 1.14 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.13 2005/05/13 14:00:37 ggdavi Added traceability to javadoc
 * 
 * Revision 1.12 2005/05/11 21:50:33 ggdavi Renamed all Subject method
 * parameters from user to subject for clarity
 * 
 * Revision 1.11 2005/05/09 18:08:55 ggdavi Added storeEvent method Revision
 * 1.10 2005/05/06 17:54:41 ggdavi Boatload of changes to accomodate change to
 * UserActivity (such as addition of SystemEvent field) and storing any
 * appropriate XML document Revision 1.9 2005/04/27 11:24:54 ggdavi Removed
 * conversationId parameter from Utilities.buildErrorDocument
 * 
 * Revision 1.8 2005/04/26 21:28:41 ggdavi endUserActivity now calls
 * XmlUserActivity.complete Revision 1.7 2005/04/21 19:18:42 ggdavi Catch
 * DataAccessException in endUserActivity, log the error but do not throw one
 * 
 * Revision 1.6 2005/04/21 15:32:47 ggdavi Added errorCode and errorMessage
 * fields to UserActivity Revision 1.5 2005/04/20 17:31:09 ggdavi Refactored to
 * cast invocation targets to interfaces instead of calling methods by
 * reflection Revision 1.4 2005/04/19 16:24:30 ggdavi More changes to support
 * long account Ids
 * 
 * Revision 1.3 2005/04/14 17:36:32 ggdavi Added traceability in Javadocs
 * 
 * Revision 1.2 2005/04/14 16:52:51 ggdavi Moved
 * ag.cf.logging.XmlUserActivityConfigurator to ag.cf.domain.XmlMessageInformer;
 * retrieve account id from authenticated user object Revision 1.1 2005/04/12
 * 19:25:01 ggdavi Renamed ActivityLogger to ActivityLoggerAdvice Revision 1.10
 * 2005/04/11 21:47:33 ggdavi Corrected traceability javadoc
 * 
 * Revision 1.9 2005/04/07 16:21:38 ggdavi Tweaked return value in invoke
 * 
 * Revision 1.8 2005/04/07 15:45:06 ggdavi Converted to an AOPAlliance method
 * interceptor Revision 1.7 2005/04/05 21:38:01 ggdavi Moved UserActivity back
 * to domain package
 * 
 * Revision 1.6 2005/04/01 21:04:52 ajbaldw Just a name change.
 * 
 * Revision 1.5 2005/04/01 16:38:49 ajbaldw Refactored and moved these into
 * ag/cf/logging package.
 * 
 * Revision 1.4 2005/03/29 23:09:49 ggdavi Moved UserActivity from logging to
 * domain
 * 
 * Revision 1.3 2005/03/29 20:03:51 ggdavi In progress for Alan to fool with
 * 
 * Revision 1.2 2005/03/28 20:49:17 ajbaldw oops, forgot formatting. Revision
 * 1.1 2005/03/28 15:13:49 ajbaldw *** empty log message ***
 */