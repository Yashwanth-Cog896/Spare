/*
 * GrowerDetails was created on Jul 24, 2007 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import com.monsanto.ag.cf.farmflex.domain.FarmFlexInfo;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.util.Date;
import java.util.List;

/**
 * Represent the information of a Grower.
 * 
 * @author Chetna Aggarwal
 * @version $Id: GrowerDetails.java,v 1.7 2008-07-02 19:43:33 dddoni Exp $
 * June 10 2008 - added fflxApproved,fmgrApproved,agreementCode
 * 
 */
public class GrowerDetails {

  private String invoiceNumber;
  private String accountName;
  private String contactFName;
  private String contactLName;
  private CustomerIds customerIds;
  private String licenseStatus;
  private AddressInformation addressInformation;
  private List zoneInformation;
  private long fflxId;
  private String fflxCode;
  private String contactPhone;
  private List mirIds;
  private Date maxEffDate;
  
  // Added on June 10 2008 for GOA II Customer Search Service
  private String fflxApproved;
  private String fmgrApproved;
  private String fmgrApprovedId;
  private String agreementCode;

    // Farm Flex
    private FarmFlexInfo farmFlexInfo;

  public GrowerDetails(String accountName, String contactFName, String contactLName, CustomerIds customerIds,
                       String licenseStatus, AddressInformation addressInformation, List zoneInformation, long fflxId,
                       String fflxCode,
                       String phone, Date maxEffDate, FarmFlexInfo farmFlexInfo) {
    super();
    this.accountName = accountName;
    this.contactFName = contactFName;
    this.contactLName = contactLName;
    this.customerIds = customerIds;
    this.licenseStatus = licenseStatus;
    this.addressInformation = addressInformation;
    this.zoneInformation = zoneInformation;
    this.fflxId = fflxId;
    this.fflxCode = fflxCode;
    this.contactPhone = phone;
    this.maxEffDate = maxEffDate;
    this.farmFlexInfo = farmFlexInfo;
  }

  public GrowerDetails(String invoiceNumber, String accountName, String contactFName, String contactLName,
                       CustomerIds customerIds, String licenseStatus, AddressInformation addressInformation,
                       List zoneInformation,
                       long fflxId, String fflxCode, String phone, Date maxEffDate, FarmFlexInfo farmFlexInfo) {
    super();
    this.invoiceNumber = invoiceNumber;
    this.accountName = accountName;
    this.contactFName = contactFName;
    this.contactLName = contactLName;
    this.customerIds = customerIds;
    this.licenseStatus = licenseStatus;
    this.addressInformation = addressInformation;
    this.zoneInformation = zoneInformation;
    this.fflxId = fflxId;
    this.fflxCode = fflxCode;
    this.contactPhone = phone;
    this.maxEffDate = maxEffDate;
    this.farmFlexInfo = farmFlexInfo;
  }

  public GrowerDetails(String accountName, String contactFName, String contactLName, CustomerIds customerIds,
                       String licenseStatus, AddressInformation addressInformation, List zoneInformation, long fflxId,
                       String fflxCode,
                       String phone, FarmFlexInfo farmFlexInfo) {
	    super();
	    this.accountName = accountName;
	    this.contactFName = contactFName;
	    this.contactLName = contactLName;
	    this.customerIds = customerIds;
	    this.licenseStatus = licenseStatus;
	    this.addressInformation = addressInformation;
	    this.zoneInformation = zoneInformation;
	    this.fflxId = fflxId;
	    this.fflxCode = fflxCode;
	    this.contactPhone = phone;
        this.farmFlexInfo = farmFlexInfo;
	   
	  }

	  public GrowerDetails(String invoiceNumber, String accountName, String contactFName, String contactLName,
                           CustomerIds customerIds, String licenseStatus, AddressInformation addressInformation,
                           List zoneInformation,
                           long fflxId, String fflxCode, String phone, FarmFlexInfo farmFlexInfo) {
	    super();
	    this.invoiceNumber = invoiceNumber;
	    this.accountName = accountName;
	    this.contactFName = contactFName;
	    this.contactLName = contactLName;
	    this.customerIds = customerIds;
	    this.licenseStatus = licenseStatus;
	    this.addressInformation = addressInformation;
	    this.zoneInformation = zoneInformation;
	    this.fflxId = fflxId;
	    this.fflxCode = fflxCode;
	    this.contactPhone = phone;
	    this.farmFlexInfo = farmFlexInfo;
	  }

	  
  public GrowerDetails() {    
  }

  public String getAccountName() {
    return accountName;
  }

  public AddressInformation getAddressInformation() {
    return addressInformation;
  }

  public String getContactFName() {
    return contactFName;
  }

  public String getContactLName() {
    return contactLName;
  }

  public CustomerIds getCustomerIds() {
    return customerIds;
  }

  public String getFflxCode() {
    return fflxCode;
  }

  public long getFflxId() {
    return fflxId;
  }

  public String getLicenseStatus() {
    return licenseStatus;
  }

  public List getZoneInformation() {
    return zoneInformation;
  }
  //added getter
  public Date getMaxEffDate() {
	   return maxEffDate;
  }

    //added maxefffdate
    public boolean equals(Object obj) {
        if (!(obj instanceof GrowerDetails)) {
            return false;
        }
        GrowerDetails rhs = (GrowerDetails) obj;
        return new EqualsBuilder().append(invoiceNumber, rhs.getInvoiceNumber())
              .append(accountName, rhs.getAccountName()).append(
                    contactFName, rhs.getContactFName()).append(contactLName, rhs.getContactLName())
              .append(customerIds, rhs.getCustomerIds()).append(licenseStatus, rhs.getLicenseStatus())
              .append(zoneInformation, rhs.getZoneInformation()).append(addressInformation, rhs.getAddressInformation())
              .append(fflxId, rhs.getFflxId()).append(fflxCode, rhs.getFflxCode())
              .append(contactPhone, rhs.getContactPhone()).append(mirIds, rhs.getMirIds())
              .append(maxEffDate, rhs.getMaxEffDate()).append(
                    farmFlexInfo, rhs.getFarmFlexInfo()).isEquals();
    }

    //added maxeffdate
    public int hashCode() {
        return new HashCodeBuilder(5, 7).append(invoiceNumber).append(accountName).append(contactFName).append(
              contactLName).append(customerIds).append(licenseStatus).append(zoneInformation).append(addressInformation)
              .append(fflxId).append(fflxCode).append(contactPhone).append(mirIds).append(maxEffDate).append(
                    farmFlexInfo).toHashCode();
    }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

  public void setZoneInformation(List zoneInformation) {
    this.zoneInformation = zoneInformation;
  }

  public String getContactPhone() {
    return contactPhone;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  public void setMirIds(List mirIds) {
    this.mirIds = mirIds;
  }

  public List getMirIds() {
    return mirIds;
  }

  public void setCustomerIds(CustomerIds customerIds) {
    this.customerIds = customerIds;
  }

  public void setFflxCode(String fflxCode) {
    this.fflxCode = fflxCode;
  }

  public void setFflxId(long fflxId) {
    this.fflxId = fflxId;
  }  
  
  //added setter
  public void setMaxEffDate(Date maxEffDate) {
	this.maxEffDate =  maxEffDate;
  }

public String getAgreementCode() {
	return agreementCode;
}

public void setAgreementCode(String agreementCode) {
	this.agreementCode = agreementCode;
}

public String getFflxApproved() {
	return fflxApproved;
}

public void setFflxApproved(String fflx_approved) {
	this.fflxApproved = fflx_approved;
}

public String getFmgrApproved() {
	return fmgrApproved;
}

public void setFmgrApproved(String fmgr_approved) {
	this.fmgrApproved = fmgr_approved;
}

public String getFmgrApprovedId() {
	return fmgrApprovedId;
}

public void setFmgrApprovedId(String fmgrApprovedId) {
	this.fmgrApprovedId = fmgrApprovedId;
}

    public FarmFlexInfo getFarmFlexInfo() {
        return farmFlexInfo;
    }

    public void setFarmFlexInfo(FarmFlexInfo farmFlexInfo) {
        this.farmFlexInfo = farmFlexInfo;
    }
}
