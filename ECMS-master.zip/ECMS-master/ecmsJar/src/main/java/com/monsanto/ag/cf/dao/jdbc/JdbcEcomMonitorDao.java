/*
 * JdbcEcomMonitorDao was created on Jul 25, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.EcomMonitorDao;

/**
 * Spring JDBC implemenation of the EcomMonitor DAO.
 * @author Chetna Aggarwal
 * @version $Id: JdbcEcomMonitorDao.java,v 1.1 2005-07-29 20:14:47 caggarw Exp $
 */
public class JdbcEcomMonitorDao extends BaseJdbcDao implements EcomMonitorDao {

  public int getDatabaseStatus() {
    String sql = "SELECT 1 FROM DUAL";
    return getJdbcTemplate().queryForInt(sql);
  }

}


/*
 * $Log: not supported by cvs2svn $
 */