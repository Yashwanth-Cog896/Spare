/*
 * JaxRpcEndpoint was created on May 25, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.endpoint;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.outage.OutageException;
import com.monsanto.ag.cf.security.RoleLookupClient;
import com.monsanto.ag.security.Authorizer;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.server.ChunkableServiceEndpoint;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.xml.validator.XmlStreamValidator;
import com.monsanto.ag.xml.validator.XmlValidationException;
import org.apache.axis.description.ServiceDesc;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.commons.lang.StringUtils;
import org.apache.ws.security.WSUsernameTokenPrincipal;
import org.springframework.remoting.jaxrpc.ServletEndpointSupport;
import org.springframework.web.context.WebApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;
import javax.xml.namespace.QName;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.soap.SOAPFaultException;
import java.util.Iterator;

/**
 * Generic endpoint for SOAP-based web services that integrates with the Spring
 * application context.
 *
 * @author Gareth Davies
 * @version $Id: JaxRpcEndpoint.java,v 1.6 2008-08-06 22:49:40 mkuchip Exp $
 */
public class JaxRpcEndpoint extends ServletEndpointSupport implements ChunkableServiceEndpoint {

    private static final String NAMESPACE_URI_ECMS = "urn:ecms:schema:errors:1:0";
    private static final String NAMESPACE_URI_WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";

    private static final String IMPLEMENTATION_BEAN_PROPERTY = "implementationBeanId";
    private static final String TRUSTED_LOOKUP_PROPERTY = "trustedBeanId";
    private static final String ROLE_LOOKUP_BEAN = "roleLookup";
    private static final String AUTHORIZER_BEAN = "authorizer";
    private static final String XML_DOCUMENT_BUILDER_BEAN = "xmlDocumentBuilder";
    private static final String XML_SCHEMA_URI_RESOLVER_BEAN = "xmlSchemaUriResolver";
    private static final String INPUT_VALIDATOR_BEAN = "inputValidator";
    private static final String OUTPUT_VALIDATOR_BEAN = "outputValidator";

    /**
     * Local fault code to specify when calling {@link #makeEcmsSoapFault(String, String)}
     * for cases of invalid business data.
     * Also used automatically when returning a Soap Fault for a schema violation.
     */
    public static final String MESSAGE_NOT_VALID_FAULT_CODE = "MessageNotValid";
    /**
     * Local fault code to specify when calling {@link #makeEcmsSoapFault(String, String)}
     * for cases of "internal error", including unexpected exception, programming
     * error detected, etc.
     */
    public static final String SERVICE_EXCEPTION_FAULT_CODE = "ServiceException";

    private SecureService service;
    private RoleLookupClient roleLookup;
    private Authorizer authorizer;
    private XmlDocumentBuilder xmlDocumentBuilder;
    private XmlSchemaUriResolver xmlSchemaUriResolver;
    private XmlStreamValidator inputValidator;
    private XmlStreamValidator outputValidator;

    protected void onInit() {
        WebApplicationContext appContext = getWebApplicationContext();

        String serviceImplBeanId = getServiceImplementationBeanId();
        Logger.log(new DebugLogEvent("Initializing SOAP endpoint for service implementation: " + serviceImplBeanId));
        service = (SecureService) appContext.getBean(serviceImplBeanId);

        String authenticatorBeanId = getAuthenticatorBeanId();
        roleLookup = (RoleLookupClient) appContext.getBean(authenticatorBeanId);

        authorizer = (Authorizer) appContext.getBean(AUTHORIZER_BEAN);

        xmlDocumentBuilder = (XmlDocumentBuilder) appContext.getBean(XML_DOCUMENT_BUILDER_BEAN);
        xmlSchemaUriResolver = (XmlSchemaUriResolver) appContext.getBean(XML_SCHEMA_URI_RESOLVER_BEAN);
        inputValidator = (XmlStreamValidator) appContext.getBean(INPUT_VALIDATOR_BEAN);
        outputValidator = (XmlStreamValidator) appContext.getBean(OUTPUT_VALIDATOR_BEAN);
    }

    private String getServiceImplementationBeanId() {
        MessageContext mc = getServletEndpointContext().getMessageContext();
        return (String) mc.getProperty(IMPLEMENTATION_BEAN_PROPERTY);
    }

    private String getAuthenticatorBeanId() {
        MessageContext mc = getServletEndpointContext().getMessageContext();
        String lookupBeanId = (String) mc.getProperty(TRUSTED_LOOKUP_PROPERTY);

        if (StringUtils.isNotBlank(lookupBeanId)) {
            //for trusted application
            return lookupBeanId;
        } else {
            //use regular lookup 
            return ROLE_LOOKUP_BEAN;
        }
    }

    /**
     * @see com.monsanto.ag.soa.server.ChunkableServiceEndpoint#execute(org.w3c.dom.Element[])
     */
    public Element[] execute(Element[] inputChunks) throws ServiceException {
        Logger.traceEntry();
        WSUsernameTokenPrincipal principal = getWSSPrincipal();
        String userId = principal.getName();
        String implBeanName = getServiceImplementationBeanId();

        try {
            Subject subject = new Subject();
            if (!implBeanName.equalsIgnoreCase("agiissubscriber") && !implBeanName.equalsIgnoreCase("inventoryactualusage"))
                 subject = roleLookup.findRoles(userId);

            if (implBeanName.equalsIgnoreCase("agiissubscriber") || implBeanName.equalsIgnoreCase("inventoryactualusage") || authorizer.isUserPermitted(subject, implBeanName)) {
                Logger.log(new DebugLogEvent("Delegating to service implementation: " + implBeanName));
                Element[] outputChunks = delegateToServiceImplementation(inputChunks, subject, service.isValidationRequired());
                return (Element[]) Logger.traceExit(outputChunks);
            } else {
                Logger.log(new LoggableWarning(userId + " is not authorized to use " + implBeanName));
                throw makeWsSecuritySoapFault("The security token could not be authorized");
            }
        } catch (SOAPFaultException sfe) {
            throw sfe;
        } catch (LoginException le) {
            Logger.log(new LoggableWarning(userId + " was not authenticated: " + le.getMessage()));
            throw makeWsSecuritySoapFault(le.getMessage());
        } catch (XmlValidationException xve) {
            Logger.log(new LoggableWarning(xve.getMessage()));
            throw makeEcmsSoapFault(MESSAGE_NOT_VALID_FAULT_CODE, xve.getMessage());
        } catch (OutageException oe) {
            Logger.log(new LoggableWarning(oe.getMessage()));
            throw makeEcmsSoapFault("ScheduledOutage", oe.getMessage());
        } catch (Exception e) {
            Logger.log(new LoggableError(e));
            throw makeEcmsSoapFault(SERVICE_EXCEPTION_FAULT_CODE, e.getMessage());
        } catch (Throwable e) {
            Logger.log(new LoggableError(e));
            throw makeEcmsSoapFault(SERVICE_EXCEPTION_FAULT_CODE, e.getMessage());
        }
    }

    private WSUsernameTokenPrincipal getWSSPrincipal() {
        MessageContext messageContext = getServletEndpointContext().getMessageContext();
        WSSecurityResultProcessor resultProcessor = new WSSecurityResultProcessor(messageContext);
        return resultProcessor.getUserPrincipal();
    }

    private Element[] delegateToServiceImplementation(Element[] inputChunks, Subject subject, boolean isValidationRequired)
            throws XmlValidationException {
        ServiceInput serviceInput = makeServiceInputFromInputElements(inputChunks);
        if (isValidationRequired) {
            validateXmlChunks(serviceInput.getXmlChunks(), inputValidator);
        }
        ServiceOutput serviceOutput = service.executeSecure(serviceInput, subject);
        if (isValidationRequired) {
            validateXmlChunks(serviceOutput.getXmlChunks(), outputValidator);
        }
        Element[] outputElements = makeOutputElementsFromServiceOutput(serviceOutput);
        return outputElements;
    }

    private ServiceInput makeServiceInputFromInputElements(Element[] inputChunks) {
        ServiceInput input = new ServiceInput();

        for (int i = 0; i < inputChunks.length; i++) {
            Element chunk = inputChunks[i];
            XmlDocument xmlDocument = xmlDocumentBuilder.createXmlDocument(chunk);
            input.getXmlChunks().addChunk(xmlDocument);
        }

        return input;
    }

    private void validateXmlChunks(XmlChunks xmlChunks, XmlStreamValidator validator) throws XmlValidationException {
        Logger
                .log(new DebugLogEvent("Validating " + xmlChunks.getCount() + " XML documents using " + validator.getClass()));
        String xmlSchemaUri = getXmlSchemaUri(xmlChunks);

        if (StringUtils.isNotEmpty(xmlSchemaUri)) {
            for (Iterator itChunk = xmlChunks.getIterator(); itChunk.hasNext();) {
                XmlStream chunk = (XmlStream) itChunk.next();
                validator.validate(chunk, xmlSchemaUri);
            }
        }
    }

    private String getXmlSchemaUri(XmlChunks xmlChunks) {
        String xmlSchemaUri = null;

        if (!xmlChunks.isEmpty()) {
            MessageContext messageContext = getServletEndpointContext().getMessageContext();
            String wsdlSpec = getWsdlUriFromServiceDescription(messageContext);

            XmlStream firstChunk = xmlChunks.getChunk(0);
            String namespaceUri = firstChunk.getDefaultNamespace().getUri();

            xmlSchemaUri = xmlSchemaUriResolver.resolve(wsdlSpec, namespaceUri);
        }

        return xmlSchemaUri;
    }

    private String getWsdlUriFromServiceDescription(MessageContext messageContext) {
        String wsdlUri = null;

        org.apache.axis.MessageContext axisContext = (org.apache.axis.MessageContext) messageContext;
        SOAPService service = axisContext.getService();

        if (messageHasServiceDescription(service)) {
            ServiceDesc serviceDesc = service.getServiceDescription();
            String wsdlFile = serviceDesc.getWSDLFile();

            if (StringUtils.isNotBlank(wsdlFile) && !Utilities.isUrlResourceSpec(wsdlFile)) {
                String transportURL = axisContext.getStrProp("transport.url");
                String path = axisContext.getStrProp("path");
                wsdlUri = StringUtils.substringBefore(transportURL, path) + wsdlFile;
            }
        }

        return wsdlUri;
    }

    private boolean messageHasServiceDescription(SOAPService service) {
        return service != null && service.getServiceDescription() != null;
    }

    private Element[] makeOutputElementsFromServiceOutput(ServiceOutput serviceOutput) {
        int outputChunkCount = serviceOutput.getXmlChunks().getCount();
        Element[] outputElements = new Element[outputChunkCount];

        XmlChunks outputChunks = serviceOutput.getXmlChunks();
        int i = 0;
        for (Iterator itChunk = outputChunks.getIterator(); itChunk.hasNext();) {
            XmlStream chunk = (XmlStream) itChunk.next();
            Document domDocument = chunk.getDOMDocument();
            outputElements[i++] = domDocument.getDocumentElement();
        }

        return outputElements;
    }

    /**
     * Create a SOAPFaultException, which will eventually be returned as a
     * SOAP Fault from the service.
     *
     * @param localFaultCode returned in the SOAP Fault as the faultcode element,
     *                       automatically prefixed by "ecms:".
     * @param faultString    returned in the SOAP Fault as the faultstring element.
     * @return SOAPFaultException as described above.
     */
    public static SOAPFaultException makeEcmsSoapFault(String localFaultCode, String faultString) {
        QName faultCode = new QName(NAMESPACE_URI_ECMS, "ecms:" + localFaultCode);
        return new SOAPFaultException(faultCode, faultString, null, null);
    }

    private SOAPFaultException makeWsSecuritySoapFault(String faultString) {
        QName faultCode = new QName(NAMESPACE_URI_WSSE, "wsse:FailedAuthentication");
        return new SOAPFaultException(faultCode, faultString, null, null);
    }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.5  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.4  2008/02/13 16:23:31  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.3.8.2  2008/02/08 21:28:53  maschec
 * Expose ecms:ServiceException as constant
 *
 * Revision 1.3.8.1  2008/02/05 19:13:40  maschec
 * Change allowable value of TransactionDetails@ProdIDQual from 'GTIN' to 'AGIIS-ProductID', and throw Soap Fault if it's anything else
 *
 * Revision 1.3  2007/05/30 20:00:06  caggarw
 * changed wsdl url to resolve to wsdl based on URL in order to run packed successfully
 * Revision 1.2 2006/07/13 18:48:25 caggarw
 * Changed the SOAP exception String for credentials expired to something more
 * instructive for the users. Revision 1.1 2006/05/08 14:17:38 caggarw moved
 * files from package jaxrpc into a common package called endpoint
 * 
 * Revision 1.24 2006/01/24 19:10:44 ggdavi Validation-related classes moved to
 * the com.monsanto.ag.xml.validator package. This will simplify the class
 * exclusion process for consumer classes not interested in XML validation.
 * 
 * Revision 1.23 2006/01/24 18:56:18 ggdavi Moved ChunkableServiceEndpoint,
 * SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to
 * com.monsanto.ag.soa.server. This will simplify the class exclusion process
 * for consumer classes only interested in ag.soa.client classes.
 * 
 * Revision 1.22 2005/12/05 20:07:08 ggdavi getWsdlUriFromServiceDescription now
 * uses the Utilities.isUrlResourceSpec method to determine if the WSDL resource
 * specification is a relative path that needs to be prefixed with the Axis home
 * directory Revision 1.21 2005/12/01 20:32:18 ggdavi Minor variable name
 * changes Revision 1.20 2005/12/01 19:34:31 ggdavi Refactored
 * com.monsanto.ag.util package, moving all XML-specific classes and tests into
 * the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class
 * replaces the java.util.List interface as the primary representation of a
 * collection of XML chunks Revision 1.19 2005/11/22 22:30:16 ggdavi Only prefix
 * WSDL file spec with Axis home directory if one exists!
 * 
 * Revision 1.18 2005/11/22 21:35:06 ggdavi Prefixed service WSDL file spec
 * (assuming its relative to the web app root) with directory of web app root
 * Revision 1.17 2005/11/09 18:47:44 ggdavi Replaced
 * ag.cf.jaxrpc.DocumentValidator interface (and implementation) usage with the
 * combination of the ag.cf.jaxrpc.XmlSchemaUriResolver and
 * ag.util.XmlStreamValidator interfaces (and implementations) usage Revision
 * 1.16 2005/11/08 21:00:31 ggdavi Updated after adding XmlStream (and StAX
 * implementation) to the com.monsanto.ag.util package and refactoring the
 * ServiceInput and ServiceOutput classes to expose both XmlStream and
 * XmlDocument objects Revision 1.15 2005/09/09 18:48:42 ggdavi Replaced
 * documentValidator bean with requestXmlValidator and responseXmlValidator, so
 * that we only validate incoming XML Revision 1.14 2005/09/06 21:09:07 ggdavi
 * DocumentValidator is now an interface with two implementations,
 * WsdlDocumentValidator (the original class, renamed) and
 * AlwaysTrueDocumentValidator (essentially a Null Object, skipping validation).
 * JaxRpcEndpoint pulls the implementation from the Spring application context
 * and passes the current MessageContext as an argument to the
 * validateXmlDocument method along with the XmlDocument. Revision 1.13
 * 2005/09/02 20:18:26 ggdavi Only validate the last input and output XML chunk
 * against XML schema
 * 
 * Revision 1.12 2005/08/24 16:48:34 ggdavi Added logging statements Revision
 * 1.11 2005/08/23 21:20:37 ggdavi Added log statements for clearer indications
 * of where time is spent during a service request Revision 1.10 2005/08/23
 * 17:14:38 ggdavi Modified SecureService.executeSecure method signature to
 * accept a ServiceInput argument instead of a List and return a ServiceOutput
 * object instead of a List Revision 1.9 2005/08/11 16:30:46 ggdavi Modified the
 * exception handling in the execute method to generate a generic SOAP fault
 * message for all RuntimeExceptions, so that nothing revealing is sent back to
 * the client Revision 1.8 2005/08/02 20:57:38 ggdavi Modified service
 * interfaces, implementations and advice to support message/document chunking
 * Revision 1.7 2005/07/08 17:27:29 ggdavi Changed beanName parameter to
 * implementationBeanId; the authenticator field is now set to the result of the
 * new getAuthenticatorBeanId method, which uses the value of the
 * authenticatorBeanId service parameter if it exists, otherwise uses the bean
 * identified by the AUTHENTICATOR_BEAN constant
 * 
 * Revision 1.6 2005/06/24 16:39:46 ggdavi Removed duplicate colon from
 * NAMESPACE_ECMS urn
 * 
 * Revision 1.5 2005/06/17 18:18:58 ggdavi Refactored ag.cf.security to move
 * common objects to ag.security
 * 
 * Revision 1.4 2005/06/06 21:19:58 ggdavi Add namespace URI to QName objects
 * Revision 1.3 2005/06/02 16:38:49 ggdavi execute catches OutageExceptions and
 * turns them into ecms:ScheduledOutage SOAP faults
 * 
 * Revision 1.2 2005/05/31 20:37:19 ggdavi Throw SOAPFaultExceptions instead of
 * creating SOAPFault documents Revision 1.1 2005/05/25 21:03:17 ggdavi Replaced
 * JaxRpc* classes with JaxRpcEndpoint
 * 
 */