/*
 * GPOSLiteTransformer was created on Jan 31, 2008 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Namespace;
import org.dom4j.QName;
import org.dom4j.Visitor;
import org.dom4j.VisitorSupport;
import org.dom4j.dom.DOMDocumentFactory;
import org.dom4j.io.SAXReader;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.service.endpoint.JaxRpcEndpoint;
import com.monsanto.ag.cf.EcmsXmlUtils;
import com.monsanto.ag.xml.NullXmlElement;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlElement;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.dom4j.Dom4jXmlDocument;
import com.monsanto.ag.xml.dom4j.Dom4jXmlDocumentBuilder;
import com.monsanto.ag.xml.dom4j.Dom4jXmlElement;

/**
 * Helper class for GPOSLite processing: Transforms the GPOSLite request
 * format into the regular GPOS (CIDX 4.0 based) request format.  This is done
 * so that GPOSLite can call the same WebMethods service as regular GPOS to perform
 * the real work.
 * <p/>
 * For debugging this class, it will be helpful to modify isDisplayOn() to return
 * true.  For production, this should return false.
 * 
 * @author Mark Schechter
 * @version $Id: GPOSLiteTransformer.java,v 1.9 2009/07/21 20:03:03 mkuchip Exp $
 */
public class GPOSLiteTransformer {
  private static final String NEW_LINE = System.getProperty("line.separator");
  
  //Attribute/Element names in Lite schema
  private static final String REPORT_DETAILS = "ReportDetails";
  private static final String REPORTER_ID = "ReporterID";
  private static final String REPORTER_QUAL = "ReporterQual";
  private static final String REPORTER_NAME = "ReporterName";
  private static final String SHIP_FROM = "ShipFrom";
  private static final String TRANSACTION_DETAILS = "TransactionDetails"; 
  private static final String OTHER_PARTNER = "OtherPartner";
  
  //Attribute/Element names in CIDX schema
  private static final String PARTNER_INFORMATION = "PartnerInformation";
  private static final String PARTNER_NAME = "PartnerName";
  private static final String PARTNER_IDENTIFIER = "PartnerIdentifier";
  private static final String AGENCY = "Agency";
  private static final String PARTNER_ROLE = "PartnerRole";
  
  /**
   * Transform the GPOSLite request (Lite format) into the regular GPOS
   * CIDX 4.0 request format.
   * 
   * @param gposliteRequest incoming request in GPOSLite_1-0.xsd format.
   * @return request transformed to CIDX_CeS_v4.0_Message_ProductMovementReport.xsd
   * format.
   */
  public XmlDocument transformToCidx40(XmlDocument gposliteRequest)
    throws DocumentException, IOException
  {
    final String GPOSLITE_NAMESPACE_URI = "urn:ecms:schema:gposlite:request:1:0";
    
    //gposliteRequest comes in as a DOMUtilXmlDocument. We want to work with
    // a Dom4jXmlDocument, and also even before that we want to work with a
    // straight Dom4j Document in order to have access to the namespaces.
    //Therefore, we'll start with the String representation of the incoming
    // document and go from there.

    String incomingXml = gposliteRequest.toString();
    
    SAXReader reader = new SAXReader();
    Document liteDom4jDoc = reader.read(
        new ByteArrayInputStream(incomingXml.getBytes()));
    Namespace rootNS = liteDom4jDoc.getRootElement().getNamespace();
    display("rootNS = " + rootNS.getPrefix() + ":" + rootNS.getURI());
    String liteNamespacePrefix = "";
    List nsList = liteDom4jDoc.getRootElement().additionalNamespaces();
    for (Iterator iter = nsList.iterator(); iter.hasNext();) {
      Namespace ns = (Namespace) iter.next();
      display("Additional NS = " + ns.getPrefix() + ":" + ns.getURI());
      if (GPOSLITE_NAMESPACE_URI.equals(ns.getURI())) {
        liteNamespacePrefix = ns.getPrefix() + ":";
      }
    }
    final String LITE_PFX = liteNamespacePrefix;
    display("LITE_PFX = " + LITE_PFX);
    final String SL_LITE_PFX = "/" + LITE_PFX;  //Slash + Lite prefix
    
    Dom4jXmlDocument liteDoc = new Dom4jXmlDocument(liteDom4jDoc);

    //Following is for debugging only
    display(liteDoc.toString());
    
    final String LITE_ROOT_XPATH = "//ProductMovementReportLite";
    final String CIDX_40_NAMESPACE =
      "urn:cidx:names:specification:ces:schema:all:4:0";

    Dom4jXmlDocument cidxDoc = new Dom4jXmlDocument(DOMDocumentFactory.getInstance().createDocument());
    XmlNamespace namespace = new XmlNamespace("cidx", CIDX_40_NAMESPACE);
    cidxDoc.addRootElement("ProductMovementReport", namespace.getDefault(), "4.0");
    cidxDoc.addNamespace(namespace);
    
    //Get the CIDX header out of the Lite version and copy to CIDX version
    XmlElement headerElement = liteDoc.selectElementByXPath(LITE_ROOT_XPATH 
        + "/cidx:Header");
    XmlElement cidxHeader = cidxDoc.getRootElement().importElement(headerElement, false);
    
    //WebMethods does NOT support having the cidx: namespace prefix on 
    // elements, at least as currently configured.  Remove it from the
    // copied Lite elements.
    Visitor namespacePrefixRemover = new VisitorSupport() {
      public void visit(Element element) {
        element.setQName(new QName(element.getName()));
      }
    };
    //Recurse through all elements in cidx:Header and remove the namespace prefix
    Element dom4jHeader = ((Dom4jXmlElement) cidxHeader).getElementImpl(); 
    dom4jHeader.accept(namespacePrefixRemover);
    
    //Tried for a couple hours to get rid of the result of:
    //  <Header xmlns="">
    //but couldn't despite numerous variations, such as:
    //  dom4jHeader.remove(new Namespace("", ""));
    //  dom4jHeader.addNamespace("", CIDX_40_NAMESPACE);
    //  etc. Just can't seem to get to this phantom namespace which doesn't
    //  show up as a child in the debugger; could possibly be a dom4j bug??
    //
    //For now, we'll use a brute force approach: 
    // Get the XML back as a String, and just replace the
    // offending portion, then transform back into DOM tree.
    // This is probably OK as a permanenet workaround since it takes less than
    // 10 milliseconds and the size of the header is small.
    {
      String cidxXml = cidxDoc.toString();
      //Note: must use Relucant wildcard (.*?) rather than Greedy (.*)
      // below, else if no line breaks will match the entire rest of the XML!
      cidxXml = cidxXml.replaceFirst("<Header.*?>", "<Header>");
      //IMPORTANT: Once the namespace declarations have been properly set
      // in the XML, as they have, use Dom4jXmlDocumentBuilder (versus
      // new Dom4jXmlDocument), because it will properly set the internal
      // XmlDocument properties defaultNamespace and otherNamespaces.
      // These must be set correctly so that XmlStreamValidator.validate()
      // will work properly if used in a unit test.
      Dom4jXmlDocumentBuilder builder = new Dom4jXmlDocumentBuilder();
      cidxDoc = (Dom4jXmlDocument) builder.createXmlDocument(new StringReader(cidxXml));
    }
    
    //If the following element is longer than 20 characters, the request will
    // fail in WebMethods because the database field written to is limited
    // to that length. This should not a problem in production, but when writing
    // test cases and getting test files from the BA it has proven to be one.
    // Business users don't want a SOAP fault thrown for this certain failure,
    // but to save developer time at least we can log the problem if it exists
    
    // 07-21-2009: Increasing the length to 40 chars, based on the change done on Webmethods.    
    String docId = cidxDoc.getNodeValueByXPath(
        "//cidx:Header/cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier");
    final int MAX_LEN_DOC_CTL_ID = 40;  //Max length of ultimate target field 
    if (docId != null && docId.trim().length() > MAX_LEN_DOC_CTL_ID) {
      logError("DocumentIdentifier in incoming request ('" +  docId 
          + "') is longer than the ultimate target database field DIRECT_STAGING.DOC_CTL_ID" 
          + " (max length " + MAX_LEN_DOC_CTL_ID
          + "), so this request will fail within the WebMethods service.");
    }

    //-------------------------------------------------------------------
    // Transform the non-Header (non-CIDX) data from its Lite format to
    // the CIDX-equivalent format
    //-------------------------------------------------------------------
    
    //Lite ReportDetails is a required element
    //Schema allows for multiple ReportDetails elements, but code is only
    // written to handle one -- not that it would be a big deal to change
    // it to handle multiples, but I'm not investing the time right now.
    List reportDetailsList = liteDoc.selectElementsByXPath(LITE_ROOT_XPATH 
        + SL_LITE_PFX + REPORT_DETAILS);
    if (reportDetailsList.size() > 1) {
      throw JaxRpcEndpoint.makeEcmsSoapFault(JaxRpcEndpoint.MESSAGE_NOT_VALID_FAULT_CODE, 
          "Multiple " + REPORT_DETAILS + " elements not currently supported.");
    }
    XmlElement liteReportDetails = (XmlElement) reportDetailsList.get(0); 
    
    XmlElement pmrBody = cidxDoc.getRootElement().addChildElement("ProductMovementReportBody");
    XmlElement pmrDetails = pmrBody.addChildElement("ProductMovementReportDetails");
    XmlElement reportingEntity = pmrDetails.addChildElement("ReportingEntity");
    XmlElement partnerInformation = reportingEntity.addChildElement(PARTNER_INFORMATION);
    
    //Lite ReporterName is a required element
    XmlElement liteReporterName = liteReportDetails.getChild(REPORTER_NAME);
    partnerInformation.addChildElement(PARTNER_NAME, liteReporterName.getText());
    
    //Lite ReporterID is a required attribute
    XmlElement partnerIdentifier = partnerInformation.addChildElement(PARTNER_IDENTIFIER, 
        liteReportDetails.getAttributeValue(REPORTER_ID));
    
    //Lite ReporterQual is a required attribute
    partnerIdentifier.setAttribute(AGENCY, 
        liteReportDetails.getAttributeValue(REPORTER_QUAL));
    
    //One or more Lite Transactions are required
    List children = liteReportDetails.getChildren();
    List liteTransactions = new ArrayList();
    for (Iterator iter = children.iterator(); iter.hasNext();) {
      XmlElement element = (XmlElement) iter.next();
      if ("Transaction".equals(element.getUnqualifiedName())) {
        liteTransactions.add(element);
      }
    }
    
    if (liteTransactions.size() > 0) { //Always true for validated Lite XML
      XmlElement pmTransactions = pmrDetails.addChildElement("ProductMovementTransactions");
      //Following is required CIDX attribute and value
      pmTransactions.setAttribute("ProductMovementReportType", "SalesReport");
      
      //Translate and add all Transaction children
      for (Iterator iter = liteTransactions.iterator(); iter.hasNext();) {
        XmlElement transaction = (XmlElement) iter.next();
        addLiteTransaction(pmTransactions, transaction, liteReportDetails);
      }
    }
    
    //Following is for debugging only
    prettyPrintDom4jXmlDocument(cidxDoc);

    return cidxDoc;
  }

  /**
   * Translate and add the Lite Transaction element to the CIDX
   * ProductMovementTransactions element.
   * 
   * @param pmTransactions CIDX ProductMovementTransactions element to add
   * translated Lite Transaction to.
   * @param transaction Lite Transaction element to add.
   * @param liteReportDetails parent of <code>transaction</code>. Note this is
   * used to provide Ship From information if it has not been explicitly provided
   * in a lite ReportsDetails/Transaction/Partners/OtherPartner[@Role='ShipFrom']
   * element.
   */
  private void addLiteTransaction(XmlElement pmTransactions, XmlElement transaction, 
      XmlElement liteReportDetails) 
  {
    XmlElement pmTransaction = pmTransactions.addChildElement("ProductMovementTransaction");
    //There is only one of the following, per CIDX schema
    XmlElement pmtProperties = pmTransaction.addChildElement("ProductMovementTransactionProperties");
    //There is only one of the following, per CIDX schema
    XmlElement pmtPartners = pmTransaction.addChildElement("ProductMovementTransactionPartners");
    
    //Lite Properties is a required child
    XmlElement properties = transaction.getChild("Properties");
    //Lite POSType a is required attribute
    pmtProperties.setAttribute("ProductMovementType", 
        properties.getAttributeValue("POSType"));
    //Lite SaleOrReturnType is a required attribute
    pmtProperties.setAttribute("SaleOrReturnType", 
        properties.getAttributeValue("SaleOrReturnType"));
    
    //Per schema, one or more Lite ReferenceInfo elements, and one or more
    // Lite EventDateTime elements, are required, as children of Lite Properties.
    List children = properties.getChildren();
    List referenceInfos = new ArrayList();
    List eventDateTimes = new ArrayList();
    for (Iterator iter = children.iterator(); iter.hasNext();) {
      XmlElement element = (XmlElement) iter.next();
      if ("ReferenceInfo".equals(element.getUnqualifiedName())) {
        referenceInfos.add(element);
      }
      else if ("EventDateTime".equals(element.getUnqualifiedName())) {
        eventDateTimes.add(element);
      }
    }
    
    //Add ReferenceInfos first (required order per schema)
    for (Iterator iter = referenceInfos.iterator(); iter.hasNext();) {
      XmlElement referenceInfo = (XmlElement) iter.next();
      XmlElement rInformation = pmtProperties.addChildElement("ReferenceInformation");
      //Lite Type attribute is required
      rInformation.setAttribute("ReferenceType",
          referenceInfo.getAttributeValue("Type"));
      //Lite DocID is a required attribute
      XmlElement docRef = rInformation.addChildElement("DocumentReference");
      XmlElement docIdentifier = docRef.addChildElement("DocumentIdentifier");
      docIdentifier.setText(referenceInfo.getAttributeValue("DocID"));
    }
    
    //Add EventDateTimes next (required order per schema)
    for (Iterator iter = eventDateTimes.iterator(); iter.hasNext();) {
      XmlElement eventDateTime = (XmlElement) iter.next();
      XmlElement cidxEDT = pmtProperties.addChildElement("EventDateTime");
      //Lite Type is a required attribute
      cidxEDT.setAttribute("EventDateType",
          eventDateTime.getAttributeValue("Type"));
      //Lite DateTime is a required attribute
      XmlElement dateTime = cidxEDT.addChildElement("DateTime");
      dateTime.setText(eventDateTime.getAttributeValue("DateTime"));
      //Following CIDX attribute must always be set
      dateTime.setAttribute("DateTimeQualifier", "On");
    }
    
    //CIDX pmtProperties also has two other required elements in the order
    // specified, as follows:
    XmlElement languageCode = pmtProperties.addChildElement("LanguageCode");
    languageCode.setAttribute("Domain", "ISO-639-2T");
    languageCode.setText("eng");
    XmlElement currencyCode = pmtProperties.addChildElement("CurrencyCode");
    currencyCode.setAttribute("Domain", "ISO-4217");
    currencyCode.setText("USD");

    //If Lite Properties@SpecialInstructions = "Reversal", then create CIDX
    // child ProductMovementTransactionProperties/SpecialInstruction
    // with attribute @InstructionType="PostingInstructions" and text
    // "Reversal", in this position per schema.
    final String REVERSAL = "Reversal";
    {   //Local block to avoid coding errors
      String specialInstructions = properties.getAttributeValue("SpecialInstructions");
      if (REVERSAL.equals(specialInstructions)) {   //Yes, it IS case-sensitive
        XmlElement cidxSpecialInstructions = pmtProperties.addChildElement("SpecialInstructions");
        //Following CIDX text and attribute are fixed, to indicate Reversal
        cidxSpecialInstructions.setText(REVERSAL);
        cidxSpecialInstructions.setAttribute("InstructionType", "PostingInstructions");
      }
    }
    
    //Lite Partners is a required child
    XmlElement partners = transaction.getChild("Partners");
    //One Lite ShipToPartner is required; there can be zero or more
    // Lite OtherPartners
    children = partners.getChildren();
    XmlElement shipToPartner = null;
    List otherPartners = new ArrayList();
    for (Iterator iter = children.iterator(); iter.hasNext();) {
      XmlElement element = (XmlElement) iter.next();
      if ("ShipToPartner".equals(element.getUnqualifiedName())) {
        shipToPartner = element;
      }
      else if (OTHER_PARTNER.equals(element.getUnqualifiedName())) {
        otherPartners.add(element);
      }
    }
    
    //Add the required Lite ShipToPartner
    XmlElement shipTo = pmtPartners.addChildElement("ShipTo");
    addPartnerInfo(shipTo, shipToPartner);
    
    //Add optional Lite OtherPartners, and track whether the requester supplied 
    // ShipFrom information
    boolean shipFromOtherPartnerExists = false;
    for (Iterator iter = otherPartners.iterator(); iter.hasNext();) {
      XmlElement otherPartner = (XmlElement) iter.next();
      XmlElement cidxOtherPartner = pmtPartners.addChildElement(OTHER_PARTNER);
      //Lite Role is a required attribute
      String roleFromRequest = otherPartner.getAttributeValue("Role"); 
      cidxOtherPartner.setAttribute(PARTNER_ROLE, roleFromRequest);
      addPartnerInfo(cidxOtherPartner, otherPartner);
      if (SHIP_FROM.equals(roleFromRequest)) {
        shipFromOtherPartnerExists = true;
      }
    }
    
    //If requester didn't provide ShipFrom info via OtherPartner element,
    // then get minimum required ShipFrom info from the Reporter info
    if (!shipFromOtherPartnerExists) {
      XmlElement cidxOtherPartner = pmtPartners.addChildElement(OTHER_PARTNER);
      addDefaultShipFromBasedOnReporterInfo(cidxOtherPartner, liteReportDetails);
    }
    
    //Add Lite TransactionDetails, 1..n
    List transactionDetailsList = new ArrayList();
    children = transaction.getChildren();
    for (Iterator iter = children.iterator(); iter.hasNext();) {
      XmlElement element = (XmlElement) iter.next();
      if (TRANSACTION_DETAILS.equals(element.getUnqualifiedName())) {
        transactionDetailsList.add(element);
      }
    }
    XmlElement pmTranDetails = 
      pmTransaction.addChildElement("ProductMovementTransactionDetails");
    for (Iterator iter = transactionDetailsList.iterator(); iter.hasNext();) {
      XmlElement transactionDetails = (XmlElement) iter.next();
      addLiteTransactionDetails(pmTranDetails, transactionDetails);
    }

  }
  
  /**
   * Translate and add the Lite TransactionDetails element to the CIDX
   * ProductMovementTransactionDetails element.
   * 
   * @param pmTranDetails CIDX ProductMovementTransactionDetails element to add
   * translated Lite TransactionDetails to.
   * @param transactionDetails Lite TransactionDetails element to add.
   */
  private void addLiteTransactionDetails(XmlElement pmTranDetails, XmlElement transactionDetails) {
    XmlElement pmpLineItem = pmTranDetails.addChildElement("ProductMovementProductLineItem");
    
    //Lite LineNbr is a required attribute
    XmlElement lineNumber = pmpLineItem.addChildElement("LineNumber");
    lineNumber.setText(transactionDetails.getAttributeValue("LineNbr"));

    //Lite ProdIDQual is a required attribute, as is Lite ProdID
    XmlElement productIdentification = pmpLineItem.addChildElement("ProductIdentification");
    XmlElement productIdentifier = productIdentification.addChildElement("ProductIdentifier");
    
    final String PROD_ID_QUAL = "ProdIDQual";
    final String PROD_ID = "ProdID";
    final String AGIIS_PRODUCTID = "AGIIS-ProductID";
    String prodIdQual = transactionDetails.getAttributeValue(PROD_ID_QUAL);
    if (AGIIS_PRODUCTID.equals(prodIdQual)) 
    { //Allowable values
      productIdentifier.setAttribute(AGENCY, prodIdQual);
      productIdentifier.setText(transactionDetails.getAttributeValue(PROD_ID));
    }
    else {
      throw JaxRpcEndpoint.makeEcmsSoapFault(JaxRpcEndpoint.MESSAGE_NOT_VALID_FAULT_CODE, 
          "Attribute value of '"+ prodIdQual + "' for " 
          + TRANSACTION_DETAILS + "@" + PROD_ID_QUAL + " is not supported. " 
          + "Allowable value is '" + AGIIS_PRODUCTID + "'.");
    }
    //Lite Qty is a required attribute
    XmlElement productQuantity = pmpLineItem.addChildElement("ProductQuantity");
    XmlElement measurement = productQuantity.addChildElement("Measurement");
    XmlElement measurementValue = measurement.addChildElement("MeasurementValue");
    measurementValue.setText(transactionDetails.getAttributeValue("Qty"));
    //Lite UOM is a required attribute
    XmlElement unitOfMeasureCode = measurement.addChildElement("UnitOfMeasureCode");
    unitOfMeasureCode.setAttribute("Domain", "UN-Rec-20");    //Required by CIDX
    unitOfMeasureCode.setText(transactionDetails.getAttributeValue("UOM"));
    //Lite Characteristic is an optional attribute
    {   //Local block to prevent copy/paste errors
      String characteristic = transactionDetails.getAttributeValue("Characteristic");
      if (!isBlank(characteristic)) {
        XmlElement cidxCharacteristic = pmpLineItem.addChildElement("Characteristic");
        XmlElement charDescription = cidxCharacteristic.addChildElement("CharacteristicDescription");
        charDescription.setText(characteristic);
      }
    }
    //Lite SpecialInstructions is an optional attribute
    {   //Local block to prevent copy/paste errors
      String specialInstructions = transactionDetails.getAttributeValue("SpecialInstructions");
      if (!isBlank(specialInstructions)) {
        XmlElement cidxSpecialInstructions = pmpLineItem.addChildElement("SpecialInstructions");
        cidxSpecialInstructions.setText(specialInstructions);
        cidxSpecialInstructions.setAttribute("InstructionType", 
            "CustomerRequiredInstructions");    //Required by CIDX
      }
    }
    //Note: As of March 2008 release, Lite attribute LotNbr (Lot Number) is
    // not being sent by handheld, nor processed here.
  }

  /**
   * Add Ship From information to the <code>cidxOtherPartner</code>element based
   * on the Lite reporter information available in various <code>liteReportDetails</code>
   * required attributes and elements.
   * <p/>
   * Note this method should only be called if Ship From information has not been 
   * explicitly provided in a lite 
   * ReportsDetails/Transaction/Partners/OtherPartner[@Role='ShipFrom']
   * element.
   * 
   * @param cidxOtherPartner CIDX element previously created to hold Ship From
   * info, that will have appropriate children created by this method.
   * @param liteReportDetails Lite source of reporter info to tranform to
   * CIDX Ship From info.
   */
  private void addDefaultShipFromBasedOnReporterInfo(XmlElement cidxOtherPartner, 
      XmlElement liteReportDetails) 
  {
    //Following two are required Lite attributes
    String reporterID = liteReportDetails.getAttributeValue(REPORTER_ID);
    String reporterQual = liteReportDetails.getAttributeValue(REPORTER_QUAL);
    //Lite ReporterName is a required element
    String reporterName = liteReportDetails.getChild(REPORTER_NAME).getText();
    
    //Now transform to CIDX equivalents representing ShipFrom info
    cidxOtherPartner.setAttribute(PARTNER_ROLE, SHIP_FROM);
    XmlElement partnerInformation = cidxOtherPartner.addChildElement(PARTNER_INFORMATION);
    XmlElement partnerName = partnerInformation.addChildElement(PARTNER_NAME);
    partnerName.setText(reporterName);
    XmlElement partnerIdentifier = partnerInformation.addChildElement(PARTNER_IDENTIFIER);
    partnerIdentifier.setAttribute(AGENCY, reporterQual);
    partnerIdentifier.setText(reporterID);
  }

  /**
   * Common routine to transform Lite-formatted partner info (ShipToPartner
   * or OtherPartner) to the equivalent CIDX format.
   * 
   * @param shipTo CIDX partner element, either a 
   * ../ProductMovementTransactionPartners/ShipTo or a
   * ../ProductMovementTransactionPartners/OtherPartner.
   * @param shipToPartner Lite-formatted partner element, either a 
   * ../Partners/ShipToPartner or a
   * ../Partners/OtherPartner.
   */
  private void addPartnerInfo(XmlElement cidxPartner, XmlElement litePartner) {
    XmlElement partnerInformation = cidxPartner.addChildElement(PARTNER_INFORMATION);
    XmlElement partnerName = partnerInformation.addChildElement(PARTNER_NAME);
    //Lite Name is a required child
    partnerName.setText(litePartner.getChild("Name").getText());
    XmlElement partnerIdentifier = partnerInformation.addChildElement(PARTNER_IDENTIFIER);
    //Lite IDQual is a required attribute
    partnerIdentifier.setAttribute(AGENCY, 
        litePartner.getAttributeValue("IDQual"));
    //Lite ID is a required attribute
    partnerIdentifier.setText(litePartner.getAttributeValue("ID"));
    
    //CIDX ShipTo/PartnerInformation/ContactInformation is optional; we'll
    // only create it if we need it to transform Lite info into
    XmlElement contactInformation = null;
    
    //Lite ContactName is an optional child
    XmlElement contactName = litePartner.getChild("ContactName");
    if (childFoundWithText(contactName)) {
      if (contactInformation == null) {
        contactInformation = createContactInformation(partnerInformation);
      }
      XmlElement cidxContactName = contactInformation.addChildElement("ContactName");
      cidxContactName.setText(contactName.getText());
    }
    //Lite ContactNumber is an optional attribute
    String contactNumber = litePartner.getAttributeValue("ContactNumber");
    if (!isBlank(contactNumber)) {
      if (contactInformation == null) {
        contactInformation = createContactInformation(partnerInformation);
      }
      XmlElement cidxContactNumber = contactInformation.addChildElement("ContactNumber");
      cidxContactNumber.setText(contactNumber);
    }
    //Lite Address is an optional child
    XmlElement addressInformation = null;
    {   //Local block to prevent copy/paste errors
      XmlElement address = litePartner.getChild("Address");
      if (childFoundWithText(address)) {
        if (addressInformation == null) {
          addressInformation = createAddressInformation(partnerInformation);
        }
        XmlElement addressLine = addressInformation.addChildElement("AddressLine");
        addressLine.setText(address.getText());
      }
    }
    //Lite City is an optional child
    {   //Local block to prevent copy/paste errors
      XmlElement city = litePartner.getChild("City");
      if (childFoundWithText(city)) {
        if (addressInformation == null) {
          addressInformation = createAddressInformation(partnerInformation);
        }
        XmlElement cityName = addressInformation.addChildElement("CityName");
        cityName.setText(city.getText());
      }
    }
    //Lite State is an optional attribute
    {   //Local block to prevent copy/paste errors
      String state = litePartner.getAttributeValue("State");
      if (!isBlank(state)) {
        if (addressInformation == null) {
          addressInformation = createAddressInformation(partnerInformation);
        }
        XmlElement stateOrProvince = addressInformation.addChildElement("StateOrProvince");
        stateOrProvince.setText(state);
      }
    }
    //Lite Zip is an optional attribute
    {   //Local block to prevent copy/paste errors
      String zip = litePartner.getAttributeValue("Zip");
      if (!isBlank(zip)) {
        if (addressInformation == null) {
          addressInformation = createAddressInformation(partnerInformation);
        }
        XmlElement postalCode = addressInformation.addChildElement("PostalCode");
        postalCode.setText(zip);
      }
    }
    //CIDX PostalCountry is a fixed value, but ONLY if we have other address
    // info already existing; else its existence would violate the CIDX schema
    {   //Local block to prevent copy/paste errors
      if (addressInformation != null) {
        XmlElement postalCountry = addressInformation.addChildElement("PostalCountry");
        postalCountry.setText("USA");
      }
    }
    
  }

  /**
   * Tests if the child XmlElement returned by an XmlElement.getChild("elementName")
   * call was really found or not. The call will always return something, but
   * if the element wasn't really found, it will return a NullXmlElement.
   * 
   * @param childReturned as described above
   * @return true if childReturned is not null and is not a NullXmlElement;
   * else false.
   */
  private boolean childFound(XmlElement childReturned) {
    return (childReturned != null && !(childReturned instanceof NullXmlElement));
  }
  
  /**
   * Similar to {@link #childFound(XmlElement)}, but for this
   * to return true, <code>childReturned</code> must also have non-blank
   * text contents.
   */
  private boolean childFoundWithText(XmlElement childReturned) {
    boolean foundWithText = false;  //Assume not
    if (childFound(childReturned)) {
      foundWithText = !isBlank(childReturned.getText());
    }
    return foundWithText;
  }

  /** Returns true if <code>str</code> is null,
   * empty, or white space. */
  private boolean isBlank(String str) {
    if (str == null) {
      return true;
    }
    return (str.trim().length() == 0);
  }

  /** Create and return a ContactInformation child element. */
  private XmlElement createContactInformation(XmlElement partnerInformation) {
    return partnerInformation.addChildElement("ContactInformation");
  }

  /** Create and return an AddressInformation child element. */
  private XmlElement createAddressInformation(XmlElement partnerInformation) {
    return partnerInformation.addChildElement("AddressInformation");
  }

  /** Log an error using Monsanto standard logging mechanism if active,
   * else just write to System.out. */
  protected void logError(String message) {
    if (Logger.numActiveLoggers() > 0) {
      Logger.log(new LoggableError(message));
    }
    else {
      System.out.println(NEW_LINE + "ERROR: " + message 
          + " (from " + this.getClass().getName() + ")");
    }
  }
  
  
  /**
   * For debugging only: Pretty-print the <code>docToPrint</code>
   * via display().
   */
  private void prettyPrintDom4jXmlDocument(Dom4jXmlDocument docToPrint) throws IOException, DocumentException {
    if (isDisplayOn()) {    //Don't waste time formatting if we're not going to display
      String prettyXml = EcmsXmlUtils.prettyPrintXml(docToPrint.toString());
      display(prettyXml);
    }
  }
  
  private boolean isDisplayOn() {
    return false;   //Must be false for production; set to true when debugging
  }
  
  /** Central location to turn on/off interactive debugging messages
   * (without messing with Log4j). */
  private void display(String msg) {
    if (isDisplayOn()) {
      System.out.println(msg);
    }
  }

}


/*
 * $Log: GPOSLiteTransformer.java,v $
 * Revision 1.9  2009/07/21 20:03:03  mkuchip
 * Adding new fields for Acceleron Treated products in Productlist_2 and ProductLite_2 versions
 *
 * Revision 1.8  2008/02/15 23:42:04  maschec
 * Standardize format of all comments re Lite element/attribute required/optional
 *
 * Revision 1.7  2008/02/15 23:15:19  maschec
 * Move TransactionsDetails transform into a separate method
 *
 * Revision 1.6  2008/02/15 22:43:20  maschec
 * Detect if multiple ReportDetails elements provided and throw Soap Fault since not currently supported
 *
 * Revision 1.5  2008/02/15 20:35:25  maschec
 * Log error if DocumentIdentifier (target DIRECT_STAGING.DOC_CTL_ID) is longer than 20 chars, since it will fail in WebMethods.
 *
 * Revision 1.4  2008/02/15 15:59:12  maschec
 * Get validation against schema working in UT, and fix problems revealed in GPOSLiteTransformer
 *
 * Revision 1.3  2008/02/14 16:46:22  maschec
 * Implement GPOSLite revision request to default Ship From information based on reporter info, if not explicitly provided by an OtherPartner element
 *
 * Revision 1.2  2008/02/13 16:23:32  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.1.2.10  2008/02/08 23:07:04  maschec
 * Fix bug with greedy match in GPOSLiteTransformer, build unit tests to detect similar in the future.
 *
 * Revision 1.1.2.9  2008/02/05 19:13:41  maschec
 * Change allowable value of TransactionDetails@ProdIDQual from 'GTIN' to 'AGIIS-ProductID', and throw Soap Fault if it's anything else
 *
 * Revision 1.1.2.8  2008/02/02 20:52:46  maschec
 * Save WIP: Get submission to WebMethods working!
 *
 * Revision 1.1.2.7  2008/02/01 17:48:50  maschec
 * Save WIP: Output now passed CIDX schema validation
 *
 * Revision 1.1.2.6  2008/02/01 16:00:59  maschec
 * Save WIP: Special processing for Reversal
 *
 * Revision 1.1.2.5  2008/02/01 15:22:33  maschec
 * Save WIP: Completed TransactionDetails transform
 *
 * Revision 1.1.2.4  2008/01/31 21:22:41  maschec
 * Save WIP: Begin work on TransactionDetails
 *
 * Revision 1.1.2.3  2008/01/31 20:13:44  maschec
 * Save WIP: Implemented entire ShipToPartner
 *
 * Revision 1.1.2.2  2008/01/31 17:55:18  maschec
 * Update GPOSLite schema and change code/data correspondingly: Rename MobilePOS element to ProductMovementReportLite, and ShipToPartners to ShipToPartner, OtherPartners to OtherPartner
 *
 * Revision 1.1.2.1  2008/01/31 16:21:54  maschec
 * Original version: Move code from GPOSLiteImpl_UT to here (this is where it really belongs)
 *
 */