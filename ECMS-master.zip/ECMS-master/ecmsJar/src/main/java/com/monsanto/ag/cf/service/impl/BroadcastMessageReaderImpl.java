package com.monsanto.ag.cf.service.impl;

import com.monsanto.ag.cf.service.BroadcastMessageReader;
import com.monsanto.ag.cf.dao.BroadcastMessageDAO;
import com.monsanto.Util.StringUtils;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableInfo;

import java.util.List;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA.
 * User: svadlam
 * Date: May 18, 2010
 * Time: 3:17:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class BroadcastMessageReaderImpl implements BroadcastMessageReader {
    private static final String FARMSOURCE_APP_DESCR = "WS_BM";
    private BroadcastMessageDAO broadcastMessageDAO;

    public List getNewMessages(String userId, String seedYear) {
        return broadcastMessageDAO.getMessages(userId,seedYear,FARMSOURCE_APP_DESCR);
    }

    public void acknowledge(String userId, List receivedMessageIds) {
        for (Iterator itMessageId = receivedMessageIds.iterator(); itMessageId.hasNext();) {
            String popupId = (String) itMessageId.next();
            if(broadcastMessageDAO.checkPopupIdValidAndNotVisited(userId,popupId))    {
                Logger.log(new LoggableInfo("Acknowledge broadcast message ID '"+popupId+"' for user '"
                        + userId +"'"));
                broadcastMessageDAO.insertPopupVisited(userId,popupId);
            }
        }
    }

    public void setBroadcastMessageDAO(BroadcastMessageDAO broadcastMessageDAO) {
        this.broadcastMessageDAO = broadcastMessageDAO;
    }
}
