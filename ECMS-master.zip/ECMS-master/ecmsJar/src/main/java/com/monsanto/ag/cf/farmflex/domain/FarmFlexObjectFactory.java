/*
 Copyright:  Copyright � 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.farmflex.domain;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.commercial.growercreditlist.domain.GrowerCreditInfo;
import com.monsanto.commercial.growercreditlist.invoker.GetCreditInfoServiceInvoker;
import org.springframework.jdbc.object.MappingSqlQuery;

import java.util.List;
import java.util.Map;

public class FarmFlexObjectFactory {
    public MergeGrowerCreditInfoWithGrowerDetails createMergeGrowerCreditInfoWithGrowerDetails(
          List<?> customerList, Map<Long, GrowerCreditInfo> growerCreditInfoMap, IdMapperDao idMapperDao) {
        return new MergeGrowerCreditInfoWithGrowerDetails(customerList, growerCreditInfoMap, idMapperDao);
    }

    public GetCreditInfoServiceInvoker createGetCreditInfoServiceInvoker() {
        return new GetCreditInfoServiceInvoker();
    }

    public MappingSqlQuery createMappingSqlQueryForFarmFlexCreditControlAreaFilter() {
        return null;
    }
}
