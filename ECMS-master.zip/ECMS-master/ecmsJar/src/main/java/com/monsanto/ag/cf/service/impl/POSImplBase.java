/*
 * POSImplBase was created on Feb 18, 2008 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;
import javax.xml.rpc.soap.SOAPFaultException;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.domain.Conversation;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.server.SecureService;
import com.monsanto.ag.util.Utilities;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;

import com.monsanto.ag.security.IdentityPrincipal;


/**
 * POJO base implementation of the various POS services including GPOSLite service.
 * Most of the POS services do not transform the input request but simply pass
 * it on for execution by a WebMethods service. GPOSLite does transform the
 * request. This base class internally calls an abstract method 
 * {@link #transformRequestAsNeeded(XmlDocument)}
 * which subclasses should implement to either transform the request (GPOSLiteImpl)
 * or return the request unchanged (POSImpl).
 * 
 * @author Gareth Davies
 * @version $Id: POSImplBase.java,v 1.3 2008-08-06 22:49:40 mkuchip Exp $
 */
public abstract class POSImplBase extends JmsSupport implements SecureService {
  
  private String id;
  private String destinationName;
  private XmlMessageInformer inputXmlMessageInformer;
  private XmlMessageInformer outputXmlMessageInformer;

  /**
   * @see com.monsanto.ag.util.Identifiable#getId()
   */
  public String getId() {
    return id;
  }

  public boolean isValidationRequired() {
    return true;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#getXmlMessageInformer()
   */
  public XmlMessageInformer getXmlMessageInformer() {
    return null;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getInputXmlMessageInformer()
   */
  public XmlMessageInformer getInputXmlMessageInformer() {
    return inputXmlMessageInformer;
  }

  /**
   * @see com.monsanto.ag.soa.server.SecureService#getOutputXmlMessageInformer()
   */
  public XmlMessageInformer getOutputXmlMessageInformer() {
    return outputXmlMessageInformer;
  }
  
  /**
   * @see com.monsanto.ag.soa.server.SecureService#executeSecure(com.monsanto.ag.soa.ServiceInput,
   *      javax.security.auth.Subject)
   */
  public ServiceOutput executeSecure(ServiceInput input, Subject subject)
      throws ServiceException {
    ServiceOutput output = new ServiceOutput();

    String conversationId = Utilities.generateConversationId();
    output.setConversationId(conversationId);

    Logger.log(new LoggableInfo("Received " + id
        + " data and sending to message queue '" + destinationName
        + "' with Conversation Id: " + conversationId));
    XmlDocument requestDocument = validateInputDocument(input);

    //Transform request if needed before enqueuing call to WebMethods service
    XmlDocument posDocument = transformRequestAsNeeded(requestDocument);

    IdentityPrincipal idPrincipal = getValidIdentityPrincipalFromSubject(subject);
    Conversation conversation = new Conversation(idPrincipal.getName(),
        idPrincipal.getAccountId(), conversationId);

    enqueueInputDocument(destinationName, posDocument, conversation);

    XmlDocument outputDocument = buildAcknowledgementDocument(conversationId,
        subject);
    output.getXmlChunks().addChunk(outputDocument);

    return output;
  }

  /**
   * Subclasses must implement this method to transform the input request,
   * if necessary, prior to calling a WebMethods service with the request. If
   * no transformation is required, the subclass implementation should simply
   * return the original request.
   * 
   * @param requestDocument original request sent by external service client.
   * @return request, transformed as necessary, used to call WebMethods service.
   */
  protected abstract XmlDocument transformRequestAsNeeded(XmlDocument requestDocument)
    throws SOAPFaultException;

  private XmlDocument validateInputDocument(ServiceInput input) {
    XmlChunks inputXmlChunks = input.getXmlChunks();
    if (inputXmlChunks.getCount() == 0) {
      throw new ServiceException("No XML document was provided for the " + id
          + " service");
    } else {
      String xpathTransaction = inputXmlMessageInformer.getXpathTransaction();
      inputXmlChunks.setXpathRepeatingElement(xpathTransaction);
      return inputXmlChunks.getXmlDocument(xmlDocumentBuilder);
    }
  }

  /*
   * NON-JAVADOC:
   * The id property is an artifact carried over from POSLiteImpl.
   * It is set via Spring, e.g. the following lines in applicationContext.xml:
   *   <bean id="gposlite" class="com.monsanto.ag.cf.service.impl.GPOSLiteImpl">
   *       <property name="id"><value>GPOSLT</value></property>
   * The id is used in various logged messages.       
   */
  public void setId(String id) {
    this.id = id;
  }

  public void setDestinationName(String destinationName) {
    this.destinationName = destinationName;
  }

  public void setInputXmlMessageInformer(XmlMessageInformer inputXmlMessageInformer) {
    this.inputXmlMessageInformer = inputXmlMessageInformer;
  }

  public void setOutputXmlMessageInformer(XmlMessageInformer outputXmlMessageInformer) {
    this.outputXmlMessageInformer = outputXmlMessageInformer;
  }    

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2008/05/27 16:02:59  na1000app-ec
 * After excluding duplicate jave files added missing imports to the java file
 *
 * Revision 1.1  2008/02/18 17:09:58  maschec
 * Refactor GPOSLiteImpl to use (new) common base class POSImplBase; this also enables artificial interface POSService to be eliminated since POSImplBase can be used instead.
 *
 *
 */