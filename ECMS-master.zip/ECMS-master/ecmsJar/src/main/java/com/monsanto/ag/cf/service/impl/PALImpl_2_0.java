/*
 * PALImpl_2_0 was created on May 21, 2008 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import javax.security.auth.Subject;

import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.cf.service.SecureServiceBase;
import com.monsanto.ag.cf.service.SoaClientInvoker;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.security.SecurityUtil;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.util.ConversationIdUtil;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.xml.XmlChunks;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

public class PALImpl_2_0 extends SecureServiceBase implements Identifiable {

    private static final String CONVERSATION_ID_MESSAGE = "Processing PAL_2_0 request with Conversation Id: ";
    private XmlDocumentBuilder xmlDocumentBuilder;
    private IdMapperDao idMapperDao;

    public PALImpl_2_0(){}

    public PALImpl_2_0(SoaClientInvoker soaClientInvoker, XmlMessageInformer inputXmlMessageInformer, XmlMessageInformer outputXmlMessageInformer, XmlDocumentBuilder xmlDocumentBuilder, IdMapperDao idMapperDao) {
        super(soaClientInvoker, inputXmlMessageInformer, outputXmlMessageInformer);
        this.xmlDocumentBuilder = xmlDocumentBuilder;
        this.idMapperDao = idMapperDao;
    }

    protected ServiceInput processInput(ServiceInput input, Subject subject) {
        IdentityPrincipal idPrincipal = SecurityUtil.getIdentityPrincipal( subject );
        XmlChunks inputXmlChunks = input.getXmlChunks();
        String xpathTransaction = getInputXmlMessageInformer().getXpathTransaction();
        inputXmlChunks.setXpathRepeatingElement( xpathTransaction );
        PALHelper.updateInputDocumentWithBuyerAndShipToSAPId( inputXmlChunks.getXmlDocument( xmlDocumentBuilder ),
                                                              idPrincipal,
                                                              idMapperDao );
        return input;
    }

    protected ServiceOutput processOutput( ServiceInput serviceInput ) {
        String conversationId = getConversationId();
        ServiceOutput output = delegateRequestToPALService( serviceInput, conversationId );
        ConversationIdUtil.substituteDocumentIdentifier( output.getXmlChunks().getXmlDocument( xmlDocumentBuilder ), conversationId );
        return output;
    }

    protected String getConversationIdMessage(){
        return CONVERSATION_ID_MESSAGE;
    }

    private ServiceOutput delegateRequestToPALService( ServiceInput inputDocument, String conversationId ) {
        ServiceInput input = new ServiceInput( inputDocument.getXmlChunks().getXmlDocument( xmlDocumentBuilder ),
                                              "PriceAndAvailabilityRequest" );

        ServiceOutput output = getSoaClientInvoker().callSoaClient(input);

        XmlDocument outputDoc = output.getXmlChunks().getXmlDocumentChunk( xmlDocumentBuilder, 0 );
        XmlChunks outputXmlChunks = new XmlChunks();
        outputXmlChunks.addChunk(outputDoc);

        ServiceOutput serviceOutput = new ServiceOutput(outputXmlChunks);
        serviceOutput.setConversationId(conversationId);
        return serviceOutput;
    }

    public String getId() {
        return "PAL2";
    }
}