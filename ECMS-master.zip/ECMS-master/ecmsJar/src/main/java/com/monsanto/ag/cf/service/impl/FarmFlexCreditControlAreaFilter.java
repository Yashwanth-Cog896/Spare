/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.service.impl;

import com.monsanto.ag.cf.dao.CreditControlAreaDao;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Collection;

public class FarmFlexCreditControlAreaFilter implements CreditControlAreaFilter {
    private int creditControlAreaCode = 0;

    @Override
    public void setCreditControlAreaCode(int creditControlAreaCode) {
        this.creditControlAreaCode = creditControlAreaCode;
    }

    @Override
    public String filter(CreditControlAreaDao creditControlAreaDao, String growerIds, MappingSqlQuery mappingSqlQuery) {
        Collection growerIdsInCreditControlArea = creditControlAreaDao
              .getGrowerIdsInCreditControlArea(mappingSqlQuery, creditControlAreaCode);
        if (growerIdsInCreditControlArea == null || growerIdsInCreditControlArea.isEmpty()) {
            return null;
        }
        return growerIdsInCreditControlAreaAsString(growerIdsInCreditControlArea, growerIds);
    }

    private String growerIdsInCreditControlAreaAsString(Collection ids, String growerIds) {
        Collection<String> filtered = new ArrayList<String>();
        for (String growerId : growerIds.split(",")) {
            if (ids.contains(growerId)) {
                filtered.add(growerId);
            }
        }
        return StringUtils.collectionToDelimitedString(filtered, ",");
    }
}
