/*
 * PALHelper was created on Jun 3, 2008 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.service.impl;

import org.springframework.dao.IncorrectResultSizeDataAccessException;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.dao.IdMapperDao;
import com.monsanto.ag.security.IdentityPrincipal;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlElement;

public class PALHelper {

  private static final String PARTNER_INFO = "/cidx:PartnerInformation/cidx:PartnerIdentifier[@"
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='";
  private static final String XPATH_PARTNER = "/ecms:PriceAndAvailabilityRequest/ecms:PriceAndAvailabilityRequestBody/ecms:PriceAndAvailabilityRequestPartners";

  private static final String XPATH_SHIPTO_AGENCY_ACCOUNT_ID = XPATH_PARTNER
      + "/cidx:ShipTo" + PARTNER_INFO + CidxConstants.ACCOUNT_ID_AGENCY + "']";
  private static final String XPATH_SHIPTO_AGENCY_EBID = XPATH_PARTNER
      + "/cidx:ShipTo" + PARTNER_INFO + CidxConstants.EBID_AGENCY + "']";
  private static final String XPATH_SHIPTO_AGENCY_SAPID = XPATH_PARTNER
      + "/cidx:ShipTo" + PARTNER_INFO + CidxConstants.SAP_ID_AGENCY + "']";
  private static final String XPATH_BUYER_ID_AGENCY_ACCOUNT_ID = XPATH_PARTNER
      + "/cidx:Buyer" + PARTNER_INFO + CidxConstants.ACCOUNT_ID_AGENCY + "']";
  private static final String XPATH_BUYER_ID_AGENCY_EBID = XPATH_PARTNER
      + "/cidx:Buyer" + PARTNER_INFO + CidxConstants.EBID_AGENCY + "']";
  private static final String XPATH_BUYER_ID_AGENCY_SAPID = XPATH_PARTNER
      + "/cidx:Buyer" + PARTNER_INFO + CidxConstants.SAP_ID_AGENCY + "']";

  public static XmlDocument updateInputDocumentWithBuyerAndShipToSAPId(
      XmlDocument inputDocument, IdentityPrincipal idPrincipal,
      IdMapperDao idMapperDao) {
    String buyerAccountId, buyerEBID, buyerSAPId, shipToAccountId, shipToEBID, shipToSAPId;
    XmlElement buyerPartnerIdEBIDNode = inputDocument
        .selectElementByXPath(XPATH_BUYER_ID_AGENCY_EBID);
    XmlElement buyerPartnerIdAccountIdNode = inputDocument
        .selectElementByXPath(XPATH_BUYER_ID_AGENCY_ACCOUNT_ID);
    XmlElement shipToPartnerIdEBIDNode = inputDocument
        .selectElementByXPath(XPATH_SHIPTO_AGENCY_EBID);
    XmlElement shipToPartnerIdAccountIdNode = inputDocument
        .selectElementByXPath(XPATH_SHIPTO_AGENCY_ACCOUNT_ID);
    XmlElement buyerPartnerIdSAPIdNode = inputDocument
        .selectElementByXPath(XPATH_BUYER_ID_AGENCY_SAPID);
    XmlElement shipToPartnerIdSAPIdNode = inputDocument
        .selectElementByXPath(XPATH_SHIPTO_AGENCY_SAPID);

    try {
      if (XmlElement.NULL.equals(buyerPartnerIdSAPIdNode)) {
        if (!(XmlElement.NULL.equals(buyerPartnerIdEBIDNode))) {
          buyerEBID = buyerPartnerIdEBIDNode.getText();
          buyerSAPId = idMapperDao.findSAPIdByAccountId(idMapperDao
              .findAccountIdByEBID(buyerEBID));
          Logger
              .log(new DebugLogEvent(
                  "Updating the PriceAndAvailabilityRequest document with Buyer SAP Id"));
          buyerPartnerIdEBIDNode.setText(buyerSAPId);
          buyerPartnerIdEBIDNode.setAttribute(
              CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
              CidxConstants.SAP_ID_AGENCY);
        } else if (!(XmlElement.NULL.equals(buyerPartnerIdAccountIdNode))) {
          buyerAccountId = buyerPartnerIdAccountIdNode.getText();
          buyerSAPId = idMapperDao.findSAPIdByAccountId(Long
              .parseLong(buyerAccountId.trim()));
          Logger
              .log(new DebugLogEvent(
                  "Updating the PriceAndAvailabilityRequest document with Buyer SAP Id"));
          buyerPartnerIdAccountIdNode.setText(buyerSAPId);
          buyerPartnerIdAccountIdNode.setAttribute(
              CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
              CidxConstants.SAP_ID_AGENCY);
        } else {
          throw new ServiceException(
              "Cannot process PAL, could not find SAPId for this Buyer");
        }
      }
      if (XmlElement.NULL.equals(shipToPartnerIdSAPIdNode)) {
        if (!(XmlElement.NULL.equals(shipToPartnerIdEBIDNode))) {
          shipToEBID = shipToPartnerIdEBIDNode.getText();
          shipToSAPId = idMapperDao.findSAPIdByAccountId(idMapperDao
              .findAccountIdByEBID(shipToEBID));
          Logger
              .log(new DebugLogEvent(
                  "Updating the PriceAndAvailabilityRequest document with ShipTo SAP Id"));
          shipToPartnerIdEBIDNode.setText(shipToSAPId);
          shipToPartnerIdEBIDNode.setAttribute(
              CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
              CidxConstants.SAP_ID_AGENCY);
        } else if (!(XmlElement.NULL.equals(shipToPartnerIdAccountIdNode))) {
          shipToAccountId = shipToPartnerIdAccountIdNode.getText();
          shipToSAPId = idMapperDao.findSAPIdByAccountId(Long
              .parseLong(shipToAccountId.trim()));
          Logger
              .log(new DebugLogEvent(
                  "Updating the PriceAndAvailabilityRequest document with ShipTo SAP Id"));
          shipToPartnerIdAccountIdNode.setText(shipToSAPId);
          shipToPartnerIdAccountIdNode.setAttribute(
              CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE,
              CidxConstants.SAP_ID_AGENCY);
        } else {
          throw new ServiceException(
              "Cannot process PAL, could not find SAPId for this ShipTo");
        }
      }
    } catch (IncorrectResultSizeDataAccessException e) {
      throw new ServiceException(
          "Cannot process PAL, could not find SAPId for this Account");
    }
    return inputDocument;
  }

}

/*
 * $Log: not supported by cvs2svn $
 */