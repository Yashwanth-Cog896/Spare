/*
 * Measurement was created on Jun 21, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.domain;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.monsanto.ag.xml.XmlElement;

/**
 * Represents an amount of something related to a commercial seed or chemical
 * product.
 * <p>
 * The information is currently only available in XML format (via the
 * {@link #appendXmlToElement(XmlElement) appendXmlToElement} method.
 * This XML conforms to the MeasurementType element of the
 * AGIISNamespacedSchema.xsd XML schema document.
 * 
 * @author Gareth Davies
 * @version $Id: Measurement.java,v 1.1 2008-07-18 21:28:18 gjkell Exp $
 */
public class Measurement extends AgiisEntity {

  private Float quantity;
  private String uomCode;

  public Measurement(Float quantity, String uomCode) {
    setQuantity(quantity);
    setUomCode(uomCode);
  }

  /**
   * @see java.lang.Object#clone()
   */
  public Object clone() throws CloneNotSupportedException {
    Measurement clone = new Measurement(quantity, uomCode);
    return clone;
  }

  private void setQuantity(Float quantity) {
    if (quantity == null) {
      this.quantity = new Float(0);
    } else {
      this.quantity = quantity;
    }
  }

  private void setUomCode(String uomCode) {
    if (StringUtils.isNotBlank(uomCode)) {
      this.uomCode = uomCode;
    } else {
      throw new IllegalArgumentException("Unit of Measure is required");
    }
  }

  /**
   * @see com.monsanto.ag.ecg.domain.AgiisEntity#appendXmlToElement(com.monsanto.ag.util.XmlElement)
   */
  public void appendXmlToElement(XmlElement baseXmlElement) {
    XmlElement rootElement = baseXmlElement.addChildElement("Measurement");
    addFirstLevelChildElements(rootElement);
  }

  private void addFirstLevelChildElements(XmlElement baseElement) {
    baseElement.addChildElement("MeasurementValue", quantity.toString());
    addUnitOfMeasureElement(baseElement, "UnitOfMeasureCode", uomCode,
        UOM_DOMAIN_UN_REC_20);
  }

  public boolean equals(Object obj) {
    if (!(obj instanceof Measurement)) {
      return false;
    }
    Measurement rhs = (Measurement) obj;
    return new EqualsBuilder().append(quantity, rhs.quantity).append(uomCode,
        rhs.uomCode).isEquals();
  }

  public int hashCode() {
    return new HashCodeBuilder(17, 9).append(quantity).append(uomCode)
        .hashCode();
  }

  public String toString() {
    return new ReflectionToStringBuilder(this).toString();
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.11  2005/12/01 19:55:37  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.10  2005/08/19 15:14:34  ggdavi
 * Modified to support different types of products
 *
 * Revision 1.9  2005/07/21 22:23:39  ggdavi
 * Added com.monsanto.ag.util.IdTranslator object to translate numeric Ids (such as Account, EBusiness and SAP Ids) back and forth between their numeric and zero-padded textual representations; enhanced and refactored XML abstraction in com.monsanto.ag.util
 *
 * Revision 1.8  2005/07/05 19:35:14  ggdavi
 * Now extends AgiisEntity instead of implementing ExtractXML, which enforces use of XmlDocumentBuilder implementations to generate the XML, as well as providing clone and dispose methods
 * Revision 1.7 2005/06/30 21:28:34 ggdavi Null
 * quantities become zero quantities
 * 
 * Revision 1.6 2005/06/30 20:18:29 ggdavi No XML is returned if the quantity is
 * null
 * 
 * Revision 1.5 2005/06/30 16:44:04 ggdavi Modified insertXml so that it simply
 * adds elements to the baseElement parameter, rather than importing the
 * Document node from the toXML method Revision 1.4 2005/06/28 20:46:41 ggdavi
 * All units of measure are required
 * 
 * Revision 1.3 2005/06/27 22:02:11 ggdavi Tweaks in an effort to hit the moving
 * anaysis target... Revision 1.2 2005/06/22 21:53:59 ggdavi Moved
 * AgiisDocumentHelper from ag.ecg.domain to ag.util Revision 1.1 2005/06/22
 * 17:22:09 ggdavi Initial version
 *  
 */