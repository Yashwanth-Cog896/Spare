package com.monsanto.ag.cf.dao;

/**
 * Created by IntelliJ IDEA.
 * User: PPVASI
 * Date: Jul 12, 2011
 * Time: 9:37:31 AM
 */
public class ProductQuery {

    private String query;

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }
}
