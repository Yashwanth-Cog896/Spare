/*
 * JdbcDealerPreferencesDao was created on Oct 3, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.jdbc;

import com.monsanto.ag.cf.dao.DealerPreferencesDao;

/**
 * Jdbc implementation of the DealerPreferencesDao.
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcDealerPreferencesDao.java,v 1.10 2008-06-03 15:56:11 rwspeh Exp $
 */
public class JdbcDealerPreferencesDao extends BaseJdbcDao implements DealerPreferencesDao {

  public void storeVersion(long accountId, String version, String sourceName) {
	    String sql = "UPDATE USER_XREF SET SOFTWARE_VERSION_ID = ?, SOURCE_NAME = ?, LAST_EXCHANGE_DATE = sysdate WHERE ACCT_ID=? AND DEVICE_ACTIVE_FLAG='Y' AND DEVICE_ID in (SELECT DEVICE_ID FROM DEVICE WHERE DEVICE_TYPE = 'HH')";
	    Object[] values = new Object[] {version, sourceName, new Long(accountId) };
	    getJdbcTemplate().update(sql, values);
	  }
  public String getLatestVersion(String appName) {
	  String sql = "SELECT SOFTWARE_VERSION_ID FROM SOFTWARE_VERSION WHERE UPPER(SOURCE_NAME)=? ORDER BY DATE_DEPLOYED DESC";
	  Object[] values = new Object[] { appName.toUpperCase() };
	  getJdbcTemplate().setMaxRows(1);
	  String version = (String) getJdbcTemplate().queryForObject(sql, values, String.class);
	  return version;
  }

  public String getSeedTrakVersionAvailableForDownload() {
	  String sql = "SELECT SOFTWARE_VERSION_ID FROM SOFTWARE_VERSION WHERE UPPER(SOURCE_NAME)='SEEDTRAK' ORDER BY DATE_DEPLOYED DESC";
	  getJdbcTemplate().setMaxRows(1);
	  String version = (String) getJdbcTemplate().queryForObject(sql,String.class);
	  return version;
  }
  
  
  
  
  public String getEnabledFlag(long acctId) {
    String sql = "SELECT HAND_HELD_FLAG FROM SEEDTRAK_USER WHERE ACCT_ID=?";
    Object[] values = new Object[] { new Long(acctId) };
    String flag = (String) getJdbcTemplate().queryForObject(sql, values, String.class);
    return flag;
  }

}
