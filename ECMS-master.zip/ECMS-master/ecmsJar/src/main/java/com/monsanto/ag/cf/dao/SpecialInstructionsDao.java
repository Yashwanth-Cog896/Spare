/*
 * SpecialInstructionsDao was created on May 12, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao;

import java.util.Set;

/**
 * Data Access Object for special instructions for data exchanges.
 * 
 * @author Gareth Davies
 * @version $Id: SpecialInstructionsDao.java,v 1.2 2005/05/13 14:00:37 ggdavi
 *          Exp $
 * @see SeedTrakInsourcingScope FC56
 */
public interface SpecialInstructionsDao {

  public Set findInstructionsByDealer(long accountId);

  public Set findInstructionsByDealerService(long accountId, String serviceId);

  public void removeInstructions(long accountId, String serviceId);

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.3 2005/07/14 21:34:54 ggdavi
 * Added findInstructionsByDealerService method Revision 1.2 2005/05/13 14:00:37
 * ggdavi Added traceability to javadoc
 * 
 * Revision 1.1 2005/05/12 21:25:55 ggdavi Initial version
 * 
 */