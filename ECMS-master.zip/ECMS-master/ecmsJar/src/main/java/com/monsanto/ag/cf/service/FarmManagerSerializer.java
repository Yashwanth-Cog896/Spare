package com.monsanto.ag.cf.service;

import java.util.List;

import com.monsanto.ag.xml.XmlStream;
import com.monsanto.ag.security.IdentityPrincipal;

public interface FarmManagerSerializer {

  XmlStream buildFarmManagerListDocument(String conversationId, IdentityPrincipal idPrincipal, List domainItems);

}
