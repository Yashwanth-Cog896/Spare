/*
 * PackageMatcherPointcut was created on Apr 6, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.aop;

import java.lang.reflect.Method;

import org.apache.commons.lang.StringUtils;
import org.springframework.aop.support.StaticMethodMatcherPointcut;

/**
 * Defines an AOP pointcut for classes in a specific package hierarchy.
 * 
 * @author Gareth Davies
 * @version $Id: PackageMatcherPointcut.java,v 1.4 2005-06-30 17:43:25 ggdavi Exp $
 */
public class PackageMatcherPointcut extends StaticMethodMatcherPointcut {

  private String mappedName;

  /**
   * Returns true if the targetClass is in the package corresponding to the
   * mapped name (or one of its children), regardless of the method.
   * 
   * @see org.springframework.aop.MethodMatcher#matches(java.lang.reflect.Method,
   *      java.lang.Class)
   */
  public boolean matches(Method method, Class targetClass) {
    if (StringUtils.isNotBlank(mappedName) && targetClass != null) {
      String targetPackageName = targetClass.getPackage().getName();
      return targetPackageName.startsWith(mappedName);
    } else {
      return false;
    }
  }

  public void setMappedName(String mappedName) {
    this.mappedName = mappedName;
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.2  2005/05/03 20:21:01  ggdavi
 * Changed to match classes in child packages of the mappedName
 *
 * Revision 1.1  2005/04/07 15:43:39  ggdavi
 * Initial version
 *
 */