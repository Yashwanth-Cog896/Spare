/*
 * ChangeLogImpl was created on Jun 10, 2008 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.service.impl;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.cf.service.SecureServiceBase;
import com.monsanto.ag.cf.service.SoaClientInvoker;
import com.monsanto.ag.soa.ServiceException;
import com.monsanto.ag.soa.ServiceInput;
import com.monsanto.ag.soa.ServiceOutput;
import com.monsanto.ag.soa.XmlMessageInformer;
import com.monsanto.ag.soa.client.SoaClient;
import com.monsanto.ag.util.ConversationIdUtil;
import com.monsanto.ag.util.Identifiable;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlStreamBuilder;

import javax.security.auth.Subject;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

/**
 * Service Implementation of the ChangeLog web service.
 *
 * @author mkuchip
 * @version ChangeLogImpl.java, Jun 10, 2008
 */
public class ChangeLogImpl extends SecureServiceBase implements Identifiable {

    private static final String KEY_CONVERSATION_ID = "ConversationID";
    private static final String CHUNK_SIZE = "ChunkSize";
    public static final String CONVERSATION_ID_MESSAGE = "Processing ChangeLog request with Conversation Id: ";

    private XmlDocumentBuilder xmlDocumentBuilder;

    public ChangeLogImpl(){}

    public ChangeLogImpl( SoaClientInvoker soaClientInvoker, XmlMessageInformer inputXmlMessageInformer, XmlMessageInformer outputXmlMessageInformer, XmlDocumentBuilder xmlDocumentBuilder) {
        super( soaClientInvoker, inputXmlMessageInformer, outputXmlMessageInformer);
        this.xmlDocumentBuilder = xmlDocumentBuilder;
    }

    public String getId() {
        return "CHLOG";
    }

    public String getConversationIdMessage(){
        return CONVERSATION_ID_MESSAGE;
    }

    protected ServiceInput processInput( ServiceInput inputDocument, Subject subject ){
        XmlMessageInformer outputXmlMessageInformer =  getOutputXmlMessageInformer();
        ServiceInput input = buildServiceInput(inputDocument);

        if (outputXmlMessageInformer.getChunkSize() > 0) {
            input.addParameter(CHUNK_SIZE, Integer.toString(outputXmlMessageInformer.getChunkSize()));
            input.setOutputXmlChunkParentXpath(XmlStreamBuilder.CHUNK_WRAPPER_ELEMENT_NAME);
        }

        return input;
    }

    private ServiceInput buildServiceInput(ServiceInput inputDocument ) {

        XmlDocument document = inputDocument.getXmlChunks().getXmlDocument( xmlDocumentBuilder );
        String rootNodeName = document.getRootElement().getUnqualifiedName();
        ServiceInput input = new ServiceInput(document, rootNodeName);
        input.addParameter(KEY_CONVERSATION_ID, getConversationId() );

        return input;
    }

    protected ServiceOutput processOutput( ServiceInput input ) {
        String conversationId = input.getParameter( KEY_CONVERSATION_ID );
        ServiceOutput output = null;

        try {
            output = delegateRequestToCHLOGService( input );
        } catch ( ServiceException e ) {
            output = handleServiceException(conversationId, output, e);
        }

        ConversationIdUtil.substituteDocumentIdentifier(output.getXmlChunks().getXmlDocument(xmlDocumentBuilder), conversationId);
        return output;
    }

    private ServiceOutput delegateRequestToCHLOGService( ServiceInput inputDocument ) {

        ServiceOutput output = getSoaClientInvoker().callSoaClient(inputDocument);
        output.setConversationId( inputDocument.getParameter( KEY_CONVERSATION_ID ) );
        return output;
    }

    private ServiceOutput handleServiceException(String conversationId, ServiceOutput output, ServiceException e) {
        try {
            output = senseAndReturnNoDataFoundResponse(e, conversationId);
        } catch (FileNotFoundException e1) {
            Logger.log(new LoggableError("Can't find resource file 'NoDataFoundChangeLogResponse.xml'"));
            e1.printStackTrace();
        }
        return output;
    }

    private ServiceOutput senseAndReturnNoDataFoundResponse( ServiceException e, String conversationId ) throws FileNotFoundException {
        ServiceOutput output;
        if ( !e.getMessage().toLowerCase().contains("no data found") ) {
            throw e;
        }

        XmlDocument xmlDocumentIn = xmlDocumentBuilder.createXmlDocument( new InputStreamReader( getClass().getResourceAsStream( "NoDataFoundChangeLogResponse.xml" ) ) );
        output = new ServiceOutput();
        output.getXmlChunks().addChunk( xmlDocumentIn );
        output.setConversationId( conversationId );

        return output;
    }
}