/*
 * BrokerPolicyAwareEndpointWorker was created on Oct 28, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */

package com.monsanto.ag.cf.message.broker;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.resource.ResourceException;
import javax.resource.spi.endpoint.MessageEndpoint;
import javax.resource.spi.work.Work;
import javax.resource.spi.work.WorkEvent;
import javax.resource.spi.work.WorkException;
import javax.resource.spi.work.WorkListener;
import javax.resource.spi.work.WorkManager;
import javax.transaction.xa.XAResource;

import org.activemq.ActiveMQConnectionConsumer;
import org.activemq.ActiveMQSession;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ActiveMQQueue;
import org.activemq.ra.ActiveMQActivationSpec;
import org.activemq.ra.ActiveMQBaseEndpointWorker;
import org.activemq.ra.ActiveMQEndpointActivationKey;
import org.activemq.ra.CircularQueue;
import org.activemq.ra.InboundEndpointWork;
import org.activemq.ra.LocalAndXATransaction;
import org.activemq.service.DeadLetterPolicy;
import org.activemq.service.RedeliveryPolicy;

import EDU.oswego.cs.dl.util.concurrent.Latch;
import EDU.oswego.cs.dl.util.concurrent.SynchronizedBoolean;

import com.monsanto.AbstractLogging.DebugLogEvent;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;

/**
 * ActiveMQ EndpointWorker that uses the broker's Redelivery and Dead Letter
 * policies to control redelivery of messages.
 * <p>
 * This class is based on org.activemq.ra.ActiveMQPollingEndpointWorker, with
 * unused pieces (such as Topic and XA stuff) removed and RedeliveryPolicy- and
 * DeadLetterPolicy-related stuff added. It would have been nicer to extend that
 * class instead, but so many of its private instance fields are needed that we
 * ended up essentially duplicating its start() and stop() methods..
 * 
 * @author Gareth Davies
 * @version $Id: BrokerPolicyAwareEndpointWorker.java,v 1.1 2005/10/28 21:03:21
 *          ggdavi Exp $
 */
public class BrokerPolicyAwareEndpointWorker extends ActiveMQBaseEndpointWorker
    implements Work {

  private static final int TIMEOUT_DURATION = 500;

  private static final int MAX_WORKERS = 10;

  private static WorkListener DEBUG_WORK_LISTENER = new WorkListener() {
    public void workAccepted(WorkEvent event) {
      Logger.log(new DebugLogEvent("Work accepted: " + event));
    }

    public void workRejected(WorkEvent event) {
      Logger.log(new LoggableWarning("Work rejected: " + event));
    }

    public void workStarted(WorkEvent event) {
      Logger.log(new DebugLogEvent("Work started: " + event));
    }

    public void workCompleted(WorkEvent event) {
      Logger.log(new DebugLogEvent("Work completed: " + event));
    }
  };

  private SynchronizedBoolean started = new SynchronizedBoolean(false);
  private SynchronizedBoolean stopping = new SynchronizedBoolean(false);
  private Latch stopLatch = new Latch();

  private ActiveMQConnectionConsumer consumer;
  private CircularQueue workers;
  private Connection connection;
  // The following fields are specific to this subclass
  private MessageDeliveryManager redeliveryManager;
  private String queueName;

  public BrokerPolicyAwareEndpointWorker(ApplicationResourceAdapter adapter,
      ActiveMQEndpointActivationKey key, RedeliveryPolicy redeliveryPolicy,
      DeadLetterPolicy deadLetterPolicy) throws ResourceException {
    super(adapter, key);
    redeliveryManager = new MessageDeliveryManager(deadLetterPolicy,
        redeliveryPolicy);
  }

  /**
   * This is a streamlined version of ActiveMQPollingEndpointWorker.start()
   * 
   * @see org.activemq.ra.ActiveMQBaseEndpointWorker#start()
   */
  public void start() throws WorkException, ResourceException {
    ActiveMQActivationSpec activationSpec = endpointActivationKey
        .getActivationSpec();
    queueName = activationSpec.getDestination();
    Logger.log(new DebugLogEvent(
        "Starting BrokerPolicyAwareEndpointWorker for "
            + activationSpec.getDestination()));
    boolean startedProperly = false;

    try {
      connection = adapter.makeConnection(activationSpec);
      connection.start();

      workers = new CircularQueue(MAX_WORKERS, stopping);
      for (int i = 0; i < workers.size(); i++) {
        int acknowledge = (transacted) ? Session.SESSION_TRANSACTED
            : activationSpec.getAcknowledgeModeForSession();
        ActiveMQSession session = (ActiveMQSession) connection.createSession(
            transacted, acknowledge);
        
        XAResource xaResource = new LocalAndXATransaction(session
            .getTransactionContext());
        MessageEndpoint endpoint = endpointFactory.createEndpoint(xaResource);
        
        InboundEndpointWork work = new InboundEndpointWork(session, endpoint,
            workers);
        workers.returnObject(work);
      }

      Destination dest = new ActiveMQQueue(queueName);
      consumer = (ActiveMQConnectionConsumer) connection
          .createConnectionConsumer(dest, null, null, 0);

      Logger.log(new DebugLogEvent("BrokerPolicyAwareEndpointWorker for "
          + activationSpec.getDestination() + " started properly"));
      workManager.scheduleWork(this, WorkManager.INDEFINITE, null,
          DEBUG_WORK_LISTENER);
      startedProperly = true;
    } catch (JMSException e) {
      throw new ResourceException("Could not start the endpoint.", e);
    } finally {
      // We don't want to leak sessions on errors. Keep them around only if
      // there were no errors.
      if (!startedProperly) {
        safeClose(consumer);
        safeClose(connection);
      }
    }
  }

  /**
   * This is essentially a copy of ActiveMQPollingEndpointWorker.stop()
   * 
   * @see org.activemq.ra.ActiveMQBaseEndpointWorker#stop()
   */
  public void stop() throws InterruptedException {
    Logger.log(new DebugLogEvent(
        "Stopping BrokerPolicyAwareEndpointWorker for " + queueName));

    stopping.set(true);
    workers.notifyWaiting();
    if (started.get()) {
      stopLatch.acquire();
    }
    safeClose(consumer);
    safeClose(connection);

    Logger.log(new DebugLogEvent("BrokerPolicyAwareEndpointWorker for "
        + queueName + " has stopped"));
  }

  /**
   * @see javax.resource.spi.work.Work#release()
   */
  public void release() {
  }

  /**
   * This is a copy of ActiveMQPollingEndpointWorker.run with the addition of
   * redelivery processing within the message processing loop, according to the
   * broker policies.
   * 
   * @see java.lang.Runnable#run()
   */
  public void run() {
    started.set(true);

    try {
      while (!stopping.get()) {
        ActiveMQMessage message = consumer.receive(TIMEOUT_DURATION);
        if (message != null) {
          InboundEndpointWork worker = (InboundEndpointWork) workers.get();
          // Did we get stopped?
          if (worker == null) {
            break;
          }

          // Check for redelivery (code added to ActiveMQPollingEndpointWorker
          // version)
          boolean deliverable = redeliveryManager.checkMessageDeliverable(
              message, queueName, stopping);
          if (deliverable) {
            worker.setMessage(message);
            workManager.scheduleWork(worker, WorkManager.INDEFINITE, null,
                DEBUG_WORK_LISTENER);
          }
        }
      }

      // Try to collect the workers so that none are running.
      workers.drain();
    } catch (Throwable e) {
      Logger.log(new LoggableWarning("BrokerPolicyAwareEndpointWorker error: "
          + e.toString()));
    } finally {
      stopLatch.release();
    }
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.5 2005/11/01
 * 22:09:09 ggdavi In the run method, the MessageEndpoint created by the
 * endpointFactory.createEndpoint method is now a LocalTransactionEndpoint (to
 * enable local JMS transactions) - this is achieved by passing in a
 * LocalAndXATransaction object which wraps the JMS session's transaction
 * context. Revision 1.4 2005/11/01 15:54:22 ggdavi Minor refactorings and
 * additional Javadoc comments Revision 1.3 2005/10/31 22:23:23 ggdavi Added
 * test for DeadLetterPolicy processing Revision 1.2 2005/10/31 15:42:43 ggdavi
 * Refactored run method for improved clarity Revision 1.1 2005/10/28 21:03:21
 * ggdavi Initial version
 * 
 */