/*
 * AgreementStatusSerializer was created on Apr 18, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.service;

import java.util.List;

import com.monsanto.ag.xml.XmlStream;

import com.monsanto.ag.security.IdentityPrincipal;


public interface AgreementStatusSerializer {
  
  XmlStream buildAgreementStatusDocument(String conversationId, IdentityPrincipal idPrincipal, List domainItems);

}
