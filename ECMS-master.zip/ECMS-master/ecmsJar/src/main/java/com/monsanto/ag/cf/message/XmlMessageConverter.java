/*
 * XmlMessageConverter was created on May 2, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.message;

import java.io.StringReader;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.lang.StringUtils;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;

/**
 * An implementation of Spring's JMS MessageConverter interface that converts
 * XML Documents to JMS TextMessages and vice versa. Usually used by Spring's
 * JmsTemplate class, for <code>convertAndSend</code> and
 * <code>receiveAndConvert</code> operations.
 * <p>
 * This converter implementation works for both JMS 1.1 and JMS 1.0.2.
 * 
 * @author Gareth Davies
 * @version $Id: XmlMessageConverter.java,v 1.6 2005-12-01 19:34:31 ggdavi Exp $
 */
public class XmlMessageConverter implements MessageConverter {

  private XmlDocumentBuilder xmlDocumentBuilder;

  /**
   * @see org.springframework.jms.support.converter.MessageConverter#toMessage(java.lang.Object,
   *      javax.jms.Session)
   */
  public Message toMessage(Object object, Session session) throws JMSException,
      MessageConversionException {
    if (object == null) {
      return session.createTextMessage(StringUtils.EMPTY);
    } else if (object instanceof XmlDocument) {
      XmlDocument xmlDocument = (XmlDocument) object;
      return session.createTextMessage(xmlDocument.toString());
    } else {
      throw new MessageConversionException("Cannot convert object [" + object
          + "] to JMS message");
    }
  }

  /**
   * @see org.springframework.jms.support.converter.MessageConverter#fromMessage(javax.jms.Message)
   */
  public Object fromMessage(Message message) throws JMSException,
      MessageConversionException {
    try {
      String messageText = ((TextMessage) message).getText();
      if (StringUtils.isEmpty(messageText)) {
        return XmlDocument.NULL;
      } else {
        return xmlDocumentBuilder.createXmlDocument(new StringReader(
            messageText));
      }
    } catch (Exception e) {
      Logger.log(new LoggableWarning(e));
      throw new MessageConversionException("Cannot convert JMS message ["
          + message + "] to XML Document");
    }
  }

  public void setXmlDocumentBuilder(XmlDocumentBuilder xmlDocumentBuilder) {
    this.xmlDocumentBuilder = xmlDocumentBuilder;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.5  2005/08/02 20:57:38  ggdavi
 * Modified service interfaces, implementations and advice to support message/document chunking
 * Revision 1.4 2005/07/08 17:30:16 ggdavi
 * Null message bodies are replaced and treated as empty Strings
 * 
 * Revision 1.3 2005/06/30 17:43:26 ggdavi Moved ag.aop, ag.config and
 * ag.message packages under the ag.cf package
 * 
 * Revision 1.4 2005/05/17 20:25:03 ggdavi Converted XmlMessageInformer from an
 * interface with accessors only to a fully-fledged bean class
 * 
 * Revision 1.3 2005/05/11 19:21:43 ggdavi fromMessage logs a warning not an
 * error
 * 
 * Revision 1.2 2005/05/06 17:44:32 ggdavi Replaced use of
 * DOMUtil.newDocument(InputStream) with DOMUtil.newDocumentNS(Reader)
 * 
 * Revision 1.1 2005/05/05 19:01:12 ggdavi Initial version
 * 
 * Revision 1.1 2005/05/03 18:14:53 ggdavi Initial version
 * 
 */