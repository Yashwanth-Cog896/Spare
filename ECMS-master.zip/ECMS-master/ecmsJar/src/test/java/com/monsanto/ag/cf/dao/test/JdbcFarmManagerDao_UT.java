/*
 * JdbcFarmManagerListDao_UT was created on May 26, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import java.util.ArrayList;
import java.util.List;

import com.monsanto.ag.cf.dao.jdbc.JdbcFarmManagerDao;
import com.monsanto.ag.cf.domain.FarmManager;

/**
 * Test retrieving of FarmManager using the JdbcFarmManagerListDao
 * 
 * @author caggarw
 * @version $Id: JdbcFarmManagerDao_UT.java,v 1.3 2005-09-28 19:12:55 ggdavi Exp $
 */
public class JdbcFarmManagerDao_UT extends BaseDbUnitTestCase {
  
  public void testGetFarmManagers() {
    JdbcFarmManagerDao jdbcFarmManagerDao = new JdbcFarmManagerDao();
    jdbcFarmManagerDao.setDataSource(getDataSource());

    FarmManager farmManager1 = new FarmManager("Magna farms", 333, 555,
        "Pine Street", "Rolla", "MO", "45566", "FN", true);
    FarmManager farmManager2 = new FarmManager("Zenith", 12, 89, "15th Street",
        "Dallas", "TX", "33336", "FP", true);
    FarmManager farmManager3 = new FarmManager("Big Brother", 586, 242,
        "Main Street", "New York", "NY", "01234", "NA", false);
    
    List expectedFarmManagerList = new ArrayList();
    expectedFarmManagerList.add(farmManager3);
    expectedFarmManagerList.add(farmManager1);
    expectedFarmManagerList.add(farmManager2);

    List actualFarmManagerList = jdbcFarmManagerDao.getFarmManagers();
    assertEquals(expectedFarmManagerList, actualFarmManagerList);
  }
  
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/06/01 15:58:39  ajbaldw
 * made a change to the roles
 *
 * Revision 1.1  2005/05/26 20:29:29  caggarw
 * Unit test for JdbcFarmManagerDao
 *
 */