package com.monsanto.ag.cf.dao.test;


import com.monsanto.ag.cf.dao.jdbc.JdbcInventoryReportingDao;
import com.monsanto.ag.cf.domain.AppConstants;
import com.monsanto.ag.cf.domain.InventoryDetails;
import com.monsanto.ag.util.test.Log4JTestConfigurationHelper;
import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;

import java.sql.PreparedStatement;
import java.util.*;

public class JdbcInventoryReportingDao_UT extends BaseDbUnitTestCase {
    @Override
    protected void setUp() throws Exception {
        Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty();

        dbUnitHelper = DbUnitHelperFactory.createDbUnitHelperUSMGEND("ECG_LD");
        PreparedStatement stmt = dbUnitHelper.getDbConnection().getConnection().prepareStatement(
                "DELETE FROM ECG_LD.DIRECT_STAGING " +
                        "WHERE conversation_id IN('YjEih7/pZgFTQJnBMHA==','CONV_ID_235')");
        stmt.execute();
        stmt.close();
//      DatabaseOperation.REFRESH.execute(dbUnitHelper.getDbConnection(),
//          getDataSet("initial"));
    }

    public void testStoreInventorySingle() throws Exception {

        JdbcInventoryReportingDao jdbcInventoryReportingDao = new JdbcInventoryReportingDao();
        jdbcInventoryReportingDao.setDataSource(getDataSource());

        Date asOfDate = new GregorianCalendar(2005, Calendar.JANUARY, 1).getTime();
        InventoryDetails inventoryDetails = new InventoryDetails(
                "HANDHELD_20071219_101010", AppConstants.CUST_TYPE_ST_TYPE, AppConstants.REPORT_TYPE,
                AppConstants.DS_TYPE, AppConstants.SF_TYPE, AppConstants.INVOICE_DATE_QUALIFIER,
                AppConstants.SHIP_DATE_QUALIFIER, AppConstants.TRANSACTION_STATUS,
                "YjEih7/pZgFTQJnBMHA==", "C5", "123456789", "REPORTER NAME", "HANDHELD",
                "7890123", "92", "OWNER NAME", "235789345", "9", "LOCATION NAMME",
                asOfDate, AppConstants.LINE_ID_QUAL_FOR_GTIN, "123456789",
                "99", AppConstants.NEGATIVE_VAL_QTY_QUALIFIER,
                AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE, "BG", "Y", "LOT NUM OPT");

        List inventoryDetailsList = new ArrayList();
        inventoryDetailsList.add(inventoryDetails);
        int actualResult = jdbcInventoryReportingDao.storeInventoryReportingDetails(inventoryDetailsList);

        assertEquals(1, actualResult);

        IDataSet expectedDataSet = getDataSet("testStoreInventoryDetails");
        ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
        ITable actualTable = getActualTableBasedOnExpectedTableColumns(
                expectedTable, "SELECT * FROM ECG_LD.DIRECT_STAGING where conversation_id='YjEih7/pZgFTQJnBMHA=='");
        Assertion.assertEquals(expectedTable, actualTable);
    }

    public void testStoreInventoryMultiple() throws Exception {
        JdbcInventoryReportingDao jdbcInventoryReportingDao = new JdbcInventoryReportingDao();
        jdbcInventoryReportingDao.setDataSource(getDataSource());

        Date asOfDate = new GregorianCalendar(2005, Calendar.JANUARY, 1).getTime();
        InventoryDetails inventoryDetails1 = new InventoryDetails(
                "HANDHELD_20071219_101010", AppConstants.CUST_TYPE_ST_TYPE, AppConstants.REPORT_TYPE,
                AppConstants.DS_TYPE, AppConstants.SF_TYPE, AppConstants.INVOICE_DATE_QUALIFIER,
                AppConstants.SHIP_DATE_QUALIFIER, AppConstants.TRANSACTION_STATUS,
                "CONV_ID_235", "C5", "123456789", "REPORTER NAME", "HANDHELD",
                "7890123", "92", "OWNER NAME", "235789345", "9", "LOCATION NAMME",
                asOfDate, AppConstants.LINE_ID_QUAL_FOR_GTIN, "123456789",
                "10", AppConstants.NEGATIVE_VAL_QTY_QUALIFIER,
                AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE, "BG", "Y", "LOT NUM OPT");

        InventoryDetails inventoryDetails2 = new InventoryDetails(
                "HANDHELD_20071219_101010", AppConstants.CUST_TYPE_ST_TYPE, AppConstants.REPORT_TYPE,
                AppConstants.DS_TYPE, AppConstants.SF_TYPE, AppConstants.INVOICE_DATE_QUALIFIER,
                AppConstants.SHIP_DATE_QUALIFIER, AppConstants.TRANSACTION_STATUS,
                "CONV_ID_235", "C5", "123456789", "REPORTER NAME", "HANDHELD",
                "7890123", "92", "OWNER NAME", "235789345", "9", "LOCATION NAMME",
                asOfDate, AppConstants.LINE_ID_QUAL_FOR_GTIN, "123456789",
                "20", AppConstants.ZERO_POSITIVE_VAL_QTY_QUALIFIER,
                AppConstants.ZERO_POSITIVE_QTY_VAL_ORDER_TYPE, "BG", "Y", "LOT NUM OPT");

        List inventoryDetailsList = new ArrayList();
        inventoryDetailsList.add(inventoryDetails1);
        inventoryDetailsList.add(inventoryDetails2);
        int actualResult = jdbcInventoryReportingDao.storeInventoryReportingDetails(inventoryDetailsList);

        assertEquals(2, actualResult);

        IDataSet expectedDataSet = getDataSet("testStoreInventoryDetailsMultiple");
        ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
        ITable actualTable = getActualTableBasedOnExpectedTableColumns(
                expectedTable, "SELECT * FROM ECG_LD.DIRECT_STAGING where conversation_id='CONV_ID_235'");
        Assertion.assertEquals(expectedTable, actualTable);

    }

    public void testStoreInvRepFailTooLargeValue() {

        JdbcInventoryReportingDao jdbcInventoryReportingDao = new JdbcInventoryReportingDao();
        jdbcInventoryReportingDao.setDataSource(getDataSource());

        InventoryDetails inventoryDetails = new InventoryDetails(
                "HANDHELD_20071219_101010", AppConstants.CUST_TYPE_ST_TYPE, AppConstants.REPORT_TYPE,
                AppConstants.DS_TYPE, AppConstants.SF_TYPE, AppConstants.INVOICE_DATE_QUALIFIER,
                AppConstants.SHIP_DATE_QUALIFIER, AppConstants.TRANSACTION_STATUS,
                "YjEih7/pZgFTQJnBMHA==", "C55555555555", "123456789", "REPORTER NAME", "HANDHELD",
                "OWNR_ID", "92", "OWN_NAM", "LOC_ID", "9", "LOC_NAM",
                new Date(), AppConstants.LINE_ID_QUAL_FOR_GTIN, "GTIN_NUM",
                "99", AppConstants.NEGATIVE_VAL_QTY_QUALIFIER,
                AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE, "BG", "Y", "LOT NUM OPT");

        List inventoryDetailsList = new ArrayList();
        inventoryDetailsList.add(inventoryDetails);

        try {
            jdbcInventoryReportingDao.storeInventoryReportingDetails(inventoryDetailsList);
            fail("Value too large for Reporter Id");
        } catch (Exception e) {
            System.out.println("Error Message" + e.getMessage());
        }
    }

    public void testStoreInventoryStoresSoldNotDeliveredAs_COMMIT_QTY() throws Exception {

        JdbcInventoryReportingDao jdbcInventoryReportingDao = new JdbcInventoryReportingDao();
        jdbcInventoryReportingDao.setDataSource(getDataSource());

        Date asOfDate = new GregorianCalendar(2005, Calendar.JANUARY, 1).getTime();
        InventoryDetails inventoryDetails = new InventoryDetails(
                "HANDHELD_20071219_101010", AppConstants.CUST_TYPE_ST_TYPE, AppConstants.REPORT_TYPE,
                AppConstants.DS_TYPE, AppConstants.SF_TYPE, AppConstants.INVOICE_DATE_QUALIFIER,
                AppConstants.SHIP_DATE_QUALIFIER, AppConstants.TRANSACTION_STATUS,
                "YjEih7/pZgFTQJnBMHA==", "C5", "123456789", "REPORTER NAME", "HANDHELD",
                "7890123", "92", "OWNER NAME", "235789345", "9", "LOCATION NAMME",
                asOfDate, AppConstants.LINE_ID_QUAL_FOR_GTIN, "123456789",
                "99", AppConstants.NEGATIVE_VAL_QTY_QUALIFIER,
                AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE, "BG", "Y", "LOT NUM OPT");
        inventoryDetails.setSoldNotDelivered("-1");

        List inventoryDetailsList = new ArrayList();
        inventoryDetailsList.add(inventoryDetails);
        int actualResult = jdbcInventoryReportingDao.storeInventoryReportingDetails(inventoryDetailsList);

        assertEquals(1, actualResult);

        IDataSet expectedDataSet = getDataSet("testStoreInventoryDetails_SoldNotDelivered");
        ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
        ITable actualTable = getActualTableBasedOnExpectedTableColumns(
                expectedTable, "SELECT * FROM ECG_LD.DIRECT_STAGING where conversation_id='YjEih7/pZgFTQJnBMHA=='");
        Assertion.assertEquals(expectedTable, actualTable);
    }

    public void testStoreInventoryStoresSoldNotDeliveredAsOfDateAs_COMMIT_AS_OF_DATE() throws Exception {

        JdbcInventoryReportingDao jdbcInventoryReportingDao = new JdbcInventoryReportingDao();
        jdbcInventoryReportingDao.setDataSource(getDataSource());

        Date asOfDate = new GregorianCalendar(2005, Calendar.JANUARY, 1).getTime();
        InventoryDetails inventoryDetails = new InventoryDetails(
                "HANDHELD_20071219_101010", AppConstants.CUST_TYPE_ST_TYPE, AppConstants.REPORT_TYPE,
                AppConstants.DS_TYPE, AppConstants.SF_TYPE, AppConstants.INVOICE_DATE_QUALIFIER,
                AppConstants.SHIP_DATE_QUALIFIER, AppConstants.TRANSACTION_STATUS,
                "YjEih7/pZgFTQJnBMHA==", "C5", "123456789", "REPORTER NAME", "HANDHELD",
                "7890123", "92", "OWNER NAME", "235789345", "9", "LOCATION NAMME",
                asOfDate, AppConstants.LINE_ID_QUAL_FOR_GTIN, "123456789",
                "99", AppConstants.NEGATIVE_VAL_QTY_QUALIFIER,
                AppConstants.NEGATIVE_QTY_VAL_ORDER_TYPE, "BG", "Y", "LOT NUM OPT");
        inventoryDetails.setDateChanged(new GregorianCalendar(2011,0,2,3,4,5).getTime());

        List inventoryDetailsList = new ArrayList();
        inventoryDetailsList.add(inventoryDetails);
        int actualResult = jdbcInventoryReportingDao.storeInventoryReportingDetails(inventoryDetailsList);

        assertEquals(1, actualResult);

        IDataSet expectedDataSet = getDataSet("testStoreInventoryDetails_SoldNotDeliveredAsOfDate");
        ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
        ITable actualTable = getActualTableBasedOnExpectedTableColumns(
                expectedTable, "SELECT * FROM ECG_LD.DIRECT_STAGING where conversation_id='YjEih7/pZgFTQJnBMHA=='");
        Assertion.assertEquals(expectedTable, actualTable);
    }
}
