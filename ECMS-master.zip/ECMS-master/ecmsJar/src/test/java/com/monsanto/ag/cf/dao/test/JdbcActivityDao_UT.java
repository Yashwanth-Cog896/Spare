/*
 * JdbcActivityDao_UT was created on Mar 29, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.springframework.dao.DataIntegrityViolationException;

import com.monsanto.ag.cf.dao.jdbc.JdbcActivityDao;
import com.monsanto.ag.cf.domain.UserActivity;

/**
 * Test storing user activity information using the JdbcActivityDao.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcActivityDao_UT.java,v 1.17 2005-07-08 17:13:30 ggdavi Exp $
 */
public class JdbcActivityDao_UT extends BaseDbUnitTestCase {

  public void testStoreCompleteUserActivity() throws Exception {
    JdbcActivityDao activityDao = new JdbcActivityDao();
    activityDao.setDataSource(getDataSource());
    activityDao.setSequenceName("data_exchange_log_seq");

    Date startDate = new GregorianCalendar(2005, Calendar.MAY, 1).getTime();
    Date endDate = new GregorianCalendar(2005, Calendar.MAY, 1).getTime();
    UserActivity activity = new UserActivity("gareth", 586,
        "YjEih7/pZgFTQJnBMHA=", "ECHO", startDate, endDate, "STC", "2006",
        "5.0.28", 1);
    activityDao.storeActivity(activity);

    IDataSet expectedDataSet = getDataSet("testStoreCompleteUserActivity");
    ITable expectedTable = expectedDataSet.getTable("DATA_EXCHANGE_LOG");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
        expectedTable, "SELECT * FROM DATA_EXCHANGE_LOG");
    Assertion.assertEquals(expectedTable, actualTable);
  }

  public void testStoreUserActivityWithoutSequenceNameThrowsException()
      throws Exception {
    JdbcActivityDao activityDao = new JdbcActivityDao();
    activityDao.setDataSource(getDataSource());

    try {
      UserActivity activity = new UserActivity("gareth", 586,
          "YjEih7/pZgFTQJnBMHA=", "ECHO", new Date(), new Date(), "STC",
          "2006", "5.0.28", 1);
      activityDao.storeActivity(activity);
      fail("Should throw DataIntegrityViolationException");
    } catch (DataIntegrityViolationException IGNORE) {
    }

    ITable table = getActualTable("SELECT * FROM DATA_EXCHANGE_LOG");
    assertEquals(0, table.getRowCount());
  }

  public void testStoreUserActivityWithMissingRequiredFieldsThrowsException()
      throws Exception {
    JdbcActivityDao activityDao = new JdbcActivityDao();
    activityDao.setDataSource(getDataSource());
    activityDao.setSequenceName("data_exchange_log_seq");

    try {
      UserActivity activity = new UserActivity();
      activityDao.storeActivity(activity);
      fail("Should throw DataIntegrityViolationException");
    } catch (DataIntegrityViolationException IGNORE) {
    }

    ITable table = getActualTable("SELECT * FROM DATA_EXCHANGE_LOG");
    assertEquals(0, table.getRowCount());
  }

}

/*
 * $Log: not supported by cvs2svn $ Revision 1.16 2005/05/09 20:30:02 ggdavi
 * Use new getActualTable method where appropriate Revision 1.15 2005/05/06
 * 17:45:44 ggdavi Removed error_code and error_message
 * 
 * Revision 1.14 2005/05/05 19:03:43 ggdavi Uses the DbUnit Assertion object to
 * compare expected and actual datasets Revision 1.13 2005/04/26 21:21:38 ggdavi
 * Added endTime to UserActivity constructor and reordered fields Revision 1.12
 * 2005/04/25 17:29:02 ggdavi Added conversationId field; startTime is no longer
 * auto-populated - it is now set in constructor or via setStartTime Revision
 * 1.11 2005/04/21 19:19:11 ggdavi Moved getTodaysDateOnly method from
 * JdbcActivityDao_UT to Utilities
 * 
 * Revision 1.10 2005/04/21 15:32:47 ggdavi Added errorCode and errorMessage
 * fields to UserActivity
 * 
 * Revision 1.9 2005/04/14 16:48:27 ggdavi Added dataSource argument to
 * UserActivity constructor Revision 1.8 2005/04/13 16:31:02 ggdavi Missing
 * required fields uses default UserActivity constructor
 * 
 * Revision 1.7 2005/04/12 19:26:12 ggdavi Added accountId field to UserActivity
 * Revision 1.6 2005/04/07 15:44:08 ggdavi Now use an integer value for the Id
 * Revision 1.5 2005/04/05 21:38:33 ggdavi Now just focuses on updating database
 * tables
 * 
 * Revision 1.4 2005/04/01 21:49:18 ajbaldw Removed references to
 * BasicDataSource dbcp pool.
 * 
 * Revision 1.3 2005/04/01 21:38:20 ajbaldw Re-enabled a test method. Revision
 * 1.2 2005/04/01 21:05:35 ajbaldw Changed the MockUserActivity to return
 * hardcoded values. Revision 1.1 2005/03/29 23:08:00 ggdavi Initial version
 */