/*
PackageMatcherPointcut_UT was created on May 3, 2005 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.aop.test;

import com.monsanto.ag.cf.aop.PackageMatcherPointcut;

import junit.framework.TestCase;

/**
 * Test the PackageMatcherPointcut.
 * @author Gareth Davies
 * @version $Id: PackageMatcherPointcut_UT.java,v 1.3 2005-06-30 17:43:26 ggdavi Exp $
 */
public class PackageMatcherPointcut_UT extends TestCase {
  
  public void testNoPackageMapped() {
    PackageMatcherPointcut pointcut = new PackageMatcherPointcut();
    
    assertFalse("Class does not match pointcut", pointcut.matches(null, this.getClass()));
  }
  
  public void testClassInSpecifiedPackage() {
    PackageMatcherPointcut pointcut = new PackageMatcherPointcut();
    pointcut.setMappedName("com.monsanto.ag.cf.aop.test");
    
    assertTrue("Class matches pointcut", pointcut.matches(null, this.getClass()));
  }
  
  public void testClassInChildPackage() {
    PackageMatcherPointcut pointcut = new PackageMatcherPointcut();
    pointcut.setMappedName("com.monsanto.ag");
    
    assertTrue("Class matches pointcut", pointcut.matches(null, this.getClass()));
  }
  
  public void testClassInDifferentPackageHierarchy() {
    PackageMatcherPointcut pointcut = new PackageMatcherPointcut();
    pointcut.setMappedName("com.monsanto.AbstractLogging");
    
    assertFalse("Class does not match pointcut", pointcut.matches(null, this.getClass()));
  }
  
  public void testNoClassSpecified() {
    PackageMatcherPointcut pointcut = new PackageMatcherPointcut();
    pointcut.setMappedName("com.monsanto.ag");
    
    assertFalse("Class does not match pointcut", pointcut.matches(null, null));
  }

}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.1  2005/05/03 20:20:19  ggdavi
 * Initial version
 *
 */