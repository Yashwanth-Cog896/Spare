/*
 * EncryptedPropertyPlaceholderConfigurer_UT was created on Mar 30, 2005 using
 * Monsanto resources and is the sole property of Monsanto. Any duplication of
 * the code and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.config.test;

import java.util.Properties;

import junit.framework.TestCase;

import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.databasepasswordencryption.StringEncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.Helper.ConvertUtils;
import com.monsanto.ag.cf.config.EncryptedPropertyPlaceholderConfigurer;

/**
 * Test the EncryptedPropertyPlaceholderConfigurer
 * 
 * @author ajbaldw
 * @version $Id: EncryptedPropertyPlaceholderConfigurer_UT.java,v 1.2 2005/04/01
 *          21:03:00 ajbaldw Exp $
 */
public class EncryptedPropertyPlaceholderConfigurer_UT extends TestCase {
  
  MockEncryptedPropertyPlaceHolderConfigurer customPropertyPlaceholder = null;
  Properties props = null;
  
  protected void setUp() throws Exception {
    customPropertyPlaceholder = new MockEncryptedPropertyPlaceHolderConfigurer();
    props = new Properties();
    System.setProperty("lsi.function","win");
    props.setProperty("win.some.key", "someWinValue");
    props.setProperty("dev.some.key", "someDevValue");
    props.setProperty("default.some.other.key", "someOtherValue");   
  }

  public void testConvertAESEncryptedPropertyValue() throws Exception {
    String encrypted = ConvertUtils.asHex(StringEncryptionUtils.encryptWithAES(
        "alan".getBytes(), "R/\nd0M_pA55w0Rd"));

    EncryptedPropertyPlaceholderConfigurer conf = new EncryptedPropertyPlaceholderConfigurer();
    String decrypted = conf.convertPropertyValue(encrypted.toUpperCase());
    
    assertEquals("alan", decrypted);
  }
  
  public void testConvertNonHexPlainTextPropertyValue() {
    EncryptedPropertyPlaceholderConfigurer conf = new EncryptedPropertyPlaceholderConfigurer();
    String decrypted = conf.convertPropertyValue("alan");
    
    assertEquals("alan", decrypted);
  }
  
  public void testConvertEmptyOrNullPropertyValue() {
    EncryptedPropertyPlaceholderConfigurer conf = new EncryptedPropertyPlaceholderConfigurer();
    
    String decrypted = conf.convertPropertyValue("");
    assertEquals("", decrypted);
    
    decrypted = conf.convertPropertyValue(null);
    assertEquals(null, decrypted);
  }
  
  public void testResolvePlaceholder_withDefaultEnvPrefix() throws Exception {
    System.out.println("lsi = "+System.getProperty("lsi.function"));
    assertEquals("someWinValue", customPropertyPlaceholder.resolvePlaceholder("some.key", props));    
  }

  public void testResolvePlaceholder_withSpecificEnvPrefix() throws Exception {
    System.setProperty("lsi.function", "dev");
    assertEquals("someDevValue", customPropertyPlaceholder.resolvePlaceholder("some.key", props));
    System.setProperty("lsi.function", "win");
  }
  
  public void testResolvePlaceholder_returnDefaultWhenKeyIsMissing() throws Exception {
    assertEquals("someOtherValue", customPropertyPlaceholder.resolvePlaceholder("some.other.key", props));    
  }    
  
  public void testResolvePlaceholder_returnNull_whenEnvPrefixAndDefaultKeysAreMissing() throws Exception {
      assertEquals(null, customPropertyPlaceholder.resolvePlaceholder("another.key", props));  
  }
  
  class MockEncryptedPropertyPlaceHolderConfigurer extends EncryptedPropertyPlaceholderConfigurer {
    protected String resolvePlaceholder(String placeHolder, Properties props) {
      return super.resolvePlaceholder(placeHolder, props);
    }
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/06/30 17:43:26  ggdavi
 * Moved ag.aop, ag.config and ag.message packages under the ag.cf package
 *
 * Revision 1.1  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.1  2005/04/07 15:40:32  ggdavi
 * Moved from web to config package
 *
 * Revision 1.3  2005/04/05 21:39:40  ggdavi
 * Got to work by overriding parseString
 * Revision 1.2
 * 2005/04/01 21:03:00 ajbaldw Added code to decrypt properties from encrypted
 * property files.
 * 
 * Revision 1.1 2005/03/31 15:30:35 ajbaldw Initial Version (Unit test working)
 *  
 */