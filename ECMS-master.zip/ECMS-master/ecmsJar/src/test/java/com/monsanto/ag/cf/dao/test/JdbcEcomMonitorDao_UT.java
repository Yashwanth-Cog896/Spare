/*
 * JdbcEcomMonitorDao_UT was created on Jul 25, 2005 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import com.monsanto.ag.cf.dao.jdbc.JdbcEcomMonitorDao;
import com.monsanto.ag.util.test.Log4JTestConfigurationHelper;

/**
 * Test retrieving ECOM Database status using the JdbcEcomMonitorDao.
 * @author Chetna Aggarwal
 * @version $Id: JdbcEcomMonitorDao_UT.java,v 1.3 2006-05-01 20:44:03 ggdavi Exp $
 */
public class JdbcEcomMonitorDao_UT extends BaseDbUnitTestCase {

  public void setUp() throws Exception {
    Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty();

    dbUnitHelper = new DbUnitHelperFactory().createDbUnitHelper();
  }

  public void testGetDatabaseStatus() {
    JdbcEcomMonitorDao jdbcEcomMonitorDao = new JdbcEcomMonitorDao();
    jdbcEcomMonitorDao.setDataSource(getDataSource());

    assertEquals(1, jdbcEcomMonitorDao.getDatabaseStatus());
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/08/18 12:30:07  ggdavi
 * All relevant test case setUp methods now use the Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty method to ensure a valid value exists for the catalina.base system property required by the log4j.properties file.
 *
 * Revision 1.1  2005/07/29 20:15:38  caggarw
 * unit test for JdbcEcomMonitorDao
 *
 */