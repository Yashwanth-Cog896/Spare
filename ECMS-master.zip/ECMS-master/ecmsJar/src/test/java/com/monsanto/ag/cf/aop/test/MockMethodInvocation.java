/*
MockMethodInvocation was created on Apr 8, 2005 using Monsanto
resources and is the sole property of Monsanto.  Any duplication of the
code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.aop.test;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInvocation;


public class MockMethodInvocation implements MethodInvocation {

  private String methodName;
  private Class[] argumentTypes;
  private Object[] arguments;
  private Object target;

  public MockMethodInvocation(String methodName, Class[] argumentTypes,
      Object[] arguments, Object target) {
    this.methodName = methodName;
    this.argumentTypes = argumentTypes;
    this.arguments = arguments;
    this.target = target;
  }

  public Method getMethod() {
    Method method = null;
    try {
      method = target.getClass().getMethod(methodName, argumentTypes);
    } catch (SecurityException e) {
      System.err.println(e);
    } catch (NoSuchMethodException e) {
      System.err.println(e);
    }
    return method;
  }

  public Object[] getArguments() {
    return arguments;
  }

  public Object proceed() throws Throwable {
    return getMethod().invoke(target, getArguments());
  }

  public Object getThis() {
    return target;
  }

  public AccessibleObject getStaticPart() {
    return null;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.1  2005/04/08 21:54:55  ajbaldw
 * Initial Version
 *
*/