/*
 * BaseDbUnitTestCase was created on Apr 12, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import java.sql.SQLException;

import javax.sql.DataSource;

import junit.framework.TestCase;

import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.operation.DatabaseOperation;

import com.monsanto.ag.util.test.DbUnitHelper;
import com.monsanto.ag.util.test.Log4JTestConfigurationHelper;

/**
 * Provides common functionality for DbUnit-based test cases.
 * 
 * @author Gareth Davies
 * @version $Id: BaseDbUnitTestCase.java,v 1.9 2006-05-01 20:44:03 ggdavi Exp $
 */
public abstract class BaseDbUnitTestCase extends TestCase {

  protected DbUnitHelper dbUnitHelper;

  protected void setUp() throws Exception {
    Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty();

    createDbUnitHelper();
    DatabaseOperation.CLEAN_INSERT.execute(dbUnitHelper.getDbConnection(),
        getDataSet("initial"));
  }

  protected void createDbUnitHelper() throws Exception {
    DbUnitHelperFactory factory = new DbUnitHelperFactory();
    dbUnitHelper = factory.createDbUnitHelper();
  }

  protected void tearDown() throws Exception {
    dbUnitHelper.cleanup();
  }

  protected DataSource getDataSource() {
    return dbUnitHelper.getDataSource();
  }

  protected IDatabaseConnection getDbConnection() {
    return dbUnitHelper.getDbConnection();
  }

  protected IDataSet getDataSet(String fileName) throws Exception {
    return dbUnitHelper.getTestCaseDataSet(this.getClass(), fileName);
  }

  protected ITable getActualTable(String sql) throws DataSetException,
      SQLException {
    return dbUnitHelper.getActualTable(sql);
  }

  protected ITable getActualTableBasedOnExpectedTableColumns(
      ITable expectedTable, String sql) throws DataSetException, SQLException {
    return dbUnitHelper.getActualTableBasedOnExpectedTableColumns(
        expectedTable, sql);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.8  2005/08/18 12:30:07  ggdavi
 * All relevant test case setUp methods now use the Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty method to ensure a valid value exists for the catalina.base system property required by the log4j.properties file.
 *
 * Revision 1.7  2005/07/29 20:15:15  caggarw
 * changed the field to protected as need to override the setup method
 *
 * Revision 1.6  2005/05/31 15:29:31  ggdavi
 * Changes not necessary
 *
 * Revision 1.4  2005/05/17 15:24:24  ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 *
 * Revision 1.3  2005/05/09 18:07:13  ggdavi
 * Added getActualTable method
 * Revision 1.2 2005/05/05 19:03:14 ggdavi Now
 * mostly delegates to DbUnitHelper Revision 1.1 2005/04/12 19:24:02 ggdavi
 * Initial version
 *  
 */