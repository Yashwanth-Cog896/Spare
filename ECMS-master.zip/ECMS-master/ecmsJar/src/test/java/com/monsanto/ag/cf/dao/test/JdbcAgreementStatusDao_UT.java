/*
 * JdbcAgreementStatus_UT was created on Apr 16, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import java.util.ArrayList;
import java.util.List;

import com.monsanto.ag.cf.dao.jdbc.JdbcAgreementStatusDao;
import com.monsanto.ag.cf.domain.AgreementDetails;

/**
 * Test retrieving of agreement status data using the JdbcAgreementStatusDao
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcAgreementStatusDao_UT.java,v 1.2 2007-05-01 18:18:42 caggarw Exp $
 */
public class JdbcAgreementStatusDao_UT extends BaseDbUnitTestCase {

  public void testGetAgreementStatus() {
    JdbcAgreementStatusDao jdbcAgreementStatusDao = new JdbcAgreementStatusDao();
    jdbcAgreementStatusDao.setDataSource(getDataSource());

    AgreementDetails expectedAgreementDetails = new AgreementDetails(1234, "Seeds Inc", "MA", "AE", "East", "AE",
        "East", "Unlicensed","Joe", "Dealer");
    List expectedDetails = new ArrayList();
    expectedDetails.add(expectedAgreementDetails);
    List actualDetails = jdbcAgreementStatusDao.getAgreementStatusDetails(1234);
    assertEquals(expectedDetails, actualDetails);
  }

}
