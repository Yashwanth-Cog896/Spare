/*
 * JdbcDealerPreferencesDao_UT was created on Oct 3, 2007 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.springframework.dao.IncorrectResultSizeDataAccessException;

import com.monsanto.ag.cf.dao.jdbc.JdbcDealerPreferencesDao;

/**
 * Test storing/retrieving dealers information using the
 * JdbcDealerPreferencesDao.
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcDealerPreferencesDao_UT.java,v 1.5 2008-04-29 15:10:53 rwspeh Exp $
 */
public class JdbcDealerPreferencesDao_UT extends BaseDbUnitTestCase {

  public void testStoreVersion() throws Exception {
    JdbcDealerPreferencesDao dealerPreferencesDao = new JdbcDealerPreferencesDao();
    dealerPreferencesDao.setDataSource(getDataSource());

    dealerPreferencesDao.storeVersion(1234, "1.3.4", "Test Source Name");    

     IDataSet expectedDataSet = getDataSet("testStoreVersion");
     ITable expectedTable = expectedDataSet.getTable("USER_XREF");
     ITable actualTable = getActualTableBasedOnExpectedTableColumns(
     expectedTable, "SELECT * FROM USER_XREF where acct_id=1234");
     Assertion.assertEquals(expectedTable, actualTable);
  }
  
  public void testStoreVersionNoEntryInTableForAccount() throws Exception {
    JdbcDealerPreferencesDao dealerPreferencesDao = new JdbcDealerPreferencesDao();
    dealerPreferencesDao.setDataSource(getDataSource());

    dealerPreferencesDao.storeVersion(3456, "1.3.4", "Test Source Name");    

     ITable actualTable = getActualTable(
     "SELECT * FROM USER_XREF where acct_id=3456");
     assertEquals(0, actualTable.getRowCount());
  }
  
  public void testStoreVersionNoActiveEntryInTableForAccount() throws Exception {
    JdbcDealerPreferencesDao dealerPreferencesDao = new JdbcDealerPreferencesDao();
    dealerPreferencesDao.setDataSource(getDataSource());

    dealerPreferencesDao.storeVersion(244, "1.3.5", "Test Source Name");
    IDataSet expectedDataSet = getDataSet("testStoreVersionDoesNotExist");
    ITable expectedTable = expectedDataSet.getTable("USER_XREF");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
    expectedTable, "SELECT * FROM USER_XREF where acct_id=244");
    Assertion.assertEquals(expectedTable, actualTable);
  }
  
  public void testGetLatestVersion() throws Exception {
    JdbcDealerPreferencesDao dealerPreferencesDao = new JdbcDealerPreferencesDao();
    dealerPreferencesDao.setDataSource(getDataSource());
    
    String version = dealerPreferencesDao.getLatestVersion("SeedTrak Mobile Inventory");
    assertEquals("1.6.7", version);
  }
  
  public void testGetLatestVersionDoesNotExistthrowsException() throws Exception {
    JdbcDealerPreferencesDao dealerPreferencesDao = new JdbcDealerPreferencesDao();
    dealerPreferencesDao.setDataSource(getDataSource());
    
    try {
      dealerPreferencesDao.getLatestVersion("Inventory");
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }
  
  public void testGetEnabledFlag() throws Exception {
    JdbcDealerPreferencesDao dealerPreferencesDao = new JdbcDealerPreferencesDao();
    dealerPreferencesDao.setDataSource(getDataSource());
    
    String version = dealerPreferencesDao.getEnabledFlag(1234);
    assertEquals("N", version);
  }

}
