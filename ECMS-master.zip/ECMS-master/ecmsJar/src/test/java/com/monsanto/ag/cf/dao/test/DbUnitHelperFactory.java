/*
 DbUnitHelperFactory was created on Apr 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.dao.test;

import com.monsanto.ag.cf.test.TestConfig;
import com.monsanto.ag.util.test.DbUnitHelper;

import java.util.Properties;

/**
 * Filename:    $RCSfile: DbUnitHelperFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: maschec $    	 On:	$Date: 2008-06-25 20:03:25 $
 *
 * @author ggdavi
 * @version $Revision: 1.7 $
 */
public class DbUnitHelperFactory {

    private static final String TEST_DATA_DIRECTORY =
            TestConfig.getTestDataParentSubpath() + "testdata/db/";

    public DbUnitHelper createDbUnitHelper() throws Exception {
        Properties jdbcProps = new Properties();
        jdbcProps.setProperty("jdbc.driverClassName", "oracle.jdbc.OracleDriver");
        //MAS 6/25/08: Changed from dev01.monsanto.com to fsdevl01.monsanto.com
        // as the latter is the proper host name, and also dev01.monsanto.com stopped
        // working today.
        jdbcProps.setProperty("jdbc.url", "jdbc:oracle:thin:@fsdevl01.monsanto.com:1521:fsdevl01");
        jdbcProps.setProperty("jdbc.schema", "ECOM");
        jdbcProps.setProperty("jdbc.username", "ecom_app");
        jdbcProps.setProperty("jdbc.password", "Lone5_ZC9w ");
        return new DbUnitHelper(jdbcProps, TEST_DATA_DIRECTORY);
    }

    public static DbUnitHelper createDbUnitHelperUSMGEND(String schema) throws Exception{
        Properties jdbcProps = new Properties();
        jdbcProps.setProperty("jdbc.driverClassName", "oracle.jdbc.OracleDriver");
        jdbcProps.setProperty("jdbc.url", "jdbc:oracle:thin:@USMGENQ.MONSANTO.COM:1521/USMGENQ.MONSANTO.COM");
        jdbcProps.setProperty("jdbc.schema", "USMGENQ");
        jdbcProps.setProperty("jdbc.username", "ecom_support");
        jdbcProps.setProperty("jdbc.password", "h1olBHf_Sj");
        return new DbUnitHelper(jdbcProps, TEST_DATA_DIRECTORY);
    }

    public static DbUnitHelper createDbUnitHelperUSMGEND() throws Exception {
        return createDbUnitHelperUSMGEND("USMGEND");
    }

    public DbUnitHelper createDbUnitHelper(Properties jdbcProps) throws Exception {
        return new DbUnitHelper(jdbcProps, TEST_DATA_DIRECTORY);
    }
}