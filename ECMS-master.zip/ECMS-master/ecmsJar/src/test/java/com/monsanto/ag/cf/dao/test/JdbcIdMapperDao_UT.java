/*
 * JdbcAccountIdDao_UT was created on Jul 20, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import org.springframework.dao.IncorrectResultSizeDataAccessException;

import com.monsanto.ag.cf.dao.jdbc.JdbcIdMapperDao;

/**
 * Test mapping Ids using the JdbcIdMapperDao.
 * 
 * @author Chetna Aggarwal
 * @version $Id: JdbcIdMapperDao_UT.java,v 1.4 2007-07-06 23:07:40 caggarw Exp $
 */
public class JdbcIdMapperDao_UT extends BaseDbUnitTestCase {

  public void testfindSAPIdForValidAccountId() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    String retrievedSAPId = accountDao.findSAPIdByAccountId(678);
    assertEquals("0000012345", retrievedSAPId);
  }

  public void testfindSAPIdForInvalidAccountId() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findSAPIdByAccountId(12345);
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }

  public void testfindSAPIdForInvalidSystemAccessCode() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findSAPIdByAccountId(345);
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }

  public void testfindSAPIdForInactiveAccount() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findSAPIdByAccountId(905);
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }

  public void testfindAccountIdForValidSAPId() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    long retrievedAccountId = accountDao.findAccountIdBySAPId("0000012345");
    assertEquals(678, retrievedAccountId);
  }

  public void testfindAccountIdForInvalidSAPId() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findAccountIdBySAPId("0000000123");
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }

  public void testfindAccountIdForInvalidSystemAccessCode() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findAccountIdBySAPId("0000000678");
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }
  
  public void testfindAccountIdForValidEBID() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    long retrievedAccountId = accountDao.findAccountIdByEBID("1235678890");
    assertEquals(1344, retrievedAccountId);
  }

  public void testfindAccountIdForInvalidEBID() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findAccountIdByEBID("0000000123");
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }

  public void testfindAccountIdForInactiveAccount() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findAccountIdByEBID("4366583356");
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }
  public void testfindAccountIdByEBIDForInvalidSystemAccessCode() {
    JdbcIdMapperDao accountDao = new JdbcIdMapperDao();
    accountDao.setDataSource(getDataSource());
    try {
      accountDao.findAccountIdByEBID("3346547323");
      fail("Should throw IncorrectResultSizeDataAccessException");
    } catch (IncorrectResultSizeDataAccessException e) {
      assertEquals("Incorrect result size: expected 1, actual 0", e
          .getMessage());
    }
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/07/26 17:11:53  ggdavi
 * IdMapperDao now treats SAP Ids as text, since that is how the materialized view treats it :-(
 *
 * Revision 1.2  2005/07/21 18:21:44  ggdavi
 * The findAccountIdBySAPId method now expects a long parameter
 *
 * Revision 1.1  2005/07/21 15:58:34  caggarw
 * UT for IdMapperDao
 *
 */