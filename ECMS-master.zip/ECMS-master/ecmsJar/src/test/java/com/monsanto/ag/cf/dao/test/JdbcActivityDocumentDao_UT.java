/*
 * JdbcActivityDocumentDao_UT was created on May 6, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.List;
import java.util.zip.GZIPInputStream;

import org.dbunit.dataset.ITable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.support.lob.OracleLobHandler;
import org.springframework.jdbc.support.nativejdbc.SimpleNativeJdbcExtractor;

import com.monsanto.ag.cf.dao.jdbc.JdbcActivityDocumentDao;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.XmlNamespace;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocumentBuilder;

/**
 * Test storing XML documents associated with user activity information using
 * the JdbcActivityDocumentDao.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcActivityDocumentDao_UT.java,v 1.1 2005/05/09 18:05:29
 *          ggdavi Exp $
 */
public class JdbcActivityDocumentDao_UT extends BaseDbUnitTestCase {

  private static final XmlNamespace DEFAULT_NAMESPACE = new XmlNamespace("ns",
      "urn:namespace");

  private OracleLobHandler lobHandler;
  private XmlDocumentBuilder xmlDocumentBuilder;

  public void setUp() throws Exception {
    super.setUp();

    // DBUnit cannot easily handle BLOBs
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());

    lobHandler = new OracleLobHandler();
    lobHandler.setNativeJdbcExtractor(new SimpleNativeJdbcExtractor());
    activityDocumentDao.setLobHandler(lobHandler);

    xmlDocumentBuilder = new DOMUtilXmlDocumentBuilder();
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    String xml2 = "<foo " + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, DbUnit!</bar></foo>";
    XmlDocument xmlDocument2 = xmlDocumentBuilder
        .createXmlDocument(new StringReader(xml2));
    activityDocumentDao.storeActivityDocument("2", xmlDocument2, "foo");

    String xml3 = "<foo " + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, Spring!</bar></foo>";
    XmlDocument xmlDocument3 = xmlDocumentBuilder
        .createXmlDocument(new StringReader(xml3));
    activityDocumentDao.storeActivityDocument("3", xmlDocument3, "foo");
  }

  public void testFindActivityDocumentByConversationId() {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    String expectedDocumentXml = "<foo "
        + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, DbUnit!</bar></foo>";

    XmlDocument xmlDocument = activityDocumentDao
        .findActivityDocumentByConversation("R8jvGQYAAqgxgTFktZg3vw==", "foo");

    assertEquals(expectedDocumentXml, xmlDocument.toString());
  }

  public void testFindActivityDocumentByNonMatchingConversationId() {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    XmlDocument xmlDocument = activityDocumentDao
        .findActivityDocumentByConversation("Doesn't exist", "foo");
    assertNull("No XML document returned for conversation Id: Doesn't exist",
        xmlDocument);

    xmlDocument = activityDocumentDao.findActivityDocumentByConversation("  ", "foo");
    assertNull("No XML document returned for conversation Id: 2-spaces",
        xmlDocument);

    xmlDocument = activityDocumentDao.findActivityDocumentByConversation("", "foo");
    assertNull("No XML document returned for conversation Id: empty-string",
        xmlDocument);

    xmlDocument = activityDocumentDao.findActivityDocumentByConversation(null, "foo");
    assertNull("No XML document returned for conversation Id: null",
        xmlDocument);
  }

  public void testFindActivityDocumentsByDealerServiceSeedYear() {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    String expectedDocumentXml1 = "<foo "
        + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, DbUnit!</bar></foo>";
    String expectedDocumentXml2 = "<foo "
        + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, Spring!</bar></foo>";

    List documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, "TEST", "foo", "2006");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(2, documents.size());

    XmlDocument xmlDocument1 = (XmlDocument) documents.get(0);
    assertEquals(expectedDocumentXml1, xmlDocument1.toString());

    XmlDocument xmlDocument2 = (XmlDocument) documents.get(1);
    assertEquals(expectedDocumentXml2, xmlDocument2.toString());
  }

  public void testFindActivityDocumentsByNonMatchingDealerServiceSeedYear() {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    List documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(0, "TEST", "foo", "2006");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());

    documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, "  ", "foo", "2006");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());

    documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, "", "foo", "2006");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());

    documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, null, "foo", "2006");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());

    documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, "TEST", "foo", "  ");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());

    documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, "TEST", "foo", "");
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());

    documents = activityDocumentDao
        .findActivityDocumentsByDealerServiceSeedYear(586, "TEST", "foo", null);
    assertNotNull("Valid list must be returned", documents);
    assertEquals(0, documents.size());
  }

  public void testStoreActivityDocument() throws Exception {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    String xml = "<foo " + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, Oracle!</bar></foo>";
    XmlDocument xmlDocument = xmlDocumentBuilder
        .createXmlDocument(new StringReader(xml));

    activityDocumentDao.storeActivityDocument("1", xmlDocument, "bar");

    ITable actualTable = getActualTable(getDataExchangeRepositorySql("TEST",
        242,"bar"));
    assertEquals(1, actualTable.getRowCount());
    assertEquals(new BigDecimal(1), actualTable.getValue(0, "DATA_EXCHANGE_ID"));

    byte[] xmlMsg = (byte[]) actualTable.getValue(0, "XML_MSG");
    GZIPInputStream gzipStream = new GZIPInputStream(new ByteArrayInputStream(
        xmlMsg));
    Reader reader = new InputStreamReader(gzipStream);
    XmlDocument rsDocument = xmlDocumentBuilder.createXmlDocument(reader);
    assertEquals(xml, rsDocument.toString());
  }

  private String getDataExchangeRepositorySql(String serviceId, long accountId, String root_node_name) {
    return "select del.*, der.xml_msg "
        + "from data_exchange_repository der, data_exchange_log del "
        + "where der.data_exchange_id = del.data_exchange_id "
        + "and del.data_exchange_type_code = '" + serviceId
        + "' and del.acct_id = " + accountId
        + "and der.root_node_name = '" + root_node_name + "'";
  }

  public void testStoreActivityDocumentWithoutForeignKeyThrowsException()
      throws Exception {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    String xml = "<foo " + DEFAULT_NAMESPACE.getDefaultDeclaration() + " "
        + DEFAULT_NAMESPACE.getDeclaration()
        + "><bar>Hello, Oracle!</bar></foo>";
    XmlDocument xmlDocument = xmlDocumentBuilder
        .createXmlDocument(new StringReader(xml));

    try {
      activityDocumentDao.storeActivityDocument(null, xmlDocument, "bar");
      fail("Should throw DataIntegrityViolationException");
    } catch (DataIntegrityViolationException IGNORE) {
    }

    ITable actualTable = getActualTable(getDataExchangeRepositorySql("TEST",
        242, "bar"));
    assertEquals(0, actualTable.getRowCount());
  }

  public void testStoreInvalidActivityDocumentThrowsException()
      throws Exception {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());
    activityDocumentDao.setLobHandler(lobHandler);
    activityDocumentDao.setXmlDocumentBuilder(xmlDocumentBuilder);

    try {
      activityDocumentDao.storeActivityDocument("1", null, "foo");
      fail("Should throw DataIntegrityViolationException");
    } catch (DataIntegrityViolationException IGNORE) {
    }

    ITable actualTable = getActualTable(getDataExchangeRepositorySql("TEST",
        242, "foo"));
    assertEquals(0, actualTable.getRowCount());
  }

  public void testRemoveActivityDocuments() throws Exception {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());

    activityDocumentDao.removeActivityDocuments("TEST", 586, "foo");

    ITable actualTable = getActualTable(getDataExchangeRepositorySql("TEST",
        586, "foo"));
    assertEquals(0, actualTable.getRowCount());
  }

  public void testRemoveActivityDocumentsThatDoNotExist() throws Exception {
    JdbcActivityDocumentDao activityDocumentDao = new JdbcActivityDocumentDao();
    activityDocumentDao.setDataSource(getDataSource());

    activityDocumentDao.removeActivityDocuments("TEST", 242, "bar");

    ITable actualTable = getActualTable(getDataExchangeRepositorySql("TEST",
        586, "foo"));
    assertEquals(2, actualTable.getRowCount());

    activityDocumentDao.removeActivityDocuments("ECHO", 586, "foo");

    actualTable = getActualTable(getDataExchangeRepositorySql("TEST", 586, "foo"));
    assertEquals(2, actualTable.getRowCount());
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.11  2005/12/01 19:34:31  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.10  2005/08/08 15:53:02  ggdavi
 * xmlDocumentBuilder field is now typed as the abstract base class instead of the DOMUtil implementation
 *
 * Revision 1.9  2005/07/25 20:57:37  ggdavi
 * XML documents now stored as compressed bytes in BLOB column
 * Revision 1.8 2005/07/21 14:48:57
 * ggdavi Fleshed out and refactored com.monsanto.ag.util to make more
 * object-oriented, in that most functionality has been pushed to the
 * XmlDocument and XmlElement objects Revision 1.7 2005/07/15 17:39:58 ggdavi
 * Added xmlDocumentProcessor field; implemented the findActivityDocument*
 * methods; added several MappingSqlQuery nested subclasses Revision 1.6
 * 2005/05/31 15:29:48 ggdavi Changes not necessary
 * 
 * Revision 1.4 2005/05/26 21:56:37 ggdavi Added removeActivityDocument method
 * Revision 1.3 2005/05/18 18:17:14 ggdavi Removed to do comment
 * 
 * Revision 1.2 2005/05/09 20:29:36 ggdavi Added exception test cases, including
 * checks for null documents Revision 1.1 2005/05/09 18:05:29 ggdavi Initial
 * version
 * 
 */