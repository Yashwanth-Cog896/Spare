/*
 * JdbcCustomerReviewDao_UT was created on Aug 9, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import com.monsanto.ag.cf.dao.jdbc.JdbcCustomerReviewDao;
import com.monsanto.ag.cf.domain.AddressInformation;
import com.monsanto.ag.cf.domain.CustomerIds;
import com.monsanto.ag.cf.domain.GrowerDetails;
import com.monsanto.ag.cf.domain.ZoneInformation;

import java.util.*;

/**
 * Test retreiving of Customer details using the JdbcCustomerReviewDao
 *
 * @author Chetna Aggarwal
 * @version $Id: JdbcCustomerReviewDao_UT.java,v 1.3 2008-07-09 21:26:46 dddoni Exp $
 */
public class JdbcCustomerReviewDao_UT extends BaseDbUnitTestCase {

  private JdbcCustomerReviewDao customerReviewDao;

  protected void setUp() throws Exception {
    super.setUp();
    customerReviewDao = new JdbcCustomerReviewDao();
    customerReviewDao.setDataSource(getDataSource());
  }

  public void testGetCustomerReview() {
    Date date = new GregorianCalendar(2007, Calendar.JULY, 2, 9, 13, 55).getTime();
    Date max_eff = new GregorianCalendar(2007, Calendar.AUGUST, 1, 0, 0,
            0).getTime();
    List results = customerReviewDao.getCustomerInformation(106, date);

    List expected = new ArrayList();
    AddressInformation address = new AddressInformation("13520 SANDERS HILL RD", "STRYKERSVILLE", "NY", "14145", "WYOMING");
    ZoneInformation zone1 = new ZoneInformation("Corn Rootworm Zones 2007", "East", "AE", "2007M", "");
    List zoneList = new ArrayList();
    zoneList.add(zone1);
    CustomerIds customerIds = new CustomerIds(50384953, "34356", "3367", "3557");

    GrowerDetails growerExpected = new GrowerDetails("1084", "JACK GEORGE ", "GEORGE", "JACK", customerIds, "Not Licensed", address,
            zoneList, 13674, "2335", "7164574103",max_eff, null);
    List mirIds = new ArrayList();
    mirIds.add(new Long(24546));
    mirIds.add(new Long(14346));
    mirIds.add(new Long(13436));
    growerExpected.setMirIds(mirIds);
    expected.add(growerExpected);

    assertEquals("results not as expected", expected, results);
  }

  public void testGetCustomerReviewNoMatch() {
    Date date = new GregorianCalendar(2007, Calendar.AUGUST, 2, 9, 13, 55).getTime();
    List results = customerReviewDao.getCustomerInformation(1061, date);
    List expected = new ArrayList();
    assertEquals("results not as expected", expected, results);
  }

  public void testGetCustomerReviewNoMatchesBasedOnTheDate() {
    Date date = new GregorianCalendar(2007, Calendar.AUGUST, 2, 9, 13, 55).getTime();
    List results = customerReviewDao.getCustomerInformation(106, date);
    List expected = new ArrayList();
    assertEquals("results not as expected", expected, results);
  }

  public void testGetCustomerReviewMultipleMatches() {
    Date date = new GregorianCalendar(2007, Calendar.JULY, 2, 9, 13, 55).getTime();
    List results = customerReviewDao.getCustomerInformation(12345, date);
    assertEquals(2, results.size());
  }

  public void testGetCustomerReviewV2() {
    Date date = new GregorianCalendar(2007, Calendar.JULY, 2, 9, 13, 55).getTime();
    Date max_eff = new GregorianCalendar(2007, Calendar.AUGUST, 1, 0, 0,
            0).getTime();
    List results = customerReviewDao.getCustomerInformationFmgr(106, date);

    List expected = new ArrayList();
    AddressInformation address = new AddressInformation("13520 SANDERS HILL RD", "STRYKERSVILLE", "NY", "14145", "WYOMING");
    ZoneInformation zone1 = new ZoneInformation("Corn Rootworm Zones 2007", "East", "AE", "2007M", "");
    List zoneList = new ArrayList();
    zoneList.add(zone1);
    CustomerIds customerIds = new CustomerIds(50384953,"34356", "3367", "3557");

    GrowerDetails growerExpected = new GrowerDetails("1084", "JACK GEORGE ", "GEORGE", "JACK", customerIds, "Not Licensed", address,
            zoneList, 13674, "2335", "7164574103",max_eff, null);
    List mirIds = new ArrayList();
    mirIds.add(new Long(24546));
    mirIds.add(new Long(14346));
    mirIds.add(new Long(13436));
    growerExpected.setMirIds(mirIds);
    expected.add(growerExpected);

    assertEquals("results not as expected", expected, results);
  }

  public void testGetCustomerReviewNoMatchV2() {
    Date date = new GregorianCalendar(2007, Calendar.AUGUST, 2, 9, 13, 55).getTime();
    List results = customerReviewDao.getCustomerInformationFmgr(1061, date);
    List expected = new ArrayList();
    assertEquals("results not as expected", expected, results);
  }

  public void testGetCustomerReviewNoMatchesBasedOnTheDateV2() {
    Date date = new GregorianCalendar(2007, Calendar.AUGUST, 2, 9, 13, 55).getTime();
    List results = customerReviewDao.getCustomerInformationFmgr(106, date);
    List expected = new ArrayList();
    assertEquals("results not as expected", expected, results);
  }

  public void testGetCustomerReviewMultipleMatchesV2() {
    Date date = new GregorianCalendar(2007, Calendar.JULY, 2, 9, 13, 55).getTime();
    List results = customerReviewDao.getCustomerInformationFmgr(12345, date);
    assertEquals(2, results.size());
  }

}
