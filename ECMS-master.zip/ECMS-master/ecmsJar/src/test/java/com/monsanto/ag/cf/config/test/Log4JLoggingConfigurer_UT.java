/*
 * Log4JLoggingConfigurer_UT was created on Mar 24, 2005 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.config.test;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.log4j.Level;

import com.dumbster.smtp.SimpleSmtpServer;
import com.dumbster.smtp.SmtpMessage;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Log4JLogging.Log4JClassSpecificLoggerFactory;
import com.monsanto.Log4JLogging.LoggingConfiguration;
import com.monsanto.ag.cf.config.Log4JLoggingConfigurer;
import com.monsanto.ag.soa.server.ServiceEndpoint;
import com.monsanto.ag.util.test.Log4JTestConfigurationHelper;

/**
 * Test the Log4JLoggingConfigurer
 * 
 * @author Gareth Davies
 * @version $Id: Log4JLoggingConfigurer_UT.java,v 1.1 2005/03/28 19:26:38 ggdavi
 *          Exp $
 */
public class Log4JLoggingConfigurer_UT extends TestCase {

  private String logFolder;
  private Log4JLoggingConfigurer configurer;
  private RandomAccessFile logFileAccessor;
  private String appName;

  public void setUp() throws Exception {
    Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty();
// If changing to use a directory then have to change the deleteLogFile method as well
//    logFolder = System.getProperty("catalina.base") + "/logs";
    logFolder = "";

    configurer = new Log4JLoggingConfigurer();
  }

  public void tearDown() throws Exception {
    if (logFileAccessor != null) {
      logFileAccessor.close();
    }

    Logger.closeLogging();
    configurer.destroy();

    deleteLogFile(appName + ".log");
    deleteLogFile(appName + ".xml");
  }

  private void deleteLogFile(String fileName) {
    File logFile = new File(logFolder + File.separator + fileName);
    if (logFile.exists() && !logFile.delete()) {
      System.err.println(logFolder + File.separator + fileName + " was not deleted!");
    }
  }

  public void testRegisterLoggerForOneDevice() throws Exception {
    appName = "test-ecms1";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.afterPropertiesSet();

    File logFile = new File(logFolder + File.separator + appName + ".log");
    assertTrue(appName + ".log file should exist", logFile.exists());
    File xmlFile = new File(logFolder + File.separator + appName + ".xml");
    assertFalse(appName + ".xml file should not exist", xmlFile.exists());
  }

  public void testRegisterLoggerForMultipleDevices() throws Exception {
    appName = "test-ecms2";
    configurer.setAppName(appName);
    configurer.setUseXmlLogDevice(true);
    configurer.setLogFolder(logFolder);
    configurer.afterPropertiesSet();

    File logFile = new File(logFolder + File.separator + appName + ".log");
    assertTrue(appName + ".log file should exist", logFile.exists());
    File xmlFile = new File(logFolder + File.separator + appName + ".xml");
    assertTrue(appName + ".xml file should exist", xmlFile.exists());
  }

  public void testRegisterLoggerForOneDeviceAndLogMessage() throws Exception {
    appName = "test-ecms3";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.afterPropertiesSet();

    String message = "Hello from testRegisterLoggerForOneDeviceAndLogMessage";
    Logger.log(new LoggableInfo(message));

    File logFile = new File(logFolder + File.separator + appName + ".log");
    logFileAccessor = new RandomAccessFile(logFile, "r");
    String firstLine = logFileAccessor.readLine();
    assertNotNull(
        appName + ".log should contain one line for the info message",
        firstLine);

//    assertEquals(appName + ".Info - " + message, firstLine.substring(32));
      System.out.println("firstLine=" + firstLine);
      assertTrue(firstLine.contains(appName + ".Info - " + message));
  }

  public void testRegisterMultipleLoggersForOneDeviceAndLogMessages()
      throws Exception {
    appName = "test-ecms4";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.afterPropertiesSet();

    String infoMessage = "Info from testRegisterMultipleLoggersForOneDeviceAndLogMessages";
    Logger.log(new LoggableInfo(infoMessage));
    String warnMessage = "Warning from testRegisterMultipleLoggersForOneDeviceAndLogMessages";
    Logger.log(new LoggableWarning(warnMessage));

    File logFile = new File(logFolder + File.separator + appName + ".log");
    logFileAccessor = new RandomAccessFile(logFile, "r");
    String firstLine = logFileAccessor.readLine();
    assertNotNull(
        appName + ".log should contain one line for the info message",
        firstLine);
//    assertEquals(appName + ".Info - " + infoMessage, firstLine.substring(32));

    System.out.println("firstLine=" + firstLine);
    assertTrue(firstLine.contains(appName + ".Info - " + infoMessage));

    String nextLine = logFileAccessor.readLine();
    assertNotNull(appName
        + ".log should contain a second line for the warning message", nextLine);
//    assertEquals(appName + ".Warning - " + warnMessage, nextLine.substring(32));

    System.out.println("nextLine=" + nextLine);
    assertTrue(nextLine.contains(appName + ".Warning - " + warnMessage));
  }

  public void testTraceStatementsWithoutTracingEnabledDoNothing()
      throws Exception {
    appName = "test-ecms5";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.afterPropertiesSet();

    File traceFile = new File(logFolder + File.separator + appName + ".log");
    assertTrue(appName + ".log file should exist", traceFile.exists());

    Logger.traceEntry();
    assertTrue("Nothing is logged to " + appName
        + ".log if tracing not enabled", traceFile.length() == 0);
  }

  public void testTraceStatementsWithTracingEnabled() throws Exception {
    appName = "test-ecms6";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.setTracingOn(true);
    configurer.afterPropertiesSet();

    File traceFile = new File(logFolder + File.separator + appName + ".log");
    assertTrue(appName + ".log file should exist", traceFile.exists());

    Logger.traceEntry(new Object[] { "Input Value", new Boolean(true),
        new Double(3.14159) });
    Logger.traceExit("Output Value");

    logFileAccessor = new RandomAccessFile(traceFile, "r");
    String firstLine = logFileAccessor.readLine();
    assertNotNull(appName
        + ".log should contain one line for the trace entry message", firstLine);
    String expectedTraceMessage = appName + ".Trace - Entering "
        + this.getClass().getName();
    System.out.println("firstLine=" + firstLine);
    System.out.println("expected =" + expectedTraceMessage);
    assertTrue("First line should be trace entry message", StringUtils
        .contains(firstLine, expectedTraceMessage));
    assertTrue("Trace entry message includes argument values", firstLine
        .endsWith("Arguments {Input Value, true, 3.14159}"));

    String nextLine = logFileAccessor.readLine();
    assertNotNull(appName
        + ".log should contain another line for the trace exit message",
        nextLine);
    //MAS 1-26-08: Message from common Monsanto class 
    // com.monsanto.AbstractLogging.Logger upon leaving the method
    // was apparently changed to have an extra space after "Leaving".
    expectedTraceMessage = appName + ".Trace - Leaving  "
        + this.getClass().getName();
    assertTrue("Next line should be trace exit message", StringUtils.contains(
        nextLine, expectedTraceMessage));
    assertTrue("Trace exit message includes return value", nextLine
        .endsWith("RetVal = 'Output Value'"));
  }

  public void testSetDefaultLoggingLevelForPackages() throws Exception {
    List defaultLevelPackages = new ArrayList();
    defaultLevelPackages.add("org.apache");
    defaultLevelPackages.add("com.monsanto.ag");

    appName = "test-ecms7";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.setDefaultLevel("WARN");
    configurer.setDefaultLevelPackages(defaultLevelPackages);
    configurer.afterPropertiesSet();

    org.apache.log4j.Logger logger = org.apache.log4j.Logger
        .getLogger("org.apache");
    assertEquals(Level.WARN, logger.getLevel());
    logger = org.apache.log4j.Logger.getLogger("com.monsanto.ag");
    assertEquals(Level.WARN, logger.getLevel());
  }

  public void testSetBadDefaultLoggingLevelUsesDefault() throws Exception {
    List defaultLevelPackages = new ArrayList();
    defaultLevelPackages.add("org.apache");

    appName = "test-ecms8";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.setDefaultLevel("BAD");
    configurer.setDefaultLevelPackages(defaultLevelPackages);
    configurer.afterPropertiesSet();

    org.apache.log4j.Logger logger = org.apache.log4j.Logger
        .getLogger("org.apache");
    assertEquals(Level.INFO, logger.getLevel());
  }

  public void testChangePackageLoggingLevel() throws Exception {
    LoggingConfiguration loggingConfig = new LoggingConfiguration("test-ecms",
        Level.INFO, Level.DEBUG, Level.INFO, Level.INFO);
    org.apache.log4j.Logger logger = Log4JClassSpecificLoggerFactory.getLogger(
        ServiceEndpoint.class, loggingConfig);
    assertEquals(Level.INFO, logger.getLevel());

    Log4JClassSpecificLoggerFactory.changeLoggingLevel("test-ecms",
        "com.monsanto.ag.soa", Level.DEBUG);
    assertEquals(Level.DEBUG, logger.getLevel());

    logger = Log4JClassSpecificLoggerFactory
        .getLogger(Log.class, loggingConfig);
    assertEquals(Level.INFO, logger.getLevel());

    Log4JClassSpecificLoggerFactory.changeLoggingLevel("test-ecms",
        "org.apache.commons.logging", Level.WARN);
    assertEquals(Level.WARN, logger.getLevel());
  }

  public void testSendEmailNotificationOfErrors() throws Exception {
    appName = "test-ecms9";
    configurer.setAppName(appName);
    configurer.setLogFolder(logFolder);
    configurer.setErrorEmailSmtpHost("localhost");
    configurer.setErrorEmailSmtpPort(2525);
    configurer.setErrorEmailRecipientList("app.admin@monsanto.com");
    configurer.afterPropertiesSet();

    SimpleSmtpServer server = SimpleSmtpServer.start(2525);
    Logger.log(new LoggableError("An error occurred!"));
    server.stop();

    assertEquals(1, server.getReceivedEmailSize());
    Iterator inbox = server.getReceivedEmail();
    SmtpMessage message = (SmtpMessage) inbox.next();

    assertEquals("app.admin@monsanto.com", message.getHeaderValue("To"));
    assertEquals(appName + " Error", message.getHeaderValue("Subject"));
    assertTrue("Message contains error text", message.getBody().indexOf(
        appName + ".Error - An error occurred!") >= 0);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.10.6.1  2008/01/26 22:32:15  maschec
 * Fix failing test
 *
 * Revision 1.10  2006/01/24 18:56:18  ggdavi
 * Moved ChunkableServiceEndpoint, SecureService, ServiceAdvice and ServiceEndpoint from com.monsanto.ag.soa to com.monsanto.ag.soa.server. This will simplify the class exclusion process for consumer classes only interested in ag.soa.client classes.
 *
 * Revision 1.9  2005/08/26 15:33:01  ggdavi
 * Added tracingOn property to the Log4JLoggingConfigurer to enable and disable AbstractLogging tracing
 * Revision 1.8 2005/08/23 21:19:58
 * ggdavi Cleaned up imports
 * 
 * Revision 1.7 2005/08/23 17:13:33 ggdavi Renamed Service to ServiceEndpoint to
 * emphasize SOAP affiliation
 * 
 * Revision 1.6 2005/08/18 12:30:07 ggdavi All relevant test case setUp methods
 * now use the Log4JTestConfigurationHelper.setCatalinaBaseSystemProperty method
 * to ensure a valid value exists for the catalina.base system property required
 * by the log4j.properties file.
 * 
 * Revision 1.5 2005/08/17 14:58:21 caggarw Removed hardcoded value of
 * log_folder and used values of catalina.base or catalina.home System property
 * instead
 * 
 * Revision 1.4 2005/08/02 20:57:38 ggdavi Modified service interfaces,
 * implementations and advice to support message/document chunking
 * 
 * Revision 1.3 2005/06/30 17:43:26 ggdavi Moved ag.aop, ag.config and
 * ag.message packages under the ag.cf package
 * 
 * Revision 1.4 2005/06/21 15:53:54 ggdavi Corrected test after removing
 * dependency on Apache Axis
 * 
 * Revision 1.3 2005/06/20 21:20:57 ggdavi Removed spurious dependency on Apache
 * Axis
 * 
 * Revision 1.2 2005/05/25 21:05:09 ggdavi Removed JaxRpcMessageEcho class...
 * 
 * Revision 1.1 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.1 2005/04/07 15:40:32 ggdavi Moved from web to config package
 * Revision 1.1 2005/03/28 19:26:38 ggdavi Initial version
 * 
 */