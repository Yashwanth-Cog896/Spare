/*
 Copyright:  Copyright 2012 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ag.cf.dao.test;

import com.monsanto.ag.cf.dao.jdbc.JdbcCreditControlAreaDao;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.object.MappingSqlQuery;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class JdbcCreditControlAreaDao_UT {
    private JdbcCreditControlAreaDao jdbcCreditControlAreaDao;
    private MappingSqlQuery query;
    private PreparedStatement stmt;
    private ResultSet rs;

    @Before
    public void runBeforeEachUnitTest() {
        query = mock(MappingSqlQuery.class);
        stmt = mock(PreparedStatement.class);
        rs = mock(ResultSet.class);
        DataSource ds = mock(DataSource.class);
        jdbcCreditControlAreaDao = new JdbcCreditControlAreaDao();
        jdbcCreditControlAreaDao.setDataSource(ds);
    }

    @Test
    public void getGrowerIdsInCreditControlArea5180_ReturnsEmptyListWhenNoGrowersFound() throws SQLException {
        assertTrue("List should be empty.", jdbcCreditControlAreaDao
              .getGrowerIdsInCreditControlArea(query, JdbcCreditControlAreaDao.INT_CREDIT_CTRL_AREA_CODE).isEmpty());
    }

    @Test
    public void getGrowerIdsInCreditControlArea5180_ReturnsNonEmptyListWhenGrowersFound() throws SQLException {
        List nonEmptyList = new ArrayList();
        nonEmptyList.add(new Object());
        when(stmt.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true);
        when(query.execute()).thenReturn(nonEmptyList);

        assertFalse("List should not be empty.", jdbcCreditControlAreaDao
              .getGrowerIdsInCreditControlArea(query, JdbcCreditControlAreaDao.INT_CREDIT_CTRL_AREA_CODE).isEmpty());
    }
}
