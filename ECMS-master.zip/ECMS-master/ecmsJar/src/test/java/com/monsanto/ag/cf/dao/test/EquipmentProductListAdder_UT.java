package com.monsanto.ag.cf.dao.test;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.ChemicalEquipment;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.ag.cf.domain.SeedEquipment;
import com.monsanto.ag.cf.dao.EquipmentProductListAdder;

import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/23/13
 * Time: 12:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class EquipmentProductListAdder_UT {

    private List list;
    private PersistentStoreResultSetFwdIterator iterator;
    private static EquipmentProductListAdder listAdder;

    @BeforeClass
    public static void runBeforeAllTests() throws WrappingException {

        listAdder = new EquipmentProductListAdder();
    }

    @Before
    public void runBeforeEachTest() throws WrappingException {

        list = mock( List.class );
        iterator = mock( PersistentStoreResultSetFwdIterator.class );

        when( iterator.getTimestamp( "row_entry_date" ) ).thenReturn( new Date() );
        when( iterator.getTimestamp( "update_date" ) ).thenReturn( new Date() );
        when( iterator.getString( "unrec20_base_uom_code" ) ).thenReturn( "an String" );
        when( iterator.getString( "base_quantity" ) ).thenReturn( "1.1" );
        when( iterator.getString( "gtin" ) ).thenReturn( "12345678901234" );
        when( iterator.getString( "unrec20_rr_uom_code" ) ).thenReturn( "an String" );
        when( iterator.getString( "universal_prod_code" ) ).thenReturn( "a" );
    }

    @Test
    public void testAddProductToListForSeedEquipment() throws WrappingException{

        when( iterator.getString( "mkt_seg_code" ) ).thenReturn( "ST" );

        Product addedProduct = listAdder.addProductToList( list, iterator, null );
        Assert.assertTrue( addedProduct instanceof SeedEquipment );
        verify( list ).add( any( SeedEquipment.class ) );
    }

    @Test
    public void testAddProductToListNullLastProductRetrieved() throws WrappingException {

        when( iterator.getString( "mkt_seg_code" ) ).thenReturn( "CH" );

        Product addedProduct = listAdder.addProductToList( list, iterator, null );
        Assert.assertTrue( addedProduct instanceof ChemicalEquipment );
        verify( list ).add( any( ChemicalEquipment.class ) );
    }
}