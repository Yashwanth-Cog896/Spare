package com.monsanto.ag.cf.dao.test;

import com.monsanto.ag.cf.dao.AGIISProductQueryBuilder;
import com.monsanto.ag.cf.dao.ProductQueryBuilder;
import com.monsanto.ag.cf.domain.Product;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: PPVASI
 * Date: Jul 21, 2011
 * Time: 1:43:55 PM
 */
public class AGIISProductQueryBuilder_UT {

    private static final Timestamp LAST_MODIFIED_DATE = new Timestamp(new GregorianCalendar(2005, Calendar.MARCH, 23,
      13, 59, 4).getTime().getTime());

    private static final String STATIC_QUERY =  "SELECT distinct p.prod_id,\n" +
                    "pbms.mkt_seg_code,\n" +
                    "p.prod_class_code product_class_id,\n" +
                    "uomxref_rr.alias_unrec20_uom_code unrec20_rr_uom_code,\n" +
                    "pps.universal_prod_Code,\n" +
                    "pps.upc_scc_code GTIN,\n" +
                    "scb.descr seed_company_brand_name,\n" +
                    "p.acronym_name acronym,\n" +
                    "t.sdescr biotech_trait,\n" +
                    "smc.special_treatment_code treatment_code,\n" +
                    "tr.descr treatment_descr,\n" +
                    "DECODE (p.prod_class_code,\n" +
                    "        'H',\n" +
                    "        pc.descr,\n" +
                    "        'D',\n" +
                    "        tc.display_descr,\n" +
                    "        'N',\n" +
                    "        'N/A')\n" +
                    "   display_descr,\n" +
                    "p.species_code,\n" +
                    "tl.license_required license_req_flag,\n" +
                    "tg.trait_group_id license_trait_grp_id,\n" +
                    "DECODE (tolerance.trait_code, NULL, 'N', 'Y') irm_flag,\n" +
                    "DECODE (p.prod_status_code, 'AC', 'Y', 'N') prod_active_flag,\n" +
                    "p.ec_list_flag,\n" +
                    "greatest(p.row_modify_date, pps.row_modify_date, nvl(mpl.row_modify_date,p.row_modify_date)) update_date,\n" +
                    "p.row_entry_date row_entry_date,\n" +
                    "p.legal_descr_1,\n" +
                    "p.legal_descr_2,\n" +
                    "pkg.descr description_text,\n" +
                    "p.base_quantity,\n" +
                    "uomxref_base.alias_unrec20_uom_code unrec20_base_uom_code,\n" +
                    "p.use_ssu,\n" +
                    "smc.grade_size_desc,\n" +
                    "DECODE (p.prod_status_code, 'AC', 'Y', 'N') pkg_active_flag,\n" +
                    "pps.quantity_of_base_package,\n" +
                    "pps.quantity_of_child_package,\n" +
                    "pps.calculated_volume,\n" +
                    "pps.gross_weight,\n" +
                    "pps.tare_weight,\n" +
                    "pps.net_weight,\n" +
                    "pps.LENGTH,\n" +
                    "pps.width,\n" +
                    "pps.height,\n" +
                    "pps.square_feet,\n" +
                    "pps.cubic_feet,\n" +
                    "pps.stacking_height,\n" +
                    "DECODE (p.prod_status_code, 'AC', 'Y', 'N') pkgcnfg_active_flag,\n" +
                    "NVL (prssr.processor_code, 'N') processor_code,\n" +
                    "--Commented group codes are in ECC, but seed trak and AGIIS are ignoring these\n" +
                    "Case\n" +
                    "   -- Rules for Cotton\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GT010' \n" +
                    "       AND MPL.SPECIES_CODE = 'T'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = 'DV'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '30'\n" +
                    "       THEN '38'\n" +
                    "   -- Rules for SORGHUM\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GS010' \n" +
                    "       AND MPL.SPECIES_CODE = 'S'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = '87'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '15'\n" +
                    "       THEN '50'\n" +
                    "   -- Rules for CANOLA\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GL012' \n" +
                    "       AND MPL.SPECIES_CODE = 'L'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = 'CZ'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '15'\n" +
                    "       THEN '45'\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GL010' \n" +
                    "       AND MPL.SPECIES_CODE = 'L'\n" +
                    "       --AND MPL.PACKAGE_SIZE_CODE = '87'  --NO Package size code rule\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '06'\n" +
                    "       THEN '20'\n" +
                    "   ---Rules for CORN\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GC010' \n" +
                    "       AND MPL.SPECIES_CODE = 'C'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = 'CZ'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '15'\n" +
                    "       THEN '45'\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GC010' \n" +
                    "       AND MPL.SPECIES_CODE = 'C'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = '87'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '15'\n" +
                    "       THEN '50'\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GC010' \n" +
                    "       AND MPL.SPECIES_CODE = 'C'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = '29'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '15'\n" +
                    "       THEN '40'\n" +
                    "   --When MPL.MAT_GROUP_CODE = 'GC010' \n" +
                    "       --AND MPL.SPECIES_CODE = 'C'\n" +
                    "       --AND MPL.PACKAGE_SIZE_CODE = '21'  \n" +
                    "       --AND MPL.PACKAGE_TYPE_CODE = '00'\n" +
                    "       --THEN '2'\n" +
                    "   ---Rules for BEAN\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GB010' \n" +
                    "       AND MPL.SPECIES_CODE = 'B'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = 'EB'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '06'\n" +
                    "       THEN '40'\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GB010' \n" +
                    "       AND MPL.SPECIES_CODE = 'B'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = '87'\n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '15'\n" +
                    "       THEN '50'\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GB010' \n" +
                    "       AND MPL.SPECIES_CODE = 'B'\n" +
                    "       AND MPL.PACKAGE_SIZE_CODE = '29'  \n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '06'\n" +
                    "       THEN '40'\n" +
                    "   --When MPL.MAT_GROUP_CODE = 'GB010' \n" +
                    "       --AND MPL.SPECIES_CODE = 'B'\n" +
                    "       --AND MPL.PACKAGE_SIZE_CODE = '29'\n" +
                    "       --AND MPL.PACKAGE_TYPE_CODE = '65'\n" +
                    "       --THEN '1000'\n" +
                    "   When MPL.MAT_GROUP_CODE = 'GB010' \n" +
                    "       --AND MPL.SPECIES_CODE = 'B'\n" +
                    "       --AND MPL.PACKAGE_SIZE_CODE = '21'  \n" +
                    "       AND MPL.PACKAGE_TYPE_CODE = '06'\n" +
                    "       THEN '40'\n" +
                    "   --When MPL.MAT_GROUP_CODE = 'GB010' \n" +
                    "       --AND MPL.SPECIES_CODE = 'B'\n" +
                    "       --AND MPL.PACKAGE_SIZE_CODE = '29'\n" +
                    "       --AND MPL.PACKAGE_TYPE_CODE = '01'\n" +
                    "       --THEN '1000'            \n" +
                    "       ELSE '1'\n" +
                    " END UNIT_QTY,\n" +
                    "spd.order_uom_id,\n" +
                    "b.brand_code,\n" +
                    "b.descr  brand_descr,\n" +
                    "p.epa_reg_num\n" +
                "FROM s_prod p,\n" +
                    "s_prod_xref px,\n" +
                    "s_prod_package_struct pps,\n" +
                    "s_package pkg,\n" +
                    "s_prod_acct_usage pau,\n" +
                    "(SELECT   prod_id, mkt_seg_code\n" +
                    "   FROM   s_prod_by_mkt_seg\n" +
                    "  WHERE   mkt_seg_code IN ('ST', 'CH')) pbms,\n" +
                    "s_trait t,\n" +
                    "s_prod_to_trait_license ptl,\n" +
                    "s_trait_license tl,\n" +
                    "s_trait_license_group tlg,\n" +
                    "s_trait_group tg,\n" +
                    "s_trait_category tc,\n" +
                    "s_seed_mat_char smc,\n" +
                    "s_treatment tr,\n" +
                    "s_seed_company_brand scb,\n" +
                    "s_master_prod_list mpl,\n" +
                    "(  SELECT   tta.trait_code,\n" +
                    "            MAX (ta.processor_type_code) processor_code\n" +
                    "     FROM   s_trait_to_trait_attr tta, s_trait_attr ta\n" +
                    "    WHERE   ta.trait_attr_id = tta.trait_attr_id\n" +
                    " GROUP BY   tta.trait_code) prssr,\n" +
                    "(SELECT   DISTINCT bp.prod_id,\n" +
                    "                   bp.active_flag,\n" +
                    "                   bp.eff_end_date,\n" +
                    "                   bp.base_rate\n" +
                    "   FROM   cdw.base_price_mv bp, s_prod p\n" +
                    "  WHERE   p.prod_id = bp.prod_id AND p.prod_class_code = 'H') bp,\n" +
                    "s_ird_parameter ip,\n" +
                    "dsrbase.material m,\n" +
                    "s_prod_chem pc,\n" +
                    "s_brand b,\n" +
                    "s_chem_family cf,\n" +
                    "s_seed_species_to_base_uom ssbu,\n" +
                    "dm_seed_product_dim spd,\n" +
                    "(SELECT   DISTINCT uom_code, alias_unrec20_uom_code FROM s_uom_xref)\n" +
                    "uomxref_rr,\n" +
                    "(SELECT   DISTINCT uom_code, alias_unrec20_uom_code FROM s_uom_xref)\n" +
                    "uomxref_base,\n" +
                    "(SELECT   DISTINCT tta.trait_code, tolerance_code\n" +
                    "   FROM   s_trait_to_trait_attr tta, s_trait_attr ta\n" +
                    "  WHERE   tta.trait_attr_id = ta.trait_attr_id\n" +
                    "          AND tolerance_code = 'I') tolerance\n" +
                "WHERE prod_status_code = 'AC'\n" +
                    "AND p.prod_id = px.prod_id\n" +
                    "AND px.system_type_code = 'SAP'\n" +
                    "AND px.active_flag = 'Y'\n" +
                    "AND px.alias_prod_code = m.material_id(+)\n" +
                    "AND (px.uom_code = pps.uom_code OR px.uom_code = p.base_uom_code)\n" +
                    "AND p.prod_id = pps.prod_id\n" +
                    "AND pps.uom_code = uomxref_rr.uom_code\n" +
                    "AND p.base_uom_code = uomxref_base.uom_code\n" +
                    "AND p.prod_id = pau.prod_id(+)\n" +
                    "AND pau.RANK(+) = 1\n" +
                    "AND (pps.universal_prod_Code IS NOT NULL\n" +
                    "     OR pps.upc_scc_code IS NOT NULL)\n" +
                    "AND p.package_code = pkg.package_code\n" +
                    "AND p.prod_id = pbms.prod_id(+)\n" +
                    "AND p.brand_code = b.brand_code\n" +
                    "AND b.major_prod_chem_code = pc.prod_chem_code\n" +
                    "AND pc.chem_family_code = cf.chem_family_code\n" +
                    "AND p.prod_id = ptl.prod_id(+)\n" +
                    "AND ptl.trait_license_id = tl.trait_license_id(+)\n" +
                    "AND ptl.trait_license_id = tlg.trait_license_id(+)\n" +
                    "AND tlg.trait_group_id = tg.trait_group_id(+)\n" +
                    "AND tl.trait_code = t.trait_code(+)\n" +
                    "AND t.trait_code = prssr.trait_code(+)\n" +
                    "AND t.trait_code = tolerance.trait_code(+)\n" +
                    "AND t.trait_category_id = tc.trait_category_id(+)\n" +
                    "AND px.alias_prod_code = smc.seed_mat_char_id(+)\n" +
                    "AND smc.special_treatment_code = tr.treatment_code(+)\n" +
                    "AND pau.seed_company_brand_id = scb.seed_company_brand_id(+)\n" +
                    "AND p.prod_id = spd.product_id(+)\n" +
                    "AND p.base_uom_code = ssbu.base_uom_code(+)\n" +
                    "AND p.species_code = ssbu.species_code(+)\n" +
                    "AND ssbu.order_uom_code(+) = 'SS'\n" +
                    "AND p.prod_id = mpl.prod_id(+)\n" +
                    "AND p.prod_id = bp.prod_id(+)\n" +
                    "AND ip.ird_parameter_code = 'SEED_YEAR'";

    private static final String ORDER_BY_CLAUSE = " ORDER BY p.acronym_name, smc.special_treatment_code, b.brand_code, p.prod_id, uomxref_rr.alias_unrec20_uom_code";

    private static final String LAST_MODIFIED_CLAUSE = " AND greatest(p.row_modify_date, pps.row_modify_date, nvl(mpl.row_modify_date,p.row_modify_date)) > ?";

    private static final String SEGMENT_SEED_CLAUSE = " AND ((p.prod_class_code = 'D' AND p.prod_id = mpl.prod_id AND mpl.year = ip.numeric_value) OR (p.prod_class_code = 'N' AND m.material_type = 'VERP')) AND pbms.mkt_seg_code = 'ST'";

    private static final String SEGMENT_CHEMICAL_CLAUSE = " AND p.prod_class_code = 'H' AND p.prod_id = bp.prod_id AND bp.active_flag = 'Y'\n"+
                                                          "AND bp.eff_end_date > SYSDATE AND bp.base_rate <> 0-- AND pbms.mkt_seg_code = 'CH'\n";

    private static final String SEGMENT_ALL_CLAUSE = " AND ((p.prod_class_code = 'D' AND p.prod_id = mpl.prod_id AND mpl.year = ip.numeric_value) OR (p.prod_class_code = 'H' AND p.prod_id = bp.prod_id AND bp.active_flag = 'Y'\n"+
                                                          "AND bp.eff_end_date > SYSDATE AND bp.base_rate <> 0) OR (p.prod_class_code = 'N' AND m.material_type = 'VERP'))";

    ProductQueryBuilder queryBuilder;

    @Test
    public void queryWithDateAndSeedCategory() {
        // Assign
        queryBuilder = new AGIISProductQueryBuilder(LAST_MODIFIED_DATE, Product.SEGMENT_SEED, null);

        // Act
        queryBuilder.createNewProductQuery();
        queryBuilder.buildQuery();

        // Assert
        assertEquals(STATIC_QUERY+LAST_MODIFIED_CLAUSE+SEGMENT_SEED_CLAUSE+ORDER_BY_CLAUSE, queryBuilder.getProductQuery().getQuery());
    }

    @Test
    public void queryWithDateAndChemicalCategory() {
        // Assign
        queryBuilder = new AGIISProductQueryBuilder(LAST_MODIFIED_DATE, Product.SEGMENT_CHEMICAL, null);

        // Act
        queryBuilder.createNewProductQuery();
        queryBuilder.buildQuery();

        // Assert
        assertEquals(STATIC_QUERY+LAST_MODIFIED_CLAUSE+SEGMENT_CHEMICAL_CLAUSE+ORDER_BY_CLAUSE, queryBuilder.getProductQuery().getQuery());
    }

    @Test
    public void queryWithDateAndAllCategory() {
        // Assign
        queryBuilder = new AGIISProductQueryBuilder(LAST_MODIFIED_DATE, Product.SEGMENT_ALL, null);

        // Act
        queryBuilder.createNewProductQuery();
        queryBuilder.buildQuery();

        // Assert
        assertEquals(STATIC_QUERY+LAST_MODIFIED_CLAUSE+SEGMENT_ALL_CLAUSE+ORDER_BY_CLAUSE, queryBuilder.getProductQuery().getQuery());
    }

    @Test
    public void queryWithOutDateAndSeedCategory() {
        // Assign
        queryBuilder = new AGIISProductQueryBuilder(null, Product.SEGMENT_SEED, null);

        // Act
        queryBuilder.createNewProductQuery();
        queryBuilder.buildQuery();

        // Assert
        assertEquals(STATIC_QUERY+SEGMENT_SEED_CLAUSE+ORDER_BY_CLAUSE, queryBuilder.getProductQuery().getQuery());
    }

    @Test(expected = IllegalArgumentException.class)
    public void queryWithInvalidCategory() {
        // Assign
        queryBuilder = new AGIISProductQueryBuilder(null, "TEST", null);

        // Act
        queryBuilder.createNewProductQuery();
        queryBuilder.buildQuery();

        // Assert        
    }
}
