/*
 * JdbcEventDao_UT was created on May 6, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.springframework.dao.DataIntegrityViolationException;

import com.monsanto.ag.cf.dao.jdbc.JdbcEventDao;
import com.monsanto.ag.cf.domain.SystemEvent;

/**
 * Test storing system event information using the JdbcEventDao.
 * 
 * @author Gareth Davies
 * @version $Id: JdbcEventDao_UT.java,v 1.7 2005-07-25 20:57:51 ggdavi Exp $
 */
public class JdbcEventDao_UT extends BaseDbUnitTestCase {

  public void testFindExistingEventByConversationIdAndStatusCode() {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());

    List events = eventDao.findEventsByConversationIdAndStatusCode(
        "8y+R/KP0pArOJRPoTwU0BA==", "DataAccessSuccess");
    assertNotNull("Must return a valid list of events", events);
    assertEquals(1, events.size());

    Date eventDate = new GregorianCalendar(2005, Calendar.MAY, 1, 16, 20, 24)
        .getTime();
    SystemEvent expectedEvent = new SystemEvent("bob", 789L,
        "8y+R/KP0pArOJRPoTwU0BA==", eventDate, "DataAccessSuccess",
        "We saved an event earlier");
    expectedEvent.setId("-1");
    assertEquals(expectedEvent, events.get(0));
  }

  public void testFindExistingEventWithNonMatchingConversationIdOrStatusCode() {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());

    List events = eventDao.findEventsByConversationIdAndStatusCode(
        "8y+R/KP0pArOJRPoTwU0BA==", "NoMatch");
    assertNotNull("Must return a valid list of events", events);
    assertEquals(0, events.size());

    events = eventDao.findEventsByConversationIdAndStatusCode(
        "8y+R/KP0pArOJRPoTwU0BA==", null);
    assertNotNull("Must return a valid list of events", events);
    assertEquals(0, events.size());

    events = eventDao.findEventsByConversationIdAndStatusCode("NoMatch",
        "DataAccessSuccess");
    assertNotNull("Must return a valid list of events", events);
    assertEquals(0, events.size());

    events = eventDao.findEventsByConversationIdAndStatusCode(null,
        "DataAccessSuccess");
    assertNotNull("Must return a valid list of events", events);
    assertEquals(0, events.size());
  }

  public void testStoreSystemEvent() throws Exception {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());
    eventDao.setSequenceName("data_exchange_event_seq");

    Date eventDate = new GregorianCalendar(2005, Calendar.MAY, 2, 9, 13, 55)
        .getTime();
    SystemEvent event = new SystemEvent("bob", 789L, "YjEih7/pZgFTQJnBMHA=",
        eventDate, "DataAccessSuccess", "We saved an event!");
    eventDao.storeEvent(event);

    IDataSet expectedDataSet = getDataSet("testStoreSystemEvent");
    ITable expectedTable = expectedDataSet.getTable("DATA_EXCHANGE_EVENT");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
        expectedTable, "SELECT * FROM DATA_EXCHANGE_EVENT");
    Assertion.assertEquals(expectedTable, actualTable);
  }

  public void testStoreSystemEventWithOverlongStatusMessage() throws Exception {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());
    eventDao.setSequenceName("data_exchange_event_seq");

    Date eventDate = new GregorianCalendar(2005, Calendar.MAY, 2, 9, 13, 55)
        .getTime();
    String statusMessage = "We saved an event that has an excessively long"
        + " status message which really cannot fit in the database column since"
        + " Don wisely decided to limit the size of that column to only 255"
        + " characters for reasons best known to himself and of course"
        + " he is not here now to explain why.";
    SystemEvent event = new SystemEvent("bob", 789L, "YjEih7/pZgFTQJnBMHA=",
        eventDate, "DataAccessSuccess", statusMessage);
    eventDao.storeEvent(event);

    IDataSet expectedDataSet = getDataSet("testStoreSystemEventWithOverlongStatusMessage");
    ITable expectedTable = expectedDataSet.getTable("DATA_EXCHANGE_EVENT");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
        expectedTable, "SELECT * FROM DATA_EXCHANGE_EVENT");
    Assertion.assertEquals(expectedTable, actualTable);
  }

  public void testStoreSystemEventWithoutOptionalFields() throws Exception {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());
    eventDao.setSequenceName("data_exchange_event_seq");

    SystemEvent event = new SystemEvent("bob", 789L, "YjEih7/pZgFTQJnBMHA=",
        null, null, null);
    eventDao.storeEvent(event);

    IDataSet expectedDataSet = getDataSet("testStoreSystemEventWithoutOptionalFields");
    ITable expectedTable = expectedDataSet.getTable("DATA_EXCHANGE_EVENT");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
        expectedTable, "SELECT * FROM DATA_EXCHANGE_EVENT");
    Assertion.assertEquals(expectedTable, actualTable);
  }

  public void testStoreEventWithoutSequenceNameThrowsException()
      throws Exception {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());

    try {
      SystemEvent event = new SystemEvent("bob", 789L, "YjEih7/pZgFTQJnBMHA=",
          new Date(), "DataAccessSuccess", "We saved an event!");
      eventDao.storeEvent(event);
      fail("Should throw DataIntegrityViolationException");
    } catch (DataIntegrityViolationException IGNORE) {
    }

    IDataSet expectedDataSet = getDataSet("initial");
    ITable expectedTable = expectedDataSet.getTable("DATA_EXCHANGE_EVENT");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
        expectedTable, "SELECT * FROM DATA_EXCHANGE_EVENT");
    Assertion.assertEquals(expectedTable, actualTable);
  }

  public void testStoreEventWithMissingRequiredFieldsThrowsException()
      throws Exception {
    JdbcEventDao eventDao = new JdbcEventDao();
    eventDao.setDataSource(getDataSource());
    eventDao.setSequenceName("data_exchange_event_seq");

    try {
      SystemEvent event = new SystemEvent();
      eventDao.storeEvent(event);
      fail("Should throw DataIntegrityViolationException");
    } catch (DataIntegrityViolationException IGNORE) {
    }

    IDataSet expectedDataSet = getDataSet("initial");
    ITable expectedTable = expectedDataSet.getTable("DATA_EXCHANGE_EVENT");
    ITable actualTable = getActualTableBasedOnExpectedTableColumns(
        expectedTable, "SELECT * FROM DATA_EXCHANGE_EVENT");
    Assertion.assertEquals(expectedTable, actualTable);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.6  2005/07/08 17:15:39  ggdavi
 * Modified SystemEventMappingQuery SQL to include the Acct_Id column from the DATA_EXCHANGE_LOG table
 * Revision 1.5 2005/07/06 21:49:36 ggdavi Only
 * store the first 255 characters of the status message Revision 1.4 2005/06/10
 * 20:46:42 ggdavi Primary key of existing record is now a negative number
 * 
 * Revision 1.3 2005/05/11 19:17:17 ggdavi Added
 * findEventsByConversationIdAndStatusCode method Revision 1.2 2005/05/09
 * 20:30:02 ggdavi Use new getActualTable method where appropriate
 * 
 * Revision 1.1 2005/05/09 18:05:29 ggdavi Initial version
 * 
 */