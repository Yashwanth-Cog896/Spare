/*
 * TraceInterceptor_UT was created on Apr 6, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.aop.test;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.aopalliance.intercept.MethodInvocation;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.Test.MockTraceLog;
import com.monsanto.ag.cf.aop.TraceInterceptor;

/**
 * Test the TraceInterceptor.
 * 
 * @author Gareth Davies
 * @version $Id: TraceInterceptor_UT.java,v 1.2 2008-01-29 23:42:34 maschec Exp $
 */
public class TraceInterceptor_UT extends TestCase {

  private static final String TRACEABLE_CLASS_NAME = "com.monsanto.ag.cf.aop.test.TraceInterceptor_UT$MockTraceableClass";

  //MAS 1-26-08: Message from common Monsanto class 
  // com.monsanto.AbstractLogging.Logger upon leaving the method
  // was apparently changed to have an extra space. This constant
  // will make it easy to make the tests work regardless of whether
  // it is left like this or is changed back to a single space.
  private static final String MSG_LEAVING_SPACE = "Leaving  ";
  
  private MockTraceLog traceLog;

  public void setUp() throws Exception {
    Logger.enableTrace();

    traceLog = new MockTraceLog();
    Logger.register(traceLog, true); // Enable trace logger.
  }

  public void tearDown() {
    Logger.disableTrace();
    Logger.closeLogging();
  }

  public void testTraceMethodWithNoArgumentsOrReturnType() throws Throwable {
    MockMethodInvocation invocation = new MockMethodInvocation(
        "noArgsOrReturnType", null, null);

    TraceInterceptor tracer = new TraceInterceptor();
    Object retVal = tracer.invoke(invocation);

    assertNull("Return value should be null", retVal);
    assertEquals(2, traceLog.messagesReceived());
    assertTrue(traceLog.hasMessageBeenLoggedContaining("Entering public void "
        + TRACEABLE_CLASS_NAME + ".noArgsOrReturnType() Arguments {}"));
    assertTrue(traceLog.hasMessageBeenLoggedContaining(MSG_LEAVING_SPACE 
        + "public void "
        + TRACEABLE_CLASS_NAME + ".noArgsOrReturnType() RetVal = '<null>'"));
  }

  public void testTraceMethodWithPrimitiveArgument() throws Throwable {
    MockMethodInvocation invocation = new MockMethodInvocation("primitiveArgument",
        new Class[] { int.class }, new Object[] { new Integer(42) });

    TraceInterceptor tracer = new TraceInterceptor();
    Object retVal = tracer.invoke(invocation);

    assertNull("Return value should be null", retVal);
    assertEquals(2, traceLog.messagesReceived());
    assertTrue(traceLog.hasMessageBeenLoggedContaining("Entering public void "
        + TRACEABLE_CLASS_NAME + ".primitiveArgument(int) Arguments {42}"));
    assertTrue(traceLog.hasMessageBeenLoggedContaining(MSG_LEAVING_SPACE
        + "public void "
        + TRACEABLE_CLASS_NAME + ".primitiveArgument(int) RetVal = '<null>'"));
  }

  public void testTraceMethodWithObjectArgument() throws Throwable {
    MockMethodInvocation invocation = new MockMethodInvocation("objectArgument",
        new Class[] { String.class }, new Object[] { "Input Value" });

    TraceInterceptor tracer = new TraceInterceptor();
    Object retVal = tracer.invoke(invocation);

    assertNull("Return value should be null", retVal);
    assertEquals(2, traceLog.messagesReceived());
    assertTrue(traceLog.hasMessageBeenLoggedContaining("Entering public void "
        + TRACEABLE_CLASS_NAME
        + ".objectArgument(java.lang.String) Arguments {Input Value}"));
    assertTrue(traceLog.hasMessageBeenLoggedContaining(MSG_LEAVING_SPACE
        + "public void " + TRACEABLE_CLASS_NAME
        + ".objectArgument(java.lang.String) RetVal = '<null>'"));
  }

  public void testTraceMethodWithMultipleArguments() throws Throwable {
    MockMethodInvocation invocation = new MockMethodInvocation("multipleArguments",
        new Class[] { int.class, String.class }, new Object[] { new Integer(42), "Input Value" });

    TraceInterceptor tracer = new TraceInterceptor();
    Object retVal = tracer.invoke(invocation);

    assertNull("Return value should be null", retVal);
    assertEquals(2, traceLog.messagesReceived());
    assertTrue(traceLog.hasMessageBeenLoggedContaining("Entering public void "
        + TRACEABLE_CLASS_NAME
        + ".multipleArguments(int,java.lang.String) Arguments {42, Input Value}"));
    assertTrue(traceLog.hasMessageBeenLoggedContaining(MSG_LEAVING_SPACE
        + "public void " + TRACEABLE_CLASS_NAME
        + ".multipleArguments(int,java.lang.String) RetVal = '<null>'"));
  }
  
  public void testTraceMethodWithPrimitiveReturnType() throws Throwable {
    MockMethodInvocation invocation = new MockMethodInvocation(
        "primitiveReturnType", null, null);

    TraceInterceptor tracer = new TraceInterceptor();
    Object retVal = tracer.invoke(invocation);

    assertEquals(Boolean.TRUE, retVal);
    assertEquals(2, traceLog.messagesReceived());
    assertTrue(traceLog.hasMessageBeenLoggedContaining("Entering public boolean "
        + TRACEABLE_CLASS_NAME + ".primitiveReturnType() Arguments {}"));
    assertTrue(traceLog.hasMessageBeenLoggedContaining(MSG_LEAVING_SPACE
        + "public boolean "
        + TRACEABLE_CLASS_NAME + ".primitiveReturnType() RetVal = 'true'"));
  }

  public void testTraceMethodWithObjectReturnType() throws Throwable {
    MockMethodInvocation invocation = new MockMethodInvocation(
        "objectReturnType", null, null);

    TraceInterceptor tracer = new TraceInterceptor();
    Object retVal = tracer.invoke(invocation);

    assertEquals("Return Value", retVal);
    assertEquals(2, traceLog.messagesReceived());
    assertTrue(traceLog.hasMessageBeenLoggedContaining("Entering public java.lang.String "
        + TRACEABLE_CLASS_NAME + ".objectReturnType() Arguments {}"));
    assertTrue(traceLog.hasMessageBeenLoggedContaining(MSG_LEAVING_SPACE
        + "public java.lang.String "
        + TRACEABLE_CLASS_NAME + ".objectReturnType() RetVal = 'Return Value'"));
  }

  private class MockMethodInvocation implements MethodInvocation {

    private String methodName;
    private Class[] argumentTypes;
    private Object[] arguments;

    MockMethodInvocation(String methodName, Class[] argumentTypes,
        Object[] arguments) {
      this.methodName = methodName;
      this.argumentTypes = argumentTypes;
      this.arguments = arguments;
    }

    public Method getMethod() {
      Method method = null;
      try {
        method = MockTraceableClass.class.getMethod(methodName, argumentTypes);
      } catch (SecurityException e) {
        System.err.println(e);
      } catch (NoSuchMethodException e) {
        System.err.println(e);
      }
      return method;
    }

    public Object[] getArguments() {
      return arguments;
    }

    public Object proceed() throws Throwable {
      return getMethod().invoke(new MockTraceableClass(), getArguments());
    }

    public Object getThis() {
      return this;
    }

    public AccessibleObject getStaticPart() {
      return null;
    }

  }

  private class MockTraceableClass {

    public void noArgsOrReturnType() {

    }

    public void primitiveArgument(int argument) {

    }

    public void objectArgument(String argument) {

    }
    
    public void multipleArguments(int argument1, String argument2) {
      
    }
    
    public boolean primitiveReturnType() {
      return true;
    }
    
    public String objectReturnType() {
      return "Return Value";
    }

  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1.6.1  2008/01/26 22:27:42  maschec
 * Fix failing tests
 *
 * Revision 1.1  2005/06/30 17:43:26  ggdavi
 * Moved ag.aop, ag.config and ag.message packages under the ag.cf package
 *
 * Revision 1.2  2005/06/29 18:00:35  ggdavi
 * Corrected package name in constant
 *
 * Revision 1.1  2005/06/28 16:08:23  ggdavi
 * Moved TraceInterceptor from ag.logging to ag.aop
 *
 * Revision 1.1  2005/04/07 15:47:11  ggdavi
 * Moved from aop package
 *
 */