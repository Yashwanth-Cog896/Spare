/*
 * AtfCoeProductDao_UT was created on Jun 24, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.dao.AtfCoeProductDao;
import com.monsanto.ag.cf.domain.*;
import com.monsanto.ag.util.test.DbUnitHelper;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test the ATF-COE implementation of the ProductDao.
 * 
 * @author Gareth Davies
 * @version $Id: AtfCoeProductDao_UT.java,v 1.4 2009/07/21 20:03:03 mkuchip Exp $
 */
public class AtfCoeProductDao_UT {

  private static final String REQUESTING_ENTITY_SEED_TRAK = "SeedTrak";
  private static final String REQUESTING_ENTITY_AGIIS = "AGIIS";

  private static final Timestamp LAST_MODIFIED_DATE = new Timestamp(new GregorianCalendar(2011, Calendar.APRIL, 23,
      13, 59, 4).getTime().getTime());

  private static final Timestamp DEKALB_SEED_ADDED_DATE = new Timestamp(new GregorianCalendar(2005, Calendar.DECEMBER, 20, 4,
      16, 19).getTime().getTime());

  private static final Timestamp DEKALB_SEED_UPDATED_DATE = new Timestamp(new GregorianCalendar(2011, Calendar.APRIL, 22, 15,
      2, 57).getTime().getTime());

  private static final SeedProduct DEKALB_SEED_PRODUCT = new SeedProduct( true, true,DEKALB_SEED_ADDED_DATE, DEKALB_SEED_UPDATED_DATE, null,
         "DEKALB", "A571", "NONE", "CP", "Concep/Poncho", "CONV", "S", false, 2, false);

  private static final Packaging DEKALB_SEED_PACKAGING = new Packaging(true,DEKALB_SEED_ADDED_DATE, DEKALB_SEED_UPDATED_DATE,
          "00070183366002", "A571 50# Concep/Poncho", "50.00 LB BAG", new Measurement(50.0F, "LBR"), "BG", false, "N/A", "N", "BG", "CP");

  private static final PackageConfiguration DEKALB_SEED_PACKAGING_CONFIGURATION = new PackageConfiguration(true,DEKALB_SEED_ADDED_DATE, DEKALB_SEED_UPDATED_DATE,"D",
          "00070183366002", "070183366002", "BG", new Measurement(1.0F, "BG"), new Measurement(1.0F, "BG"), 50.0F, 50.0F, 0.0F, 50.0F, 0.0F, 0.0F,
          0.0F, new Measurement(0.0F, "FOT"), new Measurement(0.0F, "FOT"), 0, 1);

  private static final Timestamp CHEM_PRODUCT_ADDED_DATE = new Timestamp(new GregorianCalendar(2006, Calendar.FEBRUARY, 16, 4,
      13, 41).getTime().getTime());

  private static final Timestamp CHEM_PRODUCT_UPDATED_DATE = new Timestamp(new GregorianCalendar(2011, Calendar.FEBRUARY, 21, 1,
      47, 29).getTime().getTime());

  private static final Timestamp CHEM_PRODUCT_ADDED_DATE1 = new Timestamp(new GregorianCalendar(2010, Calendar.MAY, 14, 4,
      10, 04).getTime().getTime());

  private static final Timestamp CHEM_PRODUCT_UPDATED_DATE1 = new Timestamp(new GregorianCalendar(2010, Calendar.MAY, 14, 8,
      30, 05).getTime().getTime());

  private static final Timestamp CHEM_PRODUCT_UPDATED_DATE2 = new Timestamp(new GregorianCalendar(2010, Calendar.MAY, 14, 8,
      29, 37).getTime().getTime());

  private static final ChemicalProduct CHEM_PRODUCT = new ChemicalProduct(true,true,CHEM_PRODUCT_ADDED_DATE, CHEM_PRODUCT_UPDATED_DATE, "365472", "4986",
         "RT3", "524-544");

  private static final Packaging CHEMICAL_PRODUCT_PACKAGING = new Packaging(true,CHEM_PRODUCT_ADDED_DATE, CHEM_PRODUCT_UPDATED_DATE,
          "90070183388410", "RT3 BULK US", "RT3 BULK US", new Measurement(1.0F, "GLL"), "VQ", false, "N/A", null, null, "N/A");

  private static final Packaging CHEMICAL_PRODUCT_PACKAGING1 = new Packaging(true,CHEM_PRODUCT_ADDED_DATE1, CHEM_PRODUCT_UPDATED_DATE1,
          "00883580419963", "RT3 265 GA CUBE US 1X265 GA CUBE PER PALLET", "RT3 265 GA CUBE US 1X265 GA CUBE PER PALLET", new Measurement(265.0F, "GLL"), "AB", false, "N/A", null, null, "N/A");

  private static final PackageConfiguration CHEMICAL_PRODUCT_PACKAGING_CONFIGURATION = new PackageConfiguration(true,CHEM_PRODUCT_ADDED_DATE, CHEM_PRODUCT_UPDATED_DATE,"H",
          "90070183388410", "070183388417", "VQ", new Measurement(1.0F, "VQ"), new Measurement(1.0F, "VQ"), 1.0F, 11.261F, 0.0F, 11.261F, 0.0F, 0.0F,
          0.0F, new Measurement(0.0F, "FOT"), new Measurement(0.0F, "FOT"), 0, 1);

  private static final PackageConfiguration CHEMICAL_PRODUCT_PACKAGING_CONFIGURATION1 = new PackageConfiguration(true,CHEM_PRODUCT_ADDED_DATE1, CHEM_PRODUCT_UPDATED_DATE1,"H",
          "00883580419963", "883580419963", "AB", new Measurement(1.0F, "AB"), new Measurement(1.0F, "AB"), 265.0F, 3145.9F, 162.0F, 2983.9F, 0.0F, 0.0F,
          0.0F, new Measurement(0.0F, "FOT"), new Measurement(0.0F, "FOT"), 3, 1);

    private static final PackageConfiguration CHEMICAL_PRODUCT_PACKAGING_CONFIGURATION2 = new PackageConfiguration(true,CHEM_PRODUCT_ADDED_DATE1, CHEM_PRODUCT_UPDATED_DATE2,"H",
          "70883580419962", null, "D97", new Measurement(1.0F, "D97"), new Measurement(1.0F, "D97"), 265.0F, 3145.9F, 0.0F, 2983.9F, 48.0F, 40.0F,
          46.0F, new Measurement(13.3333F, "FOT"), new Measurement(51.1111F, "FOT"), 3, 1);



  static {
      DEKALB_SEED_PRODUCT.addPackaging(DEKALB_SEED_PACKAGING);
      DEKALB_SEED_PACKAGING.addConfiguration(DEKALB_SEED_PACKAGING_CONFIGURATION);

      CHEM_PRODUCT.addPackaging(CHEMICAL_PRODUCT_PACKAGING);
      CHEM_PRODUCT.addPackaging(CHEMICAL_PRODUCT_PACKAGING1);
      CHEMICAL_PRODUCT_PACKAGING.addConfiguration(CHEMICAL_PRODUCT_PACKAGING_CONFIGURATION);
      CHEMICAL_PRODUCT_PACKAGING1.addConfiguration(CHEMICAL_PRODUCT_PACKAGING_CONFIGURATION1);
      CHEMICAL_PRODUCT_PACKAGING1.addConfiguration(CHEMICAL_PRODUCT_PACKAGING_CONFIGURATION2);
  }


  protected DbUnitHelper dbUnitHelper;

  private AtfCoeProductDao productDao;

  @Before
  public void setUp() throws Exception {
      productDao = new AtfCoeProductDao();
      dbUnitHelper = DbUnitHelperFactory.createDbUnitHelperUSMGEND();
      productDao.setDataSource(dbUnitHelper.getDataSource());
  }

  @After
  public void tearDown() throws Exception {
    dbUnitHelper.cleanup();
  }


  @Ignore
  @Test  
  public void testFindSeedProducts() throws WrappingException {

    List<Product> actualProducts = productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_SEED_TRAK, null, Product.SEGMENT_SEED, null);
    assertTrue(actualProducts.contains(DEKALB_SEED_PRODUCT));      
  }

  @Test
  public void testFindProductsModifiedAfterDateTime() throws WrappingException {

    List actualProducts = productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_SEED_TRAK, LAST_MODIFIED_DATE, Product.SEGMENT_SEED, null);
    assertTrue(actualProducts.size() > 0);
    assertFalse(actualProducts.contains(DEKALB_SEED_PRODUCT));  
  }

  @Ignore
  @Test
  public void testFindChemProducts() throws WrappingException {

    List actualProducts = productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_AGIIS, null, Product.SEGMENT_CHEMICAL, null);
    assertTrue(actualProducts.contains(CHEM_PRODUCT));
  }

  @Test
  public void testFindChemProductsModifiedAfterDateTime() throws WrappingException {

    List actualProducts = productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_AGIIS, LAST_MODIFIED_DATE, Product.SEGMENT_CHEMICAL, null);
    assertTrue(actualProducts.size() > 0);
    assertFalse(actualProducts.contains(CHEM_PRODUCT));  
  }

  @Ignore
  @Test
  public void testFindAllProducts() throws WrappingException {

    List actualProducts = productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_AGIIS, null, Product.SEGMENT_ALL, null);
    assertTrue(actualProducts.contains(DEKALB_SEED_PRODUCT));
    assertTrue(actualProducts.contains(CHEM_PRODUCT));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFindProductsWithInvalidCategory() throws WrappingException {
    productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_SEED_TRAK, null, "Invalid", null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testGetAllProductsWithEmptyStringCategory() throws WrappingException {
     productDao.findProductsByDateCategoryBrand(REQUESTING_ENTITY_SEED_TRAK, null, "", null);
  }
}

/*
 * $Log: AtfCoeProductDao_UT.java,v $
 * Revision 1.4  2009/07/21 20:03:03  mkuchip
 * Adding new fields for Acceleron Treated products in Productlist_2 and ProductLite_2 versions
 *
 * Revision 1.3  2008/09/09 16:25:04  rwspeh
 * *** empty log message ***
 *
 * Revision 1.1  2008/07/29 21:56:06  dddoni
 * ECG Service code Migrated  to ECMS. - UT from  ECG.
 *
 * Revision 1.17  2008/07/18 20:36:03  gjkell
 * Interstate
 *
 * Revision 1.16  2006/09/11 18:44:58  caggarw
 * Changed SELECT query to include order by PROD_CODE, RR_UOM_CODE. It needed to be added after the Oracle 10g upgrade.
 *
 * Revision 1.15  2006/05/24 18:28:12  caggarw
 * added processor_code to packaging under field userDefinedField1 to Processing
 * Revision 1.14 2006/05/12 20:01:12 caggarw
 * password changed for user ects_ld on ecg DB
 *
 * Revision 1.13 2006/05/02 22:03:23 caggarw Added DbUnitHelperFactory.
 *
 * Revision 1.12 2006/03/11 07:27:04 mecoru WrappingException import changed
 * from dataservices to Util.Exceptions: Done by automated script
 *
 * Revision 1.11 2005/09/09 17:59:44 ggdavi Fixed equipment and seed packaging
 * names and descriptions to not append a null if the LEGAL_DESCR_2 column is
 * null (TT00229) Revision 1.10 2005/08/24 14:36:24 ggdavi The
 * getLastModifiedDateTimeWhereClause method now uses greater than instead of
 * greater than or equal to (TT 00169) Revision 1.9 2005/08/19 15:15:17 ggdavi
 * Modified to support different types of products; retrieve brand from the
 * SEED_COMPANY_BRAND_NAME column instead of the BRAND_NAME column Revision 1.8
 * 2005/08/05 23:00:55 ggdavi Products are grouped by variety (aka ACRONYM) and
 * treatment code Revision 1.7 2005/07/28 15:47:50 ggdavi Added ActionRequest
 * attribute to various Product document elements; mapped the PackageLevelCode
 * and CheckDigit elements to the GTIN database column; only send one error
 * email per ProductUpdate document, containing all product-specific errors
 * Revision 1.6 2005/07/21 22:18:24 ggdavi Added
 * testGetAllProductsWithEmptyStringCategory
 *
 * Revision 1.5 2005/07/05 21:01:39 ggdavi Added an activeFlag parameter to
 * findProductsByDateCategoryBrand
 *
 * Revision 1.4 2005/06/29 17:12:19 ggdavi Modified SQL to convert package and
 * measurement units of measurement codes to Un-Rec-20 format
 *
 * Revision 1.3 2005/06/27 23:08:50 ggdavi Added bad parameter tests and fixed
 * problem with empty set of brands
 *
 * Revision 1.2 2005/06/27 22:01:51 ggdavi Implemented Revision 1.1 2005/06/24
 * 21:48:39 ggdavi Initial version
 *
 */