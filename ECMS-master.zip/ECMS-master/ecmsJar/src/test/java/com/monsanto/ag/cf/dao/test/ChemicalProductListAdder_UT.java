package com.monsanto.ag.cf.dao.test;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.ag.cf.domain.Product;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.ag.cf.domain.ChemicalProduct;
import com.monsanto.ag.cf.dao.ChemicalProductListAdder;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: ECELI
 * Date: 5/23/13
 * Time: 12:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChemicalProductListAdder_UT {

    private ChemicalProduct product;
    private List list;
    private static PersistentStoreResultSetFwdIterator iterator;
    private static ChemicalProductListAdder listAdder;

    @BeforeClass
    public static void runBeforeAllTests() throws WrappingException {

        listAdder = new ChemicalProductListAdder();
        iterator = mock( PersistentStoreResultSetFwdIterator.class );

        when( iterator.getTimestamp( "row_entry_date" ) ).thenReturn( new Date() );
        when( iterator.getTimestamp( "update_date" ) ).thenReturn( new Date() );
        when( iterator.getString( "unrec20_base_uom_code" ) ).thenReturn( "an String" );
        when( iterator.getString( "base_quantity" ) ).thenReturn( "1.1" );
        when( iterator.getString( "gtin" ) ).thenReturn( "12345678901234" );
        when( iterator.getString( "unrec20_rr_uom_code" ) ).thenReturn( "an String" );
        when( iterator.getString( "universal_prod_code" ) ).thenReturn( "a" );
    }

    @Before
    public void runBeforeEachTest(){

        product = mock( ChemicalProduct.class );
        list = mock( List.class );
    }

    @Test
    public void testAddProductToList() throws WrappingException {

        Product addedProduct = listAdder.addProductToList( list, iterator, product );
        Assert.assertTrue( addedProduct == product );
        verifyZeroInteractions( list );
    }

    @Test
    public void testAddProductToListNullLastProductRetrieved() throws WrappingException {

        Product addedProduct = listAdder.addProductToList( list, iterator, null );
        Assert.assertNotNull( addedProduct );
        verify( list ).add( any( Product.class ) );
    }
}