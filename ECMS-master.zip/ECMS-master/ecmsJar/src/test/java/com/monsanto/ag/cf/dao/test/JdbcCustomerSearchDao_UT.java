/*
 * JdbcEntityInquiryDao_UT was created on Jul 23, 2007 using Monsanto resources
 * and is the sole property of Monsanto. Any duplication of the code and/or
 * logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.dao.test;

import com.monsanto.ag.cf.dao.jdbc.JdbcCustomerSearchDao;
import com.monsanto.ag.cf.domain.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Test retreiving of Entity details using the JdbcCustomerSearchDao
 *
 * @author Chetna Aggarwal
 * @version $Id: JdbcGrowerDetailsInquiryDao_UT.java,v 1.1 2007/07/25 21:46:06
 *          caggarw Exp $
 *  June 06 2008 - Test Cases added for GOAII Customer Search Service        
 *
 */
public class JdbcCustomerSearchDao_UT extends BaseDbUnitTestCase {
  public static final String SEED_YEAR = "2012M";
  private JdbcCustomerSearchDao jdbcCustomerSearchDao;

  protected void setUp() throws Exception {
    super.setUp();
    jdbcCustomerSearchDao = new JdbcCustomerSearchDao();
    jdbcCustomerSearchDao.setDataSource(getDataSource());
  }

  public void testEntityInquiryAccountId() {

    AddressInformation address = new AddressInformation("PO BOX 246", "VERNON", "NY", "13476", "ONEIDA");
    List zoneList = new ArrayList();
    //MAS 3-11-08: Apparently another zone was added in the database, as follows:
    final String RR_ALFALFA_ZONES = "Roundup Ready Alfalfa Pricing Zones";
    ZoneInformation zone1 = new ZoneInformation(RR_ALFALFA_ZONES,
            "East", "AE", "2008M", "A");
    zoneList.add(zone1);
    //MAS 2-11-08: Changed description to be what is actually returned today since
    // test has started failing; still seems close to what it used to be.
//OLD ONE: final String CORN_ROOTWORM_ZONES = "Forecasting Corn Rootworm Zones 2008/2009/2010 (FORECASTING ONLY)";
    final String CORN_ROOTWORM_ZONES = "Corn Rootworm Zones 2008";
    ZoneInformation zone2 = new ZoneInformation(CORN_ROOTWORM_ZONES,
            "East", "AE", "2008M", "C");
    zoneList.add(zone2);
    CustomerIds customerIds = new CustomerIds(96, "1035326", "0000428487412905", "0001234567");
    GrowerDetails growerExpected = new GrowerDetails("AGWAY POHLS FEEDWAY", "Chet", "Pohl", customerIds, "Unlicensed",
            address, zoneList, 19424, "FFLX", "3158292753", null);
    GrowerCriteria criteria = new GrowerCriteria();
    criteria.setAccountId(96);
    criteria.setAddressInformation(new AddressInformation(null, null, "NY", null, null));
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetails(criteria, SEED_YEAR);
    assertEquals(1, growerDetails.size());
    GrowerDetails growerActual = (GrowerDetails) growerDetails.get(0);
    //  assertEquals(growerExpected, growerActual);
  }

  public void testEntityInquiryState() {

    GrowerCriteria criteria = new GrowerCriteria();
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetails(criteria, SEED_YEAR);
    assertEquals(2, growerDetails.size());
  }

  public void testEntityInquiryNothingInSearchCriteria() {
    GrowerCriteria criteria = new GrowerCriteria();
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetails(criteria, SEED_YEAR);
    assertEquals(2, growerDetails.size());
  }

  public void testStateLookupMatchByLName() {
    GrowerCriteria criteria = new GrowerCriteria(0, null, null, "Po%", null, null, new AddressInformation(null,
            null, "NY", "", ""), 5);
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetails(criteria, SEED_YEAR);
    assertEquals(2, growerDetails.size());
  }

  public void testEntityInquiryNoMatch() {
    AddressInformation address = new AddressInformation(null, "Saint Louis", "MO", "63141", null);
    GrowerCriteria criteria = new GrowerCriteria(4567, "Joe Inc", "Joe", "Stemler", "1234567777", "licensed", address,
            5);
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetails(criteria, SEED_YEAR);
    assertEquals(0, growerDetails.size());
  }

  public void testEntityInquiryAccountIdV2() {

//	    AddressInformation address = new AddressInformation("PO BOX 246", "VERNON", "NY", "13476", "ONEIDA");
    List zoneList = new ArrayList();
    //MAS 3-11-08: Apparently another zone was added in the database, as follows:
    final String RR_ALFALFA_ZONES = "Roundup Ready Alfalfa Pricing Zones";
    ZoneInformation zone1 = new ZoneInformation(RR_ALFALFA_ZONES,
            "East", "AE", "2008M", "A");
    zoneList.add(zone1);
    //MAS 2-11-08: Changed description to be what is actually returned today since
    // test has started failing; still seems close to what it used to be.
//	OLD ONE: final String CORN_ROOTWORM_ZONES = "Forecasting Corn Rootworm Zones 2008/2009/2010 (FORECASTING ONLY)";
    final String CORN_ROOTWORM_ZONES = "Corn Rootworm Zones 2008";
    ZoneInformation zone2 = new ZoneInformation(CORN_ROOTWORM_ZONES,
            "East", "AE", "2008M", "C");
    zoneList.add(zone2);
//	    CustomerIds customerIds = new CustomerIds(96, 1035326, "0000428487412905", "0001234567");
//	    GrowerDetails growerExpected = new GrowerDetails("AGWAY POHLS FEEDWAY", "Chet", "Pohl", customerIds, "Unlicensed",
//	        address, zoneList, 19424, "FFLX", "3158292753");
    GrowerCriteria criteria = new GrowerCriteria();
    criteria.setAccountId(96);
    criteria.setAddressInformation(new AddressInformation(null, null, "NY", null, null));
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetailsWithAgreementCode(criteria, SEED_YEAR);
    assertEquals(1, growerDetails.size());
//	    GrowerDetails growerActual = (GrowerDetails) growerDetails.get(0);
//	    assertEquals(growerExpected, growerActual);
  }

  public void testEntityInquiryStateV2() {

    GrowerCriteria criteria = new GrowerCriteria();
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetailsWithAgreementCode(criteria, SEED_YEAR);
    assertEquals(2, growerDetails.size());
  }

  public void testEntityInquiryCountryV2() {

    GrowerCriteria criteria = new GrowerCriteria();
    AddressInformation address =new AddressInformation(null, null, null, null, "ONEIDA");
    criteria.setAddressInformation(address);

    List growerDetails = jdbcCustomerSearchDao.getCustomerDetailsWithAgreementCode(criteria, SEED_YEAR);
    assertEquals(1, growerDetails.size());
  }

  public void testEntityInquiryNothingInSearchCriteriaV2() {
    GrowerCriteria criteria = new GrowerCriteria();
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetailsWithAgreementCode(criteria, SEED_YEAR);
    assertEquals(2, growerDetails.size());
  }

  public void testStateLookupMatchByLNameV2() {
    GrowerCriteria criteria = new GrowerCriteria(0, null, null, null, null, null, new AddressInformation(null,
            null, "NY", "", ""), 5);
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetailsWithAgreementCode(criteria, SEED_YEAR);
    assertEquals(2, growerDetails.size());
  }

  public void testEntityInquiryNoMatchV2() {
    AddressInformation address = new AddressInformation(null, "Saint Louis", "MO", "63141", null);
    GrowerCriteria criteria = new GrowerCriteria(4567, "Joe Inc", "Joe", "Stemler", "1234567777", "licensed", address,
            5);
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetailsWithAgreementCode(criteria, SEED_YEAR);
    assertEquals(0, growerDetails.size());
  }

  // TODO: test?
  public void testGetCustomerDetailsWithGrowerIds(){
    String accountIds = "96,126";
    jdbcCustomerSearchDao.getCustomerDetailsWithGrowerIds(accountIds, SEED_YEAR);
  }

  public void testStateLookupMatchByLNameWithQuote() {
    GrowerCriteria criteria = new GrowerCriteria(0, null, null, "O'LEARY", null, null, new AddressInformation(null,
            null, "NY", "", ""), 5);
    List growerDetails = jdbcCustomerSearchDao.getCustomerDetails(criteria, SEED_YEAR);
    assertEquals(0, growerDetails.size());
  }

}
