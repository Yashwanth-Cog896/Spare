EComMessageSystem\testdata\db\DealerPreferences_AT

This directory was copied from EComMessageSystem\testdata\db\DealerPreferences_FT on
March 31, 2008, as part of the process of gradually renaming the acceptance
test cases from *_FT to *_AT.  Once the
renaming is complete, the *_FT version can be deleted.
