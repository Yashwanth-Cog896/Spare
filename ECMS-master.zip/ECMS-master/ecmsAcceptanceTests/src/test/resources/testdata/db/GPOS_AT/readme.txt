EComMessageSystem\testdata\db\GPOS_AT

This directory was copied from EComMessageSystem\testdata\db\GPOS_FT on
March 10, 2008, as part of the process of gradually renaming the acceptance
test cases from *_FT to *_AT (in this case, GPOS_FT to GPOS_AT).  Once the
renaming is complete, the *_FT version can be deleted.
