/*
 * DealerPreferences_PT was created on May 16, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.DealerPreferences_AT;

/**
 * Test the performance of the DealerPreferences web service.
 * 
 * @author Gareth Davies
 * @version $Id: DealerPreferences_PT.java,v 1.4 2006-08-14 21:14:59 caggarw Exp $
 */
public class DealerPreferences_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for Dealer Preferences");

    Test dealerPreferences = new DealerPreferences_AT(
        "testJaxRpcDealerPreferencesBasicResponse");
    Test timedDealerPreferences = new TimedTest(dealerPreferences,
        MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedDealerPreferences);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2005/06/02 19:15:15  ggdavi
 * Now extends PerformanceTestCase and calls an acceptance test method that doesn't fool with DbUnit
 * Revision 1.2 2005/05/17 15:24:24 ggdavi
 * Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.1 2005/05/16 23:08:06 ggdavi Initial version
 *  
 */