/*
 * PPOS_AT was created on Jun 3, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;

/**
 * Test the PPOS web services.
 * 
 * @author Gareth Davies
 * @version $Id: PPOS_AT.java,v 1.2 2008-02-13 16:23:31 maschec Exp $
 */
public class PPOS_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/PPOS_1-0";

  public PPOS_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcPPOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcPPOSBasicResponse() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/PPOS/I3_Test3a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcPPOSSingleTransaction() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/PPOS/I3_Test3a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("PPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    Object transactionCount = logTable.getValue(0, "TRANSACTION_COUNT");
    assertEquals(new BigDecimal(1), transactionCount);
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ForecastedProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable actualEcgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3a");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcPPOSMultipleTransactions() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/PPOS/I3_Test3b.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("PPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ForecastedProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable actualEcgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3b");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcPPOSNotPPOSReporter() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/PPOS/I3_Test3c.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("PPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ForecastedProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable actualEcgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3c");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcPPOSVoidTransaction() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/PPOS/I3_Test3h.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("PPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ForecastedProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable actualEcgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3h");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1.8.1  2008/02/11 21:44:35  maschec
 * Refaactor common code to (more robust) assertBothEventsLogged()
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.16  2006/07/26 18:04:17  caggarw
 * *** empty log message ***
 * Revision 1.15 2006/06/26 15:20:21 caggarw
 * root_node_name added to data_exchange_repository as a primary key
 * 
 * Revision 1.14 2006/05/01 20:44:03 ggdavi Updated to reflect changes in
 * DbUnitHelper
 * 
 * Revision 1.13 2005/09/02 18:21:53 ggdavi Refactored getRequestXmlFromUri
 * method from xPOS_AT to read request XML from files
 * 
 * Revision 1.12 2005/08/17 14:00:17 ggdavi Removed extraction of DOM document
 * from test*BasicResponse methods, since it adds unnecessary time to the
 * performance tests that use them
 * 
 * Revision 1.11 2005/07/26 17:14:19 ggdavi Modified data exchange repository
 * XML assertions because of CLOB to BLOB change Revision 1.10 2005/07/19
 * 17:43:36 ggdavi All PostMethodWebRequest objects are built using the
 * superclass's buildSoapRequestWithCompression or
 * buildSoapRequestWithoutCompression methods
 * 
 * Revision 1.9 2005/06/30 17:43:26 ggdavi Moved ag.aop, ag.config and
 * ag.message packages under the ag.cf package
 * 
 * Revision 1.8 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method Revision 1.7 2005/06/27 22:14:52
 * ggdavi Commented out a DOMUtil.outputXML
 * 
 * Revision 1.6 2005/06/10 17:20:00 ggdavi Removed extraneous comments and
 * useless assertions
 * 
 * Revision 1.5 2005/06/10 16:25:19 sravipa changed assertEquals to
 * assertXmlEqual.
 * 
 * Revision 1.4 2005/06/10 15:13:30 sravipa Removed unneccesary code
 * 
 * Revision 1.3 2005/06/09 17:44:31 sravipa *** empty log message ***
 * 
 * Revision 1.2 2005/06/07 17:01:14 ggdavi Added first couple of test methods
 * and to do comments for the rest Revision 1.1 2005/06/03 13:59:02 ggdavi
 * Initial version
 * 
 */