/*
 * PriceSheet was created on Jun 15, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Test the PriceSheet web service.
 * 
 * @author caggarw
 * @version $Id: PriceSheet_AT.java,v 1.3 2008-04-16 18:34:38 maschec Exp $
 */
public class PriceSheet_AT extends AcceptanceTestCase {

  private static final String PRICE_SHEET_USER_ID = "1025910";
  private static final String PRICE_SHEET_PASSWORD = "test-123";
  private static final String PRICE_SHEET_EBID = "0";

  private static final String SERVICE_URI = "/soap/PriceSheet_1-0";

  private static final String TEMPLATE_MESSAGE_XML = "<PriceSheetRequest "
      + "xmlns=\"urn:ecms:schema:price:request:1:0\" "
      + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
      + " xmlns:ecms=\"urn:ecms:schema:price:request:1:0\" Version=\"1.0\">{0}"
      + "<PriceSheetRequestBody><PriceSheetRequestProperties/><PriceSheetRequestPartners><cidx:Seller><cidx:PartnerInformation>"
      + "<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>" + "<cidx:PartnerIdentifier "
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE
      + "=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:Seller>"
      + "</PriceSheetRequestPartners><PriceSheetRequestDetails><IncludeZoneGeographyList/>"
      + "<IncludePaymentTermsList/><IncludeProductLineItem/><IncludeAllowanceChargeList/>"
      + "<cidx:FromDateTime>{1}</cidx:FromDateTime><ProductFeatures><ProductAttribute>" + "<ProductAttributeName "
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"AGIISProductDirectory\">PrimaryProductSegmentCode"
      + "</ProductAttributeName><ProductAttributeValue>Seed</ProductAttributeValue>"
      + "</ProductAttribute></ProductFeatures></PriceSheetRequestDetails>"
      + "</PriceSheetRequestBody></PriceSheetRequest>";

  public PriceSheet_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcPrice() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcPriceSheetBasicResponse() throws Exception {
    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.JULY, 4);
    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());

    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, PRICE_SHEET_EBID, "ST", "06.27.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
    String wsseSecurityHeader = buildWSSecurityHeader(PRICE_SHEET_USER_ID, PRICE_SHEET_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcPriceSheet() throws Exception {
    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.JULY, 4);
    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());

    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, PRICE_SHEET_EBID, "ST", "06.27.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
    //MAS 4-16-08: Use regular GOOD_USER_ID rather than special ID, since
    // PRICE_SHEET_USER_ID is no longer valid. (Test passes with GOOD_USER_ID;
    // if there is some particular reason that special PRICE_SHEET_USER_ID is
    // needed, then need to get password reset.
//    String wsseSecurityHeader = buildWSSecurityHeader(PRICE_SHEET_USER_ID, PRICE_SHEET_PASSWORD, null, null);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    //DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathPrice = "/Envelope/Body/PriceSheet/PriceSheetBody/PriceSheetDetails/PriceSheetProductLineItem";
    int priceCount = XPathUtil.getNodeCount(responseXml, xpathPrice);
    System.out.println("Number of prices retrieved: " + priceCount);
    assertFalse("At least one price is expected", 0 == priceCount);

  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2008/02/13 16:23:31  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.1.8.1  2008/02/10 22:30:39  maschec
 * Add debugging stmt (commented out) like in other _FT classes
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.18  2006/07/26 17:45:25  caggarw
 * Use CIDXConstants for Agency Attributes
 * Revision 1.17 2006/05/09 23:48:45 ggdavi Removed
 * protected namespace declaration constants from CidxMessageTestCase - now use
 * the XmlNamespace constants directly
 * 
 * Revision 1.16 2006/01/17 18:50:15 caggarw password was changed for this user
 * 
 * Revision 1.15 2005/12/01 19:34:30 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.14 2005/11/30 13:54:19 ggdavi Factored out constants from user Ids
 * and passwords Revision 1.13 2005/09/16 18:01:11 ggdavi Changed user after
 * production refresh =:O
 * 
 * Revision 1.12 2005/08/17 14:00:17 ggdavi Removed extraction of DOM document
 * from test*BasicResponse methods, since it adds unnecessary time to the
 * performance tests that use them
 * 
 * Revision 1.11 2005/08/11 22:25:14 caggarw this test passes now. Changed the
 * fromDateTime in the Request from last week to a date before the prices were
 * modified after that date. Revision 1.10 2005/08/10 17:22:43 ggdavi Fixed the
 * basic response test case to include the FromDateTime element in the request
 * 
 * Revision 1.9 2005/08/10 17:16:45 ggdavi Changed user; removed Xpath-based
 * assertions from testJaxRpc*BasicResponse and put then into a new test method,
 * so they won't impact the performance tests; added FromDateTime and
 * PrimaryProductSegmentCode parameters to the request XML Revision 1.8
 * 2005/08/05 18:48:36 ggdavi Added (commented out) assertions to check that
 * prices are returned Revision 1.7 2005/07/19 17:43:36 ggdavi All
 * PostMethodWebRequest objects are built using the superclass's
 * buildSoapRequestWithCompression or buildSoapRequestWithoutCompression methods
 * Revision 1.6 2005/07/08 17:12:24 ggdavi Split SoapTestCase.buildCidxHeader
 * into buildCidxHeaderFromDealer and buildCidxHeaderToDealer methods
 * 
 * Revision 1.5 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method Revision 1.4 2005/06/28 17:54:21
 * ggdavi Added a to do comment for an assertion of returned prices to be added
 * 
 * Revision 1.3 2005/06/27 21:17:21 caggarw added test Revision 1.2 2005/06/16
 * 19:03:31 caggarw changed service name from Price_1-0 to PriceSheet_1-0
 * Revision 1.1 2005/06/15 20:37:44 caggarw Acceptance test for PriceSheet
 */