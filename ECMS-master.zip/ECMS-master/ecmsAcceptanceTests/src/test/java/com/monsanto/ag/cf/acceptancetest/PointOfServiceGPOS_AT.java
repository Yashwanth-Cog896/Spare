package com.monsanto.ag.cf.acceptancetest;

import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.transform.TransformerException;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.POSResultDocumentProcessor;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.XPathUtil;

public class PointOfServiceGPOS_AT extends AcceptanceTestCase {

  private static final String INTERNAL_GPOS_USER_ID = "int_gpos_4-0";
  private static final String INTERNAL_GPOS_USER_ACCOUNT_ID = "0";

  public PointOfServiceGPOS_AT(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    System.setProperty("catalina.base", "C:\\Tools\\jakarta-tomcat-5.0.28");
    System.setProperty("lsi.function", "win");

  }

  public void testInvokePosServiceWithoutUsingPOSCommunication() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1h.xml");
    PostMethodWebRequest request = new PostMethodWebRequest(getServiceUrl("")
        + "/servlet/EComMessageSystem_GPOS_4-0",
        new ByteArrayInputStream(messageXml.getBytes()), "text/xml");
    WebResponse response = webConversation.getResponse(request);
    assertEquals("text/html", response.getContentType());

    //MAS 3-31-08: Looks like CruiseControl Tomcat was changed to 5.5.20 !!
//  assertEquals("Apache Tomcat/5.0.28 - Error report", response.getTitle());
    String responseTitle = response.getTitle();
    assertNotNull(responseTitle);
    assertTrue(responseTitle.startsWith("Apache Tomcat/5."));
    assertTrue(responseTitle.endsWith(" - Error report"));
  }

  public void testGPOSService() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1h.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));

    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);

    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", outputDoc);
    // DOMUtil.outputXML(outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);
  }

  public void testGoodGPOSService() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1a.xml");

    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", outputDoc);
    // DOMUtil.outputXML(outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(INTERNAL_GPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 5, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_GPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    assertEquals(1, ecgTable.getRowCount());
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1a");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testGoodGPOSGoodDealerAllProducts() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1b.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(INTERNAL_GPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.APRIL, 28, 3, 2, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_GPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1b");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testGoodGPOSGoodDealerSalesReturns() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1c.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1c");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSGoodDealerAlfalfa() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1d.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1d");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSGoodDealerReversals() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1e.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    // Check output document
    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1e");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSGoodDealerWrongEBID() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1k.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    // Check output document
    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1k");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void test2004GPOSGoodDealer() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1l.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    // Check output document
    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(INTERNAL_GPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.APRIL, 20, 3, 2, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2004", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_GPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1l");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testNullDocumentGPOS() throws Exception {

    try {
      POSConnection posComm = new XMLPOSConnection();
      posComm.callService("EComMessageSystem_GPOS_4-0", null);
      fail("Should through an exception");
    } catch (Exception e) {
      assertEquals("No Input Document", e.getMessage());
    }
  }

  public void testGoodGPOSGoodDealerNonASKDProducts() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1n.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    // Check output document
    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1n");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSMultipleDealers() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1o.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    // Check output document
    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1o");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodDealerWrongEBID() throws Exception {
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1p.xml");

    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
    Document outputDoc = new POSResultDocumentProcessor().getDocument(result);

    // Check output document
    assertNotNull("Valid document must be returned", outputDoc);
    String conversationId = getConversationIdFromResponseDocument(outputDoc);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(GPOS_AT.class, "I2_Data1p");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testNonCidxXmlGoodDealer() throws Exception {
    try {
      String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1q.xml");
      Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));
      POSConnection posComm = new XMLPOSConnection();
      posComm.callService("EComMessageSystem_GPOS_4-0", inputDoc);
      fail("Should through an error");
    } catch (Exception e) {
      assertTrue(e.getMessage().startsWith("Document failed XML schema validation"));
    }
  }

  protected String getConversationIdFromResponseDocument(Document responseXml) throws TransformerException {
    return XPathUtil.getTextNodeValue(responseXml, "/cidx:Header/cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier");
  }
  
}
