/*
 * FarmManagerList_PT was created on Jun 2, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.FarmManagerList_AT;

/**
 * Test the performance of the Farm Manager List web service.
 * 
 * @author Gareth Davies
 * @version $Id: FarmManagerList_PT.java,v 1.3 2006-08-14 21:14:59 caggarw Exp $
 */
public class FarmManagerList_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for Farm Manager List");

    Test farmManagerList = new FarmManagerList_AT(
        "testJaxRpcFarmManagerListBasicResponse");
    Test timedFarmManagerList = new TimedTest(farmManagerList,
        MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedFarmManagerList);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/06/23 21:46:12  ggdavi
 * Renamed acceptance test method for consistency
 * Revision 1.1 2005/06/02 19:15:27 ggdavi
 * Initial version
 *  
 */