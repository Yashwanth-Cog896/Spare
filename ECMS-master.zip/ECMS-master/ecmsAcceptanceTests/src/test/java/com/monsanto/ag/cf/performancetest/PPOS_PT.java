/*
 * PPOS_PT was created on Jun 7, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.PPOS_AT;

/**
 * Test the performance of the PPOS web service.
 * 
 * @author Gareth Davies
 * @version $Id: PPOS_PT.java,v 1.2 2006-08-14 21:14:59 caggarw Exp $
 */
public class PPOS_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for PPOS");

    Test ppos = new PPOS_AT("testJaxRpcPPOSBasicResponse");
    TimedTest timedPpos = new TimedTest(ppos,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedPpos);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/06/07 19:45:08  ggdavi
 * Added FPOS_PT and PPOS_PT
 *
 */