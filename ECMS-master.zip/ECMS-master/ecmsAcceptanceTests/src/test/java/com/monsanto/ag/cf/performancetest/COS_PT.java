package com.monsanto.ag.cf.performancetest;

import com.monsanto.ag.cf.acceptancetest.COS_AT;
import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;

public class COS_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for COS");

    Test productList = new COS_AT("testJaxRpcCOSBasicResponse");
    Test timedProductList = new TimedTest(productList,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedProductList);

    return suite;
  }

}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/07/27 18:24:51  ggdavi
 * Initial version
 *
 */