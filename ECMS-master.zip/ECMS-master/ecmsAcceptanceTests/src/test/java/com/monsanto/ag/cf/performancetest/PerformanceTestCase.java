/*
 * PerformanceTestCase was created on Jun 2, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.commons.lang.StringUtils;

import com.clarkware.junitperf.ConstantTimer;
import com.clarkware.junitperf.LoadTest;
import com.clarkware.junitperf.Timer;

/**
 * Contains common fixtures for all performance test cases.
 * 
 * @author Gareth Davies
 * @version $Id: PerformanceTestCase.java,v 1.2 2005-07-08 17:16:49 ggdavi Exp $
 */
public abstract class PerformanceTestCase {

  protected static final int MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE = 30000;
  protected static final int MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE = 60000;
  private static final int AVERAGE_CONCURRENT_USERS = 3;
//  private static final int PEAK_CONCURRENT_USERS = 25;
  private static final Timer CONSTANT_DELAY_TIMER = new ConstantTimer(500);
//  private static final Timer RANDOM_DELAY_TIMER = new RandomTimer(500, 250);

  protected static void setUserLoadAndAddToSuite(TestSuite suite, Test timedTest) {
    int maxUsers = AVERAGE_CONCURRENT_USERS;
    String propValue = System.getProperty("ecms.performancetest.maxUsers");
    if (StringUtils.isNumeric(propValue)) {
      maxUsers = Integer.parseInt(propValue);
    }

    suite.addTest(new LoadTest(timedTest, maxUsers, CONSTANT_DELAY_TIMER));
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/06/02 19:15:27  ggdavi
 * Initial version
 *
 */