/*
 * EDNProducer_AT was created on Jul 6, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Date;

import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

public class EDNProducer_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/EDNProducer_4-0";
  private static final String APPLICATION_USER_ID = "application";
  private static final String APPLICATION_PASSWORD = "trust-me";

  private static final String TEMPLATE_MESSAGE_XML = "<ShipNotice "
      + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration()
      + " "
      + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
      + " Version=\"4.0\">{0}<ShipNoticeBody><ShipNoticeProperties>"
      + "<ShipmentIdentification><DocumentReference><DocumentIdentifier>12345"
      + "</DocumentIdentifier></DocumentReference></ShipmentIdentification>"
      + "<ShipDate><DateTime DateTimeQualifier=\"On\">2005-07-06T15:21:00Z</DateTime></ShipDate>"
      + "<TransportMethodCode Domain=\"UN-Rec-19\">6</TransportMethodCode>"
      + "<ReferenceInformation ReferenceType=\"DeliveryNoteNumber\"><DocumentReference>"
      + "<DocumentIdentifier>0881074853</DocumentIdentifier></DocumentReference></ReferenceInformation>"
      + "<ShipNoticeDate><DateTime DateTimeQualifier=\"On\">2005-07-07T17:35:00Z</DateTime></ShipNoticeDate>"
      + "</ShipNoticeProperties><ShipNoticePartners>"
      + "<Buyer><PartnerInformation><PartnerName>Joe Dealer</PartnerName>"
      + "<PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">1234567890123</PartnerIdentifier>"
      + "</PartnerInformation></Buyer><Seller><PartnerInformation>"
      + "<PartnerName>MONSANTO AGRICULTURAL CO</PartnerName>"
      + "<PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">0062668030000</PartnerIdentifier>"
      + "</PartnerInformation></Seller></ShipNoticePartners><ShipNoticeDetails>"
      + "<ShipNoticeProductLineItem><LineNumber>1</LineNumber><ProductIdentification>"
      + "<ProductIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"AGIIS-ProductID\">98765</ProductIdentifier>"
      + "</ProductIdentification><ShippedQuantity><Measurement>"
      + "<MeasurementValue>24</MeasurementValue>"
      + "<UnitOfMeasureCode Domain=\"UN-Rec-20\">KGM</UnitOfMeasureCode>"
      + "</Measurement></ShippedQuantity></ShipNoticeProductLineItem>"
      + "</ShipNoticeDetails></ShipNoticeBody></ShipNotice>";

  public EDNProducer_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcEDNProducer() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcEDNProducerBasicResponse() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderToDealer(nowUTC, GOOD_USER_SAP_ID,
        false, 2005);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
        cidxHeader);
    String wsseSecurityHeader = buildWSSecurityHeader(APPLICATION_USER_ID,
        APPLICATION_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }
  
  public void testJaxRpcEDNProducer() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderToDealer(nowUTC, GOOD_USER_SAP_ID,
        false, 2005);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
        cidxHeader);
    String wsseSecurityHeader = buildWSSecurityHeader(APPLICATION_USER_ID,
        APPLICATION_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist",
        conversationId);

    // Check that Log Record has been created
    String activityLogSql = buildActivityLogSql(conversationId);
    ITable logTable = getEcomDbUnitHelper().getActualTable(
        activityLogSql);
    assertEquals(1, logTable.getRowCount());
    assertEquals(APPLICATION_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("SNP", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertTrue("DATA_EXCHANGE_START_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(logTable, 0,
            "DATA_EXCHANGE_START_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(logTable, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0,
        "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    String xmlRepositorySql = buildXmlRepositorySql(dataExchangeId, "ShipNotice");
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        xmlRepositorySql);
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0,
        "XML_MSG"));
  }
  
}
/*
 * $Log: not supported by cvs2svn $
 * Revision 1.10  2006/07/26 17:42:40  caggarw
 * Use CIDXConstants for Agency Attributes
 *
 * Revision 1.9  2006/06/26 15:18:50  caggarw
 * root_node_name added to data_exchange_repository as a primary key
 *
 * Revision 1.8  2006/05/09 23:48:45  ggdavi
 * Removed protected namespace declaration constants from CidxMessageTestCase - now use the XmlNamespace constants directly
 *
 * Revision 1.7  2006/01/23 17:08:58  caggarw
 * added delivery_id to xml
 *
 * Revision 1.6  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.5  2005/08/17 14:00:17  ggdavi
 * Removed extraction of DOM document from test*BasicResponse methods, since it adds unnecessary time to the performance tests that use them
 *
 * Revision 1.4  2005/08/10 20:58:27  ggdavi
 * Added testJaxRpcEDNProducer method and added tests for the correct population of the activity log and XML repository
 * Revision 1.3 2005/07/26 21:43:42 ggdavi Use SAP
 * Id instead of Account Id in header
 * 
 * Revision 1.2 2005/07/19 17:43:36 ggdavi All PostMethodWebRequest objects are
 * built using the superclass's buildSoapRequestWithCompression or
 * buildSoapRequestWithoutCompression methods
 * 
 * Revision 1.1 2005/07/08 17:04:25 ggdavi Initial version
 * 
 */