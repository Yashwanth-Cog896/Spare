/*
 * CustomerSearch_FT was created on Aug 6, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;

/**
 * Test the Customer Search web service.
 * 
 * @author Devaiah Doni
 * @version $Id: CustomerSearch2_AT.java,v 1.6 2008-09-22 17:01:54 dddoni Exp $
 */
public class CustomerSearch2_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/CustomerSearch_2-0";

  public CustomerSearch2_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcCustomerSearch() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcCustomerSearchBasicResponse() throws Exception {
    String messageXml = getRequestXmlFromUri("/CustomerSearch/CustomerSearchRequest_3.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
   
//    DOMUtil.outputXML(response.getDOM());
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcCustomerSearchCitySearch() throws Exception {
    String messageXml = getRequestXmlFromUri("/CustomerSearch/CustomerSearchRequest_3.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);

    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
//     DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    String xpathCustomerSearchResponse = "/Envelope/Body/AGIISEntityInquiryResponse/Body/AGIISEntityInquiryResponseDetails/EntityInquiryResponse/EntityInformationResponse";
		int cusermerSearchResults = XPathUtil.getNodeCount(responseXml, xpathCustomerSearchResponse);
	System.out.println("No of Customer Search Results Received "+cusermerSearchResults);

     xpathCustomerSearchResponse = "/Envelope/Body/AGIISEntityInquiryResponse/Body/AGIISEntityInquiryResponseDetails/EntityInquiryResponse/EntityInformationResponse/FarmFlexApproved";
     // FarmFlexApproved
//    assertXpathEvaluatesTo("Yes",xpathCustomerSearchResponse,response.getDOM());
    xpathCustomerSearchResponse = "/Envelope/Body/AGIISEntityInquiryResponse/Body/AGIISEntityInquiryResponseDetails/EntityInquiryResponse/EntityInformationResponse/FarmManagerApproved";
    //FarmManagerApproved
    assertXpathEvaluatesTo("Yes",xpathCustomerSearchResponse,response.getDOM());
    
  }

  public void testJaxRpcCustomerSearchWithMultipleAccountIds() throws Exception {
	    String messageXml = getRequestXmlFromUri("/CustomerSearch/CustomerSearchRequest_4.xml");
	    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
	    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
	        messageXml);

	    WebResponse response = webConversation.getResponse(request);

	    Document responseXml = response.getDOM();

	    assertNotNull("Valid document must be returned", responseXml);
//	    FileOutputStream fis = new FileOutputStream("CustomerSearch"); 
//	     DOMUtil.outputXML(responseXml,fis);
	    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

	    String xpathCustomerSearchResponse = "/Envelope/Body/AGIISEntityInquiryResponse/Body/AGIISEntityInquiryResponseDetails/EntityInquiryResponse/EntityInformationResponse";
 		int cusermerSearchResults = XPathUtil.getNodeCount(responseXml, xpathCustomerSearchResponse);
		System.out.println("No of Customer Search Results Received "+cusermerSearchResults);
		assertFalse("At least one product is expected", 0 == cusermerSearchResults);
	    
	  }

  public void dtestJaxRpcCustomerSearchWithChunks() throws Exception {
	    String messageXml = getRequestXmlFromUri("/CustomerSearch/CustomerSearchRequest_5.xml");
	    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
	    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
	        messageXml);

	    WebResponse response = webConversation.getResponse(request);
	    Document responseXml = response.getDOM();

	    assertNotNull("Valid document must be returned", responseXml);
//	    FileOutputStream fis = new FileOutputStream("CustomerSearch"); 
//	     DOMUtil.outputXML(responseXml);
	    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

	    String xpathCustomerSearchResponse = "/Envelope/Body/AGIISEntityInquiryResponse/Body/AGIISEntityInquiryResponseDetails/EntityInquiryResponse/EntityInformationResponse";
		int cusermerSearchResults = XPathUtil.getNodeCount(responseXml, xpathCustomerSearchResponse);
		System.out.println("No of Customer Search Results Received "+cusermerSearchResults);
		assertFalse("At least one product is expected", 0 == cusermerSearchResults);
	    
	  }

  
}
