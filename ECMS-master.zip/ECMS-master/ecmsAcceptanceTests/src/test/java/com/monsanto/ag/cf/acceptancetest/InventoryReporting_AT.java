/*
 * InventoryReporting_FT was created on Apr 19, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Document;
import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;

/**
 * Test the Inventory Reporting web service
 * 
 * @author Ramesh Kukunarapu
 * @version $Id: InventoryReporting_AT.java,v 1.3 2008-01-02 15:33:20 RRKUKU Exp $
 */
public class InventoryReporting_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/InventoryReporting_1-0";

  public InventoryReporting_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcInventoryReporting() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }
  
  public void testJaxRpcInventoryReportingBasicResponse() throws Exception {
   
    //String INVENTORY_DETAIL_XML = "<InventoryDetail PhysicalCountIND=\"true\" ProductUOM=\"BG\" LocationQual=\"AGIIS-EBID\" LocationID=\"0593996880000\" GTIN=\"00070183294398\" AsOFDate=\"2007-11-11T10:05:06Z\" Quantity=\"-123\" LotNumber=\"\"><LocationName>Tigges Seed Sales</LocationName></InventoryDetail>";
    String INVENTORY_DETAIL_XML = "<InventoryDetail PhysicalCountIND=\"true\" ProductUOM=\"BG\" LocationQual=\"AGIIS-EBID\" LocationID=\"0593996880000\" GTIN=\"1234567\" AsOFDate=\"2007-12-03T10:05:06Z\" Quantity=\"786\" LotNumber=\"786\"><LocationName>Tigges Seed Sales</LocationName></InventoryDetail>";
    String messageXml = "<InventoryMobile xmlns=\"urn:ecms:schema:inventory:request:1:0\" xmlns:ecms=\"urn:ecms:schema:inventory:request:1:0\" xmlns:cidx=\"urn:cidx:names:specification:ces:schema:all:4:0\">    " +
    "<cidx:Header>" +
    "        <cidx:ThisDocumentIdentifier> <cidx:DocumentIdentifier>INVREP22</cidx:DocumentIdentifier>" +
    "        </cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime>" +
    "            <cidx:DateTime DateTimeQualifier=\"After\">2006-03-08T16:54:48Z</cidx:DateTime>" +
    "        </cidx:ThisDocumentDateTime><cidx:From><cidx:PartnerInformation>" +
    "                <cidx:PartnerName>ATigges Seed Sales</cidx:PartnerName>" +
    "                <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">12345678901234</cidx:PartnerIdentifier>" +
    "                <cidx:ContactInformation> <cidx:ContactName>HANDHELD</cidx:ContactName>" +
    "                    <cidx:ContactDescription>DataSource</cidx:ContactDescription>  </cidx:ContactInformation>" +
    "                <cidx:ContactInformation><cidx:ContactName>2008</cidx:ContactName>" +
    "                    <cidx:ContactDescription>SeedYear</cidx:ContactDescription></cidx:ContactInformation>" +
    "                <cidx:ContactInformation><cidx:ContactName>12.12.05</cidx:ContactName>" +
    "                    <cidx:ContactDescription>SoftwareVersion</cidx:ContactDescription></cidx:ContactInformation>" +
    "            </cidx:PartnerInformation></cidx:From><cidx:To><cidx:PartnerInformation>" +
    "                <cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>" +
    "                <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier>" +
    "            </cidx:PartnerInformation></cidx:To></cidx:Header>" +
    "    <InventoryPartners OwnerID=\"12345678901234\" OwnerQual=\"AGIIS-EBID\"><OwnerName>Tigges Seed Sales</OwnerName></InventoryPartners>" +
    "    <InventoryDetails> "+INVENTORY_DETAIL_XML+" </InventoryDetails>" +
    "</InventoryMobile>";

    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcInventoryReporting() throws Exception {
    
    String INVENTORY_DETAIL_XML = "<InventoryDetail PhysicalCountIND=\"true\" ProductUOM=\"BG\" LocationQual=\"AGIIS-EBID\" LocationID=\"0593996880000\" GTIN=\"00070183294398\" AsOFDate=\"2007-01-01T10:05:06Z\" Quantity=\"456.78\" LotNumber=\"456.78\"><LocationName>Tigges Seed Sales</LocationName></InventoryDetail>";
    INVENTORY_DETAIL_XML += "<InventoryDetail PhysicalCountIND=\"false\" ProductUOM=\"UN\" LocationQual=\"AGIIS-NAPD\" LocationID=\"123456789\" GTIN=\"00000123345\" AsOFDate=\"2007-02-02T10:05:06Z\" Quantity=\"-90.90\" LotNumber=\"-90.90\"><LocationName>Tigges Seed Sales</LocationName></InventoryDetail>";
    
    String messageXml = "<InventoryMobile xmlns=\"urn:ecms:schema:inventory:request:1:0\" xmlns:ecms=\"urn:ecms:schema:inventory:request:1:0\" xmlns:cidx=\"urn:cidx:names:specification:ces:schema:all:4:0\">    " +
    "<cidx:Header>" +
    "        <cidx:ThisDocumentIdentifier> <cidx:DocumentIdentifier>INVREP22</cidx:DocumentIdentifier>" +
    "        </cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime>" +
    "            <cidx:DateTime DateTimeQualifier=\"After\">2006-03-08T16:54:48Z</cidx:DateTime>" +
    "        </cidx:ThisDocumentDateTime><cidx:From><cidx:PartnerInformation>" +
    "                <cidx:PartnerName>ATigges Seed Sales</cidx:PartnerName>" +
    "                <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">12345678901234</cidx:PartnerIdentifier>" +
    "                <cidx:ContactInformation> <cidx:ContactName>SEEDTRAK</cidx:ContactName>" +
    "                    <cidx:ContactDescription>DataSource</cidx:ContactDescription>  </cidx:ContactInformation>" +
    "                <cidx:ContactInformation><cidx:ContactName>2008</cidx:ContactName>" +
    "                    <cidx:ContactDescription>SeedYear</cidx:ContactDescription></cidx:ContactInformation>" +
    "                <cidx:ContactInformation><cidx:ContactName>12.12.05</cidx:ContactName>" +
    "                    <cidx:ContactDescription>SoftwareVersion</cidx:ContactDescription></cidx:ContactInformation>" +
    "            </cidx:PartnerInformation></cidx:From><cidx:To><cidx:PartnerInformation>" +
    "                <cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>" +
    "                <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier>" +
    "            </cidx:PartnerInformation></cidx:To></cidx:Header>" +
    "    <InventoryPartners OwnerID=\"0593996880000\" OwnerQual=\"AGIIS-EBID\"><OwnerName>Tigges Seed Sales</OwnerName></InventoryPartners>" +
    "    <InventoryDetails> "+INVENTORY_DETAIL_XML+" </InventoryDetails>" +
    "</InventoryMobile>";

    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    assertNotNull("Valid document must be returned", responseXml);
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
  
  public void testNonWellFormedXMLRequest() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/NonWellFormedRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    assertXpathEvaluatesTo("ecms:MessageNotValid", "/Envelope/Body/Fault/faultcode", responseXml);
  }
  
  public void testFieldLengthLargeRequest() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/FieldLengthLargeRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
  
  public void testDifferentPartnersPhysicalCountYesReqXML() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/DiffPartnerPhyCntYesRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
  
  public void testDifferentGTINsReqXML() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/DiffGTINsRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
  
  public void testSameProductDifferentUOMReqXML() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/SameProductDiffUOMRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
  
  public void testCottonProductsReqXML() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/CottonProductsRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
    
  public void testInventoryReportingRequestInvPartnerMissingXML() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/Inventory_Request_XML.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
  
  public void testInventoryMultipleGTINXML() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/INVREP/MultipleGTIN.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    String xpathInventoryDetail = "/Envelope/Body/InventoryReportingResponse/Status";
    String statusValue = XPathUtil.getTextNodeValue(responseXml, xpathInventoryDetail);
    assertEquals("Success",statusValue);
  }
}
