/*
 * FarmManagerList_AT was created on May 23, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Date;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Test the Farm Manager List web services.
 * 
 * @author Gareth Davies
 * @version $Id: FarmManagerList_AT.java,v 1.1 2006-08-14 21:14:47 caggarw Exp $
 */
public class FarmManagerList_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/FarmManagerList_1-0";

  public FarmManagerList_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcFarmManagerList() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcFarmManagerListBasicResponse() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, true);
    String messageXml = "<FarmManagerListRequest "
        + "xmlns=\"urn:ecms:schema:fmlist:request:1:0\" " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:fmlist:request:1:0\" Version=\"1.0\">"
        + cidxHeader + "<FarmManagerListRequestBody/>"
        + "</FarmManagerListRequest>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcFarmManagerList() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, true);
    String messageXml = "<FarmManagerListRequest "
        + "xmlns=\"urn:ecms:schema:fmlist:request:1:0\" " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:fmlist:request:1:0\" Version=\"1.0\">"
        + cidxHeader + "<FarmManagerListRequestBody/>"
        + "</FarmManagerListRequest>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist",
        getConversationIdFromResponseDocument(responseXml));

    final String xpathFarmManager = "/Envelope/Body/FarmManagerList/FarmManagerListBody/FarmManagerEntity";
    int farmManagerCount = XPathUtil
        .getNodeCount(responseXml, xpathFarmManager);
    System.out
        .println("Number of farm managers retrieved: " + farmManagerCount);
    assertFalse("At least one farm manager is expected", 0 == farmManagerCount);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.22  2006/05/09 23:48:45  ggdavi
 * Removed protected namespace declaration constants from CidxMessageTestCase - now use the XmlNamespace constants directly
 *
 * Revision 1.21  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.20  2005/08/19 15:55:16  ggdavi
 * Output the number of transactions used for the basic response tests to the console (in another test)
 * Revision 1.19 2005/08/17 14:00:17 ggdavi
 * Removed extraction of DOM document from test*BasicResponse methods, since it
 * adds unnecessary time to the performance tests that use them
 * 
 * Revision 1.18 2005/08/10 17:16:54 ggdavi Removed Xpath-based assertions from
 * testJaxRpc*BasicResponse and put then into a new test method, so they won't
 * impact the performance tests
 * 
 * Revision 1.17 2005/07/19 17:43:36 ggdavi All PostMethodWebRequest objects are
 * built using the superclass's buildSoapRequestWithCompression or
 * buildSoapRequestWithoutCompression methods Revision 1.16 2005/07/08 17:12:24
 * ggdavi Split SoapTestCase.buildCidxHeader into buildCidxHeaderFromDealer and
 * buildCidxHeaderToDealer methods
 * 
 * Revision 1.15 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method
 * 
 * Revision 1.14 2005/06/27 20:21:12 ajbaldw Fixed the issue with padding the
 * EBID.
 * 
 * Revision 1.13 2005/06/23 21:46:02 ggdavi Renamed method for consistency
 * Revision 1.12 2005/06/08 17:31:41 ggdavi Added required Version attribute to
 * root element of request
 * 
 * Revision 1.11 2005/06/02 16:39:23 ggdavi All XPaths now work on the SOAP
 * document
 * 
 * Revision 1.10 2005/06/01 18:56:52 ggdavi Refactored for consistency Revision
 * 1.9 2005/06/01 17:18:29 ggdavi Added WSDL test method; changed default
 * namespace of request to match schema Revision 1.8 2005/05/31 20:42:31 ggdavi
 * Removed validate... method Revision 1.7 2005/05/31 17:42:54 ajbaldw changed
 * the body element to FarmManagerListBody Revision 1.6 2005/05/31 17:29:09
 * ajbaldw some xpath changes for the soap faults. Revision 1.5 2005/05/26
 * 21:26:33 ajbaldw changed all xpath assertions to assertEquals or the like
 * because of the cidx: prefixes. Revision 1.4 2005/05/26 18:23:50 ajbaldw
 * tweaked what is there to be xpath compatible.
 * 
 * Revision 1.3 2005/05/26 13:44:01 lsdenny Added Test for FM List - not
 * finished, just wanted to let know I was working on it.
 * 
 * Revision 1.2 2005/05/25 22:29:16 ggdavi fmListUrl now set in setUp
 * 
 * Revision 1.1 2005/05/24 15:21:14 ggdavi Initial version
 * 
 */