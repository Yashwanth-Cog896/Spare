/*
 * GrowerOrder_FT was created on Jun 11, 2008 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;

public class GrowerOrder_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/GrowerOrder_1-0";
  private static final String TEMPLATE_MESSAGE_XML = "<OrderChange Version=\"1.0\" xmlns=\"urn:ecms:schema:growerorder:request:1:0\" "
      + "xmlns:ecms=\"urn:ecms:schema:growerorder:request:1:0\" "
      + "xmlns:cidx=\"urn:cidx:names:DRAFT_0014:ces:schema:all:5:0\">"
      + "<cidx:Header><cidx:ThisDocumentIdentifier><cidx:DocumentIdentifier>121493854742811362</cidx:DocumentIdentifier></cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime><cidx:DateTime DateTimeQualifier=\"On\">2008-07-01T18:55:47Z</cidx:DateTime></cidx:ThisDocumentDateTime><cidx:From><cidx:PartnerInformation><cidx:PartnerName>RICK &amp; SHIRLEY STEVENS</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0002536410000</cidx:PartnerIdentifier><cidx:ContactInformation><cidx:ContactName>SeedTrak</cidx:ContactName><cidx:ContactDescription>DataSource</cidx:ContactDescription></cidx:ContactInformation><cidx:ContactInformation><cidx:ContactName>2008</cidx:ContactName><cidx:ContactDescription>SeedYear</cidx:ContactDescription></cidx:ContactInformation><cidx:ContactInformation><cidx:ContactName>3.1.54</cidx:ContactName><cidx:ContactDescription>SoftwareVersion</cidx:ContactDescription></cidx:ContactInformation></cidx:PartnerInformation></cidx:From><cidx:To><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:To></cidx:Header><OrderChangeBody><OrderChangeProperties><cidx:PurchaseOrderNumber><cidx:DocumentIdentifier>1001</cidx:DocumentIdentifier></cidx:PurchaseOrderNumber><cidx:PurchaseOrderTypeCode Domain=\"ANSI-ASC-X12-92\">KN</cidx:PurchaseOrderTypeCode><cidx:PurchaseOrderIssuedDate><cidx:DateTime DateTimeQualifier=\"On\">2008-07-01T05:00:00Z</cidx:DateTime></cidx:PurchaseOrderIssuedDate><cidx:LanguageCode Domain=\"ISO-639-2T\">eng</cidx:LanguageCode><cidx:CurrencyCode Domain=\"ISO-4217\">USD</cidx:CurrencyCode><cidx:BuyerSequenceNumber>1</cidx:BuyerSequenceNumber><cidx:ReferenceInformation ReferenceType=\"SalesOrderReference\"><cidx:DocumentReference><cidx:DocumentIdentifier>0610000182</cidx:DocumentIdentifier></cidx:DocumentReference></cidx:ReferenceInformation></OrderChangeProperties><OrderChangePartners><cidx:Buyer><cidx:PartnerInformation><cidx:PartnerName>RICK &amp; SHIRLEY STEVENS</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">1854842350000</cidx:PartnerIdentifier><cidx:ContactInformation><cidx:ContactName>RICK &amp; SHIRLEY STEVENS</cidx:ContactName><cidx:ContactDescription>SalesPerson</cidx:ContactDescription><cidx:ContactNumber>5155326558</cidx:ContactNumber><cidx:EmailAddress>Rick@aol.com</cidx:EmailAddress><cidx:AlternativeCommunicationMethod CommunicationMethodType=\"Fax\">Telephone[515,532,6558,&lt;null>]</cidx:AlternativeCommunicationMethod><cidx:AlternativeCommunicationMethod CommunicationMethodType=\"CellPhone\">5155326558</cidx:AlternativeCommunicationMethod></cidx:ContactInformation><cidx:AddressInformation><cidx:AddressLine>1802 OBRIEN AVE</cidx:AddressLine><cidx:CityName>Clarion</cidx:CityName><cidx:StateOrProvince>IA</cidx:StateOrProvince><cidx:PostalCode>50525761</cidx:PostalCode><cidx:PostalCountry>USA</cidx:PostalCountry></cidx:AddressInformation></cidx:PartnerInformation></cidx:Buyer><cidx:Seller><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AssignedBySeller\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:Seller><cidx:ShipTo><cidx:PartnerInformation><cidx:PartnerName>CHARLES MURPHY </cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AssignedBySeller\">255106</cidx:PartnerIdentifier><cidx:ContactInformation><cidx:ContactName>Charles Murphy</cidx:ContactName><cidx:ContactNumber>2195942917</cidx:ContactNumber><cidx:AlternativeCommunicationMethod CommunicationMethodType=\"Fax\">Telephone[&lt;null>,&lt;null>,&lt;null>,&lt;null>]</cidx:AlternativeCommunicationMethod><cidx:AlternativeCommunicationMethod CommunicationMethodType=\"CellPhone\">0000000000</cidx:AlternativeCommunicationMethod></cidx:ContactInformation><cidx:AddressInformation><cidx:AddressLine>4661 E WOOSTER RD</cidx:AddressLine><cidx:CityName>PIERCETON</cidx:CityName><cidx:StateOrProvince>IN</cidx:StateOrProvince><cidx:PostalCode>46562</cidx:PostalCode><cidx:PostalCountry>USA</cidx:PostalCountry></cidx:AddressInformation></cidx:PartnerInformation></cidx:ShipTo><cidx:Payer><cidx:PartnerInformation><cidx:PartnerName>RICK &amp; SHIRLEY STEVENS</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">1854842350000</cidx:PartnerIdentifier><cidx:ContactInformation><cidx:ContactName>RICK &amp; SHIRLEY STEVENS</cidx:ContactName><cidx:ContactDescription>SalesPerson</cidx:ContactDescription><cidx:ContactNumber>5155326558</cidx:ContactNumber><cidx:EmailAddress>Rick@aol.com</cidx:EmailAddress><cidx:AlternativeCommunicationMethod CommunicationMethodType=\"Fax\">Telephone[515,532,6558,&lt;null>]</cidx:AlternativeCommunicationMethod><cidx:AlternativeCommunicationMethod CommunicationMethodType=\"CellPhone\">5155326558</cidx:AlternativeCommunicationMethod></cidx:ContactInformation><cidx:AddressInformation><cidx:AddressLine>1802 OBRIEN AVE</cidx:AddressLine><cidx:CityName>Clarion</cidx:CityName><cidx:StateOrProvince>IA</cidx:StateOrProvince><cidx:PostalCode>50525761</cidx:PostalCode><cidx:PostalCountry>USA</cidx:PostalCountry></cidx:AddressInformation></cidx:PartnerInformation></cidx:Payer></OrderChangePartners><OrderChangeDetails><OrderChangeProductLineItem><cidx:LineNumber>999999</cidx:LineNumber><cidx:LineItemType>Sale</cidx:LineItemType><cidx:PurchaseOrderLineItemNumber>10</cidx:PurchaseOrderLineItemNumber><cidx:ProductIdentification><cidx:ProductIdentifier Agency=\"UPC\">070183007097</cidx:ProductIdentifier></cidx:ProductIdentification><cidx:ProductIdentification><cidx:ProductIdentifier Agency=\"AGIIS-ProductID\">00070183077472</cidx:ProductIdentifier></cidx:ProductIdentification><cidx:ProductQuantity><cidx:Measurement><cidx:MeasurementValue>20</cidx:MeasurementValue><cidx:UnitOfMeasureCode Domain=\"UN-Rec-20\">BG</cidx:UnitOfMeasureCode></cidx:Measurement></cidx:ProductQuantity><cidx:ScheduleDateTimeInformation ScheduleType=\"RequestedDelivery\"><cidx:DateTimeInformation><cidx:DateTime DateTimeQualifier=\"On\">2008-07-01T17:03:11Z</cidx:DateTime></cidx:DateTimeInformation></cidx:ScheduleDateTimeInformation><cidx:ActionRequest>Replace</cidx:ActionRequest></OrderChangeProductLineItem></OrderChangeDetails></OrderChangeBody></OrderChange>";
  private static final String XPATH_GO_RESPONSE = "/Envelope/Body/OrderResponse/OrderResponseBody/OrderResponseDetails/OrderResponseProductLineItem";

  public GrowerOrder_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcGO() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcGOBasicResponse() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, TEMPLATE_MESSAGE_XML);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testGO() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, TEMPLATE_MESSAGE_XML);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist",
        getConversationIdFromResponseDocument(responseXml));

    int lineItemCount = XPathUtil.getNodeCount(responseXml, XPATH_GO_RESPONSE);
    System.out.println("Number of GO line items retrieved: " + lineItemCount);
    assertFalse("At least one GO line item is expected", 0 == lineItemCount);
  }
}

/*
 * $Log: not supported by cvs2svn $
 */