/*
 * PPOS_AT was created on Jun 3, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.dbunit.Assertion;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.cf.logging.XmlUserActivity;
import com.monsanto.ag.xml.XPathUtil;

/**
 * Test the PPOS web services.
 * 
 * @author Chetna Aggarwal
 */
public class GOPPOS_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/GOPPOS_1-0";
  private static final String XPATH_TRANSACTION = "/Envelope/Body/ForecastedProductMovementReportResponse/ForecastedProductMovementReportResponseBody/ForecastedProductMovementReportResponseDetails/ForecastedProductMovementResponseTransactions/ForecastedProductMovementResponseTransaction";
  private static final String LINE_ITEM = "/ForecastedProductMovementResponseTransactionDetails/ForecastedProductMovementResponseProductLineItem";
  private static final String RESPONSE_STATUS = XPATH_TRANSACTION
      + "/ForecastedProductMovementResponseTransactionDetails/ForecastedProductMovementResponseProductLineItem/ResponseStatus";
  private static final String XPATH_TRANSACTION_RESPONSE_STATUS = XPATH_TRANSACTION
      + "/ForecastedProductMovementResponseTransactionProperties/ResponseStatus";
  private static final String XPATH_DETAILS_RESPONSE_STATUS = "/Envelope/Body/ForecastedProductMovementReportResponse/ForecastedProductMovementReportResponseBody/ForecastedProductMovementReportResponseDetails/ResponseStatus";

  public GOPPOS_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcGOPPOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcPreValidatingPPOSBasicResponse() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/PPOS/I3_Test3a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcGOPPOSSingleTransaction() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/I3_Test3a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
//     DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(1, transactionCount);

    assertXpathNotExists(RESPONSE_STATUS, responseXml);
    assertXpathNotExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that data is correct
    ITable actualEcgTable = getActualEcgGoPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3a");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));
  }

  public void testJaxRpcGOPPOSMultipleTransactions() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/I3_Test3b.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
//     DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION + LINE_ITEM);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(4, transactionCount);

    assertXpathNotExists(RESPONSE_STATUS, responseXml);
    assertXpathNotExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that data is correct
    ITable actualEcgTable = getActualEcgGoPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3b");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));

  }

  public void testJaxRpcGOPPOSNotPPOSReporter() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/I3_Test3c.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
//    DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION + LINE_ITEM);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(1, transactionCount);

    assertXpathNotExists(RESPONSE_STATUS, responseXml);
    assertXpathNotExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);
    assertXpathExists(XPATH_DETAILS_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that event has been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));

  }

  public void testJaxRpcGOPPOSVoidTransaction() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/I3_Test3h.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION + LINE_ITEM);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(1, transactionCount);

    assertXpathNotExists(RESPONSE_STATUS, responseXml);
    assertXpathNotExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that data is correct
    ITable actualEcgTable = getActualEcgGoPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3h");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));

  }

  public void testJaxRpcGOPPOSTransactionWithLineErrors() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/SingleTransactionWithLineItemErrorRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION + LINE_ITEM);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(1, transactionCount);

    assertXpathExists(RESPONSE_STATUS, responseXml);
    assertXpathNotExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that event has been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));

  }

  public void testJaxRpcGOPPOSTransactionWithTransactionErrors() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/TransactionWithTransactionErrorRequest.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION + LINE_ITEM);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(1, transactionCount);

    assertXpathNotExists(RESPONSE_STATUS, responseXml);
    assertXpathExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that event has been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));
  }

  public void testJaxRpcGOPPOSMultipleTransactionsMappingChanges() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GOPPOS/I3_Test3i.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    int transactionCount = XPathUtil.getNodeCount(responseXml, XPATH_TRANSACTION + LINE_ITEM);
    System.out.println("Number of transactions: " + transactionCount);
    assertEquals(4, transactionCount);

    assertXpathNotExists(RESPONSE_STATUS, responseXml);
    assertXpathNotExists(XPATH_TRANSACTION_RESPONSE_STATUS, responseXml);

    // Check that Log Record has been created
    ITable logTable = assertLogRecordCreated(conversationId);

    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();

    // Check that request XML has been stored in Data_Exchange_Repository
    assertRequestXMLLogged(dataExchangeId);

    // Check that response XML has been stored in Data_Exchange_Repository
    assertResponseXMLLogged(dataExchangeId);

    // Check that data is correct
    ITable actualEcgTable = getActualEcgGoPosStagingTable(conversationId);
    IDataSet expectedEcgDataSet = getEcgDbUnitHelper().getTestCaseDataSet(this.getClass(), "I3_Data3i");
    ITable expectedEcgTable = expectedEcgDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedEcgTable, actualEcgTable);

    // Check that two events have been logged
    //TODO: (MAS 6/6/08) Consider replacing the following lines with the single line:
    //          assertBothEventsLogged(conversationId);
    //      once the rest of the test is passing
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(1, eventTable.getRowCount());
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, eventTable.getValue(0, "STATUS_CODE"));

  }  

  private ITable assertLogRecordCreated(String conversationId) throws DataSetException, SQLException, Exception {
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GOPPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));
    return logTable;
  }

  private void assertRequestXMLLogged(String dataExchangeId) throws DataSetException, SQLException, Exception {
    ITable repositoryRequestTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ForecastedProductMovementReport"));
    assertEquals(1, repositoryRequestTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryRequestTable.getValue(0, "XML_MSG"));
  }

  private void assertResponseXMLLogged(String dataExchangeId) throws DataSetException, SQLException, Exception {
    ITable repositoryResponseTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ForecastedProductMovementReportResponse"));
    assertEquals(1, repositoryResponseTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryResponseTable.getValue(0, "XML_MSG"));
  }
}