/*
 * CustomerSearch_FT was created on Aug 6, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;

/**
 * Test the Customer Search web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: CustomerSearch_AT.java,v 1.5 2009-01-21 21:34:44 caggarw Exp $
 */
public class CustomerSearch_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/CustomerSearch_1-0";

  public CustomerSearch_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcCustomerSearch() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcCustomerSearchBasicResponse() throws Exception {
    String messageXml = getRequestXmlFromUri("/CustomerSearch/CustomerSearchRequest.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    // DOMUtil.outputXML(response.getDOM());
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcCustomerSearchCitySearch() throws Exception {
    String messageXml = getRequestXmlFromUri("/CustomerSearch/CustomerSearchRequest.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);

    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathCustomerSearchResponse = "/Envelope/Body/AGIISEntityInquiryResponse/Body/AGIISEntityInquiryResponseDetails/EntityInquiryResponse/EntityInformationResponse";
    int lineItemCount = XPathUtil.getNodeCount(responseXml, xpathCustomerSearchResponse);
    System.out.println("Number of Customer Search line items retrieved: " + lineItemCount);
    assertFalse("At least one Customer Search line item is expected", 0 == lineItemCount);
    assertTrue("50 line items expected", 50 == lineItemCount);
  }

}
