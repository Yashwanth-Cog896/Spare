package com.monsanto.ag.cf.acceptancetest;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;

public class ProductLight_ALSB_2_0_AT extends AcceptanceTestCase {
	private static final String ALSB_SERVICE_URI = "/soap/Products_2-0";	

	public ProductLight_ALSB_2_0_AT(String name) {
			  super(name);
	}
	public void testALSBProductLiteVersion2PullsBackProducts() throws Exception {
		GregorianCalendar fromDate = new GregorianCalendar(2008, Calendar.JULY, 4);
	    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());
	    String cidxHeader = buildCIDXHeaderFromDealerAccountId(fromDateUTC, "314525", "ST", "03.23.05", 2005, true);		    
		String messageXml = MessageFormatter.format(ProductList_AT.TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
		String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
		PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(ALSB_SERVICE_URI), wsseSecurityHeader, messageXml);
		WebResponse response = webConversation.getResponse(request);
		assertNotNull(response);
		assertEquals("text/xml", response.getContentType());
		Document responseXml = response.getDOM();
		assertNotNull("Valid document must be returned", responseXml);
		DOMUtil.outputXML(responseXml);
		final String xpathProduct = "/Envelope/Body/Products/Product";
		int productCount = XPathUtil.getNodeCount(responseXml, xpathProduct);
		System.out.println("Number of products extracted: " + productCount);
		assertFalse("At least one product is expected", 0 == productCount);
	}
}