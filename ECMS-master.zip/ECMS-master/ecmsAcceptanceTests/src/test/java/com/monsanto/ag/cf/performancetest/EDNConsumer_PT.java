package com.monsanto.ag.cf.performancetest;

import com.monsanto.ag.cf.acceptancetest.EDNConsumer_AT;
import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;

public class EDNConsumer_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for EDN Consumer");

    Test productList = new EDNConsumer_AT("testJaxRpcEDNConsumerBasicResponse");
    Test timedProductList = new TimedTest(productList,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedProductList);

    return suite;
  }

}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/07/27 18:25:09  ggdavi
 * Changed to a "heavyweight" service
 *
 * Revision 1.1  2005/07/26 18:22:19  ggdavi
 * Initial version
 *
 */