package com.monsanto.ag.cf.acceptancetest;

import java.io.IOException;
import java.net.MalformedURLException;

import org.xml.sax.SAXException;

import com.meterware.httpunit.GetMethodWebRequest;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;

public class PerformanceMonitorServlet_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/performanceMonitor";

  public PerformanceMonitorServlet_AT(String name) {
    super(name);
  }

  public void testEComPingTest() throws Exception {
    WebRequest request = createWebRequest();
    request.setParameter("pingType", "ecom");
    checkWhetherPingTestSucceeds(request);
  }

  public void testJMSPingTest() throws Exception {
    WebRequest request = createWebRequest();
    request.setParameter("pingType", "jmsBroker");
    checkWhetherPingTestSucceeds(request);
  }

  public void testECGPingTest() throws Exception {
    WebRequest request = createWebRequest();
    request.setParameter("pingType", "ecg");
    checkWhetherPingTestSucceeds(request);
  }

  public void testFarmSourcePingTest() throws Exception {
    WebRequest request = createWebRequest();
    request.setParameter("pingType", "farmSource");
    checkWhetherPingTestSucceeds(request);
  }

  public void testWMPingTest() throws Exception {
    WebRequest request = createWebRequest();
    request.setParameter("pingType", "webMethods");
    checkWhetherPingTestSucceeds(request);
  }

  private WebRequest createWebRequest() {
    WebRequest request = new GetMethodWebRequest(getServiceUrl(SERVICE_URI));
    return request;
  }

  private void checkWhetherPingTestSucceeds(WebRequest request) throws MalformedURLException, IOException, SAXException {
    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    
    //MAS 6-12-08: Started failing when run against CruiseControl; added
    // "text/plain" as an acceptable contentType in addition to "text/html"
    //assertEquals("text/html", response.getContentType());
    final String TEXT_HTML = "text/html";
    final String TEXT_PLAIN = "text/plain";
    String contentType = response.getContentType();
    if (!TEXT_HTML.equals(contentType) && !TEXT_PLAIN.equals(contentType)) {
      fail("response.getContentType() must be either " + TEXT_HTML + " or "
          + TEXT_PLAIN + ", but was " + contentType);
    }
    
    assertEquals(200, response.getResponseCode());
    assertEquals("OK", response.getResponseMessage());
    assertEquals("SUCCESS", response.getText());
  }

}
