/*
 * PAL_2_0_AT was created on May 21, 2008 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Date;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

public class PAL_2_0_AT extends AcceptanceTestCase {

//  private static final String SERVICE_URI = "/soap/PAL_2-0_Target";
  private static final String SERVICE_URI = "/soap/PAL_2-0";
  private final String xpathPALResponse = "/Envelope/Body/PriceAndAvailabilityResponse/PriceAndAvailabilityResponseBody/PriceAndAvailabilityResponseDetails/PriceAndAvailabilityResponseProductLineItem";
  private static final String TEMPLATE_MESSAGE_XML = "<PriceAndAvailabilityRequest xmlns=\"urn:ecms:schema:pal:request:2:0\" "
      + XmlNamespace.NAMESPACE_CIDX_50_DRAFT14.getDeclaration()
      + " xmlns:ecms=\"urn:ecms:schema:pal:request:2:0\" Version=\"2.0\">"
      + "<cidx:Header><cidx:ThisDocumentIdentifier><cidx:DocumentIdentifier>ClientConversationId</cidx:DocumentIdentifier>"
      + "</cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime>"
      + "<cidx:DateTime DateTimeQualifier=\"On\">2005-06-17T16:39:36Z</cidx:DateTime></cidx:ThisDocumentDateTime>"
      + "<cidx:From><cidx:PartnerInformation><cidx:PartnerName>Joe Dealer</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier "
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE
      + "=\""
      + CidxConstants.ACCOUNT_ID_AGENCY
      + "\">{1}</cidx:PartnerIdentifier></cidx:PartnerInformation>"
      + "</cidx:From><cidx:To><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier "
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE
      + "=\""
      + CidxConstants.EBID_AGENCY
      + "\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation>"
      + "</cidx:To></cidx:Header><PriceAndAvailabilityRequestBody><PriceAndAvailabilityRequestProperties>"
      + "<cidx:RequisitionNumber><cidx:DocumentIdentifier>123456</cidx:DocumentIdentifier>"
      + "</cidx:RequisitionNumber><RequisitionTypeCode Domain=\"ANSI-ASC-X12-92\">DEALRPAL"
      + "</RequisitionTypeCode><cidx:LanguageCode Domain=\"ISO-639-2T\">eng</cidx:LanguageCode>"
      + "<cidx:CurrencyCode Domain=\"ISO-4217\">USD</cidx:CurrencyCode><cidx:SpecialInstructions InstructionType=\"RequiredNotice\">Y</cidx:SpecialInstructions>"
      + "</PriceAndAvailabilityRequestProperties>"
      + "<PriceAndAvailabilityRequestPartners><cidx:Buyer><cidx:PartnerInformation><cidx:PartnerName>"
      + "SeedTrak_Dealer_Name</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AssignedByPapiNet\">0001020923"
      + "</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:Buyer><cidx:Seller>"
      + "<cidx:PartnerInformation><cidx:PartnerName>Monsanto Corporation</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier>"
      + "</cidx:PartnerInformation></cidx:Seller><cidx:ShipTo><cidx:PartnerInformation>"
      + "<cidx:PartnerName>SeedTrak_Dealer_Name</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier Agency=\"AssignedByPapiNet\">0001020923</cidx:PartnerIdentifier>"
      + "</cidx:PartnerInformation></cidx:ShipTo><cidx:Payer><cidx:PartnerInformation>"
      + "<cidx:PartnerName>SeedTrak_Dealer_Name</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AssignedBySeller\">"
      + "22599</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:Payer>"
      + "</PriceAndAvailabilityRequestPartners><PriceAndAvailabilityRequestDetails>"
      + "<PriceAndAvailabilityRequestProductLineItem><cidx:LineNumber>1</cidx:LineNumber>"
      + "<cidx:RequisitionLineItemNumber>12345</cidx:RequisitionLineItemNumber>"
      + "<ProductSelection><cidx:ProductIdentification><cidx:ProductIdentifier Agency=\"UPC\">70183291298"
      + "</cidx:ProductIdentifier><cidx:ProductClassification>C</cidx:ProductClassification></cidx:ProductIdentification>"
      + "</ProductSelection><cidx:ProductQuantity>"
      + "<cidx:Measurement><cidx:MeasurementValue>50</cidx:MeasurementValue>"
      + "<cidx:UnitOfMeasureCode Domain=\"UN-Rec-20\">BG</cidx:UnitOfMeasureCode>"
      + "</cidx:Measurement></cidx:ProductQuantity><cidx:ScheduleDateTimeInformation ScheduleType=\"RequestedDelivery\">"
      + "<cidx:DateTimeInformation><cidx:DateTime DateTimeQualifier=\"On\">2006-05-08T09:30:47.0Z</cidx:DateTime>"
      + "</cidx:DateTimeInformation></cidx:ScheduleDateTimeInformation></PriceAndAvailabilityRequestProductLineItem>"
      + "</PriceAndAvailabilityRequestDetails></PriceAndAvailabilityRequestBody></PriceAndAvailabilityRequest>";

  public PAL_2_0_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcPAL() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcPALBasicResponse() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
        cidxHeader, "0001020923");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);
    WebResponse response = webConversation.getResponse(request);
    // DOMUtil.outputXML(response.getDOM());
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testPAL() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);
//    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
//        cidxHeader, "22599");
    String messageXml = getRequestXmlFromUri("/PAL/GoodReq.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
     DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist",
        getConversationIdFromResponseDocument(responseXml));

    int lineItemCount = XPathUtil.getNodeCount(responseXml, xpathPALResponse);
    System.out.println("Number of PAL line items retrieved: " + lineItemCount);
    assertFalse("At least one PAL line item is expected", 0 == lineItemCount);
  }
  
  public void testPALWithGZIPCompression() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);
    String messageXml = getRequestXmlFromUri("/PAL/GoodReq.xml");
    System.out.println(messageXml);
//    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
//        cidxHeader, "22599");
    String wsseSecurityHeader = buildWSSecurityHeader("196426",
        "Ridd37");
    PostMethodWebRequest request = buildSoapRequestWithCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
     DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist",
        getConversationIdFromResponseDocument(responseXml));

    int lineItemCount = XPathUtil.getNodeCount(responseXml, xpathPALResponse);
    System.out.println("Number of PAL line items retrieved: " + lineItemCount);
    assertFalse("At least one PAL line item is expected", 0 == lineItemCount);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2008/07/22 17:54:54  caggarw
 * Added PAL and Grower Order FT for GOA II.
 * Revision 1.1 2008/06/04 15:03:49 caggarw Added new
 * service (PAL_2-0)
 * 
 */