/*
 * ProductLight_FT was created on Oct 2, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;


/**
 * Test the Product Light web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: ProductLight_AT.java,v 1.1 2007-10-02 18:51:46 caggarw Exp $
 */
public class ProductLight_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/Products_1-0";
  
  public ProductLight_AT(String name) {
    super(name);
  }
  
  public void testGetWsdlForJaxRpcProductLight() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcProductLightBasicResponse() throws Exception {
    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.JULY, 4);
    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());

    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(ProductList_AT.TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }
  
  public void testJaxRpcProductLight() throws Exception {
    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.MAY, 4);
    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());

    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(ProductList_AT.TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
//     DOMUtil.outputXML(responseXml);
    
    final String xpathProduct = "/Envelope/Body/Products/Product";
    int productCount = XPathUtil.getNodeCount(responseXml, xpathProduct);
    System.out.println("Number of products extracted: " + productCount);
    assertFalse("At least one product is expected", 0 == productCount);

  }
}
