/*
 * AgreementStatus_PT was created on Apr 27, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import com.monsanto.ag.cf.acceptancetest.AgreementStatus_AT;
import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;

/**
 * Test the performance of the AgreementStatus web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: AgreementStatus_PT.java,v 1.1 2007-05-01 18:18:42 caggarw Exp $
 */
public class AgreementStatus_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for AgreementStatus");

    Test agreementStatusList = new AgreementStatus_AT("testJaxRpcAgreementStatusLoadData");
    Test timedAgreementStatusList = new TimedTest(agreementStatusList, MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedAgreementStatusList);

    return suite;
  }

}
