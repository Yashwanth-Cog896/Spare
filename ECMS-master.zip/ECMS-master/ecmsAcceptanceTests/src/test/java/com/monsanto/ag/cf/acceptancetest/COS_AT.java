/*
 * COS_AT was created on Jun 7, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Date;
import java.util.Properties;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Test the COS web services.
 * 
 * @author caggarw
 * @version $Id: COS_AT.java,v 1.3 2009-01-21 21:34:44 caggarw Exp $
 */
public class COS_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/COS_1-0";
  
  // TODO get an SAPID that will fetch COS data in H08 and D08
  private static final String COS_USERID = "1660158";
  private static final String COS_PASSWORD = "Test_123";
  
  private static final String TEMPLATE_MESSAGE_XML = "<OrderStatusListRequest xmlns=\"urn:ecms:schema:cos:request:1:0\" "
      + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
      + " xmlns:ecms=\"urn:ecms:schema:cos:request:1:0\" Version=\"1.0\">"
      + "<cidx:Header><cidx:ThisDocumentIdentifier><cidx:DocumentIdentifier>ClientConversationId</cidx:DocumentIdentifier>"
      + "</cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime>"
      + "<cidx:DateTime DateTimeQualifier=\"On\">2005-06-17T16:39:36Z</cidx:DateTime></cidx:ThisDocumentDateTime>"
      + "<cidx:From><cidx:PartnerInformation><cidx:PartnerName>Joe Dealer</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.SAP_ID_AGENCY + "\">{1}</cidx:PartnerIdentifier></cidx:PartnerInformation>"
      + "</cidx:From><cidx:To><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation>"
      + "</cidx:To></cidx:Header><OrderStatusListRequestBody><OrderStatusListRequestProperties/>"
      + "<OrderStatusListRequestPartners><cidx:Seller><cidx:PartnerInformation>"
      + "<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">0062668030000</cidx:PartnerIdentifier>"
      + "</cidx:PartnerInformation></cidx:Seller></OrderStatusListRequestPartners>"
      + "<OrderStatusListRequestDetails/></OrderStatusListRequestBody></OrderStatusListRequest>";

  public COS_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcCOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcCOSBasicResponse() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
        cidxHeader, getSAPIdBasedOnEnvironment());
    String wsseSecurityHeader = buildWSSecurityHeader(COS_USERID, COS_PASSWORD,
        null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcCOS() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
        cidxHeader, getSAPIdBasedOnEnvironment());
    String wsseSecurityHeader = buildWSSecurityHeader(COS_USERID, COS_PASSWORD,
        null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
     DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist",
        getConversationIdFromResponseDocument(responseXml));

    final String xpathCOSResponse = "/Envelope/Body/OrderStatusListResponse/OrderStatusListResponseBody/OrderStatusListResponseDetails/OrderStatusResponseBody";
    int lineItemCount = XPathUtil.getNodeCount(responseXml, xpathCOSResponse);
    System.out.println("Number of COS line items retrieved: " + lineItemCount);
    assertFalse("At least one COS line item is expected", 0 == lineItemCount);
    
//  Check that Log Record has been created
//    ITable logTable = getEcomDbUnitHelper().getActualTable(
//        buildActivityLogSql(conversationId));
//    assertEquals(1, logTable.getRowCount());    
//    Object transactionCount = logTable.getValue(0, "TRANSACTION_COUNT");
//    System.out.print("Object type " + transactionCount.getClass().getName());
//    assertEquals(new BigDecimal(1), transactionCount);
    
  }

  private String getSAPIdBasedOnEnvironment() throws Exception {
    Properties ecomProps = getAcceptanceTestEnvironmentProperties("ecom-test.properties");
    String SAPId;
    String url = ecomProps.getProperty("url.base");
    if ("http://wwwd.webservices.farmsource.monsanto.com/ecms".equals(url) || "http://localhost:8080/ecms".equals(url)) {
      SAPId = "1003520";
    } else {
      SAPId = "1660158";
    }
    return SAPId;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2008/06/05 20:18:16  mkuchip
 * new COS_2-0 service
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.14  2006/07/26 17:41:45  caggarw
 * Use CIDXConstants for Agency Attributes
 *
 * Revision 1.13  2006/05/09 23:48:45  ggdavi
 * Removed protected namespace declaration constants from CidxMessageTestCase - now use the XmlNamespace constants directly
 *
 * Revision 1.12  2006/04/24 19:50:35  caggarw
 * *** empty log message ***
 *
 * Revision 1.11  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.10  2005/11/30 15:49:05  caggarw
 * use fully resolved url
 *
 * Revision 1.9  2005/09/27 17:56:20  caggarw
 * change the SAPId in the request based on the environments (dev or test)
 * Revision 1.8 2005/09/27 15:29:04 ggdavi Extracted
 * userId and password to constants
 * 
 * Revision 1.7 2005/08/17 14:00:17 ggdavi Removed extraction of DOM document
 * from test*BasicResponse methods, since it adds unnecessary time to the
 * performance tests that use them
 * 
 * Revision 1.6 2005/08/10 17:15:51 ggdavi Changed user; removed Xpath-based
 * assertions from testJaxRpc*BasicResponse and put then into a new test method,
 * so they won't impact the performance tests Revision 1.5 2005/08/08 16:53:15
 * ggdavi Added fix me comment
 * 
 * Revision 1.4 2005/08/05 18:47:22 ggdavi Cleaned up debug statements
 * 
 * Revision 1.3 2005/07/26 22:20:44 caggarw added testJaxRpcCOSBasicResponse()
 * Revision 1.2 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method Revision 1.1 2005/06/10 18:56:13
 * caggarw add AT for COS
 * 
 */