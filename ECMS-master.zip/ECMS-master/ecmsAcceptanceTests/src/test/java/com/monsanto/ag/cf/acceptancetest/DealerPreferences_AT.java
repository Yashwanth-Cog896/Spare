/*
 * DealerPreferences_AT was created on Apr 22, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Date;

import junit.framework.ComparisonFailure;

import org.apache.xpath.XPathAPI;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.operation.DatabaseOperation;
import org.w3c.dom.Document;
import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Test the Dealer Preferences web services.
 * 
 * @author lsdenny $Id: DealerPreferences_AT.java,v 1.5 2005/04/22 20:47:24
 *         lsdenny Exp $
 */
public class DealerPreferences_AT extends AcceptanceTestCase {

  private static final String NEW_LINE = System.getProperty("line.separator");
  private static final String SERVICE_URI = "/soap/DealerPreferences";

  private static final String NOT_AUTHORIZED_USER_ID = "1730073";
  private static final String NOT_AUTHORIZED_USER_PASSWORD = "EF#45ghi";
  private static final String NOT_AUTHORIZED_USER_EBID = "6234379280000";
  private static final String EXPIRED_USER_ID = "136065";
  private static final String EXPIRED_USER_PASSWORD = "rJ1sK9kZ";
  private static final String NOT_EXISTS_USER_ID = "LINDA1";
  private static final String NOT_EXISTS_USER_PASSWORD = "trytowork";
//  private static final String GOOD_CHILD_USER_ID = "1022957";
// private static final String GOOD_CHILD_USER_PASSWORD = "Test_123";
//  private static final String GOOD_CHILD_USER_EBID = "0180511850000";
  private static final String CREDENTIALS_EXPIRED_MESSAGE = "Your FarmSource password has expired. You need to log into FarmSource and change your password to update the account. Data exchange can then be completed";

  // private static final int GOOD_CHILD_USER_ACCOUNT_ID = 12900;

  public DealerPreferences_AT(String name) {
    super(name);
  }

  public void testJaxRpcDealerPreferencesBasicResponse() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcDealerPreferencesReturnsFullPOSRefresh()
      throws Exception {
    IDataSet iDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(),
        "InsertGPOSSpecialInstruction");
    DatabaseOperation.CLEAN_INSERT.execute(getEcomDbUnitHelper()
        .getDbConnection(), iDataSet);

    iDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(),
        "InsertPPOSSpecialInstruction");
    DatabaseOperation.INSERT.execute(getEcomDbUnitHelper().getDbConnection(),
        iDataSet);

    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();
    DOMUtil.outputXML(responseXml);
    assertXpathEvaluatesTo("REFRSH",
        "/Envelope/Body/preferences/special-instructions/gpos/instruction",
        responseXml);
    assertXpathEvaluatesTo("REFRSH",
        "/Envelope/Body/preferences/special-instructions/ppos/instruction",
        responseXml);
  }

  public void testJaxRpcDealerPreferencesAuthorizedUserNoSpecialInstructions()
      throws Exception {
    IDataSet iDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(),
        "NoSpecialInstructions");
    DatabaseOperation.CLEAN_INSERT.execute(getEcomDbUnitHelper()
        .getDbConnection(), iDataSet);

    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);
    assertEquals("Server Time must be current time within tolerance",
        new Date().getTime(), XPathUtil.getDateNodeValue(responseXml,
            "/Envelope/Body/preferences/Header/ThisDocumentDateTime/DateTime")
            .getTime(), 30000);
    assertXpathEvaluatesTo(
        String.valueOf(GOOD_USER_EBID),
        "/Envelope/Body/preferences/Header/To/PartnerInformation/PartnerIdentifier[@" + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.EBID_AGENCY + "']",
        responseXml);

    //MAS 2/8/08:
    //Following test commented out since is NOT a good idea; 
    // the number of roles is constantly changing. Some specific roles of 
    // interest are verified below, so no purpose is served by counting the 
    // total number of roles.
//    assertXpathEvaluatesTo("6",
//        "count(/Envelope/Body/preferences/roles/role-name)", responseXml);

    assertXpathEvaluatesTo("1",
        "count(/Envelope/Body/preferences/roles[role-name='GPOS_REPORTER'])",
        responseXml);
    assertXpathEvaluatesTo("1",
        "count(/Envelope/Body/preferences/roles[role-name='FPOS_REPORTER'])",
        responseXml);
    assertXpathEvaluatesTo("1",
        "count(/Envelope/Body/preferences/roles[role-name='PPOS_REPORTER'])",
        responseXml);
    //MAS 3-31-8 : There are plenty of roles to test which are present in the
    // response, but DATA_RETRIEVER isn't one of them
//    assertXpathEvaluatesTo("1",
//        "count(/Envelope/Body/preferences/roles[role-name='DATA_RETRIEVER'])",
//        responseXml);

    assertXpathEvaluatesTo("",
        "/Envelope/Body/preferences/special-instructions/gpos/instruction",
        responseXml);
    assertXpathEvaluatesTo("",
        "/Envelope/Body/preferences/special-instructions/ppos/instruction",
        responseXml);

    ITable table = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    int myRow = 0;
    assertEquals(1, table.getRowCount());
    assertEquals(GOOD_USER_ID, table.getValue(myRow, "USER_ID"));
    assertEquals("PREF", table.getValue(myRow, "DATA_EXCHANGE_TYPE_CODE"));
    assertTrue("DATA_EXCHANGE_START_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(table, myRow,
            "DATA_EXCHANGE_START_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(table, myRow,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", table.getValue(myRow, "SEED_YEAR"));
    assertEquals("03.23.05", table.getValue(myRow, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), table.getValue(myRow,
        "ACCT_ID"));
  }

  public void testJaxRpcDealerPreferencesAuthorizedUserSpecialInstructionsGpos()
      throws Exception {
    IDataSet iDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(),
        "InsertGPOSSpecialInstruction");
    DatabaseOperation.CLEAN_INSERT.execute(getEcomDbUnitHelper()
        .getDbConnection(), iDataSet);

    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);
    assertEquals("Server Time must be current time within tolerance",
        new Date().getTime(), XPathUtil.getDateNodeValue(responseXml,
            "/Envelope/Body/preferences/Header/ThisDocumentDateTime/DateTime")
            .getTime(), 30000);
    assertXpathEvaluatesTo(
        String.valueOf(GOOD_USER_EBID),
        "/Envelope/Body/preferences/Header/To/PartnerInformation/PartnerIdentifier[@" + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "='" + CidxConstants.EBID_AGENCY + "']",
        responseXml);
    //MAS 2/8/08:
    //Following test commented out since is NOT a good idea; 
    // the number of roles is constantly changing. Some specific roles of 
    // interest are verified below, so no purpose is served by counting the 
    // total number of roles.
//    assertXpathEvaluatesTo("6",
//        "count(/Envelope/Body/preferences/roles/role-name)", responseXml);
    assertXpathEvaluatesTo("1",
        "count(/Envelope/Body/preferences/roles[role-name='GPOS_REPORTER'])",
        responseXml);
    assertXpathEvaluatesTo("1",
        "count(/Envelope/Body/preferences/roles[role-name='FPOS_REPORTER'])",
        responseXml);
    assertXpathEvaluatesTo("1",
        "count(/Envelope/Body/preferences/roles[role-name='PPOS_REPORTER'])",
        responseXml);
    //MAS 3-31-8 : There are plenty of roles to test which are present in the
    // response, but DATA_RETRIEVER isn't one of them
//    assertXpathEvaluatesTo("1",
//        "count(/Envelope/Body/preferences/roles[role-name='DATA_RETRIEVER'])",
//        responseXml);

    assertNotNull(XPathAPI
        .selectSingleNode(responseXml,
            "/Envelope/Body/preferences/special-instructions/gpos[instruction='REFRSH']"));

    // DOMUtil.outputXML(responseXml);
    assertNull(XPathAPI.selectSingleNode(responseXml,
        "/Envelope/Body/preferences/special-instructions/ppos/instruction"));

    ITable table = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    assertEquals(1, table.getRowCount());
    assertEquals(GOOD_USER_ID, table.getValue(0, "USER_ID"));
    assertEquals("PREF", table.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertTrue("DATA_EXCHANGE_START_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(table, 0,
            "DATA_EXCHANGE_START_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(table, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", table.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", table.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), table.getValue(0,
        "ACCT_ID"));
  }

  public void testJaxRpcChildPreferencesWithAuthorizedUser() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();
    
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    assertEquals("Server Time must be current time within tolerance",
        new Date().getTime(), XPathUtil.getDateNodeValue(responseXml,
            "/Envelope/Body/preferences/Header/ThisDocumentDateTime/DateTime")
            .getTime(), 30000);

    ITable table = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    assertEquals(1, table.getRowCount());
    assertEquals(GOOD_USER_ID, table.getValue(0, "USER_ID"));
    assertEquals("PREF", table.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertTrue("DATA_EXCHANGE_START_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(table, 0,
            "DATA_EXCHANGE_START_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(table, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", table.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", table.getValue(0, "SOFTWARE_VERSION_ID"));
    // assertEquals(new Integer(GOOD_CHILD_USER_ACCOUNT_ID),
    // table.getValue(0,
    // "ACCT_ID"));
  }

  public void testJaxRpcDealerPreferencesWithGoodUserExpiredPassword()
      throws Exception {
    int origDbLogRowCount = getDataExchangeLogRowCount();
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(EXPIRED_USER_ID,
        EXPIRED_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(responseXml);
    try {
      assertXpathEvaluatesTo("ecms:" + CREDENTIALS_EXPIRED_MESSAGE,
          "/Envelope/Body/Fault/faultcode", responseXml);
      assertXpathEvaluatesTo("The security token is no longer valid",
          "/Envelope/Body/Fault/faultstring", responseXml);
    } catch (ComparisonFailure e) {
      //Didn't get a CredentialsExpired failure, but some other sort of authentication
      // failure. Give a warning, but don't fail the test.
      assertXpathEvaluatesTo("wsse:FailedAuthentication",
          "/Envelope/Body/Fault/faultcode", responseXml);
      assertXpathEvaluatesTo("The security token could not be authenticated or authorized",
          "/Envelope/Body/Fault/faultstring", responseXml);
      logError("testJaxRpcDealerPreferencesWithGoodUserExpiredPassword() " 
          + "did NOT confirm an 'ecms:" + CREDENTIALS_EXPIRED_MESSAGE
          + "'," + NEW_LINE + " but did confirm a failed authentication. Check status of FarmSource user ID/password "
          + EXPIRED_USER_ID + "/" + EXPIRED_USER_PASSWORD + " and configure those, or this test, appropriately.");
    }

    assertEquals(origDbLogRowCount, getDataExchangeLogRowCount());
  }

  public void testJaxRpcDealerPreferencesWithNoWSSecurityHeader() throws Exception {
    int origDbLogRowCount = getDataExchangeLogRowCount();
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), null, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertXpathEvaluatesTo("soapenv:Server.generalException",
        "/Envelope/Body/Fault/faultcode", responseXml);
    assertXpathEvaluatesTo(
        "WSDoAllReceiver: Request does not contain required Security header",
        "/Envelope/Body/Fault/faultstring", responseXml);

    assertEquals(origDbLogRowCount, getDataExchangeLogRowCount());
  }

  public void testJaxRpcDealerPreferencesWithWrongPassword() throws Exception {
    int origDbLogRowCount = getDataExchangeLogRowCount();
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        NOT_EXISTS_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertXpathEvaluatesTo("wsse:FailedAuthentication",
        "/Envelope/Body/Fault/faultcode", responseXml);
    assertXpathEvaluatesTo(
        "The security token could not be authenticated or authorized",
        "/Envelope/Body/Fault/faultstring", responseXml);

    assertEquals(origDbLogRowCount, getDataExchangeLogRowCount());
  }

  public void testJaxRpcDealerPreferencesWithNonUser() throws Exception {
    int origDbLogRowCount = getDataExchangeLogRowCount();
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(NOT_EXISTS_USER_ID,
        NOT_EXISTS_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertXpathEvaluatesTo("wsse:FailedAuthentication",
        "/Envelope/Body/Fault/faultcode", responseXml);
    assertXpathEvaluatesTo(
        "The security token could not be authenticated or authorized",
        "/Envelope/Body/Fault/faultstring", responseXml);

    assertEquals(origDbLogRowCount, getDataExchangeLogRowCount());
  }

  public void testJaxRpcDealerPreferencesWithUnauthorizedUser()
      throws Exception {
    int origDbLogRowCount = getDataExchangeLogRowCount();
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), NOT_AUTHORIZED_USER_EBID, "ST", "03.23.05",
        2005, false);
    String messageXml = "<preferences-request " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader + "</preferences-request>";
    String wsseSecurityHeader = buildWSSecurityHeader(NOT_AUTHORIZED_USER_ID,
        NOT_AUTHORIZED_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertXpathEvaluatesTo("wsse:FailedAuthentication",
        "/Envelope/Body/Fault/faultcode", responseXml);
    assertXpathEvaluatesTo(
        "The security token could not be authenticated or authorized",
        "/Envelope/Body/Fault/faultstring", responseXml);

    assertEquals(origDbLogRowCount, getDataExchangeLogRowCount());
  }

  public void testGetHandheldVersion() throws Exception {
	  String REQUEST_XML = 
		  "<preferences-request xmlns=\"urn:cidx:names:specification:ces:schema:all:4:0\" xmlns:cidx=\"urn:cidx:names:specification:ces:schema:all:4:0\">" + 
		  "<Header><ThisDocumentIdentifier><DocumentIdentifier>DealerPreferences</DocumentIdentifier></ThisDocumentIdentifier><ThisDocumentDateTime>" +
		  "<DateTime DateTimeQualifier=\"On\">2008-04-30T15:08:46Z</DateTime></ThisDocumentDateTime>"+
		  "<From><PartnerInformation><PartnerName>Dean A. Booth</PartnerName>" +
		  "<PartnerIdentifier Agency=\"AGIIS-EBID\">0301682930000</PartnerIdentifier><ContactInformation><ContactDescription>DataSource</ContactDescription>" +
		  "<ContactName>SeedTrak</ContactName></ContactInformation><ContactInformation><ContactDescription>SeedYear</ContactDescription><ContactName>2008</ContactName>"+
		  "</ContactInformation><ContactInformation><ContactDescription>SoftwareVersion</ContactDescription><ContactName>3.1.44</ContactName></ContactInformation>"+
		  "</PartnerInformation></From><To><PartnerInformation><PartnerName>MONSANTO AGRICULTURAL CO</PartnerName>"+
		  "<PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</PartnerIdentifier></PartnerInformation></To></Header>"+
		  "{0}</preferences-request>";
	  String DEVICE_INFO = "<handheld><devices><device><applications><application name=\"SeedTrak Mobile Inventory\" version=\"3.1.33\"/></applications></device></devices></handheld>";
	  String messageXml = MessageFormatter.format(REQUEST_XML, DEVICE_INFO);
	  String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
	            GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==", "2005-03-17T00:00:00");
	  PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);
	  WebResponse response = webConversation.getResponse(request);
	  Document responseXml = response.getDOM();
	  DOMUtil.outputXML(responseXml);
	  
	  String XPATH_HANDHELD_DEVICE_APP = "/Envelope/Body/preferences/handheld/applications/application/@name";	  
	  assertXpathEvaluatesTo("SeedTrak Mobile Inventory", XPATH_HANDHELD_DEVICE_APP,responseXml);
	  
	// can not assert on version,because its changing 
	//  assertXpathEvaluatesTo("2.6.2", "/Envelope/Body/preferences/Header/From/PartnerInformation/ContactInformation/ContactName",responseXml);
	  
  }  
  
  private int getDataExchangeLogRowCount() throws Exception {
    return getEcomDbUnitHelper().getRowCount("DATA_EXCHANGE_LOG");
  }

}