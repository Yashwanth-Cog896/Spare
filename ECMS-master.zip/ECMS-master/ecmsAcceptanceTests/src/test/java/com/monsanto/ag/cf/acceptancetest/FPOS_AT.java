/*
 * FPOS_AT was created on Jun 1, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;

/**
 * Test the FPOS web services.
 * 
 * Note: When dates are written to the DIRECT_STAGING table by WebMethods,
 * which these web services call, GMT date/times are transformed to St. Louis
 * date/times. Therefore dates such as 2004-07-15T00:00:00Z become
 * 2004-07-14 since St. Louis is 5 or 6 hours prior to GMT depending on whether
 * Daylight Savings Time is in effect.  The fields in DIRECT_STAGING affected
 * are RPT_DATE, INV_DATE and SHIP_DATE.
 * 
 * @author Gareth Davies
 * @version $Id: FPOS_AT.java,v 1.3 2008-06-06 15:00:05 maschec Exp $
 */
public class FPOS_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/FPOS_4-0";
  
  public FPOS_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcFPOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcFPOSBasicResponse() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcFPOSMultipleTransactions() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(docBody);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34)
        .getTime(), logTable.getValue(0, "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(logTable, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0,
        "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0,
        "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(
        this.getClass(), "I3_Data4a");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcFPOSSalesReplants() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4b.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(docBody);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34)
        .getTime(), logTable.getValue(0, "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(logTable, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0,
        "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0,
        "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(
        this.getClass(), "I3_Data4b");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcFPOSFarmFlex() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4c.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(docBody);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34)
        .getTime(), logTable.getValue(0, "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(logTable, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0,
        "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0,
        "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(
        this.getClass(), "I3_Data4c");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }
  
  public void testJaxRpcFPOSFarmManagerMappingChanges() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4d.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(docBody);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(
        buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34)
        .getTime(), logTable.getValue(0, "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time",
        getEcomDbUnitHelper().isDateColumnValueNearCurrentTime(logTable, 0,
            "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0,
        "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0,
        "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(
        this.getClass(), "I3_Data4d");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2008/04/14 16:23:47  maschec
 * Update FPOS acceptance test to reflect fix that now stores dates in DIRECT_STAGING in St. Louis time rather than GMT time.
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.17  2006/07/26 17:58:21  caggarw
 * adde test to check farm manager detailsas per new mappings for SeedTrak
 *
 * Revision 1.16  2006/06/26 15:19:07  caggarw
 * root_node_name added to data_exchange_repository as a primary key
 *
 * Revision 1.15  2006/05/01 20:44:03  ggdavi
 * Updated to reflect changes in DbUnitHelper
 *
 * Revision 1.14  2005/09/02 18:21:53  ggdavi
 * Refactored getRequestXmlFromUri method from xPOS_AT to read request XML from files
 *
 * Revision 1.13  2005/08/17 14:00:17  ggdavi
 * Removed extraction of DOM document from test*BasicResponse methods, since it adds unnecessary time to the performance tests that use them
 *
 * Revision 1.12  2005/07/19 17:43:36  ggdavi
 * All PostMethodWebRequest objects are built using the superclass's buildSoapRequestWithCompression or buildSoapRequestWithoutCompression methods
 *
 * Revision 1.11  2005/06/30 17:43:26  ggdavi
 * Moved ag.aop, ag.config and ag.message packages under the ag.cf package
 *
 * Revision 1.10  2005/06/30 16:20:28  ggdavi
 * Moved body of WSDL test methods into base class assertWsdlServiceUrl method
 * Revision 1.9 2005/06/10 19:10:42 sravipa *** empty log
 * message ***
 * 
 * Revision 1.8 2005/06/10 17:20:00 ggdavi Removed extraneous comments and
 * useless assertions
 * 
 * Revision 1.7 2005/06/10 16:39:50 sravipa chnaged file I3Test4a to i3_Test4a
 * 
 * Revision 1.6 2005/06/10 14:51:34 ggdavi Removed unnecessary checkEachValue
 * method
 * 
 * Revision 1.5 2005/06/09 21:57:42 sravipa *** empty log message ***
 * 
 * Revision 1.4 2005/06/07 17:00:53 ggdavi Added to do comments
 * 
 * Revision 1.3 2005/06/06 19:44:14 ggdavi Now use wrapMessageInSoap method
 * Revision 1.2 2005/06/06 17:07:02 ajbaldw created a very basic test case for
 * FPOS. Revision 1.1 2005/06/01 19:06:42 ggdavi Initial version
 *  
 */