/*
 * BroadcastMessage_PT was created on Jun 2, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import com.monsanto.ag.cf.acceptancetest.BroadcastMessage_AT;
import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;

/**
 * Test the performance of the GPOS web service.
 * 
 * @author Gareth Davies
 * @version $Id: BroadcastMessage_PT.java,v 1.3 2006-08-14 21:14:59 caggarw Exp $
 */
public class BroadcastMessage_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for Broadcast Message");

    Test broadcastMessages = new BroadcastMessage_AT(
        "testJaxRpcBroadcastMessageBasicResponse");
    Test timedBroadcastMessages = new TimedTest(broadcastMessages,
        MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedBroadcastMessages);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/08/17 13:54:24  ggdavi
 * Added testJaxRpcBroadcastMessageBasicResponse for performance test usage
 *
 * Revision 1.1  2005/06/02 19:15:27  ggdavi
 * Initial version
 *
 */