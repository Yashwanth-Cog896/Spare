/*
 * GPOS_PT was created on Jun 2, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import com.monsanto.ag.cf.acceptancetest.GPOS_AT;
import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;

/**
 * Test the performance of the GPOS web service.
 * 
 * @author Gareth Davies
 * @version $Id: GPOS_PT.java,v 1.2 2006-08-14 21:14:59 caggarw Exp $
 */
public class GPOS_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for GPOS");

    Test gpos = new GPOS_AT("testJaxRpcGPOSBasicResponse");
    TimedTest timedGpos = new TimedTest(gpos,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedGpos);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/06/02 19:15:27  ggdavi
 * Initial version
 *
 */