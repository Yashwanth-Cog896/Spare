/*
 * BroadcastMessage_AT was created on May 20, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;
import org.w3c.dom.Document;

import java.util.Date;

/**
 * Test the BroadcastMessage web service.
 * 
 * @author ajbaldw
 * @version $Id: BroadcastMessage_AT.java,v 1.2 2008-02-13 16:23:31 maschec Exp $
 */
public class BroadcastMessage_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/BroadcastMessage";
  private static final String GOOD_SOFTWARE_VERSION = "09.26.05";

  public BroadcastMessage_AT(String name) {
    super(name);
  }

  public void testJaxRpcBroadcastMessageBasicResponse() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", GOOD_SOFTWARE_VERSION,
        2005, true);
    String messageXml = "<BroadcastMessageRequest " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration()
        + " " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader
        + "<BroadcastMessageRequestBody/></BroadcastMessageRequest>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcBroadcastMessageFirstPass() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", GOOD_SOFTWARE_VERSION,
        2006, true);
    String messageXml = "<BroadcastMessageRequest " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration()
        + " " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration() + ">" + cidxHeader
        + "<BroadcastMessageRequestBody/>" 
        + "</BroadcastMessageRequest>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(responseXml);

    final String xpathBroadcastMessage = "/Envelope/Body/BroadcastMessage/BroadcastMessageBody/MessageDetail";
    int broadcastMessageCount = XPathUtil.getNodeCount(responseXml,
        xpathBroadcastMessage);
    System.out.println("Number of broadcast messages extracted: "
        + broadcastMessageCount);
    assertFalse("At least one broadcast message is expected",
        0 == broadcastMessageCount);

    assertXpathExists(
        "/Envelope/Body/BroadcastMessage/BroadcastMessageBody/MessageDetail[1]/MessageIdentifier",
        responseXml);
    assertXpathExists(
        "/Envelope/Body/BroadcastMessage/BroadcastMessageBody/MessageDetail[1]/MessageDescription",
        responseXml);
    assertXpathExists(
        "/Envelope/Body/BroadcastMessage/BroadcastMessageBody/MessageDetail[1]/MessageText",
        responseXml);
  }

  public void testJaxRpcBroadcastMessageSecondPass() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", GOOD_SOFTWARE_VERSION,
        2005, true);
    String messageXml = "<BroadcastMessageRequest "
        + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration()
        + " "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + ">"
        + cidxHeader
        + "<BroadcastMessageRequestBody><MessageDetail>"
        + "<MessageIdentifier>-1</MessageIdentifier>"
        + "<MessageIdentifier>-2</MessageIdentifier>"
        + "<MessageIdentifier>-3</MessageIdentifier>"
        + "</MessageDetail></BroadcastMessageRequestBody></BroadcastMessageRequest>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(responseXml);
    // do we really even care what comes back for the second pass?
    assertXpathExists("/Envelope/Body/BroadcastMessage/BroadcastMessageBody",
        responseXml);
  }
}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1.8.1  2008/02/10 22:10:47  maschec
 * Replace invalid SoftwareVersionID with valid one
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.24  2006/05/09 23:48:45  ggdavi
 * Removed protected namespace declaration constants from CidxMessageTestCase - now use the XmlNamespace constants directly
 *
 * Revision 1.23  2006/01/23 17:07:52  caggarw
 * changed test for 2006
 *
 * Revision 1.22  2005/12/01 19:34:30  ggdavi
 * Refactored com.monsanto.ag.util package, moving all XML-specific classes and tests into the new com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as the primary representation of a collection of XML chunks
 *
 * Revision 1.21  2005/08/19 15:55:16  ggdavi
 * Output the number of transactions used for the basic response tests to the console (in another test)
 * Revision 1.20 2005/08/17 13:54:24 ggdavi
 * Added testJaxRpcBroadcastMessageBasicResponse for performance test usage
 * 
 * Revision 1.19 2005/07/19 17:43:36 ggdavi All PostMethodWebRequest objects are
 * built using the superclass's buildSoapRequestWithCompression or
 * buildSoapRequestWithoutCompression methods Revision 1.18 2005/07/08 17:12:24
 * ggdavi Split SoapTestCase.buildCidxHeader into buildCidxHeaderFromDealer and
 * buildCidxHeaderToDealer methods
 * 
 * Revision 1.17 2005/06/28 18:31:15 ggdavi Modified
 * testGetBroadcastMessageFirstPass to not be so dependent on number of returned
 * records Revision 1.16 2005/06/27 20:21:12 ajbaldw Fixed the issue with
 * padding the EBID.
 * 
 * Revision 1.15 2005/06/15 15:48:28 ggdavi Cleaned up debugging output
 * 
 * Revision 1.14 2005/06/14 18:51:58 ajbaldw added another (commented out)
 * assertion. We don't seem to be confirming the messages correctly. Revision
 * 1.13 2005/06/02 16:39:23 ggdavi All XPaths now work on the SOAP document
 * Revision 1.12 2005/06/01 18:56:52 ggdavi Refactored for consistency Revision
 * 1.11 2005/06/01 17:17:11 ggdavi Added prefix flag to
 * SoapTestCase.buildCIDXHeader
 * 
 * Revision 1.10 2005/05/27 23:10:46 ajbaldw working acceptance tests. Revision
 * 1.9 2005/05/26 21:26:33 ajbaldw changed all xpath assertions to assertEquals
 * or the like because of the cidx: prefixes. Revision 1.8 2005/05/25 22:30:36
 * ggdavi Added CIDX namespaces to input document Revision 1.5 2005/05/24
 * 16:24:27 ggdavi Replaced SoapTestCase.buildEcmsHeader with buildCIDXHeader
 * and added constants for the default and CIDX namespace declarations
 * 
 * Revision 1.4 2005/05/23 19:29:20 ggdavi Changed XPaths to reflect enclosure
 * in SOAP message Revision 1.3 2005/05/23 16:06:02 ggdavi Removed to do comment
 * 
 * Revision 1.2 2005/05/20 20:42:18 ajbaldw changed to reflect new request
 * schema.
 * 
 * Revision 1.1 2005/05/20 17:03:03 ajbaldw Initial version
 * 
 */