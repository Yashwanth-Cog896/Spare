package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.PointOfServiceFPOS_AT;

public class PointOfServiceFPOS_PT extends PerformanceTestCase {
  
  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for PointOfService FPOS");

    Test gpos = new PointOfServiceFPOS_AT("testFPOSService");
    TimedTest timedGpos = new TimedTest(gpos,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedGpos);

    return suite;
  }

}
