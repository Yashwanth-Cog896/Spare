package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Properties;

import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;

/**
 * Test the COS web services.
 * 
 * @author mkuchip
 */
public class COS_2_0_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/COS_2-0";
    
  private static final String TEMPLATE_MESSAGE_XML = "<OrderStatusListRequest xmlns=\"urn:ecms:schema:cos:request:2:0\" "
      + " xmlns:cidx=\"urn:cidx:names:DRAFT_0014:ces:schema:all:5:0\" "
      + " xmlns:ecms=\"urn:ecms:schema:cos:request:2:0\" Version=\"2.0\">"
      + "<cidx:Header><cidx:ThisDocumentIdentifier><cidx:DocumentIdentifier>ClientConversationId</cidx:DocumentIdentifier>"
      + "</cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime>"
      + "<cidx:DateTime DateTimeQualifier=\"On\">2005-06-17T16:39:36Z</cidx:DateTime></cidx:ThisDocumentDateTime>"
      + "<cidx:From><cidx:PartnerInformation><cidx:PartnerName>Joe Dealer</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">{1}</cidx:PartnerIdentifier>" +
            "<cidx:ContactInformation> <cidx:ContactName>SeedTrak</cidx:ContactName> <cidx:ContactDescription>DataSource</cidx:ContactDescription> </cidx:ContactInformation>"+
            "<cidx:ContactInformation> <cidx:ContactName>03.23.07</cidx:ContactName> <cidx:ContactDescription>SoftwareVersion</cidx:ContactDescription> </cidx:ContactInformation>" +
            "<cidx:ContactInformation> <cidx:ContactName>2007</cidx:ContactName> <cidx:ContactDescription>SeedYear</cidx:ContactDescription> </cidx:ContactInformation>" +
            "</cidx:PartnerInformation>"
      + "</cidx:From><cidx:To><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation>"
      + "</cidx:To></cidx:Header><OrderStatusListRequestBody><OrderStatusListRequestProperties/>"
      + "<OrderStatusListRequestPartners><cidx:Seller><cidx:PartnerInformation>"
      + "<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">0062668030000</cidx:PartnerIdentifier>"
      + "</cidx:PartnerInformation></cidx:Seller></OrderStatusListRequestPartners>"
      + "<OrderStatusListRequestDetails/></OrderStatusListRequestBody></OrderStatusListRequest>";

  public COS_2_0_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcCOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcCOS() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);

//  Data For DEV
//  String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
//        cidxHeader, "0785721740000");
    
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
        cidxHeader, "16812");
    
//  Data for PS External  
//    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML,
//        cidxHeader, "0476531540000");
//    
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD,
        null, null);
    System.out.println(wsseSecurityHeader);
    System.out.println(messageXml);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    final String xpathCOSResponse = "/Envelope/Body/OrderStatusListResponse/OrderStatusListResponseBody/OrderStatusListResponseDetails/OrderStatusResponseBody";
    int lineItemCount = XPathUtil.getNodeCount(responseXml, xpathCOSResponse);
    System.out.println("Number of COS line items retrieved: " + lineItemCount);
    assertFalse("At least one COS line item is expected", 0 == lineItemCount);
    
//  Check that Log Record has been created
//    ITable logTable = getEcomDbUnitHelper().getActualTable(
//        buildActivityLogSql(conversationId));
//    assertEquals(1, logTable.getRowCount());    
//    assertEquals("2007", (String)logTable.getValue(0, "SEED_YEAR"));
//    assertEquals("03.23.07", (String)logTable.getValue(0, "SOFTWARE_VERSION_ID"));
//    assertEquals(new BigDecimal(2160), (BigDecimal)logTable.getValue(0, "ACCT_ID"));
//    BigDecimal dataExchangeId = (BigDecimal)logTable.getValue(0, "DATA_EXCHANGE_ID");
//    System.out.println("DataExchangeId = "+dataExchangeId.longValue());
//    
//    ITable eventTable = getEcomDbUnitHelper().getActualTable(
//        buildActivityEventSql(conversationId));
//    assertEquals(1, eventTable.getRowCount());    
//    assertEquals("UserActivitySuccessful", eventTable.getValue(0, "STATUS_CODE"));
//    
//    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
//        buildXmlRepositorySql(dataExchangeId.longValue()+"", "OrderStatusListResponse"));
//    assertEquals(1, repositoryTable.getRowCount());
    
  }

  private String getSAPIdBasedOnEnvironment() throws Exception {
    Properties ecomProps = getAcceptanceTestEnvironmentProperties("ecom-test.properties");
    String SAPId;
    String url = ecomProps.getProperty("url.base");
    if ("http://wwwd.webservices.farmsource.monsanto.com/ecms".equals(url) || "http://localhost:8080/ecms".equals(url)) {
      SAPId = "1003520";
    } else {
      SAPId = "1660158";
    }
    return SAPId;
  }

}
