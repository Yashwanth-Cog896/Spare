/*
 * ChangeLog_FT was created on Jul 7, 2008 using Monsanto
 * resources and is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Date;

import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;

/**
 * Service Implementation of the web service.
 * 
 * @author mkuchip
 * @version ChangeLog_FT.java, Jul 7, 2008
 */
public class ChangeLog_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/ChangeLog_1-0";
  
  private static final String REQUEST_XML = "<p:ChangeLogRequest xmlns:p=\"urn:ecms:schema:changelog:request:1:0\" xmlns:cidx=\"urn:cidx:names:DRAFT_0014:ces:schema:all:5:0\" Version=\"1.0\">" +
  "  <cidx:Header>" +
  "    <cidx:ThisDocumentIdentifier>" +
  "      <cidx:DocumentIdentifier>CHLOG_SC_1</cidx:DocumentIdentifier>" +
  "    </cidx:ThisDocumentIdentifier>" +
  "    <cidx:ThisDocumentDateTime>" +
  "      <cidx:DateTime DateTimeQualifier=\"After\">2001-12-31T12:00:00Z</cidx:DateTime>" +
  "    </cidx:ThisDocumentDateTime>" +
  "    <cidx:From>" +
  "      <cidx:PartnerInformation>" +
  "        <cidx:PartnerName>Taeger Seed 0001048347 0001003540 0001023280</cidx:PartnerName>" +
  "        <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0001048347</cidx:PartnerIdentifier>" +
  "      </cidx:PartnerInformation>" +
  "    </cidx:From>" +
  "    <cidx:To>" +
  "      <cidx:PartnerInformation>" +
  "        <cidx:PartnerName>Monsanto</cidx:PartnerName>" +
  "        <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier>" +
  "      </cidx:PartnerInformation>" +
  "    </cidx:To>" +
  "  </cidx:Header>" +
  "  <ChangeLogRequestBody>" +
  "    <ChangeLogRequestProperties>" +
  "      <RequestedDocumentTypeCode>LOG</RequestedDocumentTypeCode>" +
  "    </ChangeLogRequestProperties>" +
  "    <ChangeLogRequestPartners>" +
  "    <Buyer>" +
  "        <cidx:PartnerInformation>" +
  "          <cidx:PartnerName>token</cidx:PartnerName>" +
  "          <cidx:PartnerIdentifier Agency=\"{0}\">{1}</cidx:PartnerIdentifier>" +
  "        </cidx:PartnerInformation>" +
  "      </Buyer>" +
  "      <Seller>" +
  "        <cidx:PartnerInformation>" +
  "          <cidx:PartnerName>token</cidx:PartnerName>" +
  "          <cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier>" +
  "        </cidx:PartnerInformation>" +
  "      </Seller>" +       
  "    </ChangeLogRequestPartners>" +
  "    <ChangeLogRequestDetail/>" +
  "  </ChangeLogRequestBody>" +
  "</p:ChangeLogRequest>"; 

  public ChangeLog_AT(String name) {
    super(name);    
  }
  
  public void testGetWsdl() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }
  
  public void testJaxRpcChangeLog_withEBID() throws Exception {
//  for PS DEV
    assertChangeLogResponse(MessageFormatter.format(REQUEST_XML, "AGIIS-EBID", "0421722670000"));
    // for PS EXT
//    assertChangeLogResponse(MessageFormatter.format(REQUEST_XML, "AGIIS-EBID", "0002537320000"));
  }
  
  public void testJaxRpcChangeLog_withAccountId() throws Exception {
//  for PS DEV
    assertChangeLogResponse(MessageFormatter.format(REQUEST_XML, "AssignedBySeller", "55644"));
    // for PS EXT
//    assertChangeLogResponse(MessageFormatter.format(REQUEST_XML, "AssignedBySeller", "314525"));
  }
  
  public void testJaxRpcChangeLog_withSAPId() throws Exception {
//  for PS DEV
    assertChangeLogResponse(MessageFormatter.format(REQUEST_XML, "AssignedByPapiNet", "0001023280"));
    // for PS EXT
//    assertChangeLogResponse(MessageFormatter.format(REQUEST_XML, "AssignedByPapiNet", "0001029671"));
    
  }
  
  
  private void assertChangeLogResponse(String requestXml) throws Exception {
    //System.out.println(requestXml);
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, "0", "ST",
        "03.23.05", 2005, true);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD,
        null, null);
    System.out.println(wsseSecurityHeader);
    System.out.println("Service Url = "+getServiceUrl(SERVICE_URI));
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, requestXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    final String xpathChangeLogDetail = "/Envelope/Body/ChangeLogResponse/ChangeLogResponseBody/ChangeLogDetail";
    int changeLogItemCount = XPathUtil.getNodeCount(responseXml, xpathChangeLogDetail);
    System.out.println("Number of ChangeLogDetail items retrieved: " + changeLogItemCount);
    assertFalse("At least one ChangeLogDetail item is expected", 0 == changeLogItemCount);
    
//  Check that Log Record has been created
//  ITable logTable = getEcomDbUnitHelper().getActualTable(
//      buildActivityLogSql(conversationId));
//  assertEquals(1, logTable.getRowCount());    
//  BigDecimal dataExchangeId = (BigDecimal)logTable.getValue(0, "DATA_EXCHANGE_ID");
//  System.out.println("DataExchangeId = "+dataExchangeId.longValue());
//  
//  ITable eventTable = getEcomDbUnitHelper().getActualTable(
//      buildActivityEventSql(conversationId));
//  assertEquals(1, eventTable.getRowCount());    
//  assertEquals("UserActivitySuccessful", eventTable.getValue(0, "STATUS_CODE"));
//  
//  ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
//      buildXmlRepositorySql(dataExchangeId.longValue()+"", "ChangeLogResponse"));
//  assertEquals(1, repositoryTable.getRowCount());    
    

  }

  
}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.3  2008/07/18 19:57:53  mkuchip
 * Added tests for EBID/ACCTID --> sAPID mapping
 *
 * Revision 1.2  2008/07/17 15:54:44  mkuchip
 * AT Changes and new GOAII test suite
 *
 * Revision 1.1  2008/07/11 18:32:13  mkuchip
 * COS2 FT
 *
 */