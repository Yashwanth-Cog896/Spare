package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;

public class ProductLight_2_0_AT extends AcceptanceTestCase {
	private static final String SERVICE_URI = "/soap/Products_2-0";


	public ProductLight_2_0_AT(String name) {
			  super(name);
	}
	
//		  public void testJaxRpcProductLightBasicResponse() throws Exception {
//		    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.JULY, 4);
//		    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());
//	
//		    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
//		    String messageXml = MessageFormatter.format(ProductList_AT.TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
//		    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
//		    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
//		        messageXml);
//	
//		    WebResponse response = webConversation.getResponse(request);
//		    assertNotNull("Valid response must be received", response);
//		    assertEquals("text/xml", response.getContentType());
//		  }
//		  
//		  public void testJaxRpcProductLight() throws Exception {
//		    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.MAY, 4);
//		    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());
//	
//		    String cidxHeader = buildCIDXHeaderFromDealerAccountId(fromDateUTC, "168618", "ST", "03.23.05", 2005, true);		    
//		    String messageXml = MessageFormatter.format(ProductList_AT.TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
//		    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
//		    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
//		        messageXml);
//	
//		    WebResponse response = webConversation.getResponse(request);
//		    assertNotNull(response);
//		    assertEquals("text/xml", response.getContentType());
//		    Document responseXml = response.getDOM();
//	
//		    assertNotNull("Valid document must be returned", responseXml);
//		    DOMUtil.outputXML(responseXml);
//		    
//		    final String xpathProduct = "/Envelope/Body/Products/Product";
//		    int productCount = XPathUtil.getNodeCount(responseXml, xpathProduct);
//		    System.out.println("Number of products extracted: " + productCount);
//		    assertFalse("At least one product is expected", 0 == productCount);
//	
//		  }
//		  
//	public void testALSBProductLiteVersion2PullsBackProducts() throws Exception {
//		GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.MAY, 4);
//	    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());
//	    String cidxHeader = buildCIDXHeaderFromDealerAccountId(fromDateUTC, "314525", "ST", "03.23.05", 2005, true);
//		String messageXml = MessageFormatter.format(ProductList_AT.TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
//		String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
//		PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);
//		WebResponse response = webConversation.getResponse(request);
//		assertNotNull(response);
//		assertEquals("text/xml", response.getContentType());
//		Document responseXml = response.getDOM();
//		assertNotNull("Valid document must be returned", responseXml);
//		DOMUtil.outputXML(responseXml);
//		final String xpathProduct = "/Envelope/Body/Products/Product";
//		int productCount = XPathUtil.getNodeCount(responseXml, xpathProduct);
//		System.out.println("Number of products extracted: " + productCount);
//		assertFalse("At least one product is expected", 0 == productCount);
//	}
	
	public void test2() throws Exception {
		String messageXml = 
			"<ProductExtractRequest Version=\"1.0\" xmlns=\"urn:ecms:schema:productlist:request:1:0\" xmlns:ecms=\"urn:ecms:schema:productlist:request:1:0\" xmlns:cidx=\"urn:cidx:names:specification:ces:schema:all:4:0\">" +
			 "<cidx:Header><cidx:ThisDocumentIdentifier><cidx:DocumentIdentifier>ProductExtract</cidx:DocumentIdentifier></cidx:ThisDocumentIdentifier><cidx:ThisDocumentDateTime><cidx:DateTime DateTimeQualifier=\"On\">2007-09-01T00:00:00Z</cidx:DateTime></cidx:ThisDocumentDateTime><cidx:From><cidx:PartnerInformation><cidx:PartnerName>doug</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0267756710000</cidx:PartnerIdentifier><cidx:ContactInformation><cidx:ContactName>SeedTrak Mobile Inventory</cidx:ContactName><cidx:ContactDescription>DataSource</cidx:ContactDescription></cidx:ContactInformation><cidx:ContactInformation><cidx:ContactName>2008</cidx:ContactName><cidx:ContactDescription>SeedYear</cidx:ContactDescription></cidx:ContactInformation><cidx:ContactInformation><cidx:ContactName>3.1.47</cidx:ContactName><cidx:ContactDescription>SoftwareVersion</cidx:ContactDescription></cidx:ContactInformation></cidx:PartnerInformation></cidx:From><cidx:To><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:To></cidx:Header><ProductExtractRequestBody><ProductExtractRequestProperties /><ProductExtractRequestPartners><cidx:Seller><cidx:PartnerInformation><cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName><cidx:PartnerIdentifier Agency=\"AGIIS-EBID\">0062668030000</cidx:PartnerIdentifier></cidx:PartnerInformation></cidx:Seller></ProductExtractRequestPartners><ProductExtractRequestDetails><cidx:FromDateTime>2007-09-01T00:00:00Z</cidx:FromDateTime><ProductFeatures><ProductAttribute><ProductAttributeName Agency=\"AGIISProductDirectory\">PrimaryProductSegmentCode</ProductAttributeName><ProductAttributeValue>Seed</ProductAttributeValue></ProductAttribute></ProductFeatures></ProductExtractRequestDetails></ProductExtractRequestBody></ProductExtractRequest>";
		String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
		PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);
		WebResponse response = webConversation.getResponse(request);
		assertNotNull(response);
		assertEquals("text/xml", response.getContentType());
		Document responseXml = response.getDOM();
		assertNotNull("Valid document must be returned", responseXml);
//		DOMUtil.outputXML(responseXml);
		final String xpathProduct = "/Envelope/Body/Products/Product";
		int productCount = XPathUtil.getNodeCount(responseXml, xpathProduct);
		System.out.println("Number of products extracted: " + productCount);
		assertFalse("At least one product is expected", 0 == productCount);
		
	}
}
