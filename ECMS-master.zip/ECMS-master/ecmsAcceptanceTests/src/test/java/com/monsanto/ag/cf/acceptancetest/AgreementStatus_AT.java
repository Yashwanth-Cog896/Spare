/*
 * AgreementStatus_FT was created on Apr 19, 2007 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;
import org.w3c.dom.Document;

import java.util.Date;

/**
 * Test the Agreement Status web service
 * 
 * @author Chetna Aggarwal
 * @version $Id: AgreementStatus_AT.java,v 1.4 2008-02-12 23:28:37 gjkell Exp $
 */
public class AgreementStatus_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/AgreementStatus_1-0";

  public AgreementStatus_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcAgreementStatus() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcAgreementStatusBasicResponse() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil.formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST",
        "03.23.05", 2005, true);
    String messageXml = "<AgreementStatusRequest " + "xmlns=\"urn:ecms:schema:agreement:request:1:0\" "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:agreement:request:1:0\" Version=\"1.0\">" + cidxHeader
        + "<AgreementStatusRequestBody><AgreementProperties><BatchProcess>false</BatchProcess>"
        + "<Agreement><AgreementMessageType>license</AgreementMessageType><AgreementName>MTA1</AgreementName>"
        + "</Agreement></AgreementProperties><AgreementDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "6</cidx:PartnerIdentifier>" 
        + "<cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.PROPRIETARY_CODE + "\">"
        + "a</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>MA</cidx:StateOrProvince></PartnerDetails></AgreementDetails>"
        + "</AgreementStatusRequestBody></AgreementStatusRequest>";

    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    //System.out.println(response);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcAgreementStatus() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil.formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST",
        "03.23.05", 2005, true);
    String messageXml = "<AgreementStatusRequest " + "xmlns=\"urn:ecms:schema:agreement:request:1:0\" "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:agreement:request:1:0\" Version=\"1.0\">" + cidxHeader
        + "<AgreementStatusRequestBody><AgreementProperties><BatchProcess>false</BatchProcess>"
        + "<Agreement><AgreementMessageType>license</AgreementMessageType><AgreementName>MTA1</AgreementName>"
        + "</Agreement></AgreementProperties><AgreementDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "6</cidx:PartnerIdentifier>"
        + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" 
        + CidxConstants.PROPRIETARY_CODE + "\">"
        + "a</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>MA</cidx:StateOrProvince></PartnerDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "50400002</cidx:PartnerIdentifier>"
        + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" 
        + CidxConstants.PROPRIETARY_CODE + "\">"
        + "b</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>NC</cidx:StateOrProvince></PartnerDetails></AgreementDetails>"
        + "</AgreementStatusRequestBody></AgreementStatusRequest>";

    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);
    

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    //DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathAgreementDetail = "/Envelope/Body/AgreementStatusResponse/AgreementStatusResponseBody/AgreementStatusResponseDetails/PartnerDetail";
    int detailCount = XPathUtil.getNodeCount(responseXml, xpathAgreementDetail);
    System.out.println("Number of agreement details retrieved: " + detailCount);
    assertFalse("At least one agreement detail is expected", 0 == detailCount);
  }

  public void testJaxRpcAgreementStatusBadAccountId() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil.formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST",
        "03.23.05", 2005, true);
    String messageXml = "<AgreementStatusRequest " + "xmlns=\"urn:ecms:schema:agreement:request:1:0\" "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:agreement:request:1:0\" Version=\"1.0\">" + cidxHeader
        + "<AgreementStatusRequestBody><AgreementProperties><BatchProcess>false</BatchProcess>"
        + "<Agreement><AgreementMessageType>license</AgreementMessageType><AgreementName>MTA1</AgreementName>"
        + "</Agreement></AgreementProperties><AgreementDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "Abc6</cidx:PartnerIdentifier>" 
        + "<cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.PROPRIETARY_CODE + "\">"
        + "Def</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>MA</cidx:StateOrProvince></PartnerDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "50400002</cidx:PartnerIdentifier>"
        + "<cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.PROPRIETARY_CODE + "\">"
        + "Hij</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>NC</cidx:StateOrProvince></PartnerDetails></AgreementDetails>"
        + "</AgreementStatusRequestBody></AgreementStatusRequest>";

    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    //DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathAgreementDetail = "/Envelope/Body/AgreementStatusResponse/AgreementStatusResponseBody/AgreementStatusResponseDetails/PartnerDetail";
    int detailCount = XPathUtil.getNodeCount(responseXml, xpathAgreementDetail);
    System.out.println("Number of agreement details retrieved: " + detailCount);
    assertFalse("At least one agreement detail is expected", 0 == detailCount);
  }

  public void testJaxRpcAgreementStatusNoData() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil.formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST",
        "03.23.05", 2005, true);
    String messageXml = "<AgreementStatusRequest " + "xmlns=\"urn:ecms:schema:agreement:request:1:0\" "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:agreement:request:1:0\" Version=\"1.0\">" + cidxHeader
        + "<AgreementStatusRequestBody><AgreementProperties><BatchProcess>false</BatchProcess>"
        + "<Agreement><AgreementMessageType>license</AgreementMessageType><AgreementName>MTA1</AgreementName>"
        + "</Agreement></AgreementProperties><AgreementDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "0</cidx:PartnerIdentifier>" 
        + "<cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.PROPRIETARY_CODE + "\">"
        + "2</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>MA</cidx:StateOrProvince></PartnerDetails></AgreementDetails>"
        + "</AgreementStatusRequestBody></AgreementStatusRequest>";

    
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    //DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathAgreementDetail = "/Envelope/Body/AgreementStatusResponse/AgreementStatusResponseBody/AgreementStatusResponseDetails/PartnerDetail";
    int detailCount = XPathUtil.getNodeCount(responseXml, xpathAgreementDetail);
    System.out.println("Number of agreement details retrieved: " + detailCount);
    assertTrue("No agreement detail is expected", 0 == detailCount);
  }

  public void testJaxRpcAgreementStatusLoadData() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/AGRMT/AgreementStatusRequest_v10.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    //DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathAgreementDetail = "/Envelope/Body/AgreementStatusResponse/AgreementStatusResponseBody/AgreementStatusResponseDetails/PartnerDetail";
    int detailCount = XPathUtil.getNodeCount(responseXml, xpathAgreementDetail);
    System.out.println("Number of agreement details retrieved: " + detailCount);
    assertFalse("At least one agreement detail is expected", 0 == detailCount);

  }

  public void testJaxRpcAgreementStatusBlank() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil.formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST",
        "03.23.05", 2005, true);
    String messageXml = "<AgreementStatusRequest " + "xmlns=\"urn:ecms:schema:agreement:request:1:0\" "
        + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + " xmlns:ecms=\"urn:ecms:schema:agreement:request:1:0\" Version=\"1.0\">" + cidxHeader
        + "<AgreementStatusRequestBody><AgreementProperties><BatchProcess>false</BatchProcess>"
        + "<Agreement><AgreementMessageType>license</AgreementMessageType><AgreementName>MTA1</AgreementName>"
        + "</Agreement></AgreementProperties><AgreementDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "30872</cidx:PartnerIdentifier>"
        + "<cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.PROPRIETARY_CODE + "\">"
        + "444</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>MS</cidx:StateOrProvince></PartnerDetails><PartnerDetails><cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.ACCOUNT_ID_AGENCY + "\">"
        + "50400002</cidx:PartnerIdentifier>"
        + "<cidx:PartnerIdentifier "
        + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.PROPRIETARY_CODE + "\">"
        + "555</cidx:PartnerIdentifier>"
        + "<cidx:StateOrProvince>NC</cidx:StateOrProvince></PartnerDetails></AgreementDetails>"
        + "</AgreementStatusRequestBody></AgreementStatusRequest>";

    
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    //DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathAgreementDetail = "/Envelope/Body/AgreementStatusResponse/AgreementStatusResponseBody/AgreementStatusResponseDetails/PartnerDetail";
    int detailCount = XPathUtil.getNodeCount(responseXml, xpathAgreementDetail);
    System.out.println("Number of agreement details retrieved: " + detailCount);
    assertFalse("At least one agreement detail is expected", 0 == detailCount);
  }

}
