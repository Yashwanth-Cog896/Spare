package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.PointOfServiceGPOS_AT;

public class PointOfServiceGPOS_PT extends PerformanceTestCase {
  
  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for PointOfService GPOS");

    Test gpos = new PointOfServiceGPOS_AT("testGPOSService");
    TimedTest timedGpos = new TimedTest(gpos,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedGpos);

    return suite;
  }

}
