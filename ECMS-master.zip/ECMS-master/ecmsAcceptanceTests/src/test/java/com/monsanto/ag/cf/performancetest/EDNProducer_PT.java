package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.EDNProducer_AT;

public class EDNProducer_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for EDN Producer");

    Test productList = new EDNProducer_AT("testJaxRpcEDNProducerBasicResponse");
    Test timedProductList = new TimedTest(productList,
        MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedProductList);

    return suite;
  }

}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/07/26 18:22:19  ggdavi
 * Initial version
 *
 */