/*
 * PriceSheet_PT was created on Jun 28, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import com.monsanto.ag.cf.acceptancetest.PriceSheet_AT;
import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;

/**
 * Test the performance of the Price Sheet web service.
 * 
 * @author Gareth Davies
 * @version $Id: PriceSheet_PT.java,v 1.2 2006-08-14 21:14:59 caggarw Exp $
 */
public class PriceSheet_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for Price Sheet");

    Test priceSheet = new PriceSheet_AT("testJaxRpcPriceSheetBasicResponse");
    Test timedPriceSheet = new TimedTest(priceSheet,
        MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedPriceSheet);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2005/06/28 17:53:33  ggdavi
 * Initial version
 *
 */