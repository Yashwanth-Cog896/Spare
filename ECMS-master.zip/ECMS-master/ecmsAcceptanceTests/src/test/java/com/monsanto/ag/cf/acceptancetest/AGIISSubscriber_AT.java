package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.XMLUtil.DOMUtil;

public class AGIISSubscriber_AT extends AcceptanceTestCase {
	private static final String SERVICE_URI = "/soap/AGIISSubscriber";

	public AGIISSubscriber_AT(String name) {
		super(name);
	}

	public void testSubscriberServiceInvalidId() throws Exception {
		String messageXml =
		"<ns2:IsAGIISSubscriber xmlns=\"http://www.monsanto.com/AGIIS/Services/Search/\" " + 
		"xmlns:ns2=\"http://www.monsanto.com/AGIIS/Services/SubscriberRequest/\"> " +
		"<ns2:IdentifierValue>121212122</ns2:IdentifierValue></ns2:IsAGIISSubscriber>";		
		String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
		PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

		WebResponse response = webConversation.getResponse(request);
        DOMUtil.outputXML(response.getDOM());
        NodeList nodeList = DOMUtil.getNodeListByTagName(response.getDOM(), "ActiveSubscriber");
		if(nodeList.getLength() > 0){
			Node node = nodeList.item(0);
			String returnValue = node.getNodeValue();
			assertEquals("false", returnValue);
		} else {
			fail("Invalid Response from AGIIS server");
		}
		assertNotNull("Valid response must be received", response);
		assertEquals("text/xml", response.getContentType());
	}
	public void testSubscriberServiceValidId() throws Exception {
		String messageXml =
		"<ns2:IsAGIISSubscriber xmlns=\"http://www.monsanto.com/AGIIS/Services/Search/\" " + 
		"xmlns:ns2=\"http://www.monsanto.com/AGIIS/Services/SubscriberRequest/\"> " +
		"<ns2:IdentifierValue>0062668030000</ns2:IdentifierValue></ns2:IsAGIISSubscriber>";
		String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
		PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

		WebResponse response = webConversation.getResponse(request);
		NodeList nodeList = DOMUtil.getNodeListByTagName(response.getDOM(), "ActiveSubscriber");
		if(nodeList.getLength() > 0){
			Node node = nodeList.item(0);
			String returnValue = node.getNodeValue();
			assertEquals("true", returnValue);
		} else {
			fail("Invalid Response from AGIIS server");
		}
		assertNotNull("Valid response must be received", response);
		assertEquals("text/xml", response.getContentType());
	}	
}