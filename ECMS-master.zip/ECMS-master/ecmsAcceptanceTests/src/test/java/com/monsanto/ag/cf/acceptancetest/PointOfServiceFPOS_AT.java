package com.monsanto.ag.cf.acceptancetest;

import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.transform.TransformerException;

import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.POSResultDocumentProcessor;
import com.monsanto.POSClient.XMLPOSConnection;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.xml.XPathUtil;

public class PointOfServiceFPOS_AT extends AcceptanceTestCase {

  private static final String INTERNAL_FPOS_USER_ID = "int_fpos_4-0";
  private static final String INTERNAL_FPOS_USER_ACCOUNT_ID = "0";

  public PointOfServiceFPOS_AT(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    System.setProperty("catalina.base", "C:\\Tools\\jakarta-tomcat-5.0.28");
    System.setProperty("lsi.function", "win");

  }

  public void testInvokePosServiceWithoutUsingPOSCommunication() throws Exception {
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4a.xml");
    PostMethodWebRequest request = new PostMethodWebRequest(getServiceUrl("")
        + "/servlet/EComMessageSystem_FPOS_4-0",
        new ByteArrayInputStream(messageXml.getBytes()), "text/xml");
    WebResponse response = webConversation.getResponse(request);
    assertEquals("text/html", response.getContentType());

    //MAS 3-31-08: Looks like CruiseControl Tomcat was changed to 5.5.20 !!
//    assertEquals("Apache Tomcat/5.0.28 - Error report", response.getTitle());
    String responseTitle = response.getTitle();
    assertNotNull(responseTitle);
    assertTrue(responseTitle.startsWith("Apache Tomcat/5."));
    assertTrue(responseTitle.endsWith(" - Error report"));
  }

  public void testFPOSService() throws Exception {
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4a.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));

    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_FPOS_4-0", inputDoc);

    Document responseXml = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(outputDoc);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(INTERNAL_FPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_FPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(FPOS_AT.class, "I3_Data4a");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testNullDocumentFPOS() throws Exception {

    try {
      POSConnection posComm = new XMLPOSConnection();
      posComm.callService("EComMessageSystem_FPOS_4-0", null);
      fail("Should through an exception");
    } catch (Exception e) {
      assertEquals("No Input Document", e.getMessage());
    }
  }

  public void testJaxRpcFPOSSalesReplants() throws Exception {

    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4b.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));

    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_FPOS_4-0", inputDoc);

    Document responseXml = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(outputDoc);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(INTERNAL_FPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_FPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(FPOS_AT.class, "I3_Data4b");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcFPOSFarmFlex() throws Exception {

    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4c.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));

    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_FPOS_4-0", inputDoc);

    Document responseXml = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(outputDoc);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(INTERNAL_FPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_FPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(FPOS_AT.class, "I3_Data4c");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testJaxRpcFPOSFarmManagerMappingChanges() throws Exception {
    String messageXml = getRequestXmlFromUri("/FPOS/I3_Test4d.xml");
    Document inputDoc = DOMUtil.newDocumentNS(new StringReader(messageXml));

    POSConnection posComm = new XMLPOSConnection();
    POSResult result = posComm.callService("EComMessageSystem_FPOS_4-0", inputDoc);

    Document responseXml = new POSResultDocumentProcessor().getDocument(result);

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(outputDoc);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(INTERNAL_FPOS_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("FPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 25, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(INTERNAL_FPOS_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(FPOS_AT.class, "I3_Data4d");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  protected String getConversationIdFromResponseDocument(Document responseXml) throws TransformerException {
    return XPathUtil.getTextNodeValue(responseXml, "/cidx:Header/cidx:ThisDocumentIdentifier/cidx:DocumentIdentifier");
  }

}
