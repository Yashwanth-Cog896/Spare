/*
 * AcceptanceTestCase was created on Apr 21, 2005 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code and/or logic is
 * a direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import com.meterware.httpunit.GetMethodWebRequest;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableWarning;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.cf.dao.test.DbUnitHelperFactory;
import com.monsanto.ag.cf.logging.XmlUserActivity;
import com.monsanto.ag.cf.message.listener.POSListener;
import com.monsanto.ag.cf.test.TestConfig;
import com.monsanto.ag.util.test.DbUnitHelper;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDocument;
import com.monsanto.ag.xml.XmlDocumentBuilder;
import com.monsanto.ag.xml.domutil.DOMUtilXmlDocumentBuilder;
import com.monsanto.ag.xml.test.SoapTestCase;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

/**
 * Contains common fixtures for all acceptance tests.
 * 
 * @author Gareth Davies
 * @version $Id: AcceptanceTestCase.java,v 1.52 2008-07-22 14:41:03 bbnand Exp $
 */
public abstract class AcceptanceTestCase extends SoapTestCase {

  private static final String TEST_DATA_PATH = new File("").getAbsolutePath() 
    + File.separator + TestConfig.getTestDataParentSubpath()
    + "testdata/xml";
  private static final String NEW_LINE = System.getProperty("line.separator");

  protected static final String GOOD_USER_ID = "1033632";
  protected static final String GOOD_USER_PASSWORD = "Test_123";    //on Dev
  // protected static final String GOOD_USER_PASSWORD = "Test_123";  //on Test
  // protected static final String GOOD_USER_PASSWORD = "test_123";  //on Training
  protected static final String GOOD_USER_EBID = "0615121660000";
  protected static final String GOOD_USER_ACCOUNT_ID = "0000000050448";
  protected static final String GOOD_USER_SAP_ID = "0001033632";

  protected static final int CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT = 60000;

  private static final String TEMPLATE_LOG_SQL = "SELECT DATA_EXCHANGE_ID, USER_ID, DATA_EXCHANGE_TYPE_CODE, "
      + "DATA_EXCHANGE_START_DATE, DATA_EXCHANGE_END_DATE, SEED_YEAR, "
      + "SOFTWARE_VERSION_ID, ACCT_ID, TRANSACTION_COUNT FROM DATA_EXCHANGE_LOG "
      + "WHERE CONVERSATION_ID = ''{0}'' ORDER BY DATA_EXCHANGE_ID";

  private static final String TEMPLATE_REPOSITORY_SQL = "SELECT DATA_EXCHANGE_ID, XML_MSG "
      + "FROM DATA_EXCHANGE_REPOSITORY WHERE DATA_EXCHANGE_ID = {0} AND ROOT_NODE_NAME = ''{1}''";

  private static final String TEMPLATE_EVENT_SQL = "SELECT DATA_EXCHANGE_EVENT_ID, STATUS_CODE "
      + "FROM DATA_EXCHANGE_EVENT " + "WHERE CONVERSATION_ID = ''{0}'' ORDER BY DATA_EXCHANGE_EVENT_ID";

  private static final String ECG_STAGING_SQL_SELECT_CLAUSE = "SELECT TRAN_SET_PURPOSE, DATA_SOURCE, RPT_DATE, RPT_TYPE, "
    + "DS_TYPE, DS_NAME, DS_ID_QUAL, DS_ID_VALUE, SF_TYPE, SF_NAME, SF_ID_QUAL, "
    + "SF_ID_VALUE, SF_ADDR1, SF_CITY, SF_STATE, SF_ZIP, ST_TYPE, ST_NAME, "
    + "ST_ID_QUAL, ST_ID_VALUE, ST_ADDR1, ST_CITY, ST_STATE, ST_ZIP, "
    + "CONTACT_NAME_QUAL, CONTACT_NAME_VALUE, CONTACT_PHONE_QUAL, "
    + "CONTACT_PHONE_VALUE, PROD_TRANSFER_CODE, INV_DATE_QUAL, INV_DATE, "
    + "SHIP_DATE_QUAL, SHIP_DATE, ORDER_TYPE, INV_NBR, QTY_QUAL, QTY, LINE_UOM, "
    + "LINE_ID_QUAL, LINE_ID_VALUE, NET_INV_AMOUNT, FARM_MANAGER_PREPAY_FLAG, "
    + "PARTNER_ID, FIELD_COORDINATES, FP_DTL_TRAN_TYPE,FM_TYPE, FM_NAME, FM_ID_QUAL, FM_ID_VALUE, " 
    + "AF_TYPE, AF_NAME, AF_ID_QUAL, AF_ID_VALUE, "
    + "PROCESSOR_CONTRACT_NBR, SEED_PROCESSOR, GROWER_LINE_ITEM, SEEDCO_SALES_REP_CODE, NET_ACRES";

  private static final String ECG_STAGING_SQL_DOC_CTL_ID = ", DOC_CTL_ID";
  
  private static final String ECG_STAGING_SQL_FROM_CLAUSE = " FROM ECG_LD.DIRECT_STAGING WHERE CONVERSATION_ID = ''{0}'' " + "ORDER BY INV_NBR, ORDER_TYPE ";

  private static final String TEMPLATE_ECG_STAGING_SQL = ECG_STAGING_SQL_SELECT_CLAUSE
      + ECG_STAGING_SQL_DOC_CTL_ID + ECG_STAGING_SQL_FROM_CLAUSE;  
  
  private static final String TEMPLATE_ECG_STAGING_SQL_GOPPOS = ECG_STAGING_SQL_SELECT_CLAUSE
  + ECG_STAGING_SQL_FROM_CLAUSE;  

  protected WebConversation webConversation;

  private DbUnitHelper ecomDbUnitHelper;
  private DbUnitHelper ecgDbUnitHelper;

  private XmlDocumentBuilder xmlDocumentBuilder;

  public AcceptanceTestCase(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();

    xmlDocumentBuilder = new DOMUtilXmlDocumentBuilder();

    webConversation = new WebConversation();
    webConversation.setExceptionsThrownOnErrorStatus(false);
  }

  protected void tearDown() throws Exception {
    if (ecgDbUnitHelper != null) {
      ecgDbUnitHelper.cleanup();
    }
    if (ecomDbUnitHelper != null) {
      ecomDbUnitHelper.cleanup();
    }

    if (webConversation != null) {
      webConversation.clearContents();
      webConversation = null;
    }

    super.tearDown();
  }

  protected String getServiceUrl(String serviceUri) {
    try {
      Properties ecomProps = getAcceptanceTestEnvironmentProperties("ecom-test.properties");
      return ecomProps.getProperty("url.base") + serviceUri;
    } catch (IOException e) {
      return "http://localhost:8080/ecms";
    }
  }

  protected String getServiceUrlSeedCo(String serviceUri) {
    String urlBase = null;
    try {
      Properties ecomProps = getAcceptanceTestEnvironmentProperties("seedco-test.properties");
      urlBase = ecomProps.getProperty("url.base");
    } catch (IOException e) {
      urlBase = null;
    }
    if (urlBase == null || urlBase.trim().length() == 0) {
      urlBase = "http://localhost:8001";
    }
    return urlBase + serviceUri;
  }
  
  protected DbUnitHelper getEcomDbUnitHelper() throws Exception {
    if (ecomDbUnitHelper == null) {
      Properties ecomProps = getAcceptanceTestEnvironmentProperties("ecom-test.properties");
      ecomDbUnitHelper = new DbUnitHelperFactory().createDbUnitHelper(ecomProps);
    }
    return ecomDbUnitHelper;
  }

  protected DbUnitHelper getEcgDbUnitHelper() throws Exception {
    if (ecgDbUnitHelper == null) {
      Properties ecgProps = getAcceptanceTestEnvironmentProperties("ecg-test.properties");
      ecgDbUnitHelper = new DbUnitHelperFactory().createDbUnitHelper(ecgProps);
    }
    return ecgDbUnitHelper;
  }

  protected Properties getAcceptanceTestEnvironmentProperties(String propsFileName) throws IOException {
    Properties ecomProps = new Properties();
    ecomProps.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(
        "com/monsanto/ag/cf/acceptancetest/" + propsFileName));
    return ecomProps;
  }

  protected String getRequestXmlFromUri(String requestXmlUri) {
    String absoluteUri = TEST_DATA_PATH + requestXmlUri;
    XmlDocument requestDoc = xmlDocumentBuilder.createXmlDocument(absoluteUri);
    return requestDoc.toString();
  }

  protected String getConversationIdFromResponseDocument(Document responseXml) throws TransformerException {
    return XPathUtil.getTextNodeValue(responseXml, "//Header/ThisDocumentIdentifier/DocumentIdentifier");
  }

  protected String buildActivityLogSql(String conversationId) {
	return MessageFormatter.format(TEMPLATE_LOG_SQL, conversationId);
  }

  protected String buildXmlRepositorySql(String dataExchangeId, String rootNodeName) {
    return MessageFormatter.format(TEMPLATE_REPOSITORY_SQL, dataExchangeId, rootNodeName);
  }

  protected String buildActivityEventSql(String conversationId) {
    return MessageFormatter.format(TEMPLATE_EVENT_SQL, conversationId);
  }

  /**
   * Retrieve records from the DIRECT_STAGING table which match the supplied
   * <code>conversationId</code>. Generally this should only be called when some
   * records are expected. This method will try up to 25 times to retrieve
   * one or more matching records from the table, pausing 1 second between
   * unsuccessful attempts.  The delays allow time for WebMethods to write
   * data to the table.
   */
  protected ITable getActualEcgPosStagingTable(String conversationId) throws Exception {
    ITable ecgTable = null;
    String sql = MessageFormatter.format(TEMPLATE_ECG_STAGING_SQL, conversationId);

    for (int i = 0; i < 25; i++) {
      ecgTable = getEcgDbUnitHelper().getActualTable(sql);
      if (ecgTable.getRowCount() > 0) {
        break;
      } else {
        Thread.sleep(1000);
      }
    }

    return ecgTable;
  }
  
  protected ITable getActualEcgGoPosStagingTable(String conversationId) throws Exception {
    ITable ecgTable = null;
    String sql = MessageFormatter.format(TEMPLATE_ECG_STAGING_SQL_GOPPOS, conversationId);

    for (int i = 0; i < 25; i++) {
      ecgTable = getEcgDbUnitHelper().getActualTable(sql);
      if (ecgTable.getRowCount() > 0) {
        break;
      } else {
        Thread.sleep(1000);
      }
    }

    return ecgTable;
  }

  protected void assertWsdlServiceUrl(String serviceUri) throws Exception {
    String serviceUrl = getServiceUrl(serviceUri);
    GetMethodWebRequest request = new GetMethodWebRequest(serviceUrl + "?wsdl");
    request.setHeaderField("Accept-Encoding", "");
    request.setHeaderField("Content-Encoding", "utf-8");

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    System.out.println(response.getText());
    boolean usingFileBasedWsdl = false;     //False for normal; true for workaround below
    final String ECMS_SOAP = "ecms/soap";   //Portion of URL
    if (!"text/xml".equals(response.getContentType())) {
      //MAS 2-11-08: For some reason the ?wsdl convention is only working against
      // localhost, not against the Dev or Test servers. But we can try an alternate
      // URL temporarily.
      //TODO: Understand why Dev and Test servers are behaving differently and
      // apply a permanent solution.
      if (serviceUrl.indexOf(ECMS_SOAP) >= 0) {
        String alternateUrl = serviceUrl.replaceFirst(ECMS_SOAP, "ecms/wsdl") + ".wsdl";
        request = new GetMethodWebRequest(alternateUrl);
        request.setHeaderField("Accept-Encoding", "");
        request.setHeaderField("Content-Encoding", "utf-8");
        response = webConversation.getResponse(request);
        assertNotNull(response);
        usingFileBasedWsdl = true;
        logError("assertWsdlServiceUrl() failing with ?wsdl appended to serviceUrl, " 
            + "but trying to obtain static file from alternate URL "
            + alternateUrl);
      }
    }
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull(responseXml);
    String addressLocation = XPathUtil.getTextNodeValue(responseXml, "/definitions/service/port/address/@location");
    if (usingFileBasedWsdl) {
      //When the static WSDL file is returned, it does NOT have the address@location
      // dynamically set to the current URL, specifically the server URL portion,
      // but we can still match on the last part of the URL
      String serviceUrlFragment = serviceUrl.substring(serviceUrl.indexOf(ECMS_SOAP));
      String addressLocationFragment = addressLocation.substring(addressLocation.indexOf(ECMS_SOAP));
      assertEquals(serviceUrlFragment, addressLocationFragment);
    }
    else {
      assertEquals(serviceUrl, addressLocation);
    }
  }
  
  protected void assertWsdlServiceUrlSeedCo(String serviceUri) throws Exception {
    String serviceUrl = getServiceUrlSeedCo(serviceUri);
    GetMethodWebRequest request = new GetMethodWebRequest(serviceUrl + "?wsdl");
    request.setHeaderField("Accept-Encoding", "");
    request.setHeaderField("Content-Encoding", "utf-8");

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    // System.out.println(response.getText());
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull(responseXml);
    assertEquals(serviceUrl, XPathUtil.getTextNodeValue(responseXml, "/definitions/service/port/address/@location"));
  }
  
  /** Log a warning using Monsanto standard logging mechanism if active,
   * else just write to System.out. */
  protected void logWarning(String message) {
    if (Logger.numActiveLoggers() > 0) {
      Logger.log(new LoggableWarning(message));
    }
    else {
      System.out.println(NEW_LINE + "WARNING: " + message 
          + " (from " + this.getClass().getName() + ")");
    }
  }

  /** Log an error using Monsanto standard logging mechanism if active,
   * else just write to System.out. */
  protected void logError(String message) {
    if (Logger.numActiveLoggers() > 0) {
      Logger.log(new LoggableError(message));
    }
    else {
      System.out.println(NEW_LINE + "ERROR: " + message 
          + " (from " + this.getClass().getName() + ")");
    }
  }
  
  /**
   * Common code for a number of _FT functional test classes: Assert that
   * there are two records in ECOM.DATA_EXCHANGE_EVENT for the specified
   * <code>conversationId</code>, one for XmlUserActivity (with status 
   * UserActivitySuccessful) and the other for POSListener (with status
   * POSProcessingSuccessful).
   * 
   * @param conversationId that was assigned to incoming service request.
   */
  protected void assertBothEventsLogged(String conversationId) throws Exception {
    final String STATUS_CODE = "STATUS_CODE";
    
    // Check that two events have been logged
    ITable eventTable = getEcomDbUnitHelper().getActualTable(buildActivityEventSql(conversationId));
    assertEquals(2, eventTable.getRowCount());
    //Order of events cannot be predicted with certainly, although typically
    // it will be in default order; try both ways if necessary.
    int xmlUserActivityIdx = 0;
    int posListenerIdx = 1;
    if (POSListener.STATUS_CODE_SUCCESS.equals(eventTable.getValue(0, STATUS_CODE))) {
      xmlUserActivityIdx = 1;
      posListenerIdx = 0;
    }
    assertEquals(XmlUserActivity.STATUS_CODE_SUCCESS, 
        eventTable.getValue(xmlUserActivityIdx, STATUS_CODE));
    assertEquals(POSListener.STATUS_CODE_SUCCESS, 
        eventTable.getValue(posListenerIdx, STATUS_CODE));
  }

  

}

/*
 * $Log: not supported by cvs2svn $
 * 
 * Revision 1.52 2008/07/22 9:38:15 bbnand
 * Update GOOD_USER_ID Password on Dev and Test
 * 
 * Revision 1.51  2008/03/20 22:53:46  maschec
 * Update GOOD_USER_ID password on Dev
 *
 * Revision 1.50  2008/03/13 21:50:22  maschec
 * Use DEV/CruiseControl environment on CVS check-in
 *
 * Revision 1.49  2008/03/13 16:29:10  bbnand
 * GOOD_USER_PASSWORD changed to new test pwd
 *
 * Revision 1.48  2008/02/23 05:21:12  maschec
 * Redo code in getServiceUrlSeedCo() to achieve desired effect
 *
 * Revision 1.47  2008/02/18 17:32:50  maschec
 * Add settings for Training (a.k.a. Production Support) environment, commented out
 *
 * Revision 1.46  2008/02/13 16:23:31  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.45.2.3  2008/02/11 21:43:59  maschec
 * Refaactor common code to (more robust) assertBothEventsLogged()
 *
 * Revision 1.45.2.2  2008/02/11 18:16:00  maschec
 * Adapt assertWsdlServiceUrl() to test static WSDL file as fallback from dynamic, since dynamic is not currently working on Dev and Test servers (but still works on localhost)
 *
 * Revision 1.45.2.1  2008/02/10 21:07:56  maschec
 * Fix failing JUnit test
 *
 * Revision 1.45  2008/01/29 23:42:32  maschec
 * Merge branches EComMessageSystem_MAS_20070123_MobileGPOS/2 to Head: Implement test harness for GPOSLite web service, and make JUnit tests that refer to file system pass within Eclipse.
 *
 * Revision 1.44.4.1  2008/01/28 17:06:39  maschec
 * Fix failing Acceptance Tests
 *
 * Revision 1.44  2008/01/16 15:43:52  caggarw
 * added wsdl information for SeedConnectivity
 *
 * Revision 1.43  2006/08/29 16:53:58  caggarw
 * PVS mapping changes
 *
 * Revision 1.42  2006/07/28 21:54:13  caggarw
 * added NET_ACRES select query
 *
 * Revision 1.41  2006/07/26 17:57:39  caggarw
 * use only 1 query for all POS tests
 *
 * Revision 1.40  2006/06/28 17:15:40  caggarw
 * added test class for GOPPOS
 * Revision 1.38 2006/05/01 20:44:03 ggdavi
 * Updated to reflect changes in DbUnitHelper
 * 
 * Revision 1.37 2005/12/01 19:34:30 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.36 2005/11/15 17:19:46 ggdavi Now extends ag.util.SoapTestCase
 * 
 * Revision 1.35 2005/10/17 14:51:04 ggdavi Increased number of "wait for data
 * in ECG" loops
 * 
 * Revision 1.34 2005/09/27 17:56:20 caggarw change the SAPId in the request
 * based on the environments (dev or test)
 * 
 * Revision 1.33 2005/09/15 14:31:55 ggdavi In tearDown, check that the
 * WebConversation exists before clearing it
 * 
 * Revision 1.32 2005/09/02 18:21:52 ggdavi Refactored getRequestXmlFromUri
 * method from xPOS_AT to read request XML from files Revision 1.31 2005/08/10
 * 17:14:36 ggdavi Clear out webConversation field contents in tearDown
 * 
 * Revision 1.30 2005/07/26 17:12:44 ggdavi Added GOOD_USER_SAP_ID constant
 * 
 * Revision 1.29 2005/07/19 17:44:21 ggdavi assertWsdlServiceUrl now creates a
 * GetMethodWebRequest object and sets the Accept-Encoding header field, so that
 * the request does not barf on GZIP compression
 * 
 * Revision 1.28 2005/07/12 22:18:36 ggdavi Added commented out line to see
 * response text on console
 * 
 * Revision 1.27 2005/07/08 17:10:35 ggdavi GOOD_USER_ACCOUNT_ID is now a String
 * 
 * Revision 1.26 2005/07/05 21:19:01 ggdavi Formatting and readability changes
 * Revision 1.25 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method Revision 1.24 2005/06/27 20:21:12
 * ajbaldw Fixed the issue with padding the EBID.
 * 
 * Revision 1.23 2005/06/24 16:49:32 ggdavi Moved SoapTestCase from ag.util.test
 * to ag.cf.service.jaxrpc.test
 * 
 * Revision 1.22 2005/06/10 20:06:51 ajbaldw added th FP_DTL_TRAN_TYPE column to
 * the SQL Revision 1.21 2005/06/10 17:43:33 ajbaldw aded two missing columns to
 * the sql.
 * 
 * Revision 1.20 2005/06/06 21:18:23 ggdavi Added buildActivityEventSql and
 * buildXmlRepositorySql methods Revision 1.19 2005/06/06 18:17:44 ggdavi Added
 * getActualEcgPosStagingTable method and use MessageFormatter to build SQL
 * statements Revision 1.17 2005/06/02 16:40:36 ggdavi Refactored to only expose
 * the DbUnitHelper field objects through lazy-initializing accessor methods, so
 * that only methods that need them create them - this will make performance
 * testing easier Revision 1.16 2005/06/01 18:56:52 ggdavi Refactored for
 * consistency
 * 
 * Revision 1.15 2005/05/27 23:10:46 ajbaldw working acceptance tests. Revision
 * 1.14 2005/05/26 21:26:33 ajbaldw changed all xpath assertions to assertEquals
 * or the like because of the cidx: prefixes.
 * 
 * Revision 1.13 2005/05/26 17:30:05 ggdavi Removed dependency on root node name
 * from getConversationIdFromResponseDocument
 * 
 * Revision 1.12 2005/05/25 22:28:33 ggdavi Added
 * getConversationIdFromResponseDocument method Revision 1.11 2005/05/23
 * 19:29:39 ggdavi Pulled-up DbUnitHelper objects to superclass
 * 
 * Revision 1.10 2005/05/17 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config,
 * ag.cf.util to ag.aop, ag.config, ag.util
 * 
 * Revision 1.9 2005/05/16 23:07:01 ggdavi Added code to support JUnitPerf
 * 
 * Revision 1.8 2005/05/11 20:33:02 ggdavi Removed TO_CHAR functions from
 * activity log SQL Revision 1.7 2005/05/10 19:51:35 lsdenny Added 2 property
 * files Revision 1.5 2005/05/09 19:24:55 lsdenny Added data_exchange_id to
 * check that XML file was being stored. Revision 1.4 2005/05/06 14:16:30
 * lsdenny *** empty log message *** Revision 1.3 2005/05/05 21:00:13 lsdenny
 * Changes Revision 1.2 2005/05/03 20:21:56 ggdavi Changed functionaltest to
 * acceptancetest Revision 1.1 2005/04/27 11:32:35 ggdavi Renamed
 * ag.cf.functionaltest to ag.cf.acceptancetest Revision 1.2 2005/04/26 16:21:11
 * ggdavi Added buildActivityLogSql method Revision 1.1 2005/04/21 19:15:22
 * ggdavi Initial version
 */