/*
 * MessageEcho_AT was created on Mar 22, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Date;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Test the Message Echo web services.
 * 
 * @author ajbaldw $Id: MessageEcho_AT.java,v 1.5 2005/04/05 20:47:24 lsdenny
 *         Exp $
 */
public class MessageEcho_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/MessageEcho";

  public MessageEcho_AT(String name) {
    super(name);
  }

  public void testJaxRpcMessageEchoWithAuthorizedUser() throws Exception {
    String cidxHeader = buildCIDXHeaderFromDealer(XmlDateTimeUtil
        .formatDateAsXmlUTC(new Date()), GOOD_USER_EBID, "ST", "03.23.05",
        2005, false);
    final String MESSAGE = "Hello ECMS!";
    String messageXml = "<echo " + XmlNamespace.NAMESPACE_CIDX_40.getDefaultDeclaration() + " " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
        + ">" + cidxHeader + "<message>" + MESSAGE + "</message></echo>";
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID,
        GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(
        getServiceUrl(SERVICE_URI), wsseSecurityHeader, messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    //DOMUtil.outputXML(responseXml);
    if (false) {
      //MAS 2-10-08 - This was the code that was executing when I found it
      // on this date, but it assumes the service is failing ??? See code
      // below which tests that the service is succeeding!
      assertXpathEvaluatesTo("ecms:ScheduledOutage",
          "/Envelope/Body/Fault/faultcode", responseXml);
      assertXpathEvaluatesTo(
          "ECHO will be out of service between 04/11/05 10:00 AM and 09/01/07 08:00 AM: Testing Outage with Echo Service",
          "/Envelope/Body/Fault/faultstring", responseXml);
    }
    else {
      assertXpathEvaluatesTo(MESSAGE,
          "/Envelope/Body/echo/message", responseXml);
    }
  }

}