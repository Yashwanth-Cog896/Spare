/*
 * ProductList_AT was created on Jun 8, 2005 using Monsanto resources and is the
 * sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;

/**
 * Test the ProductList web services.
 * 
 * @author Gareth Davies
 * @version $Id: ProductList_AT.java,v 1.2 2008-02-13 16:23:31 maschec Exp $
 */
public class ProductList_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/ProductList_1-0";

  public static final String TEMPLATE_MESSAGE_XML = "<ProductExtractRequest "
      + "xmlns=\"urn:ecms:schema:productlist:request:1:0\" " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
      + " xmlns:ecms=\"urn:ecms:schema:productlist:request:1:0\" Version=\"1.0\">{0}"
      + "<ProductExtractRequestBody><ProductExtractRequestProperties/>"
      + "<ProductExtractRequestPartners><cidx:Seller><cidx:PartnerInformation>"
      + "<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>" + "<cidx:PartnerIdentifier "
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY
      + "\">0062668030000</cidx:PartnerIdentifier>" + "</cidx:PartnerInformation></cidx:Seller>"
      + "</ProductExtractRequestPartners><ProductExtractRequestDetails>"
      + "<cidx:FromDateTime>{1}</cidx:FromDateTime><ProductFeatures><ProductAttribute>" + "<ProductAttributeName "
      + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"AGIISProductDirectory\">PrimaryProductSegmentCode"
      + "</ProductAttributeName><ProductAttributeValue>Seed</ProductAttributeValue>"
      + "</ProductAttribute></ProductFeatures></ProductExtractRequestDetails>"
      + "</ProductExtractRequestBody></ProductExtractRequest>";

  public ProductList_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcProductList() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcProductListBasicResponse() throws Exception {
    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.JULY, 4);
    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());

    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcProductList() throws Exception {
    /*
     * MAS 2-11-08: To make this run in the local environment, I had to do the
     * following, because it is going to call a supporting service:
     * http://localhost:8080/ecg-services/servlet/AGIISProductUpdate
     * 1) Modify EcomMessageSystem version of URLMappings.xml, and change
     *    <PosName>ECGServices_AGIISProductUpdate</PosName>
     *      <Url>
     *        <win>http://localhost/ecg-services/servlet/AGIISProductUpdate</win>
     *    to
     *        <win>http://localhost:8080/ecg-services/servlet/AGIISProductUpdate</win>
     *    In other words, add the port number (8080)
     * 2) Get project ECGServices from CVS, and have it running in Tomcat
     * 3) Verify it is running by hitting the above URL. The normal response it:
     *    -1Could not find input document Could not find input document [etc]
     * Once you have done all these things, this test should pass.
     */
    GregorianCalendar fromDate = new GregorianCalendar(2005, Calendar.MAY, 4);
    String fromDateUTC = XmlDateTimeUtil.formatDateAsXmlUTC(fromDate.getTime());

    String cidxHeader = buildCIDXHeaderFromDealer(fromDateUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader, fromDateUTC);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    final String xpathProduct = "/Envelope/Body/AGIISProductExtract/Body/AGIISProductExtractDetails/CompanyInformation/ProductInformation";
    int productCount = XPathUtil.getNodeCount(responseXml, xpathProduct);
    System.out.println("Number of products extracted: " + productCount);
    assertFalse("At least one product is expected", 0 == productCount);

  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1.8.1  2008/02/11 21:06:51  maschec
 * Add javadoc about what it takes to get this test running, including running ECG Services, and changing URLMapping.xml.
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.17  2006/07/26 17:46:38  caggarw
 * Use CIDXConstants for Agency Attributes
 * Revision 1.16 2006/05/09 23:48:45 ggdavi
 * Removed protected namespace declaration constants from CidxMessageTestCase -
 * now use the XmlNamespace constants directly
 * 
 * Revision 1.15 2005/12/01 19:34:30 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.14 2005/09/16 18:00:48 ggdavi Changed visibility of request
 * message XML template to public so it can be used by the production
 * operational readiness test
 * 
 * Revision 1.13 2005/09/15 14:32:32 ggdavi Changed from date in
 * testJaxRpcProductList to bring back products in Test and Development
 * 
 * Revision 1.12 2005/08/17 14:00:17 ggdavi Removed extraction of DOM document
 * from test*BasicResponse methods, since it adds unnecessary time to the
 * performance tests that use them
 * 
 * Revision 1.11 2005/08/10 17:17:06 ggdavi Removed Xpath-based assertions from
 * testJaxRpc*BasicResponse and put then into a new test method, so they won't
 * impact the performance tests
 * 
 * Revision 1.10 2005/08/09 20:45:55 ggdavi Added the PrimaryProductSegmentCode
 * parameter to the request; from date time is now today at midnight, so we can
 * pick up data loaded (changed) today Revision 1.9 2005/08/09 16:40:01 ggdavi
 * Write the number of products extracted to the system console Revision 1.8
 * 2005/07/27 18:24:34 ggdavi Added FromDateTime parameter in an attempt to
 * minimize the risk of downloading thousands of products if someone else has
 * clobbered the database table... Revision 1.7 2005/07/19 17:43:36 ggdavi All
 * PostMethodWebRequest objects are built using the superclass's
 * buildSoapRequestWithCompression or buildSoapRequestWithoutCompression methods
 * 
 * Revision 1.6 2005/07/08 17:12:24 ggdavi Split SoapTestCase.buildCidxHeader
 * into buildCidxHeaderFromDealer and buildCidxHeaderToDealer methods
 * 
 * Revision 1.5 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method Revision 1.4 2005/06/27 23:10:01
 * ggdavi Remove to do comment
 * 
 * Revision 1.3 2005/06/23 21:47:29 ggdavi Added (currently failing) test for at
 * least one product Revision 1.2 2005/06/08 18:41:41 ggdavi Added required
 * //Seller element Revision 1.1 2005/06/08 17:33:53 ggdavi Initial version
 * 
 */