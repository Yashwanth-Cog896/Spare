package com.monsanto.ag.cf.acceptancetest;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.Util.MessageFormatter;
import com.monsanto.ag.xml.CidxConstants;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;
import com.monsanto.ag.xml.XmlNamespace;
import org.dbunit.dataset.IDataSet;
import org.dbunit.operation.DatabaseOperation;
import org.w3c.dom.Document;

import java.util.Date;

public class EDNConsumer_AT extends AcceptanceTestCase {

  private static final String FULL_REFRESH_USER_ID = "1033632";
  private static final String FULL_REFRESH_PASSWORD = "Test_123";
  private static final String FULL_REFRESH_EBID = "0002537320000";

  private static final String SERVICE_URI = "/soap/EDNConsumer_1-0";

  private static final String TEMPLATE_MESSAGE_XML = "<ShipNoticeListRequest "
      + "xmlns=\"urn:ecms:schema:shipnotice:request:1:0\" " + XmlNamespace.NAMESPACE_CIDX_40.getDeclaration()
      + " xmlns:ecms=\"urn:ecms:schema:shipnotice:request:1:0\" Version=\"1.0\">{0}"
      + "<ShipNoticeListRequestBody><ShipNoticeListRequestProperties/>"
      + "<ShipNoticeListRequestPartners><cidx:Seller><cidx:PartnerInformation>"
      + "<cidx:PartnerName>MONSANTO AGRICULTURAL CO</cidx:PartnerName>"
      + "<cidx:PartnerIdentifier " + CidxConstants.PARTNER_ID_AGENCY_ATTRIBUTE + "=\"" + CidxConstants.EBID_AGENCY + "\">0062668030000</cidx:PartnerIdentifier>"
      + "</cidx:PartnerInformation></cidx:Seller>" + "</ShipNoticeListRequestPartners><ShipNoticeListRequestDetails/>"
      + "</ShipNoticeListRequestBody></ShipNoticeListRequest>";

  public EDNConsumer_AT(String arg0) {
    super(arg0);
  }

  public void testGetWsdlForJaxRpcEDNConsumer() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcEDNConsumerBasicResponse() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcEDNConsumerLatestOnly() throws Exception {
    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));
  }

  public void testJaxRpcEDNConsumerFullRefresh() throws Exception {
    IDataSet iDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(),
        "InsertEDNSpecialInstruction");
    DatabaseOperation.CLEAN_INSERT.execute(getEcomDbUnitHelper()
        .getDbConnection(), iDataSet);

    String nowUTC = XmlDateTimeUtil.formatDateAsXmlUTC(new Date());
    // String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, FULL_REFRESH_EBID, "ST", "03.23.05", 2005, true);
    String cidxHeader = buildCIDXHeaderFromDealer(nowUTC, GOOD_USER_EBID, "ST", "03.23.05", 2005, true);
    String messageXml = MessageFormatter.format(TEMPLATE_MESSAGE_XML, cidxHeader);
    //String wsseSecurityHeader = buildWSSecurityHeader(FULL_REFRESH_USER_ID, FULL_REFRESH_PASSWORD, null, null);
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathShipNotice = "/Envelope/Body/ShipNoticeList/ShipNoticeListBody/ShipNoticeListDetails/ShipNoticeBody";
    int shipNoticeCount = XPathUtil.getNodeCount(responseXml, xpathShipNotice);
    System.out.println("Number of ship notices retrieved: " + shipNoticeCount);
    assertFalse("At least one ship notice is expected", 0 == shipNoticeCount);
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.12  2006/07/26 17:42:23  caggarw
 * Use CIDXConstants for Agency Attributes
 * Revision 1.11 2006/05/09 23:48:45 ggdavi
 * Removed protected namespace declaration constants from CidxMessageTestCase -
 * now use the XmlNamespace constants directly
 * 
 * Revision 1.10 2006/05/01 20:44:03 ggdavi Updated to reflect changes in
 * DbUnitHelper
 * 
 * Revision 1.9 2005/12/01 19:34:30 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.8 2005/11/30 13:54:19 ggdavi Factored out constants from user Ids
 * and passwords Revision 1.7 2005/09/06 21:06:57 ggdavi Use alternative user
 * for the full refresh test (someone who has a lot of SNPs, at least in the
 * Test environment...)
 * 
 * Revision 1.6 2005/08/19 15:55:16 ggdavi Output the number of transactions
 * used for the basic response tests to the console (in another test) Revision
 * 1.5 2005/08/17 14:00:17 ggdavi Removed extraction of DOM document from
 * test*BasicResponse methods, since it adds unnecessary time to the performance
 * tests that use them
 * 
 * Revision 1.4 2005/08/10 20:58:52 ggdavi Added
 * testJaxRpcEDNConsumerFullRefresh method Revision 1.3 2005/08/10 17:16:11
 * ggdavi Removed Xpath-based assertions from testJaxRpc*BasicResponse and put
 * then into a new test method, so they won't impact the performance tests
 * 
 * Revision 1.2 2005/07/19 17:43:36 ggdavi All PostMethodWebRequest objects are
 * built using the superclass's buildSoapRequestWithCompression or
 * buildSoapRequestWithoutCompression methods
 * 
 * Revision 1.1 2005/07/12 22:18:14 ggdavi Initial version
 * 
 */