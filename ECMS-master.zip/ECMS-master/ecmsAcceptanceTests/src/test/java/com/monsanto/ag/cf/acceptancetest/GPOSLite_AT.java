/*
 * GPOSLite_FT was created on Jan 30, 2008 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.ag.cf.EcmsXmlUtils;
import com.monsanto.ag.cf.test.TestConfig;
import com.monsanto.ag.util.test.DbUnitHelper;
import org.dbunit.Assertion;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dom4j.Attribute;
import org.dom4j.Element;
import org.w3c.dom.Document;

import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Test the GPOSLite web services.
 * 
 * @author Mark Schechter
 * @version $Id: GPOSLite_AT.java,v 1.9 2008-02-26 21:28:16 maschec Exp $
 */
public class GPOSLite_AT extends AcceptanceTestCase {
  private static final String NEW_LINE = System.getProperty("line.separator");

//  private static final String NOT_AUTHORIZED_USER_ID = "1730073";
//  private static final String NOT_AUTHORIZED_USER_PASSWORD = "EF#45ghi";
  
  private static final String DATA_EXCHANGE_TYPE_CODE = "GPOSLT";
  private static final String ROOT_NODE_NAME = "ProductMovementReportLite";

  private static final String SERVICE_URI = "/soap/GPOSLite_1-0";

  public GPOSLite_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcGPOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcGPOSBasicResponse() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOSLite/I2_Test1a.xml");
    String serviceUrl = getServiceUrl(SERVICE_URI);
    display("Sending request to: " + serviceUrl);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(serviceUrl, wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
    
    String responseText = EcmsXmlUtils.getResponseContents(response);
    display("response stream as string:\r\n" + responseText);
    
    Document responseXml = response.getDOM();

    DOMUtil.outputXML(responseXml);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals(DATA_EXCHANGE_TYPE_CODE, logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    /*
     * Following test is per input XML:
     *   <cidx:ThisDocumentDateTime>
     *     <cidx:DateTime DateTimeQualifier="On">2008-01-17T09:30:47Z</cidx:DateTime>
     *   </cidx:ThisDocumentDateTime>
     * Note there is a six hour differential, probably due to GMT vs. Central time.
     */
    assertEquals(new GregorianCalendar(2008, Calendar.JANUARY, 17, 3, 30, 47).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2008", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("3.1.12", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, ROOT_NODE_NAME));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    final int NUM_DIRECT_STAGING_RECS_EXPECTED = 2;
    assertEquals(NUM_DIRECT_STAGING_RECS_EXPECTED, ecgTable.getRowCount());
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), 
        "I2_Data1a");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
    
  }
  
  /**
   * Test scenario where ProdIDQual value is set to "GTIN"
   * rather than "AGIIS-ProductID".  A Soap Fault should be returned.
   * Note GTIN was originally allowed by the GPOSLite schema, but as of
   * 2-11-08 no longer passes schema validation.
   */
  public void testProdIdQualOldGTIN() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOSLite/I2_Test1b.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
    
    String responseText = EcmsXmlUtils.getResponseContents(response);
    display("response stream as string:\r\n" + responseText);

    Document responseDocument = response.getDOM();
    assertXpathEvaluatesTo("ecms:MessageNotValid", "/Envelope/Body/Fault/faultcode", responseDocument);
    //TODO: Either upgrade to XmlUnit 1.1 and see if it has this facility, or implement
    // it in Dom4jXmlUnit, but make a method which returns the value of an XPath
    // expression so we can test that it STARTS WITH or CONTAINS something, without having to
    // do an exact match.
    assertXpathExists("/Envelope/Body/Fault/faultstring", responseDocument);
    /*
     * The contents of faultstring should look something like this:
     * Document failed XML schema validation against 
     * http://localhost:8080/ecms/schemas/ecms/1-0/GPOSLite_1-0.xsd: 
     * cvc-enumeration-valid: Value 'GTIN' is not facet-valid with respect to enumeration 
     * '[AGIIS-ProductID, ANSI, AssignedByBuyer, AssignedByManufacturer, AssignedBySeller, EAN, EDIFACT, GBABA, ISO, Other, UPC]'. 
     * It must be a value from the enumeration.
     * ... more ...
     */
    int docFailedIdx = responseText.indexOf("Document failed XML schema validation"); 
    int notFacetValidIdx = responseText.indexOf("Value 'GTIN' is not facet-valid with respect to enumeration");
    assertTrue(docFailedIdx > 0);
    assertTrue(notFacetValidIdx > 0);
    assertTrue(notFacetValidIdx > docFailedIdx);
    
  }
  
  /**
   * Test scenario where ProdIDQual value is set to "UPC" (or any other valid value)
   * rather than "AGIIS-ProductID".  A Soap Fault should be returned.
   */
  public void testProdIdQualNotAGIISProductID() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOSLite/I2_Test1d.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
    
    String responseText = EcmsXmlUtils.getResponseContents(response);
    display("response stream as string:\r\n" + responseText);

    Document responseDocument = response.getDOM();
    assertXpathEvaluatesTo("ecms:MessageNotValid", "/Envelope/Body/Fault/faultcode", responseDocument);
    assertXpathEvaluatesTo("Attribute value of 'UPC' for TransactionDetails@ProdIDQual is not supported. " 
        + "Allowable value is 'AGIIS-ProductID'.", 
        "/Envelope/Body/Fault/faultstring", responseDocument);
  }

  /**
   * Test scenario where explicit ShipFrom element
   * is not specified, so that reporter information should be used 
   * instead to create Ship From information.
   */
  public void testCreateShipFromBasedOnReporterInformation() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOSLite/I2_Test1e.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
    
    String responseText = EcmsXmlUtils.getResponseContents(response);
    display("response stream as string:\r\n" + responseText);
    
    Document responseXml = response.getDOM();

    DOMUtil.outputXML(responseXml);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals(DATA_EXCHANGE_TYPE_CODE, logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    /*
     * Following test is per input XML:
     *   <cidx:ThisDocumentDateTime>
     *     <cidx:DateTime DateTimeQualifier="On">2008-01-17T09:30:47Z</cidx:DateTime>
     *   </cidx:ThisDocumentDateTime>
     * Note there is a six hour differential, probably due to GMT vs. Central time.
     */
    assertEquals(new GregorianCalendar(2008, Calendar.JANUARY, 17, 3, 30, 47).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2008", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("3.1.12", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, ROOT_NODE_NAME));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    final int NUM_DIRECT_STAGING_RECS_EXPECTED = 2;
    assertEquals(NUM_DIRECT_STAGING_RECS_EXPECTED, ecgTable.getRowCount());
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), 
        "I2_Data1e");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
    
  }

  /**
   * Test a valid Ship From with valid agency qualifier.
   * Standard GPOS - order of 10bags Dekalb corn - delivered to grower.
   * Happy path - all primary components supplied.
   */
  public void testGoodGPOSLiteGoodDealer() throws Exception {
    commonTestGoodRequest("/GPOSLite/TestGoodDealer_1a.xml", 1, "TestGoodDealer_Data1a");
  }

  /**
   * Test delivery of all product specie types (canola, corn, soy, sudax, etc.).
   * Same reporter, same Ship From, various growers (expected qualifiers)
   */
  public void testGoodGPOSGoodDealerAllProducts() throws Exception {
    commonTestGoodRequest("/GPOSLite/TestGoodDealerAllProds_1b.xml", 11, 
        "TestGoodDealerAllProds_Data1b");
  }
  
  /**
   * Common routine to execute tests with request XML in a file, and expected
   * staging results (to be verified by DbUnit as found in table DIRECT_STAGING)
   * in a file.
   * 
   * @param requestXmlFilename name of file containing request XML, to be passed
   * to getRequestXmlFromUri().
   * @param expectedStagingRows number of rows (records) in DIRECT_STAGING table
   * expected to result from the request.
   * @param expectedStagingDataFilename name of file containing contents of expected 
   * rows in DIRECT_STAGING table, to be passed to getEcomDbUnitHelper().getTestCaseDataSet().
   */
  private void commonTestGoodRequest(String requestXmlFilename, int expectedStagingRows,
      String expectedStagingDataFilename) throws Exception 
  {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri(requestXmlFilename);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    DOMUtil.outputXML(responseXml);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOSLT", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2008, Calendar.JANUARY, 17, 3, 30, 47).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2007", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("3.1.12", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReportLite"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    assertEquals(expectedStagingRows, ecgTable.getRowCount());
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), 
        expectedStagingDataFilename);
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }
  
  /**
   * Run this test manually to generate the field values of DIRECT_STAGING from
   * a particular input. Of course, generating the expected results in this way
   * is only useful if the validity of the actual results (which this method pulls)
   * were confirmed independently. 
   */
  public void xtestSelectDirectStaging() throws Exception {
    DbUnitHelper dbUnitHelper = getEcgDbUnitHelper();
    IDatabaseConnection databaseConnection = dbUnitHelper.getDbConnection();
    //Partial database export
    QueryDataSet partialDataSet = new QueryDataSet(databaseConnection);
    String conversationId = "F24cAI441Qe4Cqn6Q+4byA=="; //CHANGE THIS to whatever the actual conversation ID was
    partialDataSet.addTable("DIRECT_STAGING", 
        "SELECT * FROM ecg_ld.DIRECT_STAGING WHERE CONVERSATION_ID = '" + conversationId + "'"
        + " ORDER BY INV_NBR, ORDER_TYPE");
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    FlatXmlDataSet.write(partialDataSet, outputStream);
    String dataSetXml = outputStream.toString(); 
    //Note: Uncommenting the following is useful during testing with BAs to
    // get a dump of all the non-null fields
    //display(dataSetXml);
    
    /*
     * To avoid having to manually massage the output (dataSetXml) to eliminate
     * the columns which are not relevant, we'll read the DTD that defines the
     * relevant columns, and use that to massage dataSetXml to eliminate 
     * non-relevant columns.
     */

    //Read the DTD and get a List of all the relevant column names
    final String TEST_DATA_DIRECTORY = 
      TestConfig.getTestDataParentSubpath() + "testdata/db/";

    final String DTD_FILE_NAME = "gposlite_test_data.dtd"; 
    File dtdFile = new File(TEST_DATA_DIRECTORY + File.separator 
        + unqualifiedClassName(this.getClass())
        + File.separator + DTD_FILE_NAME);
    assertTrue(dtdFile.exists());
    InputStream dtdStream = new BufferedInputStream(new FileInputStream(dtdFile));
    StringBuffer sb = new StringBuffer();
    EcmsXmlUtils.readStreamIntoStringBuffer(dtdStream, sb);
    String dtd = sb.toString();
//    display(dtd);

    String ptrn = null;
    //Note re the following: StartOfLine (^) wasn't working, but that may 
    // require some initial setting to consider/not consider line breaks
    ptrn = "\\s*([\\w_]*)\\s*CDATA";
    Pattern pattern = Pattern.compile(ptrn);

    Matcher matcher = pattern.matcher(dtd);

    List dtdColNames = new ArrayList();
//    display("+++++++++++ MATCHES ++++++++++++");
    while (matcher.find()) {
      String colName = matcher.group(1);
//        display("I found the text " + matcher.group()
//            + " starting at index " + matcher.start()
//            + " and ending at index "+ matcher.end()
//            + " and group(1) = '" + colName + "'");
        dtdColNames.add(colName);
    }
    assertTrue(dtdColNames.size() > 10);    //10 is arbitrary, but we should have a whole bunch
//    for (Iterator iter = dtdColNames.iterator(); iter.hasNext();) {
//      String colName = (String) iter.next();
//      display("'" + colName + "'");
//    }
    
    org.dom4j.Document dataSetDoc = EcmsXmlUtils.createDom4jDoc(dataSetXml);
    List directStagingList = dataSetDoc.selectNodes("/dataset/DIRECT_STAGING");
    for (Iterator iter = directStagingList.iterator(); iter.hasNext();) {
      Element element = (Element) iter.next();
      List attributes = element.attributes();
      List attributesToRemove = new ArrayList();
      for (Iterator attrIter = attributes.iterator(); attrIter.hasNext();) {
        Attribute attribute = (Attribute) attrIter.next();
        String attributeName = attribute.getName();
        if (!dtdColNames.contains(attributeName)) {
          //display("Attribute " + attributeName + " not in DTD");
          attributesToRemove.add(attribute);
        }
      }
      for (Iterator iterator = attributesToRemove.iterator(); iterator
          .hasNext();) {
        Attribute attribute = (Attribute) iterator.next();
        element.remove(attribute);
      }
    }
    dataSetXml = dataSetDoc.asXML();
    //Add the DTD declaration at the appropriate place
    final String DATASET_ELEMENT_NAME = "dataset";
    int startOfDatasetElement = dataSetXml.indexOf("<" + DATASET_ELEMENT_NAME + ">");
    dataSetXml = dataSetXml.substring(0, startOfDatasetElement) 
      + "<!DOCTYPE " + DATASET_ELEMENT_NAME + " SYSTEM \"" + DTD_FILE_NAME + "\">" + NEW_LINE
      + dataSetXml.substring(startOfDatasetElement);
    display(dataSetXml);
  }

  /**
   * Return the class name only, without the package name prefix.
   */
  private String unqualifiedClassName(Class clazz) {
    String qualifiedClassName = clazz.getName();
    return qualifiedClassName.substring(qualifiedClassName.lastIndexOf(".") + 1);
  }

  
  
  /** Central location to turn on/off interactive debugging messages
   * (without messing with Log4j). */
  private void display(String msg) {
    System.out.println(msg);
  }
  
}
/*
 * $Log: not supported by cvs2svn $
 * Revision 1.8  2008/02/15 19:51:26  maschec
 * Add comment
 *
 * Revision 1.7  2008/02/14 16:46:22  maschec
 * Implement GPOSLite revision request to default Ship From information based on reporter info, if not explicitly provided by an OtherPartner element
 *
 * Revision 1.6  2008/02/13 23:31:55  maschec
 * Remove intermediary strings when building dataset
 *
 * Revision 1.5  2008/02/13 23:26:01  maschec
 * Automatically add DTD line to generated dataset contents
 *
 * Revision 1.4  2008/02/13 22:29:53  maschec
 * Get testGoodPOSGoodDealerAllProducts() working, including automatically create DBUnit expected results file
 *
 * Revision 1.3  2008/02/13 20:48:07  maschec
 * Get TestGoodDealerAllProds FT working
 *
 * Revision 1.2  2008/02/13 16:23:31  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.1.2.8  2008/02/12 23:38:19  maschec
 * Begin adding functional tests from Denise
 *
 * Revision 1.1.2.7  2008/02/12 16:11:34  maschec
 * Add test where ProdIDQual is still valid per schema but is not AGIIS-ProductID
 *
 * Revision 1.1.2.6  2008/02/12 15:48:32  maschec
 * Update GPOSLite schema to reference CIDX for enum values where applicable; modify expected test results accordingly
 *
 * Revision 1.1.2.5  2008/02/08 21:27:11  maschec
 * Implement functional test for when ProdIDQual is set incorrectly
 *
 * Revision 1.1.2.4  2008/02/05 19:13:41  maschec
 * Change allowable value of TransactionDetails@ProdIDQual from 'GTIN' to 'AGIIS-ProductID', and throw Soap Fault if it's anything else
 *
 * Revision 1.1.2.3  2008/02/05 00:05:49  maschec
 * Save WIP: After getting SRXH working properly in WebMethods
 *
 * Revision 1.1.2.2  2008/02/04 21:02:23  maschec
 * Implement full acceptance test for GPOSLite including confirmation of results (based on pattern used in GPOS_AT, namely regular GPOS acceptance test).
 *
 * Revision 1.1.2.1  2008/01/30 22:51:39  maschec
 * Get GPOSLite implementation working (without transform and without passing to WebMethods)
 *
 *
 */