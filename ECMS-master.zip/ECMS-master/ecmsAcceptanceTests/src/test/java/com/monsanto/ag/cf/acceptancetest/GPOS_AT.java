/*
 * GPOS_AT was created on Apr 21, 2005 using Monsanto resources and is the sole
 * property of Monsanto. Any duplication of the code and/or logic is a direct
 * infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.dbunit.Assertion;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;
import com.monsanto.ag.xml.XmlDateTimeUtil;

/**
 * Test the GPOS web services.
 * 
 * Note: When dates are written to the DIRECT_STAGING table by WebMethods,
 * which these web services call, GMT date/times are transformed to St. Louis
 * date/times. Therefore dates such as 2004-07-15T00:00:00Z become
 * 2004-07-14 since St. Louis is 5 or 6 hours prior to GMT depending on whether
 * Daylight Savings Time is in effect.  The fields in DIRECT_STAGING affected
 * are RPT_DATE, INV_DATE and SHIP_DATE.
 * 
 * @author Gareth Davies
 * @version $Id: GPOS_AT.java,v 1.5 2008-04-16 18:58:32 maschec Exp $
 */
public class GPOS_AT extends AcceptanceTestCase {

  private static final String NOT_AUTHORIZED_USER_ID = "1730073";
  private static final String NOT_AUTHORIZED_USER_PASSWORD = "EF#45ghi";

  private static final String SERVICE_URI = "/soap/GPOS_4-0";

  public GPOS_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcGPOS() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
    
  }

  public void testJaxRpcGPOSBasicResponse() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1h.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testGoodGPOSGoodDealer() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1a.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // DOMUtil.outputXML(responseXml);
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.MAY, 5, 10, 55, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    assertEquals(1, ecgTable.getRowCount());
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1a");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testGoodGPOSGoodDealerAllProducts() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1b.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(1, logTable.getRowCount());
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.APRIL, 28, 3, 2, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2005", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1b");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testGoodGPOSGoodDealerSalesReturns() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1c.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1c");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSGoodDealerAlfalfa() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1d.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1d");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSGoodDealerReversals() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1e.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1e");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testNoGPOSRoleForDealer() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(NOT_AUTHORIZED_USER_ID, NOT_AUTHORIZED_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1f.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    assertXpathEvaluatesTo("wsse:FailedAuthentication", "/Envelope/Body/Fault/faultcode", responseXml);
    assertXpathEvaluatesTo("The security token could not be authenticated or authorized",
        "/Envelope/Body/Fault/faultstring", responseXml);
  }

  public void testFullRefreshGPOSWithGZIPCompression() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1h.xml");
    PostMethodWebRequest request = buildSoapRequestWithCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("gzip", response.getHeaderField("Content-Encoding"));
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));
  }

  public void testGoodGPOSGoodDealerWrongEBID() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1k.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1k");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void test2004GPOSGoodDealer() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1l.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that Log Record has been created
    ITable logTable = getEcomDbUnitHelper().getActualTable(buildActivityLogSql(conversationId));
    assertEquals(GOOD_USER_ID, logTable.getValue(0, "USER_ID"));
    assertEquals("GPOS", logTable.getValue(0, "DATA_EXCHANGE_TYPE_CODE"));
    assertEquals(new GregorianCalendar(2005, Calendar.APRIL, 20, 3, 2, 34).getTime(), logTable.getValue(0,
        "DATA_EXCHANGE_START_DATE"));
    assertTrue("DATA_EXCHANGE_END_DATE is not near current time", getEcomDbUnitHelper()
        .isDateColumnValueNearCurrentTime(logTable, 0, "DATA_EXCHANGE_END_DATE", CURRENT_TIME_TOLERANCE_MILLIS_DEFAULT));
    assertEquals("2004", logTable.getValue(0, "SEED_YEAR"));
    assertEquals("03.23.05", logTable.getValue(0, "SOFTWARE_VERSION_ID"));
    assertEquals(new BigDecimal(GOOD_USER_ACCOUNT_ID), logTable.getValue(0, "ACCT_ID"));

    // Check that XML has been stored in Data_Exchange_Repository
    String dataExchangeId = logTable.getValue(0, "DATA_EXCHANGE_ID").toString();
    ITable repositoryTable = getEcomDbUnitHelper().getActualTable(
        buildXmlRepositorySql(dataExchangeId, "ProductMovementReport"));
    assertEquals(1, repositoryTable.getRowCount());
    assertNotNull("Repository XML must exist", repositoryTable.getValue(0, "XML_MSG"));

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1l");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);

    // Check that two events have been logged
    assertBothEventsLogged(conversationId);
  }

  public void testPoorlyFormedGPOS() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, "XrJFAA4vH5NqDnBj+OtfKg==",
        XmlDateTimeUtil.formatDateAsXmlUTC(new Date()));
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        "<foo><bar></foo>");

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();
    // DOMUtil.outputXML(responseXml);

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    assertXpathEvaluatesTo("soapenv:Server.generalException", "/Envelope/Body/Fault/faultcode", responseXml);
    String faultString = XPathUtil.getTextNodeValue(responseXml, "/Envelope/Body/Fault/faultstring");
    assertTrue(StringUtils.contains(faultString, "cannot convert into document"));
  }

  public void testGoodGPOSGoodDealerNonASKDProducts() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1n.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1n");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodGPOSMultipleDealers() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1o.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

//    DOMUtil.outputXML(responseXml);
    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1o");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testGoodDealerWrongEBID() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1p.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1p");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  public void testNonCidxXmlGoodDealer() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1q.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertXpathEvaluatesTo("ecms:MessageNotValid", "/Envelope/Body/Fault/faultcode", responseXml);
    String validationError = "Document failed XML schema validation";
    String faultString = XPathUtil.getTextNodeValue(responseXml, "/Envelope/Body/Fault/faultstring");
    assertTrue("Document fails schema validation", faultString.startsWith(validationError));
  }
  
  public void testGoodGPOSGoodDealerSalesEndUser() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1r.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

//    DOMUtil.outputXML(responseXml);
    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1r");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }
  
  public void testGoodGPOSGoodDealerSalesWholesale() throws Exception {
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    String messageXml = getRequestXmlFromUri("/GPOS/I2_Test1s.xml");
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    assertNotNull(response);
    assertEquals("text/xml", response.getContentType());
    Document responseXml = response.getDOM();

//    DOMUtil.outputXML(responseXml);
    // Check output document
    assertNotNull("Valid document must be returned", responseXml);
    String conversationId = getConversationIdFromResponseDocument(responseXml);
    assertNotNull("Conversation Id must exist", conversationId);

    // Check that data is correct
    ITable ecgTable = getActualEcgPosStagingTable(conversationId);
    IDataSet expectedDataSet = getEcomDbUnitHelper().getTestCaseDataSet(this.getClass(), "I2_Data1s");
    ITable expectedTable = expectedDataSet.getTable("DIRECT_STAGING");
    Assertion.assertEquals(expectedTable, ecgTable);
  }

  private boolean checkEachValue(ITable expectedTable, ITable ecgTable, int myRowEcg) throws Exception {
    assertEquals(expectedTable.getValue(0, "TRAN_SET_PURPOSE"), ecgTable.getValue(myRowEcg, "TRAN_SET_PURPOSE"));
    assertEquals(expectedTable.getValue(0, "DATA_SOURCE"), ecgTable.getValue(myRowEcg, "DATA_SOURCE"));
    assertEquals(expectedTable.getValue(0, "RPT_DATE"), ecgTable.getValue(myRowEcg, "RPT_DATE"));
    assertEquals(expectedTable.getValue(0, "RPT_TYPE"), ecgTable.getValue(myRowEcg, "RPT_TYPE"));
    assertEquals(expectedTable.getValue(0, "DS_TYPE"), ecgTable.getValue(myRowEcg, "DS_TYPE"));
    assertEquals(expectedTable.getValue(0, "DS_NAME"), ecgTable.getValue(myRowEcg, "DS_NAME"));
    assertEquals(expectedTable.getValue(0, "DS_ID_QUAL"), ecgTable.getValue(myRowEcg, "DS_ID_QUAL"));
    assertEquals(expectedTable.getValue(0, "DS_ID_VALUE"), ecgTable.getValue(myRowEcg, "DS_ID_VALUE"));
    assertEquals(expectedTable.getValue(0, "SF_ID_QUAL"), ecgTable.getValue(myRowEcg, "SF_ID_QUAL"));
    assertEquals(expectedTable.getValue(0, "SF_ID_VALUE"), ecgTable.getValue(myRowEcg, "SF_ID_VALUE"));
    assertEquals(expectedTable.getValue(0, "ST_TYPE"), ecgTable.getValue(myRowEcg, "ST_TYPE"));
    assertEquals(expectedTable.getValue(0, "ST_NAME"), ecgTable.getValue(myRowEcg, "ST_NAME"));
    assertEquals(expectedTable.getValue(0, "ST_ID_QUAL"), ecgTable.getValue(myRowEcg, "ST_ID_QUAL"));
    assertEquals(expectedTable.getValue(0, "ST_ID_VALUE"), ecgTable.getValue(myRowEcg, "ST_ID_VALUE"));
    assertEquals(expectedTable.getValue(0, "ST_ADDR1"), ecgTable.getValue(myRowEcg, "ST_ADDR1"));
    assertEquals(expectedTable.getValue(0, "ST_CITY"), ecgTable.getValue(myRowEcg, "ST_CITY"));
    assertEquals(expectedTable.getValue(0, "ST_STATE"), ecgTable.getValue(myRowEcg, "ST_STATE"));
    assertEquals(expectedTable.getValue(0, "ST_ZIP"), ecgTable.getValue(myRowEcg, "ST_ZIP"));
    assertEquals(expectedTable.getValue(0, "CONTACT_NAME_QUAL"), ecgTable.getValue(myRowEcg, "CONTACT_NAME_QUAL"));
    assertEquals(expectedTable.getValue(0, "CONTACT_NAME_VALUE"), ecgTable.getValue(myRowEcg, "CONTACT_NAME_VALUE"));
    assertEquals(expectedTable.getValue(0, "CONTACT_PHONE_QUAL"), ecgTable.getValue(myRowEcg, "CONTACT_PHONE_QUAL"));
    assertEquals(expectedTable.getValue(0, "CONTACT_PHONE_VALUE"), ecgTable.getValue(myRowEcg, "CONTACT_PHONE_VALUE"));
    assertEquals(expectedTable.getValue(0, "PROD_TRANSFER_CODE"), ecgTable.getValue(myRowEcg, "PROD_TRANSFER_CODE"));
    assertEquals(expectedTable.getValue(0, "INV_DATE_QUAL"), ecgTable.getValue(myRowEcg, "INV_DATE_QUAL"));
    assertEquals(expectedTable.getValue(0, "INV_DATE"), ecgTable.getValue(myRowEcg, "INV_DATE"));
    assertEquals(expectedTable.getValue(0, "SHIP_DATE_QUAL"), ecgTable.getValue(myRowEcg, "SHIP_DATE_QUAL"));
    assertEquals(expectedTable.getValue(0, "SHIP_DATE"), ecgTable.getValue(myRowEcg, "SHIP_DATE"));
    assertEquals(expectedTable.getValue(0, "ORDER_TYPE"), ecgTable.getValue(myRowEcg, "ORDER_TYPE"));
    assertEquals(expectedTable.getValue(0, "INV_NBR"), ecgTable.getValue(myRowEcg, "INV_NBR"));
    assertEquals(expectedTable.getValue(0, "QTY_QUAL"), ecgTable.getValue(myRowEcg, "QTY_QUAL"));
    assertEquals(expectedTable.getValue(0, "QTY"), ecgTable.getValue(myRowEcg, "QTY"));
    assertEquals(expectedTable.getValue(0, "LINE_UOM"), ecgTable.getValue(myRowEcg, "LINE_UOM"));
    assertEquals(expectedTable.getValue(0, "LINE_ID_QUAL"), ecgTable.getValue(myRowEcg, "LINE_ID_QUAL"));
    assertEquals(expectedTable.getValue(0, "LINE_ID_VALUE"), ecgTable.getValue(myRowEcg, "LINE_ID_VALUE"));
    assertEquals(expectedTable.getValue(0, "DOC_CTL_ID"), ecgTable.getValue(myRowEcg, "DOC_CTL_ID"));
    assertEquals(expectedTable.getValue(0, "PARTNER_ID"), ecgTable.getValue(myRowEcg, "PARTNER_ID"));
    assertEquals(expectedTable.getValue(0, "FIELD_COORDINATES"), ecgTable.getValue(myRowEcg, "FIELD_COORDINATES"));
    return true;
  }

}
/*
 * $Log: not supported by cvs2svn $
 * Revision 1.4  2008/04/14 16:51:57  maschec
 * Update GPOS acceptance test to reflect fix that now stores dates in DIRECT_STAGING in St. Louis time rather than GMT time.
 *
 * Revision 1.3  2008/02/13 16:23:31  maschec
 * Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 *
 * Revision 1.2.2.1  2008/02/11 21:43:37  maschec
 * Refaactor common code to (more robust) assertBothEventsLogged()
 *
 * Revision 1.2  2008/01/29 23:42:32  maschec
 * Merge branches EComMessageSystem_MAS_20070123_MobileGPOS/2 to Head: Implement test harness for GPOSLite web service, and make JUnit tests that refer to file system pass within Eclipse.
 *
 * Revision 1.1.6.1  2008/01/28 17:11:43  maschec
 * Re-enable test accidentally disabled
 *
 * Revision 1.1  2006/08/14 21:14:47  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.70  2006/07/28 21:56:42  caggarw
 * added tests for to check attributes sent by LOL
 *
 * Revision 1.69  2006/07/26 18:03:07  caggarw
 * *** empty log message ***
 * Revision 1.68 2006/06/26 15:19:43 caggarw
 * root_node_name added to data_exchange_repository as a primary key
 * 
 * Revision 1.67 2006/05/01 20:44:03 ggdavi Updated to reflect changes in
 * DbUnitHelper
 * 
 * Revision 1.66 2005/12/01 19:34:30 ggdavi Refactored com.monsanto.ag.util
 * package, moving all XML-specific classes and tests into the new
 * com.monsanto.ag.xml package; the com.monsanto.ag.xml.XmlChunks class replaces
 * the java.util.List interface as the primary representation of a collection of
 * XML chunks
 * 
 * Revision 1.65 2005/11/30 13:54:19 ggdavi Factored out constants from user Ids
 * and passwords Revision 1.64 2005/09/02 18:21:53 ggdavi Refactored
 * getRequestXmlFromUri method from xPOS_AT to read request XML from files
 * 
 * Revision 1.63 2005/08/19 15:55:16 ggdavi Output the number of transactions
 * used for the basic response tests to the console (in another test) Revision
 * 1.62 2005/08/17 14:00:17 ggdavi Removed extraction of DOM document from
 * test*BasicResponse methods, since it adds unnecessary time to the performance
 * tests that use them
 * 
 * Revision 1.61 2005/08/08 16:53:49 ggdavi Fixed validation error message text
 * to be suitably generic between implementations Revision 1.60 2005/08/05
 * 18:49:43 ggdavi Changed SOAP fault messages for bad XML Revision 1.59
 * 2005/07/26 17:14:38 ggdavi Modified assertion for schema validation errors
 * Revision 1.58 2005/07/19 17:43:36 ggdavi All PostMethodWebRequest objects are
 * built using the superclass's buildSoapRequestWithCompression or
 * buildSoapRequestWithoutCompression methods Revision 1.57 2005/07/18 16:13:12
 * ggdavi Added testFullRefreshGPOSWithGZIPCompression method Revision 1.56
 * 2005/06/30 17:43:26 ggdavi Moved ag.aop, ag.config and ag.message packages
 * under the ag.cf package
 * 
 * Revision 1.55 2005/06/30 16:20:28 ggdavi Moved body of WSDL test methods into
 * base class assertWsdlServiceUrl method Revision 1.54 2005/06/13 19:49:24
 * ajbaldw changed the password for testGoodGPOSMultipleDealers()
 * 
 * Revision 1.53 2005/06/06 21:18:53 ggdavi Added buildActivityEventSql and
 * buildXmlRepositorySql methods Revision 1.52 2005/06/06 18:17:56 ggdavi
 * Refactoring Revision 1.50 2005/06/02 16:41:45 ggdavi All XPaths now work on
 * the SOAP document Revision 1.49 2005/06/01 20:32:38 ggdavi
 * DATA_EXCHANGE_EVENT status code assertions now use the constants in
 * XmlUserActivity and POSListener Revision 1.48 2005/06/01 18:56:52 ggdavi
 * Refactored for consistency
 * 
 * Revision 1.47 2005/06/01 17:17:54 ggdavi Added prefix flag to
 * SoapTestCase.buildCIDXHeader; test for 2 event records in DB; cleaned up some
 * naming Revision 1.46 2005/05/31 20:42:48 ggdavi Use SOAP faults instead of a
 * standard error document Revision 1.45 2005/05/31 17:29:09 ajbaldw some xpath
 * changes for the soap faults. Revision 1.44 2005/05/28 00:27:31 ajbaldw not
 * quite working yet... The DocumentValidationHandler has something wrong with
 * it.
 * 
 * Revision 1.43 2005/05/26 21:26:33 ajbaldw changed all xpath assertions to
 * assertEquals or the like because of the cidx: prefixes. Revision 1.42
 * 2005/05/25 22:29:29 ggdavi Security failures now result in SOAP faults
 * Revision 1.41 2005/05/25 14:05:21 lsdenny *** empty log message ***
 * 
 * Revision 1.40 2005/05/23 19:29:39 ggdavi Pulled-up DbUnitHelper objects to
 * superclass
 * 
 * Revision 1.39 2005/05/23 17:31:24 lsdenny Added Ship-From Address Info
 * 
 * Revision 1.38 2005/05/18 17:33:23 lsdenny *** empty log message ***
 * 
 * Revision 1.37 2005/05/17 19:36:19 lsdenny Updated with test corrections.
 * Added code that Gareth had added. Revision 1.34 2005/05/17 13:49:30 lsdenny
 * *** empty log message *** Revision 1.33 2005/05/16 23:06:06 ggdavi Added
 * tolerance parameter to DbUnitHelper.isDateColumnValueNearCurrentTime method
 * Revision 1.31 2005/05/16 20:57:55 lsdenny *** empty log message *** Revision
 * 1.29 2005/05/16 17:24:36 lsdenny *** empty log message *** Revision 1.28
 * 2005/05/16 16:33:45 lsdenny *** empty log message *** Revision 1.27
 * 2005/05/16 16:00:53 lsdenny *** empty log message *** Revision 1.26
 * 2005/05/13 18:56:32 lsdenny *** empty log message *** Revision 1.25
 * 2005/05/13 18:32:01 lsdenny Added Error Messages for poorly formed XML
 * message and non-standard XML message. Revision 1.24 2005/05/13 17:43:23
 * lsdenny *** empty log message *** Revision 1.23 2005/05/13 15:09:11 lsdenny
 * *** empty log message *** Revision 1.22 2005/05/12 15:19:35 lsdenny *** empty
 * log message *** Revision 1.21 2005/05/12 13:07:04 lsdenny *** empty log
 * message *** Revision 1.20 2005/05/11 21:13:22 lsdenny Using
 * Assertion.assertEquals() for logTable compare. Revision 1.18 2005/05/11
 * 19:16:50 lsdenny *** empty log message *** Revision 1.17 2005/05/11 18:14:18
 * lsdenny *** empty log message *** Revision 1.16 2005/05/11 15:14:49 lsdenny
 * *** empty log message *** Revision 1.15 2005/05/11 14:56:06 lsdenny *** empty
 * log message *** Revision 1.14 2005/05/11 12:51:33 lsdenny *** empty log
 * message *** Revision 1.13 2005/05/10 20:51:11 lsdenny *** empty log message
 * *** Revision 1.12 2005/05/10 19:48:32 lsdenny Change to use 2 unitHelpers
 * Revision 1.11 2005/05/10 15:19:03 lsdenny Adding ECG db connection Revision
 * 1.10 2005/05/09 21:37:00 lsdenny Added DB Changes Revision 1.9 2005/05/09
 * 20:47:56 lsdenny Added checks for Repository and Event tables Revision 1.8
 * 2005/05/06 17:39:56 ggdavi Made changes so the classes would compile...
 * Revision 1.7 2005/05/06 17:36:31 ggdavi Removed unnecessary objects Revision
 * 1.6 2005/05/06 14:16:30 lsdenny *** empty log message *** Revision 1.5
 * 2005/05/05 21:00:13 lsdenny Changes Revision 1.4 2005/05/05 18:58:12 lsdenny
 * *** empty log message *** Revision 1.3 2005/05/05 18:53:01 lsdenny *** empty
 * log message *** Revision 1.2 2005/05/05 15:00:49 lsdenny *** empty log
 * message *** Revision 1.1 2005/04/27 11:32:35 ggdavi Renamed
 * ag.cf.functionaltest to ag.cf.acceptancetest Revision 1.1 2005/04/21 19:15:22
 * ggdavi Initial version $Log: not supported by cvs2svn $
 * ggdavi Initial version Revision 1.4  2008/04/14 16:51:57  maschec
 * ggdavi Initial version Update GPOS acceptance test to reflect fix that now stores dates in DIRECT_STAGING in St. Louis time rather than GMT time.
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.3  2008/02/13 16:23:31  maschec
 * ggdavi Initial version Merge GPOSLite implementation from branch EComMessageSystem_MAS_20070130_GPOSLite
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.2.2.1  2008/02/11 21:43:37  maschec
 * ggdavi Initial version Refaactor common code to (more robust) assertBothEventsLogged()
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.2  2008/01/29 23:42:32  maschec
 * ggdavi Initial version Merge branches EComMessageSystem_MAS_20070123_MobileGPOS/2 to Head: Implement test harness for GPOSLite web service, and make JUnit tests that refer to file system pass within Eclipse.
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.1.6.1  2008/01/28 17:11:43  maschec
 * ggdavi Initial version Re-enable test accidentally disabled
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.1  2006/08/14 21:14:47  caggarw
 * ggdavi Initial version renamed Acceptance Tests (AT) to Functional Tests (FT)
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.70  2006/07/28 21:56:42  caggarw
 * ggdavi Initial version added tests for to check attributes sent by LOL
 * ggdavi Initial version
 * ggdavi Initial version Revision 1.69  2006/07/26 18:03:07  caggarw
 * ggdavi Initial version *** empty log message ***
 * ggdavi Initial version ggdavi Initial version Revision
 * 1.68 2006/06/26 15:19:43 caggarw ggdavi Initial version root_node_name added
 * to data_exchange_repository as a primary key ggdavi Initial version ggdavi
 * Initial version Revision 1.67 2006/05/01 20:44:03 ggdavi ggdavi Initial
 * version Updated to reflect changes in DbUnitHelper ggdavi Initial version
 * ggdavi Initial version Revision 1.66 2005/12/01 19:34:30 ggdavi ggdavi
 * Initial version Refactored com.monsanto.ag.util package, moving all
 * XML-specific classes and tests into the new com.monsanto.ag.xml package; the
 * com.monsanto.ag.xml.XmlChunks class replaces the java.util.List interface as
 * the primary representation of a collection of XML chunks ggdavi Initial
 * version ggdavi Initial version Revision 1.65 2005/11/30 13:54:19 ggdavi
 * ggdavi Initial version Factored out constants from user Ids and passwords
 * ggdavi Initial version ggdavi Initial version Revision 1.64 2005/09/02
 * 18:21:53 ggdavi ggdavi Initial version Refactored getRequestXmlFromUri method
 * from xPOS_AT to read request XML from files ggdavi Initial version ggdavi
 * Initial version Revision 1.63 2005/08/19 15:55:16 ggdavi ggdavi Initial
 * version Output the number of transactions used for the basic response tests
 * to the console (in another test) ggdavi Initial version ggdavi Initial
 * version Revision 1.62 2005/08/17 14:00:17 ggdavi ggdavi Initial version
 * Removed extraction of DOM document from test*BasicResponse methods, since it
 * adds unnecessary time to the performance tests that use them ggdavi Initial
 * version ggdavi Initial version Revision 1.61 2005/08/08 16:53:49 ggdavi
 * ggdavi Initial version Fixed validation error message text to be suitably
 * generic between implementations ggdavi Initial version ggdavi Initial version
 * Revision 1.60 2005/08/05 18:49:43 ggdavi ggdavi Initial version Changed SOAP
 * fault messages for bad XML ggdavi Initial version ggdavi Initial version
 * Revision 1.59 2005/07/26 17:14:38 ggdavi ggdavi Initial version Modified
 * assertion for schema validation errors ggdavi Initial version ggdavi Initial
 * version Revision 1.58 2005/07/19 17:43:36 ggdavi ggdavi Initial version All
 * PostMethodWebRequest objects are built using the superclass's
 * buildSoapRequestWithCompression or buildSoapRequestWithoutCompression methods
 * ggdavi Initial version ggdavi Initial version Revision 1.57 2005/07/18
 * 16:13:12 ggdavi ggdavi Initial version Added
 * testFullRefreshGPOSWithGZIPCompression method ggdavi Initial version ggdavi
 * Initial version Revision 1.56 2005/06/30 17:43:26 ggdavi ggdavi Initial
 * version Moved ag.aop, ag.config and ag.message packages under the ag.cf
 * package ggdavi Initial version ggdavi Initial version Revision 1.55
 * 2005/06/30 16:20:28 ggdavi ggdavi Initial version Moved body of WSDL test
 * methods into base class assertWsdlServiceUrl method ggdavi Initial version
 * ggdavi Initial version Revision 1.54 2005/06/13 19:49:24 ajbaldw ggdavi
 * Initial version changed the password for testGoodGPOSMultipleDealers() ggdavi
 * Initial version ggdavi Initial version Revision 1.53 2005/06/06 21:18:53
 * ggdavi ggdavi Initial version Added buildActivityEventSql and
 * buildXmlRepositorySql methods ggdavi Initial version ggdavi Initial version
 * Revision 1.52 2005/06/06 18:17:56 ggdavi ggdavi Initial version Refactoring
 * ggdavi Initial version ggdavi Initial version Revision 1.50 2005/06/02
 * 16:41:45 ggdavi ggdavi Initial version All XPaths now work on the SOAP
 * document ggdavi Initial version ggdavi Initial version Revision 1.49
 * 2005/06/01 20:32:38 ggdavi ggdavi Initial version DATA_EXCHANGE_EVENT status
 * code assertions now use the constants in XmlUserActivity and POSListener
 * ggdavi Initial version ggdavi Initial version Revision 1.48 2005/06/01
 * 18:56:52 ggdavi ggdavi Initial version Refactored for consistency ggdavi
 * Initial version ggdavi Initial version Revision 1.47 2005/06/01 17:17:54
 * ggdavi ggdavi Initial version Added prefix flag to
 * SoapTestCase.buildCIDXHeader; test for 2 event records in DB; cleaned up some
 * naming ggdavi Initial version ggdavi Initial version Revision 1.46 2005/05/31
 * 20:42:48 ggdavi ggdavi Initial version Use SOAP faults instead of a standard
 * error document ggdavi Initial version ggdavi Initial version Revision 1.45
 * 2005/05/31 17:29:09 ajbaldw ggdavi Initial version some xpath changes for the
 * soap faults. ggdavi Initial version ggdavi Initial version Revision 1.44
 * 2005/05/28 00:27:31 ajbaldw ggdavi Initial version not quite working yet...
 * The DocumentValidationHandler has something wrong with it. ggdavi Initial
 * version ggdavi Initial version Revision 1.43 2005/05/26 21:26:33 ajbaldw
 * ggdavi Initial version changed all xpath assertions to assertEquals or the
 * like because of the cidx: prefixes. ggdavi Initial version ggdavi Initial
 * version Revision 1.42 2005/05/25 22:29:29 ggdavi ggdavi Initial version
 * Security failures now result in SOAP faults ggdavi Initial version Revision
 * 1.41 2005/05/25 14:05:21 lsdenny *** empty log message ***
 * 
 * Revision 1.40 2005/05/23 19:29:39 ggdavi Pulled-up DbUnitHelper objects to
 * superclass
 * 
 * Revision 1.39 2005/05/23 17:31:24 lsdenny Added Ship-From Address Info
 * 
 * Revision 1.38 2005/05/18 17:33:23 lsdenny *** empty log message ***
 * 
 * Revision 1.37 2005/05/17 19:36:19 lsdenny Updated with test corrections.
 * Added code that Gareth had added.
 * 
 * Revision 1.36 2005/05/17 16:31:51 ggdavi Extracted ag.util.XmlDateTimeUtil
 * and ag.soa.ErrorDocument from ag.util.Utilities Revision 1.35 2005/05/17
 * 15:24:24 ggdavi Move ag.cf.aop, ag.cf.config, ag.cf.util to ag.aop,
 * ag.config, ag.util
 * 
 * Revision 1.34 2005/05/17 13:49:30 lsdenny *** empty log message ***
 * 
 * Revision 1.33 2005/05/16 23:06:06 ggdavi Added tolerance parameter to
 * DbUnitHelper.isDateColumnValueNearCurrentTime method
 * 
 * Revision 1.31 2005/05/16 20:57:55 lsdenny *** empty log message ***
 * 
 * Revision 1.29 2005/05/16 17:24:36 lsdenny *** empty log message ***
 * 
 * Revision 1.28 2005/05/16 16:33:45 lsdenny *** empty log message ***
 * 
 * Revision 1.27 2005/05/16 16:00:53 lsdenny *** empty log message ***
 * 
 * Revision 1.26 2005/05/13 18:56:32 lsdenny *** empty log message ***
 * 
 * Revision 1.25 2005/05/13 18:32:01 lsdenny Added Error Messages for poorly
 * formed XML message and non-standard XML message. Revision 1.24 2005/05/13
 * 17:43:23 lsdenny *** empty log message *** Revision 1.23 2005/05/13 15:09:11
 * lsdenny *** empty log message *** Revision 1.22 2005/05/12 15:19:35 lsdenny
 * *** empty log message *** Revision 1.21 2005/05/12 13:07:04 lsdenny *** empty
 * log message *** Revision 1.20 2005/05/11 21:13:22 lsdenny Using
 * Assertion.assertEquals() for logTable compare. Revision 1.18 2005/05/11
 * 19:16:50 lsdenny *** empty log message *** Revision 1.17 2005/05/11 18:14:18
 * lsdenny *** empty log message *** Revision 1.16 2005/05/11 15:14:49 lsdenny
 * *** empty log message *** Revision 1.15 2005/05/11 14:56:06 lsdenny *** empty
 * log message *** Revision 1.14 2005/05/11 12:51:33 lsdenny *** empty log
 * message *** Revision 1.13 2005/05/10 20:51:11 lsdenny *** empty log message
 * *** Revision 1.12 2005/05/10 19:48:32 lsdenny Change to use 2 unitHelpers
 * Revision 1.11 2005/05/10 15:19:03 lsdenny Adding ECG db connection Revision
 * 1.10 2005/05/09 21:37:00 lsdenny Added DB Changes Revision 1.9 2005/05/09
 * 20:47:56 lsdenny Added checks for Repository and Event tables Revision 1.8
 * 2005/05/06 17:39:56 ggdavi Made changes so the classes would compile...
 * Revision 1.7 2005/05/06 17:36:31 ggdavi Removed unnecessary objects Revision
 * 1.6 2005/05/06 14:16:30 lsdenny *** empty log message *** Revision 1.5
 * 2005/05/05 21:00:13 lsdenny Changes Revision 1.4 2005/05/05 18:58:12 lsdenny
 * *** empty log message *** Revision 1.3 2005/05/05 18:53:01 lsdenny *** empty
 * log message *** Revision 1.2 2005/05/05 15:00:49 lsdenny *** empty log
 * message *** Revision 1.1 2005/04/27 11:32:35 ggdavi Renamed
 * ag.cf.functionaltest to ag.cf.acceptancetest Revision 1.1 2005/04/21 19:15:22
 * ggdavi Initial version
 */