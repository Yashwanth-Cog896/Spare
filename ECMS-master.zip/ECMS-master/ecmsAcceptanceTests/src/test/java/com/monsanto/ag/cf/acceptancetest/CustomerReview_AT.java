/*
 * CustomerReview_FT was created on Aug 16, 2007 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.acceptancetest;

import org.w3c.dom.Document;

import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.ag.xml.XPathUtil;

/**
 * Test the Customer Review web service.
 * 
 * @author Chetna Aggarwal
 * @version $Id: CustomerReview_AT.java,v 1.1 2007-08-16 19:41:41 caggarw Exp $
 */
public class CustomerReview_AT extends AcceptanceTestCase {

  private static final String SERVICE_URI = "/soap/CustomerReview_1-0";

  public CustomerReview_AT(String name) {
    super(name);
  }

  public void testGetWsdlForJaxRpcCustomerReview() throws Exception {
    assertWsdlServiceUrl(SERVICE_URI);
  }

  public void testJaxRpcCustomerReviewBasicResponse() throws Exception {
    String messageXml = getRequestXmlFromUri("/CustomerReview/CustomerReviewImpl_FT_1.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);
    // DOMUtil.outputXML(response.getDOM());
    assertNotNull("Valid response must be received", response);
    assertEquals("text/xml", response.getContentType());
  }

  public void testJaxRpcCustomerReview() throws Exception {
    String messageXml = getRequestXmlFromUri("/CustomerReview/CustomerReviewImpl_FT_1.xml");
    String wsseSecurityHeader = buildWSSecurityHeader(GOOD_USER_ID, GOOD_USER_PASSWORD, null, null);
    PostMethodWebRequest request = buildSoapRequestWithoutCompression(getServiceUrl(SERVICE_URI), wsseSecurityHeader,
        messageXml);

    WebResponse response = webConversation.getResponse(request);

    Document responseXml = response.getDOM();

    assertNotNull("Valid document must be returned", responseXml);
    // DOMUtil.outputXML(responseXml);
    assertNotNull("Conversation Id must exist", getConversationIdFromResponseDocument(responseXml));

    final String xpathCustomerReviewResponse = "/Envelope/Body/GrowerIDResponse/GrowerIDResponseBody/GrowerIDResponseDetails/TransactionDetails";
    int lineItemCount = XPathUtil.getNodeCount(responseXml, xpathCustomerReviewResponse);
    System.out.println("Number of Customer Review line items retrieved: " + lineItemCount);
    assertFalse("At least one Customer Review line item is expected", 0 == lineItemCount);
  }

}
