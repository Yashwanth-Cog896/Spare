/*
 * ProductList_PT was created on Jun 28, 2005 using Monsanto resources and is
 * the sole property of Monsanto. Any duplication of the code and/or logic is a
 * direct infringement of Monsanto's copyright.
 */
package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.ProductList_AT;

/**
 * Test the performance of the Product List web service.
 * 
 * @author Gareth Davies
 * @version $Id: ProductList_PT.java,v 1.3 2006-08-14 21:14:59 caggarw Exp $
 */
public class ProductList_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for Product List");

    Test productList = new ProductList_AT("testJaxRpcProductListBasicResponse");
    Test timedProductList = new TimedTest(productList,
        MAX_RESPONSE_TIME_LIGHTWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedProductList);

    return suite;
  }

}

/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2005/07/11 21:40:57  ggdavi
 * Corrected text
 *
 * Revision 1.1  2005/06/28 17:53:33  ggdavi
 * Initial version
 *
 */