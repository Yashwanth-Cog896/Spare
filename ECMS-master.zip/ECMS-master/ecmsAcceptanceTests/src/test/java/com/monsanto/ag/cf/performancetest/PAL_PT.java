package com.monsanto.ag.cf.performancetest;

import junit.framework.Test;
import junit.framework.TestSuite;

import com.clarkware.junitperf.TimedTest;
import com.monsanto.ag.cf.acceptancetest.PAL_AT;

public class PAL_PT extends PerformanceTestCase {

  public static Test suite() {
    TestSuite suite = new TestSuite("Performance tests for PAL");

    Test PALList = new PAL_AT("testJaxRpcPALBasicResponse");
    Test timedPALList = new TimedTest(PALList,
        MAX_RESPONSE_TIME_HEAVYWEIGHT_SERVICE);

    setUserLoadAndAddToSuite(suite, timedPALList);

    return suite;
  }

}


/*
 * $Log: not supported by cvs2svn $
 * Revision 1.2  2006/08/14 21:14:59  caggarw
 * renamed Acceptance Tests (AT) to Functional Tests (FT)
 *
 * Revision 1.1  2005/07/27 18:24:51  ggdavi
 * Initial version
 *
 */