insert into special_instruction_type (special_instruction_type_code, descr, row_task_id)
values ('REFRSH','Send Full Refresh','Initial Population');

commit;
