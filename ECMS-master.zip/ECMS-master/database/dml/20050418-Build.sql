insert into user_status (user_status_code, descr, row_task_id)
values ('A','Active','Initial Population');

insert into user_status (user_status_code, descr, row_task_id)
values ('I','Inactive','Initial Population');

insert into user_status (user_status_code, descr, row_task_id)
values ('PE','Pending','Initial Population');

insert into user_status (user_status_code, descr, row_task_id)
values ('PR','Prospect','Initial Population');

insert into user_status (user_status_code, descr, row_task_id)
values ('D','Denied','Initial Population');

commit;

insert into software_version (software_version_id, descr, seed_year, date_deployed, row_task_id)
values ('09.10.03','Main Release 2004','2004',to_date('09/10/2003','mm/dd/yyyy'),'Initial Population');

insert into software_version (software_version_id, descr, seed_year, date_deployed, row_task_id)
values ('03.12.04','Maintenance Release 2004','2004',to_date('03/12/2004','mm/dd/yyyy'),'Initial Population');

insert into software_version (software_version_id, descr, seed_year, date_deployed, row_task_id)
values ('09.28.04','Main Release 2005','2005',to_date('09/28/2004','mm/dd/yyyy'),'Initial Population');

insert into software_version (software_version_id, descr, seed_year, date_deployed, row_task_id)
values ('03.23.05','Maintenance Release 2005','2005',to_date('03/12/2005','mm/dd/yyyy'),'Initial Population');

commit;

insert into connection_type (descr, sort_order, row_task_id)
values ('28.8k modem',1,'Initial Population');

insert into connection_type (descr, sort_order, row_task_id)
values ('56k modem',2,'Initial Population');

insert into connection_type (descr, sort_order, row_task_id)
values ('DSL/Cable',3,'Initial Population');

insert into connection_type (descr, sort_order, row_task_id)
values ('T1 or Higher',4,'Initial Population');

insert into connection_type (descr, sort_order, row_task_id)
values ('ISDN',5,'Initial Population');

insert into connection_type (descr, sort_order, row_task_id)
values ('Other Broadband',6,'Initial Population');

insert into connection_type (descr, sort_order, row_task_id)
values ('Other',7,'Initial Population');

commit;

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Windows 98',1,'Initial Population');

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Windows NT 4.0',2,'Initial Population');

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Windows ME',3,'Initial Population');

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Windows 2000',4,'Initial Population');

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Windows XP Home',5,'Initial Population');

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Windows XP Pro',6,'Initial Population');

insert into operating_system_type (descr, sort_order, row_task_id)
values ('Other',7,'Initial Population');

commit;

insert into ms_office_version (descr, sort_order, row_task_id)
values ('MS Office 95',1,'Initial Population');

insert into ms_office_version (descr, sort_order, row_task_id)
values ('MS Office 97',2,'Initial Population');

insert into ms_office_version (descr, sort_order, row_task_id)
values ('MS Office 2000',3,'Initial Population');

insert into ms_office_version (descr, sort_order, row_task_id)
values ('MS Office 2003',4,'Initial Population');

insert into ms_office_version (descr, sort_order, row_task_id)
values ('MS Office XP',5,'Initial Population');

insert into ms_office_version (descr, sort_order, row_task_id)
values ('Other',6,'Initial Population');

commit;
