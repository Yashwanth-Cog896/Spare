insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('SNP','Ship Notice (EDN) Publication','Initial Population',user,sysdate,sysdate)
;

commit
;
