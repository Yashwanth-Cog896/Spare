insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('GPOS','GPOS Reporting','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('PPOS','PPOS Reporting','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('FPOS','FPOS Reporting','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('COS','Customer Order Summary','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('EDN','Electronic Delivery Notification','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('FM','Farm Manager List','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('PROD','Product List','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('PRICE','Price List','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('ECHO','EchoTest','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('PREF','Dealer Preferences','Initial Population',user,sysdate,sysdate)
;

insert into data_exchange_type (data_exchange_type_code,descr,row_task_id,row_user_id,row_entry_date,row_modify_date)
values ('BM','Broadcast Message','Initial Population',user,sysdate,sysdate)
;

commit
;
