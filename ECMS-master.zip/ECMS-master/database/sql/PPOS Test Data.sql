select th.tran_id, th.prod_transfer_code, th.order_type, th.rptd_doc_nbr, th.rptd_doc_date,
th.ship_date, td.rptd_line_qual, td.rptd_line_value, td.rptd_qty_qual, td.rptd_qty, td.rptd_uom,
td.ssu_qty, spl.conversion_factor, td.ssu_qty/td.rptd_qty reporting_factor, spl.edi_rpt_ind_code, spl.brand_name, spl.product_class_id, spl.description_text,
tp2.party_code, tp2.cust_type, tp2.rptd_name, tp2.rptd_id_qual, tp2.rptd_id_value, tp2.contact_name, tp2.contact_phone,
tp2.rptd_addr1, tp2.rptd_city, tp2.rptd_state, tp2.rptd_zip,
th.rptd_doc_date, tp1.party_code, tp1.rptd_name, tp1.rptd_id_qual, tp1.rptd_id_value
from ecg.tracking_source ts, ecg.tran_header th, ecg.tran_party tp1,
    ecg.tran_party tp2, ecg.tran_detail td, ecg.seedtrak_product_list spl
where ts.source ='CMISEED' and ts.tracking_code='BK'
and th.rpt_type='PP'
and th.tracking_id=ts.tracking_id
and th.tran_id=td.tran_id
and tp1.tran_id=th.tran_id
and tp1.party_code='DS'
and tp1.acct_id=2160
and tp2.tran_id=th.tran_id
and tp2.party_code='ST'
and td.rds_prod_id =spl.prod_code
and td.rptd_uom=spl.rr_uom_code
and td.product_sales_year>=2004
order by td.product_sales_year desc,spl.edi_rpt_ind_code,spl.description_text

select * from ecg.tracking_source
where source ='CMISEED' and tracking_code='SI'

select distinct tracking_code from ecg.tracking_source
where source ='CMISEED'
-- SI = GPOS
-- BK = PPOS
-- FP = FPOS

select * from ecg.tracking_source ts, ecg.tran_header th, ecg.tran_party tp, ecg.tran_detail td
where ts.source ='CMISEED' and ts.tracking_code='BK'
and th.tracking_id=ts.tracking_id
and th.tran_id=td.tran_id
and th.tran_id=tp.tran_id
and tp.party_code='DS'
and tp.acct_id=2160
and th.rptd_doc_nbr='01416-0010'

select * from ecg.tran_party where tran_id='775604608'

select * from ecg.tran_header
select * from ecg.tran_detail
select * from ecg.tran_party
select distinct rptd_id_qual from ecg.tran_party

select * from ecg.seedtrak_product_list
where prod_code='64960'
