CREATE TABLE ActiveMQ_Msgs (
       ID                   NUMBER NOT NULL,
       Container            VARCHAR2(250) NULL,
       MsgID                VARCHAR2(250) NULL,
       Msg                  BLOB NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE ActiveMQ_Msgs
       ADD  constraint ActiveMQ_Msgs_PK PRIMARY KEY (ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX ActiveMQ_Msgs_IDX1 ON ActiveMQ_Msgs
(
       Container            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX ActiveMQ_Msgs_IDX2 ON ActiveMQ_Msgs
(
       MsgID            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON ActiveMQ_Msgs TO ecom_role,seedtrak
/

drop sequence Message_Queue_Seq;
      
drop TABLE Message_Queue;
