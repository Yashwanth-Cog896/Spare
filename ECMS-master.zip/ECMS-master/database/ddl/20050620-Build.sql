create or replace view price_zone_geography_vw
as
select f.fips_code,
	   f.state_code,
	   f.county_descr,
	   sap.region_def_code sap_region_code,
	   sap_d.descr sap_region_descr,
	   azr.region_def_code azr_region_code,
	   azr_d.descr azr_region_descr,
	   sap.region_def_code||azr.region_def_code price_region,
	   sap_d.descr||' '||azr_d.descr price_region_descr
  from agcc.fips_mv f,
  	   agcc.fips_to_region_def_mv azr,
	   agcc.fips_to_region_def_mv sap,
	   agcc.region_def_mv azr_d,
	   agcc.region_def_mv sap_d
 where f.fips_code=azr.fips_code
   and azr.region_struct_code='AZR1'
   and f.fips_code=sap.fips_code
   and sap.region_struct_code='SPR1'
   and azr.region_def_code=azr_d.region_def_code
   and azr.region_struct_code=azr_d.region_struct_code
   and sap.region_def_code=sap_d.region_def_code
   and sap.region_struct_code=sap_d.region_struct_code
/

grant select on price_zone_geography_vw to ecom_role, seedtrak, agcc_iis, developer
/

create or replace view seed_product_price_vw
as
select b.rds_product_id,
	   b.region_def_code||d.region_def_code price_region,
	   p.upc_code,
	   b.region_def_code base_region_code,
	   d.region_def_code zone_discount_region,
	   b.rate base_rate,
	   d.zone_discount_rate,
	   b.rate+d.zone_discount_rate net_rate,
	   b.uom_id,
	   b.eff_start_date_sd,
	   b.eff_end_date_sd,
	   b.eff_start_date_tf,
	   b.eff_end_date_tf,
	   d.eff_start_date eff_start_date_zd,
	   d.eff_end_date eff_end_date_zd,
	   greatest(b.row_modify_date,d.row_modify_date) row_modify_date,
	   b.active_flag
 from  agcc.seed_base_price_mv b,
 	   agcc.seed_zone_discount_price_mv d,
	   agcc.prod p
where b.rds_product_id=d.rds_product_id
and p.prod_code=b.rds_product_id
union
select b.rds_product_id,
	   b.region_def_code||r.azr_region_code price_region,
	   p.upc_code,
	   b.region_def_code base_region_code,
	   r.azr_region_code zone_discount_region,
	   b.rate base_rate,
	   0,
	   b.rate net_rate,
	   b.uom_id,
	   b.eff_start_date_sd,
	   b.eff_end_date_sd,
	   b.eff_start_date_tf,
	   b.eff_end_date_tf,
	   null,
	   null,
	   b.row_modify_date,
	   b.active_flag
 from  agcc.seed_base_price_mv b,
 	   agcc.seed_zone_discount_price_mv d,
	   agcc.prod p,
	   (select price_region,sap_region_code,azr_region_code from price_zone_geography_vw
			group by price_region,sap_region_code,azr_region_code) r
where b.rds_product_id=d.rds_product_id(+)
and p.prod_code=b.rds_product_id
and d.region_def_code is null
and r.sap_region_code=b.region_def_code
/

grant select on seed_product_price_vw to ecom_role, seedtrak, agcc_iis, developer
/

create or replace view acct_to_stt_vw
as
select eta.acct_id,
	   eta.emp_id stt_emp_id,
	   e.empfirst stt_first_name,
	   e.emplast stt_last_name,
	   e.phone_business stt_phone,
	   e.email_address st_email
 from agcc.emp_to_acct_mv eta,
	  agcc.emp e
where eta.emp_to_acct_type_code = 'STT'
  and eta.emp_id = e.empnum
union
select aed.acct_id,
	   eto.emp_id,
	   e.empfirst,
	   e.emplast,
	   e.phone_business,
	   e.email_address
 from agcc.acct_ext_dnml aed,
 	  agcc.zip_code_mv zc,
	  agcc.fips_to_region_def_mv ftr,
	  agcc.emp_to_org eto,
	  agcc.emp e,
	  agcc.ird_parameter p,
	  agcc.emp_to_acct_mv eta
where aed.mailing_zip = zc.zip_code
  and zc.fips_code = ftr.fips_code
  and ftr.region_struct_code = 'STT'
  and eto.org_code = ftr.region_def_code
  and eto.org_struct_code = p.character_value
  and p.ird_parameter_code = 'ORG_STRUCTURE'
  and eto.emp_relation_code = 'A'
  and eto.emp_id = e.empnum
  and e.emporgcode = p.character_value
  and eta.acct_id(+) = aed.acct_id
  and eta.emp_id is null
/

grant select on acct_to_stt_vw to ecom_role, seedtrak, agcc_iis, developer
/

