CREATE TABLE SEEDTRAK_PRODUCT_LIST
(
  LEGAL_DESCR_1               VARCHAR2(60 BYTE),
  LEGAL_DESCR_2               VARCHAR2(40 BYTE),  
  ST_UOM_CODE                 VARCHAR2(2 BYTE),
  PRODUCT_CLASS_ID            VARCHAR2(1 BYTE),
  BASE_UOM                    VARCHAR2(2 BYTE),
  PROD_UNIT_CONV              NUMBER,
  GTIN                        VARCHAR2(14 BYTE),
  SPECIES_DESCR               VARCHAR2(35 BYTE),
  USE_SSU                     VARCHAR2(1 BYTE),
  DISPLAY_DESCR               VARCHAR2(35 BYTE),
  SEEDTRAK_FILE_FLAG          VARCHAR2(1 BYTE),
  MKT_SEG_CODE                VARCHAR2(2 BYTE),
  UPDATE_DATE                 DATE,
  PROD_ACTIVE_FLAG            VARCHAR2(1 BYTE),  
  SEED_COMPANY_BRAND_NAME     VARCHAR2(35 BYTE)
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )           
;
/
grant select on SEEDTRAK_PRODUCT_LIST to ecom_role, seedtrak;
/
CREATE SYNONYM CAGGARW.ECG_SEEDTRAK_PRODUCT_LIST FOR CAGGARW.SEEDTRAK_PRODUCT_LIST;
/
