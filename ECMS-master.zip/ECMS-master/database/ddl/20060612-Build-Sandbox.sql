ALTER TABLE seed_product_price_vw
    ADD    (RRA_RATE_SD  NUMBER NULL,
    RRA_RATE_TF NUMBER NULL );
