ALTER TABLE data_exchange_repository
    ADD    (  root_node_name VARCHAR2(120));
