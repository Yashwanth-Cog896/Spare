ALTER TABLE acct_to_price_zone
    ADD    (  full_refresh_flag VARCHAR2(1) default 'Y');
