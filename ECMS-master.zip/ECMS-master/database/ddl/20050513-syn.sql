CREATE SYNONYM ecom_app.special_instruction_type
           FOR ecom.special_instruction_type
/

CREATE SYNONYM ecom_app.special_instruction
           FOR ecom.special_instruction
/
