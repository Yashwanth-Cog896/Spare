
-- Start of DDL script for DATA_EXCHANGE_LOG_SEQ
-- Generated 5-Apr-05  3:52:36 pm
-- from fs_devl-ECOM_APP:1

-- Synonym DATA_EXCHANGE_LOG_SEQ

CREATE SYNONYM ecom_app.data_exchange_log_seq
           FOR ecom.data_exchange_log_seq
/

-- End of DDL script for DATA_EXCHANGE_LOG_SEQ

-- Start of DDL script for DATA_EXCHANGE_LOG
-- Generated 5-Apr-05  3:52:36 pm
-- from fs_devl-ECOM_APP:1

-- Synonym DATA_EXCHANGE_LOG

CREATE SYNONYM ecom_app.data_exchange_log
           FOR ecom.data_exchange_log
/

-- End of DDL script for DATA_EXCHANGE_LOG

-- Start of DDL script for DATA_EXCHANGE_TYPE
-- Generated 5-Apr-05  3:52:36 pm
-- from fs_devl-ECOM_APP:1

-- Synonym DATA_EXCHANGE_TYPE

CREATE SYNONYM ecom_app.data_exchange_type
           FOR ecom.data_exchange_type
/

-- End of DDL script for DATA_EXCHANGE_TYPE

-- Start of DDL script for SEEDTRAK_USER
-- Generated 5-Apr-05  3:52:36 pm
-- from fs_devl-ECOM_APP:1

-- Synonym SEEDTRAK_USER

CREATE SYNONYM ecom_app.seedtrak_user
           FOR ecom.seedtrak_user
/

-- End of DDL script for SEEDTRAK_USER

-- Start of DDL script for SOFTWARE_VERSION
-- Generated 5-Apr-05  3:52:36 pm
-- from fs_devl-ECOM_APP:1

-- Synonym SOFTWARE_VERSION

CREATE SYNONYM ecom_app.software_version
           FOR ecom.software_version
/

-- End of DDL script for SOFTWARE_VERSION
