drop view price_zone_geography_vw;
drop view seed_product_price_vw;
drop view acct_to_stt_vw;