drop table ENTITY_INQUIRY_VW
/
