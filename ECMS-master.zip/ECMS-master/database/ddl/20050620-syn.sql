CREATE SYNONYM ecom_app.price_zone_geography_vw
           FOR ecom.price_zone_geography_vw
/

CREATE SYNONYM ecom_app.seed_product_price_vw
           FOR ecom.seed_product_price_vw
/

CREATE SYNONYM ecom_app.acct_to_stt_vw
           FOR ecom.acct_to_stt_vw
/

