CREATE INDEX Data_Exchange_Log_IDX4 ON Data_Exchange_Log
(
       Acct_ID                        ASC,
       Data_Exchange_Type_Code        ASC,
       Seed_Year                      ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;
