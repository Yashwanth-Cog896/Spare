drop view st_sales_grp_vw
/

drop view st_terr_vw
/

ALTER TABLE SEEDTRAK_USER
    rename column GPOS_Exchange_Flag to POS_Exchange_Flag;

ALTER TABLE SEEDTRAK_USER
    drop (PPOS_Exchange_Flag, FPOS_Exchange_Flag, GPOS_Refresh_Flag, PPOS_Refresh_Flag);
