drop table SEED_PRODUCT_PRICE_VW
/
drop table ACCT_TO_PRICE_ZONE
/