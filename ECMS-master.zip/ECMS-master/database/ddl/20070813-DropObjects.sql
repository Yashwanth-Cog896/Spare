drop table GROWER_INQUIRY_VW
/
