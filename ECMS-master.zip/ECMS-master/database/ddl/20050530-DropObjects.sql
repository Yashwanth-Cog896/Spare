/* for devl, test, prod
drop view farm_manager_list_vw
/
*/

drop table farm_manager_list_vw
/
