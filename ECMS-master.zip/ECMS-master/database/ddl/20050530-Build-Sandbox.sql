drop view farm_manager_list_vw
/

create table farm_manager_list_vw
(       active_flag varchar2(1),
        short_name varchar2(30),
        sap_id varchar2(10),
        addr_line_1 varchar2(40),
        city varchar2(40),
        state_code varchar2(2),
        zip varchar2(10),
        acct_id varchar2(12),
        row_modify_date date,
        acct_role_code varchar2(2)
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

grant select on farm_manager_list_vw to ecom_role, seedtrak
/
