CREATE TABLE USER_XREF
(
  SOFTWARE_ID                   VARCHAR2(8 BYTE),
  ACCT_ID                       NUMBER,
  DEVICE_ACTIVE_FLAG            VARCHAR2(1 BYTE)
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )           
;

/
grant select on USER_XREF to ecom_role, seedtrak;
/
ALTER TABLE SEEDTRAK_USER
      ADD HAND_HELD_FLAG VARCHAR2(1 BYTE) DEFAULT 'N'
      ;
      
ALTER TABLE SOFTWARE_VERSION
      ADD SOURCE_NAME VARCHAR2(10 BYTE)
      ;
