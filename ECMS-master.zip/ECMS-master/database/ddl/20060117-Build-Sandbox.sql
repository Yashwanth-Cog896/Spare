ALTER TABLE ship_notice_publication
    ADD    (  delivery_id VARCHAR2(10) NULL);