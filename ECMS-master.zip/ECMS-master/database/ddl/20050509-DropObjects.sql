drop table activemq_msgs;
drop table data_exchange_event;
drop sequence data_exchange_event_seq;

alter table data_exchange_log
add (Error_Code VARCHAR2(50) NULL,
     Error_Msg  VARCHAR2(255) NULL,
     Date_Processed       DATE NULL);

alter table data_exchange_repository
drop column xml_msg
/

alter table data_exchange_repository
add (xml_msg xmltype)
/
