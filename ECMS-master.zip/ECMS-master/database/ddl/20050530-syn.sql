CREATE SYNONYM ecom_app.farm_manager_list_vw
           FOR ecom.farm_manager_list_vw
/
