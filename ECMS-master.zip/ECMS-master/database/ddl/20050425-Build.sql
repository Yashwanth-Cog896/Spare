ALTER TABLE DATA_EXCHANGE_LOG
ADD (Error_Code VARCHAR2(50) NULL,
     Error_Msg  VARCHAR2(255) NULL);

delete from data_exchange_log;
commit;

ALTER TABLE DATA_EXCHANGE_LOG
ADD (Conversation_ID      VARCHAR2(255) NOT NULL,
       Date_Processed       DATE NULL);

CREATE UNIQUE INDEX Data_Exchange_Log_IDX3 ON Data_Exchange_Log
(
       Conversation_ID                ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

