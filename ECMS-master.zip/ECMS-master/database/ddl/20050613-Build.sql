create or replace view terr_vw
as
select
	oh_terr.org_code terr_id,
    oh_terr.descr terr_descr,
    oh_team.org_code team_id,
    oh_team.descr team_descr,
    oh_regn.org_code region_id,
    oh_regn.descr region_descr,
	e.empnum salesrep_emp_id,
	e.empfirst salesrep_first_name,
	e.emplast salesrep_last_name
from
	agcc.ird_parameter ip,
    agcc.org_hrchy_mv_vw oh_terr,
    agcc.org_hrchy_mv_vw oh_team,
    agcc.org_hrchy_mv_vw oh_regn,
    agcc.org_level_hrchy_mv_vw olh_team,
    agcc.org_level_hrchy_mv_vw olh_regn,
	agcc.emp e,
	agcc.emp_to_org eto
where
  ip.ird_parameter_code = 'ORG_STRUCTURE'
  and oh_terr.org_struct_code = ip.character_value
  and substr(oh_terr.org_hrchy_id,1,olh_team.org_level_total) = oh_team.org_hrchy_id
  and oh_team.org_struct_code = ip.character_value
  and substr(oh_terr.org_hrchy_id,1,olh_regn.org_level_total) = oh_regn.org_hrchy_id
  and oh_regn.org_struct_code = ip.character_value
  and olh_team.org_level_code = 'TEAM'
  and olh_team.org_struct_code = ip.character_value
  and olh_regn.org_level_code = 'REGN'
  and olh_regn.org_struct_code = ip.character_value
  and eto.org_code = oh_terr.org_code
  and eto.org_struct_code = ip.character_value
  and eto.emp_relation_code = 'A'
  and e.empnum = eto.emp_id
  and e.emporgcode = ip.character_value
/

grant select on terr_vw to ecom_role, seedtrak, agcc_iis, developer
/

alter table seedtrak_user
drop column stt_id
/

