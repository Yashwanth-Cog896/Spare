drop table DATA_EXCHANGE_TYPE;
drop table DATA_EXCHANGE_LOG;
drop table SEEDTRAK_USER;
drop table SOFTWARE_VERSION;
