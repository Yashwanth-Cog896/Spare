create table ENTITY_INQUIRY_VW
(       purchaser_acct_id number,
        acct_name varchar2(80),
        contact_id number,
        mailing_state_code varchar2(2),
        azr_descr varchar2(100),
        zone_descr varchar2(100),
        zone_code varchar2(20),
        zone_year varchar2(8),
        license_status varchar2(22),
        st_license_status varchar2(22),
        primary_contact_last_name varchar2(40),
        primary_contact_first_name varchar2(40),
        mailing_addr_line_1 varchar2(40),
        mailing_city varchar2(40),
        mailing_zip varchar2(5),
        county_descr varchar2(25),
        contact_phone_number varchar2(16),
        contact_last_name varchar2(40),
        contact_first_name varchar2(40),
        sap_id number,
        napd_id varchar2(20),
        gln_id varchar2(20),
        acct_status number,
        fflx_code varchar2(4),
        fflx_dlr number  
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

grant select on ENTITY_INQUIRY_VW to ecom_role, seedtrak
/