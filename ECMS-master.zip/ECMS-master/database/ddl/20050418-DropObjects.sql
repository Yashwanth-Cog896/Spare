delete from User_Status;
delete from Software_Version;
delete from MS_Office_Version;
delete from Operating_System_Type;
delete from Connection_Type;

commit;

alter table MS_Office_Version
drop (Sort_Order);

alter table Operating_System_Type
drop (Sort_Order);

alter table Connection_Type
drop (Sort_Order);

drop trigger MS_Office_Version_ins1;
drop trigger Operating_System_Type_ins1;
drop trigger Connection_Type_ins1;

drop sequence MS_Office_Version_Seq;
drop sequence Operating_System_Type_Seq;
drop sequence Connection_Type_Seq;

alter table SEEDTRAK_USER
drop (Contact_Email);

