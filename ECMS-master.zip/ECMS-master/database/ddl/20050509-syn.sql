create synonym ecom_app.ActiveMQ_Msgs for ecom.ActiveMQ_Msgs
/

create synonym ecom_app.Data_Exchange_Event for ecom.Data_Exchange_Event
/

create synonym ecom_app.Data_Exchange_Event_Seq for ecom.Data_Exchange_Event_Seq
/
