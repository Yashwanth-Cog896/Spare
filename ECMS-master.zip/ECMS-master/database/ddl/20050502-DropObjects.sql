drop table data_exchange_repository;

alter table seedtrak_user
add (exchange_software_version_id varchar2(8),
     first_connect_date date,
     last_connect_date date );

ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK2
 FOREIGN KEY
 (EXCHANGE_SOFTWARE_VERSION_ID
 )
 REFERENCES SOFTWARE_VERSION
  (SOFTWARE_VERSION_ID
 )
/

CREATE INDEX SeedTrak_User_IDX3 ON SeedTrak_User
(
       Exchange_Software_Version_ID   ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

