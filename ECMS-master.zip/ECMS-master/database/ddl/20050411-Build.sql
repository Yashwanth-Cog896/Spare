alter table data_exchange_log
add (acct_id number)
;

CREATE INDEX Data_Exchange_Log_IDX1 ON Data_Exchange_Log
(
       Software_Version_ID            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX Data_Exchange_Log_IDX2 ON Data_Exchange_Log
(
       DATA_EXCHANGE_TYPE_CODE        ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


create sequence Seedtrak_User_Seq
;

ALTER TABLE SEEDTRAK_USER DROP PRIMARY KEY;

ALTER TABLE SEEDTRAK_USER DROP column user_id;

ALTER TABLE SEEDTRAK_USER
add (seedtrak_id number not null,
     acct_id number not null)
;

ALTER TABLE SeedTrak_User
       ADD constraint SeedTrak_User_PK PRIMARY KEY (seedtrak_id)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


ALTER TABLE DATA_EXCHANGE_LOG MODIFY (ACCT_ID NOT NULL);
ALTER TABLE DATA_EXCHANGE_LOG MODIFY (DATA_EXCHANGE_START_DATE NOT NULL);
ALTER TABLE DATA_EXCHANGE_LOG MODIFY (SOFTWARE_VERSION_ID NULL);
ALTER TABLE DATA_EXCHANGE_TYPE MODIFY (DESCR NOT NULL);
ALTER TABLE SOFTWARE_VERSION MODIFY (DESCR NOT NULL);
ALTER TABLE SOFTWARE_VERSION MODIFY (SEED_YEAR NOT NULL);
ALTER TABLE SOFTWARE_VERSION MODIFY (DATE_DEPLOYED NOT NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (DOWNLOAD_SOFTWARE_VERSION_ID NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (EXCHANGE_SOFTWARE_VERSION_ID NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (CD_DELIVERY_FLAG NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (CD_SOFTWARE_VERSION_ID NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (OPERATING_SYSTEM_TYPE_ID NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (CONNECTION_TYPE_ID NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (MS_OFFICE_FLAG NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (DEALER_PROSPECT_FLAG NULL);
ALTER TABLE SEEDTRAK_USER MODIFY (POS_EXCHANGE_FLAG DEFAULT 'Y');
ALTER TABLE SEEDTRAK_USER MODIFY (UPLOAD_FILE_FLAG DEFAULT 'N');

alter table SeedTrak_User drop (Business_Phone, Home_Phone, Mobile_Phone, Fax_Phone,
CD_Address, CD_City, CD_State_Code, CD_Zip, CD_Zip4);

CREATE UNIQUE INDEX SeedTrak_User_IDX1 ON SeedTrak_User
(
       Acct_ID                        ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX2 ON SeedTrak_User
(
       Download_Software_Version_ID   ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX3 ON SeedTrak_User
(
       Exchange_Software_Version_ID   ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX4 ON SeedTrak_User
(
       CD_Software_Version_ID         ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX5 ON SeedTrak_User
(
       User_Status_Code               ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX6 ON SeedTrak_User
(
       Operating_System_Type_ID       ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX7 ON SeedTrak_User
(
       Connection_Type_ID             ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX SeedTrak_User_IDX8 ON SeedTrak_User
(
       MS_Office_Version_ID           ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;




-- Trigger SEEDTRAK_USER_INS1

CREATE OR REPLACE TRIGGER seedtrak_user_ins1
BEFORE INSERT
ON seedtrak_user
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select seedtrak_user_seq.nextval into :new.seedtrak_id from dual;

End;
/


      /*
      ACTION is CREATE Table Connection_Type
      */

CREATE TABLE Connection_Type (
       Connection_Type_ID   NUMBER NOT NULL,
       Descr                VARCHAR2(35) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON Connection_Type TO ecom_role,seedtrak
/

ALTER TABLE Connection_Type
       ADD constraint Connection_Type_PK PRIMARY KEY (Connection_Type_ID)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


      /*
      ACTION is CREATE Table MS_Office_Version
      */

CREATE TABLE MS_Office_Version (
       MS_Office_Version_ID NUMBER NOT NULL,
       Descr                VARCHAR2(35) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON MS_Office_Version TO ecom_role,seedtrak
/

ALTER TABLE MS_Office_Version
       ADD constraint MS_Office_Version_PK PRIMARY KEY (MS_Office_Version_ID)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


      /*
      ACTION is CREATE Table Operating_System_Type
      */

CREATE TABLE Operating_System_Type (
       Operating_System_Type_ID NUMBER NOT NULL,
       Descr                VARCHAR2(35) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON Operating_System_Type TO ecom_role,seedtrak
/

ALTER TABLE Operating_System_Type
       ADD constraint Operating_System_Type_PK PRIMARY KEY (Operating_System_Type_ID)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


      /*
      ACTION is CREATE Table User_Status
      */

CREATE TABLE User_Status (
       User_Status_Code     VARCHAR2(2) NOT NULL,
       Descr                VARCHAR2(35) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON User_Status TO ecom_role,seedtrak
/

ALTER TABLE User_Status
       ADD constraint User_Status_PK PRIMARY KEY (User_Status_Code)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK4
 FOREIGN KEY
 (Operating_System_Type_ID
 )
 REFERENCES Operating_System_Type
  (Operating_System_Type_ID
 )
/

ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK5
 FOREIGN KEY
 (User_Status_Code
 )
 REFERENCES User_Status
  (User_Status_Code
 )
/

ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK6
 FOREIGN KEY
 (MS_Office_Version_ID
 )
 REFERENCES MS_Office_Version
  (MS_Office_Version_ID
 )
/

ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK7
 FOREIGN KEY
 (Connection_Type_ID
 )
 REFERENCES Connection_Type
  (Connection_Type_ID
 )
/

ALTER TABLE Data_Exchange_Log
 ADD CONSTRAINT Data_Exchange_Log_FK2
 FOREIGN KEY
 (DATA_EXCHANGE_TYPE_CODE
 )
 REFERENCES Data_Exchange_Type
  (DATA_EXCHANGE_TYPE_CODE
 )
/


CREATE OR REPLACE TRIGGER Conection_Type_Audit
  BEFORE INSERT or UPDATE
  on Connection_Type

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER MS_Office_Version_Audit
  BEFORE INSERT or UPDATE
  on MS_Office_Version

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER Operating_System_Type_Audit
  BEFORE INSERT or UPDATE
  on Operating_System_Type

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER User_Status_Audit
  BEFORE INSERT or UPDATE
  on User_Status

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/
