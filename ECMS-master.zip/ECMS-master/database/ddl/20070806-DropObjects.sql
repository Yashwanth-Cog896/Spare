drop table RR_GROWERS
/
