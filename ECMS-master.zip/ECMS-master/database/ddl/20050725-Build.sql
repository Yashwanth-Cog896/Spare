
ALTER TABLE  DATA_EXCHANGE_REPOSITORY ADD  Xml_Msg1 BLOB
/

ALTER TABLE  DATA_EXCHANGE_REPOSITORY DROP COLUMN Xml_Msg
/

ALTER TABLE  DATA_EXCHANGE_REPOSITORY  RENAME COLUMN Xml_Msg1 TO Xml_Msg
/

CREATE TABLE Ship_Notice_Publication (
       Ship_Notice_Pub_ID   NUMBER NOT NULL,
       Acct_ID              NUMBER NOT NULL,
       Conversation_ID      VARCHAR2(255) NOT NULL,
       Consumption_Flag     VARCHAR2(1) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

ALTER TABLE Ship_Notice_Publication
       ADD  constraint Ship_Notice_Publication_PK PRIMARY KEY (Ship_Notice_Pub_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

CREATE INDEX Ship_Notice_Publication_IDX1 ON Ship_Notice_Publication
(
       Acct_ID                     ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

create trigger Ship_Notice_Publication_Audit
  BEFORE INSERT or UPDATE
  on Ship_Notice_Publication

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

GRANT DELETE,INSERT,SELECT,UPDATE ON Ship_Notice_Publication TO ecom_role,seedtrak
/

create sequence Ship_Notice_Publication_Seq
;

GRANT SELECT ON Ship_Notice_Publication_Seq TO ecom_role,seedtrak
/

