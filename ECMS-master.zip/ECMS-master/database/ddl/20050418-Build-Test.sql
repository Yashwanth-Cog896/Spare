
-- Start of DDL script for CONNECTION_TYPE_SEQ
-- Generated 19-Apr-05  7:40:22 am
-- from fs_devl-ECOM:2

-- Sequence CONNECTION_TYPE_SEQ
-- Please Note: The 'Start With' value is taken directly
-- from the 'Last Value' field

CREATE SEQUENCE connection_type_seq
/

-- End of DDL script for CONNECTION_TYPE_SEQ

-- Start of DDL script for DATA_EXCHANGE_LOG_SEQ
-- Generated 19-Apr-05  7:40:22 am
-- from fs_devl-ECOM:2

-- Sequence DATA_EXCHANGE_LOG_SEQ
-- Please Note: The 'Start With' value is taken directly
-- from the 'Last Value' field

CREATE SEQUENCE data_exchange_log_seq
/

GRANT SELECT ON data_exchange_log_seq TO ecom_role
/
GRANT SELECT ON data_exchange_log_seq TO seedtrak
/

-- End of DDL script for DATA_EXCHANGE_LOG_SEQ

-- Start of DDL script for MS_OFFICE_VERSION_SEQ
-- Generated 19-Apr-05  7:40:22 am
-- from fs_devl-ECOM:2

-- Sequence MS_OFFICE_VERSION_SEQ
-- Please Note: The 'Start With' value is taken directly
-- from the 'Last Value' field

CREATE SEQUENCE ms_office_version_seq
/

-- End of DDL script for MS_OFFICE_VERSION_SEQ

-- Start of DDL script for OPERATING_SYSTEM_TYPE_SEQ
-- Generated 19-Apr-05  7:40:22 am
-- from fs_devl-ECOM:2

-- Sequence OPERATING_SYSTEM_TYPE_SEQ
-- Please Note: The 'Start With' value is taken directly
-- from the 'Last Value' field

CREATE SEQUENCE operating_system_type_seq
/

-- End of DDL script for OPERATING_SYSTEM_TYPE_SEQ

-- Start of DDL script for SEEDTRAK_USER_SEQ
-- Generated 19-Apr-05  7:40:22 am
-- from fs_devl-ECOM:2

-- Sequence SEEDTRAK_USER_SEQ
-- Please Note: The 'Start With' value is taken directly
-- from the 'Last Value' field

CREATE SEQUENCE seedtrak_user_seq
/

-- End of DDL script for SEEDTRAK_USER_SEQ

-- Start of DDL script for CONNECTION_TYPE
-- Generated 19-Apr-05  7:40:51 am
-- from fs_devl-ECOM:2

-- Table CONNECTION_TYPE

CREATE TABLE connection_type
 (
  connection_type_id         NUMBER NOT NULL,
  descr                      VARCHAR2(35) NOT NULL,
  sort_order                 NUMBER NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for CONNECTION_TYPE

GRANT DELETE,INSERT,SELECT,UPDATE ON connection_type TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON connection_type TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON connection_type TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON connection_type TO seedtrak
/

-- Constraints for CONNECTION_TYPE

ALTER TABLE connection_type
 ADD CONSTRAINT connection_type_pk PRIMARY KEY (connection_type_id)
 USING INDEX
/


-- Triggers for CONNECTION_TYPE

CREATE OR REPLACE TRIGGER conection_type_audit
BEFORE INSERT  OR UPDATE
ON connection_type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER connection_type_ins1
BEFORE INSERT
ON connection_type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select Connection_Type_seq.nextval into :new.Connection_Type_id from dual;

End;
/

-- End of DDL script for CONNECTION_TYPE

-- Start of DDL script for SOFTWARE_VERSION
-- Generated 19-Apr-05  7:41:00 am
-- from fs_devl-ECOM:2

-- Table SOFTWARE_VERSION

CREATE TABLE software_version
 (
  software_version_id        VARCHAR2(8) NOT NULL,
  descr                      VARCHAR2(35) NOT NULL,
  seed_year                  VARCHAR2(4) NOT NULL,
  date_deployed              DATE NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for SOFTWARE_VERSION

GRANT DELETE,INSERT,SELECT,UPDATE ON software_version TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON software_version TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON software_version TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON software_version TO seedtrak
/

-- Constraints for SOFTWARE_VERSION

ALTER TABLE software_version
 ADD CONSTRAINT software_version_pk PRIMARY KEY (software_version_id)
 USING INDEX
/


-- Triggers for SOFTWARE_VERSION

CREATE OR REPLACE TRIGGER software_version_audit
BEFORE INSERT  OR UPDATE
ON software_version
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

-- End of DDL script for SOFTWARE_VERSION

-- Start of DDL script for USER_STATUS
-- Generated 19-Apr-05  7:41:01 am
-- from fs_devl-ECOM:2

-- Table USER_STATUS

CREATE TABLE user_status
 (
  user_status_code           VARCHAR2(2) NOT NULL,
  descr                      VARCHAR2(35) NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for USER_STATUS

GRANT DELETE,INSERT,SELECT,UPDATE ON user_status TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON user_status TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON user_status TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON user_status TO seedtrak
/

-- Constraints for USER_STATUS

ALTER TABLE user_status
 ADD CONSTRAINT user_status_pk PRIMARY KEY (user_status_code)
 USING INDEX
/


-- Triggers for USER_STATUS

CREATE OR REPLACE TRIGGER user_status_audit
BEFORE INSERT  OR UPDATE
ON user_status
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

-- End of DDL script for USER_STATUS

-- Start of DDL script for DATA_EXCHANGE_TYPE
-- Generated 19-Apr-05  7:40:54 am
-- from fs_devl-ECOM:2

-- Table DATA_EXCHANGE_TYPE

CREATE TABLE data_exchange_type
 (
  data_exchange_type_code    VARCHAR2(6) NOT NULL,
  descr                      VARCHAR2(35) NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for DATA_EXCHANGE_TYPE

GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_type TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_type TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_type TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_type TO seedtrak
/

-- Constraints for DATA_EXCHANGE_TYPE

ALTER TABLE data_exchange_type
 ADD CONSTRAINT data_exchange_type_pk PRIMARY KEY (data_exchange_type_code)
 USING INDEX
/


-- Triggers for DATA_EXCHANGE_TYPE

CREATE OR REPLACE TRIGGER data_exchange_type_audit
BEFORE INSERT  OR UPDATE
ON data_exchange_type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

-- End of DDL script for DATA_EXCHANGE_TYPE

-- Start of DDL script for MS_OFFICE_VERSION
-- Generated 19-Apr-05  7:40:55 am
-- from fs_devl-ECOM:2

-- Table MS_OFFICE_VERSION

CREATE TABLE ms_office_version
 (
  ms_office_version_id       NUMBER NOT NULL,
  descr                      VARCHAR2(35) NOT NULL,
  sort_order                 NUMBER NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for MS_OFFICE_VERSION

GRANT DELETE,INSERT,SELECT,UPDATE ON ms_office_version TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON ms_office_version TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON ms_office_version TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON ms_office_version TO seedtrak
/

-- Constraints for MS_OFFICE_VERSION

ALTER TABLE ms_office_version
 ADD CONSTRAINT ms_office_version_pk PRIMARY KEY (ms_office_version_id)
 USING INDEX
/


-- Triggers for MS_OFFICE_VERSION

CREATE OR REPLACE TRIGGER ms_office_version_audit
BEFORE INSERT  OR UPDATE
ON ms_office_version
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER ms_office_version_ins1
BEFORE INSERT
ON ms_office_version
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select MS_Office_Version_seq.nextval into :new.MS_Office_Version_id from dual;

End;
/

-- End of DDL script for MS_OFFICE_VERSION

-- Start of DDL script for OPERATING_SYSTEM_TYPE
-- Generated 19-Apr-05  7:40:56 am
-- from fs_devl-ECOM:2

-- Table OPERATING_SYSTEM_TYPE

CREATE TABLE operating_system_type
 (
  operating_system_type_id   NUMBER NOT NULL,
  descr                      VARCHAR2(35) NOT NULL,
  sort_order                 NUMBER NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for OPERATING_SYSTEM_TYPE

GRANT DELETE,INSERT,SELECT,UPDATE ON operating_system_type TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON operating_system_type TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON operating_system_type TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON operating_system_type TO seedtrak
/

-- Constraints for OPERATING_SYSTEM_TYPE

ALTER TABLE operating_system_type
 ADD CONSTRAINT operating_system_type_pk PRIMARY KEY (operating_system_type_id)
 USING INDEX
/


-- Triggers for OPERATING_SYSTEM_TYPE

CREATE OR REPLACE TRIGGER operating_system_type_audit
BEFORE INSERT  OR UPDATE
ON operating_system_type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER operating_system_type_ins1
BEFORE INSERT
ON operating_system_type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select Operating_System_Type_seq.nextval into :new.Operating_System_Type_id from dual;

End;
/

-- End of DDL script for OPERATING_SYSTEM_TYPE

-- Start of DDL script for SEEDTRAK_USER
-- Generated 19-Apr-05  7:40:58 am
-- from fs_devl-ECOM:2

-- Table SEEDTRAK_USER

CREATE TABLE seedtrak_user
 (
  seedtrak_id                NUMBER NOT NULL,
  acct_id                    NUMBER NOT NULL,
  user_status_code           VARCHAR2(2) NOT NULL,
  contact_name               VARCHAR2(40),
  contact_phone              VARCHAR2(16),
  contact_email              VARCHAR2(50),
  stt_id                     NUMBER NOT NULL,
  download_date              DATE,
  download_software_version_id  VARCHAR2(8),
  exchange_software_version_id  VARCHAR2(8),
  cd_delivery_flag           VARCHAR2(1),
  cd_sent_date               DATE,
  cd_software_version_id     VARCHAR2(8),
  user_guide_sent_date       DATE,
  first_connect_date         DATE,
  last_connect_date          DATE,
  operating_system_type_id   NUMBER,
  connection_type_id         NUMBER,
  ms_office_flag             VARCHAR2(1),
  ms_office_version_id       NUMBER,
  isp                        VARCHAR2(20),
  dealer_prospect_flag       VARCHAR2(1),
  application_submitted_date  DATE,
  application_processed_date  DATE,
  application_comment        VARCHAR2(4000),
  pos_exchange_flag          VARCHAR2(1) DEFAULT 'Y' NOT NULL,
  override_start_date        DATE,
  override_end_date          DATE,
  upload_file_flag           VARCHAR2(1) DEFAULT 'N' NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for SEEDTRAK_USER

GRANT DELETE,INSERT,SELECT,UPDATE ON seedtrak_user TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON seedtrak_user TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON seedtrak_user TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON seedtrak_user TO seedtrak
/

-- Indexes for SEEDTRAK_USER

CREATE  UNIQUE INDEX seedtrak_user_idx1
 ON seedtrak_user
  ( acct_id  )
/

-- Index SEEDTRAK_USER_IDX2

CREATE  INDEX seedtrak_user_idx2
 ON seedtrak_user
  ( download_software_version_id  )
/

CREATE  INDEX seedtrak_user_idx3
 ON seedtrak_user
  ( exchange_software_version_id  )
/

CREATE  INDEX seedtrak_user_idx4
 ON seedtrak_user
  ( cd_software_version_id  )
/

CREATE  INDEX seedtrak_user_idx5
 ON seedtrak_user
  ( user_status_code  )
/

CREATE  INDEX seedtrak_user_idx6
 ON seedtrak_user
  ( operating_system_type_id  )
/

CREATE  INDEX seedtrak_user_idx7
 ON seedtrak_user
  ( connection_type_id  )
/

CREATE  INDEX seedtrak_user_idx8
 ON seedtrak_user
  ( ms_office_version_id  )
/

-- Constraints for SEEDTRAK_USER

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_pk PRIMARY KEY (seedtrak_id)
 USING INDEX
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk1 FOREIGN KEY (download_software_version_id)
      REFERENCES SOFTWARE_VERSION(software_version_id)
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk2 FOREIGN KEY (exchange_software_version_id)
      REFERENCES SOFTWARE_VERSION(software_version_id)
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk3 FOREIGN KEY (cd_software_version_id)
      REFERENCES SOFTWARE_VERSION(software_version_id)
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk4 FOREIGN KEY (operating_system_type_id)
      REFERENCES OPERATING_SYSTEM_TYPE(operating_system_type_id)
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk5 FOREIGN KEY (user_status_code)
      REFERENCES USER_STATUS(user_status_code)
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk6 FOREIGN KEY (ms_office_version_id)
      REFERENCES MS_OFFICE_VERSION(ms_office_version_id)
/

ALTER TABLE seedtrak_user
 ADD CONSTRAINT seedtrak_user_fk7 FOREIGN KEY (connection_type_id)
      REFERENCES CONNECTION_TYPE(connection_type_id)
/

-- Triggers for SEEDTRAK_USER

CREATE OR REPLACE TRIGGER seedtrak_user_audit
BEFORE INSERT  OR UPDATE
ON seedtrak_user
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER seedtrak_user_ins1
BEFORE INSERT
ON seedtrak_user
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select seedtrak_user_seq.nextval into :new.seedtrak_id from dual;

End;
/

-- End of DDL script for SEEDTRAK_USER
-- Start of DDL script for DATA_EXCHANGE_LOG
-- Generated 19-Apr-05  7:40:52 am
-- from fs_devl-ECOM:2

-- Table DATA_EXCHANGE_LOG

CREATE TABLE data_exchange_log
 (
  data_exchange_id           NUMBER NOT NULL,
  user_id                    VARCHAR2(50) NOT NULL,
  data_exchange_type_code    VARCHAR2(6) NOT NULL,
  data_exchange_start_date   DATE NOT NULL,
  data_exchange_end_date     DATE,
  seed_year                  VARCHAR2(4),
  software_version_id        VARCHAR2(8),
  transaction_count          NUMBER,
  acct_id                    NUMBER NOT NULL,
  row_user_id                VARCHAR2(12) NOT NULL,
  row_task_id                VARCHAR2(31) NOT NULL,
  row_entry_date             DATE NOT NULL,
  row_modify_date            DATE NOT NULL
 )
/

-- Grants for DATA_EXCHANGE_LOG

GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_log TO agcc_iis
/
GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_log TO developer
/
GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_log TO ecom_role
/
GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_log TO seedtrak
/

-- Indexes for DATA_EXCHANGE_LOG

CREATE  INDEX data_exchange_log_idx1
 ON data_exchange_log
  ( software_version_id  )
/

CREATE  INDEX data_exchange_log_idx2
 ON data_exchange_log
  ( data_exchange_type_code  )
/

-- Constraints for DATA_EXCHANGE_LOG

ALTER TABLE data_exchange_log
 ADD CONSTRAINT data_exchange_log_pk PRIMARY KEY (data_exchange_id)
 USING INDEX
/

ALTER TABLE data_exchange_log
 ADD CONSTRAINT data_exchange_log_fk1 FOREIGN KEY (software_version_id)
      REFERENCES SOFTWARE_VERSION(software_version_id)
/

ALTER TABLE data_exchange_log
 ADD CONSTRAINT data_exchange_log_fk2 FOREIGN KEY (data_exchange_type_code)
      REFERENCES DATA_EXCHANGE_TYPE(data_exchange_type_code)
/



-- Triggers for DATA_EXCHANGE_LOG

CREATE OR REPLACE TRIGGER data_exchange_log_audit
BEFORE INSERT  OR UPDATE
ON data_exchange_log
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

-- End of DDL script for DATA_EXCHANGE_LOG


-- Synonyms for ECOM_APP

CREATE SYNONYM ecom_app.data_exchange_log_seq
           FOR ecom.data_exchange_log_seq
/

CREATE SYNONYM ecom_app.data_exchange_log
           FOR ecom.data_exchange_log
/

CREATE SYNONYM ecom_app.data_exchange_type
           FOR ecom.data_exchange_type
/

CREATE SYNONYM ecom_app.seedtrak_user
           FOR ecom.seedtrak_user
/

CREATE SYNONYM ecom_app.software_version
           FOR ecom.software_version
/

CREATE SYNONYM ecom_app.acct_ext_dnml
           FOR agcc.acct_ext_dnml
/

CREATE SYNONYM ecom_app.state_us_terr_mv
           FOR agcc.state_us_terr_mv
/

CREATE SYNONYM ecom_app.user_status
           FOR ecom.user_status
/

CREATE SYNONYM ecom_app.connection_type
           FOR ecom.connection_type
/

CREATE SYNONYM ecom_app.operating_system_type
           FOR ecom.operating_system_type
/

CREATE SYNONYM ecom_app.ms_office_version
           FOR ecom.ms_office_version
/

