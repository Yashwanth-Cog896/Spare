drop table ACCT_XREF_MV
/

create table ACCT_XREF_MV
(       
		ALIAS_ID VARCHAR2(20), 
		ACCT_ID NUMBER, 
		SYSTEM_TYPE_CODE VARCHAR2(6), 
		ACTIVE_FLAG VARCHAR2(1)		
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

grant select on ACCT_XREF_MV to ecom_role, seedtrak
/