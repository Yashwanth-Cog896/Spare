CREATE OR REPLACE FORCE VIEW ECOM.ACCT_TO_STT_VW
AS 
SELECT "ORG_STRUCT_CODE","ACCT_ID","STT_EMP_ID","STT_NAME","EMAIL_ADDRESS","PHONE_BUSINESS"
FROM  AGCC.STT_MV
/

CREATE OR REPLACE FORCE VIEW ECOM.SEED_PRODUCT_PRICE_VW
AS 
SELECT rb.rds_product_id prod_code, rb.price_region, p.upc_code,
          rb.zone_code base_region_code,
          rb.azr_region_code zone_discount_region, rb.rate base_rate,
          NVL (z.zone_discount_rate, 0) zone_discount_rate,
          (rb.rate + NVL (z.zone_discount_rate, 0)) net_rate, rb.uom_id,
          GREATEST (rb.eff_start_date_sd,
                    NVL (rb.eff_start_date_tf, rb.eff_start_date_sd),
                    NVL (z.eff_start_date, rb.eff_start_date_sd)
                   ) eff_start_date,
          LEAST (rb.eff_end_date_sd,
                 NVL (rb.eff_end_date_tf, rb.eff_end_date_sd),
                 NVL (z.eff_end_date, rb.eff_end_date_sd)
                ) eff_end_date,
          rb.eff_start_date_sd, rb.eff_end_date_sd, rb.eff_start_date_tf,
          rb.eff_end_date_tf, z.eff_start_date eff_start_date_zd,
          z.eff_end_date eff_end_date_zd,
          LEAST (rb.row_entry_date,
                 NVL (z.row_entry_date, rb.row_entry_date)
                ) row_entry_date,
          GREATEST (rb.row_modify_date,
                    NVL (z.row_modify_date, rb.row_modify_date)
                   ) row_modify_date,
          rb.active_flag, p.prod_class_code, 'ST' mktsgmt,
          SUBSTR (brd.descr, 1, 6) brand
     FROM (SELECT r.price_region, r.azr_region_code, b.zone_code,
                  b.rds_product_id, b.rate, b.uom_id, b.eff_start_date_sd,
                  b.eff_end_date_sd, b.eff_start_date_tf, b.eff_end_date_tf,
                  b.row_entry_date, b.row_modify_date, b.active_flag
             FROM (SELECT   price_region, sap_region_code, azr_region_code
                       FROM ecom.price_zone_geography_vw
                   GROUP BY price_region, sap_region_code, azr_region_code) r,
                  agcc.seed_base_price_mv b
            WHERE r.sap_region_code = b.zone_code AND b.active_flag = 'Y') rb,
          agcc.seed_zone_discount_price_mv z,
          agcc.prod p,
          agcc.brand_mv brd
    WHERE rb.rds_product_id = z.rds_product_id(+)
      AND rb.azr_region_code = z.zone_code(+)
      AND rb.rds_product_id = p.prod_code
      AND p.brand_code = brd.brand_code
      AND z.active_flag(+) = 'Y'
/