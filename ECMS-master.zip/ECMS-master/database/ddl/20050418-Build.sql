alter table MS_Office_Version
add (Sort_Order  number not null)
;

alter table Operating_System_Type
add (Sort_Order  number not null)
;

alter table Connection_Type
add (Sort_Order  number not null)
;

create sequence MS_Office_Version_Seq
;

create sequence Operating_System_Type_Seq
;

create sequence Connection_Type_Seq
;

CREATE OR REPLACE TRIGGER MS_Office_Version_ins1
BEFORE INSERT
ON MS_Office_Version
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select MS_Office_Version_seq.nextval into :new.MS_Office_Version_id from dual;

End;
/

CREATE OR REPLACE TRIGGER Operating_System_Type_ins1
BEFORE INSERT
ON Operating_System_Type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select Operating_System_Type_seq.nextval into :new.Operating_System_Type_id from dual;

End;
/

CREATE OR REPLACE TRIGGER Connection_Type_ins1
BEFORE INSERT
ON Connection_Type
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
    Select Connection_Type_seq.nextval into :new.Connection_Type_id from dual;

End;
/

grant select,insert,update,delete on data_exchange_log to developer,agcc_iis;
grant select,insert,update,delete on data_exchange_type to developer,agcc_iis;
grant select,insert,update,delete on seedtrak_user to developer,agcc_iis;
grant select,insert,update,delete on user_status to developer,agcc_iis;
grant select,insert,update,delete on connection_type to developer,agcc_iis;
grant select,insert,update,delete on operating_system_type to developer,agcc_iis;
grant select,insert,update,delete on ms_office_version to developer,agcc_iis;
grant select,insert,update,delete on software_version to developer,agcc_iis;

ALTER TABLE SEEDTRAK_USER ADD (Contact_Email        VARCHAR2(50) NULL);
