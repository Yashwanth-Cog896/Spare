create or replace view farm_manager_list_vw
as
select  atr.active_flag,
        aed.short_name,
        ax.alias_id sap_id,
        aed.mailing_addr_line_1 addr_line_1,
        aed.mailing_city city,
        aed.mailing_state_code state_code,
        aed.mailing_zip||nvl2(aed.mailing_zip4,'-','')||aed.mailing_zip4 zip,
        aed.acct_id,
        aed.row_modify_date,
        atr.acct_role_code
from    agcc.acct_ext_dnml aed,
        agcc.acct_to_role_mv atr,
        agcc.acct_xref_mv ax
where   aed.acct_id = ax.acct_id
  and   ax.system_type_code = 'SAP'
  and   ax.active_flag = 'Y'
  and   aed.acct_id = atr.acct_id
  and   atr.acct_role_code in ('FN','FP')
/

grant select on farm_manager_list_vw to ecom_role, seedtrak
/

create or replace view st_terr_vw as
select
    atd.acct_id,
    atd.ba_id,
    atd.final_terr_code terr_id,
    oh_terr.descr terr_descr,
    oh_team.org_code team_id,
    oh_team.descr team_descr,
    oh_regn.org_code region_id,
    oh_regn.descr region_descr,
	e.empnum salesrep_emp_id,
	e.empfirst salesrep_first_name,
	e.emplast salesrep_last_name
from agcc.acct_terr_dnml atd,
    agcc.ird_parameter ip,
    agcc.org_hrchy_mv_vw oh_terr,
    agcc.org_hrchy_mv_vw oh_team,
    agcc.org_hrchy_mv_vw oh_regn,
    agcc.org_level_hrchy_mv_vw olh_team,
    agcc.org_level_hrchy_mv_vw olh_regn,
	agcc.emp e,
	agcc.emp_to_org eto
where atd.org_struct_code = ip.character_value
  and atd.mkt_seg_code = 'ST'
  and ip.ird_parameter_code = 'ORG_STRUCTURE'
  and oh_terr.org_code = atd.final_terr_code
  and oh_terr.org_struct_code = ip.character_value
  and substr(oh_terr.org_hrchy_id,1,olh_team.org_level_total) = oh_team.org_hrchy_id
  and oh_team.org_struct_code = ip.character_value
  and substr(oh_terr.org_hrchy_id,1,olh_regn.org_level_total) = oh_regn.org_hrchy_id
  and oh_regn.org_struct_code = ip.character_value
  and olh_team.org_level_code = 'TEAM'
  and olh_team.org_struct_code = ip.character_value
  and olh_regn.org_level_code = 'REGN'
  and olh_regn.org_struct_code = ip.character_value
  and eto.org_code = atd.final_terr_code
  and eto.org_struct_code = ip.character_value
  and eto.emp_relation_code = 'A'
  and e.empnum = eto.emp_id
  and e.emporgcode = ip.character_value
/

grant select on st_terr_vw to ecom_role, seedtrak, agcc_iis, developer
/

CREATE SYNONYM ecom_app.farm_manager_list_vw
           FOR ecom.farm_manager_list_vw
/
