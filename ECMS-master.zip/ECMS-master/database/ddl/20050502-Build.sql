alter table seedtrak_user
drop constraint seedtrak_user_fk2;

drop index seedtrak_user_idx3;

alter table seedtrak_user
drop (exchange_software_version_id, first_connect_date, last_connect_date);


CREATE TABLE Data_Exchange_Repository (
       DATA_EXCHANGE_ID     NUMBER NOT NULL,
       XML_Msg              XMLTYPE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;
ALTER TABLE Data_Exchange_Repository
       ADD  constraint Data_Exchange_Repository_PK PRIMARY KEY (DATA_EXCHANGE_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

-- Grants for SOFTWARE_VERSION

GRANT DELETE,INSERT,SELECT,UPDATE ON Data_Exchange_Repository TO ecom_role,seedtrak,agcc_iis,developer
/


ALTER TABLE Data_Exchange_Repository
       ADD  ( FOREIGN KEY (DATA_EXCHANGE_ID)
                             REFERENCES Data_Exchange_Log ) ;

