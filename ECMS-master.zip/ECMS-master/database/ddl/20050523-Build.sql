DROP TABLE ACTIVEMQ_MSGS;

create sequence Message_Queue_Seq
;

GRANT SELECT ON Message_Queue_Seq TO ecom_role,seedtrak
/

CREATE TABLE Message_Queue (
       Msg_Queue_ID         NUMBER NOT NULL,
       Destination          VARCHAR2(250) NOT NULL,
       JMS_Msg_ID           VARCHAR2(250) NOT NULL,
       XML_Msg              BLOB NOT NULL,
       Conversation_ID      VARCHAR2(255) NOT NULL,
       Broker_ID            VARCHAR2(250) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Message_Queue
       ADD  constraint Message_Queue_PK PRIMARY KEY (Msg_Queue_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX Message_Queue_IDX1 ON Message_Queue
(
       JMS_Msg_ID                     ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


create trigger Message_Queue_Audit
  BEFORE INSERT or UPDATE
  on Message_Queue

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

GRANT DELETE,INSERT,SELECT,UPDATE ON Message_Queue TO ecom_role,seedtrak
/
