create synonym ecom_app.data_exchange_repository for ecom.data_exchange_repository
/
