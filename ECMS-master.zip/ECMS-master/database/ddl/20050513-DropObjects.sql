ALTER TABLE SEEDTRAK_USER
    ADD (GPOS_Refresh_Flag   VARCHAR2(1) DEFAULT 'N' NOT NULL,
         PPOS_Refresh_Flag   VARCHAR2(1) DEFAULT 'N' NOT NULL);

drop sequence Special_Instruction_Seq;
drop table Special_Instruction;
drop table Special_Instruction_Type;
