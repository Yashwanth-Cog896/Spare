DDL SCRIPT DEFINITIONS
======================
DDL Scripts with the following naming conventions exist:
YYYYMMDD-Build-Sandbox.sql
YYYYMMDD-Build.sql
YYYYMMDD-Build-Test.sql
YYYYMMDD-DropObjects.sql
YYYYMMDD-syn.sql
SandboxDropAllObjects.sql

where "YYYYMMDD" represents a script for a build on a particular date;
EX:  20050404-Build.sql is for the build that is scheduled to occur on April 4, 2005

Normal implementation of a build in a sandbox schema will require the running of the
following scripts:
1) YYYYMMDD-Build-Sandbox.sql
2) YYYYMMDD-Build.sql

The scripts are defined and should be executed as follows:

YYYYMMDD-Build-Sandbox.sql 
------------------------
Contains DDL that will create objects necessary to complete a build in a sandbox 
environment.  These objects normally reside in other schemas such as AGCC or 
AGCC_REPL.  This script should be executed first in sequence.

YYYYMMDD-Build.sql 
----------------
Contains DDL that will create objects that will normally reside in the ECOM 
schema.  This is the DDL that will be executed in the development 
environment.  A script of the same name may also exist in the dml folder.  If 
so, it should be executed after the ddl script.

YYYYMMDD-Build-Test.sql 
----------------
Contains DDL that will create objects that will normally reside in the ECOM 
schema.  This is the DDL that will be executed in the test environment.  It contains the
cumulative ddl from the development builds since the last test build.

YYYYMMDD-DropObjects.sql 
----------------------------
Contains DDL to drop objects created for that particular build only.  Rolling 
back to a given build requires execution of all later DropObject scripts in 
reverse order.

YYYYMMDD-syn.sql 
--------------------
Contains DDL to create synonyms that will reside in ECOM_APP. These will not 
need to be run in sandbox schemas as the objects they reference will already
exist in the sandbox.

SandboxDropAllObjects.sql
-------------------------
Contains ddl to drop all objects that exist in a sandbox schema that has all 
build scripts implmented.  It is the equivalent to running all 
YYYYMMDD-DropObject.sql scripts.


RUNNING DDL SCRIPTS
===================
Many DDL scripts can be run within Eclipse using the Quantum DB plugin. However,
scripts creating PL/SQL objects (triggers, stored procedures etc.) cannot be run
this way and must be executed using a tool like Toad, SQL Navigator or SQL*Plus.

To run these scripts from SQL*Plus, enter the following at the "SQL>" prompt:

@C:\workspace\EComMessageSystem\database\ddl\SandboxDropAllObjects
@C:\workspace\EComMessageSystem\database\ddl\SandboxBuildAllObjects

The ".sql" extension is assumed, so
need not be entered.

**NOTE**: If new scripts are added, we need to make sure SandboxDropAllObjects and SandboxBuildAllObjects are kept up to date.
