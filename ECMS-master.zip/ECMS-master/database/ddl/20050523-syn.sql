CREATE SYNONYM ecom_app.Message_Queue_Seq
           FOR ecom.Message_Queue_Seq
/

CREATE SYNONYM ecom_app.Message_Queue
           FOR ecom.Message_Queue
/

DROP SYNONYM ecom_app.ACTIVEMQ_MSGS
/
