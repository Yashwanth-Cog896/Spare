create table GROWER_LICENSE_ZONE_VW
(     
        PURCHASER_ACCT_ID NUMBER,
        ACCT_NAME VARCHAR2(80),
        MAILING_STATE_CODE VARCHAR2(2),
        CORN_ZONE VARCHAR2(100),
        CORN_ZONE_CODE VARCHAR2(20),
        ALFALFA_ZONE VARCHAR2(100),
        ALFALFA_ZONE_CODE VARCHAR2(20),
        LICENSE_STATUS VARCHAR2(22),     
        CONTACT_LAST_NAME VARCHAR2(40),
        CONTACT_FIRST_NAME VARCHAR2(40)   
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
/

grant select on GROWER_LICENSE_ZONE_VW to ecom_role, seedtrak
/
