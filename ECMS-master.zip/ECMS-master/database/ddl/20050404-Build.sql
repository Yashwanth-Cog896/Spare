create sequence Data_Exchange_Log_Seq
;

GRANT SELECT ON data_exchange_log_seq TO ecom_role,seedtrak
/

create trigger DATA_EXCHANGE_LOG_Audit
  BEFORE INSERT or UPDATE
  on Data_Exchange_Log

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/




create trigger Data_Exchange_Type_Audit
  BEFORE INSERT or UPDATE
  on Data_Exchange_Type

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/





create trigger SeedTrak_User_Audit
  BEFORE INSERT or UPDATE
  on SeedTrak_User

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/





create trigger Software_Version_Audit
  BEFORE INSERT or UPDATE
  on Software_Version

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/


alter table SeedTrak_User
Add (
       CD_Address           VARCHAR2(40) NULL,
       CD_City              VARCHAR2(40) NULL,
       CD_State_Code        VARCHAR2(2) NOT NULL,
       CD_Zip               VARCHAR2(5) NULL,
       CD_Zip4              VARCHAR2(4) NULL
       )
;



ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK1
 FOREIGN KEY
 (DOWNLOAD_SOFTWARE_VERSION_ID
 )
 REFERENCES SOFTWARE_VERSION
  (SOFTWARE_VERSION_ID
 )
/

ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK2
 FOREIGN KEY
 (EXCHANGE_SOFTWARE_VERSION_ID
 )
 REFERENCES SOFTWARE_VERSION
  (SOFTWARE_VERSION_ID
 )
/

ALTER TABLE SEEDTRAK_USER
 ADD CONSTRAINT SEEDTRAK_USER_FK3
 FOREIGN KEY
 (CD_SOFTWARE_VERSION_ID
 )
 REFERENCES SOFTWARE_VERSION
  (SOFTWARE_VERSION_ID
 )
/

ALTER TABLE DATA_EXCHANGE_LOG
 ADD CONSTRAINT DATA_EXCHANGE_LOG_FK1
 FOREIGN KEY
 (SOFTWARE_VERSION_ID
 )
 REFERENCES SOFTWARE_VERSION
  (SOFTWARE_VERSION_ID
 )
/

