
CREATE SYNONYM ecom_app.acct_ext_dnml
           FOR agcc.acct_ext_dnml
/

CREATE SYNONYM ecom_app.state_us_terr_mv
           FOR agcc.state_us_terr_mv
/

CREATE SYNONYM ecom_app.user_status
           FOR ecom.user_status
/

CREATE SYNONYM ecom_app.connection_type
           FOR ecom.connection_type
/

CREATE SYNONYM ecom_app.operating_system_type
           FOR ecom.operating_system_type
/

CREATE SYNONYM ecom_app.ms_office_version
           FOR ecom.ms_office_version
/

