CREATE TABLE ACCT_MV
(
  ACCT_ID                 NUMBER                NOT NULL,
  BA_ID                   VARCHAR2(12 BYTE),
  SAP_ACCT_GRP_TYPE_CODE  VARCHAR2(4 BYTE),
  ACCT_STATUS_TYPE_ID     NUMBER                NOT NULL,
  DATA_SOURCE_ID          NUMBER,
  ROW_ENTRY_DATE          DATE                  NOT NULL,
  ROW_MODIFY_DATE         DATE                  NOT NULL,
  ROW_TASK_ID             VARCHAR2(31 BYTE)     NOT NULL,
  ROW_USER_ID             VARCHAR2(12 BYTE)     NOT NULL,
  SHORT_NAME              VARCHAR2(30 BYTE)     NOT NULL,
  END_DATE                DATE,
  LICENSED_SINCE_YEAR     NUMBER,
  NAME_1                  VARCHAR2(40 BYTE)     NOT NULL,
  NAME_2                  VARCHAR2(40 BYTE),
  INTEGRATED_MKTG_SEG_ID  NUMBER
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )           
;
CREATE TABLE ACCT_NAPD_DNML
(
  ACCT_ID  NUMBER                               NOT NULL,
  NAPD_ID  VARCHAR2(20 BYTE)                    NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;         

CREATE TABLE ACCT_TO_ZONE_MV
(
  ACCT_ID             NUMBER                    NOT NULL,
  ZONE_STRUCT_CODE    VARCHAR2(20 BYTE)         NOT NULL,
  MKT_YEAR_CODE       VARCHAR2(8 BYTE)          NOT NULL,
  ZONE_CODE           VARCHAR2(20 BYTE),
  ZONE_DESCR          VARCHAR2(100 BYTE)        NOT NULL,
  RECLASS_FLAG        VARCHAR2(1 BYTE)          NOT NULL,
  SAP_FLAG            VARCHAR2(1 BYTE)          NOT NULL,
  ORIGINAL_ZONE_CODE  VARCHAR2(20 BYTE),
  ROW_ENTRY_DATE      DATE                      NOT NULL,
  ROW_MODIFY_DATE     DATE                      NOT NULL,
  ROW_TASK_ID         VARCHAR2(31 BYTE)         NOT NULL,
  ROW_USER_ID         VARCHAR2(12 BYTE)         NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;
CREATE TABLE TRAIT_TO_ZONE_STRUCT_MV
(
  TRAIT_CODE        VARCHAR2(3 BYTE)            NOT NULL,
  SPECIES_CODE      VARCHAR2(2 BYTE)            NOT NULL,
  MKT_YEAR_CODE     VARCHAR2(8 BYTE)            NOT NULL,
  USAGE_CODE        VARCHAR2(2 BYTE)            NOT NULL,
  ZONE_STRUCT_CODE  VARCHAR2(20 BYTE)           NOT NULL,
  ROW_ENTRY_DATE    DATE                        NOT NULL,
  ROW_MODIFY_DATE   DATE                        NOT NULL,
  ROW_TASK_ID       VARCHAR2(31 BYTE)           NOT NULL,
  ROW_USER_ID       VARCHAR2(12 BYTE)           NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;          
CREATE TABLE REGION_STRUCT_MV
(
  REGION_STRUCT_CODE  VARCHAR2(20 BYTE)         NOT NULL,
  DESCR               VARCHAR2(100 BYTE)        NOT NULL,
  ROW_USER_ID         VARCHAR2(12 BYTE)         NOT NULL,
  ROW_TASK_ID         VARCHAR2(31 BYTE)         NOT NULL,
  ROW_ENTRY_DATE      DATE                      NOT NULL,
  ROW_MODIFY_DATE     DATE                      NOT NULL
)  
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )                          
;
ALTER TABLE ACCT_XREF_MV ADD 
(
  BEGIN_DATE        DATE                        NOT NULL,
  BA_ID             VARCHAR2(12 BYTE),
  ROW_ENTRY_DATE    DATE                        NOT NULL,
  ROW_MODIFY_DATE   DATE                        NOT NULL,
  ROW_TASK_ID       VARCHAR2(31 BYTE)           NOT NULL,
  ROW_USER_ID       VARCHAR2(12 BYTE)           NOT NULL,
  END_DATE          DATE                        NOT NULL
)
;
CREATE TABLE ACCT_TO_AGREEMENT_MV
(
  BEGIN_DATE       DATE                         NOT NULL,
  ACCT_ID          NUMBER                       NOT NULL,
  AGREEMENT_CODE   VARCHAR2(4 BYTE)             NOT NULL,
  BA_ID            VARCHAR2(12 BYTE),
  SIGNER_ACCT_ID   NUMBER,
  ROW_ENTRY_DATE   DATE                         NOT NULL,
  ROW_MODIFY_DATE  DATE                         NOT NULL,
  ROW_TASK_ID      VARCHAR2(31 BYTE)            NOT NULL,
  ROW_USER_ID      VARCHAR2(12 BYTE)            NOT NULL,
  END_DATE         DATE,
  DOCUMENTUM_ID    VARCHAR2(16 BYTE)
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )                          
;
/
grant select on ACCT_MV to ecom_role, seedtrak;
grant select on ACCT_NAPD_DNML to ecom_role, seedtrak;
grant select on ACCT_TO_ZONE_MV to ecom_role, seedtrak;
grant select on TRAIT_TO_ZONE_STRUCT_MV to ecom_role, seedtrak;
grant select on REGION_STRUCT_MV to ecom_role, seedtrak;
grant select on ACCT_TO_AGREEMENT_MV to ecom_role, seedtrak;
/
