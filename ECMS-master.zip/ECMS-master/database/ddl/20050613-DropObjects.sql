drop view terr_vw
/

alter table seedtrak_user
add (stt_id number)
/
