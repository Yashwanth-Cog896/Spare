ALTER TABLE SEEDTRAK_USER
    rename column POS_Exchange_Flag to GPOS_Exchange_Flag;
ALTER TABLE SEEDTRAK_USER
    ADD (PPOS_Exchange_Flag   VARCHAR2(1) DEFAULT 'Y' NOT NULL);
ALTER TABLE SEEDTRAK_USER
    ADD (FPOS_Exchange_Flag   VARCHAR2(1) DEFAULT 'Y' NOT NULL);
ALTER TABLE SEEDTRAK_USER
    ADD (GPOS_Refresh_Flag   VARCHAR2(1) DEFAULT 'N' NOT NULL);
ALTER TABLE SEEDTRAK_USER
    ADD (PPOS_Refresh_Flag   VARCHAR2(1) DEFAULT 'N' NOT NULL);

create or replace view st_sales_grp_vw
as
select asa.acct_id,
       asa.customer_grp_code,
       cg.descr,
       case asa.customer_grp_code
           when 'V7' then 'National'
           when 'V5' then 'National'
           when 'V4' then 'National'
           when 'XA' then 'National'
           when 'V6' then 'National'
           when 'V9' then 'National'
           when 'XE' then 'National'
           when 'VN' then 'National'
           when 'V2' then 'National'
           when 'VD' then 'Indep Seed Only Deal'
           when 'VA' then 'Indep Seed Only Deal'
           when 'VW' then 'Indep Seed Only Deal'
           when 'VB' then 'Independent Retailer'
           when 'VF' then 'Grower Financing'
           else 'Other'
       end st_sales_grp_descr
  from agcc.acct_sales_area_mv asa,
       agcc.customer_grp_mv cg
 where asa.customer_grp_code=cg.customer_grp_code
   and asa.division_code='17'
   and asa.distribution_channel_code='90'
   and asa.sales_org_code='US20'
/

grant select on st_sales_grp_vw to ecom_role, seedtrak, agcc_iis, developer
/

create or replace view st_terr_vw as
select
    atd.acct_id,
    atd.sap_id,
    atd.ba_id,
    atd.final_terr_code terr_id,
    oh_terr.descr terr_descr,
    oh_team.org_code team_id,
    oh_team.descr team_descr,
    oh_regn.org_code region_id,
    oh_regn.descr region_descr
from agcc.acct_terr_dnml atd,
    agcc.ird_parameter ip,
    agcc.org_hrchy_mv_vw oh_terr,
    agcc.org_hrchy_mv_vw oh_team,
    agcc.org_hrchy_mv_vw oh_regn,
    agcc.org_level_hrchy_mv_vw olh_team,
    agcc.org_level_hrchy_mv_vw olh_regn
where atd.org_struct_code = ip.character_value
  and atd.mkt_seg_code = 'ST'
  and ip.ird_parameter_code = 'ORG_STRUCTURE'
  and oh_terr.org_code = atd.final_terr_code
  and oh_terr.org_struct_code = ip.character_value
  and substr(oh_terr.org_hrchy_id,1,olh_team.org_level_total) = oh_team.org_hrchy_id
  and oh_team.org_struct_code = ip.character_value
  and substr(oh_terr.org_hrchy_id,1,olh_regn.org_level_total) = oh_regn.org_hrchy_id
  and oh_regn.org_struct_code = ip.character_value
  and olh_team.org_level_code = 'TEAM'
  and olh_team.org_struct_code = ip.character_value
  and olh_regn.org_level_code = 'REGN'
  and olh_regn.org_struct_code = ip.character_value
/

grant select on st_terr_vw to ecom_role, seedtrak, agcc_iis, developer
/
