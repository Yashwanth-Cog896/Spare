CREATE SYNONYM ecom_app.terr_vw
           FOR ecom.terr_vw
/
