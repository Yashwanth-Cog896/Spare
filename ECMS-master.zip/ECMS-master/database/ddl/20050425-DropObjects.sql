DROP INDEX Data_Exchange_Log_IDX3;

alter table DATA_EXCHANGE_LOG
drop (Error_Code,Error_Msg);

alter table DATA_EXCHANGE_LOG
drop (Conversation_ID,Date_Processed);

