ALTER TABLE SEEDTRAK_USER
    drop (GPOS_Refresh_Flag, PPOS_Refresh_Flag);

create sequence Special_Instruction_Seq
;

GRANT SELECT ON Special_Instruction_Seq TO ecom_role,seedtrak,agcc_iis,developer
/

CREATE TABLE Special_Instruction_Type (
       Special_Instruction_Type_Code   VARCHAR2(6) NOT NULL,
       Descr                VARCHAR2(35) NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON Special_Instruction_Type TO ecom_role,seedtrak,agcc_iis,developer
/

ALTER TABLE Special_Instruction_Type
       ADD  constraint Special_Instruction_Type_PK PRIMARY KEY (Special_Instruction_Type_Code)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

create trigger Special_Instruction_Type_Audit
  BEFORE INSERT or UPDATE
  on Special_Instruction_Type

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE TABLE Special_Instruction (
       Special_Instruction_ID         NUMBER NOT NULL,
       Acct_ID                        NUMBER NOT NULL,
       Data_Exchange_Type_Code        VARCHAR2(6) NOT NULL,
       Special_Instruction_Type_Code  VARCHAR2(6) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON Special_Instruction TO ecom_role,seedtrak,agcc_iis,developer
/

ALTER TABLE Special_Instruction
       ADD  constraint Special_Instruction_PK PRIMARY KEY (Special_Instruction_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE UNIQUE INDEX Special_Instruction_IDX1 ON Special_Instruction
(
       Acct_ID            ASC,
       Data_Exchange_Type_Code ASC,
       Special_Instruction_Type_Code ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX Special_Instruction_IDX2 ON Special_Instruction
(
       Data_Exchange_Type_Code            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX Special_Instruction_IDX3 ON Special_Instruction
(
       Special_Instruction_Type_Code            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Special_Instruction
 ADD CONSTRAINT Special_Instruction_FK1
 FOREIGN KEY
 (DATA_EXCHANGE_TYPE_CODE
 )
 REFERENCES Data_Exchange_Type
  (DATA_EXCHANGE_TYPE_CODE
 )
/

ALTER TABLE Special_Instruction
 ADD CONSTRAINT Special_Instruction_FK2
 FOREIGN KEY
 (SPECIAL_INSTRUCTION_TYPE_CODE
 )
 REFERENCES Special_Instruction_Type
  (SPECIAL_INSTRUCTION_TYPE_CODE
 )
/

create trigger Special_Instruction_Audit
  BEFORE INSERT or UPDATE
  on Special_Instruction

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

CREATE OR REPLACE TRIGGER Special_Instruction_Ins1
BEFORE INSERT
ON Special_Instruction
REFERENCING NEW AS NEW OLD AS OLD
FOR EACH ROW
Begin
        Select Special_Instruction_seq.nextval into :new.Special_Instruction_id from dual;
End;
/
