rename acct_ext_dnml_mv1 to acct_ext_dnml;

alter table acct_ext_dnml
add (ic_code varchar2(20))
;
