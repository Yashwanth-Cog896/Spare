
      /*
      ACTION is CREATE Table Acct_Ext_Dnml_MV1
      */

CREATE TABLE Acct_Ext_Dnml_mv1 (
       Acct_ID              NUMBER NOT NULL,
       BA_ID                VARCHAR2(12) NULL,
       Name_1               VARCHAR2(40) NULL,
       Mailing_Addr_Line_1  VARCHAR2(40) NULL,
       Mailing_Addr_Line_2  VARCHAR2(40) NULL,
       Mailing_Addr_Line_3  VARCHAR2(40) NULL,
       Mailing_City         VARCHAR2(40) NULL,
       Mailing_State_Code   VARCHAR2(2) NULL,
       Mailing_Zip          VARCHAR2(5) NULL,
       Mailing_Zip4         VARCHAR2(4) NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Acct_Ext_Dnml_mv1
       ADD constraint Acct_Ext_Dnml_pk PRIMARY KEY (Acct_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;
      /*
      ACTION is CREATE Table State_US_Terr_MV
      */

CREATE TABLE State_US_Terr_MV (
       State_Code           VARCHAR2(2) NOT NULL,
       State_US_Terr_Name   VARCHAR2(20) NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE State_US_Terr_MV
       ADD constraint State_US_Terr_MV_pk PRIMARY KEY (State_Code)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

