delete from data_exchange_log;
commit;

ALTER TABLE DATA_EXCHANGE_LOG
ADD (Conversation_ID      VARCHAR2(255) NOT NULL);

CREATE UNIQUE INDEX Data_Exchange_Log_IDX3 ON Data_Exchange_Log
(
       Conversation_ID                ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;


alter table seedtrak_user
drop constraint seedtrak_user_fk2;

drop index seedtrak_user_idx3;

alter table seedtrak_user
drop (exchange_software_version_id, first_connect_date, last_connect_date);


CREATE TABLE Data_Exchange_Repository (
       DATA_EXCHANGE_ID     NUMBER NOT NULL,
       XML_Msg              CLOB NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Data_Exchange_Repository
       ADD  constraint Data_Exchange_Repository_PK PRIMARY KEY (DATA_EXCHANGE_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

-- Grants for SOFTWARE_VERSION

GRANT DELETE,INSERT,SELECT,UPDATE ON Data_Exchange_Repository TO ecom_role,seedtrak,agcc_iis,developer
/


ALTER TABLE Data_Exchange_Repository
       ADD  ( FOREIGN KEY (DATA_EXCHANGE_ID)
                             REFERENCES Data_Exchange_Log ) ;

      /*
      ACTION is CREATE Table ActiveMQ_Msgs
      */

CREATE TABLE ActiveMQ_Msgs (
       ID                   NUMBER NOT NULL,
       Container            VARCHAR2(250) NULL,
       MsgID                VARCHAR2(250) NULL,
       Msg                  BLOB NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE ActiveMQ_Msgs
       ADD  constraint ActiveMQ_Msgs_PK PRIMARY KEY (ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX ActiveMQ_Msgs_IDX1 ON ActiveMQ_Msgs
(
       Container            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX ActiveMQ_Msgs_IDX2 ON ActiveMQ_Msgs
(
       MsgID            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

GRANT DELETE,INSERT,SELECT,UPDATE ON ActiveMQ_Msgs TO ecom_role,seedtrak
/


      /*
      ACTION is CREATE Table Data_Exchange_Event
      */

CREATE TABLE Data_Exchange_Event (
       Data_Exchange_Event_ID NUMBER NOT NULL,
       Conversation_ID      VARCHAR2(255) NOT NULL,
       Event_Date           DATE NULL,
       Status_Code          VARCHAR2(50) NULL,
       Status_Msg           VARCHAR2(255) NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Data_Exchange_Event
       ADD  constraint Data_Exchange_Event_PK PRIMARY KEY (Data_Exchange_Event_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

CREATE INDEX Data_Exchange_Event_IDX1 ON Data_Exchange_Event
(
       Conversation_ID            ASC
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;



create trigger Data_Exchange_Event_Audit
  BEFORE INSERT or UPDATE
  on Data_Exchange_Event

  for each row
Begin
    :new.row_modify_date := sysdate;

    If Inserting Then
        :new.row_entry_date := sysdate;
    End If;

    If :new.row_task_id is null Then
        :new.row_task_id := 'UNKNOWN';
    End If;

    If :new.row_user_id is null Then
        :new.row_user_id := User;
    End If;
End;
/

GRANT DELETE,INSERT,SELECT,UPDATE ON Data_Exchange_Event TO ecom_role,seedtrak,agcc_iis,developer
/

create sequence Data_Exchange_Event_Seq
;

GRANT SELECT ON Data_Exchange_Event_Seq TO ecom_role,seedtrak,agcc_iis,developer
/


create synonym ecom_app.data_exchange_repository for ecom.data_exchange_repository
/

create synonym ecom_app.ActiveMQ_Msgs for ecom.ActiveMQ_Msgs
/

create synonym ecom_app.Data_Exchange_Event for ecom.Data_Exchange_Event
/

create synonym ecom_app.Data_Exchange_Event_Seq for ecom.Data_Exchange_Event_Seq
/
