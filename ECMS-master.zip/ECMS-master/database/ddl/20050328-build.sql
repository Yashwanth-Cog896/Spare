
      /*
      ACTION is CREATE Table Software_Version
      */

CREATE TABLE Software_Version (
       Software_Version_ID  VARCHAR2(8) NOT NULL,
       Descr                VARCHAR2(35) NULL,
       Seed_Year            VARCHAR2(4) NULL,
       Date_Deployed        DATE NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Software_Version
       ADD  constraint Software_Version_PK PRIMARY KEY (Software_Version_ID)
USING INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

-- Grants for SOFTWARE_VERSION

GRANT DELETE,INSERT,SELECT,UPDATE ON software_version TO ecom_role,seedtrak
/



      /*
      ACTION is CREATE Table Data_Exchange_Type
      */

CREATE TABLE Data_Exchange_Type (
       Data_Exchange_Type_Code   VARCHAR2(6) NOT NULL,
       Descr                VARCHAR2(35) NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Data_Exchange_Type
       ADD  constraint Data_Exchange_Type_PK PRIMARY KEY (Data_Exchange_Type_Code)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

-- Grants for DATA_EXCHANGE_TYPE

GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_type TO ecom_role,seedtrak
/



      /*
      ACTION is CREATE Table Data_Exchange_Log
      */

CREATE TABLE Data_Exchange_Log (
       Data_Exchange_ID          NUMBER NOT NULL,
       User_ID              VARCHAR2(50) NOT NULL,
       Data_Exchange_Type_Code   VARCHAR2(6) NOT NULL,
       Data_Exchange_Start_Date  DATE NULL,
       Data_Exchange_End_Date    DATE NULL,
       Seed_Year            VARCHAR2(4) NULL,
       Software_Version_ID  VARCHAR2(8) NOT NULL,
       Transaction_Count    NUMBER NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL,
	   Source_Name          VARCHAR2(32)
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE Data_Exchange_Log
       ADD constraint Data_Exchange_Log_PK  PRIMARY KEY (Data_Exchange_ID)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

-- Grants for DATA_EXCHANGE_LOG

GRANT DELETE,INSERT,SELECT,UPDATE ON data_exchange_log TO ecom_role,seedtrak
/



      /*
      ACTION is CREATE Table SeedTrak_User
      */

CREATE TABLE SeedTrak_User (
       User_ID              VARCHAR2(50) NOT NULL,
       User_Status_Code     VARCHAR2(2) NOT NULL,
       Business_Phone       VARCHAR2(16) NULL,
       Home_Phone           VARCHAR2(16) NULL,
       Mobile_Phone         VARCHAR2(16) NULL,
       Fax_Phone            VARCHAR2(16) NULL,
       Contact_Name         VARCHAR2(40) NULL,
       Contact_Phone        VARCHAR2(16) NULL,
       STT_ID               NUMBER NOT NULL,
       Download_Date        DATE NULL,
       Download_Software_Version_ID VARCHAR2(8) NOT NULL,
       Exchange_Software_Version_ID VARCHAR2(8) NOT NULL,
       CD_Delivery_Flag     VARCHAR2(1) NOT NULL,
       CD_Sent_Date         DATE NULL,
       CD_Software_Version_ID VARCHAR2(8) NOT NULL,
       User_Guide_Sent_Date DATE NULL,
       First_Connect_Date   DATE NULL,
       Last_Connect_Date    DATE NULL,
       Operating_System_Type_ID NUMBER NOT NULL,
       Connection_Type_ID   NUMBER NOT NULL,
       MS_Office_Flag       VARCHAR2(1) NOT NULL,
       MS_Office_Version_ID NUMBER NULL,
       ISP                  VARCHAR2(20) NULL,
       Dealer_Prospect_Flag VARCHAR2(1) NOT NULL,
       Application_Submitted_Date DATE NULL,
       Application_Processed_Date DATE NULL,
       Application_Comment  VARCHAR2(4000) NULL,
       POS_Exchange_Flag    VARCHAR2(1) NOT NULL,
       Override_Start_Date  DATE NULL,
       Override_End_Date    DATE NULL,
       Upload_File_Flag     VARCHAR2(1) NOT NULL,
       Row_User_ID          VARCHAR2(12) NOT NULL,
       Row_Task_ID          VARCHAR2(31) NOT NULL,
       Row_Entry_Date       DATE NOT NULL,
       Row_Modify_Date      DATE NOT NULL
)
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

ALTER TABLE SeedTrak_User
       ADD constraint SeedTrak_User_PK PRIMARY KEY (User_ID)
using INDEX
STORAGE    (
            INITIAL          8K
            NEXT             8K
            PCTINCREASE      0
           )
;

-- Grants for SEEDTRAK_USER

GRANT DELETE,INSERT,SELECT,UPDATE ON seedtrak_user TO ecom_role,seedtrak
/


