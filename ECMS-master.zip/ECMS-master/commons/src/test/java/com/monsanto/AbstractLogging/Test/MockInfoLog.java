/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.IInfoLog;

/**
 * <p>Title: MockInfoLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockInfoLog.java,v 1.13 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockInfoLog extends MockLog implements IInfoLog
{
   public MockInfoLog ()
   {
      super(0);
   }

   public MockInfoLog (int iID)
   {
      super(iID);
   }

   public String name()
   {
      return "MockLog.Info";
   }

   public String type()
   {
      return "INFO";
   }

   /**
    * Closes the log.
    */
   public void close()
   {
   }
}
