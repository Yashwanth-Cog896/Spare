package com.monsanto.ServletFramework.Test;


import com.monsanto.ServletFramework.FormRequestData;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 7, 2005
 * Time: 3:07:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockConcreteForm implements FormRequestData {

  private String stuff;
  private int amount;
  private boolean huh;
  private String[] htmlMultiSelectListValues;

  public MockConcreteForm() {
    amount = 43;
  }

  public String getStuff() {
    return stuff;
  }

  public void setStuff(String stuff) {
    this.stuff = stuff;
  }

  public int getAmount() {
    return amount;
  }

  public void setAmount(int amount) {
    this.amount = amount;
  }

  public boolean isHuh() {
    return huh;
  }

  public void setHuh(boolean huh) {
    this.huh = huh;
  }

  public String[] getHtmlMultiSelectListValues() {
    return htmlMultiSelectListValues;
  }

  public void setHtmlMultiSelectListValues(String[] htmlMultiSelectListValues) {
    this.htmlMultiSelectListValues = htmlMultiSelectListValues;
  }
}
