package com.monsanto.ServletFramework.Test;

/**
 * Created by IntelliJ IDEA.
 * User: sdshan1
 * Date: Sep 16, 2005
 * Time: 10:35:59 AM
 * To change this template use File | Settings | File Templates.
 */

import com.meterware.httpunit.cookies.CookieProperties;
import com.meterware.servletunit.InvocationContext;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.UCCHelperCommon;
import junit.framework.TestCase;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class UCCHelperCommon_UT extends TestCase {

  private ServletRunner servletRunner = new ServletRunner();
  private ServletUnitClient servletUnitClient = servletRunner.newClient();
  private static final String TEST_SERVLET_URL = "http://localhost:7080/testServlet";
  private static final int EXPECTED_MAX_DELAY_IN_RUNNING_TEST_IN_SECONDS = 60;

  public UCCHelperCommon_UT() {
    servletRunner.registerServlet("testServlet/*", testServlet.class.getName());
  }

  public void testGetCookies() throws Exception {
    CookieProperties.setDomainMatchingStrict(false);
    CookieProperties.setPathMatchingStrict(false);
    String FIRST_COOKIE = "RANDOM_COOKIE";
    String SECOND_COOKIE = "ANOTHER_COOKIE";
    String FIRST_COOKIE_VALUE = "cookie1";
    String SECOND_COOKIE_VALUE = "cookie2";
    servletUnitClient.putCookie(FIRST_COOKIE, FIRST_COOKIE_VALUE);
    servletUnitClient.putCookie(SECOND_COOKIE, SECOND_COOKIE_VALUE);

    UCCHelperCommon helperCommon = UCCHelperTestUtil.getHelperCommonUsingInvocationContextForURL(TEST_SERVLET_URL, servletUnitClient);

    javax.servlet.http.Cookie[] cookies = helperCommon.getCookies();
    javax.servlet.http.Cookie firstActualCookie = cookies[0];
    javax.servlet.http.Cookie secondActualCookie = cookies[1];

    assertEquals(FIRST_COOKIE, firstActualCookie.getName());
    assertEquals(SECOND_COOKIE, secondActualCookie.getName());

    assertEquals(FIRST_COOKIE_VALUE, firstActualCookie.getValue());
    assertEquals(SECOND_COOKIE_VALUE, secondActualCookie.getValue());
  }

  public void testGetMonsantoCookies() throws Exception {
    CookieProperties.setDomainMatchingStrict(false);
    CookieProperties.setPathMatchingStrict(false);
    String FIRST_COOKIE = "RANDOM_COOKIE";
    String SECOND_COOKIE = "ANOTHER_COOKIE";
    String FIRST_COOKIE_VALUE = "cookie1";
    String SECOND_COOKIE_VALUE = "cookie2";
    servletUnitClient.putCookie(FIRST_COOKIE, FIRST_COOKIE_VALUE);
    servletUnitClient.putCookie(SECOND_COOKIE, SECOND_COOKIE_VALUE);

    UCCHelperCommon helperCommon = UCCHelperTestUtil.getHelperCommonUsingInvocationContextForURL(TEST_SERVLET_URL, servletUnitClient);

    com.monsanto.ServletFramework.Cookie[] cookies = helperCommon.getClientCookies();
    com.monsanto.ServletFramework.Cookie firstActualCookie = cookies[0];
    com.monsanto.ServletFramework.Cookie secondActualCookie = cookies[1];

    assertEquals(FIRST_COOKIE, firstActualCookie.getName());
    assertEquals(SECOND_COOKIE, secondActualCookie.getName());

    assertEquals(FIRST_COOKIE_VALUE, firstActualCookie.getValue());
    assertEquals(SECOND_COOKIE_VALUE, secondActualCookie.getValue());
  }

  public void testAddCookie() throws Exception {
    CookieProperties.setDomainMatchingStrict(false);
    CookieProperties.setPathMatchingStrict(false);

    InvocationContext invocation = servletUnitClient.newInvocation(TEST_SERVLET_URL);
    HttpServletRequest request = invocation.getRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    UCCHelperCommon helperCommon = new UCCHelperCommon(request, response);

    com.monsanto.ServletFramework.Cookie monsantoCookie = new com.monsanto.ServletFramework.Cookie("RANDOM_PUT_COOKIE", "put value");
    helperCommon.addCookie(monsantoCookie);

    Vector cookies = response.getCookies();
    assertEquals(1, cookies.size());
    javax.servlet.http.Cookie javaCookie = (javax.servlet.http.Cookie) cookies.get(0);
    assertEquals("RANDOM_PUT_COOKIE", javaCookie.getName());
    assertEquals("put value", javaCookie.getValue());
		assertEquals(getMaxAgeDefaultValue(), javaCookie.getMaxAge());
	}

 /**
	 * Important Note: This test validates the MaxAge to be present within a specific range. Considering there will be some
	 * delay for running test, exact asserts can not be done for values in seconds.
	 * Currently the "EXPECTED_MAX_DELAY_IN_RUNNING_TEST_IN_SECONDS" has been set to 60 seconds, but if that's not sufficient please
	 * set it to a larger value.
	 * @throws Exception
	 */
	public void testAddCookie_SetsAppropriateMaxAgeOnJavaCookie_IfExpirationDateOnMonsantoCookieIsSpecified() throws Exception {
		int numberOfDays = 3;
		InvocationContext invocation = servletUnitClient.newInvocation(TEST_SERVLET_URL);
		MockHttpServletResponse response = new MockHttpServletResponse();
		UCCHelperCommon helperCommon = new UCCHelperCommon(invocation.getRequest(), response);
		com.monsanto.ServletFramework.Cookie monsantoCookie = new com.monsanto.ServletFramework.Cookie("RANDOM_PUT_COOKIE", "put value");
		monsantoCookie.setExpiration(getDateNumberOfDaysFromToday(numberOfDays));
		helperCommon.addCookie(monsantoCookie);
		javax.servlet.http.Cookie javaCookie = (javax.servlet.http.Cookie) response.getCookies().get(0);
		validateMaxAge(numberOfDays, javaCookie);
	}

	public void testAddCookie_DoesNotSetMaxAgeOnJavaCookie_IfExpirationDateOnMonsantoCookieIsNull() throws Exception {
		InvocationContext invocation = servletUnitClient.newInvocation(TEST_SERVLET_URL);
		MockHttpServletResponse response = new MockHttpServletResponse();
		UCCHelperCommon helperCommon = new UCCHelperCommon(invocation.getRequest(), response);
		com.monsanto.ServletFramework.Cookie monsantoCookie = new com.monsanto.ServletFramework.Cookie("RANDOM_PUT_COOKIE", "put value");
		monsantoCookie.setExpiration(null);
		helperCommon.addCookie(monsantoCookie);
		javax.servlet.http.Cookie javaCookie = (javax.servlet.http.Cookie) response.getCookies().get(0);
		assertEquals(getMaxAgeDefaultValue(), javaCookie.getMaxAge());
	}

	public void testAddCookie_DoesNotSetMaxAgeOnJavaCookie_IfExpirationDateOnMonsantoCookieExistsInPast() throws Exception {
		InvocationContext invocation = servletUnitClient.newInvocation(TEST_SERVLET_URL);
		MockHttpServletResponse response = new MockHttpServletResponse();
		UCCHelperCommon helperCommon = new UCCHelperCommon(invocation.getRequest(), response);
		com.monsanto.ServletFramework.Cookie monsantoCookie = new com.monsanto.ServletFramework.Cookie("RANDOM_PUT_COOKIE", "put value");
		monsantoCookie.setExpiration(new SimpleDateFormat("mm/dd/yyyy").parse("07/07/2007"));
		helperCommon.addCookie(monsantoCookie);
		javax.servlet.http.Cookie javaCookie = (javax.servlet.http.Cookie) response.getCookies().get(0);
		assertEquals(getMaxAgeDefaultValue(), javaCookie.getMaxAge());
	}

	private void validateMaxAge(int numberOfDays, javax.servlet.http.Cookie javaCookie) {
		int expectedMaxAge = getSeconds(numberOfDays);
		int actualMaxAge = javaCookie.getMaxAge();
		assertTrue(actualMaxAgeIsWithinAcceptableRangeConsideringDelayInRunningTest(actualMaxAge, expectedMaxAge));
	}

	private boolean actualMaxAgeIsWithinAcceptableRangeConsideringDelayInRunningTest(int actualMaxAge, int expectedMaxAge) {
		return actualMaxAge >= expectedMaxAge - EXPECTED_MAX_DELAY_IN_RUNNING_TEST_IN_SECONDS && actualMaxAge <= expectedMaxAge;
	}

	private int getMaxAgeDefaultValue() {
		return -1;
	}

	private int getSeconds(int numberofDays) {
		return numberofDays * 24 * 60 * 60;
	}

	private Date getDateNumberOfDaysFromToday(int numberOfDays) {
		return new Date(new Date().getTime() + new Long(numberOfDays * 24 * 60 * 60 * 1000).longValue());
	}
}