/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.MultiPart.FilePart;
import com.monsanto.ServletFramework.MultiPart.MultipartParser;
import com.monsanto.Util.fileutil.FileUtil;
import junit.framework.TestCase;

import javax.servlet.http.HttpServletRequest;
import java.io.File;

/**
 * Filename:    $RCSfile: MultipartParser_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ardharn $    	 On:	$Date: 2007-09-12 22:56:16 $
 *
 * @author paprit
 * @version $Revision: 1.8 $
 */
public class MultipartParser_UT extends TestCase {
  public MultipartParser_UT(String name) {
    super(name);
  }

  public void testOneFilePart() throws Exception {
    HttpServletRequest request = new MockHttpServletRequest(0);
    MultipartParser parser = new MultipartParser(request, 1000);
    FilePart part = (FilePart) parser.readNextPart();
    assertEquals("field1", part.getName());
    assertTrue(part.isFile());
    assertFalse(part.isParam());
    assertEquals("file1.txt", part.getFileName());
    assertEquals("type/subtype", part.getContentType());
    File fileToCreate = new File(part.getFileName());
    part.writeTo(fileToCreate);
    String content = FileUtil.readFileToString(fileToCreate);
    assertEquals("This is content line 1.\r\nThis is content line 2.", content);
  }

  public void testOneNullReadLineBeforeFilePart() throws Exception {
    HttpServletRequest request = new MockHttpServletRequest(1);
    MultipartParser parser = new MultipartParser(request, 1000);
    FilePart part = (FilePart) parser.readNextPart();
    assertEquals("field1", part.getName());
    assertTrue(part.isFile());
    assertFalse(part.isParam());
    assertEquals("file1.txt", part.getFileName());
    assertEquals("type/subtype", part.getContentType());
    File fileToCreate = new File(part.getFileName());
    part.writeTo(fileToCreate);
    String content = FileUtil.readFileToString(fileToCreate);
    assertEquals("This is content line 1.\r\nThis is content line 2.", content);
  }
}