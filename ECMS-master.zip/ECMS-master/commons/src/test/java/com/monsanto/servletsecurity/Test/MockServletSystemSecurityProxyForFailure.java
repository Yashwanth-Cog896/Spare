package com.monsanto.servletsecurity.Test;

import javax.servlet.http.HttpServletRequest;

/*
 MockServletSystemSecurityProxyForFailure was created on Jun 29, 2005 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto Co.
 */

public class MockServletSystemSecurityProxyForFailure extends MockServletSystemSecurityProxy {
    public void init(HttpServletRequest request) {
        throw new RuntimeException("Mock");
    }
}
