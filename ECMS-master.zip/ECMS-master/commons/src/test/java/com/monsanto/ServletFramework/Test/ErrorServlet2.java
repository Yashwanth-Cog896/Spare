package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.GatewayServlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 4:45:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class ErrorServlet2 extends GatewayServlet {
  public ErrorServlet2() {
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		super.doGet(request, response);
//    respond(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		super.doPost(request, response);
//    respond(request, response);
  }

//  private void respond(HttpServletRequest request, HttpServletResponse response) {
//    UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);
//    helper.reportError(new IOException("Big I/O Error"));
//  }
}
