package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.FormRequestData;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Nov 16, 2005
 * Time: 5:24:03 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FormWithListData extends FormRequestData {
  Object getMapDataMapped(String key);

  void setMapDataMapped(String key, Object value);

  MyStuff getListData(int index);

  void setListData(int index, MyStuff value);

  String getStringListData(int index);

  void setStringListData(int index, String value);

  String getStuff();

  void setStuff(String stuff);

  int getAmount();

  void setAmount(int amount);

  boolean isHuh();

  void setHuh(boolean huh);

  MyStuff getMyNestedStuff();
}
