/*
 MockNotificationSource was created on Nov 23, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.NotificationSource;

/**
 * <p>Title: MockNotificationSource</p> <p>Description: <p>Copyright: Copyright (c) 2004</p> <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: MockNotificationSource.java,v 1.10 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockNotificationSource implements NotificationSource
{
   private boolean m_boolNotified = false;
   private String m_cstrMessage = "";

   public void notify(String cstrMessage)
   {
      m_boolNotified = true;
      m_cstrMessage = cstrMessage;
   }

   public boolean wasNotified()
   {
      return m_boolNotified;
   }

   public boolean messageWas(String cstrExpectedMessage)
   {
      return m_cstrMessage.equals(cstrExpectedMessage);
   }
}
