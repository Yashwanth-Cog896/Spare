package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.GatewayServlet;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 3:35:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class PassThroughServlet extends GatewayServlet {

  public PassThroughServlet() {
		super(500);
  }
}
