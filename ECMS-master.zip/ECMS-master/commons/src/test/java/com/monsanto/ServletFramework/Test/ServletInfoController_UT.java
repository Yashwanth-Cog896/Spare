package com.monsanto.ServletFramework.Test;

import com.meterware.httpunit.WebResponse;
import com.meterware.servletunit.InvocationContext;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import junit.framework.TestCase;
import org.xml.sax.SAXException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Hashtable;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 4:58:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServletInfoController_UT extends TestCase {
	private ServletRunner m_sr = new ServletRunner();
	private ServletUnitClient m_sc = m_sr.newClient();
	private static final String TEST_SERVLET_URL = "http://localhost:8080/testServlet";
	private final String LINE_SEP = System.getProperty("line.separator");

	protected void setUp() throws Exception {
		m_sr.registerServlet("testServlet", testServlet.class.getName());
		registerServletForTest("ServletInfoServlet", ServletInfoServlet.class.getName());
	}

	public void testServletInfoController() throws Exception {
		String text = getTextFromInvokingServletByForward("ServletInfoServlet");
		assertTextContainsValue(text, "<TITLE>SERVLET INFO</TITLE>");
		String expectedInitParms = "Init Parameters:" + LINE_SEP + "<tr>" + LINE_SEP + "<td>initparm2</td>" + LINE_SEP +
						"<td>value2</td>" + LINE_SEP + "</tr>" + LINE_SEP + "<tr>" + LINE_SEP + "<td>initparm1</td>" + LINE_SEP +
						"<td>value1</td>" + LINE_SEP + "</tr>";
		assertTextContainsValue(text, expectedInitParms);
		assertTextContainsValue(text, "Current Working Folder:");
		String expectedContextAtts = "Context Attributes:" + LINE_SEP + "<tr>" + LINE_SEP + "<td>contextAttribute1</td>" +
						LINE_SEP + "<td>contextAttributeValue1</td>" + LINE_SEP + "</tr>";
		assertTextContainsValue(text, expectedContextAtts);
		assertTextContainsValue(text, "System Properties:");
		String expectedJavaHome = "<td>java.home</td>"+LINE_SEP+
						"<td>"+System.getProperty("java.home")+"</td>";
		assertTextContainsValue(text, expectedJavaHome);
		assertTextContainsValue(text, "XML Properties:");
		assertTextContainsValue(text, "version.xerces2=Xerces-J");
		assertTextContainsValue(text, "Database Properties:");
		//Didn't assert anything about persistent store because I don't want to assume that using the ServletFramework
		//package "requires" the dataservices package.
    assertTextContainsValue(text, "Memory usage");
    assertTextContainsValue(text, "Total memory");
    assertTextContainsValue(text, "Free memory");
    assertTextContainsValue(text, "Max memory");
	}

	private void registerServletForTest(String name, String className) {
		Hashtable initParms = new Hashtable();
		initParms.put("initparm1", "value1");
		initParms.put("initparm2", "value2");
		m_sr.registerServlet(name, className, initParms);
	}

	public void testRun_OutputApplicationSpecificInformation_Invoked() throws Exception {
		registerServletForTest("ServletInfoAppSpecificServlet", ServletInfoAppSpecificServlet.class.getName());
		String text = getTextFromInvokingServletByForward("ServletInfoAppSpecificServlet");
		assertTextContainsValue(text, "HELLO WORLD FROM APPLICATION SPECIFIC");
	}

	private void assertTextContainsValue(String text, String str) {
		assertTrue(text.indexOf(str) != -1);
	}

	private String getTextFromInvokingServletByForward(String name) throws IOException, ServletException, SAXException {
		InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
		HttpServletRequest requ = invocation.getRequest();
		HttpServletResponse resp = invocation.getResponse();
		ServletConfig conf = null;
		UCCHelper helper = new UCCServletHelper(conf, requ, resp);
		invocation.getServlet().getServletConfig().getServletContext().setAttribute("contextAttribute1", "contextAttributeValue1");
		helper.forward(name);
		WebResponse response = m_sc.getResponse(invocation);
		return response.getText();
	}

}
