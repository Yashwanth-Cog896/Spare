/*
 MockPerformanceLog was created on Apr 16, 2005 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.IPerformanceLog;

/**
 * <p>Title: MockPerformanceLog</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: MockPerformanceLog.java,v 1.11 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockPerformanceLog extends MockLog implements IPerformanceLog
{
   public MockPerformanceLog()
   {
      super(0);
   }

   public MockPerformanceLog(int iID)
   {
      super(iID);
   }

   public String name()
   {
      return "MockLog.Performance";
   }

   public String type()
   {
      return "PERFORMANCE";
   }

   /**
    * Closes the log.
    */
   public void close()
   {
   }
}
