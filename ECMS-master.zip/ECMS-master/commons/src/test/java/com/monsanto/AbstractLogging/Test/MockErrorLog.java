/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.IErrorLog;

/**
 * <p>Title: MockErrorLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockErrorLog.java,v 1.13 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockErrorLog extends MockLog implements IErrorLog
{
   private String[] m_cstrLogDeviceTypes_a = new String[2];
   private String[] m_cstrLogDeviceLocations_a = new String[2];

   public MockErrorLog ()
   {
      super(0);

      m_cstrLogDeviceTypes_a[0] = "DeviceType1";
      m_cstrLogDeviceTypes_a[1] = "DeviceType2";

      m_cstrLogDeviceLocations_a[0] = "Location1";
      m_cstrLogDeviceLocations_a[1] = "Location2";
   }

   public MockErrorLog(int iID)
   {
      super(iID);
   }

   public String name()
   {
      return "MockLog.Error";
   }

   public String type()
   {
      return "ERROR";
   }

   public int numLogDevices()
   {
      return m_cstrLogDeviceTypes_a.length;
   }

   /**
    * Returns a string identifying the log device type.  Examples of a log device
    * type are "MidnightRolling", "XML", and "Database".
    *
    * @param j The index of the log device.
    * @return The device type.
    */
   public String getLogDeviceType(int j)
   {
      return m_cstrLogDeviceTypes_a[j];
   }

   /**
    * Returns location where the log device outputs its results.  For example,
    * this may be a disk file or a database.
    *
    * @param j The index of the log device.
    * @return The device's output location.
    */
   public String getLogDeviceLocation(int j)
   {
      return m_cstrLogDeviceLocations_a[j];
   }

   /**
    * Closes the log.
    */
   public void close()
   {
   }
}
