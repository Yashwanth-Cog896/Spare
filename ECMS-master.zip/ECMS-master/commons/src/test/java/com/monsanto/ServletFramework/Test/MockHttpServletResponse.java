/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ServletFramework.Test;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.Vector;

/**
 * Filename:    $RCSfile: MockHttpServletResponse.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ardharn $    	 On:	$Date: 2007-09-12 22:56:14 $
 *
 * @author SCBALE
 * @version $Revision: 1.6 $
 */
public class MockHttpServletResponse implements HttpServletResponse {
  private Vector cookies = new Vector();

  public Vector getCookies() {
    return cookies;
  }

  public void addCookie(Cookie cookie) {
    cookies.add(cookie);
  }

  public boolean containsHeader(String string) {
    return false;
  }

  public String encodeURL(String string) {
    return null;
  }

  public String encodeRedirectURL(String string) {
    return null;
  }

  public void sendError(int i, String string) throws IOException {
  }

  public void sendError(int i) throws IOException {
  }

  public void sendRedirect(String string) throws IOException {
  }

  public void setDateHeader(String string, long l) {
  }

  public void addDateHeader(String string, long l) {
  }

  public void setHeader(String string, String string1) {
  }

  public void addHeader(String string, String string1) {
  }

  public void setIntHeader(String string, int i) {
  }

  public void addIntHeader(String string, int i) {
  }

  public void setStatus(int i) {
  }

  public String encodeUrl(String string) {
    return null;
  }

  public String encodeRedirectUrl(String string) {
    return null;
  }

  public void setStatus(int i, String string) {
  }


  public String getCharacterEncoding() {
    return null;
  }

  public String getContentType() {
    return null;
  }

  public ServletOutputStream getOutputStream() throws IOException {
    return null;
  }

  public PrintWriter getWriter() throws IOException {
    return null;
  }

  public void setCharacterEncoding(String string) {
  }

  public void setContentLength(int i) {
  }

  public void setContentType(String string) {
  }

  public void setBufferSize(int i) {
  }

  public int getBufferSize() {
    return 0;
  }

  public void flushBuffer() throws IOException {
  }

  public void resetBuffer() {
  }

  public boolean isCommitted() {
    return false;
  }

  public void reset() {
  }

  public void setLocale(Locale locale) {
  }

  public Locale getLocale() {
    return null;
  }
}