/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.IDebugLog;
import com.monsanto.AbstractLogging.Logger;

/**
 * <p>Title: MockDebugLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockDebugLog.java,v 1.14 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockDebugLog extends MockLog implements IDebugLog
{
   private boolean m_boolCloseCalled = false;

   public MockDebugLog ()
   {
        super(0);
   }

	 public MockDebugLog(int iID)
	 {
			super(iID);
	 }

	 public String name()
	 {
			return "MockLog.Debug";
	 }

	 public String type()
	 {
			return "DEBUG";
	 }

   /**
    * Closes the log.
    */
   public void close()
   {
      m_boolCloseCalled = true;
   }

   public String getLoggerName() {
      return Logger.DEBUG_LOG;
   }

   public boolean isClosed()
   {
      return m_boolCloseCalled;
   }
}
