/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ServletFramework.Test;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.util.Enumeration;
import java.util.Hashtable;

public class MockHttpSession implements HttpSession {

  private Hashtable attributes= new Hashtable();

  public MockHttpSession() {
    super();
  }

  public long getCreationTime() {
    return 0;
  }

  public String getId() {
    return null;
  }

  public long getLastAccessedTime() {
    return 0;
  }

  public ServletContext getServletContext() {
    return null;
  }

  public void setMaxInactiveInterval(int arg0) {

  }

  public int getMaxInactiveInterval() {
    return 0;
  }

  public HttpSessionContext getSessionContext() {
    return null;
  }

  private int getAttributeCalls;
  public Object getAttribute(String arg0) {
    getAttributeCalls++;
    return attributes.get(arg0);
  }

  public int getGetAttributeCalls() {
    return getAttributeCalls;
  }

  public Object getValue(String arg0) {
    return null;
  }

  private int getAttributeNamesCalls;
  public Enumeration getAttributeNames() {
    getAttributeNamesCalls++;
    return attributes.keys();
  }

  public int getGetAttributeNamesCalls() {
    return getAttributeNamesCalls;
  }

  public String[] getValueNames() {
    return null;
  }

  private int setAttributeCalls;
  public void setAttribute(String arg0, Object arg1) {
    setAttributeCalls++;
    attributes.put(arg0, arg1);
  }

  public int getSetAttributeCalls() {
    return setAttributeCalls;
  }

  public void putValue(String arg0, Object arg1) {

  }

  private int removeAttributeCalls;
  public void removeAttribute(String arg0) {
    removeAttributeCalls++;
    attributes.remove(arg0);
  }

  public int getRemoveAttributeCalls() {
    return removeAttributeCalls;
  }

  public void removeValue(String arg0) {

  }

  private int invalidateCalls = 0;
  public void invalidate() {
    invalidateCalls++;
  }

  public int getInvalidateCalls() {
    return invalidateCalls;
  }

  public boolean isNew() {
    return false;
  }

  public boolean hasAttribute(String attributeKey) {
    Enumeration enu = getAttributeNames();
    boolean hasAttribute = false;
    while (!hasAttribute && enu.hasMoreElements()) {
      String key = (String)enu.nextElement();
      hasAttribute = key.equals(attributeKey);
    }
    return hasAttribute;
  }

}