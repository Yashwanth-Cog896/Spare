/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.IWarningLog;

/**
 * <p>Title: MockWarningLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockWarningLog.java,v 1.13 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockWarningLog extends MockLog implements IWarningLog
{
   private boolean m_boolCloseCalled = false;

   public MockWarningLog ()
   {
      super(0);
   }

   public MockWarningLog (int iID)
   {
      super(iID);
   }

   public String name()
   {
      return "MockLog.Warning";
   }

   public String type()
   {
      return "WARNING";
   }

   /**
    * Closes the log.
    */
   public void close()
   {
      m_boolCloseCalled = true;
   }

   public boolean isClosed()
   {
      return m_boolCloseCalled;
   }
}
