package com.monsanto.ServletFramework.Test;

import junit.framework.TestCase;
import org.apache.commons.beanutils.BeanUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 7, 2005
 * Time: 3:07:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class FormRequestData_UT extends TestCase {

	// Note: The FormRequestData interface's behavior is tested more thoroughly in UCCServletHelper_UT
	
  public void testPopulateWithSubClass() throws Exception {
    Map map = new HashMap();
    String expectedString = "a string";
    int expectedInt = 42;
    boolean expectedBoolean = true;

    map.put("stuff", expectedString);
    map.put("amount", new Integer(expectedInt));
    map.put("huh", new Boolean(expectedBoolean));

    MockConcreteForm data = new MockConcreteForm();
    BeanUtils.populate(data, map);

    assertEquals(expectedString, data.getStuff());
    assertEquals(expectedInt, data.getAmount());
    assertEquals(expectedBoolean, data.isHuh());

  }
}
