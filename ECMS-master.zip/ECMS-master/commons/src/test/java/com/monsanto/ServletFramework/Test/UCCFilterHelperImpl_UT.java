package com.monsanto.ServletFramework.Test;

/**
 * Created by IntelliJ IDEA.
 * User: sdshan1
 * Date: Sep 16, 2005
 * Time: 9:21:54 AM
 * To change this template use File | Settings | File Templates.
 */

import com.meterware.httpunit.cookies.CookieProperties;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.UCCFilterHelperImpl;
import junit.framework.TestCase;

import javax.servlet.http.Cookie;
import java.util.Enumeration;

public class UCCFilterHelperImpl_UT extends TestCase implements ServletRunnerClientConfigurable{
  private ServletRunner m_sr = new ServletRunner();
  private ServletUnitClient m_sc = m_sr.newClient();
  private static final String TEST_SERVLET_URL = "http://localhost:7080/testServlet";

  public UCCFilterHelperImpl_UT() {
    m_sr.registerServlet("testServlet/*", testServlet.class.getName());
  }

  public void testGetCookies() throws Exception {
    CookieProperties.setDomainMatchingStrict(false);
    CookieProperties.setPathMatchingStrict(false);
    String FIRST_COOKIE = "RANDOM_COOKIE";
    String SECOND_COOKIE = "ANOTHER_COOKIE";
    String FIRST_COOKIE_VALUE = "cookie1";
    String SECOND_COOKIE_VALUE = "cookie2";
    m_sc.putCookie(FIRST_COOKIE, FIRST_COOKIE_VALUE);
    m_sc.putCookie(SECOND_COOKIE, SECOND_COOKIE_VALUE);
    UCCFilterHelperImpl helper = UCCHelperTestUtil.getFilterHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

    Cookie[] cookies = helper.getCookies();
    Cookie firstActualCookie = cookies[0];
    Cookie secondActualCookie = cookies[1];

    assertEquals(FIRST_COOKIE, firstActualCookie.getName());
    assertEquals(SECOND_COOKIE, secondActualCookie.getName());

    assertEquals(FIRST_COOKIE_VALUE, firstActualCookie.getValue());
    assertEquals(SECOND_COOKIE_VALUE, secondActualCookie.getValue());
  }

  public void testRequestedURL() throws Exception {
    UCCFilterHelperImpl helper = UCCHelperTestUtil.getFilterHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

    String cstrURL = helper.requestedURL();
    assertEquals("http://localhost/testServlet", cstrURL);
  }

  public void testGetHeader() throws Exception {
    UCCFilterHelperImpl helper = UCCHelperTestUtil.getFilterHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

    String userAgent = helper.getHeader("User-Agent");
    assertTrue(userAgent.startsWith("httpunit"));
  }

  public void testGetHeaderNames() throws Exception {
    UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
    UCCFilterHelperImpl helper = UCCHelperTestUtil.getFilterHelperUsingInvocationContextForURL(
      UCCServletHelper_UT.BEAN_TEST_SERVLET_URL + "?huh=true", m_sc);
    String[] names = helper.getHeaderNames();
    assertEquals(3, names.length);
    assertEquals("User-Agent", names[0]);
    assertEquals("Accept-Encoding", names[1]);
    assertEquals("Content-Length", names[2]);
  }

  public void testRequestParametersMethods() throws Exception {
    UCCFilterHelperImpl helper = UCCHelperTestUtil.getFilterHelperUsingInvocationContextForURL(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true", m_sc);
    assertEnumerationSize(2, helper.getParameterNames());
    Enumeration enumeration = helper.getParameterNames();
    String firstElement = (String) enumeration .nextElement();
    assertEquals("outfile", firstElement);
    String secondElement = (String) enumeration .nextElement();
    assertEquals("mtype", secondElement);

    String outfileValue = helper.getRequestParameterValue("outfile");
    assertEquals("true", outfileValue);

    String[] values = helper.getRequestParameterValues("outfile");
    assertEquals(1, values.length);
    assertEquals("true", values[0]);
  }


  public void setRunnerClient(ServletRunner runner, ServletUnitClient client) {
    m_sr = runner;
    m_sc = client;
  }

  private void assertEnumerationSize(int expectedSize, Enumeration enumeration) {
    int count = 0;
    for (Enumeration enum1 = enumeration; enum1.hasMoreElements();) {
      enum1.nextElement();
      count++;
    }
    assertEquals(expectedSize, count);
  }
}