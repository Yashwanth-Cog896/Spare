package com.monsanto.ServletFramework.Test;

/*
 MockUCCHelper_UT was created on Jun 29, 2005 using Monsanto
 resources and is the sole property of Monsanto.
 Any duplication of the code and/or logic is a
 direct infringement of Monsanto's copyright.
*/

/**
 * @author Kenneth J. Johnson, TCC, Monsanto Co.
 */

import com.monsanto.ServletFramework.FormattedWriter;
import junit.framework.TestCase;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Even though MockUCCHelper is obviously a mock, it is
 * used across many, many projects, and should have tests to clearly establish its interface.
 */
public class MockUCCHelper_UT extends TestCase {
    private static final String TEST_URL = "MOCK";
    private static final String TEST_PARAM = "Foo";

    private static final String TEST_STRING = "This is a test";
    private static final String[] TEST_STRING_ARRAY = {"Test String 1", "Another Test String"};

    public MockUCCHelper_UT(String name) {
        super(name);
    }

    public void testNullParameterReturnsNull() throws IOException {
        MockUCCHelper helper = new MockUCCHelper(TEST_URL);
        assertNull(helper.getRequestParameterValue(TEST_PARAM));
        assertNull(helper.getRequestParameterValues(TEST_PARAM));
    }

    public void testStringParameterReturnsCorrectly() throws IOException {
        MockUCCHelper helper = new MockUCCHelper(TEST_URL);

        helper.setRequestParameterValue(TEST_PARAM, TEST_STRING);
        assertEquals(TEST_STRING, helper.getRequestParameterValue(TEST_PARAM));

        String[] values = helper.getRequestParameterValues(TEST_PARAM);
        assertEquals(1, values.length);
        assertEquals(TEST_STRING, values[0]);
    }

    public void testObjectParameterReturnsCorrectly() throws IOException {
        MockUCCHelper helper = new MockUCCHelper(TEST_URL);
        MockObject mockObject = new MockObject(1);

        helper.setRequestParameterValue(TEST_PARAM, mockObject);
        assertEquals(mockObject.toString(), helper.getRequestParameterValue(TEST_PARAM));

        String[] values = helper.getRequestParameterValues(TEST_PARAM);
        assertEquals(1, values.length);
        assertEquals(mockObject.toString(), values[0]);
    }

    public void testStringArrayParameterReturnsCorrectly() throws IOException {
        MockUCCHelper helper = new MockUCCHelper(TEST_URL);

        helper.setRequestParameterValue(TEST_PARAM, TEST_STRING_ARRAY);
        assertEquals(TEST_STRING_ARRAY[0], helper.getRequestParameterValue(TEST_PARAM));

        String[] values = helper.getRequestParameterValues(TEST_PARAM);
        assertEquals(TEST_STRING_ARRAY.length, values.length);
        for (int i = 0; i < values.length; i++) {
            assertEquals(TEST_STRING_ARRAY[i], values[i]);
        }
    }

    public void testObjectArrayParameterReturnsCorrectly() throws IOException {
        MockUCCHelper helper = new MockUCCHelper(TEST_URL);
        MockObject[] mockObjectArray = new MockObject[10];
        for (int i = 0; i < mockObjectArray.length; i++) {
            mockObjectArray[i] = new MockObject(i);
        }

        helper.setRequestParameterValue(TEST_PARAM, mockObjectArray);
        assertEquals(mockObjectArray[0].toString(), helper.getRequestParameterValue(TEST_PARAM));

        String[] values = helper.getRequestParameterValues(TEST_PARAM);
        assertEquals(mockObjectArray.length, values.length);
        for (int i = 0; i < values.length; i++) {
            assertEquals(mockObjectArray[i].toString(), values[i]);
        }
    }

    public void testGetRequestURIReturnsCorrectValueInSimplestCase()  {
        String address = "http://www.myserver.com/test.html";
        MockUCCHelper helper = new MockUCCHelper(address);

        assertEquals("/test.html", helper.getRequestURI());
    }

    public void testGetRequestURIReturnsCorrectValueTwoLevelsDeep()  {
        String address = "http://www.myserver.com/mytest/test.html";
        MockUCCHelper helper = new MockUCCHelper(address);

        assertEquals("/mytest/test.html", helper.getRequestURI());
    }

    public void testGetRequestURIRemovesQueryParameters()  {
        String address = "http://www.myserver.com/test.html?param1=test&param2=test";
        MockUCCHelper helper = new MockUCCHelper(address);

        assertEquals("/test.html", helper.getRequestURI());
    }

    public void testGetRequestURICanHandleURLsWithoutServerName()  {
        String address = "/test.html";
        MockUCCHelper helper = new MockUCCHelper(address);

        assertEquals("/test.html", helper.getRequestURI());
    }

    public void testGetRequestURIRemovesQueryParamsWithoutServerName()  {
        String address = "/test.html?param1=test";
        MockUCCHelper helper = new MockUCCHelper(address);

        assertEquals("/test.html", helper.getRequestURI());
    }

    public void testGetFormattedWriter() throws Exception{
        MockUCCHelper helper = new MockUCCHelper(null);
        FormattedWriter mockWriter = new FormattedWriter(){public void write(OutputStream os){}};
        helper.writeToFormattedWriter(mockWriter);
        assertSame(mockWriter, helper.getFormattedWriter());
    }

    public void testScratchFolderIsSettable() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        String scratchFolder = helper.getScratchFolder();
        assertNotNull(scratchFolder);
        assertEquals(System.getProperty("java.io.tmpdir"), scratchFolder);

        String newScratchFolder = System.getProperty("java.io.tmpdir") + "1" + File.separator;
        helper.setScratchFolder(newScratchFolder);
        assertEquals(newScratchFolder, helper.getScratchFolder());
    }

    class MockObject {
        private int id;

        public MockObject(int id) {
            this.id = id;
        }

        public String toString() {
            return "This is mock object #" + id;
        }
    }
}
