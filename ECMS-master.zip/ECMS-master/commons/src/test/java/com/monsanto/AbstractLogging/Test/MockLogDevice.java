/*
 MockLogDevice was created on Jun 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.ILog;
import com.monsanto.AbstractLogging.LogDevice;

import java.util.ArrayList;

/**
 * <p>Title: MockLogDevice</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockLogDevice.java,v 1.15 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockLogDevice implements LogDevice
{
   private boolean m_boolCloseCalled = false;

   public MockLogDevice ()
   {
   }

   public int attach (ILog log)
   {
      return 1;
   }

   /**
    * Returns the output strategies of LogDevice.
    *
    * @return A String array with each element of the array containing the name
    *         of an output strategy.  For example: Console, MidnightRollingFile.
    */
   public ArrayList logDeviceTypes()
   {
      ArrayList RetVal = new ArrayList();

      RetVal.add("MockLogDevice");

      return RetVal;
   }

   /**
    * Returns the output media of LogDevice.
    *
    * @return A String array with each element of the array containing the name
    *         of an output location.  For example: Console, c:\\Logs\MyApp.log.
    */
   public ArrayList logDeviceLocations()
   {
      ArrayList RetVal = new ArrayList();

      RetVal.add("Internal Structure");

      return RetVal;
   }

   public void close()
   {
      m_boolCloseCalled = true;
   }

   public boolean contains(String s)
   {
      return false;  //To change body of created methods use File | Settings | File Templates.
   }

   public boolean wasClosed()
   {
      return m_boolCloseCalled;
   }
}
