package com.monsanto.ServletFramework.Test;

import com.meterware.servletunit.InvocationContext;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.UCCFilterHelperImpl;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCHelperCommon;
import com.monsanto.ServletFramework.UCCServletHelper;
import org.xml.sax.SAXException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: sdshan1
 * Date: Sep 16, 2005
 * Time: 9:27:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class UCCHelperTestUtil {
  public static UCCHelper getHelperUsingInvocationContextForURL(String testServletUrl, ServletUnitClient servletUnitClient) throws Exception
  {
    InvocationContext invocation = servletUnitClient.newInvocation(testServletUrl);
    return getHelperUsingInvocationContext(invocation);
  }

  public static UCCFilterHelperImpl getFilterHelperUsingInvocationContextForURL(String testServletUrl, ServletUnitClient servletUnitClient) throws Exception
  {
    InvocationContext invocation = servletUnitClient.newInvocation(testServletUrl);
    return getFilterHelperUsingInvocationContext(invocation);
  }

  public static UCCHelper getHelperUsingInvocationContext(InvocationContext invocation) throws ServletException
  {
    HttpServletRequest requ = invocation.getRequest();
    HttpServletResponse resp = invocation.getResponse();
    ServletConfig conf = invocation.getServlet().getServletConfig();
    return new UCCServletHelper(conf, requ, resp);
  }

  public static UCCFilterHelperImpl getFilterHelperUsingInvocationContext(InvocationContext invocation)
  {
    HttpServletRequest requ = invocation.getRequest();
    HttpServletResponse resp = invocation.getResponse();
    return new UCCFilterHelperImpl(requ, resp);
  }

  public static UCCHelperCommon getHelperCommonUsingInvocationContextForURL(String testServletUrl, ServletUnitClient servletUnitClient) throws IOException
  {
    InvocationContext invocation = servletUnitClient.newInvocation(testServletUrl);
    HttpServletRequest request = invocation.getRequest();
    HttpServletResponse response = invocation.getResponse();

    return new UCCHelperCommon(request, response);
  }

  public static void setupRunnerAndClientWithWEBXML(ServletRunnerClientConfigurable unitTest,
																										String pathOfWebXmlFile) throws IOException, SAXException
  {
    InputStream stream = new FileInputStream(new File(pathOfWebXmlFile));
    ServletRunner runner = new ServletRunner(stream);
    unitTest.setRunnerClient(runner, runner.newClient());
  }

}
