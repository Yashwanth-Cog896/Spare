package com.monsanto.ServletFramework.Test;

import junit.framework.Test;
import junit.framework.TestSuite;


public class ServletFramework_TS extends TestSuite {
  public static Test suite() {
    TestSuite aSuite = new TestSuite();

    aSuite.addTestSuite(UCCManager_UT.class);
    aSuite.addTestSuite(UCCServletHelper_UT.class);
    aSuite.addTestSuite(UCCHelperCommon_UT.class);
    aSuite.addTestSuite(ServletInfoController_UT.class);
    aSuite.addTestSuite(PingServletController_UT.class);
    aSuite.addTestSuite(GatewayServlet_UT.class);
    aSuite.addTestSuite(DoubleHitBlocker_UT.class);
    aSuite.addTestSuite(MockUCCHelper_UT.class);
    aSuite.addTestSuite(UCCFilterHelperImpl_UT.class);
    aSuite.addTestSuite(FormDataFactory_UT.class);
    aSuite.addTestSuite(FormRequestData_UT.class);

    //ToDo: Need more specific tests for: MultipartRequest
    aSuite.addTestSuite(MultipartRequest_UT.class);

    return aSuite;
  }
}
