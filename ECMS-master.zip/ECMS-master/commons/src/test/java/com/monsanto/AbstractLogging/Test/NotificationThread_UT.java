/*
 NotificationThread_UT was created on Nov 23, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.NotificationSource;
import com.monsanto.AbstractLogging.NotificationThread;
import junit.framework.TestCase;

/**
 * <p>Title: NotificationThread_UT</p> <p>Description: <p>Copyright: Copyright (c) 2004</p> <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: NotificationThread_UT.java,v 1.12 2007/09/12 22:31:42 ardharn Exp $
 */
public class NotificationThread_UT extends TestCase {
    public NotificationThread_UT(String s) {
        super(s);
    }

    public void testCreate() {
        NotificationSource notifyMe = new MockNotificationSource();

        NotificationThread thread = new NotificationThread(1, notifyMe, "Message");
        assertNotNull(thread);
    }

    public void testThreadNotifiesIfTimeoutExceeded() throws InterruptedException {
        MockNotificationSource notifyMe = new MockNotificationSource();

        NotificationThread thread = new NotificationThread(1, notifyMe, "Message");

        thread.start();

        Thread.sleep(1500);

        assertTrue(notifyMe.wasNotified());
    }

    public void testThreadDoesNotNotifyIfTimeoutNotExceeded() throws InterruptedException {
        MockNotificationSource notifyMe = new MockNotificationSource();

        NotificationThread thread = new NotificationThread(1, notifyMe, "Message");

        thread.start();

        Thread.sleep(100);

        thread.interrupt();
        assertFalse(notifyMe.wasNotified());

        Thread.sleep(1500);  // Be sure there are not zombie notifications
        assertFalse(notifyMe.wasNotified());
    }

    public void testThreadDoesNotNotifyIfInterrupted() throws InterruptedException {
        MockNotificationSource notifyMe = new MockNotificationSource();

        NotificationThread thread = new MockNotificationThread(1, notifyMe, "Message");

        thread.start();
        assertFalse(notifyMe.wasNotified());

        Thread.sleep(1500);  // Be sure there are not zombie notifications
        assertFalse(notifyMe.wasNotified());
    }

    public void testNotificationGetsCorrectMessage() throws InterruptedException {
        MockNotificationSource notifyMe = new MockNotificationSource();

        NotificationThread thread = new NotificationThread(1, notifyMe, "Message");

        thread.start();

        Thread.sleep(1500);

        assertTrue(notifyMe.messageWas("Message"));
    }

    class MockNotificationThread extends NotificationThread {
        public MockNotificationThread(int iTimeoutSec, NotificationSource notificationSource, String cstrMessage) {
            super(iTimeoutSec, notificationSource, cstrMessage);
        }

        public boolean isInterrupted() {
            return true;
        }
    }
}
