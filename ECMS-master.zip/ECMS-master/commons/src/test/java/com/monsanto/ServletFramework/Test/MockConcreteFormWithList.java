package com.monsanto.ServletFramework.Test;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 7, 2005
 * Time: 3:07:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockConcreteFormWithList implements FormWithListData {

  private String stuff;
  private int amount;
  private boolean huh;
  private List listData = new ArrayList();
  private MyStuff myNestedStuff;
  private List stringListData = new ArrayList();
  private Map mapData = new HashMap();

  public MockConcreteFormWithList() {
    amount = 43;
  }

  public Object getMapDataMapped(String key) {
    return mapData.get(key);
  }

  public void setMapDataMapped(String key, Object value) {
    mapData.put(key,value);
  }

  public int getSize() {
    return listData.size();
  }

  public MyStuff getMyNestedStuff() {
    return myNestedStuff;
  }

  public void setMyNestedStuff(MyStuff myNestedStuff) {
    this.myNestedStuff = myNestedStuff;
  }

  public MyStuff getListData(int index) {
    return (MyStuff) listData.get(index);
  }

  public void setListData(int index, MyStuff value) {
    listData.set(index, value);
  }

  public String getStringListData(int index) {
    return (String) stringListData.get(index);
  }

  public void setStringListData(int index, String value) {
    stringListData.set(index, value);
  }

  public String getStuff() {
    return stuff;
  }

  public void setStuff(String stuff) {
    this.stuff = stuff;
  }

  public int getAmount() {
    return amount;
  }

  public void setAmount(int amount) {
    this.amount = amount;
  }

  public boolean isHuh() {
    return huh;
  }

  public void setHuh(boolean huh) {
    this.huh = huh;
  }

}

