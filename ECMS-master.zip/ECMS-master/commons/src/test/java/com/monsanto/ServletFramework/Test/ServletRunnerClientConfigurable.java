package com.monsanto.ServletFramework.Test;

import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Jun 6, 2006
 * Time: 5:00:22 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ServletRunnerClientConfigurable {
	void setRunnerClient(ServletRunner runner, ServletUnitClient client);
}
