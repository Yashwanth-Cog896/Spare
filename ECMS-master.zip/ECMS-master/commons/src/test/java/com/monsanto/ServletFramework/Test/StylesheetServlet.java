package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.sun.org.apache.xerces.internal.parsers.DOMParser;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 3:35:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class StylesheetServlet extends GatewayServlet {

  public StylesheetServlet() {
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

  private void respond(HttpServletRequest request, HttpServletResponse response) throws IOException {
    UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);
		try {
			Document inputDoc = getDocument("./com/monsanto/ServletFramework/Test/testXMLfileForStyleSheet.XML");
			String	contentType = (String)request.getAttribute( "encoding" );
			if( contentType == null )
				helper.applyStylesheet( inputDoc, "./com/monsanto/ServletFramework/Test/testStyleSheet.xslt");
			else
				helper.applyStylesheet( inputDoc,
										"./com/monsanto/ServletFramework/Test/testStyleSheet.xslt",
										contentType );
		} catch (SAXException e) {
			throw new IOException(e.toString());
		}
  }

   private Document getDocument (String docName) throws IOException, SAXException {
      File m_XmlFile = new File(docName);
      DOMParser parser = new DOMParser();
      parser.parse(m_XmlFile.toURL().toString());
      Document retVal = parser.getDocument();
      return retVal;
   }
}
