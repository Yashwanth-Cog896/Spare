/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import java.util.ArrayList;

/**
 * <p>Title: MockLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: MockLog.java,v 1.14 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockLog {
    private ArrayList m_Messages;
    private int m_iID;

    public MockLog(int iId) {
        m_Messages = new ArrayList();
        m_iID = iId;
    }

    /**
     * @param cstrMessage
     */
    public void log(String cstrMessage) {
        m_Messages.add(cstrMessage);
    }

    public void removeLogDevices() {
    }


    public int messagesReceived() {
        return m_Messages.size();
    }

    public boolean hasMessageBeenLogged(String cstrMessage) {
        return m_Messages.contains(cstrMessage);
    }

    public boolean hasMessageBeenLoggedStartingWith(String searchString) {
        boolean retVal = false;
        for (int index = 0; index < m_Messages.size(); index++)
        {
            String currentMessage = (String) m_Messages.get(index);
            if (currentMessage.startsWith(searchString))
            {
                retVal = true;
                break;
            }
        }
        return retVal;
    }

    public boolean hasMessageBeenLoggedContaining(String s) {
        boolean boolRetVal = false;

        for (int i = 0; i < m_Messages.size(); i++) {
            String cstrMessage = (String) m_Messages.get(i);
            if (cstrMessage.indexOf(s) != -1) {
                boolRetVal = true;
                break;
            }
        }

        return boolRetVal;
    }

    public boolean equals(Object obj) {
        boolean boolRetVal = false;

        if (obj instanceof MockLog) {
            MockLog ml = (MockLog) obj;

            boolRetVal = (ml.m_iID == m_iID);
        }

        return boolRetVal;
    }

    public int hashCode() {
        return m_iID;
    }

    public int numLogDevices() {
        return 0;
    }

    /**
     * Returns a string identifying the log device type.  Examples of a log device
     * type are "MidnightRolling", "XML", and "Database".
     *
     * @param j The index of the log device.
     * @return The device type.
     */
    public String getLogDeviceType(int j) {
        throw new ArrayIndexOutOfBoundsException(j);
    }

    /**
     * Returns location where the log device outputs its results.  For example,
     * this may be a disk file or a database.
     *
     * @param j The index of the log device.
     * @return The device's output location.
     */
    public String getLogDeviceLocation(int j) {
        throw new ArrayIndexOutOfBoundsException(j);
    }

}
