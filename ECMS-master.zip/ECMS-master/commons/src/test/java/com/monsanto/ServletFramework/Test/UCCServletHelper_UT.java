/*
 UCCServletHelper_UT was created on Mar 5, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework.Test;

import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.PostMethodWebRequest;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.cookies.CookieProperties;
import com.meterware.servletunit.InvocationContext;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.*;
import com.monsanto.Util.fileutil.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import junit.framework.TestCase;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSName;
import org.ietf.jgss.Oid;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>Title: UCCServletHelper_UT</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: UCCServletHelper_UT.java,v 1.70 2007-09-12 22:56:15 ardharn Exp $
 */
public class UCCServletHelper_UT extends TestCase implements ServletRunnerClientConfigurable {
    private ServletRunner m_sr = new ServletRunner();
    private ServletUnitClient m_sc = m_sr.newClient();
    private static final String TEST_SERVLET_URL = "http://localhost:7080/testServlet";
    public static final String BEAN_TEST_SERVLET_URL = "http://localhost:7080/BeanTest";
    public static final String BEAN_TEST_SERVLET_SESSION_URL = "http://localhost:7080/BeanTestSession";
    public static final String BEAN_TEST_WITH_LIST_SERVLET_URL = "http://localhost:7080/BeanTestWithList";
    private static final String BAD_BEAN_TEST_SERVLET_URL = "http://localhost:7080/BadBeanTest";
    private static final String BAD_BEAN_TEST_SERVLET_TOO_MANY_PARMS_URL = "http://localhost:7080/BadBeanTestTooManyParms";
    private static final String NO_SUCH_BEAN_TEST_SERVLET_URL = "http://localhost:7080/NoSuchBeanTest";
    private static final String BAD_DATA_BEAN_TEST_SERVLET_URL = "http://localhost:7080/BadDataBeanTest";
    private static final String INCOMPATIBLE_BEAN_TEST_SERVLET_URL = "http://localhost:7080/IncompatibleBeanTest";
    String USERID = "Userid";
    String FULL_NAME = "FullName";
    public static final String DOMAIN = "NA.DS.MONSANTO.COM";
    static final String OTHER_OUTPUT = "<html>other data</html>";
    private final String LINE_SEP = System.getProperty("line.separator");
	public static final String BACKSLASH = "\\";
	public static final String FORWARD_SLASH = "/";

	public UCCServletHelper_UT(String s) {
        super(s);

        m_sr.registerServlet("testServlet/*", testServlet.class.getName());
    }

  public void test() {

  }

    public void ignore_testCreate() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        assertNotNull(helper);
    }

    public void ignore_testContentTypeIsTextHtmlByDefault() throws Exception {
        WebRequest request = new PostMethodWebRequest(TEST_SERVLET_URL);
        WebResponse response = m_sc.getResponse(request);
        assertNotNull(response);

        assertEquals("text/html", response.getContentType());
    }

    public void ignore_testSetContentType() throws IOException, SAXException {
        m_sr.registerServlet("testServletTextPlainOutput", testServletTextPlainOutput.class.getName());
        ServletUnitClient sc = m_sr.newClient();

        WebRequest request = new PostMethodWebRequest("http://localhost:7080/testServletTextPlainOutput");
        WebResponse response = sc.getResponse(request);
        assertNotNull(response);

        assertEquals("text/plain", response.getContentType());
    }

    public void ignore_testGetResource() throws IOException, SAXException {
        m_sr.registerServlet("testServletGetResource", testServletGetResource.class.getName());
        ServletUnitClient sc = m_sr.newClient();

        WebRequest request = new PostMethodWebRequest("http://localhost:7080/testServletGetResource");
        WebResponse response = sc.getResponse(request);
        assertNotNull(response);

        assertTrue(response.getText().endsWith("ttp:/localhost"));
    }

    public void ignore_testGetScratchFolder() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        String scratchFolderName = helper.getScratchFolder();
        File fScratchFolder = new File(scratchFolderName);

        assertTrue(fScratchFolder.exists());

        helper.deleteScratchFolder();
    }

    public void ignore_testDeleteScratchFolder() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        String scratchFolderName = helper.getScratchFolder();
        File fScratchFolder = new File(scratchFolderName);
        assertTrue(fScratchFolder.exists());

        helper.deleteScratchFolder();
        assertFalse(fScratchFolder.exists());
    }

    public void ignore_testDeleteScratchFolder_NoneCreated() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        helper.deleteScratchFolder();
    }

    public void ignore_testScratchFolderGoesToTempFolderIfScratchFolderCannotBeUsed() throws IOException, ServletException {
        final String cstrTestTempFolderName = "testTemp";

        String cstrOldTempDir = System.getProperty("java.io.tmpdir");
        File testTemp = new File(cstrTestTempFolderName);
        testTemp.mkdir();

        try {
            System.setProperty("java.io.tmpdir", "xxxx");

            InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
            HttpServletRequest requ = invocation.getRequest();
            HttpServletResponse resp = invocation.getResponse();
            ServletConfig conf = invocation.getServlet().getServletConfig();
            conf.getServletContext().setAttribute("javax.servlet.context.tempdir", testTemp);

            UCCHelper helper = new UCCServletHelper(conf, requ, resp);

            String cstrTempDir = helper.getScratchFolder();

            assertNotNull(cstrTempDir);

            String cstrExpected = helper.getTempDirectory().getAbsolutePath() + "\\webapps\\tmp\\" + helper.name();
            assertTrue(cstrTempDir.equalsIgnoreCase(cstrExpected));
        } finally {
            System.setProperty("java.io.tmpdir", cstrOldTempDir);
            FileUtil.deleteAllFilesFromFolder(testTemp);
            testTemp.delete();
        }
    }

    public void ignore_testSetFileImportFolderToRelativePathReturnsOldFolder() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        String cstrImportFileDir1 = helper.setImportFileDir(".");
        String cstrImportFileDir2 = helper.setImportFileDir(cstrImportFileDir1);

        String cstrInitialDirectory = new File(".").getAbsolutePath();
        cstrInitialDirectory = cstrInitialDirectory.substring(0, cstrInitialDirectory.length() - 1);
        assertTrue(cstrImportFileDir2.equals(cstrInitialDirectory));
    }

    public void ignore_testSetFileImportFolderToRelativePathIsSetToScratchFolderByDefault() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        String cstrScratchFolderName = helper.getScratchFolder() + File.separatorChar;
        String cstrImportFileDir = helper.setImportFileDir(".");

        assertTrue(cstrScratchFolderName.equals(cstrImportFileDir));
    }

    public void ignore_testSetFileImportFolderToRelativePathCannotBeSetToNonFolder() throws IOException {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        File tempFile = new File(".\\testFile.txt");
        tempFile.createNewFile();

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        try {
            helper.setImportFileDir(".\\testFile.txt");
            fail();
        } catch (IllegalArgumentException iae) {
            assertTrue(iae.toString().startsWith("java.lang.IllegalArgumentException: Not a directory:"));  //Expected path
        } finally {
            tempFile.delete();
        }
    }

    public void ignore_testFileImportFolderToRelativePathCannotBeSetToReadOnlyFolder() throws IOException {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        File tempFolder = new File(".\\testTempFolder");
        tempFolder.mkdirs();
        tempFolder.setReadOnly();

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        try {
            helper.setImportFileDir(".\\testTempFolder");
            fail();
        } catch (IOException ioe) {
            assertTrue(ioe.toString().startsWith("java.io.IOException: Not writable:"));  //Expected path
        } finally {
            tempFolder.delete();
        }
    }

    public void ignore_testSetFileImportFolderToAbsolutePathReturnsOldFolder() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        String cstrInitialDirectory = new File(".").getAbsolutePath();
        cstrInitialDirectory = cstrInitialDirectory.substring(0, cstrInitialDirectory.length() - 1);

        String cstrImportFileDir1 = helper.setImportFileDir(cstrInitialDirectory, false);
        String cstrImportFileDir2 = helper.setImportFileDir(cstrImportFileDir1, false);

        assertTrue(cstrImportFileDir2.equals(cstrInitialDirectory));
    }

    public void ignore_testFileImportFolderToAbsolutePathIsSetToScratchFolderByDefault() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        String cstrInitialDirectory = new File(".").getAbsolutePath();
        String cstrScratchFolderName = helper.getScratchFolder() + File.separatorChar;
        String cstrImportFileDir = helper.setImportFileDir(cstrInitialDirectory, false);

        assertTrue(cstrScratchFolderName.equals(cstrImportFileDir));
    }

    public void ignore_testFileImportFolderToAbsolutePathCannotBeSetToNonFolder() throws IOException {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        File tempFile = File.createTempFile("abc", ".tmp");

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        try {
            helper.setImportFileDir(tempFile.getAbsolutePath(), false);
            fail();
        } catch (IllegalArgumentException iae) {
            assertTrue(iae.toString().startsWith("java.lang.IllegalArgumentException: Not a directory:"));  //Expected path
        } finally {
            tempFile.delete();
        }
    }

    public void ignore_testFileImportFolderToAbsolutePathCannotBeSetToReadOnlyFolder() throws IOException {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        File tempFolder = new File(".\\testTempFolder");
        tempFolder.mkdirs();
        tempFolder.setReadOnly();

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        try {
            helper.setImportFileDir(tempFolder.getAbsolutePath(), false);
            fail();
        } catch (IOException ioe) {
            assertTrue(ioe.toString().startsWith("java.io.IOException: Not writable:"));  //Expected path
        } finally {
            tempFolder.delete();
        }
    }

    public void ignore_testFileImportFolderCannotBeSetToNull() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        try {
            helper.setImportFileDir(null, false);
            fail();
        } catch (NullPointerException npe) {
            //Expected path
        }
    }

    public void ignore_testFileImportFolderCannotBeSetToEmptyString() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        try {
            helper.setImportFileDir("", false);
            fail();
        } catch (IOException ioe) {
            // Expected path
        }
    }

    public void ignore_testFileImportFolderCannotBeSetAfterMultipartHasAlreadyBeenSavedToScratch() throws Exception {
        String FILE_NAME = "myFile.txt";
        HttpUnitOptions.setDefaultContentType(UCCServletHelper.MULTI_PART_REQUEST);
        String fileData = "<stuff>data</stuff>";
        ByteArrayInputStream stream = new ByteArrayInputStream(fileData.getBytes());

        PostMethodWebRequest submitPost = new PostMethodWebRequest(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true");
        submitPost.setMimeEncoded(true);
        submitPost.setParameter("importname", "jobName");

        submitPost.selectFile("importname", FILE_NAME, stream, UCCServletHelper.MULTI_PART_REQUEST);
        InvocationContext invocation = m_sc.newInvocation(submitPost);

        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        try {
            helper.getParameterNames();  // calls initMPR(); which saves the Multipart input to default scratch dir
            String cstrInitialDirectory = new File(".").getAbsolutePath();
            helper.setImportFileDir(cstrInitialDirectory, false);
            fail();
        } catch (IOException ioe) {
            assertEquals("Cannot setFileImportFileDir after other calls to helper have used the default setting.", ioe.getMessage());
        }
    }

    public void ignore_testRequestedURL() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        String cstrURL = helper.requestedURL();
        assertEquals("http://localhost/testServlet", cstrURL);
    }

    public void ignore_testGetServletName() throws Exception {
        final String WEB_XML_STRING = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<!DOCTYPE web-app PUBLIC \"-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN\" \"http://java.sun.com/dtd/web-app_2_3.dtd\">\n"
                + "<web-app>\n"
                + "    <servlet>\n"
                + "        <servlet-name>OtherServlet</servlet-name>\n"
                + "        <servlet-class>com.monsanto.ServletFramework.Test.OtherServlet</servlet-class>\n"
                + "    </servlet>"
                + "    <servlet-mapping>\n"
                + "        <servlet-name>OtherServlet</servlet-name>\n"
                + "        <url-pattern>/servlet/OtherServlet</url-pattern>\n"
                + "    </servlet-mapping>"
                + "</web-app>";

        ServletRunner runner = null;
        try {
            runner = new ServletRunner(new ByteArrayInputStream(WEB_XML_STRING.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }

        ServletUnitClient client = runner.newClient();
        InvocationContext invocation = client.newInvocation("http://localhost:7080/servlet/OtherServlet");

        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        String cstrURL = helper.getServletName();

        assertTrue(cstrURL.endsWith("OtherServlet"));
    }

    public void ignore_testExpire() throws IOException {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        helper.expire();

        String cstrExpires = invocation.getServletResponse().getHeaderField("Expires");
        assertEquals("0", cstrExpires);

        String cstrPragma = invocation.getServletResponse().getHeaderField("Pragma");
        assertEquals("no-cache", cstrPragma);

        String cstrCacheControl = invocation.getServletResponse().getHeaderField("Cache-control");
        assertEquals("no-cache,must-revalidate", cstrCacheControl);
    }

    public void ignore_testSetHeader() throws IOException {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        helper.setHeader("Name", "Value");

        String cstrName = invocation.getServletResponse().getHeaderField("Name");
        assertEquals("Value", cstrName);
    }

    public void ignore_testGetHeader() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        String userAgent = helper.getHeader("User-Agent");
        assertTrue(userAgent.startsWith("httpunit"));
    }

    public void ignore_testSystemSecurityProxyConstructor_AndAssociatedMethods() throws Exception {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        UCCHelper helper = new UCCServletHelper(conf, requ, resp, true, new MockSystemSecurityProxy());
        assertNotNull("Helper is NULL!!", helper);
        assertEquals("getAuthenticatedUserID", USERID, helper.getAuthenticatedUserID());
        assertEquals("getAuthenticatedUserFullName", FULL_NAME, helper.getAuthenticatedUserFullName());
        assertEquals("getFailedLogonAttempts", 1, helper.getFailedLogonAttempts());

        Date expectedTime = Calendar.getInstance().getTime();
        Date lastLogon = helper.getLastLogon();
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
        String expectedDate = format.format(expectedTime);
        String actualDate = format.format(lastLogon);
        assertEquals(expectedDate, actualDate);
    }

    public void ignore_testConstructor_AndAssociatedMethods_SystemSecurityNotEnabled() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        assertNotNull(helper);
        assertNull(helper.getAuthenticatedUserID());
        assertNull(helper.getAuthenticatedUserFullName());
        assertEquals(0, helper.getFailedLogonAttempts());
        assertNull(helper.getLastLogon());
    }

    public void ignore_testMultipartRequest() throws Exception {
        String FILE_NAME = "myFile.txt";
        HttpUnitOptions.setDefaultContentType(UCCServletHelper.MULTI_PART_REQUEST);
        String fileData = "<stuff>data</stuff>";
        ByteArrayInputStream stream = new ByteArrayInputStream(fileData.getBytes());

        PostMethodWebRequest submitPost = new PostMethodWebRequest(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true");
        submitPost.setMimeEncoded(true);
        String IMPORT_NAME = "importname";
        submitPost.setParameter(IMPORT_NAME, "jobName");

        submitPost.selectFile(IMPORT_NAME, FILE_NAME, stream, UCCServletHelper.MULTI_PART_REQUEST);
        InvocationContext invocation = m_sc.newInvocation(submitPost);

        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        MockUCCServletHelperMultiPart helper = new MockUCCServletHelperMultiPart(conf, requ, resp);
        assertNotNull(helper);
        ArrayList files = helper.getClientFiles();
        assertEquals(1, files.size());
        String fileName = (String) files.get(0);
        assertTrue(fileName.endsWith(FILE_NAME));
        assertEquals(fileData.length(), (new File(fileName)).length());

        MultipartRequest multiRequest = helper.getMultipartRequest();
        File file = multiRequest.getFile(IMPORT_NAME);
        assertNotNull(file);
        assertEquals(FILE_NAME, file.getName());
        String contentType = multiRequest.getContentType(IMPORT_NAME);
        assertEquals(UCCServletHelper.MULTI_PART_REQUEST, contentType);

        File badFile = multiRequest.getFile("BadFile");
        assertNull(badFile);
        String badContentType = multiRequest.getContentType("BadFile");
        assertNull(badContentType);
    }

    public void ignore_testServerAuthorizedUser_GetUserFromCookie() throws Exception {
        CookieProperties.setDomainMatchingStrict(false);
        CookieProperties.setPathMatchingStrict(false);
        m_sc.putCookie("USER", USERID);
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        String actualCookieUser = helper.serverAuthorizedUser();
        assertEquals(USERID, actualCookieUser);

        m_sc.clearContents();
        helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        actualCookieUser = helper.serverAuthorizedUser();
        assertEquals(null, actualCookieUser);

        m_sc.clearContents();
        m_sc.putCookie("SomeOtherCookieNotUser", USERID);
        helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        actualCookieUser = helper.serverAuthorizedUser();
        assertEquals(null, actualCookieUser);
    }

    public void ignore_testGetCookies() throws Exception {
        CookieProperties.setDomainMatchingStrict(false);
        CookieProperties.setPathMatchingStrict(false);
        String FIRST_COOKIE = "RANDOM_COOKIE";
        String SECOND_COOKIE = "ANOTHER_COOKIE";
        String FIRST_COOKIE_VALUE = "cookie1";
        String SECOND_COOKIE_VALUE = "cookie2";
        m_sc.putCookie(FIRST_COOKIE, FIRST_COOKIE_VALUE);
        m_sc.putCookie(SECOND_COOKIE, SECOND_COOKIE_VALUE);
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        javax.servlet.http.Cookie[] cookies = helper.getCookies();
        javax.servlet.http.Cookie firstActualCookie = cookies[0];
        javax.servlet.http.Cookie secondActualCookie = cookies[1];

        assertEquals(FIRST_COOKIE, firstActualCookie.getName());
        assertEquals(SECOND_COOKIE, secondActualCookie.getName());

        assertEquals(FIRST_COOKIE_VALUE, firstActualCookie.getValue());
        assertEquals(SECOND_COOKIE_VALUE, secondActualCookie.getValue());
    }

    public void ignore_testGetInternalCookies() throws Exception {
        CookieProperties.setDomainMatchingStrict(false);
        CookieProperties.setPathMatchingStrict(false);
        String FIRST_COOKIE = "RANDOM_COOKIE";
        String SECOND_COOKIE = "ANOTHER_COOKIE";
        String FIRST_COOKIE_VALUE = "cookie1";
        String SECOND_COOKIE_VALUE = "cookie2";
        m_sc.putCookie(FIRST_COOKIE, FIRST_COOKIE_VALUE);
        m_sc.putCookie(SECOND_COOKIE, SECOND_COOKIE_VALUE);
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        com.monsanto.ServletFramework.Cookie[] cookies = helper.getClientCookies();
        com.monsanto.ServletFramework.Cookie firstActualCookie = cookies[0];
        com.monsanto.ServletFramework.Cookie secondActualCookie = cookies[1];

        assertEquals(FIRST_COOKIE, firstActualCookie.getName());
        assertEquals(SECOND_COOKIE, secondActualCookie.getName());

        assertEquals(FIRST_COOKIE_VALUE, firstActualCookie.getValue());
        assertEquals(SECOND_COOKIE_VALUE, secondActualCookie.getValue());
    }

    public void ignore_testWriteXMLDocument() throws Exception {
        ByteArrayInputStream stream = new ByteArrayInputStream("<stuff>data</stuff>".getBytes());
        Document expectedDocument = DOMUtil.newDocument(stream);

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        helper.writeXMLDocument(expectedDocument);
        WebResponse response = m_sc.getResponse(invocation);
        String HEADER = "<?xml version=\"1.0\"?>\n";
        assertEquals(HEADER + DOMUtil.getXMLString(expectedDocument), response.getText());
    }

    public void ignore_testWriteXMLDocumentWithEncoding() throws Exception {
        ByteArrayInputStream stream = new ByteArrayInputStream("<stuff>data</stuff>".getBytes());
        Document expectedDocument = DOMUtil.newDocument(stream);

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        helper.writeXMLDocument(expectedDocument, "UTF-8");
        WebResponse response = m_sc.getResponse(invocation);
        String HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        assertEquals(HEADER + DOMUtil.getXMLString(expectedDocument), response.getText().trim());
    }

    public void ignore_testSetMaxImportFileSize() throws Exception {
        String FILE_NAME = "myFile.txt";
        HttpUnitOptions.setDefaultContentType(UCCServletHelper.MULTI_PART_REQUEST);
        ByteArrayInputStream stream = new ByteArrayInputStream("<stuff>longdatastring_longdatastring_longdatastring_longdatastring_longdatastring_</stuff>".getBytes());

        PostMethodWebRequest submitPost = new PostMethodWebRequest(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true");
        submitPost.setMimeEncoded(true);
        submitPost.setParameter("importname", "jobName");

        submitPost.selectFile("importname", FILE_NAME, stream, UCCServletHelper.MULTI_PART_REQUEST);
        InvocationContext invocation = m_sc.newInvocation(submitPost);

        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        assertNotNull(helper);
        helper.setMaxImportFileSize(30);
        try {
            helper.getClientFiles();
            fail("Should have gotten exception due to max import file size being exceeded");
        } catch (IOException e) {
            assertTrue(e.toString().indexOf("exceeds limit of 30") != -1);
        }
    }

    // note -- when running from an un-packed war file, getRealPath returns null.  There does not appear to be
    // any way to simulate this for creating a test (LKPETER Jan 2005)
    public void ignore_testGetRealPath() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        String relativePath = "stuff";
        String expectedPath = System.getProperty("user.dir") + BACKSLASH + relativePath;
        String actualPath = helper.getRealPath(FORWARD_SLASH + relativePath);
        assertEquals(expectedPath, actualPath);
    }

    public void ignore_testRequestAttributes_variousMethods() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        assertNotNull(helper);
        String expectedAttribute = "javax.servlet.request.X509Certificate";
        String expectedValue = "FakeCertificate";

        helper.setRequestAttributeValue(expectedAttribute, expectedValue);

        Iterator iterator = helper.getRequestAttributeNames();
        String name = (String) iterator.next();
        assertEquals(expectedAttribute, name);

        String actualAttributeValue = (String) helper.getRequestAttributeValue(name);
        assertEquals(expectedValue, actualAttributeValue);

        helper.removeRequestAttribute(name);
        iterator = helper.getRequestAttributeNames();

        assertFalse(iterator.hasNext());
    }

    public void ignore_testDisplayHTML_File() throws Exception {
        m_sr.registerServlet("OtherServlet", OtherServlet.class.getName());
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);

        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        helper.displayHTML_File(null);
        helper.displayHTML_File("");
        helper.displayHTML_File("OtherServlet");

        WebResponse response = m_sc.getResponse(invocation);
        assertEquals(OTHER_OUTPUT, response.getText());
    }

    public void ignore_testForward() throws Exception {
        String text = getTextResponseFromForwardToServlet("OtherServlet", OtherServlet.class.getName(), (Hashtable) null);
        assertEquals(OTHER_OUTPUT, text);
    }

    public void ignore_testInclude() throws Exception {
        String servletName = "OtherServlet";
        m_sr.registerServlet(servletName, OtherServlet.class.getName());
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        helper.include("/" + servletName);
        WebResponse response = m_sc.getResponse(invocation);
        assertEquals(OTHER_OUTPUT, response.getText());
    }

    public void ignore_testEncodeURL_DoesNothingSinceCookiesAreSupported() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        String expectedURL = TEST_SERVLET_URL + "?mtype=XMLDOC";
        String actualEncodedURL = helper.encodeURL(expectedURL);
        assertEquals(expectedURL, actualEncodedURL);
    }

    public void ignore_testSessionParms_Set_Remove_Get_Clear_Close() throws Exception {
        //closeSession
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);
        String expectedValue1 = "value1";
        helper.setSessionParameter("parm1", expectedValue1);
        String expectedValue2 = "value2";
        helper.setSessionParameter("parm2", expectedValue2);
        String expectedValue3 = "value3";
        helper.setSessionParameter("parm3", expectedValue3);

        Iterator iterator1 = helper.getSessionParameterNames();
        assertIteratorSize(3, iterator1);

        assertEquals(expectedValue1, helper.getSessionParameter("parm1"));
        assertEquals(expectedValue2, helper.getSessionParameter("parm2"));
        assertEquals(expectedValue3, helper.getSessionParameter("parm3"));

        helper.removeSessionParameter("parm3");
        Iterator iterator2 = helper.getSessionParameterNames();
        assertIteratorSize(2, iterator2);

        helper.clearSession();
        Iterator iterator3 = helper.getSessionParameterNames();
        assertIteratorSize(0, iterator3);

        helper.setSessionParameter("parm1", expectedValue1);
        Iterator iterator4 = helper.getSessionParameterNames();
        assertIteratorSize(1, iterator4);

        helper.closeSession();
        Iterator iterator5 = helper.getSessionParameterNames();
        assertIteratorSize(0, iterator5);
    }

    public void ignore_testReportError_Throwable() throws Exception {
        m_sr.registerServlet("ErrorServlet", ErrorServlet.class.getName());
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        try {
            helper.forward("ErrorServlet");
            fail("Should have thrown RuntimeException");
        } catch (Exception e) {
        }
        WebResponse response = m_sc.getResponse(invocation);
        assertTrue(response.getText().indexOf("<h3>java.io.IOException: Big I/O Error</h3>java.io.IOException: Big I/O Error") != -1);
    }

    public void ignore_testReportError_StringMessage() throws Exception {
        String text = getTextResponseFromForwardToServlet("ErrorServlet2", ErrorServlet2.class.getName(), (Hashtable) null);
        assertTrue(text.indexOf("<h3>\"controller\" parameter not found for use-case lookup.  Contact technical support.</h3>") != -1);
    }

    public void ignore_testGetContextAttributes() throws Exception {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        ServletConfig servletConfig = invocation.getServlet().getServletConfig();
        String expectedContextAttribute = "contextAttribute1";
        String contextAttributeValue = "contextAttributeValue1";
        servletConfig.getServletContext().setAttribute(expectedContextAttribute, contextAttributeValue);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        UCCHelper helper = new UCCServletHelper(servletConfig, requ, resp);

        HashMap attributes = helper.getContextAttributes();
        assertEquals(1, attributes.size());
        assertTrue(attributes.keySet().contains(expectedContextAttribute));
        String actualValue = (String) attributes.get(expectedContextAttribute);
        assertEquals("Attribute value is incorrect", contextAttributeValue, actualValue);
    }

    public void ignore_testGetInitParameters() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        m_sc.setAuthorization("user", "WebTestRole");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        Map params = helper.getInitParameters();

        assertTrue("servletConfigInitParam not found", params.containsKey("servletConfigInitParam"));
        assertEquals("servletConfigInitParam should be true", "true", params.get("servletConfigInitParam"));
        assertTrue("servletContextInitParam not found", params.containsKey("servletContextInitParam"));
        assertEquals("servletContextInitParam should be false", "false", params.get("servletContextInitParam"));
    }

    public void ignore_testServletConfigInitParametersOverrideServletContext() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        m_sc.setAuthorization("user", "WebTestRole");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        Map params = helper.getInitParameters();

        assertTrue("overriddenParam not found", params.containsKey("overriddenParam"));
        assertEquals("overriddenParam should be 'fromConfig'", "fromConfig", params.get("overriddenParam"));
    }

    public void ignore_testSetGetRemoveContextAttribute() throws Exception {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        ServletConfig servletConfig = invocation.getServlet().getServletConfig();
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        UCCHelper helper = new UCCServletHelper(servletConfig, requ, resp);
        //Set Context Attributes
        helper.setContextAttribute("key1", new Integer(123));
        helper.setContextAttribute("key2", "key2 value");
        helper.setContextAttribute("key3", new String[]{"one", "two", "three", "four", "five"});
        //Get and Verify Context Attributes
        Integer actualValue1 = (Integer) helper.getContextAttribute("key1");
        assertEquals("Key value mismatch", actualValue1, new Integer(123));
        String actualValue2 = (String) helper.getContextAttribute("key2");
        assertEquals("Key value mismatch", actualValue2, "key2 value");
        String[] actualValue3 = (String[]) helper.getContextAttribute("key3");
        assertEquals("Array should have five elements", 5, actualValue3.length);
        assertEquals("Key value mismatch", actualValue3[0], "one");
        assertEquals("Key value mismatch", actualValue3[1], "two");
        assertEquals("Key value mismatch", actualValue3[2], "three");
        assertEquals("Key value mismatch", actualValue3[3], "four");
        assertEquals("Key value mismatch", actualValue3[4], "five");
        //Remove Context Attributes
        helper.removeContextAttribute("key1");
        helper.removeContextAttribute("key2");
        helper.removeContextAttribute("key3");
        //Verify Context Attributes were removed
        assertNull("Context Attribute should have been null", helper.getContextAttribute("key1"));
        assertNull("Context Attribute should have been null", helper.getContextAttribute("key2"));
        assertNull("Context Attribute should have been null", helper.getContextAttribute("key3"));
    }


    public void ignore_testRequestParametersMethods() throws Exception {
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true", m_sc);
        assertEnumerationSize(2, helper.getParameterNames());
        Enumeration e = helper.getParameterNames();
        String firstElement = (String) e.nextElement();
        assertEquals("outfile", firstElement);
        String secondElement = (String) e.nextElement();
        assertEquals("mtype", secondElement);

        String outfileValue = helper.getRequestParameterValue("outfile");
        assertEquals("true", outfileValue);

        String[] values = helper.getRequestParameterValues("outfile");
        assertEquals(1, values.length);
        assertEquals("true", values[0]);
    }

    public void ignore_testApplyStylesheet() throws Exception {
        String text = getTextResponseFromForwardToServlet("StylesheetServlet", StylesheetServlet.class.getName(), (Hashtable) null);
        String expectedResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><EDE>"
                + "<font size=\"10pt\"><FD1><ProgramID>MIRAGE MP N</ProgramID>"
                + "<DateFormat>YYYY/MM/DD</DateFormat><UnitsIndicator>U</UnitsIndicator>"
                + "<TimeFormat>HH:MM</TimeFormat></FD1></font></EDE>";
        text = stripWhiteSpace(text);
        assertEquals(expectedResult, text);
    }

    public void ignore_testApplyEncodedStylesheet() throws Exception {
        String text = getTextResponseFromForwardToServlet("StylesheetServlet", StylesheetServlet.class.getName(), "application/ms-excel");
        String expectedResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><EDE>"
                + "<font size=\"10pt\"><FD1><ProgramID>MIRAGE MP N</ProgramID>"
                + "<DateFormat>YYYY/MM/DD</DateFormat><UnitsIndicator>U</UnitsIndicator>"
                + "<TimeFormat>HH:MM</TimeFormat></FD1></font></EDE>";
        text = stripWhiteSpace(text);
        assertEquals(expectedResult, text);
    }

    public void ignore_testApplyBadlyEncodedStylesheet() throws Exception {
        String text = getTextResponseFromForwardToServlet("StylesheetServlet", StylesheetServlet.class.getName(), "some fake content type");
        String expectedResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><EDE>"
                + "<font size=\"10pt\"><FD1><ProgramID>MIRAGE MP N</ProgramID>"
                + "<DateFormat>YYYY/MM/DD</DateFormat><UnitsIndicator>U</UnitsIndicator>"
                + "<TimeFormat>HH:MM</TimeFormat></FD1></font></EDE>";
        text = stripWhiteSpace(text);
        assertEquals(expectedResult, text);
    }

    public void ignore_testApplyStylesheet_WithParms() throws Exception {
        String text = getTextResponseFromForwardToServlet("StylesheetWithParmsServlet", StylesheetWithParmsServlet.class.getName(), (Hashtable) null);
        String expectedResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><EDE>"
                + "<font size=\"12pt\"><FD1><ProgramID>MIRAGE MP N</ProgramID>"
                + "<DateFormat>YYYY/MM/DD</DateFormat><UnitsIndicator>U</UnitsIndicator>"
                + "<TimeFormat>HH:MM</TimeFormat></FD1></font></EDE>";
        text = stripWhiteSpace(text);
        assertEquals(expectedResult, text);
    }

    public void ignore_testApplyStylesheetWithoutLeadingSeparator() throws Exception {
        Document doc = DOMUtil.newDocument();
        DOMUtil.addChildElement(doc, "Root");

        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true", m_sc);
        helper.applyStylesheet(doc, "com/monsanto/ServletFramework/Test/testStyleSheet.xslt");
    }

    public void ignore_testApplyStylesheetWithLeadingSeparator() throws Exception {
        Document doc = DOMUtil.newDocument();
        DOMUtil.addChildElement(doc, "Root");

        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true", m_sc);
        helper.applyStylesheet(doc, "/com/monsanto/ServletFramework/Test/testStyleSheet.xslt");
    }

    public void ignore_testApplyStylesheetWithDotLeadingSeparator() throws Exception {
        Document doc = DOMUtil.newDocument();
        DOMUtil.addChildElement(doc, "Root");

        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true", m_sc);
        helper.applyStylesheet(doc, "com/monsanto/ServletFramework/Test/testStyleSheet.xslt");
    }

    public void ignore_testApplyStylesheetWithBogusLeadingSeparatorThrows() throws Exception {
        Document doc = DOMUtil.newDocument();
        DOMUtil.addChildElement(doc, "Root");

        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL + "?mtype=XMLDOC&outfile=true", m_sc);
        try {
            helper.applyStylesheet(doc, "\\com/monsanto/ServletFramework/Test/testStyleSheet.xslt");
            fail();
        } catch (IOException e) {
            // Expected path
        }
    }

    public void ignore_testWriteToExcel() throws Exception {
        Document doc = DOMUtil.newDocument();
        Node root = DOMUtil.addChildElement(doc, "Root");
        Node row = DOMUtil.addChildElement(root, "row");
        DOMUtil.addChildElement(row, "field", "field1");
        DOMUtil.addChildElement(row, "field", "field2");
        DOMUtil.addChildElement(row, "field", "field3");

        String myFileName = "/myFileName.xls";
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL + myFileName);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        //note: use an html table in your style sheet & excel will put each <TD\> into a cell.
        helper.writeToExcel(doc, "com/monsanto/ServletFramework/Test/testStyleSheetForExcel.xslt", new HashMap());
        WebResponse response = m_sc.getResponse(invocation);

        assertEquals("application/vnd.ms-excel", response.getContentType());
        assertTrue(response.getURL().toString().endsWith(myFileName));

        String expectedResult = "<html><body><TABLE BORDER=\"1\">"
                + "<TR><TH>     column     1    </TH><TH> column 2</TH><TH>column 3</TH></TR>"
                + "<TR><TD>field1</TD><TD>field2</TD><TD>field3</TD></TR></TABLE></body></html>";
        String actualResult = stripWhiteSpace(response.getText());
        assertEquals(expectedResult, actualResult);
    }

    public void ignore_testWriteToExcel_NoParamMap() throws Exception {
        Document doc = DOMUtil.newDocument();
        Node root = DOMUtil.addChildElement(doc, "Root");
        Node row = DOMUtil.addChildElement(root, "row");
        DOMUtil.addChildElement(row, "field", "field1");
        DOMUtil.addChildElement(row, "field", "field2");
        DOMUtil.addChildElement(row, "field", "field3");

        String myFileName = "/myFileName.xls";
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL + myFileName);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        //note: use an html table in your style sheet & excel will put each <TD\> into a cell.
        helper.writeToExcel(doc, "com/monsanto/ServletFramework/Test/testStyleSheetForExcel.xslt");
        WebResponse response = m_sc.getResponse(invocation);

        assertEquals("application/vnd.ms-excel", response.getContentType()); //this is what gets the browser to open excel
        assertTrue(response.getURL().toString().endsWith(myFileName));

        String expectedResult = "<html><body>"
                + "<TABLE BORDER=\"1\"><TR><TH>     column     1    </TH><TH> column 2</TH><TH>column 3</TH></TR>"
                + "<TR><TD>field1</TD><TD>field2</TD><TD>field3</TD></TR></TABLE></body></html>";
        String actualResult = stripWhiteSpace(response.getText());
        assertEquals(expectedResult, actualResult);
    }

    public void ignore_testWriteToWord() throws Exception {
        Document doc = DOMUtil.newDocument();
        DOMUtil.addChildElement(doc, "Root");

        String myFileName = "/myFileName.doc";
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL + myFileName);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        helper.writeToWord(doc, "com/monsanto/ServletFramework/Test/testStyleSheet.xslt", new HashMap());
        WebResponse response = m_sc.getResponse(invocation);

        assertEquals("application/msword", response.getContentType());
        assertTrue(response.getURL().toString().endsWith(myFileName));
    }

    public void ignore_testWriteToWord_NoParamMap() throws Exception {
        Document doc = DOMUtil.newDocument();
        DOMUtil.addChildElement(doc, "Root");

        String myFileName = "/myFileName.doc";
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL + myFileName);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        helper.writeToWord(doc, "com/monsanto/ServletFramework/Test/testStyleSheet.xslt");
        WebResponse response = m_sc.getResponse(invocation);

        assertEquals("application/msword", response.getContentType());
        assertTrue(response.getURL().toString().endsWith(myFileName));
    }

    public void ignore_testRunControllerInGatewayServlet() throws Exception {
				//Note: This test requires ant-launcher.jar from Ant 1.65 or later
        Hashtable initParms = new Hashtable();
        initParms.put("controller", "ServletFramework.ServletInfoController");
        String text = getTextResponseFromForwardToServlet("ServletInfoServlet", PassThroughServlet.class.getName(), initParms);
        assertTextContainsValue(text, "<TITLE>SERVLET INFO</TITLE>");
        String expectedInitParms = "Init Parameters:"
                + LINE_SEP
                + "<tr>"
                + LINE_SEP
                + "<td>controller</td>"
                + LINE_SEP
                + "<td>ServletFramework.ServletInfoController</td>"
                + LINE_SEP
                + "</tr>";
        assertTextContainsValue(text, expectedInitParms);
        assertTextContainsValue(text, "Current Working Folder:");
    }

    public void ignore_testIsUserInRole() throws Exception {
        String USER_ROLE = "WebTestRole";
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        m_sc.setAuthorization("user", USER_ROLE);
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        boolean isInRole = helper.isUserInRole(USER_ROLE);
        assertTrue(isInRole);
    }

    public void ignore_testIsUserInRole_UserIsNOTInRole() throws Exception {
        String USER_ROLE = "WebTestRole";
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        m_sc.setAuthorization("user", USER_ROLE);
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL, m_sc);

        boolean isInRole = helper.isUserInRole("SomeOtherRandomRole");
        assertFalse(isInRole);
    }

		public void ignore_testGetAuthenticatedUserDomain() throws Exception {
			SystemSecurityProxy systemProxy = new MockSystemSecurityProxy();
			MockUCCHelper helper = new MockUCCHelper("http://localhost", true, systemProxy);
			String authenticatedUserID = helper.getAuthenticatedUserID();
			String domain = helper.getAuthenticatedUserDomain();
			assertEquals(USERID, authenticatedUserID);
			assertEquals(DOMAIN, domain);
		}

		public void ignore_testGetAuthenticatedUserDomain_InvalidDomain_ExpectNullReturn() throws Exception {
			SystemSecurityProxy systemProxy = new MockSystemSecurityProxyBadCredential();
			MockUCCHelper helper = new MockUCCHelper("http://localhost", true, systemProxy);
			String authenticatedUserID = helper.getAuthenticatedUserID();
			String domain = helper.getAuthenticatedUserDomain();
			assertEquals(USERID, authenticatedUserID);
			assertNull(domain);
		}

    public void ignore_testGetPathInfo() throws Exception {
        String pathInfo = "/dontCarePathInfo.txt";
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(TEST_SERVLET_URL + pathInfo, m_sc);
        assertEquals(pathInfo, helper.getPathInfo());
    }

    private void assertTextContainsValue(String text, String str) {
        assertTrue(text.indexOf(str) != -1);
    }

    public void ignore_testSetMaxInactiveInterval() throws Exception {
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();

        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        helper.setMaxInactiveInterval(2);
        assertEquals(2, requ.getSession().getMaxInactiveInterval());

        helper.setMaxInactiveInterval(3);
        assertEquals(3, requ.getSession().getMaxInactiveInterval());
    }

    public void ignore_testFormDataCreation() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_URL, m_sc);

        FormRequestData form = helper.getFormRequestData();
        assertNotNull(form);
        assertTrue(form instanceof MockConcreteForm);
    }

    public void ignore_testFormDataCreation_Exception() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BAD_BEAN_TEST_SERVLET_URL, m_sc);
        try {
            helper.getFormRequestData();
            fail("Should have gotten BadFormDataException");
        } catch (BadFormDataException e) {
            assertTrue(e.toString().endsWith("No FormBean or FormBeanSession specified in web.xml"));
        }
    }

    public void ignore_testFormDataCreation_ExceptionTooManyParms() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BAD_BEAN_TEST_SERVLET_TOO_MANY_PARMS_URL, m_sc);
        try {
            helper.getFormRequestData();
            fail("Should have gotten BadFormDataException");
        } catch (BadFormDataException e) {
            assertTrue(e.toString().endsWith("Both FormBean and FormBeanSession specified in web.xml.  Specify only one."));
        }
    }

    public void ignore_testFormDataCreation_ExceptionClassNotFound() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(NO_SUCH_BEAN_TEST_SERVLET_URL, m_sc);
        try {
            helper.getFormRequestData();
            fail("Should have gotten BadFormDataException");
        } catch (BadFormDataException e) {
            assertTrue(e.getCause() instanceof ClassNotFoundException);
        }
    }

    public void ignore_testFormDataCreation_ExceptionBadData() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BAD_DATA_BEAN_TEST_SERVLET_URL
                + "?stuff=Stuff&amount=NOTNUMERIC&huh=MAYBE", m_sc);
        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();
        assertFormData(form, "Stuff", 0, false);
    }

    public void ignore_testFormDataCreation_ExceptionIncompatibleType() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(INCOMPATIBLE_BEAN_TEST_SERVLET_URL, m_sc);
        try {
            helper.getFormRequestData();
            fail("Should have gotten BadFormDataException");
        } catch (BadFormDataException e) {
            assertTrue(e.getCause() instanceof InstantiationException);
        }
    }

    public void ignore_testFormDataCreation_WithDataPopulated() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_URL
                + "?stuff=Stuff&amount=42&huh=false", m_sc);

        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();
        assertFormData(form, "Stuff", 42, false);
    }

    public void ignore_testFormDataCreation_WithPartialDataPopulated() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_URL + "?huh=true", m_sc);

        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();

        assertNull(form.getStuff());
        assertEquals(43, form.getAmount());
        assertEquals(true, form.isHuh());
    }

    public void ignore_testFormDataCreation_WithExtraData() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_URL
                + "?stuff=Stuff&amount=42&huh=true&moreData=hello&count=17", m_sc);

        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();
        assertFormData(form, "Stuff", 42, true);
    }

    public void ignore_testFormDataOnSession() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        InvocationContext invocation = m_sc.newInvocation(BEAN_TEST_SERVLET_SESSION_URL
                + "?stuff=Stuff&amount=42&huh=true"
                + "&moreData=hello&count=17");
        HttpServletRequest request = invocation.getRequest();
        UCCHelper helper = new UCCServletHelper(invocation.getServlet().getServletConfig(), request, invocation.getResponse());
        assertThatFormOnSessionIsNullToStartWith(request);

        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();
        assertFormData(form, "Stuff", 42, true);

        form.setAmount(100);

        MockConcreteForm newForm = (MockConcreteForm) request.getSession().getAttribute(UCCServletHelper.FORM_REQUEST_SESSION_PARM);
        assertFormData(newForm, "Stuff", 100, true);

        getResponseForClientToProcessCookiesForSessionData(invocation);
        UCCHelper helper2 = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_SESSION_URL
                + "?stuff=NotStuff", m_sc);

        MockConcreteForm formFromSession = (MockConcreteForm) helper2.getFormRequestData();
        assertFormData(formFromSession, "NotStuff", 100, true);
    }

    private void assertFormData(MockConcreteForm form, String stuffValue, int amountValue, boolean huhValue) {
        assertEquals(stuffValue, form.getStuff());
        assertEquals(amountValue, form.getAmount());
        assertEquals(huhValue, form.isHuh());
    }

    private void assertThatFormOnSessionIsNullToStartWith(HttpServletRequest request) {
        MockConcreteForm oldForm = (MockConcreteForm) request.getSession().getAttribute(UCCServletHelper.FORM_REQUEST_SESSION_PARM);
        assertNull(oldForm);
    }

    private void getResponseForClientToProcessCookiesForSessionData(InvocationContext invocation) throws IOException, SAXException {
        m_sc.getResponse(invocation);
    }

    public void ignore_testFormDataCreation_WithExtraData_ListAndMapSupport() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_WITH_LIST_SERVLET_URL
                + "?stuff=Stuff&amount=42&listData[0].data=list2&myNestedStuff.data=list1"
                + "&stringListData[0]=list3&stringListData[4]=list5&huh=true&moreData=hello&count=17"
                + "&mapDataMapped(firstKey)=firstValue&mapDataMapped(anotherKey)=someValue", m_sc);

        MockConcreteFormWithList form = (MockConcreteFormWithList) helper.getFormRequestData();
        assertEquals("Stuff", form.getStuff());
        assertEquals(42, form.getAmount());
        assertEquals(true, form.isHuh());
        assertEquals("list2", form.getListData(0).getData());
        assertEquals("list1", form.getMyNestedStuff().getData());
        assertEquals("list3", form.getStringListData(0));
        assertEquals("list5", form.getStringListData(4));
        assertEquals("firstValue", form.getMapDataMapped("firstKey"));
        assertEquals("someValue", form.getMapDataMapped("anotherKey"));
    }

		public void ignore_testFormDataCreation_MultipleItemsInTheList() throws Exception {
			UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
			UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_WITH_LIST_SERVLET_URL
							+ "?listData[0].data=value1&listData[1].data=value2&listData[2].data=value3", m_sc);

			MockConcreteFormWithList form = null;
			form = (MockConcreteFormWithList) helper.getFormRequestData();
			assertEquals("value1", form.getListData(0).getData());
			assertEquals("value2", form.getListData(1).getData());
			assertEquals("value3", form.getListData(2).getData());
		}

    public void ignore_testFormDataCreation_NoDataInterfaceProvided_DoesNotUseProxy() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_URL
                + "?stuff=Stuff&amount=42&huh=false"
                + "&htmlMultiSelectListValues=selected1&htmlMultiSelectListValues=selected2", m_sc);

        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();
        assertFormData(form, "Stuff", 42, false);
        assertEquals("selected1", form.getHtmlMultiSelectListValues()[0]);
        assertEquals("selected2", form.getHtmlMultiSelectListValues()[1]);
    }

    public void ignore_testFormDataIsPutOnRequest() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");

        InvocationContext invocation = m_sc.newInvocation(BEAN_TEST_SERVLET_URL
                + "?stuff=Stuff&amount=42&huh=true&moreData=hello&count=17");
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = invocation.getServlet().getServletConfig();
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);

        MockConcreteForm form = (MockConcreteForm) helper.getFormRequestData();
        assertFormData(form, "Stuff", 42, true);

        form.setAmount(100);

        helper.forward("BeanTest");

        MockConcreteForm newForm = (MockConcreteForm) requ.getAttribute(UCCServletHelper.FORM_REQUEST_PARM);
        assertEquals(100, newForm.getAmount());
        assertEquals("Stuff", form.getStuff());
        assertEquals(true, form.isHuh());
    }

    public void ignore_testGetHeaderNames() throws Exception {
        UCCHelperTestUtil.setupRunnerAndClientWithWEBXML(this, "com/monsanto/ServletFramework/Test/webtest.xml");
        UCCHelper helper = UCCHelperTestUtil.getHelperUsingInvocationContextForURL(BEAN_TEST_SERVLET_URL + "?huh=true", m_sc);
        String[] names = helper.getHeaderNames();
        assertEquals(3, names.length);
        assertEquals("User-Agent", names[0]);
        assertEquals("Accept-Encoding", names[1]);
        assertEquals("Content-Length", names[2]);
    }

    public void setRunnerClient(ServletRunner runner, ServletUnitClient client) {
        m_sr = runner;
        m_sc = client;
    }

    private void assertIteratorSize(int expectedSize, Iterator iterator) {
        int count = 0;
        while (iterator.hasNext()) {
            iterator.next();
            count++;
        }
        assertEquals(expectedSize, count);
    }

    private void assertEnumerationSize(int expectedSize, Enumeration enumerator) {
        int count = 0;
        while (enumerator.hasMoreElements()) {
            enumerator.nextElement();
            count++;
        }
        assertEquals(expectedSize, count);
    }

    private String getTextResponseFromForwardToServlet(String servletName, String fullClassName,
																											 Hashtable initParms)
						throws IOException, SAXException {
        if (initParms != null) {
            m_sr.registerServlet(servletName, fullClassName, initParms);
        } else {
            m_sr.registerServlet(servletName, fullClassName);
        }
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        helper.forward(servletName);
        WebResponse response = m_sc.getResponse(invocation);
        return response.getText();
    }

    private String getTextResponseFromForwardToServlet(String servletName, String fullClassName, String encoding) throws IOException, SAXException {
        m_sr.registerServlet(servletName, fullClassName);
        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest requ = invocation.getRequest();
        requ.setAttribute("encoding", encoding);
        HttpServletResponse resp = invocation.getResponse();
        ServletConfig conf = null;
        UCCHelper helper = new UCCServletHelper(conf, requ, resp);
        helper.forward(servletName);
        WebResponse response = m_sc.getResponse(invocation);
        return response.getText();
    }

    private String stripWhiteSpace(String text) {
        text = text.replaceAll("[\\t\\n\\r]", "");
        return text;
    }

    class MockSystemSecurityProxy implements SystemSecurityProxy {
  			protected GSSCredential credentials = null;

			  public MockSystemSecurityProxy() {
					try {
						credentials = createClientCredentials(USERID + UCCServletHelper.AT_SIGN + DOMAIN);
					} catch (GSSException IGNORE_LEAVE_NULL) {
					}
				}

        public String getUserID() {
            return USERID;
        }

        public String getFullName() {
            return FULL_NAME;
        }

        public int getFailedLogonAttempts() {
            return 1;
        }

        public Date getLastLogon() {
            return Calendar.getInstance().getTime();
        }

        public GSSCredential getDelegCredential() {
            return credentials;
        }

        protected GSSCredential createClientCredentials(String localUserName) throws GSSException {
					  return new MockGSSCredential(localUserName);
			  }
    }

		class MockSystemSecurityProxyBadCredential extends MockSystemSecurityProxy {
			public MockSystemSecurityProxyBadCredential() {
				try {
					credentials = createClientCredentials(USERID);
				} catch (GSSException IGNORE_LEAVE_NULL) {
				}

			}
		}

		class MockGSSCredential implements GSSCredential {
			String nameString = null;

			public MockGSSCredential(String fullUserAndDomain) {
				nameString = 	fullUserAndDomain;
			}

			public void dispose() throws GSSException {
			}

			public GSSName getName() throws GSSException {
				return new MockGSSName(nameString);
			}

			public GSSName getName(Oid mech) throws GSSException {
				return null;
			}

			public int getRemainingLifetime() throws GSSException {
				return 0;
			}

			public int getRemainingInitLifetime(Oid mech) throws GSSException {
				return 0;
			}

			public int getRemainingAcceptLifetime(Oid mech) throws GSSException {
				return 0;
			}

			public int getUsage() throws GSSException {
				return 0;
			}

			public int getUsage(Oid mech) throws GSSException {
				return 0;
			}

			public Oid[] getMechs() throws GSSException {
				return new Oid[0];
			}

			public void add(GSSName name, int initLifetime, int acceptLifetime, Oid mech, int usage) throws GSSException {
			}
		}

		class MockGSSName implements GSSName {
			private String fullNameAndDomain;

			public MockGSSName(String fullNameAndDomain) {
				this.fullNameAndDomain = fullNameAndDomain;
			}

			public String toString() {
				return fullNameAndDomain;
			}

			public boolean equals(GSSName another) throws GSSException {
				return false;
			}

			public GSSName canonicalize(Oid mech) throws GSSException {
				return null;
			}

			public byte[] export() throws GSSException {
				return new byte[0];
			}

			public Oid getStringNameType() throws GSSException {
				return null;
			}

			public boolean isAnonymous() {
				return false;
			}

			public boolean isMN() {
				return false;
			}
		}

    class MockUCCServletHelperMultiPart extends UCCServletHelper {
        public MockUCCServletHelperMultiPart(final ServletConfig config, final HttpServletRequest request, final HttpServletResponse response) {
            super(config, request, response);
        }

        public MockUCCServletHelperMultiPart(final ServletConfig config, final HttpServletRequest request, final HttpServletResponse response, final boolean systemSecurityEnabled, final SystemSecurityProxy proxy) {
            super(config, request, response, systemSecurityEnabled, proxy);
        }

        public MultipartRequest getMultipartRequest() {
            return m_MPR;
        }

    }

}
