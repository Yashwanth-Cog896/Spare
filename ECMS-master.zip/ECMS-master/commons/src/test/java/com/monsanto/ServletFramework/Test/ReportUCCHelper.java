/*
 ReportUCCHelper was created on May 16, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.Cookie;
import com.monsanto.ServletFramework.FormRequestData;
import com.monsanto.ServletFramework.FormattedWriter;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.fileutil.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.XSLTUtil;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import org.w3c.dom.Document;

import java.io.*;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.*;

/**
 * Filename:    $RCSfile: ReportUCCHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ardharn $    	 On:	$Date: 2007-09-12 22:56:15 $
 *
 * @author cfkan
 * @version $Revision: 1.9 $
 */


public class ReportUCCHelper implements UCCHelper {
    private String m_cstrContentType = "text/html";
    private String m_cstrTo = null;
    private String m_cstrCurrentFolder = new File(".").getName();
    private int m_iMaxImportFileSize = s_iDefaultFileUploadSize;
    private StringWriter m_Response = null;
    private OutputStream m_BinaryResponse = null;
    private HashMap m_RequestParameters = new HashMap();
    private HashMap m_SessionParameters = new HashMap();
    private HashMap m_RequestAttributes = new HashMap();
    private HashMap contextAttributes = new HashMap();

    private HashMap m_initParameters = new HashMap();

    private boolean m_boolIsExpired = false;
    private String m_cstrRequestedURL;
    private String m_cstrServletName;
    private boolean systemSecurityEnabled = false;
    private SystemSecurityProxy systemSecurityProxy = null;
    protected Document m_XMLDoc = null;
    protected String m_cstrStylesheet = null;
    protected Map m_xslParameters = null;
    private boolean m_boolErrorReported = false;
    protected boolean m_boolApplyStylesheet = true;
    protected String m_stylesheetContentType = null;
    private boolean m_boolRequestParamsAccessed = false;
    private ArrayList m_ClientFiles = new ArrayList();
    protected Document transformedDocument = null;
    private HashMap m_headers = new HashMap();
    private String pathInfo = "";
    private FormRequestData m_formRequestData;
    private Vector cookies = new Vector();

    public ReportUCCHelper(String cstrRequestedURL) {
        m_cstrRequestedURL = cstrRequestedURL;
    }

    public ReportUCCHelper(String cstrRequestedURL, String cstrServletName) {
        m_cstrRequestedURL = cstrRequestedURL;
        m_cstrServletName = cstrServletName;
    }

    public ReportUCCHelper(String cstrRequestedURL,
                           boolean systemSecurityEnabled,
                           SystemSecurityProxy proxy) {
        m_cstrRequestedURL = cstrRequestedURL;
        this.systemSecurityEnabled = systemSecurityEnabled;
        this.systemSecurityProxy = proxy;
    }

    public ReportUCCHelper(String cstrRequestedURL, boolean boolApplyStylesheet) {
        m_cstrRequestedURL = cstrRequestedURL;
        m_boolApplyStylesheet = boolApplyStylesheet;
        m_Response = new StringWriter(1024);
    }

    public void setContentType(String contentType) {
        m_cstrContentType = contentType;
    }

    public void applyStylesheet(Document xmlDoc, String xslURL) throws IOException {
        m_XMLDoc = xmlDoc;
        m_cstrStylesheet = xslURL;

        if (m_boolApplyStylesheet) {
            transformedDocument = XSLTUtil.applyStyleSheet(m_XMLDoc, m_cstrStylesheet);
            DOMUtil.outputXML(transformedDocument, getPrintWriter());
        }
    }

    public void applyStylesheet(Document xmlDoc, String xslURL, String contentType) throws IOException {
        m_XMLDoc = xmlDoc;
        m_cstrStylesheet = xslURL;
        m_stylesheetContentType = contentType;

        if (m_boolApplyStylesheet) {
            transformedDocument = XSLTUtil.applyStyleSheet(m_XMLDoc, m_cstrStylesheet);
            DOMUtil.outputXML(transformedDocument, getPrintWriter());
        }
    }

    public Document getTransformedDocument() {
        return transformedDocument;
    }

    public void applyStylesheet(Document xmlDoc, String xsltURI, Map paramMap) throws IOException {
        m_XMLDoc = xmlDoc;
        m_cstrStylesheet = xsltURI;
        m_xslParameters = paramMap;
        if (m_boolApplyStylesheet) {
            applyStylesheet(xmlDoc, xsltURI);
        }
    }

    public void writeToExcel(Document xmlDoc, String xsltURI, String relativeFilePath) throws IOException {
        applyStylesheet(xmlDoc, xsltURI);
    }

    public void writeToExcel(Document xmlDoc, String xsltURI, Map paramMap, String relativeFilePath) throws IOException {
        writeToExcel(xmlDoc, xsltURI, relativeFilePath);
    }

  public void writeToExcel(Document xmlDoc, String xsltURI, Map paramMap) throws IOException {
      applyStylesheet(xmlDoc, xsltURI, "application/vnd.ms-excel");
  }

  public void writeToExcel(Document xmlDoc, String xsltURI) throws IOException {
      writeToExcel(xmlDoc, xsltURI, (Map) null);
  }

  public void writeToWord(Document xmlDoc, String xsltURI, Map paramMap) throws IOException {
      applyStylesheet(xmlDoc, xsltURI, "application/msword");
  }

  public void writeToWord(Document xmlDoc, String xsltURI) throws IOException {
      writeToExcel(xmlDoc, xsltURI, (Map) null);
  }

    public void writeToWord(Document xmlDoc, String xsltURI, String relativeFilePath) throws IOException {
    }

    public void writeToWord(Document xmlDoc, String xsltURI, Map paramMap, String relativeFilePath) throws IOException {
        writeToWord(xmlDoc, xsltURI, relativeFilePath);
    }

    public InputStream getInputStream(String url) throws IOException {
        InputStream stream = new ByteArrayInputStream(m_BinaryResponse.toString().getBytes());
        return stream;
    }

    public Enumeration getParameterNames() throws IOException {
        m_boolRequestParamsAccessed = true;
        //return new Vector().elements();
        Vector vect = new Vector(5);
        Set set = m_RequestParameters.keySet();
        if (set != null) {
            Iterator iterator = set.iterator();
            while (iterator.hasNext()) {
                String strKey = (String) iterator.next();
                vect.add(strKey);
            }
        }
        return vect.elements();
    }

    public void setBinaryStream(OutputStream os) {
        m_BinaryResponse = os;
    }

    public OutputStream getBinaryStream() throws IOException {
        if (m_BinaryResponse == null) {
            m_BinaryResponse = new ByteArrayOutputStream(1024);
        }

        return m_BinaryResponse;
    }

    public PrintWriter getPrintWriter() throws IOException {
        if (m_Response == null) {
            m_Response = new StringWriter(1024);
        }
        return new PrintWriter(m_Response);
    }

    public String getRequestParameterValue(String parameterName) throws IOException {
        m_boolRequestParamsAccessed = true;

        Object values = m_RequestParameters.get(parameterName);
        if (values == null) {
            return null;
        } else if (values.getClass().isArray()) {
            return ((String[]) values)[0];
        } else {
            return (String) values;
        }
    }

    public String[] getRequestParameterValues(String parameterName) throws IOException {
        m_boolRequestParamsAccessed = true;

        Object values = m_RequestParameters.get(parameterName);
        if (values == null) {
            return null;
        } else if (values.getClass().isArray()) {
            return (String[]) values;
        } else {
            String[] returnArray = new String[1];
            returnArray[0] = (String) values;
            return returnArray;
        }
    }

    public Iterator getRequestAttributeNames() throws IOException {
        m_boolRequestParamsAccessed = true;

        return m_RequestAttributes.keySet().iterator();
    }

    public Object getRequestAttributeValue(String attributeName) {
        m_boolRequestParamsAccessed = true;

        return m_RequestAttributes.get(attributeName);
    }

    public void setRequestAttributeValue(String name, Object value) {
        m_boolRequestParamsAccessed = true;

        m_RequestAttributes.put(name, value);
    }

    public void removeRequestAttribute(String attributeName) {
        m_boolRequestParamsAccessed = true;

        m_RequestAttributes.remove(attributeName);
    }

    public Iterator getSessionParameterNames() throws IOException {
        return m_SessionParameters.keySet().iterator();
    }

    public void setSessionParameter(String name, Object value) {
        m_SessionParameters.put(name, value);
    }

    public void removeSessionParameter(String cstrName) {
        m_SessionParameters.remove(cstrName);
    }

    public Object getSessionParameter(String parameterName) {
        return m_SessionParameters.get(parameterName);
    }

    /**
     * Gets the init parameters.  The <code>HasMap</code> has the init parameter name for the key values and the init
     * parameter value for the value.
     *
     * @return The init parameters in a HashMap keyed by the init parameter name.
     */
    public HashMap getInitParameters() {
        return m_initParameters;
    }

    public void setInitParameters(HashMap initParameters) {
        m_initParameters = initParameters;
    }

    public void addInitParameters(HashMap moreInitParameters) {
        m_initParameters.putAll(moreInitParameters);
    }

    public void addInitParameter(Object key, Object value) {
        m_initParameters.put(key, value);
    }


    public void reportError(String message) {
        try {
            getPrintWriter().print(message);
            m_boolErrorReported = true;
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }
    }

    public void reportError(Throwable t) {
        this.reportError(t.toString());
    }

    public void reportPlainMessage(String message, String color) {
        try {
            getPrintWriter().print(message);
            m_boolErrorReported = true;
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        }
    }

    public void closeSession() {
        clearSession();
    }

    public void clearSession() {
        m_SessionParameters.clear();
    }

    public String encodeURL(String cstrURL) {
        return null;
    }

    public String serverAuthorizedUser() {
        return null;
    }

    public void displayHTML_File(String cstrFileName) throws IOException {
        String message = FileUtil.read(cstrFileName);

        getPrintWriter().print(message);

        m_cstrTo = cstrFileName;
    }

    public void include(String cstrTo) throws IOException {
    }

    public void forward(String cstrTo) throws IOException {
        m_cstrTo = cstrTo;
    }

    public ArrayList getClientFiles() throws IOException {
        return m_ClientFiles;
    }

    public String getCurrentDirectory() {
        return m_cstrCurrentFolder;
    }

    /**
     * Returns a name of a temporary directory where short-lived working files can be stored.
     *
     * @return The directory path.
     */
    public File getTempDirectory() {
        return new File(System.getProperty("java.io.tmpdir"));
    }


    public File getSecureFileSystemRoot() {
        return getTempDirectory();
    }

    public String getRealPath(String path) {
        return null;
    }

    public String setImportFileDir(String cstrDirectory) {
        String cstrRetVal = m_cstrCurrentFolder;
        m_cstrCurrentFolder = cstrDirectory;
        return cstrRetVal;
    }

    public String setImportFileDir(String cstrDirectory, boolean relative) {
        String cstrRetVal = m_cstrCurrentFolder;
        m_cstrCurrentFolder = cstrDirectory;
        return cstrRetVal;
    }

    public int setMaxImportFileSize(int iMaxSize) {
        if (!m_boolRequestParamsAccessed) {
            m_iMaxImportFileSize = iMaxSize;
        }

        return m_iMaxImportFileSize;
    }

    public String name() {
        return Integer.toString(m_cstrRequestedURL.hashCode());
    }

    public String getHeader(String name) {
        return (String) m_headers.get(name);
    }

    public String[] getHeaderNames() {
        String[] headers = new String[m_headers.size()];
        int index = 0;
        for (Iterator iterator = m_headers.keySet().iterator(); iterator.hasNext();) {
            headers[index++] = (String) iterator.next();
        }
        return headers;
    }

    public void setHeader(String name, String value) {
        m_headers.put(name, value);
    }

    public void writeXMLDocument(Document doc) {
        m_XMLDoc = doc;
        try {
            DOMUtil.outputXML(doc, getPrintWriter());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeXMLDocument(Document doc, String encoding) {
        m_XMLDoc = doc;
        try {
            DOMUtil.outputXML(doc, getPrintWriter(), encoding);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void expire() {
        m_boolIsExpired = true;
    }

    public String requestedURL() {
        return m_cstrRequestedURL;
    }

    public void redirect(String cstrTo) throws IOException {
        m_cstrTo = cstrTo;
    }

    /**
     * Gets the context attributes.  The <code>HasMap</code> has the attribute name for the key values and the attribute
     * value for the value.  Each are stored as a <code>String</code>.
     *
     * @return The context attributes in a HashMap keyed by the attribute name.
     */
    public HashMap getContextAttributes() {
        return contextAttributes;
    }

    public Object getContextAttribute(String name) {
        return contextAttributes.get(name);
    }

    public void setContextAttribute(String name, Object object) {
        contextAttributes.put(name, object);
    }

    public void removeContextAttribute(String name) {
        contextAttributes.remove(name);
    }

    /* ============== Mock accessors ================ */
    public boolean wasSentTo(String cstrExpectedNextLocation) {
        boolean boolRetVal = false;

        if ((m_cstrTo == null) && (cstrExpectedNextLocation == null)) {
            boolRetVal = true;
        } else {
            if (m_cstrTo != null) {
                boolRetVal = m_cstrTo.equalsIgnoreCase(cstrExpectedNextLocation);
            }
        }

        return boolRetVal;
    }

    public boolean isExpired() {
        return m_boolIsExpired;
    }

    public boolean isMaxInputSize(int iSize) {
        return (m_iMaxImportFileSize == iSize);
    }

    public boolean isContentType(String cstrExpectedContentType) {
        return (m_cstrContentType.equals(cstrExpectedContentType));
    }

    public boolean doesResultContain(String cstrText) {
        return (m_Response.toString().indexOf(cstrText) != -1);
    }

    public String getResponse() {
        return (m_Response == null ? null : m_Response.toString());
    }

    public boolean wasStylesheetUsed() {
        boolean boolRetVal = false;

        if (m_cstrStylesheet != null) {
            File stylesheet = new File(m_cstrStylesheet);
            if (stylesheet.exists()) {
                boolRetVal = true;
            }
        }

        return boolRetVal;
    }

    public String getStylesheetUsed() {
        return m_cstrStylesheet;
    }

    public Map getXSLParamMapUsed(){
        return m_xslParameters;
    }

    /**
     * Returns the XML document that was passed to the helper.
     *
     * @return XML Document that was previously passed to applyStylesheet or writeXMLDocument
     */
    public Document getXML() {
        return m_XMLDoc;
    }

    public boolean wasErrorGenerated() {
        return m_boolErrorReported;
    }

    public void setRequestParameterValue(String key, Object value) {
        if (value == null) {
            m_RequestParameters.put(key, null);
        } else if (value.getClass().isArray()) {
            String[] stringArray = new String[Array.getLength(value)];
            for (int i = 0; i < stringArray.length; i++) {
                stringArray[i] = Array.get(value, i).toString();
            }
            m_RequestParameters.put(key, stringArray);
        } else {
            m_RequestParameters.put(key, value.toString());
        }
    }

    public void setCurrentDirectory(String cstrDir) {
        m_cstrCurrentFolder = cstrDir;
    }

    public URL getResource(String uri) throws IOException {
        return null;
    }

    public void addClientFile(String cstrFileName) {
        m_ClientFiles.add(cstrFileName);
    }

    public String getScratchFolder() {
        String sScratchFolderName = null;
        return sScratchFolderName;
    }

    public void deleteScratchFolder() {

    }

    public boolean isSystemSecurityEnabled() {
        return systemSecurityEnabled;
    }

    public String getAuthenticatedUserID() {
        String userID = null;
        if (isSystemSecurityEnabled()) {
            userID = systemSecurityProxy.getUserID();
        }
        return userID;
    }

    public String getAuthenticatedUserFullName() {
        String fullName = null;
        if (isSystemSecurityEnabled()) {
            fullName = systemSecurityProxy.getFullName();
        }
        return fullName;
    }

    public int getFailedLogonAttempts() {
        int failedLogonAttempts = 0;
        if (isSystemSecurityEnabled()) {
            failedLogonAttempts = systemSecurityProxy.getFailedLogonAttempts();
        }
        return failedLogonAttempts;
    }

    public Date getLastLogon() {
        Date lastLogon = null;
        if (isSystemSecurityEnabled()) {
            lastLogon = systemSecurityProxy.getLastLogon();
        }
        return lastLogon;
    }

    public String getAuthenticatedUserDomain() {
        return null;
    }

    public boolean isUserInRole(String role) {
        return false;
    }

    public Cookie[] getCookies(String dummyValue) {
      return (Cookie[]) cookies.toArray(new Cookie[cookies.size()]);
    }

    public javax.servlet.http.Cookie[] getCookies() {
        return new javax.servlet.http.Cookie[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

  public void addCookie(Cookie cookie) {
    cookies.add(cookie);
  }

  public SystemSecurityProxy getSystemSecurityProxy() {
        return systemSecurityProxy;
    }

    public void setMaxInactiveInterval(int iTimeOut) {
    }


    public void removeRequestParameter(String paramName) {
        m_RequestParameters.remove(paramName);
    }

    public String getServletName() {
        return m_cstrServletName;
    }

    public void setServletName(String servletName) {
        m_cstrServletName = servletName;
    }

    public String getPathInfo() {
        return pathInfo;
    }

    public void setPathInfo(String pathInfo) {
        this.pathInfo = pathInfo;
    }

    public FormRequestData getFormRequestData() {
        return m_formRequestData;
    }

    public void setFormRequestData(FormRequestData formData) {
        m_formRequestData = formData;
    }

    public void writeToFormattedWriter(FormattedWriter writer) throws IOException {
    }

    public String getM_stylesheetContentType() {
        return m_stylesheetContentType;
    }

    public String getRequestURI() {
        String result;
        if (isRequestFullUrl())  {
            result = buildURI();
        } else  {
            result = removeQueryParameters(m_cstrRequestedURL);
        }
        return result;
    }

    private boolean isRequestFullUrl()  {
        return (-1 != m_cstrRequestedURL.indexOf("//"));
    }

    private String buildURI()  {
        int doubleSlashes = m_cstrRequestedURL.indexOf("//") + 2;
        int begin = m_cstrRequestedURL.indexOf("/", doubleSlashes);
        String result = m_cstrRequestedURL.substring(begin);
        return removeQueryParameters(result);
    }

    private String removeQueryParameters(String url)  {
        int end = url.indexOf("?");
        if (-1 == end)  {
            end = url.length();
        }
        return url.substring(0, end);
    }

    public String getContextPath() {
        return "/";
    }

  public   Cookie [] getClientCookies(){
    return null;
  }

}