/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.ITraceLog;

/**
 * <p>Title: MockTraceLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: MockTraceLog.java,v 1.14 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockTraceLog extends MockLog implements ITraceLog {
    public MockTraceLog() {
        super(0);
    }

    public String name() {
        return "MockLog.Trace";
    }

    public String type() {
        return "TRACE";
    }

    public int numLogDevices() {
        return 1;
    }

    /**
     * Returns a string identifying the log device type.  Examples of a log device
     * type are "MidnightRolling", "XML", and "Database".
     *
     * @param j The index of the log device.
     * @return The device type.
     */
    public String getLogDeviceType(int j) {
        if (j > 0) {
            throw new ArrayIndexOutOfBoundsException(j);
        }

        return "MockLogDevice";
    }

    /**
     * Returns location where the log device outputs its results.  For example,
     * this may be a disk file or a database.
     *
     * @param j The index of the log device.
     * @return The device's output location.
     */
    public String getLogDeviceLocation(int j) {
        if (j > 0) {
            throw new ArrayIndexOutOfBoundsException(j);
        }

        return "Location1";
    }

   /**
    * Closes the log.
    */
   public void close()
   {
   }

   public String deviceType() {
       return "MockDevice";
   }

    public boolean hasTracedEntryIntoMethod(String methodName) {
        //Entering  com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryPoint(Logger_UT.java:112)
        String searchString = "Entering " + methodName;
        return this.hasMessageBeenLoggedStartingWith(searchString);
    }


}
