package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.MultiPart.FilePart;
import com.monsanto.ServletFramework.MultiPart.MultipartParser;
import com.monsanto.ServletFramework.MultiPart.Part;
import com.monsanto.ServletFramework.MultipartRequest;
import junit.framework.TestCase;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rdesai2
 * Date: Apr 6, 2006
 * Time: 5:10:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class MultipartRequest_UT extends TestCase {

  private static final String FIRST_FILE_NAME = "input_123.xml";
  private static final String SECOND_FILE_NAME = "testFile1.txt";

  public static final String BOUNDARY = "*****";
  public static final String MIME_TYPE_TEXT = "text/plain";
  public static final String MIME_TYPE_XML = "text/xml";
  public static final String SERVLET_INPUT_STREAM_BOUNDARY_DATA = "--" + BOUNDARY
          + "\r\n";
  public static final String SERVLET_INPUT_STREAM_FILE_1_DATA = "Test XML Data\r\n" + BOUNDARY;
  public static final String SERVLET_INPUT_STREAM_FILE_2_DATA = "Test Attachment Data\r\n" + BOUNDARY;
  public static final String MULTI_PART_FORM_HEADER = "multipart/form-data";
  public static final String MULTI_PART_CONTENT_TYPE = "multipart/form-data;boundary=" + BOUNDARY;

  public void testGetFileNamesReturnsFileNameInTheOrderEncounteredInMultiPartFormData() throws Exception {
    int maxPostSize = 1024;
    HttpServletRequest request = new MockHttpServletRequest();
    String saveDir = System.getProperty("java.io.tmpdir");
    MultipartRequest multipartRequest = new MockMultipartRequest(request, saveDir, maxPostSize);
    Iterator files = multipartRequest.getFileNames();
    assertEquals(FIRST_FILE_NAME, multipartRequest.getFilesystemName((String) files.next()));
    assertEquals(SECOND_FILE_NAME, multipartRequest.getFilesystemName((String) files.next()));
  }

  class MockMultipartRequest extends MultipartRequest {
    public MockMultipartRequest(HttpServletRequest request, String saveDirectory, int maxPostSize) throws IOException {
      super(request, saveDirectory, maxPostSize);
    }

    protected MultipartParser getMultipartParser(HttpServletRequest request, int maxPostSize) throws IOException {
      return new MockMultipartParser(request, maxPostSize, false, false);
    }
  }

  class MockMultipartParser extends MultipartParser{

    private int counter = 0;

    public MockMultipartParser(HttpServletRequest req, int maxSize, boolean buffer, boolean limitLength) throws IOException {
      super(req, maxSize, buffer, limitLength);
    }

    public Part readNextPart() throws IOException {
      FilePart filePart = null;
      byte[] bytes;
      if(counter == 0){
        bytes = SERVLET_INPUT_STREAM_FILE_1_DATA.getBytes();
        filePart = new FilePart("upload53", new MockServletInputStream(bytes), BOUNDARY,
                MIME_TYPE_XML, FIRST_FILE_NAME, "C:/testFilePath/input_123.xml");
      }
      if(counter == 1){
        bytes = SERVLET_INPUT_STREAM_FILE_2_DATA.getBytes();
        filePart = new FilePart("upload117", new MockServletInputStream(bytes), BOUNDARY,
                MIME_TYPE_TEXT, SECOND_FILE_NAME, "C:/testFilePath/testFile1.txt");
      }
      counter++;
      return filePart;
    }
  }

  class MockHttpServletRequest implements HttpServletRequest{

    public String getHeader(String string) {
      return MULTI_PART_FORM_HEADER;
    }

    public ServletInputStream getInputStream() throws IOException {
      return new MockServletInputStream(SERVLET_INPUT_STREAM_BOUNDARY_DATA.getBytes());
    }

    public String getContentType() {
      return MULTI_PART_CONTENT_TYPE;
    }

    public String getAuthType() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Cookie[] getCookies() {
      return new Cookie[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public long getDateHeader(String string) {
      return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Enumeration getHeaders(String string) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Enumeration getHeaderNames() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getIntHeader(String string) {
      return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getMethod() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getPathInfo() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getPathTranslated() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getContextPath() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getQueryString() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getRemoteUser() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isUserInRole(String string) {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Principal getUserPrincipal() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getRequestedSessionId() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getRequestURI() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public StringBuffer getRequestURL() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getServletPath() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public HttpSession getSession(boolean b) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public HttpSession getSession() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isRequestedSessionIdValid() {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isRequestedSessionIdFromCookie() {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isRequestedSessionIdFromURL() {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isRequestedSessionIdFromUrl() {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Object getAttribute(String string) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Enumeration getAttributeNames() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getCharacterEncoding() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setCharacterEncoding(String string) throws UnsupportedEncodingException {
      //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getContentLength() {
      return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getParameter(String string) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Enumeration getParameterNames() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String[] getParameterValues(String string) {
      return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Map getParameterMap() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getProtocol() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getScheme() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getServerName() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getServerPort() {
      return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public BufferedReader getReader() throws IOException {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getRemoteAddr() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getRemoteHost() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setAttribute(String string, Object object) {
      //To change body of implemented methods use File | Settings | File Templates.
    }

    public void removeAttribute(String string) {
      //To change body of implemented methods use File | Settings | File Templates.
    }

    public Locale getLocale() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public Enumeration getLocales() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isSecure() {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public RequestDispatcher getRequestDispatcher(String string) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getRealPath(String string) {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getRemotePort() {
      return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getLocalName() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getLocalAddr() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public int getLocalPort() {
      return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }
  }

  class MockServletInputStream extends ServletInputStream{

    private byte[] bytes;
    private int counter = 0;

    public MockServletInputStream(byte[] bytes) {
      this.bytes = bytes;
    }

    public int read() throws IOException {
      int bytesLength = bytes.length;
      byte currentByte;
      if (counter < bytesLength) {
        currentByte = bytes[counter];
      } else{
        currentByte = -1;
      }
      counter++;
      return currentByte;
    }
  }
}