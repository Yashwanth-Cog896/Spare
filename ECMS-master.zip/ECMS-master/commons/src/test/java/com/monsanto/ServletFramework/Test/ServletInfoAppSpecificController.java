package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.ServletInfoController;

import java.io.PrintWriter;

/**
 * Created by IntelliJ IDEA.
* User: MECORU
* Date: Aug 24, 2007
* Time: 6:48:49 PM
* To change this template use File | Settings | File Templates.
*/
public class ServletInfoAppSpecificController extends ServletInfoController {
	protected void outputApplicationSpecificInformation(PrintWriter out) {
		out.println("HELLO WORLD FROM APPLICATION SPECIFIC CONTROLLER");
	}
}
