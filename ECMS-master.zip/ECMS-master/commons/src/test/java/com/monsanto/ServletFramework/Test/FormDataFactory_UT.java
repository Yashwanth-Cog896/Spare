package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.FormDataFactory;
import com.monsanto.ServletFramework.FormRequestData;
import junit.framework.TestCase;
import org.apache.commons.beanutils.BeanUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Nov 17, 2005
 * Time: 5:30:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class FormDataFactory_UT extends TestCase {

  public void testGetFormRequestDataToPopulate_NoDataInterfaces_ReturnsRawFormRequestData() throws Exception {
    MockConcreteForm form = new MockConcreteForm();
    FormDataFactory factory = new FormDataFactory(new MockUCCHelper(""));
    FormRequestData newFormData = factory.getFormRequestDataToPopulate(form);
    ((MockConcreteForm)newFormData).setAmount(45);
    assertEquals(45,((MockConcreteForm)newFormData).getAmount());
  }

  public void testGetFormRequestDataToPopulate_DataInterfaceExists_ReturnsProxyFormRequestData() throws Exception {
    MockConcreteFormWithList form = new MockConcreteFormWithList();
    FormDataFactory factory = new FormDataFactory(new MockUCCHelper(""));
    FormRequestData newFormData = factory.getFormRequestDataToPopulate(form);
    Map map = new HashMap();
    map.put("stringListData[0]", "bye");
    map.put("stringListData[1]", "hello");
    BeanUtils.populate(newFormData, map);

    assertEquals("bye", form.getStringListData(0));
    assertEquals("hello", form.getStringListData(1));
  }

}
