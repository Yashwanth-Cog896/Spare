/*
 MockControllerForUccManagerTest was created on Oct 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;

import java.io.IOException;

/**
 * <p>Title: MockControllerForUccManagerTest</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockControllerForUccManagerTestThrowable.java,v 1.8 2007-09-12 22:56:14 ardharn Exp $
 */
public class MockControllerForUccManagerTestThrowable implements UseCaseController
{
   public void run (UCCHelper helper) throws IOException
   {
      throw new AbstractMethodError("Fake Error for Throwable to catch");
   }
}
