package com.monsanto.servletsecurity.Test;

import com.monsanto.servletsecurity.ServletSystemSecurityProxy;
import org.ietf.jgss.GSSCredential;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MECORU
 * Date: Mar 3, 2005
 * Time: 12:48:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class MockServletSystemSecurityProxy implements ServletSystemSecurityProxy {
  public final static String AUTHENTICATED_USERID = "MECORU";

  public String getUserID() {
    return AUTHENTICATED_USERID;
  }

  public String getFullName() {
    return "Michael E Corum";
  }

  public int getFailedLogonAttempts() {
    return 0;
  }

  public Date getLastLogon() {
    return null;
  }

  public void init(HttpServletRequest request) {
  }

  public GSSCredential getDelegCredential() {
    return null;
  }
}
