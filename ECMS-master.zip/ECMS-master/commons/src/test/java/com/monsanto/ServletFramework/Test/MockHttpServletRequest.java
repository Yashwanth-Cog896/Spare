/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ServletFramework.Test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockHttpServletRequest.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ardharn $    	 On:	$Date: 2007-09-12 22:56:14 $
*
* @author paprit
* @version $Revision: 1.9 $
*/
public class MockHttpServletRequest implements HttpServletRequest {
  private int contentLength = 0;
  private byte[] bytes;
  private int numNullsToSendFirst;
  private HttpSession httpSession;

  public MockHttpServletRequest(int numNullsToSendFirst) {
    this.numNullsToSendFirst = numNullsToSendFirst;
    bytes = getContentBytes();
    contentLength = bytes.length;
  }

  public MockHttpServletRequest(HttpSession httpSession) {
    this.httpSession = httpSession;
  }

  public String getHeader(String string) {
    return MultipartRequest_UT.MULTI_PART_FORM_HEADER;
  }

  public ServletInputStream getInputStream() throws IOException {
    return new MockServletInputStream(bytes, numNullsToSendFirst);
  }

  private byte[] getContentBytes() {
    String content = MultipartRequest_UT.SERVLET_INPUT_STREAM_BOUNDARY_DATA;
    content += "Content-Disposition: form-data; name=\"field1\"; filename=\"file1.txt\"\r\n";
    content += "Content-Type: type/subtype\r\n";
    content += "Content-Transfer-Encoding: binary\r\n";
    content += "\r\nThis is content line 1.\r\nThis is content line 2.\r\n";
    content += MultipartRequest_UT.SERVLET_INPUT_STREAM_BOUNDARY_DATA;
    return content.getBytes();
  }

  public String getContentType() {
    return MultipartRequest_UT.MULTI_PART_CONTENT_TYPE;
  }

  public String getAuthType() {
    return null;
  }

  public Cookie[] getCookies() {
    return new Cookie[0];
  }

  public long getDateHeader(String string) {
    return 0;
  }

  public Enumeration getHeaders(String string) {
    return null;
  }

  public Enumeration getHeaderNames() {
    return null;
  }

  public int getIntHeader(String string) {
    return 0;
  }

  public String getMethod() {
    return null;
  }

  public String getPathInfo() {
    return null;
  }

  public String getPathTranslated() {
    return null;
  }

  public String getContextPath() {
    return null;
  }

  public String getQueryString() {
    return null;
  }

  public String getRemoteUser() {
    return null;
  }

  public boolean isUserInRole(String string) {
    return false;
  }

  public Principal getUserPrincipal() {
    return null;
  }

  public String getRequestedSessionId() {
    return null;
  }

  public String getRequestURI() {
    return null;
  }

  public StringBuffer getRequestURL() {
    return null;
  }

  public String getServletPath() {
    return null;
  }

  public HttpSession getSession(boolean b) {
    return httpSession;
  }

  public HttpSession getSession() {
    return httpSession;
  }

  public boolean isRequestedSessionIdValid() {
    return false;
  }

  public boolean isRequestedSessionIdFromCookie() {
    return false;
  }

  public boolean isRequestedSessionIdFromURL() {
    return false;
  }

  public boolean isRequestedSessionIdFromUrl() {
    return false;
  }

  public Object getAttribute(String string) {
    return null;
  }

  public Enumeration getAttributeNames() {
    return null;
  }

  public String getCharacterEncoding() {
    return null;
  }

  public void setCharacterEncoding(String string) throws UnsupportedEncodingException {

  }

  public int getContentLength() {
    return contentLength;
  }

  public String getParameter(String string) {
    return null;
  }

  public Enumeration getParameterNames() {
    return null;
  }

  public String[] getParameterValues(String string) {
    return new String[0];
  }

  public Map getParameterMap() {
    return null;
  }

  public String getProtocol() {
    return null;
  }

  public String getScheme() {
    return null;
  }

  public String getServerName() {
    return null;
  }

  public int getServerPort() {
    return 0;
  }

  public BufferedReader getReader() throws IOException {
    return null;
  }

  public String getRemoteAddr() {
    return null;
  }

  public String getRemoteHost() {
    return null;
  }

  public void setAttribute(String string, Object object) {

  }

  public void removeAttribute(String string) {

  }

  public Locale getLocale() {
    return null;
  }

  public Enumeration getLocales() {
    return null;
  }

  public boolean isSecure() {
    return false;
  }

  public RequestDispatcher getRequestDispatcher(String string) {
    return null;
  }

  public String getRealPath(String string) {
    return null;
  }

  public int getRemotePort() {
    return 0;
  }

  public String getLocalName() {
    return null;
  }

  public String getLocalAddr() {
    return null;
  }

  public int getLocalPort() {
    return 0;
  }
}