package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.BlockingUseCaseControllerImpl;
import com.monsanto.ServletFramework.UCCHelper;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Apr 1, 2005
 * Time: 4:21:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockBlockingController extends BlockingUseCaseControllerImpl
{
   private static int count = 0;

   public int getCount() {
      return count;
   }

   public static void reset() {
      count = 0;
   }

   public void run(UCCHelper helper) throws IOException {
      ++ count;

      try {
         Thread.sleep(500);
      } catch (InterruptedException e) {
         e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      }
   }


}




