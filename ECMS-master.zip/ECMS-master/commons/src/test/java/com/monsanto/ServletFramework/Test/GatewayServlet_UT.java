package com.monsanto.ServletFramework.Test;

import com.meterware.servletunit.InvocationContext;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.servletsecurity.Test.MockServletSystemSecurityProxy;
import junit.framework.TestCase;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA. User: MECORU Date: Mar 3, 2005 Time: 12:36:59 AM To change this template use File |
 * Settings | File Templates.
 */
public class GatewayServlet_UT extends TestCase {
    private static final String TEST_SERVLET_URL = "http://localhost:8080/testServlet";
    private ServletRunner m_sr = new ServletRunner();
    private ServletUnitClient m_sc = m_sr.newClient();

    protected void setUp() throws Exception {
        m_sr.registerServlet("testServlet", testServlet.class.getName());
    }

    public void testCreateHelper() throws IOException {
        System.setProperty(GatewayServlet.SYSTEM_SECURITY_PROXY,
            "com.monsanto.servletsecurity.Test.MockServletSystemSecurityProxy");
        MockGatewayServlet servlet = new MockGatewayServlet();

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest request = invocation.getRequest();
        HttpServletResponse response = invocation.getResponse();
        UCCHelper helper = servlet.createHelper(request, response);


        assertTrue(helper.isSystemSecurityEnabled());
        assertEquals(MockServletSystemSecurityProxy.AUTHENTICATED_USERID, helper.getAuthenticatedUserID());
    }

    public void testCreateHelperWithFailedSystemSecurityProxy() throws IOException {
        System.setProperty(GatewayServlet.SYSTEM_SECURITY_PROXY,
            "com.monsanto.servletsecurity.Test.MockServletSystemSecurityProxyForFailure");
        MockGatewayServlet servlet = new MockGatewayServlet();

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest request = invocation.getRequest();
        HttpServletResponse response = invocation.getResponse();
        UCCHelper helper = servlet.createHelper(request, response);

        assertFalse(helper.isSystemSecurityEnabled());
    }

    public void testInitializeSessionTimeout() throws IOException, ServletException {
        System.setProperty(GatewayServlet.SYSTEM_SECURITY_PROXY,
            "com.monsanto.servletsecurity.Test.MockServletSystemSecurityProxy");
        MockGatewayServlet servlet = new MockGatewayServlet(5);

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest request = invocation.getRequest();
        HttpServletResponse response = invocation.getResponse();

        servlet.doGet(request, response);
        assertEquals(5, request.getSession().getMaxInactiveInterval());
    }

    public void testDefaultConstructorTimeout() throws IOException, ServletException {
        System.setProperty(GatewayServlet.SYSTEM_SECURITY_PROXY,
            "com.monsanto.servletsecurity.Test.MockServletSystemSecurityProxy");
        MockGatewayServlet servlet = new MockGatewayServlet();

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest request = invocation.getRequest();
        HttpServletResponse response = invocation.getResponse();

        servlet.doGet(request, response);
        assertEquals(0, request.getSession().getMaxInactiveInterval());
    }

    public void testDoPostIsMappedToDoGet() throws IOException, ServletException {
        MockGatewayServlet servlet = new MockGatewayServlet();

        InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);
        HttpServletRequest request = invocation.getRequest();
        HttpServletResponse response = invocation.getResponse();

        servlet.doPost(request, response);

        assertTrue(servlet.wasDoGetCalled());
    }

    class MockGatewayServlet extends GatewayServlet {
        private boolean m_boolDoGetCalled = false;

        public MockGatewayServlet() {
            super();
        }

        public MockGatewayServlet(int sessionTimeout) {
            super(sessionTimeout);
        }

        public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
            m_boolDoGetCalled = true;

            super.doGet(request, response);
        }

        public String getInitParameter(String s) {
            return null;
        }

        protected UCCHelper createHelper(HttpServletRequest request, HttpServletResponse response) {
            return super.createHelper(request, response);
        }

        public boolean wasDoGetCalled() {
            return m_boolDoGetCalled;
        }
    }

}
