package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCManager;

/**
 * Created by IntelliJ IDEA.
 * User: MECORU
 * Date: Aug 24, 2007
 * Time: 6:49:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServletInfoAppSpecificServlet extends ServletInfoServlet {
		protected void runServletInfoController(UCCHelper helper) {
			UCCManager.runController("com.monsanto.ServletFramework.Test.ServletInfoAppSpecificController", helper);
		}
	}
