/*
 Copyright:  Copyright 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.ServletFramework.Test;

import javax.servlet.ServletInputStream;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MockServletInputStream.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ardharn $    	 On:	$Date: 2007-09-12 22:56:14 $
*
* @author paprit
* @version $Revision: 1.8 $
*/
public class MockServletInputStream extends ServletInputStream {

  private byte[] contentBytes;
  private int numNullsToSendFirst;
  private int numNullsSent = 0;
  private int counter = 0;

  public MockServletInputStream(byte[] bytes, int numNullsToSendFirst) {
    this.contentBytes = bytes;
    this.numNullsToSendFirst = numNullsToSendFirst;
  }

  public int read() throws IOException {
    if (numNullsSent < numNullsToSendFirst) {
      numNullsSent++;
      return -1;
    }
    int bytesLength = contentBytes.length;
    byte currentByte;
    if (counter < bytesLength) {
      currentByte = contentBytes[counter];
    } else{
      currentByte = -1;
    }
    counter++;
    return currentByte;
  }
}