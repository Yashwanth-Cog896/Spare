/*
 Logger_UT was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

/**
 * <p>Title: Logger_UT</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: Logger_UT.java,v 1.32 2007/09/12 22:31:42 ardharn Exp $
 */
public class Logger_UT extends LoggingUTBase {
    public Logger_UT(String s) {
        super(s);
    }

    protected void setUp() throws Exception {
        super.setUp();

        Logger.closeLogging();
    }

    protected void tearDown() throws Exception {
        Logger.closeLogging();

        super.tearDown();
    }

    /* ========== Performance Log Tests ============== */
    public void testRegisterPerformanceLogReturnsPreviousTraceLog() throws LogRegistrationException {
        IPerformanceLog newLog = new MockPerformanceLog();
        IPerformanceLog oldLog = new MockPerformanceLog();

        IPerformanceLog returnedLog = Logger.register(oldLog);
        assertNull(returnedLog);

        returnedLog = Logger.register(newLog);
        assertTrue(returnedLog == oldLog);
    }

    public void testPerformanceLogGetsMessage() throws LogRegistrationException {
        Logger.register(new MockPerformanceLog(), true);

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        IPerformanceLog mockLog = Logger.register((IPerformanceLog) null);

        assertEquals(1, ((MockPerformanceLog) mockLog).messagesReceived());
        assertTrue(((MockPerformanceLog) mockLog).hasMessageBeenLogged("Value 1"));
    }

    public void testPerformanceLogCanBeShutOff() throws LogRegistrationException {
        Logger.log(new LoggablePerformanceMetric("Value 1"));  // Not logged

        Logger.register(new MockPerformanceLog(), true);  // Enable performance logger.

        Logger.log(new LoggablePerformanceMetric("Value 2"));  // Logged

        IPerformanceLog mockLog = Logger.register((IPerformanceLog) null);

        Logger.log(new LoggablePerformanceMetric("Value 3"));  // Not Logged

        assertEquals(1, ((MockPerformanceLog) mockLog).messagesReceived());
    }

    public void testPerformanceLogCanBeTurnedOnAndOff() throws LogRegistrationException {
        Logger.log(new LoggablePerformanceMetric("Value 1"));  // NOOP since log is not enabled.

        Logger.register(new MockPerformanceLog());  // Register performance logger.  Don't enabled it yet.

        Logger.log(new LoggablePerformanceMetric("Value 1"));  // NOOP since log is not enabled.

        Logger.enableLogger(Logger.PERFORMANCE_LOG);

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        Logger.disableLogger(Logger.PERFORMANCE_LOG);

        Logger.log(new LoggablePerformanceMetric("Value 1"));  // NOOP since log is not enabled.

        Logger.enableLogger(Logger.PERFORMANCE_LOG);   // Enable again.

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        IPerformanceLog mockLog = Logger.register((IPerformanceLog) null);

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        assertEquals(2, ((MockPerformanceLog) mockLog).messagesReceived());
    }

  /**
   * @deprecated deprecated test of deprecated methods
   */
    public void testPerformanceLogCanBeTurnedOnAndOffDeprecated() throws LogRegistrationException {
        Logger.log(new LoggablePerformanceMetric("Value 1"));  // NOOP since log is not enabled.

        Logger.register(new MockPerformanceLog());  // Register performance logger.  Don't enabled it yet.

        Logger.log(new LoggablePerformanceMetric("Value 1"));  // NOOP since log is not enabled.

        Logger.enablePerformanceMonitor();

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        Logger.disablePerformanceMonitor();

        Logger.log(new LoggablePerformanceMetric("Value 1"));  // NOOP since log is not enabled.

        Logger.enablePerformanceMonitor();  // Enable again.

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        IPerformanceLog mockLog = Logger.register((IPerformanceLog) null);

        Logger.log(new LoggablePerformanceMetric("Value 1"));

        assertEquals(2, ((MockPerformanceLog) mockLog).messagesReceived());
    }

    public void testDeregisteringPerformanceLoggerMultipleTimmes() throws LogRegistrationException {
        Logger.register((IPerformanceLog) null);
        Logger.register((IPerformanceLog) null);
        Logger.register((IPerformanceLog) null);
    }

    public void testReregisteringSamePerformanceLogTwiceDoesNotChangeLogger() throws LogRegistrationException {
        IPerformanceLog log1 = new MockPerformanceLog();
        Logger.register(log1, true);
        Logger.log(new LoggablePerformanceMetric("Info 1"));
        Logger.log(new LoggablePerformanceMetric("Info 2"));
        assertEquals(2, ((MockPerformanceLog) log1).messagesReceived());
        assertTrue(((MockPerformanceLog) log1).hasMessageBeenLogged("Info 1"));
        assertTrue(((MockPerformanceLog) log1).hasMessageBeenLogged("Info 2"));

        IPerformanceLog log2 = new MockPerformanceLog();
        Logger.register(log2, true);  // Should have no effect since all MockPerformanceLogs are equal.
        Logger.log(new LoggablePerformanceMetric("Info 3"));
        assertEquals(3, ((MockPerformanceLog) log1).messagesReceived());
        assertEquals(0, ((MockPerformanceLog) log2).messagesReceived());
        assertTrue(((MockPerformanceLog) log1).hasMessageBeenLogged("Info 3"));
    }

    public void testReregisterPerformanceLog() throws LogRegistrationException {
        IPerformanceLog log1 = new MockPerformanceLog(0);
        Logger.register(log1, true);
        Logger.log(new LoggablePerformanceMetric("Info 1"));
        Logger.log(new LoggablePerformanceMetric("Info 2"));
        assertEquals(2, ((MockPerformanceLog) log1).messagesReceived());
        assertTrue(((MockPerformanceLog) log1).hasMessageBeenLogged("Info 1"));
        assertTrue(((MockPerformanceLog) log1).hasMessageBeenLogged("Info 2"));

        IPerformanceLog log2 = new MockPerformanceLog(1);
        Logger.register(log2, true);
        Logger.log(new LoggablePerformanceMetric("Info 3"));
        assertEquals(1, ((MockPerformanceLog) log2).messagesReceived());
        assertTrue(((MockPerformanceLog) log2).hasMessageBeenLogged("Info 3"));

        Logger.register((IPerformanceLog) null);

        IPerformanceLog log3 = new MockPerformanceLog(2);
        Logger.register(log3, true);
        Logger.log(new LoggablePerformanceMetric("Info 4"));
        Logger.log(new LoggablePerformanceMetric("Info 5"));
        Logger.log(new LoggablePerformanceMetric("Info 6"));
        assertEquals(3, ((MockPerformanceLog) log3).messagesReceived());
        assertTrue(((MockPerformanceLog) log3).hasMessageBeenLogged("Info 4"));
        assertTrue(((MockPerformanceLog) log3).hasMessageBeenLogged("Info 5"));
        assertTrue(((MockPerformanceLog) log3).hasMessageBeenLogged("Info 6"));
    }

    public void testEnablingPerformanceLoggerWhenNoPerformanceLoggerRegisteredWritesMessageToWarningLog() throws LogRegistrationException {
        MockWarningLog warningLog = new MockWarningLog();

        Logger.register(warningLog);

        Logger.enableLogger(Logger.PERFORMANCE_LOG);

        assertEquals(1, ((MockWarningLog) warningLog).messagesReceived());
        assertTrue(((MockWarningLog) warningLog).hasMessageBeenLoggedContaining(Logger.PERFORMANCE_LOG + " enabled but there is no log device registered."));
    }

  /**
   * @deprecated deprecated test of deprecated method
   */
    public void testEnablingPerformanceLoggerWhenNoPerformanceLoggerRegisteredWritesMessageToWarningLogDeprecated() throws LogRegistrationException {
        MockWarningLog warningLog = new MockWarningLog();

        Logger.register(warningLog);

        Logger.enablePerformanceMonitor();

        assertEquals(1, ((MockWarningLog) warningLog).messagesReceived());
        assertTrue(((MockWarningLog) warningLog).hasMessageBeenLoggedContaining(Logger.PERFORMANCE_LOG + " enabled but there is no log device registered."));
    }

    /* ========== Trace Log Tests ============== */
    public void testRegisterTraceLogReturnsPreviousTraceLog() throws LogRegistrationException {
        ITraceLog newLog = new MockTraceLog();
        ITraceLog oldLog = new MockTraceLog();

        ITraceLog returnedLog = Logger.register(oldLog);
        assertNull(returnedLog);

        returnedLog = Logger.register(newLog);
        assertTrue(returnedLog == oldLog);
    }

    public void testTraceLogCanBeShutOff() throws LogRegistrationException {
        traceExitReturnsVoid();    // Not logged

        Logger.register(new MockTraceLog(), true);  // Enable trace logger.

        traceExitReturnsVoid();   // Logged

        ITraceLog mockLog = Logger.register((ITraceLog) null);

        traceExitReturnsVoid();   // Not Logged

        assertEquals(2, ((MockTraceLog) mockLog).messagesReceived());  // 2 because traceExitReturnsVoid calls traceEntry() & traceExit()
    }

    public void testTraceLogCanBeTurnedOnAndOff() throws LogRegistrationException {
        traceExitReturnsVoid();  // NOOP since traing is not enabled.

        Logger.register(new MockTraceLog());  // Enable trace logger.  Don't enabled it yet.

        traceExitReturnsVoid();  // NOOP since tracing is not enabled.

        Logger.enableLogger(Logger.TRACE_LOG);  // Enable tracing

        traceExitReturnsVoid();  // Generate some trace data

        Logger.disableLogger(Logger.TRACE_LOG);  // Deactivate tracing

        traceExitReturnsVoid();  // NOOP since tracing is not enabled.

        Logger.enableLogger(Logger.TRACE_LOG);  // Enable tracing again.

        traceExitReturnsVoid();  // Generate some more trace data

        ITraceLog mockLog = Logger.register((ITraceLog) null);  // Eliminate tracing

        traceExitReturnsVoid();

        assertEquals(4, ((MockTraceLog) mockLog).messagesReceived());
    }

  /**
   * @deprecated deprecated test of deprecated method
   */
    public void testTraceLogCanBeTurnedOnAndOffDeprecated() throws LogRegistrationException {
        traceExitReturnsVoid();  // NOOP since traing is not enabled.

        Logger.register(new MockTraceLog());  // Enable trace logger.  Don't enabled it yet.

        traceExitReturnsVoid();  // NOOP since tracing is not enabled.

        Logger.enableTrace();  // Enable tracing

        traceExitReturnsVoid();  // Generate some trace data

        Logger.disableTrace();  // Deactivate tracing

        traceExitReturnsVoid();  // NOOP since tracing is not enabled.

        Logger.enableTrace();  // Enable tracing again.

        traceExitReturnsVoid();  // Generate some more trace data

        ITraceLog mockLog = Logger.register((ITraceLog) null);  // Eliminate tracing

        traceExitReturnsVoid();

        assertEquals(4, ((MockTraceLog) mockLog).messagesReceived());
    }

    public void testTraceEntryPoint() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true); // Enable trace logger.

        Logger.traceEntry();
        assertEquals(1, traceLog.messagesReceived());

        //we know that the first word should be 'Entering' followed by our method name
        assertTrue("Could not find correct method trace!",
                traceLog.hasTracedEntryIntoMethod("com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryPoint"));
    }

    public void testTraceEntryWithNullArgument() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true); // Enable trace logger.

        Logger.traceEntry(null);
        assertEquals(1, traceLog.messagesReceived());

        assertTrue("Could not find correct method trace!",
                traceLog.hasTracedEntryIntoMethod(
                        "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryWithNullArgument"));
        assertTrue("Empty argument list should be included in logged message",
                traceLog.hasMessageBeenLoggedContaining("Arguments {}"));
    }

    public void testTraceEntryWithNoArguments() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true); // Enable trace logger.

        Logger.traceEntry(new Object[]{});
        assertEquals(1, traceLog.messagesReceived());
        assertTrue("Empty argument list should be included in logged message",
                traceLog.hasMessageBeenLoggedContaining("Arguments {}"));
    }

    public void testTraceEntryWithOneArgument() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true); // Enable trace logger.

        Logger.traceEntry(new Object[]{"Input Value"});
        assertEquals(1, traceLog.messagesReceived());
        assertTrue("Argument value should be included in logged message",
                traceLog.hasMessageBeenLoggedContaining("Arguments {Input Value}"));
    }

    public void testTraceEntryWithMultipleArgumentsOfDifferentTypes() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true); // Enable trace logger.

        Logger.traceEntry(new Object[]{"Input Value", new Boolean(true), new Double(3.14159)});
        assertEquals(1, traceLog.messagesReceived());
        assertTrue("Argument values should be included in logged message",
                traceLog.hasMessageBeenLoggedContaining("Arguments {Input Value, true, 3.14159}"));
    }

    public void testTraceEntryWithSpecifiedMethodName() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true); // Enable trace logger.

        Logger.traceEntry(null, "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryWithNullArgument");
        assertEquals(1, traceLog.messagesReceived());
        assertTrue("Could not find correct method trace!",
                traceLog.hasTracedEntryIntoMethod(
                        "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryWithNullArgument"));
    }

    public void testTraceEntryWithParametersAndNoLoggerRegistered() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();

        Logger.traceEntry(new Object[]{"Input Value", new Boolean(true), new Double(3.14159)});
        assertEquals(0, traceLog.messagesReceived());
    }

    public void testTraceEntryWithParametersAndLoggerRegisteredAndTraceLoggingTurnedOff()
            throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, false); // Disable trace logger.

        Logger.traceEntry(new Object[]{"Input Value", new Boolean(true), new Double(3.14159)});
        assertEquals(0, traceLog.messagesReceived());
    }

    public void testTraceEntryWithMethodNameWithParametersAndNoLoggerRegistered() throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();

        Logger.traceEntry(new Object[]{"Input Value", new Boolean(true), new Double(3.14159)},
                "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryWithMethodNameWithParametersAndNoLoggerRegistered");
        assertEquals(0, traceLog.messagesReceived());
    }

    public void testTraceEntryWithMethodNameWithParametersAndLoggerRegisteredAndTraceLoggingTurnedOff()
            throws LogRegistrationException {
        MockTraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, false); // Disable trace logger.

        Logger.traceEntry(new Object[]{"Input Value", new Boolean(true), new Double(3.14159)},
                "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceEntryWithMethodNameWithParametersAndLoggerRegisteredAndTraceLoggingTurnedOff");
        assertEquals(0, traceLog.messagesReceived());
    }

    public void testTraceExitOnVoidReturn() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        traceExitReturnsVoid();

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnObjectReturn() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        ArrayList al1 = new ArrayList();
        al1.add("String 1");
        al1.add("String 2");

        ArrayList al2 = traceExitReturnsArrayList(al1);
        assertNotNull(al2);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = '[String 1, String 2]'"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnObjectReturnTraceLoggingDisabled() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, false);

        ArrayList al1 = new ArrayList();
        al1.add("String 1");
        al1.add("String 2");

        ArrayList al2 = traceExitReturnsArrayList(al1);
        assertNotNull(al2);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnObjectReturnNoLoggerRegistered() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();

        ArrayList al1 = new ArrayList();
        al1.add("String 1");
        al1.add("String 2");

        ArrayList al2 = traceExitReturnsArrayList(al1);
        assertNotNull(al2);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnObjectReturnWhenParameterIsNull() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        Object obj = null;
        obj = traceExitReturnsObject(obj);
        assertNull(obj);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = '<null>'"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitReturningObjectWithSpecifiedMethodName() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        ArrayList al1 = new ArrayList();
        al1.add("String 1");
        al1.add("String 2");

        ArrayList al2 = (ArrayList) Logger.traceExit(al1,
                "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceExitOnObjectReturn");
        assertNotNull(al2);
        assertEquals(1, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(
                ((MockTraceLog) traceLog).hasMessageBeenLoggedContaining(
                        "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceExitOnObjectReturn"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitReturningNullObjectWithSpecifiedMethodName() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        ArrayList al1 = null;

        ArrayList al2 = (ArrayList) Logger.traceExit(al1,
                "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceExitOnObjectReturn");
        assertNull(al2);
        assertEquals(1, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(
                ((MockTraceLog) traceLog).hasMessageBeenLoggedContaining(
                        "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceExitOnObjectReturn"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitReturningObjectWithSpecifiedMethodNameLoggerDisabled() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, false);

        ArrayList al1 = new ArrayList();
        al1.add("String 1");
        al1.add("String 2");

        ArrayList al2 = (ArrayList) Logger.traceExit(al1,
                "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceExitOnObjectReturn");
        assertNotNull(al2);
        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitReturningObjectWithSpecifiedMethodNameNoLoggerRegistered() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();

        ArrayList al1 = new ArrayList();
        al1.add("String 1");
        al1.add("String 2");

        ArrayList al2 = (ArrayList) Logger.traceExit(al1,
                "com.monsanto.AbstractLogging.Test.Logger_UT.testTraceExitOnObjectReturn");
        assertNotNull(al2);
        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnIntReturn() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        int iRetVal = traceExitReturnsInt(1234);
        assertEquals(1234, iRetVal);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = '1234'"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnIntReturnWithTraceLoggingDisabled() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog);

        int iRetVal = traceExitReturnsInt(1234);
        assertEquals(1234, iRetVal);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnIntReturnWithTraceLoggingNotRegistered() throws LogRegistrationException {
        Logger.closeLogging();

        ITraceLog traceLog = new MockTraceLog();

        int iRetVal = traceExitReturnsInt(1234);
        assertEquals(1234, iRetVal);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnDoubleReturn() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        double dRetVal = traceExitReturnsDouble(1234.5678);
        assertEquals(1234.5678, dRetVal, 0.00005);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = '1234.5678'"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnDoubleReturnWithTraceLoggingDisabled() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog);

        double dRetVal = traceExitReturnsDouble(1234.5678);
        assertEquals(1234.5678, dRetVal, 0.00005);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnDoubleReturnWithNoTraceLoggingRegistered() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();

        double dRetVal = traceExitReturnsDouble(1234.5678);
        assertEquals(1234.5678, dRetVal, 0.00005);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnBooleanReturn() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        boolean boolRetVal = traceExitReturnsBoolean(false);
        assertFalse(boolRetVal);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = 'false'"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnBooleanReturnWithTraceLoggingDisabled() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog);

        boolean boolRetVal = traceExitReturnsBoolean(false);
        assertFalse(boolRetVal);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnBooleanReturnWithNoTraceLoggingRegistered() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog);

        boolean boolRetVal = traceExitReturnsBoolean(false);
        assertFalse(boolRetVal);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnStringReturn() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        String cstrRetVal = traceExitReturnsString("String 1");
        assertEquals("String 1", cstrRetVal);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = 'String 1'"));

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnStringReturnWithTraceLoggerDisabled() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog);

        String cstrRetVal = traceExitReturnsString("String 1");
        assertEquals("String 1", cstrRetVal);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnStringReturnWithNoTraceLoggerRegistered() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog);

        String cstrRetVal = traceExitReturnsString("String 1");
        assertEquals("String 1", cstrRetVal);

        assertEquals(0, ((MockTraceLog) traceLog).messagesReceived());

        Logger.register((ITraceLog) null);
    }

    public void testTraceExitOnStringReturnWhenParameterIsNull() throws LogRegistrationException {
        ITraceLog traceLog = new MockTraceLog();
        Logger.register(traceLog, true);  // Enable trace logger.

        String cstrRetVal = null;
        cstrRetVal = traceExitReturnsString(cstrRetVal);
        assertNull(cstrRetVal);

        assertEquals(2, ((MockTraceLog) traceLog).messagesReceived());
        assertTrue(((MockTraceLog) traceLog).hasMessageBeenLoggedContaining("RetVal = '<null>'"));

        Logger.register((ITraceLog) null);
    }

    public void testEnablingTraceWhenNoTraceLoggerRegisteredWritesMessageToWarningLog() throws LogRegistrationException {
        MockWarningLog warningLog = new MockWarningLog();

        Logger.register(warningLog);

        Logger.enableLogger(Logger.TRACE_LOG);

        assertEquals(1, ((MockWarningLog) warningLog).messagesReceived());
        assertTrue(((MockWarningLog) warningLog).hasMessageBeenLoggedContaining( Logger.TRACE_LOG + " enabled but there is no log device registered."));
    }

  /**
   * @deprecated deprecated test of deprecated method
   */
    public void testEnablingTraceWhenNoTraceLoggerRegisteredWritesMessageToWarningLogDeprecated() throws LogRegistrationException {
        MockWarningLog warningLog = new MockWarningLog();

        Logger.register(warningLog);

        Logger.enableTrace();

        assertEquals(1, ((MockWarningLog) warningLog).messagesReceived());
        assertTrue(((MockWarningLog) warningLog).hasMessageBeenLoggedContaining( Logger.TRACE_LOG + " enabled but there is no log device registered."));
    }

    /* ========== Info Log Tests ============== */
    public void testRegisterInfoLogReturnsPreviousInfoLog() throws LogRegistrationException {
        IInfoLog newLog = new MockInfoLog();
        IInfoLog oldLog = new MockInfoLog();

        IInfoLog returnedLog = Logger.register(oldLog);
        assertNull(returnedLog);

        returnedLog = Logger.register(newLog);
        assertTrue(returnedLog == oldLog);
    }

    public void testInfoLogGetsMessage() throws LogRegistrationException {
        Logger.register(new MockInfoLog());  // Enable info logging

        Logger.log(new LoggableInfo("Info 1"));  // Send a message that should be logged

        IInfoLog mockLog = Logger.register((IInfoLog) null);  // Turn info logging off

        assertEquals(1, ((MockInfoLog) mockLog).messagesReceived());
        assertTrue(((MockInfoLog) mockLog).hasMessageBeenLogged("Info 1"));
    }

    public void testInfoLoadExceptionGetsMessage() throws LogRegistrationException {
        final String exceptionMessage = "This is a test exception";
        Logger.register(new MockInfoLog());  // Enable info logging

        Exception e = new ArithmeticException(exceptionMessage);
        Logger.log(new LoggableInfo(e));  // Send an exception that should be logged

        IInfoLog mockLog = Logger.register((IInfoLog) null);  // Turn info logging off

        assertEquals(1, ((MockInfoLog) mockLog).messagesReceived());
        assertTrue(((MockInfoLog) mockLog).hasMessageBeenLoggedContaining(exceptionMessage));
        assertTrue(((MockInfoLog) mockLog).hasMessageBeenLoggedContaining(e.getClass().getName()));
    }

    public void testInfoLogCanBeShutOff() throws LogRegistrationException {
        Logger.log(new LoggableInfo("Info 1"));  // Send a message that should be ignored

        Logger.register(new MockInfoLog());  // Enable info logging

        Logger.log(new LoggableInfo("Info 2"));  // Send a message that should be logged

        IInfoLog mockLog = Logger.register((IInfoLog) null);  // Turn info logging off

        Logger.log(new LoggableInfo("Info 3"));  // Send a message that should be ignored

        assertEquals(1, ((MockInfoLog) mockLog).messagesReceived());
        assertTrue(((MockInfoLog) mockLog).hasMessageBeenLogged("Info 2"));
    }

    public void testReregisterInfoLog() throws LogRegistrationException {
        IInfoLog log1 = new MockInfoLog(0);
        Logger.register(log1);
        Logger.log(new LoggableInfo("Info 1"));
        Logger.log(new LoggableInfo("Info 2"));
        assertEquals(2, ((MockInfoLog) log1).messagesReceived());
        assertTrue(((MockInfoLog) log1).hasMessageBeenLogged("Info 1"));
        assertTrue(((MockInfoLog) log1).hasMessageBeenLogged("Info 2"));

        IInfoLog log2 = new MockInfoLog(1);
        Logger.register(log2);
        Logger.log(new LoggableInfo("Info 3"));
        assertEquals(1, ((MockInfoLog) log2).messagesReceived());
        assertTrue(((MockInfoLog) log2).hasMessageBeenLogged("Info 3"));

        Logger.register((IInfoLog) null);

        IInfoLog log3 = new MockInfoLog(2);
        Logger.register(log3);
        Logger.log(new LoggableInfo("Info 4"));
        Logger.log(new LoggableInfo("Info 5"));
        Logger.log(new LoggableInfo("Info 6"));
        assertEquals(3, ((MockInfoLog) log3).messagesReceived());
        assertTrue(((MockInfoLog) log3).hasMessageBeenLogged("Info 4"));
        assertTrue(((MockInfoLog) log3).hasMessageBeenLogged("Info 5"));
        assertTrue(((MockInfoLog) log3).hasMessageBeenLogged("Info 6"));
    }

    public void testReregisteringSameInfoLogTwiceDoesNotChangeLogger() throws LogRegistrationException {
        IInfoLog log1 = new MockInfoLog();
        Logger.register(log1);
        Logger.log(new LoggableInfo("Info 1"));
        Logger.log(new LoggableInfo("Info 2"));
        assertEquals(2, ((MockInfoLog) log1).messagesReceived());
        assertTrue(((MockInfoLog) log1).hasMessageBeenLogged("Info 1"));
        assertTrue(((MockInfoLog) log1).hasMessageBeenLogged("Info 2"));

        IInfoLog log2 = new MockInfoLog();
        Logger.register(log2);  // Should have no effect since all MockInfoLogs are equal.
        Logger.log(new LoggableInfo("Info 3"));
        assertEquals(3, ((MockInfoLog) log1).messagesReceived());
        assertEquals(0, ((MockInfoLog) log2).messagesReceived());
        assertTrue(((MockInfoLog) log1).hasMessageBeenLogged("Info 3"));
    }

    /* ========== Warning Log Tests ============== */
    public void testRegisterWarningLogReturnsPreviousWarningLog() throws LogRegistrationException {
        IWarningLog newLog = new MockWarningLog();
        IWarningLog oldLog = new MockWarningLog();

        IWarningLog returnedLog = Logger.register(oldLog);
        assertNull(returnedLog);

        returnedLog = Logger.register(newLog);
        assertTrue(returnedLog == oldLog);
    }

    public void testWarningLogGetsMessage() throws LogRegistrationException {
        Logger.register(new MockWarningLog());  // Enable debug logging

        Logger.log(new LoggableWarning("Warning 1"));  // Send a message that should be logged

        IWarningLog mockLog = Logger.register((IWarningLog) null);  // Turn debug logging off

        assertEquals(1, ((MockWarningLog) mockLog).messagesReceived());
        assertTrue(((MockWarningLog) mockLog).hasMessageBeenLogged("Warning 1"));
    }

    public void testWarningLogCanBeShutOff() throws LogRegistrationException {
        Logger.log(new LoggableWarning("Warning 1"));  // Send a message that should be ignored

        Logger.register(new MockWarningLog());  // Enable warning logging

        Logger.log(new LoggableWarning("Warning 2"));  // Send a message that should be logged

        IWarningLog mockLog = Logger.register((IWarningLog) null);  // Turn warning logging off

        Logger.log(new LoggableWarning("Warning 3"));  // Send a message that should be ignored

        assertEquals(1, ((MockWarningLog) mockLog).messagesReceived());
        assertTrue(((MockWarningLog) mockLog).hasMessageBeenLogged("Warning 2"));
    }

    public void testReregisterWarningLog() throws LogRegistrationException {
        IWarningLog log1 = new MockWarningLog(1);
        Logger.register(log1);
        Logger.log(new LoggableWarning("Warning 1"));
        Logger.log(new LoggableWarning("Warning 2"));
        assertEquals(2, ((MockWarningLog) log1).messagesReceived());
        assertTrue(((MockWarningLog) log1).hasMessageBeenLogged("Warning 1"));
        assertTrue(((MockWarningLog) log1).hasMessageBeenLogged("Warning 2"));

        IWarningLog log2 = new MockWarningLog(2);
        Logger.register(log2);
        Logger.log(new LoggableWarning("Warning 3"));
        assertEquals(1, ((MockWarningLog) log2).messagesReceived());
        assertTrue(((MockWarningLog) log2).hasMessageBeenLogged("Warning 3"));

        Logger.register((IWarningLog) null);

        IWarningLog log3 = new MockWarningLog(3);
        Logger.register(log3);
        Logger.log(new LoggableWarning("Warning 4"));
        Logger.log(new LoggableWarning("Warning 5"));
        Logger.log(new LoggableWarning("Warning 6"));
        assertEquals(3, ((MockWarningLog) log3).messagesReceived());
        assertTrue(((MockWarningLog) log3).hasMessageBeenLogged("Warning 4"));
        assertTrue(((MockWarningLog) log3).hasMessageBeenLogged("Warning 5"));
        assertTrue(((MockWarningLog) log3).hasMessageBeenLogged("Warning 6"));
    }

    public void testReregisteringSameWarningLogTwiceDoesNotChangeLogger() throws LogRegistrationException {
        IWarningLog log1 = new MockWarningLog();
        Logger.register(log1);
        Logger.log(new LoggableWarning("Warning 1"));
        Logger.log(new LoggableWarning("Warning 2"));
        assertEquals(2, ((MockWarningLog) log1).messagesReceived());
        assertTrue(((MockWarningLog) log1).hasMessageBeenLogged("Warning 1"));
        assertTrue(((MockWarningLog) log1).hasMessageBeenLogged("Warning 2"));

        IWarningLog log2 = new MockWarningLog();
        Logger.register(log2);
        Logger.log(new LoggableWarning("Warning 3"));
        assertEquals(3, ((MockWarningLog) log1).messagesReceived());
        assertEquals(0, ((MockWarningLog) log2).messagesReceived());
        assertTrue(((MockWarningLog) log1).hasMessageBeenLogged("Warning 3"));

        Logger.register((IWarningLog) null);
    }

    /* ========== Error Log Tests ============== */
    public void testRegisterErrorLogReturnsPreviousErrorLog() throws LogRegistrationException {
        IErrorLog newLog = new MockErrorLog();
        IErrorLog oldLog = new MockErrorLog();

        IErrorLog returnedLog = Logger.register(oldLog);
        assertNull(returnedLog);

        returnedLog = Logger.register(newLog);
        assertTrue(returnedLog == oldLog);
    }

    public void testErrorLogGetsErrorMessage() throws LogRegistrationException {
        Logger.register(new MockErrorLog());  // Enable debug logging

        Logger.log(new LoggableError("Error 1"));  // Send a message that should be logged

        IErrorLog mockLog = Logger.register((IErrorLog) null);  // Turn debug logging off

        assertEquals(1, ((MockErrorLog) mockLog).messagesReceived());
        assertTrue(((MockErrorLog) mockLog).hasMessageBeenLogged("Error 1"));
    }

    public void testErrorLogGetsFatalMessage() throws LogRegistrationException {
        Logger.register(new MockErrorLog());  // Enable debug logging

        Logger.log(new FatalEvent("Fatal"));  // Send a message that should be logged

        IErrorLog mockLog = Logger.register((IErrorLog) null);  // Turn debug logging off

        assertEquals(1, ((MockErrorLog) mockLog).messagesReceived());
        assertTrue(((MockErrorLog) mockLog).hasMessageBeenLogged("Fatal"));
    }

    public void testFatalMessageReportedEvenIfNoLogRegistered() {
        PrintStream oldOut = System.err;

        ByteArrayOutputStream errorStream = new ByteArrayOutputStream();
        System.setErr(new PrintStream(errorStream));

        Logger.log(new FatalEvent("Fatal"));  // Send a message that should be logged

        String cstrResults = errorStream.toString();
        assertEquals("Fatal\r\n", cstrResults);

        System.setOut(oldOut);
    }

    public void testLoggingNullFatalMessageDoesNotCrash() {
        Logger.log((FatalEvent) null);
    }

    public void testErrorLogCanBeShutOff() throws LogRegistrationException {
        Logger.log(new LoggableError("Error 1"));  // Send a message that should be ignored

        Logger.register(new MockErrorLog());  // Enable error logging

        Logger.log(new LoggableError("Error 2"));  // Send a message that should be logged

        IErrorLog mockLog = Logger.register((IErrorLog) null);  // Turn Error logging off

        Logger.log(new LoggableError("Error 3"));  // Send a message that should be ignored

        assertEquals(1, ((MockErrorLog) mockLog).messagesReceived());
        assertTrue(((MockErrorLog) mockLog).hasMessageBeenLogged("Error 2"));
    }

    public void testReregisterErrorLog() throws LogRegistrationException {
        IErrorLog log1 = new MockErrorLog(1);
        Logger.register(log1);
        Logger.log(new LoggableError("Error 1"));
        Logger.log(new LoggableError("Error 2"));
        assertEquals(2, ((MockErrorLog) log1).messagesReceived());
        assertTrue(((MockErrorLog) log1).hasMessageBeenLogged("Error 1"));
        assertTrue(((MockErrorLog) log1).hasMessageBeenLogged("Error 2"));

        IErrorLog log2 = new MockErrorLog(2);
        Logger.register(log2);
        Logger.log(new LoggableError("Error 3"));
        assertEquals(1, ((MockErrorLog) log2).messagesReceived());
        assertTrue(((MockErrorLog) log2).hasMessageBeenLogged("Error 3"));

        Logger.register((IErrorLog) null);

        IErrorLog log3 = new MockErrorLog(3);
        Logger.register(log3);
        Logger.log(new LoggableError("Error 4"));
        Logger.log(new LoggableError("Error 5"));
        Logger.log(new LoggableError("Error 6"));
        assertEquals(3, ((MockErrorLog) log3).messagesReceived());
        assertTrue(((MockErrorLog) log3).hasMessageBeenLogged("Error 4"));
        assertTrue(((MockErrorLog) log3).hasMessageBeenLogged("Error 5"));
        assertTrue(((MockErrorLog) log3).hasMessageBeenLogged("Error 6"));
    }

    public void testReregisteringSameErrorLogTwiceDoesNotChangeLogger() throws LogRegistrationException {
        IErrorLog log1 = new MockErrorLog();
        Logger.register(log1);
        Logger.log(new LoggableError("Error 1"));
        Logger.log(new LoggableError("Error 2"));
        assertEquals(2, ((MockErrorLog) log1).messagesReceived());
        assertTrue(((MockErrorLog) log1).hasMessageBeenLogged("Error 1"));
        assertTrue(((MockErrorLog) log1).hasMessageBeenLogged("Error 2"));

        IErrorLog log2 = new MockErrorLog();
        Logger.register(log2);
        Logger.log(new LoggableError("Error 3"));
        assertEquals(3, ((MockErrorLog) log1).messagesReceived());
        assertTrue(((MockErrorLog) log1).hasMessageBeenLogged("Error 3"));
    }


    /* ========== Debug Log Tests ============== */
    public void testRegisterDebugLogReturnsPreviousDebugLog() throws LogRegistrationException {
        IDebugLog newLog = new MockDebugLog();
        IDebugLog oldLog = new MockDebugLog();

        IDebugLog returnedLog = Logger.register(oldLog);
        assertNull(returnedLog);

        returnedLog = Logger.register(newLog);
        assertTrue(returnedLog == oldLog);
    }

    public void testDebugLogGetsMessage() throws LogRegistrationException {
        Logger.register(new MockDebugLog());  // Enable debug logging

        Logger.log(new DebugLogEvent("Debug 1"));  // Send a message that should be logged

        IDebugLog mockLog = Logger.register((IDebugLog) null);  // Turn debug logging off

        assertEquals(1, ((MockDebugLog) mockLog).messagesReceived());
        assertTrue(((MockDebugLog) mockLog).hasMessageBeenLogged("Debug 1"));
    }

    public void testDebugLogCanBeShutOff() throws LogRegistrationException {
        Logger.log(new DebugLogEvent("Debug 1"));  // Send a message that should be ignored

        Logger.register(new MockDebugLog());  // Enable debug logging

        Logger.log(new DebugLogEvent("Debug 2"));  // Send a message that should be logged

        IDebugLog mockLog = Logger.register((IDebugLog) null);  // Turn debug logging off

        Logger.log(new DebugLogEvent("Debug 3"));  // Send a message that should be ignored

        assertEquals(1, ((MockDebugLog) mockLog).messagesReceived());
        assertTrue(((MockDebugLog) mockLog).hasMessageBeenLogged("Debug 2"));
    }

    public void testReregisterDebugLog() throws LogRegistrationException {
        IDebugLog log1 = new MockDebugLog(1);
        Logger.register(log1);
        Logger.log(new DebugLogEvent("Debug 1"));
        Logger.log(new DebugLogEvent("Debug 2"));
        assertEquals(2, ((MockDebugLog) log1).messagesReceived());
        assertTrue(((MockDebugLog) log1).hasMessageBeenLogged("Debug 1"));
        assertTrue(((MockDebugLog) log1).hasMessageBeenLogged("Debug 2"));

        IDebugLog log2 = new MockDebugLog(2);
        Logger.register(log2);
        Logger.log(new DebugLogEvent("Debug 3"));
        assertEquals(1, ((MockDebugLog) log2).messagesReceived());
        assertTrue(((MockDebugLog) log2).hasMessageBeenLogged("Debug 3"));

        Logger.register((IDebugLog) null);

        IDebugLog log3 = new MockDebugLog(3);
        Logger.register(log3);
        Logger.log(new DebugLogEvent("Debug 4"));
        Logger.log(new DebugLogEvent("Debug 5"));
        Logger.log(new DebugLogEvent("Debug 6"));
        assertEquals(3, ((MockDebugLog) log3).messagesReceived());
        assertTrue(((MockDebugLog) log3).hasMessageBeenLogged("Debug 4"));
        assertTrue(((MockDebugLog) log3).hasMessageBeenLogged("Debug 5"));
        assertTrue(((MockDebugLog) log3).hasMessageBeenLogged("Debug 6"));
    }

    public void testReregisteringSameDebugLogTwiceDoesNotChangeLogger() throws LogRegistrationException {
        IDebugLog log1 = new MockDebugLog();
        Logger.register(log1);
        Logger.log(new DebugLogEvent("Debug 1"));
        Logger.log(new DebugLogEvent("Debug 2"));
        assertEquals(2, ((MockDebugLog) log1).messagesReceived());
        assertTrue(((MockDebugLog) log1).hasMessageBeenLogged("Debug 1"));
        assertTrue(((MockDebugLog) log1).hasMessageBeenLogged("Debug 2"));

        IDebugLog log2 = new MockDebugLog();
        Logger.register(log2);
        Logger.log(new DebugLogEvent("Debug 3"));
        assertEquals(3, ((MockDebugLog) log1).messagesReceived());
        assertEquals(0, ((MockDebugLog) log2).messagesReceived());
        assertTrue(((MockDebugLog) log1).hasMessageBeenLogged("Debug 3"));

        Logger.register((IDebugLog) null);
    }


    /* ========== Audit Log Tests ============== */
    public void testMultipleNullAuditLogRegistrationsDoesNotCrash() throws LogRegistrationException {
        Logger.register((IAuditLog) null);
        Logger.register((IAuditLog) null);
        Logger.register((IAuditLog) null);
        Logger.register((IAuditLog) null);
    }

    public void testAuditLogCannotBeShutOff() {
        Logger.log(new AuditInfo("Audit 1"));  // Send a message that should be ignored

        IAuditLog auditLog = new MockAuditLog();
        try {
            Logger.register(auditLog);  // Enable audit logging
        } catch (LogRegistrationException e) {
            fail();
        }

        Logger.log(new AuditInfo("Audit 2"));  // Send a message that should be logged

        try {
            Logger.register((IAuditLog) null);  // Try to turn audit logging off
            fail();
        } catch (LogRegistrationException e) {
            // Expected path
        }

        Logger.log(new AuditInfo("Audit 3"));  // Send a message that should be logged

        try {
            Logger.register(new MockAuditLog());  // Try to re-assign audit logging
            fail();
        } catch (LogRegistrationException e) {
            // Expected path
        }

        Logger.log(new AuditInfo("Audit 4"));  // Send a message that should be logged

        assertEquals(5, ((MockAuditLog) auditLog).messagesReceived());
        assertTrue(((MockAuditLog) auditLog).hasMessageBeenLogged("Audit 2"));
        assertTrue(((MockAuditLog) auditLog).hasMessageBeenLogged("Audit 3"));
        assertTrue(((MockAuditLog) auditLog).hasMessageBeenLogged("Audit 4"));
        assertTrue(((MockAuditLog) auditLog).hasMessageBeenLogged("Attempt to redifine the audit log failed"));  // 2 of these
    }

    public void testNumActiveLoggers() throws LogRegistrationException {
        assertEquals(0, Logger.numActiveLoggers());

        Logger.register(new MockAuditLog());
        assertEquals(1, Logger.numActiveLoggers());

        Logger.register(new MockDebugLog());
        assertEquals(2, Logger.numActiveLoggers());

        Logger.register(new MockDebugLog());
        assertEquals(2, Logger.numActiveLoggers());

        Logger.register(new MockErrorLog());
        assertEquals(3, Logger.numActiveLoggers());

        Logger.register(new MockInfoLog());
        assertEquals(4, Logger.numActiveLoggers());

        Logger.register(new MockTraceLog());
        assertEquals(5, Logger.numActiveLoggers());

        Logger.register(new MockWarningLog());
        assertEquals(6, Logger.numActiveLoggers());
    }

    public void testRegisteringNullLoggers() throws LogRegistrationException {
        Logger.register((IDebugLog) null);
        Logger.register((IInfoLog) null);
        Logger.register((IWarningLog) null);
        Logger.register((IErrorLog) null);
        Logger.register((IAuditLog) null);
        Logger.register((ITraceLog) null);

        Logger.register((IDebugLog) null);
        Logger.register((IInfoLog) null);
        Logger.register((IWarningLog) null);
        Logger.register((IErrorLog) null);
        Logger.register((IAuditLog) null);
        Logger.register((ITraceLog) null);

        assertEquals(0, Logger.numActiveLoggers());
    }

    public void testExceptionSendToLogWillOutputStackTrace() throws LogRegistrationException {
        Logger.register(new MockErrorLog());  // Enable debug logging

        Exception exception = new Exception("Exception message");
        Logger.log(new LoggableError(exception));  // Send an exception that should be logged

        IErrorLog mockLog = Logger.register((IErrorLog) null);  // Turn debug logging off

        assertEquals(1, ((MockErrorLog) mockLog).messagesReceived());

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        exception.printStackTrace(new PrintStream(out));
        String exceptionStackTrace = out.toString();

        assertTrue(((MockErrorLog) mockLog).hasMessageBeenLogged(exceptionStackTrace));
    }

    public void testGetLogInfoReturnsCorrectInformation() throws LogRegistrationException {
        Logger.register(new MockErrorLog());
        for (int i = 0; i < Logger.numActiveLoggers(); i++) {
            LogInfo li = Logger.getLogInfo(i);
            assertEquals(2, li.numLogDevices());
        }
    }

	public void testEnableDebugLogging_LogsDebugMessagesWhenDebugLoggerExists() throws LogRegistrationException {
		MockDebugLog logger = new MockDebugLog();
		Logger.register(logger);
		Logger.enableLogger(Logger.DEBUG_LOG);

		String testMessage = "test";
		Logger.log(new DebugLogEvent(testMessage));

		assertTrue("Message not logged", logger.hasMessageBeenLogged(testMessage));
	}

	public void testDebugLoggingEnabledByDefault_LogsMessagesWithoutCallingEnable() throws LogRegistrationException {
		MockDebugLog logger = new MockDebugLog();
		Logger.register(logger);

		String testMessage = "test";
		Logger.log(new DebugLogEvent(testMessage));

		assertTrue("Message not logged", logger.hasMessageBeenLogged(testMessage));
	}

	public void testDisableDebugLogging_DoesNotLogDebugMessagesWhenLoggerExists() throws LogRegistrationException {
		MockDebugLog logger = new MockDebugLog();
		Logger.register(logger);

		Logger.log(new DebugLogEvent("testMessage2"));
		assertTrue(logger.hasMessageBeenLogged("testMessage2"));

		Logger.disableLogger(Logger.DEBUG_LOG);

		String testMessage = "test";
		Logger.log(new DebugLogEvent(testMessage));

		assertFalse("Message logged", logger.hasMessageBeenLogged(testMessage));
	}

	public void testEnableDebugLogging_LogsMessageAfterDisableIsCalled() throws LogRegistrationException {
		MockDebugLog logger = new MockDebugLog();
		Logger.register(logger);
		Logger.disableLogger(Logger.DEBUG_LOG);
		String testMessage = "test";

		Logger.log(new DebugLogEvent(testMessage));
		assertFalse("Message logged", logger.hasMessageBeenLogged(testMessage));

		Logger.enableLogger(Logger.DEBUG_LOG);

		Logger.log(new DebugLogEvent(testMessage));

		assertTrue("Message not logged", logger.hasMessageBeenLogged(testMessage));
	}

	public void testEnableDebugLogging_LogsWarningWhenDebugLogNotRegistered() throws LogRegistrationException {
		MockWarningLog logger = new MockWarningLog();
		Logger.register(logger);
		Logger.enableLogger(Logger.DEBUG_LOG);
		String warningMessage = Logger.DEBUG_LOG + " enabled but there is no log device registered.";
		assertTrue("Warning Message not logged, or wrong message", logger.hasMessageBeenLogged(warningMessage));
	}

	public void testClose_RemovesAllLoggers() throws LogRegistrationException {
		Logger.register(new MockWarningLog());
		Logger.register(new MockDebugLog());
		Logger.register(new MockAuditLog());
		Logger.register(new MockTraceLog());
		Logger.register(new MockInfoLog());
		Logger.register(new MockErrorLog());
		Logger.register(new MockPerformanceLog());

		assertEquals(7, Logger.numActiveLoggers());

		Logger.closeLogging();

		assertEquals(0, Logger.numActiveLoggers());
	}

	public void testClose_SetsLoggerEnabledToCorrectDefaults() throws LogRegistrationException {
		Logger.register(new MockTraceLog());

		Logger.disableLogger(Logger.AUDIT_LOG);
		Logger.disableLogger(Logger.DEBUG_LOG);
		Logger.disableLogger(Logger.WARNING_LOG);
		Logger.disableLogger(Logger.INFO_LOG);
		Logger.disableLogger(Logger.ERROR_LOG);
		Logger.disableLogger(Logger.PERFORMANCE_LOG);
		Logger.enableLogger(Logger.TRACE_LOG);

		Logger.closeLogging();
		MockWarningLog warningLog = new MockWarningLog();
		MockDebugLog debugLog = new MockDebugLog();
		MockTraceLog traceLog = new MockTraceLog();
		MockAuditLog auditLog = new MockAuditLog();
		MockInfoLog infoLog = new MockInfoLog();
		MockErrorLog errorLog = new MockErrorLog();
		MockPerformanceLog performanceLog = new MockPerformanceLog();
		Logger.register(warningLog);
		Logger.register(debugLog);
		Logger.register(auditLog);
		Logger.register(traceLog);
		Logger.register(infoLog);
		Logger.register(errorLog);
		Logger.register(performanceLog);
		String message = "message";
		Logger.log(new LoggableWarning(message));
		Logger.log(new LoggableError(message));
		Logger.log(new DebugLogEvent(message));
		Logger.log(new LoggableInfo(message));
		Logger.log(new LoggablePerformanceMetric(message));
		Logger.log(new AuditInfo(message));
		Logger.traceEntry();

		assertTrue(warningLog.hasMessageBeenLogged(message));
		assertTrue(debugLog.hasMessageBeenLogged(message));
		assertFalse(traceLog.hasTracedEntryIntoMethod("testClose_SetsLoggerEnabledToCorrectDefaults"));
		assertTrue(auditLog.hasMessageBeenLogged(message));
		assertTrue(infoLog.hasMessageBeenLogged(message));
		assertTrue(errorLog.hasMessageBeenLogged(message));
		assertFalse(performanceLog.hasMessageBeenLogged(message));
	}

public void testDisableLogger_DoesNotLogWhenLogCalled() throws LogRegistrationException {
		MockWarningLog warningLog = new MockWarningLog();
		MockDebugLog debugLog = new MockDebugLog();
		MockTraceLog traceLog = new MockTraceLog();
		MockAuditLog auditLog = new MockAuditLog();
		MockInfoLog infoLog = new MockInfoLog();
		MockErrorLog errorLog = new MockErrorLog();
		MockPerformanceLog performanceLog = new MockPerformanceLog();
		Logger.register(warningLog);
		Logger.register(debugLog);
		Logger.register(auditLog);
		Logger.register(traceLog);
		Logger.register(infoLog);
		Logger.register(errorLog);
		Logger.register(performanceLog);

		Logger.disableLogger(Logger.AUDIT_LOG);
		Logger.disableLogger(Logger.DEBUG_LOG);
		Logger.disableLogger(Logger.WARNING_LOG);
		Logger.disableLogger(Logger.INFO_LOG);
		Logger.disableLogger(Logger.ERROR_LOG);
		Logger.disableLogger(Logger.PERFORMANCE_LOG);
		Logger.disableLogger(Logger.TRACE_LOG);

		String message = "message";
		Logger.log(new LoggableWarning(message));
		Logger.log(new LoggableError(message));
		Logger.log(new DebugLogEvent(message));
		Logger.log(new LoggableInfo(message));
		Logger.log(new LoggablePerformanceMetric(message));
		Logger.log(new AuditInfo(message));
		Logger.traceEntry();

		assertFalse(warningLog.hasMessageBeenLogged(message));
		assertFalse(debugLog.hasMessageBeenLogged(message));
		assertFalse(traceLog.hasTracedEntryIntoMethod("testClose_SetsLoggerEnabledToCorrectDefaults"));
		assertFalse(auditLog.hasMessageBeenLogged(message));
		assertFalse(infoLog.hasMessageBeenLogged(message));
		assertFalse(errorLog.hasMessageBeenLogged(message));
		assertFalse(performanceLog.hasMessageBeenLogged(message));
	}

	public void testRegisterLogger_SetsDebugLogger() throws Exception {
		MockDebugLog logger = new MockDebugLog();
		Logger.register(logger);

		Logger.log(new DebugLogEvent("test"));

		assertTrue(logger.hasMessageBeenLogged("test"));

	}

	public void testIsEnabled_DebugShouldBeEnabledByDefault() throws LogRegistrationException {
		Logger.register(new MockDebugLog());
		assertTrue(Logger.isEnabled(Logger.DEBUG_LOG));
	}

	public void testIsEnabled_WhenBadName() {
    assertFalse(Logger.isEnabled("name not a logger"));
	}

	public void testIsEnabled_returnsFalseWhenDisabled() throws Exception {
		Logger.register(new MockDebugLog());
		Logger.disableLogger(Logger.DEBUG_LOG);
		assertFalse(Logger.isEnabled(Logger.DEBUG_LOG));
	}

	public void testIsEnabled_WhenNullPassed() throws Exception {
    assertFalse(Logger.isEnabled(null));
	}

	public void testIsEnabled_LoggerNotRegistered(){
    assertFalse(Logger.isEnabled(Logger.DEBUG_LOG));
	}

  public void testIsRegistered() throws Exception {
    Logger.register(new MockDebugLog());
    assertTrue(Logger.isRegistered(Logger.DEBUG_LOG));
  }

  public void testIsRegistered_WhenBadName() throws Exception {
    assertFalse(Logger.isRegistered("name not a logger"));
  }

  public void testIsRegistered_WhenNullPassed() throws Exception {
    assertFalse(Logger.isRegistered(null));
  }

  public void testIsRegistered_LoggerNotRegistered() throws Exception {
    assertFalse(Logger.isRegistered(Logger.DEBUG_LOG));
  }

   public void testClosingLoggerClosesRegisteredLogs() throws LogRegistrationException
   {
      MockWarningLog warningLog = new MockWarningLog();
      MockDebugLog debugLog = new MockDebugLog();

      Logger.register(warningLog);
      Logger.register(debugLog);

      assertFalse(warningLog.isClosed());
      assertFalse(debugLog.isClosed());

      Logger.closeLogging();

      assertTrue(warningLog.isClosed());
      assertTrue(debugLog.isClosed());
   }
}
