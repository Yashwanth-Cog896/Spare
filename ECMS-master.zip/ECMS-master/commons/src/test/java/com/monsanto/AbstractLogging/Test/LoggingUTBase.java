/*
 * Created by IntelliJ IDEA.
 * User: CPWALT
 * Date: Oct 2, 2002
 * Time: 1:46:12 PM
 * To change template for new class use
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.*;
import junit.framework.TestCase;

import java.util.ArrayList;

public class LoggingUTBase extends TestCase
{
   public LoggingUTBase(String cstrName)
   {
      super(cstrName);
   }


   protected void doLogging ()
   {
      long lStart = System.currentTimeMillis();

      Logger.traceEntry();

      Logger.log(new AuditInfo("Auditing - someone has changed data"));

      Logger.log(new LoggableInfo("Working in the LoggingExample class"));

      Logger.log(new DebugLogEvent("Getting ready to call \"throwAnException()\""));
      try {
         throwAnException();
      }
      catch (Exception e) {
         Logger.log(new LoggableError(e));
      }
      Logger.log(new DebugLogEvent("Call to \"throwAnException()\" complete."));

      traceEntryWithParameters(1, 2.3, "Param3");
      traceExitReturnsBoolean();
      traceExitReturnsInt();
      traceExitReturnsDouble();
      traceExitReturnsArrayList();

      try {
         throwFatalException();
      }
      catch (Exception e) {
         Logger.log(new LoggableError(e));
      }

      long lStop = System.currentTimeMillis();
      StringBuffer performanceMessage = new StringBuffer("doLogging took ").append(lStop - lStart).append(" mSec");
      Logger.log(new LoggablePerformanceMetric(performanceMessage.toString()));

      Logger.traceExit();
   }

   private void traceEntryWithParameters(int i, double v, String s)
   {
      Logger.traceEntry(new Object[]{new Integer(i), new Double(v), s});

      Logger.traceExit();
   }

   protected void traceExitReturnsVoid ()
   {
      Logger.traceEntry();

      Logger.traceExit();
   }

   private void throwAnException() throws Exception
   {
      Logger.traceEntry();

      Logger.log(new LoggableWarning("Warning!  About to throw an exception."));

      if (true) {
         Logger.traceExit();
         throw new Exception("Bad things have happened!  Be sure this is logged.");
      }

      Logger.traceExit();
   }

   private int throwFatalException() throws Exception
   {
      Logger.traceEntry();

      Logger.log(new LoggableWarning("Warning!  About to throw a fatal exception."));

      int i = 0;

      int iBadDiv = 3/i;

      return Logger.traceExit(iBadDiv);
   }

   private boolean traceExitReturnsBoolean()
   {
      Logger.traceEntry();

      return Logger.traceExit(false);
   }

   private int traceExitReturnsInt()
   {
      Logger.traceEntry();

      return Logger.traceExit(123);
   }

   private double traceExitReturnsDouble()
   {
      Logger.traceEntry();

      return Logger.traceExit(123.456);
   }

   private ArrayList traceExitReturnsArrayList()
   {
      Logger.traceEntry();

      ArrayList RetVal = new ArrayList();
      RetVal.add("String 1");
      RetVal.add("String 2");
      RetVal.add("String 3");
      RetVal.add("String 4");
      RetVal.add("String 5");

      return (ArrayList)Logger.traceExit(RetVal);
   }

   protected boolean traceExitReturnsBoolean (boolean boolRetVal)
   {
      Logger.traceEntry();

      return Logger.traceExit(boolRetVal);
   }

   protected int traceExitReturnsInt (int iRetVal)
   {
      Logger.traceEntry();

      return Logger.traceExit(iRetVal);
   }

   protected double traceExitReturnsDouble (double dRetVal)
   {
      Logger.traceEntry();

      return Logger.traceExit(dRetVal);
   }

   protected ArrayList traceExitReturnsArrayList (ArrayList al)
   {
      Logger.traceEntry();

      return (ArrayList)Logger.traceExit(al);
   }

   protected String traceExitReturnsString (String cstrVal)
   {
      Logger.traceEntry();

      return Logger.traceExit(cstrVal);
   }

   protected Object traceExitReturnsObject (Object oRetVal)
   {
      Logger.traceEntry();

      return Logger.traceExit(oRetVal);
   }
}
