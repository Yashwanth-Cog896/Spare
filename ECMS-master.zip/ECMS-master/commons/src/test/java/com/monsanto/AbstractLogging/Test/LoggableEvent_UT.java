/*
 LoggableEvent_UT was created on Oct 20, 2004 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.LoggableEvent;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * Filename:    $RCSfile: LoggableEvent_UT.java,v $
 * Label:       $Name: abstract-logging-1_0_2 $
 * Last Change: $Author: ardharn $    	 On:	$Date: 2007/09/12 22:31:42 $
 * 
 * @author PAPRIT
 * @version $Revision: 1.14 $
 */
public class LoggableEvent_UT extends TestCase {
   public LoggableEvent_UT(String name) {
      super(name);
   }

   public void testCreateLoggableEventWithString() throws Exception {
      String message = "This is the string";
      LoggableEvent event = new MockLoggableEvent(message);
      assertEquals(message, event.toString());
   }

   public void testCreateLoggableEventWithException() throws Exception {
      Exception e = new Exception("Exception message");
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      e.printStackTrace(new PrintStream(out));
      LoggableEvent event = new MockLoggableEvent(e);
      assertEquals(out.toString(), event.toString());
   }

	public void testCreateLoggableEventWithNullFields() throws Exception
	{
		LoggableEvent event = new MockLoggableEvent( (String)null );
		event.toString();
		assertEquals("", event.toString());
	}

	class MockLoggableEvent extends LoggableEvent{
		public MockLoggableEvent(String cstrMessage) {
			super(cstrMessage);
		}

		public MockLoggableEvent(Throwable e) {
			super(e);
		}

		public String getLoggerName() {
			return null;
		}
	}
}

/*
* Revision Log
* $Log: LoggableEvent_UT.java,v $
* Revision 1.14  2007/09/12 22:31:42  ardharn
* restored
*
* Revision 1.12  2007/08/29 18:22:00  mecoru
* Restoring components that should NOT have been deleted
*
* Revision 1.10  2007/08/22 00:20:55  ardharn
* restored
*
* Revision 1.8  2007/07/02 16:49:29  edturc
* Changed constructor to take Throwable instead of Exception
*
* Revision 1.7  2007/05/31 23:38:14  mebrei1
* no message
*
* Revision 1.6  2007/04/11 19:36:59  SSPATI1
* renamed jsp/shared to jsp/common
*
* Revision 1.5  2007/04/04 18:49:52  wsmcqu
* GenesisNortherns MEGA changes
*
* Revision 1.4  2006/10/06 21:44:56  bathalh
* Avoid null pointer exception changing loggable event to string when all fields are null
*
* Revision 1.3  2006/06/22 12:27:13  eisincl
* Refactored Logger to allow disabling any logger on the fly.
*
* Revision 1.2  2005/02/25 13:07:47  NJAMADA
* cyclic dependencies removal-Nanda
*
* Revision 1.1  2004/10/20 14:42:03  paprit
* Changed logger to log stack trace when an Exception is passed
*
*/