/*
 testServlet was created on Mar 5, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * <p>Title: testServlet</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: testServletTextPlainOutput.java,v 1.9 2007-09-12 22:56:15 ardharn Exp $
 */
public class testServletTextPlainOutput extends GatewayServlet {
   public testServletTextPlainOutput() {}

   /**
    * @param request  The request object sent from the servlet server.
    * @param response The response object that must be filled with the information to be sent back to the user.
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);

      helper.setContentType("text/plain");

      PrintWriter pw = helper.getPrintWriter();
      pw.write("This is text/plain output");
      pw.close();
   }
}
