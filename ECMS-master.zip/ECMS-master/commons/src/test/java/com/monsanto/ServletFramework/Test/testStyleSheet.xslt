<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

	<xsl:param name="bodyTextSize">10pt</xsl:param>

	<xsl:template match="/">
		<EDE>
			<xsl:apply-templates/>
		</EDE>
	</xsl:template>

	<xsl:template match="FD1">
		<font size="{$bodyTextSize}">
			<FD1>
				<ProgramID><xsl:value-of select="X1"/></ProgramID>
				<DateFormat><xsl:value-of select="X2"/></DateFormat>
				<UnitsIndicator><xsl:value-of select="X3"/></UnitsIndicator>
				<TimeFormat><xsl:value-of select="X4"/></TimeFormat>
			</FD1>
		</font>
	</xsl:template>
</xsl:stylesheet>
