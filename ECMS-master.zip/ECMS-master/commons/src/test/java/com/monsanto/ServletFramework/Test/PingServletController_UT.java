package com.monsanto.ServletFramework.Test;

import com.meterware.httpunit.WebResponse;
import com.meterware.servletunit.InvocationContext;
import com.meterware.servletunit.ServletRunner;
import com.meterware.servletunit.ServletUnitClient;
import com.monsanto.ServletFramework.ServletPingServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import junit.framework.TestCase;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: CZHANG Date: Feb 25, 2005 Time: 9:11:18 AM To change this template use File |
 * Settings | File Templates.
 */
public class PingServletController_UT extends TestCase
{
   private static int HTTP_REQUEST_SUCCEEDED = 200;

   private ServletRunner m_sr = new ServletRunner();
   private ServletUnitClient m_sc = m_sr.newClient();
   private static final String TEST_SERVLET_URL = "http://localhost:8080/ServletPingServlet";

   protected void setUp() throws Exception
   {
      m_sr.registerServlet("ServletPingServlet", ServletPingServlet.class.getName());
   }

   public void testPingServletController() throws Exception
   {
      InvocationContext invocation = m_sc.newInvocation(TEST_SERVLET_URL);

      HttpServletRequest requ = invocation.getRequest();
      HttpServletResponse resp = invocation.getResponse();
      ServletConfig conf = null;
      UCCHelper helper = new UCCServletHelper(conf, requ, resp);
      helper.forward("ServletPingServlet");

      WebResponse response = m_sc.getResponse(invocation);
      assertEquals(HTTP_REQUEST_SUCCEEDED, response.getResponseCode());
   }
}
