package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 3:35:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class OtherServlet extends GatewayServlet {

  public OtherServlet() {
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

  private void respond(HttpServletRequest request, HttpServletResponse response) throws IOException {
    UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response);
    PrintWriter pw = helper.getPrintWriter();
    pw.write(UCCServletHelper_UT.OTHER_OUTPUT);
    pw.close();
  }
}
