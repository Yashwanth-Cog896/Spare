/*
 CompositeLogDevice_UT was created on Jun 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.CompositeLogDevice;
import junit.framework.TestCase;

import java.util.ArrayList;

/**
 * <p>Title: CompositeLogDevice_UT</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: CompositeLogDevice_UT.java,v 1.15 2007/09/12 22:31:42 ardharn Exp $
 */
public class CompositeLogDevice_UT extends TestCase
{
   public CompositeLogDevice_UT (String s)
   {
      super(s);
   }

   public void testCreateEmptyComposite()
   {
      CompositeLogDevice cld = new CompositeLogDevice();
      assertNotNull(cld);
   }

   public void testCreateEmptyThenAddDevices() {
      CompositeLogDevice cld = new CompositeLogDevice();

      cld.add(new MockLogDevice());
      assertNotNull(cld);
      assertFalse(cld.logDeviceLocations().isEmpty());
      assertFalse((cld.logDeviceTypes().isEmpty()));
   }

   public void testCompositeLogDeviceReturnsNumberOfLogDevicesAttached()
   {
      CompositeLogDevice cld = new CompositeLogDevice();
      cld.add(new MockLogDevice());

      MockTraceLog tl = new MockTraceLog();
      assertEquals(1, cld.attach(tl));

      CompositeLogDevice cld2 = new CompositeLogDevice();
      cld2.add(new MockLogDevice());
      cld2.add(new MockLogDevice());
      cld.add(cld2);

      assertEquals(3, cld.attach(tl));
   }

   public void testLogDeviceTypesReturnsEmptyListIfNoLoggersRegistered()
   {
      CompositeLogDevice cld = new CompositeLogDevice();

      ArrayList deviceTypes = cld.logDeviceTypes();

      assertNotNull(deviceTypes);
      // Why not use Collection's isEmpty method instead of deviceTypes.size() == 0
      assertTrue(deviceTypes.isEmpty());
      assertEquals(0, deviceTypes.size());
   }

   public void testLogDeviceTypesReturnsTypesOfRegisteredLoggers()
   {
      CompositeLogDevice cld = new CompositeLogDevice();

      cld.add(new MockLogDevice());
      cld.add(new MockLogDevice());

      ArrayList deviceTypes = cld.logDeviceTypes();

      assertNotNull(deviceTypes);
      assertEquals(2, deviceTypes.size());
   }

   public void testLogDeviceLocationReturnsEmptyListIfNoLoggersRegistered()
   {
      CompositeLogDevice cld = new CompositeLogDevice();

      ArrayList deviceLocations = cld.logDeviceLocations();

      assertNotNull(deviceLocations);
      assertEquals(0, deviceLocations.size());
   }

   public void testLogDeviceLocationsReturnsLocationsOfRegisteredLoggers()
   {
      CompositeLogDevice cld = new CompositeLogDevice();

      cld.add(new MockLogDevice());
      cld.add(new MockLogDevice());

      ArrayList deviceLocations = cld.logDeviceLocations();

      assertNotNull(deviceLocations);
      assertEquals(2, deviceLocations.size());
   }

   public void testClosingCompositePassesCloseToAllComponents()
   {
      MockLogDevice ld1 = new MockLogDevice();
      MockLogDevice ld2 = new MockLogDevice();

      CompositeLogDevice cld = new CompositeLogDevice();

      cld.add(ld1);
      cld.add(ld2);

      cld.close();

      assertTrue(ld1.wasClosed());
      assertTrue(ld2.wasClosed());
   }
}
