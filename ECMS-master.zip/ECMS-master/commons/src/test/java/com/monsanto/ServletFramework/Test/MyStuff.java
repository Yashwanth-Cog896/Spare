package com.monsanto.ServletFramework.Test;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Oct 13, 2005
 * Time: 12:05:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class MyStuff {
  private String data;

  public String getData() {
    return data;
  }

  public void setData(String data) {
    this.data = data;
  }
}
