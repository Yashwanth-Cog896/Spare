<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="/">
    <html>
      <body>
        <TABLE BORDER="1">
          <TR>
            <TH>     column     1    </TH>
            <TH> column 2</TH>
            <TH>column 3</TH>
          </TR>

          <xsl:apply-templates select="//row"/>
        </TABLE>

      </body>
    </html>
  </xsl:template>

  <xsl:template match="row">
    <TR>
      <xsl:apply-templates select="field"/>
    </TR>
  </xsl:template>

  <xsl:template match="field">
    <TD>
      <xsl:value-of select="."/>
    </TD>
  </xsl:template>

</xsl:stylesheet>
