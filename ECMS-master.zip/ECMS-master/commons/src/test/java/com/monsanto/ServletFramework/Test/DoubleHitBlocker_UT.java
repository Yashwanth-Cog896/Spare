package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.DoubleHitBlocker;
import com.monsanto.ServletFramework.UCCHelper;
import junit.framework.TestCase;


/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Mar 23, 2005
 * Time: 12:25:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class DoubleHitBlocker_UT
extends TestCase
{
/*
   // pseudo implementation by servlet or UseCaseController

   {
      DoubleHitBlocker blocker = new DoubleHitBlocker();

      try {
         if (blocker.lock(helper)) {
            // do servlet logic here
         }
         else {
            handleFailedLock();
         }
      }
      finally {
         blocker.release(helper);
      }
      // NO MORE SERVLET LOGIC HERE
   }
*/



   public void testValidSingleSubmit() {
      UCCHelper helper = new MockUCCHelper("foo");

      DoubleHitBlocker blocker = new DoubleHitBlocker();
      try {
         assertTrue(blocker.lock(helper));
      }
      finally {
         blocker.release();
      }
   }


   public void testDoubleHitFails()  {
      UCCHelper helper = new MockUCCHelper("foo");
      DoubleHitBlocker blocker1 = new DoubleHitBlocker();
      DoubleHitBlocker blocker2 = new DoubleHitBlocker();
      try {
         assertTrue(blocker1.lock(helper));

         assertFalse(blocker1.lock(helper));

         assertFalse(blocker2.lock(helper));
      }
      finally {
         blocker1.release();
         blocker2.release();
      }
   }

   public void testDoubleBlockDoesntAffectOtherSession() {
      UCCHelper helper1 = new MockUCCHelper("foo");
      UCCHelper helper2 = new MockUCCHelper("bar");
      DoubleHitBlocker blocker1 = new DoubleHitBlocker();
      DoubleHitBlocker blocker2 = new DoubleHitBlocker();

      try {
         blocker1.lock(helper1);

         assertTrue(blocker2.lock(helper2));
      }
      finally {
         blocker1.release();
         blocker2.release();
      }

   }
}

