/*
 UCCManager_UT was created on Oct 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCManager;
import junit.framework.TestCase;

/**
 * <p>Title: UCCManager_UT</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: UCCManager_UT.java,v 1.17 2007-09-12 22:56:15 ardharn Exp $
 */
public class UCCManager_UT extends TestCase {
	private MockUCCHelper helper;
	private MockUCCHelper helper1;
	private MockUCCHelper helper2;
	private MockUCCHelper helper3;
	private MockUCCHelper helper4;


	protected void setUp() throws Exception {
		helper = new MockUCCHelper("testUccManager");
		helper1 = new MockUCCHelper("foo");
		helper2 = new MockUCCHelper("foo");

		MockBlockingController.reset();
		MockNonBlockingController.reset();
	}

	protected void tearDown() throws Exception {
		MockBlockingController.reset();
		MockNonBlockingController.reset();
	}

	public void testRunControllerRunsActualController() {
		UCCManager.runController("ServletFramework.Test.MockControllerForUccManagerTest", helper);

		assertTrue(helper.wasSentTo("./com/monsanto/ServletFramework/Test/MockControllerRunSuccessfully.html"));
	}

	public void testRunControllerRunsActualControllerWhenComMonsantoSpecified() {
		UCCManager.runController("com.monsanto.ServletFramework.Test.MockControllerForUccManagerTest", helper);

		assertTrue(helper.wasSentTo("./com/monsanto/ServletFramework/Test/MockControllerRunSuccessfully.html"));
	}

	public void testRunControllerReportsErrorIfControllerNotFouond() {
		UCCManager.runController("ServletFramework.Test.NoSuchController", helper);

		assertTrue(helper.wasErrorGenerated());
	}

	public void testRunControllerReportsErrorOnThrowable() throws Exception {

		UCCManager.runController("ServletFramework.Test.MockControllerForUccManagerTestThrowable", helper);

		assertTrue(helper.wasErrorGenerated());
	}

	public void testBlockingControllerBlocksDoubleHit() throws InterruptedException {

		runThreadedCalls("ServletFramework.Test.MockBlockingController");

		MockBlockingController ucc1 = new MockBlockingController();
		assertEquals(1, ucc1.getCount());
	}

	public void testBlockingControllerHandlesError() throws InterruptedException {
		//ToDo: Now that I have the test below working, the threading problems have moved to this test.
		runThreadedCalls("ServletFramework.Test.MockBlockingController");

		String response = getResponsesPreferringNotNull();
      assertNotNull("not null assert", response);
      assertTrue("response startsWith -Cannot handle... assert",
								 response.startsWith("Cannot handle double click"));

		MockBlockingController ucc1 = new MockBlockingController();
      assertNotNull("2nd not null assert", ucc1);
      assertEquals("getCount == 1 assert", 1, ucc1.getCount());
	}

	private String getResponsesPreferringNotNull() {
		String response2 = helper2.getResponse();
		String response3 = helper3.getResponse();
		String response4 = helper4.getResponse();
		return response2 != null ? response2 : (response3 != null ? response3 : response4);
	}

	public void testNonBlockingControllerDoesntBlock() throws InterruptedException {
		runThreadedCalls("ServletFramework.Test.MockNonBlockingController");

		MockNonBlockingController ucc1 = new MockNonBlockingController();
		for (int i = 0; i < 10; i++) {
			if (ucc1.getCount() == 4) break;
			Thread.sleep(1000);
		}
		//ToDo: After trying to fix this threading error about 50 times, I gave up and just assert that
		//ToDo: it is at least 3.  Perhaps Aaron Cox (original author) can fix it sometime.
		assertTrue(ucc1.getCount() > 2);
	}


	private void runThreadedCalls(String controllerName) throws InterruptedException {
		helper3 = new MockUCCHelper("foo");
		helper4 = new MockUCCHelper("foo");

		Thread thr1 = new MockThreadedCall(helper1, controllerName);
		Thread thr2 = new MockThreadedCall(helper2, controllerName);
		Thread thr3 = new MockThreadedCall(helper3, controllerName);
		Thread thr4 = new MockThreadedCall(helper4, controllerName);

		thr1.start();
		thr2.start();
		thr3.start();
		thr4.start();
		Thread.sleep(50);

		thr4.join();
		thr3.join();
		thr2.join();
		thr1.join();
		Thread.sleep(50);
	}
}


class MockThreadedCall
				extends Thread {
	private UCCHelper helper;
	private String controllerName;

	MockThreadedCall(UCCHelper helper, String controllerName) {
		//this.ucc = ucc;
		this.helper = helper;
		this.controllerName = controllerName;
	}

	public void run() {
		UCCManager.runController(controllerName, helper);
	}
}

