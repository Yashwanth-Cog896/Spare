/*
 MockDebugLog was created on Jun 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging.Test;

import com.monsanto.AbstractLogging.IAuditLog;

/**
 * <p>Title: MockErrorLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockAuditLog.java,v 1.13 2007/09/12 22:31:42 ardharn Exp $
 */
public class MockAuditLog extends MockLog implements IAuditLog
{
   public MockAuditLog ()
   {
      super(0);
   }

   public String name()
   {
      return "MockLog.Audit";
   }

   public String type()
   {
      return "AUDIT";
   }

   /**
    * Closes the log.
    */
   public void close()
   {
   }
}
