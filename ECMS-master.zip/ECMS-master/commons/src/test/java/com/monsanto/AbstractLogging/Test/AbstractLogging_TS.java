package com.monsanto.AbstractLogging.Test;

import junit.framework.Test;
import junit.framework.TestSuite;


public class AbstractLogging_TS  extends TestSuite
{
   public static Test suite()
   {
      TestSuite aSuite = new TestSuite();

      aSuite.addTestSuite(LoggableEvent_UT.class);
      aSuite.addTestSuite(CompositeLogDevice_UT.class);
      aSuite.addTestSuite(Logger_UT.class);
      aSuite.addTestSuite(NotificationThread_UT.class);

      return aSuite;
   }
}
