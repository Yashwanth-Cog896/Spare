package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 3:35:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServletInfoServlet extends GatewayServlet {

  public ServletInfoServlet() {
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

	protected void runServletInfoController(UCCHelper helper) {
		UCCManager.runController("ServletFramework.ServletInfoController", helper);
	}

	private void respond(HttpServletRequest request, HttpServletResponse response) throws IOException {
    UCCHelper helper = createHelper(request, response);
		runServletInfoController(helper);
	}
}
