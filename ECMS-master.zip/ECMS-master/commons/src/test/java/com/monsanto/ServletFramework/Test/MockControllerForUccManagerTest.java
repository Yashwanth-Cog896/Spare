/*
 MockControllerForUccManagerTest was created on Oct 30, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;

import java.io.IOException;

/**
 * <p>Title: MockControllerForUccManagerTest</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: MockControllerForUccManagerTest.java,v 1.10 2007-09-12 22:56:14 ardharn Exp $
 */
public class MockControllerForUccManagerTest implements UseCaseController
{
   public void run (UCCHelper helper) throws IOException
   {
//      helper.displayHTML_File("MockControllerRunSuccessfully.html");
      helper.displayHTML_File("./com/monsanto/ServletFramework/Test/MockControllerRunSuccessfully.html");
   }
}
