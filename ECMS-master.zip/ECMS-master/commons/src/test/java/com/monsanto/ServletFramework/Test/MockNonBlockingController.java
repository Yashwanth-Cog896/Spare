package com.monsanto.ServletFramework.Test;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Apr 1, 2005
 * Time: 4:34:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockNonBlockingController implements UseCaseController
{
   private static int count = 0;

   public int getCount() {
      return count;
   }

   public static void reset() {
      count = 0;
   }

   public void run(UCCHelper helper) throws IOException {
		 increment();

		 try {
         Thread.sleep(500);
      } catch (InterruptedException e) {
         e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
      }
   }

	private synchronized void increment() {
		++ count;
	}

}
