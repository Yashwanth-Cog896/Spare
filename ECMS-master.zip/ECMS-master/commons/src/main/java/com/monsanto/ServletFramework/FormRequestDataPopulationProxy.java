package com.monsanto.ServletFramework;

import java.lang.reflect.*;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Nov 16, 2005
 * Time: 2:24:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class FormRequestDataPopulationProxy implements InvocationHandler {
  private Object obj;
  private static FormRequestDataPopulationProxy formRequestDataProxy;
  private Class delegateClass;
  public static final String MAPPED_SUFFIX = "Mapped";
  public static final String SET_METHOD_PREFIX = "set";
  public static final String GET_METHOD_PREFIX = "get";

  public static FormRequestData newInstance(Object obj) {
    Class aClass = obj.getClass();
    formRequestDataProxy = new FormRequestDataPopulationProxy(obj);
    Object proxyObject = Proxy.newProxyInstance(aClass.getClassLoader(), aClass.getInterfaces(),
                                                formRequestDataProxy);
    return (FormRequestData) proxyObject;
  }

  private FormRequestDataPopulationProxy(Object obj) {
    this.obj = obj;
    delegateClass = obj.getClass();
  }

  public Object invoke(Object proxy, Method method, Object[] args)
          throws Throwable {
    Object result = null;
    String methodName = method.getName();
    try {
      if (isSetMethodWithTwoArgumentsAndFirstArgAnInteger(args, methodName)) {
        preFillListElementsForSetter(methodName, args);
      }
      result = method.invoke(obj, args);
      if (isGetterWithNoArgumentsAndNoResult(args, methodName, result)) {
        result = invokeSetMethodForGetterAndReturnTypedResult(methodName, method, args);
      }
    } catch (InvocationTargetException e) {
      Throwable targetException = e.getTargetException();
      if (isIndexOutOfBoundsException(targetException)
              && isGetMethodWithOneIntegerArgument(args, methodName)) {
        result = invokeSetMethodForGetterAndReturnTypedResult(methodName, method, args);
      } else {
        throw targetException;
      }
    } catch (Exception e) {
      throw new RuntimeException("unexpected invocation exception: " + e);
    }
    return result;
  }

  private boolean isSetMethodWithTwoArgumentsAndFirstArgAnInteger(Object[] args, String methodName) {
    return isSetMethodWithTwoArguments(args, methodName) && isFirstArgumentAnInteger(args);
  }

  private void preFillListElementsForSetter(String methodName, Object[] args)
					throws NoSuchFieldException, IllegalAccessException, NoSuchMethodException,
					InstantiationException {
    Field field = getFieldForSetMethod(methodName);
    int index = ((Integer) args[0]).intValue();
    field.setAccessible(true);
    Class classOfInstanceVar = field.getType();
    if (classOfInstanceVar.isAssignableFrom(List.class)) {
      List list = (List) field.get(obj);
      int listSize = list.size();
			int startIndex = listSize - 1;
			if (startIndex < index) {
				Class returnClass = getReturnTypeOfGetterGivenSetter(methodName);
				for (int i = startIndex; i < index; i++) {
					Object instance = returnClass.newInstance();
          list.add(instance);
        }
      }
    }
  }

	private Class getReturnTypeOfGetterGivenSetter(String methodName) throws NoSuchMethodException {
		String getMethodName = GET_METHOD_PREFIX + methodName.substring(3);
		Class[] parms = new Class[]{int.class};
		Method getMethod = delegateClass.getMethod(getMethodName, parms);
		Class returnClass = getMethod.getReturnType();
		return returnClass;
	}

	private boolean isIndexOutOfBoundsException(Throwable targetException) {
    return targetException.toString().startsWith("java.lang.IndexOutOfBoundsException");
  }

  private boolean isGetMethodWithOneIntegerArgument(Object[] args, String methodName) {
    return methodName.startsWith(GET_METHOD_PREFIX) && args != null
            && args.length == 1 && isFirstArgumentAnInteger(args);
  }

  private Field getFieldForSetMethod(String methodName) throws NoSuchFieldException {
    String instanceVariableName = getInstanceVariableNameFromMethodName(methodName);
    Field field = delegateClass.getDeclaredField(instanceVariableName);
    return field;
  }

  private boolean isGetterWithNoArgumentsAndNoResult(Object[] args, String methodName, Object result) {
    return args == null && methodName.startsWith(GET_METHOD_PREFIX) && result == null;
  }

  private boolean isFirstArgumentAnInteger(Object[] args) {
    return args[0] instanceof Integer;
  }

  private boolean isSetMethodWithTwoArguments(Object[] args, String methodName) {
    return methodName.startsWith(SET_METHOD_PREFIX) && args != null && args.length == 2;
  }

  private Object invokeSetMethodForGetterAndReturnTypedResult(String methodName, Method method,
                                                              Object[] args) throws Throwable {
    String setMethodName = SET_METHOD_PREFIX + methodName.substring(3);
    Class returnClass = method.getReturnType();
    Object result = returnClass.newInstance();
    Object[] setArgs = null;
    Class[] parms = null;
    if (args != null && args.length > 0) {
      setArgs = new Object[]{args[0], result};
      parms = new Class[]{int.class, returnClass};
    } else {
      setArgs = new Object[]{result};
      parms = new Class[]{returnClass};
    }
    Method setMethod = delegateClass.getMethod(setMethodName, parms);
    this.invoke(formRequestDataProxy, setMethod, setArgs);
    return result;
  }

  private String getInstanceVariableNameFromMethodName(String methodName) {
    String rawName = methodName.substring(3, 4).toLowerCase() + methodName.substring(4);
    return rawName;
  }

}
