package com.monsanto.ServletFramework.MultiPart;

/**
 * <p>Title: Part</p>
 * <p>Description: A <code>Part</code> is an abstract upload part which
 * represents an <code>INPUT</code> form element in a
 * <code>multipart/form-data</code> form submission.</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Monsanto</p>
 * @see FilePart
 * @see ParamPart
 * @author Craig Walters
 * @version $Id: Part.java,v 1.11 2007-09-12 22:56:16 ardharn Exp $
 */
public abstract class Part
{
  private String name;

  /**
   * Constructs an upload part with the given name.
   * @param name The given name.
   */
  Part(String name)
  {
    this.name = name;
  }


  /**
   * Returns the name of the form element that this Part corresponds to.
   * @return the name of the form element that this Part corresponds to.
   */
  public String getName()
  {
    return name;
  }


  /**
   * Returns true if this Part is a FilePart.
   * @return true if this is a FilePart.
   */
  public boolean isFile()
  {
    return false;
  }


  /**
   * Returns true if this Part is a ParamPart.
   * @return true if this is a ParamPart.
   */
  public boolean isParam()
  {
    return false;
  }
}