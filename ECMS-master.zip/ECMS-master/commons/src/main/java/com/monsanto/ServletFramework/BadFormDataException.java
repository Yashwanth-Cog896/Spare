package com.monsanto.ServletFramework;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 7, 2005
 * Time: 5:12:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class BadFormDataException extends Exception {
  public BadFormDataException(String message) {
    super(message);
  }

  public BadFormDataException(Exception e) {
    super(e);
  }
}
