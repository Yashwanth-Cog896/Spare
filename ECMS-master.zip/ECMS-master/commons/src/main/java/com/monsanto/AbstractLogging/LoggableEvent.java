package com.monsanto.AbstractLogging;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;


/**
 * A message that needs written to a LogDevice.  This is the base class for all
 * of the log messages.
 *
 * @author CPWALT
 * @version $Id: LoggableEvent.java,v 1.19 2007/09/12 22:31:43 ardharn Exp $
 */
public abstract class LoggableEvent
{
   private String m_cstrMessage = null;
   private Throwable exception = null;

   /**
    * Constructor.
    *
    * @param cstrMessage The message to log.
    */
   public LoggableEvent(String cstrMessage)
   {
      super();

      m_cstrMessage = cstrMessage;
   }

   public LoggableEvent(Throwable e) {
      exception = e;
   }

   /**
    * Converts the message to a <code>String</code>.
    *
    * @return The message as a String.
    */
   public String toString()
   {
      if (exception != null) {
         ByteArrayOutputStream out = new ByteArrayOutputStream();
         exception.printStackTrace(new PrintStream(out));
         return out.toString();
      }
	  if (m_cstrMessage != null) {
		  //noinspection RedundantStringConstructorCall
		  return new String(m_cstrMessage);
      }
      String msg = new StringBuffer()
			   .append( "Cannot change " )
			   .append( this.getClass().getName() )
			   .append( " with null exception and null message to string." )
			   .toString();
      Logger.log( new LoggableWarning( msg ) );
	  return "";
   }

	public abstract String getLoggerName();
}
