/*
 LoggablePerformanceMetric was created on Apr 16, 2005 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;

/**
 * <p>Title: LoggablePerformanceMetric</p>
 * <p>Description:  </p> 
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company:  Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: LoggablePerformanceMetric.java,v 1.9 2007/09/12 22:31:43 ardharn Exp $
 */
public class LoggablePerformanceMetric extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrMessage The message to log.
    */
   public LoggablePerformanceMetric(String cstrMessage)
   {
      super(cstrMessage);
   }

	public String getLoggerName() {
		return Logger.PERFORMANCE_LOG;
	}
}
