package com.monsanto.ServletFramework;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: CZHANG
 * Date: Feb 25, 2005
 * Time: 9:15:13 AM
 * This controller is dedicated to all web based application pinging purpose.
 * it is the echo controller that AppPinger requests and collects response time from application,
 * and later response status/time are used to determine whether or not the application is alive.
 * It will be attacthed to all applications that need to monitor.
 *
 */
public class PingServletController implements UseCaseController {
    public void run(UCCHelper helper) throws IOException {
        Logger.traceEntry();
        Logger.log(new LoggableInfo("I am being pinged"));
        Logger.traceExit();
    }
}
