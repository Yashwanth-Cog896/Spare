//Source file: C:\\Develo~1\\Projects\\Career~1\\src\\com\\monsanto\\ServletFramework\\UCCManager.java
package com.monsanto.ServletFramework;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;

import java.io.IOException;

/** Manages UseCaseController subclasses. */
public class UCCManager {
	private static final String MONSANTO_PREFIX = "com.monsanto.";

	/**
	 * Runs a given controller.
	 *
	 * @param controllerName the name of a controller class
	 * @param helper         a UCCHelper that provides access to parameters and the environment
	 *
	 * @see com.monsanto.ServletFramework.Test.UCCManager_UT#testRunControllerRunsActualController()
	 * @see com.monsanto.ServletFramework.Test.UCCManager_UT#testRunControllerReportsErrorIfControllerNotFouond()
	 */
	public static void runController(String controllerName, UCCHelper helper) {
		Logger.traceEntry();
		try {
			StringBuffer controllerClassName = new StringBuffer(controllerName);
			if(controllerClassName.indexOf(MONSANTO_PREFIX) != 0) {
				controllerClassName.insert(0, MONSANTO_PREFIX);
			}
			Class controllerClass = Thread.currentThread().getContextClassLoader().loadClass(controllerClassName.toString());
			Logger.log(new LoggableInfo(new StringBuffer("Starting controller ").append(controllerClass).toString()));
			UseCaseController controller = (UseCaseController) controllerClass.newInstance();
			if(controller instanceof BlockingUseCaseController) {
				runBlockingCall((BlockingUseCaseController) controller, helper);
			} else {
				controller.run(helper);
			}
    } catch(Throwable t) {
			Logger.log(new LoggableError(t));
			helper.reportError(t);
		}
		Logger.traceExit();
	}

	private static void runBlockingCall(BlockingUseCaseController controller, UCCHelper helper) throws IOException {
		DoubleHitBlocker blocker = new DoubleHitBlocker();
		if(blocker.lock(helper)) {
			try {
				controller.run(helper);
			} finally {
				blocker.release();
			}
		} else {
			controller.handleDoubleSubmit(helper);
		}
	}
}
