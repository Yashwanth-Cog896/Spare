package com.monsanto.AbstractLogging;


/**
 * Interface for a trace log.
 *
 * @author CPWALT
 * @version $Id: ITraceLog.java,v 1.15 2007/09/12 22:31:42 ardharn Exp $
 */
public interface ITraceLog extends ILog, LogInfo
{

   /**
    * Removes all {@link LogDevice} objects from
    * the trace log.
    */
   public void removeLogDevices();
}
