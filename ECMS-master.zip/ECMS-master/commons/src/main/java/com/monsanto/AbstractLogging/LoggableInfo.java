package com.monsanto.AbstractLogging;


/**
 * A message that needs written to the InfoLog (if one has been registered).
 *
 * @author CPWALT
 * @version $Id: LoggableInfo.java,v 1.13 2007/09/12 22:31:43 ardharn Exp $
 */
 public class LoggableInfo extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrText The message to log.
    */
   public LoggableInfo(String cstrText)
   {
      super(cstrText);
   }

   /**
    * Constructor.
    *
    * @param throwable The exception to log.
    */
   public LoggableInfo(Throwable throwable)
   {
      super(throwable);
   }

	public String getLoggerName() {
		return Logger.INFO_LOG;
	}
}
