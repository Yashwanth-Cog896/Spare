/*
 ServletSystemSecurityProxy was created on Feb 22, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.servletsecurity;

import com.monsanto.securityinterfaces.SystemSecurityProxy;

import javax.servlet.http.HttpServletRequest;

/**
 * Filename:    $RCSfile: ServletSystemSecurityProxy.java,v $
 * Label:       $Name: servlet-security-1_0_0 $
 * Last Change: $Author: ardharn $    	 On:	$Date: 2007/09/12 22:59:50 $
 *
 * @author SRKARNA
 * @version $Revision: 1.10 $
 */
public interface ServletSystemSecurityProxy extends SystemSecurityProxy {
  void init(HttpServletRequest request);
}

/*
* Revision Log
* $Log: ServletSystemSecurityProxy.java,v $
* Revision 1.10  2007/09/12 22:59:50  ardharn
* restored
*
* Revision 1.8  2007/08/22 01:30:45  ardharn
* restored
*
* Revision 1.6  2007/05/31 23:39:11  mebrei1
* no message
*
* Revision 1.5  2007/04/11 19:37:43  SSPATI1
* renamed jsp/shared to jsp/common
*
* Revision 1.4  2007/04/04 18:50:31  wsmcqu
* GenesisNortherns MEGA changes
*
* Revision 1.3  2006/02/23 20:22:11  srkarna
* changed imports
*
* Revision 1.2  2006/02/22 23:47:54  srkarna
* moved ClientSecurityProxy and SystemSecurityProxy to SecurityInterfaces package
*
* Revision 1.1  2006/02/22 19:17:12  srkarna
* changes to SystemSecurityProxy - moved init() to the new interface
* ServletSystemSecurityProxy that extends SystemSecurityProxy
*
*/