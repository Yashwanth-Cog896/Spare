package com.monsanto.ServletFramework;

import java.io.IOException;

/** Provides a standard interface for all classes that define the functionality associated with a single use case. */
public interface UseCaseController {
	/**
	 * Runs the code that implements a given use case.
	 *
	 * @param helper a UCCHelper used to perform common UCC tasks
	 *
	 * @exception java.io.IOException
	 */
	void run(UCCHelper helper) throws IOException;
}
