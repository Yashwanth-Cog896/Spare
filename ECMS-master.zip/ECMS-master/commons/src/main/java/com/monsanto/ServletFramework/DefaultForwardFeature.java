package com.monsanto.ServletFramework;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Jun 6, 2006
 * Time: 4:33:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultForwardFeature implements ForwardFeature {
	public String processForwardURI(HttpServletRequest request, HttpServletResponse response,
																							ServletConfig config, String cstrTo) throws IOException {
		return null;
	}
}
