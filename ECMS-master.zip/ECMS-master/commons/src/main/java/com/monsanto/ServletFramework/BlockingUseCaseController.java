package com.monsanto.ServletFramework;

/**
 * Created by IntelliJ IDEA.
 * User: ADCOX
 * Date: Apr 4, 2005
 * Time: 7:49:56 AM
 * To change this template use File | Settings | File Templates.
 */
public interface BlockingUseCaseController
extends UseCaseController
{
   public void handleDoubleSubmit(UCCHelper helper);
}
