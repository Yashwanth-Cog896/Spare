/*
 NotificationThread was created on Nov 23, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;

/**
 * <p>Title: NotificationThread</p> <p>Description: <p>Copyright: Copyright (c) 2004</p> <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: NotificationThread.java,v 1.8 2007/09/12 22:31:43 ardharn Exp $
 */
public class NotificationThread extends Thread
{
   private int                m_iTimeoutSec;
   private NotificationSource m_NotificationSource;
   private String             m_cstrMessage;

   public NotificationThread(int iTimeoutSec, NotificationSource notificationSource, String cstrMessage)
   {
      m_iTimeoutSec = iTimeoutSec;
      m_NotificationSource = notificationSource;
      m_cstrMessage = cstrMessage;
   }

   /**
    * If this thread was constructed using a separate <code>Runnable</code> run object, then that <code>Runnable</code>
    * object's <code>run</code> method is called; otherwise, this method does nothing and returns.
    * <p/>
    * Subclasses of <code>Thread</code> should override this method.
    *
    * @see Thread#start()
    * @see Thread#stop()
    * @see Thread#Thread(ThreadGroup, Runnable, String)
    * @see Runnable#run()
    */
   public void run()
   {
      try {
         sleep(m_iTimeoutSec * 1000);

         // Our sleep() finished before the parent told us to stop.  Notify and wait forever.
         if (!isInterrupted()) {
            m_NotificationSource.notify(m_cstrMessage);

            sleep(Integer.MAX_VALUE);
         }
      }
      catch (InterruptedException e) {  // We were in sleep() when parent teld us to stop
         // Nothing required
      }
   }
}
