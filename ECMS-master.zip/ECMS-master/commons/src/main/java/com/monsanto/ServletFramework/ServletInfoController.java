package com.monsanto.ServletFramework;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.sun.org.apache.xalan.internal.xslt.EnvironmentCheck;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

public class ServletInfoController implements UseCaseController
{
   public void run (UCCHelper helper) throws IOException
   {
      PrintWriter out = helper.getPrintWriter();

      out.println("<HTML>");
      out.println("<HEAD><TITLE>SERVLET INFO</TITLE></HEAD>");
      out.println("<BODY>");

		 outputApplicationSpecificInformation(out);
		 
			outputInitParameters(helper, out);

      outputCurrentDirectory(helper, out);

      outputContextAttributes(helper, out);

      outputSystemProperties(out);

      outputXmlProperties(out);

      outputDatabaseProperties(out);

     outputMemoryUsage(out);

      out.println("</BODY>");
      out.println("</HTML>");
      out.flush();
   }

	protected void outputApplicationSpecificInformation(PrintWriter out) {
	}

	private void outputXmlProperties(PrintWriter out)
   {
      /*
      <?xml version="1.0"?>
      <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
         xmlns:xalan="http://xml.apache.org/xalan"
         exclude-result-prefixes="xalan">
         <xsl:output indent="yes"/>

         <xsl:template match="/">
            <out>
               <xsl:copy-of select="xalan:checkEnvironment()"/>
            </out>
         </xsl:template>
      </xsl:stylesheet>
      */
      out.println("<CENTER><TABLE border width=80%>");
      out.println("XML Properties:");

      out.println("<tr>");
      out.println("<td>");
      boolean environmentOK = (new EnvironmentCheck()).checkEnvironment(out);
      if (!environmentOK) {
         out.print("XML Environment could not be evaluated - major problems exist");
      }
      out.println("</td>");
      out.println("</t4>");
   }

  private void outputMemoryUsage(PrintWriter out) {
    out.println("<CENTER><TABLE border width=80%>");
    out.println("Memory usage");
    out.println("<tr>");
    out.println("<td>Total memory</td><td>"+ Runtime.getRuntime().totalMemory() + "</td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td>Free memory</td><td>"+ Runtime.getRuntime().freeMemory() + "</td>");
    out.println("</tr>");
    out.println("<tr>");
    out.println("<td>Max memory</td><td>"+ Runtime.getRuntime().maxMemory() + "</td>"); 
    out.println("</tr>");
    out.println("</TABLE></CENTER>");

  }

   private void outputDatabaseProperties(PrintWriter out) {
      out.println("<CENTER><TABLE border width=80%>");
      out.println("Database Properties:");

      out.println("<tr>");
      out.println("<td>" + "lsi.system" + "</td>");
      try {
         out.println("<td>" + EnvironmentHelper.getPropertyPrefix() + "</td>");
      }
      catch (EnvironmentHelperException e) {
         out.println("<td>" + e.toString() + "</td>");
      }
      out.println("</tr>");

      out.println("<tr>");
      out.println("<td>" + "Database Driver" + "</td>");
      try {
         out.println("<td>" + PersistentStore.instance().getDriverInfo() + "</td>");
      }
      catch (WrappingException e) {
         out.println("<td>" + e.toString() + "</td>");
      }

      out.println("<tr>");
      out.println("<td>" + "Database User" + "</td>");
      try {
         out.println("<td>" + PersistentStore.instance().getUserName() + "</td>");
      }
      catch (WrappingException e) {
         out.println("<td>" + e.toString() + "</td>");
      }

      out.println("<tr>");
      out.println("<td>" + "Datasource" + "</td>");
      try {
         out.println("<td>" + PersistentStore.instance().getDataSource() + "</td>");
      }
      catch (WrappingException e) {
         out.println("<td>" + e.toString() + "</td>");
      }

      out.println("</TABLE></CENTER>");
   }

   private void outputSystemProperties (PrintWriter out)
   {
      out.println("<CENTER><TABLE border width=80%>");
      out.println("System Properties:");

      Properties props = System.getProperties();
      Enumeration e_props = props.propertyNames();
      while (e_props.hasMoreElements()) {
         String name = (String)e_props.nextElement();
         out.println("<tr>");
         out.println("<td>" + name + "</td>");
         out.println("<td>" + props.getProperty(name) + "</td>");
         out.println("</tr>");
      }
      out.println("</TABLE></CENTER>");
   }

   private void outputContextAttributes (UCCHelper helper, PrintWriter out)
   {
      out.println("<CENTER><TABLE border width=80%>");
      out.println("Context Attributes:");

      HashMap contextAttributes = helper.getContextAttributes();
      Iterator contextIter = contextAttributes.keySet().iterator();
      while (contextIter.hasNext()) {
         String cstrName = (String)contextIter.next();
         out.println("<tr>");
         out.println("<td>" + cstrName + "</td>");
         out.println("<td>" + contextAttributes.get(cstrName) + "</td>");
         out.println("</tr>");
      }
      out.println("</TABLE></CENTER>");
   }

   private void outputCurrentDirectory (UCCHelper helper, PrintWriter out)
   {
      out.println("<CENTER><TABLE border width=80%>");
      out.println("Current Working Folder:");
     String currentDirectory = "";
     try {
       currentDirectory = helper.getCurrentDirectory();
     } catch (Exception IGNORE_LEAVE_DIRECTORY_EMPTY) {
     }
     out.println("<td>" + currentDirectory + "</td>");
      out.println("</TABLE></CENTER>");
   }

   private void outputInitParameters (UCCHelper helper, PrintWriter out)
   {
      out.println("<CENTER><TABLE border width=80%>");
      out.println("Init Parameters:");

      HashMap initParams = helper.getInitParameters();
      Iterator nameIter = initParams.keySet().iterator();
      while (nameIter.hasNext()) {
         String cstrName = (String)nameIter.next();
         out.println("<tr>");
         out.println("<td>" + cstrName + "</td>");
         out.println("<td>" + initParams.get(cstrName) + "</td>");
         out.println("</tr>");
      }
      out.println("</TABLE></CENTER>");
   }
}