package com.monsanto.AbstractLogging;


/**
 * Interface for an info log.
 *
 * @author CPWALT
 * @version $Id: IInfoLog.java,v 1.14 2007/09/12 22:31:42 ardharn Exp $
 */
public interface IInfoLog extends LogInfo
{
  
   /**
    * Removes all {@link LogDevice} objects from
    * the info log.
    */
   public void removeLogDevices();
 }
