package com.monsanto.AbstractLogging;

/**
 * A message that needs written to the WarningLog (if one has been registered).
 *
 * @author CPWALT
 * @version $Id: LoggableWarning.java,v 1.14 2007/09/12 22:31:43 ardharn Exp $
 */
 public class LoggableWarning extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrText The message to log.
    */
   public LoggableWarning(String cstrText)
   {
       super(cstrText);
   }

  /**
   * Constructor.
   *
   * @param throwable The exception to log.
   */
   public LoggableWarning(Throwable throwable)
   {
       super(throwable);
   }

  public String getLoggerName() {
		return Logger.WARNING_LOG;
	}
}
