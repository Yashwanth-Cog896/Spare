//Source file: C:\\Development\\Mirage\\Source\\java\\com\\monsanto\\AbstractLogging\\LogRegistrationException.java

package com.monsanto.AbstractLogging;


/**
 * <p>Title: LogRegistrationException</p>
 * <p>Description: Exception thrown if a logger cannot be registered.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Craig Walters
 * @version $Id: LogRegistrationException.java,v 1.8 2007/09/12 22:31:43 ardharn Exp $
 */
 public class LogRegistrationException extends Exception
{

   /**
    * Constructs the exception
    * @param cstrMessage - A message describing the problem.
    * @roseuid 3F004A30026F
    */
   public LogRegistrationException(String cstrMessage)
   {
      super(cstrMessage);
   }
}
