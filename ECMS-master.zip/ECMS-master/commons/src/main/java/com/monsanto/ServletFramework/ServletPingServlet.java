package com.monsanto.ServletFramework;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 30, 2004
 * Time: 3:35:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServletPingServlet extends GatewayServlet {

  public ServletPingServlet() {
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
    respond(request, response);
  }

  private void respond(HttpServletRequest request, HttpServletResponse response) {
    UCCHelper helper = createHelper(request, response);
		
    UCCManager.runController("ServletFramework.PingServletController", helper);
  }
}
