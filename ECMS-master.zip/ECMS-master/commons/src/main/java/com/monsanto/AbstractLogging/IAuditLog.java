package com.monsanto.AbstractLogging;


/**
 * Interface for an audit log.  An audit log is a special log type for tracking
 *  who does what in the application.  Once an IAuditLog is registered it can
 * never be un-registered.
 *
 * @author CPWALT
 * @version $Id: IAuditLog.java,v 1.14 2007/09/12 22:31:42 ardharn Exp $
 */
public interface IAuditLog extends LogInfo
{

	/**
	 * Removes all {@link LogDevice} objects from
	 * the audit log.
	 */
	public void removeLogDevices();
}
