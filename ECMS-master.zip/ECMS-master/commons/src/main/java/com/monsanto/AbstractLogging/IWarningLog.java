package com.monsanto.AbstractLogging;


/**
 * Interface for a warning log.
 *
 * @author CPWALT
 * @version $Id: IWarningLog.java,v 1.13 2007/09/12 22:31:42 ardharn Exp $
 */
public interface IWarningLog extends LogInfo
{
   
   /**
    * Removes all {@link com.monsanto.AbstractLogging.LogDevice} objects from
    * the warning log.
    */
   public void removeLogDevices();
 }
