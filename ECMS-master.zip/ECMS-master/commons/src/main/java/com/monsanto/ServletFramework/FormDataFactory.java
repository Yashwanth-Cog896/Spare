package com.monsanto.ServletFramework;

import org.apache.commons.beanutils.BeanUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Oct 18, 2005
 * Time: 2:53:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class FormDataFactory {
  private UCCHelper helper;

  public FormDataFactory(UCCHelper helper) {
    this.helper = helper;
  }


  public FormRequestData createFormData() throws BadFormDataException {

    FormRequestData formRequest = null;
    try {
      String formRequestDataClassName = getFormRequestDataClassName();
      String formSessionDataClassName = getFormSessionDataClassName();
      verifyProperFormDataParameters(formRequestDataClassName, formSessionDataClassName);
      formRequest = instantiateAppropriateObject(formRequestDataClassName, formSessionDataClassName);
      populateFormRequestData(formRequest);
      putFormRequestDataOnAppropriateHolder(formRequestDataClassName, formRequest, formSessionDataClassName);

    } catch (Exception e) {
      throw new BadFormDataException(e);
    }
    return formRequest;
  }

  private void putFormRequestDataOnAppropriateHolder(String formRequestDataClassName, FormRequestData formRequest, String formSessionDataClassName) {
    if (formRequestDataClassName != null) {
      putFormRequestDataObjectOnRequestAsAttribute(formRequest);
    }

    if (formSessionDataClassName != null) {
      putFormDataObjectOnSessionAsAttribute(formRequest);
    }
  }

  private FormRequestData instantiateAppropriateObject(String formRequestDataClassName,
                                                       String formSessionDataClassName)
          throws IllegalAccessException, InstantiationException, ClassNotFoundException {
    FormRequestData formRequest = null;
    if (formRequestDataClassName != null) {
      formRequest = instantiateFormData(formRequestDataClassName);
    }
    if (formSessionDataClassName != null) {
      formRequest = instantiateFormSessionData(formSessionDataClassName);
    }
    return formRequest;
  }

  private FormRequestData instantiateFormSessionData(String formSessionDataClassName)
          throws ClassNotFoundException, InstantiationException, IllegalAccessException {
    FormRequestData form = (FormRequestData) helper.getSessionParameter(UCCServletHelper.FORM_REQUEST_SESSION_PARM);
    if (form == null) {
      form = instantiateFormData(formSessionDataClassName);
    }
    return form;
  }

  private void putFormDataObjectOnSessionAsAttribute(FormRequestData formRequest) {
    helper.setSessionParameter(UCCServletHelper.FORM_REQUEST_SESSION_PARM, formRequest);
  }

  private void verifyProperFormDataParameters(String formRequestDataClassName,
                                              String formSessionDataClassName)
          throws BadFormDataException {
    if (null == formRequestDataClassName && null == formSessionDataClassName) {
      throw new BadFormDataException("No FormBean or FormBeanSession specified in web.xml");
    }
    if (null != formRequestDataClassName && null != formSessionDataClassName) {
      throw new BadFormDataException("Both FormBean and FormBeanSession specified in web.xml.  Specify only one.");
    }
  }

  private void putFormRequestDataObjectOnRequestAsAttribute(FormRequestData formRequest) {
    helper.setRequestAttributeValue(UCCServletHelper.FORM_REQUEST_PARM, formRequest);
  }

  private void populateFormRequestData(FormRequestData formRequestData) throws IOException, IllegalAccessException, InvocationTargetException, ClassNotFoundException {
    Map map = getRequestParameterMap();
    FormRequestData formRequestDataToPopulate = getFormRequestDataToPopulate(formRequestData);
    BeanUtils.populate(formRequestDataToPopulate, map);
  }

  private FormRequestData instantiateFormData(String formdataclass) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
    FormRequestData formRequest;
    Class formRequestClass = Class.forName(formdataclass);
    formRequest = (FormRequestData) formRequestClass.newInstance();
    return formRequest;
  }

  private String getFormRequestDataClassName() {
    HashMap parms = helper.getInitParameters();
    String formDataClass = (String) parms.get(UCCServletHelper.FORM_REQUEST_PARM);
    return formDataClass;
  }

  private String getFormSessionDataClassName() {
    HashMap parms = helper.getInitParameters();
    String formDataClass = (String) parms.get(UCCServletHelper.FORM_REQUEST_SESSION_PARM);
    return formDataClass;
  }

  private Map getRequestParameterMap() throws IOException {
    Map map = new HashMap();
    Enumeration enumeration = helper.getParameterNames();
    while (enumeration.hasMoreElements()) {
      String name = (String) enumeration.nextElement();
      String[] value = helper.getRequestParameterValues(name);
      map.put(name, value);
    }
    return map;
  }


  public FormRequestData getFormRequestDataToPopulate(FormRequestData formRequestData)
          throws ClassNotFoundException {
    Class[] interfaces = formRequestData.getClass().getInterfaces();
    for (int i = 0; i < interfaces.length; i++) {
      Class anInterface = interfaces[i];
      String interfaceName = anInterface.getName();
      if (interfaceNameIsNotFormRequestDataButContainsData(interfaceName)) {
        return FormRequestDataPopulationProxy.newInstance(formRequestData);
      }
    }
    return formRequestData;
  }

  private boolean interfaceNameIsNotFormRequestDataButContainsData(String interfaceName) {
    return !interfaceName.equals("com.monsanto.ServletFramework.FormRequestData")
            && interfaceName.indexOf("Data") != -1;
  }
}
