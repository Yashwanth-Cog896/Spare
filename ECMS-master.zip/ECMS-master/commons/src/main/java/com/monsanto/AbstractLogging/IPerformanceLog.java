/*
 IPerformanceLog was created on Apr 16, 2005 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;

/**
 * <p>Title: IPerformanceLog</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Monsanto</p>
 * </p>
 *
 * @author CPWALT
 * @version $Id: IPerformanceLog.java,v 1.9 2007/09/12 22:31:42 ardharn Exp $
 */
public interface IPerformanceLog extends LogInfo
{
   
   /**
    * Removes all {@link LogDevice} objects from the debug log.
    */
   public void removeLogDevices();
}
