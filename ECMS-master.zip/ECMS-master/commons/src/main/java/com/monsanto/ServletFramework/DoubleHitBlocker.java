package com.monsanto.ServletFramework;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Mar 24, 2005
 * Time: 12:14:45 PM
 * Simple semaphore implementation that locks based on the session id of the passed in
 * UCCHelper.  See DoubleHitBlocker_UT for test/implementation details.
 *
 * <P> The 'locked' UCCHelper is stored in a static map, so the client must use caution
 * and ensure that the lock is always released when finished.
 */
public class DoubleHitBlocker {
   private static Map map = new HashMap();

   private String nameKey;


   public DoubleHitBlocker()
   {
   }

   /**
    * Attempts to apply a 'lock' based on the session_id of the passed in UCC Helper.
    * Ensures that the lock may only be applied once to a given helper, until a
    * corresponding release call is applied.
    *
    * <P>Note, once the session is 'locked' it will remain so until a corresponding
    * release() call is made.
    *
    * @param helper The UCCHelper that is attempting the lock.
    * @return true if lock is successfully applied.
    */
   public boolean lock(UCCHelper helper) {
      boolean b = false;

      nameKey = helper.name();

      synchronized(map) {
         if (! map.containsKey(nameKey)) {
            map.put(nameKey, null);
            b = true;
         }
      }

      return b;
   }

   /**
    * Release the 'lock' from the last lock() call.
    */
   public void release() {
      synchronized(map) {
         map.remove(nameKey);
      }
   }
}
