package com.monsanto.AbstractLogging;


/**
 * Interface for an error log.
 *
 * @author CPWALT
 * @version $Id: IErrorLog.java,v 1.14 2007/09/12 22:31:42 ardharn Exp $
 */

public interface IErrorLog extends LogInfo
{

   /**
    * Removes all {@link LogDevice} objects from
    * the error log.
    */
   public void removeLogDevices();
}
