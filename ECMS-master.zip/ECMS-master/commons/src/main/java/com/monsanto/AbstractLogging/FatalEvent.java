package com.monsanto.AbstractLogging;


/**
 * This class encapsulates a fatal event.
 *
 * @author CPWALT
 * @version $Id: FatalEvent.java,v 1.15 2007/09/12 22:31:42 ardharn Exp $
 */
 public class FatalEvent extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrText The text of the message.
    */
   public FatalEvent (String cstrText)
   {
      super(cstrText);
   }

   /**
    * Constructor.
    *
    * @param throwable An exception that is fatal to the application.
    */
   public FatalEvent (Throwable throwable)
   {
      super(throwable);
   }

	public String getLoggerName() {
		return Logger.ERROR_LOG;
	}
}
