package com.monsanto.ServletFramework;

/**
 * Created by IntelliJ IDEA.
 * User: MECORU
 * Date: Jun 11, 2006
 * Time: 6:45:33 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ForwardFeatureConfigurable {
	void addForwardFeature(ForwardFeature feature);
}
