package com.monsanto.AbstractLogging;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * Main access point for the client applications to the logging system.
 *
 * @author Craig Walters
 * @version $Id: Logger.java,v 1.38 2007/09/12 22:31:43 ardharn Exp $
 */
public class Logger {
  private static Hashtable s_ListOfRegisteredLoggers = new Hashtable();
  private static Hashtable enabledLoggerMap = null;

  public static final String AUDIT_LOG = "Audit";
  public static final String INFO_LOG = "Info";
  public static final String ERROR_LOG = "Error";
  public static final String TRACE_LOG = "Trace";
  public static final String DEBUG_LOG = "Debug";
  public static final String WARNING_LOG = "Warning";
  public static final String PERFORMANCE_LOG = "Performance";

  static {
    resetLoggerEnabledStates();
  }

  private static void resetLoggerEnabledStates() {
    enabledLoggerMap = new Hashtable();
    enabledLoggerMap.put(AUDIT_LOG, Boolean.TRUE);
    enabledLoggerMap.put(INFO_LOG, Boolean.TRUE);
    enabledLoggerMap.put(ERROR_LOG, Boolean.TRUE);
    enabledLoggerMap.put(TRACE_LOG, Boolean.FALSE);
    enabledLoggerMap.put(DEBUG_LOG, Boolean.TRUE);
    enabledLoggerMap.put(WARNING_LOG, Boolean.TRUE);
    enabledLoggerMap.put(PERFORMANCE_LOG, Boolean.FALSE);
  }

  private static String buildCallStack() {
    String cstrStack = "Unrecoverable";

    String cstrFullStack = extractFullStackTrace(new Exception());
    cstrStack = getCallStackAppropriateForLogging(cstrFullStack);
    cstrStack = formatFinalCallStack(cstrStack);

    return cstrStack;
  }

  private static String formatFinalCallStack(String cstrStack) {
    StringBuilder sb = new StringBuilder(cstrStack);
    sb.delete(0, 3);  // Get rid of "\tat "
    sb.delete(sb.length() - 1, sb.length());

    cstrStack = sb.toString().trim();
    return cstrStack;
  }

  private static String getCallStackAppropriateForLogging(String cstrFullStack) {
    String cstrStack;
    StringTokenizer st = new StringTokenizer(cstrFullStack, "\n");

    removeLoggingPackageEntries(st);

    cstrStack = st.nextToken();
    return cstrStack;
  }

  private static String extractFullStackTrace(Exception e) {
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    e.printStackTrace(pw);
    return sw.toString();
  }

  private static void removeLoggingPackageEntries(StringTokenizer st) {
    st.nextToken();
    st.nextToken();
    st.nextToken();
  }

  private static boolean shouldLogBeDeactivated(LogInfo newLog) {
    return newLog == null;
  }

  /**
   * Tells the logger where to send debug messages.
   *
   * @param newLog The implementation to send debug messages to.  Pass <code>null</code> to disable debug logging.
   * @return com.monsanto.AbstractLogging.IDebugLog - The previous debug log implementation or <code>null</code> if
   *         none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterDebugLogReturnsPreviousDebugLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testDebugLogCanBeShutOff()
   */
  public static IDebugLog register(IDebugLog newLog) throws LogRegistrationException {

      IDebugLog currentLogger = ( IDebugLog ) s_ListOfRegisteredLoggers.get( DEBUG_LOG );

      if ( shouldLogBeDeactivated( newLog ) ) {

          if ( currentLogger != null ) {

              currentLogger.removeLogDevices();
              s_ListOfRegisteredLoggers.remove( DEBUG_LOG );
              s_ListOfRegisteredLoggers.put( DEBUG_LOG, newLog );
          }

      } else {

          if ( !newLog.equals( currentLogger ) ) {

              s_ListOfRegisteredLoggers.put( DEBUG_LOG, newLog );
          }
      }
      return currentLogger;
  }

  /**
   * Tells the logger where to send trace messages.
   *
   * @param newLog           - The implementation to send trace messages to.  Pass <code>null</code> to disable trace
   *                         logging.
   * @param boolStartEnabled - <code>true</code> if trace logging should be started immediatly.  If this parameter is
   *                         <code>false</code> tracing will not be started until <code>Logger.enableTrace()</code> is
   *                         called.
   * @return com.monsanto.AbstractLogging.ITraceLog - The previous trace log implementation or <code>null</code> if
   *         none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterTraceLogReturnsPreviousTraceLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceLogCanBeShutOff()
   */
  public static ITraceLog register(ITraceLog newLog, boolean boolStartEnabled) throws
      LogRegistrationException {

      ITraceLog currentLogger = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);

      if (shouldLogBeDeactivated(newLog)) {
          if (currentLogger != null) {
              currentLogger.removeLogDevices();
              s_ListOfRegisteredLoggers.remove(TRACE_LOG);
              s_ListOfRegisteredLoggers.put(TRACE_LOG, newLog);
          }

          enableLogger(TRACE_LOG);

      } else {
          if (!newLog.equals(currentLogger)) {
              s_ListOfRegisteredLoggers.put(TRACE_LOG, newLog);
          }

          if (boolStartEnabled) {
              enableLogger(TRACE_LOG);
          } else {
              disableLogger(TRACE_LOG);
          }
      }
      return currentLogger;
  }

  /**
   * Tells the logger where to send trace messages.
   *
   * @param traceLog - The implementation to send trace messages to.  Pass <code>null</code> to disable trace logging.
   *                 Tracing will not be started until <code>Logger.enableTrace()</code> is called.
   * @return com.monsanto.AbstractLogging.ITraceLog - The previous trace log implementation or <code>null</code> if
   *         none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterTraceLogReturnsPreviousTraceLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceLogCanBeShutOff()
   */
  public static ITraceLog register(ITraceLog traceLog) throws LogRegistrationException {
    return Logger.register(traceLog, false);
  }

  /**
   * Tells the logger where to send debug messages.
   *
   * @param newLog The implementation to send error messages to.  Pass <code>null</code> to disable error logging.
   * @return com.monsanto.AbstractLogging.IErrorLog - The previous error log implementation or <code>null</code> if
   *         none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterErrorLogReturnsPreviousErrorLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testErrorLogCanBeShutOff()
   */
  public static IErrorLog register(IErrorLog newLog) throws LogRegistrationException {

      IErrorLog currentLogger = (IErrorLog) s_ListOfRegisteredLoggers.get(ERROR_LOG);

      if (shouldLogBeDeactivated(newLog)) {
          if (currentLogger != null) {
              currentLogger.removeLogDevices();
              s_ListOfRegisteredLoggers.remove(ERROR_LOG);
              s_ListOfRegisteredLoggers.put(ERROR_LOG, newLog);
          }

      } else {
          if (!newLog.equals(currentLogger)) {
              s_ListOfRegisteredLoggers.put(ERROR_LOG, newLog);
          }
      }
      return currentLogger;
  }

  /**
   * Tells the logger where to send warning messages.
   *
   * @param newLog The implementation to send warning messages to.  Pass <code>null</code> to disable warning logging.
   * @return com.monsanto.AbstractLogging.IWarningLog - The previous warning log implementation or <code>null</code> if
   *         none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterWarningLogReturnsPreviousWarningLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testWarningLogCanBeShutOff()
   */
  public static IWarningLog register(IWarningLog newLog) throws LogRegistrationException {

      IWarningLog currentLogger= (IWarningLog) s_ListOfRegisteredLoggers.get(WARNING_LOG);

      if (shouldLogBeDeactivated(newLog)) {
          if (currentLogger != null) {
              currentLogger.removeLogDevices();
              s_ListOfRegisteredLoggers.remove(WARNING_LOG);
              s_ListOfRegisteredLoggers.put(WARNING_LOG, newLog);
          }

      } else {
          if (!newLog.equals(currentLogger)) {
              s_ListOfRegisteredLoggers.put(WARNING_LOG, newLog);
          }
      }
      return currentLogger;
  }

  /**
   * Tells the logger where to send info messages.
   *
   * @param newLog The implementation to send info messages to.  Pass <code>null</code> to disable info logging.
   * @return com.monsanto.AbstractLogging.IInfoLog - The previous info log implementation or <code>null</code> if none
   *         was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterInfoLogReturnsPreviousInfoLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testInfoLogCanBeShutOff()
   */
  public static IInfoLog register(IInfoLog newLog) throws LogRegistrationException {

      IInfoLog currentLogger = (IInfoLog) s_ListOfRegisteredLoggers.get(INFO_LOG);

      if (shouldLogBeDeactivated(newLog)) {
          if (currentLogger != null) {
              currentLogger.removeLogDevices();
              s_ListOfRegisteredLoggers.remove(INFO_LOG);
              s_ListOfRegisteredLoggers.put(INFO_LOG, newLog);
          }
      } else {
          if (!newLog.equals(currentLogger)) {
              s_ListOfRegisteredLoggers.put(INFO_LOG, newLog);
          }
      }
      return currentLogger;
  }

  /**
   * Tells the logger where to send audit messages.
   *
   * @param newLog The implementation to send audit messages to.  Once audit logging is enabled it cannot be disabled.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If an attempt is made to re-register the audit log.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testAuditLogCannotBeShutOff()
   */
  public static final void register(IAuditLog newLog) throws LogRegistrationException {

      IAuditLog currentLog = (IAuditLog) s_ListOfRegisteredLoggers.get(AUDIT_LOG);

      if (currentLog == null) {
          if (newLog != null) {
              s_ListOfRegisteredLoggers.put(AUDIT_LOG, newLog);
      }
      } else {
          currentLog.log("Attempt to redifine the audit log failed");

          throw new LogRegistrationException("The audit log may not be re-defined.");
      }
  }

  /**
   * Tells the logger where to send performance data.
   *
   * @param newLog           - The implementation to send performance data to.  Pass <code>null</code> to disable
   *                         performance logging.
   * @param boolStartEnabled - <code>true</code> if performance logging should be started immediatly.  If this
   *                         parameter is <code>false</code> performance tracking will not be started until {@link
   *                         #enablePerformanceMonitor} is called.
   * @return com.monsanto.AbstractLogging.IPerformanceLog - The previous trace log implementation or <code>null</code>
   *         if none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterPerformanceLogReturnsPreviousTraceLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testPerformanceLogCanBeShutOff()
   */
  public static IPerformanceLog register(IPerformanceLog newLog, boolean boolStartEnabled)
      throws LogRegistrationException {

      IPerformanceLog currentLogger = (IPerformanceLog) s_ListOfRegisteredLoggers.get(PERFORMANCE_LOG);

      if (shouldLogBeDeactivated(newLog)) {
          if (currentLogger != null) {
              currentLogger.removeLogDevices();
              s_ListOfRegisteredLoggers.remove(PERFORMANCE_LOG);
              s_ListOfRegisteredLoggers.put(PERFORMANCE_LOG, newLog);
          }

          disableLogger(PERFORMANCE_LOG);

      } else {
          if (!newLog.equals(currentLogger)) {
              s_ListOfRegisteredLoggers.put(PERFORMANCE_LOG, newLog);
          }

          if (boolStartEnabled) {
              enableLogger(PERFORMANCE_LOG);
          } else {
              disableLogger(PERFORMANCE_LOG);
          }
      }
      return currentLogger;
  }

  /**
   * Tells the logger where to send performance data.
   *
   * @param newLog The implementation to send performance messages to.  Pass <code>null</code> to disable performance
   *               logging.  Metrics will not be gathered until {@link #enablePerformanceMonitor} is called.
   * @return com.monsanto.AbstractLogging.IPerformanceLog - The previous performance log implementation or
   *         <code>null</code> if none was previously registered.
   * @throws com.monsanto.AbstractLogging.LogRegistrationException - If the log device cannot be registered.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterPerformanceLogReturnsPreviousTraceLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testPerformanceLogCanBeShutOff()
   */
  public static IPerformanceLog register(IPerformanceLog newLog) throws LogRegistrationException {
    return Logger.register(newLog, false);
  }

  /**
   * Starts performance logging if the logger is registered.
   *
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testPerformanceLogCanBeTurnedOnAndOff ()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testEnablingPerformanceLoggerWhenNoPerformanceLoggerRegisteredWritesMessageToWarningLog
   *      ()
   * @deprecated Use Logger.enableLogger(Logger.PERFORMANCE_LOG); instead.
   */
  public static void enablePerformanceMonitor() {
    enableLogger(PERFORMANCE_LOG);
  }

  /**
   * Stops performance logging if the logger is registered.
   *
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testPerformanceLogCanBeTurnedOnAndOff ()
   * @deprecated Use Logger.disableLogger(Logger.PERFORMANCE_LOG); instead
   */
  public static void disablePerformanceMonitor() {
    disableLogger(PERFORMANCE_LOG);
  }

  /**
   * Logs the entry of a method to the trace log.  This call should be placed at the begining of every method where
   * trace logging is desired.
   *
   * @see com.monsanto.AbstractLogging.Logger#traceExit()
   * @see com.monsanto.AbstractLogging.Logger#traceExit(Object)
   * @see com.monsanto.AbstractLogging.Logger#traceExit(Object, String)
   * @see com.monsanto.AbstractLogging.Logger#traceExit(int)
   * @see com.monsanto.AbstractLogging.Logger#traceExit(double)
   * @see com.monsanto.AbstractLogging.Logger#traceExit(boolean)
   * @see com.monsanto.AbstractLogging.Logger#traceExit(String)
   * @see com.monsanto.AbstractLogging.Logger#enableTrace()
   * @see com.monsanto.AbstractLogging.Logger#disableTrace()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterTraceLogReturnsPreviousTraceLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceLogCanBeShutOff()
   */
  public static void traceEntry() {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      String sb = new StringBuilder("Entering ").append(buildCallStack()).toString();

      synchronized (traceLog){
          traceLog.log(sb);
      }
    }
  }

  /**
   * Logs the entry of a method to the trace log.  This call should be placed at the begining of every method where
   * trace logging is desired.
   *
   * @param arguments Values of the traced method's input arguments
   */
  public static void traceEntry(Object[] arguments) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      traceEntry(arguments, buildCallStack());
    }
  }

  /**
   * Logs the entry of a method to the trace log.  This call should be placed at the begining of every method where
   * trace logging is desired.
   *
   * @param arguments  Values of the traced method's input arguments
   * @param methodName Fully-qualified name of the method being traced (useful if traceEntry is called from a different
   *                   method, such as an AOP-like interceptor)
   */
  public static void traceEntry(Object[] arguments, String methodName) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      StringBuilder sb = new StringBuilder("Entering ").append(methodName).append(" Arguments {");
      if (arguments != null) {
        for (int i = 0; i < arguments.length; i++) {
          if (i > 0) {
            sb.append(", ");
          }
          sb.append(arguments[i]);
        }
      }
      sb.append("}");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }
  }

  /**
   * Logs the return of a method with no return value to the trace log.  This call should be placed at the return point
   * of every method where trace logging is desired.
   *
   * @see #traceEntry()
   * @see #enableTrace()
   * @see #disableTrace()
   * @see #traceExit(Object oRetVal)
   * @see #traceExit(int iRetVal)
   * @see #traceExit(double dRetVal)
   * @see #traceExit(boolean boolRetVal)
   * @see #traceExit(String cstrRetVal)
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testRegisterTraceLogReturnsPreviousTraceLog()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceLogCanBeShutOff()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceExitOnVoidReturn()
   */
  public static void traceExit() {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      String cstrCallStack = buildCallStack();
      String sb = new StringBuilder("Leaving  ").append(cstrCallStack).toString();

        synchronized (traceLog){
            traceLog.log(sb);
        }
    }
  }

  /**
   * Logs the return of a method which returns an <code>Object</code>.  This call should be placed at the return point
   * of every method where trace logging is desired.  The returned object's <code>toString()</code> method is called
   * and its output is sent to the log.
   *
   * @param oRetVal - The value being returned
   * @return java.lang.Object - oRetVal is passed through
   * @see #traceEntry()
   * @see #enableTrace()
   * @see #disableTrace()
   * @see #traceExit()
   * @see #traceExit(int iRetVal)
   * @see #traceExit(double dRetVal)
   * @see #traceExit(boolean boolRetVal)
   * @see #traceExit(String cstrRetVal)
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceExitOnObjectReturn()
   */
  public static Object traceExit(Object oRetVal) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      String cstrMethodName = buildCallStack();
      StringBuilder sb = new StringBuilder("Leaving  ").append(cstrMethodName).append(" RetVal = '")
          .append((oRetVal == null ? "<null>" : oRetVal.toString())).append("'");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }

    return oRetVal;
  }

  /**
   * Logs the return of a method which returns an <code>Object</code>.  This call should be placed at the return point
   * of every method where trace logging is desired.  The returned object's <code>toString()</code> method is called
   * and its output is sent to the log.
   *
   * @param oRetVal    The value being returned
   * @param methodName Fully-qualified name of the method being traced (useful if traceExit is called from a different
   *                   method, such as an AOP-like interceptor)
   * @return The oRetVal parameter value
   */
  public static Object traceExit(Object oRetVal, String methodName) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      StringBuilder sb = new StringBuilder("Leaving  ").append(methodName).append(" RetVal = '")
          .append((oRetVal == null ? "<null>" : oRetVal.toString())).append("'");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }

    return oRetVal;
  }

  /**
   * Logs the return of a method which returns an <code>int</code>.  This call should be placed at the return point of
   * every method where trace logging is desired.  The value of the <code>int</code> is sent to the log.
   *
   * @param iRetVal - The value being returned
   * @return int iRetVal is passed through
   * @see #traceEntry()
   * @see #enableTrace()
   * @see #disableTrace()
   * @see #traceExit()
   * @see #traceExit(Object oRetVal)
   * @see #traceExit(double dRetVal)
   * @see #traceExit(boolean boolRetVal)
   * @see #traceExit(String cstrRetVal)
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceExitOnObjectReturn()
   */
  public static int traceExit(int iRetVal) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      StringBuilder sb = new StringBuilder("Leaving  ").append(buildCallStack()).append(" RetVal = '").append(iRetVal)
          .append("'");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }

    return iRetVal;
  }

  /**
   * Logs the return of a method which returns an <code>double</code>.  This call should be placed at the return point
   * of every method where trace logging is desired.  The value of the <code>double</code> is sent to the log.
   *
   * @param dRetVal
   * @return double
   * @see #traceExit()
   * @see #traceExit(Object oRetVal)
   * @see #traceExit(int iRetVal)
   * @see #traceExit(boolean boolRetVal)
   * @see #traceExit(String cstrRetVal)
   */
  public static double traceExit(double dRetVal) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      StringBuilder sb = new StringBuilder("Leaving  ").append(buildCallStack()).append(" RetVal = '").append(dRetVal)
          .append("'");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }

    return dRetVal;
  }

  /**
   * Logs the return of a method which returns an <code>boolean</code>.  This call should be placed at the return point
   * of every method where trace logging is desired.  The value of the <code>boolean</code> is sent to the log.
   *
   * @param boolRetVal
   * @return boolean
   * @see #traceExit()
   * @see #traceExit(Object oRetVal)
   * @see #traceExit(int iRetVal)
   * @see #traceExit(double dRetVal)
   * @see #traceExit(String cstrRetVal)
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceExitOnBooleanReturn()
   */
  public static boolean traceExit(boolean boolRetVal) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      StringBuilder sb = new StringBuilder("Leaving  ").append(buildCallStack()).append(" RetVal = '").append(boolRetVal)
          .append("'");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }

    return boolRetVal;
  }

  /**
   * Logs the return of a method which returns an <code>String</code>.  This call should be placed at the return point
   * of every method where trace logging is desired.  The value of the <code>String</code> is sent to the log.
   *
   * @param cstrRetVal
   * @return String
   * @see #traceExit()
   * @see #traceExit(Object oRetVal)
   * @see #traceExit(int iRetVal)
   * @see #traceExit(double dRetVal)
   * @see #traceExit(boolean boolRetVal)
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceExitOnStringReturn()
   */
  public static String traceExit(String cstrRetVal) {
    ITraceLog traceLog = (ITraceLog) s_ListOfRegisteredLoggers.get(TRACE_LOG);
    if ((traceLog != null) && ((Boolean) enabledLoggerMap.get(TRACE_LOG)).booleanValue()) {
      StringBuilder sb = new StringBuilder("Leaving  ").append(buildCallStack()).append(" RetVal = '")
          .append((cstrRetVal == null ? "<null>" : cstrRetVal)).append("'");

        synchronized (traceLog){
            traceLog.log(sb.toString());
        }
    }

    return cstrRetVal;
  }

  /**
   * Starts trace logging.  An ITraceLog-derived object must already be registered.  If no TraceLog is registered a
   * note is written ot the debug log and the call returns silently.
   *
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceLogCanBeTurnedOnAndOff()
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testEnablingTraceWhenNoTraceLoggerRegisteredWritesMessageToWarningLog()
   * @deprecated Use Logger.enableLogger(Logger.TRACE_LOG); instead.
   */
  public static void enableTrace() {
    enableLogger(TRACE_LOG);
  }

  /**
   * Stops trace logging.
   *
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testTraceLogCanBeTurnedOnAndOff ()
   * @deprecated Use Logger.disableLogger(TRACE_LOG); instead.
   */
  public static void disableTrace() {
    disableLogger(TRACE_LOG);
  }

  /**
   * Logs a fatal event to the Error Log.  All fatal events are also written to <code>System.err</code> (even if no
   * ErrorLog is registered).
   *
   * @param event - The event to log.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testFatalMessageReportedEvenIfNoLogRegistered()
   */
  public static void log(FatalEvent event) {
    /*  Redirect Fatal errors to the error log. */
    if (event != null) {
      IErrorLog log = (IErrorLog) s_ListOfRegisteredLoggers.get(ERROR_LOG);
      if (log != null) {
          synchronized (log){
              log.log(event.toString());
          }
      }
      System.err.println(event);
    }
  }

  /**
   * Logs an event to the Audit Log.
   *
   * @param event - The event to log.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testAuditLogCannotBeShutOff()
   */
  public static void log(LoggableEvent event) {
      log(event.getLoggerName(), event);
  }

  /**
   * Returns the number of output devices currently registered to the logger.
   *
   * @return The number of active Loggers.
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testNumActiveLoggers()
   */
  public static int numActiveLoggers() {
    return s_ListOfRegisteredLoggers.size();
  }

  /**
   * Closes all logs.  New logs can be reopened with subsequent calls to Logger.register();
   *
   * @see com.monsanto.AbstractLogging.Test.Logger_UT#testNumActiveLoggers()
   */
  public static void closeLogging() {
    closeLoggers();
    s_ListOfRegisteredLoggers.clear();
    resetLoggerEnabledStates();
  }

  /**
   * Gets the {@link LogInfo LogInfo} data for the selected logger,
   *
   * @param i The index of the logger of interest.
   * @return A LoggerInfo object.
   */
  public static LogInfo getLogInfo(int i) {
    Object[] RetVal_a = s_ListOfRegisteredLoggers.values().toArray();
    return (LogInfo) RetVal_a[i];
  }

  public static void enableLogger(String loggerName) {
    LogInfo logger = (LogInfo) s_ListOfRegisteredLoggers.get(loggerName);
    if (logger != null) {
        synchronized ( enabledLoggerMap ){
            enabledLoggerMap.put(loggerName, Boolean.TRUE);
        }
    } else {
      Logger.log(new LoggableWarning(loggerName + " enabled but there is no log device registered."));
    }
  }

  public static void disableLogger(String loggerName) {
      synchronized (enabledLoggerMap){
          enabledLoggerMap.put(loggerName, Boolean.FALSE);
      }
  }

  /**
   * This method returns if the specified logger is enabled.  If the specified logger is not registered this method
   * return false.
   *
   * @param logName String representing the logger name.
   * @return boolean - Representing if the logger is enabled.
   */
  public static boolean isEnabled(String logName) {
    if (!isRegistered(logName)) {
      return false;
    }
    return ((Boolean) enabledLoggerMap.get(logName)).booleanValue();
  }

  /**
   * This method returns if the specified logger is registered.
   *
   * @param loggerName String reresenting the logger name.
   * @return boolean - Representing if the logger is registered.
   */
  public static boolean isRegistered(String loggerName) {
    if (s_ListOfRegisteredLoggers.get(loggerName) == null) {
      return false;
    }
    return true;
  }

  private static void log(String loggerName, LoggableEvent event) {
      LogInfo logger = (LogInfo) s_ListOfRegisteredLoggers.get(loggerName);
      if (logger != null && event != null && ((Boolean) enabledLoggerMap.get(loggerName)).booleanValue()) {
          synchronized (logger){
              logger.log(event.toString());
          }
      }
  }

  private static void closeLoggers() {
    Iterator iter = s_ListOfRegisteredLoggers.values().iterator();
    while (iter.hasNext()) {
      LogInfo logger = (LogInfo) iter.next();
      if (logger != null) {
        logger.close();
      }
    }
  }
}
