package com.monsanto.AbstractLogging;

import java.util.ArrayList;


/**
 * Base interface for a log device.
 *
 * @version $Id: LogDevice.java,v 1.15 2007/09/12 22:31:42 ardharn Exp $
 * @author CPWALT
 */
public interface LogDevice
{
   /**
    * Attaches the LogDevice to the specified log type.
    *
    * @param log The log to attach to.
    */
   public int attach(ILog log);

   /**
    * Returns the output strategies of LogDevice.
    *
    * @return A String array with each element of the array containing the name
    * of an output strategy.  For example: Console, MidnightRollingFile.
    */
   public ArrayList logDeviceTypes();

   /**
    * Returns the output media of LogDevice.
    *
    * @return A String array with each element of the array containing the name
    *         of an output location.  For example: Console, c:\\Logs\MyApp.log.
    */
   public ArrayList logDeviceLocations();

   /**
    * Closes the log device.
    */
   public void close();
}
