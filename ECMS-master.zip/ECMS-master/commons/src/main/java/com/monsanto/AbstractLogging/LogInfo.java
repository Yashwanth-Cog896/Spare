/*
 LogInfo was created on Jul 2, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;




/**
 * <p>Title: LogInfo</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: LogInfo.java,v 1.11 2007/09/12 22:31:43 ardharn Exp $
 */
public interface LogInfo
{
   /**
    * Returns the name of the log engine.  Examples of the name are
    * "exampleServlet.Info" and "exampleServlet.Error".
    *
    * @return The name.
    */
   public String name();

   /**
    * Returns the type of the log. Examples of the type are "ERROR" and "INFO".
    *
    * @return The type.
    */
   public String type();

   /**
    * Returns the number of code>{@link LogDevice}</code>
    * objects associated with this log.  A log device is the class that manages
    * the actual storage of the log messages.
    *
    * @return the number of log devices.
    */
   public int numLogDevices();

   /**
    * Returns a string identifying the log device type.  Examples of a log device
    * type are "MidnightRolling", "XML", and "Database".
    *
    * @param j  The index of the log device.
    *
    * @return The device type.
    */
   public String getLogDeviceType(int j);

   /**
    * Returns location where the log device outputs its results.  For example,
    * this may be a disk file or a database.
    *
    * @param j The index of the log device.
    *
    * @return The device's output location.
    */
   public String getLogDeviceLocation(int j);

	/**
	 * Logs the message to the Audit Log.
	 *
	 * @param cstrMessage The message to log.
	 */
	void log(String cstrMessage);

   /**
    * Closes the log.
    */
   public void close();
}
