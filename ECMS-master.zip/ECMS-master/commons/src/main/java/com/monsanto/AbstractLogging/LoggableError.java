package com.monsanto.AbstractLogging;


/**
 * A message that needs written to the ErrorLog (if one has been registered).
 *
 * @author CPWALT
 * @version $Id: LoggableError.java,v 1.15 2007/09/12 22:31:42 ardharn Exp $
 */
public class LoggableError extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrText The message to log.
    */
   public LoggableError(String cstrText)
   {
       super(cstrText);
   }

   /**
    * Constructor.
    *
    * @param throwable The exception to log.
    */
   public LoggableError(Throwable throwable)
   {
       super(throwable);
   }

	public String getLoggerName() {
		return Logger.ERROR_LOG;
	}
}
