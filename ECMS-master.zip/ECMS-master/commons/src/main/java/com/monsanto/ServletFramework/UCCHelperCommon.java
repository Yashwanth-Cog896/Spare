package com.monsanto.ServletFramework;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;

/**
 * Created by IntelliJ IDEA.
 * User: sdshan1
 * Date: Sep 16, 2005
 * Time: 9:16:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class UCCHelperCommon {
  private HttpServletRequest request;
  private HttpServletResponse response;

  public UCCHelperCommon(HttpServletRequest request, HttpServletResponse response) {
    this.request = request;
    this.response = response;
  }

  /**
   * deprecated
   */
  public javax.servlet.http.Cookie[] getCookies() {
    if(request == null) {
      return new javax.servlet.http.Cookie[0];
    }
    return request.getCookies();
  }

  public Cookie[] getClientCookies() {
    if(request == null || request.getCookies() == null) {
      return new Cookie[0];
    } else {
      javax.servlet.http.Cookie[] javaCookies = request.getCookies();
      Cookie[] monsantoCookies = new Cookie[javaCookies.length];
      for (int i = 0; i < javaCookies.length; i++) {
        javax.servlet.http.Cookie javaCookie = javaCookies[i];
        monsantoCookies[i] = new Cookie(javaCookie.getName(), javaCookie.getValue());
        monsantoCookies[i].setDomain(javaCookie.getDomain());
        monsantoCookies[i].setPath(javaCookie.getPath());
      }
      return monsantoCookies;
    }
  }

  public void addCookie(Cookie monsantoCookie) {
    if (monsantoCookie != null) {
      javax.servlet.http.Cookie javaCookie = new javax.servlet.http.Cookie(monsantoCookie.getName(), monsantoCookie.getValue());
      if (!StringUtils.isNullOrEmpty(monsantoCookie.getDomain())) {
        javaCookie.setDomain(monsantoCookie.getDomain());
      }
      if (!StringUtils.isNullOrEmpty(monsantoCookie.getPath())) {
        javaCookie.setPath(monsantoCookie.getPath());
      }
			Date expirationDate = monsantoCookie.getExpiration();
			Date currentDate = new Date();
			if (expirationDate != null && expirationDate.getTime() > currentDate.getTime()) {
				javaCookie.setMaxAge((int) ((expirationDate.getTime() - currentDate.getTime())/1000));
      }
      response.addCookie(javaCookie);
    }
  }

  public String requestedURL() {
    Logger.traceEntry();

    if(request == null) {
      return "";
    }
    String cstrRetVal = request.getRequestURL().toString();
    return Logger.traceExit(cstrRetVal);
  }

  public String getHeader(final String name) {
    if(request == null) {
      return "";
    }
    return request.getHeader(name);
  }

  public String[] getHeaderNames() {
    if(request == null) {
      return new String[0];
    }
    ArrayList listOfHeaderNames = new ArrayList();
    for (Enumeration en = request.getHeaderNames(); en.hasMoreElements();) {
      listOfHeaderNames.add(en.nextElement());
    }
    String[] headerNamesArray = new String[listOfHeaderNames.size()];
    listOfHeaderNames.toArray(headerNamesArray);
    return headerNamesArray;
  }

  public Enumeration getParameterNames() throws java.io.IOException {
    //ToDo: Don't have UCCServletHelper delegate to this one until we've figured out the implementation issues
    if(request == null) {
      return Collections.enumeration(Collections.EMPTY_LIST);
    }
    return request.getParameterNames();
  }

  public String getRequestParameterValue(final String cstrParameterName) throws java.io.IOException {
    //ToDo: Don't have UCCServletHelper delegate to this one until we've figured out the implementation issues
    if(request == null) {
      return "";
    }
    return request.getParameter(cstrParameterName);
  }

  public String[] getRequestParameterValues(final String cstrParameterName) throws java.io.IOException {
    //ToDo: Don't have UCCServletHelper delegate to this one until we've figured out the implementation issues
    if(request == null) {
      return new String[0];
    }
    return (request.getParameterValues(cstrParameterName));
  }


}
