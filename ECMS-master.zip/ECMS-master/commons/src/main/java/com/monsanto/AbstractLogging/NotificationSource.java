/*
 NotificationSource was created on Nov 23, 2004 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;


/**
 * <p>Title: NotificationSource</p> <p>Description: <p>Copyright: Copyright (c) 2004</p> <p>Company: Monsanto</p>
 *
 * @author CPWALT
 * @version $Id: NotificationSource.java,v 1.8 2007/09/12 22:31:43 ardharn Exp $
 */
public interface NotificationSource
{
   public void notify(String cstrMessage);
}
