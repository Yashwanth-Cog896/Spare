//Source file: C:\\Development\\MTed\\Source\\java\\com\\monsanto\\ServletFramework\\UCCHelper.java

package com.monsanto.ServletFramework;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import org.w3c.dom.Document;

import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * Provides helper methods used by UseCaseController subclasses.
 */
public interface UCCHelper extends Serializable{
  static final int s_iDefaultFileUploadSize = 1024 * 1024;

  void setContentType(String contentType);

  /**
   * Applies an XSL stylesheet to an XML document. Implementing classes
   * are responsible for determine where the result should be sent.
   *
   * @param xmlDoc the XML Document on which the stylesheet should be applied
   * @param xslURL the URL of an XSL stylesheet
   * @throws java.io.IOException
   */
  void applyStylesheet(Document xmlDoc, String xslURL) throws IOException;

  /**
   * Applies an XSL stylesheet to an XML document. Implementing classes
   * are responsible for determine where the result should be sent.
   *
   * @param xmlDoc the XML Document on which the stylesheet should be applied
   * @param xslURL the URL of an XSL stylesheet
   * @param contentType the contentType of the transformed stream
   * @throws java.io.IOException
   */
  public abstract void applyStylesheet(Document xmlDoc,
                                       String xslURL,
                                       String contentType) throws IOException;

  /**
   * Applies an XSL stylesheet to an XML document using the given stylesheet
   * parameters. Implementing classes are responsible for determine where the
   * result should be sent.
   *
   * @param xmlDoc   the XML Document on which the stylesheet should be applied
   * @param xsltURI  the URI of an XSL stylesheet
   * @param paramMap stylesheet parameter map (param name, param value)
   * @throws java.io.IOException
   */
  void applyStylesheet(Document xmlDoc, String xsltURI, Map paramMap) throws IOException;

  /**
    * <P>Enables to output result of a request to any output formats</P>
    * <p/>
    * <P>For that, applications need to write their implementation of Formatted writer</P>
    * <p/>
    *
    * @param writer    a reference to the implementation repsonsible for writing result to correct formats
    *
    * @throws java.io.IOException relevant for each FormattedWriter implementation
   */
   void writeToFormattedWriter(FormattedWriter writer) throws IOException;

  /**
     * Applies a stylesheet & sets the contentType to application/vnd.ms-excel on the results.  Use an html table in
     * the style sheet & excel will interpret each cell in the html table as an excel cell.
     *<p/>
     * If you want to specify the file name that is used, add "extra path information" to your UCC invocation
     * (i.e. action attribute of your form /servletpath/MyServlet/desiredFileName.xls) and make sure your web.xml
     * servlet mapping allows this via the wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern>
     * <p/>
     *
     * @param xmlDoc   the XML Document on which the stylesheet should be applied
     * @param xsltURI  the URI of an XSL stylesheet
     * @param paramMap stylesheet parameter map (param name, param value)
     * @throws java.io.IOException
     */
    void writeToExcel(Document xmlDoc, String xsltURI, Map paramMap) throws IOException;

    /**
     * Applies a stylesheet & sets the contentType to application/vnd.ms-excel on the results.  Use an html table in
     * the style sheet & excel will interpret each cell in the html table as an excel cell.
     *<p/>
     * If you want to specify the file name that is used, add "extra path information" to your UCC invocation
     * (i.e. action attribute of your form /servletpath/MyServlet/desiredFileName.xls) and make sure your web.xml
     * servlet mapping allows this via the wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern>
     * <p/>
     *
     * @param xmlDoc  the XML Document on which the stylesheet should be applied
     * @param xsltURI the URI of an XSL stylesheet
     * @throws java.io.IOException
     */
    void writeToExcel(Document xmlDoc, String xsltURI) throws IOException;

  /**
   * <P>Applies an XSL stylesheet to an XML document and sets the content type to msword.
   * </P>
   * If you want to specify the file name that is used, add "extra path information" to your UCC invocation
   * (i.e. action attribute of your form /servletpath/MyServlet/desiredFileName.doc) and make sure your web.xml
   * servlet mapping allows this via the wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern>
   * <p/>
   *
   * @param xmlDoc
   * @param xsltURI
   * @param paramMap
   * @throws java.io.IOException
   */
  void writeToWord(final Document xmlDoc, final String xsltURI, final Map paramMap) throws IOException;

  /**
   * <P>Applies an XSL stylesheet to an XML document and sets the content type to msword.
   * </P>
   * If you want to specify the file name that is used, add "extra path information" to your UCC invocation
   * (i.e. action attribute of your form /servletpath/MyServlet/desiredFileName.doc) and make sure your web.xml
   * servlet mapping allows this via the wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern>
   * <p/>
   *
   * @param xmlDoc
   * @param xsltURI
   * @throws java.io.IOException
   */
  void writeToWord(final Document xmlDoc, final String xsltURI) throws IOException;

  /**
   * Gets an InputStream from reading statisticalmeasure from a given URL.
   *
   * @param url the URL of the file to be read
   * @return an InputStream for reading it.
   * @throws java.io.IOException
   */
  InputStream getInputStream(String url) throws IOException;

  /**
   * @return an Enumeration of the names of the available parameters.
   * @throws java.io.IOException
   */
  Enumeration getParameterNames() throws IOException;

  /**
   * Gets a binary stream connected to the client.
   *
   * @return The stream.
   * @throws java.io.IOException
   */
  OutputStream getBinaryStream() throws IOException;

  /**
   * Gets a PrintWriter where results should be written.
   *
   * @return the PrintWriter.
   * @throws java.io.IOException
   */
  PrintWriter getPrintWriter() throws IOException;

  /**
   * Returns The value of the given parameter name.
   *
   * @param parameterName The name of the parameter to get the value of.
   * @return The value of the given parameter name.
   * @throws java.io.IOException
   */
  String getRequestParameterValue(String parameterName) throws IOException;

  /**
   * Gets the value of a given request-scoped parameter.
   *
   * @param parameterName the name of the parameter
   * @return the parameter value.
   * @throws java.io.IOException
   */
  String[] getRequestParameterValues(String parameterName) throws IOException;

  /**
   * Gets an Iterator over the ids associated with the
   * request attributes.
   *
   * @return An Iterator over the ids.
   * @throws java.io.IOException If an error occurs.
   */
  Iterator getRequestAttributeNames() throws IOException;

  /**
   * Returns the value associated with the given request attribute name.
   *
   * @param attributeName The name associated with the request attribute.
   * @return The Object associated with the given attribute name.
   */
  Object getRequestAttributeValue(String attributeName);

  /**
   * Sets the value of the given request-scoped attribute.
   *
   * @param name  The name to associate with the attribute.
   * @param value The attribute to add.
   */
  void setRequestAttributeValue(String name, Object value);

  /**
   * Removes the attribute associated with given name.
   *
   * @param attributeName The name associated with the attribute
   *                      to be removed.
   */
  void removeRequestAttribute(String attributeName);

  /**
   * Gets an Iterator over the ids associated with the
   * session attributes.
   *
   * @return An Iterator over the ids.
   * @throws java.io.IOException If an error occurs.
   */
  Iterator getSessionParameterNames() throws IOException;

  /**
   * Gets the value of a given session-scoped parameter.
   *
   * @param parameterName the name of the parameter
   * @return the parameter value.
   */
  Object getSessionParameter(String parameterName);

  /**
   * Gets the init parameters.  The <code>HasMap</code> has the init parameter name for the key values and the init
   * parameter value for the value.  Each are stored as a <code>String</code>.
   *
   * @return The init parameters in a HashMap keyed by the init parameter name.
   */
  HashMap getInitParameters();

  /**
   * Reports a given error.
   *
   * @param message the error message
   */
  void reportError(String message);

  /**
   * Reports a given error.
   *
   * @param t a Throwable describing the error
   */
  void reportError(Throwable t);

  /**
   * Sets the value of a given session-scoped parameter.
   *
   * @param name  the name of the parameter
   * @param value the value of the parameter
   */
  void setSessionParameter(String name, Object value);

  /**
   * Removes the value of a given session-scoped parameter.
   *
   * @param cstrName The name of the parameter
   */
  void removeSessionParameter(String cstrName);

  /**
   * Closes the session and eliminates all session-scoped paramaters.
   */
  void closeSession();

  /**
   * Eliminates all session-scoped paramaters.
   */
  void clearSession();

  /**
   * Encodes the given URL.
   *
   * @param cstrURL The given URL to Encode.
   * @return The Encoded URL.
   */
  String encodeURL(String cstrURL);

  /**
   * Checks the server to see if the server has already authenticated the user.
   *
   * @return java.lang.String
   */
  String serverAuthorizedUser();

  /**
   * Displays the given HTML file.
   *
   * @param cstrFileName The name of the HTML file to display.
   * @throws java.io.IOException
   */
  void displayHTML_File(String cstrFileName) throws IOException;

    /**
     * <P>This method includes the request from this servlet to the response of a servlet in another context.  This
     * method allows a resource in one context to execute a UCC in another context and include its response as part of
     * its response.</P>
     * <P>An example use of this would be if you have a JSP in one context wanting to include the ressponse from a UCC
     * in another context.  There would then be a JSP in the calling context and a UCC in the called context.  The
     * calling context needs to have its crossContext attribute in its context.xml file set to "true".  Somewhere on
     * the JSP would be line like <c:import url="/calledContextUCCUrl" context=/calledContext" />.  At the bottom of
     * the UCC method, instead of doing a forward it would do a helper.include passing in the JSP name to send back.
     * <P>Just like the helper.forward method, this method acts entirely within the server and the client cannot tell
     * the include occured.</P>
     *
     * @param cstrTo The given URL to include in the cross context response object.
     * @throws java.io.IOException - If there was an error processing the RequestDispatcher.include.
     */
  void include(String cstrTo) throws IOException;

    /**
     * <P>This method forwards the request from this servlet to another resource
     * on the server.  THis method allows one UCC to do preliminary processing of
     * a request and another resource (URL) to generate the response.</P>
     * <P>Unlike {@link #redirect(String)}, this method acts entirely
     * within the server and the client cannot tell the forward occured.</P>
     *
     * @param cstrTo The URL to forward the response object to.
     * @throws java.io.IOException
     */
  void forward(String cstrTo) throws IOException;

  /**
   * <P>This method returns an ArrayList containing the complete path & filenames
   * of the files uploaded to the servlet.</P>
   * <P>HTML to initiate the file upload looks like this:</P>
   * <P> <PRE>&lt;FORM ACTION="Your_Servlet_Action"
   * ENCTYPE="multipart/form-data" METHOD="POST"&gt; Enter file to upload:&lt;INPUT TYPE=FILE NAME=file&gt; &lt;INOUT TYPE=SUBMIT&gt;
   * </P></PRE>
   *
   * @return A collection of client file path/names from a multipart form.
   *
   * @throws java.io.IOException
   */
  ArrayList getClientFiles() throws IOException;

  /**
   * Returns the current directory.
   *
   * @return The current directory.
   */
  String getCurrentDirectory();

  /**
   * Returns a name of a temporary directory where short-lived working files
   * can be stored.  Each context receives a different temporary directory.
   * The folder returned by this method may have limited space available.
   *
   * @return The directory.
   * @see #getScratchFolder()
   */
  File getTempDirectory();

  /**
   * Returns the current context execution path.
   *
   * @param path The relative path of the current context execution path.
   * @return The current context execution path.
   */
  String getRealPath(String path);

  /**
    *set the (absolute) path to the import file directory.  Variation of
   * setImportFileDir(path, boolean).  The default location if this method is
   * not called is the scratch directory.
   *
   * @param cstrDirectory - The absolute path to set the import file directory to.
   * @return String The previous directory.
   * @throws java.io.IOException If the target folder is read-only or does not exist.
   * @see UCCHelper#setImportFileDir(String, boolean)
   */
  String setImportFileDir(String cstrDirectory) throws IOException;

  /**
   * Sets the path to the import file directory.  Variation of
   * setImportFileDir(path) with added flexibility to specify if the passed-in
   * path is a relative path or an absolute path.  The default location if this
   * method is not called is the scratch directory.
   *
   * @param cstrDirectory - The path to set the import file directory to.
   * @param relative      - true, if cstrDirectory is realtive to current directory.
   *                      false, otherwise.
   * @return String The previous directory.
   * @throws java.io.IOException If the target folder is read-only or does not exist.
   * @see UCCHelper#setImportFileDir(String)
   */
  String setImportFileDir(String cstrDirectory, boolean relative) throws IOException;

  /**
   * Sets the Maximum Import File Size allowed to import a file from a
   * multipart form.
   *
   * @param iMaxSize The import file size (in bytes).
   * @return The previous maximum import file size.
   */
  int setMaxImportFileSize(int iMaxSize);

  /**
   * Returns the session id.
   *
   * @return The session id.
   */
  String name();

  /**
   * Returns the session header information.
   *
   * @param name The name of the header to return the value of.
   * @return The session header information.
   */
  String getHeader(String name);

  /**
   * Returns the names of the session headers.
   *
   * @return String[] of session header names.
   */
  String[] getHeaderNames();

  /**
   * Sets the response header information.
   *
   * @param name  The name of the header.
   * @param value The value of the header.
   */
  void setHeader(String name, String value);

  /**
   * Writes the XML document to the Browser
   *
   * @param doc The document need to display in the browser
   */
  void writeXMLDocument(Document doc);

  /**
   * Writes the XML document to the Browser
   *
   * @param doc The document need to display in the browser
   * @param encoding encoding used to serialize XML
   */
  void writeXMLDocument(Document doc, String encoding);

  /**
   * Sets a web page to expire immediately.
   */
  void expire();

  /**
   * get Servlet Context attribute
   */
  Object getContextAttribute(String name);

  /**
   * set servlet context attribute
   */
  void setContextAttribute(String name, Object object);

  /**
   * remove servlet context attribute
   */
  void removeContextAttribute(String name);

  /**
   * Returns the URL that was requested by the client.
   *
   * @return The requested URL.
   */
  String requestedURL();

  /**
   * <P>This method redirects the response to the specified location.</P>
   * <p/>
   * <P>This method sends a temporary redirect response to the client using the
   * specified redirect location <code>cstrTo</code>. This method can accept
   * relative URLs; the servlet container must convert the relative URL to an
   * absolute URL before sending the response to the client. If the location is
   * relative without a leading '/' the container interprets it as relative to
   * the current request URI. If the location is relative with a leading '/'
   * the container interprets it as relative to the servlet container root.</P>
   * <p/>
   * <P>If the response has already been committed, this method throws an
   * <code>IllegalStateException</code>. After using this method, the response
   * should be considered to be committed and should not be written to.</P>
   *
   * @param cstrTo - The URL of the resource being redirected to.
   * @throws java.io.IOException
   * @see #forward(String)
   */
  void redirect(String cstrTo) throws IOException;

  /**
   * Gets the context attributes.  The <code>HasMap</code> has the attribute name for the key values and the attribute
   * value for the value.  Each are stored as a <code>String</code>.
   *
   * @return The context attributes in a HashMap keyed by the attribute name.
   */
  HashMap getContextAttributes();

  /**
   * Get a resource from the ServletContext
   *
   * @param uri relative location of a resource object
   * @return The URL for
   * @throws java.io.IOException
   */
  URL getResource(String uri) throws IOException;

  /**
   * Create a uniquely named scratch folder for this session.  The folder
   * returned by this call will typically have have more disk space available
   * than what is available from the call to getTempDirectory().
   *
   * @return Name of the scratch folder
   * @see #getTempDirectory()
   */
  String getScratchFolder();

  /**
   * Removes the scratch folder created for this session.
   */
  void deleteScratchFolder();

  boolean isSystemSecurityEnabled();

  String getAuthenticatedUserID();

  String getAuthenticatedUserFullName();

  int getFailedLogonAttempts();

  Date getLastLogon();

	String getAuthenticatedUserDomain();

  boolean isUserInRole(String role);

  Cookie [] getClientCookies();

  Cookie [] getCookies(String dummyValue);

  /**
   * deprecated
   */
  javax.servlet.http.Cookie[] getCookies();

  void addCookie(Cookie cookie);

  SystemSecurityProxy getSystemSecurityProxy();

  void setMaxInactiveInterval(int iTimeOut);

  String getServletName();

  String getPathInfo();

  FormRequestData getFormRequestData() throws BadFormDataException;

    /**  This method will return the part of the request's URL from the
     * protocol name up to the query string in the first line of the
     * http request. The web container does not decode this String. For example:
     * <br/>
     * <br/>
     * POST /some/path.html HTTP/1.1		/some/path.html <br/>
     * GET http://foo.bar/a.html HTTP/1.0 		/a.html</br>
     *
     * see http://java.sun.com/j2ee/sdk_1.3/techdocs/api/javax/servlet/http/HttpServletRequest.html#getRequestURI()
     * @return Request URI
     */
  String getRequestURI();

    /** This will return the current context path for the application
     *
     */
    String getContextPath();
}
