package com.monsanto.ServletFramework;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: mecoru
 * Date: Sep 7, 2005
 * Time: 3:08:25 PM
 *
 * Your data object (bean) should implement this marker interface and provide getters and setters.
 * You will specify the full package path of the data class in the web.xml in a formdata init-param
 * of the servlet definition as in this example:
 *
 *   <servlet>
 *    <servlet-name>BeanTest</servlet-name>
 *    <servlet-class>com.monsanto.ServletFramework.Test.testServlet</servlet-class>
 *    <init-param>
 *      <param-name>controller</param-name>
 *      <param-value>com.monsanto.ServletFramework.Test.MockBlockingController</param-value>
 *    </init-param>
 *    <!-- This is the definition of your form request data object -->
 *    <init-param>
 *      <param-name>formdata</param-name>
 *      <param-value>com.monsanto.ServletFramework.Test.MyConcreteFormRequestDataObject</param-value>
 *    </init-param>
 *  </servlet>
 *
 * In order to get access to the data object in your UCC (UseCaseController), you would use the
 * getFormRequestData() method of the UCCHelper as follows:
 *
 * MyConcreteFormRequestDataObject form = (MyConcreteFormRequestDataObject) helper.getFormRequestData();
 *
 * The concrete data object is also placed onto the Request as an attribute so that if you change data in
 * the data object and forward to a JSP for output, your JSP would have access
 *
 * NOTE: If you prefer that the object be placed onto the Session instead of the Request, change the
 *  init-param from "formdata" to "formdatasession" like this example:
 *
 *   <servlet>
 *    <servlet-name>BeanTestSession</servlet-name>
 *    <servlet-class>com.monsanto.ServletFramework.Test.testServlet</servlet-class>
 *    <init-param>
 *      <param-name>controller</param-name>
 *      <param-value>com.monsanto.ServletFramework.Test.MockBlockingController</param-value>
 *    </init-param>
 *    <!-- This is the definition of your form request data object -->
 *    <init-param>
 *      <param-name>formdatasession</param-name>
 *      <param-value>com.monsanto.ServletFramework.Test.MyConcreteFormRequestDataObject</param-value>
 *    </init-param>
 *  </servlet>
 *
 * NOTE: The standard notations for Lists, Maps, and nested data can be recognized and handled properly.
 *  This means that your bean can include Lists, Maps, and nested beans and they will be populated from
 *  the form data.  To see an example of how the form would need to supply the data, look at the test
 *  called "testFormDataCreation_WithExtraData_ListAndMapSupport" in UCCServletHelper_UT.  JSTL can be
 *  used to generate forms that will provide data in the format shown in the test.  In order to turn on
 *  the ability to handle Lists, Maps, and nested data, your bean must implement an additional Interface
 *  between the concrete bean and this interface.  This additional interface must have the word "Data" in
 *  the name.  Here is an example hierarchy.
 *
 *      FormRequestData
 *            ^
 *            |
 *      MyFormWithListData (interface defining getters and setters including List, Map, and nested access)
 *            ^
 *            |
 *        MyForm (concrete bean)
 *
 *  For an example of how this Interface can be defined and how it relates to the concrete bean, look at
 *  the FormWithListData interface and MockConcreteFormWithList java classes in /ServletFramework/Test.
 *  If you define a "Data" interface, only the getters and setters in that interface will actually be
 *  populated from the form.  If you have additional getters/setters in the concrete bean class that aren't
 *  in the "Data" interface, they would not be populated.
 *
 *  This List/Map/Nested data feature allows the population of beans from complex forms to be handled
 *  automatically. At this time, ONLY the Java List, and Map collection interfaces are handled.  The
 *  typical (expected) concrete collections to back these would be an ArrayList and a HashMap.  These are
 *  the only concrete collection classes that have been tested.  Using other concrete collection classes
 *  may or may not work.  If support for other collection classes is required, tests for these should be
 *  added to the UCCServletHelper_UT and the MockConcreteFormWithList concrete class should be updated with
 *  examples to test.  The class that would need to be updated to provide the additional support is
 *  FormRequestDataPopulationProxy.
 *
 */
public interface FormRequestData extends Serializable {
}
