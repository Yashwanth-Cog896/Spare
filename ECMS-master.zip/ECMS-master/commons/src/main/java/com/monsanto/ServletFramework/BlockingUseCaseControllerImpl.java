package com.monsanto.ServletFramework;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Apr 1, 2005
 * Time: 4:02:28 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class BlockingUseCaseControllerImpl
implements BlockingUseCaseController
{
   public void handleDoubleSubmit(UCCHelper helper) {
      helper.reportError("Cannot handle double click; class: " + this.getClass().getName());
   }
}
