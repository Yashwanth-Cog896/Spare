package com.monsanto.ServletFramework;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.fileutil.FileUtil;
import com.monsanto.XMLUtil.XSLTUtil;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.sun.org.apache.xml.internal.serialize.Method;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.iterators.EnumerationIterator;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSName;
import org.w3c.dom.Document;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.*;
import java.net.URL;
import java.util.*;


/**
 * Provides servlet-specific helper methods used by UseCaseController subclasses.
 */
public class UCCServletHelper implements UCCHelper, HttpSessionBindingListener, ForwardFeatureConfigurable {
  private XMLSerializer serializer = new XMLSerializer();
  public static final String MULTI_PART_REQUEST = "multipart/form-data";
  private static final String DEFAULT_CONTENT_TYPE = "text/html";
  private static final String EXCEL_CONTENT_TYPE = "application/vnd.ms-excel";
  private static final String WORD_CONTENT_TYPE = "application/msword";


  protected MultipartRequest m_MPR = null;
  private boolean m_boolIsMultiPartRequest;

  private String m_cstrFileSaveDir;
  private String m_cstrScratchFolder;

  private int m_iMaxRequestSize = s_iDefaultFileUploadSize;
  protected HttpServletRequest m_request;
  protected HttpServletResponse m_response;
  private ServletConfig m_config;
  private boolean systemSecurityEnabled = false;
  protected SystemSecurityProxy systemSecurityProxy = null;
  public static final String FORM_REQUEST_PARM = "formdata";
  public static final String FORM_REQUEST_SESSION_PARM = "formdatasession";
  private UCCHelperCommon helperCommon;
  private ForwardFeature forwardFeature = new DefaultForwardFeature();
  public static final String AT_SIGN = "@";

  /**
   * Creates a UCCServletHelper.
   *
   * @param config   the ServletConfig
   * @param request  the HttpServletRequest
   * @param response the HttpServletResponse
   *
   * @see com.monsanto.ServletFramework.Test.UCCServletHelper_UT#testCreate()
   */
  public UCCServletHelper(final ServletConfig config,
                          final HttpServletRequest request,
                          final HttpServletResponse response) {
    initialSetup(config, request, response, false, null);
  }

  /**
   * Constructs a UCCServletHelper with system secturity.
   *
   * @param config                a ServletConfig object.
   * @param request               a HttpServletRequest object.
   * @param response              a HttpServletResponse object.
   * @param systemSecurityEnabled <code>true</code> if the servlet should use the system security standard.
   * @param proxy                 The security proxy server to get authorization information from.
   */
  public UCCServletHelper(final ServletConfig config,
                          final HttpServletRequest request,
                          final HttpServletResponse response,
                          final boolean systemSecurityEnabled,
                          final SystemSecurityProxy proxy) {
    initialSetup(config, request, response, systemSecurityEnabled, proxy);
  }

  /**
   * Provides initial setup for class.
   *
   * @param config                a ServletConfig object.
   * @param request               a HttpServletRequest object.
   * @param response              a HttpServletResponse object.
   * @param systemSecurityEnabled <code>true</code> if the servlet should use the system security standard.
   * @param proxy                 The security proxy server to get authorization information from.
   */
  protected void initialSetup(final ServletConfig config,
                              final HttpServletRequest request,
                              final HttpServletResponse response,
                              final boolean systemSecurityEnabled,
                              final SystemSecurityProxy proxy) {
    this.m_config = config;
    this.m_request = request;
    this.m_response = response;
    this.systemSecurityEnabled = systemSecurityEnabled;
    this.systemSecurityProxy = proxy;
    this.m_boolIsMultiPartRequest = false;
    String cstrContentType = request.getContentType();
    if (cstrContentType != null && cstrContentType.length() >= MULTI_PART_REQUEST.length()) {
      cstrContentType = cstrContentType.substring(0, MULTI_PART_REQUEST.length());
      m_boolIsMultiPartRequest = (cstrContentType.equalsIgnoreCase(MULTI_PART_REQUEST));
    }
    m_response.setContentType("text/html");

    helperCommon = new UCCHelperCommon(request, response);
  }

  /*  Initializes the Multipart Request if necessary.  */
  private void initMPR() throws IOException {
    if (m_boolIsMultiPartRequest && (m_MPR == null)) {
      m_MPR = new MultipartRequest(m_request, getSaveFileDir(), m_iMaxRequestSize);
    }
  }

  private String getSaveFileDir() {
	  if (m_cstrFileSaveDir ==  null) {
		  m_cstrFileSaveDir  = getScratchFolder();
	  }
	  return m_cstrFileSaveDir;
  }

  private String setSaveFileDir(String cstrDirectory)
  throws IllegalArgumentException, IOException
  {
	    String originalSaveFileDir = getSaveFileDir();

	    m_cstrFileSaveDir = new File(cstrDirectory).getAbsolutePath();
	    if (m_cstrFileSaveDir.endsWith(".")) {
	    	m_cstrFileSaveDir = m_cstrFileSaveDir.substring(0, m_cstrFileSaveDir.length() - 1);
	    }

	    if (!FileUtil.isFolder(m_cstrFileSaveDir)) {
	      throw new IllegalArgumentException("Not a directory: " + m_cstrFileSaveDir);
	    }

	    final File folder = new File(cstrDirectory);
	    if (!folder.canWrite()) {
	      throw new IOException("Not writable: " + m_cstrFileSaveDir);
	    }

	    // check to make sure return value has a trailing /
	    if (!originalSaveFileDir.endsWith(File.separator)) {
	      originalSaveFileDir = originalSaveFileDir + File.separator;
	    }

	    return originalSaveFileDir;
  }

  /**
   * Overrides the defaultcontent type for the response.  The default is text/html.
   *
   * @param contentType - The content type to use if other than text/html.
   *
   * @see com.monsanto.ServletFramework.Test.UCCServletHelper_UT#testSetContentType()
   * @see com.monsanto.ServletFramework.Test.UCCServletHelper_UT#testContentTypeIsTextHtmlByDefault()
   */
  public void setContentType(final String contentType) {
    m_response.setContentType(contentType);
  }

  /**
   * Applies an XSL stylesheet to an XML document. Implementing classes are responsible for determine where the result
   * should be sent.
   *
   * @param xmlDoc  the XML Document on which the stylesheet should be applied
   * @param xsltURI the URI of an XSL stylesheet
   *
   * @exception java.io.IOException
   */
  public void applyStylesheet(final Document xmlDoc, final String xsltURI) throws IOException {
    applyStylesheet(xmlDoc, xsltURI, DEFAULT_CONTENT_TYPE);
  }

  /**
   * Applies an XSL stylesheet to an XML document. Implementing classes are responsible for determine where the result
   * should be sent.
   *
   * @param xmlDoc      the XML Document on which the stylesheet should be applied
   * @param xsltURI     the URI of an XSL stylesheet
   * @param contentType the contentType of the transformed stream
   *
   * @exception java.io.IOException
   */
  public void applyStylesheet(final Document xmlDoc,
                              final String xsltURI,
                              final String contentType)
      throws IOException {
    final PrintWriter pw = getPrintWriter();
    applyStylesheet(xmlDoc, xsltURI, null, contentType, pw);
    pw.close();
  }

  /**
   * Applies an XSL stylesheet to an XML document using the given stylesheet parameters. Implementing classes are
   * responsible for determine where the result should be sent.
   *
   * @param xmlDoc   the XML Document on which the stylesheet should be applied
   * @param xsltURI  the URI of an XSL stylesheet
   * @param paramMap stylesheet parameter map (param name, param value)
   *
   * @exception java.io.IOException
   */
  public void applyStylesheet(final Document xmlDoc, final String xsltURI, final Map paramMap)
      throws IOException {
    final PrintWriter pw = getPrintWriter();

    applyStylesheet(xmlDoc, xsltURI, paramMap, DEFAULT_CONTENT_TYPE, pw);

    pw.close();
  }

  /**
   * <P>Enables to output result of a request to any output formats</P> <p/> <P>For that, applications need to write
   * their implementation of Formatted writer</P> <p/>
   *
   * @param fw a reference to the implementation repsonsible for writing result to correct formats
   *
   * @exception java.io.IOException
   */
  public void writeToFormattedWriter(FormattedWriter fw) throws IOException {
    fw.write(getBinaryStream());

  }

  /**
   * Applies a stylesheet & sets the contentType to application/vnd.ms-excel on thre results.  Use an html table in the
   * style sheet & excel will interpret each cell in the html table as an excel cell. <p/> If you want to specify the
   * file name that is used, add "extra path information" to your UCC invocation (i.e. action attribute of your form
   * /servletpath/MyServlet/desiredFileName.xls) and make sure your web.xml servlet mapping allows this via the
   * wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern> <p/>
   *
   * @param xmlDoc   the XML Document on which the stylesheet should be applied
   * @param xsltURI  the URI of an XSL stylesheet
   * @param paramMap stylesheet parameter map (param name, param value)
   *
   * @exception java.io.IOException
   */
  public void writeToExcel(final Document xmlDoc,
                           final String xsltURI,
                           final Map paramMap) throws IOException {
    applyStylesheet(xmlDoc, xsltURI, paramMap, EXCEL_CONTENT_TYPE, getPrintWriter());
  }

  /**
   * Applies a stylesheet & sets the contentType to application/vnd.ms-excel on thre results.  Use an html table in the
   * style sheet & excel will interpret each cell in the html table as an excel cell. <p/> If you want to specify the
   * file name that is used, add "extra path information" to your UCC invocation (i.e. action attribute of your form
   * /servletpath/MyServlet/desiredFileName.xls) and make sure your web.xml servlet mapping allows this via the
   * wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern> <p/>
   *
   * @param xmlDoc  the XML Document on which the stylesheet should be applied
   * @param xsltURI the URI of an XSL stylesheet
   *
   * @exception java.io.IOException
   */
  public void writeToExcel(final Document xmlDoc,
                           final String xsltURI) throws IOException {
    writeToExcel(xmlDoc, xsltURI, (Map) null);
  }

  /**
   * <P>Applies an XSL stylesheet to an XML document and sets the content type to msword. </P> If you want to specify
   * the file name that is used, add "extra path information" to your UCC invocation (i.e. action attribute of your form
   * /servletpath/MyServlet/desiredFileName.doc) and make sure your web.xml servlet mapping allows this via the
   * wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern> <p/>
   *
   * @param xmlDoc
   * @param xsltURI
   * @param paramMap
   *
   * @exception java.io.IOException
   */
  public void writeToWord(final Document xmlDoc,
                          final String xsltURI,
                          final Map paramMap) throws IOException {
    applyStylesheet(xmlDoc, xsltURI, paramMap, WORD_CONTENT_TYPE, getPrintWriter());
  }

  /**
   * <P>Applies an XSL stylesheet to an XML document and sets the content type to msword. </P> If you want to specify
   * the file name that is used, add "extra path information" to your UCC invocation (i.e. action attribute of your form
   * /servletpath/MyServlet/desiredFileName.doc) and make sure your web.xml servlet mapping allows this via the
   * wildcard(*) like this : <url-pattern>/servletpath/MyServlet/*</url-pattern> <p/>
   *
   * @param xmlDoc
   * @param xsltURI
   *
   * @exception java.io.IOException
   */
  public void writeToWord(final Document xmlDoc, final String xsltURI) throws IOException {
    writeToWord(xmlDoc, xsltURI, (Map) null);
  }

  /**
   * Applies an XSL stylesheet to an XML document. Implementing classes are responsible for determine where the result
   * should be sent.
   *
   * @param xmlDoc      the XML Document on which the stylesheet should be applied
   * @param xsltURI     the URI of an XSL stylesheet
   * @param paramMap    stylesheet parameter map (param name, param value)
   * @param contentType the content type of the response by default goes to browser "text/html"
   * @param writer      the PrintWriter to be used in the javax.xml.transform.Result object
   *
   * @exception java.io.IOException
   */
  private void applyStylesheet(final Document xmlDoc, String xsltURI,
                               final Map paramMap, final String contentType, final PrintWriter writer)
      throws IOException {
    m_response.setContentType(contentType);
    URL url = getURLFromPath(xsltURI);
    XSLTUtil.applyStylesheet(url, paramMap, xmlDoc, writer);
  }

  private URL getURLFromPath(String xsltURI) throws IOException {
    final String cstrSeparator = "/";
    if (!xsltURI.startsWith(cstrSeparator)) {
      xsltURI = cstrSeparator + xsltURI;
    }
    URL url = getResource(xsltURI);
    if (url == null) {
      url = getClass().getResource(xsltURI);
    }
    return url;
  }

  /**
   * Gets an InputStream for reading data from a given URL. The URL can be relative to the web app of the servlet.
   *
   * @param url the URL of the file to be read
   *
   * @return an InputStream for reading it.
   *
   * @exception java.io.IOException
   */
  public InputStream getInputStream(final String url) throws IOException {
    return m_config.getServletContext().getResourceAsStream(url);
  }

  /**
   * Gets the parameter names passed from the request.
   *
   * @return an Enumeration of the names of the available parameters.
   *
   * @exception java.io.IOException
   */
  public Enumeration getParameterNames() throws IOException {
    initMPR();

    return (m_boolIsMultiPartRequest ? m_MPR.getParameterNames() : m_request.getParameterNames());
  }

  /**
   * Gets a PrintWriter where results should be written.
   *
   * @return the PrintWriter.
   *
   * @exception java.io.IOException
   */
  public PrintWriter getPrintWriter() throws IOException {
    return m_response.getWriter();
  }

  /**
   * Gets a binary stream connected to the client.
   *
   * @return The stream.
   *
   * @exception java.io.IOException
   */
  public OutputStream getBinaryStream() throws IOException {
    return m_response.getOutputStream();
  }

  /**
   * Returns the value of the given request parameter.
   *
   * @param cstrParameterName The name of the request parameter.
   *
   * @return The value of the given request parameter.
   *
   * @exception java.io.IOException
   */
  public String getRequestParameterValue(final String cstrParameterName) throws IOException {
    initMPR();

    return (m_boolIsMultiPartRequest ? m_MPR.getParameter(cstrParameterName) :
        m_request.getParameter(cstrParameterName));
  }

  /**
   * Gets the values of a given request-scoped parameter.
   *
   * @param cstrParameterName The name of the request parameter.
   *
   * @return An array containing all parameter values.
   *
   * @exception java.io.IOException
   */
  public String[] getRequestParameterValues(final String cstrParameterName) throws IOException {
    initMPR();

    return (m_boolIsMultiPartRequest ? m_MPR.getParameterValues(cstrParameterName) :
        m_request.getParameterValues(cstrParameterName));
  }

  /**
   * Gets an Iterator over the ids associated with the session attributes.
   *
   * @return An Iterator over the ids.
   *
   * @exception java.io.IOException If an error occurs.
   */
  public Iterator getSessionParameterNames() throws IOException {
    final Enumeration e_attrNames = m_request.getSession().getAttributeNames();
    final ArrayList list = new ArrayList();
    while (e_attrNames.hasMoreElements()) {
      list.add(e_attrNames.nextElement());
    }
    return list.iterator();
  }

  /**
   * Gets the value of a given session-scoped parameter.
   *
   * @param cstrParameterName The name of the request parameter.
   *
   * @return the parameter value.
   */
  public Object getSessionParameter(final String cstrParameterName) {
    return m_request.getSession().getAttribute(cstrParameterName);
  }

  /**
   * Gets the init parameters from ServletContext and ServletConfig. The <code>HashMap</code> has the init parameter
   * name for the key values and the init parameter value for the value.  Each are stored as a <code>String</code>. If
   * both ServletContext and ServletConfig define parameters with the same name, the Map will contain the ServletConfig
   * value.
   *
   * @return The init parameters in a HashMap keyed by the init parameter name.
   */
  public HashMap getInitParameters() {
    final HashMap map = new HashMap();
    final ServletContext context = m_config.getServletContext();
    CollectionUtils.collect(new EnumerationIterator(context.getInitParameterNames()), new Transformer() {
      public Object transform(Object entity) {
        return map.put(entity, context.getInitParameter((String) entity));
      }
    });
    CollectionUtils.collect(new EnumerationIterator(m_config.getInitParameterNames()), new Transformer() {
      public Object transform(Object entity) {
        return map.put(entity, m_config.getInitParameter((String) entity));
      }
    });
    return map;
  }

  /**
   * Gets the context attributes.  The <code>HasMap</code> has the attribute name for the key values and the attribute
   * value for the value.  Each are stored as a <code>String</code>.
   *
   * @return The context attributes in a HashMap keyed by the attribute name.
   */
  public HashMap getContextAttributes() {
    final HashMap retVal = new HashMap();

    final Enumeration en = m_config.getServletContext().getAttributeNames();
    while (en.hasMoreElements()) {
      final String cstrName = (String) en.nextElement();
      final Object cobjValue = m_config.getServletContext().getAttribute(cstrName);

      retVal.put(cstrName, cobjValue);
    }

    return retVal;
  }

  /**
   * Outputs HTML describing an error.
   *
   * @param message the error message
   */
  public void reportError(final String message) {
    try {
      final PrintWriter writer = getPrintWriter();
      writer.println("<html>");
      writer.println("<body>");
      writer.println("<h1 style='color:red'>Error</h1>");
      writer.println("<h3>" + message + "</h3>");
      writer.println("</body>");
      writer.println("</html>");

      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public Object getContextAttribute(String name) {
    return m_config.getServletContext().getAttribute(name);
  }

  public void setContextAttribute(String name, Object object) {
    m_config.getServletContext().setAttribute(name, object);
  }

  public void removeContextAttribute(String name) {
    m_config.getServletContext().removeAttribute(name);
  }

  private String getStackTrace(final Throwable BadNews) {
    final ByteArrayOutputStream BAOS = new ByteArrayOutputStream();
    BadNews.printStackTrace(new PrintStream(BAOS));
    return BAOS.toString();
  }


  /**
   * Outputs HTML describing an error.
   *
   * @param t a Throwable describing the error.
   */
  public void reportError(final Throwable t) {
    try {
      final PrintWriter writer = getPrintWriter();
      writer.println("<html>");
      writer.println("<body>");
      writer.println("<h1 style='color:red'>Error</h1>");
      writer.println("<h3>" + t.toString() + "</h3>" + getStackTrace(t) + "<br/>");
      writer.println("</body>");
      writer.println("</html>");

      writer.close();

      throw new RuntimeException(">>>>" + getStackTrace(t) + "<<<<<");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }


  /**
   * Sets the value of a given session-scoped parameter.
   *
   * @param name  the name of the parameter
   * @param value the value of the parameter
   */
  public void setSessionParameter(final String name, final Object value) {
    final HttpSession session = m_request.getSession();
    session.setAttribute(name, value);
  }

  /**
   * Notifies the object that it is being bound to a session and identifies the session.
   *
   * @param event the event that identifies the session
   */
  public void valueBound(final HttpSessionBindingEvent event) {

  }

  /**
   * Notifies the object that it is being unbound from a session and identifies the session.
   *
   * @param event the event that identifies the session
   */
  public void valueUnbound(final HttpSessionBindingEvent event) {

  }

  /**
   * Removed the given session parameter from the session.
   *
   * @param cstrName The name of the session parameter.
   */
  public void removeSessionParameter(final String cstrName) {
    m_request.getSession().removeAttribute(cstrName);
  }

  /**
   * Clears all session parameters.
   */
  public void clearSession() {
    // vvvvvvvvv Original Implementation vvvvvvvvvvvvv
//    Enumeration enumerationeration = m_request.getSession().getAttributeNames();
//    while (enumerationeration.hasMoreElements())
//    {
//      removeSessionParameter((String) enumerationeration.nextElement());
//    }
    // ^^^^^^^^^ Original Implementation ^^^^^^^^^^^^^

    //ADCOX 9/13/2004
    // The above implementation throws a java.util.ConcurrentModificationException
    // often, while using Tomcat 4.1.18
    // The enumerationeration.nextElement() causes the exception.  Presumably, it's
    // a state problem since the list that this enumeration works on
    // is being deleted from.
    //
    // The following implementation creates a simple list from the
    // attributes names & clears each session entry from that separate
    // list

    final List list = new ArrayList();
    final Enumeration e_attrNames = m_request.getSession().getAttributeNames();
    while (e_attrNames.hasMoreElements()) {
      list.add(e_attrNames.nextElement());
    }

    final Iterator iter = list.iterator();
    while (iter.hasNext()) {
      removeSessionParameter((String) iter.next());
    }
  }

  /**
   * Invalidates the current session.
   */
  public void closeSession() {
    final HttpSession session = m_request.getSession();
    session.invalidate();
  }

  /**
   * Encodes the given URL.
   *
   * @param cstrURL The given URL to Encode.
   *
   * @return The Encoded URL.
   */
  public String encodeURL(final String cstrURL) {
    return m_response.encodeURL(cstrURL);
  }

  /**
   * Checks the server to see if the server has already authenticated the user.
   *
   * @return The name of the remote user.
   */
  public String serverAuthorizedUser() {
    String cstrRetVal;

    cstrRetVal = m_request.getRemoteUser();  // See if the web server has authenticated the user
    if ((cstrRetVal == null) || cstrRetVal.equals("")) {
      cstrRetVal = getUserNameFromCookie();  // If not, see if we can get the userID from the client's cookie

      if ((cstrRetVal == null) || cstrRetVal.equals(
          "")) {  // If still no luck, see if the userID was sent in from the client via the query string (set by using the java script to the ASP page).
        try {
          cstrRetVal = this.getRequestParameterValue("UID");
        } catch (IOException ioe) {
          Logger.log(new LoggableError(ioe));
        }
        if ((cstrRetVal != null) && !cstrRetVal.equals("")) {
          Logger.log(new LoggableInfo("User " + cstrRetVal + " authenticated from the client desktop."));
        }
      }
    } else {
      Logger.log(new LoggableInfo("User " + cstrRetVal + " authenticated from the server."));
    }

    return cstrRetVal;
  }

  /**
   * Redirects the response to the specified HTML file or JSP.  The servlet context path is prepended onto
   * cstrFileName.
   *
   * @param cstrFileName The name of the HTML file to display.
   *
   * @exception java.io.IOException
   */
  public void displayHTML_File(final String cstrFileName) throws IOException {
    if ((cstrFileName != null) && (!cstrFileName.trim().equals(""))) {
      final StringBuffer strFileName = new StringBuffer(m_request.getContextPath()).append("/").append(cstrFileName);
      m_response.sendRedirect(strFileName.toString());
    }
  }

  public void addForwardFeature(ForwardFeature feature) {
    this.forwardFeature = feature;
  }

  /**
   * <P>This method includes the request from this servlet to the response of a servlet in another context.  This
   * method allows a resource in one context to execute a UCC in another context and include its response as part of
   * its response.</P> <P>An example use of this would be if you have a JSP in one context wanting to include the
   * ressponse from a UCC in another context.  There would then be a JSP in the calling context and a UCC in the
   * called context.  The calling context needs to have its crossContext attribute in its context.xml file set to
   * "true".  Somewhere on the JSP would be line like <c:import url="/calledContextUCCUrl" context=/calledContext" />.
   *  At the bottom of the UCC method, instead of doing a forward it would do a helper.include passing in the JSP name
   * to send back. <P>Just like the helper.forward method, this method acts entirely within the server and the client
   * cannot tell the include occured.</P>
   *
   * @param cstrTo The given URL to include in the cross context response object.
   *
   * @exception java.io.IOException - If there was an error processing the RequestDispatcher.include.
   */
  public void include(final String cstrTo) throws IOException {

    final RequestDispatcher dispatcher = m_request.getSession().getServletContext().getRequestDispatcher(cstrTo);
    try {
      dispatcher.include(m_request, m_response);
    } catch (ServletException e) {
      throw new IOException(e.toString());
    }
  }

  /**
   * <P>This method forwards the request from this servlet to another resource on the server.  THis method allows one
   * UCC to do preliminary processing of a request and another resource (URL) to generate the response.</P> <P>Unlike
   * {@link #redirect(String)}, this method acts entirely within the server and the client cannot tell the
   * forward occured.</P>
   *
   * @param cstrTo The given URL to forward the response object to.
   *
   * @exception java.io.IOException - If there was an error accessing the resource <code>cstrTo</code>.
   * @see #redirect(String)
   */
  public void forward(final String cstrTo) throws IOException {

    String uri = forwardFeature.processForwardURI(m_request, m_response, m_config, cstrTo);
    if (uri == null) uri = cstrTo;

    final RequestDispatcher dispatcher = m_request.getRequestDispatcher(uri);
    try {
      dispatcher.forward(m_request, m_response);
    } catch (ServletException e) {
      Logger.log(new LoggableError(
          e)); // ideally we would wrap this, but I don't want to change the behavior or signature of the method
      throw new IOException(e.toString());
    }
  }

  /**
   * <P>This method redirects the response to the specified location, automatically setting the status code and
   * <code>Location</code> header. It also writes a short response body that contains a hyperlink to the new location
   * (to support browsers without redirect capabilities).</P> <p/> <P>This method sends a temporary redirect response to
   * the client using the specified redirect location <code>cstrTo</code>. This method can accept relative URLs; the
   * servlet container must convert the relative URL to an absolute URL before sending the response to the client. If
   * the location is relative without a leading '/' the container interprets it as relative to the current request URI.
   * If the location is relative with a leading '/' the container interprets it as relative to the servlet container
   * root.</P> <p/> <P>If the response has already been committed, this method throws an <code>IOException</code>. After
   * using this method, the response should be considered to be committed and should not be written to.</P>
   *
   * @param cstrTo - The URL of the resource being redirected to.
   *
   * @exception java.io.IOException - If there was an error accessing the resource <code>cstrTo</code>.
   * @see #forward(String)
   */
  public void redirect(final String cstrTo) throws IOException {
    m_response.sendRedirect(cstrTo);
  }

  /**
   * <P>This method returns an ArrayList containing the complete path & filenames of the files uploaded to the
   * servlet.</P> <P>HTML to initiate the file upload looks like this:</P> <P> <PRE>&lt;FORM
   * ACTION="Your_Servlet_Action" ENCTYPE="multipart/form-data" METHOD="POST"&gt; Enter file to upload:&lt;INPUT
   * TYPE=FILE NAME=file&gt; &lt;INOUT TYPE=SUBMIT&gt; </P></PRE>
   */
  public ArrayList getClientFiles() throws IOException {
    final ArrayList RetVal = new ArrayList();
    String cstrFileName;
    initMPR();

    if (m_boolIsMultiPartRequest) {
      final Iterator files = m_MPR.getFileNames();
      final String cstrSeparator = (
          ((getSaveFileDir().length() == 0) || (getSaveFileDir().endsWith(File.separator))) ? "" : File.separator);

      while (files.hasNext()) {
        cstrFileName = m_MPR.getFilesystemName((String) files.next());
        if (cstrFileName != null) {
          cstrFileName = new StringBuffer(getSaveFileDir()).append(cstrSeparator).append(cstrFileName).toString();
          RetVal.add(cstrFileName);
        }
      }
    }

//      for (int i=0; i<RetVal.size(); i++) {
//         System.err.println((String)RetVal.get(i));
//      }

    return RetVal;
  }

  /**
   * Gets an Iterator over the ids associated with the request attributes.
   *
   * @return An Iterator over the ids.
   *
   * @exception java.io.IOException If an error occurs.
   */
  public Iterator getRequestAttributeNames() throws IOException {
    final Enumeration e_attrNames = m_request.getAttributeNames();
    final ArrayList list = new ArrayList();
    while (e_attrNames.hasMoreElements()) {
      list.add(e_attrNames.nextElement());
    }
    return list.iterator();
  }

  /**
   * Returns the value of the given request parameter.
   *
   * @param cstrParameterName The name of the request parameter.
   *
   * @return The value of the given request parameter.
   */
  public Object getRequestAttributeValue(final String cstrParameterName) {
    return m_request.getAttribute(cstrParameterName);
  }

  /**
   * Sets the value of a given request-scoped attribute.
   *
   * @param name  the name of the parameter
   * @param value the value of the parameter
   */
  public void setRequestAttributeValue(final String name, final Object value) {
    m_request.setAttribute(name, value);
  }

  /**
   * Removes the attribute associated with given name.
   *
   * @param attributeName The name associated with the attribute to be removed.
   */
  public void removeRequestAttribute(final String attributeName) {
    m_request.removeAttribute(attributeName);
  }

  /**
   * Returns the full path to the currect directory.
   *
   * @return String - a String specifying current directory, or null if the translation cannot be performed.
   */
  public String getCurrentDirectory() {
    return m_config.getServletContext().getRealPath("");
  }

  /**
   * Returns a name of a temporary directory where short-lived working files can be stored.  Each context receives a
   * different temporary directory. The folder returned by this method may have limited space available.
   *
   * @return The directory.
   *
   * @see #getScratchFolder()
   */
  public File getTempDirectory() {
    return (File) m_config.getServletContext().getAttribute("javax.servlet.context.tempdir");
  }

  /**
   * Returns a String containing the real path for a given virtual path. For example, the path "/index.html" returns the
   * absolute file path on the server's filesystem would be served by a request for
   * "http://host/contextPath/index.html", where contextPath is the context path of this ServletContext.. <p/> The real
   * path returned will be in a form appropriate to the computer and operating system on which the servlet container is
   * running, including the proper path separators. This method returns null if the servlet container cannot translate
   * the virtual path to a real path for any reason (such as when the content is being made available from a .war
   * archive).
   *
   * @param path - A String specifying a virtual path
   *
   * @return String - a String specifying the real path, or null if the translation cannot be performed.
   */
  public String getRealPath(final String path) {
    return m_config.getServletContext().getRealPath(path.trim());
  }

  /**
   * Sets the (absolute) path to the import file directory.  Variation of setImportFileDir(path, boolean).  The default
   * location if this method is not called is the scratch directory.
   *
   * @param cstrDirectory - The absolute path to set the import file directory to.
   *
   * @return String The previous directory.
   *
   * @exception java.io.IOException If the target folder is read-only or does not exist.
   * @see UCCServletHelper#setImportFileDir(String,boolean)
   */
  public String setImportFileDir(final String cstrDirectory) throws IOException {
    return setImportFileDir(cstrDirectory, true);
  }

  /**
   * Sets the path to the import file directory.  Variation of setImportFileDir(path) with added flexibility to specify
   * if the passed-in path is a relative path or an absolute path.  The default location if this method is not called is
   * the scratch directory.
   *
   * @param cstrDirectory The directory. (Do not append a trailing / or \\).
   * @param boolRelative  <code>false</code> if the supplied directory path is an absolute path, <code>true</code> if it
   *                      is relative to the current location.  (i.e. Use setImportFileDir(path, false) to specify an
   *                      absolute path).
   *
   * @return String The previous directory.
   *
   * @exception java.io.IOException If the target folder is read-only or does not exist.
   * @see UCCServletHelper#setImportFileDir(String)
   */
  public String setImportFileDir(final String cstrDirectory, final boolean boolRelative) throws IOException {
    throwExceptionIfItsTooLateForThis();

    return setSaveFileDir(cstrDirectory);

  }

  private void throwExceptionIfItsTooLateForThis() throws IOException {
    // if the MultipartRequest has already been created, then the files have already been saved to the
    // default directory & it is too late to try to set it.
    if (m_MPR != null) {
      throw new IOException("Cannot setFileImportFileDir after other calls to helper have used the default setting.");
    }
  }

  /**
   * Overrides the default maximum file upload size.  This is the total size of all files to be uploaded.
   *
   * @param iMaxSize - The maximum allowed upload size in Bytes.
   *
   * @return int - The previous size.
   */
  public int setMaxImportFileSize(final int iMaxSize) {
    final int iRetVal = m_iMaxRequestSize;

    m_iMaxRequestSize = iMaxSize;
    return iRetVal;
  }

  /**
   * Returns the session id.
   *
   * @return The session id.
   */
  public String name() {
    return m_request.getSession().getId();
  }

  /**
   * Returns the servlet request header.
   *
   * @param name The name of the header.
   *
   * @return a String representing the javax.servlet.ServletRequest header request
   */
  public String getHeader(final String name) {
    return helperCommon.getHeader(name);
  }

  /**
   * Returns the names of the session headers.
   *
   * @return String[] of request header names
   */
  public String[] getHeaderNames() {
    return helperCommon.getHeaderNames();
  }

  /**
   * set the servlet response header.
   *
   * @param name  The name of the header.
   * @param value The value of the header.
   */
  public void setHeader(final String name, final String value) {
    m_response.setHeader(name, value);
  }

  /**
   * Writes the XML document to the Browser.
   *
   * @param doc The document need to display in the browser.
   */
  public void writeXMLDocument(final Document doc) {
    Logger.traceEntry();

    try {
      final PrintWriter pw = getPrintWriter();
      serializer.setOutputCharStream(pw);
      serializer.serialize(doc);
      pw.close();
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
    }

    Logger.traceExit();
  }

  /**
   * Writes the XML document to the Browser.
   *
   * @param doc The document need to display in the browser.
   */
  public void writeXMLDocument(final Document doc, String encoding) {
    Logger.traceEntry();

    try {
      OutputFormat format = new OutputFormat(Method.XML, encoding, true);
      serializer.setOutputFormat(format);
      serializer.setOutputByteStream(m_response.getOutputStream());
      serializer.serialize(doc);
    } catch (IOException e) {
      Logger.log(new LoggableError(e));
    }

    Logger.traceExit();
  }

  /**
   * Adds the expires header to expire a page immediately; also adds a cache-control header that will make a page
   * generated in response to a POST request inaccessible to the Back button in IE 5.5.  Note that for this to work,
   * expire() must be called before any output to the servlet response has been committed (basically, flushed from the
   * buffer).
   */
  public void expire() {
    Logger.traceEntry();

    m_response.addIntHeader("Expires", 0);
    m_response.addHeader("Pragma", "no-cache");
    m_response.addHeader("Cache-control", "no-cache,must-revalidate");

    Logger.traceExit();
  }

  /**
   * Returns the URL that was requested by the client.
   *
   * @return the requested URL
   */
  public String requestedURL() {
    Logger.traceEntry();

    return Logger.traceExit(helperCommon.requestedURL());
  }

  /**
   * Returns the name (web login ID) of the user making the request (gleaned from the USER cookie) or null if the user
   * is not defined.
   *
   * @return the name (web login ID) of the user making the request or null if the user is not defined
   */
  private String getUserNameFromCookie() {
    Logger.traceEntry();

    String cstrUserName = null;

    final javax.servlet.http.Cookie[] c = m_request.getCookies();

    if (c == null || (c.length == 0)) {
      Logger.log(new LoggableInfo("getUserNameFromCookie: null or empty cookie array"));
      return (cstrUserName);
    }

    /*  Walk through list of cookies to find the USER cookie (there is no direct access)  */
    int i;
    boolean boolFoundUser = false;
    for (i = 0; i < c.length && (!boolFoundUser); i++) {
      if (c[i].getName().equals("USER")) {
        boolFoundUser = true;
        cstrUserName = c[i].getValue();
      }
    }

    return Logger.traceExit(cstrUserName);
  }

//   private OutputStream getCompressedOutputStream () throws IOException
//   {
//      OutputStream out = null;
//
//      /*  Select the appropriate content encoding based on the client's Accept-Encoding header. Choose GZIP if the
//      header includes "gzip". Choose ZIP if the header includes "compress".  Choose no compression otherwise. Make
//      sure the Content-Encoding uses the "x-" prefix if and only if the Accept-Encoding does.  */
//      String encodings = m_request.getHeader("Accept-Encoding");
//      if ((encodings != null) && (encodings.indexOf("gzip") != -1)) {
//         if (encodings.indexOf("x-gzip") != -1) {
//            m_response.setHeader("Content-Encoding", "x-gzip");
//            Logger.log(new LoggableInfo("Using x-gzip compression"));
//         } else {
//            m_response.setHeader("Content-Encoding", "gzip");
//            Logger.log(new LoggableInfo("Using gzip compression"));
//         }
//
//         out = new GZIPOutputStream(m_response.getOutputStream());
//
//      } else if ((encodings != null) && (encodings.indexOf("compress") != -1)) {
//         if (encodings.indexOf("x-compress") != -1) {
//            m_response.setHeader("Content-Encoding", "x-compress");
//            Logger.log(new LoggableInfo("Using x-compress compression"));
//         } else {
//            m_response.setHeader("Content-Encoding", "compress");
//            Logger.log(new LoggableInfo("Using compress compression"));
//         }
//
//         out = new ZipOutputStream(m_response.getOutputStream());
//         ((ZipOutputStream)out).putNextEntry(new ZipEntry("dummy name"));
//
//      } else {
//         out = m_response.getOutputStream();
//         Logger.log(new LoggableInfo("No compression"));
//      }
//
//      m_response.setHeader("Vary", "Accept-Encoding");
//
//      return out;
//   }

  /**
   * Get a resource from the ServletContext.
   *
   * @param uri relative location of a resource.
   *
   * @return The URL of the desired resource.
   *
   * @exception java.io.IOException if the resource could not be located.
   */
  public URL getResource(final String uri) throws IOException {
    Logger.traceEntry();

    return (URL) Logger.traceExit(m_config.getServletContext().getResource(uri));
  }

  /**
   * Create a uniquely named scratch folder for this session.  The folder returned by this call will typically have have
   * more disk space available than what is available from the call to getTempDirectory().
   *
   * @return Name of the scratch folder
   *
   * @see #getTempDirectory()
   */
  public String getScratchFolder() {
    Logger.traceEntry();

    if (m_cstrScratchFolder == null)
    {
      final String sSessionID = name();
      File tempDir;

      final String cstrJavaIoTempDir = System.getProperty("java.io.tmpdir");
      if (cstrJavaIoTempDir != null) {
        tempDir = new File(cstrJavaIoTempDir);
        if (!tempDir.exists()) {
          tempDir = getTempDirectory();
        }
      } else {
        tempDir = getTempDirectory();
        if (tempDir == null) {
          tempDir = new File(".");
        }
      }
      final File webappsTempDir = new File(tempDir, "webapps");
      final File webappsTempTempDir = new File(webappsTempDir, "tmp");
      final File sessionTempDir = new File(webappsTempTempDir, sSessionID);

      if (!sessionTempDir.exists()) {
        sessionTempDir.mkdirs();
      }

      m_cstrScratchFolder = sessionTempDir.getAbsolutePath();
    }

    return Logger.traceExit(m_cstrScratchFolder);
  }

  /**
   * Removes the scratch folder created for this session.
   */
  public void deleteScratchFolder() {
    Logger.traceEntry();

    deleteScratchFolder(getScratchFolder());

    Logger.traceExit();
  }

  public FormRequestData getFormRequestData() throws BadFormDataException {
    FormDataFactory factory = new FormDataFactory(this);
    return factory.createFormData();
  }

  private void deleteScratchFolder(final String sFolderName) {
    Logger.traceEntry();

    final File fScratchFolder = new File(sFolderName);
    FileUtil.deleteAllFilesFromFolder(fScratchFolder);
    fScratchFolder.delete();

    Logger.traceExit();
  }

  public boolean isSystemSecurityEnabled() {
    return systemSecurityEnabled;
  }

  public String getAuthenticatedUserID() {
    String userID = null;
    if (isSystemSecurityEnabled()) {
      userID = systemSecurityProxy.getUserID();
    }
    return userID;
  }

  public String getAuthenticatedUserFullName() {
    String fullName = null;
    if (isSystemSecurityEnabled()) {
      fullName = systemSecurityProxy.getFullName();
    }
    return fullName;
  }

  public int getFailedLogonAttempts() {
    int failedLogonAttempts = 0;
    if (isSystemSecurityEnabled()) {
      failedLogonAttempts = systemSecurityProxy.getFailedLogonAttempts();
    }
    return failedLogonAttempts;
  }

  public Date getLastLogon() {
    Date lastLogon = null;
    if (isSystemSecurityEnabled()) {
      lastLogon = systemSecurityProxy.getLastLogon();
    }
    return lastLogon;
  }

  public String getAuthenticatedUserDomain() {
    String value = null;
    try {
      GSSName gssName = systemSecurityProxy.getDelegCredential().getName();
      String[] temp = gssName.toString().split(AT_SIGN);
      if (temp.length > 1) {
        value = temp[1];
      }
    } catch (GSSException IGNORE_RETURN_NULL) {
    }
    return value;
  }

  public boolean isUserInRole(String role) {
    return m_request.isUserInRole(role);
  }

  //this is a deprecated method to be dumped in couple of weeks - Srinivas Gunturu
  public javax.servlet.http.Cookie[] getCookies() {
    return m_request.getCookies();
  }

  public Cookie[] getClientCookies() {
    return helperCommon.getClientCookies();
  }

  public Cookie[] getCookies(String dummyValue) {
    return getClientCookies();
  }

  public void addCookie(Cookie cookie) {
    helperCommon.addCookie(cookie);
  }

  public SystemSecurityProxy getSystemSecurityProxy() {
    return systemSecurityProxy;
  }

  public void setMaxInactiveInterval(int numberOfSeconds) {
    HttpSession session = m_request.getSession();
    session.setMaxInactiveInterval(numberOfSeconds);
  }

  public String getServletName() {
    return m_config.getServletName();
  }

  public String getPathInfo() {
    return m_request.getPathInfo();
  }

  public String getRequestURI() {
    return m_request.getRequestURI();
  }

  public String getContextPath() {
    return m_request.getContextPath();
  }
}