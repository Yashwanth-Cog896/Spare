package com.monsanto.AbstractLogging;


/**
 * This class encapsulates a debug message.
 *
 * @author CPWALT
 * @version $Id: DebugLogEvent.java,v 1.12 2007/09/12 22:31:42 ardharn Exp $
 */
 public class DebugLogEvent extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrMessage The text of the message.
    */
   public DebugLogEvent(String cstrMessage)
   {
       super(cstrMessage);
   }

	public String getLoggerName() {
		return Logger.DEBUG_LOG;
	}
}
