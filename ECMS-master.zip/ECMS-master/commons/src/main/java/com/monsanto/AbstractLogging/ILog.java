/*
 ILog was created on Jul 2, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;


/**
 * An interface for some logs.  This interface is only for use as a "name".
 *
 * @author CPWALT
 * @version $Id: ILog.java,v 1.10 2007/09/12 22:31:42 ardharn Exp $
 */
public interface ILog
{
}
