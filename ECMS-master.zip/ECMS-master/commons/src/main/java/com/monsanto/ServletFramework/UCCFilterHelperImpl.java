package com.monsanto.ServletFramework;

import com.monsanto.AbstractLogging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;

/**
 * Created by IntelliJ IDEA.
 * User: sdshan1
 * Date: Sep 16, 2005
 * Time: 9:16:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class UCCFilterHelperImpl {
  private UCCHelperCommon helperCommon;

  public UCCFilterHelperImpl(HttpServletRequest request, HttpServletResponse response) {
    this.helperCommon = new UCCHelperCommon(request, response);
  }

  /**
   * deprecated
   */
  public javax.servlet.http.Cookie[] getCookies() {
    return helperCommon.getCookies();
  }

  public Cookie[] getCookies(String dummyValue) {
    return helperCommon.getClientCookies();
  }

  public void addCookie(Cookie cookie) {
    helperCommon.addCookie(cookie);
  }

  public String requestedURL() {
    Logger.traceEntry();

    return Logger.traceExit(helperCommon.requestedURL());
  }

  public String getHeader(final String name) {
    return helperCommon.getHeader(name);
  }

  public String[] getHeaderNames() {
    return helperCommon.getHeaderNames();
  }

  public Enumeration getParameterNames() throws java.io.IOException {
    return helperCommon.getParameterNames();
  }

  public String getRequestParameterValue(final String cstrParameterName) throws java.io.IOException {
    return helperCommon.getRequestParameterValue(cstrParameterName);
  }

  public String[] getRequestParameterValues(final String cstrParameterName) throws java.io.IOException {
    return helperCommon.getRequestParameterValues(cstrParameterName);

  }


}
