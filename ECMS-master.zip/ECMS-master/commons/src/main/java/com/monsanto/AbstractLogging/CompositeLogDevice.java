//Source file: C:\\Development\\Mirage\\Source\\java\\com\\monsanto\\AbstractLogging\\CompositeLogDevice.java

/*
 CompositeLogDevice was created on Jun 3, 2003 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.AbstractLogging;

import java.util.ArrayList;

/**
 * <p>Title: CompositeLogDevice</p>
 * <p>Description:  This <code>{@link LogDevice}</code>
 * holds other log devices.  Logging to a CompositeLogDevice will log to all of the
 * child log devices also.  A CompositeLogDevice can also contain other
 * CompositeLogDevices as well as LogDevices.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author CPWALT
 * @version $Id: CompositeLogDevice.java,v 1.12 2007/09/12 22:31:42 ardharn Exp $
 */
public class CompositeLogDevice implements LogDevice
{
   private ArrayList m_Members;

   /**
    * Constructs a device with no composites.  See
    * {@link com.monsanto.AbstractLogging.CompositeLogDevice#add(LogDevice)}
    */
   public CompositeLogDevice()
   {
      m_Members = new ArrayList();
   }

   /**
    * Attaches the <code>LogDevice</code> to the composite.
    * @param ld The <code>LogDevice</code> to add to the composite.
    */
   public void add(LogDevice ld)
   {
      m_Members.add(ld);
   }

   /**
    * Overrides the parent class method.  All contained LogDevices are attached to the log.
    * @param log The log to attach these output devices to.
    */
   public int attach (ILog log)
   {
      int iRetVal = 0;

      for (int i=0; i<m_Members.size(); i++) {
         iRetVal += ((LogDevice)m_Members.get(i)).attach(log);
      }

      return iRetVal;
   }

   /**
    * Returns the output strategies of LogDevice.
    *
    * @return A String array with each element of the array containing the name
    *         of an output strategy.  For example: Console, MidnightRollingFile.
    */
   public ArrayList logDeviceTypes()
   {
      ArrayList RetVal = new ArrayList();

      for (int i=0; i<m_Members.size(); i++) {
         RetVal.addAll(((LogDevice) m_Members.get(i)).logDeviceTypes());
      }

      return RetVal;
   }

   /**
    * Returns the output media of LogDevice.
    *
    * @return A String array with each element of the array containing the name
    *         of an output location.  For example: Console, c:\\Logs\MyApp.log.
    */
   public ArrayList logDeviceLocations()
   {
      ArrayList RetVal = new ArrayList();

      for (int i = 0; i < m_Members.size(); i++) {
         RetVal.addAll(((LogDevice) m_Members.get(i)).logDeviceLocations());
      }

      return RetVal;
   }

   public void close()
   {
      for (int i = 0; i < m_Members.size(); i++) {
         ((LogDevice)m_Members.get(i)).close();
      }
   }
}
