package com.monsanto.ServletFramework;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Base interface for all application specific outputs. 
 * 
 * Used by the UccHelper in order to allow application to customize their outputs to any format 
 * / technology they need to.
 * 
 *  
 */
public interface FormattedWriter 
{
    /**
     * Perform necessary tasks to write the result of a user request
     * to application specific formats. 
     * 
     * @param os outpustream to which request result will be displayed
     */
    void write(OutputStream os) throws IOException;

}
