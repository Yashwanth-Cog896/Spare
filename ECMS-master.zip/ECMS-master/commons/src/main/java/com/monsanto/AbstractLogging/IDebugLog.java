package com.monsanto.AbstractLogging;


/**
 * Interface for a debug log.
 *
 * @author CPWALT
 * @version $Id: IDebugLog.java,v 1.13 2007/09/12 22:31:42 ardharn Exp $
 */
public interface IDebugLog extends LogInfo
{
   /**
    * Logs the message to the debug Log.
    *
    * @param cstrMessage The message to log.
    */
   public void log(String cstrMessage);

   /**
    * Removes all {@link com.monsanto.AbstractLogging.LogDevice} objects from
    * the debug log.
    */
   public void removeLogDevices();
}
