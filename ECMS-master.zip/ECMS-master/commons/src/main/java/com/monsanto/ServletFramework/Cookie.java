/*
 Cookie was created on Apr 29, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.ServletFramework;

import java.util.Date;

/**
 * Filename:    $RCSfile: Cookie.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ardharn $    	 On:	$Date: 2007-09-12 22:56:15 $
 *
 * @author SSGUNT
 * @version $Revision: 1.8 $
 */
public class Cookie {
  private String name = null;
  private String value = null;
  private String domain = null;
  private String path = null;
  private Date expiration = null;

  public Cookie(String name, String value) {
    this.name = name;
    this.value = value;
  }

  public String getName() {
    return name;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  public String getDomain() {
    return domain;
  }

  public void setDomain(String domain) {
    this.domain = domain;
  }

  public String getPath() {
    return path;
  }

  public void setPath(String path) {
    this.path = path;
  }

  public Date getExpiration() {
    return expiration;
  }

  public void setExpiration(Date expiration) {
    this.expiration = expiration;
  }
}
/*
* Revision Log
* $Log: not supported by cvs2svn $
* Revision 1.6  2007/08/22 01:30:15  ardharn
* restored
*
* Revision 1.4  2007/05/31 23:38:37  mebrei1
* no message
*
* Revision 1.3  2007/04/11 19:37:19  SSPATI1
* renamed jsp/shared to jsp/common
*
* Revision 1.2  2007/04/04 18:50:06  wsmcqu
* GenesisNortherns MEGA changes
*
* Revision 1.1  2006/05/08 13:41:12  ssgunt
* no message
*
*/