//Source file: C:\\Development\\Mirage\\Source\\java\\com\\monsanto\\AbstractLogging\\AuditInfo.java

package com.monsanto.AbstractLogging;


/**
 * This class encapsulates an audit message.
 * @author CPWALT
 * @version $Id: AuditInfo.java,v 1.11 2007/09/12 22:31:42 ardharn Exp $
 */
public class AuditInfo extends LoggableEvent
{
	 /**
    * Constructor.
    * @param cstrText The text of the message.
    */
   public AuditInfo(String cstrText)
   {
      super(cstrText);
   }

	public String getLoggerName(){
		return Logger.AUDIT_LOG;
	}
}
