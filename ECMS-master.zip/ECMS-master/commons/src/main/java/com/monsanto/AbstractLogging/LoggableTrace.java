package com.monsanto.AbstractLogging;

/**
 * A message that needs written to the InfoLog (if one has been registered).
 *
 * @author CPWALT
 * @version $Id: LoggableTrace.java,v 1.1 2007/09/27 20:46:20 mebrei1 Exp $
 */
public class LoggableTrace extends LoggableEvent
{
   /**
    * Constructor.
    *
    * @param cstrText The message to log.
    */
   public LoggableTrace(String cstrText)
   {
      super(cstrText);
   }

   /**
    * Constructor.
    *
    * @param throwable The exception to log.
    */
   public LoggableTrace(Throwable throwable)
   {
      super(throwable);
   }

    public String getLoggerName() {
        return Logger.TRACE_LOG;
    }
}
