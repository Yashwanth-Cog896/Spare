package com.monsanto.ServletFramework;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.LoggablePerformanceMetric;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.servletsecurity.ServletSystemSecurityProxy;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;


/**
 * This is the single servlet that manages all browser requests for the web application. It dispatches requests to
 * objects of classes that implement UseCaseController.
 */
public class GatewayServlet extends HttpServlet
{
   /*  Default values for the servlet properties.  */
   public static final String SYSTEM_SECURITY_PROXY = "system.security.proxy";
   private Integer m_iTimeout;  // The number of minutes that must ellapse before the session will expire.

   /**
    * Default constructor.  It sets the default timeout for the session.
    */
   protected GatewayServlet()
   {
      Logger.traceEntry();

      Logger.traceExit();
   }


   /**
    * This constructor allows the derived class to alter the default behavior of the servlet.
    *
    * @param iTimeout The number of seconds that, once ellapsed, will cause the servlet session to expire.
    */
   protected GatewayServlet(int iTimeout)
   {
      Logger.traceEntry();
      m_iTimeout = new Integer(iTimeout);
      Logger.log(new LoggableInfo("Setting Timeout value to " +
                                  m_iTimeout.intValue()));

      Logger.traceExit();
   }

   /**
    * @param request  The request object sent from the servlet server.
    * @param response The response object that must be filled with the information to be sent back to the user.
    *
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      Logger.traceEntry();

      /*  Insure that sessions are inactivated after the desired period of inactivity.  */
      HttpSession session = request.getSession();
      if (null != m_iTimeout) {
         session.setMaxInactiveInterval(m_iTimeout.intValue());
      }
      UCCHelper helper = createHelper(request, response);
      String controllerName = getInitParameter("controller");
      if (controllerName != null) {
         Date before = new Date();
         UCCManager.runController(controllerName, helper);
         Date after = new Date();
         String message = buildMessageString(controllerName, after, before);
         Logger.log(new LoggablePerformanceMetric(message));
      } else {
         Logger.log(
               new LoggableError("web.xml error: Controller parameter not found for URL " + helper.requestedURL()));
         helper.reportError("\"controller\" parameter not found for use-case lookup.  Contact technical support.");
      }

      Logger.traceExit();
   }

   private String buildMessageString(String controllerName, Date after, Date before)
   {
      return new StringBuffer("Controller '").append(controllerName).append("' ran in ").append((double)(after.getTime() - before.getTime())/1000.0).append(" seconds.").toString();
   }

   protected UCCHelper createHelper(HttpServletRequest request, HttpServletResponse response)
   {
      Logger.traceEntry();

      UCCHelper helper = createNonSecureHelper(request, response);

      return (UCCHelper) Logger.traceExit(helper);
   }

	protected UCCServletHelper createNonSecureHelper(HttpServletRequest request, HttpServletResponse response) {
		return new UCCServletHelper(getServletConfig(), request, response);
	}

	protected UCCServletHelper createSecureHelper(HttpServletRequest request, HttpServletResponse response, ServletSystemSecurityProxy proxy) {
		return new UCCServletHelper(getServletConfig(), request, response, true, proxy);
	}


	/**
    * @param request  The request object sent from the servlet server.
    * @param response The response object that must be filled with the information to be sent back to the user.
    *
    * @throws java.io.IOException
    * @throws javax.servlet.ServletException
    */
   public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
   {
      Logger.traceEntry();

      doGet(request, response);

      Logger.traceExit();
   }
}







