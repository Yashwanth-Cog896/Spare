package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tcc.inventorycommon.service.InventoryProductNameLinkageService;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageRequest;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageResponse;
import com.monsanto.tcc.inventorycommon.transferobject.PreCommercialLinkageResponse;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.KeywordDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageAuditDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageSeedProductDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import org.apache.commons.lang.StringUtils;


import java.text.SimpleDateFormat;
import java.util.*;

public class ProductStageEditBusinessImpl implements ProductStageEditBusiness {
    private LexiconProductStageDao lexiconProductStageDao;
    private LexiconBrandDao lexiconBrandDao;
    private LexiconCountryDao lexiconCountryDao;
    private LexiconStageDao lexiconStageDao;
    private CommercialTraitStackDao commercialTraitStackDao;
    private MirageSeedProductWriter mirageSeedProductWriter;
    private MidasProductNameWriter midasProductNameWriter;
    private ExceptionCodeWriter exceptionCodeWriter;
    private GeneticMaterialWriter geneticMaterialWriter;
    private MapProductMirageWriter mapProductMirageWriter;
    private FbsCommonProductNameXrefWriter fbsCommonProductNameXrefWriter;
// These steps were taken from lexicon to match in this service.    
//          targetSPN.setExceptionCode(writeExceptionCode(stageAttributes, conn.getLexiconConnection()));
//      targetSPN.setLexProdStage(writeLexiconStage(stageAttributes, conn.getLexiconConnection()));
//      targetSPN.setMirageProduct(writeMirageProduct(stageAttributes, conn.getMirageConnection()));
//      targetSPN.setMidasComlPN(writeMidasComlPN(stageAttributes, conn.getMidasConnection()));
////      Midas Manf Removal - Uncomment if/when we start flowing Manf names to Midas again
////      targetSPN.setMidasManfPN(writeMidasManfPN(stageAttributes.getCountry(), conn.getMidasConnection()));
//      writeMidasGlobalPCName(stageAttributes.getCountry(), conn.getMidasConnection());
//      GeneticMaterial geneticMaterial = writeMirageGeneticMaterial(conn.getMidasConnection());
//      targetSPN.setYieldMartProduct(writeMapProductMirage(geneticMaterial, conn.getYieldMartConnection()));
//      targetSPN.setNameXref(writeNameXref(conn.getFBSCommonConnection()));

    public void editProductStages(Product  product, LexiconProductEntity lexiconProduct ) {
         Map<String, LexiconProductStageEntity> stageMap = new HashMap<String, LexiconProductStageEntity>();
         for(LexiconProductStageEntity lexiconProductStage: lexiconProduct.getLexiconProductStages()){
             if(!lexiconProductStage.isLogicalDelete()){
                 stageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
             }
         }
         for(ProductStage productStage: product.getProductStages()){

             LexiconProductStageEntity lexiconProductStage = getLexiconProductStage(lexiconProduct, stageMap, productStage);
             exceptionCodeWriter.writeExceptionCode(product,productStage,lexiconProductStage);
             
             writeLexiconProductStage(lexiconProduct, productStage, lexiconProductStage);
             MirageSeedProductEntity mirageSeedProduct = mirageSeedProductWriter.writeMirageSeedProduct( lexiconProduct, productStage, lexiconProductStage);

             MidasProductNameEntity midasProductName = midasProductNameWriter.writeMidasProductName(lexiconProduct, productStage, lexiconProductStage);
             midasProductNameWriter.writeMidasGlobalPCName(lexiconProduct, productStage);
             GeneticMaterialEntity mirageGeneticMaterial = geneticMaterialWriter.writeMirageGeneticMaterial(lexiconProduct);
             mapProductMirageWriter.writeMapProductMirage(lexiconProduct, mirageSeedProduct, mirageGeneticMaterial);
             fbsCommonProductNameXrefWriter.writeNameXref(lexiconProductStage, mirageSeedProduct, midasProductName);
         }
        return;
    }


    private void writeLexiconProductStage(LexiconProductEntity lexiconProduct, ProductStage productStage, LexiconProductStageEntity lexiconProductStage) {
        lexiconProductStage.setCommercialName(productStage.getCommercialName());
        lexiconProductStage.setLexiconBrand(lexiconBrandDao.getByName(productStage.getBrandName()));
        lexiconProductStage.setLexiconCountry(lexiconCountryDao.findByAbbreviation(productStage.getCountryAbbreviation()));
        lexiconProductStage.setLexiconStage(lexiconStageDao.findStageByAbbreviation(productStage.getStageAbbreviation()));
        lexiconProductStage.setOecdRegistrationName(productStage.getOecdName());
        lexiconProductStage.setCommercialMaturity(StringUtils.isBlank(productStage.getCommercialMaturity())?null:Double.parseDouble(productStage.getCommercialMaturity()));
        lexiconProductStage.setCommercialTraitStack(StringUtils.isBlank(productStage.getComlTraitName())?null:commercialTraitStackDao.getByTraitNameAndCrop(productStage.getComlTraitName(), lexiconProduct.getLexiconCrop().getName()).get(0));
        lexiconProductStage.setActive(productStage.isActive());
        lexiconProductStage.setLogicalDelete(productStage.isDelete());
        lexiconProductStage.setPreferredName(productStage.isPreferredName());
        if(StringUtils.isBlank(productStage.getProductStagePubkey())){
           lexiconProductStageDao.saveOrUpdate(lexiconProductStage);
           productStage.setProductStagePubkey(lexiconProductStage.getPubkey());
        }
    }

    private LexiconProductStageEntity getLexiconProductStage(LexiconProductEntity lexiconProduct, Map<String, LexiconProductStageEntity> stageMap, ProductStage productStage) {
        LexiconProductStageEntity lexiconProductStage = null;
        if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
            lexiconProductStage = stageMap.get(productStage.getProductStagePubkey());
        }
        if(lexiconProductStage==null){
           lexiconProductStage = new LexiconProductStageEntity();
           lexiconProductStage.setLexiconProduct(lexiconProduct);
           lexiconProductStage.setPubkey(lexiconProductStageDao.getNextPubkey());
           lexiconProduct.getLexiconProductStages().add(lexiconProductStage);
        }
        return lexiconProductStage;
    }

    public void setCommercialTraitStackDao(CommercialTraitStackDao commercialTraitStackDao) {
        this.commercialTraitStackDao = commercialTraitStackDao;
    }

    public void setExceptionCodeWriter(ExceptionCodeWriter exceptionCodeWriter) {
        this.exceptionCodeWriter = exceptionCodeWriter;
    }

    public void setFbsCommonProductNameXrefWriter(FbsCommonProductNameXrefWriter fbsCommonProductNameXrefWriter) {
        this.fbsCommonProductNameXrefWriter = fbsCommonProductNameXrefWriter;
    }

    public void setGeneticMaterialWriter(GeneticMaterialWriter geneticMaterialWriter) {
        this.geneticMaterialWriter = geneticMaterialWriter;
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }

    public void setLexiconCountryDao(LexiconCountryDao lexiconCountryDao) {
        this.lexiconCountryDao = lexiconCountryDao;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }

    public void setMapProductMirageWriter(MapProductMirageWriter mapProductMirageWriter) {
        this.mapProductMirageWriter = mapProductMirageWriter;
    }

    public void setMidasProductNameWriter(MidasProductNameWriter midasProductNameWriter) {
        this.midasProductNameWriter = midasProductNameWriter;
    }

    public void setMirageSeedProductWriter(MirageSeedProductWriter mirageSeedProductWriter) {
        this.mirageSeedProductWriter = mirageSeedProductWriter;
    }
}
