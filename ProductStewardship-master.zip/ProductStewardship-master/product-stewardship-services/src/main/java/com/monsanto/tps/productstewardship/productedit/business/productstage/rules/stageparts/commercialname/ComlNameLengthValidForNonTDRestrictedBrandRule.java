package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialname;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ComlNameLengthValidForNonTDRestrictedBrandRule implements ValidationSimpleRule<StageValidationModel> {
    public static final int MAX_SIZE = 30;    
    private LexiconBrandDao lexiconBrandDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        String brand = model.getProductStage().getBrandName();
        String commercialName = model.getProductStage().getCommercialName();
        if(StringUtils.isNotBlank(brand)&&StringUtils.isNotBlank(commercialName)){
            LexiconBrandEntity lexiconBrand = lexiconBrandDao.getByName(brand);
            if((lexiconBrand!=null)&&(!lexiconBrand.isTechDevRestricted())&&(commercialName.length()>MAX_SIZE)){
                status.addCondition(new ValidationResult(ProductEditService.COML_NAME_TOO_LONG_NON_TDR_CODE, ValidationSeverity.ERROR));
            }
        }
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }
}
