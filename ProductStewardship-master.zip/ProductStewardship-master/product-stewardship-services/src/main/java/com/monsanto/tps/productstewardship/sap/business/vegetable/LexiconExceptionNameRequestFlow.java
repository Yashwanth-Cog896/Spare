package com.monsanto.tps.productstewardship.sap.business.vegetable;


import com.monsanto.sap.vegetable.webservice.exception.DTLexiconExceptionNamesReq;
import com.monsanto.sap.vegetable.webservice.exception.DTLexiconExceptionNamesRsp;
import com.monsanto.sap.vegetable.webservice.exception.MILexiconExceptionNamesOSBSReq;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.productstewardship.blend.business.BlendedProductGermplasmBusiness;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductGermplasmEntity;
import org.apache.log4j.Logger;

import java.util.*;

public class LexiconExceptionNameRequestFlow
{
    private static final org.apache.log4j.Logger log = Logger.getLogger(LexiconExceptionNameRequestFlow.class);
    private DTLexiconHeaderBuilder dtLexiconHeaderBuilder;
    private MILexiconExceptionNamesOSBSReq miLexiconExceptionNamesOSBSReq;
    private ProductStageExceptionNameBuilder productStageExceptionNameBuilder;
    private BlendedProductGermplasmBusiness blendedProductGermplasmBusiness;

    public DTLexiconExceptionNamesRsp flowToSap(Set<LexiconProductEntity> lexiconProducts)  {
       Set< DTLexiconExceptionNamesReq.ExceptionNames> exceptionNames =  buildExceptionNamesRequest(lexiconProducts);
        if(!exceptionNames.isEmpty()){
            DTLexiconExceptionNamesReq namesOSBReq = build(exceptionNames);
            return  miLexiconExceptionNamesOSBSReq.miLexiconExceptionNamesOSBSReq(namesOSBReq);
    }
        else {
            return null;
        }
    }

    private  DTLexiconExceptionNamesReq build(Set<DTLexiconExceptionNamesReq.ExceptionNames> exceptionNames) {
      DTLexiconExceptionNamesReq request = new DTLexiconExceptionNamesReq();
      request.setHeader(dtLexiconHeaderBuilder.buildHeader());
      request.getExceptionNames().addAll(exceptionNames);
      return request;
   }

    private  Set< DTLexiconExceptionNamesReq.ExceptionNames>   buildExceptionNamesRequest(Set<LexiconProductEntity> lexiconProducts) {
        Set<DTLexiconExceptionNamesReq.ExceptionNames> exceptionNames = new HashSet<DTLexiconExceptionNamesReq.ExceptionNames>();
        for(LexiconProductEntity lexiconProduct: lexiconProducts){
            LexBlendedProductDetails productComponents = getBlendedProductComponents(lexiconProduct.getFbsCommonProductXref().getMidasProduct());
            for(LexiconProductStageEntity lexiconProductStage: lexiconProduct.getLexiconProductStages()){
                if((lexiconProductStage.getExceptionCode()!=null)&&(!lexiconProductStage.isLogicalDelete())){
                    exceptionNames.add( productStageExceptionNameBuilder.build(lexiconProductStage, productComponents));
                }
            }
        }
        return exceptionNames;
    }

    private LexBlendedProductDetails getBlendedProductComponents(MidasProductEntity midasProduct) {
        Collection<ProductGermplasmEntity> productGermplasms = midasProduct.getProductGermplasms();
        if (!productGermplasms.isEmpty()) {
            ProductGermplasmEntity productGermplasm = productGermplasms.iterator().next();
            List<LexBlendedProductDetails> detailsList= blendedProductGermplasmBusiness.getBlendedProductDetails(Arrays.asList(productGermplasm.getGermplasm().getId()));
            if(!detailsList.isEmpty()){
                return detailsList.get(0);
            }
        }
        return null;
    }
    
    public void setMiLexiconExceptionNamesOSBSReq(MILexiconExceptionNamesOSBSReq miLexiconExceptionNamesOSBSReq) {
        this.miLexiconExceptionNamesOSBSReq = miLexiconExceptionNamesOSBSReq;
    }


    public void setDtLexiconHeaderBuilder(DTLexiconHeaderBuilder dtLexiconHeaderBuilder) {
        this.dtLexiconHeaderBuilder = dtLexiconHeaderBuilder;
    }

    public void setProductStageExceptionNameBuilder(ProductStageExceptionNameBuilder productStageExceptionNameBuilder) {
        this.productStageExceptionNameBuilder = productStageExceptionNameBuilder;
    }
    public void setBlendedProductGermplasmBusiness(BlendedProductGermplasmBusiness blendedProductGermplasmBusiness) {
        this.blendedProductGermplasmBusiness = blendedProductGermplasmBusiness;
    }

}
