package com.monsanto.tps.productstewardship.productedit.business.product.rules.existingproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class LinkedMidasProdNotInactiveRule implements ValidationSimpleRule<ProductValidationModel> {

    private LexiconProductDao lexiconProductDao;
    @Override
    public void validate(ProductValidationModel model, ValidationStatus status) {
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(model.getProduct().getProductPubkey());
            if(lexiconProduct!=null){
                FbsCommonProductXrefEntity commonProductXrefEntity = lexiconProduct.getFbsCommonProductXref();
                if(!lexiconProduct.isLogicalDelete()&&(commonProductXrefEntity !=null)&&
                   (commonProductXrefEntity.getMidasProduct()!=null)&&
                   (!commonProductXrefEntity.getMidasProduct().isRefActive())){
                     status.addCondition(new ValidationResult(ProductEditService.LINKED_MIDAS_PROD_INACTIVE_CODE, ValidationSeverity.INFO));
                }
            }
        }
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
