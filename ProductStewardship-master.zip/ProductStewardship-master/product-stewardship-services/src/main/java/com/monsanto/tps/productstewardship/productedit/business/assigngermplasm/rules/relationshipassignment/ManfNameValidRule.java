package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class ManfNameValidRule implements ValidationSimpleRule<Product>{

  public static final int MAX_SIZE = 50;

  @Override
  public void validate(Product model, ValidationStatus status) {
       if (!StringUtils.isNullOrEmpty(model.getManufacturingName())){
           if (valueTooLarge(model.getManufacturingName())||hasInvalidCharacters(model.getManufacturingName())){
               status.addCondition(new ValidationResult(ProductEditService.MANF_NAME_INVALID_CODE, ValidationSeverity.ERROR));
           }
       }
  }

  private boolean valueTooLarge(String manfName) {
      return manfName.length() > MAX_SIZE;
  }

  private boolean hasInvalidCharacters(String manfName) {
      if (manfName.startsWith("+")){
          return true;
      }
      if (manfName.endsWith("+")){
          return true;
      }
      if (manfName.contains("+++")){
          return true;
      }
      if (!manfName.matches("[\\w\\-\\+]+")){
          return true;
      }
      return false;
   }
}
