package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class TraitVersNameValidRule implements ValidationSimpleRule<Product>{

  public static final int MAX_SIZE = 10;

  @Override
  public void validate(Product model, ValidationStatus status) {
       if (!StringUtils.isNullOrEmpty(model.getTraitVersion())){
           if (valueTooLarge(model.getTraitVersion())||hasInvalidCharacters(model.getTraitVersion())){
               status.addCondition(new ValidationResult(ProductEditService.TRAIT_VERS_INVALID_CODE, ValidationSeverity.ERROR));
           }
       }
  }

  private boolean valueTooLarge(String manfName) {
      return manfName.length() > MAX_SIZE;
  }

  private boolean hasInvalidCharacters(String manfName) {
      if (!manfName.matches("[\\w\\-\\+]+")){
          return true;
      } else {
        return false;
      }
  }
}
