package com.monsanto.tps.productstewardship.sap.business.vegetable;

import java.util.List;

public interface SapVegetableProductFlow {
     public List<Long> retrievePqSapQueueEntryIdsToProcess();
     public  void flowNextChangesToSap(List<Long> pqSapProductId);
}
