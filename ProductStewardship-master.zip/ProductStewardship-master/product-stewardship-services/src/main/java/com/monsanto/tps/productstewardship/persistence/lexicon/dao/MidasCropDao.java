package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapCropMirageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasCropEntity;

public interface MidasCropDao extends GenericDao<MidasCropEntity,Long>{
    public MapCropMirageEntity findMapCropMirage(String midasName);
}
