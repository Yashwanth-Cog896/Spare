package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.country;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCountryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class CountryValidRule implements ValidationSimpleRule<StageValidationModel> {
    LexiconCountryDao lexiconCountryDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean isValid = false;
        if(StringUtils.isNotBlank(model.getProductStage().getCountryAbbreviation())){
            LexiconCountryEntity lexiconCountry = lexiconCountryDao.findByAbbreviation(model.getProductStage().getCountryAbbreviation());
            if((lexiconCountry!=null)&&(!lexiconCountry.isLogicalDelete())){
                isValid=true;            
            }
        }
        if(!isValid){
            status.addCondition(new ValidationResult(ProductEditService.INVALID_COUNTY_CODE, ValidationSeverity.ERROR));
        }
    }

    public void setLexiconCountryDao(LexiconCountryDao lexiconCountryDao) {
        this.lexiconCountryDao = lexiconCountryDao;
    }
}
