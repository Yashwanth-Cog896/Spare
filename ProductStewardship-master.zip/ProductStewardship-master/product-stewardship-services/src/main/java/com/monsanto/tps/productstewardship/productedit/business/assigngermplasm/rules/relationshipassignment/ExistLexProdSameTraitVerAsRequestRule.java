package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

import java.util.*;

public class ExistLexProdSameTraitVerAsRequestRule implements ValidationSimpleRule<Product>{

  private LexiconProductDao lexiconProductDao;

  @Override
  public void validate(Product model, ValidationStatus status) {
    LexiconProductEntity existingProduct = (model.getPreCommercialName()== null)?null:lexiconProductDao.getByPreCommercialName(model.getPreCommercialName());

    if ((existingProduct != null)&&(!existingProduct.isLogicalDelete())) {
      Set<ProductRelationshipXrefEntity> existingProductRelationshipXrefs = existingProduct.getLexiconProductRelationshipXrefs();
      if ((existingProductRelationshipXrefs==null) ||(existingProductRelationshipXrefs.size()==0)) {
        if (!StringUtils.isNullOrEmpty(model.getTraitVersion()))  {
           status.addCondition(new ValidationResult(ProductEditService.EXIST_LEX_PROD_DIFF_MANF_VER, ValidationSeverity.ERROR));
        }
      }  else {
          boolean matchedTraitVerFound = false;
          for (ProductRelationshipXrefEntity productRelationshipXref:existingProductRelationshipXrefs) {
            String traitName = productRelationshipXref.getTraitVersion();
            if (StringUtils.isNullOrEmpty(traitName)){
              matchedTraitVerFound = StringUtils.isNullOrEmpty(model.getTraitVersion())? true:matchedTraitVerFound;
            } else if (traitName.equals(model.getTraitVersion())){
              matchedTraitVerFound = true;
            }
          }
          if (!matchedTraitVerFound){
            status.addCondition(new ValidationResult(ProductEditService.EXIST_LEX_PROD_DIFF_MANF_VER, ValidationSeverity.ERROR));
          }
      }
    }
  }

  public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
    this.lexiconProductDao = lexiconProductDao;
  }
}
