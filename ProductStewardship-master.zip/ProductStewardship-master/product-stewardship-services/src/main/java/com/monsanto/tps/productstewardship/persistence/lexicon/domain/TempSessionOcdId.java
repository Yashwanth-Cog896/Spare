/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * rlcasw - Feb 19, 2010 2:28:10 PM
 */
@Embeddable
public class TempSessionOcdId
   implements Serializable
{
   @Column(name="REQUEST_ID", nullable = false)
   private Long requestId;
   @Column(name="NUMBER_1", nullable = true)
   private Long number1;
   @Column(name="TEXT_1",nullable=true)
   private String text1;
   @Column(name="TEXT_2",nullable=true)
   private String text2;

   @Column(name="SORT_ORDER", nullable = false)
   private Long sortOrder;
   private static final int MULTIPLIER = 31;


    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    public TempSessionOcdId() {
   }


    public TempSessionOcdId(Long requestId, Long number1, String text1, String text2, Long sortOrder) {
        this.requestId = requestId;
        this.number1 = number1;
        this.text1 = text1;
        this.text2 = text2;
        this.sortOrder = sortOrder;
    }

    public TempSessionOcdId(Long id, Long num1, Long sort) {
       this.requestId = id;
       this.number1 = num1;
       this.sortOrder = sort;

       this.text1 = "";
   }

   public TempSessionOcdId(Long id, String text1, Long sort) {
       this.requestId = id;
       this.number1 = 0L;
       this.sortOrder = sort;
       this.text1 = text1;
   }

    public TempSessionOcdId(Long requestId, Long number1, String text1, Long sort) {
       this.requestId = requestId;
       this.number1 = number1;
       this.text1 = text1;
       this.sortOrder = sort;
    }

    public TempSessionOcdId(Long requestId, String text1, String text2, Long sortOrder) {
        this.requestId = requestId;
        this.text1 = text1;
        this.text2 = text2;
        this.sortOrder = sortOrder;
    }

    public Long getRequestId() {
       return this.requestId;
   }

   public void setRequestId(Long id) {
       this.requestId = id;
   }

   public Long getNumber1() {
       return number1;
   }

   public void setNumber1(Long num) {
       this.number1 = num;
   }


   public Long getSortOrder() {
       return sortOrder;
   }

   public void setSortOrder(Long sort) {
       this.sortOrder = sort;
   }

   public String getText1() {
      return text1;
   }

   public void setText1(String text1) {
      this.text1 = text1;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (!(o instanceof TempSessionOcdId)) {
         return false;
      }

      TempSessionOcdId that = (TempSessionOcdId) o;

      if (number1 != null ? !number1.equals(that.number1) : that.number1 != null) {
         return false;
      }
      if (requestId != null ? !requestId.equals(that.requestId) : that.requestId != null) {
         return false;
      }
      if (sortOrder != null ? !sortOrder.equals(that.sortOrder) : that.sortOrder != null) {
         return false;
      }
      if (text1 != null ? !text1.equals(that.text1) : that.text1 != null) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result = requestId != null ? requestId.hashCode() : 0;
      result = 31 * result + (number1 != null ? number1.hashCode() : 0);
      result = 31 * result + (text1 != null ? text1.hashCode() : 0);
      result = 31 * result + (sortOrder != null ? sortOrder.hashCode() : 0);
      return result;
   }
}