package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.xmlserialization.XmlSerializerBuilder;

public class SapSyncResponseSerializer
   extends BasicSerializer<SapSyncResponse>
{
   public void registerMappings(XmlSerializerBuilder serializerBuilder)
   {
      serializerBuilder.registerMapping(null, "response", SapSyncResponseImpl.class);
      serializerBuilder.registerAttributeMapping(SapSyncResponseImpl.class, "sapLinkageAuditId");
   }
}