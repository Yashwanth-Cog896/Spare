package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class TraitVerGivenManfNameGivenRule implements ValidationSimpleRule<Product> {

  @Override
  public void validate(Product model, ValidationStatus status) {
      if (!StringUtils.isNullOrEmpty(model.getTraitVersion()) && StringUtils.isNullOrEmpty(model.getManufacturingName())){
          status.addCondition(new ValidationResult(ProductEditService.TRAIT_VER_SPEC_MANF_NOT_CODE, ValidationSeverity.ERROR));
      }
  }
}
