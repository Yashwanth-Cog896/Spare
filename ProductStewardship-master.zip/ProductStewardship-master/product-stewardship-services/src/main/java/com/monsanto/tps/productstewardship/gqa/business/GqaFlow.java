package com.monsanto.tps.productstewardship.gqa.business;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 25, 2011
 * Time: 9:26:21 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GqaFlow {
    public void flowChangesToGqa();
}
