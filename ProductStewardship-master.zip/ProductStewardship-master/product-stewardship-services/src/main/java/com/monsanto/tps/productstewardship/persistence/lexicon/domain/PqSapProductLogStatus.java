package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 19, 2011
 * Time: 10:47:42 AM
 * To change this template use File | Settings | File Templates.
 */
public enum PqSapProductLogStatus {
    E, //Error
    S  //Success
}
