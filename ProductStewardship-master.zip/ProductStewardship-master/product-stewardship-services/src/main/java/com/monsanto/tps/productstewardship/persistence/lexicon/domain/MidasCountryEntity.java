package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 15, 2011
 * Time: 10:08:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "COUNTRY", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasCountryEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "COUNTRY_ID", precision = 0, length = 22)
    private long id;
    @Column(name="NAME",length = 80,nullable=false)
    private String name;
    @Type(type="true_false")
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean refActive;

    @Column(name="COUNTRY_ABBR",length=3,nullable = true)
    private String abbreviation;

    @Column(name="MIRAGE_COUNTRY_REF_ID",length=10,nullable = true)
    private String mirageCountryRefId;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMirageCountryRefId() {
        return mirageCountryRefId;
    }

    public void setMirageCountryRefId(String mirageCountryRefId) {
        this.mirageCountryRefId = mirageCountryRefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }
}
