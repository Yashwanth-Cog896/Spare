package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageCompanyEntity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BRAND_XREF", schema = "FBS_COMMON")
public class FbsCommonBrandXrefEntity implements Serializable{

    @Id
    @Column(name="LEXICON_BRAND_PUBKEY",length = 20)
    String lexiconBrandPubkey;

    @ManyToOne
    @JoinColumn(name = "MIDAS_BRAND_ID", nullable = true)
    MidasBrandEntity midasBrand;

    @ManyToOne
    @JoinColumn(name = "MIRAGE_COMPANY_ID", nullable = true)
    MirageCompanyEntity mirageCompany;

    @ManyToOne
    @JoinColumn(name = "LEXICON_COMPANY_PUBKEY",referencedColumnName = "COMPANY_PUBKEY",nullable = true)
    LexiconCompany lexiconCompany;

    public String getLexiconBrandPubkey() {
        return lexiconBrandPubkey;
    }

    public void setLexiconBrandPubkey(String lexiconBrandPubkey) {
        this.lexiconBrandPubkey = lexiconBrandPubkey;
    }

    public LexiconCompany getLexiconCompany() {
        return lexiconCompany;
    }

    public void setLexiconCompany(LexiconCompany lexiconCompany) {
        this.lexiconCompany = lexiconCompany;
    }

    public MidasBrandEntity getMidasBrand() {
        return midasBrand;
    }

    public void setMidasBrand(MidasBrandEntity midasBrand) {
        this.midasBrand = midasBrand;
    }

    public MirageCompanyEntity getMirageCompany() {
        return mirageCompany;
    }

    public void setMirageCompany(MirageCompanyEntity mirageCompany) {
        this.mirageCompany = mirageCompany;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FbsCommonBrandXrefEntity)) return false;

        FbsCommonBrandXrefEntity that = (FbsCommonBrandXrefEntity) o;

        if (lexiconBrandPubkey != null ? !lexiconBrandPubkey.equals(that.lexiconBrandPubkey) : that.lexiconBrandPubkey != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return lexiconBrandPubkey != null ? lexiconBrandPubkey.hashCode() : 0;
    }
}
