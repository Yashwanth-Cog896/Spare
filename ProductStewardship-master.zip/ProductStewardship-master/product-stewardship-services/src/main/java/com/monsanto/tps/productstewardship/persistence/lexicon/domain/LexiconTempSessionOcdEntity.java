/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * rlcasw - Feb 19, 2010 2:27:35 PM
 */
@Entity
@Table(name = "TEMP_SESSION_OCD", schema = "LEXICON")
public class LexiconTempSessionOcdEntity implements Serializable 
{
    @EmbeddedId
    private TempSessionOcdId id;

    public LexiconTempSessionOcdEntity() {
    }

    public LexiconTempSessionOcdEntity(TempSessionOcdId tempSessionOcdId) {
        this.id = tempSessionOcdId;
    }

    public TempSessionOcdId getId() {
        return this.id;
    }

    public void setId(TempSessionOcdId tempSessionOcdId) {
        this.id = tempSessionOcdId;
    }
}