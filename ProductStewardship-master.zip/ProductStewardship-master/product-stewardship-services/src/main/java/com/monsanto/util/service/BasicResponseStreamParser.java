package com.monsanto.util.service;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 12, 2007
 * Time: 4:42:10 PM
 */
public class BasicResponseStreamParser implements ResponseStreamParser {

   public Document parseResponse(final InputStream responseStream) throws IOException {
      try {
         return DOMUtil.newDocument(responseStream);
      }
      catch (SAXException e) {
         throw new IOException(e.getMessage());
      }
   }
}
