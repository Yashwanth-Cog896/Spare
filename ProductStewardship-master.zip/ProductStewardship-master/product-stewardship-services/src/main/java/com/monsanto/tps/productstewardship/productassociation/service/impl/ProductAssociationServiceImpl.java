package com.monsanto.tps.productstewardship.productassociation.service.impl;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.productassociation.business.ProductAssociationBusiness;
import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationSearchResponse;
import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationSearchType;
import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationService;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 8, 2011
 * Time: 10:32:35 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public class ProductAssociationServiceImpl implements ProductAssociationService {

    private ProductAssociationBusiness productAssociationBusiness;
    @Override
    public List<ProductAssociationSearchResponse> findProductAssociations(ProductAssociationSearchType searchType, List<String> names, boolean hybridOnly) {
        return productAssociationBusiness.findProductAssociations(searchType,names,hybridOnly);
    }

    public void setProductAssociationBusiness(ProductAssociationBusiness productAssociationBusiness) {
        this.productAssociationBusiness = productAssociationBusiness;
    }
}
