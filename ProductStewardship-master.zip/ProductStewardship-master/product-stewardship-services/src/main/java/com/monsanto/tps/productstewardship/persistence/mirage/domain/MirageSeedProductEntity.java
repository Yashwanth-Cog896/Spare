package com.monsanto.tps.productstewardship.persistence.mirage.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 27, 2011
 * Time: 9:58:52 AM
 * To change this template use File | Settings | File Templates.
 */

@Entity
@SequenceGenerator(name = "mirageSeedProductIdGenerator",allocationSize = 1,sequenceName = "Mirage2.AUDIT_ID_SEQ")
@Table(name = "SEED_PRODUCTS", schema = "Mirage2")
public class MirageSeedProductEntity  implements Serializable {
    @Id
    @Column(name="PRODUCT_ID")
    @GeneratedValue(generator = "mirageSeedProductIdGenerator")
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="COMPANY_ID",nullable=false)
    private MirageCompanyEntity mirageCompany;
    @Column(name="PRODUCT_NAME",nullable = false,length = 30)
    private String name;
    @Column(name="CROP_BAYER_CODE",nullable = false, length=6)
    private String bayerCode;
    @Column(name="COUNTRY_CODE",nullable=false,length=3)
    private String countryCode;
    @Column(name="TRAIT_CHARACTERISTIC_CODE",nullable=true,precision = 8,scale = 0)
    private Long traitCharacteristicCode;
    @Column(name="GENERIC_PRODUCT_FLAG",nullable = true)
    @Type(type = "yes_no")
    private Boolean genericProduct;
    @Column(name="ENABLED",nullable = false)
    @Type(type = "yes_no")
    private boolean enabled;
    @Column(name="DISABLED_DATE",nullable=true)
    @Temporal(TemporalType.DATE)
    private Date disabledDate;
    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name="AUDIT_ID",nullable=true)
    private MirageAuditEntity audit;

    public MirageAuditEntity getAudit() {
        return audit;
    }

    public void setAudit(MirageAuditEntity audit) {
        this.audit = audit;
    }

    public String getBayerCode() {
        return bayerCode;
    }

    public void setBayerCode(String bayerCode) {
        this.bayerCode = bayerCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Date getDisabledDate() {
        return disabledDate;
    }

    public void setDisabledDate(Date disabledDate) {
        this.disabledDate = disabledDate;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Boolean getGenericProduct() {
        return genericProduct;
    }

    public void setGenericProduct(Boolean genericProduct) {
        this.genericProduct = genericProduct;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MirageCompanyEntity getMirageCompany() {
        return mirageCompany;
    }

    public void setMirageCompany(MirageCompanyEntity mirageCompany) {
        this.mirageCompany = mirageCompany;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTraitCharacteristicCode() {
        return traitCharacteristicCode;
    }

    public void setTraitCharacteristicCode(Long traitCharacteristicCode) {
        this.traitCharacteristicCode = traitCharacteristicCode;
    }
}
