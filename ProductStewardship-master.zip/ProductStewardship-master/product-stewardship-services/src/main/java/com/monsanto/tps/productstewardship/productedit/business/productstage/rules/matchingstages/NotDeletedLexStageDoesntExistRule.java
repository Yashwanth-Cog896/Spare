package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.matchingstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.*;

public class NotDeletedLexStageDoesntExistRule  implements ValidationSimpleRule<StageValidationModel> {
    
    private LexiconProductDao lexiconProductDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean foundMatch=false;

     ProductStage productStage= model.getProductStage();
        Collection<LexiconProductStageEntity> lexiconProductStages = loadLexiconProductStagesNotInRequest(model);
        for(LexiconProductStageEntity lexiconProductStage: lexiconProductStages){
            if(StringUtils.equals(productStage.getBrandName(),lexiconProductStage.getLexiconBrand().getName())&&
               StringUtils.equals(productStage.getCountryAbbreviation(),lexiconProductStage.getLexiconCountry().getAbbreviation())&&
               !StringUtils.equals(productStage.getProductStagePubkey(),lexiconProductStage.getPubkey())){
                foundMatch=true;
                break ;
            }
        }
        if(!foundMatch){
            for(ProductStage testProductStage: model.getProduct().getProductStages()){
               if((productStage!=testProductStage)&&//Actually checking instance thus not using equals method
                    StringUtils.equals(productStage.getBrandName(),testProductStage.getBrandName())&&
                   StringUtils.equals(productStage.getCountryAbbreviation(),testProductStage.getCountryAbbreviation())&&
                   !testProductStage.isDelete()){
                   foundMatch=true;
                   break ;
               }
            }
        }

        if(foundMatch){
             status.addCondition(new ValidationResult(ProductEditService.MATCHING_LEX_STAGE_EXISTS_CODE, ValidationSeverity.ERROR));
        }



    }


    private Collection<LexiconProductStageEntity> loadLexiconProductStagesNotInRequest(StageValidationModel model) {
        Map<String,LexiconProductStageEntity> lexiconProductStageMap = new HashMap<String, LexiconProductStageEntity>();
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity lexiconProduct=lexiconProductDao.getByPubkey(productPubkey);
            if(lexiconProduct!=null&&!lexiconProduct.isLogicalDelete()){
                for(LexiconProductStageEntity lexiconProductStage:lexiconProduct.getLexiconProductStages()){
                    if(!lexiconProductStage.isLogicalDelete()){
                       lexiconProductStageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
                    }
                }
                for(ProductStage productStage: model.getProduct().getProductStages()){
                    if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
                        lexiconProductStageMap.remove(productStage.getProductStagePubkey());
                    }
                }
            }
        }
        Collection<LexiconProductStageEntity> lexiconProductStages = lexiconProductStageMap.values();
        return lexiconProductStages;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
