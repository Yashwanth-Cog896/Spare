package com.monsanto.tps.productstewardship.persistence.lexicon.transform;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;
import com.monsanto.tps.productstewardship.transfer.ProductRelationship;
import com.monsanto.tps.productstewardship.transfer.ProductRelationshipXref;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: 8/15/11
 * Time: 12:56 PM
 */
public class BaseProductEntityTransformer {

    public BaseProduct transformBaseProduct(BaseProductEntity baseProductEntity) {
        BaseProduct baseProduct = new BaseProduct();
        baseProduct.setBaseProductId(baseProductEntity.getId());
        baseProduct.setCropId(baseProductEntity.getId());
        baseProduct.setBaseManufacturingName(baseProductEntity.getBaseManufacturingName());
        //TODO: baseProduct.setParent();
        baseProduct.setProductRelationship(convertProductRelationshipEntities(baseProductEntity.getProductRelationships()));
        return baseProduct;
    }

    private List<ProductRelationship> convertProductRelationshipEntities(List<ProductRelationshipEntity> productRelationshipEntities) {
        List<ProductRelationship> productRelationships = null;
        if (productRelationshipEntities != null) {
            productRelationships = new ArrayList<ProductRelationship>();
            for (ProductRelationshipEntity productRelationshipEntity : productRelationshipEntities) {
                convertProductRelationshipEntity(productRelationshipEntity);
            }
        }
        return productRelationships;
    }

    private ProductRelationship convertProductRelationshipEntity(ProductRelationshipEntity productRelationshipEntity) {
        ProductRelationship productRelationship = null;
        if (productRelationshipEntity != null) {
            productRelationship = new ProductRelationship();
            productRelationship.setProductRelationshipId(productRelationshipEntity.getId());
            productRelationship.setManufacturingName(productRelationshipEntity.getManufacturingName());
            productRelationship.setVarietyName(productRelationshipEntity.getVarietyName());
            productRelationship.setProductRelationshipXrefs(convertProductRelationshipXRefEntities(productRelationshipEntity.getProductRelationshipXRefs()));
        }
        return productRelationship;
    }

    private List<ProductRelationshipXref> convertProductRelationshipXRefEntities(List<ProductRelationshipXrefEntity> productRelationshipXrefEntities) {
        List<ProductRelationshipXref> productRelationshipXrefs = null;
        if (productRelationshipXrefEntities != null) {
            productRelationshipXrefs = new ArrayList<ProductRelationshipXref>();
            for (ProductRelationshipXrefEntity productRelationshipXrefEntity : productRelationshipXrefEntities) {
                productRelationshipXrefs.add(convertProductRelationshipXRefEntity(productRelationshipXrefEntity));
            }
        }
        return productRelationshipXrefs;
    }

    private ProductRelationshipXref convertProductRelationshipXRefEntity(ProductRelationshipXrefEntity productRelationshipXrefEntity) {
        ProductRelationshipXref productRelationshipXref = null;
        if (productRelationshipXrefEntity != null) {
            productRelationshipXref = new ProductRelationshipXref();
            productRelationshipXref.setProductRelationshipXrefId(productRelationshipXrefEntity.getId());
            if (productRelationshipXrefEntity.getProductionStatus() != null) {
                productRelationshipXref.setProductionStatusId(productRelationshipXrefEntity.getProductionStatus().getId());
            }
            productRelationshipXref.setTraitVersion(productRelationshipXrefEntity.getTraitVersion());
        }
        return productRelationshipXref;
    }
}
