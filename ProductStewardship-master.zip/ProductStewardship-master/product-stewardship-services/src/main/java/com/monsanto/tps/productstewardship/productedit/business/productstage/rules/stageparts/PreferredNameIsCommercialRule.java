package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class PreferredNameIsCommercialRule  implements ValidationSimpleRule<StageValidationModel> {
    private LexiconStageDao lexiconStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        String stageAbbreviation = model.getProductStage().getStageAbbreviation();
        if(StringUtils.isNotBlank(stageAbbreviation)){
           LexiconStageEntity stage = lexiconStageDao.findStageByAbbreviation(stageAbbreviation);
            if(stage!=null){
                if((!stage.isCommercial())&&(model.getProductStage().isPreferredName())) {
                   status.addCondition(new ValidationResult(ProductEditService.PREFERRED_NAME_IS_COML_CODE, ValidationSeverity.ERROR)); 
                }
            }
        }
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
