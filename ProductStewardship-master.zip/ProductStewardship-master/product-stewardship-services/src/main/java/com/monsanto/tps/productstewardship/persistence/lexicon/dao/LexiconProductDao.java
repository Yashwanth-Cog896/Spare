package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 30, 2011
 * Time: 10:06:05 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductDao extends GenericDao<LexiconProductEntity,Long> {
    @DynamicDaoMethod(queryName = "LexiconProductEntity.getByPubkey",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    LexiconProductEntity getByPubkey(@DynamicDaoParameter(name="pubkey") String pubkey);

    @DynamicDaoMethod(queryName = "LexiconProductEntity.getByPreCommercialName",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    LexiconProductEntity getByPreCommercialName(@DynamicDaoParameter(name="preCommercialName") String preCommercialName);


    @DynamicDaoMethod(queryName = "LexiconProductDao.getByIds",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductEntity> getByIds(@DynamicDaoParameter(name="requestId") Long requestId);

    @DynamicDaoMethod(queryName = "LexiconProductDao.getByCropAndVarietyName",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductEntity> getByCropAndVarietyName(@DynamicDaoParameter(name="lexiconCropName")String lexiconCropName,@DynamicDaoParameter(name="varietyName") String varietyName);


    
    List<LexiconProductEntity> findBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria);
    List<LexiconProductEntity> findBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria,int pageSize,int pageNumber);
    int countBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria);
    List<LexiconProductEntity> findByAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops);
    Long countAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops);
    List<LexiconProductEntity> findPagedByAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops,int pageSize,int pageNumber);

}
