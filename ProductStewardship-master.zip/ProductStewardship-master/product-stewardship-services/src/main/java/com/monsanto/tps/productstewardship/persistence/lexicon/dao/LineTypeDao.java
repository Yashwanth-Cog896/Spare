package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LineTypeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;

import java.util.List;

public interface LineTypeDao extends GenericDao<LineTypeEntity,Long> {
   @DynamicDaoMethod(queryName = "LineTypeDao.getByRefId",
                parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public LineTypeEntity getByRefId(@DynamicDaoParameter(name="lineTypeRefId")String lineTypeRefId);
}
