package com.monsanto.tps.productstewardship.gqa.business;

import com.monsanto.Util.Exceptions.ExceptionAsString;
import com.monsanto.mfg.gqa.lexicon.webservice.*;
import com.monsanto.osb.webservice.credentials.CredentialsFactory;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import org.apache.log4j.Logger;
import org.hibernate.exception.LockAcquisitionException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 19, 2011
 * Time: 9:22:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class GqaProductFlowImpl implements GqaProductFlow {
    private final org.apache.log4j.Logger log = Logger.getLogger(this.getClass());
    private PqSapQueueEntryDao pqSapQueueEntryDao;
    private CredentialsFactory credentialsFactory;
    private ProductRelationshipDao productRelationshipDao;
    private LexiconProductStageDao lexiconProductStageDao;
    private LexiconProductDao lexiconProductDao;
    private PqSapLogDao pqSapLogDao;
    private BaseProductDao baseProductDao;
    private ProductChangeListener productChangeListener;


    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public List<Long> getPqSapProductIdsToProcess() {
        List<Long> idsToProcess = pqSapQueueEntryDao.getPqSapQueueEntryIdsToProcessForGqa();
        for(Long id:idsToProcess);//make sure list is completely fetched so transaction is not required to read list.
        return idsToProcess;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    @AuditStage(processName = "GqaFlowServiceImpl.flowChangesToGqa")
    public void flowNextChangeToGqa(long pqSapProductId){
         try{
            PqSapQueueEntryEntity pqSapQueueEntry = pqSapQueueEntryDao.retrieveForUpdateAndLock(pqSapProductId);
            if(pqSapQueueEntry !=null){
                try{
                    String tableName = pqSapQueueEntry.getTableName();
                    if(tableName.equals(PqSapQueueEntryEntity.PRE_COML_PRODUCT)||
                       tableName.equals(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP_XREF)){
                       LexiconProductEntity lexiconProduct = lexiconProductDao.get(pqSapQueueEntry.getTableId());
                       notifyListener(lexiconProduct);
                    }
                    else if(tableName.equals(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP)){
                        ProductRelationshipEntity productRelationship = productRelationshipDao.get(pqSapQueueEntry.getTableId());
                        notifyListener(productRelationship);
                    }
                    else if(tableName.equals(PqSapQueueEntryEntity.PRODUCT_STAGE)){
                        LexiconProductStageEntity productStage = lexiconProductStageDao.get(pqSapQueueEntry.getTableId());
                        notifyListener(productStage.getLexiconProduct());
                    }
                    else if(tableName.equals(PqSapQueueEntryEntity.BASE_PRODUCT)){
                         BaseProductEntity baseProduct = baseProductDao.get(pqSapQueueEntry.getTableId());
                         for(ProductRelationshipEntity productRelationship: baseProduct.getProductRelationships()){
                             notifyListener(productRelationship);
                         }
                    }
                    buildAndPersistLogEntry(pqSapQueueEntry, PqSapProductLogStatus.S, null);
                    pqSapQueueEntryDao.delete(pqSapQueueEntry);
                }

                catch(Exception e){
                    log.error(e.getMessage(),e);
                    PqSapLogEntity log = buildAndPersistLogEntry(pqSapQueueEntry, PqSapProductLogStatus.E, createThrowableErrorMessage(e));
                }
            }
        }
        catch(LockAcquisitionException lockAcquisitionException){
             //Ignore this, because  lockAcquisitionException is due to concurrent access issues. Not really a problem.
        }

    }
    private String createThrowableErrorMessage(Throwable throwable) {
      return truncateIfNecessary(throwable.getMessage()+"\n"+new ExceptionAsString().getStackTraceAsString(throwable));
   }

   private String truncateIfNecessary(String errorMessage) {
      return errorMessage.substring(0, Math.min(errorMessage.length(), PqSapLogDao.MAX_ERROR_MESSAGE_LENGTH));
   }

    private void notifyListener(ProductRelationshipEntity productRelationship) {
        if(productRelationship!=null){
            for(ProductRelationshipXrefEntity xref: productRelationship.getProductRelationshipXRefs()){
                notifyListener(xref.getLexiconProduct());
            }
        }
    }

    private void notifyListener(LexiconProductEntity lexiconProduct) {
        if(lexiconProduct!=null){
            ProductChangeInformation changeInfo = new ProductChangeInformation();
            changeInfo.setSpeciesCode(lexiconProduct.getLexiconCrop().getAbbreviation());
            changeInfo.setProductKey(lexiconProduct.getPubkey());
            productChangeListener.productChanged(credentialsFactory.createCredentialsContainer(),changeInfo);
        }
    }


    private PqSapLogEntity buildAndPersistLogEntry(PqSapQueueEntryEntity pqSapQueueEntry, PqSapProductLogStatus status, String message) {
        PqSapLogEntity pqSapLog = new PqSapLogEntity();
        pqSapLog.setInitDate(pqSapQueueEntry.getInitDate());
        pqSapLog.setStatus(status);
        pqSapLog.setMessage(message);
        pqSapLog.setTableId(pqSapQueueEntry.getTableId());
        pqSapLog.setTableName(pqSapQueueEntry.getTableName());
        pqSapLog.setCloseDate(new Date());
        pqSapLog.setProcessType(pqSapQueueEntry.getProcessType());
        pqSapLogDao.saveOrUpdate(pqSapLog);
        return pqSapLog;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }

    public void setPqSapQueueEntryDao(PqSapQueueEntryDao pqSapQueueEntryDao) {
        this.pqSapQueueEntryDao = pqSapQueueEntryDao;
    }

    public void setPqSapLogDao(PqSapLogDao pqSapLogDao) {
        this.pqSapLogDao = pqSapLogDao;
    }

    public void setProductChangeListener(ProductChangeListener productChangeListener) {
        this.productChangeListener = productChangeListener;
    }

    public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
        this.productRelationshipDao = productRelationshipDao;
    }

    public void setBaseProductDao(BaseProductDao baseProductDao) {
        this.baseProductDao = baseProductDao;
    }

    public void setCredentialsFactory(CredentialsFactory credentialsFactory) {
        this.credentialsFactory = credentialsFactory;
    }
}
