package com.monsanto.sap.vegetable.webservice.country;

import com.monsanto.sap.vegetable.webservice.country.TableOfYmmvegcntryStr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Error" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfYmmvegcntryStr"/>
 *         &lt;element name="ErrorRec" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="InsertRec" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="RecvRec" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="UpdateRec" type="{urn:sap-com:document:sap:rfc:functions}char10"/>
 *         &lt;element name="VegctrynameIn" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfYmmvegcntryStr"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "error",
    "errorRec",
    "insertRec",
    "recvRec",
    "updateRec",
    "vegctrynameIn"
})
@XmlRootElement(name = "YmmVegcntrynameDataUploadResponse")
public class YmmVegcntrynameDataUploadResponse {

    @XmlElement(name = "Error", required = true)
    protected TableOfYmmvegcntryStr error;
    @XmlElement(name = "ErrorRec", required = true)
    protected String errorRec;
    @XmlElement(name = "InsertRec", required = true)
    protected String insertRec;
    @XmlElement(name = "RecvRec", required = true)
    protected String recvRec;
    @XmlElement(name = "UpdateRec", required = true)
    protected String updateRec;
    @XmlElement(name = "VegctrynameIn", required = true)
    protected TableOfYmmvegcntryStr vegctrynameIn;

    /**
     * Gets the value of the error property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public TableOfYmmvegcntryStr getError() {
        return error;
    }

    /**
     * Sets the value of the error property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public void setError(TableOfYmmvegcntryStr value) {
        this.error = value;
    }

    /**
     * Gets the value of the errorRec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorRec() {
        return errorRec;
    }

    /**
     * Sets the value of the errorRec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorRec(String value) {
        this.errorRec = value;
    }

    /**
     * Gets the value of the insertRec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsertRec() {
        return insertRec;
    }

    /**
     * Sets the value of the insertRec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsertRec(String value) {
        this.insertRec = value;
    }

    /**
     * Gets the value of the recvRec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecvRec() {
        return recvRec;
    }

    /**
     * Sets the value of the recvRec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecvRec(String value) {
        this.recvRec = value;
    }

    /**
     * Gets the value of the updateRec property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateRec() {
        return updateRec;
    }

    /**
     * Sets the value of the updateRec property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateRec(String value) {
        this.updateRec = value;
    }

    /**
     * Gets the value of the vegctrynameIn property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public TableOfYmmvegcntryStr getVegctrynameIn() {
        return vegctrynameIn;
    }

    /**
     * Sets the value of the vegctrynameIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public void setVegctrynameIn(TableOfYmmvegcntryStr value) {
        this.vegctrynameIn = value;
    }

}
