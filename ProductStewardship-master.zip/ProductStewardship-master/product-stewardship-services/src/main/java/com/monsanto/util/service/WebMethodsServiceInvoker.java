package com.monsanto.util.service;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 11, 2007
 * Time: 3:06:18 PM
 */
public class WebMethodsServiceInvoker extends HttpServiceInvoker {

    private final  ServiceURLProvider serviceURLProvider;
    private final RequestStreamer requestStreamer;
    private final WebMethodsConnectionPreparer webMehodsConnectionPreparer;


    public WebMethodsServiceInvoker(ServiceURLProvider serviceURLProvider,RequestStreamer requestStreamer,WebMethodsConnectionPreparer webMehodsConnectionPreparer) {
        this.serviceURLProvider = serviceURLProvider;
        this.requestStreamer = requestStreamer;
        this.webMehodsConnectionPreparer=webMehodsConnectionPreparer;
   }

   protected ServiceURLProvider getURLProvider() {
       return serviceURLProvider;
   }
   protected ConnectionPreparer getConnectionPreparer() {
      return  webMehodsConnectionPreparer;
   }
   protected RequestStreamer getRequestStreamer() {
       return requestStreamer;
   }
   protected ResponseStreamParser getResponseStreamParser() {
      return new BasicResponseStreamParser();
   }
}