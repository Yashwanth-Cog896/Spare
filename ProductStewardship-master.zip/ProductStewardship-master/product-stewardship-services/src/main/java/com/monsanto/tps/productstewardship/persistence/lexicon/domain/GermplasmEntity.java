package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:49:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "GERMPLASM", schema = "Midas")
@GenericGenerator(
        name = "midas_generator",
        strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class GermplasmEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "GERMPLASM_ID", precision = 22, scale = 0)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "LINE_TYPE_ID", nullable = false)
    private LineTypeEntity lineType;
    @Column(name = "IS_DELETED", nullable = false)
    @Type(type = "true_false")
    private boolean deleted;
    @Column(name = "IS_FINISHED_OR_FINISHED_CHILD", nullable = false)
    @Type(type = "true_false")
    private boolean finished;
    @Column(name = "EVENT_DISPLAY", nullable = true, length = 2000)
    private String eventDisplay;
    @Column(name = "ORIGIN", nullable = true, length = 2000)
    private String origin;
    @Column(name = "LINE_CODE", nullable = true, length = 50)
    private String lineCode;
    @Column(name = "PEDIGREE_NAME", nullable = false, length = 3200)
    private String pedigreeName;
    @Column(name = "IS_TRANSGENIC", nullable = false)
    @Type(type = "true_false")
    private boolean transgenic;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "OWNER_BR_PROG_ID", nullable = false)
    private ProgramEntity ownerProgram;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private MidasCropEntity midasCrop;
    @OneToMany(mappedBy = "germplasm", fetch = FetchType.LAZY)
    private Set<GermplasmRoyaltyEntity> germplasmRoyalties = new HashSet<GermplasmRoyaltyEntity>();

    @OneToMany(mappedBy = "germplasm", fetch = FetchType.LAZY)
    private Set<TraitValueEntity> traitValues = new HashSet<TraitValueEntity>();

    @OneToMany(mappedBy = "germplasm", fetch = FetchType.LAZY)
    private Set<GeneticMaterialEntity> geneticMaterials = new HashSet<GeneticMaterialEntity>();

    @OneToMany(mappedBy = "germplasm", fetch = FetchType.LAZY)
    private Set<GermplasmEventConstructEntity> germplasmEventConstructs = new HashSet<GermplasmEventConstructEntity>();

    @OneToMany(mappedBy = "germplasm", fetch = FetchType.LAZY)
    private Set<ProductGermplasmEntity> productGermplasms = new HashSet<ProductGermplasmEntity>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LineTypeEntity getLineType() {
        return lineType;
    }

    public void setLineType(LineTypeEntity lineType) {
        this.lineType = lineType;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public boolean isTransgenic() {
        return transgenic;
    }

    public void setTransgenic(boolean transgenic) {
        this.transgenic = transgenic;
    }

    public ProgramEntity getOwnerProgram() {
        return ownerProgram;
    }

    public void setOwnerProgram(ProgramEntity ownerProgram) {
        this.ownerProgram = ownerProgram;
    }

    public MidasCropEntity getMidasCrop() {
        return midasCrop;
    }

    public void setMidasCrop(MidasCropEntity midasCrop) {
        this.midasCrop = midasCrop;
    }

    public Set<GermplasmRoyaltyEntity> getGermplasmRoyalties() {
        return germplasmRoyalties;
    }

    public void setGermplasmRoyalties(Set<GermplasmRoyaltyEntity> germplasmRoyalties) {
        this.germplasmRoyalties = germplasmRoyalties;
    }

    public Set<ProductGermplasmEntity> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(Set<ProductGermplasmEntity> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public Set<TraitValueEntity> getTraitValues() {
        return traitValues;
    }

    public void setTraitValues(Set<TraitValueEntity> traitValues) {
        this.traitValues = traitValues;
    }

    public Set<GeneticMaterialEntity> getGeneticMaterials() {
        return geneticMaterials;
    }

    public void setGeneticMaterials(Set<GeneticMaterialEntity> geneticMaterials) {
        this.geneticMaterials = geneticMaterials;
    }

    public Set<GermplasmEventConstructEntity> getGermplasmEventConstructs() {
        return germplasmEventConstructs;
    }

    public void setGermplasmEventConstructs(Set<GermplasmEventConstructEntity> germplasmEventConstructs) {
        this.germplasmEventConstructs = germplasmEventConstructs;
    }
}
