package com.monsanto.tps.productstewardship.email;

import org.apache.regexp.RE;
import org.apache.regexp.RESyntaxException;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * User: pjberry
 * Date: Oct 2, 2007
 * Time: 10:58:15 AM
 */
public class ExceptionFormatter
{
   public String format(Exception e, boolean encode) {
      String msg = getMessage(e);
      return encode ? encodeForHtml(msg) : msg;
   }

   private String getMessage(Exception e) {
      StringWriter sw = new StringWriter();
      PrintWriter out = new PrintWriter(sw);
      write(e, out);
      return sw.getBuffer().toString();
   }

   private void write(Exception e, PrintWriter out) {
      out.println("msg: " + e.getMessage());
      out.println("trace:");
      e.printStackTrace(out);
      out.close();
   }

   private String encodeForHtml(String src) {
      try {
         RE reLT = new RE("\\<");
         RE reGT = new RE("\\>");
         String dst = reLT.subst(src, "&lt;");
         return reGT.subst(dst, "&gt;");
      } catch (RESyntaxException e1) {
         throw new RuntimeException(e1.getMessage());
      }
   }
}
