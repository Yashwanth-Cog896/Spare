package com.monsanto.tps.productstewardship.gqa.business;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 19, 2011
 * Time: 11:27:58 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GqaProductFlow {
    void flowNextChangeToGqa(long pqSapProductId);
     public List<Long> getPqSapProductIdsToProcess();

}
