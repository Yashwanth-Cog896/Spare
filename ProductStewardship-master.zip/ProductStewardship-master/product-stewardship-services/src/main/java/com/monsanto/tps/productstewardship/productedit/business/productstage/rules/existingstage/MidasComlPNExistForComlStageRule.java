package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.existingstage;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class MidasComlPNExistForComlStageRule  implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductStageDao lexiconProductStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        LexiconProductStageEntity lexiconProductStage = lexiconProductStageDao.getByPubkey(model.getProductStage().getProductStagePubkey());
        if((lexiconProductStage!=null)&&(lexiconProductStage.getLexiconStage().isCommercial())&&
           (lexiconProductStage.getFbsCommonProductNameXref()!=null)&&(lexiconProductStage.getFbsCommonProductNameXref().getMidasProductName()==null)){
           status.addCondition(new ValidationResult(ProductEditService.MIDAS_COML_PN_NOT_EXIST_CODE, ValidationSeverity.INFO));
        }
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }
}
