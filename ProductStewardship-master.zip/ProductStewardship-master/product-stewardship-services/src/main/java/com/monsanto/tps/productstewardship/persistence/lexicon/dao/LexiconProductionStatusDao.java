package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductionStatusEntity;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 8/12/11
 * Time: 4:19 PM
 */
public interface LexiconProductionStatusDao extends GenericDao<LexiconProductionStatusEntity, Long> {
}
