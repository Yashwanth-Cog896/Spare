package com.monsanto.tps.productstewardship.productsearch.service.impl;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;
import com.monsanto.tps.productstewardship.productsearch.business.LexiconProductSearch;
import com.monsanto.tps.productstewardship.productsearch.service.*;
import com.monsanto.tps.productstewardship.transfer.Product;
import org.springframework.transaction.annotation.Transactional;

import javax.jws.WebParam;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 5:21:15 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional(readOnly = true)
public class LexiconProductSearchServiceImpl implements LexiconProductSearchService{
    private LexiconProductSearch lexiconProductSearch;

    @Override
    @ProfileLogging

    public ProductSearchResults productSearch(@WebParam(name = "searchCriteria") LexiconProductSearchCriteria productSearchCriteria, @WebParam(name = "pageSize") int pageSize, @WebParam(name = "pageNumber") int pageNumber) {
        return lexiconProductSearch.productSearch(productSearchCriteria,pageSize,pageNumber);
    }

    @Override
    @ProfileLogging

    public ProductStageSearchResults productStageSearch(@WebParam(name = "searchCriteria") LexiconProductSearchCriteria productSearchCriteria, @WebParam(name = "pageSize") int pageSize, @WebParam(name = "pageNumber") int pageNumber) {
        return lexiconProductSearch.productStageSearch(productSearchCriteria,pageSize,pageNumber);
    }

    @Override
    @ProfileLogging
   
    public List<Product> productSearch(@WebParam(name = "searchCriteria") LexiconProductSearchCriteria productSearchCriteria)  throws TooManyResultsException {
         return lexiconProductSearch.productSearch(productSearchCriteria);
    }

    public void setLexiconProductSearch(LexiconProductSearch lexiconProductSearch) {
        this.lexiconProductSearch = lexiconProductSearch;
    }
}
