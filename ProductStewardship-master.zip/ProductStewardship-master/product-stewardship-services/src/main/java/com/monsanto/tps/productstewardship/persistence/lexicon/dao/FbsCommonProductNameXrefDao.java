package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 18, 2011
 * Time: 1:33:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FbsCommonProductNameXrefDao extends GenericDao<FbsCommonProductNameXrefEntity,String> {
}
