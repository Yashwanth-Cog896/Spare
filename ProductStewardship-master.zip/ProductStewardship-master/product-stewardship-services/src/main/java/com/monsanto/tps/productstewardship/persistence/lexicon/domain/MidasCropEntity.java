/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

/* vvkalu - 6/23/11 */
@Entity
@Table(name = "CROP", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasCropEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "CROP_ID", precision = 0, length = 22)
    private long id;
    @Column(name = "NAME", length = 50, nullable = true)
    private String cropName;
    @Type(type="true_false")
    @Column(name = "REF_ACTIVE", nullable = false)
    private boolean refActive;

    @Column(name = "REM_CROP_ID", nullable = false, length = 2)
    private String remCropId;
    @Column(name = "GENUS_SPECIES", nullable = false, length = 2)
    private String genusSpecies;
    @Column(name = "RM_MIN", nullable = false, precision = 6, scale = 1)
    private BigDecimal rmMin;
    @Column(name = "RM_MAX", nullable = false, precision = 6, scale = 1)
    private BigDecimal rmMax;
    @Column(name = "RM_INCREMENT", nullable = false, precision = 7, scale = 2)
    private BigDecimal rmIncrement;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getRemCropId() {
        return remCropId;
    }

    public void setRemCropId(String remCropId) {
        this.remCropId = remCropId;
    }

    public String getGenusSpecies() {
        return genusSpecies;
    }

    public void setGenusSpecies(String genusSpecies) {
        this.genusSpecies = genusSpecies;
    }

    public BigDecimal getRmMin() {
        return rmMin;
    }

    public void setRmMin(BigDecimal rmMin) {
        this.rmMin = rmMin;
    }

    public BigDecimal getRmMax() {
        return rmMax;
    }

    public void setRmMax(BigDecimal rmMax) {
        this.rmMax = rmMax;
    }

    public BigDecimal getRmIncrement() {
        return rmIncrement;
    }

    public void setRmIncrement(BigDecimal rmIncrement) {
        this.rmIncrement = rmIncrement;
    }
}