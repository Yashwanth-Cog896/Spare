package com.monsanto.util.service;

import org.apache.commons.codec.binary.Base64;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: Oct 19, 2010
 * Time: 10:03:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class WebMethodsConnectionPreparer extends BasicPostConnectionPreparer {

    private final  String usernamePassword;
    public WebMethodsConnectionPreparer(String usernamePassword){
        this.usernamePassword=usernamePassword;
    }
    public HttpURLConnection prepareConnection(final HttpURLConnection conn) throws IOException {
        super.prepareConnection(conn);
        conn.setRequestProperty("Connection", "Keep-Alive");
        conn.setRequestProperty("Authorization", "Basic " + createdEncodedUserNamePassword());
        return conn;
    }

    private String retrieveUserNamePassword() {
        return usernamePassword;
    }

    private String createdEncodedUserNamePassword() {
        String userPassword = retrieveUserNamePassword();
        String encoded = Base64.encodeBase64String(userPassword.getBytes());
        //TODO -WARNING Delete line this removing on the last two characters when updating to commons-codec 1.6
        encoded = encoded.substring(0, encoded.length() - 2);//Remove trailing CRLF
        return encoded;
    }
}
