package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 1:39:24 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "countryIdGenerator",allocationSize = 1,sequenceName = "Lexicon.COUNTRY_ID_SEQ")
@Table(name = "COUNTRY", schema = "Lexicon")
public class LexiconCountryEntity  implements Serializable {
    @Id
    @Column(name="COUNTRY_ID")
    @GeneratedValue(generator = "countryIdGenerator")
    private long id;
    @Column(name="COUNTRY_PUBKEY",nullable = false,length = 20)
    private String pubkey;
    @Column(name="COUNTRY_ABBR",nullable = false,length = 3)
    private String abbreviation;
    @Column(name="COUNTRY_NAME",nullable =false, length=80)
    private String name;
    @Column(name="ISO_CODE",nullable=false, length=2)
    private String isoCode;
    @Column(name="UN_CODE",nullable = false, length=3)
    private long unCode;
    @Column(name="SUB_COUNTRY_LABEL",nullable = true,length = 50)
    private String subCountry;
    @Column(name="SUB_SUB_COUNTRY_LABEL",nullable = true,length=50)
    private String subsubCountry;
    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE")
    private boolean logicalDelete;

    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH, CascadeType.DETACH},orphanRemoval = false,fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_COUNTRY_PUBKEY",referencedColumnName="COUNTRY_PUBKEY", updatable = false)
    private Set<FbsCommonCountryXrefEntity> fbsCommonCountryXrefs = new HashSet<FbsCommonCountryXrefEntity>();
    
    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIsoCode() {
        return isoCode;
    }

    public void setIsoCode(String isoCode) {
        this.isoCode = isoCode;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public String getSubCountry() {
        return subCountry;
    }

    public void setSubCountry(String subCountry) {
        this.subCountry = subCountry;
    }

    public String getSubsubCountry() {
        return subsubCountry;
    }

    public void setSubsubCountry(String subsubCountry) {
        this.subsubCountry = subsubCountry;
    }

    public long getUnCode() {
        return unCode;
    }

    public void setUnCode(long unCode) {
        this.unCode = unCode;
    }

    public Set<FbsCommonCountryXrefEntity> getFbsCommonCountryXrefs() {
        return fbsCommonCountryXrefs;
    }

    public void setFbsCommonCountryXrefs(Set<FbsCommonCountryXrefEntity> fbsCommonCountryXrefs) {
        this.fbsCommonCountryXrefs = fbsCommonCountryXrefs;
    }
}
