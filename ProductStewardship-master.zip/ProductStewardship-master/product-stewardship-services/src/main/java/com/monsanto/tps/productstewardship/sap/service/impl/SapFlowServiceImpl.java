package com.monsanto.tps.productstewardship.sap.service.impl;

import com.monsanto.tps.productstewardship.sap.business.SapFlow;
import com.monsanto.tps.productstewardship.sap.service.SapFlowService;

public class SapFlowServiceImpl implements SapFlowService {
    private SapFlow sapFlow;
    @Override
    public void flowVegetableChangesToSap() {
       sapFlow.flowVegetableChangesToSap();
    }

    public void setSapFlow(SapFlow sapFlow) {
        this.sapFlow = sapFlow;
    }
}
