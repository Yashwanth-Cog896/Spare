package com.monsanto.tps.productstewardship.productedit.business.product.rules;


import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class PCNameValueValidRule implements ValidationSimpleRule<ProductValidationModel> {
     public static final int MAX_SIZE = 30;
    @Override
    public void validate(ProductValidationModel model, ValidationStatus status) {
        if(criteriaViolated(model.getProduct().getPreCommercialName())){
            status.addCondition(new ValidationResult(ProductEditService.INVALID_PC_NAME_CODE, ValidationSeverity.ERROR));
        }
    }

   protected boolean criteriaViolated(String precommercialName) {
      return valueIsEmpty(precommercialName) || valueTooLarge(precommercialName) || hasInvalidCharacters(precommercialName);
   }

   private boolean valueIsEmpty(String precommercialName) {
      return StringUtils.isBlank(precommercialName);
   }

   private boolean valueTooLarge(String precommercialName) {
      return precommercialName.length() > MAX_SIZE;
   }

   private boolean hasInvalidCharacters(String precommercialName) {
      return !precommercialName.matches("[a-zA-Z0-9\\-]+");
   }
}
