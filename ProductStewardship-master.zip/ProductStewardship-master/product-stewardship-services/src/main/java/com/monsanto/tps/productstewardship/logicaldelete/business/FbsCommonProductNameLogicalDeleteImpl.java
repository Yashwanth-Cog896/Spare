package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageAuditDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageSeedProductDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

import java.util.Date;

public class FbsCommonProductNameLogicalDeleteImpl implements FbsCommonProductNameLogicalDelete {
    private FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao;
    private MirageAuditDao mirageAuditDao;

    public void logicalDelete(FbsCommonProductNameXrefEntity productNameXref) {

        MidasProductNameEntity midasProductName = productNameXref.getMidasProductName();
        if(midasProductName!=null){
            midasProductName.setRefActive(false);
        }
        disableMirageSeedProduct(productNameXref);
        fbsCommonProductNameXrefDao.delete(productNameXref);

    }

    private void disableMirageSeedProduct(FbsCommonProductNameXrefEntity productNameXref) {
        if(productNameXref.getMirageSeedProduct()!=null){
            MirageSeedProductEntity mirageSeedProduct = productNameXref.getMirageSeedProduct();
            mirageSeedProduct.setDisabledDate(new Date());
            mirageSeedProduct.setEnabled(false);
            mirageSeedProduct.setAudit(mirageAuditDao.createAudit(MirageAuditDao.UPDATE_SP_EVENT));
        }
    }

    public void setFbsCommonProductNameXrefDao(FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao) {
        this.fbsCommonProductNameXrefDao = fbsCommonProductNameXrefDao;
    }

    public void setMirageAuditDao(MirageAuditDao mirageAuditDao) {
        this.mirageAuditDao = mirageAuditDao;
    }


}