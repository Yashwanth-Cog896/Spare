package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.brand;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class BrandValidRule  implements ValidationSimpleRule<StageValidationModel> {
    private LexiconBrandDao lexiconBrandDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        if((StringUtils.isBlank(model.getProductStage().getBrandName()))|| brandNotFound(model.getProductStage())){
             status.addCondition(new ValidationResult(ProductEditService.INVALID_BRAND_CODE, ValidationSeverity.ERROR));
        }
    }

    private boolean brandNotFound(ProductStage model) {
        LexiconBrandEntity brand = lexiconBrandDao.getByName(model.getBrandName());
        return (brand==null||!brand.isActive());
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }
}
