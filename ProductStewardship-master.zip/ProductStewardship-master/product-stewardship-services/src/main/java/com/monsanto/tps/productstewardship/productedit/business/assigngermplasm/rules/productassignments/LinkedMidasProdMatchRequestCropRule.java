package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.productassignments;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapCropMirageEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class LinkedMidasProdMatchRequestCropRule implements ValidationSimpleRule<Product> {
    private MidasCropDao midasCropDao;
    private LexiconProductDao lexiconProductDao;
    @Override
    public void validate(Product model, ValidationStatus status) {
        MapCropMirageEntity mapCropMirage = midasCropDao.findMapCropMirage(model.getLexiconCropName());
        LexiconProductEntity lexiconProduct = lexiconProductDao.getByPreCommercialName(model.getPreCommercialName());

        if((mapCropMirage!=null)&&(lexiconProduct!=null)&&
                (lexiconProduct.getFbsCommonProductXref()!=null)&&
            (!Long.valueOf(lexiconProduct.getFbsCommonProductXref().getMidasProduct().getMidasCrop().getId()).equals(mapCropMirage.getMidasCropId()))){
                   status.addCondition(new ValidationResult(ProductEditService.LINKED_MIDAS_PROD_CROP_MISMATCH_CODE, ValidationSeverity.ERROR));
        }
    }

    public void setMidasCropDao(MidasCropDao midasCropDao) {
        this.midasCropDao = midasCropDao;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
