package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Jul 13, 2007
 * Time: 6:07:18 PM
 */
public interface Serializer<T>
{
   void registerMappings(XmlSerializerBuilder builder);
   Document toDocument(T object) throws SerializationException;
   T fromDocument(Document doc) throws DeserializationException;
}