package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationRulesAggregate;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageAuditDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageSeedProductDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import org.springframework.transaction.annotation.Transactional;

import javax.jws.WebParam;
import java.util.ArrayList;
import java.util.List;

public class ProductEditBusinessImpl implements ProductEditBusiness {
    private MidasCropDao midasCropDao;
    private MirageAuditDao mirageAuditDao;
    private MirageSeedProductDao mirageSeedProductDao;
    private LexiconProductDao lexiconProductDao;
    private ExceptionCodeDao exceptionCodeDao;
    private LexiconProductStageDao lexiconProductStageDao;
    private ProductClassificationDao productClassificationDao;
    private SupplyChainOwnerGroupDao supplyChainOwnerGroupDao;
    private ProductStageEditBusiness productStageEditBusiness;

    public void setEditProductStageValidation(ValidationRulesAggregate<StageValidationModel> editProductStageValidation) {
        this.editProductStageValidation = editProductStageValidation;
    }

    private ValidationRulesAggregate<ProductValidationModel> editGlobalPcNamesValidation;
    private ValidationRulesAggregate<StageValidationModel> editProductStageValidation;
    private ValidationRulesAggregate<StageValidationModel> addProductStageValidation;
    
    public static final String MONSANTO = "MONSANTO";

    @Transactional
    @Override
    public boolean validate(List<Product> products) {
        boolean hasError  = false;
        for(Product product:products){
           ValidationStatus productValidationStatus = new ValidationStatus();
           editGlobalPcNamesValidation.validate(new ProductValidationModel(products,product),productValidationStatus);
           hasError |= productValidationStatus.hasSeverity(ValidationSeverity.ERROR);
           product.setValidationResults(extractValidationResults(productValidationStatus));
           for(ProductStage productStage: product.getProductStages()){
                 ValidationStatus productStageValidationStatus = new ValidationStatus();
                 if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
                    editProductStageValidation.validate(new StageValidationModel(products,product,productStage),productStageValidationStatus);
                 }
                 else {
                    addProductStageValidation.validate(new StageValidationModel(products,product,productStage),productStageValidationStatus);
                 }
                 productStage.setValidationResults(extractValidationResults(productStageValidationStatus));
                 hasError |= productStageValidationStatus.hasSeverity(ValidationSeverity.ERROR);
           }
        }
        return !hasError;
    }
    private List<ValidationResult> extractValidationResults(ValidationStatus validationStatus) {
        List<ValidationResult> validationResults = new ArrayList<ValidationResult>();
        for(ValidationSeverity severity: ValidationSeverity.values()){
             validationResults.addAll(validationStatus.getResults(severity));
        }
        return validationResults;
    }    
    @Override
    @Transactional
    @AuditStage(processName = "Edit Products", auditComment = "Edit Products Save")
    public List<Product> editProducts(List<Product> products) {
       for(Product product: products){
           LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(product.getProductPubkey());
           if(!lexiconProduct.getPreCommercialName().equals(product.getPreCommercialName())){
              lexiconProduct.setExceptionCode(updateExceptionKey( lexiconProduct.getLexiconCrop(),lexiconProduct.getPreCommercialName(), product.getPreCommercialName()));
              updateMatchingMiragePCProduct(product,lexiconProduct);
              updateMidasGlobalPCNames(product, lexiconProduct);
           }
           updateMidasProductDenomination(product, lexiconProduct);
           updateLexiconProduct(product, lexiconProduct);
           productStageEditBusiness.editProductStages(product,lexiconProduct);
       }
       return products;
    }

    private void updateMidasProductDenomination(Product product, LexiconProductEntity lexiconProduct) {
        if((lexiconProduct.getFbsCommonProductXref()!=null)&&(lexiconProduct.getFbsCommonProductXref().getMidasProduct()!=null)){
             MidasProductEntity midasProduct = lexiconProduct.getFbsCommonProductXref().getMidasProduct();
             midasProduct.setDenomination(product.getVarietyName());
        }
    }

    private void updateLexiconProduct(Product product, LexiconProductEntity lexiconProduct) {
        lexiconProduct.setPreCommercialName(product.getPreCommercialName());
        lexiconProduct.setProductClassification(getProductClassification( product.getProductClassificationCode()));
        lexiconProduct.setTagVarietyName(product.getVarietyName());
        lexiconProduct.setSupplyChainOwnerGroup(getSupplyChainOwnerGroup(product));
    }

    private SupplyChainOwnerGroupEntity getSupplyChainOwnerGroup(Product product) {
        return StringUtils.isBlank(product.getSupplyChainGroupOwnerCode())?null:supplyChainOwnerGroupDao.getByCode(product.getSupplyChainGroupOwnerCode());
    }

    private ProductClassificationEntity getProductClassification( String productClassificationCode) {
        return StringUtils.isBlank(productClassificationCode)?null:productClassificationDao.getByProductClassificationCode(productClassificationCode);
    }

    private ExceptionCodeEntity updateExceptionKey( LexiconCropEntity lexiconCrop, String oldProductName,String newProductName) {

        if(lexiconCrop.getStageCategory().getName().equals(StageCategoryEntity.VEGETABLE)){
            ExceptionCodeEntity existingExceptionCode = exceptionCodeDao.getByProductName(newProductName, lexiconCrop.getId());
            if(existingExceptionCode!=null){
                return existingExceptionCode;
            }
            else {
                ExceptionCodeEntity oldExceptionCodeEntity = exceptionCodeDao.getByProductName(oldProductName, lexiconCrop.getId());
                if(oldExceptionCodeEntity==null|| commercialNamesUseExceptionCode(oldProductName, lexiconCrop)){
                    return createNewExceptionCode(lexiconCrop, newProductName);
                }
                else {
                    oldExceptionCodeEntity.setProductName(newProductName);
                    return oldExceptionCodeEntity;
                }
            }
        }
        else {
            return null;
        }
    }

    private ExceptionCodeEntity createNewExceptionCode(LexiconCropEntity lexiconCrop, String productName) {
        ExceptionCodeEntity exceptionCode = new ExceptionCodeEntity();
        exceptionCode.setLexiconCrop(lexiconCrop);
        exceptionCode.setProductName(productName);
        exceptionCode.setExceptionCode(exceptionCodeDao.getNextExceptionCode());
        exceptionCode.setPrimary(false);
        exceptionCodeDao.saveOrUpdate(exceptionCode);
        return exceptionCode;
    }

    private boolean commercialNamesUseExceptionCode(String newName, LexiconCropEntity lexiconCrop) {
        return (!lexiconProductStageDao.findByCommercialNameAndCrop(newName, lexiconCrop.getId()).isEmpty());
    }

    private void updateMidasGlobalPCNames(Product product, LexiconProductEntity lexiconProduct) {
        if((lexiconProduct.getFbsCommonProductXref()!=null)&&(lexiconProduct.getFbsCommonProductXref().getMidasProduct()!=null)){
            MidasProductEntity midasProduct = lexiconProduct.getFbsCommonProductXref().getMidasProduct();
            for(MidasProductNameEntity midasProductName:  midasProduct.getMidasProductNames()){
                if(midasProductName.getMidasBrand().getName().equals(MONSANTO)){
                   midasProductName.setName(product.getPreCommercialName());
                }
            }
        }
    }

    private void updateMatchingMiragePCProduct(Product product, LexiconProductEntity lexiconProduct){
        MapCropMirageEntity mapCropMirage = midasCropDao.findMapCropMirage(product.getLexiconCropName());
        if((mapCropMirage!=null)&&(StringUtils.isNotBlank(mapCropMirage.getMirageBayerCode()))){
            MirageSeedProductEntity mirageSeedProduct = mirageSeedProductDao.findByPreComlProductByNameAndBayerCode(lexiconProduct.getPreCommercialName(),mapCropMirage.getMirageBayerCode());
            if(mirageSeedProduct!=null){
                mirageSeedProduct.setAudit(mirageAuditDao.createAudit(MirageAuditDao.UPDATE_SP_EVENT));
                mirageSeedProduct.setName(product.getPreCommercialName());
            }
        }
    }

    public void setExceptionCodeDao(ExceptionCodeDao exceptionCodeDao) {
        this.exceptionCodeDao = exceptionCodeDao;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }

    public void setMidasCropDao(MidasCropDao midasCropDao) {
        this.midasCropDao = midasCropDao;
    }

    public void setMirageAuditDao(MirageAuditDao mirageAuditDao) {
        this.mirageAuditDao = mirageAuditDao;
    }

    public void setMirageSeedProductDao(MirageSeedProductDao mirageSeedProductDao) {
        this.mirageSeedProductDao = mirageSeedProductDao;
    }

    public void setProductClassificationDao(ProductClassificationDao productClassificationDao) {
        this.productClassificationDao = productClassificationDao;
    }

    public void setSupplyChainOwnerGroupDao(SupplyChainOwnerGroupDao supplyChainOwnerGroupDao) {
        this.supplyChainOwnerGroupDao = supplyChainOwnerGroupDao;
    }

    public void setProductStageEditBusiness(ProductStageEditBusiness productStageEditBusiness) {
        this.productStageEditBusiness = productStageEditBusiness;
    }

    public void setEditGlobalPcNamesValidation(ValidationRulesAggregate<ProductValidationModel> editGlobalPcNamesValidation) {
        this.editGlobalPcNamesValidation = editGlobalPcNamesValidation;
    }

    public void setAddProductStageValidation(ValidationRulesAggregate<StageValidationModel> addProductStageValidation) {
        this.addProductStageValidation = addProductStageValidation;
    }
}
