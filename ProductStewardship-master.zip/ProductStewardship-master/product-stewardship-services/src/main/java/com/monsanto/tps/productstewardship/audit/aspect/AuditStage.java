package com.monsanto.tps.productstewardship.audit.aspect;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * rrchak1 - Oct 23, 2008 11:46:09 AM
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface AuditStage
{
   String processName();
   String auditComment() default "";
   String auditRequestor() default "";
}
