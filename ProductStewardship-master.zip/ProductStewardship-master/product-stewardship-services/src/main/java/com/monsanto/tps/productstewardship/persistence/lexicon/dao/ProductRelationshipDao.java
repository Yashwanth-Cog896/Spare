/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;

import java.util.*;

/* vvkalu - 7/19/11 */
public interface ProductRelationshipDao extends GenericDao<ProductRelationshipEntity,Long> {
    @DynamicDaoMethod(queryName = "productRelationshipPubkeySeq")
    public String getRelationshipPubkey();

  @DynamicDaoMethod(queryName = "ProductRelationshipEntity.getByManufacturingName",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public ProductRelationshipEntity getByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);

   @DynamicDaoMethod(queryName = "ProductRelationshipEntity.findSubscribedProductRelationships",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<ProductRelationshipEntity> findSubscribedProductRelationships(@DynamicDaoParameter(name = "requestId") long requestId,
                                                                              @DynamicDaoParameter(name = "externalSystemName") String externalSystemName);
}