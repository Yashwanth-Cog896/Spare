package com.monsanto.tps.productstewardship.comments.business;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalComments;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 5, 2011
 * Time: 10:01:30 AM
 * To change this template use File | Settings | File Templates.
 */

public class ProductAdditionalCommentsBusinessImpl implements ProductAdditionalCommentsBusiness {
    private LexiconProductDao lexiconProductDao;

    private UserPrivilegesService userPrivilegesService;

    private UserProfile userProfile;

    @Override
    public List<ProductAdditionalCommentsSearchResult> findProductAdditionalComments(List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops) {
        List<ProductAdditionalCommentsSearchResult> pacs = buildAdditionalCommentsSearchResults(lexiconProductDao.findByAdditionalCommentsCriteria(userPrivilegesService.getCrops(userProfile.getUserName()),productNames, nameType, crops));
        return pacs;  
    }

    private List<ProductAdditionalCommentsSearchResult> buildAdditionalCommentsSearchResults(List<LexiconProductEntity> products) {
        List<ProductAdditionalCommentsSearchResult> pacs = new ArrayList<ProductAdditionalCommentsSearchResult>();
        for(LexiconProductEntity product: products){
            ProductAdditionalCommentsSearchResult pac = new ProductAdditionalCommentsSearchResult();
            pac.setAdditionalComments(product.getAdditionalComments());
            pac.setProductPubkey(product.getPubkey());
            pac.setCrop(product.getLexiconCrop().getName());
            pac.setPreCommercialName(product.getPreCommercialName());
            pac.setVarietyName(product.getTagVarietyName());
            pacs.add(pac);
        }
        return pacs;
    }

    @Override
    @AuditStage(processName = "Additional Comments Save", auditComment = "Additional Comments Save")
    public void saveProductAdditionalComments(List<ProductAdditionalComments> productAdditionalComments) {
        for(ProductAdditionalComments pac: productAdditionalComments){
            LexiconProductEntity product = lexiconProductDao.getByPubkey(pac.getProductPubkey());
            product.setAdditionalComments(pac.getAdditionalComments());
        }
    }

    @Override
    public Long countProductAdditionalComments(List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops) {
        return lexiconProductDao.countAdditionalCommentsCriteria(userPrivilegesService.getCrops(userProfile.getUserName()),productNames, nameType,crops);
    }

    @Override
    public List<ProductAdditionalCommentsSearchResult> findPagedProductAdditionalComments(List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops, int pageSize, int pageNumber) {
        return buildAdditionalCommentsSearchResults(lexiconProductDao.findPagedByAdditionalCommentsCriteria(userPrivilegesService.getCrops(userProfile.getUserName()),productNames, nameType, crops,pageSize,pageNumber));
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setUserPrivilegesService(UserPrivilegesService userPrivilegesService) {
        this.userPrivilegesService = userPrivilegesService;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
}
