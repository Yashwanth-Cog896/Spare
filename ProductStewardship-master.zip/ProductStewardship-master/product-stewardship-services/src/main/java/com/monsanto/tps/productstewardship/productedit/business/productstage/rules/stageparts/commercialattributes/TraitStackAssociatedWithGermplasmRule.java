package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.tps.lexicon.eventtraitservice.GermplasmEventTraitService;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductGermplasmEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductGermplasm;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TraitStackAssociatedWithGermplasmRule implements ValidationSimpleRule<StageValidationModel> {
    private CommercialTraitStackDao commercialTraitStackDao;
    private GermplasmEventTraitService germplasmEventTraitService;
    private LexiconProductDao lexiconProductDao;

    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        Set<Long> traitStackIds = getGermplasmIds(model);
        String comlTraitName = model.getProductStage().getComlTraitName();
        if(StringUtils.isNotBlank(comlTraitName)){
        List<CommercialTraitStackEntity> stacks = commercialTraitStackDao.getByTraitNameAndCrop(comlTraitName,model.getProduct().getLexiconCropName());
         if(!stacks.isEmpty()){
             if(!traitStackIds.contains(stacks.get(0).getId())){
                status.addCondition(new ValidationResult(ProductEditService.TRAIT_STACK_NOT_ASSOCIATED_WITH_GERMPLASM_CODE, ValidationSeverity.INFO)); 
              }
            }
        }
    }

    private Set<Long> getGermplasmIds(StageValidationModel model) {
        Set<Long> germplasmIds = new HashSet<Long>();
        List<ProductGermplasm> productGermplasms = model.getProduct().getAssignedGermplasms();
        for(ProductGermplasm productGermplasm: productGermplasms){
            germplasmIds.add(productGermplasm.getGermplasmId());
        }
        if(StringUtils.isNotBlank(model.getProduct().getProductPubkey())){
            LexiconProductEntity lexiconProduct= lexiconProductDao.getByPubkey(model.getProduct().getProductPubkey());
            if(lexiconProduct!=null){
                for(ProductGermplasmEntity pge: lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()){
                    GermplasmEntity germplasm = pge.getGermplasm();
                    if(!germplasm.isDeleted()){
                        germplasmIds.add(germplasm.getId());
                    }
                }
            }
        }
        Set<Long> traitStackIds = new HashSet<Long>();
        for(Long germplasmId: germplasmIds){
           List<Long> traitStackIdsForGermplasm = germplasmEventTraitService.getComTraitStackIdByEventConstructs(germplasmId);
           if(traitStackIdsForGermplasm!=null){
               traitStackIds.addAll(traitStackIdsForGermplasm);
           }
        }
        return traitStackIds;
    }

    public void setCommercialTraitStackDao(CommercialTraitStackDao commercialTraitStackDao) {
        this.commercialTraitStackDao = commercialTraitStackDao;
    }



    public void setGermplasmEventTraitService(GermplasmEventTraitService germplasmEventTraitService) {
        this.germplasmEventTraitService = germplasmEventTraitService;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
