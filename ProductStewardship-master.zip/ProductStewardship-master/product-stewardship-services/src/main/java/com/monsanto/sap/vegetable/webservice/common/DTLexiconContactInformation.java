package com.monsanto.sap.vegetable.webservice.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * <p/>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p/>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "contactName",
        "contactDescription",
        "contactPhoneNumber",
        "emailAddress"
})
public class DTLexiconContactInformation {

    @XmlElement(name = "ContactName")
    private String contactName;
    @XmlElement(name = "ContactDescription")
    private String contactDescription;
    @XmlElement(name = "ContactPhoneNumber")
    private String contactPhoneNumber;
    @XmlElement(name = "EmailAddress")
    private String emailAddress;

    /**
     * Gets the value of the contactName property.
     *
     * @return possible object is
     *         {@link String }
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Sets the value of the contactName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactName(String value) {
        this.contactName = value;
    }

    /**
     * Gets the value of the contactDescription property.
     *
     * @return possible object is
     *         {@link String }
     */
    public String getContactDescription() {
        return contactDescription;
    }

    /**
     * Sets the value of the contactDescription property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactDescription(String value) {
        this.contactDescription = value;
    }

    /**
     * Gets the value of the contactPhoneNumber property.
     *
     * @return possible object is
     *         {@link String }
     */
    public String getContactPhoneNumber() {
        return contactPhoneNumber;
    }

    /**
     * Sets the value of the contactPhoneNumber property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactPhoneNumber(String value) {
        this.contactPhoneNumber = value;
    }

    /**
     * Gets the value of the emailAddress property.
     *
     * @return possible object is
     *         {@link String }
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

}
