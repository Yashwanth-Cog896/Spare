package com.monsanto.util.service;

import com.sun.org.apache.xerces.internal.impl.PropertyManager;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: Oct 19, 2010
 * Time: 10:02:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class WebMethodsServiceURLProvider implements ServiceURLProvider {
    private final String urlBase;
    private final String urlPath;

    public WebMethodsServiceURLProvider(String urlBase,String urlPath){
        this.urlBase = urlBase;
        this.urlPath = urlPath;
    }

    public String getServiceURL() throws IOException {
        return urlBase + "/" + urlPath;
    }

}
