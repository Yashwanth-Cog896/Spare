package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.brand;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class PCBrandForComlStageRule implements ValidationSimpleRule<StageValidationModel> {
    public static final String PRE_COML_BRAND = "MONSANTO";

    private LexiconStageDao lexiconStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        LexiconStageEntity lexiconStage = lexiconStageDao.findStageByAbbreviation(model.getProductStage().getStageAbbreviation());
        if((lexiconStage!=null)&& isCommercialStage(lexiconStage) && isPrecommercialBrand(model.getProductStage())){
            status.addCondition(new ValidationResult(ProductEditService.PC_BRAND_FOR_COML_STAGE_CODE, ValidationSeverity.ERROR));
        }
    }

    private boolean isCommercialStage(LexiconStageEntity lexiconStage) {
        return lexiconStage.isCommercial();
    }

    private boolean isPrecommercialBrand(ProductStage model) {
        return PRE_COML_BRAND.equalsIgnoreCase(model.getBrandName());
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
