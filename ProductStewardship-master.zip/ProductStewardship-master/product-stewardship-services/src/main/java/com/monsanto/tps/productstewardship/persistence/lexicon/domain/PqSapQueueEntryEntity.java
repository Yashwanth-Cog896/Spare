package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 18, 2011
 * Time: 2:45:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PQ_SAP_PRODUCT", schema = "LEXICON")
@SequenceGenerator(name = "pqSapProductIdGenerator",allocationSize = 1,sequenceName = "Lexicon.pq_sap_product_id_seq")
public  class PqSapQueueEntryEntity {
    public static final String PRE_COML_PRODUCT= "PRE_COML_PRODUCT";
    public static final String PRODUCT_STAGE = "PRODUCT_STAGE";
    public static final String PRODUCT_RELATIONSHIP_XREF = "PRODUCT_RELATIONSHIP_XREF";
    public static final String PRODUCT_RELATIONSHIP = "PRODUCT_RELATIONSHIP";
    public static final String BASE_PRODUCT = "BASE_PRODUCT";
    @Id
    @Column(name="PQ_SAP_PRODUCT_ID")
    @GeneratedValue(generator = "pqSapProductIdGenerator")
    private long id;
    @Column(name="SHOULD_PROCESS",nullable = false)
    @Type(type = "boolean-yn")
    private boolean shouldProcess;
    @Column(name="INIT_TMSTP",nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date  initDate;
    
    @Column(name="TABLE_NAME",length = 30,nullable = false)
    private String tableName;

    @Column(name = "TABLE_ID",nullable = false)
    private long tableId;

    @Column(name="PQ_SAP_PROCESS_TYPE",nullable = false)
    @Enumerated(EnumType.STRING)
    private PqSapProcessType processType;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getInitDate() {
        return initDate;
    }

    public void setInitDate(Date initDate) {
        this.initDate = initDate;
    }

    public boolean isShouldProcess() {
        return shouldProcess;
    }

    public void setShouldProcess(boolean shouldProcess) {
        this.shouldProcess = shouldProcess;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public long getTableId() {
        return tableId;
    }

    public void setTableId(long tableId) {
        this.tableId = tableId;
    }

    public PqSapProcessType getProcessType() {
        return processType;
    }

    public void setProcessType(PqSapProcessType processType) {
        this.processType = processType;
    }
}
