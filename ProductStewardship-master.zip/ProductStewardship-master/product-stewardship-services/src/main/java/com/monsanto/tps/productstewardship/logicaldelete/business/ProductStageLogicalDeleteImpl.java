package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 14, 2011
 * Time: 1:26:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStageLogicalDeleteImpl implements ProductStageLogicalDelete {
    private LexiconProductStageDao lexiconProductStageDao;

    private FbsCommonProductNameLogicalDelete fbsCommonProductNameLogicalDelete;

    public void logicallyDeleteProductStages(List<String> productStagePubkeys) {
        for (String productStagePubkey : productStagePubkeys) {
            LexiconProductStageEntity productStage = lexiconProductStageDao.getByPubkey(productStagePubkey);
            if (productStage != null) {
                logicallyDeleteProductStage(productStage);
            } 
        }
    }

    private void logicallyDeleteProductStage(LexiconProductStageEntity productStage) {
        productStage.setLogicalDelete(true);
        FbsCommonProductNameXrefEntity productNameXref = productStage.getFbsCommonProductNameXref();
        productStage.setFbsCommonProductNameXref(null);
        fbsCommonProductNameLogicalDelete.logicalDelete(productNameXref);

        boolean allDeleted = true;
        for (LexiconProductStageEntity otherProductStage : productStage.getLexiconProduct().getLexiconProductStages()) {
            allDeleted &= otherProductStage.isLogicalDelete();
        }
        if (allDeleted) {
            for (MidasProductNameEntity midasProductName :productNameXref.getMidasProductName().getMidasProduct().getMidasProductNames()) {
                if ((midasProductName.getMidasBrand().getName().equals(MidasBrandEntity.MONSANTO_BRAND))&&
                      midasProductName.getName().equals(productStage.getLexiconProduct().getPreCommercialName())){ //TODO: Ask Chidi: DO we need to compare to pre-commercial name or brand since they should all be inactive anyway?
                    midasProductName.setRefActive(false);
                }
            }
        }
    }

    public void setFbsCommonProductNameLogicalDelete(FbsCommonProductNameLogicalDelete fbsCommonProductNameLogicalDelete) {
        this.fbsCommonProductNameLogicalDelete = fbsCommonProductNameLogicalDelete;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }
}
