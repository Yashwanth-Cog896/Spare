package com.monsanto.tps.productstewardship.comments.service.impl;


import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.productstewardship.comments.business.ProductAdditionalCommentsBusiness;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalComments;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsService;
import org.springframework.transaction.annotation.Transactional;

import javax.jws.WebParam;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 5, 2011
 * Time: 9:48:06 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public class ProductAdditionalCommentsServiceImpl implements ProductAdditionalCommentsService {

    private ProductAdditionalCommentsBusiness productBusiness;
    
    @Override
    @ProfileLogging
    public List<ProductAdditionalCommentsSearchResult> findProductAdditionalComments(List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops) {
        return productBusiness.findProductAdditionalComments(productNames,nameType,crops);
    }

    @Override
    @ProfileLogging
    @PerformanceMetric(task = "Additional Comments", comment = "save")
    public void saveProductAdditionalComments(@WebParam(name = "productAdditionalComments") List<ProductAdditionalComments> productAdditionalComments) {
         productBusiness.saveProductAdditionalComments(productAdditionalComments);
    }

    @Override
    @ProfileLogging
    public Long countProductAdditionalComments(@WebParam(name = "productNames") List<String> productNames, @WebParam(name = "nameType") ProductAdditionalCommentsNameType nameType, @WebParam(name = "crops") List<String> crops) {
        return productBusiness.countProductAdditionalComments(productNames,nameType,crops); 
    }

    @Override
    @ProfileLogging
    public List<ProductAdditionalCommentsSearchResult> findPagedProductAdditionalComments(@WebParam(name = "productNames") List<String> productNames, @WebParam(name = "nameType") ProductAdditionalCommentsNameType nameType, @WebParam(name = "crops") List<String> crops, @WebParam(name = "pageSize") Integer pageSize, @WebParam(name = "pageNumber") Integer pageNumber) {
        return productBusiness.findPagedProductAdditionalComments(productNames,nameType,crops,pageSize,pageNumber);
    }

    public void setProductBusiness(ProductAdditionalCommentsBusiness productBusiness) {
        this.productBusiness = productBusiness;
    }
}
