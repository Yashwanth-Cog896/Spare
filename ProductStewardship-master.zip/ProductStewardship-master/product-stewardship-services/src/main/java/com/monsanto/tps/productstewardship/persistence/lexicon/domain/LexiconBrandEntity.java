package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:21:26 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "lexiconBrandIdGenerator",allocationSize = 1,sequenceName = "Lexicon.BRAND_ID_SEQ")
@Table(name = "BRAND", schema = "Lexicon")
public class LexiconBrandEntity  implements Serializable {
    @Id
    @Column(name="BRAND_ID")
    @GeneratedValue(generator = "lexiconBrandIdGenerator" )
    private long id;

    @Column(name="BRAND_PUBKEY",nullable = false, length = 20)
    private String pubkey;

    @Column(name="BRAND_NAME",nullable = false, length=50)
    private String name;

    @Column(name="BRAND_ABBR",nullable = false,length = 20)
    private String abbreviation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="COMPANY_ID",nullable = false)
    private LexiconCompany lexiconCompany;

    @Type(type = "boolean-yn")
    @Column(name="IS_ACTIVE",nullable = false)
    private boolean active;

    @Type(type = "boolean-yn")
    @Column(name="TD_RESTRICTED",nullable = false)
    private boolean techDevRestricted;

    @Column(name="AUTO_NAME_BRAND_CODE",nullable = true, length=2)
    private String autoNameBrandCode;
   
    @OneToMany(cascade = {CascadeType.PERSIST,CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH, CascadeType.DETACH},orphanRemoval = false,fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_BRAND_PUBKEY",referencedColumnName="BRAND_PUBKEY", updatable = false)
    private Set<FbsCommonBrandXrefEntity> fbsCommonBrandXrefs = new HashSet<FbsCommonBrandXrefEntity>();

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCompany getLexiconCompany() {
        return lexiconCompany;
    }

    public void setLexiconCompany(LexiconCompany lexiconCompany) {
        this.lexiconCompany = lexiconCompany;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public boolean isTechDevRestricted() {
        return techDevRestricted;
    }

    public void setTechDevRestricted(boolean techDevRestricted) {
        this.techDevRestricted = techDevRestricted;
    }

    public String getAutoNameBrandCode() {
      return autoNameBrandCode;
    }

    public void setAutoNameBrandCode(String autoNameBrandCode) {
      this.autoNameBrandCode = autoNameBrandCode;
    }

    public Set<FbsCommonBrandXrefEntity> getFbsCommonBrandXrefs() {
        return fbsCommonBrandXrefs;
    }

    public void setFbsCommonBrandXrefs(Set<FbsCommonBrandXrefEntity> fbsCommonBrandXrefs) {
        this.fbsCommonBrandXrefs = fbsCommonBrandXrefs;
    }
}
