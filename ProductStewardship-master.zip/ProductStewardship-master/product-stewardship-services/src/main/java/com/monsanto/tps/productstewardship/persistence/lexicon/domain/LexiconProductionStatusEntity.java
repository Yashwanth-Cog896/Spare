package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:31:21 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCTION_STATUS", schema = "Lexicon")
public class LexiconProductionStatusEntity  implements Serializable {
    @Id
    @Column(name = "PRODUCTION_STATUS_ID")
    private long id;
    @Column(name="PRODUCTION_STATUS_NAME",nullable = true,length = 20)
    private String productionStatusName;
    @Column(name = "SOURCE_SYSTEM", nullable = false, length = 100)
    private String sourceSystem;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getProductionStatusName() {
        return productionStatusName;
    }

    public void setProductionStatusName(String productionStatusName) {
        this.productionStatusName = productionStatusName;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }
}
