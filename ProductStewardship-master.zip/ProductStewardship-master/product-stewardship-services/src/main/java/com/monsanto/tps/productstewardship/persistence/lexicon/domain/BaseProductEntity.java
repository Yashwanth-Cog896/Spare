package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableAlias;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:33:24 PM
 * To change this template use File | Settings | File Templates.
 */
@Filterable
@Entity
@SequenceGenerator(name = "baseProductIdGenerator",allocationSize = 1,sequenceName = "Lexicon.BASE_PRODUCT_ID_SEQ")
@Table(name = "BASE_PRODUCT", schema = "Lexicon")
public class BaseProductEntity  implements Serializable {
    @Id
    @Column(name="BASE_PRODUCT_ID")
    @GeneratedValue(generator = "baseProductIdGenerator")
    private Long id;
    @FilterableProperty(filterKey = "baseManufacturingName")
    @Column(name="BASE_MANUFACTURING_NAME",nullable = false, length = 50)
    private String baseManufacturingName;
    @FilterableAlias(alias="lexiconCrop")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="CROP_ID",nullable = false)
    private LexiconCropEntity lexiconCrop;
    @Type(type = "boolean-yn")
    @Column(name="PARENT_PRODUCT",nullable = true)
    private Boolean parentProduct;
    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = true)
    private Boolean logicalDelete;
    @OneToMany(mappedBy = "baseProduct", cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private List<ProductRelationshipEntity> productRelationships = new ArrayList<ProductRelationshipEntity>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public void setBaseManufacturingName(String baseManufacturingName) {
        this.baseManufacturingName = baseManufacturingName;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public Boolean getParentProduct() {
        return parentProduct;
    }

    public void setParentProduct(Boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    public Boolean getLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(Boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public List<ProductRelationshipEntity> getProductRelationships() {
        return productRelationships;
    }

    public void setProductRelationships(List<ProductRelationshipEntity> productRelationships) {
        this.productRelationships = productRelationships;
    }
}
