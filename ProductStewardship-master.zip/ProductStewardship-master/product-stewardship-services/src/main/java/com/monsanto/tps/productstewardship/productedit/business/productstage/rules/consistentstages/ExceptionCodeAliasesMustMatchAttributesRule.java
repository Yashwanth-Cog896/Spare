package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.consistentstages;

import org.apache.commons.lang.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.StageCategoryEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExceptionCodeAliasesMustMatchAttributesRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductStageDao lexiconProductStageDao;
    private LexiconCropDao lexiconCropDao;

    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean isValid = true;

        ProductStage productStage= model.getProductStage();
        Product product = model.getProduct();
        if(!productStage.isDelete()){
            LexiconCropEntity crop = lexiconCropDao.getByName(product.getLexiconCropName());
            boolean isVegetable =crop.getStageCategory().getName().equals(StageCategoryEntity.VEGETABLE);
            if(isVegetable){
               isValid = validateRequest(model.getProducts(),model.getProduct(),model.getProductStage());
               if(isValid){
                   isValid = validateAgainstDb(model, productStage, product);
               }
               if(!isValid){
                    status.addCondition(new ValidationResult(ProductEditService.VEGETABLE_PROD_REQ_SAME_ATTR_CODE, ValidationSeverity.ERROR));
               }
            }
        }
    }

    private boolean validateAgainstDb(StageValidationModel model,  ProductStage productStage, Product product) {
        boolean valid = true;
        for(LexiconProductStageEntity lexiconStage: fetchMatchingProductStagesNotInRequest(model.getProducts(),productStage, product)){
            if(!(productStage.getBrandName().equals(lexiconStage.getLexiconBrand().getName())&&
               (productStage.getStageAbbreviation().equals(lexiconStage.getLexiconStage().getAbbreviation())))){
                valid =false;
            }
         }
        return valid;
    }

    private Collection<LexiconProductStageEntity> fetchMatchingProductStagesNotInRequest(List<Product> products,ProductStage productStage, Product product) {
        
        Map<String,LexiconProductStageEntity> lexiconProductStageMap = new HashMap<String, LexiconProductStageEntity>();
        for(LexiconProductStageEntity lexiconProductStage:lexiconProductStageDao.findByMatchingProductNames(
                                             StringUtils.isNotBlank(productStage.getCommercialName())?productStage.getCommercialName():product.getPreCommercialName(),
                                             product.getLexiconCropName())){
            lexiconProductStageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
        }
        for(Product testProduct: products){
            for(ProductStage testProductStage: testProduct.getProductStages()){
                if(StringUtils.isNotBlank(testProductStage.getProductStagePubkey())){
                   lexiconProductStageMap.remove(testProductStage.getProductStagePubkey());
                }
            }
        }
        return lexiconProductStageMap.values();
    }

    public boolean validateRequest(List<Product> products,Product product, ProductStage stage){
        boolean isValid = true;
        String name = StringUtils.isNotBlank(stage.getCommercialName())? stage.getCommercialName():product.getPreCommercialName();
        out:
        for(Product testProduct:products){
            if(product.getLexiconCropName().equals(testProduct.getLexiconCropName())){
                for(ProductStage testStage: testProduct.getProductStages()){
                    if((testStage!=stage)&&(!testStage.isDelete())){
                        String testName= StringUtils.isNotBlank(testStage.getCommercialName())?testStage.getCommercialName():testProduct.getPreCommercialName();
                        if(StringUtils.equalsIgnoreCase(name,testName)&&
                           (!(StringUtils.equalsIgnoreCase(stage.getBrandName(),testStage.getBrandName())&&
                           StringUtils.equalsIgnoreCase(stage.getStageAbbreviation(),testStage.getStageAbbreviation())))){
                            isValid=false;
                            break out;
                        }
                    }
                }
            }
        }
        return isValid;
    }
    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }
}
