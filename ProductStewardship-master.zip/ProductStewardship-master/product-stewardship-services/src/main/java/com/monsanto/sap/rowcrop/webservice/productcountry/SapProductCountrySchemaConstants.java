package com.monsanto.sap.rowcrop.webservice.productcountry;

/**
 * nbwald Jul 11, 2007 4:46:31 PM
 */
public interface SapProductCountrySchemaConstants {
   String NAMESPACE = "http://www.monsanto.com/lexicon/SapProductCountry";
   String SCHEMA_LOC = "xsd/lexicon/xstream/SapProductCountry.xsd";
}