package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.Util.statistics.RangeCheck;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapCropMirageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasCropEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ComlMaturityInRangeRule  implements ValidationSimpleRule<StageValidationModel> {

    private MidasCropDao midasCropDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        if(StringUtils.isNotBlank(model.getProductStage().getCommercialMaturity())&&(StringUtils.isNotBlank(model.getProduct().getLexiconCropName()))){
            MidasCropEntity midasCropEntity = getMidasCrop(model);
            if((midasCropEntity!=null)&&(midasCropEntity.getRmMin().compareTo(midasCropEntity.getRmMax())<0)){
                RangeCheck rangeCheck = new RangeCheck(midasCropEntity.getRmMin().doubleValue(), midasCropEntity.getRmMax().doubleValue(), midasCropEntity.getRmIncrement().doubleValue());
                try {
                   if(!rangeCheck.inRange(Double.parseDouble(model.getProductStage().getCommercialMaturity())))
                   {
                       status.addCondition(new ValidationResult(ProductEditService.COML_MATRUITY_OUT_OF_RANGE_CODE, ValidationSeverity.ERROR));
                   }
                }
                catch (NumberFormatException nfe){
                    status.addCondition(new ValidationResult(ProductEditService.NON_NUMERIC_COML_MATURITY_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    private MidasCropEntity getMidasCrop(StageValidationModel model) {
        MidasCropEntity midasCropEntity =  null;
        MapCropMirageEntity mapCropMirage = midasCropDao.findMapCropMirage(model.getProduct().getLexiconCropName());
        if((mapCropMirage!=null)&&(mapCropMirage.getMidasCropId()!=null)){
             midasCropEntity = midasCropDao.get(mapCropMirage.getMidasCropId());
        }
        return midasCropEntity;
    }

    public void setMidasCropDao(MidasCropDao midasCropDao) {
        this.midasCropDao = midasCropDao;
    }
}
