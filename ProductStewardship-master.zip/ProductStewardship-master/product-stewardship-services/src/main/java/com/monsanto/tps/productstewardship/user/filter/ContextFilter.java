/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.filter;

/**
 * nbwald - Mar 31, 2009 9:24:32 AM
 */
public interface ContextFilter
{
   boolean appliesTo(String context);

   String parse(String context);
}