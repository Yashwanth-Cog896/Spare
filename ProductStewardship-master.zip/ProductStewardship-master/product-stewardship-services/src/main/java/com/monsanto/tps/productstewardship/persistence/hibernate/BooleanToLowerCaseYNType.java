package com.monsanto.tps.productstewardship.persistence.hibernate;

import org.hibernate.type.CharBooleanType;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 28, 2009
 * Time: 12:22:39 PM
 */
public class BooleanToLowerCaseYNType extends CharBooleanType{

   protected String getFalseString() {
      return "n";
   }

   protected String getTrueString() {
      return "y";
   }
}
