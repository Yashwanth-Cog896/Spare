package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapLogEntity;


public interface PqSapLogDao extends GenericDao<PqSapLogEntity,Long> {
    public static final int MAX_ERROR_MESSAGE_LENGTH = 4000;
}
