package com.monsanto.tps.productstewardship.blend.business;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 1, 2010
 * Time: 1:31:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlendedPreComlProduct {

    private String lexiconPubkey;
    private String preComlName;
    private Long midasProductId;

    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public Long getMidasProductId() {
        return midasProductId;
    }

    public void setMidasProductId(Long midasProductId) {
        this.midasProductId = midasProductId;
    }
}
