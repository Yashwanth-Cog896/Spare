/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProductSearchType;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;

import java.util.ArrayList;
import java.util.List;

/* vvkalu - 7/8/11 */
public class BaseProductSearchBusiness {

    private UserPrivilegesService userPrivilegesService;
    private UserProfile userProfile;
    private ManfNamesSearchBuilderFactory manfNamesSearchBuilderFactory;

    public List<BaseProduct> findBaseProducts(BaseProductSearchType searchType, List<String> names) {
        if(checkForNullAndEmpty(searchType, names)) {
            String userLoginId = userProfile.getUserName();
            List<String> authorizedCrops = getAuthorizedCropsForUser(userLoginId);
            if(!authorizedCrops.isEmpty()) {
                return getBaseProductsForCrops(authorizedCrops, searchType, names);
            }
        }
        return new ArrayList<BaseProduct>();
    }

    private boolean checkForNullAndEmpty(BaseProductSearchType searchType, List<String> names) {
        return searchType != null && names != null && !names.isEmpty();
    }

    private List<BaseProduct> getBaseProductsForCrops(List<String> authorizedCrops,
                                                      BaseProductSearchType searchType,
                                                      List<String> names) {
        ManfNamesSearchCriteria searchCriteria = manfNamesSearchBuilderFactory.getSearchCriteria(searchType);
        return searchCriteria.findBaseProducts(authorizedCrops, names);
    }

    private List<String> getAuthorizedCropsForUser(String userLoginId) {
        if(userLoginId != null) {
            return userPrivilegesService.getCrops(userLoginId);
        }
        return new ArrayList<String>();
    }

    public void setUserPrivilegesService(UserPrivilegesService userPrivilegesService) {
        this.userPrivilegesService = userPrivilegesService;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

    public void setManfNamesSearchBuilderFactory(ManfNamesSearchBuilderFactory manfNamesSearchBuilderFactory) {
        this.manfNamesSearchBuilderFactory = manfNamesSearchBuilderFactory;
    }
}