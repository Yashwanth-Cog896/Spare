package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.productimage.service.ProductImagesService;
import com.monsanto.tps.productstewardship.transfer.ValidationProperty;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

/**
 * vvkalu - Apr 27, 2010 2:04:53 PM
 */
public class ImageDisplayNameExceedsLengthRule implements ValidationSimpleRule<ImageValidationModel> {

   private static final int UNDERSCORE_LENGTH = 1;
   private static final int YEAR_LENGTH = 2;
   private static final int MONTH_LENGTH = 2;
   private static final int DAY_LENGTH = 2;
   private static final int HOUR_LENGTH = 2;
   private static final int MIN_LENGTH = 2;
   private static final int SEC_LENGTH = 2;
   private static final int TIMESTAMP_LENGTH = YEAR_LENGTH + MONTH_LENGTH + DAY_LENGTH + HOUR_LENGTH + MIN_LENGTH + SEC_LENGTH;
   private static final int PERIOD_LENGTH = 1;
   private static final int JPG_EXTENSION_LENGTH = 3;
   private static final int DISPLAY_NAME_MAX_LENGTH = 30;
   public static final int DISPLAY_NAME_TOTAL_MAX_LENGTH = DISPLAY_NAME_MAX_LENGTH + UNDERSCORE_LENGTH + TIMESTAMP_LENGTH + PERIOD_LENGTH + JPG_EXTENSION_LENGTH;

   @Override
   public void  validate(ImageValidationModel model, ValidationStatus status) {
      if (!StringUtils.isNullOrEmpty(model.getDisplayName()) && model.getDisplayName().length() > DISPLAY_NAME_TOTAL_MAX_LENGTH) {
         status.addCondition(new ValidationResult(ProductImagesService.IMAGE_DISPLAY_NAME_EXCEEDS_MAX_LENGTH, ValidationSeverity.ERROR,new ValidationProperty("displayNameMaxLength",String.valueOf(DISPLAY_NAME_MAX_LENGTH))));
      }
   }
}
