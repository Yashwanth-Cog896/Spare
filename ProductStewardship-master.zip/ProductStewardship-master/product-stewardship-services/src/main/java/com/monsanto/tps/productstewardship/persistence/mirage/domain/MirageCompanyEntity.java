package com.monsanto.tps.productstewardship.persistence.mirage.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 27, 2011
 * Time: 10:35:09 AM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@SequenceGenerator(name = "mirageCompanyIdGenerator",allocationSize = 1,sequenceName = "Mirage2.AUDIT_ID_SEQ")
@Table(name = "COMPANIES", schema = "Mirage2")
public class MirageCompanyEntity  implements Serializable {
    @Id
    @Column(name="COMPANY_ID")
    @GeneratedValue(generator = "mirageCompanyIdGenerator")
    private long id;
    @Column(name="COMPANY_NAME",nullable = true,length = 80)
    private String name;
    @Column(name="COMPANY_ABBREV",nullable = false,length=3)
    private String abbreviation;
    @Type(type = "yes_no")
    @Column(name="SEED_FLAG",nullable = true)
    private Boolean seed;
    @Type(type = "yes_no")
    @Column(name="CHEMICAL_FLAG",nullable = true)
    private Boolean chemical;
    @Type(type = "yes_no")
    @Column(name="PROGRAMS_FLAG",nullable = true)
    private Boolean programs;
    @Type(type = "yes_no")
    @Column(name="MONSANTO_FLAG",nullable = true)
    private Boolean monsanto;


    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }



    public Boolean getChemical() {
        return chemical;
    }

    public void setChemical(Boolean chemical) {
        this.chemical = chemical;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Boolean getMonsanto() {
        return monsanto;
    }

    public void setMonsanto(Boolean monsanto) {
        this.monsanto = monsanto;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getPrograms() {
        return programs;
    }

    public void setPrograms(Boolean programs) {
        this.programs = programs;
    }

    public Boolean getSeed() {
        return seed;
    }

    public void setSeed(Boolean seed) {
        this.seed = seed;
    }
}
