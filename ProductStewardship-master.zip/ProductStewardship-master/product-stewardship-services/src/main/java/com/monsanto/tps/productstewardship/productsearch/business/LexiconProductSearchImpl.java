package com.monsanto.tps.productstewardship.productsearch.business;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.authorization.LexiconUserRoleProvider;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import com.monsanto.tps.productstewardship.productsearch.service.ProductSearchResults;
import com.monsanto.tps.productstewardship.productsearch.service.ProductStageSearchResults;
import com.monsanto.tps.productstewardship.productsearch.service.TooManyResultsException;
import com.monsanto.tps.productstewardship.transfer.*;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 5:25:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductSearchImpl implements LexiconProductSearch {
    private UserPrivilegesService userPrivilegesService;
    private LexiconProductDao lexiconProductDao;
    private MidasProductDao midasProductDao;
    private LexiconProductStageDao lexiconProductStageDao;
    private LexiconTempSessionOcdDao lexiconTempSessionOcdDao;
    private MidasTempSessionOcdDao midasTempSessionOcdDao;
    private GeneticMaterialDao geneticMaterialDao;


    private UserProfile userProfile;
    private LexiconUserRoleProvider userRoleProvider;
    public static final String SHOW_ALL_GPFIELDS = "ShowAllGPFields";
    public static final String GERMPLASM_ACCESS = "GermplasmAccess";
    public static final String ROYALTY_DATA_ACCESS = "RoyaltyDataAccess";
    public static final String ROYALTY_DATA_EDIT = "RoyaltyDataEdit";
    public static final String INBRED_ACCESS = "InbredAccess";
    public static final String FINISHED_LINE_TYPE = "FINISHED";
    public static final String HYBRID_LINE_TYPE = "HYBRID";
    public static final String CODED_LINE_TYPE = "CODED";
    public static final String INBRED_STAGE_ABBREVIATION = "INBR";
    public static final String MALE = "M";
    public static final String FEMALE = "F";
    public static final List<String> VALID_PARENTAL_ROLES = Arrays.asList(MALE, FEMALE);


    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    @Override
    public ProductSearchResults productSearch(LexiconProductSearchCriteria productSearchCriteria, int pageSize, int pageNumber) {
        List<String> cropPubkeys = userPrivilegesService.getCrops(userProfile.getUserName());
        int totalRecordsFound = lexiconProductDao.countBySearchCriteria(cropPubkeys, productSearchCriteria);
        List<LexiconProductEntity> productEntities = lexiconProductDao.findBySearchCriteria(cropPubkeys,
                productSearchCriteria, pageSize, pageNumber);
        fetchProductInformation(productEntities, productSearchCriteria);
        List<Product> products = buildProductResults(productSearchCriteria, productEntities);
        ProductSearchResults results = new ProductSearchResults();
        results.setPageNumber(pageNumber);
        results.setPageSize(pageSize);
        results.setTotalRecordsFound(totalRecordsFound);
        results.setProducts(products);
        return results;
    }

    private List<Product> buildProductResults(LexiconProductSearchCriteria productSearchCriteria, List<LexiconProductEntity> productEntities) {
        int productCounter = 0;
        List<Product> products = new ArrayList<Product>(productEntities.size());
        for (LexiconProductEntity productEntity : productEntities) {
            if (productCounter > 999) {
                throw new TooManyResultsException("Greater than 1000 search results returned, please narrow criteria");
            }
            Product product = buildProduct(productSearchCriteria, productEntity);
            List<ProductStage> productStages = new ArrayList<ProductStage>(productEntity.getLexiconProductStages().size());
            for (LexiconProductStageEntity lexiconProductStage : productEntity.getLexiconProductStages()) {
                if ((!lexiconProductStage.isLogicalDelete()) || productSearchCriteria.isIncludeLogicalDelete()) {
                    productStages.add(buildProductStage(productEntity, lexiconProductStage));
                }
            }
            product.setProductStages(productStages);
            products.add(product);
            productCounter++;
        }
        return products;
    }

    @Override
    public List<Product> productSearch(LexiconProductSearchCriteria productSearchCriteria) throws TooManyResultsException {
        List<String> cropPubkeys = userPrivilegesService.getCrops(userProfile.getUserName());
        List<LexiconProductEntity> productEntities = lexiconProductDao.findBySearchCriteria(cropPubkeys,
                productSearchCriteria);
        fetchProductInformation(productEntities, productSearchCriteria);
        return buildProductResults(productSearchCriteria, productEntities);
    }

    private void fetchProductInfoForStages(List<LexiconProductStageEntity> productStageEntities, LexiconProductSearchCriteria productSearchCriteria) {
        List<LexiconProductEntity> products = new ArrayList<LexiconProductEntity>(productStageEntities.size());
        for (LexiconProductStageEntity productStage : productStageEntities) {
            products.add(productStage.getLexiconProduct());
        }
        fetchProductInformation(products, productSearchCriteria);
    }

    private void fetchProductInformation(List<LexiconProductEntity> productEntities, LexiconProductSearchCriteria productSearchCriteria) {
        Set<Long> productIds = new HashSet<Long>();
        Set<Long> midasProductIds = new HashSet<Long>();

        int productCounter = 0;
        for (LexiconProductEntity product : productEntities) {
            if (productCounter > 999) {
                throw new TooManyResultsException("Greater than 1000 search results returned, please narrow criteria");
            }
            if ((product.getFbsCommonProductXrefs() != null) && (product.getFbsCommonProductXrefs().size() > 0)) {
                productIds.add(product.getId());
                midasProductIds.add(product.getFbsCommonProductXref().getMidasProduct().getId());
            }
            productCounter++;
        }
        long requestId = System.currentTimeMillis() % 10000000L;
        lexiconTempSessionOcdDao.insertNumberValues(requestId, productIds);
        lexiconProductDao.getByIds(requestId);
        midasTempSessionOcdDao.insertNumberValues(requestId, midasProductIds);

        if (productSearchCriteria.isRetrieveParents()) {
            List<MidasProductEntity> midasProducts = midasProductDao.getWithParentageByIds(requestId);
            for (MidasProductEntity midasProduct : midasProducts) ;//Force load
        } else {
            List<MidasProductEntity> midasProducts = midasProductDao.getByIds(requestId);
            for (MidasProductEntity midasProduct : midasProducts) ; //Force load
        }

    }

    @Override
    public ProductStageSearchResults productStageSearch(LexiconProductSearchCriteria productSearchCriteria, int pageSize, int pageNumber) {
        List<String> cropPubkeys = userPrivilegesService.getCrops(userProfile.getUserName());
        int totalRecordsFound = lexiconProductStageDao.countBySearchCriteria(cropPubkeys, productSearchCriteria);
        List<LexiconProductStageEntity> productStageEntities = lexiconProductStageDao.findBySearchCriteria(cropPubkeys, productSearchCriteria, pageSize, pageNumber);
        fetchProductInfoForStages(productStageEntities, productSearchCriteria);
        List<Product> products = new ArrayList<Product>();
        Product currentProduct = null;
        for (LexiconProductStageEntity productStageEntity : productStageEntities) {
            if ((currentProduct == null) || (currentProduct.getId() != productStageEntity.getLexiconProduct().getId())) {
                if (currentProduct != null) {
                    products.add(currentProduct);
                }
                currentProduct = buildProduct(productSearchCriteria, productStageEntity.getLexiconProduct());
            }
            if ((!productStageEntity.isLogicalDelete()) || productSearchCriteria.isIncludeLogicalDelete()) {
                currentProduct.getProductStages().add(buildProductStage(productStageEntity.getLexiconProduct(), productStageEntity));
            }
        }
        if (currentProduct != null) {
            products.add(currentProduct);
        }
        ProductStageSearchResults results = new ProductStageSearchResults();
        results.setPageNumber(pageNumber);
        results.setPageSize(pageSize);
        results.setTotalStageRecordsFound(totalRecordsFound);
        results.setProducts(products);
        return results;
    }

    private Product buildProduct(LexiconProductSearchCriteria productSearchCriteria, LexiconProductEntity productEntity) {
        Product product = new Product();
        product.setId(productEntity.getId());
        product.setCrop(productEntity.getLexiconCrop().getName());
        product.setPreCommercialName(productEntity.getPreCommercialName());
        if (!userRoleProvider.hasRole(INBRED_ACCESS)) {
            for (LexiconProductStageEntity productStage : productEntity.getLexiconProductStages()) {
                if (productStage.getLexiconStage().getAbbreviation().equals(INBRED_STAGE_ABBREVIATION)) {
                    product.setPreCommercialName(null);
                }
            }
        }
        product.setHybrid(getHybridStatus(productEntity));
        product.setVarietyName(productEntity.getTagVarietyName());
        product.setPubkey(productEntity.getPubkey());
        product.setLogicalDelete(productEntity.isLogicalDelete());
        List<Relationship> relationships = buildRelationshipsForProduct(productEntity);
        product.setRelationships(relationships);

        product.setProductGermplasms(buildProductGermplasms(productSearchCriteria, productEntity));

        product.setRoyalty(getRoyalty(productEntity));
        product.setClassification(buildProductClassification(productEntity));
        return product;
    }

    private Boolean getHybridStatus(LexiconProductEntity productEntity) {
        if ((productEntity.getFbsCommonProductXrefs() == null) || (productEntity.getFbsCommonProductXrefs().size() == 0)) {
            return null;
        }
        boolean isHybrid = false;
        for (ProductGermplasmEntity productGermplasm : productEntity.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
            if (productGermplasm.getGermplasm().getLineType().getLineTypeRefId().equals(HYBRID_LINE_TYPE)) {
                isHybrid = true;
                break;
            }
        }
        return isHybrid;
    }

    private List<Relationship> buildRelationshipsForProduct(LexiconProductEntity productEntity) {
        List<Relationship> relationships = new ArrayList<Relationship>();
        if (!productEntity.getLexiconProductRelationshipXrefs().isEmpty()) {
            for (ProductRelationshipXrefEntity productRelationshipXref : productEntity.getLexiconProductRelationshipXrefs()) {
                ProductRelationshipEntity productRelationship = productRelationshipXref.getProductRelationship();
                BaseProductEntity baseProduct = productRelationship.getBaseProduct();
                if ((baseProduct != null) && (baseProduct.getLogicalDelete() != Boolean.TRUE) &&
                        (productRelationship.getLogicalDelete() != Boolean.TRUE)) {
                    Relationship relationship = new Relationship();
                    relationship.setProductionStatus(productRelationshipXref.getProductionStatus().getProductionStatusName());
                    relationship.setTraitVersion(productRelationshipXref.getTraitVersion());
                    relationship.setManufacturingName(productRelationship.getManufacturingName());
                    relationship.setBaseManufacturingName(baseProduct.getBaseManufacturingName());
                    relationship.setLogicalDelete(productRelationship.getLogicalDelete());
                    relationships.add(relationship);
                }
            }
        }
        return relationships;
    }

    private ProductStage buildProductStage(LexiconProductEntity productEntity, LexiconProductStageEntity lexiconProductStage) {
        ProductStage productStage = new ProductStage();
        productStage.setId(lexiconProductStage.getId());
        productStage.setActive(lexiconProductStage.isActive());
        productStage.setBrand(lexiconProductStage.getLexiconBrand().getName());
        productStage.setCommercialMaturity(lexiconProductStage.getCommercialMaturity());
        productStage.setCommercialName(lexiconProductStage.getCommercialName());
        productStage.setCountry(lexiconProductStage.getLexiconCountry().getAbbreviation());
        productStage.setOecdRegistrationName(lexiconProductStage.getOecdRegistrationName());
        productStage.setPreferredName(lexiconProductStage.isPreferredName());
        productStage.setPubkey(lexiconProductStage.getPubkey());
        productStage.setStage(lexiconProductStage.getLexiconStage().getAbbreviation());
        productStage.setCommercialTrait(getCommercialTriat(lexiconProductStage));
        productStage.setLogicalDelete(lexiconProductStage.isLogicalDelete());
        ExceptionCodeEntity exceptionCode = lexiconProductStage.getExceptionCode();
        if (exceptionCode != null) {
            productStage.setPrimary(exceptionCode.isPrimary());
            productStage.setExceptionPubkey(exceptionCode.getExceptionCode());
        }
        return productStage;
    }

    private String getCommercialTriat(LexiconProductStageEntity lexiconProductStage) {
        String commercialTrait = null;
        CommercialTraitStackEntity commercialTraitStack = lexiconProductStage.getCommercialTraitStack();
        if (commercialTraitStack != null) {
            if (StringUtils.isNotBlank(commercialTraitStack.getReportingName())) {
                commercialTrait = commercialTraitStack.getReportingName();
            } else {
                commercialTrait = commercialTraitStack.getAbbreviation();
            }
        }
        return commercialTrait;
    }

    private ProductClassification buildProductClassification(LexiconProductEntity productEntity) {
        ProductClassification productClassification = new ProductClassification();
        ProductClassificationEntity productClassificationEntity = productEntity.getProductClassification();
        if (productClassificationEntity != null) {
            productClassification.setFamily(productClassificationEntity.getFamily().getName());
            productClassification.setMaterialGroup(productClassificationEntity.getMaterialGroup().getName());
            productClassification.setMaterialPricingGroup(productClassificationEntity.getMaterialPricingGroup().getName());
            productClassification.setProductionEnvironment(productClassificationEntity.getProductionEnvironment().getName());
            productClassification.setProductType(productClassificationEntity.getProductType().getName());
        }
        SupplyChainOwnerGroupEntity chainOwnerGroup = productEntity.getSupplyChainOwnerGroup();
        productClassification.setSupplyChainOwnerGroup(chainOwnerGroup == null ? null : chainOwnerGroup.getCode());
        return productClassification;
    }

    private Boolean getRoyalty(LexiconProductEntity productEntity) {
        if ((productEntity.getFbsCommonProductXrefs() == null) || (productEntity.getFbsCommonProductXrefs().size() == 0)) {
            return null;
        }
        if (userRoleProvider.hasRole(ROYALTY_DATA_ACCESS) || userRoleProvider.hasRole(ROYALTY_DATA_EDIT)) {
            Boolean royalty = false;
            for (ProductGermplasmEntity productGermplasmEntity : productEntity.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                GermplasmEntity germplasm = productGermplasmEntity.getGermplasm();
                if (!germplasm.isDeleted()) {

                    for (GermplasmRoyaltyEntity germplasmRoyalty : germplasm.getGermplasmRoyalties()) {
                        if ((germplasmRoyalty.getActive() == Boolean.TRUE) &&
                                (germplasmRoyalty.isRoyaltyIndicator())) {
                            royalty = true;
                            break;
                        }
                    }
                }
            }
            return royalty;
        } else {
            return null;
        }
    }

    private List<ProductGermplasm> buildProductGermplasms(LexiconProductSearchCriteria productSearchCriteria, LexiconProductEntity productEntity) {
        boolean hasParents = false;
        List<ProductGermplasm> productGermplasms = new ArrayList<ProductGermplasm>();
        if ((productEntity.getFbsCommonProductXrefs() == null) || (productEntity.getFbsCommonProductXrefs().size() == 0)) {
            return productGermplasms;
        }

        boolean retrieveGermplasm = productSearchCriteria.isRetrieveGermplasm();
        boolean retrieveParents = determineShouldRetrieveParents(productEntity, productSearchCriteria.isRetrieveParents());
        if (retrieveGermplasm || retrieveParents) {
            for (ProductGermplasmEntity productGermplasmEntity : productEntity.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                GermplasmEntity germplasm = productGermplasmEntity.getGermplasm();
                if (!germplasm.isDeleted()) {

                    ProductGermplasm productGermplasm = new ProductGermplasm();
                    if (retrieveGermplasm) {
                        if (userRoleProvider.hasRole(GERMPLASM_ACCESS)) {
                            productGermplasm.setPedigree(germplasm.getPedigreeName());
                            productGermplasm.setGermplasmId(germplasm.getId());
                            Boolean preferred = productGermplasmEntity.getPreferred();
                            productGermplasm.setPreferredPedigree(preferred != null ? preferred.booleanValue() : false);
                            productGermplasm.setEventList(germplasm.getEventDisplay());
                            for (TraitValueEntity traitValue : germplasm.getTraitValues()) {
                                MidasTraitEntity midasTrait = traitValue.getMidasTrait();
                                if (midasTrait.isActive() && MidasTraitEntity.C_TRAIT_TYPE.equals(midasTrait.getTraitType()) &&
                                        MidasTraitEntity.RELATIVE_MATURITY_NAME.equals(midasTrait.getName())) {
                                    productGermplasm.setRelativeMaturity(traitValue.getNumValue());
                                }
                            }
                        }

                        if (userRoleProvider.hasRole(SHOW_ALL_GPFIELDS)) {
                            productGermplasm.setOwner(germplasm.getOwnerProgram().getName());
                            productGermplasm.setFinished(germplasm.isFinished());
                            productGermplasm.setLineType(germplasm.getLineType().getLineTypeRefId());
                            productGermplasm.setLineCode(germplasm.getLineCode());
                            productGermplasm.setOrigin(germplasm.getOrigin());
                        } else if (userRoleProvider.hasRole(GERMPLASM_ACCESS)) {
                            if (germplasm.getLineType().getLineTypeRefId().equals(FINISHED_LINE_TYPE) ||
                                    germplasm.getLineType().getLineTypeRefId().equals(CODED_LINE_TYPE)) {
                                productGermplasm.setLineCode(germplasm.getLineCode());
                            }
                            if (germplasm.getLineType().getLineTypeRefId().equals(HYBRID_LINE_TYPE)) {
                                productGermplasm.setOrigin(germplasm.getOrigin());
                            }
                        }
                    }

                    Set<GeneticMaterialEntity> geneticMaterials = germplasm.getGeneticMaterials();
                    Set<Parents> parentses = new HashSet<Parents>(geneticMaterials.size());
                    Set<String> sources = new HashSet<String>();
                    for (GeneticMaterialEntity geneticMaterial : geneticMaterials) {
                        boolean materialHasParents = false;

                        if (userRoleProvider.hasRole(GERMPLASM_ACCESS) || userRoleProvider.hasRole(SHOW_ALL_GPFIELDS)) {
                            if (retrieveGermplasm && productSearchCriteria.isIncludeSourceData()) {
                                sources.add(geneticMaterial.getSource());
                            }
                        }
                        Parents parents = new Parents();
                        if (retrieveParents) {
                            for (GeneticMaterialParentEntity parent : geneticMaterial.getParents()) {
                                if (VALID_PARENTAL_ROLES.contains(parent.getParentalRole().getParentalRoleRefId())) {
                                    materialHasParents = true;
                                    hasParents = true;
                                    ProductParent productParent = buildGeneticMaterialParent(parent);
                                    if (parent.getParentalRole().getParentalRoleRefId().equals(FEMALE)) {
                                        parents.setMother(productParent);
                                    } else {
                                        parents.setFather(productParent);
                                    }
                                }
                            }
                        }
                        if ((retrieveGermplasm && (userRoleProvider.hasRole(SHOW_ALL_GPFIELDS) || userRoleProvider.hasRole(GERMPLASM_ACCESS))) || materialHasParents) {
                            parentses.add(parents);
                        }
                    }

                    productGermplasm.getSources().addAll(sources);
                    productGermplasm.getParents().addAll(parentses);
                    if ((retrieveGermplasm && (userRoleProvider.hasRole(SHOW_ALL_GPFIELDS) || userRoleProvider.hasRole(GERMPLASM_ACCESS))) || (!parentses.isEmpty())) {
                        productGermplasms.add(productGermplasm);
                    }
                }

            }
        }
        if (userRoleProvider.hasRole(SHOW_ALL_GPFIELDS) || userRoleProvider.hasRole(GERMPLASM_ACCESS) || hasParents) {
            return productGermplasms;
        } else {
            return new ArrayList<ProductGermplasm>();
        }

    }

    private boolean determineShouldRetrieveParents(LexiconProductEntity productEntity, boolean retrieveParents) {
        boolean foundHybridFinishedTrue = false;
        boolean foundFinishedOrCodedGermplasm = false;
        if (retrieveParents) {
            for (ProductGermplasmEntity productGermplasmEntity : productEntity.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                GermplasmEntity germplasm = productGermplasmEntity.getGermplasm();
                if (!germplasm.isDeleted()) {
                    if ((germplasm.getLineType().getLineTypeRefId().equals(LineTypeEntity.HYBRID)) && (germplasm.isFinished())) {
                        foundHybridFinishedTrue = true;
                    }
                    if (germplasm.getLineType().getLineTypeRefId().equals(LineTypeEntity.FINISHED) ||
                            germplasm.getLineType().getLineTypeRefId().equals(LineTypeEntity.CODED)) {
                        foundFinishedOrCodedGermplasm = true;
                    }
                }
            }
        }
        return retrieveParents && foundHybridFinishedTrue && (!foundFinishedOrCodedGermplasm);
    }

    private ProductParent buildGeneticMaterialParent(GeneticMaterialParentEntity parent) {
        ProductParent productParent = new ProductParent();
        List<Relationship> parentRelationships = new ArrayList<Relationship>();
        GermplasmEntity parentGermplasm = parent.getParent().getGermplasm();
        productParent.setPredigree(parentGermplasm.getPedigreeName());
        if (!parentGermplasm.isDeleted()) {
            for (ProductGermplasmEntity parentProductGermplasm : parentGermplasm.getProductGermplasms()) {
                MidasProductEntity parentMidasProduct = parentProductGermplasm.getMidasProduct();
                for (FbsCommonProductXrefEntity parentProductXref : parentMidasProduct.getFbsCommonProductXrefs()) {
                    LexiconProductEntity parentLexiconProduct = parentProductXref.getLexiconProduct();
                    if (parentLexiconProduct != null) {
                        productParent.setProductPubkey(parentLexiconProduct.getPubkey());
                        productParent.setPreCommercialName(parentLexiconProduct.getPreCommercialName());
                        parentRelationships.addAll(buildRelationshipsForProduct(parentLexiconProduct));
                    }
                }
            }
        }

        productParent.setRelationships(parentRelationships);
        return productParent;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }

    public void setUserPrivilegesService(UserPrivilegesService userPrivilegesService) {
        this.userPrivilegesService = userPrivilegesService;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

    public void setUserRoleProvider(LexiconUserRoleProvider userRoleProvider) {
        this.userRoleProvider = userRoleProvider;
    }

    public void setLexiconTempSessionOcdDao(LexiconTempSessionOcdDao lexiconTempSessionOcdDao) {
        this.lexiconTempSessionOcdDao = lexiconTempSessionOcdDao;
    }

    public void setMidasProductDao(MidasProductDao midasProductDao) {
        this.midasProductDao = midasProductDao;
    }

    public void setMidasTempSessionOcdDao(MidasTempSessionOcdDao midasTempSessionOcdDao) {
        this.midasTempSessionOcdDao = midasTempSessionOcdDao;
    }

    public void setGeneticMaterialDao(GeneticMaterialDao geneticMaterialDao) {
        this.geneticMaterialDao = geneticMaterialDao;
    }
}
