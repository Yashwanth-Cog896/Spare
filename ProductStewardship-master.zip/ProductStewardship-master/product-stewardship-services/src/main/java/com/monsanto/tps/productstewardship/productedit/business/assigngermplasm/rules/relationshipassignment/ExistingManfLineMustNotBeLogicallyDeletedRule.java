package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class ExistingManfLineMustNotBeLogicallyDeletedRule implements ValidationSimpleRule<Product>{

  private ProductRelationshipDao productRelationshipDao;

  @Override
  public void validate(Product model, ValidationStatus status) {
    if (!StringUtils.isNullOrEmpty(model.getManufacturingName())) {
      ProductRelationshipEntity existingProductRelationships = productRelationshipDao.getByManufacturingName(model.getManufacturingName());
      if ((existingProductRelationships!=null)&&(existingProductRelationships.getLogicalDelete())){
          status.addCondition(new ValidationResult(ProductEditService.MANF_LINE_IS_LOGICALLY_DELETED, ValidationSeverity.ERROR));
      }
    }
  }

  public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
    this.productRelationshipDao = productRelationshipDao;
  }
}
