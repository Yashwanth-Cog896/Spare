package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.SQLInsert;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:19:34 PM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@SequenceGenerator(name = "commercialTraitStackIdGenerator",allocationSize = 1,sequenceName = "Lexicon.COML_TRAIT_STACK_ID_SEQ")
@Table(name = "COML_TRAIT_STACK2", schema = "Lexicon")
public class CommercialTraitStackEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "commercialTraitStackIdGenerator")
    @Column(name="COML_TRAIT_STACK_ID")
    private long id;

    @Column(name="REPORTING_NAME",nullable = true,length = 50)
    private String reportingName;
    @Column(name="STACK_DESC",nullable=false,length=50)
    private String description;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="CROP_ID",nullable = false)
    private LexiconCropEntity lexiconCrop;
    @Column(name="TD_NAME",nullable = true, length = 50)
    private String techDevName;
    @Column(name="STACK_ABBR",nullable = false, length = 50)
    private String abbreviation;
    @Column(name="COML_TRAIT_STACK_PUBKEY",nullable = false,length = 20)
    private String pubkey;
    @Column(name="MANF_TRAIT_CODE",nullable = true,length=3)
    private String manufacturingTraitCode;
    @Type(type = "boolean-yn")
    @Column(name="IS_PRE_COMMERCIAL_IND",nullable = false)
    private boolean preCommercial;

    @OneToMany(mappedBy = "commercialTraitStack",fetch = FetchType.LAZY)
    List<CommercialTraitStackAlternateNameEntity> alternateNames = new ArrayList<CommercialTraitStackAlternateNameEntity>();

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "COML_TRAIT_STACK_XREF2",schema = "Lexicon",joinColumns = @JoinColumn(name = "COML_TRAIT_STACK_ID"),
              inverseJoinColumns = @JoinColumn(name="COML_TRAIT_NAME_ID")  )
    @SQLInsert(sql = "INSERT INTO LEXICON.COML_TRAIT_STACK_XREF2 (coml_trait_stack_xref_id, coml_trait_stack_id, coml_trait_name_id) values ( Lexicon.coml_trait_stack_xref_id_seq.nextval, ?, ?)" )
    List<CommercialTraitNameEntity> commercialTraitNames = new ArrayList<CommercialTraitNameEntity>();
    
    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCropEntity getLexiconCrop() {
        return lexiconCrop;
    }

    public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
        this.lexiconCrop = lexiconCrop;
    }

    public String getManufacturingTraitCode() {
        return manufacturingTraitCode;
    }

    public void setManufacturingTraitCode(String manufacturingTraitCode) {
        this.manufacturingTraitCode = manufacturingTraitCode;
    }

    public boolean isPreCommercial() {
        return preCommercial;
    }

    public void setPreCommercial(boolean preCommercial) {
        this.preCommercial = preCommercial;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public String getReportingName() {
        return reportingName;
    }

    public void setReportingName(String reportingName) {
        this.reportingName = reportingName;
    }

    public String getTechDevName() {
        return techDevName;
    }

    public void setTechDevName(String techDevName) {
        this.techDevName = techDevName;
    }

    public List<CommercialTraitStackAlternateNameEntity> getAlternateNames() {
        return alternateNames;
    }

    public void setAlternateNames(List<CommercialTraitStackAlternateNameEntity> alternateNames) {
        this.alternateNames = alternateNames;
    }

    public List<CommercialTraitNameEntity> getCommercialTraitNames() {
        return commercialTraitNames;
    }

    public void setCommercialTraitNames(List<CommercialTraitNameEntity> commercialTraitNames) {
        this.commercialTraitNames = commercialTraitNames;
    }
}
