package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.assigninggermplasm;


import com.monsanto.tps.productstewardship.persistence.lexicon.dao.GermplasmDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LineTypeEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductGermplasm;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

import java.util.*;

public class AssigningGermplasmConsistentRule implements ValidationSimpleRule<Product>{

  private GermplasmDao germplasmDao;

  @Override
  public void validate(Product model, ValidationStatus status) {

    if ((model.getAssignedGermplasms() !=null)&& (model.getAssignedGermplasms().size()>0)){
       List<ProductGermplasm>  productGermplasms = model.getAssignedGermplasms();
       String baseLineType ="";
       for (ProductGermplasm productGermplasm:productGermplasms){
         GermplasmEntity germplasm = germplasmDao.get(productGermplasm.getGermplasmId()) ;
         if (germplasm != null) {
           String curLineType = getLineType(germplasm);
           if ((!baseLineType.equals("")) && (!baseLineType.equals(curLineType))){
             status.addCondition(new ValidationResult(ProductEditService.ASSIGNING_GP_INCONSISTANT_CODE, ValidationSeverity.ERROR));
             return;
           }else if (baseLineType.equals("")){
             baseLineType = curLineType;
           }
         }
       }
    }
  }

  private String getLineType(GermplasmEntity germplasm) {
      String lineType = germplasm.getLineType().getLineTypeRefId();
      if (LineTypeEntity.CODED.equals(lineType)||
          LineTypeEntity.FINISHED.equals(lineType)){
          return "INBRED";
      } else if (LineTypeEntity.HYBRID.equals(lineType)) {
          return "HYBRED";
      }  else {
          return "UNKNOW";
      }

  }

  public void setGermplasmDao(GermplasmDao germplasmDao) {
    this.germplasmDao = germplasmDao;
  }
}
