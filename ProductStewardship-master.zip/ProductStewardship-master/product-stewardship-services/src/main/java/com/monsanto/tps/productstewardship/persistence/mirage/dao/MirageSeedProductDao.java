package com.monsanto.tps.productstewardship.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 18, 2011
 * Time: 1:50:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageSeedProductDao extends GenericDao<MirageSeedProductEntity,Long>{
     @DynamicDaoMethod(queryName = "MirageSeedProductDao.findByProductNameBayerCodeCountryCompany",
             parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    MirageSeedProductEntity findByProductNameBayerCodeCountryCompany(@DynamicDaoParameter(name="productName")String productName,
                                                                                  @DynamicDaoParameter(name="mirageBayerCode")String mirageBayerCode,
                                                                                  @DynamicDaoParameter(name="mirageCountryCode")String mirageCountryCode,
                                                                                  @DynamicDaoParameter(name="mirageCompanyId")Long mirageCompanyId);

    @DynamicDaoMethod(queryName = "MirageSeedProductDao.findByPreComlProductByNameAndBayerCode",
             parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    MirageSeedProductEntity findByPreComlProductByNameAndBayerCode(@DynamicDaoParameter(name="productName")String productName,
                                                                                  @DynamicDaoParameter(name="mirageBayerCode")String mirageBayerCode);
}
