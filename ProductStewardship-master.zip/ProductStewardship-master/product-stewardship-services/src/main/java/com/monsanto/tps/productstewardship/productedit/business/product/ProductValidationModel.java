package com.monsanto.tps.productstewardship.productedit.business.product;

import com.monsanto.tps.productstewardship.productedit.service.Product;

import java.util.List;

public class ProductValidationModel {
    List<Product> products;
    Product product;
    public ProductValidationModel(List<Product>products, Product product){
        this.products = products;
        this.product = product;
    }
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}
