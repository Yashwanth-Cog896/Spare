package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.tps.productstewardship.productimage.service.ProductImagesService;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;


/**
 * vvkalu - Mar 15, 2010 2:02:13 PM
 */
public class InvalidImageFormatRule extends AbstractValidationSimpleRule  {

   @Override
   public void validate(ImageValidationModel model, ValidationStatus status) {
      if(!preConditionsMet(model) || model.getFormatName() == null || !model.getFormatName().equalsIgnoreCase("JPEG")) {
         status.addCondition(ProductImagesService.IMAGE_FORMAT_INVALID);
      }
   }
}
