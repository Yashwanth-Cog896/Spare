package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.GeneticMaterialDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.GermplasmDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LineTypeDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductGermplasmDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import org.apache.commons.lang.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GeneticMaterialWriter {
    public static final String BASE_SOURCE = "PRE-COMMERCIAL PRODUCT IMPORT";
    public static final String FINISHED_GENERATION = "INBRED";
    public static final String HYBRID_GENERATION = "F1";

    private GermplasmDao germplasmDao;
    private GeneticMaterialDao geneticMaterialDao;
    private LineTypeDao lineTypeDao;
    private ProductGermplasmDao productGermplasmDao;

    public static final String MIRAGE_USE_ONLY = " MIRAGE USE ONLY";

    public GeneticMaterialEntity writeMirageGeneticMaterial(LexiconProductEntity lexiconProduct) {
        GeneticMaterialEntity mirageGeneticMaterial = findMirageGeneticMaterial(lexiconProduct);
        GermplasmEntity mirageGermplasm = getFinishedGermplasm(lexiconProduct);
        if (mirageGeneticMaterial != null) {
            if (mirageGermplasm != null) {  //This is weird but the way it works in lexiconPOS
                mirageGeneticMaterial.getGermplasm().getGeneticMaterials().remove(mirageGeneticMaterial);
                mirageGermplasm.getGeneticMaterials().add(mirageGeneticMaterial);
                mirageGeneticMaterial.setGermplasm(mirageGermplasm);
            }
        } else {

            if ((mirageGermplasm == null) && (!lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms().isEmpty())) {
                boolean isInbred = false;
                if (allLineTypesConsistent(lexiconProduct)) {
                    for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                        String lineTypeRefId = productGermplasm.getGermplasm().getLineType().getLineTypeRefId();
                        if ((!productGermplasm.getGermplasm().isDeleted()) && (isInbredType(lineTypeRefId) || lineTypeRefId.equals(LineTypeEntity.HYBRID))) {
                            GermplasmEntity germplasm = productGermplasm.getGermplasm();
                            isInbred = isInbredType(lineTypeRefId);
                            break;
                        }
                    }
                }
                ProgramEntity ownerProgram = null;
                for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                    GermplasmEntity germplasm = productGermplasm.getGermplasm();
                    if ((!germplasm.isDeleted()) && germplasm.getOwnerProgram() != null) {
                        ownerProgram = germplasm.getOwnerProgram();
                        break;
                    }
                }
                String eventDisplay = null;
                for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                    GermplasmEntity germplasm = productGermplasm.getGermplasm();
                    if ((!germplasm.isDeleted()) && StringUtils.isNotBlank(germplasm.getEventDisplay())) {
                        eventDisplay = germplasm.getEventDisplay();
                        break;
                    }
                }

                boolean anyTransgenic = false;
                for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
                    GermplasmEntity germplasm = productGermplasm.getGermplasm();
                    if ((!germplasm.isDeleted()) && germplasm.isTransgenic()) {
                        anyTransgenic = true;
                        break;
                    }
                }
//                boolean hasEvents  = false;
//                for(ProductGermplasmEntity productGermplasm:lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms() ) {
//                    GermplasmEntity germplasm1 = productGermplasm.getGermplasm();
//                    if((!germplasm1.isDeleted())&&(!germplasm1.getGermplasmEventConstructs().isEmpty())){
//                      hasEvents= true;
//                      break;
//                  }
//               }
                String spaceStrippedName = lexiconProduct.getPreCommercialName().replace(' ', '_');
                GermplasmEntity dummyGermplasm = new GermplasmEntity();
                dummyGermplasm.setOrigin(spaceStrippedName);
                dummyGermplasm.setLineCode(isInbred ? spaceStrippedName : null);
                dummyGermplasm.setPedigreeName(spaceStrippedName);
                dummyGermplasm.setLineType(isInbred ? lineTypeDao.getByRefId(LineTypeEntity.CODED) : lineTypeDao.getByRefId(LineTypeEntity.HYBRID));
                dummyGermplasm.setMidasCrop(lexiconProduct.getFbsCommonProductXref().getMidasProduct().getMidasCrop());
                dummyGermplasm.setOwnerProgram(ownerProgram);
                dummyGermplasm.setEventDisplay(eventDisplay);
                dummyGermplasm.setTransgenic(anyTransgenic);
                dummyGermplasm.setDeleted(false);
                dummyGermplasm.setFinished(false);
                germplasmDao.saveOrUpdate(dummyGermplasm);
                ProductGermplasmEntity dummyProductGermplasm = new ProductGermplasmEntity();
                dummyProductGermplasm.setGermplasm(dummyGermplasm);
                dummyProductGermplasm.setMidasProduct(lexiconProduct.getFbsCommonProductXref().getMidasProduct());
                dummyProductGermplasm.getMidasProduct().getProductGermplasms().add(dummyProductGermplasm);
                dummyProductGermplasm.getGermplasm().getProductGermplasms().add(dummyProductGermplasm);
                productGermplasmDao.saveOrUpdate(dummyProductGermplasm);
                mirageGermplasm = dummyGermplasm;
            }

            if (mirageGermplasm != null) {
                GeneticMaterialEntity geneticMaterial = new GeneticMaterialEntity();
                geneticMaterial.setGermplasm(mirageGermplasm);
                boolean inbredType = isInbredType(mirageGermplasm.getLineType().getLineTypeRefId());
                geneticMaterial.setLineage(inbredType ? "|" : null);
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
                geneticMaterial.setSource(BASE_SOURCE + " " + formatter.format(new Date()) + MIRAGE_USE_ONLY);
                geneticMaterial.setGeneration(inbredType ? FINISHED_GENERATION : HYBRID_GENERATION);
                mirageGermplasm.getGeneticMaterials().add(geneticMaterial);
                geneticMaterialDao.saveOrUpdate(geneticMaterial);
                mirageGeneticMaterial = geneticMaterial;
            }
        }
        return mirageGeneticMaterial;
    }

    private boolean allLineTypesConsistent(LexiconProductEntity lexiconProduct) {
        GermplasmEntity germplasm = null;
        String refId = null;
        boolean lineTypeConsistent = true;
        for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
            if (!productGermplasm.getGermplasm().isDeleted()) {
                if (germplasm == null) {
                    refId = (germplasm != null) ? germplasm.getLineType().getLineTypeRefId() : "UNKNOWN";
                }
                lineTypeConsistent &= isConsistentLineType(refId, productGermplasm.getGermplasm());
                if (!lineTypeConsistent) {
                    break;
                }
            }
        }
        return lineTypeConsistent;
    }

    private boolean isConsistentLineType(String refId1, GermplasmEntity germplasm) {

        String refId2 = germplasm.getLineType().getLineTypeRefId();
        if (refId1.equals(LineTypeEntity.HYBRID)) {
            return (!(isInbredType(refId2)));
        } else if (isInbredType(refId1)) {
            return (!refId2.equals(LineTypeEntity.HYBRID));
        } else {
            return true;
        }
    }

    private boolean isInbredType(String lineTypeRefId) {
        return lineTypeRefId.equals(LineTypeEntity.CODED) || lineTypeRefId.equals(LineTypeEntity.FINISHED);
    }

    private GeneticMaterialEntity findMirageGeneticMaterial(LexiconProductEntity lexiconProduct) {
        GeneticMaterialEntity mirageGeneticMaterial = null;
        mirageGeneticMaterialLoop:
        for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
            if (!productGermplasm.getGermplasm().isDeleted()) {
                for (GeneticMaterialEntity geneticMaterial : productGermplasm.getGermplasm().getGeneticMaterials()) {
                    if (geneticMaterial.getSource().toUpperCase().contains("MIRAGE")) {
                        mirageGeneticMaterial = geneticMaterial;
                        break mirageGeneticMaterialLoop;
                    }
                }
            }
        }
        return mirageGeneticMaterial;
    }

    private GermplasmEntity getFinishedGermplasm(LexiconProductEntity lexiconProduct) {
        GermplasmEntity finishedGermplasm = null;
        for (ProductGermplasmEntity productGermplasm : lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
            GermplasmEntity germplasm = productGermplasm.getGermplasm();
            if ((!germplasm.isDeleted()) && germplasm.isFinished()) {
                finishedGermplasm = germplasm;
                break;
            }
        }
        return finishedGermplasm;
    }

    public void setGeneticMaterialDao(GeneticMaterialDao geneticMaterialDao) {
        this.geneticMaterialDao = geneticMaterialDao;
    }

    public void setGermplasmDao(GermplasmDao germplasmDao) {
        this.germplasmDao = germplasmDao;
    }

    public void setLineTypeDao(LineTypeDao lineTypeDao) {
        this.lineTypeDao = lineTypeDao;
    }

    public void setProductGermplasmDao(ProductGermplasmDao productGermplasmDao) {
        this.productGermplasmDao = productGermplasmDao;
    }
}
