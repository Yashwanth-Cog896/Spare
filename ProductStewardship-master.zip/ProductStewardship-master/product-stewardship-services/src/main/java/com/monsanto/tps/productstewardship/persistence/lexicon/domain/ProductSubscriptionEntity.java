package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "PRODUCT_SUBSCRIPTION", schema = "LEXICON")
@SequenceGenerator(name = "productSubscriptionIdGenerator", allocationSize = 1,sequenceName = "LEXICON.PRODUCT_SUBSCRIPTION_ID_SEQ")
public class ProductSubscriptionEntity implements Serializable{
  public static final String SAP="SAP";
  @Id
  @Column(name = "PRODUCT_SUBSCRIPTION_ID")
  @GeneratedValue(generator = "productSubscriptionIdGenerator")
  private long id;
  @Column(name = "EXTERNAL_SYSTEM_NAME", nullable = false,length = 50)
  private String externalSystemName;
  @ManyToOne
  @JoinColumn(name = "CROP_ID",nullable = true)
  private LexiconCropEntity lexiconCrop;
  @ManyToOne
  @JoinColumn(name = "STAGE_ID",nullable = true)
  private LexiconStageEntity lexiconStage;
  @ManyToOne
  @JoinColumn(name = "COUNTRY_ID",nullable = true)
  private LexiconCountryEntity lexiconCountry;

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getExternalSystemName() {
    return externalSystemName;
  }

  public void setExternalSystemName(String externalSystemName) {
    this.externalSystemName = externalSystemName;
  }

  public LexiconCropEntity getLexiconCrop() {
    return lexiconCrop;
  }

  public void setLexiconCrop(LexiconCropEntity lexiconCrop) {
    this.lexiconCrop = lexiconCrop;
  }

  public LexiconStageEntity getLexiconStage() {
    return lexiconStage;
  }

  public void setLexiconStage(LexiconStageEntity lexiconStage) {
    this.lexiconStage = lexiconStage;
  }

  public LexiconCountryEntity getLexiconCountry() {
    return lexiconCountry;
  }

  public void setLexiconCountry(LexiconCountryEntity lexiconCountry) {
    this.lexiconCountry = lexiconCountry;
  }
}
