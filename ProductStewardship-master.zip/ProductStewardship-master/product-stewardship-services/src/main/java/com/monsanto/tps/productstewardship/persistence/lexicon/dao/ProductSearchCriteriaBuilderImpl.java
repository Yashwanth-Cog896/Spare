package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductGermplasmEntity;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductType;

import com.monsanto.tps.productstewardship.productsearch.service.NameType;
import com.monsanto.tps.productstewardship.productsearch.service.StageType;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.*;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 10:22:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductSearchCriteriaBuilderImpl implements ProductSearchCriteriaBuilder {
    public static final String LEXICON_PRODUCT = "lexiconProduct";
    public static final String LEXICON_PRODUCT_RELATIONSHIP_XREF_ALIAS =  "lexiconProductRelationshipX";
    public static final String PRODUCT_RELATIONSHIP = "productRelationship";
    public static final String BASE_PRODUCT_ALIAS = "baseProduct";
    public static final String LOGICAL_DELETE_ALIAS = "logicalDelete";
    public static final String ID = "id";
    public static final String LEXICON_PRODUCT_STAGES_ALIAS = "lexiconProductStages";
    public static final String PRE_COMMERCIAL_NAME = "preCommercialName";
    public static final String PRE_COMMERCIAL_NAME_ALIAS = PRE_COMMERCIAL_NAME;
    public static final String COMMERCIAL_NAME = "commercialName";
    public static final String COMMERCIAL_NAME_ALIAS = COMMERCIAL_NAME;
    public static final String MANUFACTURING_NAME_ALIAS = "manufacturingName";
    public static final String BASE_MANUFACTURING_NAME_ALIAS = "baseManufacturingName";
    public static final String SEPARATOR = ".";
    public static final String TAG_VARIETY_NAME_ALIAS = "tagVarietyName";
    public static final String VARIETY_NAME_ALIAS = "varietyName";
    public static final String LEXICON_BRAND_ALIAS = "lexiconBrand";
    public static final String NAME = "name";
    public static final String NAME_ALIAS = NAME;
    public static final String LEXICON_COUNTRY_ALIAS = "lexiconCountry";
    public static final String PUBKEY_ALIAS = "pubkey";
    public static final String STAGE_ALIAS = "lexiconStage";
    public static final String ABBREVIATION = "abbreviation";
    public static final String LEXICON_CROP = "lexiconCrop";
    public static final String CROP_ALIAS = "crop";
    public static final String COMMERCIAL_TRAIT_STACK = "commercialTraitStack";
    public static final String ALTERNATE_NAMES = "alternateNames";
    public static final String ALTERNATE_NAME = "alternateName";
    public static final String REPORTING_NAME = "reportingName";
    public static final String COMMERCIAL_TRAIT_NAME = "commercialTraitName";
    public static final String COMMERCIAL_TRAIT_NAMES = COMMERCIAL_TRAIT_NAME + "s";
    public static final String EXCEPTION_CODE = "exceptionCode";
    public static final String PRODUCT_NAME = "productName";
    public static final String EXCEPTION_CODE_CRITERIA = "exceptionCodeCriteria";
    public static final String PRODUCT_CLASSIFICATION = "productClassification";
    public static final String FAMILY = "family";
    public static final String PRODUCT_CLASSIFICATION_FAMILY = "productClassificationFamily";
    public static final String MATERIAL_GROUP = "materialGroup";
    public static final String PRODUCT_CLASSIFICATION_MATERIAL_GROUP = "productClassificationMaterialGroup";
    public static final String MATERIAL_PRICING_GROUP = "materialPricingGroup";
    public static final String PRODUCT_CLASSIFICATION_MATERIAL_PRICING_GROUP = "productClassificationMaterialPricingGroup";
    public static final String PRODUCTION_ENVIRONMENT = "productionEnvironment";
    public static final String PRODUCT_CLASSIFICATION_PRODUCTION_ENVIRONMENT = "productClassificationProductionEnvironment";
    public static final String PRODUCT_CLASSIFICATION_PRODUCT_TYPE = "productClassificationProductType";
    public static final String PRODUCT_TYPE = "productType";
    public static final String ACTIVE = "active";
    public static final String PRODUCT_GERMPLASM = "ProductGermplasm";
    public static final String DELETED = "deleted";
    public static final String LINE_CODE = "lineCode";
    public static final String ORIGIN = "origin";
    public static final String MIDAS_PRODUCT = "midasProduct";
    public static final String FBS_COMMON_PRODUCT_XREFS = "fbsCommonProductXrefs";
    public static final String FBS_COMMON_PRODUCT_XREF = "fbsCommonProductXref";
    public static final String GERMPLASM = "germplasm";
    public static final String PRODUCT_GERMPLASMS = "productGermplasms";
    public static final String GENETIC_MATERIALS = "geneticMaterials";
    public static final String PARENT_PRODUCT = "parentProduct";
    public static final String STAGE_EXCEPTION_CODE = "stageExceptionCode";
    public static final String PRODUCT_EXCEPTION_CODE = "productExceptionCode";

    @Override
    public DetachedCriteria buildProductSearchCriteria(Session session,List<String> cropPubkeys, LexiconProductSearchCriteria searchCriteria) {

        DetachedCriteria lexiconProductCriteria = DetachedCriteria.forClass(LexiconProductEntity.class, LEXICON_PRODUCT);
        DetachedCriteria lexiconProductStageCriteria = DetachedCriteria.forClass(LexiconProductStageEntity.class,LEXICON_PRODUCT_STAGES_ALIAS);
        lexiconProductStageCriteria.add(Restrictions.eqProperty(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+"lexiconProduct.id",LEXICON_PRODUCT + SEPARATOR + ID));
        lexiconProductStageCriteria.setProjection(Projections.property(LEXICON_PRODUCT + SEPARATOR + ID));
        lexiconProductCriteria.add(Subqueries.propertyIn(ID,lexiconProductStageCriteria));
        buildCriteria(searchCriteria, cropPubkeys,lexiconProductCriteria,lexiconProductStageCriteria);
        buildExceptionCodeCriteria(searchCriteria,lexiconProductCriteria);
        buildProductNameCriteria(searchCriteria, lexiconProductCriteria);
        return lexiconProductCriteria;
    }

    @Override
    public DetachedCriteria buildProductSearchCriteriaOrdered(Session session, List<String> cropPubkeys, LexiconProductSearchCriteria searchCriteria) {
        DetachedCriteria lexiconProductCriteria = buildProductSearchCriteria(session,cropPubkeys,searchCriteria);
        lexiconProductCriteria.addOrder(Order.asc(PUBKEY_ALIAS));
        return lexiconProductCriteria;
    }

    @Override
    public DetachedCriteria buildProductStageSearchCriteria(Session session,List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria) {

       DetachedCriteria productStageCriteria =    DetachedCriteria.forClass(LexiconProductStageEntity.class,LEXICON_PRODUCT_STAGES_ALIAS);

       DetachedCriteria lexiconProductCriteria =   productStageCriteria.createCriteria(LEXICON_PRODUCT,LEXICON_PRODUCT,DetachedCriteria.INNER_JOIN);

       buildCriteria(searchCriteria, cropPubkeys, lexiconProductCriteria,productStageCriteria);
       buildExceptionCodeCriteriaForStageSearch(searchCriteria,productStageCriteria);
       buildNameCriteria(searchCriteria, lexiconProductCriteria,productStageCriteria);

       return productStageCriteria;
    }
    @Override
    public DetachedCriteria buildProductStageSearchCriteriaOrdered(Session session, List<String> cropPubkeys, LexiconProductSearchCriteria searchCriteria) {
       DetachedCriteria productStageCriteria =  buildProductStageSearchCriteria(session,cropPubkeys,searchCriteria);
       productStageCriteria.setResultTransformer(DetachedCriteria.DISTINCT_ROOT_ENTITY);
       productStageCriteria.addOrder(Order.asc(LEXICON_PRODUCT+SEPARATOR+PUBKEY_ALIAS));
       productStageCriteria.addOrder(Order.asc(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+PUBKEY_ALIAS));
       return productStageCriteria;
    }
    private void buildCriteria(LexiconProductSearchCriteria searchCriteria,List<String> cropPubkeys, DetachedCriteria lexiconProductCriteria,DetachedCriteria lexiconProductStageCriteria) {
        if (!searchCriteria.isIncludeLogicalDelete()){
            lexiconProductCriteria.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));

            lexiconProductStageCriteria.add(Restrictions.eq(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+LOGICAL_DELETE_ALIAS,false));
        }
        lexiconProductCriteria.createAlias(LEXICON_CROP, CROP_ALIAS,DetachedCriteria.INNER_JOIN);
        lexiconProductCriteria.createAlias(PRODUCT_CLASSIFICATION, PRODUCT_CLASSIFICATION,DetachedCriteria.LEFT_JOIN);
        lexiconProductCriteria.createAlias(FBS_COMMON_PRODUCT_XREFS,FBS_COMMON_PRODUCT_XREF, (searchCriteria.isIncludeLogicalDelete()?DetachedCriteria.LEFT_JOIN:DetachedCriteria.INNER_JOIN));


        lexiconProductCriteria.createAlias(FBS_COMMON_PRODUCT_XREF+SEPARATOR+MIDAS_PRODUCT,MIDAS_PRODUCT,(searchCriteria.isIncludeLogicalDelete()?DetachedCriteria.LEFT_JOIN:DetachedCriteria.INNER_JOIN));



        buildProductTypeCriteria(searchCriteria,lexiconProductCriteria);

        buildBrandCriteria(searchCriteria, lexiconProductStageCriteria);
        buildCountryCriteria(searchCriteria,lexiconProductStageCriteria);
        buildProductPubkeyCriteria(searchCriteria,lexiconProductCriteria);
        buildProductStagePubkeyCriteria(searchCriteria,lexiconProductStageCriteria);
        buildProductStageCriteria(searchCriteria,lexiconProductStageCriteria);
        buildStageTypeCriteria(searchCriteria,lexiconProductStageCriteria);
        buildCropCriteria(searchCriteria,cropPubkeys,lexiconProductCriteria);
        buildComlTraitCriteria(searchCriteria,lexiconProductStageCriteria);
        buildClassificationFamilyCriteria(searchCriteria,lexiconProductCriteria);
        buildClassificationMaterialGroupCriteria(searchCriteria,lexiconProductCriteria);
        buildClassificationMaterialPricingGroupCriteria(searchCriteria,lexiconProductCriteria);
        buildClassificationProductionEnvironmentCriteria(searchCriteria,lexiconProductCriteria);
        buildClassificationProductTypeCriteria(searchCriteria,lexiconProductCriteria);
        buildGermplasmCriteria(searchCriteria,lexiconProductCriteria);
        buildProductStageActiveCriteria(searchCriteria,lexiconProductStageCriteria);
        return;
    }

    private void buildProductStageActiveCriteria(LexiconProductSearchCriteria searchCriteria,DetachedCriteria lexiconProductStageCriteria){
        if(searchCriteria.isActiveProductsOnly()){
            lexiconProductStageCriteria.add(Restrictions.eq(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+ ACTIVE,true));
        }
    }
    private void buildComlTraitCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductStageCriteria) {

        List<String> commercialTraits = filterBlanks(searchCriteria.getCommercialTraits());
        if( commercialTraits !=null&&!commercialTraits.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            Junction comlTraitNameJunction =searchCriteria.isTraitsAnd()?Restrictions.conjunction():Restrictions.disjunction();
            DetachedCriteria commercialTraitStackCriteria = DetachedCriteria.forClass(CommercialTraitStackEntity.class, COMMERCIAL_TRAIT_STACK);
            commercialTraitStackCriteria.createCriteria(ALTERNATE_NAMES,ALTERNATE_NAME,DetachedCriteria.LEFT_JOIN);
            commercialTraitStackCriteria.createCriteria(COMMERCIAL_TRAIT_NAMES, COMMERCIAL_TRAIT_NAME,DetachedCriteria.LEFT_JOIN);
            Disjunction traitOr = Restrictions.disjunction();
            for(String comlTrait: commercialTraits){
                traitOr.add(likeUpper(ALTERNATE_NAME+SEPARATOR+ REPORTING_NAME, comlTrait));
                traitOr.add(likeUpper(REPORTING_NAME,comlTrait));
                comlTraitNameJunction.add(likeUpper(COMMERCIAL_TRAIT_NAME+SEPARATOR+ABBREVIATION,comlTrait));
            }
            traitOr.add(comlTraitNameJunction);
            commercialTraitStackCriteria.add(traitOr);
            commercialTraitStackCriteria.setProjection(Projections.property(ID));
            or.add(Subqueries.propertyIn(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_TRAIT_STACK+SEPARATOR+ID,commercialTraitStackCriteria ));
            lexiconProductStageCriteria.add(or);
        }
    }

    private void buildGermplasmCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria){

        if(hasGermplasmCriteria(searchCriteria)){
//            DetachedCriteria productGermplasmCriteria  = DetachedCriteria.forClass(ProductGermplasmEntity.class,"PRODUCT_GERMPLASM");
//            productGermplasmCriteria.createAlias(PRODUCT_GERMPLASM+SEPARATOR+GERMPLASM,GERMPLASM,DetachedCriteria.LEFT_JOIN);
//            productGermplasmCriteria.createAlias(GERMPLASM+SEPARATOR+ GENETIC_MATERIALS,GENETIC_MATERIALS,DetachedCriteria.LEFT_JOIN);
             DetachedCriteria productGermplasmCriteria = DetachedCriteria.forClass(ProductGermplasmEntity.class, PRODUCT_GERMPLASM);
             DetachedCriteria germplasmCriteria= productGermplasmCriteria.createCriteria(GERMPLASM);
             germplasmCriteria.add(Restrictions.eq(DELETED,false));
             if(StringUtils.isNotBlank(searchCriteria.getLineCode())){
                germplasmCriteria.add(ilike(LINE_CODE,searchCriteria.getLineCode()));
             }
             if(StringUtils.isNotBlank(searchCriteria.getOrigin())){
                germplasmCriteria.add(ilike(ORIGIN,searchCriteria.getOrigin()));
             }
             productGermplasmCriteria.setProjection(Projections.property(MIDAS_PRODUCT + SEPARATOR+ID));
             //DetachedCriteria fbsCommonProductXrefCriteria = lexiconProductCriteria.createCriteria(FBS_COMMON_PRODUCT_XREFS, FBS_COMMON_PRODUCT_XREF);

             lexiconProductCriteria.add(Subqueries.propertyIn(FBS_COMMON_PRODUCT_XREF+SEPARATOR+MIDAS_PRODUCT +SEPARATOR+ ID,productGermplasmCriteria));
        }
    }


    private boolean hasGermplasmCriteria(LexiconProductSearchCriteria searchCriteria) {
        return StringUtils.isNotBlank(searchCriteria.getLineCode())||StringUtils.isNotBlank(searchCriteria.getOrigin());
    }

    private void buildExceptionCodeCriteriaForStageSearch(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductStageCriteria) {
        if(StringUtils.isNotBlank(searchCriteria.getExceptionCode())){

            Disjunction or = Restrictions.disjunction();


            DetachedCriteria productStagesCriteria  = DetachedCriteria.forClass(LexiconProductStageEntity.class,LEXICON_PRODUCT_STAGES_ALIAS) ;
            DetachedCriteria productCriteria = productStagesCriteria.createCriteria(LEXICON_PRODUCT,LEXICON_PRODUCT);
            if (!searchCriteria.isIncludeLogicalDelete()) {
                productCriteria.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));
                productStagesCriteria.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));
            }

            DetachedCriteria exceptionCodeCriteria = DetachedCriteria.forClass(ExceptionCodeEntity.class);
            exceptionCodeCriteria.add(Restrictions.eqProperty(LEXICON_CROP+SEPARATOR+ID,LEXICON_PRODUCT+SEPARATOR+LEXICON_CROP+SEPARATOR+ID));
            exceptionCodeCriteria.add(Restrictions.eq(EXCEPTION_CODE,searchCriteria.getExceptionCode()));
            exceptionCodeCriteria.setProjection(Projections.property(PRODUCT_NAME));




            Conjunction productAnd = Restrictions.conjunction();
            productAnd.add(Restrictions.isNull(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_NAME));
            productAnd.add(Subqueries.propertyIn(LEXICON_PRODUCT+SEPARATOR+PRE_COMMERCIAL_NAME,exceptionCodeCriteria));

            Conjunction stageAnd = Restrictions.conjunction();
            stageAnd.add(Restrictions.isNotNull(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_NAME));
            stageAnd.add(Subqueries.propertyIn(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_NAME,exceptionCodeCriteria));

            or.add(productAnd);
            or.add(stageAnd);
            productStagesCriteria.add(or);
            productStagesCriteria.setProjection(Projections.property(ID));
            lexiconProductStageCriteria.add(Subqueries.propertyIn(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+ID,productStagesCriteria ));
        }
    }
    private void buildExceptionCodeCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if(StringUtils.isNotBlank(searchCriteria.getExceptionCode())){

            Disjunction or = Restrictions.disjunction();


            DetachedCriteria productCriteria  = DetachedCriteria.forClass(LexiconProductEntity.class,LEXICON_PRODUCT) ;
            if (!searchCriteria.isIncludeLogicalDelete()) {
                productCriteria.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));
            }
            DetachedCriteria exceptionCodeCriteria = DetachedCriteria.forClass(ExceptionCodeEntity.class);
            exceptionCodeCriteria.add(Restrictions.eqProperty(LEXICON_CROP+SEPARATOR+ID,LEXICON_PRODUCT+SEPARATOR+LEXICON_CROP+SEPARATOR+ID));
            exceptionCodeCriteria.add(Restrictions.eq(EXCEPTION_CODE,searchCriteria.getExceptionCode()));
            exceptionCodeCriteria.setProjection(Projections.property(PRODUCT_NAME));

            DetachedCriteria productStageCriteria = productCriteria.createCriteria(LEXICON_PRODUCT_STAGES_ALIAS,LEXICON_PRODUCT_STAGES_ALIAS,DetachedCriteria.LEFT_JOIN);
            if (!searchCriteria.isIncludeLogicalDelete()){
                productStageCriteria.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));
            }
            Conjunction productAnd = Restrictions.conjunction();
            productAnd.add(Restrictions.isNull(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_NAME));
            productAnd.add(Subqueries.propertyIn(LEXICON_PRODUCT+SEPARATOR+PRE_COMMERCIAL_NAME,exceptionCodeCriteria));

            Conjunction stageAnd = Restrictions.conjunction();
            stageAnd.add(Restrictions.isNotNull(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_NAME));
            stageAnd.add(Subqueries.propertyIn(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+COMMERCIAL_NAME,exceptionCodeCriteria));

            or.add(productAnd);
            or.add(stageAnd);
            productCriteria.add(or);
            productCriteria.setProjection(Projections.property(ID));
            lexiconProductCriteria.add(Subqueries.propertyIn(LEXICON_PRODUCT+SEPARATOR+ID,productCriteria ));
        }
    }
    private  List<String> filterBlanks(List<String> values){
        if(values==null){
            return  values;
        }
        else {
            List<String> filtered = new ArrayList<String>();
            for(String element: values){
                if(StringUtils.isNotBlank(element)){
                    filtered.add(element);
                }
            }
            return filtered;
        }
    }
    private void buildProductPubkeyCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        List<String> productPubkeys = filterBlanks(searchCriteria.getProductPubkeys());
        if( productPubkeys !=null&&!productPubkeys.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            for(String pubkey:productPubkeys){
                or.add(likeUpper(PUBKEY_ALIAS, pubkey));
            }
            lexiconProductCriteria.add(or);
        }
    }
    private void buildCropCriteria(LexiconProductSearchCriteria searchCriteria, List<String> cropPubkeys,DetachedCriteria lexiconProductCriteria) {
        List<String> crops = filterBlanks(searchCriteria.getCrops());
        if( crops !=null&&!crops.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            for(String crop: crops){
                or.add(likeUpper(CROP_ALIAS +SEPARATOR+ NAME_ALIAS, crop));
            }
            lexiconProductCriteria.add(or);
        }
        lexiconProductCriteria.add(Restrictions.in(CROP_ALIAS +SEPARATOR+ PUBKEY_ALIAS, cropPubkeys));
    }
    private void buildClassificationFamilyCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if( StringUtils.isNotBlank(searchCriteria.getClassificationFamily())){
            DetachedCriteria criteria=lexiconProductCriteria.createCriteria(PRODUCT_CLASSIFICATION+SEPARATOR+ FAMILY, PRODUCT_CLASSIFICATION_FAMILY,DetachedCriteria.LEFT_JOIN);
            criteria.add(Restrictions.eq(NAME,searchCriteria.getClassificationFamily()));
        }
    }
    private void buildClassificationMaterialGroupCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if( StringUtils.isNotBlank(searchCriteria.getClassificationMaterialGroup())){
            DetachedCriteria criteria=lexiconProductCriteria.createCriteria(PRODUCT_CLASSIFICATION+SEPARATOR+ MATERIAL_GROUP, PRODUCT_CLASSIFICATION_MATERIAL_GROUP,DetachedCriteria.LEFT_JOIN);
            criteria.add(Restrictions.eq(NAME,searchCriteria.getClassificationMaterialGroup()));
        }
    }
    private void buildClassificationMaterialPricingGroupCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if( StringUtils.isNotBlank(searchCriteria.getClassificationMaterialPricingGroup())){
            DetachedCriteria criteria=lexiconProductCriteria.createCriteria(PRODUCT_CLASSIFICATION+SEPARATOR+ MATERIAL_PRICING_GROUP, PRODUCT_CLASSIFICATION_MATERIAL_PRICING_GROUP,DetachedCriteria.LEFT_JOIN);
            criteria.add(Restrictions.eq(NAME,searchCriteria.getClassificationMaterialPricingGroup()));
        }
    }
    private void buildClassificationProductionEnvironmentCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if( StringUtils.isNotBlank(searchCriteria.getClassificationProductionEnvironment())){
            DetachedCriteria criteria=lexiconProductCriteria.createCriteria(PRODUCT_CLASSIFICATION+SEPARATOR+ PRODUCTION_ENVIRONMENT, PRODUCT_CLASSIFICATION_PRODUCTION_ENVIRONMENT,DetachedCriteria.LEFT_JOIN);
            criteria.add(Restrictions.eq(NAME,searchCriteria.getClassificationProductionEnvironment()));
        }
    }
    private void buildClassificationProductTypeCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if( StringUtils.isNotBlank(searchCriteria.getClassificationProductType())){
            DetachedCriteria criteria=lexiconProductCriteria.createCriteria(PRODUCT_CLASSIFICATION+SEPARATOR+ PRODUCT_TYPE, PRODUCT_CLASSIFICATION_PRODUCT_TYPE,DetachedCriteria.LEFT_JOIN);
            criteria.add(Restrictions.eq(NAME,searchCriteria.getClassificationProductType()));
        }
    }
    private void buildProductStageCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductStageCriteria) {
        List<String> stages = filterBlanks(searchCriteria.getStages());
        if( stages !=null&&!stages.isEmpty()){
            lexiconProductStageCriteria.createAlias(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+STAGE_ALIAS,STAGE_ALIAS,DetachedCriteria.LEFT_JOIN);
            Disjunction or = Restrictions.disjunction();
            for(String stage: stages){
                or.add(likeUpper(STAGE_ALIAS +SEPARATOR+ ABBREVIATION, stage));
            }
            lexiconProductStageCriteria.add(or);
        }
    }
    private void buildStageTypeCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductStageCriteria) {
        if( searchCriteria.getStageType()!=null){
            lexiconProductStageCriteria.add(Restrictions.eq(STAGE_ALIAS +SEPARATOR+"commercial",Boolean.valueOf(searchCriteria.getStageType()== StageType.COMMERCIAL)));
        }
    }

    private void buildProductStagePubkeyCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        List<String> productStagePubkeys = filterBlanks(searchCriteria.getProductStagePubkeys());
        if( productStagePubkeys !=null&&!productStagePubkeys.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            for(String pubkey: productStagePubkeys){
                or.add(likeUpper(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+PUBKEY_ALIAS, pubkey));
            }
            lexiconProductCriteria.add(or);
        }
    }
    private void buildCountryCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        List<String> countries = filterBlanks(searchCriteria.getCountries());
        if( countries !=null&&!countries.isEmpty()){
            DetachedCriteria countryCriteria =  lexiconProductCriteria.createCriteria(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+ LEXICON_COUNTRY_ALIAS, LEXICON_COUNTRY_ALIAS,DetachedCriteria.LEFT_JOIN);
            Disjunction or = Restrictions.disjunction();
            for(String country: countries){
                or.add(likeUpper(LEXICON_COUNTRY_ALIAS + SEPARATOR + ABBREVIATION, country));
            }
            lexiconProductCriteria.add(or);
        }
    }
    private void buildBrandCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductStageCriteria) {
        List<String> brandNames = filterBlanks(searchCriteria.getBrandNames());
        if( brandNames !=null&&!brandNames.isEmpty()){
            lexiconProductStageCriteria.createAlias(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+LEXICON_BRAND_ALIAS, LEXICON_BRAND_ALIAS,DetachedCriteria.LEFT_JOIN);
            Disjunction or = Restrictions.disjunction();
            for(String brandName: brandNames){
                or.add(likeUpper(LEXICON_BRAND_ALIAS + SEPARATOR + NAME_ALIAS, brandName));
            }
            lexiconProductStageCriteria.add(or);
        }
    }



    private void buildNameCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria,DetachedCriteria lexiconProductStageCriteria) {
        List<String> productNames = filterBlanks(searchCriteria.getProductNames());
        if(!productNames.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            NameType nameType = searchCriteria.getNameType();



            buildPreCommmercialProductsNameCriteria(searchCriteria, lexiconProductCriteria,or, nameType);
            buildCommercialNameCriteria(searchCriteria,  or, nameType,lexiconProductStageCriteria);

            if(nameTypeSelected(nameType, NameType.MANUFACTURING,NameType.BASE_MANUFACTURING)){
                DetachedCriteria productRelationshipXrefCriteria = DetachedCriteria.forClass(ProductRelationshipXrefEntity.class, LEXICON_PRODUCT_RELATIONSHIP_XREF_ALIAS);
               // DetachedCriteria prxProductCriteria = productRelationshipXrefCriteria.createCriteria(LEXICON_PRODUCT);
                 DetachedCriteria productRelationshipCriteria =  productRelationshipXrefCriteria.createCriteria(PRODUCT_RELATIONSHIP, PRODUCT_RELATIONSHIP,DetachedCriteria.INNER_JOIN)
                                 .createCriteria(BASE_PRODUCT_ALIAS, BASE_PRODUCT_ALIAS,DetachedCriteria.INNER_JOIN);
                Disjunction orPrx = Restrictions.disjunction();
                buildManufacturingNameCriteria(searchCriteria, nameType, productRelationshipXrefCriteria, orPrx);
                buildBaseManufacturingNameCriteria(searchCriteria, nameType, productRelationshipXrefCriteria, orPrx);

                productRelationshipXrefCriteria.add(orPrx);
                productRelationshipXrefCriteria.setProjection(Projections.property(LEXICON_PRODUCT + SEPARATOR + ID));
                or.add(Subqueries.propertyIn(ID,productRelationshipXrefCriteria ));
            }
            lexiconProductCriteria.add(or);
        }
    }

    private static String PRODUCT_PRE_COML_NAME_SQL= " (select PRODUCT_ID from Lexicon.PRE_COML_PRODUCT pcp where pcp.logical_delete='n' and pcp.pre_coml_name like ? )";
    private static String PRODUCT_PRE_COML_NAME_ALL_SQL= " (select PRODUCT_ID from Lexicon.PRE_COML_PRODUCT pcp where pcp.pre_coml_name like ? )";
    private static String PRODUCT_VARIETY_NAME_SQL= " (select PRODUCT_ID from Lexicon.PRE_COML_PRODUCT pcp where pcp.logical_delete='n' and pcp.tag_variety_name like ? )";
    private static String PRODUCT_VARIETY_NAME_ALL_SQL= " (select PRODUCT_ID from Lexicon.PRE_COML_PRODUCT pcp where pcp.tag_variety_name like ? )";
    private static String PRODUCT_COML_NAME_SQL= " (select ps.PRODUCT_ID from Lexicon.PRODUCT_STAGE PS inner join Lexicon.PRE_COML_PRODUCT pcp on pcp.product_id=ps.product_id " +
                                                 " where ps.logical_delete='n' and ps.COMMERCIAL_NAME like ? )" ;
    private static String PRODUCT_COML_NAME_ALL_SQL= " (select ps.PRODUCT_ID from Lexicon.PRODUCT_STAGE PS inner join Lexicon.PRE_COML_PRODUCT pcp on pcp.product_id=ps.product_id " +
                                                 " where ps.COMMERCIAL_NAME like ? )" ;
    private static String MANUFACTURING_NAME_LOGICAL_DELETE_SET = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  where PR.LOGICAL_DELETE='n' and PR.MANUFACTURING_NAME like ? ) ";
    private static String MANUFACTURING_NAME_LOGICAL_DELETE_NULL = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  where PR.LOGICAL_DELETE is null and PR.MANUFACTURING_NAME like ? ) ";
  private static String MANUFACTURING_NAME_ALL = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                             "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                             "  where PR.MANUFACTURING_NAME like ? ) ";
    private static String BASEMANUFACTURING_NAME_LOGICAL_DELETE_NULL_NULL = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  inner join Lexicon.BASE_PRODUCT BP on PR.BASE_PRODUCT_ID=BP.BASE_PRODUCT_ID "+
                                               "  where PR.LOGICAL_DELETE is null and BP.LOGICAL_DELETE is null and BP.BASE_MANUFACTURING_NAME like ? ) ";
    private static String BASEMANUFACTURING_NAME_LOGICAL_DELETE_SET_NULL = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  inner join Lexicon.BASE_PRODUCT BP on PR.BASE_PRODUCT_ID=BP.BASE_PRODUCT_ID "+
                                               "  where PR.LOGICAL_DELETE='n' and BP.LOGICAL_DELETE is null and BP.BASE_MANUFACTURING_NAME like ? ) ";
    private static String BASEMANUFACTURING_NAME_LOGICAL_DELETE_NULL_SET = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  inner join Lexicon.BASE_PRODUCT BP on PR.BASE_PRODUCT_ID=BP.BASE_PRODUCT_ID "+
                                               "  where PR.LOGICAL_DELETE is null and BP.LOGICAL_DELETE='n' and BP.BASE_MANUFACTURING_NAME like ? ) ";
    private static String BASEMANUFACTURING_NAME_LOGICAL_DELETE_SET_SET = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  inner join Lexicon.BASE_PRODUCT BP on PR.BASE_PRODUCT_ID=BP.BASE_PRODUCT_ID "+
                                               "  where PR.LOGICAL_DELETE='n' and BP.LOGICAL_DELETE='n' and BP.BASE_MANUFACTURING_NAME like ? ) ";
    private static String BASEMANUFACTURING_NAME_ALL = " (select PRODUCT_ID from Lexicon.PRODUCT_RELATIONSHIP_XREF PRX " +
                                               "  inner join Lexicon.PRODUCT_RELATIONSHIP PR on PRX.PRODUCT_RELATIONSHIP_ID=PR.PRODUCT_RELATIONSHIP_ID" +
                                               "  inner join Lexicon.BASE_PRODUCT BP on PR.BASE_PRODUCT_ID=BP.BASE_PRODUCT_ID "+
                                               "  where BP.BASE_MANUFACTURING_NAME like ? ) ";

    private void buildProductNameCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        List<String> productNames = filterBlanks(searchCriteria.getProductNames());
        if(!productNames.isEmpty()){
            List<String> nameCriteria = new ArrayList<String>(productNames.size()*9);
            List<Type> types = new ArrayList<Type>(productNames.size()*9);
            StringBuilder sb = new StringBuilder("{alias}.PRODUCT_ID in ( ");
            boolean addUnion=false;
            for(String productNameRaw: productNames){
                String productName = productNameRaw.replace("*","%");
                if(nameTypeSelected(searchCriteria.getNameType(),NameType.PRE_COMMERCIAL)){
                    if(addUnion){
                        sb.append(" UNION ALL ");
                    }
                    sb.append((searchCriteria.isIncludeLogicalDelete())?PRODUCT_PRE_COML_NAME_ALL_SQL:PRODUCT_PRE_COML_NAME_SQL);
                    nameCriteria.add(productName);
                    types.add(new StringType());
                    addUnion=true;
                }
                if(nameTypeSelected(searchCriteria.getNameType(),NameType.VARIETY)){
                    if(addUnion){
                        sb.append(" UNION ALL ");
                    }
                    sb.append(searchCriteria.isIncludeLogicalDelete()?PRODUCT_VARIETY_NAME_ALL_SQL:PRODUCT_VARIETY_NAME_SQL);
                    nameCriteria.add(productName);
                    types.add(new StringType());
                    addUnion=true;
                }
                if(nameTypeSelected(searchCriteria.getNameType(),NameType.COMMERCIAL)){
                    if(addUnion){
                        sb.append(" UNION ALL ");
                    }
                    sb.append(searchCriteria.isIncludeLogicalDelete()?PRODUCT_COML_NAME_ALL_SQL:PRODUCT_COML_NAME_SQL);
                    nameCriteria.add(productName);
                    types.add(new StringType());
                    addUnion=true;
                }
                if(nameTypeSelected(searchCriteria.getNameType(),NameType.MANUFACTURING)){
                    if(addUnion){
                        sb.append(" UNION ALL ");
                    }
                    if (searchCriteria.isIncludeLogicalDelete()) {
                        sb.append(MANUFACTURING_NAME_ALL);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                    }   else {
                        sb.append(MANUFACTURING_NAME_LOGICAL_DELETE_SET);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                        sb.append(" UNION ALL ");
                        sb.append(MANUFACTURING_NAME_LOGICAL_DELETE_NULL);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                    }
                    addUnion=true;
                }
                if(nameTypeSelected(searchCriteria.getNameType(),NameType.BASE_MANUFACTURING)){
                    if(addUnion){
                        sb.append(" UNION ALL ");
                    }
                    if (searchCriteria.isIncludeLogicalDelete()){
                        sb.append(BASEMANUFACTURING_NAME_ALL);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                    }   else {
                        sb.append(BASEMANUFACTURING_NAME_LOGICAL_DELETE_NULL_NULL);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                        sb.append(" UNION ALL ");
                        sb.append(BASEMANUFACTURING_NAME_LOGICAL_DELETE_SET_NULL);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                        sb.append(" UNION ALL ");
                        sb.append(BASEMANUFACTURING_NAME_LOGICAL_DELETE_SET_SET);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                        sb.append(" UNION ALL ");
                        sb.append(BASEMANUFACTURING_NAME_LOGICAL_DELETE_NULL_SET);
                        nameCriteria.add(productName);
                        types.add(new StringType());
                    }
                    addUnion=true;
                }
            }
            sb.append(" )");
            lexiconProductCriteria.add(Restrictions.sqlRestriction(sb.toString(),nameCriteria.toArray(new Object[nameCriteria.size()]),types.toArray(new Type[types.size()])));
        }
    }

    private void buildPreCommmercialProductsNameCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria, Disjunction or, NameType nameType) {
        if(nameTypeSelected(nameType, NameType.PRE_COMMERCIAL,NameType.VARIETY)){
            DetachedCriteria subquery = DetachedCriteria.forClass(LexiconProductEntity.class);
            if (!searchCriteria.isIncludeLogicalDelete()) {
                subquery.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));
            }
            Disjunction nameOr = Restrictions.disjunction();
            subquery.add(nameOr);
            List<String> productNames = filterBlanks(searchCriteria.getProductNames());
            for(String name: productNames){
               if(nameTypeSelected(nameType,NameType.PRE_COMMERCIAL)){
                  nameOr.add(likeUpper(PRE_COMMERCIAL_NAME_ALIAS,name));
               }
                if(nameTypeSelected(nameType, NameType.VARIETY)){
                   nameOr.add(likeUpper(TAG_VARIETY_NAME_ALIAS,name));
                }
            }
            subquery.setProjection(Projections.property(ID));
            or.add(Subqueries.propertyIn(ID,subquery));
        }

    }
    private void buildProductTypeCriteria(LexiconProductSearchCriteria searchCriteria, DetachedCriteria lexiconProductCriteria) {
        if(searchCriteria.getProductType()!=null){
            lexiconProductCriteria.add(Restrictions.eq(PARENT_PRODUCT,Boolean.valueOf(searchCriteria.getProductType()== LexiconProductType.PARENTS)));
        }
    }    

    private void buildCommercialNameCriteria(LexiconProductSearchCriteria searchCriteria,  Disjunction or, NameType nameType,DetachedCriteria stageCriteria) {
        Disjunction stageOr = Restrictions.disjunction();
        List<String> productNames = filterBlanks(searchCriteria.getProductNames());
        if((nameTypeSelected(nameType, NameType.COMMERCIAL)&&!productNames.isEmpty())){
           DetachedCriteria lexiconProductStageCriteria = DetachedCriteria.forClass(LexiconProductStageEntity.class);
;
            if(stageCriteria==null){
               lexiconProductStageCriteria.setProjection(Projections.property(LEXICON_PRODUCT + SEPARATOR + ID));
               or.add(Subqueries.propertyIn(ID,lexiconProductStageCriteria));
            }
            else {
               lexiconProductStageCriteria.setProjection(Projections.property(ID));
               or.add(Subqueries.propertyIn(LEXICON_PRODUCT_STAGES_ALIAS+SEPARATOR+ID,lexiconProductStageCriteria));
            }
            for(String name: productNames){
               Conjunction and = Restrictions.conjunction();
               and.add( likeUpper( COMMERCIAL_NAME_ALIAS,name));
               if (searchCriteria.isIncludeLogicalDelete())  {
                  and.add(Restrictions.eq(LOGICAL_DELETE_ALIAS,false));
               }
               if(searchCriteria.isActiveProductsOnly()){
                  and.add(Restrictions.eq(ACTIVE,true));
               }
               stageOr.add(and);
            }
            lexiconProductStageCriteria.add(stageOr);

        }
    }

//    private void buildVarietyNameCriteria(LexiconProductSearchCriteria searchCriteria, Disjunction or, NameType nameType) {
//        if(nameTypeSelected(nameType, NameType.VARIETY)){
//            for(String name: searchCriteria.getProductNames()){
//               or.add(likeUpper(TAG_VARIETY_NAME_ALIAS,name));
//            }
//        }
//    }

    private void buildBaseManufacturingNameCriteria(LexiconProductSearchCriteria searchCriteria, NameType nameType, DetachedCriteria productRelationshipXrefCriteria, Disjunction orPrx) {
        if(nameTypeSelected(nameType, NameType.BASE_MANUFACTURING)){
            List<String> productNames = filterBlanks(searchCriteria.getProductNames());
            for(String name: productNames){
               Conjunction and = new Conjunction();
               and.add(likeUpper(BASE_PRODUCT_ALIAS + SEPARATOR + BASE_MANUFACTURING_NAME_ALIAS,name));
               if (!searchCriteria.isIncludeLogicalDelete()){
                   productRelationshipXrefCriteria.add(getLogicicalDeleteExpression(BASE_PRODUCT_ALIAS + SEPARATOR + LOGICAL_DELETE_ALIAS));
                   productRelationshipXrefCriteria.add(getLogicicalDeleteExpression(PRODUCT_RELATIONSHIP+ SEPARATOR + LOGICAL_DELETE_ALIAS));
               }
               orPrx.add(and);
            }
        }
    }

    private void buildManufacturingNameCriteria(LexiconProductSearchCriteria searchCriteria, NameType nameType, DetachedCriteria productRelationshipXrefCriteria, Disjunction orPrx) {
        if(nameTypeSelected(nameType, NameType.MANUFACTURING)){
            List<String> productNames = filterBlanks(searchCriteria.getProductNames());
            for(String name: productNames){
               Conjunction and = new Conjunction();
               and.add(likeUpper(PRODUCT_RELATIONSHIP+ SEPARATOR + MANUFACTURING_NAME_ALIAS,name));
               if (!searchCriteria.isIncludeLogicalDelete()){
                  and.add(getLogicicalDeleteExpression(PRODUCT_RELATIONSHIP+ SEPARATOR + LOGICAL_DELETE_ALIAS));
               }
               orPrx.add(and);
            }
        }
    }

    private Disjunction getLogicicalDeleteExpression(String alias){
        Disjunction or = Restrictions.disjunction();
        or.add(Restrictions.eq(alias,false)) ;
        or.add(Restrictions.isNull(alias));
        return or;

    }


    private boolean nameTypeSelected(NameType selectedNameType, NameType ... nameTypes) {
        boolean nameTypeSelected = false;
        for(NameType nameType:nameTypes){
          nameTypeSelected |= (selectedNameType ==null|| selectedNameType.equals(nameType));
        }
        return nameTypeSelected;
    }
    private Criterion likeUpper(String propertyName, String propertyValue) {
        return Restrictions.like(propertyName,propertyValue.toUpperCase().replace('*','%'),MatchMode.EXACT);
    }
    private Criterion ilike(String propertyName, String propertyValue) {
        return Restrictions.ilike(propertyName,propertyValue.replace('*','%'),MatchMode.EXACT);
    }
    
}
