package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 18, 2011
 * Time: 10:55:07 AM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@SequenceGenerator(name = "lexiconProductNameIdGenerator",allocationSize = 1,sequenceName = "Lexicon.UNIQUE_PRODUCT_NAME_ID_SEQ")
@Table(name = "PRODUCT_NAME", schema = "Lexicon")
public class LexiconProductNameEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "lexiconProductNameIdGenerator")
    @Column(name="PRODUCT_NAME_ID")
    private long id;

    @Column(name="PRODUCT_NAME",length=50,nullable=false)
    private String name;

    @Column(name="PRODUCT_NAME_PUBKEY",length=20,nullable=false)
    private String pubkey;


    @Type(type = "boolean-yn")
    @Column(name="IS_ACTIVE",nullable = false)
    private boolean active;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="COUNTRY_ID",nullable = false)
    private LexiconCountryEntity lexiconCountry;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="BRAND_ID",nullable = false)
    private LexiconBrandEntity lexiconBrand;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_ID",nullable = false)
    private CompetitiveProductEntity competitiveProduct;

    @OneToMany( cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_NAME_PUBKEY",referencedColumnName="PRODUCT_NAME_PUBKEY", updatable = false)
    private List<FbsCommonProductNameXrefEntity> fbsCommonProductNameXrefs = new ArrayList<FbsCommonProductNameXrefEntity>(); ;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public CompetitiveProductEntity getCompetitiveProduct() {
        return competitiveProduct;
    }

    public void setCompetitiveProduct(CompetitiveProductEntity competitiveProduct) {
        this.competitiveProduct = competitiveProduct;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconBrandEntity getLexiconBrand() {
        return lexiconBrand;
    }

    public void setLexiconBrand(LexiconBrandEntity lexiconBrand) {
        this.lexiconBrand = lexiconBrand;
    }

    public LexiconCountryEntity getLexiconCountry() {
        return lexiconCountry;
    }

    public void setLexiconCountry(LexiconCountryEntity lexiconCountry) {
        this.lexiconCountry = lexiconCountry;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    @Transient
    public FbsCommonProductNameXrefEntity getFbsCommonProductNameXref() {
        if(fbsCommonProductNameXrefs.size()>0){
            return fbsCommonProductNameXrefs.get(0);
        }
        else {
            return null;
        }
    }

    public void setFbsCommonProductNameXref(FbsCommonProductNameXrefEntity fbsCommonProductNameXref) {
        fbsCommonProductNameXrefs.clear();
        if(fbsCommonProductNameXref!=null){
           fbsCommonProductNameXrefs.add(fbsCommonProductNameXref);
        }
    }

    
    List<FbsCommonProductNameXrefEntity> getFbsCommonProductNameXrefs() {
        return fbsCommonProductNameXrefs;
    }

    void setFbsCommonProductNameXrefs(List<FbsCommonProductNameXrefEntity> fbsCommonProductNameXrefs) {
        this.fbsCommonProductNameXrefs = fbsCommonProductNameXrefs;
    }
}
