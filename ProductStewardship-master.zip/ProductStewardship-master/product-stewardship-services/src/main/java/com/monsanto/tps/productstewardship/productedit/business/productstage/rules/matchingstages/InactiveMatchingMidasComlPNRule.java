package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.matchingstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCountryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class InactiveMatchingMidasComlPNRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconBrandDao lexiconBrandDao;
    private LexiconProductDao lexiconProductDao;
    private LexiconCountryDao lexiconCountryDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        MidasBrandEntity midasBrand = findMidasBrand(model);
        MidasProductEntity midasProduct = findMidasProduct(model);
        MidasCountryEntity midasCountry = findMidasCountry(model);
        if((midasBrand!=null)&&(midasProduct!=null)&&(midasCountry!=null)){
            for(MidasProductNameEntity midasProductName: midasProduct.getMidasProductNames()){
                if((midasProductName.getMidasBrand().getId()==midasBrand.getId())&& (midasBrand.isRefActive()) &&
                   (midasProductName.getMidasCountry().getId()==midasCountry.getId())&& (midasCountry.isRefActive()) &&
                   (!midasProductName.isRefActive())){
                    status.addCondition(new ValidationResult(ProductEditService.MATCHING_INACTIVE_MIDAS_COML_PN_EXISTS_CODE,
                                                             ValidationSeverity.INFO));
                }
            }
        }
    }

    private MidasProductEntity findMidasProduct(StageValidationModel model) {
        LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(model.getProduct().getProductPubkey());
        MidasProductEntity midasProduct1 = null;
        if(lexiconProduct.getFbsCommonProductXref()!=null){
            midasProduct1 = lexiconProduct.getFbsCommonProductXref().getMidasProduct();
        }
        return midasProduct1;
    }

    private MidasCountryEntity findMidasCountry(StageValidationModel model) {
        MidasCountryEntity midasCountry = null;
        if(StringUtils.isNotBlank(model.getProductStage().getCountryAbbreviation())){
            LexiconCountryEntity lexiconCountry = lexiconCountryDao.findByAbbreviation(model.getProductStage().getCountryAbbreviation());
            if((lexiconCountry!=null)&&(!lexiconCountry.getFbsCommonCountryXrefs().isEmpty())){
                midasCountry = lexiconCountry.getFbsCommonCountryXrefs().iterator().next().getMidasCountry();
            }
        }
        return midasCountry;
    }

    private MidasBrandEntity findMidasBrand(StageValidationModel model) {
        LexiconBrandEntity lexiconBrand = null;
        MidasBrandEntity midasBrand = new MidasBrandEntity();
        String brandName = model.getProductStage().getBrandName();
        if(StringUtils.isNotBlank(brandName)){
             lexiconBrand = lexiconBrandDao.getByName(brandName);
        }

        if((lexiconBrand!=null)&&(!lexiconBrand.getFbsCommonBrandXrefs().isEmpty())){
            midasBrand = lexiconBrand.getFbsCommonBrandXrefs().iterator().next().getMidasBrand();
        }
        return midasBrand;
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }

    public void setLexiconCountryDao(LexiconCountryDao lexiconCountryDao) {
        this.lexiconCountryDao = lexiconCountryDao;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
