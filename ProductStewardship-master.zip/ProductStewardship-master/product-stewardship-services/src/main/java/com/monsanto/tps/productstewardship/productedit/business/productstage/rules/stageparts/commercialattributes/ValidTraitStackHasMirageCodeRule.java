package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.KeywordDao;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;
import java.util.List;

public class ValidTraitStackHasMirageCodeRule implements ValidationSimpleRule<StageValidationModel> {
    private CommercialTraitStackDao commercialTraitStackDao;
    private KeywordDao keywordDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
                String comlTraitName = model.getProductStage().getComlTraitName();
        if(StringUtils.isNotBlank(comlTraitName)){
            List<CommercialTraitStackEntity> stacks = commercialTraitStackDao.getByTraitNameAndCrop(comlTraitName,model.getProduct().getLexiconCropName());
            if(!stacks.isEmpty()){
                String tdName = stacks.get(0).getTechDevName();
                if(StringUtils.isBlank(tdName)){
                    tdName= KeywordDao.NON_TRANS_STRING;
                }
                if(keywordDao.findEnabledByTypeAndName(KeywordDao.TRAIT_CHARACTERISTIC,tdName).isEmpty()){
                    status.addCondition(new ValidationResult(ProductEditService.MIRAGE_TRAIT_CODE_NOTFOUND_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    public void setCommercialTraitStackDao(CommercialTraitStackDao commercialTraitStackDao) {
        this.commercialTraitStackDao = commercialTraitStackDao;
    }

    public void setKeywordDao(KeywordDao keywordDao) {
        this.keywordDao = keywordDao;
    }
}
