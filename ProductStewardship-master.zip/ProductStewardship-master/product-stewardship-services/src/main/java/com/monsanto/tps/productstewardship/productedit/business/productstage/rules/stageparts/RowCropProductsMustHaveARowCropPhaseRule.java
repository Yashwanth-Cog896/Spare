package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.StageCategoryEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class RowCropProductsMustHaveARowCropPhaseRule implements ValidationSimpleRule<StageValidationModel> {
    LexiconCropDao lexiconCropDao;
    LexiconStageDao lexiconStageDao;

    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {

        if (StringUtils.isNotBlank(model.getProductStage().getStageAbbreviation()) && (StringUtils.isNotBlank(model.getProduct().getLexiconCropName()))) {
            LexiconStageEntity lexiconStage = lexiconStageDao.findStageByAbbreviation(model.getProductStage().getStageAbbreviation());
            LexiconCropEntity lexiconCrop = lexiconCropDao.getByName(model.getProduct().getLexiconCropName());
            if ((lexiconStage != null) && (lexiconCrop != null)) {
                if ((lexiconCrop.getStageCategory().getName().equals(StageCategoryEntity.NON_VEGETABLE)) && (!lexiconStage.getStageCategories().contains(lexiconCrop.getStageCategory()))) {
                    status.addCondition(new ValidationResult(ProductEditService.ROW_CROP_PRODUCT_WITH_VEGETABLE_PHASE_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
