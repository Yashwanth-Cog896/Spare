package com.monsanto.tps.productstewardship.blend.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 9, 2011
 * Time: 5:54:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlendProductDetailsStrategy implements BlendedSearchStrategy {

    private BlendedComponentsStrategy componentsStrategy;

    private BlendedProductsStrategy productsStrategy;

    @Override
    public Multimap<Long, FbsCommonProductXrefEntity> buildGermplasmIdToProductXrefsMap(Map<Long, FbsCommonProductXrefEntity> xrefByProductIds,
                                                                         BlendedProductDetails productDetails) {
        Multimap<Long, FbsCommonProductXrefEntity> productIdToXrefMap = ArrayListMultimap.create();
        if (xrefByProductIds != null && productDetails != null) {
            productIdToXrefMap.putAll(componentsStrategy.buildGermplasmIdToProductXrefsMap(xrefByProductIds, productDetails));
            productIdToXrefMap.putAll(productsStrategy.buildGermplasmIdToProductXrefsMap(xrefByProductIds, productDetails));
        }
        return productIdToXrefMap;
    }

    @Override
    public LexBlendedProductDetails buildLexBlendedProductDetails(BlendedProductDetails blendedProductDetail, Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductsMap) {
        LexBlendedProductDetails lexProductDetails = new LexBlendedProductDetails();
        lexProductDetails.setBlendedGermplasmId(blendedProductDetail.getGermplasmId());

        LexBlendedProductDetails componentProduct = componentsStrategy.buildLexBlendedProductDetails(blendedProductDetail,
                germplasmIdToPreComlProductsMap);
        LexBlendedProductDetails blendProduct = productsStrategy.buildLexBlendedProductDetails(blendedProductDetail,
                germplasmIdToPreComlProductsMap);
        lexProductDetails.setComponentProductGermplasms(componentProduct.getComponentProductGermplasms());
        lexProductDetails.setBlendedProductGermplasms(blendProduct.getBlendedProductGermplasms());
        return lexProductDetails;
    }

    public void setComponentsStrategy(BlendedComponentsStrategy componentsStrategy) {
        this.componentsStrategy = componentsStrategy;
    }

    public void setProductsStrategy(BlendedProductsStrategy productsStrategy) {
        this.productsStrategy = productsStrategy;
    }
}
