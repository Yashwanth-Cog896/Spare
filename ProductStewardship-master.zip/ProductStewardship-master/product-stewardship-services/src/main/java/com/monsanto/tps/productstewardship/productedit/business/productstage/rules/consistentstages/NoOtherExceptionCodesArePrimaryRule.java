package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.consistentstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.StageCategoryEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class NoOtherExceptionCodesArePrimaryRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductDao lexiconProductDao;
    private LexiconCropDao lexiconCropDao;
  
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean ruleViolated = false;

        ProductStage productStage= model.getProductStage();
        Product product = model.getProduct();


        LexiconCropEntity crop = lexiconCropDao.getByName(product.getLexiconCropName());
        boolean isVegetable =crop.getStageCategory().getName().equals(StageCategoryEntity.VEGETABLE);
        if(isVegetable){
            if(productStage.isPrimary()&&(!productStage.isDelete())){
                for(ProductStage testProductStage: model.getProduct().getProductStages()){
                   if((productStage!=testProductStage)&&
                      (!testProductStage.isDelete())&&
                       testProductStage.isPrimary()&&
                       !StringUtils.equalsIgnoreCase(productStage.getCommercialName(),testProductStage.getCommercialName())){
                          ruleViolated=true;
                          break;
                      }
                   }
                if(!ruleViolated){
                    for(LexiconProductStageEntity testProductStage: loadLexiconProductStagesNotInRequest(model)){
                       if((!testProductStage.isLogicalDelete())&&
                           isPrimaryExceptionCodeNonMatchingStage(productStage, testProductStage)){
                           ruleViolated=true;
                           break;
                        }
                    }
                }
                if(ruleViolated){
                    status.addCondition(new ValidationResult(ProductEditService.ONLY_ONE_EXCEPTION_CODE_MAY_BE_PRIMARY_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    private boolean isPrimaryExceptionCodeNonMatchingStage(ProductStage productStage, LexiconProductStageEntity testProductStage) {
        return (!StringUtils.equalsIgnoreCase(productStage.getCommercialName(),testProductStage.getCommercialName())&&
        (((testProductStage.getExceptionCode()!=null)&&
         (testProductStage.getExceptionCode().isPrimary()))||
        (StringUtils.isBlank(testProductStage.getCommercialName())&&
         testProductStage.getLexiconProduct().getExceptionCode()!=null&&
         testProductStage.getLexiconProduct().getExceptionCode().isPrimary())));
    }



    private Collection<LexiconProductStageEntity> loadLexiconProductStagesNotInRequest(StageValidationModel model) {
        Map<String,LexiconProductStageEntity> lexiconProductStageMap = new HashMap<String, LexiconProductStageEntity>();
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity lexiconProduct=lexiconProductDao.getByPubkey(productPubkey);
            if(!lexiconProduct.isLogicalDelete()){
                for(LexiconProductStageEntity lexiconProductStage:lexiconProduct.getLexiconProductStages()){
                    if(!lexiconProductStage.isLogicalDelete()){
                       lexiconProductStageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
                    }
                }
                for(ProductStage productStage: model.getProduct().getProductStages()){
                    if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
                        lexiconProductStageMap.remove(productStage.getProductStagePubkey());
                    }
                }
            }
        }
        Collection<LexiconProductStageEntity> lexiconProductStages = lexiconProductStageMap.values();
        return lexiconProductStages;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }
}
