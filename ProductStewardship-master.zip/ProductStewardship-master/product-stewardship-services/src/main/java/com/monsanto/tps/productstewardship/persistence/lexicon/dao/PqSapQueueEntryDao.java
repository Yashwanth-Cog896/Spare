package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;

import java.util.List;

public interface PqSapQueueEntryDao extends GenericDao<PqSapQueueEntryEntity,Long> {

    @DynamicDaoMethod(queryName = "PqSapQueueEntryDao.getPqSapQueueEntryIdsToProcessForGqa",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<Long> getPqSapQueueEntryIdsToProcessForGqa();

    @DynamicDaoMethod(queryName = "PqSapQueueEntryDao.getPqSapQueueEntryIdsToProcessForSap",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<Long> getPqSapQueueEntryIdsToProcessForSap(@DynamicDaoParameter(name="stageCategoryName")String stageCategoryName);

    @DynamicDaoMethod(queryName = "PqSapQueueEntryDao.getPqSapRowCropQueueEntriesToProcessForSap",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<PqSapQueueEntryEntity> getPqSapRowCropQueueEntriesToProcessForSap(@DynamicDaoParameter(name = "stageCategoryName") String stageCategoryName);

    public PqSapQueueEntryEntity retrieveForUpdateAndLock(long id);
}
