package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.productassignments;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ExistingParentProductFlagMatchesRequestRule implements ValidationSimpleRule<Product> {
    private LexiconProductDao lexiconProductDao;

    @Override
    public void validate(Product model, ValidationStatus status) {
        String preCommercialName= model.getPreCommercialName();
         if(StringUtils.isNotBlank(preCommercialName)){
            LexiconProductEntity product = lexiconProductDao.getByPreCommercialName(preCommercialName);
            if((product!=null)&& (product.isLogicalDelete()==model.getParentProduct().booleanValue())){
                status.addCondition(new ValidationResult(ProductEditService.PARENT_PRODUCT_FLAG_DIFFER_CODE, ValidationSeverity.INFO));
            }
         }
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
