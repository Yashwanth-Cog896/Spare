package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.productimage.service.ProductImagesService;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

/**
 * vvkalu - Mar 17, 2010 2:07:51 AM
 */
public class ImageDisplayNameExistsRule implements ValidationSimpleRule<ImageValidationModel> {

   @Override
   public void  validate(ImageValidationModel model, ValidationStatus status) {
      if(model.getLexiconProductPicture() != null) {
         status.addCondition(ProductImagesService.IMAGE_DISPLAY_NAME_EXISTS);
      }
   }
}
