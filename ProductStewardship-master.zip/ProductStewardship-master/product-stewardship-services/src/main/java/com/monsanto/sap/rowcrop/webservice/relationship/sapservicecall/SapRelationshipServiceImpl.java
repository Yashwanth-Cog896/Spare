package com.monsanto.sap.rowcrop.webservice.relationship.sapservicecall;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.util.service.ServiceInvoker;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipInfo;

/**
 * User: pjberry
 * Date: Jul 18, 2007
 * Time: 12:16:14 PM
 */
public class SapRelationshipServiceImpl implements SapRelationshipService {
   private final ServiceInvoker serviceInvoker;

    public SapRelationshipServiceImpl(ServiceInvoker serviceInvoker) {
        this.serviceInvoker = serviceInvoker;
    }

    public SapSyncResponse synSap(SapRelationshipInfo relationshipInfo) throws WrappingException {
      SapRelationshipSyncServiceCall sapCall = new SapRelationshipSyncServiceCall(serviceInvoker);
      return sapCall.call(relationshipInfo);
   }

}

