package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

public class MapCropMirageEntity {
    private Long midasCropId;
    private String midasCropName;
    private String mirageBayerCode;

    public Long getMidasCropId() {
        return midasCropId;
    }

    public void setMidasCropId(Long midasCropId) {
        this.midasCropId = midasCropId;
    }

    public String getMidasCropName() {
        return midasCropName;
    }

    public void setMidasCropName(String midasCropName) {
        this.midasCropName = midasCropName;
    }

    public String getMirageBayerCode() {
        return mirageBayerCode;
    }

    public void setMirageBayerCode(String mirageBayerCode) {
        this.mirageBayerCode = mirageBayerCode;
    }
}
