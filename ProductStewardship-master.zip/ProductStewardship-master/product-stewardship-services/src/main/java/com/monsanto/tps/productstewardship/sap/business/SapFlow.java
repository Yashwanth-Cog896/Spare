package com.monsanto.tps.productstewardship.sap.business;

public interface SapFlow {
     public void flowVegetableChangesToSap();
}
