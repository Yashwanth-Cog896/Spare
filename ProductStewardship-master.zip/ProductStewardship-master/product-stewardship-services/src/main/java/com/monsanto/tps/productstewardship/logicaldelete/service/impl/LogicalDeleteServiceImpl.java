package com.monsanto.tps.productstewardship.logicaldelete.service.impl;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.productstewardship.audit.aspect.AuditComment;
import com.monsanto.tps.productstewardship.audit.aspect.AuditRequestor;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;
import com.monsanto.tps.productstewardship.logicaldelete.business.ProductNameLogicalDelete;
import com.monsanto.tps.productstewardship.logicaldelete.business.ProductStageLogicalDelete;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.logicaldelete.service.LogicalDeleteService;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 14, 2011
 * Time: 10:40:07 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public class LogicalDeleteServiceImpl implements LogicalDeleteService {
    ProductStageLogicalDelete productStageLogicalDelete;
    ProductNameLogicalDelete productNameLogicalDelete;
    
    @Override
    @AuditStage(processName = "LogicalDeleteService.logicalDeleteStageAndName")
    @ProfileLogging
    public void logicalDeleteStageAndName(List<String> pubkeys, String requestor, String auditComment) {
        productStageLogicalDelete.logicallyDeleteProductStages(pubkeys);
        productNameLogicalDelete.logicallyDeleteProductNames(pubkeys);
    }

    public void setProductNameLogicalDelete(ProductNameLogicalDelete productNameLogicalDelete) {
        this.productNameLogicalDelete = productNameLogicalDelete;
    }

    public void setProductStageLogicalDelete(ProductStageLogicalDelete productStageLogicalDelete) {
        this.productStageLogicalDelete = productStageLogicalDelete;
    }
}
