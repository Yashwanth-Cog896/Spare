package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.productassignments;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ExistingLexProdMatchesRequestCropRule implements ValidationSimpleRule<Product> {
    private LexiconProductDao lexiconProductDao;

    @Override
    public void validate(Product model, ValidationStatus status) {
        String precommercialName = model.getPreCommercialName();
        String cropName = model.getLexiconCropName();
        if(StringUtils.isNotBlank(precommercialName)&&(StringUtils.isNotBlank(cropName))){
            LexiconProductEntity product = lexiconProductDao.getByPreCommercialName(precommercialName);
            if((product!=null)&& !productIsDeleted(product) &&(!product.getLexiconCrop().getName().equals(cropName))){
                status.addCondition(new ValidationResult(ProductEditService.EXIST_LEX_CROP_DIFFER_CODE, ValidationSeverity.ERROR)); 
            }

        }
    }

    private boolean productIsDeleted(LexiconProductEntity product) {
        boolean isDeleted =  product.isLogicalDelete();
        if(!isDeleted){
            isDeleted=true;
            for(LexiconProductStageEntity productStage: product.getLexiconProductStages()){
                if(!productStage.isLogicalDelete()){
                    isDeleted=false;
                    break;
                }
            }
        }
        return isDeleted;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
