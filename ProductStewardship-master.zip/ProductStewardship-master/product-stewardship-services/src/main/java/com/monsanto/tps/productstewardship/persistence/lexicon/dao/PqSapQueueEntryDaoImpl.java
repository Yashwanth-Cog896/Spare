package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import org.hibernate.LockMode;
import org.hibernate.LockOptions;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 19, 2011
 * Time: 9:39:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class PqSapQueueEntryDaoImpl extends GenericDaoImpl<PqSapQueueEntryEntity,Long> implements  PqSapQueueEntryDao {
    public PqSapQueueEntryDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<Long> getPqSapQueueEntryIdsToProcessForGqa() {
        return null;
    }

    @Override
    public List<Long> getPqSapQueueEntryIdsToProcessForSap(@DynamicDaoParameter(name = "stageCategoryName") String stageCategoryName) {
        return null;
    }

    @Override
    public PqSapQueueEntryEntity retrieveForUpdateAndLock(long id) {
        return (PqSapQueueEntryEntity)this.getSession().get(PqSapQueueEntryEntity.class,id,new LockOptions(LockMode.UPGRADE_NOWAIT));
    }

  @Override
  public List<PqSapQueueEntryEntity> getPqSapRowCropQueueEntriesToProcessForSap(@DynamicDaoParameter(name = "stageCategoryName") String stageCategoryName) {
    return null;
  }
}
