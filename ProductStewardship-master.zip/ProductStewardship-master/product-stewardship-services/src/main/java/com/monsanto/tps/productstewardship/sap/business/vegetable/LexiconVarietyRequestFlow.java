package com.monsanto.tps.productstewardship.sap.business.vegetable;


import com.monsanto.sap.vegetable.webservice.variety.DTLexiconVarietyReq;
import com.monsanto.sap.vegetable.webservice.variety.DTLexiconVarietyRsp;
import com.monsanto.sap.vegetable.webservice.variety.MILexiconVarietyOSBSReq;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import org.apache.log4j.Logger;

import java.util.HashSet;
import java.util.Set;

public class LexiconVarietyRequestFlow
{
    private static final org.apache.log4j.Logger log = Logger.getLogger(LexiconVarietyRequestFlow.class);
    private MILexiconVarietyOSBSReq miLexiconVarietyOSBSReq;
    private DTLexiconHeaderBuilder dtLexiconHeaderBuilder;
    private ProductStageVarietyBuilder productStageVarietyBuilder;

    public DTLexiconVarietyRsp flowToSap(Set<LexiconProductEntity> lexiconProducts){
        Set< DTLexiconVarietyReq.VarietyRequest.Variety> varieties = new HashSet<DTLexiconVarietyReq.VarietyRequest.Variety>();
        for(LexiconProductEntity lexiconProduct: lexiconProducts){
           varieties.addAll(buildVarietiesRequest(lexiconProduct));
        }
        if(!varieties.isEmpty()){
        DTLexiconVarietyReq dtLexiconVarietyReq = build(varieties);
            return miLexiconVarietyOSBSReq.miLexiconVarietyOSBSReq(dtLexiconVarietyReq);
    }
        else {
            return null;
        }

    }
    private  DTLexiconVarietyReq build(Set<DTLexiconVarietyReq.VarietyRequest.Variety> varieties) {
      DTLexiconVarietyReq request = new DTLexiconVarietyReq();
      request.setHeader(dtLexiconHeaderBuilder.buildHeader());
      request.setVarietyRequest(varietyRequest(varieties));
      return request;
   }

   private DTLexiconVarietyReq.VarietyRequest varietyRequest(Set<DTLexiconVarietyReq.VarietyRequest.Variety> varieties) {
      DTLexiconVarietyReq.VarietyRequest varietyRequest = new DTLexiconVarietyReq.VarietyRequest();
      for (DTLexiconVarietyReq.VarietyRequest.Variety variety : varieties) {
         varietyRequest.getVariety().add(variety);
      }
      return varietyRequest;
   }

    private  Set< DTLexiconVarietyReq.VarietyRequest.Variety>   buildVarietiesRequest(LexiconProductEntity lexiconProduct) {
        Set< DTLexiconVarietyReq.VarietyRequest.Variety> varieties = new HashSet<DTLexiconVarietyReq.VarietyRequest.Variety>();
        if(lexiconProduct!=null){
            for(LexiconProductStageEntity lexiconProductStage: lexiconProduct.getLexiconProductStages()){
               if(!lexiconProductStage.isLogicalDelete()){
                DTLexiconVarietyReq.VarietyRequest.Variety variety = productStageVarietyBuilder.build(lexiconProductStage);
                if(variety!=null){
                    varieties.add(variety);
                }
            }
        }
        }
        return varieties;
    }

    public void setMiLexiconVarietyOSBSReq(MILexiconVarietyOSBSReq miLexiconVarietyOSBSReq) {
        this.miLexiconVarietyOSBSReq = miLexiconVarietyOSBSReq;
    }

    public void setProductStageVarietyBuilder(ProductStageVarietyBuilder productStageVarietyBuilder) {
        this.productStageVarietyBuilder = productStageVarietyBuilder;
    }

    public void setDtLexiconHeaderBuilder(DTLexiconHeaderBuilder dtLexiconHeaderBuilder) {
        this.dtLexiconHeaderBuilder = dtLexiconHeaderBuilder;
    }
}
