package com.monsanto.tps.productstewardship.persistence.lexicon.transform;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductionStatusEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;
import com.monsanto.tps.productstewardship.transfer.ProductRelationship;
import com.monsanto.tps.productstewardship.transfer.ProductRelationshipXref;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 8/11/11
 * Time: 1:43 PM
 */
public class BaseProductTransformer {

    private BaseProductDao baseProductDao;
    private LexiconCropDao lexiconCropDao;
    private ProductRelationshipDao productRelationshipDao;
    private ProductRelationshipXRefDao productRelationshipXRefDao;
    private LexiconProductionStatusDao lexiconProductionStatusDao;

    public BaseProductEntity transformBaseProduct(BaseProduct baseProduct) {
        BaseProductEntity baseProductEntity = null;
        if (baseProduct != null) {
            if (baseProduct.getBaseProductId() != null) {
                baseProductEntity = baseProductDao.get(baseProduct.getBaseProductId());
            } else {
                baseProductEntity = new BaseProductEntity();
            }
            baseProductEntity.setBaseManufacturingName(baseProduct.getBaseManufacturingName());
            baseProductEntity.setLexiconCrop(lexiconCropDao.get(baseProduct.getCropId()));
            //TODO: Why is this not there? baseProductEntity.setLogicalDelete();
            //TODO: Why is this not there? baseProductEntity.setParentProduct();
            baseProductEntity.setProductRelationships(convertProductRelationships(baseProduct.getProductRelationships()));
        }
        return baseProductEntity;
    }

    private List<ProductRelationshipEntity> convertProductRelationships(List<ProductRelationship> productRelationships) {
        List<ProductRelationshipEntity> productRelationshipEntities = null;
        if (productRelationships != null) {
            productRelationshipEntities = new ArrayList<ProductRelationshipEntity>();
            for (ProductRelationship productRelationship : productRelationships) {
                ProductRelationshipEntity productRelationshipEntity = convertProductRelationship(productRelationship);
                productRelationshipEntities.add(productRelationshipEntity);
            }
        }
        return productRelationshipEntities;
    }

    private ProductRelationshipEntity convertProductRelationship(ProductRelationship productRelationship) {
        ProductRelationshipEntity productRelationshipEntity = null;
        if (productRelationship != null) {
            if (productRelationship.getProductRelationshipId() != 0) {
                productRelationshipEntity = productRelationshipDao.get(productRelationship.getProductRelationshipId());
            } else {
                productRelationshipEntity = new ProductRelationshipEntity();
            }
            productRelationshipEntity.setManufacturingName(productRelationship.getManufacturingName());
            productRelationshipEntity.setVarietyName(productRelationship.getVarietyName());
            productRelationshipEntity.setProductRelationshipXRefs(convertProductRelationshipXRefs(productRelationship.getProductRelationshipXrefs()));
        }
        return productRelationshipEntity;
    }

    private List<ProductRelationshipXrefEntity> convertProductRelationshipXRefs(List<ProductRelationshipXref> productRelationshipXRefs) {
        List<ProductRelationshipXrefEntity> productRelationshipXRefEntities = new ArrayList<ProductRelationshipXrefEntity>();
        for (ProductRelationshipXref productRelationshipXref : productRelationshipXRefs) {
            ProductRelationshipXrefEntity productRelationshipXrefEntity = convertProductRelationshipXRef(productRelationshipXref);
            productRelationshipXRefEntities.add(productRelationshipXrefEntity);
        }
        return productRelationshipXRefEntities;
    }

    private ProductRelationshipXrefEntity convertProductRelationshipXRef(ProductRelationshipXref productRelationshipXref) {
        ProductRelationshipXrefEntity productRelationshipXrefEntity = null;
        if (productRelationshipXref != null) {
            if (productRelationshipXref.getProductRelationshipXrefId() != 0) {
                productRelationshipXrefEntity = productRelationshipXRefDao.get(productRelationshipXref.getProductRelationshipXrefId());
            } else {
                productRelationshipXrefEntity = new ProductRelationshipXrefEntity();
            }
            productRelationshipXrefEntity.setTraitVersion(productRelationshipXref.getTraitVersion());
            if (productRelationshipXref.getProductionStatusId() != 0) {
                LexiconProductionStatusEntity lexiconProductionStatusEntity = lexiconProductionStatusDao.get(productRelationshipXref.getProductionStatusId());
                productRelationshipXrefEntity.setProductionStatus(lexiconProductionStatusEntity);
            }
        }
        return productRelationshipXrefEntity;
    }

    public void setLexiconProductionStatusDao(LexiconProductionStatusDao lexiconProductionStatusDao) {
        this.lexiconProductionStatusDao = lexiconProductionStatusDao;
    }

    public void setProductRelationshipXRefDao(ProductRelationshipXRefDao productRelationshipXRefDao) {
        this.productRelationshipXRefDao = productRelationshipXRefDao;
    }

    public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
        this.productRelationshipDao = productRelationshipDao;
    }

    public void setBaseProductDao(BaseProductDao baseProductDao) {
        this.baseProductDao = baseProductDao;
    }

    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }
}
