package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.*;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 12, 2011
 * Time: 8:37:23 AM
 * To change this template use File | Settings | File Templates.
 */
public  class ProductRelationshipXRefDaoImpl  extends GenericDaoImpl<ProductRelationshipXrefEntity, Long> implements ProductRelationshipXRefDao {
    public ProductRelationshipXRefDaoImpl(Class entityClass) {
        super(entityClass);
    }
/* I know comments are bad. But I had to note that the filter uses AOP.  SO the following code actually works */
    @Override
    public List<ProductRelationshipXrefEntity> findProductRelationshipXrefByFilter(Filter[] filters) {
        return null;
    }

    @Override
    public List<ProductRelationshipXrefEntity> findProductRelationshipsByBaseManufacturingName(List<String> names, boolean hybridOnly, List<String> cropPubkeys) {
        Session session = getSessionFactory().getCurrentSession();
        Criteria xrefCriteria = session.createCriteria(ProductRelationshipXrefEntity.class);
        Criteria baseProductCriteria = xrefCriteria.createCriteria("productRelationship").createCriteria("baseProduct");
        baseProductCriteria.createCriteria("lexiconCrop").add(Restrictions.in("pubkey",cropPubkeys));
        for(String name: names){
           baseProductCriteria.add(Restrictions.eq("baseManufacturingName",name).ignoreCase());
        }
        if(hybridOnly){
            Criteria productCriteria = xrefCriteria.createCriteria("lexiconProduct");
            DetachedCriteria productStageCriteria = DetachedCriteria.forClass(LexiconProductStageEntity.class,"productStage");
            productStageCriteria.createCriteria("lexiconStage").add(Restrictions.eq("abbreviation","INBR"));
            productStageCriteria.add(Property.forName("productStage.lexiconProduct.id").eqProperty("lexiconProduct.id"));
            productCriteria.add(Subqueries.notExists(productStageCriteria.setProjection(Projections.property("productStage.id"))));
        }
        return xrefCriteria.list();  
    }
}
