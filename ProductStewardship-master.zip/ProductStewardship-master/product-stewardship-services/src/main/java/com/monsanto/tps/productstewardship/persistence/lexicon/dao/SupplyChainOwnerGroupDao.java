package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductClassificationEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.SupplyChainOwnerGroupEntity;

public interface SupplyChainOwnerGroupDao extends GenericDao<SupplyChainOwnerGroupEntity,Long> {
    @DynamicDaoMethod(queryName = "SupplyChainOwnerGroupDao.getBySupplyChainOwnerGroupCode",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    SupplyChainOwnerGroupEntity getByCode(@DynamicDaoParameter(name="supplyChainOwnerGroupCode") String supplyChainOwnerGroupCode);

}
