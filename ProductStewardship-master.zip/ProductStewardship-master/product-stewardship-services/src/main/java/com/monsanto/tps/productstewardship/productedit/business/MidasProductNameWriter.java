package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCountryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasProductNameDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MidasProductNameWriter {
    public static final String MONSANTO = "MONSANTO";
    private MidasProductNameDao midasProductNameDao;
    private LexiconBrandDao lexiconBrandDao;
    private LexiconCountryDao lexiconCountryDao;
    public MidasProductNameEntity writeMidasProductName(LexiconProductEntity lexiconProduct, ProductStage productStage, LexiconProductStageEntity lexiconProductStage) {
        MidasBrandEntity midasBrand = fetchMidasBrand(lexiconProductStage);
        MidasCountryEntity midasCountry = fetchMidasCountry(lexiconProductStage);
        MidasProductNameEntity midasProductName = lexiconProductStage.getFbsCommonProductNameXref()==null? null: lexiconProductStage.getFbsCommonProductNameXref().getMidasProductName();
        if(midasProductName!=null){
              midasProductName.setRefActive(false);
        }
          MidasProductNameEntity matchingMidasProductName = null;
        if (lexiconProductStage.getLexiconStage().isCommercial()){
            boolean existing = true;

            matchingMidasProductName  = midasProductNameDao.getByProductBrandCountry(lexiconProduct.getFbsCommonProductXref().getMidasProduct().getId(),
                                                                            midasBrand.getId(),
                                                                            midasCountry.getId());
            if(matchingMidasProductName==null){
                existing=false;
                MidasProductEntity midasProduct = lexiconProduct.getFbsCommonProductXref().getMidasProduct();
                matchingMidasProductName = new MidasProductNameEntity();
                matchingMidasProductName.setMidasProduct(midasProduct);
                matchingMidasProductName.setMidasBrand(midasBrand);
                matchingMidasProductName.setMidasCountry(midasCountry);
                midasProduct.getMidasProductNames().add(matchingMidasProductName);
            }
            matchingMidasProductName.setRefActive(true);
            lexiconProductStage.getFbsCommonProductNameXref().setMidasProductName(matchingMidasProductName);
            matchingMidasProductName.setPreferredName(productStage.isPreferredName());
            matchingMidasProductName.setName(productStage.getCommercialName());

            if(!existing){
               midasProductNameDao.saveOrUpdate(matchingMidasProductName);
            }
        }

        return matchingMidasProductName;
    }
    public void writeMidasGlobalPCName(LexiconProductEntity lexiconProduct, ProductStage productStage) {
        if(!lexiconProduct.getPreCommercialName().startsWith("UNKNOWN")){
            List<MidasProductNameEntity> pcNames = new ArrayList<MidasProductNameEntity>();
            boolean hasActiveRecords = false;
            for(MidasProductNameEntity midasProductName :lexiconProduct.getFbsCommonProductXref().getMidasProduct().getMidasProductNames()){
                if(MONSANTO.equals(midasProductName.getMidasBrand().getName())){
                    if(midasProductName.isRefActive()){
                        hasActiveRecords=true;
                    }
                    else {
                       pcNames.add(midasProductName);
                    }
                }
            }
            if(!hasActiveRecords){
                MidasProductNameEntity globalPcName = null;
                if(pcNames.isEmpty()){
                    globalPcName = new MidasProductNameEntity();
                    globalPcName.setName(lexiconProduct.getPreCommercialName());
                    globalPcName.setMidasBrand(lexiconBrandDao.getByName(MONSANTO).getFbsCommonBrandXrefs().iterator().next().getMidasBrand());
                    globalPcName.setMidasCountry(lexiconCountryDao.findByAbbreviation(productStage.getCountryAbbreviation()).getFbsCommonCountryXrefs().iterator().next().getMidasCountry());
                    globalPcName.setMidasProduct(lexiconProduct.getFbsCommonProductXref().getMidasProduct());
                    globalPcName.setRefActive(true);
                    globalPcName.setStageActive(true);
                    
                    lexiconProduct.getFbsCommonProductXref().getMidasProduct().getMidasProductNames().add(globalPcName);
                    midasProductNameDao.saveOrUpdate(globalPcName);
                }
                else {
                    globalPcName =   pcNames.get(0);
                    globalPcName.setName(lexiconProduct.getPreCommercialName());
                    globalPcName.setRefActive(true);
                }
            }

        }
    }
    private MidasCountryEntity fetchMidasCountry(LexiconProductStageEntity lexiconProductStage) {
        MidasCountryEntity midasCountry = null;
        Set<FbsCommonCountryXrefEntity> countryXrefs = lexiconProductStage.getLexiconCountry().getFbsCommonCountryXrefs();
        for(FbsCommonCountryXrefEntity countryXref: countryXrefs){
            midasCountry = countryXref.getMidasCountry();
        }
        return midasCountry;
    }

    private MidasBrandEntity fetchMidasBrand(LexiconProductStageEntity lexiconProductStage) {
        MidasBrandEntity midasBrand = null;
        Set<FbsCommonBrandXrefEntity> brandXrefs = lexiconProductStage.getLexiconBrand().getFbsCommonBrandXrefs();
        for(FbsCommonBrandXrefEntity brandXref: brandXrefs){
            midasBrand=brandXref.getMidasBrand();
        }
        return midasBrand;
    }

    public void setMidasProductNameDao(MidasProductNameDao midasProductNameDao) {
        this.midasProductNameDao = midasProductNameDao;
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }

    public void setLexiconCountryDao(LexiconCountryDao lexiconCountryDao) {
        this.lexiconCountryDao = lexiconCountryDao;
    }
}
