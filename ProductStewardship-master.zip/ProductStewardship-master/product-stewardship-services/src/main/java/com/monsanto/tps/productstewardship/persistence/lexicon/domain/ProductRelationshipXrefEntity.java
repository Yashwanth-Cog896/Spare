package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableAlias;
import com.monsanto.tps.filter.annotation.FilterableProperty;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:06:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCT_RELATIONSHIP_XREF", schema = "Lexicon")
@Filterable
public class ProductRelationshipXrefEntity implements Serializable {
    @Id
    @Column(name="PRODUCT_RELATIONSHIP_XREF_ID")
    private long id;

    @FilterableAlias(alias = "lexiconProduct")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_ID",nullable = false)
    private LexiconProductEntity lexiconProduct;
    @FilterableAlias(alias = "productRelationship")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_RELATIONSHIP_ID",nullable = false)
    private ProductRelationshipEntity productRelationship;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCTION_STATUS_ID",nullable = false)
    private LexiconProductionStatusEntity productionStatus;
    @FilterableProperty(filterKey = "traitVersion")
    @Column(name="TRAIT_VERSION",nullable = true, length = 10)
    private String traitVersion;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconProductEntity getLexiconProduct() {
        return lexiconProduct;
    }

    public void setLexiconProduct(LexiconProductEntity lexiconProduct) {
        this.lexiconProduct = lexiconProduct;
    }

    public ProductRelationshipEntity getProductRelationship() {
        return productRelationship;
    }

    public void setProductRelationship(ProductRelationshipEntity productRelationship) {
        this.productRelationship = productRelationship;
    }

    public LexiconProductionStatusEntity getProductionStatus() {
        return productionStatus;
    }

    public void setProductionStatus(LexiconProductionStatusEntity productionStatus) {
        this.productionStatus = productionStatus;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProductRelationshipXrefEntity that = (ProductRelationshipXrefEntity) o;

        if (lexiconProduct != null ? lexiconProduct.getId()!=that.lexiconProduct.getId() : that.lexiconProduct != null)
            return false;
        if (productRelationship != null ? productRelationship.getId() != that.productRelationship.getId() : that.productRelationship != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = lexiconProduct != null ? ((Long)lexiconProduct.getId()).hashCode() : 0;
        result = 31 * result + (productRelationship != null ? ((Long)productRelationship.getId()).hashCode() : 0);
        return result;
    }
}
