package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialname;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ComlNameRequiredForComlStageRule implements ValidationSimpleRule<StageValidationModel> {
    LexiconStageDao lexiconStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {

        if(StringUtils.isNotBlank(model.getProductStage().getStageAbbreviation())){
            LexiconStageEntity stage = lexiconStageDao.findStageByAbbreviation(model.getProductStage().getStageAbbreviation());
            if(stage!=null&&stage.isCommercial()&&(StringUtils.isBlank(model.getProductStage().getCommercialName()))){
                  status.addCondition(new ValidationResult(ProductEditService.COML_NAME_REQ_COML_STAGE_CODE, ValidationSeverity.ERROR));
            }
        }

    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
