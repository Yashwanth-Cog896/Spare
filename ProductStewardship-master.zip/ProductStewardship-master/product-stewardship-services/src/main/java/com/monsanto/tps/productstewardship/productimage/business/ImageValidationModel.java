package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ConfigurationPictureEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;
import com.monsanto.tps.productstewardship.productimage.service.ImageDimensions;


/**
 * VVKALU - Mar 15, 2010 1:22:15 AM
 */
public class ImageValidationModel {

   private LexiconProductEntity lexiconProduct;
   private ImageDimensions imageDimensions;
   private String formatName;
   private LexiconProductPictureEntity lexiconProductPicture;
   private ConfigurationPictureEntity configurationPicture;
   private boolean preConditionMet;
   private String displayName;

   public void setLexiconProduct(LexiconProductEntity lexiconProduct) {
      this.lexiconProduct = lexiconProduct;
   }

   public LexiconProductEntity getLexiconProduct() {
      return lexiconProduct;
   }

   public ImageDimensions getImageDimensions() {
      return imageDimensions;
   }

   public void setImageDimensions(ImageDimensions imageDimensions) {
      this.imageDimensions = imageDimensions;
   }

   public void setFormatName(String formatName) {
      this.formatName = formatName;
   }

   public String getFormatName() {
      return formatName;
   }

   public LexiconProductPictureEntity getLexiconProductPicture() {
      return lexiconProductPicture;
   }

   public void setLexiconProductPicture(LexiconProductPictureEntity lexiconProductPicture) {
      this.lexiconProductPicture = lexiconProductPicture;
   }

   public ConfigurationPictureEntity getConfigurationPicture() {
      return configurationPicture;
   }

   public void setConfigurationPicture(ConfigurationPictureEntity configurationPicture) {
      this.configurationPicture = configurationPicture;
   }

   public boolean isPreConditionMet() {
      return preConditionMet;
   }

   public void setPreConditionMet(boolean preConditionMet) {
      this.preConditionMet = preConditionMet;
   }

   public String getDisplayName() {
      return displayName;
   }

   public void setDisplayName(String displayName) {
      this.displayName = displayName;
   }
}
