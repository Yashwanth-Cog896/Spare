package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:44:54 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCT_NAME", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasProductNameEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "PRODUCT_NAME_ID", precision = 0, length = 22)
    private long id;
    @Column(name="NAME",length = 50,nullable=false)
    private String name;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BRAND_ID",nullable = false)    
    private MidasBrandEntity midasBrand;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COUNTRY_ID",nullable = false)
    private MidasCountryEntity midasCountry;
    @Type(type="true_false")
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean refActive;
    @Type(type="true_false")
    @Column(name="IS_STAGE_ACTIVE",nullable = false)
    private boolean stageActive;
    @Type(type="true_false")
    @Column(name="PREFERRED_NAME",nullable = false)
    private boolean preferredName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRODUCT_ID",nullable = false)
    private MidasProductEntity midasProduct;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasBrandEntity getMidasBrand() {
        return midasBrand;
    }

    public void setMidasBrand(MidasBrandEntity midasBrand) {
        this.midasBrand = midasBrand;
    }

    public MidasCountryEntity getMidasCountry() {
        return midasCountry;
    }

    public void setMidasCountry(MidasCountryEntity midasCountry) {
        this.midasCountry = midasCountry;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isPreferredName() {
        return preferredName;
    }

    public void setPreferredName(boolean preferredName) {
        this.preferredName = preferredName;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public boolean isStageActive() {
        return stageActive;
    }

    public void setStageActive(boolean stageActive) {
        this.stageActive = stageActive;
    }

    public MidasProductEntity getMidasProduct() {
        return midasProduct;
    }

    public void setMidasProduct(MidasProductEntity midasProduct) {
        this.midasProduct = midasProduct;
    }
}
