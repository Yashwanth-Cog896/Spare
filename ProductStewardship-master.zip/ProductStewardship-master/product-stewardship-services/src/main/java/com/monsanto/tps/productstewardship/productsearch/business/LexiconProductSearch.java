package com.monsanto.tps.productstewardship.productsearch.business;

import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import com.monsanto.tps.productstewardship.productsearch.service.ProductSearchResults;
import com.monsanto.tps.productstewardship.productsearch.service.ProductStageSearchResults;
import com.monsanto.tps.productstewardship.productsearch.service.TooManyResultsException;
import com.monsanto.tps.productstewardship.transfer.Product;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 5:24:45 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductSearch {
     public ProductSearchResults productSearch(LexiconProductSearchCriteria productSearchCriteria,int pageSize,int pageNumber);
     public List<Product> productSearch(LexiconProductSearchCriteria productSearchCriteria)  throws TooManyResultsException;
     public ProductStageSearchResults productStageSearch(LexiconProductSearchCriteria productSearchCriteria,int pageSize,int pageNumber);
}
