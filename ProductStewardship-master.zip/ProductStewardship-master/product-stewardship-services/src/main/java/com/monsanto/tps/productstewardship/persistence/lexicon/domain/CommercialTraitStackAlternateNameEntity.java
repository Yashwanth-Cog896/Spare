package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 22, 2011
 * Time: 9:07:43 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "commercialTraitStackAltNameIdGenerator",allocationSize = 1,sequenceName = "Lexicon.CML_TT_STCK_ALT_NM_ID_SEQ")
@Table(name = "COML_TRAIT_STACK_ALT_NAME", schema = "Lexicon")
public class CommercialTraitStackAlternateNameEntity {
    @Id
    @GeneratedValue(generator = "commercialTraitStackAltNameIdGenerator")
    @Column(name="COML_TRAIT_STACK_ALT_NAME_ID")
    private long id;
    @ManyToOne(optional = false)
    @JoinColumn(name="COML_TRAIT_STACK_ID",nullable = false)
    private CommercialTraitStackEntity  commercialTraitStack;
    @Column(name="COML_TRAIT_STCK_ALT_NM_PUBKEY",nullable = false, length = 20)
    private String pubkey;
    @Column(name="REPORTING_NAME",nullable = false,length = 50)
    private String reportingName;
    @Column(name="STACK_DESC",nullable = false,length = 100)
    private String description;

    public CommercialTraitStackEntity getCommercialTraitStack() {
        return commercialTraitStack;
    }

    public void setCommercialTraitStack(CommercialTraitStackEntity commercialTraitStack) {
        this.commercialTraitStack = commercialTraitStack;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public String getReportingName() {
        return reportingName;
    }

    public void setReportingName(String reportingName) {
        this.reportingName = reportingName;
    }
}
