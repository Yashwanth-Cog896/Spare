package com.monsanto.tps.productstewardship.blend.business;

import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 6, 2011
 * Time: 4:49:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlendBuilderFactory {

    private BlendedProductsStrategy blendedProductsStrategy;

    private BlendedComponentsStrategy blendedComponentsStrategy;

    private BlendProductDetailsStrategy blendProductDetailsStrategy;

    public BlendBuilderFactory() {
    }

    public BlendedSearchStrategy getStrategy(BlendedProductDetails details) {
        BlendedSearchStrategy strategy = null;
        if (checkForProductDetails(details)) {
            strategy = blendProductDetailsStrategy;
        } else if (checkForBlendedProducts(details)) {
            strategy = blendedProductsStrategy;
        } else if (checkForComponents(details)) {
            strategy = blendedComponentsStrategy;
        }
        return strategy;
    }

    private boolean checkForComponents(BlendedProductDetails details) {
        return details.getComponentProductGermplasms() != null && !details.getComponentProductGermplasms().isEmpty();
    }

    private boolean checkForBlendedProducts(BlendedProductDetails details) {
        return details.getBlendedProductGermplasms() != null && !details.getBlendedProductGermplasms().isEmpty();
    }

    private boolean checkForProductDetails(BlendedProductDetails details) {
        return checkForBlendedProducts(details) && checkForComponents(details);
    }

    public void setBlendedProductsStrategy(BlendedProductsStrategy blendedProductsStrategy) {
        this.blendedProductsStrategy = blendedProductsStrategy;
    }

    public void setBlendedComponentsStrategy(BlendedComponentsStrategy blendedComponentsStrategy) {
        this.blendedComponentsStrategy = blendedComponentsStrategy;
    }

    public void setBlendProductDetailsStrategy(BlendProductDetailsStrategy blendProductDetailsStrategy) {
        this.blendProductDetailsStrategy = blendProductDetailsStrategy;
    }

}
