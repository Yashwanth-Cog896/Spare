package com.monsanto.sap.rowcrop.webservice.relationship;

public interface SapRelationshipSchemaConstants
{
   String NAMESPACE = "http://www.monsanto.com/lexicon/SapRelationship";
   String SCHEMA_LOC = "xsd/lexicon/xstream/SapRelationship.xsd";
}
