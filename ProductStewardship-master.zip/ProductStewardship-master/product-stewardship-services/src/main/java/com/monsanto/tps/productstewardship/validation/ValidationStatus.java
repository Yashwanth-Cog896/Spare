package com.monsanto.tps.productstewardship.validation;

import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 15, 2006
 * Time: 12:45:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationStatus {

   private final HashMap<ValidationSeverity,List<ValidationResult>> resultsMap = new HashMap();

   public boolean hasSeverity(ValidationSeverity severity) {
      return (resultsMap.get(severity) != null);
   }

   public void addCondition(ValidationResult validationResult) {
       ValidationSeverity severity = validationResult.getSeverity();
       List validationResults = (List) resultsMap.get(severity);
      if (validationResults == null) {
         validationResults = new ArrayList();
         resultsMap.put(severity, validationResults);
      }
      validationResults.add(validationResult);
   }

   public List<ValidationResult> getResults(ValidationSeverity severity) {
      List results = (List) resultsMap.get(severity);
      return (results == null) ? new ArrayList<ValidationResult>() : results;
   }

}
