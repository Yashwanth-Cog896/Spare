package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductGermplasmEntity;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 5, 2011
 * Time: 9:07:36 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductGermplasmDao extends GenericDao<ProductGermplasmEntity,Long>{
    @DynamicDaoMethod(queryName = "ProductGermplasmDao.getByMidasProductIdFetchParentage",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductPictureEntity> getByMidasProductIdFetchParentage(@DynamicDaoParameter(name="requestId") Long requestId);
 
}
