package com.monsanto.tps.productstewardship.productassociation.dao;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 12, 2011
 * Time: 10:47:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductAssociationDaoImpl implements ProductAssociationDao {

    private SessionFactory sessionFactory;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }


    @Override
    public List<ProductAssociation> findByBaseManufacturingName(List<String> names, boolean hybridOnly, List<String> cropPubkeys) {

        Session session = getSessionFactory().getCurrentSession();
        Criteria baseProductCriteria = session.createCriteria(BaseProductEntity.class,"baseProduct");
        buildNameCriteria(names, baseProductCriteria, "baseManufacturingName");
        baseProductCriteria.add(getLogicicalDeleteExpression("logicalDelete"));
        Criteria productRelationshipCriteria = baseProductCriteria.createCriteria("productRelationships","productRelationships" ,Criteria.LEFT_JOIN);
        productRelationshipCriteria.add(getLogicicalDeleteExpression("logicalDelete"));
        Criteria productRelationshipXRefCriteria = productRelationshipCriteria.createCriteria("productRelationshipXRefs","productRelationshipXRefs",Criteria.LEFT_JOIN);
        Criteria productCriteria = productRelationshipXRefCriteria.createCriteria("lexiconProduct","theLexiconProduct",Criteria.LEFT_JOIN,Restrictions.eq("logicalDelete",Boolean.FALSE));
        baseProductCriteria.createCriteria("lexiconCrop","theLexiconCrop",Criteria.LEFT_JOIN).add(Restrictions.in("pubkey",cropPubkeys));
        addHybridCriteria(hybridOnly, productCriteria);
        return buildProductAssociationsFromCriteria(baseProductCriteria);
    }

        private Disjunction getLogicicalDeleteExpression(String alias){
        Disjunction or = Restrictions.disjunction();
        or.add(Restrictions.eq(alias,false)) ;
        or.add(Restrictions.isNull(alias));
        return or;

    }
    @Override
    public List<ProductAssociation> findByManufacturingName(List<String> names, boolean hybridOnly, List<String> cropPubkeys) {
        Criteria productRelationshipCriteria = buildProductRelationshipCriteria(hybridOnly, cropPubkeys);
        buildNameCriteria(names, productRelationshipCriteria, "manufacturingName");
        return buildProductAssociationsFromCriteria(productRelationshipCriteria);
    }
    @Override
    public List<ProductAssociation> findByVarietyName(List<String> names, boolean hybridOnly, List<String> cropPubkeys) {
        Criteria productRelationshipCriteria = buildProductRelationshipCriteria(hybridOnly, cropPubkeys);
        buildNameCriteria(names, productRelationshipCriteria, "varietyName");
        return buildProductAssociationsFromCriteria(productRelationshipCriteria);
    }

    private Criteria buildProductRelationshipCriteria(boolean hybridOnly, List<String> cropPubkeys) {
        Session session = getSessionFactory().getCurrentSession();
        Criteria productRelationshipCriteria = session.createCriteria(ProductRelationshipEntity.class,"productRelationships");
        productRelationshipCriteria.add(getLogicicalDeleteExpression("logicalDelete"));
        Criteria baseProductCriteria = productRelationshipCriteria.createCriteria("baseProduct","baseProduct",Criteria.INNER_JOIN);
        baseProductCriteria.add(getLogicicalDeleteExpression("logicalDelete"));
        Criteria productRelationshipXRefCriteria = productRelationshipCriteria.createCriteria("productRelationshipXRefs","productRelationshipXRefs",Criteria.LEFT_JOIN);
        Criteria productCriteria = productRelationshipXRefCriteria.createCriteria("lexiconProduct","theLexiconProduct",Criteria.LEFT_JOIN,Restrictions.eq("logicalDelete",Boolean.FALSE));
        baseProductCriteria.createCriteria("lexiconCrop","theLexiconCrop",Criteria.INNER_JOIN).add(Restrictions.in("pubkey",cropPubkeys));
        addHybridCriteria(hybridOnly, productCriteria);
        return productRelationshipCriteria;
    }
    @Override
    public List<ProductAssociation> findByPreCommercialName(List<String> names, boolean hybridOnly, List<String> cropPubkeys) {
        Criteria productCriteria = buildProductCriteria(hybridOnly, cropPubkeys);
        buildNameCriteria(names, productCriteria, "preCommercialName");
        return buildProductAssociationsFromCriteria(productCriteria);
    }

    @Override
    public List<ProductAssociation> findByTagVarietyName(List<String> names, boolean hybridOnly, List<String> cropPubkeys) {
        Criteria productCriteria = buildProductCriteria(hybridOnly, cropPubkeys);
        String nameAlias = "tagVarietyName";
        buildNameCriteria(names, productCriteria, nameAlias);
        return buildProductAssociationsFromCriteria(productCriteria);

    }

    private void buildNameCriteria(List<String> names, Criteria criteria, String nameAlias) {
        Disjunction or = Restrictions.disjunction();
        for(String name: names){
            or.add(Restrictions.ilike(nameAlias,name.replace("*","%"), MatchMode.EXACT));
        }
        criteria.add(or);
    }

    private Criteria buildProductCriteria(boolean hybridOnly, List<String> cropPubkeys) {
        Session session = getSessionFactory().getCurrentSession();
        Criteria productCriteria = session.createCriteria(LexiconProductEntity.class,"theLexiconProduct");
        productCriteria.add(Restrictions.eq("logicalDelete",Boolean.FALSE));
        Criteria productRelationshipXRefCriteria = productCriteria.createCriteria("lexiconProductRelationshipXrefs","productRelationshipXrefs",Criteria.LEFT_JOIN);
        Criteria productRelationshipCriteria = productRelationshipXRefCriteria.createCriteria("productRelationship","productRelationships" ,Criteria.LEFT_JOIN);
        productRelationshipCriteria.add(getLogicicalDeleteExpression("logicalDelete"));

        Criteria baseProductCriteria = productRelationshipCriteria.createCriteria("baseProduct","baseProduct",Criteria.LEFT_JOIN);
        baseProductCriteria.add(getLogicicalDeleteExpression("logicalDelete"));
        productCriteria.createCriteria("lexiconCrop","theLexiconCrop",Criteria.INNER_JOIN).add(Restrictions.in("pubkey",cropPubkeys));
        addHybridCriteria(hybridOnly, productCriteria);
        return productCriteria;
    }

    private void addHybridCriteria(boolean hybridOnly, Criteria productCriteria) {
        if(hybridOnly){
            DetachedCriteria productStageCriteria = DetachedCriteria.forClass(LexiconProductStageEntity.class,"productStage");
            productStageCriteria.createCriteria("lexiconStage").add(Restrictions.eq("abbreviation","INBR"));
            productStageCriteria.add(Property.forName("theLexiconProduct.id").eqProperty("lexiconProduct.id"));
            productCriteria.add(Subqueries.notExists(productStageCriteria.setProjection(Projections.property("productStage.id"))));
        }
    }

    private List<ProductAssociation> buildProductAssociationsFromCriteria(Criteria criteria) {
        List<ProductAssociation>productAssociations = new ArrayList<ProductAssociation>();
        criteria.setProjection(Projections.projectionList().
                                         add( Projections.property("baseProduct.baseManufacturingName"))
                                         .add(Projections.property("productRelationships.manufacturingName"))
                                         .add(Projections.property("productRelationships.varietyName"))
                                         .add(Projections.property("theLexiconProduct.tagVarietyName"))
                                         .add(Projections.property("theLexiconProduct.preCommercialName"))
                                         .add(Projections.property("theLexiconCrop.id")));
        criteria.addOrder(Property.forName("baseProduct.baseManufacturingName").asc())
                                         .addOrder(Property.forName("productRelationships.manufacturingName").asc())
                                         .addOrder(Property.forName("productRelationships.varietyName").asc())
                                         .addOrder(Property.forName("theLexiconProduct.tagVarietyName").asc())
                                         .addOrder(Property.forName("theLexiconProduct.preCommercialName").asc())
                                         .addOrder(Property.forName("theLexiconCrop.id").asc());
       //TODO:Use transformer here instead of tuple 
        for(Object[] tuple: (List<Object[]>)criteria.list()){
            ProductAssociation productAssociation = new ProductAssociation();
            productAssociation.setBaseManufacturingName((String)tuple[0]);
            productAssociation.setManufacturingName((String)tuple[1]);
            productAssociation.setVarietyName((String)(tuple[3]==null?tuple[2]:tuple[3]));
            productAssociation.setPreCommercialName((String)tuple[4]);
            productAssociation.setCropId(tuple[5]==null?null:((Number)tuple[5]).longValue());
            productAssociations.add(productAssociation);
        }
        return productAssociations;
    }
}
