package com.monsanto.sap.vegetable.webservice.exception;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DT_LexiconExceptionNames_Rsp", propOrder = {
    "varietyResponse"
})
public class DTLexiconExceptionNamesRsp {

    @XmlElement(name = "VarietyResponse", required = true)
    private VarietyResponse varietyResponse;

    public VarietyResponse getVarietyResponse() {
        return varietyResponse;
    }

    public void setVarietyResponse(VarietyResponse value) {
        this.varietyResponse = value;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "recErrorStatus",
        "recInsertStatus",
        "recRecvStatus",
        "recUpdateStatus",
        "errorDetails"
    })
    public static class VarietyResponse {

        @XmlElement(name = "RecErrorStatus")
        private String recErrorStatus;
        @XmlElement(name = "RecInsertStatus")
        private String recInsertStatus;
        @XmlElement(name = "RecRecvStatus")
        private String recRecvStatus;
        @XmlElement(name = "RecUpdateStatus")
        private String recUpdateStatus;
        @XmlElement(name = "ErrorDetails", required = true)
        private List<ErrorDetails> errorDetails;

        public String getRecErrorStatus() {
            return recErrorStatus;
        }

        public void setRecErrorStatus(String value) {
            this.recErrorStatus = value;
        }

        public String getRecInsertStatus() {
            return recInsertStatus;
        }

        public void setRecInsertStatus(String value) {
            this.recInsertStatus = value;
        }

        public String getRecRecvStatus() {
            return recRecvStatus;
        }

        public void setRecRecvStatus(String value) {
            this.recRecvStatus = value;
        }

        public String getRecUpdateStatus() {
            return recUpdateStatus;
        }

        public void setRecUpdateStatus(String value) {
            this.recUpdateStatus = value;
        }

        public List<ErrorDetails> getErrorDetails() {
            if (errorDetails == null) {
                errorDetails = new ArrayList<ErrorDetails>();
            }
            return this.errorDetails;
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "pubkey",
            "productCode",
            "errorCode",
            "errorId",
            "errorDescription"
        })
        public static class ErrorDetails {

            @XmlElement(name = "Pubkey", required = true)
            private String pubkey;
            @XmlElement(name = "ProductCode", required = true)
            private String productCode;
            @XmlElement(name = "ErrorCode", required = true)
            private String errorCode;
            @XmlElement(name = "ErrorId", required = true)
            private String errorId;
            @XmlElement(name = "ErrorDescription", required = true)
            private String errorDescription;

            public String getPubkey() {
                return pubkey;
            }

            public void setPubkey(String value) {
                this.pubkey = value;
            }

            public String getProductCode() {
                return productCode;
            }

            public void setProductCode(String value) {
                this.productCode = value;
            }

            public String getErrorCode() {
                return errorCode;
            }

            public void setErrorCode(String value) {
                this.errorCode = value;
            }

            public String getErrorId() {
                return errorId;
            }

            public void setErrorId(String value) {
                this.errorId = value;
            }

            public String getErrorDescription() {
                return errorDescription;
            }

            public void setErrorDescription(String value) {
                this.errorDescription = value;
            }
        }
    }
}
