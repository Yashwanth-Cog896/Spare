/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.transfer.ProductRelationship;

import java.util.ArrayList;
import java.util.List;

/* vvkalu - 7/18/11 */
public class BaseProductSearchResultTransformer {

    public List<BaseProduct> buildBaseProduct(List<BaseProductEntity> baseProducts) {
        List<BaseProduct> baseProductList = new ArrayList<BaseProduct>();
        if (baseProducts != null && !baseProducts.isEmpty()) {
            for (BaseProductEntity baseProduct : baseProducts) {
                baseProductList.add(createBaseProduct(baseProduct));
            }
        }
        return baseProductList;
    }

    private BaseProduct createBaseProduct(BaseProductEntity baseProductEntity) {
        BaseProduct baseProduct = createTransferBaseProduct(baseProductEntity);
        List<ProductRelationship> relationships = new ArrayList<ProductRelationship>();
        for (ProductRelationshipEntity relationshipEntity : baseProductEntity.getProductRelationships()) {
            relationships.add(createTransferProductRelationship(relationshipEntity));
        }
        baseProduct.setProductRelationship(relationships);
        return baseProduct;
    }

    private BaseProduct createTransferBaseProduct(BaseProductEntity baseProductEntity) {
        BaseProduct baseProduct = new BaseProduct();
        baseProduct.setBaseManufacturingName(baseProductEntity.getBaseManufacturingName());
        baseProduct.setBaseProductId(baseProductEntity.getId());
        baseProduct.setCropId(baseProductEntity.getLexiconCrop().getId());
        baseProduct.setParent(baseProductEntity.getParentProduct());
        return baseProduct;
    }

    private ProductRelationship createTransferProductRelationship(ProductRelationshipEntity relationshipEntity) {
        ProductRelationship relationship = new ProductRelationship();
        relationship.setProductRelationshipId(relationshipEntity.getId());
        relationship.setManufacturingName(relationshipEntity.getManufacturingName());
        relationship.setVarietyName(relationshipEntity.getVarietyName() != null ? relationshipEntity.getVarietyName() : null);
        return relationship;
    }

}