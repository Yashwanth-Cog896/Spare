package com.monsanto.tps.productstewardship.persistence.lexicon.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "AUTO_NAME_BRAND_ASSIGN", schema="Lexicon")
public class AutoNameBrandAssignEntity implements Serializable{
  @Id
  @Column(name = "AUTO_NAME_BRAND_ASSIGN_ID")
  private long id;

  @ManyToOne
  @JoinColumn(name = "BRAND_ID", nullable = false)
  private LexiconBrandEntity brand;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name="PRODUCT_TYPE_ID",nullable = false)
  private ProductTypeEntity productType;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name="PRODUCTION_ENVIRONMENT_ID",nullable = false)
  private ProductionEnvironmentEntity productionEnvironment;

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public LexiconBrandEntity getBrand() {
    return brand;
  }

  public void setBrand(LexiconBrandEntity brand) {
    this.brand = brand;
  }

  public ProductTypeEntity getProductType() {
    return productType;
  }

  public void setProductType(ProductTypeEntity productType) {
    this.productType = productType;
  }

  public ProductionEnvironmentEntity getProductionEnvironment() {
    return productionEnvironment;
  }

  public void setProductionEnvironment(ProductionEnvironmentEntity productionEnvironment) {
    this.productionEnvironment = productionEnvironment;
  }
}
