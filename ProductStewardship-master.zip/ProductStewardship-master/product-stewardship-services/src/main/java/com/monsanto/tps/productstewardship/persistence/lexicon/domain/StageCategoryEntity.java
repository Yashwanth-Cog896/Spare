package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 12:48:02 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "STAGE_CATEGORY", schema = "Lexicon")
public class StageCategoryEntity  implements Serializable {
    public static final String VEGETABLE="Vegetable";
    public static final String NON_VEGETABLE = "Non-Vegetable";
    @Id
    @Column(name="STAGE_CATEGORY_ID",nullable = false)
    private Long id;

    @Column(name="STAGE_CATEGORY_NAME",nullable = false,length=50)
    private String  name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
