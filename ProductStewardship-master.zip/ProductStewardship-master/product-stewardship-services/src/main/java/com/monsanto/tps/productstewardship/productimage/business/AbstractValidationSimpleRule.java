package com.monsanto.tps.productstewardship.productimage.business;


import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;

/**
 * vvkalu - Mar 22, 2010 5:22:52 PM
 */
public abstract class AbstractValidationSimpleRule implements ValidationSimpleRule<ImageValidationModel> {

   protected boolean preConditionsMet(ImageValidationModel model) {
      return model.isPreConditionMet();
   }
}
