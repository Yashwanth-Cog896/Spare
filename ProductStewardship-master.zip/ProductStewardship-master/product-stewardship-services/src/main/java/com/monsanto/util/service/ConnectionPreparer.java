package com.monsanto.util.service;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 12, 2007
 * Time: 12:52:30 PM
 */
public interface ConnectionPreparer {
   HttpURLConnection prepareConnection(final HttpURLConnection conn) throws IOException;
}
