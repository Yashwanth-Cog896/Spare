package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialname;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ComlNameValidRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconBrandDao lexiconBrandDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        if(criteriaViolated(model.getProductStage().getBrandName(),model.getProductStage().getCommercialName())){
             status.addCondition(new ValidationResult(ProductEditService.INVALID_COML_NAME, ValidationSeverity.ERROR));
        }
    }

    private boolean criteriaViolated(String brandName, String comlNameValue){
        if(StringUtils.isNotBlank(comlNameValue)){
           return !(isTechDevRestricted(brandName) ? isValidNameForTDRestrictedBrands(comlNameValue) : isValidNameForTDEnabledBrands(comlNameValue));
        }
        else {
            return false;
        }
    }
    private boolean isValidNameForTDRestrictedBrands(String comlNameValue) {
       return comlNameValue.matches("[a-zA-Z0-9_\\+\\-\\/\\ ]+");
    }
    private boolean isValidNameForTDEnabledBrands(String comlNameValue) {
       return comlNameValue.matches("[a-zA-Z0-9\\+\\-\\/\\ ]+");
    }

    private boolean isTechDevRestricted(String brandName){
        boolean techDevRestricted = false;
        if(StringUtils.isNotBlank(brandName)){
            LexiconBrandEntity lexiconBrand = lexiconBrandDao.getByName(brandName);
            if(lexiconBrand!=null){
                techDevRestricted=lexiconBrand.isTechDevRestricted();
            }
        }
        return techDevRestricted;
    }
    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }
}
