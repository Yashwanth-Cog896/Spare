package com.monsanto.sap.vegetable.webservice.exception;



import com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for DT_LexiconExceptionNames_Req complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DT_LexiconExceptionNames_Req">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DocumentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="DocumentDateTime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="From">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="PartnerIdentifier" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                                     &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="ContactInformation" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="To" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="PartnerIdentifier" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                                     &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="ContactInformation" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ExceptionNames" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ExceptionCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ProductCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="ExceptionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="SemiMaterialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="BlenderCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="BlendPercent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="RestrictCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="PhaseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="PhaseSequence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="PrimaryBrand" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="QualityLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="DisplaySequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DT_LexiconExceptionNames_Req", propOrder = {
    "header",
    "exceptionNames"
})
public class DTLexiconExceptionNamesReq {

    @XmlElement(name = "Header", required = true)
    private DTLexiconHeader header;
    @XmlElement(name = "ExceptionNames", required = true)
    private List<ExceptionNames> exceptionNames;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader }
     *     
     */
    public DTLexiconHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader }
     *     
     */
    public void setHeader(DTLexiconHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the exceptionNames property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exceptionNames property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExceptionNames().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExceptionNames }
     * 
     * 
     */
    public List<ExceptionNames> getExceptionNames() {
        if (exceptionNames == null) {
            exceptionNames = new ArrayList<ExceptionNames>();
        }
        return this.exceptionNames;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ExceptionCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ProductCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *         &lt;element name="ExceptionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="SemiMaterialCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="BlenderCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="BlendPercent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="RestrictCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="PhaseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="PhaseSequence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="PrimaryBrand" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="QualityLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="DisplaySequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "exceptionCode",
        "productCode",
        "exceptionName",
        "semiMaterialCode",
        "blenderCode",
        "blendPercent",
        "restrictCode",
        "phaseCode",
        "phaseSequence",
        "primaryBrand",
        "qualityLevel",
        "displaySequenceNumber"
    })
    public static class ExceptionNames {

        @XmlElement(name = "ExceptionCode", required = true)
        private String exceptionCode;
        @XmlElement(name = "ProductCode", required = true)
        private String productCode;
        @XmlElement(name = "ExceptionName")
        private String exceptionName;
        @XmlElement(name = "SemiMaterialCode")
        private String semiMaterialCode;
        @XmlElement(name = "BlenderCode")
        private String blenderCode;
        @XmlElement(name = "BlendPercent")
        private String blendPercent;
        @XmlElement(name = "RestrictCode")
        private String restrictCode;
        @XmlElement(name = "PhaseCode")
        private String phaseCode;
        @XmlElement(name = "PhaseSequence")
        private String phaseSequence;
        @XmlElement(name = "PrimaryBrand")
        private String primaryBrand;
        @XmlElement(name = "QualityLevel")
        private String qualityLevel;
        @XmlElement(name = "DisplaySequenceNumber")
        private String displaySequenceNumber;

        /**
         * Gets the value of the exceptionCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getExceptionCode() {
            return exceptionCode;
        }

        /**
         * Sets the value of the exceptionCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setExceptionCode(String value) {
            this.exceptionCode = value;
        }

        /**
         * Gets the value of the productCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProductCode() {
            return productCode;
        }

        /**
         * Sets the value of the productCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProductCode(String value) {
            this.productCode = value;
        }

        /**
         * Gets the value of the exceptionName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getExceptionName() {
            return exceptionName;
        }

        /**
         * Sets the value of the exceptionName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setExceptionName(String value) {
            this.exceptionName = value;
        }

        /**
         * Gets the value of the semiMaterialCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSemiMaterialCode() {
            return semiMaterialCode;
        }

        /**
         * Sets the value of the semiMaterialCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSemiMaterialCode(String value) {
            this.semiMaterialCode = value;
        }

        /**
         * Gets the value of the blenderCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBlenderCode() {
            return blenderCode;
        }

        /**
         * Sets the value of the blenderCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBlenderCode(String value) {
            this.blenderCode = value;
        }

        /**
         * Gets the value of the blendPercent property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBlendPercent() {
            return blendPercent;
        }

        /**
         * Sets the value of the blendPercent property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBlendPercent(String value) {
            this.blendPercent = value;
        }

        /**
         * Gets the value of the restrictCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRestrictCode() {
            return restrictCode;
        }

        /**
         * Sets the value of the restrictCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRestrictCode(String value) {
            this.restrictCode = value;
        }

        /**
         * Gets the value of the phaseCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPhaseCode() {
            return phaseCode;
        }

        /**
         * Sets the value of the phaseCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPhaseCode(String value) {
            this.phaseCode = value;
        }

        /**
         * Gets the value of the phaseSequence property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPhaseSequence() {
            return phaseSequence;
        }

        /**
         * Sets the value of the phaseSequence property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPhaseSequence(String value) {
            this.phaseSequence = value;
        }

        /**
         * Gets the value of the primaryBrand property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPrimaryBrand() {
            return primaryBrand;
        }

        /**
         * Sets the value of the primaryBrand property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPrimaryBrand(String value) {
            this.primaryBrand = value;
        }

        /**
         * Gets the value of the qualityLevel property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getQualityLevel() {
            return qualityLevel;
        }

        /**
         * Sets the value of the qualityLevel property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setQualityLevel(String value) {
            this.qualityLevel = value;
        }

        /**
         * Gets the value of the displaySequenceNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDisplaySequenceNumber() {
            return displaySequenceNumber;
        }

        /**
         * Sets the value of the displaySequenceNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDisplaySequenceNumber(String value) {
            this.displaySequenceNumber = value;
        }

    }
}
