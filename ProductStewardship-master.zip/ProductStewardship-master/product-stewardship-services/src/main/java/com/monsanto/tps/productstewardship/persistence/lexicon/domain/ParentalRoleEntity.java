package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:55:28 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PARENTAL_ROLE", schema = "MIDAS")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class ParentalRoleEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "PARENTAL_ROLE_ID")
    private long id;

    @Basic
    @Column(name = "NAME")
    private String name;

    @Basic
    @Column(name = "PARENTAL_ROLE_REF_ID")
    private String parentalRoleRefId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getParentalRoleRefId() {
        return parentalRoleRefId;
    }

    public void setParentalRoleRefId(String parentalRoleRefId) {
        this.parentalRoleRefId = parentalRoleRefId;
    }
}
