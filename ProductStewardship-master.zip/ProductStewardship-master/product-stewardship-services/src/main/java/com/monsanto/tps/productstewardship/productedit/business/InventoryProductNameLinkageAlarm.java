package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageRequest;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageResponse;
import com.monsanto.tcc.inventorycommon.transferobject.PreCommercialLinkageResponse;
import com.monsanto.tps.productstewardship.email.EmailParticipants;
import com.monsanto.tps.productstewardship.email.ExceptionFormatter;
import com.monsanto.tps.productstewardship.email.PostOffice;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import javax.mail.MessagingException;
import java.util.List;

public class InventoryProductNameLinkageAlarm {
    private static final org.apache.log4j.Logger log = Logger.getLogger(InventoryProductNameLinkageAlarm.class);
    public  static final String ERROR_EMAIL_RECIPIENTS_CSV = "dl-tps-lexicon-dev@monsanto.com, vvsri@monsanto.com";
    public static final String ERROR_EMAIL_SENDER = EmailParticipants.SENDER;
    public static final String ERROR_EMAIL_SUBJECT = "Error creating inventory to product name linkage (" + EnvironmentHelper.getFunction() + ")";
    
    private PostOffice postOffice;
    private ExceptionFormatter exceptionFormatter;

    public  void raisePrecommercialAlarm(List<PreCommercialLinkageResponse> preCommercialLinkageResponses) {
        raiseAlarm(buildPrecommercialResponseErrorText(preCommercialLinkageResponses));
    }
    public void raisePrecommercialAlarm(List<String> productPubkeys, RuntimeException e) {
        raiseAlarm(buildPrecommercialExceptionErrorText(productPubkeys, e));
    }
    public void raiseCommercialAlarm(List<CommercialLinkageRequest> commercialLinkageRequests, RuntimeException e) {
        raiseAlarm(buildCommercialExceptionErrorText(commercialLinkageRequests,e));
    }

    public void raiseCommercialAlarm(List<CommercialLinkageResponse> commercialLinkageResponses) {
        raiseAlarm(buildCommercialResponseErrorText(commercialLinkageResponses));
    }

    private String buildPrecommercialExceptionErrorText(List<String> productPubkeys, RuntimeException e) {

       String productPubkeyCsv = StringUtils.join(productPubkeys, ",");
       return "Error while updating precommercial inventory product name linkage with pubkeys: " + productPubkeyCsv + ".  Error was:\n\n" + exceptionFormatter.format(e,false);
    }

    private String buildCommercialExceptionErrorText(List<CommercialLinkageRequest> commercialLinkageRequests, RuntimeException e) {
       StringBuffer errorText = new StringBuffer("Error while updating commercial inventory product name linkage with requests:\n");
       for (CommercialLinkageRequest commercialLinkageRequest : commercialLinkageRequests) {
          errorText.append(" " + render(commercialLinkageRequest) + "\n");
       }
       errorText.append("Error was:\n\n" + exceptionFormatter.format(e,false));
       return errorText.toString();
    }
    private String render(CommercialLinkageRequest request) {
      return "[Product name pubkey: " + request.getProductNamePublicKey() + ", tdRestricted: " + request.isTdRestricted() + "]";
    }
    private String buildPrecommercialResponseErrorText(List<PreCommercialLinkageResponse> responses) {
        StringBuilder errorText = new StringBuilder();
        for (PreCommercialLinkageResponse response : responses) {
           addErrors(errorText, response.getErrorMessages(), "precommercial product", response.getProductPublicKey());
        }
        return errorText.toString();
     }

     private String buildCommercialResponseErrorText(List<CommercialLinkageResponse> responses) {
        StringBuilder errorText = new StringBuilder();
        for (CommercialLinkageResponse response : responses) {
           addErrors(errorText, response.getErrorMessages(), "commercial product stage", response.getProductNamePublicKey());
        }
        return errorText.toString();
     }

     private void addErrors(StringBuilder errorText, List<String> errorMessages, String typeOfPublicKey, String publicKey) {
       if(hasErrors(errorMessages)) {
          errorText.append("Error for ").append(typeOfPublicKey).append(" pubkey '").append(publicKey).append("':").append("\n");
          for (String errorMessage : errorMessages) {
             errorText.append("    - ").append(errorMessage).append("\n");
          }
          errorText.append("\n\n");
       }
   }
    private boolean hasErrors(List<String> errorMessages) {
       return !CollectionUtils.isEmpty(errorMessages);
    }

   private void raiseAlarm(String alarm) {
      if(EnvironmentHelper.sf_cstrWin.equals(EnvironmentHelper.getFunction())) {
         log.error(alarm);
      }
      else {
         tryToEmailButFallBackOnLoggingIfEmailFails(alarm);
      }
   }

   private void tryToEmailButFallBackOnLoggingIfEmailFails(String alarm) {
      try {
         email(alarm);
      }
      catch (MessagingException e) {
         log.error(alarm);
         log.error(e.getMessage(),e);
      }
   }
   private void email(String alarm)
      throws MessagingException
   {
      postOffice.send(ERROR_EMAIL_RECIPIENTS_CSV, ERROR_EMAIL_SENDER, ERROR_EMAIL_SUBJECT, alarm);
   }

    public void setExceptionFormatter(ExceptionFormatter exceptionFormatter) {
        this.exceptionFormatter = exceptionFormatter;
    }

    public void setPostOffice(PostOffice postOffice) {
        this.postOffice = postOffice;
    }
}
