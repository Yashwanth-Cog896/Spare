package com.monsanto.sap.vegetable.webservice.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>Java class for anonymous complex type.
 * <p/>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p/>
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PartnerIdentifier" minOccurs="0">
 *           &lt;complexType>
 *             &lt;simpleContent>
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                 &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/extension>
 *             &lt;/simpleContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ContactInformation" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "partnerName",
        "partnerIdentifier",
        "contactInformation"
})
public class DTLexiconFrom {

    @XmlElement(name = "PartnerName", required = true)
    private String partnerName;
    @XmlElement(name = "PartnerIdentifier")
    private DTLexiconPartnerIdentifier partnerIdentifier;
    @XmlElement(name = "ContactInformation")
    private DTLexiconContactInformation contactInformation;

    /**
     * Gets the value of the partnerName property.
     *
     * @return possible object is
     *         {@link String }
     */
    public String getPartnerName() {
        return partnerName;
    }

    /**
     * Sets the value of the partnerName property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPartnerName(String value) {
        this.partnerName = value;
    }

    /**
     * Gets the value of the partnerIdentifier property.
     *
     * @return possible object is
     *         {@link DTLexiconVarietyReq.Header.From.PartnerIdentifier }
     */
    public DTLexiconPartnerIdentifier getPartnerIdentifier() {
        return partnerIdentifier;
    }

    /**
     * Sets the value of the partnerIdentifier property.
     *
     * @param value allowed object is
     *              {@link DTLexiconVarietyReq.Header.From.PartnerIdentifier }
     */
    public void setPartnerIdentifier(DTLexiconPartnerIdentifier value) {
        this.partnerIdentifier = value;
    }

    /**
     * Gets the value of the contactInformation property.
     *
     * @return possible object is
     *         {@link DTLexiconVarietyReq.Header.From.ContactInformation }
     */
    public DTLexiconContactInformation getContactInformation() {
        return contactInformation;
    }

    /**
     * Sets the value of the contactInformation property.
     *
     * @param value allowed object is
     *              {@link DTLexiconVarietyReq.Header.From.ContactInformation }
     */
    public void setContactInformation(DTLexiconContactInformation value) {
        this.contactInformation = value;
    }

}
