package com.monsanto.tps.productstewardship.sap.business.rowcrop;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;

import java.util.*;

public interface SapRowCropFlow {
  List<List<PqSapQueueEntryEntity>> retrievePqSapQueueEntriesInGroupToProcess(int groupSize);
  void flowNextChangesToSap(List<PqSapQueueEntryEntity> pqSapQueueEntries);
}
