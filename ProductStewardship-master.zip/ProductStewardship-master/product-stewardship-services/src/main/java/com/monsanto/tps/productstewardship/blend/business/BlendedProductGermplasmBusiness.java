package com.monsanto.tps.productstewardship.blend.business;


import com.monsanto.tps.dataservices.product.services.BlendedProductService;
import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Sep 27, 2010
 * Time: 2:10:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlendedProductGermplasmBusiness {
    private BlendedProductDetailsBuilder blendedProductDetailsBuilder;

    private BlendedProductService blendedProductService;

    private MidasProductIdToXrefMapBuilder midasProductIdToXrefMapBuilder;

    public List<LexBlendedProductDetails> getBlendedProductDetails(List<Long> germplasmIds) {
        if (checkForNullAndEmpty(germplasmIds)) {
            List<BlendedProductDetails> productDetails = blendedProductService.getBlendedProductComponents(germplasmIds);
            Map<Long, FbsCommonProductXrefEntity> productXrefMap = midasProductIdToXrefMapBuilder.buildMap(productDetails);
            List<LexiconProductEntity> preComlProducts = getPreComlProducts(productXrefMap);
            return blendedProductDetailsBuilder.buildProductDetails(productDetails, productXrefMap, preComlProducts);
        }
        return new ArrayList<LexBlendedProductDetails>();
    }

    private List<LexiconProductEntity> getPreComlProducts(Map<Long, FbsCommonProductXrefEntity> productXrefMap) {
        List<LexiconProductEntity> preComlProducts = new ArrayList<LexiconProductEntity>(productXrefMap.size());
        for(FbsCommonProductXrefEntity xref:productXrefMap.values()){
            preComlProducts.add(xref.getLexiconProduct());
        }
        return preComlProducts;
    }

    private boolean checkForNullAndEmpty(List<Long> germplasmIds) {
        return germplasmIds != null && !germplasmIds.isEmpty();
    }

    public void setBlendedProductDetailsBuilder(BlendedProductDetailsBuilder blendedProductDetailsBuilder) {
        this.blendedProductDetailsBuilder = blendedProductDetailsBuilder;
    }

    public void setBlendedProductService(BlendedProductService blendedProductService) {
        this.blendedProductService = blendedProductService;
    }

    public void setMidasProductIdToXrefMapBuilder(MidasProductIdToXrefMapBuilder midasProductIdToXrefMapBuilder) {
        this.midasProductIdToXrefMapBuilder = midasProductIdToXrefMapBuilder;
    }
}
