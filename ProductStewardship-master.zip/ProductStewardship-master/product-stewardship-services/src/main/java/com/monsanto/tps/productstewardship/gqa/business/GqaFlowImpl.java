package com.monsanto.tps.productstewardship.gqa.business;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 25, 2011
 * Time: 9:27:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class GqaFlowImpl implements GqaFlow{

    private GqaProductFlow gqaProductFlow;
    public static final int TEN_MINUTES = 600000;

    @Override
    public void flowChangesToGqa() {
        long startTime = System.currentTimeMillis();
        List<Long> productIdsToProcess = gqaProductFlow.getPqSapProductIdsToProcess();
        for(Long pqSapProductId: productIdsToProcess){
            gqaProductFlow.flowNextChangeToGqa(pqSapProductId);
            if((System.currentTimeMillis()-startTime)> TEN_MINUTES){
                break;
            }
        }
    }
    public void setGqaProductFlow(GqaProductFlow gqaProductFlow) {
        this.gqaProductFlow = gqaProductFlow;
    }
}
