package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "AUDIT_STAGING", schema = "Lexicon")
public class AuditStagingEntity implements Serializable {
    @Id
    @Column(name = "ORACLE_SID", nullable = false)
    private Long   oracleSid;

    @Column(name= "USER_PARTY_ID", nullable = true)
    private Long  userPartyId;

    @Column(name = "PROCESS_NAME", nullable = false,length=50)
    private String processName;

    @Column(name = "AUDIT_COMMENT", nullable = true, length = 4000)
    private String auditComment;

    @Column(name = "AUDIT_REQUESTOR", nullable = true, length = 50 )
    private String auditRequestor;

    @Column(name = "CREATION_TIMESTAMP", nullable = true)
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationTimestamp;

    @Column(name = "OSUSER", nullable = true, length=30)
    private String osuser;

    @Column(name = "MACHINE", nullable = true, length=64)
    private String machine;

    @Column(name="USER_LOGIN_ID", nullable=false, length=32)
    private String userLoginId;


    public Long getOracleSid() {
        return oracleSid;
    }

    public void setOracleSid(Long oracleSid) {
        this.oracleSid = oracleSid;
    }    
    public String getAuditComment() {
        return auditComment;
    }

    public void setAuditComment(String auditComment) {
        this.auditComment = auditComment;
    }

    public String getAuditRequestor() {
        return auditRequestor;
    }

    public void setAuditRequestor(String auditRequestor) {
        this.auditRequestor = auditRequestor;
    }

    public Date getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(Date creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }


    public String getOsuser() {
        return osuser;
    }

    public void setOsuser(String osuser) {
        this.osuser = osuser;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getUserLoginId() {
        return userLoginId;
    }

    public void setUserLoginId(String userLoginId) {
        this.userLoginId = userLoginId;
    }

    public Long getUserPartyId() {
        return userPartyId;
    }

    public void setUserPartyId(Long userPartyId) {
        this.userPartyId = userPartyId;
    }
}
