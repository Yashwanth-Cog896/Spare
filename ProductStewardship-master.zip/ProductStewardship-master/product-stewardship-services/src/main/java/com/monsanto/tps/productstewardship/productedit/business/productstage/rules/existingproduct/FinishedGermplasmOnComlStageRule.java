package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.existingproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductGermplasmEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class FinishedGermplasmOnComlStageRule implements ValidationSimpleRule<StageValidationModel> {
   public static final String FINISHED_LINE_TYPE = "FINISHED";
   public static final String HYBRID_LINE_TYPE = "HYBRID";
   private LexiconProductDao lexiconProductDao;
   private LexiconStageDao lexiconStageDao;
    
    @Override
    public void validate(StageValidationModel model, ValidationStatus    status) {
        String productPubkey = model.getProduct().getProductPubkey();
        String stageAbbreviation = model.getProductStage().getStageAbbreviation();
        if(StringUtils.isNotBlank(productPubkey)&&(StringUtils.isNotBlank(stageAbbreviation))){
            LexiconProductEntity lexiconProduct=lexiconProductDao.getByPubkey(productPubkey);
            LexiconStageEntity lexiconStage=lexiconStageDao.findStageByAbbreviation(stageAbbreviation);
            if((lexiconStage!=null)&&
               (lexiconStage.isCommercial())&&
               (lexiconProduct!=null)&&
               (lexiconProduct.getFbsCommonProductXref()!=null)){
                if(!hasFinishedGermplasm(lexiconProduct)){
                    status.addCondition(new ValidationResult(ProductEditService.NO_FINISHED_GERMPLASM_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    private boolean hasFinishedGermplasm(LexiconProductEntity lexiconProduct) {
        boolean hasFinished=false;
        for(ProductGermplasmEntity productGermplasm:lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()){
            GermplasmEntity germplasm = productGermplasm.getGermplasm();
            if(!germplasm.isDeleted()&&germplasmFinished(germplasm)){
                hasFinished=true;
            }
        }
        return hasFinished;
    }

    public boolean germplasmFinished(GermplasmEntity germplasm){
        String lineType = germplasm.getLineType().getLineTypeRefId();
        return (HYBRID_LINE_TYPE.equals(lineType)) ?
              germplasm.isFinished() : FINISHED_LINE_TYPE.equals(lineType);
    }
    public void setLexiconProductDao(LexiconProductDao  lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
