package com.monsanto.tps.productstewardship.sap.business;

import com.monsanto.tps.productstewardship.sap.business.vegetable.SapVegetableProductFlow;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class SapFlowImpl implements SapFlow {
   private static final org.apache.log4j.Logger log = Logger.getLogger(SapFlowImpl.class);
    private SapVegetableProductFlow sapVegetableProductFlow;
    public static final int TEN_MINUTES = 600000;
    private int pqSapGroupSize = 100;

    @Override
    public void flowVegetableChangesToSap() {
        long startTime = System.currentTimeMillis();
        List<List<Long>> pqSapQueueEntryIdGroups = retrievePqSapQueueEntryGroups();
        for(List<Long> pqSapQueueEntryIdGroup: pqSapQueueEntryIdGroups){
            flowNextChangesToSap(pqSapQueueEntryIdGroup);
            if((System.currentTimeMillis()-startTime)> TEN_MINUTES){
                break;
            }            
        }
    }

    private List<List<Long>> retrievePqSapQueueEntryGroups() {
        List<Long> pqSapQueueEntryIds = sapVegetableProductFlow.retrievePqSapQueueEntryIdsToProcess();
        boolean extraGroup =  ((pqSapQueueEntryIds.size() % pqSapGroupSize)>0);
        int numberOfGroups = (pqSapQueueEntryIds.size() / pqSapGroupSize) + (extraGroup?1:0);
        List<List<Long>> pqSapQueueEntryIdGroups = new ArrayList<List<Long>>(numberOfGroups);
        int pqSapQueueEntryIdsSize = pqSapQueueEntryIds.size();
        for(int groupIndex=0;groupIndex<numberOfGroups;groupIndex++){
            int groupStartIndex = groupIndex * pqSapGroupSize;
            int groupEndIndex =  groupStartIndex+ pqSapGroupSize;
            if(groupEndIndex> pqSapQueueEntryIdsSize){
                groupEndIndex = pqSapQueueEntryIds.size();
            }
            pqSapQueueEntryIdGroups.add(pqSapQueueEntryIds.subList(groupStartIndex,groupEndIndex));
        }
        return pqSapQueueEntryIdGroups;
    }

    private void flowNextChangesToSap(List<Long> productIdsGroup) {
        sapVegetableProductFlow.flowNextChangesToSap(productIdsGroup);
    }

    public void setSapVegetableProductFlow(SapVegetableProductFlow sapVegetableProductFlow) {
        this.sapVegetableProductFlow = sapVegetableProductFlow;
    }

    public int getPqSapGroupSize() {
        return pqSapGroupSize;
    }

    public void setPqSapGroupSize(int pqSapGroupSize) {
        this.pqSapGroupSize = pqSapGroupSize;
    }
}
