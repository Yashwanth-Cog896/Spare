package com.monsanto.tps.productstewardship.blend.business;

import com.google.common.collect.Multimap;
import com.monsanto.tps.dataservices.product.transfer.ProductGermplasmDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.BlendedComponentPreComlProduct;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexProductGermplasmDetails;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Sep 30, 2010
 * Time: 5:46:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexBlendedProductBuilder {

    public List<LexProductGermplasmDetails> build(Long germplasmId,
                                                  List<ProductGermplasmDetails> productGermplasmDetails,
                                                  Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductsMap) {
        List<LexProductGermplasmDetails> productGermplasms = new ArrayList<LexProductGermplasmDetails>();
        for (ProductGermplasmDetails productGermplasm : productGermplasmDetails) {
            createLexProductDetails(germplasmId, germplasmIdToPreComlProductsMap, productGermplasms, productGermplasm);
        }
        return productGermplasms;
    }

    private void createLexProductDetails(Long germplasmId, Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductsMap, List<LexProductGermplasmDetails> productGermplasms, ProductGermplasmDetails productGermplasm) {
        LexProductGermplasmDetails lexProductGermplasm = new LexProductGermplasmDetails();
        lexProductGermplasm.setBlendPercent(productGermplasm.getBlendPercent());
        lexProductGermplasm.setBlendComponent(productGermplasm.getBlendComponent());
        lexProductGermplasm.setComponentGermplasmId(productGermplasm.getComponentGermplasmId());
        lexProductGermplasm.setBlendedGermplasmId(productGermplasm.getBlendedProductGermplasmId());
        lexProductGermplasm.setFinished(productGermplasm.getFinished());
        lexProductGermplasm.setLineCode(productGermplasm.getLineCode());
        lexProductGermplasm.setLineType(productGermplasm.getLineType());
        lexProductGermplasm.setOrigin(productGermplasm.getOrigin());
        lexProductGermplasm.setSources(productGermplasm.getSources());

        buildBlendedPreComlProduct(germplasmId,
                germplasmIdToPreComlProductsMap,
                lexProductGermplasm,
                productGermplasm);
        productGermplasms.add(lexProductGermplasm);
    }

    private void buildBlendedPreComlProduct(Long germplasmId,
                                            Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductsMap,
                                            LexProductGermplasmDetails lexProductGermplasm,
                                            ProductGermplasmDetails productGermplasm) {
        List<BlendedComponentPreComlProduct> preComlProducts = new ArrayList<BlendedComponentPreComlProduct>();
        for (Long productId : productGermplasm.getMidasProductIds()) {
            for (BlendedPreComlProduct productBlended : germplasmIdToPreComlProductsMap.get(germplasmId)) {
                createBlendedPreComlProduct(preComlProducts, productId, productBlended);
            }
        }
        lexProductGermplasm.setPreComlProduct(preComlProducts);
    }

    private void createBlendedPreComlProduct(List<BlendedComponentPreComlProduct> preComlProducts, Long productId, BlendedPreComlProduct productBlended) {
        if (productId.equals(productBlended.getMidasProductId())) {
            BlendedComponentPreComlProduct preComlProduct = new BlendedComponentPreComlProduct();
            preComlProduct.setLexiconProductPubkey(productBlended.getLexiconPubkey());
            preComlProduct.setPreComlName(productBlended.getPreComlName());
            preComlProducts.add(preComlProduct);
        }
    }
}
