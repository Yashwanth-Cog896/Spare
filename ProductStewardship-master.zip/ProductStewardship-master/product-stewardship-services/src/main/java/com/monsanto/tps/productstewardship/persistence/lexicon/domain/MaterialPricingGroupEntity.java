package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:28:03 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "materialPricingGroupIdGenerator",allocationSize = 1,sequenceName = "Lexicon.MATERIAL_PRICING_GROUP_ID_SEQ")
@Table(name = "MATERIAL_PRICING_GROUP", schema = "Lexicon")

public class MaterialPricingGroupEntity  implements Serializable {
    
    @Id
    @Column(name="MATERIAL_PRICING_GROUP_ID")
    @GeneratedValue(generator = "materialPricingGroupIdGenerator")
    private long id;
    @Column(name="MATERIAL_PRICING_GROUP_NAME",nullable = false, length = 50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Column(name="MATERIAL_PRICING_GROUP_CODE",nullable = false,length=10)
    private String code;
    @Column(name="MATERIAL_PRICING_GROUP_PUBKEY",nullable = false, length=20)
    private String pubkey;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
