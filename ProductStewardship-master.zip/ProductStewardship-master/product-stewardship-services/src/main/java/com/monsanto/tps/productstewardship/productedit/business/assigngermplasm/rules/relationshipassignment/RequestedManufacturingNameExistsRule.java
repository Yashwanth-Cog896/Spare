package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class RequestedManufacturingNameExistsRule implements ValidationSimpleRule<Product> {

  private ProductRelationshipDao productRelationshipDao;
  @Override
  public void validate(Product model, ValidationStatus status) {
    if (!StringUtils.isNullOrEmpty(model.getManufacturingName())) {
        ProductRelationshipEntity existingProductRelationship = productRelationshipDao.getByManufacturingName(model.getManufacturingName());
        if ((existingProductRelationship==null) || existingProductRelationship.getLogicalDelete()) {
          status.addCondition(new ValidationResult(ProductEditService.SPEC_MANUFACTURING_NAME_DOES_NOT_EXIST, ValidationSeverity.ERROR));
        }
    }
  }

  public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
    this.productRelationshipDao = productRelationshipDao;
  }
}
