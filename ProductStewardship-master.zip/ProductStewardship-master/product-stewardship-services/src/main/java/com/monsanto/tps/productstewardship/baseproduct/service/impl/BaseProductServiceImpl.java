/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.service.impl;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;
import com.monsanto.tps.productstewardship.baseproduct.business.createorupdate.BaseProductBusiness;
import com.monsanto.tps.productstewardship.baseproduct.business.search.BaseProductSearchBusiness;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProductSearchType;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProductService;
import org.springframework.stereotype.Service;

import javax.jws.WebParam;
import java.util.List;

/* vvkalu - 6/27/11 */
@Service
public class BaseProductServiceImpl implements BaseProductService {

    private BaseProductSearchBusiness baseProductSearchBusiness;
    private BaseProductBusiness baseProductBusiness;

    @Override
    @PerformanceMetric(task = "BaseProductService-findBaseProduct", comment = "findBaseProduct")
    public List<BaseProduct> findBaseProduct(@WebParam(name = "searchType") BaseProductSearchType searchType,
                                             @WebParam(name = "name") List<String> names) {
        return baseProductSearchBusiness.findBaseProducts(searchType, names);
    }

    @Override
    @ProfileLogging
    @AuditStage(processName = "Baseproduct create or edit processs", auditComment = "Baseproduct create or edit audit comment")
    public List<BaseProduct> saveProductBaseProducts(@WebParam(name = "baseProducts") List<BaseProduct> baseProducts) {
        return baseProductBusiness.saveOrUpdate(baseProducts);
    }

    public void setBaseProductBusiness(BaseProductBusiness baseProductBusiness) {
        this.baseProductBusiness = baseProductBusiness;
    }

    public void setBaseProductSearchBusiness(BaseProductSearchBusiness baseProductSearchBusiness) {
        this.baseProductSearchBusiness = baseProductSearchBusiness;
    }
}