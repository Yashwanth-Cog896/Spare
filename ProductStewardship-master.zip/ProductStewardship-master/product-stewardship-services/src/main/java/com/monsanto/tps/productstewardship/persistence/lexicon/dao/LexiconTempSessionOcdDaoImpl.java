/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconTempSessionOcdEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TempSessionOcdId;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import javax.annotation.Resource;
import java.util.Collection;

/* vvkalu - 7/11/11 */
public class LexiconTempSessionOcdDaoImpl extends GenericDaoImpl<LexiconTempSessionOcdEntity, TempSessionOcdId> implements LexiconTempSessionOcdDao {

    @Resource
    private SessionFactory sessionFactory;

    public LexiconTempSessionOcdDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public void insertNumberValues(Long requestId, Collection<Long> ids) {
        Session session = sessionFactory.getCurrentSession();
        long counter = 0L;
        for(Long id: ids) {
            session.save(new LexiconTempSessionOcdEntity(new TempSessionOcdId(requestId, id, counter)));
            counter++;
        }
        session.flush();
    }

    @Override
    public void insertTextValues(Long requestId, Collection<String> values) {
        Session session = sessionFactory.getCurrentSession();
        long counter = 0L;
        for(String value: values) {
            session.save(new LexiconTempSessionOcdEntity(new TempSessionOcdId(requestId, value, counter)));
            counter++;
        }
        session.flush();
    }
}