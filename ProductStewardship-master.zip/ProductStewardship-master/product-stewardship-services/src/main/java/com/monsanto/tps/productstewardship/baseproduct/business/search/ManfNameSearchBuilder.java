/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconTempSessionOcdDao;

import java.util.*;

/* vvkalu - 7/15/11 */
public class ManfNameSearchBuilder implements ManfNamesSearchCriteria{

    private static final long REQUEST_ID = 15072011L;
    private BaseProductDao baseProductDao;
    private LexiconTempSessionOcdDao lexiconTempSessionOcdDao;
    private BaseProductSearchResultTransformer baseProductSearchResultTransformer;

    @Override
    public List<BaseProduct> findBaseProducts(List<String> authorizedCropPubkeys, List<String> names) {
        lexiconTempSessionOcdDao.insertTextValues(REQUEST_ID, names);
        return baseProductSearchResultTransformer.buildBaseProduct(baseProductDao.findBaseProductsByManfName(REQUEST_ID, authorizedCropPubkeys));
    }

    public void setBaseProductDao(BaseProductDao baseProductDao) {
        this.baseProductDao = baseProductDao;
    }

    public void setLexiconTempSessionOcdDao(LexiconTempSessionOcdDao lexiconTempSessionOcdDao) {
        this.lexiconTempSessionOcdDao = lexiconTempSessionOcdDao;
    }

    public void setBaseProductSearchResultTransformer(BaseProductSearchResultTransformer baseProductSearchResultTransformer) {
        this.baseProductSearchResultTransformer = baseProductSearchResultTransformer;
    }
}