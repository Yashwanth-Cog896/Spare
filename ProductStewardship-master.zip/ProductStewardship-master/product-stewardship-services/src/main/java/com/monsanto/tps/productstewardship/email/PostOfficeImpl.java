package com.monsanto.tps.productstewardship.email;

import com.monsanto.Util.StringUtils;

import javax.mail.Message;
import javax.mail.MessagingException;

/**
 * User: pjberry
 * Date: Sep 27, 2007
 * Time: 3:55:26 PM
 */
public class PostOfficeImpl
   implements PostOffice
{
   private  SimpleTransport transport;
    private MessageFactory messageFactory;


    public void send(String recipientAddressesCSV, String senderAddress, String subject, String body)
      throws MessagingException
   {
      String[] recipientAddresses = buildRecipients(recipientAddressesCSV);
      Message emailMessage = buildMessage(recipientAddresses, senderAddress, subject, body);
      transport.send(emailMessage);
   }

   private String[] buildRecipients(String recipientAddressesCSV) {
      return StringUtils.splitCsv(recipientAddressesCSV, false);
   }

   private Message buildMessage(String[] recipientAddresses, String senderAddress, String subject, String body)
      throws MessagingException
   {
       return messageFactory.buildMessage(recipientAddresses, senderAddress, subject, body);
   }

    public void setTransport(SimpleTransport transport) {
        this.transport = transport;
    }

    public void setMessageFactory(MessageFactory messageFactory) {
        this.messageFactory = messageFactory;
    }
}
