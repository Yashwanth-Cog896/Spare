package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;
import java.util.List;

public class CommercialProductsMayNotHavePrecommercialTraitsRule  implements ValidationSimpleRule<StageValidationModel> {
    private CommercialTraitStackDao commercialTraitStackDao;
    private LexiconStageDao lexiconStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        String comlTraitName = model.getProductStage().getComlTraitName();
        String stageAbbreviation = model.getProductStage().getStageAbbreviation();
        if(StringUtils.isNotBlank(model.getProduct().getLexiconCropName())&&
           StringUtils.isNotBlank(stageAbbreviation)){
            if(StringUtils.isNotBlank(comlTraitName)){
                List<CommercialTraitStackEntity> traitStacks = commercialTraitStackDao.getByTraitNameAndCrop(comlTraitName,model.getProduct().getLexiconCropName());
                LexiconStageEntity stage = lexiconStageDao.findStageByAbbreviation(stageAbbreviation);
                if(!traitStacks.isEmpty()&&stage!=null){
                    CommercialTraitStackEntity traitStack = traitStacks.get(0);
                    if(traitStack.isPreCommercial()&&stage.isCommercial()){
                        status.addCondition(new ValidationResult(ProductEditService.COML_PROD_WITH_PRECOML_TRAIT, ValidationSeverity.ERROR));
                    }
                }
            }
        }
    }

    public void setCommercialTraitStackDao(CommercialTraitStackDao commercialTraitStackDao) {
        this.commercialTraitStackDao = commercialTraitStackDao;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
