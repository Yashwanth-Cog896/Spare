package com.monsanto.tps.productstewardship.gqa.service.impl;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.productstewardship.gqa.business.GqaFlow;
import com.monsanto.tps.productstewardship.gqa.service.GqaFlowService;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 24, 2011
 * Time: 9:36:54 AM
 * To change this template use File | Settings | File Templates.
 */

public class GqaFlowServiceImpl implements GqaFlowService {

    private GqaFlow gqaFlow;

    @Override
    @ProfileLogging
    public void flowChangesToGqa(){
        gqaFlow.flowChangesToGqa();
    }

    public void setGqaFlow(GqaFlow gqaFlow) {
        this.gqaFlow = gqaFlow;
    }
}
