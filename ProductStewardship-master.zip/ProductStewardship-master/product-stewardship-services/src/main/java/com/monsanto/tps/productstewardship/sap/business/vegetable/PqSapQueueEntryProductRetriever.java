package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;

import java.util.ArrayList;
import java.util.List;

public class PqSapQueueEntryProductRetriever {
    private LexiconProductDao lexiconProductDao;
    private ProductRelationshipDao productRelationshipDao;
    private LexiconProductStageDao lexiconProductStageDao;
    private BaseProductDao baseProductDao;

    
    public List<LexiconProductEntity> retrieveLexiconProducts(PqSapQueueEntryEntity pqSapQueueEntry) {
         List<LexiconProductEntity> lexiconProducts = new ArrayList<LexiconProductEntity>();
         String tableName = pqSapQueueEntry.getTableName();
         if (tableName.equals(PqSapQueueEntryEntity.PRE_COML_PRODUCT) ||
                 tableName.equals(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP_XREF)) {
             retreiveProductToProcess(pqSapQueueEntry, lexiconProducts);
         } else if (tableName.equals(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP)) {
             retrieveProductsToProcessForProductRelationship(lexiconProducts, pqSapQueueEntry);
         } else if (tableName.equals(PqSapQueueEntryEntity.PRODUCT_STAGE)) {
             retrieveProductsToProcessForProductStage(lexiconProducts,pqSapQueueEntry );
         } else if (tableName.equals(PqSapQueueEntryEntity.BASE_PRODUCT)) {
             retrieveProductsToProcessForBaseProduct(lexiconProducts,pqSapQueueEntry );
         }
         return lexiconProducts;
     }

     private void retreiveProductToProcess(PqSapQueueEntryEntity pqSapQueueEntry, List<LexiconProductEntity> lexiconProducts) {

         LexiconProductEntity lexiconProduct = lexiconProductDao.get(pqSapQueueEntry.getTableId());
         if (hasPrimaryExceptionCode(lexiconProduct)) {
             lexiconProducts.add(lexiconProduct);
         }
     }

     private void retrieveProductsToProcessForProductRelationship(List<LexiconProductEntity> lexiconProducts,PqSapQueueEntryEntity pqSapQueueEntry) {
         ProductRelationshipEntity productRelationship = productRelationshipDao.get(pqSapQueueEntry.getTableId());
         if (productRelationship != null) {
             for (ProductRelationshipXrefEntity productRelationshipXref : productRelationship.getProductRelationshipXRefs()) {
                 LexiconProductEntity lexiconProduct = productRelationshipXref.getLexiconProduct();
                 if (hasPrimaryExceptionCode(lexiconProduct)) {
                     lexiconProducts.add(productRelationshipXref.getLexiconProduct());
                 }
             }
         }
     }

     private void retrieveProductsToProcessForProductStage(List<LexiconProductEntity> lexiconProducts,PqSapQueueEntryEntity pqSapQueueEntry ) {
         LexiconProductStageEntity productStage =lexiconProductStageDao.get(pqSapQueueEntry.getTableId());
         if (productStage != null) {
             LexiconProductEntity lexiconProduct = productStage.getLexiconProduct();
             if (hasPrimaryExceptionCode(lexiconProduct)) {
                 lexiconProducts.add(productStage.getLexiconProduct());
             }
         }
     }

     private void retrieveProductsToProcessForBaseProduct(List<LexiconProductEntity> lexiconProducts,PqSapQueueEntryEntity pqSapQueueEntry ) {
         BaseProductEntity baseProduct = baseProductDao.get(pqSapQueueEntry.getTableId());
         if (baseProduct != null) {
             for (ProductRelationshipEntity productRelationship : baseProduct.getProductRelationships()) {
                 for (ProductRelationshipXrefEntity relationshipXref : productRelationship.getProductRelationshipXRefs()) {
                     LexiconProductEntity lexiconProduct = relationshipXref.getLexiconProduct();
                     if (hasPrimaryExceptionCode(lexiconProduct)) {
                         lexiconProducts.add(relationshipXref.getLexiconProduct());
                     }
                 }
             }
         }
     }

     private boolean hasPrimaryExceptionCode(LexiconProductEntity lexiconProduct) {
         boolean hasPrimaryExceptionCode = false;
         if (lexiconProduct != null) {
             for (LexiconProductStageEntity lexiconProductStage : lexiconProduct.getLexiconProductStages()) {
                 ExceptionCodeEntity exceptionCode = lexiconProductStage.getExceptionCode();
                 if ((!lexiconProductStage.isLogicalDelete())&& (exceptionCode != null) && (exceptionCode.isPrimary())) {
                     hasPrimaryExceptionCode = true;
                     break;
                 }
             }
         }
         return hasPrimaryExceptionCode;
     }

    public void setBaseProductDao(BaseProductDao baseProductDao) {
        this.baseProductDao = baseProductDao;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }

    public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
        this.productRelationshipDao = productRelationshipDao;
    }
}
