/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.filter;

/**
 * nbwald - Mar 31, 2009 11:52:51 AM
 */
public class SpecificRoleContextFilter implements ContextFilter{

    private final String LEXICON_ROLE_CONTEXT_PATTERN_START = "lexicon\\.(";
    private final String LEXICON_ROLE_CONTEXT_PATTERN_END = ")";
    private final RegexpContextFilterHelper helper;

    public SpecificRoleContextFilter(String roleName)
    {
        helper = new RegexpContextFilterHelper(LEXICON_ROLE_CONTEXT_PATTERN_START + roleName + LEXICON_ROLE_CONTEXT_PATTERN_END);
    }

    @Override
    public boolean appliesTo(String context) {
       return helper.appliesTo(context);
    }

    @Override
    public String parse(String context) {
       return helper.parse(context);
    }
}