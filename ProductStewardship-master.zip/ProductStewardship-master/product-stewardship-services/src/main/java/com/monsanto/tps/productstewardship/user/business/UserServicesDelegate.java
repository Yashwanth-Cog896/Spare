/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.business;

import com.monsanto.tps.architecture.security.common.user.UserProfile;
import com.monsanto.tps.architecture.security.common.user.UserProfileDto;

import java.util.List;

/* vvkalu - 6/30/11 */
public interface UserServicesDelegate {

    UserProfile retrieveUserRoles(String userLoginId);

    List<UserProfileDto> retrieveUsersRoles(List<String> userLoginIds);
}