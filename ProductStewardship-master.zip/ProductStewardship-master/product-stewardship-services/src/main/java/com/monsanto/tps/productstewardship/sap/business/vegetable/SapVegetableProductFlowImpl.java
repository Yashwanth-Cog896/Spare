package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.SetMultimap;
import com.monsanto.sap.vegetable.webservice.country.YmmVegcntrynameDataUploadResponse;
import com.monsanto.sap.vegetable.webservice.exception.DTLexiconExceptionNamesRsp;
import com.monsanto.sap.vegetable.webservice.variety.DTLexiconVarietyRsp;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.PqSapQueueEntryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.StageCategoryEntity;
import com.monsanto.tps.productstewardship.supportcenter.TaskItemFactory;
import com.monsanto.tps.support.service.SupportCenterClient;
import com.monsanto.tps.support.service.TaskItem;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SapVegetableProductFlowImpl implements SapVegetableProductFlow {
    private static final org.apache.log4j.Logger log = Logger.getLogger(SapVegetableProductFlowImpl.class);
    private PqSapQueueEntryDao pqSapQueueEntryDao;
    private LexiconVarietyRequestFlow lexiconVarietyRequestFlow;
    private LexiconExceptionNameRequestFlow lexiconExceptionNameRequestFlow;
    private LexiconCountryRequestFlow lexiconCountryRequestFlow;
    private PqSapQueueEntriesGatherer pqSapQueueEntriesGatherer;
    private SapVegetableResponseHandler sapVegetableResponseHandler;
    private PqSapLogWriter pqSapLogWriter;
    private TaskItemFactory taskItemFactory;
    private SupportCenterClient supportCenterClient;
    public static final String LEXICON_VARIETY_REQUEST_FLOW = "lexiconVarietyRequestFlow";
    public static final String LEXICON_EXCEPTION_NAME_REQUEST_FLOW = "lexiconExceptionNameRequestFlow";
    public static final String LEXICON_COUNTRY_REQUEST_FLOW = "lexiconCountryRequestFlow";
    public static final String HANDLE_RESPONSES = "handleResponses";


    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public List<Long> retrievePqSapQueueEntryIdsToProcess() {
        List<Long> idsToProcess = pqSapQueueEntryDao.getPqSapQueueEntryIdsToProcessForSap(StageCategoryEntity.VEGETABLE);
        for (Long id : idsToProcess);//make sure list is completely fetched so transaction is not required to read list.
        return idsToProcess;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void flowNextChangesToSap(List<Long> pqSapProductIds) {
        SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapProducts = HashMultimap.create();
        Set<LexiconProductEntity> productsToProcess = new HashSet<LexiconProductEntity>();
        List<PqSapQueueEntryEntity> pqSapProductsToProcess = new ArrayList<PqSapQueueEntryEntity>();
        pqSapQueueEntriesGatherer.gatherProductsToProcessFromQueueEntry(pqSapProductIds, productPubkeyToPqSapProducts, productsToProcess, pqSapProductsToProcess);
        if (!productsToProcess.isEmpty()) {
            flowProducts(productPubkeyToPqSapProducts, productsToProcess, pqSapProductsToProcess);
        }
    }


    private void flowProducts(SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapProducts, Set<LexiconProductEntity> productsToProcess, List<PqSapQueueEntryEntity> pqSapQueueEntriesToProcess) {

        String itemId = null;
        List<TaskItem> taskItems = new ArrayList<TaskItem>(5);
        try{
            itemId= LEXICON_VARIETY_REQUEST_FLOW;
            DTLexiconVarietyRsp varietyResponse = lexiconVarietyRequestFlow.flowToSap(productsToProcess);
            taskItems.add(taskItemFactory.createTaskItem(TaskItemFactory.SAP_VEGETABLE_FLOW,itemId,true,null));
            itemId= LEXICON_EXCEPTION_NAME_REQUEST_FLOW;
            DTLexiconExceptionNamesRsp exceptionResponse = lexiconExceptionNameRequestFlow.flowToSap(productsToProcess);
            taskItems.add(taskItemFactory.createTaskItem(TaskItemFactory.SAP_VEGETABLE_FLOW,itemId,true,null));
            itemId= LEXICON_COUNTRY_REQUEST_FLOW;
            YmmVegcntrynameDataUploadResponse countryResponse = lexiconCountryRequestFlow.flowToSap(productsToProcess);
            taskItems.add(taskItemFactory.createTaskItem(TaskItemFactory.SAP_VEGETABLE_FLOW,itemId,true,null));
            itemId= HANDLE_RESPONSES;
            sapVegetableResponseHandler.handleResponses(productPubkeyToPqSapProducts, pqSapQueueEntriesToProcess, varietyResponse, exceptionResponse, countryResponse);
            taskItems.add(taskItemFactory.createTaskItem(TaskItemFactory.SAP_VEGETABLE_FLOW,itemId,true,null));
        }
        catch(Exception e){
            taskItems.add(taskItemFactory.createTaskItem(TaskItemFactory.SAP_VEGETABLE_FLOW,itemId,e));
            pqSapLogWriter.logException(pqSapQueueEntriesToProcess, e);
        }
        supportCenterClient.reportIssues(taskItems);
    }


    public void setLexiconExceptionNameRequestFlow(LexiconExceptionNameRequestFlow lexiconExceptionNameRequestFlow) {
        this.lexiconExceptionNameRequestFlow = lexiconExceptionNameRequestFlow;
    }

    public void setLexiconVarietyRequestFlow(LexiconVarietyRequestFlow lexiconVarietyRequestFlow) {
        this.lexiconVarietyRequestFlow = lexiconVarietyRequestFlow;
    }

    public void setPqSapQueueEntryDao(PqSapQueueEntryDao pqSapQueueEntryDao) {
        this.pqSapQueueEntryDao = pqSapQueueEntryDao;
    }

    public void setPqSapQueueEntriesGatherer(PqSapQueueEntriesGatherer pqSapQueueEntriesGatherer) {
        this.pqSapQueueEntriesGatherer = pqSapQueueEntriesGatherer;
    }

    public void setLexiconCountryRequestFlow(LexiconCountryRequestFlow lexiconCountryRequestFlow) {
        this.lexiconCountryRequestFlow = lexiconCountryRequestFlow;
    }

    public void setSapVegetableResponseHandler(SapVegetableResponseHandler sapVegetableResponseHandler) {
        this.sapVegetableResponseHandler = sapVegetableResponseHandler;
    }

    public void setPqSapLogWriter(PqSapLogWriter pqSapLogWriter) {
        this.pqSapLogWriter = pqSapLogWriter;
    }

    public void setSupportCenterClient(SupportCenterClient supportCenterClient) {
        this.supportCenterClient = supportCenterClient;
    }

    public void setTaskItemFactory(TaskItemFactory taskItemFactory) {
        this.taskItemFactory = taskItemFactory;
    }
}