package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductNameDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductNameEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 3:05:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductNameLogicalDeleteImpl implements ProductNameLogicalDelete {
    private LexiconProductNameDao lexiconProductNameDao;
    private FbsCommonProductNameLogicalDelete fbsCommonProductNameLogicalDelete;
    @Override
    public void logicallyDeleteProductNames(List<String> productNamePubkeys) {
        for(String productNamePubkey: productNamePubkeys){
            logicallyDeleteCompetitiveProduct(productNamePubkey);
        }
    }
    private void logicallyDeleteCompetitiveProduct(String productStagePubkey) {
        LexiconProductNameEntity productName = lexiconProductNameDao.getByPubkey(productStagePubkey);
        if (productName != null) {
            productName.setLogicalDelete(true);
            fbsCommonProductNameLogicalDelete.logicalDelete(productName.getFbsCommonProductNameXref());
            productName.setFbsCommonProductNameXref(null);
        }
    }

    public void setFbsCommonProductNameLogicalDelete(FbsCommonProductNameLogicalDelete fbsCommonProductNameLogicalDelete) {
        this.fbsCommonProductNameLogicalDelete = fbsCommonProductNameLogicalDelete;
    }

    public void setLexiconProductNameDao(LexiconProductNameDao lexiconProductNameDao) {
        this.lexiconProductNameDao = lexiconProductNameDao;
    }
}
