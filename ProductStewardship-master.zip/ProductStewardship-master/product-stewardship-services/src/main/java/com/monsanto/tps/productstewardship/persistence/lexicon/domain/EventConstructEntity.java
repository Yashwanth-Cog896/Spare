package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.lang.annotation.Target;

@Entity
@Table(name="EVENT_CONSTRUCT",schema = "MIDAS")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class EventConstructEntity implements Serializable {
    @GeneratedValue(generator = "midas_generator")
    @Id
    @Column(name="EVENT_CONSTRUCT_ID")
    private long id;
    @Column(name="NAME",length = 80,nullable = true)
    private String name;
    @Column(name="EVENT_NAME",length=50,nullable = true)
    private String eventName;
    @Column(name="CONSTRUCT_NAME",length=200, nullable = true)
    private String constructName;
    @Column(name="BARCODE",length=50,nullable = true)
    private String barcode;
    @Column(name="REF_ACTIVE")
    @Type(type="true_false")
    private boolean refActive;
    @ManyToOne
    @JoinColumn(name = "CROP_ID",nullable = false)
    private MidasCropEntity crop;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getConstructName() {
        return constructName;
    }

    public void setConstructName(String constructName) {
        this.constructName = constructName;
    }

    public MidasCropEntity getCrop() {
        return crop;
    }

    public void setCrop(MidasCropEntity crop) {
        this.crop = crop;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }
}
