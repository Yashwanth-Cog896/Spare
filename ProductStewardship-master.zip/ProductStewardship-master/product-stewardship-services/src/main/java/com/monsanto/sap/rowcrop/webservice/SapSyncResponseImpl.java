package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.xmlserialization.SerializationException;

public class SapSyncResponseImpl implements SapSyncResponse {
   private Long sapLinkageAuditId;
   private String updateResponse;
   private Integer errorCode;
   private String errorMessage;
   private String errorDetail;

   public SapSyncResponseImpl(
      Long sapLinkageAuditId,
      String updateResponse,
      Integer errorCode,
      String errorMessage,
      String errorDetail)
   {
      this.sapLinkageAuditId = sapLinkageAuditId;
      this.updateResponse = updateResponse;
      this.errorCode = errorCode;
      this.errorMessage = errorMessage;
      this.errorDetail = errorDetail;
   }

   public Long getSapLinkageAuditId() {
      return sapLinkageAuditId;
   }

   public String getUpdateResponse() {
      return updateResponse;
   }

   public Integer getErrorCode() {
      return errorCode;
   }

   public String getErrorMessage() {
      return errorMessage;
   }

   public String getErrorDetail() {
      return errorDetail;
   }

   public String asXmlString()
      throws SerializationException
   {
      SapSyncResponseSerializer serializer = new SapSyncResponseSerializer();
      return DOMUtil.getXMLString(serializer.toDocument(this));
   }
}
