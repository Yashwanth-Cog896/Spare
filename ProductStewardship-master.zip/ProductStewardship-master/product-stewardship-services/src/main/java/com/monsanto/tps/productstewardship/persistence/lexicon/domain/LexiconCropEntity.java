package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 10:05:45 AM
 * To change this template use File | Settings | File Templates.
 */
@Filterable
@Entity
@SequenceGenerator(name = "cropIdGenerator",allocationSize = 1,sequenceName = "Lexicon.CROP_ID_SEQ")
@Table(name = "CROP", schema = "Lexicon")
public class LexiconCropEntity  implements Serializable {
    @Id
    @Column(name="CROP_ID")
    @GeneratedValue(generator = "cropIdGenerator")
    private long id;

    @Column(name = "CROP_NAME", nullable = false,length = 50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name = "MAJOR_CROP", nullable = false)
    private boolean majorCrop;

    @FilterableProperty(filterKey="cropPubkey")
    @Column(name="CROP_PUBKEY",nullable = false,length=20)
    private String pubkey;

    @Type(type = "boolean-yn")
    @Column(name="REGULATORY_CROP",nullable = false)
    private boolean regulatory;

    @Column(name="COMPLIANCE_SHIPPING_STATEMENT",nullable = true, length=255)
    private String complianceShippingStatement;

    @Column(name="ABBREVIATION", nullable = true, length=2)
    private String abbreviation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="STAGE_CATEGORY_ID",nullable = false)
    private StageCategoryEntity stageCategory;

  //Family reference

    @Type(type = "boolean-yn")
    @Column(name="AUTO_GENERATE_TAG_NM_IND",nullable = true)
    private Boolean autoGenerateTagVarietyName=false;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public Boolean getAutoGenerateTagVarietyName() {
        return autoGenerateTagVarietyName;
    }

    public void setAutoGenerateTagVarietyName(Boolean autoGenerateTagVarietyName) {
        this.autoGenerateTagVarietyName = autoGenerateTagVarietyName;
    }

    public String getComplianceShippingStatement() {
        return complianceShippingStatement;
    }

    public void setComplianceShippingStatement(String complianceShippingStatement) {
        this.complianceShippingStatement = complianceShippingStatement;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isMajorCrop() {
        return majorCrop;
    }

    public void setMajorCrop(boolean majorCrop) {
        this.majorCrop = majorCrop;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public boolean isRegulatory() {
        return regulatory;
    }

    public void setRegulatory(boolean regulatory) {
        this.regulatory = regulatory;
    }

    public StageCategoryEntity getStageCategory() {
        return stageCategory;
    }

    public void setStageCategory(StageCategoryEntity stageCategory) {
        this.stageCategory = stageCategory;
    }
}
