package com.monsanto.osb.webservice.credentials;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlValue;

public class Password {

    private String value;

    private String type;

    @XmlAttribute(name="Type") 
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    @XmlValue
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
