package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.KeywordDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageAuditDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageSeedProductDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import org.apache.commons.lang.StringUtils;

import java.util.Date;
import java.util.List;
import java.util.Set;

public class MirageSeedProductWriter {

    private FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao;
    private MirageAuditDao mirageAuditDao;
    private MidasCropDao midasCropDao;
    private MirageSeedProductDao mirageSeedProductDao;
    private CommercialTraitStackDao commercialTraitStackDao;   
    private KeywordDao keywordDao;
    
    public MirageSeedProductEntity writeMirageSeedProduct( LexiconProductEntity lexiconProduct, ProductStage productStage,  LexiconProductStageEntity lexiconProductStage) {
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = lexiconProductStage.getFbsCommonProductNameXref();
        if(fbsCommonProductNameXref ==null){
            fbsCommonProductNameXref= new FbsCommonProductNameXrefEntity();
            fbsCommonProductNameXref.setLexiconPubkey(lexiconProductStage.getPubkey());
            fbsCommonProductNameXrefDao.saveOrUpdate(fbsCommonProductNameXref);
            lexiconProductStage.setFbsCommonProductNameXref(fbsCommonProductNameXref);
        }
        boolean writeMirageSeedProduct = false;
        MirageSeedProductEntity mirageSeedProduct = fbsCommonProductNameXref.getMirageSeedProduct();
        if(mirageSeedProduct ==null){
            mirageSeedProduct = new MirageSeedProductEntity();
            mirageSeedProduct.setEnabled(true);
            mirageSeedProduct.setAudit(mirageAuditDao.createAudit(MirageAuditDao.INSERT_SP_EVENT));
            writeMirageSeedProduct=true;
            fbsCommonProductNameXref.setMirageSeedProduct(mirageSeedProduct);
        }
        else {
            mirageSeedProduct.setAudit(mirageAuditDao.createAudit(MirageAuditDao.UPDATE_SP_EVENT));
        }
        LexiconBrandEntity lexiconBrand = lexiconProductStage.getLexiconBrand();
        mirageSeedProduct.setMirageCompany(lexiconBrand.getFbsCommonBrandXrefs().iterator().next().getMirageCompany());
        mirageSeedProduct.setName(StringUtils.isBlank(lexiconProductStage.getCommercialName())?lexiconProduct.getPreCommercialName():lexiconProductStage.getCommercialName());
        mirageSeedProduct.setEnabled(!lexiconBrand.isTechDevRestricted());
        MapCropMirageEntity mapCropMirage = midasCropDao.findMapCropMirage(lexiconProduct.getLexiconCrop().getName());
        mirageSeedProduct.setBayerCode(fetchBayerCode(mapCropMirage));
        mirageSeedProduct.setCountryCode(fetchCountryCode(lexiconProductStage));
        if((lexiconBrand.isTechDevRestricted())&&(mirageSeedProduct.getDisabledDate()==null)){
             mirageSeedProduct.setDisabledDate(new Date());
        }
        mirageSeedProduct.setTraitCharacteristicCode(fetchTraitCharacteristicCode(lexiconProduct, productStage));
        if(writeMirageSeedProduct){
           mirageSeedProductDao.saveOrUpdate(mirageSeedProduct);
        }
        return mirageSeedProduct;
    }
    private Long fetchTraitCharacteristicCode(LexiconProductEntity product, ProductStage productStage) {
        Long traitCharacteristicCode = null;
        String comlTraitName = productStage.getComlTraitName();
        if(StringUtils.isNotBlank(comlTraitName)){
            List<CommercialTraitStackEntity> stacks = commercialTraitStackDao.getByTraitNameAndCrop(comlTraitName,product.getLexiconCrop().getName());
            if(!stacks.isEmpty()){
                String tdName = stacks.get(0).getTechDevName();
                if(StringUtils.isBlank(tdName)){
                    tdName= KeywordDao.NON_TRANS_STRING;
                }
                traitCharacteristicCode = keywordDao.findEnabledByTypeAndName(KeywordDao.TRAIT_CHARACTERISTIC, tdName).get(0).getCode();
            }
        }
        return traitCharacteristicCode;
    }

    private String fetchCountryCode(LexiconProductStageEntity lexiconProductStage) {
        String countryCode = null;
        Set<FbsCommonCountryXrefEntity> countryXrefs = lexiconProductStage.getLexiconCountry().getFbsCommonCountryXrefs();
        if(!countryXrefs.isEmpty()){
           for(FbsCommonCountryXrefEntity countryXref : countryXrefs){
               if(countryXref.getMirageCountry()!=null){
                   countryCode=countryXref.getMirageCountry().getCode();
                   break;
               }
           }
        }
        return countryCode;
    }

    private String fetchBayerCode(MapCropMirageEntity mapCropMirage) {
        String bayerCode = null;
        if(mapCropMirage!=null){
            bayerCode = mapCropMirage.getMirageBayerCode();
        }
        return bayerCode;
    }
    

    public void setCommercialTraitStackDao(CommercialTraitStackDao commercialTraitStackDao) {
        this.commercialTraitStackDao = commercialTraitStackDao;
    }

    public void setFbsCommonProductNameXrefDao(FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao) {
        this.fbsCommonProductNameXrefDao = fbsCommonProductNameXrefDao;
    }

    public void setKeywordDao(KeywordDao keywordDao) {
        this.keywordDao = keywordDao;
    }


    public void setMidasCropDao(MidasCropDao midasCropDao) {
        this.midasCropDao = midasCropDao;
    }

    public void setMirageAuditDao(MirageAuditDao mirageAuditDao) {
        this.mirageAuditDao = mirageAuditDao;
    }

    public void setMirageSeedProductDao(MirageSeedProductDao mirageSeedProductDao) {
        this.mirageSeedProductDao = mirageSeedProductDao;
    }
}
