package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.existingproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductGermplasmEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class MidasProductHasGermplasmRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductDao lexiconProductDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity lexiconProduct=lexiconProductDao.getByPubkey(productPubkey);
            if((lexiconProduct!=null)&&
               (lexiconProduct.getFbsCommonProductXref()!=null)){
                boolean valid = false;
                for(ProductGermplasmEntity productGermplasm:lexiconProduct.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()){
                    if(!productGermplasm.getGermplasm().isDeleted()){
                        valid=true;
                    }
                }
                if(!valid){
                        status.addCondition(new ValidationResult(ProductEditService.NO_PRODUCT_GERMPLASM_CODE, ValidationSeverity.ERROR));
                }

            }
        }
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
