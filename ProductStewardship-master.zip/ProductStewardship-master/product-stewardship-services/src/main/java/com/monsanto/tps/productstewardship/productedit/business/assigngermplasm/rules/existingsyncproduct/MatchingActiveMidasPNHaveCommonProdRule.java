package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.existingsyncproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasProductNameDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MatchingActiveMidasPNHaveCommonProdRule implements ValidationSimpleRule<Product> {
    MidasProductNameDao midasProductNameDao;
    public static final String MONSANTO = "MONSANTO";

    @Override
    public void validate(Product model, ValidationStatus status) {
        if(StringUtils.isNotBlank(model.getPreCommercialName())){
            List<MidasProductNameEntity> productNames = midasProductNameDao.getActiveByBrandAndName(MONSANTO, model.getPreCommercialName());
            if(!productNames.isEmpty()){
                MidasProductEntity commonProduct = getCommonProduct(productNames);
                if(commonProduct==null){
                    status.addCondition(new ValidationResult(ProductEditService.MATCH_MIDAS_PN_MULT_PRODID_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    public MidasProductEntity getCommonProduct(List<MidasProductNameEntity> midasProductNames){
        MidasProductEntity product = null;
        Set<Long> productIds = new HashSet<Long>();
        for(MidasProductNameEntity midasProductName: midasProductNames){
            productIds.add(midasProductName.getMidasProduct().getId());
        }
        if(productIds.size()==1){
            product = midasProductNames.get(0).getMidasProduct();
        }
        return product;
    }
    public void setMidasProductNameDao(MidasProductNameDao midasProductNameDao) {
        this.midasProductNameDao = midasProductNameDao;
    }
}
