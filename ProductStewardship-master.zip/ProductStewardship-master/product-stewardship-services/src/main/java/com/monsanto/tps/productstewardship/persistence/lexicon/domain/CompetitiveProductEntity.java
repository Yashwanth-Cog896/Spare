package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 18, 2011
 * Time: 11:03:28 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "lexiconCompetitiveProductIdGenerator",allocationSize = 1,sequenceName = "Lexicon.UNIQUE_PRODUCT_ID_SEQ")
@Table(name = "PRODUCT", schema = "Lexicon")
public class CompetitiveProductEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "lexiconCompetitiveProductIdGenerator")
    @Column(name="PRODUCT_ID")
    private long id;

    @Column(name="PRODUCT_PUBKEY",length=20,nullable=false)
    private String pubkey;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;

    @OneToMany(mappedBy = "competitiveProduct",cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    private List<LexiconProductNameEntity> lexiconProductNames= new ArrayList<LexiconProductNameEntity>();


    @OneToMany(cascade = CascadeType.ALL,orphanRemoval = true,fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_PUBKEY",referencedColumnName="PRODUCT_PUBKEY", updatable = false)
    private List<FbsCommonProductXrefEntity> fbsCommonProductXrefs = new ArrayList<FbsCommonProductXrefEntity>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public List<LexiconProductNameEntity> getLexiconProductNames() {
        return lexiconProductNames;
    }

    public void setLexiconProductNames(List<LexiconProductNameEntity> lexiconProductNames) {
        this.lexiconProductNames = lexiconProductNames;
    }
    @Transient
    public FbsCommonProductXrefEntity getFbsCommonProductXref() {
        if(fbsCommonProductXrefs.size()>0){
            return fbsCommonProductXrefs.get(0);
        }
        else {
            return null;
        }
    }

    public void setFbsCommonProductXref(FbsCommonProductXrefEntity fbsCommonProductXref) {
        fbsCommonProductXrefs.clear();
        if(fbsCommonProductXref!=null){
            fbsCommonProductXrefs.add(fbsCommonProductXref);
        }
    }

    List<FbsCommonProductXrefEntity> getFbsCommonProductXrefs() {
        return fbsCommonProductXrefs;
    }

    void setFbsCommonProductXrefs(List<FbsCommonProductXrefEntity> fbsCommonProductXrefs) {
        this.fbsCommonProductXrefs = fbsCommonProductXrefs;
    }    
}
