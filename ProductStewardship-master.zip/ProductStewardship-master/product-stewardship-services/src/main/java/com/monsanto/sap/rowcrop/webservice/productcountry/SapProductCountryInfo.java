package com.monsanto.sap.rowcrop.webservice.productcountry;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Jul 5, 2007
 * Time: 1:53:38 PM
 */
public class SapProductCountryInfo
{
   // Long discussion, publics are bad everything else is worse.  Discussion continues...
   public final String productCountryPubkey;
   public final String productPubkey;
   public final String countryCode;
   public final String brandPubkey;
   public final String commercialName;
   public final String lifecycleAbbreviation;
   public final String traitStackPubkey;
   public final Double commercialMaturity;
   public final boolean isActive;
   public final boolean logicalDelete;
   public final long sapLinkageAuditId;

   public SapProductCountryInfo(LexiconProductStageEntity productStage, long sapLinkageAuditId) {
      this.productCountryPubkey = productStage.getLexiconCountry().getPubkey();
      this.productPubkey = productStage.getPubkey();
      this.countryCode = productStage.getLexiconCountry().getIsoCode();
      this.brandPubkey = productStage.getLexiconBrand().getPubkey();
      this.commercialName = productStage.getCommercialName();
      this.lifecycleAbbreviation = productStage.getLexiconStage().getAbbreviation();
      this.traitStackPubkey = productStage.getCommercialTraitStack()==null?null:productStage.getCommercialTraitStack().getPubkey();
      this.commercialMaturity = productStage.getCommercialMaturity();
      this.isActive = productStage.isActive();
      this.logicalDelete = productStage.isLogicalDelete();
      this.sapLinkageAuditId = sapLinkageAuditId;
   }
}