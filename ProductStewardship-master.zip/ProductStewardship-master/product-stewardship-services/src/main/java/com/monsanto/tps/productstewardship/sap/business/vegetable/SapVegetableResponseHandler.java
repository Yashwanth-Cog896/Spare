package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.SetMultimap;
import com.monsanto.sap.vegetable.webservice.country.TableOfYmmvegcntryStr;
import com.monsanto.sap.vegetable.webservice.country.YmmVegcntrynameDataUploadResponse;
import com.monsanto.sap.vegetable.webservice.country.YmmvegcntryStr;
import com.monsanto.sap.vegetable.webservice.exception.DTLexiconExceptionNamesRsp;
import com.monsanto.sap.vegetable.webservice.variety.DTLexiconVarietyRsp;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.PqSapQueueEntryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapLogEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapProductLogStatus;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import com.monsanto.tps.productstewardship.supportcenter.TaskItemFactory;
import com.monsanto.tps.support.service.SupportCenterClient;
import com.monsanto.tps.support.service.TaskItem;

import javax.xml.bind.JAXB;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SapVegetableResponseHandler {
    private PqSapQueueEntryDao pqSapQueueEntryDao;
    private PqSapLogWriter pqSapLogWriter;
    private TaskItemFactory taskItemFactory;
    private SupportCenterClient supportCenterClient;

    public void handleResponses(SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapProducts, List<PqSapQueueEntryEntity> pqSapQueueEntriesToProceses, DTLexiconVarietyRsp varietyResponse, DTLexiconExceptionNamesRsp exceptionResponse, YmmVegcntrynameDataUploadResponse countryResponse) {
        List<PqSapLogEntity> pqSapLogs = new ArrayList<PqSapLogEntity>();
        SetMultimap<PqSapQueueEntryEntity, DTLexiconExceptionNamesRsp.VarietyResponse.ErrorDetails> pqSapProductToExceptionErrorDetails = HashMultimap.create();
        SetMultimap<PqSapQueueEntryEntity, DTLexiconVarietyRsp.VarietyResponse.ErrorDetails> pqSapProductToVarietyErrorDetails = HashMultimap.create();
        SetMultimap<PqSapQueueEntryEntity, YmmvegcntryStr> pqSapProductToCountryErrorDetails = HashMultimap.create();
        populateErrorDetails(productPubkeyToPqSapProducts,pqSapProductToCountryErrorDetails,countryResponse);
        populateErrorDetails(productPubkeyToPqSapProducts, pqSapProductToExceptionErrorDetails, exceptionResponse);
        buildVarietyErrorDetails(productPubkeyToPqSapProducts, pqSapProductToVarietyErrorDetails, varietyResponse);
        for (PqSapQueueEntryEntity pqSapQueueEntry : pqSapQueueEntriesToProceses) {
            Set<DTLexiconExceptionNamesRsp.VarietyResponse.ErrorDetails> exceptionErrorDetails = pqSapProductToExceptionErrorDetails.get(pqSapQueueEntry);
            Set<DTLexiconVarietyRsp.VarietyResponse.ErrorDetails> varietyErrorDetails = pqSapProductToVarietyErrorDetails.get(pqSapQueueEntry);
            Set<YmmvegcntryStr> countryErrorDetails = pqSapProductToCountryErrorDetails.get(pqSapQueueEntry);
            if ((varietyErrorDetails == null || varietyErrorDetails.isEmpty()) && (exceptionErrorDetails == null || exceptionErrorDetails.isEmpty()) &&
                (countryResponse==null||countryResponse.getError()==null||countryResponse.getError().getItem()==null||countryResponse.getError().getItem().isEmpty())) {
                pqSapLogs.add(pqSapLogWriter.buildAndPersistLogEntry(pqSapQueueEntry, PqSapProductLogStatus.S, null));
                pqSapQueueEntryDao.delete(pqSapQueueEntry);
            } else {
                pqSapLogs.add(buildAndPersistErrorLogEntry(pqSapQueueEntry, exceptionErrorDetails, varietyErrorDetails,countryErrorDetails));
            }
        }
        supportCenterLog(pqSapLogs);
    }

    private void supportCenterLog(List<PqSapLogEntity> pqSapLogs){
        List<TaskItem> taskItems = new ArrayList<TaskItem>(pqSapLogs.size());
        for(PqSapLogEntity pqSapLog:pqSapLogs){
            taskItems.add(taskItemFactory.createTaskItem(TaskItemFactory.SAP_VEGETABLE_FLOW,pqSapLog.getTableName()+":"+pqSapLog.getTableId(),pqSapLog.getStatus()==PqSapProductLogStatus.S,pqSapLog.getMessage()));
        }
        supportCenterClient.reportIssues(taskItems);
    }
    private void buildVarietyErrorDetails(SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapProducts, SetMultimap<PqSapQueueEntryEntity, DTLexiconVarietyRsp.VarietyResponse.ErrorDetails> pqSapProductToVarietyErrorDetails, DTLexiconVarietyRsp varietyResponse) {
        if(varietyResponse!=null){
        List<DTLexiconVarietyRsp.VarietyResponse.ErrorDetails> varietyErrorDetails = varietyResponse.getVarietyResponse().getErrorDetails();
        for (DTLexiconVarietyRsp.VarietyResponse.ErrorDetails errorDetail : varietyErrorDetails) {
            Set<PqSapQueueEntryEntity> effectedQueueEntries = productPubkeyToPqSapProducts.get(errorDetail.getPubkey());
            if (effectedQueueEntries != null) {
                for (PqSapQueueEntryEntity effectedQueueEntry : effectedQueueEntries) {
                    pqSapProductToVarietyErrorDetails.put(effectedQueueEntry, errorDetail);
                }
            }
        }
        }
        return;
    }

    private void populateErrorDetails(SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapProducts, SetMultimap<PqSapQueueEntryEntity, YmmvegcntryStr> pqSapProductToCountryErrorDetails , YmmVegcntrynameDataUploadResponse countryResponse) {

        if((countryResponse!=null)&&(countryResponse.getError()!=null)&&(countryResponse.getError().getItem()!=null)){
        TableOfYmmvegcntryStr error = countryResponse.getError();
            List<YmmvegcntryStr> errorDetails = error.getItem();
            for (YmmvegcntryStr errorDetail : errorDetails) {
                Set<PqSapQueueEntryEntity> effectedQueueEntries = productPubkeyToPqSapProducts.get(errorDetail.getYyproductKey());
                if (effectedQueueEntries != null) {
                    for (PqSapQueueEntryEntity effectedQueueEntry : effectedQueueEntries) {
                        pqSapProductToCountryErrorDetails.put(effectedQueueEntry, errorDetail);
                    }
                }
            }
        }
        return ;
    }
    private void populateErrorDetails(SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapProducts, SetMultimap<PqSapQueueEntryEntity, DTLexiconExceptionNamesRsp.VarietyResponse.ErrorDetails> pqSapProductToErrorDetails, DTLexiconExceptionNamesRsp exceptionResponse) {
        if(exceptionResponse!=null){
        List<DTLexiconExceptionNamesRsp.VarietyResponse.ErrorDetails> errorDetails = exceptionResponse.getVarietyResponse().getErrorDetails();
        for (DTLexiconExceptionNamesRsp.VarietyResponse.ErrorDetails errorDetail : errorDetails) {
            Set<PqSapQueueEntryEntity> effectedQueueEntries = productPubkeyToPqSapProducts.get(errorDetail.getPubkey());
            if (effectedQueueEntries != null) {
                for (PqSapQueueEntryEntity effectedQueueEntry : effectedQueueEntries) {
                    pqSapProductToErrorDetails.put(effectedQueueEntry, errorDetail);
                }
            }
        }
        }
        return;
    }

    private PqSapLogEntity buildAndPersistErrorLogEntry(PqSapQueueEntryEntity pqSapQueueEntry, Set<DTLexiconExceptionNamesRsp.VarietyResponse.ErrorDetails> exceptionErrorDetails,
                                              Set<DTLexiconVarietyRsp.VarietyResponse.ErrorDetails> varietyErrorDetails, Set<YmmvegcntryStr> countryErrorDetails) {
        StringBuilder messageBuilder = new StringBuilder();
        appendErrors(messageBuilder, exceptionErrorDetails);
        appendErrors(messageBuilder, varietyErrorDetails);
        appendErrors(messageBuilder,countryErrorDetails);
        return pqSapLogWriter.buildAndPersistLogEntry(pqSapQueueEntry, PqSapProductLogStatus.E, messageBuilder.toString());
    }

    private <T> void appendErrors(StringBuilder messageBuilder, Set<T> varietyErrorDetails) {
        if (varietyErrorDetails != null) {
            for (Object detail : varietyErrorDetails) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                JAXB.marshal(detail, byteArrayOutputStream);
                messageBuilder.append(byteArrayOutputStream.toString());
            }
        }
    }


    public void setPqSapQueueEntryDao(PqSapQueueEntryDao pqSapQueueEntryDao) {
        this.pqSapQueueEntryDao = pqSapQueueEntryDao;
    }

    public void setPqSapLogWriter(PqSapLogWriter pqSapLogWriter) {
        this.pqSapLogWriter = pqSapLogWriter;
    }

    public void setSupportCenterClient(SupportCenterClient supportCenterClient) {
        this.supportCenterClient = supportCenterClient;
    }

    public void setTaskItemFactory(TaskItemFactory taskItemFactory) {
        this.taskItemFactory = taskItemFactory;
    }
}
