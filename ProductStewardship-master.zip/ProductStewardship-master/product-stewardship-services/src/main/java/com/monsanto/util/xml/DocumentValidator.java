package com.monsanto.util.xml;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.XMLUtil.ValidationException;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.*;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 6, 2007
 * Time: 3:26:18 PM
 */
public class DocumentValidator
{
   public static boolean isDocumentValid(Document doc, String schemaLoc)
      throws IOException, ParserException, TransformerException
   {
      return getValidationErrors(doc, schemaLoc) == null;
   }

   public static List getValidationErrors(Document doc, String schemaLoc)
      throws IOException, TransformerException, ParserException
   {
      final InputStream inputStream = DOMUtil.makeInputStreamFromDocument(doc);
      try {
         DOMUtil.newDocument(inputStream, schemaLoc);
         return null;
      }
      catch (ValidationException e) {
         return e.getValidationErrors();
      }
   }

   public static String getValidationErrorMessage(Document document, String schemaLoc)
      throws ParserException, TransformerException, IOException
   {
      List validationErrors = getValidationErrors(document, schemaLoc);
      return validationErrors == null ? null : buildErrorMessage(document, validationErrors);
   }

   private static String buildErrorMessage(Document document, List validationErrors) {
      StringBuilder errorMessage = new StringBuilder();
      String docText = getDocumentAsString(document);
      errorMessage.append("\nDocument is:\n").append(docText).append("\n");
      errorMessage.append("Errors are:\n");
      for (Object validationError : validationErrors) {
         errorMessage.append(validationError.toString()).append("\n");
      }
      return errorMessage.toString();
   }

   private static String getDocumentAsString(Document document) {
      // Output is a little nicer (newlined, tabbed) than DOMUtil.getXMLString()
      StringWriter stringWriter = new StringWriter();
      DOMUtil.outputXML(document, stringWriter);
      return stringWriter.toString();
   }
}
