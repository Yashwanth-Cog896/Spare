package com.monsanto.tps.productstewardship.email;

import javax.mail.Message;
import javax.mail.MessagingException;

/**
 * User: pjberry
 * Date: Sep 27, 2007
 * Time: 3:54:19 PM
 */
public interface SimpleTransport
{
   public void send(Message message)
      throws MessagingException;
}
