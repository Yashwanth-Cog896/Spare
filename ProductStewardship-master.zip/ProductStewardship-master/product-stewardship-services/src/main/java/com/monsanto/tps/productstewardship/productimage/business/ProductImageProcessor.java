package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.dcm.service.DocumentContentManagementService;
import com.monsanto.tcc.dcm.transfer.DocumentContent;
import com.monsanto.tcc.dcm.transfer.Reference;
import com.monsanto.tps.productstewardship.validation.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductPictureDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;
import com.monsanto.tps.productstewardship.productimage.service.*;
import com.monsanto.tps.productstewardship.transfer.ValidationProperty;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import org.apache.log4j.Logger;

import javax.activation.DataHandler;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.mail.util.ByteArrayDataSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


/**
 * vvkalu - Mar 12, 2010 10:23:25 AM
 */
public class ProductImageProcessor {

    private final org.apache.log4j.Logger log = Logger.getLogger(this.getClass());
    private LexiconProductDao lexiconProductDao;
    private LexiconProductPictureDao productPictureDao;
    private ValidationInvoker<ImageValidationModel> validationInvoker;
    private ImageValidationModelHelper imageValidationModelHelper;
    private DocumentContentManagementService documentContentManagementService;
    public static final String PICTURES_FOLDER = "/COVAR/";

    public List<ImageResponse> getProductImagesByProdPubKey(String productPubKey) throws IOException {
        List<ImageResponse> responses = new ArrayList<ImageResponse>();
        LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(productPubKey);
        return  buildImageResponse(lexiconProduct.getLexiconProductPictures());
    }

    private List<ImageResponse> buildImageResponse(List<LexiconProductPictureEntity> productPictures) throws IOException {
        List<ImageResponse> imageResponseList = new ArrayList<ImageResponse>();
        for (LexiconProductPictureEntity picture : productPictures) {
            ImageResponse imageResponse = new ImageResponse();

            byte[] imageData = getImageData(picture.getDocumentId());

            imageResponse.setImageData(new DataHandler(new ByteArrayDataSource(imageData, "image/jpeg")));
            imageResponse.setImageId(picture.getId());
            imageResponse.setImageTitle(picture.getDisplayName());
            imageResponse.setImageDimensions(getImageDimensions(imageData));
            imageResponseList.add(imageResponse);
        }
        return imageResponseList;
    }

    private byte[] getImageData(String documentId) throws IOException {
        Reference reference = new Reference();
        reference.setDocumentId(documentId);
        DocumentContent documentContent = documentContentManagementService.retrieveContent(reference);
        InputStream imageInputStream = documentContent.getContents().getDataSource().getInputStream();
        List<byte[]> allBytes = new ArrayList<byte[]>();
        int bytesRead = 0;
        int totalBytesRead = 0;
        while (bytesRead != -1) {
            byte[] bytes = new byte[100];
            bytesRead = imageInputStream.read(bytes, 0, 100);
            if (bytesRead > 0) {
                totalBytesRead += bytesRead;
                if (bytesRead == 100) {
                    allBytes.add(bytes);
                } else {
                    allBytes.add(Arrays.copyOf(bytes, bytesRead));
                }
            }
        }
        byte[] imageData = new byte[totalBytesRead];
        int partPosition = 0;
        for (byte[] imagePart : allBytes) {
            System.arraycopy(imagePart, 0, imageData, partPosition * 100, imagePart.length);
            partPosition++;
        }
        return imageData;
    }

    private ImageDimensions getImageDimensions(byte[] image) throws IOException {
        ImageDimensions dimensions = new ImageDimensions();
        ImageInputStream iis = null;
        ImageReader reader = null;
        InputStream inputStream = new ByteArrayInputStream(image);
        try {
            iis = ImageIO.createImageInputStream(inputStream);
            Iterator readers = ImageIO.getImageReaders(iis);
            reader = (ImageReader) readers.next();
            reader.setInput(iis);
            dimensions.setImageHeight(reader.getHeight(0));
            dimensions.setImageWidth(reader.getWidth(0));
        } finally {
            close(iis);
            if (reader != null) {
                reader.dispose();
            }
        }
        return dimensions;
    }

    private void close(ImageInputStream iis)
            throws IOException {
        if (iis != null) {
            iis.close();
        }
    }

    public ImageUploadResponse process(ImageUploadRequest imageRequest) {
        try {
            long imageId = 0;
            ValidationStatus status = validateRequest(imageRequest);
            if (!status.hasSeverity(ValidationSeverity.ERROR)) {
                imageId = write(imageRequest);
            }
            return createResponse(status, imageId);
        }
        catch (Exception e) {
            log.error(e.getMessage(), e);
            return createErrorResponse(e);
        }
    }

    private ValidationStatus validateRequest(ImageUploadRequest imageRequest) throws WrappingException, IOException {
        ImageValidationModel model = imageValidationModelHelper.getValidationModel(imageRequest);
        return validationInvoker.executeValidations(model);
    }

    private long write(ImageUploadRequest imageRequest) throws IOException, WrappingException {
        persistImage(imageRequest);
        return imageIdLookup(imageRequest);
    }

    private long imageIdLookup(ImageUploadRequest imageRequest) throws WrappingException {
        LexiconProductPictureEntity picture = productPictureDao.getByDisplayname(imageRequest.getImageTitle());
        return picture.getId();
    }

    private void persistImage(ImageUploadRequest imageRequest) throws WrappingException {
        Reference reference = documentContentManagementService.create(PICTURES_FOLDER + imageRequest.getImageTitle(), false,
                imageRequest.getImageData(), null);
        LexiconProductEntity preComlProduct = lexiconProductDao.getByPubkey(imageRequest.getProductPubKey());
        LexiconProductPictureEntity preComlProductPicture = new LexiconProductPictureEntity();
        preComlProductPicture.setDisplayName(imageRequest.getImageTitle());
        preComlProductPicture.setDocumentId(reference.getDocumentId());
        preComlProduct.getLexiconProductPictures().add(preComlProductPicture);
        lexiconProductDao.saveOrUpdate(preComlProduct);
    }

    private ImageUploadResponse createResponse(ValidationStatus status, long imageId) {
        ImageUploadResponse response = new ImageUploadResponse();
        response.setSuccessful(!status.hasSeverity(ValidationSeverity.ERROR));
        List<ValidationResult> validationResults = new ArrayList<ValidationResult>();
        validationResults.addAll(status.getResults(ValidationSeverity.ERROR));
        validationResults.addAll(status.getResults(ValidationSeverity.INFO));
        response.setValidationResults(validationResults);
        response.setImageId(imageId);
        return response;
    }



    private ImageUploadResponse createErrorResponse(Exception e) {
        ValidationStatus status = new ValidationStatus();
        status.addCondition(new ValidationResult(ProductImagesService.UNEXPECTED_ERROR,new ValidationProperty("message",e.getMessage())));
        return createResponse(status, 0);
    }

    public void deletePictureByPictureId(long imageId) {
        if (imageId != 0) {
            LexiconProductPictureEntity picture = productPictureDao.get(imageId);
            if (picture.getDocumentId() != null) {
                documentContentManagementService.deleteAll(picture.getDocumentId());
            }
            
            productPictureDao.delete(imageId);
        }
    }

    public DocumentContentManagementService getDocumentContentManagementService() {
        return documentContentManagementService;
    }

    public void setDocumentContentManagementService(DocumentContentManagementService documentContentManagementService) {
        this.documentContentManagementService = documentContentManagementService;
    }

    public ImageValidationModelHelper getImageValidationModelHelper() {
        return imageValidationModelHelper;
    }

    public void setImageValidationModelHelper(ImageValidationModelHelper imageValidationModelHelper) {
        this.imageValidationModelHelper = imageValidationModelHelper;
    }

    public LexiconProductDao getLexiconProductDao() {
        return lexiconProductDao;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public LexiconProductPictureDao getProductPictureDao() {
        return productPictureDao;
    }

    public void setProductPictureDao(LexiconProductPictureDao productPictureDao) {
        this.productPictureDao = productPictureDao;
    }

    public ValidationInvoker<ImageValidationModel> getValidationInvoker() {
        return validationInvoker;
    }

    public void setValidationInvoker(ValidationInvoker<ImageValidationModel> validationInvoker) {
        this.validationInvoker = validationInvoker;
    }
}
