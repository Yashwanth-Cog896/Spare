package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.matchingstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ProductNameXrefNotExistRule  implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductStageDao lexiconProductStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
       if((!model.getProductStage().isDelete())&&StringUtils.isNotBlank(model.getProductStage().getProductStagePubkey())){
           LexiconProductStageEntity lexiconProductStage = lexiconProductStageDao.getByPubkey(model.getProductStage().getProductStagePubkey());
           if((lexiconProductStage!=null)&&(!lexiconProductStage.isLogicalDelete())&&(lexiconProductStage.getFbsCommonProductNameXref()==null)){
               status.addCondition(new ValidationResult(ProductEditService.NAME_XREF_EXISTS_CODE, ValidationSeverity.ERROR));
           }
       }
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }
}
