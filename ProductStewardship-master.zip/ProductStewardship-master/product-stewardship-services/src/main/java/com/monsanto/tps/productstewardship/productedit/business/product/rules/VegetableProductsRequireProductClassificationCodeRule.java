package com.monsanto.tps.productstewardship.productedit.business.product.rules;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.StageCategoryEntity;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class VegetableProductsRequireProductClassificationCodeRule implements ValidationSimpleRule<ProductValidationModel> {
    private LexiconCropDao lexiconCropDao;

    @Override
    public void validate(ProductValidationModel model, ValidationStatus status) {
        LexiconCropEntity crop = lexiconCropDao.getByName(model.getProduct().getLexiconCropName());
     
        if( crop.getStageCategory().getName().equals(StageCategoryEntity.VEGETABLE)&&StringUtils.isBlank(model.getProduct().getProductClassificationCode())){
            status.addCondition(new ValidationResult(ProductEditService.VEGE_PROD_MISSING_PROD_CLASSIFICATION_CODE, ValidationSeverity.ERROR));
        }
    }

    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }
}
