package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;

public interface LexiconBrandDao extends GenericDao<LexiconBrandEntity,Long> {
    @DynamicDaoMethod(queryName = "LexiconBrandDao.getByName",parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
     public LexiconBrandEntity getByName(@DynamicDaoParameter(name = "brandName")String brandName);
}
