package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapProductMirageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

public interface MapProductMirageDao extends GenericDao<MapProductMirageEntity, Long> {


}
