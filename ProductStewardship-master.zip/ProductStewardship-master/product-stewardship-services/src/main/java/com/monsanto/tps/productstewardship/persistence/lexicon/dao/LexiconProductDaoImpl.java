package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import com.monsanto.tps.productstewardship.productsearch.service.TooManyResultsException;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.*;

import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 21, 2011
 * Time: 9:07:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductDaoImpl extends GenericDaoImpl<LexiconProductEntity, Long>  implements LexiconProductDao {

    ProductSearchCriteriaBuilder  productSearchCriteriaBuilder;
    public static final String LOGICAL_DELETE = "logicalDelete";
    public static final String LEXICON_PRODUCT = "lexiconProduct";
    public static final String ID = "id";
    public static final String SEPARATOR = ".";

    public LexiconProductDaoImpl() {
        super(LexiconProductEntity.class);
    }

    /* I know comments are bad. But I had to note that the DyanmicDao uses AOP.  SO the following code actually works */
    @Override
    public LexiconProductEntity getByPubkey(@DynamicDaoParameter(name = "pubkey") String pubkey) {
        return null;  
    }

    @Override
    public List<LexiconProductEntity> getByIds(@DynamicDaoParameter(name = "requestId") Long requestId) {
        return null;
    }

    @Override
    public LexiconProductEntity getByPreCommercialName(@DynamicDaoParameter(name = "preCommercialName") String preCommercialName) {
        return null;  
    }

    @Override
    public List<LexiconProductEntity> getByCropAndVarietyName(@DynamicDaoParameter(name = "lexiconCropName") String lexiconCropName, @DynamicDaoParameter(name = "varietyName") String varietyName) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<LexiconProductEntity> findBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria) {

        DetachedCriteria productSearchCriteria = productSearchCriteriaBuilder.buildProductSearchCriteriaOrdered(getSessionFactory().getCurrentSession(),cropPubkeys,searchCriteria);
        Criteria executableCriteria = productSearchCriteria.getExecutableCriteria(getSession());
        executableCriteria.setFetchSize(100);
        return executableCriteria.list();
    }

    
    @Override
    public int countBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria) {
        DetachedCriteria productSearchCriteria = productSearchCriteriaBuilder.buildProductSearchCriteria(getSessionFactory().getCurrentSession(),cropPubkeys,searchCriteria);
        productSearchCriteria.setProjection(Projections.rowCount());
         Number count = (Number) productSearchCriteria.getExecutableCriteria(getSession()).uniqueResult();
//        Criteria executableCriteria = getSession().createCriteria(LexiconProductEntity.class);
//        executableCriteria.add(Subqueries.propertyIn("id",productSearchCriteria ));
//        executableCriteria.setProjection(Projections.rowCount());
//        Number count = (Number)executableCriteria.setProjection(Projections.rowCount()).uniqueResult();
        return count.intValue();
    }

    @Override
    public List<LexiconProductEntity> findBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria, int pageSize, int pageNumber) {
        DetachedCriteria productSearchCriteria = productSearchCriteriaBuilder.buildProductSearchCriteriaOrdered(getSessionFactory().getCurrentSession(),cropPubkeys,searchCriteria);
        Criteria executableCriteria = productSearchCriteria.getExecutableCriteria(getSession());
        executableCriteria.setFirstResult(pageSize*pageNumber);
        executableCriteria.setMaxResults(pageSize);
        return executableCriteria.list();  
    }

    @Override
    public List<LexiconProductEntity> findByAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops) {
         return buildAdditionalCommentsCriteria(cropPubkeys,productNames, nameType, crops).list();
    }

    private Criteria buildAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops) {
        Criteria criteria = getSession().createCriteria(LexiconProductEntity.class, LEXICON_PRODUCT);
        if(productNames!=null&&!productNames.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            for(String productName:productNames){
                 String nameCriteria = productName.replace("*","%");
                 if(nameType==ProductAdditionalCommentsNameType.PRE_COMMERCIAL||nameType==null){
                    or.add(Restrictions.like("preCommercialName",nameCriteria.toUpperCase()));
                 }
                 if(nameType == ProductAdditionalCommentsNameType.VARIETY|| nameType==null){
                    or.add(Restrictions.like("tagVarietyName",nameCriteria.toUpperCase()));
                 }
            }
            criteria.add(or);
        }
        criteria.add(Restrictions.eq(LOGICAL_DELETE,false));
        DetachedCriteria stageCriteria = DetachedCriteria.forClass(LexiconProductStageEntity.class);
        stageCriteria.add(Restrictions.eq(LOGICAL_DELETE,false));
        stageCriteria.setProjection(Projections.property(LEXICON_PRODUCT + SEPARATOR + ID));
        criteria.add(Subqueries.propertyIn(ID,stageCriteria));
        Criteria cropCriteria = criteria.createCriteria("lexiconCrop");
        if(crops!=null&&!crops.isEmpty()){
            Disjunction or = Restrictions.disjunction();
            for(String crop:crops){
               or.add(Restrictions.eq("name",crop.toUpperCase()));
            }
            cropCriteria.add(or);
        }
        cropCriteria.add(Restrictions.in("pubkey",cropPubkeys));
        return criteria;
    }

    @Override
    public Long countAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops) {
        Criteria criteria = buildAdditionalCommentsCriteria(cropPubkeys,productNames, nameType, crops);
        criteria.setProjection(Projections.count(ID));
        return (Long)criteria.uniqueResult();
    }

    @Override
    public List<LexiconProductEntity> findPagedByAdditionalCommentsCriteria(List<String> cropPubkeys,List<String> productNames, ProductAdditionalCommentsNameType nameType, List<String> crops, int pageSize, int pageNumber) {
         Criteria criteria = buildAdditionalCommentsCriteria( cropPubkeys,productNames, nameType, crops);
        criteria.setFirstResult(pageNumber*pageSize);
        criteria.setMaxResults(pageSize);
        return criteria.list();  
    }

    public void setProductSearchCriteriaBuilder(ProductSearchCriteriaBuilder productSearchCriteriaBuilder) {
        this.productSearchCriteriaBuilder = productSearchCriteriaBuilder;
    }
}
