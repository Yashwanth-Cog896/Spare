package com.monsanto.tps.productstewardship.productassociation.dao;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 12, 2011
 * Time: 10:42:51 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductAssociation implements Comparable {
   private String baseManufacturingName;
   private String manufacturingName;
   private String varietyName;
   private Long cropId;
   private String preCommercialName;

    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public void setBaseManufacturingName(String baseManufacturingName) {
        this.baseManufacturingName = baseManufacturingName;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || !getClass().isAssignableFrom(o.getClass())) return false;

        ProductAssociation that = (ProductAssociation) o;
        if (cropId != null ? !cropId.equals(that.cropId) : that.cropId != null) return false;
        if (baseManufacturingName != null ? !baseManufacturingName.equals(that.baseManufacturingName) : that.baseManufacturingName != null)
            return false;
        if (manufacturingName != null ? !manufacturingName.equals(that.manufacturingName) : that.manufacturingName != null)
            return false;
        if (preCommercialName != null ? !preCommercialName.equals(that.preCommercialName) : that.preCommercialName != null)
            return false;
        if (varietyName != null ? !varietyName.equals(that.varietyName) : that.varietyName != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = baseManufacturingName != null ? baseManufacturingName.hashCode() : 0;
        result = 31 * result + (manufacturingName != null ? manufacturingName.hashCode() : 0);
        result = 31 * result + (varietyName != null ? varietyName.hashCode() : 0);
        result = 31 * result + (int) (cropId ^ (cropId >>> 32));
        result = 31 * result + (preCommercialName != null ? preCommercialName.hashCode() : 0);
        return result;
    }

    @Override
    public int compareTo(Object o) {
               ProductAssociation that = (ProductAssociation) o;
        int retval = compareField(baseManufacturingName,that.baseManufacturingName);
        if(retval==0){
            retval = compareField(manufacturingName,that.manufacturingName);
        }
        if(retval==0){
            retval = compareField(varietyName,that.varietyName);
        }
        if(retval==0){
            retval = compareField(preCommercialName,that.preCommercialName);
        }
        if(retval==0){
            retval = compareField(cropId,that.cropId);
        }
        return retval;
    }

    int compareField(Comparable val1, Comparable val2){
        if(val1==val2){
            return 0;
        }
        else if(val1==null){
            return -1;
        }
        else if(val2==null){
            return 1;
        }
        else {
            return val1.compareTo(val2);
        }
    }
}
