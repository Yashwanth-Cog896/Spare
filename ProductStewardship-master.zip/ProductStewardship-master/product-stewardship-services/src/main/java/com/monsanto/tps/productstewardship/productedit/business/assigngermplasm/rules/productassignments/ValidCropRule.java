package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.productassignments;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ValidCropRule implements ValidationSimpleRule<Product> {
    LexiconCropDao lexiconCropDao;
    @Override
    public void validate(Product model, ValidationStatus status) {
        boolean invalid=true;
        if(StringUtils.isNotBlank(model.getLexiconCropName())){
           LexiconCropEntity lexiconCrop = lexiconCropDao.getByName(model.getLexiconCropName());
           if(lexiconCrop!=null){
               invalid=false;

           }
        }
        if(invalid){
            status.addCondition(new ValidationResult(ProductEditService.INVALID_CROP, ValidationSeverity.ERROR));
        }
    }

    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }
}
