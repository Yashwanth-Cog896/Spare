package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.productimage.service.ImageDimensions;
import com.monsanto.tps.productstewardship.productimage.service.ProductImagesService;
import com.monsanto.tps.productstewardship.transfer.ValidationProperty;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;


/**
 * VVKALU - Mar 15, 2010 1:32:48 AM
 */
public class ImagePixelsExceededRule implements ValidationSimpleRule<ImageValidationModel> {

    @Override
    public void  validate(ImageValidationModel model, ValidationStatus status) {
        ImageDimensions dimension = model.getImageDimensions();
        if (dimension == null) {
            return ;
        }
        long maxImageHeight = model.getConfigurationPicture().getImageHeight();
        long maxImageWidth = model.getConfigurationPicture().getImageWidth();
        if (dimension.getImageHeight() > maxImageHeight
                || dimension.getImageWidth() > maxImageWidth) {
            status.addCondition(new ValidationResult( ProductImagesService.IMAGE_PIXELS_EXCEED_LIMIT,new ValidationProperty(ProductImagesService.MAX_WIDTH,String.valueOf(maxImageWidth)),new ValidationProperty(ProductImagesService.MAX_HEIGHT,String.valueOf(maxImageHeight))));
        }
    }
}
