package com.monsanto.tps.productstewardship.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.KeywordEntity;
import java.util.List;

public interface  KeywordDao extends GenericDao<KeywordEntity,Long> {
    String TRAIT_CHARACTERISTIC = "TRAIT CHARACTERISTIC";
    String NON_TRANS_STRING = "NON-TRANSGENIC";

    @DynamicDaoMethod(queryName = "KeywordDao.findEnabledByTypeAndName",
             parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
     public List<KeywordEntity> findEnabledByTypeAndName(@DynamicDaoParameter(name="keywordType")String type, @DynamicDaoParameter(name="keywordName")String name);

}
