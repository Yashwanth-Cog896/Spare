package com.monsanto.sap.vegetable.webservice.country;

import com.monsanto.sap.vegetable.webservice.country.TableOfYmmvegcntryStr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Error" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfYmmvegcntryStr"/>
 *         &lt;element name="VegctrynameIn" type="{urn:sap-com:document:sap:soap:functions:mc-style}TableOfYmmvegcntryStr"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "error",
    "vegctrynameIn"
})
@XmlRootElement(name = "YmmVegcntrynameDataUpload")
public class YmmVegcntrynameDataUploadRequest {

    @XmlElement(name = "Error", required = true)
    protected TableOfYmmvegcntryStr error;
    @XmlElement(name = "VegctrynameIn", required = true)
    protected TableOfYmmvegcntryStr vegctrynameIn;

    /**
     * Gets the value of the error property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public TableOfYmmvegcntryStr getError() {
        return error;
    }

    /**
     * Sets the value of the error property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.monsanto.sap.vegetable.webservice.country.TableOfYmmvegcntryStr }
     *     
     */
    public void setError(TableOfYmmvegcntryStr value) {
        this.error = value;
    }

    /**
     * Gets the value of the vegctrynameIn property.
     * 
     * @return
     *     possible object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public TableOfYmmvegcntryStr getVegctrynameIn() {
        return vegctrynameIn;
    }

    /**
     * Sets the value of the vegctrynameIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link TableOfYmmvegcntryStr }
     *     
     */
    public void setVegctrynameIn(TableOfYmmvegcntryStr value) {
        this.vegctrynameIn = value;
    }

}
