package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 28, 2011
 * Time: 3:04:21 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductPictureDao extends GenericDao<LexiconProductPictureEntity,Long>{
    @DynamicDaoMethod(queryName = "LexiconProductPictureEntity.getByProductPubkey",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
  List<LexiconProductPictureEntity> getByProductPubkey(@DynamicDaoParameter(name="productPubkey") String productPubKey);

    @DynamicDaoMethod(queryName = "LexiconProductPictureEntity.getByDisplayName",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    LexiconProductPictureEntity getByDisplayname(@DynamicDaoParameter(name="displayName") String displayName);
//   List<LexiconProductPictureDao> getImagePixels();
}
