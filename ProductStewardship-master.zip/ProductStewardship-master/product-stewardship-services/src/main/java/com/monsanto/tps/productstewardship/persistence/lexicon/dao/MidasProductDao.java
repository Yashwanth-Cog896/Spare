package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 5, 2011
 * Time: 4:02:55 PM
 * To change this template use File | Settings | File Templates.
 */
public interface  MidasProductDao extends GenericDao<MidasProductEntity,Long>{
         @DynamicDaoMethod(queryName = "MidasProductDao.getByIds",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
         List<MidasProductEntity> getByIds(@DynamicDaoParameter(name="requestId") Long requestId);
             @DynamicDaoMethod(queryName = "MidasProductDao.getWithParentageByIds",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
         List<MidasProductEntity> getWithParentageByIds(@DynamicDaoParameter(name="requestId") Long requestId);
}

