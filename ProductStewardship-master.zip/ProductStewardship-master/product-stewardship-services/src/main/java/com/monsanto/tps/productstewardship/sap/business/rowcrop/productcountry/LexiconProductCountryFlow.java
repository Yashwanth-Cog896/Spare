package com.monsanto.tps.productstewardship.sap.business.rowcrop.productcountry;


import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconTempSessionOcdDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductSubscriptionEntity;
import com.monsanto.tps.productstewardship.sap.business.rowcrop.SapRowCropResponseHandler;

import java.util.*;

public class LexiconProductCountryFlow {
  private SapRowCropResponseHandler sapRowCropResponseHandler;
  private LexiconProductStageDao lexiconProductStageDao;
  private LexiconTempSessionOcdDao lexiconTempSessionOcdDao;
  private SapProductCountryServiceDelegate sapProductCountryServiceDelegate;

  public List<PqSapQueueEntryEntity> flowProducts(List<PqSapQueueEntryEntity> pqSapQueueEntries){
     List<PqSapQueueEntryEntity> processedQueueEntries = new ArrayList<PqSapQueueEntryEntity>();
     if (!pqSapQueueEntries.isEmpty()){
       Multimap<Long,PqSapQueueEntryEntity> productStageMap = createProductStageMap(pqSapQueueEntries);
       List<LexiconProductStageEntity> productStagesToProcess = retrieveProductStagesToProcess(productStageMap.keySet());
       List<SapSyncResponse> responses =  flowToSap(productStagesToProcess);
       processUnmatchedQueueEntries(pqSapQueueEntries, productStagesToProcess, productStageMap);
       processedQueueEntries = sapRowCropResponseHandler.processResponses(responses, pqSapQueueEntries, productStageMap);
     }
     return processedQueueEntries;
  }

  private List<SapSyncResponse> flowToSap(List<LexiconProductStageEntity> productStagesToProcess) {
    List<SapSyncResponse> responses = new ArrayList<SapSyncResponse>();
    if (!productStagesToProcess.isEmpty()){
       responses = sapProductCountryServiceDelegate.flowToSap(productStagesToProcess);
    }
    return responses;
  }

  private List<LexiconProductStageEntity> retrieveProductStagesToProcess(Set<Long> productStageIds) {
    //todo: decide the request id
    long requestId = 19000101L;
    lexiconTempSessionOcdDao.insertNumberValues(requestId,productStageIds);
    return lexiconProductStageDao.findSubscribedProductStage(requestId, ProductSubscriptionEntity.SAP);
  }

  private Multimap<Long, PqSapQueueEntryEntity> createProductStageMap(List<PqSapQueueEntryEntity> pqSapQueueEntries) {
    Multimap<Long, PqSapQueueEntryEntity> productStageMap = ArrayListMultimap.create();
    for (PqSapQueueEntryEntity queueEntry:pqSapQueueEntries){
      if (PqSapQueueEntryEntity.PRODUCT_STAGE.equals(queueEntry.getTableName())){
        productStageMap.put(queueEntry.getTableId(),queueEntry);
      }
    }
    return productStageMap;
  }

  private void processUnmatchedQueueEntries(List<PqSapQueueEntryEntity> pqSapQueueEntries, List<LexiconProductStageEntity> productStagesToProcess, Multimap<Long, PqSapQueueEntryEntity> productStageMap) {
    List<Long> unprocessedStageIds = getUnprocessedStageIds(productStagesToProcess, productStageMap);
    for (Long stageId:unprocessedStageIds){
      Collection<PqSapQueueEntryEntity> queueEntriesToRemove = productStageMap.get(stageId);
      pqSapQueueEntries.removeAll(queueEntriesToRemove);
      sapRowCropResponseHandler.removeQueueEntries(queueEntriesToRemove);
    }
  }

  private List<Long> getUnprocessedStageIds(List<LexiconProductStageEntity> productStagesToProcess, Multimap<Long, PqSapQueueEntryEntity> productStageMap) {
    List<Long> unprocessedStageIds = new ArrayList<Long>(productStageMap.keySet());
    List<Long> processedStageIds = getStageIds(productStagesToProcess);
    unprocessedStageIds.removeAll(processedStageIds);
    return unprocessedStageIds;
  }

  private List<Long> getStageIds(List<LexiconProductStageEntity> productStages) {
    List<Long> stageIds = new ArrayList<Long>();
    for (LexiconProductStageEntity productStage:productStages){
      stageIds.add(productStage.getId());
    }
    return stageIds;
  }

  public void setSapRowCropResponseHandler(SapRowCropResponseHandler sapRowCropResponseHandler) {
    this.sapRowCropResponseHandler = sapRowCropResponseHandler;
  }

  public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
    this.lexiconProductStageDao = lexiconProductStageDao;
  }

  public void setLexiconTempSessionOcdDao(LexiconTempSessionOcdDao lexiconTempSessionOcdDao) {
    this.lexiconTempSessionOcdDao = lexiconTempSessionOcdDao;
  }

  public void setSapProductCountryServiceDelegate(SapProductCountryServiceDelegate sapProductCountryServiceDelegate) {
    this.sapProductCountryServiceDelegate = sapProductCountryServiceDelegate;
  }
}
