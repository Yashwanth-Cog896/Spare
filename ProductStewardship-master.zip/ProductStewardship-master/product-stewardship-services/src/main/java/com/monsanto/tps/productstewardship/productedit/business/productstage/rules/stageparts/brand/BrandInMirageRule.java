package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.brand;


import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonBrandXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;


public class BrandInMirageRule  implements ValidationSimpleRule<StageValidationModel> {
    LexiconBrandDao lexiconBrandDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
         if(StringUtils.isNotBlank(model.getProductStage().getBrandName())){
             LexiconBrandEntity lexiconBrand =  lexiconBrandDao.getByName(model.getProductStage().getBrandName());
             if(brandFound(lexiconBrand) &&(! isBrandInMirage(lexiconBrand))){
                 status.addCondition(new ValidationResult(ProductEditService.BRAND_NOT_IN_MIRAGE_CODE, ValidationSeverity.ERROR));
             }
         }
    }

    private boolean brandFound(LexiconBrandEntity lexiconBrand) {
        return lexiconBrand!=null&&lexiconBrand.isActive();
    }

    private boolean isBrandInMirage(LexiconBrandEntity lexiconBrand) {
        boolean mirageFound=false;
        for(FbsCommonBrandXrefEntity brandXref: lexiconBrand.getFbsCommonBrandXrefs()){
            if(brandXref.getMirageCompany()!=null){
                mirageFound=true;
            }
        }
        return mirageFound;
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }
}
