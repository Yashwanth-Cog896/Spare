package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.existingsyncproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasProductNameDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LinkedAndMatchingMidasProdCantExistRule implements ValidationSimpleRule<Product> {
    LexiconProductDao lexiconProductDao;
    MidasProductNameDao midasProductNameDao;
    public static final String MONSANTO = "MONSANTO";

    @Override
    public void validate(Product model, ValidationStatus status) {
        MidasProductEntity midasProduct = fetchMidasProduct(model);
        if(midasProduct!=null){
            MidasProductEntity commonProduct = getCommonProduct(model.getPreCommercialName());
            if(commonProduct!=null){
                if(midasProduct.getId()!=commonProduct.getId()){
                     status.addCondition(new ValidationResult(ProductEditService.BOTH_LINKED_AND_MATCH_MIDAS_PROD_CODE, ValidationSeverity.ERROR)); 
                }
            }
        }
    }

    public MidasProductEntity getCommonProduct(String productName){
        MidasProductEntity product = null;
        List<MidasProductNameEntity> midasProductNames = midasProductNameDao.getActiveByBrandAndName(MONSANTO,productName);
        if(!midasProductNames.isEmpty()){
            Set<Long> productIds = new HashSet<Long>();
            for(MidasProductNameEntity midasProductName: midasProductNames){
                productIds.add(midasProductName.getMidasProduct().getId());
            }
            if(productIds.size()==1){
                product = midasProductNames.get(0).getMidasProduct();
            }
        }
        return product;
    }
    private MidasProductEntity fetchMidasProduct(Product model) {
        MidasProductEntity midasProduct = null;
        if (StringUtils.isNotBlank(model.getProductPubkey())) {
            LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(model.getProductPubkey());
            if (lexiconProduct != null) {
                FbsCommonProductXrefEntity commonProductXrefEntity = lexiconProduct.getFbsCommonProductXref();
                if (!lexiconProduct.isLogicalDelete() && (commonProductXrefEntity != null) &&
                        (commonProductXrefEntity.getMidasProduct() != null)) {
                    midasProduct = commonProductXrefEntity.getMidasProduct();
                }
            }
        }
        return midasProduct;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setMidasProductNameDao(MidasProductNameDao midasProductNameDao) {
        this.midasProductNameDao = midasProductNameDao;
    }
}
