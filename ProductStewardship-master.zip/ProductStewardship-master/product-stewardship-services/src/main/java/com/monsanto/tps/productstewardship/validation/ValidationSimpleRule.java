/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.validation;


/**
 * vvkalu - Feb 25, 2010 9:53:51 AM
 */
public interface ValidationSimpleRule<ModelT> {

   void  validate(ModelT model, ValidationStatus status);

}