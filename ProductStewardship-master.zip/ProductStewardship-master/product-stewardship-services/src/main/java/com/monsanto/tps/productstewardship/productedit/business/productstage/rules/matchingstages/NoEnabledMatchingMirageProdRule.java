package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.matchingstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageSeedProductDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageCompanyEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageCountryEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class NoEnabledMatchingMirageProdRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductStageDao lexiconProductStageDao;
    private MirageSeedProductDao mirageSeedProductDao;
    private LexiconBrandDao lexiconBrandDao;
    private LexiconCountryDao lexiconCountryDao;
    private LexiconStageDao lexiconStageDao;
    private MidasCropDao midasCropDao;
    
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        LexiconProductStageEntity lexiconProductStage = findLexiconProductStage(model);
        MirageSeedProductEntity existingMirageProduct = findExistingMirageProduct(lexiconProductStage);
        LexiconStageEntity lexiconStage = lexiconStageDao.findStageByAbbreviation(model.getProductStage().getStageAbbreviation());
        MirageSeedProductEntity matchingMirageProduct = findMirageProduct(model);
        if((!isRevertingToPreComlStage(lexiconProductStage, lexiconStage, existingMirageProduct)) &&
             enabledMatchingProductFound(matchingMirageProduct, existingMirageProduct)){
             status.addCondition(new ValidationResult(ProductEditService.MATCHING_MIRAGE_EXISTS_CODE, ValidationSeverity.ERROR));
        }
    }

    private MirageSeedProductEntity findExistingMirageProduct(LexiconProductStageEntity lexiconProductStage) {
        MirageSeedProductEntity existingMirageProduct = null;

        if(lexiconProductStage!=null){
            FbsCommonProductNameXrefEntity nameXref = lexiconProductStage.getFbsCommonProductNameXref();
            if(nameXref!=null){
                existingMirageProduct = nameXref.getMirageSeedProduct();
            }
        }
        return existingMirageProduct;
    }

    private LexiconProductStageEntity findLexiconProductStage(StageValidationModel model) {
        LexiconProductStageEntity lexiconProductStage = null;
        if(StringUtils.isNotBlank(model.getProductStage().getProductStagePubkey())){
            lexiconProductStage = lexiconProductStageDao.getByPubkey(model.getProductStage().getProductStagePubkey());
        }
        return lexiconProductStage;
    }

    private boolean enabledMatchingProductFound(MirageSeedProductEntity matchingMirageSeedProduct, MirageSeedProductEntity existingMirageProduct) {
        return ((existingMirageProduct != null) && ((matchingMirageSeedProduct != null) && ( (matchingMirageSeedProduct.getId() != existingMirageProduct.getId()) && (matchingMirageSeedProduct.isEnabled()))))||
                ((existingMirageProduct==null)&&(matchingMirageSeedProduct!=null)&&matchingMirageSeedProduct.isEnabled());
    }

    private boolean isRevertingToPreComlStage(LexiconProductStageEntity lexiconProductStage, LexiconStageEntity lexiconStage, MirageSeedProductEntity existingMirageProduct) {
        return (existingMirageProduct==null||lexiconStage==null)?false:(lexiconProductStage.getLexiconStage().isCommercial()&&!lexiconStage.isCommercial());
    }

    private MirageSeedProductEntity findMirageProduct(StageValidationModel model) {
        String productName = StringUtils.isBlank(model.getProductStage().getCommercialName()) ? model.getProduct().getPreCommercialName() :model.getProductStage().getCommercialName();
        MirageCompanyEntity mirageCompany = getMirageCompany(model);
        MapCropMirageEntity mapCropMirage = getMapCropMirage(model);
        MirageCountryEntity mirageCountry = getMirageCountry(model);
        MirageSeedProductEntity mirageSeedProduct =  null;
        if(productName!=null&&mirageCompany!=null&&mapCropMirage!=null&&mirageCountry!=null){
            mirageSeedProduct= mirageSeedProductDao.findByProductNameBayerCodeCountryCompany(productName,mapCropMirage.getMirageBayerCode(),mirageCountry.getCode(),mirageCompany.getId());
        }
        return mirageSeedProduct;
   }

    private MirageCountryEntity getMirageCountry(StageValidationModel model) {
        String countryAbbreviation = model.getProductStage().getCountryAbbreviation();
        LexiconCountryEntity lexiconCountry = lexiconCountryDao.findByAbbreviation(countryAbbreviation);
        MirageCountryEntity mirageCountry = null;
        if(lexiconCountry!=null&&!lexiconCountry.getFbsCommonCountryXrefs().isEmpty()){
            FbsCommonCountryXrefEntity countryXref = lexiconCountry.getFbsCommonCountryXrefs().iterator().next();
            mirageCountry = countryXref.getMirageCountry();
        }
        return mirageCountry;
    }

    private MapCropMirageEntity getMapCropMirage(StageValidationModel model) {
        MapCropMirageEntity mapCropMirage =  null;
        String cropName = model.getProduct().getLexiconCropName();
        if(StringUtils.isNotBlank(cropName)){
            mapCropMirage=midasCropDao.findMapCropMirage(cropName);
        }
        return mapCropMirage;
    }

    private MirageCompanyEntity getMirageCompany(StageValidationModel model) {
        MirageCompanyEntity mirageCompany = null;
        LexiconBrandEntity lexiconBrand = lexiconBrandDao.getByName(model.getProductStage().getBrandName());

        if((lexiconBrand!=null)&&(!lexiconBrand.getFbsCommonBrandXrefs().isEmpty())){
            FbsCommonBrandXrefEntity brandXref = lexiconBrand.getFbsCommonBrandXrefs().iterator().next();
            mirageCompany = brandXref.getMirageCompany();
        }
        return mirageCompany;
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }

    public void setLexiconCountryDao(LexiconCountryDao lexiconCountryDao) {
        this.lexiconCountryDao = lexiconCountryDao;
    }

    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }

    public void setMidasCropDao(MidasCropDao midasCropDao) {
        this.midasCropDao = midasCropDao;
    }

    public void setMirageSeedProductDao(MirageSeedProductDao mirageSeedProductDao) {
        this.mirageSeedProductDao = mirageSeedProductDao;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
