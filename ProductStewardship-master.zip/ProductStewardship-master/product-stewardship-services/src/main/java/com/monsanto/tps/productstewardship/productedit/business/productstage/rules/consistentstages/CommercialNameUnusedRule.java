package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.consistentstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommercialNameUnusedRule  implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductStageDao lexiconProductStageDao;
    
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean isValid = true;
        if(StringUtils.isNotBlank(model.getProductStage().getCommercialName())){
           isValid = validateRequest(model.getProducts(),model.getProduct(),model.getProductStage().getCommercialName());
           if(isValid){
              isValid = findMatchingStagesNotInRequest(model).isEmpty();
           }
           if(!isValid){
              status.addCondition(new ValidationResult(ProductEditService.COML_NAME_EXISTS_FOR_DIFF_PROD_CODE, ValidationSeverity.ERROR));
           }
        }
    }

    private Map<String, LexiconProductStageEntity> findMatchingStagesNotInRequest(StageValidationModel model) {
        Map<String,LexiconProductStageEntity> lexiconProductStageMap = new HashMap<String, LexiconProductStageEntity>();
        for(LexiconProductStageEntity lexiconProductStage:lexiconProductStageDao.findByMatchingCommercialNames(model.getProductStage().getCommercialName(),model.getProduct().getProductPubkey())){
            lexiconProductStageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
        }
        for(Product product: model.getProducts()){
            if(model.getProduct()!=product){
                for(ProductStage productStage: product.getProductStages()){
                    if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
                       lexiconProductStageMap.remove(productStage.getProductStagePubkey());
                    }
                }
            }

        }
        return lexiconProductStageMap;
    }

    public boolean validateRequest(List<Product> products,Product product, String commercialName){
        boolean isValid = true;
        out:
        for(Product testProduct:products){
            if(testProduct!=product){
                for(ProductStage testStage: testProduct.getProductStages()){
                    if(StringUtils.equalsIgnoreCase(commercialName,testStage.getCommercialName())){
                        isValid=false;
                        break out;
                    }
                }
            }
        }
        return isValid;
    }
    public void setLexiconProductStageDao(LexiconProductStageDao lexiconProductStageDao) {
        this.lexiconProductStageDao = lexiconProductStageDao;
    }
}
