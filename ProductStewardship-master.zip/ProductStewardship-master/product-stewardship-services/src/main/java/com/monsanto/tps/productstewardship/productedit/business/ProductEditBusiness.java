package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.productedit.service.Product;

import javax.jws.WebParam;
import java.util.List;

public interface ProductEditBusiness {
    public List<Product> editProducts(List<Product> products);
    public  boolean validate(List<Product> products);
}
