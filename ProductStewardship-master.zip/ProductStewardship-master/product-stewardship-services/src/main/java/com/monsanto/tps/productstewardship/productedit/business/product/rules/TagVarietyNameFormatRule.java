package com.monsanto.tps.productstewardship.productedit.business.product.rules;


import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class TagVarietyNameFormatRule implements ValidationSimpleRule<ProductValidationModel> {
    @Override
    public void validate(ProductValidationModel model, ValidationStatus status) {
       boolean criteriaViolated = false;

       String tagVarietyName = model.getProduct().getVarietyName();
       if(StringUtils.isNotBlank(tagVarietyName)){
           if(tagVarietyName.length()>50){
               criteriaViolated = true;
           }
           else if (!tagVarietyName.matches("[a-zA-Z0-9\\- ]+")){
               criteriaViolated=true;
           }
       }
       if(criteriaViolated){
            status.addCondition(new ValidationResult(ProductEditService.TAG_VARIETY_NAME_FORMAT_CODE, ValidationSeverity.ERROR));
       }
    }
}
