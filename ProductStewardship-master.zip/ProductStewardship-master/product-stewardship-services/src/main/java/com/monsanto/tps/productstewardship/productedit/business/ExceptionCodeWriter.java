package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ExceptionCodeDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ExceptionCodeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import org.apache.commons.lang.StringUtils;

public class ExceptionCodeWriter {
    private ExceptionCodeDao exceptionCodeDao;

    public void writeExceptionCode(Product product, ProductStage productStage, LexiconProductStageEntity lexiconProductStage){
        ExceptionCodeEntity exceptionCode = null;
        String productName  = productStage.getCommercialName();
        LexiconProductEntity lexiconProduct = lexiconProductStage.getLexiconProduct();
        LexiconCropEntity lexiconCrop = lexiconProduct.getLexiconCrop();
        if(StringUtils.isNotBlank(productName)){
            exceptionCode = getExistingExceptionCode(product,lexiconProductStage,lexiconCrop, productName);
            if(exceptionCode==null){
                exceptionCode = new ExceptionCodeEntity();
                exceptionCode.setProductName(productName);
                exceptionCode.setExceptionCode(exceptionCodeDao.getNextExceptionCode());
                exceptionCode.setLexiconCrop(lexiconCrop);
                exceptionCodeDao.saveOrUpdate(exceptionCode);
            }
            exceptionCode.setProductName(productName);
        }
        else {
            exceptionCode = exceptionCodeDao.getByProductName(lexiconProduct.getPreCommercialName(), lexiconCrop.getId());
        }
        exceptionCode.setPrimary(productStage.isPrimary());
    }

    private ExceptionCodeEntity getExistingExceptionCode(Product product, LexiconProductStageEntity lexiconProductStage,LexiconCropEntity lexiconCrop,String productName) {
        ExceptionCodeEntity exceptionCode  =  exceptionCodeDao.getByProductName(productName, lexiconCrop.getId());
        ExceptionCodeEntity oldExceptionCode = (StringUtils.isNotBlank(lexiconProductStage.getCommercialName()))? exceptionCodeDao.getByProductName(lexiconProductStage.getCommercialName(), lexiconCrop.getId()):null;
        if(exceptionCode==null){
            if(oldExceptionCode!=null){
                String oldCommercialName = lexiconProductStage.getCommercialName();
                if(StringUtils.isNotBlank(oldCommercialName)){
                    boolean needNewExceptionCode = false;
                    for(ProductStage testStage: product.getProductStages()){
                        if(oldCommercialName.equalsIgnoreCase(testStage.getCommercialName())){
                            needNewExceptionCode = true;
                            break;
                        }
                    }
                    if(!needNewExceptionCode){
                        exceptionCode = oldExceptionCode;
                    }
                }
            }

        }
        return exceptionCode;
    }

    public void setExceptionCodeDao(ExceptionCodeDao exceptionCodeDao) {
        this.exceptionCodeDao = exceptionCodeDao;
    }
}
