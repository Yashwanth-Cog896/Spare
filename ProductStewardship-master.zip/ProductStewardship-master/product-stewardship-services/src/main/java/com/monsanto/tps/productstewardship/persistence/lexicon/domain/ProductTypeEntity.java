package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:29:54 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "productTypeIdGenerator",allocationSize = 1,sequenceName = "Lexicon.PRODUCT_TYPE_ID_SEQ")
@Table(name = "PRODUCT_TYPE", schema = "Lexicon")
public class ProductTypeEntity  implements Serializable {
    @Id
    @Column(name="PRODUCT_TYPE_ID")
    @GeneratedValue(generator = "productTypeIdGenerator")
    private long id;
    @Column(name="PRODUCT_TYPE_NAME",nullable = false, length = 50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Column(name="PRODUCT_TYPE_CODE",nullable = false,length=10)
    private String code;
    @Column(name="PRODUCT_TYPE_PUBKEY",nullable = false, length=20)
    private String pubkey;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
