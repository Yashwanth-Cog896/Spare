package com.monsanto.osb.webservice.credentials;

import javax.xml.bind.annotation.XmlElement;

public class CredentialsContainer {
   
    Credentials credentials;

    @XmlElement(name = "UsernameToken",namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" )
    public Credentials getCredentials() {
        return credentials;
    }

    public void setCredentials(Credentials credentials) {
        this.credentials = credentials;
    }
}
