package com.monsanto.tps.productstewardship.email;

import com.monsanto.Util.EnvironmentHelper;

/**
 * User: pjberry
 * Date: Oct 18, 2007
 * Time: 2:34:54 PM
 */
public interface EmailParticipants
{
   String RECIPIENTS = "DL-TPS-Lexicon-Dev@monsanto.com, lexicon.support@monsanto.com";
   String SENDER = "lexicon.support@monsanto.com";
   String ENVIRONMENT = EnvironmentHelper.getFunction();
}
