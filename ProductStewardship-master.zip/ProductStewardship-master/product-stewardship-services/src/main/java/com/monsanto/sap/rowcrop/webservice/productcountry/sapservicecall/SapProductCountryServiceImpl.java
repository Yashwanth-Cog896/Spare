package com.monsanto.sap.rowcrop.webservice.productcountry.sapservicecall;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.productcountry.SapProductCountryInfo;

/**
 * nbwald Jul 12, 2007 3:59:37 PM
 */
public class SapProductCountryServiceImpl implements SapProductCountryService
{
    private final SapProductCountrySyncServiceCall serviceCall;

    public SapProductCountryServiceImpl(SapProductCountrySyncServiceCall serviceCall){
        this.serviceCall=serviceCall;
    }
    public SapSyncResponse syncSap(SapProductCountryInfo productCountryInfo) throws WrappingException {
      return serviceCall.call(productCountryInfo);
   }

}