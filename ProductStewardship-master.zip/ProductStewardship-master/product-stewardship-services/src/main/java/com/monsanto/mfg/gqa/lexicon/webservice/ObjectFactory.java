
package com.monsanto.mfg.gqa.lexicon.webservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.mfg.gqa.lexicon.webservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ProductChangedResponse_QNAME = new QName("http://webservice.lexicon.gqa.mfg.monsanto.com/", "productChangedResponse");
    private final static QName _ProductChanged_QNAME = new QName("http://webservice.lexicon.gqa.mfg.monsanto.com/", "productChanged");
    private final static QName _Productchangeinfo_QNAME = new QName("http://webservice.lexicon.gqa.mfg.monsanto.com/", "productchangeinfo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.mfg.gqa.lexicon.webservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ProductChanged }
     * 
     */
    public ProductChanged createProductChanged() {
        return new ProductChanged();
    }

    /**
     * Create an instance of {@link ProductChangeInformation }
     * 
     */
    public ProductChangeInformation createProductChangeInformation() {
        return new ProductChangeInformation();
    }

    /**
     * Create an instance of {@link ProductChangedResponse }
     * 
     */
    public ProductChangedResponse createProductChangedResponse() {
        return new ProductChangedResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductChangedResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.lexicon.gqa.mfg.monsanto.com/", name = "productChangedResponse")
    public JAXBElement<ProductChangedResponse> createProductChangedResponse(ProductChangedResponse value) {
        return new JAXBElement<ProductChangedResponse>(_ProductChangedResponse_QNAME, ProductChangedResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductChanged }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.lexicon.gqa.mfg.monsanto.com/", name = "productChanged")
    public JAXBElement<ProductChanged> createProductChanged(ProductChanged value) {
        return new JAXBElement<ProductChanged>(_ProductChanged_QNAME, ProductChanged.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductChangeInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.lexicon.gqa.mfg.monsanto.com/", name = "productchangeinfo")
    public JAXBElement<ProductChangeInformation> createProductchangeinfo(ProductChangeInformation value) {
        return new JAXBElement<ProductChangeInformation>(_Productchangeinfo_QNAME, ProductChangeInformation.class, null, value);
    }

}
