/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.filter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * nbwald - Mar 31, 2009 11:52:51 AM
 */
public class RegexpContextFilterHelper {

    private final Pattern pattern;
    private final String regexpPattern;

    public RegexpContextFilterHelper(String regexpPattern) {
      this.regexpPattern = regexpPattern;
      this.pattern = Pattern.compile(this.regexpPattern);
    }

    public boolean appliesTo(String context) {
      Matcher matcher = pattern.matcher(context);
      return matcher.matches();
    }

    public String parse(String context) {
      Matcher matcher = pattern.matcher(context);
      if(!matcher.matches()) {
         throw new RuntimeException("Attempted to parse context '" + context + "' but it does not match '" + regexpPattern + "'");
      }
      return matcher.group(1);
    }
}