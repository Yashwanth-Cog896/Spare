package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class BaseProductExistsRule implements ValidationSimpleRule<Product> {

  private BaseProductDao baseProductDao;

  @Override
  public void validate(Product model, ValidationStatus status) {
    if (!StringUtils.isNullOrEmpty(model.getManufacturingName())){
      BaseProductEntity baseProduct = baseProductDao.getBaseProductsNotDeletedByManufacturingName(model.getManufacturingName());
      if (baseProduct==null){
        status.addCondition(new ValidationResult(ProductEditService.BASE_PRODUCT_DOES_NOT_EXIST, ValidationSeverity.ERROR));
      }
    }
}

  public void setBaseProductDao(BaseProductDao baseProductDao) {
    this.baseProductDao = baseProductDao;
  }
}
