package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "CONFIGURATION_PICTURE", schema = "Lexicon")
public class ConfigurationPictureEntity  implements Serializable {

   @Id
   @Column(name="CONFIGURATION_PICTURE_ID")
   private long id;
   @Column(name="IMAGE_WIDTH",nullable = false)
   private long imageWidth;
   @Column(name="IMAGE_HEIGHT",nullable = false)
   private long imageHeight;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getImageHeight() {
        return imageHeight;
    }

    public void setImageHeight(long imageHeight) {
        this.imageHeight = imageHeight;
    }

    public long getImageWidth() {
        return imageWidth;
    }

    public void setImageWidth(long imageWidth) {
        this.imageWidth = imageWidth;
    }
}
