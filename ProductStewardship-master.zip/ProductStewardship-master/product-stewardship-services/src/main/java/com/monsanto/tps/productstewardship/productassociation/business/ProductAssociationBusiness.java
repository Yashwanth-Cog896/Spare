package com.monsanto.tps.productstewardship.productassociation.business;

import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationSearchResponse;
import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationSearchType;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 11, 2011
 * Time: 3:50:29 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductAssociationBusiness {
    public List<ProductAssociationSearchResponse> findProductAssociations(ProductAssociationSearchType searchType, List<String> name, boolean hybridOnly);    
}
