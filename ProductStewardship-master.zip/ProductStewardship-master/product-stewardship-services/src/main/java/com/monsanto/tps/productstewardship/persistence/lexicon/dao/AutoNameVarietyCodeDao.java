package com.monsanto.tps.productstewardship.persistence.lexicon.dao;


import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AutoNameVarietyCodeEntity;

public interface AutoNameVarietyCodeDao extends GenericDao<AutoNameVarietyCodeEntity,Long>{

  @DynamicDaoMethod(queryName = "AutoNameVarietyCodeEntity.getAutoNameVarietyCode",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
  public AutoNameVarietyCodeEntity getAutoNameVarietyCode(@DynamicDaoParameter(name = "productTypeId") long productTypeId,
                                                          @DynamicDaoParameter(name = "materialGroupId") long materialGroupId,
                                                          @DynamicDaoParameter(name = "materialPricingGroupId") long materialPricingGroupId);
}
