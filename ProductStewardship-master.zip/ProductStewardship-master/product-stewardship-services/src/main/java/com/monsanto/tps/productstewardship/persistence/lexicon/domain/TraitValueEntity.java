package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 26, 2011
 * Time: 1:06:42 PM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@Table(name = "CHAR_TRAIT_VALUE", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
public class TraitValueEntity {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name="CHAR_TRAIT_VALUE_ID", precision = 22, scale = 0)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="GERMPLASM_ID",nullable = false)
    private GermplasmEntity germplasm;

    @Column(name="NUM_VALUE",nullable = true,precision = 20,scale = 6)
    private Double numValue;

    @Column(name="STR_VALUE",nullable=true,length = 255)
    private String strValue;

    @Column(name="NUM_UOM_ID",nullable = true)
    private Long uomId;

    @Column(name="GENERATION_TRAIT_VAL_OBSERVED",length = 255, nullable = true)
    private String generationObserved;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="TRAIT_ID",nullable = true)
    MidasTraitEntity midasTrait;

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasTraitEntity getMidasTrait() {
        return midasTrait;
    }

    public void setMidasTrait(MidasTraitEntity midasTrait) {
        this.midasTrait = midasTrait;
    }

    public Double getNumValue() {
        return numValue;
    }

    public void setNumValue(Double numValue) {
        this.numValue = numValue;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public String getGenerationObserved() {
        return generationObserved;
    }

    public void setGenerationObserved(String generationObserved) {
        this.generationObserved = generationObserved;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || (!getClass().isAssignableFrom(o.getClass()))) return false;

        TraitValueEntity that = (TraitValueEntity) o;

        if (generationObserved != null ? !generationObserved.equals(that.generationObserved) : that.generationObserved != null)
            return false;
        if (!germplasm.equals(that.germplasm)) return false;
        if (midasTrait != null ? !midasTrait.equals(that.midasTrait) : that.midasTrait != null) return false;
        if (numValue != null ? !numValue.equals(that.numValue) : that.numValue != null) return false;
        if (strValue != null ? !strValue.equals(that.strValue) : that.strValue != null) return false;
        if (uomId != null ? !uomId.equals(that.uomId) : that.uomId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = germplasm.hashCode();
        result = 31 * result + (numValue != null ? numValue.hashCode() : 0);
        result = 31 * result + (strValue != null ? strValue.hashCode() : 0);
        result = 31 * result + (uomId != null ? uomId.hashCode() : 0);
        result = 31 * result + (generationObserved != null ? generationObserved.hashCode() : 0);
        result = 31 * result + (midasTrait != null ? midasTrait.hashCode() : 0);
        return result;
    }
}
