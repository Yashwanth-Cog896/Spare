package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:27:22 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "familyIdGenerator",allocationSize = 1,sequenceName = "Lexicon.FAMILY_ID_SEQ")
@Table(name = "FAMILY", schema = "Lexicon")
public class FamilyEntity  implements Serializable {
    @Id
    @Column(name="FAMILY_ID")
    @GeneratedValue(generator = "familyIdGenerator")
    private long id;
    @Column(name="FAMILY_NAME",nullable = false, length = 50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Column(name="FAMILY_CODE",nullable = false,length=10)
    private String code;

    
    @Column(name="FAMILY_PUBKEY",nullable = false, length=20)
    private String pubkey;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
