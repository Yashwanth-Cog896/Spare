package com.monsanto.tps.productstewardship.validation;

import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

import java.util.List;

public class ValidationRulesAggregate<ModelT> implements ValidationSimpleRule<ModelT> {
        private List<ValidationSimpleRule<ModelT>> rules;
        @Override
        public void validate(ModelT model, ValidationStatus status) {
            for(ValidationSimpleRule<ModelT> rule: rules){
                rule.validate(model,status);
            }
        }

        public void setRules(List<ValidationSimpleRule<ModelT>> rules) {
            this.rules = rules;
        }
    }
