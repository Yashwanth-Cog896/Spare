package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Subqueries;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 28, 2011
 * Time: 9:35:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductStageDaoImpl  extends GenericDaoImpl<LexiconProductStageEntity,Long> implements LexiconProductStageDao {

    ProductSearchCriteriaBuilder  productSearchCriteriaBuilder;
    
    public LexiconProductStageDaoImpl(){
        this(LexiconProductStageEntity.class);
    }
    public LexiconProductStageDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<LexiconProductStageEntity> findBySearchCriteria(List<String>cropPubkeys,LexiconProductSearchCriteria searchCriteria, int pageSize, int pageNumber) {
        DetachedCriteria productSearchCriteria = productSearchCriteriaBuilder.buildProductStageSearchCriteriaOrdered(getSessionFactory().getCurrentSession(),cropPubkeys,searchCriteria);
        Criteria executableCriteria = productSearchCriteria.getExecutableCriteria(getSession());
        executableCriteria.setFirstResult(pageSize*pageNumber);
        executableCriteria.setMaxResults(pageSize);
        return executableCriteria.list();
    }

    @Override
    public int countBySearchCriteria(List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria) {
        DetachedCriteria productSearchCriteria = productSearchCriteriaBuilder.buildProductStageSearchCriteria(getSessionFactory().getCurrentSession(),cropPubkeys,searchCriteria);
        productSearchCriteria.setProjection(Projections.rowCount());
        Number count = (Number) productSearchCriteria.getExecutableCriteria(getSession()).uniqueResult();
        return count.intValue();
    }

    /* This method is empty because all of the work is done via AOP. */
    @Override
    public LexiconProductStageEntity getByPubkey(@DynamicDaoParameter(name = "pubkey") String pubkey) {
        return null;  
    }

    @Override
    public List<LexiconProductStageEntity> findByMatchingCommercialNames(@DynamicDaoParameter(name = "commercialName") String commercialName, @DynamicDaoParameter(name = "productPubkey") String productPubkey) {
        return null;  
    }

    @Override
    public List<LexiconProductStageEntity> findByMatchingProductNames(@DynamicDaoParameter(name = "productName") String productName, @DynamicDaoParameter(name = "cropAbbreviation") String cropAbbreviation) {
        return null;  
    }

    @Override
    public List<LexiconProductStageEntity> findBySimilarCommercialNames(@DynamicDaoParameter(name = "commercialName") String commercialName, @DynamicDaoParameter(name = "productPubkey") String productPubkey) {
        return null;  
    }

    @Override
    public List<LexiconProductStageEntity> findByCommercialNameAndCrop(@DynamicDaoParameter(name = "commercialName") String commercialName, @DynamicDaoParameter(name = "cropId") Long lexiconCropId) {
        return null;  
    }

    @Override
    public List<LexiconProductStageEntity> findSubscribedProductStage(@DynamicDaoParameter(name = "requestId") Long requestId, @DynamicDaoParameter(name = "externalSystemName") String externalSystemName) {
      return null;
    }

    @Override
    public String getNextPubkey() {
        return null;  
    }

    public void setProductSearchCriteriaBuilder(ProductSearchCriteriaBuilder productSearchCriteriaBuilder) {
        this.productSearchCriteriaBuilder = productSearchCriteriaBuilder;
    }
}
