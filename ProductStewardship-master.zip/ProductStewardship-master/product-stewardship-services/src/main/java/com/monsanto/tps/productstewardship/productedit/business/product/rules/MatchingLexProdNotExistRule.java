package com.monsanto.tps.productstewardship.productedit.business.product.rules;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class MatchingLexProdNotExistRule  implements ValidationSimpleRule<ProductValidationModel> {
    private LexiconProductDao lexiconProductDao;
    @Override
    public void validate(ProductValidationModel validationModel, ValidationStatus status) {
        boolean foundMatch = false;
        Product model = validationModel.getProduct();
        if(StringUtils.isNotBlank(model.getPreCommercialName())){
            for(Product product: validationModel.getProducts()){
                if((product!=model)&&(model.getPreCommercialName().equalsIgnoreCase(product.getPreCommercialName()))){
                    foundMatch = true;
                    break;
                }
            }
            if((!foundMatch)&&(StringUtils.isNotBlank(model.getProductPubkey()))){
               LexiconProductEntity syncLexiconProduct = lexiconProductDao.getByPubkey(model.getProductPubkey());
                if(syncLexiconProduct!=null){
                    LexiconProductEntity matchingLexiconProduct = lexiconProductDao.getByPreCommercialName(model.getPreCommercialName());
                    foundMatch =((matchingLexiconProduct!=null)&&(!matchingLexiconProduct.getPubkey().equalsIgnoreCase(syncLexiconProduct.getPubkey())));
                }
            }
            if(foundMatch){
                 status.addCondition(new ValidationResult(ProductEditService.MATCHING_LEX_PROD_EXIST, ValidationSeverity.ERROR));
            }
        }
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
