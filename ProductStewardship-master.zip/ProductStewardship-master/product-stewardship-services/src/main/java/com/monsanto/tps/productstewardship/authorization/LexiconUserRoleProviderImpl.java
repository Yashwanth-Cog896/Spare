package com.monsanto.tps.productstewardship.authorization;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.authentication.UserRole;
import com.monsanto.tps.authentication.UserRoleImpl;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 1, 2011
 * Time: 2:49:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconUserRoleProviderImpl implements LexiconUserRoleProvider {
    private UserProfile userProfile;
    private UserPrivilegesService userPrivilegesService;
    private List<String> roles=null;

 

    @Override
    public List<UserRole> getRoles() {

        List<UserRole> userRoles = new ArrayList<UserRole>();
        for(String roleName:lazyLoadRoles()){
            userRoles.add(new UserRoleImpl(roleName));
        }
        return userRoles; 
    }

    private List<String> lazyLoadRoles() {
        if(roles==null){
            roles= userPrivilegesService.getRoles(userProfile.getUserName());
        }
        return roles;
    }

    @Override
    public boolean hasRole(String roleName) {
        return lazyLoadRoles().contains(roleName);  
    }

    public void setUserPrivilegesService(UserPrivilegesService userPrivilegesService) {
        this.userPrivilegesService = userPrivilegesService;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
}
