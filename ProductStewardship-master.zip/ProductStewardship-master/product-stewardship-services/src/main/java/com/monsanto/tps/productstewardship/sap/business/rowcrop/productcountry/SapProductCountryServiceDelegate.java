package com.monsanto.tps.productstewardship.sap.business.rowcrop.productcountry;


import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponseImpl;
import com.monsanto.sap.rowcrop.webservice.productcountry.SapProductCountryInfo;
import com.monsanto.sap.rowcrop.webservice.productcountry.sapservicecall.SapProductCountryService;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import org.apache.log4j.Logger;

import java.util.*;

public class SapProductCountryServiceDelegate {
  private static final Logger log = Logger.getLogger(SapProductCountryServiceDelegate.class);
  private final SapProductCountryService sapProductCountryService;

  public SapProductCountryServiceDelegate(SapProductCountryService sapProductCountryService) {
    this.sapProductCountryService = sapProductCountryService;
  }

  public List<SapSyncResponse> flowToSap(List<LexiconProductStageEntity>  productStagesToProcess){
    List<SapProductCountryInfo> productStageInfos = createProductStageInfos(productStagesToProcess);
        List<SapSyncResponse> responses = new ArrayList<SapSyncResponse>();
        for(SapProductCountryInfo info: productStageInfos) {
            try {
                responses.add(sapProductCountryService.syncSap(info));
            } catch (Exception e) {
                responses.add(processException(e, info));
                log.error(e.getMessage(),e);
            }
        }
        return responses;
  }

  private List<SapProductCountryInfo> createProductStageInfos(List<LexiconProductStageEntity> productStagesToProcess) {
    List<SapProductCountryInfo> productCountryInfos = new ArrayList<SapProductCountryInfo>();
        for(LexiconProductStageEntity stage: productStagesToProcess) {
            productCountryInfos.add(buildInfoObject(stage));
        }
        return productCountryInfos;
  }

  private SapProductCountryInfo buildInfoObject(LexiconProductStageEntity stage) {
    return new SapProductCountryInfo(stage, stage.getId());
  }

  private SapSyncResponse processException(Exception e, SapProductCountryInfo info) {
    return new SapSyncResponseImpl(info.sapLinkageAuditId,null,SapSyncResponse.ERROR_CODE,SapSyncResponse.ERROR_MESSAGE,e.getMessage());
  }
}
