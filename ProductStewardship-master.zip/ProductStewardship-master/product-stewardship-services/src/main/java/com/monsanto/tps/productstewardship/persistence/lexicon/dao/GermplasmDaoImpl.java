package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.apache.log4j.Logger;

import javax.annotation.Resource;
import java.util.*;

/**
 * Created by mansa on 11/23/2016.
 */
public class GermplasmDaoImpl extends GenericDaoImpl<GermplasmEntity,Long>    implements GermplasmDao  {
    public static final String GET_FEMALE_MALE_LEXICON_PUB_KEY = "GermplasmDao.getFemaleMaleLexiconPubKey";
    @Resource
    private SessionFactory sessionFactory;
    private static final Logger log = Logger.getLogger(GermplasmDaoImpl.class);
    public GermplasmDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public Map<String,List<String>> getFemaleMaleLexiconPubKey(Long germplasmID) {
        Query query = sessionFactory.getCurrentSession().getNamedQuery(GET_FEMALE_MALE_LEXICON_PUB_KEY)
                .setParameter("germplasmID",germplasmID);
        List pubKeyList=query.list();
        Map<String,List<String>> pubKeyMap = new HashMap<String, List<String>>();

        Iterator pubKeyIterator = pubKeyList.iterator();

        while(pubKeyIterator.hasNext()){
            List<String> lstPubKey = new ArrayList<String>();
            Object pubKeyData[] = (Object[]) pubKeyIterator.next();

            lstPubKey.add(pubKeyData[0].toString());
            lstPubKey.add(pubKeyData[1].toString());
            pubKeyMap.put(pubKeyData[2].toString(),lstPubKey);

        }
        return pubKeyMap;



    }
}
