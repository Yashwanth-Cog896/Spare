package com.monsanto.sap.rowcrop.webservice.productcountry;

import com.monsanto.sap.rowcrop.webservice.BasicSerializer;
import com.monsanto.sap.rowcrop.webservice.SapLinkageSchemaConsts;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Jul 5, 2007
 * Time: 3:40:05 PM
 */
public class SapProductCountrySerializer extends BasicSerializer<SapProductCountryInfo> {
  private static final String PRODUCT_COUNTRY = "productCountry";
  private static final String SAP_LINKAGE_AUDIT_ID = "sapLinkageAuditId";

  public void registerMappings(final XmlSerializerBuilder serializerBuilder) {
      serializerBuilder.registerMapping(SapLinkageSchemaConsts.NAMESPACE, PRODUCT_COUNTRY, SapProductCountryInfo.class);
      serializerBuilder.registerAttributeMapping(SapProductCountryInfo.class, SAP_LINKAGE_AUDIT_ID);
   }
}
