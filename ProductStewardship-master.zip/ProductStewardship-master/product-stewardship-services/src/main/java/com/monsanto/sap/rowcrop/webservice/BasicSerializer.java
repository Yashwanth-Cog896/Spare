package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import org.w3c.dom.Document;

public abstract class BasicSerializer<T>
   implements Serializer<T>
{
   public abstract void registerMappings(XmlSerializerBuilder serializerBuilder);

   private XmlSerializer serializer;

   protected XmlSerializer getSerializer() {
      if (serializer == null) {
         XmlSerializerBuilder serializerBuilder = new XmlSerializerBuilder();
         registerMappings(serializerBuilder);
         serializer = serializerBuilder.createSerializer();
      }
      return serializer;
   }

   public Document toDocument(T object) throws SerializationException {
      return getSerializer().toDocument(object);
   }
   public T fromDocument(Document doc) throws DeserializationException {
      return (T) getSerializer().fromDocument(doc);
   }
}