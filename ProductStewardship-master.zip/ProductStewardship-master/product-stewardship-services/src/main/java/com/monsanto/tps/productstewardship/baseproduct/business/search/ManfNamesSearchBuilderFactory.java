/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProductSearchType;

import java.util.Map;

/* vvkalu - 7/15/11 */
public class ManfNamesSearchBuilderFactory {

    private Map<String, ManfNamesSearchCriteria> searchCriteriaMap;

    public ManfNamesSearchCriteria getSearchCriteria(BaseProductSearchType searchType) {
        return searchCriteriaMap.get(searchType.getValue());
    }

    public void setSearchCriteriaMap(Map<String, ManfNamesSearchCriteria> searchCriteriaMap) {
        this.searchCriteriaMap = searchCriteriaMap;
    }
}