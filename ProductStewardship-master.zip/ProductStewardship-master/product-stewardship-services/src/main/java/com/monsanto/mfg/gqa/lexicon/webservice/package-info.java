@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.lexicon.gqa.mfg.monsanto.com/")
package com.monsanto.mfg.gqa.lexicon.webservice;

