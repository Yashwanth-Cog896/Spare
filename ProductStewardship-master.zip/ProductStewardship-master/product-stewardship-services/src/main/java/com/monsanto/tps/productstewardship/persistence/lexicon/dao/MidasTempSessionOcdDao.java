/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasTempSessionOcdEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TempSessionOcdId;

import java.util.Collection;

/**
 * rlcasw - Feb 19, 2010 2:55:19 PM
 */
public interface MidasTempSessionOcdDao extends GenericDao<MidasTempSessionOcdEntity, TempSessionOcdId> {

    void insertNumberValues(Long requestId, Collection<Long> ids);
}