package com.monsanto.tps.productstewardship.productedit.business.product.rules.existingproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ExistingLexProdHasProdXrefRule implements ValidationSimpleRule<ProductValidationModel> {
    private LexiconProductDao lexiconProductDao;
    @Override
    public void validate(ProductValidationModel model, ValidationStatus status) {
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity product = lexiconProductDao.getByPubkey(model.getProduct().getProductPubkey());
            if((product!=null)&&(!product.isLogicalDelete()&&product.getFbsCommonProductXrefs().isEmpty())){
                 status.addCondition(new ValidationResult(ProductEditService.LEX_PROD_FOUND_NO_XREF_CODE, ValidationSeverity.ERROR));
            }
        }
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}