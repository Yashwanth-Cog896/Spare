package com.monsanto.tps.productstewardship.gqa.business;

public class WebMethodsCredentials {
    String username;
    String password;
    public WebMethodsCredentials(String combinedCredentials){
        int colonIndex = combinedCredentials.indexOf(':');
        username = combinedCredentials.substring(0,colonIndex);
        password = combinedCredentials.substring(colonIndex+1,combinedCredentials.length());
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }
}
