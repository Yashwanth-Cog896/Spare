package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;

public interface ProductStageEditBusiness {
      void editProductStages(Product product, LexiconProductEntity lexiconProduct ); 
}
