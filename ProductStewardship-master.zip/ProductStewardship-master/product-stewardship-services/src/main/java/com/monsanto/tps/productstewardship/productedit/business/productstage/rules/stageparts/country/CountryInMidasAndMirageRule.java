package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.country;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCountryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonCountryXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class CountryInMidasAndMirageRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconCountryDao lexiconCountryDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        if(StringUtils.isNotBlank(model.getProductStage().getCountryAbbreviation())){
            LexiconCountryEntity lexiconCountry = lexiconCountryDao.findByAbbreviation(model.getProductStage().getCountryAbbreviation());
            if((lexiconCountry!=null)&&(!lexiconCountry.isLogicalDelete())){
                boolean isInMidasAndMirage = false;
                if(!lexiconCountry.getFbsCommonCountryXrefs().isEmpty()){
                    FbsCommonCountryXrefEntity countryXref = lexiconCountry.getFbsCommonCountryXrefs().iterator().next();
                    if(isInMidas(countryXref)&& isInMirage(countryXref)){
                        isInMidasAndMirage=true;
                    }
                }
                if(!isInMidasAndMirage){
                    status.addCondition(new ValidationResult(ProductEditService.COUNTRY_NOT_IN_M_OR_M_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }

    private boolean isInMirage(FbsCommonCountryXrefEntity countryXref) {
        return (countryXref.getMirageCountry()!=null);
    }

    private boolean isInMidas(FbsCommonCountryXrefEntity countryXref) {
        return (countryXref.getMidasCountry()!=null)&&(countryXref.getMidasCountry().isRefActive());
    }

    public void setLexiconCountryDao(LexiconCountryDao lexiconCountryDao) {
        this.lexiconCountryDao = lexiconCountryDao;
    }
}
