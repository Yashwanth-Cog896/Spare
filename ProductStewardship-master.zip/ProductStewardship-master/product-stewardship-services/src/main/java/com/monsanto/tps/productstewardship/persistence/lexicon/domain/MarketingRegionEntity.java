package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:11:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "MARKETING_REGION", schema = "Lexicon")
public class MarketingRegionEntity  implements Serializable {
    @Id
    @Column(name = "MARKETING_REGION_ID")
    long id;
    
    @Column(name="MARKETING_REGION_NAME",nullable = false, length = 50)
    String name;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
