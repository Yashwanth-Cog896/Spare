package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.monsanto.osb.webservice.credentials.CredentialsFactory;
import com.monsanto.sap.vegetable.webservice.country.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class LexiconCountryRequestFlow {

     private YMMVEGCNTRYNAMEDATAUPLOAD ymmVegCntryNameDataUpload;
     private CredentialsFactory credentialsFactory;

     public YmmVegcntrynameDataUploadResponse flowToSap(Set<LexiconProductEntity> lexiconProducts){
       TableOfYmmvegcntryStr tableOfYmmvegcntryStr = new TableOfYmmvegcntryStr();
       List<YmmvegcntryStr> ymmVegCntryStrs = tableOfYmmvegcntryStr.getItem();
       for(LexiconProductEntity lexiconProduct: lexiconProducts){
          ymmVegCntryStrs.addAll(buildYmmVegCntryStrs(lexiconProduct));
       }
       if(!ymmVegCntryStrs.isEmpty()){
       YmmVegcntrynameDataUploadRequest request = new YmmVegcntrynameDataUploadRequest();
       request.setError(new TableOfYmmvegcntryStr());
       request.setVegctrynameIn(tableOfYmmvegcntryStr);
       return ymmVegCntryNameDataUpload.ymmVegcntrynameDataUpload(credentialsFactory.createCredentialsContainer(),request);
    }
       else {
         return null;
       }
    }


    List<YmmvegcntryStr>  buildYmmVegCntryStrs(LexiconProductEntity lexiconProduct){
        List<YmmvegcntryStr> ymmVegCntryStrs = new ArrayList<YmmvegcntryStr>(lexiconProduct.getLexiconProductStages().size());
        for(LexiconProductStageEntity productStage: lexiconProduct.getLexiconProductStages()){
            if((productStage.getExceptionCode()!=null)&&(!productStage.isLogicalDelete())){
               YmmvegcntryStr  ymmvegcntryStr = new YmmvegcntryStr();
               ymmvegcntryStr.setYyid(null);
               ymmvegcntryStr.setYyproductKey(productStage.getLexiconProduct().getPubkey());
               ymmvegcntryStr.setYyexceptionKey(productStage.getExceptionCode().getExceptionCode());
               ymmvegcntryStr.setYyvarietyName(StringUtils.isNotBlank(productStage.getCommercialName())?productStage.getCommercialName():lexiconProduct.getPreCommercialName());
               ymmvegcntryStr.setYycountry(productStage.getLexiconCountry().getIsoCode());
               ymmvegcntryStr.setYydesc(null);
               ymmvegcntryStr.setYyerror(null);
               ymmVegCntryStrs.add(ymmvegcntryStr);
            }
        }
        return ymmVegCntryStrs;
    }

    public void setYmmVegCntryNameDataUpload(YMMVEGCNTRYNAMEDATAUPLOAD ymmVegCntryNameDataUpload) {
        this.ymmVegCntryNameDataUpload = ymmVegCntryNameDataUpload;
    }

    public void setCredentialsFactory(CredentialsFactory credentialsFactory) {
        this.credentialsFactory = credentialsFactory;
    }
}
