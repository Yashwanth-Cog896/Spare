/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/* vvkalu - 6/23/11 */
@Entity
@Table(name = "GERMPLASM_ROYALTY", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class GermplasmRoyaltyEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name="GERMPLASM_ROYALTY_ID", precision = 22, scale = 0)
    private long id;
    @Temporal(TemporalType.DATE)
    @Column(name="MODIFIED_DT",nullable = false)
    private Date modifiedDate;
    @Temporal(TemporalType.DATE)
    @Column(name="INACTIVE_DT",nullable = false)
    private Date inactiveDate;
    @Type(type="true_false")
    @Column(name="ROYALTY_IND",nullable = false)
    private boolean royaltyIndicator;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "GERMPLASM_ID", nullable = false)
    private GermplasmEntity germplasm;

    @Column(name="ROYALTY_CONTRACT_ID",nullable = false)
    private long royaltyContractId;
    
    @Type(type="true_false")
    @Column(name="IS_ACTIVE_IND",nullable = true)
    private Boolean active;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Date getInactiveDate() {
        return inactiveDate;
    }

    public void setInactiveDate(Date inactiveDate) {
        this.inactiveDate = inactiveDate;
    }

    public boolean isRoyaltyIndicator() {
        return royaltyIndicator;
    }

    public void setRoyaltyIndicator(boolean royaltyIndicator) {
        this.royaltyIndicator = royaltyIndicator;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public long getRoyaltyContractId() {
        return royaltyContractId;
    }

    public void setRoyaltyContractId(long royaltyContractId) {
        this.royaltyContractId = royaltyContractId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || (!getClass().isAssignableFrom(o.getClass()))) return false;

        GermplasmRoyaltyEntity that = (GermplasmRoyaltyEntity) o;

        if (royaltyContractId != that.royaltyContractId) return false;
        if (!germplasm.equals(that.germplasm)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = germplasm.hashCode();
        result = 31 * result + (int) (royaltyContractId ^ (royaltyContractId >>> 32));
        return result;
    }
}