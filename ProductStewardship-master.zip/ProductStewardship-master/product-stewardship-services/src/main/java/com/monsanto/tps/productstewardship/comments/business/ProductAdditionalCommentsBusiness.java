package com.monsanto.tps.productstewardship.comments.business;

import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalComments;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;

import javax.jws.WebParam;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 5, 2011
 * Time: 9:56:53 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductAdditionalCommentsBusiness {
       List<ProductAdditionalCommentsSearchResult> findProductAdditionalComments(List<String> productName, ProductAdditionalCommentsNameType nameType, List<String> crop);
       Long countProductAdditionalComments(List<String> productName, ProductAdditionalCommentsNameType nameType, List<String> crop);
       List<ProductAdditionalCommentsSearchResult> findPagedProductAdditionalComments(List<String> productName, ProductAdditionalCommentsNameType nameType, List<String> crop,int pageSize,int pageNumber);
       void saveProductAdditionalComments(List<ProductAdditionalComments> productAdditionalComments);

}
