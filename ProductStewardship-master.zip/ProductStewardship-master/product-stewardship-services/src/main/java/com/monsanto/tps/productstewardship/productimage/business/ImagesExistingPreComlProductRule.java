package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.productimage.service.ProductImagesService;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

/**
 * VVKALU - Mar 15, 2010 1:30:09 AM
 */
public class ImagesExistingPreComlProductRule implements ValidationSimpleRule<ImageValidationModel>  {

   @Override
   public void  validate(ImageValidationModel model, ValidationStatus status) {
      if (model.getLexiconProduct() == null) {
         status.addCondition(ProductImagesService.MATCHING_PRECOMLPROD_DOES_EXIST);
      }
   }
}
