package com.monsanto.tps.productstewardship.persistence.lexicon.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "AUTO_NAME_VARIETY_CODE", schema = "Lexicon")
public class AutoNameVarietyCodeEntity implements Serializable{
    @Id
    @Column(name="AUTO_NAME_VARIETY_CODE_ID")
    private long id;

    @Column(name="AUTO_NAME_VARIETY_CODE",nullable = false,length=2)
    private String  autoNameVarietyCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="PRODUCT_TYPE_ID",nullable = false)
    private ProductTypeEntity productType;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "MATERIAL_PRICING_GROUP_ID",nullable = false)
    private MaterialPricingGroupEntity materialPricingGroup;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="MATERIAL_GROUP_ID",nullable = false)
    private MaterialGroupEntity materialGroup;

    public long getId() {
      return id;
    }

    public void setId(long id) {
      this.id = id;
    }

    public String getAutoNameVarietyCode() {
      return autoNameVarietyCode;
    }

    public void setAutoNameVarietyCode(String autoNameVarietyCode) {
      this.autoNameVarietyCode = autoNameVarietyCode;
    }

    public ProductTypeEntity getProductType() {
      return productType;
    }

    public void setProductType(ProductTypeEntity productType) {
      this.productType = productType;
    }

    public MaterialPricingGroupEntity getMaterialPricingGroup() {
      return materialPricingGroup;
    }

    public void setMaterialPricingGroup(MaterialPricingGroupEntity materialPricingGroup) {
      this.materialPricingGroup = materialPricingGroup;
    }

    public MaterialGroupEntity getMaterialGroup() {
      return materialGroup;
    }

    public void setMaterialGroup(MaterialGroupEntity materialGroup) {
      this.materialGroup = materialGroup;
    }
}
