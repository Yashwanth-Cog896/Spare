package com.monsanto.tps.productstewardship.productimage.service.impl;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.productstewardship.audit.aspect.AuditStage;
import com.monsanto.tps.productstewardship.productimage.business.ProductImageProcessor;
import com.monsanto.tps.productstewardship.productimage.service.*;
import org.springframework.transaction.annotation.Transactional;

import javax.jws.WebService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * vvkalu - Mar 11, 2010 10:26:48 AM
 */
@WebService
@Transactional
public class ProductImagesServiceImpl implements ProductImagesService {
   private ProductImageProcessor productImageProcessor;

   @Override
   public List<ImageResponse> getProductImages(String productPubKey)
      throws IOException   {
      List<ImageResponse> responses = new ArrayList<ImageResponse>();
      if(productPubKey != null) {
         responses = productImageProcessor.getProductImagesByProdPubKey(productPubKey);
      }
      return responses;
   }

   @Override
   @AuditStage(processName = "UPLOAD_IMAGE", auditComment = "ProductImagesServiceImpl")
   @ProfileLogging
   public List<ImageUploadResponse> uploadImages(List<ImageUploadRequest> requests) {
         List<ImageUploadResponse> response = new ArrayList<ImageUploadResponse>();
         if(!requests.isEmpty()) {
            for(ImageUploadRequest imageRequest: requests) {
               response.add(productImageProcessor.process(imageRequest));
            }
         }
         return response;
   }

   @Override
   @ProfileLogging
   @AuditStage(processName = "DELETE_IMAGE", auditComment = "ProductImagesServiceImpl")
   public void deleteImages(List<DeleteImageRequest> requests) {
     for(DeleteImageRequest deleteRequest: requests) {
          productImageProcessor.deletePictureByPictureId(deleteRequest.getImageId());
     }
   }

   public void setProductImageProcessor(ProductImageProcessor productImageProcessor) {
      this.productImageProcessor = productImageProcessor;
   }
}
