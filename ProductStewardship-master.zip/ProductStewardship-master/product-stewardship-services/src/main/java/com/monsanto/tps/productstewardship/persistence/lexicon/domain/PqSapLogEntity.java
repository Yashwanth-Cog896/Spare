package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 18, 2011
 * Time: 2:45:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PQ_SAP_PRODUCT_LOG", schema = "LEXICON")
@SequenceGenerator(name = "pqSapLogIdGenerator",allocationSize = 1,sequenceName = "Lexicon.pq_sap_product_log_id_seq")
public  class PqSapLogEntity {
    @Id
    @Column(name="PQ_SAP_PRODUCT_LOG_ID")
    @GeneratedValue(generator = "pqSapLogIdGenerator")
    private long id;

    @Column(name="INIT_TMSTP",nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date  initDate;
    
    @Column(name="TABLE_NAME",length = 30,nullable = false)
    private String tableName;

    @Column(name = "TABLE_ID",nullable = false)
    private long tableId;

    @Column(name="MESSAGE",nullable = true,length = 4000,insertable = true, updatable = false)
    private String message;

    @Column(name="CLOSE_TMSTP",nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date closeDate;

    @Column(name="STATUS",nullable = false)
    @Enumerated(EnumType.STRING) 
    private PqSapProductLogStatus status;

    @Column(name="PQ_SAP_PROCESS_TYPE",nullable = false)
    @Enumerated(EnumType.STRING)
    private PqSapProcessType processType;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getInitDate() {
        return initDate;
    }

    public void setInitDate(Date initDate) {
        this.initDate = initDate;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public long getTableId() {
        return tableId;
    }

    public void setTableId(long tableId) {
        this.tableId = tableId;
    }

    public Date getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(Date closeDate) {
        this.closeDate = closeDate;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public PqSapProductLogStatus getStatus() {
        return status;
    }

    public void setStatus(PqSapProductLogStatus status) {
        this.status = status;
    }

    public PqSapProcessType getProcessType() {
        return processType;
    }

    public void setProcessType(PqSapProcessType processType) {
        this.processType = processType;
    }
}
