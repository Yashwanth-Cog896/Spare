package com.monsanto.util.service;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 12, 2007
 * Time: 4:48:49 PM
 */
class BasicPostConnectionPreparer implements ConnectionPreparer
{
   public HttpURLConnection prepareConnection(final HttpURLConnection conn) throws IOException {
      conn.setRequestMethod("POST");
      conn.setDoOutput(true);
      conn.setDoInput(true);
      conn.setUseCaches(false);
      return conn;
   }
}