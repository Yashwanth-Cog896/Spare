package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:43:21 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCT", schema = "Midas")
@GenericGenerator(
        name = "midas_generator",
        strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasProductEntity implements Serializable {
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "PRODUCT_ID", precision = 22, scale = 0)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private MidasCropEntity midasCrop;
    @Type(type = "true_false")
    @Column(name = "REF_ACTIVE", nullable = false)
    private boolean refActive;

    @Column(name = "DENOMINATION", nullable = true, length = 255)
    private String denomination;

    @OneToMany(mappedBy = "midasProduct", fetch = FetchType.LAZY)
    private List<MidasProductNameEntity> midasProductNames = new ArrayList<MidasProductNameEntity>();

    @OneToMany(mappedBy = "midasProduct", fetch = FetchType.LAZY)

    private Set<ProductGermplasmEntity> productGermplasms = new HashSet<ProductGermplasmEntity>();

    @OneToMany(mappedBy = "midasProduct", fetch = FetchType.LAZY)
    private Set<FbsCommonProductXrefEntity> fbsCommonProductXrefs = new HashSet<FbsCommonProductXrefEntity>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasCropEntity getMidasCrop() {
        return midasCrop;
    }

    public void setMidasCrop(MidasCropEntity midasCrop) {
        this.midasCrop = midasCrop;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public Set<ProductGermplasmEntity> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(Set<ProductGermplasmEntity> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public List<MidasProductNameEntity> getMidasProductNames() {
        return midasProductNames;
    }

    public void setMidasProductNames(List<MidasProductNameEntity> midasProductNames) {
        this.midasProductNames = midasProductNames;
    }

    public Set<FbsCommonProductXrefEntity> getFbsCommonProductXrefs() {
        return fbsCommonProductXrefs;
    }

    public void setFbsCommonProductXrefs(Set<FbsCommonProductXrefEntity> fbsCommonProductXrefs) {
        this.fbsCommonProductXrefs = fbsCommonProductXrefs;
    }

    public String getDenomination() {
        return denomination;
    }

    public void setDenomination(String denomination) {
        this.denomination = denomination;
    }
}
