package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ApplicationParameterEntity;
import org.hibernate.criterion.Restrictions;

public class ApplicationParameterDaoImpl extends GenericDaoImpl<ApplicationParameterEntity,Long> implements ApplicationParameterDao{
    public ApplicationParameterDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public String getParameterValue(String key) {
        String env = System.getProperty("lsi.function");
        ApplicationParameterEntity ap = (ApplicationParameterEntity)getSession().createCriteria(ApplicationParameterEntity.class).add(Restrictions.eq("key",env+"."+key)).uniqueResult();
        if(ap==null){
            ap = (ApplicationParameterEntity)getSession().createCriteria(ApplicationParameterEntity.class).add(Restrictions.eq("key",key)).uniqueResult();
        }
        return ap.getValue();
    }
}
