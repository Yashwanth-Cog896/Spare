package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.existingsyncproduct;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ExistingLexLDProdHasNoNonLDStagesRule implements ValidationSimpleRule<Product> {
    LexiconProductDao lexiconProductDao;
    @Override
    public void validate(Product model, ValidationStatus status) {
        if(StringUtils.isNotBlank(model.getProductPubkey())){
            LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(model.getProductPubkey());
            if(lexiconProduct!=null){
                if((lexiconProduct.isLogicalDelete())||hasNonDeletedStages(lexiconProduct)){
                     status.addCondition(new ValidationResult(ProductEditService.DEL_PROD_CONTAINS_NON_LD_STAGES_CODE, ValidationSeverity.ERROR));
                }
            }
        }
    }
    boolean hasNonDeletedStages(LexiconProductEntity lexiconProduct){
        boolean nonDeletedStagesExist = false;
        for(LexiconProductStageEntity stage: lexiconProduct.getLexiconProductStages()){
            if(!stage.isLogicalDelete()){
                nonDeletedStagesExist=true;
                break;
            }
        }
        return nonDeletedStagesExist;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
