/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.business;

import com.monsanto.tps.architecture.security.UserRolesService;
import com.monsanto.tps.architecture.security.common.user.UserProfile;
import com.monsanto.tps.architecture.security.common.user.UserProfileDto;
import org.apache.log4j.Logger;

import java.util.List;

/* vvkalu - 6/30/11 */
public class UserServicesDelegateImpl implements UserServicesDelegate {

    private static final Logger log = Logger.getLogger(UserServicesDelegateImpl.class);
    private UserRolesService userRolesService;

    @Override
    public UserProfile retrieveUserRoles(String userLoginId) {
        try {
            return userRolesService.getUserRoles(userLoginId, "LEXICON");
        } catch (Throwable unfortunately_cannot_make_this_more_specific_exception_type) {
            log.error(unfortunately_cannot_make_this_more_specific_exception_type.getMessage(),
                    unfortunately_cannot_make_this_more_specific_exception_type);
            return null;
        }
    }

    @Override
    public List<UserProfileDto> retrieveUsersRoles(List<String> userLoginIds) {
        try {
            return userRolesService.getUsersRoles(userLoginIds, "LEXICON");
        } catch (Throwable unfortunately_cannot_make_this_more_specific_exception_type) {
            log.error(unfortunately_cannot_make_this_more_specific_exception_type.getMessage(),
                    unfortunately_cannot_make_this_more_specific_exception_type);
            return null;
        }
    }

    public void setUserRolesService(UserRolesService userRolesService) {
        this.userRolesService = userRolesService;
    }
}