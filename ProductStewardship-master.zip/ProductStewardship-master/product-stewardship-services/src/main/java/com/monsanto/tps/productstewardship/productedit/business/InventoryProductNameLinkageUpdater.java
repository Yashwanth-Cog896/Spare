package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.productedit.service.Product;

import java.util.List;

public interface InventoryProductNameLinkageUpdater {
    public void updateNameLinkages(List<Product> product);
}
