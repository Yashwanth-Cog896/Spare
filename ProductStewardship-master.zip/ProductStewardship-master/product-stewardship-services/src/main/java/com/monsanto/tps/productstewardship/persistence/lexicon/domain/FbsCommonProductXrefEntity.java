package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:15:20 PM
 * To change this template use File | Settings | File Templates.
 */
 @Entity
@Table(name = "PRODUCT_XREF", schema = "FBS_COMMON")
public class FbsCommonProductXrefEntity implements Serializable {
    @Id
    @Column(name="LEXICON_PRODUCT_PUBKEY",length = 20)
    String lexiconPubkey;

    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH})
    @JoinColumn(name="midas_product_id")
    private MidasProductEntity midasProduct;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_PUBKEY",referencedColumnName = "PRODUCT_PUBKEY",updatable = false,insertable = false)
    private LexiconProductEntity lexiconProduct;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="LEXICON_PRODUCT_PUBKEY",referencedColumnName = "PRODUCT_PUBKEY",updatable = false,insertable = false)
    private CompetitiveProductEntity competitiveProduct;


    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public MidasProductEntity getMidasProduct() {
        return midasProduct;
    }

    public void setMidasProduct(MidasProductEntity midasProduct) {
        this.midasProduct = midasProduct;
    }

    public LexiconProductEntity getLexiconProduct() {
        return lexiconProduct;
    }

    public void setLexiconProduct(LexiconProductEntity lexiconProduct) {
        this.lexiconProduct = lexiconProduct;
    }

    public CompetitiveProductEntity getCompetitiveProduct() {
        return competitiveProduct;
    }

    public void setCompetitiveProduct(CompetitiveProductEntity competitiveProduct) {
        this.competitiveProduct = competitiveProduct;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || (!getClass().isAssignableFrom(o.getClass()))) return false;

        FbsCommonProductXrefEntity that = (FbsCommonProductXrefEntity) o;

        if (!lexiconPubkey.equals(that.lexiconPubkey)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return lexiconPubkey.hashCode();
    }
}
