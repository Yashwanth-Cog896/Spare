
package com.monsanto.mfg.gqa.lexicon.webservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for productChanged complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="productChanged">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="changeinfo" type="{http://webservice.lexicon.gqa.mfg.monsanto.com/}productChangeInformation" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "productChanged", propOrder = {
    "changeinfo"
})
public class ProductChanged {

    protected ProductChangeInformation changeinfo;

    /**
     * Gets the value of the changeinfo property.
     * 
     * @return
     *     possible object is
     *     {@link ProductChangeInformation }
     *     
     */
    public ProductChangeInformation getChangeinfo() {
        return changeinfo;
    }

    /**
     * Sets the value of the changeinfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductChangeInformation }
     *     
     */
    public void setChangeinfo(ProductChangeInformation value) {
        this.changeinfo = value;
    }

}
