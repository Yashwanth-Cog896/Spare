@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" ,
 xmlns = {
                @javax.xml.bind.annotation.XmlNs(prefix = "wsse",
                   namespaceURI = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd")  ,
          @javax.xml.bind.annotation.XmlNs(prefix = "wsu",
                   namespaceURI = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd")
        }
)
package com.monsanto.osb.webservice.credentials;

