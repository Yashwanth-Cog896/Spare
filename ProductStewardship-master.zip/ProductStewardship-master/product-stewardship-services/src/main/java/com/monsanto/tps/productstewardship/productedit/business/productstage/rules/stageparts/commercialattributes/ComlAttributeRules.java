package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationRulesAggregate;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ComlAttributeRules implements ValidationSimpleRule<StageValidationModel> {
    private LexiconStageDao lexiconStageDao;
    private LexiconProductDao lexiconProductDao;

    private ValidationRulesAggregate<StageValidationModel> rulesWhenActiveNonPreComlParent;
    private ValidationRulesAggregate<StageValidationModel> rulesWhenInactiveOrPreComlParent;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        if(StringUtils.isNotBlank(model.getProductStage().getStageAbbreviation())){
            LexiconStageEntity stage = lexiconStageDao.findStageByAbbreviation(model.getProductStage().getStageAbbreviation());
            if(  model.getProductStage().isActive() && (!isParentProduct(model)||isCommercialStage(stage))){
                rulesWhenActiveNonPreComlParent.validate(model,status);
            }
            else {
                rulesWhenInactiveOrPreComlParent.validate(model,status);
            }
        }
    }

    private boolean isParentProduct(StageValidationModel model) {
        Boolean parentProduct = model.getProduct().getParentProduct();
        if(parentProduct!=null){
            return (parentProduct !=null&& parentProduct.booleanValue());
        }
        else {
            String productPubkey =  model.getProduct().getProductPubkey();
            if(StringUtils.isNotBlank(productPubkey)){
                LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(productPubkey);
                if(lexiconProduct!=null){
                    return lexiconProduct.isParentProduct();
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        }
    }


    private boolean isCommercialStage(LexiconStageEntity stage) {
        return stage!=null&&stage.isCommercial();
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }

    public void setRulesWhenActiveNonPreComlParent(ValidationRulesAggregate<StageValidationModel> rulesWhenActiveNonPreComlParent) {
        this.rulesWhenActiveNonPreComlParent = rulesWhenActiveNonPreComlParent;
    }

    public void setRulesWhenInactiveOrPreComlParent(ValidationRulesAggregate<StageValidationModel> rulesWhenInactiveOrPreComlParent) {
        this.rulesWhenInactiveOrPreComlParent = rulesWhenInactiveOrPreComlParent;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
