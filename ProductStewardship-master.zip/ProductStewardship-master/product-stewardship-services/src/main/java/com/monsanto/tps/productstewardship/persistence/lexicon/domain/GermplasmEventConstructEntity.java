package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name="GERMPLASM_EVENT_CONSTRUCT",schema = "MIDAS")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class GermplasmEventConstructEntity {
    @GeneratedValue(generator = "midas_generator")
    @Id
    @Column(name="GERMPLASM_EVENT_CONSTRUCT_ID")
    private long id;

    @ManyToOne
    @JoinColumn(name = "GERMPLASM_ID",nullable = false)
    private GermplasmEntity germplasm;

    @ManyToOne
    @JoinColumn(name="EVENT_CONSTRUCT_ID", nullable = false)
    private EventConstructEntity eventConstruct;

    public EventConstructEntity getEventConstruct() {
        return eventConstruct;
    }

    public void setEventConstruct(EventConstructEntity eventConstruct) {
        this.eventConstruct = eventConstruct;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
