package com.monsanto.sap.rowcrop.webservice.relationship.sapservicecall;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponseSerializer;
import com.monsanto.util.service.ServiceInvoker;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipInfo;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipSerializer;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * User: pjberry
 * Date: Jul 18, 2007
 * Time: 12:58:56 PM
 */
public class SapRelationshipSyncServiceCall {
    private static final Logger log = Logger.getLogger(SapRelationshipSyncServiceCall.class);

    private final ServiceInvoker serviceInvoker;

    public SapRelationshipSyncServiceCall(ServiceInvoker serviceInvoker) {
        this.serviceInvoker = serviceInvoker;
    }

    public SapSyncResponse call(SapRelationshipInfo info) throws WrappingException {
        Document request = renderRequest(info);
        log.debug("SapRelationshipSyncService Request");
        log.debug(DOMUtil.getXMLString(request));

        Document response = callService(request);
        log.debug("SapRelationshipSyncService Response");
        log.debug(DOMUtil.getXMLString(response));
        return parseResponse(response);
    }

    private Document renderRequest(SapRelationshipInfo info) throws SerializationException {
        SapRelationshipSerializer requestSerializer = new SapRelationshipSerializer();
        return requestSerializer.toDocument(info);
    }

    private Document callService(Document request) throws WrappingException {
        return serviceInvoker.call(request);
    }

    private SapSyncResponse parseResponse(Document response)  throws DeserializationException {
        SapSyncResponseSerializer serializer = new SapSyncResponseSerializer();
        return serializer.fromDocument(response);
    }
}
