package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;

import java.util.List;

public interface MidasProductNameDao extends GenericDao<MidasProductNameEntity,Long>{
   @DynamicDaoMethod(queryName = "MidasProductNameDao.getActiveByBrandAndName",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
               List<MidasProductNameEntity> getActiveByBrandAndName(@DynamicDaoParameter(name="brand") String brand,@DynamicDaoParameter(name="name") String name);

    @DynamicDaoMethod(queryName = "MidasProductNameDao.getByProductBrandCountry",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
                MidasProductNameEntity getByProductBrandCountry(@DynamicDaoParameter(name="midasProductId") long midasProductId,
                                                                      @DynamicDaoParameter(name="midasBrandId") long midasBrandId,
                                                                      @DynamicDaoParameter(name="midasCountryId") long midasCountry);


}
