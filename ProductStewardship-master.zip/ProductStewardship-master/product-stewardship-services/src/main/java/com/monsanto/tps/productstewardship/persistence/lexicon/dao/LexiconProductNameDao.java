package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductNameEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 10:38:59 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductNameDao extends GenericDao<LexiconProductNameEntity,Long> {
      @DynamicDaoMethod(queryName = "LexiconProductNameDao.getByPubkey",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
      LexiconProductNameEntity getByPubkey(@DynamicDaoParameter(name="pubkey") String pubkey);
}
