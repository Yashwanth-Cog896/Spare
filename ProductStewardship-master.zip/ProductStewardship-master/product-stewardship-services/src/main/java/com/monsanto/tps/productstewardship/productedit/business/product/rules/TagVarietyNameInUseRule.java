package com.monsanto.tps.productstewardship.productedit.business.product.rules;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class TagVarietyNameInUseRule  implements ValidationSimpleRule<ProductValidationModel> {
    private LexiconProductDao lexiconProductDao;
    
    @Override
    public void validate(ProductValidationModel model, ValidationStatus status) {
         LexiconProductEntity product = null;
        if(StringUtils.isNotBlank(model.getProduct().getProductPubkey())){
             product = lexiconProductDao.getByPubkey(model.getProduct().getProductPubkey());
        }
        if(doValidateTagVarietyName(product,model.getProduct().getVarietyName())){
            List<String> pubkeys = new ArrayList<String>();
            Product productModel = model.getProduct();
            lexiconProductDao.getByCropAndVarietyName(model.getProduct().getLexiconCropName(), productModel.getVarietyName());
            for(LexiconProductEntity lexiconProduct: lexiconProductDao.getByCropAndVarietyName(productModel.getLexiconCropName(),productModel.getVarietyName()) ){
                if(!lexiconProduct.getPubkey().equals(productModel.getProductPubkey())){
                    pubkeys.add(lexiconProduct.getPubkey());
                }
            }
            if(!pubkeys.isEmpty()){
                  status.addCondition(new ValidationResult(ProductEditService.TAG_VARIETY_NAME_IN_USE_CODE, ValidationSeverity.ERROR));
            }
        }
    }
    private boolean doValidateTagVarietyName(LexiconProductEntity product, String tagVarietyName){
        boolean hasTagVarietyName = StringUtils.isNotBlank(tagVarietyName);
        boolean hasManufacturingName = false;
        if(hasTagVarietyName&&product!=null){
            for(ProductRelationshipXrefEntity xref:product.getLexiconProductRelationshipXrefs()){
                ProductRelationshipEntity relationship = xref.getProductRelationship();
                BaseProductEntity baseProduct = xref.getProductRelationship().getBaseProduct();
                if((!isTrue(relationship.getLogicalDelete()))&&
                    !isTrue(baseProduct.getLogicalDelete())){
                    hasManufacturingName = StringUtils.isNotBlank(relationship.getManufacturingName());
                    if(hasManufacturingName){
                        break;
                    }
                }
            }
        }
        return (!hasManufacturingName)&& hasTagVarietyName;
    }
    private boolean isTrue(Boolean test){
        boolean answer=false;
        if(test!=null){
            answer=test;
        }
        return answer;
    }
    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
