package com.monsanto.sap.rowcrop.webservice.productcountry.sapservicecall;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponseSerializer;
import com.monsanto.sap.rowcrop.webservice.productcountry.SapProductCountryInfo;
import com.monsanto.sap.rowcrop.webservice.productcountry.SapProductCountrySerializer;
import com.monsanto.util.service.ServiceInvoker;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

/**
 * nbwald Jul 13, 2007 12:36:25 PM
 */
public class SapProductCountrySyncServiceCall {
    private static final Logger log = Logger.getLogger(SapProductCountrySyncServiceCall.class);

    private final ServiceInvoker serviceInvoker;

    public SapProductCountrySyncServiceCall(ServiceInvoker serviceInvoker) {
        this.serviceInvoker = serviceInvoker;
    }

    public SapSyncResponse call(SapProductCountryInfo info) throws WrappingException {
        Document request = renderRequest(info);
        log.debug("SapProductCountrySyncServiceCall Request");
        log.debug(DOMUtil.getXMLString(request));

        Document response = callService(request);
        log.debug("SapProductCountrySyncServiceCall Response");
        log.debug(DOMUtil.getXMLString(response));
        return parseResponse(response);
    }

    private Document renderRequest(SapProductCountryInfo info) throws SerializationException {
        SapProductCountrySerializer requestSerializer = new SapProductCountrySerializer();
        return requestSerializer.toDocument(info);
    }

    private Document callService(Document request) throws WrappingException {
        return serviceInvoker.call(request);
    }

    private SapSyncResponse parseResponse(Document response) throws DeserializationException {
        SapSyncResponseSerializer serializer = new SapSyncResponseSerializer();
        return serializer.fromDocument(response);
    }
}