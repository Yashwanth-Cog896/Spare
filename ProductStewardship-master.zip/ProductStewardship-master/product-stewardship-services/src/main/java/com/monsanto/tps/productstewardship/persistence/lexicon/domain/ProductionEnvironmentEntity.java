package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:29:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "productionEnvironmentIdGenerator",allocationSize = 1,sequenceName = "Lexicon.PRODUCTION_ENVIRONMENT_ID_SEQ")
@Table(name = "PRODUCTION_ENVIRONMENT", schema = "Lexicon")
public class ProductionEnvironmentEntity  implements Serializable {
    @Id
    @Column(name="PRODUCTION_ENVIRONMENT_ID")
    @GeneratedValue(generator = "productionEnvironmentIdGenerator")
    private long id;
    @Column(name="PRODUCTION_ENVIRONMENT_NAME",nullable = false, length = 50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name="LOGICAL_DELETE",nullable = false)
    private boolean logicalDelete;
    @Column(name="PRODUCTION_ENVIRONMENT_CODE",nullable = false,length=10)
    private String code;
    @Column(name="PRODUCTION_ENVIRONMENT_PUBKEY",nullable = false, length=20)
    private String pubkey;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
