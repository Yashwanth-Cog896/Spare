package com.monsanto.sap.vegetable.webservice.country;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for YmmvegcntryStr complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="YmmvegcntryStr">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="YyproductKey" type="{urn:sap-com:document:sap:rfc:functions}char20"/>
 *         &lt;element name="YyexceptionKey" type="{urn:sap-com:document:sap:rfc:functions}numeric20"/>
 *         &lt;element name="Yycountry" type="{urn:sap-com:document:sap:rfc:functions}char3"/>
 *         &lt;element name="YyvarietyName" type="{urn:sap-com:document:sap:rfc:functions}char30"/>
 *         &lt;element name="Yyerror" type="{urn:sap-com:document:sap:rfc:functions}char6"/>
 *         &lt;element name="Yyid" type="{urn:sap-com:document:sap:rfc:functions}char20"/>
 *         &lt;element name="Yydesc" type="{urn:sap-com:document:sap:rfc:functions}char132"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "YmmvegcntryStr", propOrder = {
    "yyproductKey",
    "yyexceptionKey",
    "yycountry",
    "yyvarietyName",
    "yyerror",
    "yyid",
    "yydesc"
})
public class YmmvegcntryStr {

    @XmlElement(name = "YyproductKey", required = true)
    protected String yyproductKey;
    @XmlElement(name = "YyexceptionKey", required = true)
    protected String yyexceptionKey;
    @XmlElement(name = "Yycountry", required = true)
    protected String yycountry;
    @XmlElement(name = "YyvarietyName", required = true)
    protected String yyvarietyName;
    @XmlElement(name = "Yyerror", required = true)
    protected String yyerror;
    @XmlElement(name = "Yyid", required = true)
    protected String yyid;
    @XmlElement(name = "Yydesc", required = true)
    protected String yydesc;

    /**
     * Gets the value of the yyproductKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYyproductKey() {
        return yyproductKey;
    }

    /**
     * Sets the value of the yyproductKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYyproductKey(String value) {
        this.yyproductKey = value;
    }

    /**
     * Gets the value of the yyexceptionKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYyexceptionKey() {
        return yyexceptionKey;
    }

    /**
     * Sets the value of the yyexceptionKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYyexceptionKey(String value) {
        this.yyexceptionKey = value;
    }

    /**
     * Gets the value of the yycountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYycountry() {
        return yycountry;
    }

    /**
     * Sets the value of the yycountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYycountry(String value) {
        this.yycountry = value;
    }

    /**
     * Gets the value of the yyvarietyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYyvarietyName() {
        return yyvarietyName;
    }

    /**
     * Sets the value of the yyvarietyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYyvarietyName(String value) {
        this.yyvarietyName = value;
    }

    /**
     * Gets the value of the yyerror property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYyerror() {
        return yyerror;
    }

    /**
     * Sets the value of the yyerror property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYyerror(String value) {
        this.yyerror = value;
    }

    /**
     * Gets the value of the yyid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYyid() {
        return yyid;
    }

    /**
     * Sets the value of the yyid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYyid(String value) {
        this.yyid = value;
    }

    /**
     * Gets the value of the yydesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYydesc() {
        return yydesc;
    }

    /**
     * Sets the value of the yydesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYydesc(String value) {
        this.yydesc = value;
    }

}
