package com.monsanto.sap.vegetable.webservice.variety;

import com.monsanto.tps.ws.serviceconnection.ServiceUrlResolver;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

/**
 * nbwald - Mar 19, 2010 2:27:56 PM
 */
public class MILexiconVarietyOSBSReqImpl
   implements MILexiconVarietyOSBSReq
{
   private static final String SAP_VARIETYSAVESERVICE = "Sap_VarietySaveService";
   private MILexiconVarietyOSBSReq delegate;
   private final ServiceUrlResolver urlResolver;
   private final Bus bus;

   public MILexiconVarietyOSBSReqImpl(ServiceUrlResolver urlResolver, Bus bus) {
      this.urlResolver = urlResolver;
      this.bus = bus;
   }

   @Override
   public DTLexiconVarietyRsp miLexiconVarietyOSBSReq(DTLexiconVarietyReq mtLexiconVarietyOSBReq) {
      if (delegate == null ) {
         JaxWsProxyFactoryBean bean = new JaxWsProxyFactoryBean();
         bean.setAddress(urlResolver.getServiceUrlString(SAP_VARIETYSAVESERVICE));
         bean.setServiceClass(MILexiconVarietyOSBSReq.class);
         bean.setBus(bus);

         delegate = (MILexiconVarietyOSBSReq) bean.create();
      }
      return delegate.miLexiconVarietyOSBSReq(mtLexiconVarietyOSBReq);
   }
}
