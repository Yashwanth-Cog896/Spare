package com.monsanto.sap.rowcrop.webservice.relationship.sapservicecall;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipInfo;


/**
 * User: pjberry
 * Date: Jul 18, 2007
 * Time: 12:13:13 PM
 */
public interface SapRelationshipService {
   SapSyncResponse synSap(SapRelationshipInfo relationshipInfo) throws WrappingException;

}
