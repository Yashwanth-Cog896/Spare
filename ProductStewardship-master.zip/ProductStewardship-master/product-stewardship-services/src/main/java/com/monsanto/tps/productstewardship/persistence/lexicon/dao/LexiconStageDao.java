package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 8/17/11
 * Time: 12:54 PM
 */
public interface LexiconStageDao extends GenericDao <LexiconStageEntity, Long>{

    @DynamicDaoMethod(queryName = "findStageByAbbreviation",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    LexiconStageEntity findStageByAbbreviation(@DynamicDaoParameter(name="abbreviation") String abbreviation);

}
