/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.business;

import com.google.common.collect.Lists;
import com.monsanto.tps.architecture.security.common.user.ContextPrivilege;
import com.monsanto.tps.architecture.security.common.user.ContextPrivilegeDto;
import com.monsanto.tps.architecture.security.common.user.UserProfile;
import com.monsanto.tps.architecture.security.common.user.UserProfileDto;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconCropDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.transfer.UserCrops;
import com.monsanto.tps.productstewardship.user.filter.AuthorizedCropContextFilter;
import com.monsanto.tps.productstewardship.user.filter.ContextFilter;
import com.monsanto.tps.productstewardship.user.filter.RoleContextFilter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* vvkalu - 6/30/11 */
public class UserServicesBusiness {

    private UserServicesDelegate userServicesDelegate;
    private LexiconCropDao lexiconCropDao;

    public List<String> retrieveUserCrops(String userLoginId, AuthorizedCropContextFilter authorizedCropContextFilter) {
        UserProfile userProfile = userServicesDelegate.retrieveUserRoles(userLoginId);
        List<String> userRoleNames =
                (userProfile != null) ? filterContextPrivileges(authorizedCropContextFilter, userProfile.getUserContextPrivilegeList())
                        : new ArrayList<String>();
        return getUserCrops(userRoleNames);
    }

    public List<UserCrops> retrieveUsersCrops(List<String> userLoginIds, AuthorizedCropContextFilter authorizedCropContextFilter) {
        List<UserProfileDto> userProfileDtoList = getUsersProfile(userLoginIds);
        List<UserCrops> userCropsList = Lists.newArrayList();

        if (null != userProfileDtoList) {
            for (UserProfileDto userProfileDto : userProfileDtoList) {
                UserCrops userCrops = new UserCrops();
                userCrops.setUserLoginId(userProfileDto.getUserName());
                userCrops.setAuthorizedCropPubkeys(getUserCrops(filterContextPrivileges(authorizedCropContextFilter, userProfileDto.getUserContextPrivilegeDtoList())));
                userCropsList.add(userCrops);
            }
        }
        return userCropsList;
    }

    private List<String> filterContextPrivileges(AuthorizedCropContextFilter filter, List<ContextPrivilegeDto> userContextPrivilegeDtoList) {
        Set<String> filteredContexts = new HashSet<String>();
        if(userContextPrivilegeDtoList != null) {
            for (ContextPrivilegeDto contextPrivilege : userContextPrivilegeDtoList) {
                String context = contextPrivilege.getContext();
                if (filter.appliesTo(context)) {
                    filteredContexts.add(filter.parse(context));
                }
            }
        }
        return new ArrayList<String>(filteredContexts);
    }

    public List<String> retrieveUserRoles(String userLoginId, RoleContextFilter roleContextFilter) {
        UserProfile userProfile = userServicesDelegate.retrieveUserRoles(userLoginId);
        return (userProfile != null) ? filterContextPrivileges(roleContextFilter, userProfile.getUserContextPrivilegeList())
                : new ArrayList<String>();
    }

    private List<UserProfileDto> getUsersProfile(List<String> userLoginIds) {
        return userServicesDelegate.retrieveUsersRoles(userLoginIds);
    }

    private List<String> filterContextPrivileges(ContextFilter filter, List<ContextPrivilege> contextPrivileges) {
        Set<String> filteredContexts = new HashSet<String>();
        String context;
        for (ContextPrivilege contextPrivilege : contextPrivileges) {
            context = contextPrivilege.getContext();
            if (filter.appliesTo(context)) {
                filteredContexts.add(filter.parse(context));
            }
        }
        return new ArrayList<String>(filteredContexts);
    }

    private List<String> getUserCrops(List<String> userRoleNames) {
        return userRoleNames.isEmpty() ? new ArrayList<String>() :
                hasAllCropRole(userRoleNames) ? gatherAllCropPubkeys() : gatherCropPubkeysThatMatchRoles(userRoleNames);
    }

    private List<String> gatherCropPubkeysThatMatchRoles(List<String> userRoleNames) {
        return extractCropPubkeys(lexiconCropDao.retrieveUserCrops(userRoleNames));
    }

    private List<String> extractCropPubkeys(List<LexiconCropEntity> lexiconCropEntities) {
        List<String> cropPubkeys = Lists.newArrayList();
        if (lexiconCropEntities != null) {
            for (LexiconCropEntity lexiconCropEntity : lexiconCropEntities) {
                cropPubkeys.add(lexiconCropEntity.getPubkey());
            }
        }
        return cropPubkeys;
    }

    private boolean hasAllCropRole(List<String> cropRoleNames) {
        for (String cropRoleName : cropRoleNames) {
            if ("ALL".equalsIgnoreCase(cropRoleName)) {
                return true;
            }
        }
        return false;
    }

    private List<String> gatherAllCropPubkeys() {
        return extractCropPubkeys(lexiconCropDao.loadAll());
    }

    public void setUserServicesDelegate(UserServicesDelegate userServicesDelegate) {
        this.userServicesDelegate = userServicesDelegate;
    }

    public void setLexiconCropDao(LexiconCropDao lexiconCropDao) {
        this.lexiconCropDao = lexiconCropDao;
    }
}