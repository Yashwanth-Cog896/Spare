package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.monsanto.sap.vegetable.webservice.exception.DTLexiconExceptionNamesReq;
import com.monsanto.tps.lexicon.blendedproduct.transfer.BlendedComponentPreComlProduct;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexProductGermplasmDetails;
import com.monsanto.tps.productstewardship.blend.business.BlendedProductGermplasmBusiness;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;


import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ProductStageExceptionNameBuilder {
    public static final String PRIMARY = "1";
    public static final String SECONDARY = "2";
    public static final String DEFAULT_SEMIMATERIAL_CODE = "0";
    public static final String DEFAULT_RESTRICT_CODE = "0000000000";
    public static final String DEFAULT_BLEND_PERCENT = "00";
    private LexiconProductDao lexiconProductDao;

    public DTLexiconExceptionNamesReq.ExceptionNames build(LexiconProductStageEntity productStage, LexBlendedProductDetails blendedComponents) {
        if (blendedComponents == null || blendedComponents.getComponentProductGermplasms().isEmpty()) {
            return buildNonBlended(productStage);
        } else {
            return buildBlended(productStage, blendedComponents);
        }
    }

    private DTLexiconExceptionNamesReq.ExceptionNames buildBlended(LexiconProductStageEntity productStage,
                                                                   LexBlendedProductDetails components) {
        LexProductGermplasmDetails lowestComponentProductGermplasm = null;
        LexProductGermplasmDetails highestComponentProductGermplasm = null;
        for (LexProductGermplasmDetails lexComponentProductGermplasm : components.getComponentProductGermplasms()) {
            if ((lowestComponentProductGermplasm == null) ||
                lowestComponentProductGermplasm.getBlendPercent() > lexComponentProductGermplasm.getBlendPercent()) {
                highestComponentProductGermplasm = lowestComponentProductGermplasm;
                lowestComponentProductGermplasm = lexComponentProductGermplasm;
            } else {
                highestComponentProductGermplasm = lexComponentProductGermplasm;
            }
        }
        DTLexiconExceptionNamesReq.ExceptionNames exceptionNames = null;
        String blenderCode = getBlenderCode(productStage, lowestComponentProductGermplasm);
        if (blenderCode != null) {
            exceptionNames = new DTLexiconExceptionNamesReq.ExceptionNames();
            exceptionNames.setBlenderCode(blenderCode);
            exceptionNames.setDisplaySequenceNumber(SECONDARY);
            exceptionNames.setBlendPercent(highestComponentProductGermplasm.getBlendPercent().toString());
            assignCommonExceptionNamesFields(productStage,  exceptionNames);
        }
        return exceptionNames;
    }

    private String getBlenderCode(LexiconProductStageEntity productStage, LexProductGermplasmDetails lowestComponentProductGermplasm) {
        String blenderCode = null;
        BlendedComponentPreComlProduct lowPreComlProduct = getPreComlProduct(lowestComponentProductGermplasm);
        if (lowPreComlProduct != null) {
            LexiconProductEntity lexiconProduct = lexiconProductDao.getByPubkey(lowPreComlProduct.getLexiconProductPubkey());
            blenderCode = lexiconProduct.getExceptionCode().getExceptionCode();
        }
        return blenderCode;
    }

    private DTLexiconExceptionNamesReq.ExceptionNames buildNonBlended(LexiconProductStageEntity productStage) {
        DTLexiconExceptionNamesReq.ExceptionNames exceptionNames = new DTLexiconExceptionNamesReq.ExceptionNames();
        exceptionNames.setDisplaySequenceNumber(productStage.getExceptionCode().isPrimary()?PRIMARY:SECONDARY);
        exceptionNames.setBlenderCode(null);
        exceptionNames.setBlendPercent(DEFAULT_BLEND_PERCENT);
        assignCommonExceptionNamesFields(productStage,  exceptionNames);
        return exceptionNames;
    }

    private void assignCommonExceptionNamesFields(LexiconProductStageEntity productStage,
                                                  DTLexiconExceptionNamesReq.ExceptionNames exceptionNames) {
        ExceptionCodeEntity exceptionCode = productStage.getExceptionCode();
        exceptionNames.setExceptionCode(exceptionCode.getExceptionCode());
        exceptionNames.setExceptionName(exceptionCode.getProductName());
        exceptionNames.setProductCode(productStage.getLexiconProduct().getPubkey());
        exceptionNames.setPrimaryBrand(productStage.getLexiconBrand().getPubkey());
        exceptionNames.setSemiMaterialCode(DEFAULT_SEMIMATERIAL_CODE);
        exceptionNames.setRestrictCode(DEFAULT_RESTRICT_CODE);
        exceptionNames.setPhaseCode(productStage.getLexiconStage().getPubkey());
        exceptionNames.setPhaseSequence(null);
        exceptionNames.setQualityLevel(null);
    }

    private BlendedComponentPreComlProduct getPreComlProduct(LexProductGermplasmDetails lowestComponentProductGermplasm) {
        BlendedComponentPreComlProduct retval = null;
        if (!lowestComponentProductGermplasm.getPreComlProduct().isEmpty()) {
            retval = lowestComponentProductGermplasm.getPreComlProduct().get(0);
        }
        return retval;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }
}
