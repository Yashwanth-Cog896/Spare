package com.monsanto.tps.productstewardship.authorization;

import com.monsanto.tps.authentication.UserRole;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 2, 2011
 * Time: 3:34:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconUserRoleProvider {
    public boolean hasRole(String roleName);
      public List<UserRole> getRoles();
}
