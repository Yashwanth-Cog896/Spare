package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Sep 1, 2011
 * Time: 9:10:13 AM
 * To change this template use File | Settings | File Templates.
 */
public enum PqSapProcessType {
    SAP,
    GQA

}
