package com.monsanto.sap.rowcrop.webservice.productcountry.sapservicecall;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.productcountry.SapProductCountryInfo;

/**
 * nbwald Jul 12, 2007 2:20:55 PM
 */
public interface SapProductCountryService {
   SapSyncResponse syncSap(SapProductCountryInfo productCountryInfo)  throws WrappingException;
}