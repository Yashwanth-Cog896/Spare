/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;

import java.util.List;

/* vvkalu - 7/11/11 */
public interface BaseProductDao extends GenericDao<BaseProductEntity,Long> {

    //TODO: rename gets to finds
    @DynamicDaoMethod(queryName = "findBaseProductsByBaseManfName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<BaseProductEntity> findBaseProductsByBaseManfName(@DynamicDaoParameter(name = "requestId") Long requestId,
            @DynamicDaoParameter(name = "cropPubkeys") List<String> cropPubkeys);

    @DynamicDaoMethod(queryName = "findBaseProductsByManfName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<BaseProductEntity> findBaseProductsByManfName(@DynamicDaoParameter(name = "requestId") Long requestId,
            @DynamicDaoParameter(name = "cropPubkeys") List<String> cropPubkeys);

    @DynamicDaoMethod(queryName = "BaseProductEntity.getByManufacturingName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    BaseProductEntity getByManfName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);

    @DynamicDaoMethod(queryName = "BaseProductEntity.getBaseProductsNotDeletedByManufacturingName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    BaseProductEntity getBaseProductsNotDeletedByManufacturingName(@DynamicDaoParameter(name = "manufacturingName") String manufacturingName);
}