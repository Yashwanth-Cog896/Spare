package com.monsanto.tps.productstewardship.sap.business.rowcrop.relationship;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconTempSessionOcdDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductSubscriptionEntity;
import com.monsanto.tps.productstewardship.sap.business.rowcrop.SapRowCropResponseHandler;


import java.util.*;
import java.util.Collection;
import java.util.Set;

public class LexiconRelationshipFlow {
  private static final int REQUEST_ID_BASE = 20120222;
  private ProductRelationshipDao productRelationshipDao;
  private LexiconTempSessionOcdDao lexiconTempSessionOcdDao;
  private SapRowCropResponseHandler sapRowCropResponseHandler;
  private SapRelationshipServiceDelegate sapRelationshipServiceDelegate;

  public List<PqSapQueueEntryEntity> flowProducts(List<PqSapQueueEntryEntity> pqSapQueueEntries){
     List<PqSapQueueEntryEntity> processedQueueEntries = new ArrayList<PqSapQueueEntryEntity>();
     if (!pqSapQueueEntries.isEmpty()){
       Multimap<Long,PqSapQueueEntryEntity> relationshipMap = createRelationshipMap(pqSapQueueEntries);
       List<ProductRelationshipEntity> relationshipsToProcess = retrieveRelationshipToProcess(relationshipMap.keySet());
       List<SapSyncResponse> responses =  flowToSap(relationshipsToProcess);
       processUnmatchedRelationship(pqSapQueueEntries,relationshipsToProcess,relationshipMap);
       processedQueueEntries = sapRowCropResponseHandler.processResponses(responses, pqSapQueueEntries, relationshipMap);
     }
     return processedQueueEntries;
  }

  private List<SapSyncResponse> flowToSap(List<ProductRelationshipEntity> relationshipsToProcess) {
    List<SapSyncResponse> responses = new ArrayList<SapSyncResponse>();
    if (!relationshipsToProcess.isEmpty()){
       responses = sapRelationshipServiceDelegate.flowToSap(relationshipsToProcess);
    }
    return responses;
  }

  private List<ProductRelationshipEntity> retrieveRelationshipToProcess(Set<Long> relationshipIds) {
      //todo
      long requestId = REQUEST_ID_BASE;
      lexiconTempSessionOcdDao.insertNumberValues(requestId,relationshipIds);
      return productRelationshipDao.findSubscribedProductRelationships(requestId, ProductSubscriptionEntity.SAP);
  }

  private Multimap<Long, PqSapQueueEntryEntity> createRelationshipMap(List<PqSapQueueEntryEntity> pqSapQueueEntries) {
    Multimap<Long, PqSapQueueEntryEntity> relationshipMap = ArrayListMultimap.create();
    for (PqSapQueueEntryEntity pqSapQueueEntry:pqSapQueueEntries){
      if (PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP.equals(pqSapQueueEntry.getTableName())) {
         relationshipMap.put(pqSapQueueEntry.getTableId(), pqSapQueueEntry);
      }
    }
    return relationshipMap;
  }

  private void processUnmatchedRelationship(List<PqSapQueueEntryEntity> pqSapQueueEntries, List<ProductRelationshipEntity> relationshipsToProcess, Multimap<Long, PqSapQueueEntryEntity> relationshipMap) {
    List<Long> relationshipIds = getUnprocessedRelationshipIds(relationshipsToProcess, relationshipMap);
    for (Long relationshipId:relationshipIds){
      Collection<PqSapQueueEntryEntity> queueEntriesToRemove = relationshipMap.get(relationshipId);
      pqSapQueueEntries.removeAll(queueEntriesToRemove);
      sapRowCropResponseHandler.removeQueueEntries(queueEntriesToRemove);
    }
  }

  private List<Long> getUnprocessedRelationshipIds(List<ProductRelationshipEntity> relationshipsToProcess, Multimap<Long, PqSapQueueEntryEntity> relationshipMap) {
    List<Long> unprocessedRelationships = new ArrayList(relationshipMap.keySet());
    List<Long> processedRelationships = getRelationshipIds(relationshipsToProcess);
    unprocessedRelationships.removeAll(processedRelationships);
    return unprocessedRelationships;
  }

  private List<Long> getRelationshipIds(List<ProductRelationshipEntity> relationships){
    List<Long> relationshipIds = new ArrayList<Long>();
    for (ProductRelationshipEntity relationship:relationships){
       relationshipIds.add(relationship.getId());
    }
    return relationshipIds;
  }

  public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
    this.productRelationshipDao = productRelationshipDao;
  }

  public void setLexiconTempSessionOcdDao(LexiconTempSessionOcdDao lexiconTempSessionOcdDao) {
    this.lexiconTempSessionOcdDao = lexiconTempSessionOcdDao;
  }

  public void setSapRowCropResponseHandler(SapRowCropResponseHandler sapRowCropResponseHandler) {
    this.sapRowCropResponseHandler = sapRowCropResponseHandler;
  }

  public void setSapRelationshipServiceDelegate(SapRelationshipServiceDelegate sapRelationshipServiceDelegate) {
    this.sapRelationshipServiceDelegate = sapRelationshipServiceDelegate;
  }
}
