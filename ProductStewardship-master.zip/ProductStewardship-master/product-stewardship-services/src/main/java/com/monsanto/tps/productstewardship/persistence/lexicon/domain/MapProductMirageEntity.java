package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "MAP_PRODUCT_MIRAGE", schema = "YLDSTG")
public class MapProductMirageEntity implements Serializable {

    @Id
    private long id;

    @MapsId
    @OneToOne
    @JoinColumn(name="SEED_PRODUCT_ID")
    private MirageSeedProductEntity mirageSeedProduct;

    @ManyToOne
    @JoinColumn(name="PRODUCT_PK",nullable = true)
    private MidasProductEntity midasProduct;
    
    @ManyToOne
    @JoinColumn(name="GENETIC_MATERIAL_PK", nullable = true)
    private GeneticMaterialEntity geneticMaterial;
    
    @Column(name = "MIRAGE_NAME",nullable = true,length = 255)
    private String mirageName;

    @Column(name= "OLD_BRAND_NAME",nullable = true, length=80)
    private String oldBrandName;

    public GeneticMaterialEntity getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterialEntity geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public MidasProductEntity getMidasProduct() {
        return midasProduct;
    }

    public void setMidasProduct(MidasProductEntity midasProduct) {
        this.midasProduct = midasProduct;
    }

    public String getMirageName() {
        return mirageName;
    }

    public void setMirageName(String mirageName) {
        this.mirageName = mirageName;
    }

    public MirageSeedProductEntity getMirageSeedProduct() {
        return mirageSeedProduct;
    }

    public void setMirageSeedProduct(MirageSeedProductEntity mirageSeedProduct) {
        this.mirageSeedProduct = mirageSeedProduct;
    }

    public String getOldBrandName() {
        return oldBrandName;
    }

    public void setOldBrandName(String oldBrandName) {
        this.oldBrandName = oldBrandName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
