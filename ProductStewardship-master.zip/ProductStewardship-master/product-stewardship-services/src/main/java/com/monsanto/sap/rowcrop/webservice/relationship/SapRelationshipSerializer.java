package com.monsanto.sap.rowcrop.webservice.relationship;

import com.monsanto.sap.rowcrop.webservice.BasicSerializer;
import com.monsanto.sap.rowcrop.webservice.SapLinkageSchemaConsts;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

public class SapRelationshipSerializer  extends BasicSerializer<SapRelationshipInfo> {
  private static final String RELATIONSHIP = "relationship";
  private static final String SAP_LINKAGE_AUDIT_ID = "sapLinkageAuditId";

  public void registerMappings(final XmlSerializerBuilder serializerBuilder) {
      serializerBuilder.registerMapping(SapLinkageSchemaConsts.NAMESPACE, RELATIONSHIP, SapRelationshipInfo.class);
      serializerBuilder.registerAttributeMapping(SapRelationshipInfo.class, SAP_LINKAGE_AUDIT_ID);
   }
}