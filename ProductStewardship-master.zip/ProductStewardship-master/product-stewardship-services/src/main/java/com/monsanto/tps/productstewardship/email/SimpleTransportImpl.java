package com.monsanto.tps.productstewardship.email;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;

/**
 * User: PJBERRY
 * Date: Oct 1, 2007
 * Time: 10:27:26 AM
 */
public class SimpleTransportImpl
   implements SimpleTransport
{
   public void send(Message message)
      throws MessagingException
   {
      Transport.send(message);
   }
}
