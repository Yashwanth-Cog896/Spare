package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 10:43:01 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductSearchCriteriaBuilder {
    public DetachedCriteria buildProductSearchCriteria(Session session, List<String> cropPubkeys, LexiconProductSearchCriteria searchCriteria);
    public DetachedCriteria buildProductSearchCriteriaOrdered(Session session, List<String> cropPubkeys, LexiconProductSearchCriteria searchCriteria);
    public DetachedCriteria buildProductStageSearchCriteria(Session session,List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria);
    public DetachedCriteria buildProductStageSearchCriteriaOrdered(Session session,List<String> cropPubkeys,LexiconProductSearchCriteria searchCriteria);
}
