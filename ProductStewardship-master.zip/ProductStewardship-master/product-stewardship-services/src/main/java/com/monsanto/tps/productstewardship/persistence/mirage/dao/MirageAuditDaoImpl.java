package com.monsanto.tps.productstewardship.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageAuditEntity;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 15, 2011
 * Time: 10:52:17 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageAuditDaoImpl extends GenericDaoImpl<MirageAuditEntity,Long> implements MirageAuditDao {
    public static final String AUDIT_USER = "product-stewardship";
    public MirageAuditDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public MirageAuditEntity createAudit(String auditEvent){
        MirageAuditEntity audit = new MirageAuditEntity();
        audit.setDate(new Date());
        audit.setUser(AUDIT_USER);
        audit.setClient(AUDIT_USER);
        audit.setEvent(auditEvent);
        audit.setEventRemark(auditEvent);
        audit.setEventTag(auditEvent);
        this.saveOrUpdate(audit);
        return audit;
    }

}
