package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

import java.util.*;

public class RequestedTraitVersUniqueForExistingManfAndNewLexProdRule implements ValidationSimpleRule<Product>
{
  private LexiconProductDao lexiconProductDao;
  private ProductRelationshipDao productRelationshipDao;

  @Override
  public void validate(Product model, ValidationStatus status) {
    if ((!isExistingLexiconProduct(model.getPreCommercialName()))&& (model.getManufacturingName() != null))
    {
      ProductRelationshipEntity existingProductRelationship = productRelationshipDao.getByManufacturingName(model.getManufacturingName());
      String traitVer = model.getTraitVersion();
      if ((existingProductRelationship != null) && (!StringUtils.isNullOrEmpty(traitVer))){
        List<ProductRelationshipXrefEntity> existingProductRelationshipXrefs = existingProductRelationship.getProductRelationshipXRefs();
        for (ProductRelationshipXrefEntity productRelationship:existingProductRelationshipXrefs){
          if (traitVer.equals(productRelationship.getTraitVersion())) {
            status.addCondition(new ValidationResult(ProductEditService.TRAIT_VERS_EXISTS_CODE, ValidationSeverity.ERROR));
            return;
          }
        }
      }
    }
  }

  private boolean isExistingLexiconProduct(String preComlName){
    LexiconProductEntity existingProduct = (preComlName== null)?null:lexiconProductDao.getByPreCommercialName(preComlName);
    if ((existingProduct == null) ||(existingProduct.isLogicalDelete())){
       return false;
    } else {
       return true;
    }
  }


  public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
    this.lexiconProductDao = lexiconProductDao;
  }

  public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
    this.productRelationshipDao = productRelationshipDao;
  }
}
