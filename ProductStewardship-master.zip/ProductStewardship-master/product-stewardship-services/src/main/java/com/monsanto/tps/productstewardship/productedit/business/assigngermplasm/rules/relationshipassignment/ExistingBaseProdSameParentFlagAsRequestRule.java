package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class ExistingBaseProdSameParentFlagAsRequestRule implements ValidationSimpleRule<Product> {

  private BaseProductDao baseProductDao;
  @Override
  public void validate(Product model, ValidationStatus status) {
    BaseProductEntity existingBaseProduct = baseProductDao.getBaseProductsNotDeletedByManufacturingName(model.getManufacturingName());
     if (existingBaseProduct!=null) {
          if (existingBaseProduct.getParentProduct() != model.getParentProduct()) {
                status.addCondition(new ValidationResult(ProductEditService.REQUESTED_PARENT_FLAG_DIFFERS_FROM_BASE_PRODUCTS, ValidationSeverity.ERROR));
          }
     }
  }

  public void setBaseProductDao(BaseProductDao baseProductDao) {
    this.baseProductDao = baseProductDao;
  }
}
