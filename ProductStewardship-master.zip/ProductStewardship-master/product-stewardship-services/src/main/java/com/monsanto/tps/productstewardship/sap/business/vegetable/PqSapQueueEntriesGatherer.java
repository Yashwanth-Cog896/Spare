package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.google.common.collect.SetMultimap;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.PqSapQueueEntryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import org.hibernate.exception.LockAcquisitionException;

import java.util.List;
import java.util.Set;

public class PqSapQueueEntriesGatherer {
    private PqSapQueueEntryDao pqSapQueueEntryDao;
    private PqSapQueueEntryProductRetriever pqSapQueueEntryProductRetriever;
    public void gatherProductsToProcessFromQueueEntry(List<Long> pqSapQueueEntryIds, SetMultimap<String, PqSapQueueEntryEntity> productPubkeyToPqSapQueueEntries, Set<LexiconProductEntity> productsToProcess, List<PqSapQueueEntryEntity> pqSapQueueEntriesToProcess) {
        for (Long pqSapQueueEntryId : pqSapQueueEntryIds) {
            try {
                PqSapQueueEntryEntity pqSapQueueEntry = pqSapQueueEntryDao.retrieveForUpdateAndLock(pqSapQueueEntryId);
                if (pqSapQueueEntry != null) {
                    List<LexiconProductEntity> lexiconProducts = pqSapQueueEntryProductRetriever.retrieveLexiconProducts(pqSapQueueEntry);
                    if (!lexiconProducts.isEmpty()) {
                        productsToProcess.addAll(lexiconProducts);
                        pqSapQueueEntriesToProcess.add(pqSapQueueEntry);
                        for (LexiconProductEntity lexiconProduct : lexiconProducts) {
                            productPubkeyToPqSapQueueEntries.put(lexiconProduct.getPubkey(), pqSapQueueEntry);
                        }
                    } else {
                        pqSapQueueEntryDao.delete(pqSapQueueEntry);
                    }
                }
            }
            catch (LockAcquisitionException lockAcquisitionException) {
                //Ignore this, because  lockAcquisitionException is due to concurrent access issues. Not really a problem.
            }
        }
    }

    public void setPqSapQueueEntryDao(PqSapQueueEntryDao pqSapQueueEntryDao) {
        this.pqSapQueueEntryDao = pqSapQueueEntryDao;
    }

    public void setPqSapQueueEntryProductRetriever(PqSapQueueEntryProductRetriever pqSapQueueEntryProductRetriever) {
        this.pqSapQueueEntryProductRetriever = pqSapQueueEntryProductRetriever;
    }
}
