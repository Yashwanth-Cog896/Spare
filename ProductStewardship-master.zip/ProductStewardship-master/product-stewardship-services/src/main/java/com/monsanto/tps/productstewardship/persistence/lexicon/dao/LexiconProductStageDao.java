package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 14, 2011
 * Time: 1:34:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductStageDao extends GenericDao<LexiconProductStageEntity,Long> {
    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.getByPubkey",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    LexiconProductStageEntity getByPubkey(@DynamicDaoParameter(name="pubkey") String pubkey);
    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.findByMatchingCommercialNames",
                          parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductStageEntity>  findByMatchingCommercialNames(@DynamicDaoParameter(name="commercialName")String commercialName,
                                                             @DynamicDaoParameter(name="productPubkey")String productPubkey);
    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.findBySimilarCommercialNames",
                          parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductStageEntity>  findBySimilarCommercialNames(@DynamicDaoParameter(name="commercialName")String commercialName,
                                                             @DynamicDaoParameter(name="productPubkey")String productPubkey);

    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.findByMatchingProductNames",
                          parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductStageEntity> findByMatchingProductNames(@DynamicDaoParameter(name="productName")String productName,
                                                               @DynamicDaoParameter(name="cropName")String cropName);
    List<LexiconProductStageEntity> findBySearchCriteria(List<String>cropPubkeys,LexiconProductSearchCriteria searchCriteria,int pageSize,int pageNumber);


    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.findByCommercialNameAndCrop",
                          parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductStageEntity> findByCommercialNameAndCrop(@DynamicDaoParameter(name="commercialName")String commercialName, @DynamicDaoParameter(name="cropId")Long lexiconCropId);

    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.getNextPubkey",
                       parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
      public String getNextPubkey();

    int countBySearchCriteria(List<String>cropPubkeys,LexiconProductSearchCriteria searchCriteria) ;

    @DynamicDaoMethod(queryName = "LexiconProductStageEntity.findSubscribedProductStage",
                          parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LexiconProductStageEntity> findSubscribedProductStage(@DynamicDaoParameter(name="requestId")Long requestId, @DynamicDaoParameter(name="externalSystemName")String externalSystemName);

}
