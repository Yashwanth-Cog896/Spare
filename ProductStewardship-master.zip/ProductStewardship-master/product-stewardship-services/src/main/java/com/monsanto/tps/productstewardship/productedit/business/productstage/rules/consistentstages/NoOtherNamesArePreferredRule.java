package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.consistentstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class NoOtherNamesArePreferredRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductDao lexiconProductDao;
  
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean ruleViolated = false;
        ProductStage productStage= model.getProductStage();


        if(productStage.isPreferredName()&&(!productStage.isDelete())){
            for(ProductStage testProductStage: model.getProduct().getProductStages()){
               if((productStage!=testProductStage)&&
                  (!testProductStage.isDelete())&&
                   testProductStage.isPreferredName()){
                      ruleViolated=true;
                      break;
                  }
               }
            if(!ruleViolated){
                for(LexiconProductStageEntity testProductStage: loadLexiconProductStagesNotInRequest(model)){
                   if((!testProductStage.isLogicalDelete())&&(testProductStage.isPreferredName())){
                       ruleViolated=true;
                       break;
                    }
                }
            }
            if(ruleViolated){
                status.addCondition(new ValidationResult(ProductEditService.ONLY_ONE_PREFERRED_NAME_ALLOWED, ValidationSeverity.ERROR));
            }
        }
    }


    private Collection<LexiconProductStageEntity> loadLexiconProductStagesNotInRequest(StageValidationModel model) {
        Map<String,LexiconProductStageEntity> lexiconProductStageMap = new HashMap<String, LexiconProductStageEntity>();
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity lexiconProduct=lexiconProductDao.getByPubkey(productPubkey);
            if(!lexiconProduct.isLogicalDelete()){
                for(LexiconProductStageEntity lexiconProductStage:lexiconProduct.getLexiconProductStages()){
                    if(!lexiconProductStage.isLogicalDelete()){
                       lexiconProductStageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
                    }
                }
                for(ProductStage productStage: model.getProduct().getProductStages()){
                    if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
                        lexiconProductStageMap.remove(productStage.getProductStagePubkey());
                    }
                }
            }
        }
        Collection<LexiconProductStageEntity> lexiconProductStages = lexiconProductStageMap.values();
        return lexiconProductStages;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

}
