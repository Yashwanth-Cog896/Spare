package com.monsanto.sap.rowcrop.webservice;

public interface SapLinkageSchemaConsts
{
   String NAMESPACE = "http://www.monsanto.com/lexicon/SAP";
   String SCHEMA_LOC = "xsd/lexicon/xstream/SapLinkage.xsd";
}
