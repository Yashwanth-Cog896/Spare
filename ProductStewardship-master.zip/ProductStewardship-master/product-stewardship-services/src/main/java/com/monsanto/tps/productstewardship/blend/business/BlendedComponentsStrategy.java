package com.monsanto.tps.productstewardship.blend.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.dataservices.product.transfer.ProductGermplasmDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexProductGermplasmDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 6, 2011
 * Time: 3:53:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlendedComponentsStrategy
        implements BlendedSearchStrategy {

    private LexBlendedProductBuilder lexBlendedProductBuilder;

    @Override
    public Multimap<Long, FbsCommonProductXrefEntity> buildGermplasmIdToProductXrefsMap(Map<Long, FbsCommonProductXrefEntity> xrefByProductIds,
                                                                         BlendedProductDetails productDetails) {
        Multimap<Long, FbsCommonProductXrefEntity> germplasmIdToProductXrefMap = ArrayListMultimap.create();
        for (ProductGermplasmDetails productGermplasm : productDetails.getComponentProductGermplasms()) {
            for (Long productId : productGermplasm.getMidasProductIds()) {
                germplasmIdToProductXrefMap.put(productDetails.getGermplasmId(), xrefByProductIds.get(productId));
            }
        }
        return germplasmIdToProductXrefMap;
    }

    @Override
    public LexBlendedProductDetails buildLexBlendedProductDetails(BlendedProductDetails blendedProductDetail,
                                                                  Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductsMap) {
        LexBlendedProductDetails lexComponent = new LexBlendedProductDetails();
        lexComponent.setBlendedGermplasmId(blendedProductDetail.getGermplasmId());

        List<LexProductGermplasmDetails> productGermplasms = lexBlendedProductBuilder.build(blendedProductDetail.getGermplasmId(),
                blendedProductDetail.getComponentProductGermplasms(),
                germplasmIdToPreComlProductsMap);
        lexComponent.setComponentProductGermplasms(productGermplasms);
        return lexComponent;
    }

    public void setLexBlendedProductBuilder(LexBlendedProductBuilder lexBlendedProductBuilder) {
        this.lexBlendedProductBuilder = lexBlendedProductBuilder;
    }
}
