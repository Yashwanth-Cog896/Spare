/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/* vvkalu - 6/23/11 */
@Entity
@Table(name = "LINE_TYPE", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class LineTypeEntity  implements Serializable {
    public static final String SEGPOP = "SEGPOP";
    public static final String HYBRID = "HYBRID";
    public static final String OP_VAR = "OP_VAR";
    public static final String CODED = "CODED";
    public static final String FINISHED = "FINISHED";

    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name="LINE_TYPE_ID", precision = 22, scale = 0)
    private long id;
    @Column(name="LINE_TYPE_REF_ID",nullable = false, length = 20)
    private String lineTypeRefId;
    @Column(name = "NAME", length = 50, nullable = false)
    private String name;
    @Type(type="true_false")
    @Column(name = "REF_ACTIVE", nullable = false)
    private boolean refActive;
    @Column(name = "PED_ENG_REF_ID", nullable = false, length = 20)
    private String pedEngineRefId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLineTypeRefId() {
        return lineTypeRefId;
    }

    public void setLineTypeRefId(String lineTypeRefId) {
        this.lineTypeRefId = lineTypeRefId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getPedEngineRefId() {
        return pedEngineRefId;
    }

    public void setPedEngineRefId(String pedEngineRefId) {
        this.pedEngineRefId = pedEngineRefId;
    }
}