package com.monsanto.util.service;

import org.w3c.dom.Document;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 12, 2007
 * Time: 12:51:53 PM
 */
public interface RequestStreamer {
   void streamRequest(final Document requestDoc, final OutputStream outputStream) throws IOException;
}
