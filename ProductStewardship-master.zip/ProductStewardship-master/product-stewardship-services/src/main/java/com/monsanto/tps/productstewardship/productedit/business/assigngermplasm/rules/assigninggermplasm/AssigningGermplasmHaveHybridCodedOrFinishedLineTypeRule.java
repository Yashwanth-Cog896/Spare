package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.assigninggermplasm;


import com.monsanto.tps.productstewardship.persistence.lexicon.dao.GermplasmDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LineTypeEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductGermplasm;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

import java.util.*;

public class AssigningGermplasmHaveHybridCodedOrFinishedLineTypeRule implements ValidationSimpleRule<Product>{

  private GermplasmDao germplasmDao;
  private final static List<String> VALID_LINETYPES = Arrays.asList(LineTypeEntity.HYBRID, LineTypeEntity.CODED,LineTypeEntity.FINISHED) ;

  @Override
  public void validate(Product model, ValidationStatus status) {

    if ((model.getAssignedGermplasms()!=null)&& (model.getAssignedGermplasms().size()>0)){
       List<ProductGermplasm>  productGermplasms = model.getAssignedGermplasms();
       for (ProductGermplasm productGermplasm:productGermplasms){
         GermplasmEntity germplasm = germplasmDao.get(productGermplasm.getGermplasmId()) ;
         if (germplasm != null) {
           if (!isValidLineType(germplasm)) {
             status.addCondition(new ValidationResult(ProductEditService.ASSIGNING_GP_INVALID_LINE_TYPE_CODE, ValidationSeverity.ERROR));
           }
         }
       }
    }
  }



  private boolean isValidLineType(GermplasmEntity germplasm) {
      if (!(VALID_LINETYPES.contains(germplasm.getLineType().getLineTypeRefId())))  {
        return false;
      }else {
        return true;
      }
  }


  public void setGermplasmDao(GermplasmDao germplasmDao) {
    this.germplasmDao = germplasmDao;
  }
}
