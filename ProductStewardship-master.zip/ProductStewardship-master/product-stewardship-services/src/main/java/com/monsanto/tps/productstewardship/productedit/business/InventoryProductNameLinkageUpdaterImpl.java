package com.monsanto.tps.productstewardship.productedit.business;


import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.tcc.inventorycommon.service.InventoryProductNameLinkageService;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageRequest;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageResponse;
import com.monsanto.tcc.inventorycommon.transferobject.PreCommercialLinkageResponse;
import com.monsanto.tps.productstewardship.email.EmailParticipants;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconBrandDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class InventoryProductNameLinkageUpdaterImpl implements InventoryProductNameLinkageUpdater {
    private static final org.apache.log4j.Logger log = Logger.getLogger(InventoryProductNameLinkageUpdaterImpl.class);

    private InventoryProductNameLinkageService inventoryProductNameLinkageService;
    private InventoryProductNameLinkageAlarm inventoryProductNameLinkageAlarm;
    private LexiconStageDao lexiconStageDao;
    private LexiconBrandDao lexiconBrandDao;

    @Transactional(readOnly = true)
    public void updateNameLinkages(List<Product> products){
       List<String> preCommercialProductPubkeys = new ArrayList<String>();
       List<CommercialLinkageRequest> commercialLinkageRequests = new ArrayList<CommercialLinkageRequest>();
        for(Product product: products){
            boolean containsPreCommercialStage=false;
            for(ProductStage productStage:product.getProductStages()){
               LexiconStageEntity lexiconStage = lexiconStageDao.findStageByAbbreviation(productStage.getStageAbbreviation());
               if(lexiconStage.isCommercial()){
                  commercialLinkageRequests.add(buildCommercialLinkageRequest(productStage));
               }
               else {
                  containsPreCommercialStage=true;
               }
            }
            if(containsPreCommercialStage){
                preCommercialProductPubkeys.add(product.getProductPubkey());
            }
        }
        updateCommercialInventoryProductNameLinkage(commercialLinkageRequests);
        if(!preCommercialProductPubkeys.isEmpty()){
            updatePreCommercialInventoryProductNameLinkage(preCommercialProductPubkeys);
        }
    }

    private CommercialLinkageRequest buildCommercialLinkageRequest(ProductStage productStage) {
        LexiconBrandEntity lexiconBrand = lexiconBrandDao.getByName(productStage.getBrandName());
        CommercialLinkageRequest commercialLinkageRequest = new CommercialLinkageRequest();
        commercialLinkageRequest.setProductNamePublicKey(productStage.getProductStagePubkey());
        commercialLinkageRequest.setTdRestricted(lexiconBrand.isTechDevRestricted());
        return commercialLinkageRequest;
    }

    private void updatePreCommercialInventoryProductNameLinkage( List<String> productPubkeys) {
        try {
            List<PreCommercialLinkageResponse> preCommercialLinkageResponses = inventoryProductNameLinkageService.updatePreCommercialInventoryProductNameLinkage(productPubkeys);
            boolean hasErrors = false;
            for(  PreCommercialLinkageResponse linkageResponse :preCommercialLinkageResponses){
                if(linkageResponse.getErrorMessages()!=null&&!linkageResponse.getErrorMessages().isEmpty()){
                    hasErrors = true;
                    break;
                }
            }
            if(hasErrors){
                inventoryProductNameLinkageAlarm.raisePrecommercialAlarm(preCommercialLinkageResponses);
            }
        }
        catch (RuntimeException e){
            inventoryProductNameLinkageAlarm.raisePrecommercialAlarm(productPubkeys, e);
        }
    }

    private void updateCommercialInventoryProductNameLinkage(List<CommercialLinkageRequest> commercialLinkageRequests) {
        if(!commercialLinkageRequests.isEmpty()){
            try{
                List<CommercialLinkageResponse> commercialLinkageResponses = inventoryProductNameLinkageService.updateCommercialInventoryProductNameLinkage(commercialLinkageRequests);
                boolean hasErrors = false;
                for(  CommercialLinkageResponse linkageResponse :commercialLinkageResponses){
                    if(linkageResponse.getErrorMessages()!=null&&!linkageResponse.getErrorMessages().isEmpty()){
                        hasErrors = true;
                        break;
                    }
                }
                if(hasErrors){
                    inventoryProductNameLinkageAlarm.raiseCommercialAlarm(commercialLinkageResponses);
                }
            }
            catch(RuntimeException e){
                inventoryProductNameLinkageAlarm.raiseCommercialAlarm(commercialLinkageRequests, e);
            }
        }
    }
    public void setInventoryProductNameLinkageService(InventoryProductNameLinkageService inventoryProductNameLinkageService) {
        this.inventoryProductNameLinkageService = inventoryProductNameLinkageService;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }

    public void setLexiconBrandDao(LexiconBrandDao lexiconBrandDao) {
        this.lexiconBrandDao = lexiconBrandDao;
    }

    public void setInventoryProductNameLinkageAlarm(InventoryProductNameLinkageAlarm inventoryProductNameLinkageAlarm) {
        this.inventoryProductNameLinkageAlarm = inventoryProductNameLinkageAlarm;
    }
}
