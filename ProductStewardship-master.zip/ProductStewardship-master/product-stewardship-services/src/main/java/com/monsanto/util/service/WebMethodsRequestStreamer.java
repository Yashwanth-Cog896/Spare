package com.monsanto.util.service;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: Oct 19, 2010
 * Time: 10:05:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class WebMethodsRequestStreamer implements RequestStreamer {

    private static final String LINE_END = "\r\n";
    private static final int MAX_BUFFER_SIZE = 1024 * 1024;
    private final String requestName;

    WebMethodsRequestStreamer(String requestName) {
        this.requestName = requestName;
    }

    public void streamRequest(final Document requestDoc, final OutputStream outputStream) throws IOException {
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
        try {
            writeHeader(dataOutputStream);
            writeContent(DOMUtil.makeInputStreamFromDocument(requestDoc), dataOutputStream);
        }
        catch (TransformerException e) {
            throw new IOException(e.getMessage(), e);
        }
        finally {
            dataOutputStream.flush();
            dataOutputStream.close();
        }
    }

    private void writeHeader(final DataOutputStream dataOutputStream) throws IOException {
        String requestNameKey = requestName + "=";
        dataOutputStream.writeBytes(requestNameKey);
        dataOutputStream.writeBytes(LINE_END);
    }

    private void writeContent(final InputStream inputStream, final DataOutputStream dataOutputStream) throws IOException {
        writeContentToBuffer(inputStream, dataOutputStream);
        dataOutputStream.writeBytes(LINE_END);
    }

    private void writeContentToBuffer(final InputStream inputStream, final DataOutputStream dataOutputStream) throws IOException {
        int bytesAvailable = inputStream.available();
        int bufferSize = Math.min(bytesAvailable, MAX_BUFFER_SIZE);
        byte[] buffer = new byte[bufferSize];
        int bytesRead = inputStream.read(buffer, 0, bufferSize);
        while (bytesRead > 0) {
            dataOutputStream.write(buffer, 0, bytesRead);
            bytesAvailable = inputStream.available();
            bufferSize = Math.min(bytesAvailable, MAX_BUFFER_SIZE);
            bytesRead = inputStream.read(buffer, 0, bufferSize);
        }
    }
}
