/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.service.impl;

import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.productstewardship.transfer.UserCrops;
import com.monsanto.tps.productstewardship.user.business.UserServicesBusiness;
import com.monsanto.tps.productstewardship.user.filter.AuthorizedCropContextFilter;
import com.monsanto.tps.productstewardship.user.filter.RoleContextFilter;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.springframework.transaction.annotation.Transactional;

import javax.jws.WebParam;
import java.util.List;

/* vvkalu - 6/30/11 */
public class UserPrivilegesServiceImpl implements UserPrivilegesService {

    private UserServicesBusiness userServicesBusiness;
    private AuthorizedCropContextFilter authorizedCropContextFilter;
    private RoleContextFilter roleContextFilter;

    @Override
    @Transactional(readOnly = true)
    @PerformanceMetric(task = "UserPrivilegesService-getCrops", comment = "getCrops")
    public List<String> getCrops(@WebParam(name = "userLoginId") String userLoginId) {
        return userServicesBusiness.retrieveUserCrops(userLoginId, authorizedCropContextFilter);
    }

    @Override
    @PerformanceMetric(task = "UserPrivilegesService-getRoles", comment = "getRoles")
    public List<String> getRoles(@WebParam(name = "userLoginId") String userLoginId) {
        return userServicesBusiness.retrieveUserRoles(userLoginId, roleContextFilter);
    }

    @Override
    @Transactional(readOnly = true)
    @PerformanceMetric(task = "UserPrivilegesService-getUsersCrops", comment = "getUsersCrops")
    public List<UserCrops> getUsersCrops(@WebParam(name = "userLoginIds") List<String> userLoginIds) {
        return userServicesBusiness.retrieveUsersCrops(userLoginIds, authorizedCropContextFilter);
    }

    public void setUserServicesBusiness(UserServicesBusiness userServicesBusiness) {
        this.userServicesBusiness = userServicesBusiness;
    }

    public void setAuthorizedCropContextFilter(AuthorizedCropContextFilter authorizedCropContextFilter) {
        this.authorizedCropContextFilter = authorizedCropContextFilter;
    }

    public void setRoleContextFilter(RoleContextFilter roleContextFilter) {
        this.roleContextFilter = roleContextFilter;
    }
}