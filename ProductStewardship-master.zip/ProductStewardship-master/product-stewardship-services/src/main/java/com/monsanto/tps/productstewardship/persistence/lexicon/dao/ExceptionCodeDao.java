package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ExceptionCodeEntity;

public interface ExceptionCodeDao extends GenericDao<ExceptionCodeEntity,Long> {
   @DynamicDaoMethod(queryName = "ExceptionCodeDao.getNextExceptionCode",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public String getNextExceptionCode();

    @DynamicDaoMethod(queryName = "ExceptionCodeDao.getByProductName",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public ExceptionCodeEntity getByProductName(@DynamicDaoParameter(name="productName")String productName, @DynamicDaoParameter(name="cropId")long lexiconCropId);
}
