/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.filter;

import org.springframework.stereotype.Component;

/* vvkalu - 6/30/11 */
@Component
public class RoleContextFilter implements ContextFilter {
   private final String ROLE_CONTEXT_PATTERN = "lexicon\\.([^\\.]+)";
   private final RegexpContextFilterHelper helper = new RegexpContextFilterHelper(ROLE_CONTEXT_PATTERN);

   @Override
   public boolean appliesTo(String context) {
      return helper.appliesTo(context);
   }

   @Override
   public String parse(String context) {
      return helper.parse(context);
   }
}