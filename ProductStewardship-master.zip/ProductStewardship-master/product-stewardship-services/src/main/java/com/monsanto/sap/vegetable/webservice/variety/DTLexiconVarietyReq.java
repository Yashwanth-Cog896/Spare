package com.monsanto.sap.vegetable.webservice.variety;



import com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for DT_LexiconVariety_Req complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DT_LexiconVariety_Req">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DocumentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="DocumentDateTime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="From">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="PartnerIdentifier" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                                     &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="ContactInformation" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="To" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="PartnerIdentifier" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                                     &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="ContactInformation" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="VarietyRequest">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="Variety" maxOccurs="unbounded">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Pubkey" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="VarietyNameCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="VarietyHybrid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Brand" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="MaterialGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="ProductType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="MaterialPricingGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Reproduction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Phase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Environment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Modification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="DifficultToProduce" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="Royalty" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="supplyChainOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "MT_LexiconVariety_OSB_Req",namespace="http://monsanto.com/MM/R3/ALSB/LexiconVariety")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MT_LexiconVariety_OSB_Req", propOrder = {
    "header",
    "varietyRequest"
})
public class DTLexiconVarietyReq {

    @XmlElement(name = "Header", required = true)
    private DTLexiconHeader header;
    @XmlElement(name = "VarietyRequest", required = true)
    private VarietyRequest varietyRequest;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader }
     *     
     */
    public DTLexiconHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader }
     *     
     */
    public void setHeader(DTLexiconHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the varietyRequest property.
     * 
     * @return
     *     possible object is
     *     {@link VarietyRequest }
     *
     */
    public VarietyRequest getVarietyRequest() {
        return varietyRequest;
    }

    /**
     * Sets the value of the varietyRequest property.
     *
     * @param value
     *     allowed object is
     *     {@link VarietyRequest }
     *
     */
    public void setVarietyRequest(VarietyRequest value) {
        this.varietyRequest = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="Variety" maxOccurs="unbounded">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Pubkey" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="VarietyNameCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="VarietyHybrid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Brand" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="MaterialGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="ProductType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="MaterialPricingGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Reproduction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Phase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Environment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Modification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="DifficultToProduce" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="Royalty" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="supplyChainOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     *
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "variety"
    })
    public static class VarietyRequest {

        @XmlElement(name = "Variety", required = true)
        private List<Variety> variety;

        /**
         * Gets the value of the variety property.
         *
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the variety property.
         *
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getVariety().add(newItem);
         * </pre>
         *
         *
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Variety }
         * 
         * 
         */
        public List<Variety> getVariety() {
            if (variety == null) {
                variety = new ArrayList<Variety>();
            }
            return this.variety;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Pubkey" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="VarietyNameCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="VarietyHybrid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Brand" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="MaterialGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="ProductType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="MaterialPricingGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Reproduction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Phase" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Environment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Modification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="DifficultToProduce" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="Royalty" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="supplyChainOwner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "pubkey",
            "level",
            "varietyNameCode",
            "varietyHybrid",
            "brand",
            "materialGroup",
            "productType",
            "materialPricingGroup",
            "reproduction",
            "phase",
            "environment",
            "modification",
            "difficultToProduce",
            "royalty",
            "supplyChainOwner",
            "preCommercialName",
            "owningRegion",
                "femaleParentPubKey",
                "maleParentPubKey",
                "femalePreComlName",
                "malePreComlName"
        })
        public static class Variety {

            @XmlElement(name = "Pubkey", required = true)
            private String pubkey;
            @XmlElement(name = "Level", required = true)
            private String level;
            @XmlElement(name = "VarietyNameCode", required = true)
            private String varietyNameCode;
            @XmlElement(name = "VarietyHybrid")
            private String varietyHybrid;
            @XmlElement(name = "Brand")
            private String brand;
            @XmlElement(name = "MaterialGroup")
            private String materialGroup;
            @XmlElement(name = "ProductType")
            private String productType;
            @XmlElement(name = "MaterialPricingGroup")
            private String materialPricingGroup;
            @XmlElement(name = "Reproduction")
            private String reproduction;
            @XmlElement(name = "Phase")
            private String phase;
            @XmlElement(name = "Environment")
            private String environment;
            @XmlElement(name = "Modification")
            private String modification;
            @XmlElement(name = "DifficultToProduce")
            private String difficultToProduce;
            @XmlElement(name = "Royalty")
            private String royalty;
            @XmlElement(name = "supplyChainOwner")
            private String supplyChainOwner;
            @XmlElement(name = "PreCommercialName")
            private String preCommercialName;
            @XmlElement(name = "OwningRegion")
            private String owningRegion;
            @XmlElement(name = "FemaleParentPubKey")
            private String femaleParentPubKey;
            @XmlElement(name = "MaleParentPubKey")
            private String maleParentPubKey;
            @XmlElement(name = "FemalePreComlName")
            private String femalePreComlName;
            @XmlElement(name = "MalePreComlName")
            private String malePreComlName;





            /**
             * Gets the value of the pubkey property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPubkey() {
                return pubkey;
            }

            /**
             * Sets the value of the pubkey property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPubkey(String value) {
                this.pubkey = value;
            }

            /**
             * Gets the value of the level property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLevel() {
                return level;
            }

            /**
             * Sets the value of the level property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLevel(String value) {
                this.level = value;
            }

            /**
             * Gets the value of the varietyNameCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVarietyNameCode() {
                return varietyNameCode;
            }

            /**
             * Sets the value of the varietyNameCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVarietyNameCode(String value) {
                this.varietyNameCode = value;
            }

            /**
             * Gets the value of the varietyHybrid property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVarietyHybrid() {
                return varietyHybrid;
            }

            /**
             * Sets the value of the varietyHybrid property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVarietyHybrid(String value) {
                this.varietyHybrid = value;
            }

            /**
             * Gets the value of the brand property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBrand() {
                return brand;
            }

            /**
             * Sets the value of the brand property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBrand(String value) {
                this.brand = value;
            }

            /**
             * Gets the value of the materialGroup property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMaterialGroup() {
                return materialGroup;
            }

            /**
             * Sets the value of the materialGroup property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMaterialGroup(String value) {
                this.materialGroup = value;
            }

            /**
             * Gets the value of the productType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getProductType() {
                return productType;
            }

            /**
             * Sets the value of the productType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setProductType(String value) {
                this.productType = value;
            }

            /**
             * Gets the value of the materialPricingGroup property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMaterialPricingGroup() {
                return materialPricingGroup;
            }

            /**
             * Sets the value of the materialPricingGroup property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMaterialPricingGroup(String value) {
                this.materialPricingGroup = value;
            }

            /**
             * Gets the value of the reproduction property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getReproduction() {
                return reproduction;
            }

            /**
             * Sets the value of the reproduction property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setReproduction(String value) {
                this.reproduction = value;
            }

            /**
             * Gets the value of the phase property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPhase() {
                return phase;
            }

            /**
             * Sets the value of the phase property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPhase(String value) {
                this.phase = value;
            }

            /**
             * Gets the value of the environment property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getEnvironment() {
                return environment;
            }

            /**
             * Sets the value of the environment property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setEnvironment(String value) {
                this.environment = value;
            }

            /**
             * Gets the value of the modification property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getModification() {
                return modification;
            }

            /**
             * Sets the value of the modification property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setModification(String value) {
                this.modification = value;
            }

            /**
             * Gets the value of the difficultToProduce property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDifficultToProduce() {
                return difficultToProduce;
            }

            /**
             * Sets the value of the difficultToProduce property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDifficultToProduce(String value) {
                this.difficultToProduce = value;
            }

            /**
             * Gets the value of the royalty property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getRoyalty() {
                return royalty;
            }

            /**
             * Sets the value of the royalty property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setRoyalty(String value) {
                this.royalty = value;
            }

            /**
             * Gets the value of the supplyChainOwner property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getSupplyChainOwner() {
                return supplyChainOwner;
            }

            /**
             * Sets the value of the supplyChainOwner property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setSupplyChainOwner(String value) {
                this.supplyChainOwner = value;
            }

            /**
             * Gets the value of the preCommercialName property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */

            public String getPreCommercialName() {
                return preCommercialName;
            }
            /**
             * Sets the value of the preCommercialName property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */

            public void setPreCommercialName(String value) {
                this.preCommercialName = value;
            }


            /**
             * Gets the value of the owningRegion property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */

            public String getOwningRegion() {return owningRegion; }

            /**
             * Sets the value of the owningRegion property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */

            public void setOwningRegion(String value) {this.owningRegion = value;  }

            public String getFemaleParentPubKey() {
                return femaleParentPubKey;
            }

            public void setFemaleParentPubKey(String femaleParentPubKey) {
                this.femaleParentPubKey = femaleParentPubKey;
            }

            public String getMaleParentPubKey() {
                return maleParentPubKey;
            }

            public void setMaleParentPubKey(String maleParentPubKey) {
                this.maleParentPubKey = maleParentPubKey;
            }

            public String getFemalePreComlName() {
                return femalePreComlName;
            }

            public void setFemalePreComlName(String femalePreComlName) {
                this.femalePreComlName = femalePreComlName;
            }



            public String getMalePreComlName() {
                return malePreComlName;
            }

            public void setMalePreComlName(String malePreComlName) {
                this.malePreComlName = malePreComlName;
            }
        }





    }

}
