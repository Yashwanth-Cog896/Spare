package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCountryEntity;

public interface LexiconCountryDao extends GenericDao<LexiconCountryEntity,Long> {
    @DynamicDaoMethod(queryName = "LexiconCountryDao.findByAbbreviation",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
        LexiconCountryEntity findByAbbreviation(@DynamicDaoParameter(name="abbreviation") String abbreviation);

}
