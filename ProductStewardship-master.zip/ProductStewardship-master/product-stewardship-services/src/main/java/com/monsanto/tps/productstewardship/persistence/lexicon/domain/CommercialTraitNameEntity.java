package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 22, 2011
 * Time: 10:08:39 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "commercialTraitNameIdGenerator",allocationSize = 1,sequenceName = "Lexicon.COML_TRAIT_ID_SEQ")
@Table(name = "COML_TRAIT_NAME2", schema = "Lexicon")
public class CommercialTraitNameEntity {
    @Id
    @GeneratedValue(generator = "commercialTraitNameIdGenerator")
    @Column(name="COML_TRAIT_NAME_ID")
    private long id;
    @Column(name="TRAIT_ABBR",length = 15,nullable = false)
    String abbreviation;
    @Column(name="TRAIT_DESC",length=50,nullable = false)
    String description;
    @Type(type = "boolean-yn")
    @Column(name="IS_ACTIVE",nullable = false)
    private boolean active;

    @ManyToOne(optional = true)
    @JoinColumn(name = "COMPANY_ID",nullable = true)
    private LexiconCompany lexiconCompany;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public LexiconCompany getLexiconCompany() {
        return lexiconCompany;
    }

    public void setLexiconCompany(LexiconCompany lexiconCompany) {
        this.lexiconCompany = lexiconCompany;
    }
}
