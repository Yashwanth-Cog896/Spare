/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/* vvkalu - 6/23/11 */
@Entity
@SequenceGenerator(name = "royaltyContractIdGenerator",allocationSize = 1,sequenceName = "Lexicon.ROYALTY_CONTRACT_ID_SEQ")
@Table(name = "ROYALTY_CONTRACT", schema = "Lexicon")
public class RoyaltyContractEntity  implements Serializable {
    @Id
    @Column(name="ROYALTY_CONTRACT_ID")
    @GeneratedValue(generator = "royaltyContractIdGenerator")
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="COMPANY_ID",nullable = false)
    private LexiconCompany company;
    @Column(name="INACTIVE_DT",nullable = true)
    @Temporal(TemporalType.DATE)
    private Date   inactiveDate;
    @Column(name="COMMENTS",nullable=true,length=2000)
    private String comments;
    @Column(name="MODIFIED_DT",nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date  modifiedTimestamp;
    @Column(name="CONTRACT_NUMBER",nullable = true, length=50)
    private String contractNumber;

    public LexiconCompany getCompany() {
        return company;
    }

    public void setCompany(LexiconCompany company) {
        this.company = company;
    }


    public void setComments(String comments) {
        this.comments = comments;
    }

    public void setModifiedTimestamp(Date modifiedTimestamp) {
        this.modifiedTimestamp = modifiedTimestamp;
    }

    public void setInactiveDate(Date inactiveDate) {
        this.inactiveDate = inactiveDate;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public long getId() {
        return id;
    }

    public String getComments() {
        return comments;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public Date getInactiveDate() {
        return inactiveDate;
    }

    public Date getModifiedTimestamp() {
        return modifiedTimestamp;
    }

    public void setId(long id) {
        this.id = id;
    }
}