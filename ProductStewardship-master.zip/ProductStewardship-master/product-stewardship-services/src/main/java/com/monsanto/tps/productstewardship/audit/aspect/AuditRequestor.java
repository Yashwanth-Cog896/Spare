package com.monsanto.tps.productstewardship.audit.aspect;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 14, 2011
 * Time: 10:55:35 AM
 * To change this template use File | Settings | File Templates.
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
public @interface AuditRequestor {
}
