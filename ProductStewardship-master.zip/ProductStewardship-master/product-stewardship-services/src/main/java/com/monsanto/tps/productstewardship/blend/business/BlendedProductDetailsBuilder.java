package com.monsanto.tps.productstewardship.blend.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 9, 2011
 * Time: 6:03:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class BlendedProductDetailsBuilder {

    private BlendBuilderFactory blendBuilderFactory;

    public List<LexBlendedProductDetails> buildProductDetails(List<BlendedProductDetails> blendedProductDetails,
                                                              Map<Long, FbsCommonProductXrefEntity> productXrefMap,
                                                              List<LexiconProductEntity> preComlProducts) {
        List<LexBlendedProductDetails> productDetails = new ArrayList<LexBlendedProductDetails>();
        if (blendedProductDetails != null) {
            for (BlendedProductDetails details : blendedProductDetails) {
                BlendedSearchStrategy strategy = blendBuilderFactory.getStrategy(details);
                processBlendStrategy(productXrefMap, preComlProducts, productDetails, details, strategy);
            }
        }
        return productDetails;
    }

    private void processBlendStrategy(Map<Long, FbsCommonProductXrefEntity> productXrefMap,
                                      List<LexiconProductEntity> preComlProducts,
                                      List<LexBlendedProductDetails> productDetails,
                                      BlendedProductDetails details,
                                      BlendedSearchStrategy strategy) {
        if (strategy != null) {
            Multimap<Long, FbsCommonProductXrefEntity> germplasmIdToXrefMap =
                    strategy.buildGermplasmIdToProductXrefsMap(productXrefMap, details);
            Map<String, BlendedPreComlProduct> blendPreComlMap =
                    buildPubkeyToPreComlProductMap(preComlProducts, germplasmIdToXrefMap);
            Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductMap =
                    buildGermplasmIdToProductMap(germplasmIdToXrefMap, blendPreComlMap);
            LexBlendedProductDetails lexBlendedProductDetail =
                    strategy.buildLexBlendedProductDetails(details, germplasmIdToPreComlProductMap);
            productDetails.add(lexBlendedProductDetail);
        }
    }

    public Map<String, BlendedPreComlProduct> buildPubkeyToPreComlProductMap(List<LexiconProductEntity> preComlProducts,
                                                                             Multimap<Long, FbsCommonProductXrefEntity> germplasmIdToProductXrefMap) {
        Map<String, BlendedPreComlProduct> pubkeyToProductMap = new HashMap<String, BlendedPreComlProduct>();
        for (FbsCommonProductXrefEntity xref : germplasmIdToProductXrefMap.values()) {
            buildBlendedPreComlProduct(preComlProducts, pubkeyToProductMap, xref);
        }
        return pubkeyToProductMap;
    }

    public Multimap<Long, BlendedPreComlProduct> buildGermplasmIdToProductMap(Multimap<Long, FbsCommonProductXrefEntity> germplasmIdToProductXrefMap,
                                                                              Map<String, BlendedPreComlProduct> pubkeyToProductMap) {
        Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductMap = ArrayListMultimap.create();
        for (Long germplasmId : germplasmIdToProductXrefMap.keySet()) {
            for (FbsCommonProductXrefEntity xref : germplasmIdToProductXrefMap.get(germplasmId)) {
                germplasmIdToPreComlProductMap.put(germplasmId, pubkeyToProductMap.get(xref.getLexiconPubkey()));
            }
        }
        return germplasmIdToPreComlProductMap;
    }

    private void buildBlendedPreComlProduct(List<LexiconProductEntity> preComlProducts, Map<String, BlendedPreComlProduct> pubkeyToProductMap, FbsCommonProductXrefEntity xref) {
        for (LexiconProductEntity preComlProduct : preComlProducts) {
            if (xref.getLexiconPubkey().equalsIgnoreCase(preComlProduct.getPubkey())) {
                BlendedPreComlProduct productBlended = new BlendedPreComlProduct();
                productBlended.setLexiconPubkey(preComlProduct.getPubkey());
                productBlended.setPreComlName(preComlProduct.getPreCommercialName());
                productBlended.setMidasProductId(xref.getMidasProduct().getId());
                pubkeyToProductMap.put(preComlProduct.getPubkey(), productBlended);
            }
        }
    }

    public void setBlendBuilderFactory(BlendBuilderFactory blendBuilderFactory) {
        this.blendBuilderFactory = blendBuilderFactory;
    }
}
