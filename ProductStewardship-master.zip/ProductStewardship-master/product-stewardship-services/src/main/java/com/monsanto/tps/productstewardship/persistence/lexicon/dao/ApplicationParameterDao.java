package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ApplicationParameterEntity;

public interface ApplicationParameterDao extends GenericDao<ApplicationParameterEntity,Long> {
    String getParameterValue(String key);
}
