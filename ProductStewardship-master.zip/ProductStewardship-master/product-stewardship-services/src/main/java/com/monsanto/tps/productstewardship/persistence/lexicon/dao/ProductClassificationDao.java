package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductClassificationEntity;

import java.util.List;

public interface ProductClassificationDao extends GenericDao<ProductClassificationEntity,Long> {
    @DynamicDaoMethod(queryName = "ProductClassificationDao.getByProductClassificationCode",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    ProductClassificationEntity getByProductClassificationCode(@DynamicDaoParameter(name="productClassificationCode") String productClassificationCode);

}
