package com.monsanto.sap.rowcrop.webservice.relationship;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;

public class SapRelationshipInfo
{
   public final String relationshipPubkey;
   public final String manufacturingName;
   public final String baseManufacturingName;
   public final String cropPubkey;
   public final boolean logicallyDeleted;
   public final long sapLinkageAuditId;

   public SapRelationshipInfo(ProductRelationshipEntity relationship, long sapLinkageAuditId)
   {
      this.relationshipPubkey = relationship.getProductRelationshipPubkey();
      this.manufacturingName = relationship.getManufacturingName();
      this.baseManufacturingName = relationship.getBaseProduct().getBaseManufacturingName();
      this.cropPubkey = relationship.getBaseProduct().getLexiconCrop().getPubkey();
      this.logicallyDeleted = relationship.getLogicalDelete();
      this.sapLinkageAuditId = sapLinkageAuditId;
   }
}