package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.monsanto.sap.vegetable.webservice.variety.DTLexiconVarietyReq;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.GermplasmDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class ProductStageVarietyBuilder {
    public static final String CONVENTIONAL_MODIFICATION = "00";
    public static final String NONCONVENTIONAL_MODIFICATION = "GMO";
    public static final String CONVENTIONAL_TRAITSTACK_ABBR = "CONV";
    public static final String IS_ROYALTY = "1";
    public static final String PRIMARY = "1";
    public static final String SECONDARY = "2";
    public static final String HYB = "HYB";
    public static final String OP = "OP";
    public static final String NOT_ROYALTY = "0";
    private static final String BEAN_CODE = "PV";
    private static final String LETTUCE_CODE = "LS";
    private static final String PEA_CODE = "PS";
    public static final String EMPTY_STRING = "";
    public static final String FEMALE_CODE = "F";
    public static final String MALE_CODE = "M";
    private static final Logger log = Logger.getLogger(ProductStageVarietyBuilder.class);

    @Resource
    private GermplasmDao germplasmDao;

    public DTLexiconVarietyReq.VarietyRequest.Variety build(LexiconProductStageEntity productStage) {
        DTLexiconVarietyReq.VarietyRequest.Variety variety = null;
        if (productStage.getExceptionCode() != null) {
            ExceptionCodeEntity exceptionCode = productStage.getExceptionCode();
            LexiconProductEntity product = productStage.getLexiconProduct();
            List<GermplasmEntity> germplasms = getGermplasms(product);
            variety = new DTLexiconVarietyReq.VarietyRequest.Variety();
            variety.setLevel(exceptionCode.isPrimary() ? PRIMARY : SECONDARY); //Change
            variety.setPubkey(product.getPubkey());//Change
            variety.setVarietyNameCode(exceptionCode.getExceptionCode());
            variety.setVarietyHybrid(exceptionCode.getProductName());
            variety.setBrand(productStage.getLexiconBrand().getPubkey());
            variety.setPhase(productStage.getLexiconStage().getPubkey());
            setProductClassificationValues(variety, product.getProductClassification());
            variety.setModification(calculateModification(productStage));
            variety.setReproduction(getReproduction(germplasms));
            variety.setRoyalty(getRoyalty(germplasms));
            setSupplyChainOwner(product, variety);
            setCovarCategory(product, variety, germplasms);
            variety.setPreCommercialName(product.getPreCommercialName());
            setOwningRegion(product, variety);
            setHardcodedValues(variety);
        }
        return variety;
    }

    private void setCovarCategory(LexiconProductEntity product, DTLexiconVarietyReq.VarietyRequest.Variety variety, List<GermplasmEntity> germplasms) {

        for (GermplasmEntity germplasm : germplasms) {
            if (LineTypeEntity.CODED.equals(germplasm.getLineType().getLineTypeRefId()) || LineTypeEntity.FINISHED.equals(germplasm.getLineType().getLineTypeRefId())) {

                if (isVarietalCrop(product.getLexiconCrop().getAbbreviation())) {
                    variety.setFemaleParentPubKey(product.getPubkey());

                    variety.setMaleParentPubKey(EMPTY_STRING);
                    variety.setFemalePreComlName(product.getPreCommercialName());

                    variety.setMalePreComlName(EMPTY_STRING);
                    break;
                }
            } else if (LineTypeEntity.HYBRID.equals(germplasm.getLineType().getLineTypeRefId())) {

                Map<String,List<String>>  femaleMalePubKeyMap = germplasmDao.getFemaleMaleLexiconPubKey(germplasm.getId());
                if (!femaleMalePubKeyMap.isEmpty()) {

                    //variety.setFemaleParentPubKey(femaleMalePubKeyMap.get(FEMALE_CODE));
                    //variety.setMaleParentPubKey(femaleMalePubKeyMap.get(MALE_CODE));
                    List<String> lstFemalePreCmclName = femaleMalePubKeyMap.get(FEMALE_CODE);
                    List<String> lstmalePreCmclName = femaleMalePubKeyMap.get(MALE_CODE);

                    variety.setFemaleParentPubKey(lstFemalePreCmclName.get(0));
                    variety.setFemalePreComlName(lstFemalePreCmclName.get(1));

                    variety.setMaleParentPubKey(lstmalePreCmclName.get(0));
                    variety.setMalePreComlName(lstmalePreCmclName.get(1));

                } else {

                    setEmptyParentPubKeys(variety);
                    setEmptyParentPreComlName(variety);

                }
                break;
            } else {

                setEmptyParentPubKeys(variety);
                setEmptyParentPreComlName(variety);
                break;
            }
        }


    }

    private boolean isVarietalCrop(String cropCode) {
        return inList(new String[]{BEAN_CODE, LETTUCE_CODE, PEA_CODE}, cropCode);
    }

    private boolean inList(String[] codes, String code) {
        return Arrays.asList(codes).contains(StringUtils.upperCase(code));
    }


    private void setEmptyParentPubKeys(DTLexiconVarietyReq.VarietyRequest.Variety variety) {
        variety.setFemaleParentPubKey(EMPTY_STRING);
        variety.setMaleParentPubKey(EMPTY_STRING);
    }

    private void setEmptyParentPreComlName(DTLexiconVarietyReq.VarietyRequest.Variety variety) {
        variety.setFemalePreComlName(EMPTY_STRING);
        variety.setMalePreComlName(EMPTY_STRING);
    }


    private List<GermplasmEntity> getGermplasms(LexiconProductEntity product) {
        List<GermplasmEntity> germplasms = new ArrayList<GermplasmEntity>(product.getFbsCommonProductXref().getMidasProduct().getProductGermplasms().size());
        for (ProductGermplasmEntity productGermplasm : product.getFbsCommonProductXref().getMidasProduct().getProductGermplasms()) {
            germplasms.add(productGermplasm.getGermplasm());
        }
        return germplasms;
    }

    public String getReproduction(List<GermplasmEntity> germplasms) {
        for (GermplasmEntity germplasm : germplasms) {
            if (LineTypeEntity.HYBRID.equals(germplasm.getLineType().getLineTypeRefId())) {
                return HYB;
            }
        }
        return OP;
    }

    public String getRoyalty(List<GermplasmEntity> germplasms) {
        for (GermplasmEntity germplasm : germplasms) {
            for (GermplasmRoyaltyEntity germplasmRoyalty : germplasm.getGermplasmRoyalties()) {
                if (germplasmRoyalty.isRoyaltyIndicator()) {
                    return IS_ROYALTY;
                }
            }
        }
        return NOT_ROYALTY;
    }


    private void setSupplyChainOwner(LexiconProductEntity product, DTLexiconVarietyReq.VarietyRequest.Variety variety) {
        variety.setSupplyChainOwner(product.getSupplyChainOwnerGroup() != null ? product.getSupplyChainOwnerGroup().getCodeInSap() : "");
    }

    private void setOwningRegion(LexiconProductEntity product, DTLexiconVarietyReq.VarietyRequest.Variety variety) {
        variety.setOwningRegion(product.getOwningMarketingRegion() != null ? product.getOwningMarketingRegion().getName() : "");
    }

    private String calculateModification(LexiconProductStageEntity productStage) {
        if (productStage.getCommercialTraitStack() == null || CONVENTIONAL_TRAITSTACK_ABBR.equals(productStage.getCommercialTraitStack().getAbbreviation())) {
            return CONVENTIONAL_MODIFICATION;
        } else {
            return NONCONVENTIONAL_MODIFICATION;
        }
    }

    private void setProductClassificationValues(DTLexiconVarietyReq.VarietyRequest.Variety variety, ProductClassificationEntity productClassification) {
        if (productClassification != null) {
            variety.setMaterialGroup(productClassification.getMaterialGroup().getPubkey());
            variety.setProductType(productClassification.getProductType().getPubkey());
            variety.setMaterialPricingGroup(productClassification.getMaterialPricingGroup().getPubkey());
            variety.setEnvironment(productClassification.getProductionEnvironment().getCode());
        }
    }

    private void setHardcodedValues(DTLexiconVarietyReq.VarietyRequest.Variety variety) {
        variety.setDifficultToProduce(NOT_ROYALTY);
    }

    public void setGermplasmDao(GermplasmDao germplasmDao) {
        this.germplasmDao = germplasmDao;
    }
}
