/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;

import java.util.List;

/* vvkalu - 7/15/11 */
public interface ManfNamesSearchCriteria {
    List<BaseProduct> findBaseProducts(List<String> authorizedCropPubkeys, List<String> names);
}