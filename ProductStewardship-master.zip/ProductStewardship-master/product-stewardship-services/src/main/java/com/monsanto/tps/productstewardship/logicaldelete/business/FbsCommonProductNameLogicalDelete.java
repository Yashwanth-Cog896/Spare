package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 2:35:50 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FbsCommonProductNameLogicalDelete {
     public void logicalDelete(FbsCommonProductNameXrefEntity productNameXref);
}
