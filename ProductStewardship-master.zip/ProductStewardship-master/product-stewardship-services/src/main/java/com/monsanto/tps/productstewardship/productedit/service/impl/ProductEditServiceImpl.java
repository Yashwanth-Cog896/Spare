package com.monsanto.tps.productstewardship.productedit.service.impl;

import com.monsanto.tps.aop.logging.ProfileLogging;
import com.monsanto.tps.productstewardship.productedit.business.InventoryProductNameLinkageUpdater;
import com.monsanto.tps.productstewardship.productedit.business.ProductEditBusiness;
import com.monsanto.tps.productstewardship.productedit.business.ProductStageEditBusiness;
import com.monsanto.tps.productstewardship.productedit.business.product.ProductValidationModel;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationRulesAggregate;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.springframework.transaction.annotation.Transactional;

import javax.jws.WebParam;
import java.util.ArrayList;
import java.util.List;

public class ProductEditServiceImpl implements ProductEditService{
    private ProductEditBusiness productEditBusiness;
    private InventoryProductNameLinkageUpdater inventoryProductNameLinkageUpdater;

    @Override

    @ProfileLogging
    public List<Product> editProducts(@WebParam(name = "product") List<Product> products) {
        boolean valid = productEditBusiness.validate(products);
        if(valid){
            productEditBusiness.editProducts(products);
            inventoryProductNameLinkageUpdater.updateNameLinkages(products);
        }
        return products;
    }

    @Override
    @ProfileLogging
    public List<Product> editProductsValidation(@WebParam(name = "product") List<Product> products) {
        productEditBusiness.validate(products);
        return products;  
    }



    public void setProductEditBusiness(ProductEditBusiness productEditBusiness) {
        this.productEditBusiness = productEditBusiness;
    }

    public InventoryProductNameLinkageUpdater getInventoryProductNameLinkageUpdater() {
        return inventoryProductNameLinkageUpdater;
    }

    public void setInventoryProductNameLinkageUpdater(InventoryProductNameLinkageUpdater inventoryProductNameLinkageUpdater) {
        this.inventoryProductNameLinkageUpdater = inventoryProductNameLinkageUpdater;
    }
}
