package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 15, 2011
 * Time: 9:55:32 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "BRAND", schema = "Midas")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)
public class MidasBrandEntity  implements Serializable {
    public static final String MONSANTO_BRAND = "MONSANTO";
    @Id
    @GeneratedValue(generator = "midas_generator")
    @Column(name = "BRAND_ID", precision = 0, length = 22)    
    private long id;
    @Column(name="NAME",length = 50,nullable=false)
    private String name;
    @Type(type="true_false")
    @Column(name="REF_ACTIVE",nullable = false)
    private boolean refActive;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="COMPANY_ID",nullable = false)
    private MidasCompanyEntity midasCompany;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public MidasCompanyEntity getMidasCompany() {
        return midasCompany;
    }

    public void setMidasCompany(MidasCompanyEntity midasCompany) {
        this.midasCompany = midasCompany;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }
}
