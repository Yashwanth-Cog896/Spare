package com.monsanto.util.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.ParserException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 24, 2007
 * Time: 2:31:49 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class HttpServiceInvoker implements ServiceInvoker {
   protected abstract ServiceURLProvider getURLProvider();
   protected abstract ConnectionPreparer getConnectionPreparer();
   protected abstract RequestStreamer getRequestStreamer();
   protected abstract ResponseStreamParser getResponseStreamParser();

   public Document call(final Document requestDoc)
      throws WrappingException
   {
      try {
         final HttpURLConnection conn = createConnection();
         getConnectionPreparer().prepareConnection(conn);
         getRequestStreamer().streamRequest(requestDoc, conn.getOutputStream());
         final InputStream responseStream = submitRequest(conn);
         return getResponseStreamParser().parseResponse(responseStream);
      }
      catch (Exception e) {
         throw new WrappingException(e);
      }
   }

   private HttpURLConnection createConnection()
      throws IOException
   {
      URL url = new URL(getURLProvider().getServiceURL());
      return (HttpURLConnection) url.openConnection();
   }

   private InputStream submitRequest(final HttpURLConnection conn)
      throws IOException, ParserException, SAXException
   {
      conn.connect();
      return conn.getInputStream();
   }
}
