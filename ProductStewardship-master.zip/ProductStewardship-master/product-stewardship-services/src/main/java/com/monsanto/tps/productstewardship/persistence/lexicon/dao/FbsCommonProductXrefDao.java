package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 8, 2011
 * Time: 8:13:22 AM
 * To change this template use File | Settings | File Templates.
 */
public interface FbsCommonProductXrefDao extends GenericDao<FbsCommonProductXrefEntity,String>{
         @DynamicDaoMethod(queryName = "FbsCommonProductXrefDao.getByProductPubkeys",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
         List<FbsCommonProductXrefEntity> getByProductPubkeys(@DynamicDaoParameter(name="requestId") Long requestId);
}
