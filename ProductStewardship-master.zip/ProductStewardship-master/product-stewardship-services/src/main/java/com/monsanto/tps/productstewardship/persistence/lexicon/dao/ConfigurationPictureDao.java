package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ConfigurationPictureEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 28, 2011
 * Time: 4:25:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ConfigurationPictureDao extends GenericDao<ConfigurationPictureEntity,Long> {
}
