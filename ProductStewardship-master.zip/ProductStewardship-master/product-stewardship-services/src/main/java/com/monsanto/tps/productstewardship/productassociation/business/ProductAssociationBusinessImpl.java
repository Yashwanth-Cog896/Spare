package com.monsanto.tps.productstewardship.productassociation.business;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.productassociation.dao.ProductAssociation;
import com.monsanto.tps.productstewardship.productassociation.dao.ProductAssociationDao;
import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationSearchResponse;
import com.monsanto.tps.productstewardship.productassociation.service.ProductAssociationSearchType;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;

import java.util.*;


public class ProductAssociationBusinessImpl implements ProductAssociationBusiness {
    private ProductAssociationDao productAssociationDao;
    private UserPrivilegesService userPrivilegesService;
    private UserProfile userProfile;

    public List<ProductAssociationSearchResponse> findProductAssociations(ProductAssociationSearchType searchType, List<String> names, boolean hybridOnly) {
        if (searchType != null) {
            return buildResponses(findProductAssociations(searchType, names, hybridOnly, userPrivilegesService.getCrops(userProfile.getUserName())));
        } else {
            return new ArrayList<ProductAssociationSearchResponse>();
        }
    }

    private List<ProductAssociation> findProductAssociations(ProductAssociationSearchType searchType, List<String> names, boolean hybridOnly, List<String> cropPubkeys) {
        List<ProductAssociation> productAssociations = null;
        switch (searchType) {
            case BASE_MANUFACTURING_NAME:
                productAssociations = productAssociationDao.findByBaseManufacturingName(names, hybridOnly, cropPubkeys);
                break;
            case MANUFACTURING_NAME:
                productAssociations = productAssociationDao.findByManufacturingName(names, hybridOnly, cropPubkeys);
                break;
            case PRECOMMERCIAL_NAME:
                productAssociations = productAssociationDao.findByPreCommercialName(names, hybridOnly, cropPubkeys);
                break;
            case VARIETY_NAME:
                Set<ProductAssociation> productAssociationSet = new HashSet<ProductAssociation>();
                productAssociationSet.addAll(productAssociationDao.findByVarietyName(names, hybridOnly, cropPubkeys));
                productAssociationSet.addAll(productAssociationDao.findByTagVarietyName(names, hybridOnly, cropPubkeys));
                productAssociations = new ArrayList<ProductAssociation>(productAssociationSet);
                Collections.sort(productAssociations, new Comparator<ProductAssociation>() {
                    @Override
                    public int compare(ProductAssociation o1, ProductAssociation o2) {
                        return 0;
                    }
                });
                break;
            default:
                productAssociations = new ArrayList<ProductAssociation>();
                break;
        }
        return productAssociations;
    }

    private List<ProductAssociationSearchResponse> buildResponses(List<ProductAssociation> productAssociations) {
        List<ProductAssociationSearchResponse> responses = new ArrayList<ProductAssociationSearchResponse>(productAssociations.size());
        for (ProductAssociation productAssociation : productAssociations) {
            ProductAssociationSearchResponse response = new ProductAssociationSearchResponse();
            response.setBaseManufacturingName(productAssociation.getBaseManufacturingName());
            response.setManufacturingName(productAssociation.getManufacturingName());
            response.setPreCommercialName(productAssociation.getPreCommercialName());
            response.setVarietyName(productAssociation.getVarietyName());
            responses.add(response);
        }
        return responses;
    }

    public void setProductAssociationDao(ProductAssociationDao productAssociationDao) {
        this.productAssociationDao = productAssociationDao;
    }

    public void setUserPrivilegesService(UserPrivilegesService userPrivilegesService) {
        this.userPrivilegesService = userPrivilegesService;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
}
