package com.monsanto.tps.productstewardship.audit.aspect;

/**
 * rrchak1 - May 15, 2009 3:42:06 PM
 */
public enum AuditStagingDataPointEnum
{
   AUDITCOMMENT,
   AUDITREQUESTOR
}
