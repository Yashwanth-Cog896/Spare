package com.monsanto.tps.productstewardship.logicaldelete.business;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 14, 2011
 * Time: 1:26:36 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductNameLogicalDelete {
    public void logicallyDeleteProductNames(List<String> productStagePubkeys);
}
