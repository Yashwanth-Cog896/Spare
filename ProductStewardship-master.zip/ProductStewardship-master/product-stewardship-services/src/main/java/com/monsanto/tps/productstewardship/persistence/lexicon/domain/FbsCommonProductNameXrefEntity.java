package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:17:10 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PRODUCT_NAME_XREF", schema = "FBS_COMMON")
public class FbsCommonProductNameXrefEntity implements Serializable {
    
    @Id
    @Column(name="LEXICON_PRODUCT_NAME_PUBKEY",length = 20)
    String lexiconPubkey;

    @ManyToOne
    @JoinColumn(name="MIDAS_PRODUCT_NAME_ID",nullable = true)
    private MidasProductNameEntity midasProductName;

    @ManyToOne
    @JoinColumn(name="mirage_product_id",nullable = true)
    private MirageSeedProductEntity mirageSeedProduct;

//    @ManyToOne
//    @JoinColumn(name="LEXICON_PRODUCT_NAME_PUBKEY",referencedColumnName = "PRODUCT_STAGE_PUBKEY",insertable = false, updatable = false)
//    private LexiconProductStageEntity lexiconProductStage;
//
//    @ManyToOne
//    @JoinColumn(name="LEXICON_PRODUCT_NAME_PUBKEY",referencedColumnName = "PRODUCT_NAME_PUBKEY",insertable = false, updatable = false)
//    private LexiconProductNameEntity lexiconProductName;

    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public MidasProductNameEntity getMidasProductName() {
        return midasProductName;
    }

    public void setMidasProductName(MidasProductNameEntity midasProductName) {
        this.midasProductName = midasProductName;
    }

    public MirageSeedProductEntity getMirageSeedProduct() {
        return mirageSeedProduct;
    }

    public void setMirageSeedProduct(MirageSeedProductEntity mirageSeedProduct) {
        this.mirageSeedProduct = mirageSeedProduct;
    }
}
