package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class StageTypeValidRule  implements ValidationSimpleRule<StageValidationModel> {
    private LexiconStageDao lexiconStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean isValid=false;
        if(StringUtils.isNotBlank(model.getProductStage().getStageAbbreviation())){
            LexiconStageEntity lexiconStage = lexiconStageDao.findStageByAbbreviation(model.getProductStage().getStageAbbreviation());
            if(lexiconStage!=null){
                isValid=true;
            }
        }
        if(!isValid){
               status.addCondition(new ValidationResult(ProductEditService.INVALID_STAGE_PUBKEY_CODE, ValidationSeverity.ERROR));
        }

    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
