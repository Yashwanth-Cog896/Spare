package com.monsanto.tps.productstewardship.email;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

/**
 * User: pjberry
 * Date: Sep 27, 2007
 * Time: 4:25:25 PM
 */
public class MessageFactory
{
   public static final String TEXT_PLAIN_CONTENT_TYPE = "text/plain";

   public Message buildMessage(String[] recipientAddresses, String senderAddress, String subject, String body)
      throws MessagingException
   {
      Message message = new MimeMessage(buildSession());
      message.setRecipients(Message.RecipientType.TO, buildRecipientAddresses(recipientAddresses));
      message.setFrom(new InternetAddress(senderAddress));
      message.setSubject(subject);
      message.setContent(body, TEXT_PLAIN_CONTENT_TYPE);
      return message;
   }

   private Session buildSession() {
      Properties sessionProperties = System.getProperties();
      sessionProperties.setProperty("mail.smtp.host", "mail.monsanto.com");
      return Session.getInstance(sessionProperties);
   }

   private Address[] buildRecipientAddresses(String[] recipientAddresses)
      throws AddressException
   {
      Address[] addresses = new Address[recipientAddresses.length];
      for (int i = 0; i < recipientAddresses.length; i++) {
         addresses[i] = new InternetAddress(recipientAddresses[i]);
      }
      return addresses;
   }
}
