package com.monsanto.tps.productstewardship.sap.business.rowcrop.relationship;


import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponseImpl;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipInfo;
import com.monsanto.sap.rowcrop.webservice.relationship.sapservicecall.SapRelationshipService;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import org.apache.log4j.Logger;

import java.util.*;

public class SapRelationshipServiceDelegate {
  private final SapRelationshipService sapRelationshipService;
  private static final Logger log = Logger.getLogger(SapRelationshipServiceDelegate.class);

  public SapRelationshipServiceDelegate(SapRelationshipService sapRelationshipService) {
    this.sapRelationshipService = sapRelationshipService;
  }

  public List<SapSyncResponse> flowToSap(List<ProductRelationshipEntity> relationshipsToProcess) {
    List<SapSyncResponse> responses = new ArrayList<SapSyncResponse>();
    List<SapRelationshipInfo> relationshipInfos = createRelationshipInfos(relationshipsToProcess);
    for (SapRelationshipInfo relationshipInfo:relationshipInfos){
       try{
         responses.add(sapRelationshipService.synSap(relationshipInfo));
       } catch (Exception e){
         responses.add(processException(e,relationshipInfo)) ;
         log.error(e.getMessage());
      }
    }
    return responses;
  }

  private SapSyncResponse processException(Exception e, SapRelationshipInfo relationshipInfo) {
    return new SapSyncResponseImpl(relationshipInfo.sapLinkageAuditId, null, SapSyncResponse.ERROR_CODE, SapSyncResponse.ERROR_MESSAGE, e.getMessage());
  }

  private List<SapRelationshipInfo> createRelationshipInfos(List<ProductRelationshipEntity> relationshipsToProcess) {
    List<SapRelationshipInfo> relationshipInfos = new ArrayList<SapRelationshipInfo>();
    for (ProductRelationshipEntity relationship:relationshipsToProcess){
      relationshipInfos.add(buildRelationshipInfo(relationship));
    }
    return relationshipInfos;
  }

  private SapRelationshipInfo buildRelationshipInfo(ProductRelationshipEntity relationship) {
    return new SapRelationshipInfo(relationship, relationship.getId());
  }
}
