package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.CommercialTraitStackDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class TraitStackValidRule  implements ValidationSimpleRule<StageValidationModel> {

    private CommercialTraitStackDao commercialTraitStackDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        String comlTraitName = model.getProductStage().getComlTraitName();
        if(StringUtils.isBlank(comlTraitName)||
           commercialTraitStackDao.getByTraitName(comlTraitName).isEmpty()){
              status.addCondition(new ValidationResult(ProductEditService.INVALID_TRAIT_STACK_CODE, ValidationSeverity.ERROR));
        }
    }

    public void setCommercialTraitStackDao(CommercialTraitStackDao commercialTraitStackDao) {
        this.commercialTraitStackDao = commercialTraitStackDao;
    }
}
