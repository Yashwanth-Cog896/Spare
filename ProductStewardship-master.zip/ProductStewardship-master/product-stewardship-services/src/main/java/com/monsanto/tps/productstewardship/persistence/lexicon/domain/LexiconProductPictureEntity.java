package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:08:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "lexiconProductPictureIdGenerator",allocationSize = 1,sequenceName = "Lexicon.PRE_COML_PRODUCT_PICT_ID_SEQ")
@Table(name = "PRE_COML_PRODUCT_PICTURE", schema = "Lexicon")
public class LexiconProductPictureEntity  implements Serializable {
    @Id
    @GeneratedValue(generator = "lexiconProductPictureIdGenerator")
    @Column(name="PRE_COML_PRODUCT_PICTURE_ID")
    private long id;

    @Column(name="DISPLAY_NAME",nullable = false,length = 2000)
    private String displayName;

    @Column(name="DOCUMENT_ID",nullable = false, length=128)
    private String documentId;

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
