package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageCountryEntity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "COUNTRY_XREF", schema = "FBS_COMMON")
public class FbsCommonCountryXrefEntity implements Serializable{
     @Id
     @Column(name="LEXICON_COUNTRY_PUBKEY",length = 20)
     private String lexiconPubkey;

    @ManyToOne
    @JoinColumn(name = "MIDAS_COUNTRY_ID", nullable = true)
     private MidasCountryEntity midasCountry;

    @ManyToOne
    @JoinColumn(name = "MIRAGE_COUNTRY_CODE", nullable = true)    
    private MirageCountryEntity mirageCountry;

    public String getLexiconPubkey() {
        return lexiconPubkey;
    }

    public void setLexiconPubkey(String lexiconPubkey) {
        this.lexiconPubkey = lexiconPubkey;
    }

    public MidasCountryEntity getMidasCountry() {
        return midasCountry;
    }

    public void setMidasCountry(MidasCountryEntity midasCountry) {
        this.midasCountry = midasCountry;
    }

    public MirageCountryEntity getMirageCountry() {
        return mirageCountry;
    }

    public void setMirageCountry(MirageCountryEntity mirageCountry) {
        this.mirageCountry = mirageCountry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FbsCommonCountryXrefEntity)) return false;

        FbsCommonCountryXrefEntity that = (FbsCommonCountryXrefEntity) o;

        if (lexiconPubkey != null ? !lexiconPubkey.equals(that.lexiconPubkey) : that.lexiconPubkey != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return lexiconPubkey != null ? lexiconPubkey.hashCode() : 0;
    }
}
