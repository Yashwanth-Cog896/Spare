package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 21, 2011
 * Time: 11:15:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "lexiconCompanyIdGenerator",allocationSize = 1,sequenceName = "Lexicon.COMPANY_ID_SEQ")
@Table(name = "COMPANY", schema = "Lexicon")
public class LexiconCompany  implements Serializable {
    @Id
    @Column(name = "COMPANY_ID")
    @GeneratedValue(generator = "lexiconCompanyIdGenerator" )
    private long id;

    @Column(name="COMPANY_PUBKEY",nullable = false,length = 20)
    private String pubkey;

    @Column(name="COMPANY_NAME", nullable = false, length=50)
    private String name;

    @Type(type = "boolean-yn")
    @Column(name="IS_ACTIVE",nullable = false)
    private boolean active;

    @Type(type = "boolean-yn")
    @Column(name="IS_COMPETITOR",nullable = false)
    private boolean competitor;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isCompetitor() {
        return competitor;
    }

    public void setCompetitor(boolean competitor) {
        this.competitor = competitor;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }
}
