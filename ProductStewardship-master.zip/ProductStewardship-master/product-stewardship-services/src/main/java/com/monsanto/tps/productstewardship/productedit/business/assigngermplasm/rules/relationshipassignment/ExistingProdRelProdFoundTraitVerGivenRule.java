package com.monsanto.tps.productstewardship.productedit.business.assigngermplasm.rules.relationshipassignment;


import com.monsanto.Util.StringUtils;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ProductRelationshipDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;

public class ExistingProdRelProdFoundTraitVerGivenRule implements ValidationSimpleRule<Product>{

  private LexiconProductDao lexiconProductDao;
  private ProductRelationshipDao productRelationshipDao;

  @Override
  public void validate(Product model, ValidationStatus status) {

    if ((!isExistingLexiconProduct(model.getPreCommercialName()))&&
      (model.getManufacturingName() != null))
    {
      ProductRelationshipEntity existingProductRelationship = productRelationshipDao.getByManufacturingName(model.getManufacturingName());
      if ((existingProductRelationship != null) &&
          (existingProductRelationship.getProductRelationshipXRefs().size()>1) &&
          (StringUtils.isNullOrEmpty(model.getTraitVersion()))){
          status.addCondition(new ValidationResult(ProductEditService.PROD_REL_PROD_EXISTS_VERS_NOT_SPEC_CODE, ValidationSeverity.ERROR));
      }

    }

  }

  private boolean isExistingLexiconProduct(String preComlName){
    LexiconProductEntity existingProduct = (preComlName== null)?null:lexiconProductDao.getByPreCommercialName(preComlName);
    if ((existingProduct == null) ||(existingProduct.isLogicalDelete())){
       return false;
    } else {
       return true;
    }
  }

  public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
    this.lexiconProductDao = lexiconProductDao;
  }

  public void setProductRelationshipDao(ProductRelationshipDao productRelationshipDao) {
    this.productRelationshipDao = productRelationshipDao;
  }
}
