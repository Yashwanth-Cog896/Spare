/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.StringType;
import org.hibernate.type.Type;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* vvkalu - 6/30/11 */
public class LexiconCropDaoImpl extends GenericDaoImpl<LexiconCropEntity, Long> implements LexiconCropDao{
    public static final String NON_ALPHABETIC_CHARACTERS = "[^\\p{Alpha}]";
    @Resource
    private SessionFactory sessionFactory;

    public LexiconCropDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<LexiconCropEntity> retrieveUserCrops(List<String> userRoleNames) {
        if(userRoleNames==null||userRoleNames.isEmpty()){
            return new ArrayList<LexiconCropEntity>();
        }
        Session session = sessionFactory.getCurrentSession();
        List<String> capsUserRoleName= new ArrayList<String>(userRoleNames.size());
         List<Type> types = new ArrayList<Type>(userRoleNames.size());
        StringBuilder criteriaBuilder = new StringBuilder("UPPER(REGEXP_REPLACE(crop_name,'[^[:alpha:]]','')) in (");
        boolean firstRecord = true;
        for(String userRoleName: userRoleNames){
            if(!firstRecord){
                criteriaBuilder.append(",");
            }
            criteriaBuilder.append("?");
            capsUserRoleName.add(userRoleName.toUpperCase().replaceAll(NON_ALPHABETIC_CHARACTERS, ""));
            types.add(new StringType());
            firstRecord=false;
        }
        criteriaBuilder.append(")");
        Criteria criteria = session.createCriteria(LexiconCropEntity.class)
                                   .add(Restrictions.sqlRestriction(criteriaBuilder.toString(),
                                                                    capsUserRoleName.toArray(new Object[capsUserRoleName.size()]),
                                                                    types.toArray(new Type[types.size()])));
        return (List<LexiconCropEntity>) criteria.list();
    }

    @Override
    public LexiconCropEntity getByName(@DynamicDaoParameter(name = "name") String name) {
        return null;  //Do nothing here because dynamic dao handles behaviour via aop.
    }
}