package com.monsanto.tps.productstewardship.sap.business.rowcrop;


import com.google.common.collect.Multimap;
import com.monsanto.Util.StringUtils;
import com.monsanto.sap.rowcrop.webservice.SapSyncResponse;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.PqSapQueueEntryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapProductLogStatus;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import com.monsanto.tps.productstewardship.sap.business.vegetable.PqSapLogWriter;
import com.thoughtworks.xstream.XStream;

import java.util.*;

public class SapRowCropResponseHandler {
  private PqSapQueueEntryDao pqSapQueueEntryDao;
  private PqSapLogWriter pqSapLogWriter;

  public List<PqSapQueueEntryEntity> processResponses(List<SapSyncResponse> responses, List<PqSapQueueEntryEntity> pqSapQueueEntries, Multimap<Long, PqSapQueueEntryEntity> productMap) {
    List<PqSapQueueEntryEntity> successfulQueueEntries = new ArrayList<PqSapQueueEntryEntity>();
    for (SapSyncResponse response:responses){
      if (StringUtils.isNullOrEmpty(response.getErrorDetail())){
        successfulQueueEntries.addAll(productMap.get(response.getSapLinkageAuditId()));
        processSuccessfulResponses(productMap.get(response.getSapLinkageAuditId()));
      }   else {
        processFailQueueEntries(productMap.get(response.getSapLinkageAuditId()), response);
      }
    }
    pqSapQueueEntries.removeAll(successfulQueueEntries);
    return  pqSapQueueEntries;
  }

  public void removeQueueEntries(Collection<PqSapQueueEntryEntity> queueEntries) {
      for (PqSapQueueEntryEntity queueEntry:queueEntries){
        pqSapQueueEntryDao.delete(queueEntry);
      }
  }

  private void processFailQueueEntries(Collection<PqSapQueueEntryEntity> pqSapQueueEntryEntities, SapSyncResponse response) {
    for (PqSapQueueEntryEntity queueEntry:pqSapQueueEntryEntities){
      pqSapLogWriter.buildAndPersistLogEntry(queueEntry,PqSapProductLogStatus.E,createErrorMessage(response.getErrorDetail()));
    }
  }

  private void processSuccessfulResponses(Collection<PqSapQueueEntryEntity> pqSapQueueEntryEntities) {
    for (PqSapQueueEntryEntity queueEntry:pqSapQueueEntryEntities){
       pqSapLogWriter.buildAndPersistLogEntry(queueEntry, PqSapProductLogStatus.S,"SUCCESSFUL");
       pqSapQueueEntryDao.delete(queueEntry);
    }
  }
   private String createErrorMessage(Object errorDetails) {
      return new XStream().toXML(errorDetails);
   }

   public void setPqSapQueueEntryDao(PqSapQueueEntryDao pqSapQueueEntryDao) {
      this.pqSapQueueEntryDao = pqSapQueueEntryDao;
   }

   public void setPqSapLogWriter(PqSapLogWriter pqSapLogWriter) {
      this.pqSapLogWriter = pqSapLogWriter;
   }
}
