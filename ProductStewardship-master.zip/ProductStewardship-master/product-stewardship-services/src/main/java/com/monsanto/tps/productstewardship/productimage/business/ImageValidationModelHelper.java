package com.monsanto.tps.productstewardship.productimage.business;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.ConfigurationPictureDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductPictureDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ConfigurationPictureEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.productimage.service.ImageDimensions;
import com.monsanto.tps.productstewardship.productimage.service.ImageUploadRequest;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

/**
 * VVKALU - Mar 15, 2010 1:41:34 AM
 */
public class ImageValidationModelHelper {

    private LexiconProductDao lexiconProductDao;
    private ConfigurationPictureDao configurationPictureDao;
    private ImageValidationModel model;
    private LexiconProductPictureDao lexiconProductPictureDao;

    public ImageValidationModel getValidationModel(ImageUploadRequest imageRequest) throws WrappingException, IOException {
        model = new ImageValidationModel();
        LexiconProductEntity preComlProduct = findPreComlProduct(imageRequest.getProductPubKey());
        model.setLexiconProduct(preComlProduct);
        model.setDisplayName(imageRequest.getImageTitle());
        getImagePixelsAndFormat(imageRequest.getImageData().getDataSource().getInputStream());
        findImageByDisplayName(imageRequest.getImageTitle());
        getConfigurationPicture();
        return model;
    }

    private void getConfigurationPicture() throws WrappingException {
        List<ConfigurationPictureEntity> configurationPictures = configurationPictureDao.loadAll();
        model.setConfigurationPicture(configurationPictures.get(0));
    }

    private void findImageByDisplayName(String imageTitle) throws WrappingException {
        model.setLexiconProductPicture(lexiconProductPictureDao.getByDisplayname(imageTitle));
    }

    private LexiconProductEntity findPreComlProduct(String prodPubKey) throws WrappingException {
        return lexiconProductDao.getByPubkey(prodPubKey);
    }

    private void getImagePixelsAndFormat(InputStream in) throws IOException {
        ImageInputStream iis = null;
        ImageReader reader = null;
        try {
            iis = ImageIO.createImageInputStream(in);
            Iterator readers = ImageIO.getImageReaders(iis);
            if (!readers.hasNext()) {
                model.setPreConditionMet(false);
            } else {
                ImageDimensions dimensions = new ImageDimensions();
                reader = (ImageReader) readers.next();
                reader.setInput(iis);
                dimensions.setImageHeight(reader.getHeight(0));
                dimensions.setImageWidth(reader.getWidth(0));
                model.setPreConditionMet(true);
                model.setImageDimensions(dimensions);
                model.setFormatName(reader.getFormatName());
            }
        } finally {
            close(iis);
            if (reader != null) {
                reader.dispose();
            }
        }
    }

    private void close(ImageInputStream iis) throws IOException {
        if (iis != null) {
            iis.close();
        }
    }

    public ConfigurationPictureDao getConfigurationPictureDao() {
        return configurationPictureDao;
    }

    public void setConfigurationPictureDao(ConfigurationPictureDao configurationPictureDao) {
        this.configurationPictureDao = configurationPictureDao;
    }

    public LexiconProductDao getLexiconProductDao() {
        return lexiconProductDao;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public LexiconProductPictureDao getLexiconProductPictureDao() {
        return lexiconProductPictureDao;
    }

    public void setLexiconProductPictureDao(LexiconProductPictureDao lexiconProductPictureDao) {
        this.lexiconProductPictureDao = lexiconProductPictureDao;
    }
}
