package com.monsanto.tps.productstewardship.productassociation.dao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 12, 2011
 * Time: 10:44:17 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductAssociationDao  {
   List<ProductAssociation> findByBaseManufacturingName(List<String> names, boolean hybridOnly, List<String> cropPubkeys);
   List<ProductAssociation> findByManufacturingName(List<String> names, boolean hybridOnly, List<String> cropPubkeys);
   List<ProductAssociation> findByVarietyName(List<String> names, boolean hybridOnly, List<String> cropPubkeys);
   List<ProductAssociation> findByPreCommercialName(List<String> names, boolean hybridOnly, List<String> cropPubkeys);
   List<ProductAssociation> findByTagVarietyName(List<String> names, boolean hybridOnly, List<String> cropPubkeys);
}
