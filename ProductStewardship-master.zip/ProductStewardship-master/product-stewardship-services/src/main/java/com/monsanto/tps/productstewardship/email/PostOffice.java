package com.monsanto.tps.productstewardship.email;

import javax.mail.MessagingException;

/**
 * User: pjberry
 * Date: Oct 23, 2007
 * Time: 12:01:15 PM
 */
public interface PostOffice
{
   void send(String recipientAddressesCSV, String senderAddress, String subject, String body) throws MessagingException;
}
