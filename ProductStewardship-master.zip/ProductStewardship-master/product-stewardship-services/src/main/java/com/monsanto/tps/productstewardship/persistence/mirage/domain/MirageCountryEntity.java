package com.monsanto.tps.productstewardship.persistence.mirage.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 27, 2011
 * Time: 11:10:48 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "COUNTRIES", schema = "Mirage2")
public class MirageCountryEntity  implements Serializable {
    @Id
    @Column(name="COUNTRY_CODE",length=3)
    private String code;
    @Column(name="COUNTRY_NAME",length=80,nullable = false)
    private String name;
    @Column(name="REGION_CODE",precision = 8,scale = 0,nullable = true)
    private long regionCode;
    @Column(name="SUBCOUNTRY_LABEL",length=15,nullable = true)
    private String subCountryLabel;
    @Column(name="SUBSUBCOUNTRY_LABEL",length=15,nullable = true)
    private String subSubCountryLabel;
    @Column(name="COUNTRY_ABBREV",length=3,nullable = false)
    private String abbreviation;
    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name="AUDIT_ID",nullable=false)
    private MirageAuditEntity audit;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public MirageAuditEntity getAudit() {
        return audit;
    }

    public void setAudit(MirageAuditEntity audit) {
        this.audit = audit;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(long regionCode) {
        this.regionCode = regionCode;
    }

    public String getSubCountryLabel() {
        return subCountryLabel;
    }

    public void setSubCountryLabel(String subCountryLabel) {
        this.subCountryLabel = subCountryLabel;
    }

    public String getSubSubCountryLabel() {
        return subSubCountryLabel;
    }

    public void setSubSubCountryLabel(String subSubCountryLabel) {
        this.subSubCountryLabel = subSubCountryLabel;
    }

}
