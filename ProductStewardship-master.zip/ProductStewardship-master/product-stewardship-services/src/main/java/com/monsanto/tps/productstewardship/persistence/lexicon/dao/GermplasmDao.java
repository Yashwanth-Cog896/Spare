package com.monsanto.tps.productstewardship.persistence.lexicon.dao;


import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;

import java.util.List;
import java.util.Map;

public interface GermplasmDao extends GenericDao<GermplasmEntity,Long>{

    Map<String,List<String>>  getFemaleMaleLexiconPubKey(Long germplasmID);
}
