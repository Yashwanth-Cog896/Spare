package com.monsanto.osb.webservice.credentials;

import com.monsanto.tps.productstewardship.gqa.business.WebMethodsCredentials;

public class CredentialsFactory {
    public static final String PASSWORD_XML_TYPE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText";
    private WebMethodsCredentials webMethodsCredentials;

    public CredentialsContainer createCredentialsContainer() {
        Credentials credentials = new Credentials();
        credentials.setUsername(webMethodsCredentials.getUsername());
        Password password = new Password();
        password.setValue(webMethodsCredentials.getPassword());
        password.setType(PASSWORD_XML_TYPE);
        credentials.setPassword(password);
        CredentialsContainer credentialsContainer= new CredentialsContainer();
        credentialsContainer.setCredentials(credentials);
        return credentialsContainer;
    }

    public void setWebMethodsCredentials(WebMethodsCredentials webMethodsCredentials) {
        this.webMethodsCredentials = webMethodsCredentials;
    }
}
