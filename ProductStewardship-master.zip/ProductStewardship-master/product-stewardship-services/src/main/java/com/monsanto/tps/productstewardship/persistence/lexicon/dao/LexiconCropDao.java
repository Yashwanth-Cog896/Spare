/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;

import java.util.List;

/* vvkalu - 6/30/11 */
public interface LexiconCropDao extends GenericDao<LexiconCropEntity,Long> {

    List<LexiconCropEntity> retrieveUserCrops(List<String> userRoleNames);
    @DynamicDaoMethod(queryName = "LexiconCropEntity.getByName",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public LexiconCropEntity getByName(@DynamicDaoParameter(name="name")String name);
}