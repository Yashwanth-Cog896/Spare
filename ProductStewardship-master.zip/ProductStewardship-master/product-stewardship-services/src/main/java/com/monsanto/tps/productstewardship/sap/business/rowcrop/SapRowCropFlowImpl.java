package com.monsanto.tps.productstewardship.sap.business.rowcrop;


import com.monsanto.tps.productstewardship.persistence.lexicon.dao.PqSapQueueEntryDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.StageCategoryEntity;
import com.monsanto.tps.productstewardship.sap.business.rowcrop.relationship.LexiconRelationshipFlow;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

public class SapRowCropFlowImpl implements SapRowCropFlow {
  private PqSapQueueEntryDao pqSapQueueEntryDao;
  private LexiconRelationshipFlow lexiconRelationshipFlow;
  private SapRowCropResponseHandler sapRowCropResponseHandler;

   @Override
   @Transactional(propagation = Propagation.REQUIRED)
   public List<List<PqSapQueueEntryEntity>> retrievePqSapQueueEntriesInGroupToProcess(int groupSize){
     List<PqSapQueueEntryEntity> sapQueueEntries = retrievePqSapQueueEntries();
     boolean extraGroup = (sapQueueEntries.size() % groupSize)>0;
     int numberOfGroup = (sapQueueEntries.size()/groupSize)+(extraGroup?1:0);
     List<List<PqSapQueueEntryEntity>> sapQueueEntriesInGroups = new ArrayList<List<PqSapQueueEntryEntity>>();
     int maxEndIndex = sapQueueEntries.size();
     for (int i=0; i<numberOfGroup; i++){
       int startIndex = i*groupSize;
       int endIndex = startIndex + groupSize;
       if (endIndex>maxEndIndex){
         endIndex = maxEndIndex;
       }
       sapQueueEntriesInGroups.add(sapQueueEntries.subList(startIndex,endIndex));
     }
     return sapQueueEntriesInGroups;
   }

   @Override
   @Transactional(propagation = Propagation.REQUIRED)
   public  void flowNextChangesToSap(List<PqSapQueueEntryEntity> pqSapQueueEntries){
     if (!pqSapQueueEntries.isEmpty()){
       lexiconRelationshipFlow.flowProducts(pqSapQueueEntries);
       removeBaseProductsFromQueue(pqSapQueueEntries);
     }
   }

   private void removeBaseProductsFromQueue(List<PqSapQueueEntryEntity> queueEntries) {
      List<PqSapQueueEntryEntity> baseProducts = new ArrayList<PqSapQueueEntryEntity>();
      for(PqSapQueueEntryEntity queueEntry : queueEntries) {
          if(PqSapQueueEntryEntity.BASE_PRODUCT.equals(queueEntry.getTableName())) {
              baseProducts.add(queueEntry);
          }
      }
      sapRowCropResponseHandler.removeQueueEntries(baseProducts);
   }

   private List<PqSapQueueEntryEntity> retrievePqSapQueueEntries() {
      List<PqSapQueueEntryEntity> queueEntriesToProcess = pqSapQueueEntryDao.getPqSapRowCropQueueEntriesToProcessForSap(StageCategoryEntity.VEGETABLE);
      for (PqSapQueueEntryEntity queueEntry:queueEntriesToProcess); //make sure list is completely fetched so transaction is not required to read list.
      return queueEntriesToProcess;
   }

    public void setPqSapQueueEntryDao(PqSapQueueEntryDao pqSapQueueEntryDao) {
      this.pqSapQueueEntryDao = pqSapQueueEntryDao;
    }

    public void setLexiconRelationshipFlow(LexiconRelationshipFlow lexiconRelationshipFlow) {
      this.lexiconRelationshipFlow = lexiconRelationshipFlow;
    }

    public void setSapRowCropResponseHandler(SapRowCropResponseHandler sapRowCropResponseHandler) {
      this.sapRowCropResponseHandler = sapRowCropResponseHandler;
    }
}
