package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GeneticMaterialEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 8, 2011
 * Time: 3:41:55 PM
 * To change this template use File | Settings | File Templates.
 */
public interface GeneticMaterialDao extends GenericDao<GeneticMaterialEntity,Long>{
             @DynamicDaoMethod(queryName = "GeneticMaterialDao.getWithParentageByMidasProductIds",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
             List<GeneticMaterialEntity> getWithParentageByMidasProductIds(@DynamicDaoParameter(name="requestId") Long requestId);  
}
