package com.monsanto.tps.productstewardship.persistence.mirage.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 27, 2011
 * Time: 10:35:20 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@SequenceGenerator(name = "mirageAuditIdGenerator",allocationSize = 1,sequenceName = "Mirage2.AUDIT_ID_SEQ")
@Table(name = "AUDIT_HISTORY", schema = "Mirage2")
public class MirageAuditEntity  implements Serializable {
    @Id
    @Column(name="AUDIT_ID")
    @GeneratedValue(generator = "mirageAuditIdGenerator")
    private long id;
    @Temporal(TemporalType.DATE)
    @Column(name="AUDIT_DATE",nullable = false)
    private Date date;
    @Column(name="AUDIT_USER",nullable=false,length = 35)
    private String user;
    @Column(name="AUDIT_CLIENT",nullable=false,length=40)
    private String client;
    @Column(name="AUDIT_EVENT",nullable=false,length=80)
    private String event;
    @Column(name="EVENT_TAG",nullable=false,length=80)
    private String eventTag;
    @Column(name="EVENT_REMARK",nullable = false,length=2000)
    private String eventRemark;


    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getEventRemark() {
        return eventRemark;
    }

    public void setEventRemark(String eventRemark) {
        this.eventRemark = eventRemark;
    }

    public String getEventTag() {
        return eventTag;
    }

    public void setEventTag(String eventTag) {
        this.eventTag = eventTag;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
