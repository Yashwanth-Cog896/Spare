package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 16, 2011
 * Time: 3:50:18 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
    @Table(name = "GENETIC_MATERIAL", schema = "MIDAS")
@GenericGenerator(
   name="midas_generator",
   strategy="com.monsanto.tps.primarykey.midas.MidasKeyGenerator"
)

public class GeneticMaterialEntity  implements Serializable {
    @Id
     @GeneratedValue(generator="midas_generator")
     @Column(name = "GENETIC_MATERIAL_ID", nullable = false)
     private Long id;

     @Column(name = "SOURCE_STR",nullable = false)
     private String source;

     @Column(name = "GENERATION")
     private String generation;

     @Column(name = "LINEAGE")
     private String lineage;

     @Column(name = "INBRED_LINE_RATING_CD")
     private String lineRating;

     @Column(name = "IS_AUTOGEN")
     @Type(type="true_false")
     private Boolean autogen;

     @ManyToOne(fetch = FetchType.LAZY)
     @JoinColumn(name="GERMPLASM_ID",nullable = false)
     private GermplasmEntity germplasm;

     @OneToMany(mappedBy = "child",fetch = FetchType.LAZY)
     private Set<GeneticMaterialParentEntity> parents= new HashSet<GeneticMaterialParentEntity>();

    public Boolean getAutogen() {
        return autogen;
    }

    public void setAutogen(Boolean autogen) {
        this.autogen = autogen;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public String getLineRating() {
        return lineRating;
    }

    public void setLineRating(String lineRating) {
        this.lineRating = lineRating;
    }

    public Set<GeneticMaterialParentEntity> getParents() {
        return parents;
    }

    public void setParents(Set<GeneticMaterialParentEntity> parents) {
        this.parents = parents;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || !getClass().isAssignableFrom(o.getClass())) return false;

        GeneticMaterialEntity that = (GeneticMaterialEntity) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
