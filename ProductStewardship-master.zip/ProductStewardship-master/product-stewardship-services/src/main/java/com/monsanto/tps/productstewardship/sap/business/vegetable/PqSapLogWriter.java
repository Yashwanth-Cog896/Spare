package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.monsanto.Util.Exceptions.ExceptionAsString;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.PqSapLogDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapLogEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapProductLogStatus;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.PqSapQueueEntryEntity;
import org.apache.log4j.Logger;

import java.util.Date;
import java.util.List;

public class PqSapLogWriter {
 private PqSapLogDao pqSapLogDao;
 private static final org.apache.log4j.Logger log = Logger.getLogger(PqSapLogWriter.class);
    private String truncateIfNecessary(String errorMessage) {
        String truncatedMessage = null;
        if(errorMessage!=null){
            truncatedMessage = errorMessage.substring(0, Math.min(errorMessage.length(), PqSapLogDao.MAX_ERROR_MESSAGE_LENGTH));
        }
        return truncatedMessage;
    }

    public void logException(List<PqSapQueueEntryEntity> pqSapQueueEntriesToProceses, Exception e) {
        log.error(e.getMessage(),e);
        for(PqSapQueueEntryEntity pqSapQueueEntry : pqSapQueueEntriesToProceses){
            buildAndPersistLogEntry(pqSapQueueEntry, PqSapProductLogStatus.E, createThrowableErrorMessage(e));
        }
   }
   private String createThrowableErrorMessage(Throwable throwable) {
     return truncateIfNecessary(throwable.getMessage()+"\n"+new ExceptionAsString().getStackTraceAsString(throwable));
   }
   public PqSapLogEntity buildAndPersistLogEntry(PqSapQueueEntryEntity pqSapQueueEntry, PqSapProductLogStatus status, String message) {
        PqSapLogEntity pqSapLog = new PqSapLogEntity();
        pqSapLog.setInitDate(pqSapQueueEntry.getInitDate());
        pqSapLog.setStatus(status);
        pqSapLog.setMessage(truncateIfNecessary(message));
        pqSapLog.setTableId(pqSapQueueEntry.getTableId());
        pqSapLog.setTableName(pqSapQueueEntry.getTableName());
        pqSapLog.setCloseDate(new Date());
        pqSapLog.setProcessType(pqSapQueueEntry.getProcessType());
        return pqSapLogDao.saveOrUpdate(pqSapLog);
    }

    public void setPqSapLogDao(PqSapLogDao pqSapLogDao) {
        this.pqSapLogDao = pqSapLogDao;
    }
}
