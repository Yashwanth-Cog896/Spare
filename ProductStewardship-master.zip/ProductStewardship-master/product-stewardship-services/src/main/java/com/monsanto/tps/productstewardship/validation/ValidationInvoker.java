package com.monsanto.tps.productstewardship.validation;



import java.util.List;

/**
 * vvkalu - Feb 25, 2010 9:01:43 AM
 */
public class ValidationInvoker<ModelT> {

   private List<ValidationSimpleRule> rules;

   public ValidationInvoker(List<ValidationSimpleRule> rules) {
      this.rules = rules;
   }

   public ValidationStatus executeValidations(ModelT model) {
      ValidationStatus status = new ValidationStatus();
      for (ValidationSimpleRule rule : rules) {
         rule.validate(model, status);
      }
      return status;
   }
}
