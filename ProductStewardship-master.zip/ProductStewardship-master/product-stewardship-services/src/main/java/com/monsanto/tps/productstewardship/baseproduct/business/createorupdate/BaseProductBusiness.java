package com.monsanto.tps.productstewardship.baseproduct.business.createorupdate;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.transform.BaseProductEntityTransformer;
import com.monsanto.tps.productstewardship.persistence.lexicon.transform.BaseProductTransformer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: 8/15/11
 * Time: 2:55 PM
 */
public class BaseProductBusiness {

    private BaseProductEntityTransformer baseProductEntityTransformer;
    private BaseProductTransformer baseProductTransformer;
    private BaseProductDao baseProductDao;

    public List<BaseProduct> saveOrUpdate(List<BaseProduct> baseProducts){
        List<BaseProduct> savedBaseProducts = new ArrayList<BaseProduct>();
        for (BaseProduct baseProduct : baseProducts) {
            BaseProductEntity baseProductEntity = baseProductTransformer.transformBaseProduct(baseProduct);
            BaseProductEntity savedBaseProductEntity = baseProductDao.saveOrUpdate(baseProductEntity);
            BaseProduct savedBaseProduct = baseProductEntityTransformer.transformBaseProduct(savedBaseProductEntity);
            savedBaseProducts.add(savedBaseProduct);
        }
        return savedBaseProducts;
    }

    public void setBaseProductEntityTransformer(BaseProductEntityTransformer baseProductEntityTransformer) {
        this.baseProductEntityTransformer = baseProductEntityTransformer;
    }

    public void setBaseProductTransformer(BaseProductTransformer baseProductTransformer) {
        this.baseProductTransformer = baseProductTransformer;
    }

    public void setBaseProductDao(BaseProductDao baseProductDao) {
        this.baseProductDao = baseProductDao;
    }
}
