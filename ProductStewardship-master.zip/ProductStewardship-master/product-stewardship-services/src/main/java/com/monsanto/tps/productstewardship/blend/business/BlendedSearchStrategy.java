package com.monsanto.tps.productstewardship.blend.business;

import com.google.common.collect.Multimap;
import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 6, 2011
 * Time: 3:52:17 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BlendedSearchStrategy {

    Multimap<Long, FbsCommonProductXrefEntity> buildGermplasmIdToProductXrefsMap(Map<Long, FbsCommonProductXrefEntity> xrefByProductIds,
                                                                  BlendedProductDetails productDetails);


    LexBlendedProductDetails buildLexBlendedProductDetails(BlendedProductDetails blendedProductDetail,
                                                           Multimap<Long, BlendedPreComlProduct> germplasmIdToPreComlProductsMap);
}
