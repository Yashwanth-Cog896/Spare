package com.monsanto.sap.vegetable.webservice.variety;



import com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for DT_LexiconVariety_Rsp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DT_LexiconVariety_Rsp">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Header">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DocumentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="DocumentDateTime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                   &lt;element name="From">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="PartnerIdentifier" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                                     &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="ContactInformation" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                   &lt;element name="To" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="PartnerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="PartnerIdentifier" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;simpleContent>
 *                                   &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>string">
 *                                     &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                                   &lt;/extension>
 *                                 &lt;/simpleContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="ContactInformation" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="ContactName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="ContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="VarietyResponse">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="RecErrorStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="RecInsertStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="RecRecvStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="RecUpdateStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="ErrorDetails" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="Pubkey" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="VarietyNameCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="ErrorID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                             &lt;element name="ErrorDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "MT_LexiconVariety_OSB_Rsp",namespace="http://monsanto.com/MM/R3/ALSB/LexiconVariety")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MT_LexiconVariety_OSB_Rsp", propOrder = {
    "header",
    "varietyResponse"
})
public class DTLexiconVarietyRsp {

    @XmlElement(name = "Header", required = true)
    private DTLexiconHeader header;
    @XmlElement(name = "VarietyResponse", required = true)
    private VarietyResponse varietyResponse;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader }
     *     
     */
    public DTLexiconHeader getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.monsanto.sap.vegetable.webservice.common.DTLexiconHeader }
     *     
     */
    public void setHeader(DTLexiconHeader value) {
        this.header = value;
    }

    /**
     * Gets the value of the varietyResponse property.
     * 
     * @return
     *     possible object is
     *     {@link VarietyResponse }
     *
     */
    public VarietyResponse getVarietyResponse() {
        return varietyResponse;
    }

    /**
     * Sets the value of the varietyResponse property.
     *
     * @param value
     *     allowed object is
     *     {@link VarietyResponse }
     *
     */
    public void setVarietyResponse(VarietyResponse value) {
        this.varietyResponse = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="RecErrorStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="RecInsertStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="RecRecvStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="RecUpdateStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="ErrorDetails" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="Pubkey" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="VarietyNameCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="ErrorID" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                   &lt;element name="ErrorDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     *
     *
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "recErrorStatus",
        "recInsertStatus",
        "recRecvStatus",
        "recUpdateStatus",
        "errorDetails"
    })
    public static class VarietyResponse {

        @XmlElement(name = "RecErrorStatus")
        private String recErrorStatus;
        @XmlElement(name = "RecInsertStatus")
        private String recInsertStatus;
        @XmlElement(name = "RecRecvStatus")
        private String recRecvStatus;
        @XmlElement(name = "RecUpdateStatus")
        private String recUpdateStatus;
        @XmlElement(name = "ErrorDetails", required = true)
        private List<ErrorDetails> errorDetails;

        /**
         * Gets the value of the recErrorStatus property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getRecErrorStatus() {
            return recErrorStatus;
        }

        /**
         * Sets the value of the recErrorStatus property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setRecErrorStatus(String value) {
            this.recErrorStatus = value;
        }

        /**
         * Gets the value of the recInsertStatus property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getRecInsertStatus() {
            return recInsertStatus;
        }

        /**
         * Sets the value of the recInsertStatus property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setRecInsertStatus(String value) {
            this.recInsertStatus = value;
        }

        /**
         * Gets the value of the recRecvStatus property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getRecRecvStatus() {
            return recRecvStatus;
        }

        /**
         * Sets the value of the recRecvStatus property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setRecRecvStatus(String value) {
            this.recRecvStatus = value;
        }

        /**
         * Gets the value of the recUpdateStatus property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getRecUpdateStatus() {
            return recUpdateStatus;
        }

        /**
         * Sets the value of the recUpdateStatus property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setRecUpdateStatus(String value) {
            this.recUpdateStatus = value;
        }

        /**
         * Gets the value of the errorDetails property.
         *
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the errorDetails property.
         *
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getErrorDetails().add(newItem);
         * </pre>
         *
         *
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link ErrorDetails }
         * 
         * 
         */
        public List<ErrorDetails> getErrorDetails() {
            if (errorDetails == null) {
                errorDetails = new ArrayList<ErrorDetails>();
            }
            return this.errorDetails;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="Pubkey" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="Level" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="VarietyNameCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="ErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="ErrorID" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *         &lt;element name="ErrorDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "pubkey",
            "level",
            "varietyNameCode",
            "errorCode",
            "errorID",
            "errorDescription"
        })
        public static class ErrorDetails {

            @XmlElement(name = "Pubkey", required = true)
            private String pubkey;
            @XmlElement(name = "Level", required = true)
            private String level;
            @XmlElement(name = "VarietyNameCode", required = true)
            private String varietyNameCode;
            @XmlElement(name = "ErrorCode", required = true)
            private String errorCode;
            @XmlElement(name = "ErrorID", required = true)
            private String errorID;
            @XmlElement(name = "ErrorDescription", required = true)
            private String errorDescription;

            /**
             * Gets the value of the pubkey property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getPubkey() {
                return pubkey;
            }

            /**
             * Sets the value of the pubkey property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setPubkey(String value) {
                this.pubkey = value;
            }

            /**
             * Gets the value of the level property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLevel() {
                return level;
            }

            /**
             * Sets the value of the level property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLevel(String value) {
                this.level = value;
            }

            /**
             * Gets the value of the varietyNameCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getVarietyNameCode() {
                return varietyNameCode;
            }

            /**
             * Sets the value of the varietyNameCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setVarietyNameCode(String value) {
                this.varietyNameCode = value;
            }

            /**
             * Gets the value of the errorCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getErrorCode() {
                return errorCode;
            }

            /**
             * Sets the value of the errorCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setErrorCode(String value) {
                this.errorCode = value;
            }

            /**
             * Gets the value of the errorID property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getErrorID() {
                return errorID;
            }

            /**
             * Sets the value of the errorID property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setErrorID(String value) {
                this.errorID = value;
            }

            /**
             * Gets the value of the errorDescription property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getErrorDescription() {
                return errorDescription;
            }

            /**
             * Sets the value of the errorDescription property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setErrorDescription(String value) {
                this.errorDescription = value;
            }

        }

    }

}
