package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicFilterableEntityDaoMethod;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;

import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 8, 2011
 * Time: 5:24:17 PM
 * To change this template use File | Settings | File Templates.
 */

public interface ProductRelationshipXRefDao extends GenericDao<ProductRelationshipXrefEntity, Long>{

    @DynamicFilterableEntityDaoMethod(filterableEntity = ProductRelationshipXrefEntity.class)
    List<ProductRelationshipXrefEntity> findProductRelationshipXrefByFilter(Filter[] filters);

    List<ProductRelationshipXrefEntity>  findProductRelationshipsByBaseManufacturingName(List<String>names,boolean hybridOnly,List<String>cropPubkeys);
}
