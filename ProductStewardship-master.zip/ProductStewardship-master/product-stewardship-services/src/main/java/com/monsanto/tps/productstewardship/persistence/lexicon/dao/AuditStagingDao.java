package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 14, 2011
 * Time: 10:42:41 AM
 * To change this template use File | Settings | File Templates.
 */
public interface AuditStagingDao extends GenericDao<AuditStagingEntity,Long> {
    @DynamicDaoMethod(queryName = "AuditStagingDao.selectSessionMachine")
    public String getSessionMachine();
    @DynamicDaoMethod(queryName = "AuditStagingDao.selectSessionOsUser")
    String getSessionOsUser();
    @DynamicDaoMethod(queryName = "AuditStagingDao.selectSessionId")
    public BigDecimal getSessionId();
    public void saveAndFlush(AuditStagingEntity auditStagingEntity);
}
