package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MapProductMirageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GeneticMaterialEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapProductMirageEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

public class MapProductMirageWriter {
       private MapProductMirageDao mapProductMirageDao;
    public void writeMapProductMirage(LexiconProductEntity lexiconProduct, MirageSeedProductEntity mirageSeedProduct, GeneticMaterialEntity mirageGeneticMaterial) {
        if((mirageGeneticMaterial!=null)&&(mirageSeedProduct!=null)){
           MapProductMirageEntity mapProductMirage = mapProductMirageDao.get(mirageSeedProduct.getId());
           if(mapProductMirage==null){
               mapProductMirage = new MapProductMirageEntity();
               mapProductMirage.setGeneticMaterial(mirageGeneticMaterial);
               mapProductMirage.setMidasProduct(lexiconProduct.getFbsCommonProductXref().getMidasProduct());
               mapProductMirage.setMirageName(mirageSeedProduct.getName());
               mapProductMirage.setMirageSeedProduct(mirageSeedProduct);
               mapProductMirageDao.saveOrUpdate(mapProductMirage);
           }
           else {
               mapProductMirage.setGeneticMaterial(mirageGeneticMaterial);
               mapProductMirage.setMidasProduct(lexiconProduct.getFbsCommonProductXref().getMidasProduct());
               mapProductMirage.setMirageName(mirageSeedProduct.getName());
           }
        }
    }

    public void setMapProductMirageDao(MapProductMirageDao mapProductMirageDao) {
        this.mapProductMirageDao = mapProductMirageDao;
    }
}
