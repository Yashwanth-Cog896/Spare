package com.monsanto.util.service;

import org.w3c.dom.Document;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 12, 2007
 * Time: 2:48:49 PM
 */
public interface ResponseStreamParser {
   Document parseResponse(final InputStream responseStream) throws IOException;
}