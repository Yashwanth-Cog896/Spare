package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapCropMirageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasCropEntity;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;

import javax.annotation.Resource;

public class MidasCropDaoImpl  extends GenericDaoImpl<MidasCropEntity,Long> implements MidasCropDao{
   public static final String SWEET_CORN = "SWEET CORN";
   public static final String TPS_CORN = "CORN";

   private String translate(String lexiconCropName) {
      return SWEET_CORN.equalsIgnoreCase(lexiconCropName) ? TPS_CORN : lexiconCropName;
   }
    @Resource
    private SessionFactory sessionFactory;

    public MidasCropDaoImpl(Class entityClass) {
        super(entityClass);
    }
    @Override
    public MapCropMirageEntity findMapCropMirage(String midasName) {
        Query query = sessionFactory.getCurrentSession().getNamedQuery("MidasCropDao.findMapCropMirage");
        query.setResultTransformer(Transformers.aliasToBean(MapCropMirageEntity.class));
        query.setParameter("midasName",translate(midasName.trim().toUpperCase()));
        return (MapCropMirageEntity)query.uniqueResult();
    }
}
