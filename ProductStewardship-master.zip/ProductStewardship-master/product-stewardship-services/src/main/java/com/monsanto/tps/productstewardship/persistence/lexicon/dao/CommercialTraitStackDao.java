package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import java.util.List;
public interface CommercialTraitStackDao extends GenericDao<CommercialTraitStackEntity,Long> {
    @DynamicDaoMethod(queryName = "CommercialTraitStackDao.getByPubkey",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    CommercialTraitStackEntity getByPubkey(@DynamicDaoParameter(name="pubkey") String pubkey);

    @DynamicDaoMethod(queryName = "CommercialTraitStackDao.getByTraitNameAndCrop",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<CommercialTraitStackEntity> getByTraitNameAndCrop(@DynamicDaoParameter(name="traitName") String traitName,@DynamicDaoParameter(name="lexiconCropName")String lexiconCropName);


    @DynamicDaoMethod(queryName = "CommercialTraitStackDao.getByTraitName",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<CommercialTraitStackEntity> getByTraitName(@DynamicDaoParameter(name="traitName") String traitName);

}
