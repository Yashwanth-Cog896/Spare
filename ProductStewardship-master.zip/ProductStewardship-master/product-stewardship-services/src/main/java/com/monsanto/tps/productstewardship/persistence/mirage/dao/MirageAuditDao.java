package com.monsanto.tps.productstewardship.persistence.mirage.dao;

import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageAuditEntity;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 15, 2011
 * Time: 10:47:48 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageAuditDao extends GenericDao<MirageAuditEntity,Long> {
    public static final String INSERT_SP_EVENT = "CREATE SEED PRODUCT";
    public static final String UPDATE_SP_EVENT = "UPDATE SEED PRODUCT";
    public static final String INSERT_MAT_EVENT = "CREATE SEED PRODUCT MATURITY";
    public static final String UPDATE_MAT_EVENT = "UPDATE SEED PRODUCT MATURITY";
    public static final String DELETE_MAT_EVENT = "DELETE SEED PRODUCT MATURITY";
    public MirageAuditEntity createAudit(String auditEvent);
}
