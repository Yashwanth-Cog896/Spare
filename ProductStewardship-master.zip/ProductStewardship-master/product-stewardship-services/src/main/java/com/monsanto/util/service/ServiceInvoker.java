package com.monsanto.util.service;

import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 11, 2007
 * Time: 5:59:32 PM
 */
public interface ServiceInvoker {
   Document call(Document requestDoc)
      throws WrappingException;
}
