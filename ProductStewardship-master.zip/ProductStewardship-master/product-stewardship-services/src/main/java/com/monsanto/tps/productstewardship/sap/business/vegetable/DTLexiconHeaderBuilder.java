package com.monsanto.tps.productstewardship.sap.business.vegetable;

import com.monsanto.sap.vegetable.webservice.common.*;

import java.util.Date;

public class DTLexiconHeaderBuilder {
    public static final String LEXICON_NAME = "LEXICON";
    public static final String SAP_VEGETABLE_LINKAGE_DOCUMENT = "SAP VEGETABLE LINKAGE DOCUMENT";
    public static final String TPS = "TPS";
    public static final String FROM_CONTACT_EMAIL = "DL-TPS-Lexicon-Dev@monsanto.com";
    public static final String COMMERCIAL = "COMMERCIAL";
    public static final String SAP = "SAP";
    public static final String TO_CONTACT_NAME = "URBAN, JASON J";
    public static final String TO_CONTACT_EMAIL = "JJURBA3@monsanto.com";

    public  DTLexiconHeader buildHeader() {
       DTLexiconHeader header = new DTLexiconHeader();
       header.setDocumentIdentifier(SAP_VEGETABLE_LINKAGE_DOCUMENT);
       header.setDocumentDateTime(new Date().toString());
       header.setFrom(from());
       header.setTo(to());
       return header;
    }

    private DTLexiconFrom from() {
       DTLexiconFrom from = new DTLexiconFrom();
       from.setPartnerName(LEXICON_NAME);
       from.setPartnerIdentifier(fromPartnerIdentifier());
       from.setContactInformation(fromContactInformation());
       return from;
    }

    private DTLexiconPartnerIdentifier fromPartnerIdentifier() {
       DTLexiconPartnerIdentifier fromPartnerIdentifier = new DTLexiconPartnerIdentifier();
       fromPartnerIdentifier.setType(TPS);
       fromPartnerIdentifier.setValue(LEXICON_NAME);
       return fromPartnerIdentifier;
    }

    private DTLexiconContactInformation fromContactInformation() {
       DTLexiconContactInformation fromContactInformation = new DTLexiconContactInformation();
       fromContactInformation.setContactName(LEXICON_NAME);
       fromContactInformation.setContactDescription(LEXICON_NAME);
       fromContactInformation.setContactPhoneNumber("");
       fromContactInformation.setEmailAddress(FROM_CONTACT_EMAIL);
       return fromContactInformation;
    }

    private DTLexiconTo to() {
       DTLexiconTo to = new DTLexiconTo();
       to.setPartnerName(SAP);
       to.setPartnerIdentifier(toPartnerIdentifier());
       to.setContactInformation(toContactInformation());
       return to;
    }

    private DTLexiconPartnerIdentifier toPartnerIdentifier() {
       DTLexiconPartnerIdentifier toPartnerIdentifier = new DTLexiconPartnerIdentifier();
       toPartnerIdentifier.setType(COMMERCIAL);
       toPartnerIdentifier.setValue(SAP);
       return toPartnerIdentifier;
    }

    protected DTLexiconContactInformation toContactInformation() {
       DTLexiconContactInformation toContactInformation = new DTLexiconContactInformation();
       toContactInformation.setContactName(TO_CONTACT_NAME);
       toContactInformation.setContactDescription(SAP);
       toContactInformation.setContactPhoneNumber("");
       toContactInformation.setEmailAddress(TO_CONTACT_EMAIL);
       return toContactInformation;
    }


}
