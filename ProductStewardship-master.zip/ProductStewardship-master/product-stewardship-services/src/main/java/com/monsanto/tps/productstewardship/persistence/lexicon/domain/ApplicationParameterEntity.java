package com.monsanto.tps.productstewardship.persistence.lexicon.domain;

import javax.persistence.*;
import java.util.Date;
@Entity
@Table(name = "APPLICATION_PARAMETER", schema = "Lexicon")
public class ApplicationParameterEntity {
     @Id
     @Column(name="APPLICATION_PARAMETER_ID")
     long id;
     @Column(name="PARAMETER_KEY_TXT",length = 50,nullable = false)
     String key;
     @Column(name="PARAMETER_VALUE_TXT",length = 200,nullable = true)
     String value;
     @Column(name="MODIFIED_DT",nullable = false)
     @Temporal(TemporalType.TIMESTAMP)
     Date  modifiedTimestamp;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Date getModifiedTimestamp() {
        return modifiedTimestamp;
    }

    public void setModifiedTimestamp(Date modifiedTimestamp) {
        this.modifiedTimestamp = modifiedTimestamp;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
