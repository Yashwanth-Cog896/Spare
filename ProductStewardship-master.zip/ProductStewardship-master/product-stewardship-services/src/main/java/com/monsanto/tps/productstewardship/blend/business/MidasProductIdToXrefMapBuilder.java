package com.monsanto.tps.productstewardship.blend.business;

import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.dataservices.product.transfer.ProductGermplasmDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasTempSessionOcdDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 6, 2011
 * Time: 12:59:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductIdToXrefMapBuilder {

    
    private  MidasProductDao midasProductDao;


    public Map<Long, FbsCommonProductXrefEntity> buildMap(List<BlendedProductDetails> productDetails) {
        long requestId = (long)(Math.random()*1000.0);
        Map<Long, FbsCommonProductXrefEntity> productIdToProductXrefMap = new HashMap<Long, FbsCommonProductXrefEntity>();
        if (checkForNullAndEmpty(productDetails)) {
            List<Long> midasProductIds = getMidasProductIds(productDetails);

            for(Long midasProductId: midasProductIds){
                MidasProductEntity midasProduct = midasProductDao.get(midasProductId);
                if(midasProduct!=null){
                    for(FbsCommonProductXrefEntity xref: midasProduct.getFbsCommonProductXrefs()){
                        productIdToProductXrefMap.put(midasProductId,xref);
                    }
                }
            }
        }
        return productIdToProductXrefMap;
    }

    private boolean checkForNullAndEmpty(List<BlendedProductDetails> blendedProductDetails) {
        return blendedProductDetails != null && !blendedProductDetails.isEmpty();
    }

    private List<Long> getMidasProductIds(List<BlendedProductDetails> blendedProductDetails) {
        List<Long> midasProductIds = new ArrayList<Long>();
        for (BlendedProductDetails productDetails : blendedProductDetails) {
            for (ProductGermplasmDetails componentGermplasm : productDetails.getComponentProductGermplasms()) {
                midasProductIds.addAll(componentGermplasm.getMidasProductIds());
            }
            for (ProductGermplasmDetails productGermplasm : productDetails.getBlendedProductGermplasms()) {
                midasProductIds.addAll(productGermplasm.getMidasProductIds());
            }
        }
        return midasProductIds;
    }

    public void setMidasProductDao(MidasProductDao midasProductDao) {
        this.midasProductDao = midasProductDao;
    }

}
