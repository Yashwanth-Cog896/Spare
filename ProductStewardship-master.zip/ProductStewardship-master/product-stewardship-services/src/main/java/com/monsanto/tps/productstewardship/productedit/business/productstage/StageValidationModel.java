package com.monsanto.tps.productstewardship.productedit.business.productstage;

import com.monsanto.tps.productstewardship.productedit.service.Product;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;

import java.util.List;

public class StageValidationModel {
    private List<Product> products;
    private Product product;
    private ProductStage productStage;

    public StageValidationModel(List<Product> products,Product product,ProductStage productStage){
        this.products = products;
        this.product=product;
        this.productStage=productStage;
    }
    public Product getProduct() {
        return product;
    }


    public ProductStage getProductStage() {
        return productStage;
    }

    public List<Product> getProducts() {
        return products;
    }
}
