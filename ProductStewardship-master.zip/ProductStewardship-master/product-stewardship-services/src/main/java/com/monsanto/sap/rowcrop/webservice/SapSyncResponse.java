package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.Util.Exceptions.WrappingException;

public interface SapSyncResponse {
   public static final String ERROR_MESSAGE = "E";
   public static final Integer ERROR_CODE = 1;
   public static final Integer SUCCESS_CODE = 0;
   public Long getSapLinkageAuditId();
   public String getUpdateResponse();
   public Integer getErrorCode();
   public String getErrorMessage();
   public String getErrorDetail();
   public String asXmlString() throws WrappingException;
}