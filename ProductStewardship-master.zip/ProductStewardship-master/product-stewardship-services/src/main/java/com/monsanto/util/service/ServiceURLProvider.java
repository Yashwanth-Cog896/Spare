package com.monsanto.util.service;

import java.io.IOException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 12, 2007
 * Time: 2:36:42 PM
 */
public interface ServiceURLProvider {
   String getServiceURL() throws IOException;
}
