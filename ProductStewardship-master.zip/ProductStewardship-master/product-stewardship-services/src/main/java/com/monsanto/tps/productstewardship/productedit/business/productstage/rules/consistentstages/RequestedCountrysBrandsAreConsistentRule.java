package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.consistentstages;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.productedit.service.ProductStage;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
//Oddly this rule has nothing to do with brands- the name is inherited from LexiconPOS -- Need to rename when migration effort complete.
public class RequestedCountrysBrandsAreConsistentRule implements ValidationSimpleRule<StageValidationModel> {
    private LexiconProductDao lexiconProductDao;
    private LexiconStageDao lexiconStageDao;
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        boolean ruleViolated = false;
        ProductStage productStage= model.getProductStage();

        LexiconStageEntity stage = getLexiconStage(productStage);
        if((stage!=null)&&(StringUtils.isNotBlank(productStage.getCountryAbbreviation()))){
            for(ProductStage testProductStage: model.getProduct().getProductStages()){
               if((productStage!=testProductStage)&&(! productStage.isDelete())){
                   LexiconStageEntity otherStage = getLexiconStage(testProductStage);
                   if((otherStage!=null)&&(stage.isCommercial()!=otherStage.isCommercial())&&
                    (productStage.getCountryAbbreviation().equals(testProductStage.getCountryAbbreviation()))){
                      ruleViolated=true;
                      break;
                  }
               }
            }
            for(LexiconProductStageEntity testProductStage: loadLexiconProductStagesNotInRequest(model)){
               if((!testProductStage.getPubkey().equals(productStage.getProductStagePubkey()))&&(testProductStage.getLexiconStage().isCommercial()!=stage.isCommercial())&&
                   (productStage.getCountryAbbreviation().equals(testProductStage.getLexiconCountry().getAbbreviation()))){
                   ruleViolated=true;
                   break;
                }
            }
            if(ruleViolated){
                status.addCondition(new ValidationResult(ProductEditService.REQ_COUNTRYS_BRANDS_INCONSISTENT_CODE, ValidationSeverity.ERROR));
            }
        }
        
    }

    private LexiconStageEntity getLexiconStage(ProductStage productStage) {
        LexiconStageEntity stage = null;
        String stageAbbreviation = productStage.getStageAbbreviation();
        if(StringUtils.isNotBlank(stageAbbreviation)){
            stage = lexiconStageDao.findStageByAbbreviation(stageAbbreviation);
        }
        return stage;
    }


    private Collection<LexiconProductStageEntity> loadLexiconProductStagesNotInRequest(StageValidationModel model) {
        Map<String,LexiconProductStageEntity> lexiconProductStageMap = new HashMap<String, LexiconProductStageEntity>();
        String productPubkey = model.getProduct().getProductPubkey();
        if(StringUtils.isNotBlank(productPubkey)){
            LexiconProductEntity lexiconProduct=lexiconProductDao.getByPubkey(productPubkey);
            if(!lexiconProduct.isLogicalDelete()){
                for(LexiconProductStageEntity lexiconProductStage:lexiconProduct.getLexiconProductStages()){
                    if(!lexiconProductStage.isLogicalDelete()){
                       lexiconProductStageMap.put(lexiconProductStage.getPubkey(),lexiconProductStage);
                    }
                }
                for(ProductStage productStage: model.getProduct().getProductStages()){
                    if(StringUtils.isNotBlank(productStage.getProductStagePubkey())){
                        lexiconProductStageMap.remove(productStage.getProductStagePubkey());
                    }
                }
            }
        }
        Collection<LexiconProductStageEntity> lexiconProductStages = lexiconProductStageMap.values();
        return lexiconProductStages;
    }

    public void setLexiconProductDao(LexiconProductDao lexiconProductDao) {
        this.lexiconProductDao = lexiconProductDao;
    }

    public void setLexiconStageDao(LexiconStageDao lexiconStageDao) {
        this.lexiconStageDao = lexiconStageDao;
    }
}
