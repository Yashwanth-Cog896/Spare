package com.monsanto.tps.productstewardship.persistence.lexicon.dao;


import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AutoNameBrandAssignEntity;

public interface AutoNameBrandAssignDao extends GenericDao<AutoNameBrandAssignEntity,Long> {

     @DynamicDaoMethod(queryName = "AutoNameBrandAssignEntity.getAutoNameBrand",
                     parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
     public AutoNameBrandAssignEntity getAutoNameBrand(@DynamicDaoParameter(name = "productTypeId") long productTypeId,
                                                          @DynamicDaoParameter(name = "productEnvironmentId") long productEnvironmentId);
}
