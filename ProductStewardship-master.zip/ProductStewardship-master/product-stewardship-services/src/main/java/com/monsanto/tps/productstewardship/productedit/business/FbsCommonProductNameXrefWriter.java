package com.monsanto.tps.productstewardship.productedit.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;

public class FbsCommonProductNameXrefWriter {
    private FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao;
    public void writeNameXref(LexiconProductStageEntity lexiconProductStage, MirageSeedProductEntity mirageSeedProduct, MidasProductNameEntity midasProductName) {
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = lexiconProductStage.getFbsCommonProductNameXref();
        if(fbsCommonProductNameXref==null){
           fbsCommonProductNameXref = new FbsCommonProductNameXrefEntity();
           fbsCommonProductNameXref.setLexiconPubkey(lexiconProductStage.getPubkey());
           lexiconProductStage.setFbsCommonProductNameXref(fbsCommonProductNameXref);
           fbsCommonProductNameXrefDao.saveOrUpdate(fbsCommonProductNameXref);
        }
        fbsCommonProductNameXref.setMirageSeedProduct(mirageSeedProduct);
        fbsCommonProductNameXref.setMidasProductName(midasProductName);
    }

    public void setFbsCommonProductNameXrefDao(FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao) {
        this.fbsCommonProductNameXrefDao = fbsCommonProductNameXrefDao;
    }
}
