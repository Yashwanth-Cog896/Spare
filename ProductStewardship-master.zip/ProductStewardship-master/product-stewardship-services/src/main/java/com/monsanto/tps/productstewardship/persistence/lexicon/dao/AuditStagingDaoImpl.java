package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;
import org.hibernate.Session;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 21, 2011
 * Time: 2:17:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class AuditStagingDaoImpl extends GenericDaoImpl<AuditStagingEntity,Long> implements AuditStagingDao{
    public AuditStagingDaoImpl(){
       this(AuditStagingEntity.class); 
    }
    public AuditStagingDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public BigDecimal getSessionId() {
      return null;//Return nothing aop gets this
    }

    @Override
    public String getSessionMachine() {
        return null; //Return nothing aop gets this
    }

    @Override
    public String getSessionOsUser() {
        return null;  //Return nothing aop gets this
    }
    public void saveAndFlush(AuditStagingEntity auditStagingEntity){
        Session session = getSession();
        session.save(auditStagingEntity);
        session.flush();
    }

    @Override
    public void delete(AuditStagingEntity auditStagingEntity) {
        getSession().flush();
        super.delete(auditStagingEntity);   
    }
}
