package com.monsanto.tps.productstewardship.audit.aspect;

import com.monsanto.Util.StringUtils;
import com.monsanto.appstatscommon.DataPoint;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;
import com.monsanto.tps.springframework.aop.AopUtils;
import org.aspectj.lang.ProceedingJoinPoint;

import java.lang.reflect.Method;
import java.util.Date;
import java.lang.annotation.Annotation;
/**
 * rrchak1 - Aug 25, 2008 10:06:54 AM
 */
public class AuditStagingAspect {
   private AuditStagingDao auditStagingDao;

   private DataPointHolder dataPointHolder;
   private UserProfile userProfile;

   public Object advice(ProceedingJoinPoint joinPoint)
      throws Throwable
   {
      Method method = AopUtils.getMethod(joinPoint);
      AuditStage auditStage = method.getAnnotation(AuditStage.class);
       String auditComment = getAuditComment(joinPoint, method, auditStage);
      String auditRequestor = getAuditRequestor(joinPoint, method,auditStage);
      AuditStagingEntity auditStaging = new AuditStagingEntity();
      auditStaging.setAuditComment(auditComment);
      auditStaging.setAuditRequestor(auditRequestor);

      String processName = auditStage.processName();


      auditStaging.setUserLoginId(userProfile.getUserName());
      auditStaging.setProcessName(processName);

      auditStaging.setCreationTimestamp(new Date());
      auditStaging.setMachine(auditStagingDao.getSessionMachine());
      auditStaging.setOracleSid(auditStagingDao.getSessionId().longValue());
      auditStaging.setOsuser(auditStagingDao.getSessionOsUser());
      try {
          auditStagingDao.saveAndFlush(auditStaging);
          return  joinPoint.proceed();
      }
      finally {
          auditStagingDao.delete(auditStaging);
      }
   }

    private String getAuditComment(ProceedingJoinPoint joinPoint, Method method, AuditStage auditStage) {
        String auditComment1 = auditStage.auditComment();
        if (StringUtils.isNullOrEmpty(auditComment1)) {
           auditComment1 = getDataPoint(AuditStagingDataPointEnum.AUDITCOMMENT);
        }
        int argIndex = 0;
        for(Annotation[] parameterAnnotations: method.getParameterAnnotations()){
           for(Annotation parameterAnnotation: parameterAnnotations){
               if(parameterAnnotation instanceof AuditComment){
                   Object auditCommentArg = joinPoint.getArgs()[argIndex];
                   if(auditCommentArg!=null){
                       auditComment1=auditCommentArg.toString();
                   }
               }
           }
           argIndex++;
        }
        return auditComment1;
    }

    private String getAuditRequestor(ProceedingJoinPoint joinPoint, Method method,AuditStage auditStage) {
      String auditRequestor = auditStage.auditRequestor();
      if (StringUtils.isNullOrEmpty(auditRequestor)) {
         auditRequestor = getDataPoint(AuditStagingDataPointEnum.AUDITREQUESTOR);
      }
        int argIndex = 0;
        for(Annotation[] parameterAnnotations: method.getParameterAnnotations()){
           for(Annotation parameterAnnotation: parameterAnnotations){
               if(parameterAnnotation instanceof AuditRequestor){
                   Object auditCommentArg = joinPoint.getArgs()[argIndex];
                   if(auditCommentArg!=null){
                       auditRequestor=auditCommentArg.toString();
                   }
               }
           }
           argIndex++;
        }
      return auditRequestor;
   }

   private String getDataPoint(AuditStagingDataPointEnum auditStagingDataPointEnum) {
      for (DataPoint dataPoint : dataPointHolder.getDataPoints()) {
         if (auditStagingDataPointEnum.name().equalsIgnoreCase(dataPoint.getName())) {
            return dataPoint.getStringValue();
         }
      }
      return null;
   }

   public void setAuditStagingDao(AuditStagingDao auditStagingDao) {
      this.auditStagingDao = auditStagingDao;
   }

   public void setDataPointHolder(DataPointHolder dataPointHolder) {
      this.dataPointHolder = dataPointHolder;
   }

   public void setUserProfile(UserProfile userProfile) {
      this.userProfile = userProfile;
   }
}
