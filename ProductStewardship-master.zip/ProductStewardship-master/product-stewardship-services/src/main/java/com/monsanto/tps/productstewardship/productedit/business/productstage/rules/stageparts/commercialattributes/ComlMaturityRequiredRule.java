package com.monsanto.tps.productstewardship.productedit.business.productstage.rules.stageparts.commercialattributes;

import com.monsanto.tps.productstewardship.productedit.business.productstage.StageValidationModel;
import com.monsanto.tps.productstewardship.productedit.service.ProductEditService;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;
import com.monsanto.tps.productstewardship.transfer.ValidationSeverity;
import com.monsanto.tps.productstewardship.validation.ValidationSimpleRule;
import com.monsanto.tps.productstewardship.validation.ValidationStatus;
import org.apache.commons.lang.StringUtils;

public class ComlMaturityRequiredRule   implements ValidationSimpleRule<StageValidationModel> {
   public static final String SOYBEANS_NAME = "SOYBEANS";
   public static final String SWEET_CORN_NAME = "SWEET CORN";
   public static final String CORN_NAME = "CORN";
    @Override
    public void validate(StageValidationModel model, ValidationStatus status) {
        if(isMaturityRequred(model.getProduct().getLexiconCropName())) {
            if(StringUtils.isBlank(model.getProductStage().getCommercialMaturity())){
                  status.addCondition(new ValidationResult(ProductEditService.COML_MATURITY_REQ_CODE, ValidationSeverity.ERROR));
            }
        }

    }
  private boolean isMaturityRequred(String cropName) {  
      return CORN_NAME.equals(cropName)
         || SWEET_CORN_NAME.equals(cropName)
         || SOYBEANS_NAME.equals(cropName);
   }
}
