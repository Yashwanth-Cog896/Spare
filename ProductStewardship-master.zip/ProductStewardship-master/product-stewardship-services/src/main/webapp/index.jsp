<%@ page import="org.springframework.context.ApplicationContext" %>
<%@ page import="org.springframework.web.context.WebApplicationContext" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ page import="java.util.Properties" %>
<%@ page import="java.net.URL" %>
<%@ page import="java.io.InputStream" %>
<%@ page import="java.util.jar.Manifest" %>
<%@ page import="java.util.jar.Attributes" %>
<%
    DecimalFormat fmt = new DecimalFormat("#0.00");

    String environment = System.getProperty("lsi.function");
%>

<%
    String version = "";
    String buildDate = "";
    String builtBy = "";
    URL url = application.getResource("/META-INF/MANIFEST.MF");
    if (url != null) {
        InputStream in = url.openStream();
        Manifest mf = new Manifest(in);
        Attributes attrs = mf.getMainAttributes();
        version = attrs.getValue("Version");
        buildDate = attrs.getValue("Build-Date");
        builtBy = attrs.getValue("Built-By");
    }
%>
<html>
<body bgcolor="#ffffff"><font face="arial" size="-1">
    <table>
        <tr>
            <td bgcolor="#9999cc">
                <table cellspacing="1" cellpadding="4">
                    <tr>
                        <td bgcolor="#eeeeee" colspan="3" align="center">
                    <tr>
                        <th bgcolor="#ccccff" align="right">Version:</th>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"><%= version %>
                        </font></td>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"></font></td>
                    </tr>
                    <tr>
                        <th bgcolor="#ccccff" align="right">Build Date:</th>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"><%= buildDate %>
                        </font></td>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"></font></td>
                    </tr>
                    <tr>
                        <th bgcolor="#ccccff" align="right">Built By:</th>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"><%= builtBy %>
                        </font></td>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"></font></td>
                    </tr>

                    <tr>
                        <th bgcolor="#ccccff" align="right">Environment:</th>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"><%= environment %>
                        </font></td>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"></font></td>
                    </tr>
                    <tr>
                        <th bgcolor="#ccccff" align="right">Service Endpoints:</th>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1">
                            <a href="services">Service Endpoints</a></li>
                        </font></td>
                        <td align="right" bgcolor="#ffffff"><font face="arial" size="-1"></font></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</font>
</body>
</html>