package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductStageDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;

import org.mockito.runners.MockitoJUnitRunner;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import java.util.List;
import java.util.Arrays;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 1:01:00 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductStageLogicalDeleteImpl_UT {
    @Mock
    LexiconProductStageDao lexiconProductStageDao;

    @Mock
    FbsCommonProductNameLogicalDelete fbsCommonProductNameLogicalDelete;

    @InjectMocks
    ProductStageLogicalDeleteImpl productStageLogicalDelete = new ProductStageLogicalDeleteImpl();
    @Test
    public void testLogicallyDeleteProductStages(){

        String stagePubkey = "stagePubkey";
        MidasBrandEntity midasBrand = new MidasBrandEntity();
        midasBrand.setName("brandName");
        LexiconProductStageEntity lexiconStage = new LexiconProductStageEntity();
        lexiconStage.setLogicalDelete(false);
        lexiconStage.setActive(true);

        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = buildFbsCommonProductNameXref(stagePubkey);
        MidasProductNameEntity midasProductName = new MidasProductNameEntity();
        midasProductName.setMidasBrand(midasBrand);
        midasProductName.setRefActive(true);
        MidasProductEntity midasProduct = new MidasProductEntity();
        midasProductName.setMidasProduct(midasProduct);
        midasProduct.setMidasProductNames(Arrays.asList(midasProductName));
        fbsCommonProductNameXref.setMidasProductName(midasProductName);

        lexiconStage.setFbsCommonProductNameXref(fbsCommonProductNameXref);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        lexiconProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        lexiconStage.setLexiconProduct(lexiconProduct);
        lexiconStage.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        Set<LexiconProductStageEntity> lexiconProductStages = lexiconProduct.getLexiconProductStages();
        lexiconProductStages.add(lexiconStage);
        when(lexiconProductStageDao.getByPubkey(stagePubkey)).thenReturn(lexiconStage);

        productStageLogicalDelete.logicallyDeleteProductStages(Arrays.asList(stagePubkey));

        assertThat(lexiconStage.getFbsCommonProductNameXref(),nullValue());
        assertThat(lexiconStage.isLogicalDelete(),is(true));
        assertThat(lexiconProduct.isLogicalDelete(),is(false));


        verify(fbsCommonProductNameLogicalDelete,times(1)).logicalDelete(fbsCommonProductNameXref);


    }

    @Test
    public void testLogicallyDeleteProductStagesDoesntDeleteOtherProductsWhenOtherUndeletedStagesExist(){
       String stagePubkey = "stagePubkey";
        LexiconProductStageEntity lexiconStage = new LexiconProductStageEntity();
        lexiconStage.setLogicalDelete(false);
        lexiconStage.setActive(true);
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = buildFbsCommonProductNameXref(stagePubkey);
        MidasProductNameEntity midasProductName = new MidasProductNameEntity();
        midasProductName.setRefActive(true);
        MidasProductEntity midasProduct = new MidasProductEntity();
        midasProductName.setMidasProduct(midasProduct);
        MidasProductNameEntity otherMidasProductName = new MidasProductNameEntity();
        otherMidasProductName.setRefActive(true);
        midasProduct.setMidasProductNames(Arrays.asList(midasProductName,otherMidasProductName));
        fbsCommonProductNameXref.setMidasProductName(midasProductName);


        lexiconStage.setFbsCommonProductNameXref(fbsCommonProductNameXref);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        lexiconProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        lexiconStage.setLexiconProduct(lexiconProduct);
        lexiconStage.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        Set<LexiconProductStageEntity> lexiconProductStages = lexiconProduct.getLexiconProductStages();
        lexiconProductStages.add(lexiconStage);
        LexiconProductStageEntity otherActiveStage = new LexiconProductStageEntity();
        otherActiveStage.setLexiconProduct(lexiconProduct);
        otherActiveStage.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        otherActiveStage.setActive(true);
        otherActiveStage.setLogicalDelete(false);
        lexiconProduct.getLexiconProductStages().add(otherActiveStage);
        when(lexiconProductStageDao.getByPubkey(stagePubkey)).thenReturn(lexiconStage);

        productStageLogicalDelete.logicallyDeleteProductStages(Arrays.asList(stagePubkey));

        assertThat(lexiconStage.getFbsCommonProductNameXref(),nullValue());
        assertThat(lexiconStage.isLogicalDelete(),is(true));
        assertThat(lexiconProduct.isLogicalDelete(),is(false));

        assertThat(otherMidasProductName.isRefActive(),is(true));
        verify(fbsCommonProductNameLogicalDelete,times(1)).logicalDelete(fbsCommonProductNameXref);

    }

    @Test
    public void testLogicallyDeleteProductStagesDeletesOtherProductsWhenAllStagesAreDeleted(){
       String stagePubkey = "stagePubkey";
        LexiconProductStageEntity lexiconStage = new LexiconProductStageEntity();
        lexiconStage.setLogicalDelete(false);
        lexiconStage.setActive(true);
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = buildFbsCommonProductNameXref(stagePubkey);
        MidasProductNameEntity midasProductName = new MidasProductNameEntity();
        midasProductName.setRefActive(true);
        MidasProductEntity midasProduct = new MidasProductEntity();
        midasProductName.setMidasProduct(midasProduct);
        MidasBrandEntity commercialBrand = new MidasBrandEntity();
        commercialBrand.setName("commercialBrand");
        midasProductName.setMidasBrand(commercialBrand);
        MidasProductNameEntity otherMidasProductName = new MidasProductNameEntity();

        otherMidasProductName.setRefActive(true);
        MidasBrandEntity monsantoBrand = new MidasBrandEntity();
        monsantoBrand.setName(MidasBrandEntity.MONSANTO_BRAND);
        otherMidasProductName.setMidasBrand(monsantoBrand);
        otherMidasProductName.setName(TestDataBuilder.generateRandomNumberString(50));
        midasProduct.setMidasProductNames(Arrays.asList(midasProductName,otherMidasProductName));
        fbsCommonProductNameXref.setMidasProductName(midasProductName);


        lexiconStage.setFbsCommonProductNameXref(fbsCommonProductNameXref);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        lexiconProduct.setPreCommercialName(otherMidasProductName.getName());
        lexiconStage.setLexiconProduct(lexiconProduct);
        lexiconStage.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        Set<LexiconProductStageEntity> lexiconProductStages = lexiconProduct.getLexiconProductStages();
        lexiconProductStages.add(lexiconStage);
        LexiconProductStageEntity otherActiveStage = new LexiconProductStageEntity();
        otherActiveStage.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        otherActiveStage.setActive(true);
        otherActiveStage.setLogicalDelete(true);
        lexiconProduct.getLexiconProductStages().add(otherActiveStage);
        when(lexiconProductStageDao.getByPubkey(stagePubkey)).thenReturn(lexiconStage);


        productStageLogicalDelete.logicallyDeleteProductStages(Arrays.asList(stagePubkey));

        assertThat(lexiconStage.getFbsCommonProductNameXref(),nullValue());
        assertThat(lexiconStage.isLogicalDelete(),is(true));
        assertThat(lexiconProduct.isLogicalDelete(),is(false));

        assertThat(otherMidasProductName.isRefActive(),is(false));
        verify(fbsCommonProductNameLogicalDelete,times(1)).logicalDelete(fbsCommonProductNameXref);
    }

    private FbsCommonProductNameXrefEntity buildFbsCommonProductNameXref(String stagePubkey) {
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = new FbsCommonProductNameXrefEntity();
        fbsCommonProductNameXref.setLexiconPubkey(stagePubkey);
        return fbsCommonProductNameXref;
    }
}
