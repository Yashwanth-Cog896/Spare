package com.monsanto.tps.productstewardship.gqa.business;

import static org.hamcrest.CoreMatchers.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class WebMethodsCredentials_UT {
    @Test
    public void testParse(){
        String username = "username";
        String password = "password";
        WebMethodsCredentials credentials = new WebMethodsCredentials("username:password");
        assertThat(credentials.getUsername(),is(username));
        assertThat(credentials.getPassword(),is(password));
    }
}
