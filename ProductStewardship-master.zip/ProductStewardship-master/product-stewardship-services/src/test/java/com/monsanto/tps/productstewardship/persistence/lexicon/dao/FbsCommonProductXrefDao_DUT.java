package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;
import java.util.Arrays;
import javax.annotation.Resource;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 8, 2011
 * Time: 8:18:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class FbsCommonProductXrefDao_DUT extends HibernateTestCase {
    @Resource
    FbsCommonProductXrefDao fbsCommonProductXrefDao;
    @Resource
    LexiconTempSessionOcdDao lexiconTempSessionOcdDao;
    @Resource
    MidasTempSessionOcdDao midasTempSessionOcdDao;

    @Test
    public void testGetByProductPubkeys(){
        LexiconProductEntity lexiconProduct = TestDataBuilder.buildLexiconProductEntity(currentSession);
        currentSession.flush();
        currentSession.clear();
        Long requestId = System.currentTimeMillis()%10000000;
        lexiconTempSessionOcdDao.insertTextValues(requestId,Arrays.asList(lexiconProduct.getPubkey()));
        midasTempSessionOcdDao.insertNumberValues(requestId,Arrays.asList(lexiconProduct.getFbsCommonProductXref().getMidasProduct().getId()));
        currentSession.flush();
        List<FbsCommonProductXrefEntity> xrefs = fbsCommonProductXrefDao.getByProductPubkeys(requestId);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(lexiconProduct,xrefs.get(0).getLexiconProduct());
    }
}
