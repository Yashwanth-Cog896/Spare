package com.monsanto.tps.productstewardship.blend.business;

import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.dataservices.product.transfer.ProductGermplasmDetails;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static junit.framework.Assert.assertNull;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 9, 2011
 * Time: 8:56:08 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class BlendBuilderFactory_UT {
    @Mock
    private BlendedProductsStrategy blendedProductsStrategy;
    @Mock
    private BlendedComponentsStrategy blendedComponentsStrategy;
    @Mock
    private BlendProductDetailsStrategy blendProductDetailsStrategy;
    private BlendBuilderFactory factory;

    @Before
    public void setUp() {
        factory = new BlendBuilderFactory();
        factory.setBlendedComponentsStrategy(blendedComponentsStrategy);
        factory.setBlendedProductsStrategy(blendedProductsStrategy);
        factory.setBlendProductDetailsStrategy(blendProductDetailsStrategy);
    }

    @Test
    public void test_GetStrategy_NullBlendedProductDetails() {
        BlendedProductDetails details = new BlendedProductDetails();
        details.setBlendedProductGermplasms(null);
        details.setComponentProductGermplasms(null);
        BlendedSearchStrategy blendedSearchStrategy = factory.getStrategy(details);
        assertNull(blendedSearchStrategy);
    }

    @Test
    public void test_GetStrategy_blendProductsStrategy() {
        BlendedProductDetails details = new BlendedProductDetails();
        details.setBlendedProductGermplasms(new ArrayList<ProductGermplasmDetails>());
        details.setComponentProductGermplasms(null);
        BlendedSearchStrategy blendedSearchStrategy = factory.getStrategy(details);
        assertNull(blendedSearchStrategy);
    }

    @Test
    public void test_GetStrategy_blendComponentsStrategy() {
        BlendedProductDetails details = new BlendedProductDetails();
        details.setBlendedProductGermplasms(null);
        details.setComponentProductGermplasms(new ArrayList<ProductGermplasmDetails>());
        BlendedSearchStrategy blendedSearchStrategy = factory.getStrategy(details);
        assertNull(blendedSearchStrategy);
    }

    @Test
    public void test_GetStrategy_blendProductsDetailsStrategy() {
        BlendedProductDetails details = new BlendedProductDetails();
        details.setBlendedProductGermplasms(new ArrayList<ProductGermplasmDetails>());
        details.setComponentProductGermplasms(new ArrayList<ProductGermplasmDetails>());
        BlendedSearchStrategy blendedSearchStrategy = factory.getStrategy(details);
        assertNull(blendedSearchStrategy);
    }
}
