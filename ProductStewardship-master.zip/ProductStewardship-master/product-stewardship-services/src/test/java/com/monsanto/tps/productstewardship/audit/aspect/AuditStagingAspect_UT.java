package com.monsanto.tps.productstewardship.audit.aspect;

import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.authentication.UserProfileImpl;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.Annotation;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;


/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 1, 2011
 * Time: 4:14:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class AuditStagingAspect_UT {

    @Test
    public void testAdvice() throws Throwable {
        AuditStagingDao auditStagingDao = mock(AuditStagingDao.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);

        String sessionOsUser = "sessionOsUser";
        when(auditStagingDao.getSessionOsUser()).thenReturn(sessionOsUser);
        String sessionMachine = "sessionMachine";
        when(auditStagingDao.getSessionMachine()).thenReturn(sessionMachine);
        BigDecimal sessionId = new BigDecimal("22");
        when(auditStagingDao.getSessionId()).thenReturn(sessionId);

        UserProfileImpl userProfile = new UserProfileImpl();
        ProceedingJoinPoint proceedingJoinPoint = mock(ProceedingJoinPoint.class);
        MethodSignature signature = mock(MethodSignature.class);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);

        Object targetObject = new TestClass();
        Method method =targetObject.getClass().getMethod("methodName",new Class[0]);
        when(signature.getMethod()).thenReturn(method);

         userProfile.setUserName("userName");

        when(proceedingJoinPoint.getTarget()).thenReturn(targetObject);
        Object interfaceMethod =  targetObject.getClass().getMethod(method.getName(), method.getParameterTypes());

/*
        Method interfaceMethod = ((MethodSignature) joinPoint.getSignature()).getMethod();
        Object targetObject = joinPoint.getTarget();
        return targetObject.getClass().getMethod(interfaceMethod.getName(), interfaceMethod.getParameterTypes());
*/

        AuditStagingAspect aspect = new AuditStagingAspect();
        aspect.setAuditStagingDao(auditStagingDao);
        aspect.setDataPointHolder(dataPointHolder);

        aspect.setUserProfile(userProfile);
        aspect.advice(proceedingJoinPoint);

        ArgumentCaptor<AuditStagingEntity> argumentCaptor = ArgumentCaptor.forClass(AuditStagingEntity.class);
        verify(auditStagingDao).saveAndFlush(argumentCaptor.capture());
        AuditStagingEntity auditStaging = argumentCaptor.getValue();
        assertThat(auditStaging.getAuditComment(),is("auditComment"));
        assertThat(auditStaging.getAuditRequestor(),is("auditRequestor"));
        assertThat(auditStaging.getCreationTimestamp(), notNullValue());
        assertThat(auditStaging.getMachine(),is(sessionMachine));
        assertThat(auditStaging.getOracleSid(),is(sessionId.longValue()));
        assertThat(auditStaging.getOsuser(),is(sessionOsUser));
        assertThat(auditStaging.getProcessName(),is("processName"));
        assertThat(auditStaging.getUserLoginId(),is(userProfile.getUserName()));
    }

    @Test
    public void testAdviceParameterAnnotations() throws Throwable {
        AuditStagingDao auditStagingDao = mock(AuditStagingDao.class);
        DataPointHolder dataPointHolder = mock(DataPointHolder.class);

        String sessionOsUser = "sessionOsUser";
        when(auditStagingDao.getSessionOsUser()).thenReturn(sessionOsUser);
        String sessionMachine = "sessionMachine";
        when(auditStagingDao.getSessionMachine()).thenReturn(sessionMachine);
        BigDecimal sessionId = new BigDecimal("22");
        when(auditStagingDao.getSessionId()).thenReturn(sessionId);

        UserProfileImpl userProfile = new UserProfileImpl();
        ProceedingJoinPoint proceedingJoinPoint = mock(ProceedingJoinPoint.class);
        MethodSignature signature = mock(MethodSignature.class);
        when(proceedingJoinPoint.getSignature()).thenReturn(signature);

        Object targetObject = new TestClassWithParameterAnnotations();
        Method method =targetObject.getClass().getMethod("methodName",new Class[]{String.class,String.class});
        when(signature.getMethod()).thenReturn(method);

        userProfile.setUserName("userName");

        when(proceedingJoinPoint.getTarget()).thenReturn(targetObject);
        when(proceedingJoinPoint.getArgs()).thenReturn(new Object[]{"annotatedcomment","annotatedrequestor",});

        Object interfaceMethod =  targetObject.getClass().getMethod(method.getName(), method.getParameterTypes());

/*
        Method interfaceMethod = ((MethodSignature) joinPoint.getSignature()).getMethod();
        Object targetObject = joinPoint.getTarget();
        return targetObject.getClass().getMethod(interfaceMethod.getName(), interfaceMethod.getParameterTypes());
*/

        AuditStagingAspect aspect = new AuditStagingAspect();
        aspect.setAuditStagingDao(auditStagingDao);
        aspect.setDataPointHolder(dataPointHolder);

        aspect.setUserProfile(userProfile);
        aspect.advice(proceedingJoinPoint);

        ArgumentCaptor<AuditStagingEntity> argumentCaptor = ArgumentCaptor.forClass(AuditStagingEntity.class);
        verify(auditStagingDao).saveAndFlush(argumentCaptor.capture());
        AuditStagingEntity auditStaging = argumentCaptor.getValue();
        assertThat(auditStaging.getAuditComment(),is("annotatedcomment"));
        assertThat(auditStaging.getAuditRequestor(),is("annotatedrequestor"));
        assertThat(auditStaging.getCreationTimestamp(), notNullValue());
        assertThat(auditStaging.getMachine(),is(sessionMachine));
        assertThat(auditStaging.getOracleSid(),is(sessionId.longValue()));
        assertThat(auditStaging.getOsuser(),is(sessionOsUser));
        assertThat(auditStaging.getProcessName(),is("processName"));
        assertThat(auditStaging.getUserLoginId(),is(userProfile.getUserName()));
    }
    public class TestClass{
        @AuditStage(processName = "processName",auditComment = "auditComment",auditRequestor = "auditRequestor")
            public void methodName() {
            }
    }
    public class TestClassWithParameterAnnotations{
        @AuditStage(processName = "processName",auditComment = "auditComment",auditRequestor = "auditRequestor")
            public void methodName(@AuditComment String comment,@AuditRequestor String requestor) {
            }
    }
}
