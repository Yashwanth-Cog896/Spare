package com.monsanto.tps.productstewardship.context;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import javax.annotation.Resource;

import java.math.BigDecimal;
import java.util.Date;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: RLCASW
 * Date: May 20, 2011
 * Time: 1:18:45 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "/com/monsanto/tps/productstewardship/contexts/hibernate-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-datasource-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-transaction-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/application-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/services-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/external-services-context.xml"
} ,
loader=ExtendedGenericXmlContextLoader.class)

@Transactional(propagation = Propagation.REQUIRED)
public class HibernateTestCase {
    @Resource
    protected AuditStagingDao auditStagingDao;

    @Resource(name = "sessionFactory")
    protected SessionFactory sessionFactory;

    protected Session currentSession;

    private long oracleSid;

    @Before
    public void setupAudit(){
        currentSession = sessionFactory.getCurrentSession();
        BigDecimal bdSessionId = (BigDecimal) currentSession.getNamedQuery("selectSessionId").uniqueResult();
        oracleSid = bdSessionId.longValueExact();
        String sessionOSuser = (String)  currentSession.getNamedQuery("selectSessionOsUser").uniqueResult();
        String machine = (String) currentSession.getNamedQuery("selectSessionMachine").uniqueResult();

        AuditStagingEntity auditStaging = new AuditStagingEntity();
        auditStaging.setOracleSid(oracleSid);
        auditStaging.setProcessName("DUT");
        auditStaging.setAuditComment("DUT");
        auditStaging.setAuditRequestor("junit");
        long currentTimeMillis = System.currentTimeMillis();
        Date creationTimestamp = new Date(currentTimeMillis-(currentTimeMillis%1000));
        auditStaging.setCreationTimestamp(creationTimestamp);
        auditStaging.setMachine(machine);
        auditStaging.setOsuser(sessionOSuser);
        auditStaging.setUserLoginId("junit");
        auditStagingDao.saveOrUpdate(auditStaging);
    }
    protected void saveFlushAndClear(Object entity) {
        currentSession.save(entity);
        flushAndClearSession();
    }
    protected void flushAndClearSession() {
        currentSession.flush();
        currentSession.clear();
    }

    protected <T> T getById(Class<T> clazz,Long id){
        return (T)currentSession.get(clazz,id);
    }
}

