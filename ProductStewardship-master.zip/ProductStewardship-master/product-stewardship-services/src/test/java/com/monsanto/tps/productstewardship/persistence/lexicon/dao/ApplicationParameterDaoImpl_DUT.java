package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ApplicationParameterEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.DateUtil;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import javax.annotation.Resource;
import java.util.Date;

public class ApplicationParameterDaoImpl_DUT extends HibernateTestCase {
    @Resource
    private ApplicationParameterDao applicationParameterDao;

    @Test
    public void testReadParameterForEnvironment(){
        ApplicationParameterEntity applicationParameter = new ApplicationParameterEntity();
        String testParam = "testParam";
        applicationParameter.setKey("win." + testParam);
        String testValue = "testValue";
        applicationParameter.setValue(testValue);
        applicationParameter.setModifiedTimestamp(new Date(DateUtil.stripMillis(System.currentTimeMillis())));
        applicationParameter.setId(TestDataBuilder.generateRandomNegativeLong());
        currentSession.save(applicationParameter);
        currentSession.flush();
        currentSession.clear();

        assertThat(applicationParameterDao.getParameterValue(testParam),is(testValue));
    }
    @Test
    public void testReadParameterWithoutEnvironment(){
        ApplicationParameterEntity applicationParameter = new ApplicationParameterEntity();
        String testParam = "testParam";
        applicationParameter.setKey( testParam);
        String testValue = "testValue";
        applicationParameter.setValue(testValue);
        applicationParameter.setModifiedTimestamp(new Date(DateUtil.stripMillis(System.currentTimeMillis())));
        applicationParameter.setId(TestDataBuilder.generateRandomNegativeLong());
        currentSession.save(applicationParameter);
        currentSession.flush();
        currentSession.clear();

        assertThat(applicationParameterDao.getParameterValue(testParam),is(testValue));
    }
    @Test
    public void testPersistence(){
        ApplicationParameterEntity applicationParameter = new ApplicationParameterEntity();
        String testParam = "testParam";
        applicationParameter.setKey( testParam);
        String testValue = "testValue";
        applicationParameter.setValue(testValue);
        applicationParameter.setModifiedTimestamp(new Date(DateUtil.stripMillis(System.currentTimeMillis())));
        applicationParameter.setId(TestDataBuilder.generateRandomNegativeLong());
        currentSession.save(applicationParameter);
        currentSession.flush();
        currentSession.clear();

        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(applicationParameter,applicationParameterDao.get(applicationParameter.getId()));
    }
}
