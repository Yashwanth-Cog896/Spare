package com.monsanto.tps.productstewardship.email;


import javax.mail.Message;

/**
 * User: pjberry
 * Date: Sep 27, 2007
 * Time: 3:54:02 PM
 */
public class MockSimpleTransport
   implements SimpleTransport
{
   private boolean wasSent = false;

   public void send(Message message) {
      if(message != null ) {
         this.wasSent = true;
      }
   }

   public boolean wasSent() {
      return wasSent;
   }
}
