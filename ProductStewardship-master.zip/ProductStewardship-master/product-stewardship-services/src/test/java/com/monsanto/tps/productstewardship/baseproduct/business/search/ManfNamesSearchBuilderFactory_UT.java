/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.business.search.BaseManfNameSearchBuilder;
import com.monsanto.tps.productstewardship.baseproduct.business.search.ManfNameSearchBuilder;
import com.monsanto.tps.productstewardship.baseproduct.business.search.ManfNamesSearchBuilderFactory;
import com.monsanto.tps.productstewardship.baseproduct.business.search.ManfNamesSearchCriteria;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProductSearchType;
import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import org.junit.Test;

import javax.annotation.Resource;

import static junit.framework.Assert.*;

/* vvkalu - 7/15/11 */
public class ManfNamesSearchBuilderFactory_UT extends HibernateTestCase{
    @Resource
    private ManfNamesSearchBuilderFactory manfNamesSearchBuilderFactory;

    @Test
    public void test_getSearchCriteria_ForBaseManfName() throws Exception {
        ManfNamesSearchCriteria searchCriteria = manfNamesSearchBuilderFactory.getSearchCriteria(BaseProductSearchType.MANUFACTURINGNAME);
        assertNotNull(searchCriteria);
        assertTrue(searchCriteria instanceof ManfNameSearchBuilder);
    }

    @Test
    public void test_getSearchCriteria_ForManfName() throws Exception {
        ManfNamesSearchCriteria searchCriteria = manfNamesSearchBuilderFactory.getSearchCriteria(BaseProductSearchType.BASEMANUFACTURINGNAME);
        assertNotNull(searchCriteria);
        assertTrue(searchCriteria instanceof BaseManfNameSearchBuilder);
    }
}