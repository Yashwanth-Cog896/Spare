package com.monsanto.tps.productstewardship.gqa.business;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 25, 2011
 * Time: 4:45:25 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class GqaFlowImpl_UT {
    @Mock
    private GqaProductFlowImpl gqaProductFlow;
    @InjectMocks
    private GqaFlowImpl gqaFlowImpl = new GqaFlowImpl();
    @Test
    public void testFlowChangesToGqa(){
        Long id = new Long(1L);
        List<Long> ids = Arrays.asList(id);
        when(gqaProductFlow.getPqSapProductIdsToProcess()).thenReturn(ids);
        gqaFlowImpl.flowChangesToGqa();
        verify(gqaProductFlow,times(1)).flowNextChangeToGqa(id);
    }
}
