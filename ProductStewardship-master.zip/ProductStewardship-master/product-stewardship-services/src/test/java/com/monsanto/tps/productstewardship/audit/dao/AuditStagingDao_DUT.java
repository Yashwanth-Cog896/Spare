package com.monsanto.tps.productstewardship.audit.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.AuditStagingDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 14, 2011
 * Time: 10:49:28 AM
 * To change this template use File | Settings | File Templates.
 */

public class AuditStagingDao_DUT extends HibernateTestCase {

    @Resource(name = "sessionFactory")
    protected SessionFactory sessionFactory;

    @Resource
    AuditStagingDao auditStagingDao;

    @Test
    public void testPersistence(){
        AuditStagingEntity auditStaging = new AuditStagingEntity();
        auditStaging.setOracleSid(2345L);
        auditStaging.setProcessName("AuditStagingEntity_DUT");
        auditStaging.setAuditComment("AuditComment");
        auditStaging.setAuditRequestor("requestor");
        long currentTimeMillis = System.currentTimeMillis();
        Date creationTimestamp = new Date(currentTimeMillis-(currentTimeMillis%1000));
        auditStaging.setCreationTimestamp(creationTimestamp);
        auditStaging.setMachine("machine");
        auditStaging.setOsuser("osuser");
        auditStaging.setUserLoginId("ulogin");
        auditStaging.setUserPartyId(333L);

        Session session = sessionFactory.getCurrentSession();
        auditStagingDao.saveOrUpdate(auditStaging);
        session.flush();
        session.clear();

        AuditStagingEntity fromDb = auditStagingDao.load( 2345L);
        assertFalse(fromDb==auditStaging);
        assertThat(fromDb.getOracleSid(),is(auditStaging.getOracleSid()));
        assertThat(fromDb.getProcessName(),is(auditStaging.getProcessName()));
        assertThat(fromDb.getAuditComment(),is(auditStaging.getAuditComment()));
        assertThat(fromDb.getAuditRequestor(),is(auditStaging.getAuditRequestor()));
        assertThat(fromDb.getCreationTimestamp(),is(auditStaging.getCreationTimestamp()));
        assertThat(fromDb.getMachine(),is(auditStaging.getMachine()));
        assertThat(fromDb.getOsuser(),is(auditStaging.getOsuser()));
        assertThat(fromDb.getUserLoginId(),is(auditStaging.getUserLoginId()));
        assertThat(fromDb.getUserPartyId(),is(auditStaging.getUserPartyId()));
    }

    @Test
    public void testGetSessionId(){
        BigDecimal sessionId = auditStagingDao.getSessionId();
        assertThat(sessionId,notNullValue());
        assertThat(sessionId.longValue(),not(0L));
    }
    @Test
    public void testGetSessionOsUser(){
        String sessionOsUser= auditStagingDao.getSessionOsUser();
        assertThat(sessionOsUser,notNullValue());
        assertThat(sessionOsUser,not(""));
    }

    @Test
    public void tesGetSessionMachine(){
        String sessionMachine = auditStagingDao.getSessionMachine();
        assertThat(sessionMachine,notNullValue());
        assertThat(sessionMachine,not(""));
    }
}
