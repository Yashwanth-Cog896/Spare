package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import com.monsanto.tps.productstewardship.productsearch.service.NameType;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Resource;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;


/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 30, 2011
 * Time: 12:34:47 PM
 */
public class LexiconProductDao_DUT extends HibernateTestCase {
    @Resource
    LexiconProductDao lexiconProductDao;
    @Test
    public void testGetByPubkey(){
        LexiconProductEntity product = new LexiconProductEntity();

        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        saveFlushAndClear(product);
        LexiconProductEntity productRead = lexiconProductDao.getByPubkey(product.getPubkey());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(product, productRead);

    }

    @Test
    public void testGetByCropAndVarietyName(){
        LexiconProductEntity product = new LexiconProductEntity();
        LexiconCropEntity lexiconCropEntity = TestDataBuilder.buildCrop(currentSession, false);
        product.setLexiconCrop(lexiconCropEntity);
        product.setPreCommercialName(TestDataBuilder.generateRandomNumberString(40));
        product.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(50));
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(10));
        currentSession.save(product);
        TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        flushAndClearSession();
        List<LexiconProductEntity> products = lexiconProductDao.getByCropAndVarietyName(lexiconCropEntity.getName(),product.getTagVarietyName());
        assertThat(products.size(),is(1));
        assertThat(products.get(0).getId(),is(product.getId()));
    }
    @Test
    public void testGetByCropAndVarietyNameLogicallyDeletedProduct(){
        LexiconProductEntity product = new LexiconProductEntity();
        LexiconCropEntity lexiconCropEntity = TestDataBuilder.buildCrop(currentSession, false);
        product.setLexiconCrop(lexiconCropEntity);
        product.setPreCommercialName(TestDataBuilder.generateRandomNumberString(40));
        product.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(50));
        product.setLogicalDelete(true);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(10));
        currentSession.save(product);
        TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        flushAndClearSession();
        List<LexiconProductEntity> products = lexiconProductDao.getByCropAndVarietyName(lexiconCropEntity.getName(),product.getTagVarietyName());
        assertThat(products.size(),is(0));
    }    
    @Test
    public void testGetByCropAndVarietyNameNoNonDeletedStages(){
        LexiconProductEntity product = new LexiconProductEntity();
        LexiconCropEntity lexiconCropEntity = TestDataBuilder.buildCrop(currentSession, false);
        product.setLexiconCrop(lexiconCropEntity);
        product.setPreCommercialName(TestDataBuilder.generateRandomNumberString(40));
        product.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(50));
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(10));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        productStage.setLogicalDelete(true);
        flushAndClearSession();
        List<LexiconProductEntity> products = lexiconProductDao.getByCropAndVarietyName(lexiconCropEntity.getName(),product.getTagVarietyName());
        assertThat(products.size(),is(0));
    }
    @Test
    public void testGetByCropAndVarietyNameNoStages(){
        LexiconProductEntity product = new LexiconProductEntity();
        LexiconCropEntity lexiconCropEntity = TestDataBuilder.buildCrop(currentSession, false);
        product.setLexiconCrop(lexiconCropEntity);
        product.setPreCommercialName(TestDataBuilder.generateRandomNumberString(40));
        product.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(50));
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(10));
        currentSession.save(product);

        flushAndClearSession();
        List<LexiconProductEntity> products = lexiconProductDao.getByCropAndVarietyName(lexiconCropEntity.getName(),product.getTagVarietyName());
        assertThat(products.size(),is(0));
    }
    @Test
    public void testGetByPreCommercialName(){
        LexiconProductEntity product = new LexiconProductEntity();

        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName(TestDataBuilder.generateRandomNumberString(40));
        product.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        product.setTagVarietyName(TestDataBuilder.generateRandomNumberString(50));
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        saveFlushAndClear(product);
        LexiconProductEntity productRead = lexiconProductDao.getByPreCommercialName(product.getPreCommercialName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(product, productRead);

    }

    @Test
    public void testFindByAdditionalCommentsPrecommercialNameCriteria(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        product.getLexiconProductStages().add(productStage);
        currentSession.save(productStage);
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(product.getPreCommercialName()), ProductAdditionalCommentsNameType.PRE_COMMERCIAL, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(products.size(),is(1));
        assertThat(products.get(0).getId(),is(product.getId()));
    }
    @Test
    public void testFindByAdditionalCommentsPrecommercialNameCriteriaAllStagesLogicallyDeleted(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        productStage.setLogicalDelete(true);
        product.getLexiconProductStages().add(productStage);
        currentSession.save(productStage);
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(product.getPreCommercialName()), ProductAdditionalCommentsNameType.PRE_COMMERCIAL, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(products.isEmpty(),is(true));
    }
    @Test
    public void testFindByAdditionalCommentsPrecommercialNameCriteriaProductLogicallyDeleted(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(true);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        product.getLexiconProductStages().add(productStage);
        currentSession.save(productStage);
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(product.getPreCommercialName()), ProductAdditionalCommentsNameType.PRE_COMMERCIAL, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(products.isEmpty(),is(true));
    }
    @Test
    public void testCountAdditionalCommentsPrecommercialNameCriteria(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
         LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        currentSession.save(productStage);
        product.getLexiconProductStages().add(productStage);
        flushAndClearSession();
        Long count =  lexiconProductDao.countAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(product.getPreCommercialName()), ProductAdditionalCommentsNameType.PRE_COMMERCIAL, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(count,is(1L));
    }
    @Test
    public void testPaginationAdditionalCommentsPrecommercialNameCriteria(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        currentSession.save(productStage);
        product.getLexiconProductStages().add(productStage);
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findPagedByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(product.getPreCommercialName()), ProductAdditionalCommentsNameType.PRE_COMMERCIAL, Arrays.asList(product.getLexiconCrop().getName()),10,0);
        assertThat(products.size(),is(1));
        assertThat(products.get(0).getId(),is(product.getId()));
    }
    @Test
    public void testFindByAdditionalCommentsVarietyNameCriteria(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        product.setPreCommercialName("0123456789012345678901234567890123456789");
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        currentSession.save(productStage);
        product.getLexiconProductStages().add(productStage);
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(product.getTagVarietyName()), ProductAdditionalCommentsNameType.VARIETY, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(products.size(),is(1));
        assertThat(products.get(0).getId(),is(product.getId()));
    }
    @Test
    public void testFindByAdditionalCommentsCriteriaPrecommercialNameWildcard(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        String preCommercialNameminus1 = "012345678901234567890123456789012345678";
        String preCommercialName = preCommercialNameminus1 + "9";
        product.setPreCommercialName(preCommercialName);
        product.setPubkey("01234567890123456789");
        product.setTagVarietyName("01234567890123456789012345678901234567890123456789");
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        currentSession.save(productStage);
        product.getLexiconProductStages().add(productStage);
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(preCommercialNameminus1+"*"), ProductAdditionalCommentsNameType.PRE_COMMERCIAL, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(products.size(),is(1));
        assertThat(products.get(0).getId(),is(product.getId()));
    }
    @Test
    public void testFindByAdditionalCommentsCriteriaVarietyNameWildcard(){
        LexiconProductEntity product = new LexiconProductEntity();
        product.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        String preCommercialNameminus1 = "012345678901234567890123456789012345678";
        String preCommercialName = preCommercialNameminus1 + "9";
        product.setPreCommercialName(preCommercialName);
        product.setPubkey("01234567890123456789");
        String varietyNameMinus1 = "0123456789012345678901234567890123456789012345678";
        String tagVarietyName = varietyNameMinus1 +
                "9";
        product.setTagVarietyName(tagVarietyName);
        product.setLogicalDelete(false);
        product.setParentProduct(false);
        product.setOwningMarketingRegion(TestDataBuilder.buildMarketingRegion(currentSession));
        product.setSupplyChainOwnerGroup(TestDataBuilder.buildSupplyChainOwnerGroup(currentSession));
        product.setProductClassification(TestDataBuilder.buildProductClassification(currentSession));
        product.setFbsCommonProductXref(TestDataBuilder.buildFbsCommonProductXref(currentSession, product));
        currentSession.save(product);
        LexiconProductStageEntity productStage  = TestDataBuilder.buildAndAddProductStage(currentSession,product, false);
        currentSession.save(productStage);
        product.getLexiconProductStages().add(productStage);        
        flushAndClearSession();
        List<LexiconProductEntity> products =  lexiconProductDao.findByAdditionalCommentsCriteria(Arrays.asList(product.getLexiconCrop().getPubkey()),Arrays.asList(varietyNameMinus1+"*"), ProductAdditionalCommentsNameType.VARIETY, Arrays.asList(product.getLexiconCrop().getName()));
        assertThat(products.size(),is(1));
        assertThat(products.get(0).getId(),is(product.getId()));
    }
    @Test
    public void testFindBySearchCriteriaPreCommercialName(){
         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         List<LexiconProductEntity> products = lexiconProductDao.findBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria);
         currentSession.flush();
         assertThat(products.size(),is(1));
         HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(lexiconProduct,products.get(0));
        
    }
    @Test
    public void testCountBySearchCriteria(){
         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         int count  = lexiconProductDao.countBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria);
         assertThat(count,is(1));
    }
    @Test
    public void testCountBySearchCriteriaProductStageLogicallyDeleted(){
         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         LexiconProductStageEntity productStage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         productStage.setLogicalDelete(true);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         int count  = lexiconProductDao.countBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria);
         assertThat(count,is(0));
    }
    @Test
    public void testCountBySearchCriteriaProductLogicallyDeleted(){
         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         lexiconProduct.setLogicalDelete(true);
         TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         int count  = lexiconProductDao.countBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria);
         assertThat(count,is(0));
    }
    @Test
    public void testFindByBySearchCriteriaPaged(){
         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);        
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         List<LexiconProductEntity> products  = lexiconProductDao.findBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria,50,0);
         assertThat(products.size(),is(1));
         HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(lexiconProduct,products.get(0));
    }
}
