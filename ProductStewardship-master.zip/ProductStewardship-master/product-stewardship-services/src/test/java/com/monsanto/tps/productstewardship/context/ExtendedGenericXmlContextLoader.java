package com.monsanto.tps.productstewardship.context;

import com.monsanto.tps.springframework.config.ThreadScope;
import org.springframework.beans.factory.config.Scope;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.test.context.support.GenericXmlContextLoader;

/**
 * RLCASW - Sep 11, 2010 12:06:13 PM
 */
public class ExtendedGenericXmlContextLoader extends GenericXmlContextLoader {
    @Override
    protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory) {
        Scope singletonScope = new ThreadScope();
        beanFactory.registerScope("session", singletonScope);


        beanFactory.registerScope("request", singletonScope);
        super.customizeBeanFactory(beanFactory);
    }

}
