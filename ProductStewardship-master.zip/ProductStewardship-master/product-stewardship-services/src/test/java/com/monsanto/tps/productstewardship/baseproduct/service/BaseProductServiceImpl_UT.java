/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.service;

import com.monsanto.tps.productstewardship.baseproduct.business.createorupdate.BaseProductBusiness;
import com.monsanto.tps.productstewardship.baseproduct.business.search.BaseProductSearchBusiness;
import com.monsanto.tps.productstewardship.baseproduct.service.impl.BaseProductServiceImpl;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.mock;

/* vvkalu - 6/29/11 */
public class BaseProductServiceImpl_UT {

    private BaseProductServiceImpl baseProductServiceImpl;
    private BaseProductSearchBusiness baseProductServiceBusiness;
    private BaseProductBusiness baseProductBusiness;

    @Before
    public void setUp() {
        baseProductServiceImpl = new BaseProductServiceImpl();
        baseProductServiceBusiness = mock(BaseProductSearchBusiness.class);
        baseProductBusiness = mock(BaseProductBusiness.class);
        baseProductServiceImpl.setBaseProductSearchBusiness(baseProductServiceBusiness);
        baseProductServiceImpl.setBaseProductBusiness(baseProductBusiness);
    }

    @Test
    public void testSearchWithNullValues() throws Exception {
        List<BaseProduct> baseProducts = baseProductServiceImpl.findBaseProduct(null, null);
        assertNotNull(baseProducts);
        assertTrue(baseProducts.isEmpty());
    }

    @Test
    public void testSearchWithNonNullValues() throws Exception {
        List<BaseProduct> baseProducts = baseProductServiceImpl.findBaseProduct(BaseProductSearchType.MANUFACTURINGNAME, Arrays.asList("s", "g"));
        assertNotNull(baseProducts);
        assertEquals(0, baseProducts.size());
    }

    @Test
    public void testSaveWithNullValues() throws Exception {
        List<BaseProduct> baseProducts = baseProductServiceImpl.saveProductBaseProducts(null);
        assertNotNull(baseProducts);
        assertTrue(baseProducts.isEmpty());
    }

    @Test
    public void testSaveWithNonNullValues() throws Exception {
        List<BaseProduct> baseProducts = new ArrayList<BaseProduct>();
        BaseProduct baseProduct = new BaseProduct();
        baseProducts.add(baseProduct);
        List<BaseProduct> savedBaseProducts = baseProductServiceImpl.saveProductBaseProducts(baseProducts);
        assertNotNull(savedBaseProducts);
        assertEquals(0, savedBaseProducts.size());
    }
}