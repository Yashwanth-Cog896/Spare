package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LineTypeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

import static org.junit.Assert.*;

public class LineTypeDao_DUT extends HibernateTestCase {
    @Resource
    private LineTypeDao lineTypeDao;
    @Test
    public void testGetByRefId(){
        LineTypeEntity lineType = TestDataBuilder.buildLineType(currentSession);
        currentSession.flush();
        currentSession.clear();

        LineTypeEntity lineTypeEntity = lineTypeDao.getByRefId(lineType.getLineTypeRefId());
        assertFalse(lineType==lineTypeEntity);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(lineType, lineTypeEntity);
    }
}
