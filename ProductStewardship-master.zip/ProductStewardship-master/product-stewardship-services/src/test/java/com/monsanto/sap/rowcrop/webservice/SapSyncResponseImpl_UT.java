package com.monsanto.sap.rowcrop.webservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class SapSyncResponseImpl_UT{
   private static final Integer ERROR_CODE = 0;

  @Test
   public void testSapSyncResponseAsXmlString() throws Exception {
      SapSyncResponse response =
         new SapSyncResponseImpl((long)123, "update response", ERROR_CODE, "error message", "error detail");

      String responseAsXmlString = response.asXmlString();

      assertNotNull(responseAsXmlString);
   }
}
