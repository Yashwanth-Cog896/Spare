package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AutoNameBrandAssignEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AutoNameVarietyCodeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import org.junit.Assert;
import org.junit.Test;

import javax.annotation.Resource;

public class AutoNameBrandAssignDao_UT extends HibernateTestCase {

  @Resource
  private AutoNameBrandAssignDao autoNameBrandAssignDao;

  @Test
  public void testGetAutoNameBrand(){

    LexiconBrandEntity brand = TestDataBuilder.buildLexiconBrand(currentSession);
    brand.setAutoNameBrandCode("ZZ");
    AutoNameBrandAssignEntity newAutoNameBrandAssign = TestDataBuilder.buildAutoNameBrandAssignEntity(currentSession, TestDataBuilder.buildLexiconBrand(currentSession)) ;


    AutoNameBrandAssignEntity ret = autoNameBrandAssignDao.getAutoNameBrand(newAutoNameBrandAssign.getProductType().getId(),
                                                                            newAutoNameBrandAssign.getProductionEnvironment().getId());

    Assert.assertEquals(newAutoNameBrandAssign.getId(), ret.getId());
    Assert.assertEquals(newAutoNameBrandAssign.getBrand().getAutoNameBrandCode(), ret.getBrand().getAutoNameBrandCode());

  }
}
