package com.monsanto.tps.productstewardship.blend.business;

import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.dataservices.product.transfer.ProductGermplasmDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.MidasProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Jan 10, 2011
 * Time: 1:29:59 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class MidasProductIdToXrefMapBuilder_UT {
    @Mock
    MidasProductDao midasProductDao;
    @Mock
    private FbsCommonProductXrefEntity xref1;
    @Mock
    private MidasProductEntity product1;
    @Mock
    private FbsCommonProductXrefEntity xref2;
    @Mock
    private MidasProductEntity product2;
    @Mock
    private FbsCommonProductXrefEntity xref3;
    @Mock
    private MidasProductEntity product3;
    @Mock
    private FbsCommonProductXrefEntity xref4;
    @Mock
    private MidasProductEntity product4;
    @Mock
    private BlendedProductDetails component1;
    @Mock
    private BlendedProductDetails component2;

    private MidasProductIdToXrefMapBuilder builder;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm1;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm2;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm3;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm4;

    @Before
    public void setUp() {
        builder = new MidasProductIdToXrefMapBuilder();
        builder.setMidasProductDao(midasProductDao);
    }

    @Test
    public void test_buildMap_EmptyList() {
        Map<Long, FbsCommonProductXrefEntity> productXrefMap = builder.buildMap(new ArrayList<BlendedProductDetails>());
        assertNotNull(productXrefMap);
        verifyZeroInteractions(midasProductDao);
    }

    @Test
    public void test_buildMap_NullList() {
        Map<Long, FbsCommonProductXrefEntity> productXrefMap = builder.buildMap(null);
        assertNotNull(productXrefMap);
        verifyZeroInteractions(midasProductDao);
    }

    @Test
    public void test_buildMap_WithAllProductIds() {
        when(component1.getGermplasmId()).thenReturn(20L);
        when(component1.getComponentProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm1, componentProductGermplasm2));
        when(componentProductGermplasm1.getMidasProductIds()).thenReturn(Arrays.asList(1L));
        when(componentProductGermplasm2.getMidasProductIds()).thenReturn(Arrays.asList(2L));

        when(component2.getGermplasmId()).thenReturn(21L);
        when(component2.getBlendedProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm3, componentProductGermplasm4));
        when(componentProductGermplasm3.getMidasProductIds()).thenReturn(Arrays.asList(3L));
        when(componentProductGermplasm4.getMidasProductIds()).thenReturn(Arrays.asList(4L));

        when(product1.getId()).thenReturn(1L);
        when(xref1.getMidasProduct()).thenReturn(product1);
        when(xref1.getLexiconPubkey()).thenReturn("PUB1");
        when(product1.getFbsCommonProductXrefs()).thenReturn(new HashSet(Arrays.asList(xref1)));

        when(product2.getId()).thenReturn(2L);
        when(xref2.getMidasProduct()).thenReturn(product2);
        when(xref2.getLexiconPubkey()).thenReturn("PUB2");
        when(product2.getFbsCommonProductXrefs()).thenReturn(new HashSet(Arrays.asList(xref2)));

        when(product3.getId()).thenReturn(3L);
        when(xref3.getMidasProduct()).thenReturn(product3);
        when(xref3.getLexiconPubkey()).thenReturn("PUB3");
        when(product3.getFbsCommonProductXrefs()).thenReturn(new HashSet(Arrays.asList(xref3)));

        when(product4.getId()).thenReturn(4L);
        when(xref4.getMidasProduct()).thenReturn(product4);
        when(xref4.getLexiconPubkey()).thenReturn("PUB4");
        when(product4.getFbsCommonProductXrefs()).thenReturn(new HashSet(Arrays.asList(xref4)));

        when(midasProductDao.get(1L)).thenReturn(product1);
        when(midasProductDao.get(2L)).thenReturn(product2);
        when(midasProductDao.get(3L)).thenReturn(product3);
        when(midasProductDao.get(4L)).thenReturn(product4);
        Map<Long, FbsCommonProductXrefEntity> productXrefMap = builder.buildMap(Arrays.asList(component1, component2));

        assertNotNull(productXrefMap);
        assertEquals(4, productXrefMap.size());
        assertEquals(xref1, productXrefMap.get(1L));
        assertEquals(xref2, productXrefMap.get(2L));
        assertEquals(xref3, productXrefMap.get(3L));
        assertEquals(xref4, productXrefMap.get(4L));
    }
}
