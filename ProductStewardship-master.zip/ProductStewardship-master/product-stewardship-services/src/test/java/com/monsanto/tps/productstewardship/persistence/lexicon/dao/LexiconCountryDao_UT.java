package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

public class LexiconCountryDao_UT extends HibernateTestCase {
    @Resource
    private LexiconCountryDao lexiconCountryDao;

    @Test
    public void testCountryFound(){
        LexiconCountryEntity country = TestDataBuilder.buildCountry(currentSession);
        flushAndClearSession();
        LexiconCountryEntity foundCountry = lexiconCountryDao.findByAbbreviation(country.getAbbreviation());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(country,foundCountry);
    }
}
