package com.monsanto.tps.productstewardship.blend.business;

import com.monsanto.tps.dataservices.product.services.BlendedProductService;
import com.monsanto.tps.dataservices.product.transfer.BlendedProductDetails;
import com.monsanto.tps.dataservices.product.transfer.ProductGermplasmDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.BlendedComponentPreComlProduct;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexBlendedProductDetails;
import com.monsanto.tps.lexicon.blendedproduct.transfer.LexProductGermplasmDetails;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Sep 27, 2010
 * Time: 2:10:45 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class BlendedProductGermplasmBusiness_UT {

    private BlendedProductGermplasmBusiness blendedProductGermplasmBusiness;
    @Mock
    private BlendedProductService mockBlendedProductService;
    @Mock
    private BlendedProductDetails component1;
    @Mock
    private BlendedProductDetails component2;
    @Mock
    private ProductGermplasmDetails productGermplasm2;
    @Mock
    private ProductGermplasmDetails productGermplasm1;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm1;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm2;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm3;
    @Mock
    private ProductGermplasmDetails componentProductGermplasm4;
    @Mock
    private ProductGermplasmDetails productDetails1;
    @Mock
    private ProductGermplasmDetails productDetails2;
    @Mock
    private ProductGermplasmDetails productDetails3;
    @Mock
    private ProductGermplasmDetails productDetails4;

    @Mock
    private BlendedProductService blendedProductService;
    @Mock
    private MidasProductIdToXrefMapBuilder midasProductIdToXrefMapBuilder;

    @Before
    public void setUp() {
        BlendedProductDetailsBuilder blendedProductDetailsBuilder = new BlendedProductDetailsBuilder();
        BlendBuilderFactory factory = new BlendBuilderFactory();
        BlendedComponentsStrategy componentsStrategy = new BlendedComponentsStrategy();
        componentsStrategy.setLexBlendedProductBuilder(new LexBlendedProductBuilder());
        factory.setBlendedComponentsStrategy(componentsStrategy);

        BlendedProductsStrategy blendedProductsStrategy = new BlendedProductsStrategy();
        blendedProductsStrategy.setLexBlendedProductBuilder(new LexBlendedProductBuilder());
        factory.setBlendedProductsStrategy(blendedProductsStrategy);

        BlendProductDetailsStrategy blendProductDetailsStrategy = new BlendProductDetailsStrategy();
        blendProductDetailsStrategy.setComponentsStrategy(componentsStrategy);
        blendProductDetailsStrategy.setProductsStrategy(blendedProductsStrategy);
        factory.setBlendProductDetailsStrategy(blendProductDetailsStrategy);

        blendedProductDetailsBuilder.setBlendBuilderFactory(factory);

        blendedProductGermplasmBusiness = new BlendedProductGermplasmBusiness();
        blendedProductGermplasmBusiness.setBlendedProductService(mockBlendedProductService);
        blendedProductGermplasmBusiness.setBlendedProductDetailsBuilder(blendedProductDetailsBuilder);
        blendedProductGermplasmBusiness.setMidasProductIdToXrefMapBuilder(midasProductIdToXrefMapBuilder);
    }

    @Test
    public void test_getBlendedProductDetails_components() {
        when(component1.getGermplasmId()).thenReturn(20L);
        when(component1.getComponentProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm1, componentProductGermplasm2));
        when(componentProductGermplasm1.getMidasProductIds()).thenReturn(Arrays.asList(1L));
        when(componentProductGermplasm2.getMidasProductIds()).thenReturn(Arrays.asList(2L));

        when(component2.getGermplasmId()).thenReturn(21L);
        when(component2.getComponentProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm3, componentProductGermplasm4));
        when(componentProductGermplasm3.getMidasProductIds()).thenReturn(Arrays.asList(3L));
        when(componentProductGermplasm4.getMidasProductIds()).thenReturn(Arrays.asList(4L));

        FbsCommonProductXrefEntity xref1 = new FbsCommonProductXrefEntity();
        MidasProductEntity product1 = new MidasProductEntity();
        product1.setId(1L);
        xref1.setMidasProduct(product1);
        xref1.setLexiconPubkey("PUB1");
        LexiconProductEntity blendedPreComlProduct1 = new LexiconProductEntity();
           blendedPreComlProduct1.setPreCommercialName("PCN1");
           blendedPreComlProduct1.setPubkey("PUB1");
        xref1.setLexiconProduct(blendedPreComlProduct1);

        FbsCommonProductXrefEntity xref2 = new FbsCommonProductXrefEntity();
        MidasProductEntity product2 = new MidasProductEntity();
        product2.setId(2L);
        xref2.setMidasProduct(product2);
        xref2.setLexiconPubkey("PUB2");
        LexiconProductEntity blendedPreComlProduct2 = new LexiconProductEntity();
        blendedPreComlProduct2.setPreCommercialName("PCN2");
        blendedPreComlProduct2.setPubkey("PUB2");
        xref2.setLexiconProduct(blendedPreComlProduct2);

        FbsCommonProductXrefEntity xref3 = new FbsCommonProductXrefEntity();
        MidasProductEntity product3 = new MidasProductEntity();
        product3.setId(3L);
        xref3.setMidasProduct(product3);
        xref3.setLexiconPubkey("PUB3");
        LexiconProductEntity blendedPreComlProduct3 = new LexiconProductEntity();
        blendedPreComlProduct3.setPreCommercialName("PCN3");
        blendedPreComlProduct3.setPubkey("PUB3");
        xref3.setLexiconProduct(blendedPreComlProduct3);

        FbsCommonProductXrefEntity xref4 = new FbsCommonProductXrefEntity();
        MidasProductEntity product4 = new MidasProductEntity();
        product4.setId(4L);
        xref4.setMidasProduct(product4);
        xref4.setLexiconPubkey("PUB4");
        LexiconProductEntity blendedPreComlProduct4 = new LexiconProductEntity();
        blendedPreComlProduct4.setPreCommercialName("PCN4");
        blendedPreComlProduct4.setPubkey("PUB4");
        xref4.setLexiconProduct(blendedPreComlProduct4);

        Map<Long, FbsCommonProductXrefEntity> productXrefMap = new HashMap<Long, FbsCommonProductXrefEntity>();
        productXrefMap.put(1L, xref1);
        productXrefMap.put(2L, xref2);
        productXrefMap.put(3L, xref3);
        productXrefMap.put(4L, xref4);



        when(mockBlendedProductService.getBlendedProductComponents(Arrays.asList(20L, 21L, 22L, 23L))).thenReturn(Arrays.asList(component1, component2));
        when(midasProductIdToXrefMapBuilder.buildMap(Arrays.asList(component1, component2))).thenReturn(productXrefMap);
        List<LexBlendedProductDetails> resultComponents = blendedProductGermplasmBusiness.getBlendedProductDetails(Arrays.asList(20L, 21L, 22L, 23L));

        assertNotNull(resultComponents);
        assertEquals(2, resultComponents.size());
        assertEquals(20L, resultComponents.get(0).getBlendedGermplasmId().longValue());
        assertEquals(21L, resultComponents.get(1).getBlendedGermplasmId().longValue());

        List<LexProductGermplasmDetails> germplasmList = resultComponents.get(0).getComponentProductGermplasms();
        assertEquals(2, germplasmList.size());
        assertEquals(1, germplasmList.get(0).getPreComlProduct().size());

        BlendedComponentPreComlProduct product = germplasmList.get(0).getPreComlProduct().get(0);
        assertEquals("PCN1", product.getPreComlName());
        assertEquals("PUB1", product.getLexiconProductPubkey());

        assertEquals(1, germplasmList.get(1).getPreComlProduct().size());
        BlendedComponentPreComlProduct comlProduct = germplasmList.get(1).getPreComlProduct().get(0);
        assertEquals("PCN2", comlProduct.getPreComlName());
        assertEquals("PUB2", comlProduct.getLexiconProductPubkey());

        List<LexProductGermplasmDetails> productGermplasmList = resultComponents.get(1).getComponentProductGermplasms();
        assertEquals(2, productGermplasmList.size());

        assertEquals(1, productGermplasmList.get(0).getPreComlProduct().size());
        BlendedComponentPreComlProduct blendedComponentPreComlProduct = productGermplasmList.get(0).getPreComlProduct().get(0);
        assertEquals("PCN3", blendedComponentPreComlProduct.getPreComlName());
        assertEquals("PUB3", blendedComponentPreComlProduct.getLexiconProductPubkey());

        assertEquals(1, productGermplasmList.get(1).getPreComlProduct().size());
        BlendedComponentPreComlProduct comlProduct1 = productGermplasmList.get(1).getPreComlProduct().get(0);
        assertEquals("PCN4", comlProduct1.getPreComlName());
        assertEquals("PUB4", comlProduct1.getLexiconProductPubkey());
    }

    @Test
    public void test_getBlendedProductDetail_BlendedProducts() {
        when(component1.getGermplasmId()).thenReturn(20L);
        when(component1.getBlendedProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm1));
        when(componentProductGermplasm1.getMidasProductIds()).thenReturn(Arrays.asList(1L));

        when(component2.getGermplasmId()).thenReturn(21L);
        when(component2.getBlendedProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm3));
        when(componentProductGermplasm3.getMidasProductIds()).thenReturn(Arrays.asList(3L));

        FbsCommonProductXrefEntity xref1 = new FbsCommonProductXrefEntity();

        MidasProductEntity product1 = new MidasProductEntity();
        product1.setId(1L);
        xref1.setMidasProduct(product1);
        xref1.setLexiconPubkey("PUB1");
        LexiconProductEntity blendedPreComlProduct1 = new LexiconProductEntity();
         blendedPreComlProduct1.setPreCommercialName("PCN1");
         blendedPreComlProduct1.setPubkey("PUB1");
         xref1.setLexiconProduct(blendedPreComlProduct1);
        FbsCommonProductXrefEntity xref3 = new FbsCommonProductXrefEntity();
        MidasProductEntity product3 = new MidasProductEntity();
        product3.setId(3L);
        xref3.setMidasProduct(product3);
        xref3.setLexiconPubkey("PUB3");
        LexiconProductEntity blendedPreComlProduct3 = new LexiconProductEntity();
        blendedPreComlProduct3.setPreCommercialName("PCN3");
        blendedPreComlProduct3.setPubkey("PUB3");
        xref3.setLexiconProduct(blendedPreComlProduct3);
        Map<Long, FbsCommonProductXrefEntity> productXrefMap = new HashMap<Long, FbsCommonProductXrefEntity>();
        productXrefMap.put(1L, xref1);
        productXrefMap.put(3L, xref3);




        List<LexiconProductEntity> preComlProducts = new ArrayList<LexiconProductEntity>();
        preComlProducts.add(blendedPreComlProduct1);
        preComlProducts.add(blendedPreComlProduct3);

        when(mockBlendedProductService.getBlendedProductComponents(Arrays.asList(20L, 21L, 22L, 23L))).thenReturn(Arrays.asList(component1, component2));
        when(midasProductIdToXrefMapBuilder.buildMap(Arrays.asList(component1, component2))).thenReturn(productXrefMap);

        List<LexBlendedProductDetails> resultComponents = blendedProductGermplasmBusiness.getBlendedProductDetails(Arrays.asList(20L, 21L, 22L, 23L));

        assertNotNull(resultComponents);
        assertEquals(2, resultComponents.size());
        assertEquals(20L, resultComponents.get(0).getBlendedGermplasmId().longValue());
        assertEquals(21L, resultComponents.get(1).getBlendedGermplasmId().longValue());

        List<LexProductGermplasmDetails> germplasmList = resultComponents.get(0).getBlendedProductGermplasms();
        assertEquals(1, germplasmList.size());
        assertEquals(1, germplasmList.get(0).getPreComlProduct().size());

        BlendedComponentPreComlProduct product = germplasmList.get(0).getPreComlProduct().get(0);
        assertEquals("PCN1", product.getPreComlName());
        assertEquals("PUB1", product.getLexiconProductPubkey());

        List<LexProductGermplasmDetails> productGermplasmList = resultComponents.get(1).getBlendedProductGermplasms();
        assertEquals(1, productGermplasmList.size());

        assertEquals(1, productGermplasmList.get(0).getPreComlProduct().size());
        BlendedComponentPreComlProduct blendedComponentPreComlProduct = productGermplasmList.get(0).getPreComlProduct().get(0);
        assertEquals("PCN3", blendedComponentPreComlProduct.getPreComlName());
        assertEquals("PUB3", blendedComponentPreComlProduct.getLexiconProductPubkey());

    }

    @Test
    public void test_getBlendedProductDetails_BothBlendsAndComponents() {
        when(component1.getGermplasmId()).thenReturn(20L);
        when(component1.getComponentProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm1, componentProductGermplasm2));
        when(componentProductGermplasm1.getMidasProductIds()).thenReturn(Arrays.asList(1L));
        when(componentProductGermplasm2.getMidasProductIds()).thenReturn(Arrays.asList(2L));

        when(component1.getBlendedProductGermplasms()).thenReturn(Arrays.asList(componentProductGermplasm3, componentProductGermplasm4));
        when(componentProductGermplasm3.getMidasProductIds()).thenReturn(Arrays.asList(3L));
        when(componentProductGermplasm4.getMidasProductIds()).thenReturn(Arrays.asList(4L));

        FbsCommonProductXrefEntity xref1 = new FbsCommonProductXrefEntity();
        MidasProductEntity product1 = new MidasProductEntity();
        product1.setId(1L);
        xref1.setMidasProduct(product1);
        xref1.setLexiconPubkey("PUB1");
        LexiconProductEntity blendedPreComlProduct1 = new LexiconProductEntity();
        blendedPreComlProduct1.setPreCommercialName("PCN1");
        blendedPreComlProduct1.setPubkey("PUB1");
        xref1.setLexiconProduct(blendedPreComlProduct1);

        FbsCommonProductXrefEntity xref2 = new FbsCommonProductXrefEntity();
        MidasProductEntity product2 = new MidasProductEntity();
        product2.setId(2L);
        xref2.setMidasProduct(product2);
        xref2.setLexiconPubkey("PUB2");
        LexiconProductEntity blendedPreComlProduct2 = new LexiconProductEntity();
        blendedPreComlProduct2.setPreCommercialName("PCN2");
        blendedPreComlProduct2.setPubkey("PUB2");
        xref2.setLexiconProduct(blendedPreComlProduct2);

        FbsCommonProductXrefEntity xref3 = new FbsCommonProductXrefEntity();
        MidasProductEntity product3 = new MidasProductEntity();
        product3.setId(3L);
        xref3.setMidasProduct(product3);
        xref3.setLexiconPubkey("PUB3");
        LexiconProductEntity blendedPreComlProduct3 = new LexiconProductEntity();
        blendedPreComlProduct3.setPreCommercialName("PCN3");
        blendedPreComlProduct3.setPubkey("PUB3");
        xref3.setLexiconProduct(blendedPreComlProduct3);

        FbsCommonProductXrefEntity xref4 = new FbsCommonProductXrefEntity();
        MidasProductEntity product4 = new MidasProductEntity();
        product4.setId(4L);
        xref4.setMidasProduct(product4);
        xref4.setLexiconPubkey("PUB4");
        LexiconProductEntity blendedPreComlProduct4 = new LexiconProductEntity();
        blendedPreComlProduct4.setPreCommercialName("PCN4");
        blendedPreComlProduct4.setPubkey("PUB4");
        xref4.setLexiconProduct(blendedPreComlProduct4);

        Map<Long, FbsCommonProductXrefEntity> productXrefMap = new HashMap<Long, FbsCommonProductXrefEntity>();
        productXrefMap.put(1L, xref1);
        productXrefMap.put(2L, xref2);
        productXrefMap.put(3L, xref3);
        productXrefMap.put(4L, xref4);

        List<LexiconProductEntity> preComlProducts = new ArrayList<LexiconProductEntity>();
        preComlProducts.add(blendedPreComlProduct1);
        preComlProducts.add(blendedPreComlProduct2);
        preComlProducts.add(blendedPreComlProduct3);
        preComlProducts.add(blendedPreComlProduct4);

        when(mockBlendedProductService.getBlendedProductComponents(Arrays.asList(20L, 21L, 22L, 23L))).thenReturn(Arrays.asList(component1));
        when(midasProductIdToXrefMapBuilder.buildMap(Arrays.asList(component1))).thenReturn(productXrefMap);

        List<LexBlendedProductDetails> resultComponents = blendedProductGermplasmBusiness.getBlendedProductDetails(Arrays.asList(20L, 21L, 22L, 23L));

        assertNotNull(resultComponents);
        assertEquals(1, resultComponents.size());
        assertEquals(20L, resultComponents.get(0).getBlendedGermplasmId().longValue());

        List<LexProductGermplasmDetails> germplasmList = resultComponents.get(0).getComponentProductGermplasms();
        assertEquals(2, germplasmList.size());
        assertEquals(1, germplasmList.get(0).getPreComlProduct().size());

        BlendedComponentPreComlProduct product = germplasmList.get(0).getPreComlProduct().get(0);
        assertEquals("PCN1", product.getPreComlName());
        assertEquals("PUB1", product.getLexiconProductPubkey());

        assertEquals(1, germplasmList.get(1).getPreComlProduct().size());
        BlendedComponentPreComlProduct comlProduct = germplasmList.get(1).getPreComlProduct().get(0);
        assertEquals("PCN2", comlProduct.getPreComlName());
        assertEquals("PUB2", comlProduct.getLexiconProductPubkey());

        List<LexProductGermplasmDetails> productGermplasmList = resultComponents.get(0).getBlendedProductGermplasms();
        assertEquals(2, productGermplasmList.size());

        assertEquals(1, productGermplasmList.get(0).getPreComlProduct().size());
        BlendedComponentPreComlProduct blendedComponentPreComlProduct = productGermplasmList.get(0).getPreComlProduct().get(0);
        assertEquals("PCN3", blendedComponentPreComlProduct.getPreComlName());
        assertEquals("PUB3", blendedComponentPreComlProduct.getLexiconProductPubkey());

        assertEquals(1, productGermplasmList.get(1).getPreComlProduct().size());
        BlendedComponentPreComlProduct comlProduct1 = productGermplasmList.get(1).getPreComlProduct().get(0);
        assertEquals("PCN4", comlProduct1.getPreComlName());
        assertEquals("PUB4", comlProduct1.getLexiconProductPubkey());
    }

    @Test
    public void return_Empty_List_WhenGermplasmIds_Empty() {
        List<LexBlendedProductDetails> result = blendedProductGermplasmBusiness.getBlendedProductDetails(new ArrayList<Long>());
        assertTrue(result.isEmpty());
        verifyZeroInteractions(mockBlendedProductService);
        verifyZeroInteractions(midasProductIdToXrefMapBuilder);
        
    }

    @Test
    public void return_Empty_Map_WhenGermplasmIds_Null() {
        List<LexBlendedProductDetails> result = blendedProductGermplasmBusiness.getBlendedProductDetails(null);
        assertTrue(result.isEmpty());
        verifyZeroInteractions(mockBlendedProductService);
        verifyZeroInteractions(midasProductIdToXrefMapBuilder);
    }
}
