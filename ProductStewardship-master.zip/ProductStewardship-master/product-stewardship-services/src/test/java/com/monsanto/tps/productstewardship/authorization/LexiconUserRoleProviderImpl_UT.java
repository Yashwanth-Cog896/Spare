package com.monsanto.tps.productstewardship.authorization;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.*;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import java.util.Arrays;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 3, 2011
 * Time: 11:04:42 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LexiconUserRoleProviderImpl_UT {
    @Mock
    private UserProfile userProfile;
    @Mock
    private UserPrivilegesService userPrivilegesService;
    @InjectMocks
    private LexiconUserRoleProviderImpl userRoleProvider = new LexiconUserRoleProviderImpl();

    @Test
    public  void testHasRoleTrue(){
       String testRole = "testRole1";
       String testUser = "test";
       when(userProfile.getUserName()).thenReturn(testUser);
       when(userPrivilegesService.getRoles(testUser)).thenReturn(Arrays.asList(testRole,"testRole2"));
       assertThat(userRoleProvider.hasRole(testRole),is(true));
    }
    @Test
    public  void testHasRoleFalse(){
       String testRole = "testRole1";
       String testUser = "test";
       when(userProfile.getUserName()).thenReturn(testUser);
       when(userPrivilegesService.getRoles(testUser)).thenReturn(Arrays.asList("testRole2"));
       assertThat(userRoleProvider.hasRole(testRole),is(false));
    }
    @Test
    public void testGetRoles(){

       String testUser = "test";
       when(userProfile.getUserName()).thenReturn(testUser);
       String testRole = "testRole";
       when(userPrivilegesService.getRoles(testUser)).thenReturn(Arrays.asList(testRole));
       assertThat(userRoleProvider.getRoles().get(0).getRoleName(),is(testRole));
    }
}
