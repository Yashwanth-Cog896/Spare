package com.monsanto.sap.rowcrop.webservice.productcountry;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCountryEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.util.xml.DocumentValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.w3c.dom.Document;

import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class SapProductCountrySerializer_UT {
  @Test
  public void testConformsToSchema()throws Exception {
      LexiconProductStageEntity productStage = new LexiconProductStageEntity();
      LexiconCountryEntity country = new LexiconCountryEntity();
      country.setPubkey("country123");
      country.setIsoCode("33");
      LexiconBrandEntity brand = new LexiconBrandEntity();
      brand.setPubkey("brand 123");
      LexiconStageEntity stage = new LexiconStageEntity();
      stage.setAbbreviation("PS");
      CommercialTraitStackEntity  traitStack = new CommercialTraitStackEntity();
      traitStack.setPubkey("stack 123");

      productStage.setId(123L);
      productStage.setPubkey("321");
      productStage.setLexiconCountry(country);
      productStage.setLexiconBrand(brand);
      productStage.setCommercialName("Commercial name");
      productStage.setLexiconStage(stage);
      productStage.setCommercialTraitStack(traitStack);
      productStage.setCommercialMaturity(10.0);
      productStage.setActive(true);
      productStage.setLogicalDelete(false);

      SapProductCountryInfo sapProductCountryInfo = new SapProductCountryInfo(productStage, productStage.getId());

      SapProductCountrySerializer serializer = new SapProductCountrySerializer();
      Document doc = serializer.toDocument(sapProductCountryInfo);

      assertTrue(DocumentValidator.isDocumentValid(doc, SapProductCountrySchemaConstants.SCHEMA_LOC));
  }

  @Test
  public void testConformsToSchema_withNullComlTrait()throws Exception {
      LexiconProductStageEntity productStage = new LexiconProductStageEntity();
      LexiconCountryEntity country = new LexiconCountryEntity();
      country.setPubkey("country123");
      country.setIsoCode("33");
      LexiconBrandEntity brand = new LexiconBrandEntity();
      brand.setPubkey("brand 123");
      LexiconStageEntity stage = new LexiconStageEntity();
      stage.setAbbreviation("PS");

      productStage.setId(123L);
      productStage.setPubkey("321");
      productStage.setLexiconCountry(country);
      productStage.setLexiconBrand(brand);
      productStage.setCommercialName("Commercial name");
      productStage.setLexiconStage(stage);
      productStage.setCommercialMaturity(10.0);
      productStage.setActive(true);
      productStage.setLogicalDelete(false);

      SapProductCountryInfo sapProductCountryInfo = new SapProductCountryInfo(productStage, productStage.getId());

      SapProductCountrySerializer serializer = new SapProductCountrySerializer();
      Document doc = serializer.toDocument(sapProductCountryInfo);

      assertTrue(DocumentValidator.isDocumentValid(doc, SapProductCountrySchemaConstants.SCHEMA_LOC));
  }
}
