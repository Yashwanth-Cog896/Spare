package com.monsanto.osb.webservice.credentials;

import com.monsanto.tps.productstewardship.gqa.business.WebMethodsCredentials;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.util.List;
import java.util.Arrays;

@RunWith(MockitoJUnitRunner.class)
public class CredentialsFactory_UT {
    @Test
    public void testCreateCredentialsContainer(){
        CredentialsFactory credentialsFactory = new CredentialsFactory();
        String username = "username";
        String password = "password";
        credentialsFactory.setWebMethodsCredentials(new WebMethodsCredentials(username + ":" + password));
        CredentialsContainer credentialsContainer = credentialsFactory.createCredentialsContainer();
        Credentials credentials = credentialsContainer.getCredentials();
        assertThat(credentials.getUsername(),is(username));
        Password passwordContainer = credentials.getPassword();
        assertThat(passwordContainer.getValue(),is(password));
        assertThat(passwordContainer.getType(),is(CredentialsFactory.PASSWORD_XML_TYPE));
    }
}
