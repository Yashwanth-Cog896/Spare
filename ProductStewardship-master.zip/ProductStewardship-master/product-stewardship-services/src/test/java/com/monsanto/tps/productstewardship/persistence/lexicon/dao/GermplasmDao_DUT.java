package com.monsanto.tps.productstewardship.persistence.lexicon.dao;


import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GermplasmEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Map;

public class GermplasmDao_DUT extends HibernateTestCase {
  @Resource
  private GermplasmDao germplasmDao;

  @Test
  public void testGetById(){
    MidasCropEntity midasCrop = TestDataBuilder.buildMidasCrop(currentSession);
    GermplasmEntity germplasm =   TestDataBuilder.buildGermplasmEntity(currentSession, midasCrop)  ;
    saveFlushAndClear(germplasm);

    GermplasmEntity retGermplasm = germplasmDao.get(germplasm.getId());
    HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(germplasm, retGermplasm);

  }

  @Test
  public void testGetFemaleMaleLexiconPubKey() throws Exception {
    Long germplasmID = 422083298164l;
    Map<String,String> pubKeyDetails = germplasmDao.getFemaleMaleLexiconPubKey(germplasmID);

  }
}
