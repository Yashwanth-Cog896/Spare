package com.monsanto.tps.productstewardship.gqa.business;


import com.monsanto.mfg.gqa.lexicon.webservice.*;
import com.monsanto.osb.webservice.credentials.Credentials;
import com.monsanto.osb.webservice.credentials.CredentialsContainer;
import com.monsanto.osb.webservice.credentials.CredentialsFactory;
import com.monsanto.osb.webservice.credentials.Password;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;

import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 19, 2011
 * Time: 12:24:13 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class GqaProductFlowImpl_UT {
    @Mock
    private PqSapQueueEntryDao pqSapQueueEntryDao;
    @Mock
    private ProductRelationshipDao productRelationshipDao;
    @Mock
    private LexiconProductStageDao lexiconProductStageDao;
    @Mock
    private LexiconProductDao lexiconProductDao;
    @Mock
    private PqSapLogDao pqSapLogDao;
    @Mock
    private ProductChangeListener productChangeListener;
    @Mock
    private BaseProductDao baseProductDao;
    @Mock
    CredentialsFactory credentialsFactory;

  
    private GqaProductFlowImpl gqaFlow = new GqaProductFlowImpl();

    @Before
    public void setup(){
        gqaFlow.setPqSapQueueEntryDao(pqSapQueueEntryDao);
        gqaFlow.setProductRelationshipDao(productRelationshipDao);
        gqaFlow.setLexiconProductStageDao(lexiconProductStageDao);
        gqaFlow.setLexiconProductDao(lexiconProductDao);
        gqaFlow.setPqSapLogDao(pqSapLogDao);
        gqaFlow.setProductChangeListener(productChangeListener);
        gqaFlow.setBaseProductDao(baseProductDao);
        gqaFlow.setCredentialsFactory(credentialsFactory);
        CredentialsContainer credentialsContainer = new CredentialsContainer();
        Password password = new Password();
        password.setValue("password");
        Credentials credentials = new Credentials();
        credentials.setPassword(password);
        credentials.setUsername("username");
        credentialsContainer.setCredentials(credentials);
        when(credentialsFactory.createCredentialsContainer()).thenReturn(credentialsContainer);

    }


    public static final String CROP_ABBREVIATION = "CR";


    @Test
    public void testGetPqSapProductIdsToProcess(){
        List<Long> idsList = Arrays.asList(new Long(1L));
        when(pqSapQueueEntryDao.getPqSapQueueEntryIdsToProcessForGqa()).thenReturn(idsList);
        List<Long> readIds = gqaFlow.getPqSapProductIdsToProcess();
        assertThat(readIds,is(idsList));
    }
    @Test
    public void testFlowPreComlProduct(){


        PqSapQueueEntryEntity pqSapQueueEntry = new PqSapQueueEntryEntity();
        long productId = 33L;
        pqSapQueueEntry.setTableId(productId);
        pqSapQueueEntry.setShouldProcess(true);
        pqSapQueueEntry.setTableName(PqSapQueueEntryEntity.PRE_COML_PRODUCT);
        pqSapQueueEntry.setProcessType(PqSapProcessType.GQA);
        when(pqSapQueueEntryDao.retrieveForUpdateAndLock(1L)).thenReturn(pqSapQueueEntry);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        String productPubkey = "productPubkey";
        lexiconProduct.setPubkey(productPubkey);
        lexiconProduct.setLexiconCrop(createCrop());
        when(lexiconProductDao.get(productId)).thenReturn(lexiconProduct);
        gqaFlow.flowNextChangeToGqa(1L);
        verify(pqSapQueueEntryDao,times(1)).delete(pqSapQueueEntry);
        ArgumentCaptor<PqSapLogEntity> captor = ArgumentCaptor.forClass(PqSapLogEntity.class);
        verify(pqSapLogDao,times(1)).saveOrUpdate(captor.capture());
        PqSapLogEntity log = captor.getValue();
        assertThat(log.getCloseDate(), CoreMatchers.<Object>notNullValue());
        assertThat(log.getTableId(),is(productId));
        assertThat(log.getTableName(),is(PqSapQueueEntryEntity.PRE_COML_PRODUCT));
        assertThat(log.getInitDate(),is(pqSapQueueEntry.getInitDate()));
        assertThat(log.getMessage(), nullValue());
        assertThat(log.getStatus(), is(PqSapProductLogStatus.S));
        assertThat(log.getProcessType(),is(pqSapQueueEntry.getProcessType()));
        ArgumentCaptor<ProductChangeInformation> changeInfoCaptor = ArgumentCaptor.forClass(ProductChangeInformation.class);
        ArgumentCaptor<CredentialsContainer> credentialsCaptor = ArgumentCaptor.forClass(CredentialsContainer.class);
        verify(productChangeListener,times(1)).productChanged(credentialsCaptor.capture(),changeInfoCaptor.capture());
        ProductChangeInformation changeInfo = changeInfoCaptor.getValue();
        assertThat(changeInfo.getSpeciesCode(),is(CROP_ABBREVIATION));
        assertThat(changeInfo.getProductKey(),is(productPubkey));

        CredentialsContainer cc = credentialsCaptor.getValue();
        assertThat(cc.getCredentials().getPassword().getValue(),is("password"));
        assertThat(cc.getCredentials().getUsername(),is("username"));

    }
    @Test
    public void testFlowPreComlProductExceptionThrown(){

        String message = "TESTTHROWS";
        long productId = 33L;
        PqSapQueueEntryEntity pqSapQueueEntry = new PqSapQueueEntryEntity();
        pqSapQueueEntry.setTableId(productId);
        pqSapQueueEntry.setShouldProcess(true);
        pqSapQueueEntry.setTableName(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP_XREF);
        when(pqSapQueueEntryDao.retrieveForUpdateAndLock(1L)).thenReturn(pqSapQueueEntry);
        when(lexiconProductDao.get(productId)).thenThrow(new RuntimeException(message));
        gqaFlow.flowNextChangeToGqa(1L);
        ArgumentCaptor<PqSapLogEntity> logCaptor = ArgumentCaptor.forClass(PqSapLogEntity.class);
        verify(pqSapLogDao,times(1)).saveOrUpdate(logCaptor.capture());
        assertThat(logCaptor.getValue().getMessage().contains(message),is(true));
    }

    @Test
    public void testFlowProductRelationshipXref(){
        PqSapQueueEntryEntity pqSapQueueEntry = new PqSapQueueEntryEntity();
        long productId = 33L;
        pqSapQueueEntry.setTableId(productId);
        pqSapQueueEntry.setShouldProcess(true);
        pqSapQueueEntry.setTableName(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP_XREF);
        when(pqSapQueueEntryDao.retrieveForUpdateAndLock(1L)).thenReturn(pqSapQueueEntry);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        String productPubkey = "productPubkey";
        lexiconProduct.setPubkey(productPubkey);
        lexiconProduct.setLexiconCrop(createCrop());
        when(lexiconProductDao.get(productId)).thenReturn(lexiconProduct);
        gqaFlow.flowNextChangeToGqa(1L);
        verify(pqSapQueueEntryDao,times(1)).delete(pqSapQueueEntry);
        ArgumentCaptor<PqSapLogEntity> captor = ArgumentCaptor.forClass(PqSapLogEntity.class);
        verify(pqSapLogDao,times(1)).saveOrUpdate(captor.capture());
        PqSapLogEntity log = captor.getValue();
        assertThat(log.getCloseDate(), CoreMatchers.<Object>notNullValue());
        assertThat(log.getTableId(),is(productId));
        assertThat(log.getTableName(),is(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP_XREF));
        assertThat(log.getInitDate(),is(pqSapQueueEntry.getInitDate()));
        assertThat(log.getMessage(), nullValue());
        assertThat(log.getStatus(), is(PqSapProductLogStatus.S));
        ArgumentCaptor<ProductChangeInformation> changeInfoCaptor = ArgumentCaptor.forClass(ProductChangeInformation.class);
        verify(productChangeListener,times(1)).productChanged(org.mockito.Matchers.any(CredentialsContainer.class),changeInfoCaptor.capture());
        ProductChangeInformation changeInfo = changeInfoCaptor.getValue();
        assertThat(changeInfo.getSpeciesCode(),is(CROP_ABBREVIATION));
        assertThat(changeInfo.getProductKey(),is(productPubkey));

    }

    @Test
    public void testFlowProductRelationship(){
        PqSapQueueEntryEntity pqSapQueueEntry = new PqSapQueueEntryEntity();
        long productId = 33L;
        long relationshipId = 44L;
        pqSapQueueEntry.setTableId(relationshipId);
        pqSapQueueEntry.setShouldProcess(true);
        pqSapQueueEntry.setTableName(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP);
        when(pqSapQueueEntryDao.retrieveForUpdateAndLock(1L)).thenReturn(pqSapQueueEntry);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        String productPubkey = "productPubkey";
        lexiconProduct.setPubkey(productPubkey);
        lexiconProduct.setLexiconCrop(createCrop());
        ProductRelationshipEntity relationship = new ProductRelationshipEntity();
        ProductRelationshipXrefEntity xref = new ProductRelationshipXrefEntity();
        xref.setLexiconProduct(lexiconProduct);
        relationship.getProductRelationshipXRefs().add(xref);
        when(productRelationshipDao.get(relationshipId)).thenReturn(relationship);
        gqaFlow.flowNextChangeToGqa(1L);
        verify(pqSapQueueEntryDao,times(1)).delete(pqSapQueueEntry);
        ArgumentCaptor<PqSapLogEntity> captor = ArgumentCaptor.forClass(PqSapLogEntity.class);
        verify(pqSapLogDao,times(1)).saveOrUpdate(captor.capture());
        PqSapLogEntity log = captor.getValue();
        assertThat(log.getCloseDate(), CoreMatchers.<Object>notNullValue());
        assertThat(log.getTableId(),is(relationshipId));
        assertThat(log.getTableName(),is(PqSapQueueEntryEntity.PRODUCT_RELATIONSHIP));
        assertThat(log.getInitDate(),is(pqSapQueueEntry.getInitDate()));
        assertThat(log.getMessage(), nullValue());
        assertThat(log.getStatus(), is(PqSapProductLogStatus.S));
        ArgumentCaptor<ProductChangeInformation> changeInfoCaptor = ArgumentCaptor.forClass(ProductChangeInformation.class);
        verify(productChangeListener,times(1)).productChanged(org.mockito.Matchers.any(CredentialsContainer.class),changeInfoCaptor.capture());
        ProductChangeInformation changeInfo = changeInfoCaptor.getValue();
        assertThat(changeInfo.getSpeciesCode(),is(CROP_ABBREVIATION));
        assertThat(changeInfo.getProductKey(),is(productPubkey));
    }

    private LexiconCropEntity createCrop() {
        LexiconCropEntity crop = new LexiconCropEntity();
        crop.setAbbreviation(CROP_ABBREVIATION);
        return crop;
    }

    @Test
    public void testFlowBaseProduct(){
        PqSapQueueEntryEntity pqSapQueueEntry = new PqSapQueueEntryEntity();
        long productId = 33L;
        long baseProductId = 44L;
        pqSapQueueEntry.setTableId(baseProductId);
        pqSapQueueEntry.setShouldProcess(true);
        pqSapQueueEntry.setTableName(PqSapQueueEntryEntity.BASE_PRODUCT);
        when(pqSapQueueEntryDao.retrieveForUpdateAndLock(1L)).thenReturn(pqSapQueueEntry);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        String productPubkey = "productPubkey";
        lexiconProduct.setPubkey(productPubkey);
        lexiconProduct.setLexiconCrop(createCrop());
        BaseProductEntity baseProduct = new BaseProductEntity();
        ProductRelationshipEntity relationship = new ProductRelationshipEntity();
        ProductRelationshipXrefEntity xref = new ProductRelationshipXrefEntity();
        xref.setLexiconProduct(lexiconProduct);
        relationship.getProductRelationshipXRefs().add(xref);
        baseProduct.getProductRelationships().add(relationship);
        when(baseProductDao.get(baseProductId)).thenReturn(baseProduct);
        gqaFlow.flowNextChangeToGqa(1L);
        verify(pqSapQueueEntryDao,times(1)).delete(pqSapQueueEntry);
        ArgumentCaptor<PqSapLogEntity> captor = ArgumentCaptor.forClass(PqSapLogEntity.class);
        verify(pqSapLogDao,times(1)).saveOrUpdate(captor.capture());
        PqSapLogEntity log = captor.getValue();
        assertThat(log.getCloseDate(), CoreMatchers.<Object>notNullValue());
        assertThat(log.getTableId(),is(baseProductId));
        assertThat(log.getTableName(),is(PqSapQueueEntryEntity.BASE_PRODUCT));
        assertThat(log.getInitDate(),is(pqSapQueueEntry.getInitDate()));
        assertThat(log.getMessage(), nullValue());
        assertThat(log.getStatus(), is(PqSapProductLogStatus.S));
        ArgumentCaptor<ProductChangeInformation> changeInfoCaptor = ArgumentCaptor.forClass(ProductChangeInformation.class);
        verify(productChangeListener,times(1)).productChanged(org.mockito.Matchers.any(CredentialsContainer.class),changeInfoCaptor.capture());
        ProductChangeInformation changeInfo = changeInfoCaptor.getValue();
        assertThat(changeInfo.getSpeciesCode(),is(CROP_ABBREVIATION));
        assertThat(changeInfo.getProductKey(),is(productPubkey));
    }
    @Test
    public void testFlowLexiconProductStage(){
        PqSapQueueEntryEntity pqSapQueueEntry = new PqSapQueueEntryEntity();
        long productId = 33L;
        pqSapQueueEntry.setTableId(productId);
        pqSapQueueEntry.setShouldProcess(true);
        pqSapQueueEntry.setTableName(PqSapQueueEntryEntity.PRODUCT_STAGE);

        when(pqSapQueueEntryDao.retrieveForUpdateAndLock(1L)).thenReturn(pqSapQueueEntry);
        LexiconProductEntity lexiconProduct = new LexiconProductEntity();
        lexiconProduct.setId(productId);
        String productPubkey = "productPubkey";
        lexiconProduct.setPubkey(productPubkey);
        lexiconProduct.setLexiconCrop(createCrop());
        LexiconProductStageEntity stage = new LexiconProductStageEntity();
        stage.setLexiconProduct(lexiconProduct);
        when(lexiconProductStageDao.get(productId)).thenReturn(stage);
        gqaFlow.flowNextChangeToGqa(1L);
        verify(pqSapQueueEntryDao,times(1)).delete(pqSapQueueEntry);
        ArgumentCaptor<PqSapLogEntity> captor = ArgumentCaptor.forClass(PqSapLogEntity.class);
        verify(pqSapLogDao,times(1)).saveOrUpdate(captor.capture());
        PqSapLogEntity log = captor.getValue();
        assertThat(log.getCloseDate(), CoreMatchers.<Object>notNullValue());
        assertThat(log.getTableId(),is(productId));
        assertThat(log.getTableName(),is(PqSapQueueEntryEntity.PRODUCT_STAGE));
        assertThat(log.getInitDate(),is(pqSapQueueEntry.getInitDate()));
        assertThat(log.getMessage(), nullValue());
        assertThat(log.getStatus(), is(PqSapProductLogStatus.S));
        ArgumentCaptor<ProductChangeInformation> changeInfoCaptor = ArgumentCaptor.forClass(ProductChangeInformation.class);
        verify(productChangeListener,times(1)).productChanged(org.mockito.Matchers.any(CredentialsContainer.class),changeInfoCaptor.capture());
        ProductChangeInformation changeInfo = changeInfoCaptor.getValue();
        assertThat(changeInfo.getSpeciesCode(),is(CROP_ABBREVIATION));
        assertThat(changeInfo.getProductKey(),is(productPubkey));
    }


}
