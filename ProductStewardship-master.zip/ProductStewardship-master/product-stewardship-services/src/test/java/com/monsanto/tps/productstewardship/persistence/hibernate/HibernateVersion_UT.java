package com.monsanto.tps.productstewardship.persistence.hibernate;

import org.hibernate.Version;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 15, 2011
 * Time: 11:19:18 AM
 * To change this template use File | Settings | File Templates.
 *   �
 */
public class HibernateVersion_UT {
    @Test
    public void testVersion(){
        assertThat(Version.getVersionString(),is("3.5.3-Final"));
    }
}
