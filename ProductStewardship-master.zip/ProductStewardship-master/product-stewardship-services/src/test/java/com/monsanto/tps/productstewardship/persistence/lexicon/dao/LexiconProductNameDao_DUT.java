package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CompetitiveProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductNameEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 11:01:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductNameDao_DUT extends HibernateTestCase {
    @Resource
    private LexiconProductNameDao lexiconProductNameDao;
        @Test
    public void testMapping(){
        CompetitiveProductEntity competitiveProduct = TestDataBuilder.buildCompetitiveProduct(currentSession);
        LexiconProductNameEntity productName = new LexiconProductNameEntity();
        productName.setActive(true);
        productName.setCompetitiveProduct(competitiveProduct);
        productName.setLexiconBrand(TestDataBuilder.buildLexiconBrand(currentSession));
        productName.setLexiconCountry(TestDataBuilder.buildCountry(currentSession));
        productName.setLogicalDelete(true);
        productName.setName(TestDataBuilder.generateRandomNumberString(50));
        productName.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        productName.setFbsCommonProductNameXref(TestDataBuilder.buildFbsCommonProductNameXref(currentSession, productName.getPubkey()));
        competitiveProduct.getLexiconProductNames().add(productName);

        saveFlushAndClear(productName);
        LexiconProductNameEntity productNameRead = lexiconProductNameDao.getByPubkey(productName.getPubkey());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(productName, productNameRead);

    }
    
}
