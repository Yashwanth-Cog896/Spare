package com.monsanto.tps.productstewardship;

import org.junit.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ClassUtils;

import java.beans.PropertyDescriptor;
import java.io.File;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@SuppressWarnings({"ResultOfMethodCallIgnored", "ObjectEqualsNull"})
public abstract class AbstractBeansTest {
    @Test
    public void coverBeans() {
        coverDirectory(new File(getDirectoryToCover()), "");
    }

    private String getDirectoryToCover() {
        return getWorkingDirForTest() +
                File.separator +
                "src" +
                File.separator +
                "main" +
                File.separator +
                "java" +
                File.separator +
                getPackageToCover().replace('.', File.separatorChar);
    }

    private void coverDirectory(File directory, String resourcePath) {
        File[] files = directory.listFiles();
        for (File file : files) {
            String fileName = file.getName();
            if (file.isDirectory()) {
                coverDirectory(file, resourcePath + fileName + File.separator);
            } else {
                coverFile(resourcePath, fileName);
            }
        }
    }

    private void coverFile(String resourcePath, String fileName) {
        if (isJavaFile(fileName)) {
            coverClass(resourcePath, fileName);
        }
    }

    private void coverClass(String resourcePath, String fileName) {
        try {
            Class clazz = getClass(resourcePath, fileName);
            if (!clazz.isInterface()) {
                coverNonInterface(clazz);
            }
        } catch (Exception e) {/* do nothing */}
    }

    private void coverNonInterface(Class clazz) {
        if (clazz.isEnum()) {
            clazz.getEnumConstants();
        } else {
            coverProperties(clazz);
        }
    }

    private void coverProperties(Class clazz) {
        PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(clazz);
        Object object = BeanUtils.instantiateClass(clazz);
        object.equals(object);
        object.equals(null);
        object.equals("");
        object.equals(BeanUtils.instantiateClass(clazz));
        try {
            object.hashCode();
        } catch (Exception e) {/* do nothing */}
        for (PropertyDescriptor descriptor : descriptors) {
            coverProperty(object, descriptor);
        }
    }

    private void coverProperty(Object object, PropertyDescriptor descriptor) {
        Object result = null;
        try {
            result = descriptor.getReadMethod().invoke(object);
        } catch (Exception e) {/* do nothing */}
        try {
            descriptor.getWriteMethod().invoke(object, result);
        } catch (Exception e) {/* do nothing */}
    }

    private Class getClass(String resourcePath, String fileName) throws ClassNotFoundException {
        String className = ClassUtils.convertResourcePathToClassName(resourcePath + fileName.replaceAll("\\.java", ""));
        return ClassUtils.forName(getPackageToCover() + "." + className);
    }

    private boolean isJavaFile(String fileName) {
        return !fileName.contains("svn") && fileName.contains(".java");
    }

    private String getWorkingDirForTest() {
        String currentDir = System.getProperty("user.dir");
        int projectBaseDirectoryIndex = currentDir.indexOf(getProjectDirectoryName());
        if (projectBaseDirectoryIndex == -1) {
            if (currentDir.endsWith(File.separator)) {
                return currentDir + getProjectDirectoryName();
            } else {
                return currentDir + File.separator + getProjectDirectoryName();
            }
        }
        int index = projectBaseDirectoryIndex + getProjectDirectoryName().length();
        if (currentDir.indexOf(File.separator, index) > 0) {
            index = currentDir.indexOf(File.separator, index);
        }
        return currentDir.substring(0, index);
    }

    protected abstract String getPackageToCover();

    protected abstract String getProjectDirectoryName();
}
