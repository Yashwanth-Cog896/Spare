package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipInfo;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipSchemaConstants;
import com.monsanto.sap.rowcrop.webservice.relationship.SapRelationshipSerializer;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.util.xml.DocumentValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.w3c.dom.Document;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SapRelationshipSerializer_UT{

  @Test
   public void testConformsToSchema()throws Exception {
      ProductRelationshipEntity relationship = new ProductRelationshipEntity();
    LexiconCropEntity crop = new LexiconCropEntity();
    crop.setPubkey("432");
    BaseProductEntity baseProduct = new BaseProductEntity();
    baseProduct.setBaseManufacturingName("BASE NAME");
    baseProduct.setLexiconCrop(crop);
    relationship.setId(123L);
    relationship.setBaseProduct(baseProduct);
    relationship.setLogicalDelete(false);
    relationship.setManufacturingName("MANF NAME");
    relationship.setProductRelationshipPubkey("12313");

    SapRelationshipInfo sapRelationshipInfo = new SapRelationshipInfo(relationship, relationship.getId());

      SapRelationshipSerializer serializer = new SapRelationshipSerializer();
      Document doc = serializer.toDocument(sapRelationshipInfo);

      assertTrue(DocumentValidator.isDocumentValid(doc, SapRelationshipSchemaConstants.SCHEMA_LOC));
   }
}