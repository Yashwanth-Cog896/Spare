package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ExceptionCodeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.hamcrest.CoreMatchers;
import org.junit.Test;
import static org.junit.Assert.*;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 10:21:28 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExceptionCodeDao_DUT extends HibernateTestCase {

    @Resource
    private ExceptionCodeDao exceptionCodeDao;
    @Test
    public void testMapping(){
        ExceptionCodeEntity exceptionCode = new ExceptionCodeEntity();
        exceptionCode.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        exceptionCode.setPrimary(false);
        exceptionCode.setExceptionCode(TestDataBuilder.generateRandomNumberString(20));
        exceptionCode.setProductName(TestDataBuilder.generateRandomNumberString(40));

        saveFlushAndClear(exceptionCode);

        ExceptionCodeEntity exceptionCodeRead = exceptionCodeDao.get(exceptionCode.getId());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(exceptionCode, exceptionCodeRead);
    }
    @Test
    public void testGetPubkey(){
        String codePubkey = exceptionCodeDao.getNextExceptionCode();
        System.out.println(codePubkey);
        assertThat(codePubkey, CoreMatchers.<Object>notNullValue());
    }
    @Test
    public void testGetByProductName(){
        ExceptionCodeEntity exceptionCode = new ExceptionCodeEntity();
        exceptionCode.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, false));
        exceptionCode.setPrimary(false);
        exceptionCode.setExceptionCode(TestDataBuilder.generateRandomNumberString(20));
        exceptionCode.setProductName(TestDataBuilder.generateRandomNumberString(40));

        saveFlushAndClear(exceptionCode);

        ExceptionCodeEntity exceptionCodeRead = exceptionCodeDao.getByProductName(exceptionCode.getProductName(),exceptionCode.getLexiconCrop().getId());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(exceptionCode, exceptionCodeRead);
    }

}
