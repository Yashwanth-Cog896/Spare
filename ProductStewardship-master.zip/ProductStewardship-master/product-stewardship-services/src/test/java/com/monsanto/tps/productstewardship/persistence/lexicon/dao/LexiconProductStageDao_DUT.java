package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconStageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductSubscriptionEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.productsearch.service.LexiconProductSearchCriteria;
import com.monsanto.tps.productstewardship.productsearch.service.NameType;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 15, 2011
 * Time: 9:09:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductStageDao_DUT extends HibernateTestCase{
    @Resource
    LexiconProductStageDao lexiconProductStageDao;
    @Resource
    private LexiconTempSessionOcdDao lexiconTempSessionOcdDao;
    @Test
    public void testGetByPubkey(){
        LexiconProductEntity product = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity productStage = TestDataBuilder.buildAndAddProductStage(currentSession, product, false);
        currentSession.flush();
        currentSession.clear();
        LexiconProductStageEntity productStageRead = lexiconProductStageDao.getByPubkey(productStage.getPubkey());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(productStage, productStageRead);
    }
    @Test
    public void testGetNextPubkey(){
        String nextPubkey = lexiconProductStageDao.getNextPubkey();
        assertThat(StringUtils.isNotBlank(nextPubkey),is(true));
    }
    @Test
    public void testFindBySearchCriteriaPreCommercialName(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria,200,0);

         assertThat(productStages.size(),is(1));
         HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(stage,productStages.get(0));
    }
    @Test

    public void testFindByMatchingProductNamesNullCommercialName(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         stage.setCommercialName(null);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByMatchingProductNames(lexiconProduct.getPreCommercialName().toLowerCase(),lexiconProduct.getLexiconCrop().getName());

         assertThat(productStages.size(),is(1));
         HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(stage,productStages.get(0));
    }
    @Test

    public void testFindByMatchingProductNamesNonNullCommercialName(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);


         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByMatchingProductNames(stage.getCommercialName().toLowerCase(),lexiconProduct.getLexiconCrop().getName());

         assertThat(productStages.size(),is(1));
         HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(stage,productStages.get(0));
    }
    @Test
    public void testFindByMatchingCommercialNamesDifferentProductPubkey(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductEntity otherLexiconProduct = TestDataBuilder.buildLexiconProductEntity(currentSession,lexiconProduct.getLexiconCrop());
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByMatchingCommercialNames(stage.getCommercialName(),otherLexiconProduct.getPubkey());

         assertThat(productStages.size(),is(1));
         HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(stage,productStages.get(0));
    }
    @Test
     public void testFindByMatchingCommercialNamesDifferentProductPubkeyDifferentCrop(){

         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         LexiconProductEntity otherLexiconProduct = TestDataBuilder.buildLexiconProductEntity(currentSession);
          ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
          LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
          currentSession.flush();
          List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByMatchingCommercialNames(stage.getCommercialName(),otherLexiconProduct.getPubkey());
          assertThat(productStages.size(),is(0));
     }


    @Test
    public void testFindByMatchingCommercialNamesSampleProductPubkey(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByMatchingCommercialNames(stage.getCommercialName(),lexiconProduct.getPubkey());

         assertThat(productStages.size(),is(0));
    }
    @Test
    public void testFindBySimilarCommercialNamesSampleProductPubkey(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findBySimilarCommercialNames(stage.getCommercialName(),lexiconProduct.getPubkey());

         assertThat(productStages.size(),is(0));
    }
    @Test
    public void testFindBySimilarCommercialNamesSampleProductPubkeyWithSpecialCharacters(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);

         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
        stage.setCommercialName(stage.getCommercialName().substring(0,stage.getCommercialName().length()-1)+"&");
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findBySimilarCommercialNames(stage.getCommercialName().substring(0,stage.getCommercialName().length()-1)+"_",lexiconProduct.getPubkey());

         assertThat(productStages.size(),is(0));
    }
    @Test
    public void testFindByMatchingCommercialNamesDifferentProductPubkeyLogicallyDeleted(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         stage.setLogicalDelete(true);
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByMatchingCommercialNames(stage.getCommercialName(),"someotherpubkey");

         assertThat(productStages.size(),is(0));
    }
    @Test
    public void testFindByCommercialNameAndCrop(){

        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         stage.setLogicalDelete(false);
         currentSession.flush();
         List<LexiconProductStageEntity> productStages = lexiconProductStageDao.findByCommercialNameAndCrop(stage.getCommercialName(),lexiconProduct.getLexiconCrop().getId());

         assertThat(productStages.size(),is(1));
    }
    @Test
    public void testCountByCriteriaPreCommercialName(){

         LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
         ProductRelationshipXrefEntity relationshipXref = TestDataBuilder.buildAndAddProductRelationshipXref(currentSession,lexiconProduct);
         LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);
         LexiconProductSearchCriteria searchCriteria = new LexiconProductSearchCriteria();
         searchCriteria.setNameType(NameType.PRE_COMMERCIAL);
         searchCriteria.setProductNames(Arrays.asList(lexiconProduct.getPreCommercialName()));
         currentSession.flush();
         int count  = lexiconProductStageDao.countBySearchCriteria(Arrays.asList(lexiconProduct.getLexiconCrop().getPubkey()),searchCriteria);
         assertThat(count,is(1));
    }
    @Test
    public void testFindSubscribedProductStage_checkCrop(){
        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);

        LexiconProductEntity lexiconProduct1  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity stage1 = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct1,false);

        ProductSubscriptionEntity productSubscription = new ProductSubscriptionEntity();
        productSubscription.setId(Long.valueOf(TestDataBuilder.generateRandomNumberString(5)));
        productSubscription.setExternalSystemName(ProductSubscriptionEntity.SAP);
        productSubscription.setLexiconCrop(lexiconProduct1.getLexiconCrop());
        saveFlushAndClear(productSubscription);

        long requestId=452352L;
        lexiconTempSessionOcdDao.insertNumberValues(requestId, Arrays.asList(stage.getId(), stage1.getId()));

        List<LexiconProductStageEntity> result = lexiconProductStageDao.findSubscribedProductStage(requestId, ProductSubscriptionEntity.SAP);
        assertNotNull(result);
        assertEquals(stage1.getId(),result.get(0).getId());
    }

    @Test
    public void testFindSubscribedProductStage_checkStage(){
        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);

        LexiconProductEntity lexiconProduct1  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity stage1 = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct1,false);

        ProductSubscriptionEntity productSubscription = new ProductSubscriptionEntity();
        productSubscription.setId(Long.valueOf(TestDataBuilder.generateRandomNumberString(5)));
        productSubscription.setExternalSystemName(ProductSubscriptionEntity.SAP);
        productSubscription.setLexiconCrop(lexiconProduct.getLexiconCrop());
        productSubscription.setLexiconStage(stage1.getLexiconStage());

        ProductSubscriptionEntity productSubscription1 = new ProductSubscriptionEntity();
        productSubscription1.setId(Long.valueOf(TestDataBuilder.generateRandomNumberString(5)));
        productSubscription1.setExternalSystemName(ProductSubscriptionEntity.SAP);
        productSubscription1.setLexiconCrop(lexiconProduct1.getLexiconCrop());
        productSubscription1.setLexiconStage(stage1.getLexiconStage());
        saveFlushAndClear(productSubscription);
        saveFlushAndClear(productSubscription1);

        long requestId=452352L;
        lexiconTempSessionOcdDao.insertNumberValues(requestId, Arrays.asList(stage.getId(), stage1.getId()));

        List<LexiconProductStageEntity> result = lexiconProductStageDao.findSubscribedProductStage(requestId, ProductSubscriptionEntity.SAP);
        assertNotNull(result);
        assertEquals(stage1.getId(),result.get(0).getId());
    }

    @Test
    public void testFindSubscribedProductStage_checkCountry(){
        LexiconProductEntity lexiconProduct  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity stage = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct,false);

        LexiconProductEntity lexiconProduct1  = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductStageEntity stage1 = TestDataBuilder.buildAndAddProductStage(currentSession,lexiconProduct1,false);

        ProductSubscriptionEntity productSubscription = new ProductSubscriptionEntity();
        productSubscription.setId(Long.valueOf(TestDataBuilder.generateRandomNumberString(5)));
        productSubscription.setExternalSystemName(ProductSubscriptionEntity.SAP);
        productSubscription.setLexiconCrop(lexiconProduct.getLexiconCrop());
        productSubscription.setLexiconStage(stage.getLexiconStage());
        productSubscription.setLexiconCountry(stage1.getLexiconCountry());

        ProductSubscriptionEntity productSubscription1 = new ProductSubscriptionEntity();
        productSubscription1.setId(Long.valueOf(TestDataBuilder.generateRandomNumberString(5)));
        productSubscription1.setExternalSystemName(ProductSubscriptionEntity.SAP);
        productSubscription1.setLexiconCrop(lexiconProduct1.getLexiconCrop());
        productSubscription1.setLexiconStage(stage1.getLexiconStage());
        productSubscription1.setLexiconCountry(stage1.getLexiconCountry());
        saveFlushAndClear(productSubscription);
        saveFlushAndClear(productSubscription1);

        long requestId=452352L;
        lexiconTempSessionOcdDao.insertNumberValues(requestId, Arrays.asList(stage.getId(), stage1.getId()));

        List<LexiconProductStageEntity> result = lexiconProductStageDao.findSubscribedProductStage(requestId, ProductSubscriptionEntity.SAP);
        assertNotNull(result);
        assertEquals(stage1.getId(),result.get(0).getId());
    }
}
