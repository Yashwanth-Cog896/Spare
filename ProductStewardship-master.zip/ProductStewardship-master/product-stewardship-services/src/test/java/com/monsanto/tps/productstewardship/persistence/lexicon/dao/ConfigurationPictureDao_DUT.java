package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ConfigurationPictureEntity;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 28, 2011
 * Time: 4:30:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConfigurationPictureDao_DUT extends HibernateTestCase {
    @Resource
    ConfigurationPictureDao configurationPictureDao;
    @Test
    public void testPersistence(){
        ConfigurationPictureEntity configurationPicture = new ConfigurationPictureEntity();
        configurationPicture.setId(-55L);
        configurationPicture.setImageHeight(300L);
        configurationPicture.setImageWidth(200L);
        configurationPictureDao.saveOrUpdate(configurationPicture);
        currentSession.flush();
        currentSession.clear();
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(configurationPicture, configurationPictureDao.get(-55L));
    }
}
