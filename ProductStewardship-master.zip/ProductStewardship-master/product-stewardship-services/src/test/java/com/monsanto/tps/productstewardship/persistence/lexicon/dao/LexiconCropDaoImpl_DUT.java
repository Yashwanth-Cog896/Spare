/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

/* vvkalu - 6/30/11 */
public class LexiconCropDaoImpl_DUT extends HibernateTestCase {
    private static final String[] apolloCrops = {"bean",
                                                "broccoli",
                                                "cabbage",
                                                "carrot",
                                                "cauliflower",
                                                "chinese-cabbage",
                                                "corn",
                                                "cotton",
                                                "cucumber",
                                                "eggplant",
                                                "fennel",
                                                "gourd",
                                                "leek",
                                                "lettuce",
                                                "melon",
                                                "okra",
                                                "onion",
                                                "osr-canola",
                                                "pea",
                                                "pepper",
                                                "radish",
                                                "sorghum",
                                                "soybeans",
                                                "spinach",
                                                "squash",
                                                "sunflower",
                                                "sweet-corn",
                                                "tomato",
                                                "watermelon"
                                                };
    @Resource
    private LexiconCropDao lexiconCropDao;

    @Test
    public void testRetrieveUserCrops() throws Exception
    {
        for(String apolloCrop: apolloCrops){
             List<LexiconCropEntity> lexiconCropEntities = lexiconCropDao.retrieveUserCrops(Arrays.asList(apolloCrop));
             assertNotNull(lexiconCropEntities);
             assertEquals(1, lexiconCropEntities.size());
             assertThat(lexiconCropEntities.get(0).getName().toUpperCase().replaceAll(LexiconCropDaoImpl.NON_ALPHABETIC_CHARACTERS,""),is(apolloCrop.toUpperCase().replaceAll(LexiconCropDaoImpl.NON_ALPHABETIC_CHARACTERS,"")));
        }
    }

   @Test
    public void testRetrieveUserCropsMoreThanOne() throws Exception
    {

             List<LexiconCropEntity> lexiconCropEntities = lexiconCropDao.retrieveUserCrops(Arrays.asList(apolloCrops[4],apolloCrops[5]));
             assertNotNull(lexiconCropEntities);
             assertEquals(2, lexiconCropEntities.size());
    }
   @Test
    public void testRetrieveUserCropsZeroReturned() throws Exception
    {

             List<LexiconCropEntity> lexiconCropEntities = lexiconCropDao.retrieveUserCrops(new ArrayList<String>());
             assertNotNull(lexiconCropEntities);
             assertEquals(0, lexiconCropEntities.size());
    }
    @Test
    public void testFindByName() throws Exception
    {
        LexiconCropEntity cropEntity = TestDataBuilder.buildCrop(currentSession, false);
        currentSession.flush();
        currentSession.clear();
        LexiconCropEntity crop= lexiconCropDao.getByName(cropEntity.getName());
        assertNotNull(crop);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(cropEntity, crop);
    }
    /*@Test
    public void testRetrieveUserCrops_CaseDifference()
       throws Exception
    {
        LexiconCropEntity crop = new LexiconCropEntity();
        crop.setAbbreviation(TestDataBuilder.generateRandomNumberString(2));
        crop.setAutoGenerateTagVarietyName(true);
        crop.setComplianceShippingStatement(TestDataBuilder.generateRandomNumberString(255));
        crop.setMajorCrop(true);
        crop.setName("TestCrop");
        crop.setPubkey(TestDataBuilder.generateRandomNumberString(20));
        crop.setRegulatory(true);
        crop.setStageCategory((StageCategoryEntity)currentMirageSession.get(StageCategoryEntity.class,2L));
        currentMirageSession.save(crop);
        currentMirageSession.flush();
        currentMirageSession.clear();
        List<LexiconCropEntity> lexiconCropEntities = lexiconCropDao.retrieveUserCrops(Arrays.asList("TEstCroP"));
        assertNotNull(lexiconCropEntities);
        assertFalse(lexiconCropEntities.isEmpty());
        assertEquals(1, lexiconCropEntities.size());
        TestUtils.assertObjectPropertiesContainSameValues(crop, lexiconCropEntities.get(0));
    }*/
}