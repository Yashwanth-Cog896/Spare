package com.monsanto.tps.productstewardship.context;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: RLCASW
 * Date: May 20, 2011
 * Time: 1:18:45 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "/com/monsanto/tps/productstewardship/contexts/hibernate-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-datasource-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-transaction-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/application-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/services-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-external-services-context.xml"
} ,
loader=ExtendedGenericXmlContextLoader.class)
@Transactional(propagation = Propagation.REQUIRED,readOnly = true)
public class TestContextConfig_DUT {
    @Resource(name = "sessionFactory")
    SessionFactory sessionFactory;

    @Test
    public void testSessionFactoryInjected(){
        assertThat(sessionFactory, notNullValue());
    }
    
}
