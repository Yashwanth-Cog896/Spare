package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageAuditDao;
import com.monsanto.tps.productstewardship.persistence.mirage.dao.MirageSeedProductDao;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.swing.*;

import static org.mockito.Mockito.*;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 2:38:48 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class FbsCommonProductNameLogicalDeleteImpl_UT {
    @Mock
    FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao;
    @Mock
    MirageSeedProductDao mirageSeedProductDao;
    @Mock
    MirageAuditDao mirageAuditDao;

    @InjectMocks
    FbsCommonProductNameLogicalDeleteImpl fbsCommonProductNameLogicalDelete = new FbsCommonProductNameLogicalDeleteImpl();
    @Test
    public void testLogicalDelete(){
       String stagePubkey = "stagePubkey";
        MidasBrandEntity midasBrand = new MidasBrandEntity();
        midasBrand.setName("brandName");
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = buildFbsCommonProductNameXref(stagePubkey);
        MidasProductNameEntity midasProductName = new MidasProductNameEntity();
        midasProductName.setRefActive(true);
        MidasProductEntity midasProduct = new MidasProductEntity();
        midasProductName.setMidasProduct(midasProduct);
        midasProductName.setMidasBrand(midasBrand);
        midasProduct.setMidasProductNames(Arrays.asList(midasProductName));
        fbsCommonProductNameXref.setMidasProductName(midasProductName);
        long mirageSeedProductId = 543L;
        fbsCommonProductNameXref.setMirageSeedProduct(createMirageSeedProduct(mirageSeedProductId));
        MirageSeedProductEntity mirageSeedProduct = new MirageSeedProductEntity();
        mirageSeedProduct.setDisabledDate(null);
        mirageSeedProduct.setEnabled(true);
        fbsCommonProductNameXref.setMirageSeedProduct(mirageSeedProduct);
        when(mirageSeedProductDao.get(mirageSeedProductId)).thenReturn(mirageSeedProduct);


        fbsCommonProductNameLogicalDelete.logicalDelete(fbsCommonProductNameXref);

        assertThat(midasProductName.isRefActive(),is(false));
        verify(fbsCommonProductNameXrefDao,times(1)).delete(fbsCommonProductNameXref);
        assertThat(mirageSeedProduct.getDisabledDate(), notNullValue());
        assertThat(mirageSeedProduct.isEnabled(),is(false));
    }
    MirageSeedProductEntity createMirageSeedProduct(Long id){
        MirageSeedProductEntity product = new MirageSeedProductEntity();
        product.setId(id);
        return product;
    }
    @Test
    public void testLogicalDeleteMidasProductNameIsNull(){
       String stagePubkey = "stagePubkey";
        MidasBrandEntity midasBrand = new MidasBrandEntity();
        midasBrand.setName("brandName");
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = buildFbsCommonProductNameXref(stagePubkey);

        MidasProductEntity midasProduct = new MidasProductEntity();
        long mirageSeedProductId = 543L;

        fbsCommonProductNameXref.setMirageSeedProduct(createMirageSeedProduct(mirageSeedProductId));
        MirageSeedProductEntity mirageSeedProduct = new MirageSeedProductEntity();
        mirageSeedProduct.setDisabledDate(null);
        mirageSeedProduct.setEnabled(true);
        when(mirageSeedProductDao.get(mirageSeedProductId)).thenReturn(mirageSeedProduct);
        fbsCommonProductNameXref.setMirageSeedProduct(mirageSeedProduct);


        fbsCommonProductNameLogicalDelete.logicalDelete(fbsCommonProductNameXref);

        verify(fbsCommonProductNameXrefDao,times(1)).delete(fbsCommonProductNameXref);
        assertThat(mirageSeedProduct.getDisabledDate(), notNullValue());
        assertThat(mirageSeedProduct.isEnabled(),is(false));

    }
    @Test
    public void testLogicalDeleteMirageSeedProductIdIsNull(){
       String stagePubkey = "stagePubkey";
        MidasBrandEntity midasBrand = new MidasBrandEntity();
        midasBrand.setName("brandName");
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = buildFbsCommonProductNameXref(stagePubkey);
        MidasProductNameEntity midasProductName = new MidasProductNameEntity();
        midasProductName.setRefActive(true);
        MidasProductEntity midasProduct = new MidasProductEntity();
        midasProductName.setMidasProduct(midasProduct);
        midasProductName.setMidasBrand(midasBrand);
        midasProduct.setMidasProductNames(Arrays.asList(midasProductName));
        fbsCommonProductNameXref.setMidasProductName(midasProductName);

       
        fbsCommonProductNameXref.setMirageSeedProduct(null);

        fbsCommonProductNameLogicalDelete.logicalDelete(fbsCommonProductNameXref);

        assertThat(midasProductName.isRefActive(),is(false));
        verify(fbsCommonProductNameXrefDao,times(1)).delete(fbsCommonProductNameXref);
        verify(mirageSeedProductDao,never()).get(anyLong());
    }    
    private FbsCommonProductNameXrefEntity buildFbsCommonProductNameXref(String stagePubkey) {
        FbsCommonProductNameXrefEntity fbsCommonProductNameXref = new FbsCommonProductNameXrefEntity();
        fbsCommonProductNameXref.setLexiconPubkey(stagePubkey);
        Long mirageProductId = -33L;
        
        fbsCommonProductNameXref.setMirageSeedProduct(createMirageSeedProduct(mirageProductId));
        MidasProductNameEntity midasProductName = new MidasProductNameEntity();
        midasProductName.setRefActive(true);
        MidasProductEntity midasProduct = new MidasProductEntity();
        midasProduct.getMidasProductNames().add(midasProductName);
        midasProduct.setRefActive(true);
        midasProductName.setMidasProduct(midasProduct);
        fbsCommonProductNameXref.setMidasProductName(midasProductName);
        return fbsCommonProductNameXref;
    }    

}
