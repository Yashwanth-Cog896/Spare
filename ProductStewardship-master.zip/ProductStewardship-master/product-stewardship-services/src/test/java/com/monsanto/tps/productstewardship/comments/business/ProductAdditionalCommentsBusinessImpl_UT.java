package com.monsanto.tps.productstewardship.comments.business;
import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalComments;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import static org.mockito.Mockito.*;
import java.util.List;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 5, 2011
 * Time: 3:33:13 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductAdditionalCommentsBusinessImpl_UT {
    @Mock
    private LexiconProductDao lexiconProductDao;
    @Mock
    private UserPrivilegesService userPrivilegesService;
    @Mock
    private UserProfile userProfile;
    @InjectMocks
    private ProductAdditionalCommentsBusinessImpl business = new ProductAdditionalCommentsBusinessImpl();
    @Test
    public void testCallsDao(){
        List<String> productNames = Arrays.asList("productName");
        List<String> crops = Arrays.asList("crop");
        when(userProfile.getUserName()).thenReturn("userName");
        when(userPrivilegesService.getCrops("userName")).thenReturn(crops);
        when(lexiconProductDao.findByAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL, crops)).thenReturn(new ArrayList<LexiconProductEntity>());
        List<ProductAdditionalCommentsSearchResult> productAdditionalComments = business.findProductAdditionalComments(productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops);
        verify(lexiconProductDao,times(1)).findByAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops);
        assertThat(productAdditionalComments.size(),is(0));
    }
    @Test
    public void testCallsDaoForPagedQuery(){
        List<String> productNames = Arrays.asList("productName");
        List<String> crops = Arrays.asList("crop");
        when(userProfile.getUserName()).thenReturn("userName");
        when(userPrivilegesService.getCrops("userName")).thenReturn(crops);
        when(lexiconProductDao.findPagedByAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL, crops,10,1)).thenReturn(new ArrayList<LexiconProductEntity>());
        List<ProductAdditionalCommentsSearchResult> productAdditionalComments = business.findPagedProductAdditionalComments(productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops,10,1);
        verify(lexiconProductDao,times(1)).findPagedByAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops,10,1);
        assertThat(productAdditionalComments.size(),is(0));
    }

    @Test
    public void testCallsDaoForCount(){
        List<String> productNames = Arrays.asList("productName");
        List<String> crops = Arrays.asList("crop");
        when(userProfile.getUserName()).thenReturn("userName");
        when(userPrivilegesService.getCrops("userName")).thenReturn(crops);
        when(lexiconProductDao.countAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL, crops)).thenReturn(25L);
        Long count = business.countProductAdditionalComments(productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops);
        verify(lexiconProductDao,times(1)).countAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops);
        assertThat(count,is(25L));
    }
    @Test
    public void testConvertsValuesDao(){
        List<String> productNames = Arrays.asList("productName");
        List<String> crops = Arrays.asList("crop");
        LexiconProductEntity product = new LexiconProductEntity();
        product.setPubkey("pubkey");
        product.setAdditionalComments("additionalComments");
        product.setTagVarietyName("varietyName");
        product.setPreCommercialName("preCommercialName");
        LexiconCropEntity lexiconCropEntity = new LexiconCropEntity();
        lexiconCropEntity.setName("cropName");
        product.setLexiconCrop(lexiconCropEntity);
        when(userProfile.getUserName()).thenReturn("userName");
        when(userPrivilegesService.getCrops("userName")).thenReturn(crops);
        when(lexiconProductDao.findByAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops)).thenReturn(Arrays.asList(product));
        List<ProductAdditionalCommentsSearchResult> productAdditionalComments = business.findProductAdditionalComments(productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops);
        verify(lexiconProductDao,times(1)).findByAdditionalCommentsCriteria(crops,productNames, ProductAdditionalCommentsNameType.PRE_COMMERCIAL,crops);
        assertThat(productAdditionalComments.size(),is(1));
        ProductAdditionalCommentsSearchResult pac = productAdditionalComments.get(0);
        assertThat(pac.getPreCommercialName(),is(product.getPreCommercialName()));
        assertThat(pac.getProductPubkey(),is(product.getPubkey()));
        assertThat(pac.getVarietyName(),is(product.getTagVarietyName()));
        assertThat(pac.getAdditionalComments(),is(product.getAdditionalComments()));
        assertThat(pac.getCrop(),is(lexiconCropEntity.getName()));
    }

    @Test
    public void testSaveProductAdditionalComments(){
        LexiconProductEntity product = new LexiconProductEntity();
        ProductAdditionalComments pac = new ProductAdditionalComments();
        String pubkey = "pubkey";
        pac.setProductPubkey(pubkey);
        String additionalComments = "additionalComments";
        pac.setAdditionalComments(additionalComments);
        when(lexiconProductDao.getByPubkey(pubkey)).thenReturn(product);
        business.saveProductAdditionalComments(Arrays.asList(pac));
        assertThat(product.getAdditionalComments(),is(additionalComments));
    }
}
