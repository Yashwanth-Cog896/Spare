package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconBrandEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

public class LexiconBrandDao_DUT  extends HibernateTestCase {
    @Resource
    private LexiconBrandDao lexiconBrandDao;

    @Test
    public void  testGetByName(){
        LexiconBrandEntity lexiconBrand = TestDataBuilder.buildLexiconBrand(currentSession);
        flushAndClearSession();
        LexiconBrandEntity foundBrand = lexiconBrandDao.getByName(lexiconBrand.getName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(lexiconBrand, foundBrand);
    }

}
