/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconTempSessionOcdDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/* vvkalu - 7/18/11 */
public class ManfNameSearchBuilder_UT {

    private ManfNameSearchBuilder manfNameSearchBuilder;
    private static final long REQUEST_ID = 15072011L;
    private BaseProductDao baseProductDao;

    @Before
    public void setUp() {
        LexiconTempSessionOcdDao lexiconTempSessionOcdDao = mock(LexiconTempSessionOcdDao.class);
        baseProductDao = mock(BaseProductDao.class);
        manfNameSearchBuilder = new ManfNameSearchBuilder();
        manfNameSearchBuilder.setBaseProductSearchResultTransformer(new BaseProductSearchResultTransformer());
        manfNameSearchBuilder.setLexiconTempSessionOcdDao(lexiconTempSessionOcdDao);
        manfNameSearchBuilder.setBaseProductDao(baseProductDao);
    }

    @Test
    public void test_findBaseProducts_Empty() throws Exception {
        when(baseProductDao.findBaseProductsByManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).thenReturn(null);
        List<BaseProduct> baseProducts = manfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertTrue(baseProducts.isEmpty());
    }
    @Test
    public void test_FindBaseProducts_When_RelationshipHasOneBaseProductEntity()throws Exception {
        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setId(7467647L);
        relationshipEntity.setManufacturingName("MANFNME");
        BaseProductEntity baseProductEntity = new BaseProductEntity();
        baseProductEntity.setId(37457L);
        baseProductEntity.setBaseManufacturingName("BMANFNAME");
        baseProductEntity.setParentProduct(false);
        baseProductEntity.setLexiconCrop(new LexiconCropEntity());
        relationshipEntity.setBaseProduct(baseProductEntity);
        baseProductEntity.setProductRelationships(Arrays.asList(relationshipEntity));
        when(baseProductDao.findBaseProductsByManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).thenReturn(Arrays.asList(baseProductEntity));
        List<BaseProduct> baseProducts = manfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertEquals(1, baseProducts.size());
        assertEquals("MANFNME", baseProducts.get(0).getProductRelationships().get(0).getManufacturingName());
        assertEquals("BMANFNAME", baseProducts.get(0).getBaseManufacturingName());
    }
    @Test
    public void test_FindBaseProducts_When_SameRelationshipsHaveOneBaseProductEntity()throws Exception {
        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setId(867785L);
        relationshipEntity.setManufacturingName("MANFNME");
        ProductRelationshipEntity relationshipEntity1 = new ProductRelationshipEntity();
        relationshipEntity1.setId(7467647L);
        relationshipEntity1.setManufacturingName("MANFNME1");
        BaseProductEntity baseProductEntity = new BaseProductEntity();
        baseProductEntity.setId(37457L);
        baseProductEntity.setBaseManufacturingName("BMANFNAME");
        baseProductEntity.setParentProduct(false);
        baseProductEntity.setLexiconCrop(new LexiconCropEntity());
        relationshipEntity.setBaseProduct(baseProductEntity);
        relationshipEntity1.setBaseProduct(baseProductEntity);
        baseProductEntity.setProductRelationships(Arrays.asList(relationshipEntity, relationshipEntity1));
        when(baseProductDao.findBaseProductsByManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).
            thenReturn(Arrays.asList(baseProductEntity));
        List<BaseProduct> baseProducts = manfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertEquals(1, baseProducts.size());
        BaseProduct baseProduct = baseProducts.get(0);
        assertEquals(2, baseProduct.getProductRelationships().size());
        assertEquals("MANFNME", baseProduct.getProductRelationships().get(0).getManufacturingName());
        assertEquals("BMANFNAME", baseProducts.get(0).getBaseManufacturingName());
    }
    @Test
    public void test_FindBaseProducts_When_MultipleRelationships()throws Exception {
        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setId(867785L);
        relationshipEntity.setManufacturingName("MANFNME");
        ProductRelationshipEntity relationshipEntity1 = new ProductRelationshipEntity();
        relationshipEntity1.setId(7467647L);
        relationshipEntity1.setManufacturingName("MANFNME1");
        BaseProductEntity baseProductEntity = new BaseProductEntity();
        baseProductEntity.setId(37457L);
        baseProductEntity.setBaseManufacturingName("BMANFNAME");
        baseProductEntity.setParentProduct(false);
        baseProductEntity.setLexiconCrop(new LexiconCropEntity());
        relationshipEntity1.setBaseProduct(baseProductEntity);
        relationshipEntity.setBaseProduct(baseProductEntity);
        baseProductEntity.setProductRelationships(Arrays.asList(relationshipEntity, relationshipEntity1));

        ProductRelationshipEntity relationshipEntity2 = new ProductRelationshipEntity();
        relationshipEntity2.setId(9758785L);
        relationshipEntity2.setManufacturingName("MANFNME1");
        BaseProductEntity baseProductEntity1 = new BaseProductEntity();
        baseProductEntity1.setId(7687854L);
        baseProductEntity1.setBaseManufacturingName("BMANFNAME1");
        baseProductEntity1.setParentProduct(false);
        baseProductEntity1.setLexiconCrop(new LexiconCropEntity());
        relationshipEntity2.setBaseProduct(baseProductEntity1);
        baseProductEntity1.setProductRelationships(Arrays.asList(relationshipEntity2));

        when(baseProductDao.findBaseProductsByManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).
            thenReturn(Arrays.asList(baseProductEntity, baseProductEntity1));
        List<BaseProduct> baseProducts = manfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertEquals(2, baseProducts.size());
    }

}