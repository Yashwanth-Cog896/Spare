package com.monsanto.tps.productstewardship.logicaldelete.service.impl;

import com.monsanto.tps.productstewardship.logicaldelete.business.ProductNameLogicalDelete;
import com.monsanto.tps.productstewardship.logicaldelete.business.ProductStageLogicalDelete;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.List;
import java.util.Arrays;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 4:54:22 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class LogicalDeleteServiceImpl_UT {
    @Mock
    private ProductStageLogicalDelete productStageLogicalDelete;
    @Mock
    private ProductNameLogicalDelete productNameLogicalDelete;

    @InjectMocks
    private LogicalDeleteServiceImpl  logicalDeleteService = new LogicalDeleteServiceImpl();

    @Test
    public void testDelegates(){
        List pubkeys =  Arrays.asList("pubkey1");
        logicalDeleteService.logicalDeleteStageAndName(pubkeys,"requestor","auditComment");

        verify(productNameLogicalDelete,times(1)).logicallyDeleteProductNames(pubkeys);
        verify(productStageLogicalDelete,times(1)).logicallyDeleteProductStages(pubkeys);
        
    }

}
