package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AutoNameVarietyCodeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductTypeEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import org.junit.Assert;
import org.junit.Test;

import javax.annotation.Resource;

public class AutoNameVarietyCodeDao_UT extends HibernateTestCase {

  @Resource
  private AutoNameVarietyCodeDao autoNameVarietyCodeDao;

  @Test
  public void testGetAutoNameVarietyCode(){

    AutoNameVarietyCodeEntity newAutoNameVarietyCode = TestDataBuilder.buildAutoNameVarietyCodeEntity(currentSession, "CC") ;


    AutoNameVarietyCodeEntity ret = autoNameVarietyCodeDao.getAutoNameVarietyCode(newAutoNameVarietyCode.getProductType().getId(),
                                                                                  newAutoNameVarietyCode.getMaterialGroup().getId(),
                                                                                  newAutoNameVarietyCode.getMaterialPricingGroup().getId());
    Assert.assertEquals(newAutoNameVarietyCode.getId(), ret.getId());

  }
}
