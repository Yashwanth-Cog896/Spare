package com.monsanto.tps.productstewardship.comments.service.impl;
import com.monsanto.tps.productstewardship.comments.business.ProductAdditionalCommentsBusiness;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalComments;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import static org.mockito.Mockito.*;
import java.util.List;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 5, 2011
 * Time: 4:12:14 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductAdditionalCommentsServiceImpl_UT {
    @Mock
    ProductAdditionalCommentsBusiness productBusiness;
    @InjectMocks
    ProductAdditionalCommentsServiceImpl productService = new ProductAdditionalCommentsServiceImpl();

    @Test
    public void testDelegatesFindProductAdditionalComments(){
        List<ProductAdditionalCommentsSearchResult> commentses = new ArrayList<ProductAdditionalCommentsSearchResult>();
        when(productBusiness.findProductAdditionalComments(anyList(), Matchers.any(ProductAdditionalCommentsNameType.class),anyList())).thenReturn(commentses);
        String productName = "productName";
        ProductAdditionalCommentsNameType commentsNameType = ProductAdditionalCommentsNameType.VARIETY;
        String crop = "crop";
        List<String> productNames = Arrays.asList(productName);
        List<String> crops = Arrays.asList(crop);
        List<ProductAdditionalCommentsSearchResult> returnedCommentses = productBusiness.findProductAdditionalComments(productNames, commentsNameType, crops);
        assertThat(returnedCommentses,sameInstance(commentses));
        verify(productBusiness,times(1)).findProductAdditionalComments(productNames,commentsNameType,crops);
    }
    @Test
    public void testDelegatesSaveProductAdditionalComments(){
        List<ProductAdditionalComments> pacs = new ArrayList<ProductAdditionalComments>();
        productService.saveProductAdditionalComments(pacs);
        ArgumentCaptor<List> pacsCaptor = ArgumentCaptor.forClass(List.class);
        verify(productBusiness,times(1)).saveProductAdditionalComments(pacsCaptor.capture());
        assertThat(pacsCaptor.getValue(),sameInstance((List)pacs));
    }
    @Test
    public void testCountProductAdditionalComments(){
        when(productBusiness.countProductAdditionalComments(anyList(), Matchers.any(ProductAdditionalCommentsNameType.class),anyList())).thenReturn(26L);
        String productName = "productName";
        ProductAdditionalCommentsNameType commentsNameType = ProductAdditionalCommentsNameType.VARIETY;
        String crop = "crop";
        List<String> productNames = Arrays.asList(productName);
        List<String> crops = Arrays.asList(crop);
        Long count = productBusiness.countProductAdditionalComments(productNames, commentsNameType, crops);
        assertThat(count,is(26L));
        verify(productBusiness,times(1)).countProductAdditionalComments(productNames,commentsNameType,crops);
    }
    @Test
    public void testDelegatesFindPagedProductAdditionalComments(){
        List<ProductAdditionalCommentsSearchResult> commentses = new ArrayList<ProductAdditionalCommentsSearchResult>();
        when(productBusiness.findPagedProductAdditionalComments(anyList(), Matchers.any(ProductAdditionalCommentsNameType.class),anyList(),anyInt(),anyInt())).thenReturn(commentses);
        String productName = "productName";
        ProductAdditionalCommentsNameType commentsNameType = ProductAdditionalCommentsNameType.VARIETY;
        String crop = "crop";
        List<String> productNames = Arrays.asList(productName);
        List<String> crops = Arrays.asList(crop);
        List<ProductAdditionalCommentsSearchResult> returnedCommentses = productBusiness.findPagedProductAdditionalComments(productNames, commentsNameType, crops,10,1);
        assertThat(returnedCommentses,sameInstance(commentses));
        verify(productBusiness,times(1)).findPagedProductAdditionalComments(productNames,commentsNameType,crops,10,1);
    }
}
