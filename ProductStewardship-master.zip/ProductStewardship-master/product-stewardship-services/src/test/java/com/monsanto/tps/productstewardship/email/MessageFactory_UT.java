package com.monsanto.tps.productstewardship.email;


import junit.framework.TestCase;

import javax.mail.Message;

/**
 * User: pjberry
 * Date: Sep 27, 2007
 * Time: 4:24:30 PM
 */
public class MessageFactory_UT
   extends TestCase
{
   public void testBuildMessage_SingleRecipient()
      throws Exception
   {
      MessageFactory messageFactory = new MessageFactory();

      Message message = messageFactory.buildMessage(new String[] {"recipientAddress"}, "senderAddress", "subject", "body");

      assertEquals(1, message.getRecipients(Message.RecipientType.TO).length);
      assertEquals("recipientAddress", message.getRecipients(Message.RecipientType.TO)[0].toString());

      assertEquals("senderAddress", message.getFrom()[0].toString());
      assertEquals("subject", message.getSubject());
      assertEquals("body", message.getContent().toString());
      assertEquals(MessageFactory.TEXT_PLAIN_CONTENT_TYPE, message.getContentType());
   }

   public void testBuildMessage_MultipleRecipients()
      throws Exception
   {
      MessageFactory messageFactory = new MessageFactory();

      Message message = messageFactory.buildMessage(new String[] {"recipientAddressOne", "recipientAddressTwo"}, "senderAddress", "subject", "body");

      assertEquals(2, message.getRecipients(Message.RecipientType.TO).length);
      assertEquals("recipientAddressOne", message.getRecipients(Message.RecipientType.TO)[0].toString());
      assertEquals("recipientAddressTwo", message.getRecipients(Message.RecipientType.TO)[1].toString());

      assertEquals("senderAddress", message.getFrom()[0].toString());
      assertEquals("subject", message.getSubject());
      assertEquals("body", message.getContent().toString());
      assertEquals(MessageFactory.TEXT_PLAIN_CONTENT_TYPE, message.getContentType());
   }
}
