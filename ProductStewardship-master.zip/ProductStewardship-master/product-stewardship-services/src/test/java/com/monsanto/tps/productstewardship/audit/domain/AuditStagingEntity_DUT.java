package com.monsanto.tps.productstewardship.audit.domain;

import com.monsanto.tps.productstewardship.context.ExtendedGenericXmlContextLoader;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.AuditStagingEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 14, 2011
 * Time: 9:58:38 AM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "/com/monsanto/tps/productstewardship/contexts/hibernate-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-datasource-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-transaction-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/application-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/services-context.xml",
        "/com/monsanto/tps/productstewardship/contexts/test-external-services-context.xml"
},
loader= ExtendedGenericXmlContextLoader.class)
@Transactional(propagation = Propagation.REQUIRED)
public class AuditStagingEntity_DUT {

    @Resource(name = "sessionFactory")
    protected SessionFactory sessionFactory;
    
    @Test
    public void testPersistAuditStagingEntity(){
        AuditStagingEntity auditStaging = new AuditStagingEntity();
        auditStaging.setOracleSid(3456L);
        auditStaging.setProcessName("AuditStagingEntity_DUT");
        auditStaging.setAuditComment("AuditComment");
        auditStaging.setAuditRequestor("requestor");
        long currentTimeMillis = System.currentTimeMillis();
        Date creationTimestamp = new Date(currentTimeMillis-(currentTimeMillis%1000));
        auditStaging.setCreationTimestamp(creationTimestamp);
        auditStaging.setMachine("machine");
        auditStaging.setOsuser("osuser");
        auditStaging.setUserLoginId("ulogin");
        auditStaging.setUserPartyId(333L);

        Session session = sessionFactory.getCurrentSession();
        session.save(auditStaging);
        session.flush();
        session.clear();

        AuditStagingEntity fromDb = (AuditStagingEntity)session.load(AuditStagingEntity.class, 3456L);
        assertFalse(fromDb==auditStaging);
        assertThat(fromDb.getOracleSid(),is(auditStaging.getOracleSid()));
        assertThat(fromDb.getProcessName(),is(auditStaging.getProcessName()));
        assertThat(fromDb.getAuditComment(),is(auditStaging.getAuditComment()));
        assertThat(fromDb.getAuditRequestor(),is(auditStaging.getAuditRequestor()));
        assertThat(fromDb.getCreationTimestamp(),is(auditStaging.getCreationTimestamp()));
        assertThat(fromDb.getMachine(),is(auditStaging.getMachine()));
        assertThat(fromDb.getOsuser(),is(auditStaging.getOsuser()));
        assertThat(fromDb.getUserLoginId(),is(auditStaging.getUserLoginId()));
        assertThat(fromDb.getUserPartyId(),is(auditStaging.getUserPartyId()));
    }
}
