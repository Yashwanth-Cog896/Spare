package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductPictureEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;
import org.springframework.orm.hibernate3.HibernateObjectRetrievalFailureException;
import org.springframework.test.annotation.ExpectedException;

import javax.annotation.Resource;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 28, 2011
 * Time: 3:32:02 PM
 */
public class LexiconProductPictureDao_DUT extends HibernateTestCase {

    @Resource LexiconProductPictureDao lexiconProductPictureDao;
    @Test
    public void testGetByPubkey(){
        LexiconProductEntity product = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductPictureEntity picture = new LexiconProductPictureEntity();
        picture.setDisplayName(TestDataBuilder.generateRandomNumberString(2000));
        picture.setDocumentId(TestDataBuilder.generateRandomNumberString(128));
        product.getLexiconProductPictures().add(picture);

        saveFlushAndClear(product);
        List<LexiconProductPictureEntity> picturesRead = lexiconProductPictureDao.getByProductPubkey(product.getPubkey());
        assertThat(picturesRead.size(),is(1));
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(picture, picturesRead.get(0));
    }

    @Test
    @ExpectedException(HibernateObjectRetrievalFailureException.class)
    public void testDelete(){
        LexiconProductEntity product = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductPictureEntity picture = new LexiconProductPictureEntity();
        picture.setDisplayName(TestDataBuilder.generateRandomNumberString(2000));
        picture.setDocumentId(TestDataBuilder.generateRandomNumberString(128));
        product.getLexiconProductPictures().add(picture);

        saveFlushAndClear(product);
        lexiconProductPictureDao.delete(picture.getId());
        LexiconProductPictureEntity pictureRead = lexiconProductPictureDao.get(picture.getId());
    }

    @Test
    public void testGetByDisplayName(){
        LexiconProductEntity product = TestDataBuilder.buildLexiconProductEntity(currentSession);
        LexiconProductPictureEntity picture = new LexiconProductPictureEntity();
        picture.setDisplayName(TestDataBuilder.generateRandomNumberString(2000));
        picture.setDocumentId(TestDataBuilder.generateRandomNumberString(128));
        product.getLexiconProductPictures().add(picture);

        saveFlushAndClear(product);
        
        LexiconProductPictureEntity pictureRead = lexiconProductPictureDao.getByDisplayname(picture.getDisplayName());

        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(picture, pictureRead);
    }
}
