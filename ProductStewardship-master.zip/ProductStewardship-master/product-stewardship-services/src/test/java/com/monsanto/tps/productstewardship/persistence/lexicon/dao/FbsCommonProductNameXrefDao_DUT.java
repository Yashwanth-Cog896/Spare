package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.FbsCommonProductNameXrefDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.*;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductNameEntity;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 18, 2011
 * Time: 1:37:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class FbsCommonProductNameXrefDao_DUT extends HibernateTestCase{
    @Resource
    FbsCommonProductNameXrefDao fbsCommonProductNameXrefDao;
    @Test
    public void testGet(){
        CompetitiveProductEntity competitiveProduct = TestDataBuilder.buildCompetitiveProduct(currentSession);
        LexiconProductNameEntity lexiconProductName = TestDataBuilder.buildAndAddLexiconProductName(currentSession, competitiveProduct);
        MidasProductNameEntity midasProductName = TestDataBuilder.buildMidasProductName(currentSession);
        FbsCommonProductNameXrefEntity xref = new FbsCommonProductNameXrefEntity();
        xref.setLexiconPubkey(TestDataBuilder.generateRandomNumberString(20));
        lexiconProductName.setPubkey(xref.getLexiconPubkey());
        xref.setMidasProductName(midasProductName);
        xref.setMirageSeedProduct(null);
        saveFlushAndClear(xref);
        FbsCommonProductNameXrefEntity xrefRead = fbsCommonProductNameXrefDao.get(xref.getLexiconPubkey());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(xref,xrefRead);
    }
}
