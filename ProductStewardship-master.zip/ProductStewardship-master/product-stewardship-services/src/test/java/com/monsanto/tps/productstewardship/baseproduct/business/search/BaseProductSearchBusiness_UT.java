/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.productstewardship.baseproduct.business.search.BaseManfNameSearchBuilder;
import com.monsanto.tps.productstewardship.baseproduct.business.search.BaseProductSearchBusiness;
import com.monsanto.tps.productstewardship.baseproduct.business.search.ManfNamesSearchBuilderFactory;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.baseproduct.service.BaseProductSearchType;
import com.monsanto.tps.productstewardship.user.service.UserPrivilegesService;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/* vvkalu - 7/15/11 */
public class BaseProductSearchBusiness_UT {

    private BaseProductSearchBusiness baseProductSearchBusiness;
    private ManfNamesSearchBuilderFactory manfNamesSearchBuilderFactory;
    private UserProfile userProfile;
    private UserPrivilegesService userPrivilegesService;

    @Before
    public void setUp() {
        baseProductSearchBusiness = new BaseProductSearchBusiness();
        manfNamesSearchBuilderFactory = mock(ManfNamesSearchBuilderFactory.class);
        userProfile = mock(UserProfile.class);
        userPrivilegesService = mock(UserPrivilegesService.class);
        baseProductSearchBusiness.setManfNamesSearchBuilderFactory(manfNamesSearchBuilderFactory);
        baseProductSearchBusiness.setUserProfile(userProfile);
        baseProductSearchBusiness.setUserPrivilegesService(userPrivilegesService);
    }
    @Test
    public void test_findBaseProduct_Empty_Crops() throws Exception {
        when(userProfile.getUserName()).thenReturn("VVKALU");
        when(userPrivilegesService.getCrops("VVKALU")).thenReturn(new ArrayList<String>());
        List<BaseProduct> baseProducts = baseProductSearchBusiness.findBaseProducts(BaseProductSearchType.BASEMANUFACTURINGNAME,
            Arrays.asList("NM1"));
        assertNotNull(baseProducts);
        assertTrue(baseProducts.isEmpty());
    }
    @Test
    public void test_findBaseProduct_Empty_UserLoginId() throws Exception {
        when(userProfile.getUserName()).thenReturn(null);
        List<BaseProduct> baseProducts = baseProductSearchBusiness.findBaseProducts(BaseProductSearchType.BASEMANUFACTURINGNAME,
            Arrays.asList("NM1"));
        assertNotNull(baseProducts);
        assertTrue(baseProducts.isEmpty());
    }
    @Test
    public void test_findBaseProduct() throws Exception {
        when(userProfile.getUserName()).thenReturn("VVKALU");
        List<String> authorizedCropPubkeys = Arrays.asList("PK1", "PK2");
        List<String> baseManfNames = Arrays.asList("NM1");
        when(userPrivilegesService.getCrops("VVKALU")).thenReturn(authorizedCropPubkeys);
        BaseManfNameSearchBuilder baseManfNameSearchBuilder = mock(BaseManfNameSearchBuilder.class);
        when(manfNamesSearchBuilderFactory.getSearchCriteria(BaseProductSearchType.BASEMANUFACTURINGNAME)).thenReturn(baseManfNameSearchBuilder);
        when(baseManfNameSearchBuilder.findBaseProducts(authorizedCropPubkeys, baseManfNames)).thenReturn(Arrays.asList(new BaseProduct()));
        List<BaseProduct> baseProducts = baseProductSearchBusiness.findBaseProducts(BaseProductSearchType.BASEMANUFACTURINGNAME, baseManfNames);
        assertNotNull(baseProducts);
        assertEquals(1, baseProducts.size());
    }
}