package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.CommercialTraitStackEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;
import java.util.List;
import javax.annotation.Resource;

public class CommercialTraitStackDao_DUT extends HibernateTestCase {
    @Resource(name = "commercialTraitStackDao")
    CommercialTraitStackDao commercialTraitStackDao;

    @Test
    public void testGetByPubkey(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        CommercialTraitStackEntity stackRead = commercialTraitStackDao.getByPubkey(commercialTraitStack.getPubkey());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stackRead);
    }
    @Test
    public void testGetByTraitNameAndCrop(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        List<CommercialTraitStackEntity> stacksRead = commercialTraitStackDao.getByTraitNameAndCrop(commercialTraitStack.getAbbreviation(),commercialTraitStack.getLexiconCrop().getName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stacksRead.get(0));
    }
    @Test
    public void testGetByTraitNameAndCropReportingName(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        List<CommercialTraitStackEntity> stacksRead = commercialTraitStackDao.getByTraitNameAndCrop(commercialTraitStack.getReportingName(),commercialTraitStack.getLexiconCrop().getName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stacksRead.get(0));
    }
    @Test
    public void testGetByTraitNameAndCropAlternateReportingName(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        List<CommercialTraitStackEntity> stacksRead = commercialTraitStackDao.getByTraitNameAndCrop(commercialTraitStack.getAlternateNames().get(0).getReportingName(),commercialTraitStack.getLexiconCrop().getName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stacksRead.get(0));
    }

    @Test
    public void testGetByTraitName(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        List<CommercialTraitStackEntity> stacksRead = commercialTraitStackDao.getByTraitName(commercialTraitStack.getAbbreviation());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stacksRead.get(0));
    }
    @Test
    public void testGetByTraitNameReportingName(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        List<CommercialTraitStackEntity> stacksRead = commercialTraitStackDao.getByTraitName(commercialTraitStack.getReportingName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stacksRead.get(0));
    }
    @Test
    public void testGetByTraitNameAlternateReportingName(){
        CommercialTraitStackEntity commercialTraitStack = TestDataBuilder.buildCommercialTraitStack(currentSession,TestDataBuilder.buildCrop(currentSession,true));
        flushAndClearSession();
        List<CommercialTraitStackEntity> stacksRead = commercialTraitStackDao.getByTraitName(commercialTraitStack.getAlternateNames().get(0).getReportingName());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(commercialTraitStack, stacksRead.get(0));
    }

}
