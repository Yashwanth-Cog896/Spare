package com.monsanto.tps.productstewardship.email;


import junit.framework.TestCase;

/**
 * User: pjberry
 * Date: Sep 27, 2007
 * Time: 3:46:24 PM
 */
public class PostOffice_UT
   extends TestCase
{
   public void testSend()
      throws Exception
   {
      MockSimpleTransport transport = new MockSimpleTransport();

    PostOfficeImpl postOffice = new PostOfficeImpl();
     postOffice.setTransport(transport);
     postOffice.setMessageFactory(new MessageFactory());
     postOffice.send("recipientEmailAddress", "senderEmailAddress", "subject", "body");

      assertTrue(transport.wasSent());
   }

   public void testDefaultConstructorExists()
      throws Exception
   {
      new PostOfficeImpl();
   }
}
