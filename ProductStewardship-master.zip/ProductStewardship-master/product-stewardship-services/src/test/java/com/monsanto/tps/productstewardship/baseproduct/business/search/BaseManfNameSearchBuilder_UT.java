/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.baseproduct.business.search;

import com.monsanto.tps.productstewardship.baseproduct.service.BaseProduct;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.BaseProductDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconTempSessionOcdDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import org.junit.Before;
import org.junit.Test;


import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/* vvkalu - 7/15/11 */
public class BaseManfNameSearchBuilder_UT {

    private BaseManfNameSearchBuilder baseManfNameSearchBuilder;
    private static final long REQUEST_ID = 16072011L;
    private BaseProductDao baseProductDao;

    @Before
    public void setUp() {
        baseManfNameSearchBuilder = new BaseManfNameSearchBuilder();
        LexiconTempSessionOcdDao lexiconTempSessionOcdDao = mock(LexiconTempSessionOcdDao.class);
        baseProductDao = mock(BaseProductDao.class);
        baseManfNameSearchBuilder.setBaseProductDao(baseProductDao);
        baseManfNameSearchBuilder.setLexiconTempSessionOcdDao(lexiconTempSessionOcdDao);
        baseManfNameSearchBuilder.setBaseProductSearchResultTransformer(new BaseProductSearchResultTransformer());
    }

    @Test
    public void test_findBaseProducts_Empty() throws Exception {
        when(baseProductDao.findBaseProductsByBaseManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).thenReturn(null);
        List<BaseProduct> baseProducts = baseManfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertTrue(baseProducts.isEmpty());
    }
    @Test
    public void test_findBaseProducts_Only_BaseProduct() throws Exception {
        BaseProductEntity baseProductEntity = new BaseProductEntity();
        baseProductEntity.setBaseManufacturingName("BMN");
        baseProductEntity.setId(37457L);
        baseProductEntity.setParentProduct(false);
        baseProductEntity.setLexiconCrop(new LexiconCropEntity());
        when(baseProductDao.findBaseProductsByBaseManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).thenReturn(Arrays.asList(baseProductEntity));
        List<BaseProduct> baseProducts = baseManfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertFalse(baseProducts.isEmpty());
        assertEquals("BMN", baseProducts.get(0).getBaseManufacturingName());
        assertEquals(37457L, baseProducts.get(0).getBaseProductId().longValue());
        assertFalse(baseProducts.get(0).isParent());
    }
    @Test
    public void test_findBaseProducts_BaseProduct_WithNullRelationship() throws Exception {
        BaseProductEntity baseProductEntity = new BaseProductEntity();
        baseProductEntity.setBaseManufacturingName("BMN");
        baseProductEntity.setId(37457L);
        baseProductEntity.setParentProduct(false);
        baseProductEntity.setLexiconCrop(new LexiconCropEntity());
        when(baseProductDao.findBaseProductsByBaseManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).thenReturn(Arrays.asList(baseProductEntity));
        List<BaseProduct> baseProducts = baseManfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertFalse(baseProducts.isEmpty());
        assertEquals("BMN", baseProducts.get(0).getBaseManufacturingName());
        assertEquals(37457L, baseProducts.get(0).getBaseProductId().longValue());
        assertFalse(baseProducts.get(0).isParent());
    }
    @Test
    public void test_findBaseProducts_BaseProductWith_Relationships() throws Exception {
        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setId(746L);
        ProductRelationshipEntity relationshipEntity1 = new ProductRelationshipEntity();
        relationshipEntity1.setId(566L);
        BaseProductEntity baseProductEntity = new BaseProductEntity();
        baseProductEntity.setBaseManufacturingName("BMN");
        baseProductEntity.setId(37457L);
        baseProductEntity.setParentProduct(false);
        baseProductEntity.setLexiconCrop(new LexiconCropEntity());
        baseProductEntity.setProductRelationships(Arrays.asList(relationshipEntity, relationshipEntity1));
        when(baseProductDao.findBaseProductsByBaseManfName(REQUEST_ID, Arrays.asList("PKY1", "PKY2"))).thenReturn(Arrays.asList(baseProductEntity));
        List<BaseProduct> baseProducts = baseManfNameSearchBuilder.findBaseProducts(Arrays.asList("PKY1", "PKY2"), Arrays.asList("NME1", "NME2"));
        assertNotNull(baseProducts);
        assertFalse(baseProducts.isEmpty());
        assertEquals("BMN", baseProducts.get(0).getBaseManufacturingName());
        assertEquals(37457L, baseProducts.get(0).getBaseProductId().longValue());
        assertFalse(baseProducts.get(0).isParent());
        assertEquals(2, baseProducts.get(0).getProductRelationships().size());
    }
}