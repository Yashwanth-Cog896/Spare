package com.monsanto.tps.productstewardship.email;


import junit.framework.TestCase;

/**
 * User: pjberry
 * Date: Oct 2, 2007
 * Time: 10:56:38 AM
 */
public class ExceptionFormatter_UT
   extends TestCase
{
   private static final String newline = System.getProperty("line.separator");

   public void testFormatException_NoHtml()
      throws Exception
   {
      try {
         throw new RuntimeException("message");
      }
      catch (RuntimeException e){
         ExceptionFormatter formatter = new ExceptionFormatter();
         String exceptionMessage = formatter.format(e, false);

         assertTrue(exceptionMessage.contains("msg: message" + newline + "trace:" + newline + "java.lang.RuntimeException: message" + newline + "\tat"));
      }
   }

    public void testFormatException_Html()
      throws Exception
   {
      try {
         throw new RuntimeException("<b>message<b>");
      }
      catch (RuntimeException e){
         ExceptionFormatter formatter = new ExceptionFormatter();
         String exceptionMessage = formatter.format(e, true);

         assertTrue(exceptionMessage.contains("msg: &lt;b&gt;message&lt;b&gt;" + newline + "trace:" + newline + "java.lang.RuntimeException: &lt;b&gt;message&lt;b&gt;" + newline + "\tat"));
      }
   }
}
