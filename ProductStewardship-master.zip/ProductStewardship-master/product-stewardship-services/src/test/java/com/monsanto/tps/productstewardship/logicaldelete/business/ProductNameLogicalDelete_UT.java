package com.monsanto.tps.productstewardship.logicaldelete.business;

import com.monsanto.tps.productstewardship.persistence.lexicon.domain.FbsCommonProductNameXrefEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.dao.LexiconProductNameDao;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconProductNameEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.Arrays;
import static org.mockito.Mockito.*;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 19, 2011
 * Time: 3:16:25 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductNameLogicalDelete_UT {

    @Mock
    LexiconProductNameDao lexiconProductNameDao;
    @Mock
    FbsCommonProductNameLogicalDelete fbsCommonProductNameLogicalDelete;
    @InjectMocks
    ProductNameLogicalDeleteImpl productStageLogicalDelete = new ProductNameLogicalDeleteImpl();

    @Test
    public void testLogicallyDeleteProductNames(){
        LexiconProductNameEntity lexiconProductName = new LexiconProductNameEntity();
        lexiconProductName.setLogicalDelete(false);
        FbsCommonProductNameXrefEntity fbsCommonProductNameXrefEntity = new FbsCommonProductNameXrefEntity();
        lexiconProductName.setFbsCommonProductNameXref(fbsCommonProductNameXrefEntity);
        String namePubkey = "namePubkey";
        when(lexiconProductNameDao.getByPubkey(namePubkey)).thenReturn(lexiconProductName);
        productStageLogicalDelete.logicallyDeleteProductNames(Arrays.asList(namePubkey));
        assertThat(lexiconProductName.isLogicalDelete(),is(true));
        assertThat(lexiconProductName.getFbsCommonProductNameXref(), nullValue());
        verify(fbsCommonProductNameLogicalDelete,times(1)).logicalDelete(fbsCommonProductNameXrefEntity);
    }
}
