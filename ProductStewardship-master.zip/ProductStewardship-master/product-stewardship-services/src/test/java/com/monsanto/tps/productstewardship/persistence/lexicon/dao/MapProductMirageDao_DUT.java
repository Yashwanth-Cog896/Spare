package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.GeneticMaterialEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MapProductMirageEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.MidasProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.persistence.mirage.domain.MirageSeedProductEntity;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;

public class MapProductMirageDao_DUT  extends HibernateTestCase {
    @Resource
    MapProductMirageDao mapProductMirageDao;

    @Test
    public void testPersistence(){
        MidasProductEntity midasProduct = TestDataBuilder.buildMidasProduct(currentSession);
        MirageSeedProductEntity mirageSeedProduct = TestDataBuilder.buildMirageSeedProduct(currentSession);
        GeneticMaterialEntity geneticMaterial = TestDataBuilder.buildGeneticMaterialEntity(currentSession,TestDataBuilder.buildMidasCrop(currentSession));

        MapProductMirageEntity mapProductMirage = new MapProductMirageEntity();
        mapProductMirage.setMirageSeedProduct(mirageSeedProduct);
        mapProductMirage.setGeneticMaterial(geneticMaterial);
        mapProductMirage.setMidasProduct(midasProduct);
        mapProductMirage.setMirageName(TestDataBuilder.generateRandomNumberString(255));
        mapProductMirage.setOldBrandName(TestDataBuilder.generateRandomNumberString(80));
        mapProductMirageDao.saveOrUpdate(mapProductMirage);
        flushAndClearSession();
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(mapProductMirage, mapProductMirageDao.get(mirageSeedProduct.getId()));
    }
}
