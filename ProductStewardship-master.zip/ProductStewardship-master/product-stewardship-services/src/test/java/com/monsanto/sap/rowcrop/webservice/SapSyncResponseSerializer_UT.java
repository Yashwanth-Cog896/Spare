package com.monsanto.sap.rowcrop.webservice;

import com.monsanto.XMLUtil.DOMUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.w3c.dom.Document;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class SapSyncResponseSerializer_UT {
    private static final Integer ERROR_CODE = 0;

  @Test
   public void testSerialize() throws Exception {
      SapSyncResponse response =
         new SapSyncResponseImpl(123L, "update response", ERROR_CODE, "error message", "error detail");

      SapSyncResponseSerializer serializer = new SapSyncResponseSerializer();
      Document document = serializer.toDocument(response);

      assertNotNull(document);
   }

  @Test
   public void testDeserialize() throws Exception {
      String documentAsString =
         "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
         "<response sapLinkageAuditId=\"123\">\n" +
         "<updateResponse>update response</updateResponse>\n" +
         "<errorCode>0</errorCode>\n" +
         "<errorMessage>error message</errorMessage>\n" +
         "<errorDetail>error detail</errorDetail>\n" +
         "</response>";

      Document document = DOMUtil.newDocumentFromXML(documentAsString);
      SapSyncResponseSerializer serializer = new SapSyncResponseSerializer();
      SapSyncResponse response = serializer.fromDocument(document);

      assertEquals(new Long(123), response.getSapLinkageAuditId());
      assertEquals("update response", response.getUpdateResponse());
      assertEquals(new Integer(0), response.getErrorCode());
      assertEquals("error message", response.getErrorMessage());
      assertEquals("error detail", response.getErrorDetail());
   }
}
