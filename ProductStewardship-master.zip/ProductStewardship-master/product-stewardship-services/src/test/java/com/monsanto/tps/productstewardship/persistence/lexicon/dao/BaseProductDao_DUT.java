/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.persistence.lexicon.dao;

import com.monsanto.tps.productstewardship.context.HibernateTestCase;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.BaseProductEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.LexiconCropEntity;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.TestDataBuilder;
import com.monsanto.tps.productstewardship.persistence.lexicon.domain.ProductRelationshipEntity;
import com.monsanto.tps.productstewardship.util.HibernateAssertTestUtil;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.*;

/* vvkalu - 7/11/11 */
public class BaseProductDao_DUT extends HibernateTestCase{

    @Resource
    private BaseProductDao baseProductDao;
    @Resource
    private LexiconTempSessionOcdDao lexiconTempSessionOcdDao;

    @Test
    public void test_saveBaseProducts_Without_Relationships() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);

        BaseProductEntity baseProductEntity = baseProductDao.saveOrUpdate(baseProduct);

        assertNotNull(baseProductEntity);
        assertTrue(baseProductEntity.getProductRelationships().isEmpty());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(baseProduct, baseProductEntity);
    }

    @Test
    public void test_SaveBaseProduct_with_Relationship() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        relationshipEntity.setBaseProduct(baseProduct);
        relationshipEntity.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        relationshipEntity.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(20));
        baseProduct.setProductRelationships(Arrays.asList(relationshipEntity));

        BaseProductEntity baseProductEntity = baseProductDao.saveOrUpdate(baseProduct);

        assertNotNull(baseProductEntity);
        assertFalse(baseProductEntity.getProductRelationships().isEmpty());
        assertEquals(1, baseProductEntity.getProductRelationships().size());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(baseProduct, baseProductEntity);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(relationshipEntity, baseProductEntity.getProductRelationships().get(0));
    }

    @Test
    public void test_SaveBaseProduct_with_Edit_Relationship() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        relationshipEntity.setBaseProduct(baseProduct);
        relationshipEntity.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        relationshipEntity.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(20));
        baseProduct.setProductRelationships(Arrays.asList(relationshipEntity));

        BaseProductEntity baseProductEntity = baseProductDao.saveOrUpdate(baseProduct);

        assertNotNull(baseProductEntity);
        assertFalse(baseProductEntity.getProductRelationships().isEmpty());
        assertEquals(1, baseProductEntity.getProductRelationships().size());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(baseProduct, baseProductEntity);
        ProductRelationshipEntity relationshipEntity1 = baseProductEntity.getProductRelationships().get(0);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(relationshipEntity, relationshipEntity1);

        relationshipEntity1.setManufacturingName("TEST_MANF_DUT_EDIT");

        BaseProductEntity editedBaseProductRelationship = baseProductDao.saveOrUpdate(baseProductEntity);
        ProductRelationshipEntity editedRelationship = editedBaseProductRelationship.getProductRelationships().get(0);
        assertNotNull(editedRelationship);
        assertEquals("TEST_MANF_DUT_EDIT", editedRelationship.getManufacturingName());
    }

    @Test
    public void test_getBaseProducts_when_BaseManfName_Equals() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);
        baseProduct.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
        saveFlushAndClear(baseProduct);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("TEST_DUT_MANF"));

        List<BaseProductEntity> baseProducts = baseProductDao.findBaseProductsByBaseManfName(sessionId, Arrays.asList(lexiconCrop.getPubkey()));

        assertNotNull(baseProducts);
        assertEquals(1, baseProducts.size());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(baseProduct,baseProducts.get(0));
    }

    @Test
    public void test_getBaseProducts_with_Relationships() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        relationshipEntity.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity.setBaseProduct(baseProduct);
        relationshipEntity.setLogicalDelete(false);
        relationshipEntity.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct.setProductRelationships(Arrays.asList(relationshipEntity));

        saveFlushAndClear(baseProduct);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("TEST_DUT_MANF"));

        List<BaseProductEntity> baseProducts = baseProductDao.findBaseProductsByBaseManfName(sessionId, Arrays.asList(lexiconCrop.getPubkey()));

        assertNotNull(baseProducts);
        assertEquals(1, baseProducts.size());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(baseProduct, baseProducts.get(0));
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(relationshipEntity,baseProducts.get(0).getProductRelationships().get(0));
    }

    @Test
    public void test_getBaseProducts_when_BaseManfName_MultipleProducts() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);
        baseProduct.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
        currentSession.save(baseProduct);

        BaseProductEntity baseProduct1 = new BaseProductEntity();
        baseProduct1.setBaseManufacturingName("TEST_DUT");
        baseProduct1.setLexiconCrop(lexiconCrop);
        baseProduct1.setLogicalDelete(false);
        baseProduct1.setParentProduct(false);
        baseProduct1.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
        saveFlushAndClear(baseProduct1);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("%T%E%T%"));

        List<BaseProductEntity> baseProducts = baseProductDao.findBaseProductsByBaseManfName(sessionId, Arrays.asList(lexiconCrop.getPubkey()));

        assertNotNull(baseProducts);
        assertTrue(baseProducts.contains(baseProductDao.get(baseProduct.getId())));
        assertTrue(baseProducts.contains(baseProductDao.get(baseProduct1.getId())));
    }

    @Test
    public void test_getBaseProducts_when_BaseManfName_MultipleProducts_MultipleCrops() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName("TEST_DUT_MANF");
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);
        baseProduct.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
        currentSession.save(baseProduct);

        LexiconCropEntity lexiconCrop1 = TestDataBuilder.buildCrop(currentSession, false);
        BaseProductEntity baseProduct1 = new BaseProductEntity();
        baseProduct1.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct1.setBaseManufacturingName("TEST_DUT");
        baseProduct1.setLexiconCrop(lexiconCrop1);
        baseProduct1.setLogicalDelete(false);
        baseProduct1.setParentProduct(false);
        baseProduct1.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
        currentSession.save(baseProduct1);

        BaseProductEntity baseProduct2 = new BaseProductEntity();
        baseProduct2.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct2.setBaseManufacturingName("TEST_DUT_NOT_RETURNED");
        baseProduct2.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, true));
        baseProduct2.setLogicalDelete(false);
        baseProduct2.setParentProduct(false);
        baseProduct2.setProductRelationships(new ArrayList<ProductRelationshipEntity>());
        saveFlushAndClear(baseProduct2);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("%T%E%T%"));

        List<BaseProductEntity> baseProducts = baseProductDao.findBaseProductsByBaseManfName(sessionId,
                Arrays.asList(lexiconCrop.getPubkey(), lexiconCrop1.getPubkey()));

        assertNotNull(baseProducts);
        assertTrue(baseProducts.contains(baseProductDao.get(baseProduct.getId())));
        assertTrue(baseProducts.contains(baseProductDao.get(baseProduct1.getId())));
        assertFalse(baseProducts.contains(baseProductDao.get(baseProduct2.getId())));
    }

    @Test
    public void test_getBaseProducts_with_Relationships_ByManfName() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setManufacturingName("TEST_DUT_MANF");
        relationshipEntity.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity.setBaseProduct(baseProduct);
        relationshipEntity.setLogicalDelete(false);
        relationshipEntity.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct.setProductRelationships(Arrays.asList(relationshipEntity));

        saveFlushAndClear(baseProduct);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("TEST_DUT_MANF"));

        List<BaseProductEntity> baseProductEntities = baseProductDao.findBaseProductsByManfName(sessionId, Arrays.asList(lexiconCrop.getPubkey()));

        assertNotNull(baseProductEntities);
        assertEquals(1, baseProductEntities.size());
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(baseProduct, baseProductEntities.get(0));
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(relationshipEntity,baseProductEntities.get(0).getProductRelationships().get(0));
    }

    @Test
    public void test_getBaseProducts_when_BaseManfName_MultipleProducts_ByManfName() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setManufacturingName("TEST_DUT_MANF");
        relationshipEntity.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity.setBaseProduct(baseProduct);
        relationshipEntity.setLogicalDelete(false);
        relationshipEntity.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct.setProductRelationships(Arrays.asList(relationshipEntity));
        currentSession.save(baseProduct);

        BaseProductEntity baseProduct1 = new BaseProductEntity();
        baseProduct1.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct1.setBaseManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        baseProduct1.setLexiconCrop(lexiconCrop);
        baseProduct1.setLogicalDelete(false);
        baseProduct1.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity1 = new ProductRelationshipEntity();
        relationshipEntity1.setManufacturingName("TEST_DUT");
        relationshipEntity1.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity1.setBaseProduct(baseProduct1);
        relationshipEntity1.setLogicalDelete(false);
        relationshipEntity1.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct1.setProductRelationships(Arrays.asList(relationshipEntity1));
        saveFlushAndClear(baseProduct1);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("%T%E%T%"));

        List<BaseProductEntity> baseProductEntities = baseProductDao.findBaseProductsByManfName(sessionId, Arrays.asList(lexiconCrop.getPubkey()));

        assertNotNull(baseProductEntities);
        assertTrue(baseProductEntities.contains(baseProductDao.get(baseProduct.getId())));
        assertTrue(baseProductEntities.contains(baseProductDao.get(baseProduct1.getId())));
    }

    @Test
    public void test_getBaseProducts_when_BaseManfName_MultipleProducts_MultipleCrops_ManfName() throws Exception {
        BaseProductEntity baseProduct = new BaseProductEntity();
        baseProduct.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct.setBaseManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        LexiconCropEntity lexiconCrop = TestDataBuilder.buildCrop(currentSession, false);
        baseProduct.setLexiconCrop(lexiconCrop);
        baseProduct.setLogicalDelete(false);
        baseProduct.setParentProduct(false);
        ProductRelationshipEntity relationshipEntity = new ProductRelationshipEntity();
        relationshipEntity.setManufacturingName("TEST_DUT_MANF");
        relationshipEntity.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity.setBaseProduct(baseProduct);
        relationshipEntity.setLogicalDelete(false);
        relationshipEntity.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct.setProductRelationships(Arrays.asList(relationshipEntity));
        currentSession.save(baseProduct);

        LexiconCropEntity lexiconCropEntity = TestDataBuilder.buildCrop(currentSession, false);
        BaseProductEntity baseProduct1 = new BaseProductEntity();
        baseProduct1.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct1.setBaseManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        baseProduct1.setLexiconCrop(lexiconCropEntity);
        baseProduct1.setLogicalDelete(false);
        baseProduct1.setParentProduct(false);

        ProductRelationshipEntity relationshipEntity1 = new ProductRelationshipEntity();
        relationshipEntity1.setManufacturingName("TEST_DUT");
        relationshipEntity1.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity1.setBaseProduct(baseProduct1);
        relationshipEntity1.setLogicalDelete(false);
        relationshipEntity1.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct1.setProductRelationships(Arrays.asList(relationshipEntity1));
        currentSession.save(baseProduct1);

        BaseProductEntity baseProduct2 = new BaseProductEntity();
        baseProduct2.setId(TestDataBuilder.generateRandomNegativeLong());
        baseProduct2.setBaseManufacturingName(TestDataBuilder.generateRandomNumberString(25));
        baseProduct2.setLexiconCrop(TestDataBuilder.buildCrop(currentSession, true));
        baseProduct2.setLogicalDelete(false);
        baseProduct2.setParentProduct(false);
        ProductRelationshipEntity relationshipEntity2 = new ProductRelationshipEntity();
        relationshipEntity2.setManufacturingName("TEST_DUT_NOT_RETURNED");
        relationshipEntity2.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
        relationshipEntity2.setBaseProduct(baseProduct2);
        relationshipEntity2.setLogicalDelete(false);
        relationshipEntity2.setVarietyName(TestDataBuilder.generateRandomNumberString(10));
        baseProduct2.setProductRelationships(Arrays.asList(relationshipEntity2));
        saveFlushAndClear(baseProduct2);

        Long sessionId = 67846784L;
        lexiconTempSessionOcdDao.insertTextValues(sessionId, Arrays.asList("%T%E%T%"));

        List<BaseProductEntity> baseProductEntities = baseProductDao.findBaseProductsByManfName(sessionId, Arrays.asList(lexiconCrop.getPubkey(), lexiconCropEntity.getPubkey()));

        assertNotNull(baseProductEntities);
        assertTrue(baseProductEntities.contains(baseProductDao.get(baseProduct.getId())));
        assertTrue(baseProductEntities.contains(baseProductDao.get(baseProduct1.getId())));
        assertFalse(baseProductEntities.contains(baseProductDao.get(baseProduct2.getId())));
    }

    @Test
    public void test_getByManufacturingName(){
      BaseProductEntity baseProduct = TestDataBuilder.createBaseProduct(currentSession,TestDataBuilder.buildCrop(currentSession,true));
      ProductRelationshipEntity productRelationship = new ProductRelationshipEntity();
      productRelationship.setManufacturingName(TestDataBuilder.generateRandomNumberString(20));
      productRelationship.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
      productRelationship.setBaseProduct(baseProduct);
      saveFlushAndClear(productRelationship);

      BaseProductEntity result = baseProductDao.getByManfName(productRelationship.getManufacturingName());

      assertNotNull(result);
      assertEquals(baseProduct.getBaseManufacturingName(), result.getBaseManufacturingName());

    }

    @Test
    public void test_getNotDeletedByManufacturingName_DeleledFalse(){
      BaseProductEntity baseProduct = TestDataBuilder.createBaseProduct(currentSession,TestDataBuilder.buildCrop(currentSession,true));
      baseProduct.setLogicalDelete(false);
      ProductRelationshipEntity productRelationship = new ProductRelationshipEntity();
      productRelationship.setManufacturingName(TestDataBuilder.generateRandomNumberString(20));
      productRelationship.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
      productRelationship.setLogicalDelete(false);
      productRelationship.setBaseProduct(baseProduct);
      saveFlushAndClear(productRelationship);

      BaseProductEntity result = baseProductDao.getBaseProductsNotDeletedByManufacturingName(productRelationship.getManufacturingName());

      assertNotNull(result);
      assertEquals(baseProduct.getBaseManufacturingName(), result.getBaseManufacturingName());

    }

    @Test
    public void test_getNotDeletedByManufacturingName_DeleledNull(){
      BaseProductEntity baseProduct = TestDataBuilder.createBaseProduct(currentSession,TestDataBuilder.buildCrop(currentSession,true));
      baseProduct.setLogicalDelete(null);
      ProductRelationshipEntity productRelationship = new ProductRelationshipEntity();
      productRelationship.setManufacturingName(TestDataBuilder.generateRandomNumberString(20));
      productRelationship.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
      productRelationship.setLogicalDelete(false);
      productRelationship.setBaseProduct(baseProduct);
      saveFlushAndClear(productRelationship);

      BaseProductEntity result = baseProductDao.getBaseProductsNotDeletedByManufacturingName(productRelationship.getManufacturingName());

      assertNotNull(result);
      assertEquals(baseProduct.getBaseManufacturingName(), result.getBaseManufacturingName());

    }

    @Test
    public void test_getNotDeletedByManufacturingName_DeleledTrue(){
      BaseProductEntity baseProduct = TestDataBuilder.createBaseProduct(currentSession,TestDataBuilder.buildCrop(currentSession,true));
      baseProduct.setLogicalDelete(true);
      ProductRelationshipEntity productRelationship = new ProductRelationshipEntity();
      productRelationship.setManufacturingName(TestDataBuilder.generateRandomNumberString(20));
      productRelationship.setProductRelationshipPubkey(TestDataBuilder.generateRandomNumberString(15));
      productRelationship.setLogicalDelete(false);
      productRelationship.setBaseProduct(baseProduct);
      saveFlushAndClear(productRelationship);

      BaseProductEntity result = baseProductDao.getBaseProductsNotDeletedByManufacturingName(productRelationship.getManufacturingName());

      assertNull(result);
    }

}