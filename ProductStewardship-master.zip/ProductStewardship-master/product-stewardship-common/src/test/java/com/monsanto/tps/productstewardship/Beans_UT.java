package com.monsanto.tps.productstewardship;

import org.junit.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ClassUtils;

import java.beans.PropertyDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@SuppressWarnings({"ResultOfMethodCallIgnored", "ObjectEqualsNull"})
public class Beans_UT {
    @Test
    public void coverBeans() {
        coverDirectory(new File(getWorkingDirForTest() + "/product-stewardship-common/src/main/java"), "");
    }

    private void coverDirectory(File directory, String resourcePath) {
        File[] files = directory.listFiles();
        for (File file : files) {
            String fileName = file.getName();
            //ignore svn directories
            if (fileName.contains("svn")){
                continue;
            }
            if (file.isDirectory()) {
                coverDirectory(file, resourcePath + fileName + "/");
            } else {
                coverFile(resourcePath, fileName);
            }
        }
    }

    private void coverFile(String resourcePath, String fileName) {
        if (isJavaFile(fileName)) {
            coverClass(resourcePath, fileName);
        }
    }

    private void coverClass(String resourcePath, String fileName) {
        try {
            Class clazz = getClass(resourcePath, fileName);
            if (!clazz.isInterface()) {
                coverNonInterface(clazz);
            }
        } catch (Exception e) {/* do nothing */}
    }

    private void coverNonInterface(Class clazz) {
        if (clazz.isEnum()) {
            clazz.getEnumConstants();
        } else {
            coverProperties(clazz);
        }
    }

    private void coverProperties(Class clazz) {
        PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(clazz);
        Object object = BeanUtils.instantiateClass(clazz);
        object.equals(object);
        object.equals(null);
        object.equals("");
        object.equals(BeanUtils.instantiateClass(clazz));
        object.toString();
        extensivelyTestOverloadedObjectMethods(clazz, descriptors, object);
        for (PropertyDescriptor descriptor : descriptors) {
            coverProperty(object, descriptor);
        }
    }

    private void extensivelyTestOverloadedObjectMethods(Class clazz, PropertyDescriptor[] descriptors, Object object) {
        Object object2 = BeanUtils.instantiateClass(clazz);
        object2.hashCode();
        populateObjects(object, object2, descriptors);
        for (Field field : object.getClass().getDeclaredFields()) {
            try {
                changeOutValueForFieldAndRunOverloadedMethods(descriptors, object, object2, field);
            } catch (Exception e) {/* do nothing */}
        }
    }

    private void changeOutValueForFieldAndRunOverloadedMethods(PropertyDescriptor[] descriptors, Object object1, Object object2, Field field) throws IllegalAccessException, InvocationTargetException {
        Method writeMethod = getWriteMethod(descriptors, field);
        Method readMethod = getReadMethod(descriptors, field);
        Object oldValue = readMethod.invoke(object2);
        testOverloadedMethods(object1, object2);
        if (field.getType().isPrimitive()) {
            setPrimativeValue(object1, field, writeMethod, false);
        } else {
            Object newValue = getNonPrimativeValue(field);
            writeMethod.invoke(object2, newValue);
        }
        testOverloadedMethods(object1, object2);
        if (!field.getType().isPrimitive()) {
            Object nullValue = null;
            writeMethod.invoke(object2, nullValue);
            testOverloadedMethods(object1, object2);
            testOverloadedMethods(object2, object1);
            writeMethod.invoke(object1, nullValue);
            testOverloadedMethods(object1, object2);
        }
        if (field.getType().isPrimitive()) {
            setPrimativeValue(object1, field, writeMethod, true);
        } else {
            writeMethod.invoke(object1, oldValue);
            writeMethod.invoke(object2, oldValue);
        }
    }

    private void testOverloadedMethods(Object object1, Object object2) {
        object1.equals(object2);
        object2.toString();
        object2.hashCode();
    }

    private Method getWriteMethod(PropertyDescriptor[] descriptors, Field field) {
        for (PropertyDescriptor propertyDescriptor : descriptors) {
            if (propertyDescriptor.getName().equals(field.getName())) {
                return propertyDescriptor.getWriteMethod();
            }
        }
        return null;
    }

    private Method getReadMethod(PropertyDescriptor[] descriptors, Field field) {
        for (PropertyDescriptor propertyDescriptor : descriptors) {
            if (propertyDescriptor.getName().equals(field.getName())) {
                return propertyDescriptor.getReadMethod();
            }
        }
        return null;
    }

    private void populateObjects(Object object1, Object object2, PropertyDescriptor[] descriptors) {
        for (Field field : object1.getClass().getDeclaredFields()) {
            if (!field.getType().getName().equals("com.intellij.rt.coverage.data.ClassData") && !Modifier.isFinal(field.getModifiers())) {
                if (field.getType().isPrimitive()) {
                    Method method = getWriteMethod(descriptors, field);
                    setPrimativeValue(object1, field, method, true);
                    setPrimativeValue(object2, field, method, true);
                } else {
                    try {
                        Object value = getNonPrimativeValue(field);
                        Method method = getWriteMethod(descriptors, field);
                        if (method != null) {
                            method.invoke(object1, value);
                            method.invoke(object2, value);
                        }
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @SuppressWarnings({"UnnecessaryBoxing"})
    private Object getNonPrimativeValue(Field field) {
        Object value = null;
        if (field.getType().isInterface()) {
            if (field.getType().getSimpleName().equals("List")) {
                value = new ArrayList();
            } else if (field.getType().getSimpleName().equals("Map")) {
                value = new HashMap();
            } else if (field.getType().getSimpleName().equals("Set")) {
                value = new HashSet();
            }
        } else if (field.getType().isEnum()) {
            value = field.getType().getEnumConstants()[0];
        } else if (field.getType().getSuperclass().equals(Number.class) || field.getType().equals(Boolean.class) || field.getType().equals(Number.class)) {
            if (field.getType().equals(Boolean.class)) {
                value = Boolean.FALSE;
            } else if (field.getType().equals(Integer.class)) {
                value = new Integer(9);
            } else if (field.getType().equals(Long.class)) {
                value = new Long(9);
            } else if (field.getType().equals(Double.class)) {
                value = new Double(9);
            } else if (field.getType().equals(Float.class)) {
                value = new Float(9);
            } else if (field.getType().equals(Byte.class)) {
                value = new Byte("a");
            } else if (field.getType().equals(Short.class)) {
                value = new Short("a");
            } else {
                value = new Integer(9);
            }
        } else if (Modifier.isAbstract(field.getType().getModifiers())) {
            if (field.getType().equals(OutputStream.class)) {
                value = new ByteArrayOutputStream();
            }
        } else if ((!field.getType().getName().equals("com.intellij.rt.coverage.data.ClassData"))&&
                   (!field.getType().getName().equals("javax.activation.DataHandler"))) {
            value = BeanUtils.instantiateClass(field.getType());
        }
        return value;
    }

    private void setPrimativeValue(Object object, Field field, Method method, boolean useDefault) {
        if (method == null) return;
        try {
            if (field.getType().equals(boolean.class)) {
                method.invoke(object, useDefault);
            } else if (field.getType().equals(int.class)) {
                method.invoke(object, useDefault ? 5 : 9);
            } else if (field.getType().equals(long.class)) {
                method.invoke(object, useDefault ? 6L : 10L);
            } else if (field.getType().equals(double.class)) {
                method.invoke(object, useDefault ? 7D : 11D);
            } else if (field.getType().equals(float.class)) {
                method.invoke(object, useDefault ? 8F : 12F);
            } else if (field.getType().equals(byte.class)) {
                byte b = 1;
                method.invoke(object, useDefault ? b : 2);
            } else if (field.getType().equals(char.class)) {
                method.invoke(object, useDefault ? 'a' : 'b');
            } else if (field.getType().equals(short.class)) {
                short s = 'a';
                method.invoke(object, useDefault ? s : 'b');
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void coverProperty(Object object, PropertyDescriptor descriptor) {
        Object result = null;
        try {
            result = descriptor.getReadMethod().invoke(object);
        } catch (Exception e) {/* do nothing */}
        try {
            descriptor.getWriteMethod().invoke(object, result);
        } catch (Exception e) {/* do nothing */}
    }

    private Class getClass(String resourcePath, String fileName) throws ClassNotFoundException {
        String className = ClassUtils.convertResourcePathToClassName(resourcePath + fileName.replaceAll("\\.java", ""));
        return ClassUtils.forName(className);
    }

    private boolean isJavaFile(String fileName) {
        return !fileName.contains("svn") && fileName.contains(".java");
    }

    private String getWorkingDirForTest() {
        try {
            String currentDir = new File(".").getCanonicalPath();
            System.out.println("currentDir = " + currentDir);
            //Use this line if running locally
            //int index = currentDir.indexOf("ProductStewardship") + 18;
            //use this line if running through Maven
            int index = currentDir.indexOf("product-stewardship-common") - 1;
            if (currentDir.indexOf(File.separator, index) > 0) {
                index = currentDir.indexOf(File.separator, index);
            }
            return currentDir.substring(0, index);
        } catch (IOException e) {
            return "";
        }

    }
}
