package com.monsanto.tps.productstewardship.productimage.service;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlType;

/**
 * vvkalu - Mar 11, 2010 10:12:18 AM
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType
public class ImageResponse {

    private long imageId;
    private String imageTitle;
    private ImageDimensions imageDimensions;
    @XmlMimeType("image/jpeg")
    private DataHandler imageData;

    public DataHandler getImageData() {
        return imageData;
    }

    public void setImageData(DataHandler imageData) {
        this.imageData = imageData;
    }

    public long getImageId() {
        return imageId;
    }

    public void setImageId(long imageId) {
        this.imageId = imageId;
    }

    public String getImageTitle() {
        return imageTitle;
    }

    public void setImageTitle(String imageTitle) {
        this.imageTitle = imageTitle;
    }

    public ImageDimensions getImageDimensions() {
        return imageDimensions;
    }

    public void setImageDimensions(ImageDimensions imageDimensions) {
        this.imageDimensions = imageDimensions;
    }
}
