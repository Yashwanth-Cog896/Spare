package com.monsanto.tps.productstewardship.comments.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 2:12:19 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface ProductAdditionalCommentsService {

    @WebMethod
    public List<ProductAdditionalCommentsSearchResult> findProductAdditionalComments(@WebParam(name="productNames")List<String> productNames,@WebParam(name="nameType") ProductAdditionalCommentsNameType nameType, @WebParam(name="crops")List<String> crops);

    @WebMethod
    public void saveProductAdditionalComments(@WebParam(name="productAdditionalComments")List<ProductAdditionalComments> productAdditionalComments);

    @WebMethod
    Long countProductAdditionalComments(@WebParam(name="productNames")List<String> productNames,@WebParam(name="nameType") ProductAdditionalCommentsNameType nameType, @WebParam(name="crops")List<String> crops);
     @WebMethod
    List<ProductAdditionalCommentsSearchResult> findPagedProductAdditionalComments(@WebParam(name="productNames")List<String> productNames,@WebParam(name="nameType") ProductAdditionalCommentsNameType nameType, @WebParam(name="crops")List<String> crops,@WebParam(name="pageSize")Integer pageSize,@WebParam(name="pageNumber")Integer pageNumber);

}
