package com.monsanto.tps.productstewardship.transfer;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 30, 2011
 * Time: 4:47:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationProperty {
    private String name;
    private String value;

    public ValidationProperty() {
    }

    public ValidationProperty(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ValidationProperty property = (ValidationProperty) o;

        if (!name.equals(property.name)) return false;
        if (!value.equals(property.value)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + value.hashCode();
        return result;
    }
}
