package com.monsanto.tps.productstewardship.productsearch.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 14, 2011
 * Time: 3:11:39 PM
 * To change this template use File | Settings | File Templates.
 */
public enum LexiconProductType {
    ALL,
    NON_PARENTS,
    PARENTS
}
