package com.monsanto.tps.productstewardship.comments.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 6, 2011
 * Time: 1:52:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductAdditionalComments {
    private String productPubkey;
    private String additionalComments;

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }
}
