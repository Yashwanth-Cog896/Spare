package com.monsanto.tps.productstewardship.logicaldelete.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 2:24:26 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface LogicalDeleteService {
    //TODO: Split this into two methods, kept for backward compatibility
    @WebMethod
    public void logicalDeleteStageAndName(@WebParam(name="pubkey")List<String> pubkeys,@WebParam(name="requestor")String requestor,@WebParam(name="comment")String auditComment);

}         
