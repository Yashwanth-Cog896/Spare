package com.monsanto.tps.productstewardship.transfer;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 4:44:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductClassification  implements Serializable {
    String family;
    String materialGroup;
    String materialPricingGroup;
    String productionEnvironment;
    String productType;
    String supplyChainOwnerGroup;

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getMaterialGroup() {
        return materialGroup;
    }

    public void setMaterialGroup(String materialGroup) {
        this.materialGroup = materialGroup;
    }

    public String getMaterialPricingGroup() {
        return materialPricingGroup;
    }

    public void setMaterialPricingGroup(String materialPricingGroup) {
        this.materialPricingGroup = materialPricingGroup;
    }

    public String getProductionEnvironment() {
        return productionEnvironment;
    }

    public void setProductionEnvironment(String productionEnvironment) {
        this.productionEnvironment = productionEnvironment;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getSupplyChainOwnerGroup() {
        return supplyChainOwnerGroup;
    }

    public void setSupplyChainOwnerGroup(String supplyChainOwnerGroup) {
        this.supplyChainOwnerGroup = supplyChainOwnerGroup;
    }
}
