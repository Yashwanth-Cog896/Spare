package com.monsanto.tps.productstewardship.productedit.service;

import java.io.Serializable;

public class ProductGermplasm  implements Serializable {
    Long germplasmId;
    boolean preferredPedigree=false;

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public boolean isPreferredPedigree() {
        return preferredPedigree;
    }

    public void setPreferredPedigree(boolean preferredPedigree) {
        this.preferredPedigree = preferredPedigree;
    }
}
