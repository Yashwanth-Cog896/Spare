package com.monsanto.tps.productstewardship.transfer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 4:51:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductGermplasm {

    private String origin;
    private String lineCode;
    private String owner;
    private String lineType;
    private Boolean finished;
    private List<String> sources = new ArrayList<String>();
    private List<Parents> parents = new ArrayList<Parents>();
    private String pedigree;
    private String eventList;
    private Double relativeMaturity;
    private Boolean preferredPedigree;
    private Long germplasmId;

    public String getEventList() {
        return eventList;
    }

    public void setEventList(String eventList) {
        this.eventList = eventList;
    }

    public Boolean getFinished() {
        return finished;
    }

    public void setFinished(Boolean finished) {
        this.finished = finished;
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public Boolean getPreferredPedigree() {
        return preferredPedigree;
    }

    public void setPreferredPedigree(Boolean preferredPedigree) {
        this.preferredPedigree = preferredPedigree;
    }

    public Double getRelativeMaturity() {
        return relativeMaturity;
    }

    public void setRelativeMaturity(Double relativeMaturity) {
        this.relativeMaturity = relativeMaturity;
    }

    public List<Parents> getParents() {
        return parents;
    }

    public void setParents(List<Parents> parents) {
        this.parents = parents;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public List<String> getSources() {
        return sources;
    }

    public void setSources(List<String> sources) {
        this.sources = sources;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public Long getGermplasmId() {
        return this.germplasmId;
    }
}
