package com.monsanto.tps.productstewardship.productpcname.service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: rlcasw
 * Date: 1/28/13
 * Time: 12:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPrecommercialNameResponse {
    private List<ValidationViolation> validationViolations = new ArrayList<ValidationViolation>();
    private  String preComlName;
    private  String productPubkey;

    public List<ValidationViolation> getValidationViolations() {
        return validationViolations;
    }

    public void setValidationViolations(List<ValidationViolation> validationViolations) {
        this.validationViolations = validationViolations;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }
}
