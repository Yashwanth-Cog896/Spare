package com.monsanto.tps.productstewardship.gqa.service;

import javax.jws.Oneway;
import javax.jws.WebService;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 24, 2011
 * Time: 1:12:03 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService(name = "GqaFlowService", targetNamespace = "http://gqa.productstewardship.tps.monsanto.com/")
public interface GqaFlowService {
    @Oneway
    void flowChangesToGqa();
}
