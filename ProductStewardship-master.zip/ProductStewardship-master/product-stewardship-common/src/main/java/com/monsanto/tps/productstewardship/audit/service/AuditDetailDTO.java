package com.monsanto.tps.productstewardship.audit.service;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 4:49 PM
 */
public class AuditDetailDTO {

    private String columnName;
    private String oldValue;
    private String newValue;

}
