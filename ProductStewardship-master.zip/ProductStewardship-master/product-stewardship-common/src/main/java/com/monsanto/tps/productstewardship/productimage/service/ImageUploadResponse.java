package com.monsanto.tps.productstewardship.productimage.service;

import com.monsanto.tps.productstewardship.transfer.ValidationResult;

import java.util.List;
/**
 * vvkalu - Mar 11, 2010 10:07:35 AM
 */
public class ImageUploadResponse {

    private long imageId;
    private boolean successful;
    private List<ValidationResult> validationResults;

    public boolean isSuccessful() {
        return successful;
    }

    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    public List<ValidationResult> getValidationResults() {
        return validationResults;
    }

    public void setValidationResults(List<ValidationResult> validationResults) {
        this.validationResults = validationResults;
    }

    public long getImageId() {
        return imageId;
    }

    public void setImageId(long imageId) {
        this.imageId = imageId;
    }
}
