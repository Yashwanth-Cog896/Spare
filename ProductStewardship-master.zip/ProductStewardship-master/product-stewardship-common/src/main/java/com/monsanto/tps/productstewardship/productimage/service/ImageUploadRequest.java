package com.monsanto.tps.productstewardship.productimage.service;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlType;

/**
 * vvkalu - Mar 9, 2010 3:15:35 PM
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType
public class ImageUploadRequest {

    private String productPubKey;
    private String imageTitle;
    @XmlMimeType("image/jpeg")
    private DataHandler imageData;

    public DataHandler getImageData() {
        return imageData;
    }

    public void setImageData(DataHandler imageData) {
        this.imageData = imageData;
    }

    public String getProductPubKey() {
        return productPubKey;
    }

    public void setProductPubKey(String productPubKey) {
        this.productPubKey = productPubKey;
    }

    public String getImageTitle() {
        return imageTitle;
    }

    public void setImageTitle(String imageTitle) {
        this.imageTitle = imageTitle;
    }
}
