package com.monsanto.tps.productstewardship.productsearch.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 21, 2011
 * Time: 9:18:54 AM
 * To change this template use File | Settings | File Templates.
 */
public enum NameType {

   PRE_COMMERCIAL("Pre-Commercial"),
   COMMERCIAL("Commercial"),
   VARIETY("Variety"),
   MANUFACTURING("Manufacturing"),
   BASE_MANUFACTURING("Base Manufacturing");
   
   private final String value;
    NameType(String value) {
        this.value=value;
    }
    public String getValue(){
        return value;
    }
}
