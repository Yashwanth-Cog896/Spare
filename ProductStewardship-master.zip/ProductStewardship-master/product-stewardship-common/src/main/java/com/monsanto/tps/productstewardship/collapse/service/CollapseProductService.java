package com.monsanto.tps.productstewardship.collapse.service;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 4:51 PM
 */
public interface CollapseProductService {

   CollapseProductServiceResponse collapseProduct(long sourceProductStageId, long destinationProdStageId);

}
