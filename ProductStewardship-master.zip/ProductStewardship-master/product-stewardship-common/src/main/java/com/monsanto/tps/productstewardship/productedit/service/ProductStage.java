package com.monsanto.tps.productstewardship.productedit.service;

import com.monsanto.tps.productstewardship.transfer.ValidationResult;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class ProductStage implements Serializable {

    private String productStagePubkey;
    private String stageAbbreviation;
    private String countryAbbreviation;
    private boolean active=true;
    private boolean preferredName=false;
    private String brandName;
    private String commercialName;
    private String commercialMaturity;
    private String comlTraitName;
    private String oecdName;
    private boolean delete=false;
    private boolean primary=false;
    private List<ValidationResult> validationResults = new ArrayList<ValidationResult>();
    
    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getComlTraitName() {
        return comlTraitName;
    }

    public void setComlTraitName(String comlTraitName) {
        this.comlTraitName = comlTraitName;
    }

    public String getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(String commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public void setCommercialName(String commercialName) {
        this.commercialName = commercialName;
    }

    public String getCountryAbbreviation() {
        return countryAbbreviation;
    }

    public void setCountryAbbreviation(String countryAbbreviation) {
        this.countryAbbreviation = countryAbbreviation;
    }

    public String getOecdName() {
        return oecdName;
    }

    public void setOecdName(String oecdName) {
        this.oecdName = oecdName;
    }

    public String getProductStagePubkey() {
        return productStagePubkey;
    }

    public void setProductStagePubkey(String productStagePubkey) {
        this.productStagePubkey = productStagePubkey;
    }

    public String getStageAbbreviation() {
        return stageAbbreviation;
    }

    public void setStageAbbreviation(String stageAbbreviation) {
        this.stageAbbreviation = stageAbbreviation;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public boolean isPreferredName() {
        return preferredName;
    }

    public void setPreferredName(boolean preferredName) {
        this.preferredName = preferredName;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public List<ValidationResult> getValidationResults() {
        return validationResults;
    }

    public void setValidationResults(List<ValidationResult> validationResults) {
        this.validationResults = validationResults;
    }
}
