package com.monsanto.tps.productstewardship.transfer;

import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 4:32:43 PM
 * To change this template use File | Settings | File Templates.
 */

public class ProductRelationship {

    private long productRelationshipId;
    private String manufacturingName;
    private String varietyName;
    private List<ProductRelationshipXref> productRelationshipXrefs;
    private List<String> productRelationshipErrors = new ArrayList<String>();

    public boolean success() {
        return productRelationshipErrors.isEmpty();
    }

    public long getProductRelationshipId() {
        return productRelationshipId;
    }

    public void setProductRelationshipId(long productRelationshipId) {
        this.productRelationshipId = productRelationshipId;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public List<ProductRelationshipXref> getProductRelationshipXrefs() {
        return productRelationshipXrefs;
    }

    public void setProductRelationshipXrefs(List<ProductRelationshipXref> productRelationshipXrefs) {
        this.productRelationshipXrefs = productRelationshipXrefs;
    }

    public List<String> getProductRelationshipErrors() {
        return productRelationshipErrors;
    }

    public void setProductRelationshipErrors(List<String> productRelationshipErrors) {
        this.productRelationshipErrors = productRelationshipErrors;
    }
}
