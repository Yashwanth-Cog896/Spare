package com.monsanto.tps.productstewardship.sap.service;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(name = "SapFlowService", targetNamespace = "http://sap.productstewardship.tps.monsanto.com/")
public interface SapFlowService {
    @Oneway
    @WebMethod(operationName = "flowVegetableChangesToSap")
     public void flowVegetableChangesToSap();
}
