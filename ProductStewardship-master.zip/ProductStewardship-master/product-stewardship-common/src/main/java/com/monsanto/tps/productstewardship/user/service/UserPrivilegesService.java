/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.user.service;

import com.monsanto.tps.productstewardship.transfer.UserCrops;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

/* vvkalu - 6/30/11 */
@WebService
public interface UserPrivilegesService {

    @WebMethod
    List<String> getCrops(@WebParam(name = "userLoginId") String userLoginId);

    @WebMethod
    List<String> getRoles(@WebParam(name = "userLoginId") String userLoginId);

    @WebMethod
    List<UserCrops> getUsersCrops(@WebParam(name = "userLoginIds") List<String> userLoginIds);
}