package com.monsanto.tps.productstewardship.productedit.service;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;
@WebService
public interface ProductEditService {
    public static final String DEL_PROD_CONTAINS_NON_LD_STAGES_CODE = "DeletedProductContainsNonLDStages";
    public static final String EXIST_LEX_PROD_DEL_CODE = "ExistingLexProdDeleted";
    public static final String LEX_PROD_FOUND_NO_XREF_CODE = "LexProdFoundWithNoXref";
    public static final String PROD_XREF_EXIST_MIDAS_PROD_DOESNT_CODE = "ProdXrefExistMidasProdDoesnt";
    public static final String LINKED_MIDAS_PROD_INACTIVE_CODE = "LinkedMidasProdInactive";
    public static final String  BOTH_LINKED_AND_MATCH_MIDAS_PROD_CODE = "BothLinkedAndMatchingMidasProdFound";
    public static final String MATCH_MIDAS_PN_MULT_PRODID_CODE = "MatchingMidasPNWithDiffProdID";
    public static final String EXIST_LEX_CROP_DIFFER_CODE = "ExistingLexCropDiffers";
    public static final String INVALID_CROP="InvalidCrop";
    public static final String PARENT_PRODUCT_FLAG_DIFFER_CODE = "ExistingParentProductFlagDiffers";
    public static final String LINKED_MIDAS_PROD_CROP_MISMATCH_CODE = "LinkedMidasProdDiffCropID";
    public static final String INVALID_PC_NAME_CODE = "InvalidPreComlName";
    public static final String MATCHING_LEX_PROD_EXIST = "MatchingLexProdExists";
    public static final String ROW_PROD_HAS_PROD_CLASSIFICATION_CODE = "RowProdHasProdClassification";
    public static final String VEGE_PROD_MISSING_PROD_CLASSIFICATION_CODE = "VegeProdMissingProdClassification";
    public static final String TAG_VARIETY_NAME_FORMAT_CODE = "TagVarietyFormat";
    public static final String TAG_VARIETY_NAME_IN_USE_CODE = "TagVarietyNameInUse";

    public static final String MANF_NAME_INVALID_CODE = "ManfNameInvalid";
    public static final String TRAIT_VERS_INVALID_CODE = "TraitVersInvalid";
    public static final String TRAIT_VER_SPEC_MANF_NOT_CODE = "TraitVerSpecManfNot";
    public static final String SPEC_MANUFACTURING_NAME_DOES_NOT_EXIST = "SpecifiedManufacturingNameDoesNotExist";
    public static final String REQUESTED_PARENT_FLAG_DIFFERS_FROM_BASE_PRODUCTS = "RequestedParentFlagDiffersFromBaseProductsParentFlag" ;
    public static final String REQUESTED_CROP_DIFFERS_FROM_BASE_PRODUCTS = "RequestedCropDiffersFromBaseProductsCrop";
    public static final String MANF_LINE_IS_LOGICALLY_DELETED = "ManufacturingLineIsLogicallyDeleted";
    public static final String BASE_PRODUCT_DOES_NOT_EXIST = "BaseProductDoesNotExist";
    public static final String PROD_REL_PROD_EXISTS_VERS_NOT_SPEC_CODE="ProdRelProdExistsTraitVersNotSpec";
    public static final String TRAIT_VERS_EXISTS_CODE = "TraitVersExists";
    public static final String EXIST_LEX_PROD_DIFF_MANF_CODE="ExistLexProdDiffManf" ;
    public static final String EXIST_LEX_PROD_DIFF_MANF_VER="ExistLexProdDiffTraitVer";
    public static final String ASSIGNING_GP_INVALID_LINE_TYPE_CODE="AssignGPInvalidLineType";
    public static final String ASSIGNING_GP_INCONSISTANT_CODE="AssigningGPInconsistent";

    public static final String LEX_PROD_NOT_EXIST_CODE = "LexProdNotExists";

    public static final String INVALID_COML_NAME = "InvalidComlName";
    public static final String  COML_NAME_TOO_LONG_NON_TDR_CODE = "ComlNameTooLongNonTDRBrand";
    public static final String  COML_NAME_TOO_LONG_TDR_BRAND_CODE = "ComlNameTooLongTDRBrand";
    public static final String COML_NAME_FOR_PC_STAGE_CODE = "ComlNameGivenForPCStage";
    public static final String  COML_NAME_REQ_COML_STAGE_CODE = "ComlNameRequiredForComlStage";

    public static final String   INVALID_BRAND_CODE = "InvalidBrand";
    public static final String   BRAND_NOT_IN_MIRAGE_CODE = "BrandNotInMirage";
    public static final String   BRAND_NOT_IN_MIDAS_CODE = "BrandNotInMidas";
    public static final String   BRAND_NOT_MON_COMPANY_CODE = "BrandNotMonCompany";
    public static final String   COML_BRAND_FOR_PC_STAGE_CODE = "ComlBrandForPCStage";
    public static final String   PC_BRAND_FOR_COML_STAGE_CODE = "PCBrandForComlStage";

    public static final String  INVALID_COUNTY_CODE = "InvalidCountry";
    public static final String  COUNTRY_NOT_IN_M_OR_M_CODE = "CountryNotInMidasOrMirage";

    public static final String  INVALID_STAGE_PUBKEY_CODE = "InvalidStageName";
    public static final String  VEGETABLE_PRODUCT_WITH_ROW_CROP_STAGE_CODE = "VegetableProductWithRowCropStage";
    public static final String  ROW_CROP_PRODUCT_WITH_VEGETABLE_PHASE_CODE = "RowCropProductWithVegetablePhase";

    public static final String  INVALID_TRAIT_STACK_CODE = "InvalidTraitStack";
    public static final String  COML_PROD_WITH_PRECOML_TRAIT = "ComlStageWithPrecomlTrait";
    public static final String  TRAIT_STACK_CROP_MISMATCH_CODE = "TraitCropMismatch";
    public static final String  NON_NUMERIC_COML_MATURITY_CODE = "ComlMatNotNumeric";
    public static final String  COML_MATRUITY_OUT_OF_RANGE_CODE = "ComlMatOutOfRange";
    public static final String COML_MATURITY_REQ_CODE = "ComlMatRequired";
    public static final String  MIRAGE_TRAIT_CODE_NOTFOUND_CODE = "MirageTraitCodeNotFound";
    public static final String  TRAIT_STACK_NOT_ASSOCIATED_WITH_GERMPLASM_CODE = "TraitStackNotAssociatedWithGermplasm";
    public static final String  PREFERRED_NAME_IS_COML_CODE = "PreferredNameIsComl";
    public static final String  NO_PRODUCT_GERMPLASM_CODE = "NoProductGermplasm";
    public static final String  NO_FINISHED_GERMPLASM_CODE = "NoFinishedGermplasm";
    
    public static final String  MATCHING_LEX_STAGE_EXISTS_CODE = "MatchLexStageExists";
    public static final String  MATCHING_LD_LEX_STAGE_EXISTS_CODE = "LDMatchLexStageExists";
    public static final String  MATCHING_MIDAS_COML_PN_EXISTS_CODE = "MatchingActiveMidasComlPNExists";
    public static final String  MATCHING_INACTIVE_MIDAS_COML_PN_EXISTS_CODE = "MatchingInActiveMidasComlPNExists";
    public static final String  MATCHING_MIRAGE_EXISTS_CODE = "MatchingEnabledMirageExists";
    public static final String  MATCHING_DISABLED_MIRAGE_EXISTS_CODE = "MatchingDisabledMirageExists";

    public static final String  NAME_XREF_EXISTS_CODE = "NameXrefExists";


    public static final String  REQ_COUNTRYS_BRANDS_INCONSISTENT_CODE = "RequestedCountrysBrandsInconsistent";
    public static final String  COML_NAME_EXISTS_FOR_DIFF_PROD_CODE = "ComlNameExistForDifferentProduct";
    public static final String  SIM_COML_NAME_EXISTS_FOR_DIFF_PROD_CODE = "SimilarComlNameExistForDifferentProduct";
    public static final String  ONLY_ONE_PREFERRED_NAME_ALLOWED = "OnlyOnePreferredNameAllowed";
    public static final String  ONLY_ONE_EXCEPTION_CODE_MAY_BE_PRIMARY_CODE = "OnlyOneExceptionCodeMayBePrimary";
    public static final String  VEGETABLE_PROD_REQ_SAME_ATTR_CODE = "VegetableProductsRequireSameAttributes";

    public static final String  EXIST_LEX_STAGE_NOT_FOUND_CODE = "ExistLexStageNotFound";
    public static final String  EXIST_LEX_STAGE_LD_CODE = "ExistLexStageLD";
    public static final String  NAME_XREF_NOT_EXISTS_CODE = "NameXrefNotExist";
    public static final String  MIDAS_COML_PN_NOT_EXIST_CODE = "MidasComlPNNotExist";
    public static final String  MIRAGE_PROD_NOT_EXIST_CODE = "MirageProdNotExist";
    @WebMethod
    public List<Product> editProducts(@WebParam(name="product")List<Product> products);
    @WebMethod
    public List<Product> editProductsValidation(@WebParam(name="product")List<Product> products);
}
