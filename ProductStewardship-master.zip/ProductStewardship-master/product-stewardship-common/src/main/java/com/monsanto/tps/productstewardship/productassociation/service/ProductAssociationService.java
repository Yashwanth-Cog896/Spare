package com.monsanto.tps.productstewardship.productassociation.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 2:40:23 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface ProductAssociationService {

    @WebMethod
    List<ProductAssociationSearchResponse> findProductAssociations(@WebParam(name = "searchType")ProductAssociationSearchType searchType,@WebParam(name = "productName")List<String> name,@WebParam(name="isHybridOnly")boolean hybridOnly);

}
