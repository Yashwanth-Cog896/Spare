package com.monsanto.tps.productstewardship.productsearch.service;

import com.monsanto.tps.productstewardship.transfer.Product;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 27, 2011
 * Time: 9:59:04 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductSearchResults {
    private List<Product> products;
    int totalRecordsFound;
    int pageSize;
    int pageNumber;

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public int getTotalRecordsFound() {
        return totalRecordsFound;
    }

    public void setTotalRecordsFound(int totalRecordsFound) {
        this.totalRecordsFound = totalRecordsFound;
    }
}
