package com.monsanto.tps.productstewardship.audit.service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 4:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class AuditInfo {

   private String primaryKey;
   private String table;
   private String tableDescription;
   private String description;
   private Collection<AuditDTO> auditDTOs;
}
