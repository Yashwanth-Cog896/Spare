package com.monsanto.tps.productstewardship.productrelationshipxref.service;

import com.monsanto.tps.productstewardship.transfer.ProductRelationship;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 4:24:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductRelationshipService {

    public List<ProductRelationship> findProductRelationships(ProductRelationshipSearchType searchType, String name, Long productionStatusId);

    public List<ProductRelationship> saveProductRelationships(List<ProductRelationship> productRelationships);
}
