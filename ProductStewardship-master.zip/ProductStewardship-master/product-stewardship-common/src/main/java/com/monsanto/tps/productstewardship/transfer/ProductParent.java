package com.monsanto.tps.productstewardship.transfer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 29, 2011
 * Time: 4:35:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductParent {
    private String productPubkey;
    private String preCommercialName;
    private List<Relationship> relationships= new ArrayList<Relationship>();
    private String predigree;

    public List<Relationship> getRelationships() {
        return relationships;
    }

    public void setRelationships(List<Relationship> relationships) {
        this.relationships = relationships;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || (!getClass().isAssignableFrom(o.getClass()))) return false;

        ProductParent that = (ProductParent) o;

        if (productPubkey != null ? !productPubkey.equals(that.productPubkey) : that.productPubkey != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return productPubkey != null ? productPubkey.hashCode() : 0;
    }

    public void setPredigree(String predigree) {
        this.predigree = predigree;
    }

    public String getPredigree() {
        return predigree;
    }
}
