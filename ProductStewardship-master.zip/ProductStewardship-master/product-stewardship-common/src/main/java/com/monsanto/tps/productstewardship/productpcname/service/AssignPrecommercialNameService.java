package com.monsanto.tps.productstewardship.productpcname.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: rlcasw
 * Date: 1/28/13
 * Time: 11:01 AM
 * To change this template use File | Settings | File Templates.
 */
@WebService(targetNamespace = "http://service.productpcname.producstewardship.tps.monsanto.com/")
public interface AssignPrecommercialNameService {
     @WebMethod(action = "assignPreCommercialName")
     public List<AssignPrecommercialNameResponse> assignPreCommercialName(@WebParam(name="request") List<AssignPrecommercialNameRequestValues> requests);
     @WebMethod(action="validateAssignPreCommercialNameRequests")
     public List<AssignPrecommercialNameResponse> validateAssignPreCommercialNameRequests(@WebParam(name="request") List<AssignPrecommercialNameRequestValues> requests);
     @WebMethod
     List<String> getAvailableNumbersForPreComlAndVarietyNaming(@WebParam (name = "cropID") Long cropID , @WebParam (name = "transgenic") boolean transgenic );
}
