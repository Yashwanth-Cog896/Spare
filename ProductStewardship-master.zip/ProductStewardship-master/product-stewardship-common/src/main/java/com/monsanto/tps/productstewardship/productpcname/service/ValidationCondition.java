package com.monsanto.tps.productstewardship.productpcname.service;


/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: May 10, 2006
 * Time: 11:18:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationCondition  {
    private  String code;
    private  String error;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
