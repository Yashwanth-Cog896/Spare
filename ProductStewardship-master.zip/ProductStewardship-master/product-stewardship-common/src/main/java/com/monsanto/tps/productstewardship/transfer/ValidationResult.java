package com.monsanto.tps.productstewardship.transfer;

import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 15, 2006
 * Time: 6:04:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class ValidationResult
{
   private  String code;
   private  ValidationSeverity severity;
   private  ValidationProperty[] properties;

    public ValidationResult() {
    }

    public ValidationResult(String code, ValidationProperty... properties) {
      this(code,ValidationSeverity.ERROR,properties);
   }

   public ValidationResult(String code, ValidationSeverity severity, ValidationProperty ... properties) {
      this.properties = properties;
      validateCode(code);
      this.severity = severity;
      this.code = code;
   }
   private void validateCode(String code) {
      if (code == null) {
         throw new NullPointerException();
      }
   }

   public String toString() {
      return code;
   }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ValidationProperty[] getProperties() {
        return properties;
    }

    public void setProperties(ValidationProperty[] properties) {
        this.properties = properties;
    }

    public ValidationSeverity getSeverity() {
        return severity;
    }

    public void setSeverity(ValidationSeverity severity) {
        this.severity = severity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || !getClass().isAssignableFrom(o.getClass())) return false;

        ValidationResult that = (ValidationResult) o;

        if (!code.equals(that.code)) return false;
        if (!Arrays.equals(properties, that.properties)) return false;
        if (!severity.equals(that.severity)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = code.hashCode();
        result = 31 * result + severity.hashCode();
        result = 31 * result + (properties != null ? Arrays.hashCode(properties) : 0);
        return result;
    }
}
