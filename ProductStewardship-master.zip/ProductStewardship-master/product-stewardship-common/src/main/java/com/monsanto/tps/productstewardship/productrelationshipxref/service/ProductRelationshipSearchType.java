package com.monsanto.tps.productstewardship.productrelationshipxref.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 4:26:17 PM
 * To change this template use File | Settings | File Templates.
 */
public enum ProductRelationshipSearchType {
}
