package com.monsanto.tps.productstewardship.productsearch.service;

import javax.xml.ws.WebFault;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 11, 2011
 * Time: 12:52:33 PM
 * To change this template use File | Settings | File Templates.
 */
@WebFault(name="TooManyResults")
public class TooManyResultsException extends RuntimeException  {
    public TooManyResultsException(String message) {
        super(message);
    }
}
