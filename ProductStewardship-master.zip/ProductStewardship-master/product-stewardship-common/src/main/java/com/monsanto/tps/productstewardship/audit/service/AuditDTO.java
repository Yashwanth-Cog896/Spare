package com.monsanto.tps.productstewardship.audit.service;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 4:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class AuditDTO {

    private int auditHeaderId;
    private String operationType;
    private String userName;
    private Date entryDate;
    private String processName;
    private String auditComment;
    private String auditRequestor;
    private String tableName;
    private String pkField;
    private Map<String, AuditDetailDTO> auditDetailsByColumnName = new TreeMap<String, AuditDetailDTO>();

}
