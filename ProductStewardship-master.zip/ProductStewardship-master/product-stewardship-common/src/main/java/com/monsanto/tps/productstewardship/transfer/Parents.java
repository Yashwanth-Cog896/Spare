package com.monsanto.tps.productstewardship.transfer;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 29, 2011
 * Time: 4:43:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class Parents {

    private ProductParent father;
    private ProductParent mother;

    public ProductParent getFather() {
        return father;
    }

    public void setFather(ProductParent father) {
        this.father = father;
    }

    public ProductParent getMother() {
        return mother;
    }

    public void setMother(ProductParent mother) {
        this.mother = mother;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || (!getClass().isAssignableFrom(o.getClass()))) return false;

        Parents parents = (Parents) o;

        if (father != null ? !father.equals(parents.father) : parents.father != null) return false;
        if (mother != null ? !mother.equals(parents.mother) : parents.mother != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = father != null ? father.hashCode() : 0;
        result = 31 * result + (mother != null ? mother.hashCode() : 0);
        return result;
    }
}
