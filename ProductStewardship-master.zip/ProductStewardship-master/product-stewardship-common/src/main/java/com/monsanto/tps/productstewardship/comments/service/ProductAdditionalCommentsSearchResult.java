package com.monsanto.tps.productstewardship.comments.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 4, 2011
 * Time: 3:34:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductAdditionalCommentsSearchResult {
    private String productPubkey;
    private String preCommercialName;
    private String varietyName;
    private String additionalComments;
    private String crop;

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }
}
