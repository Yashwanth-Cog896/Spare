package com.monsanto.tps.productstewardship.audit.service;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 4:45 PM
 */
public class AuditReportQueryParams {

    private String tableName;
    private String tableHtml;
    private String columnName;
    private String columnHtml;
    private String oldValue;
    private String newValue;
    private String userLoginId;
    private String userHtml;
    private String comments;
    private String requestor;
    private String actionType;
    private String actionTypeHtml;
    private String fromDate;
    private String toDate;
    private String tableCount;
    private String tableCountMessage;
    private String errorMessage;

}
