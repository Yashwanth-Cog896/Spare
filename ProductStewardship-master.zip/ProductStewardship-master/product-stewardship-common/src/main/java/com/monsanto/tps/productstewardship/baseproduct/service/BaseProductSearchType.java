package com.monsanto.tps.productstewardship.baseproduct.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 5:02:26 PM
 * To change this template use File | Settings | File Templates.
 */
public enum BaseProductSearchType {
    BASEMANUFACTURINGNAME("BaseManufacturingName"),
    MANUFACTURINGNAME("ManufacturingName");

    private String value;

    BaseProductSearchType(String value) {
        this.value = value;
    }

    public static BaseProductSearchType fromValue(String value){
        if(BASEMANUFACTURINGNAME.getValue().equalsIgnoreCase(value)) {
            return BASEMANUFACTURINGNAME;
        } else {
            return MANUFACTURINGNAME;
        }
    }

    public String getValue() {
        return this.value;
    }
}
