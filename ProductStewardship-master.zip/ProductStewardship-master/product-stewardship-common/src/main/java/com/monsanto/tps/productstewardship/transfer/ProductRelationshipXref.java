package com.monsanto.tps.productstewardship.transfer;



import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 2:56:08 PM
 */

public class ProductRelationshipXref {

    private Long productRelationshipXrefId;
    private String traitVersion;
    private long   productionStatusId;
    private List<ProductRelationshipXrefGermplasm> germplasms;

    public Long getProductRelationshipXrefId() {
        return productRelationshipXrefId;
    }

    public void setProductRelationshipXrefId(Long productRelationshipXrefId) {
        this.productRelationshipXrefId = productRelationshipXrefId;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    public long getProductionStatusId() {
        return productionStatusId;
    }

    public void setProductionStatusId(long productionStatusId) {
        this.productionStatusId = productionStatusId;
    }

    public List<ProductRelationshipXrefGermplasm> getGermplasms() {
        return germplasms;
    }

    public void setGermplasms(List<ProductRelationshipXrefGermplasm> germplasms) {
        this.germplasms = germplasms;
    }
}
