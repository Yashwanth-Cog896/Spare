/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.productstewardship.productimage.service;

import com.monsanto.tps.productstewardship.transfer.ValidationResult;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.io.IOException;
import java.util.List;

/**
 * vvkalu - Mar 9, 2010 2:17:17 PM
 */
@WebService
public interface ProductImagesService {
   public static final ValidationResult MATCHING_PRECOMLPROD_DOES_EXIST = new ValidationResult("LexProdNotExists");
   public static final String IMAGE_PIXELS_EXCEED_LIMIT = "imagePixelsExceedLimit";
   public static final ValidationResult IMAGE_FORMAT_INVALID = new ValidationResult("imageFormatInvalid");
   public static final ValidationResult IMAGE_DISPLAY_NAME_EXISTS = new ValidationResult("imageDisplayNameExists");
   public static final String IMAGE_DISPLAY_NAME_EXCEEDS_MAX_LENGTH = "imageDisplayNameExceedsMaxLength";
   public static final String UNEXPECTED_ERROR = "UNEXPECTED ERROR";
   public static final String MAX_WIDTH="maxWidth";
   public static final String MAX_HEIGHT="maxHeight";

    @WebMethod
    List<ImageResponse> getProductImages(@WebParam(name="productPubkey")String productPubKey)
            throws IOException;

    @WebMethod
    List<ImageUploadResponse> uploadImages(@WebParam(name="imageUploadRequest")List<ImageUploadRequest> imageUploadRequests);

    @WebMethod
    void deleteImages(@WebParam(name="deleteImageRequest")List<DeleteImageRequest> deleteImageRequests);
}