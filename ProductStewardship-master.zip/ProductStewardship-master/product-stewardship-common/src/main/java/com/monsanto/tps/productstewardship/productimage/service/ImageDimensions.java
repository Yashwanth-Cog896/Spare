package com.monsanto.tps.productstewardship.productimage.service;

/**
 * vvkalu - Mar 29, 2010 3:28:46 PM
 */
public class ImageDimensions {

    private long imageHeight;
    private long imageWidth;

    public long getImageHeight() {
        return imageHeight;
    }

    public long getImageWidth() {
        return imageWidth;
    }

    public void setImageHeight(long imageHeight) {
        this.imageHeight = imageHeight;
    }

    public void setImageWidth(long imageWidth) {
        this.imageWidth = imageWidth;
    }
}
