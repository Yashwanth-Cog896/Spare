package com.monsanto.tps.productstewardship.baseproduct.service;

import com.monsanto.tps.productstewardship.transfer.ProductRelationship;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 4:52:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class BaseProduct {

    private Long baseProductId;
    private long cropId;
    private boolean parent;
    private String baseManufacturingName;
    private List<ProductRelationship> productRelationship;
    private List<String> baseProductErrors = new ArrayList<String>();

    public boolean success() {
        return baseProductErrors.isEmpty();
    }

    public Long getBaseProductId() {
        return baseProductId;
    }

    public void setBaseProductId(Long baseProductId) {
        this.baseProductId = baseProductId;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public boolean isParent() {
        return parent;
    }

    public void setParent(boolean parent) {
        this.parent = parent;
    }

    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public void setBaseManufacturingName(String baseManufacturingName) {
        this.baseManufacturingName = baseManufacturingName;
    }

    public List<ProductRelationship> getProductRelationships() {
        return productRelationship;
    }

    public void setProductRelationship(List<ProductRelationship> productRelationship) {
        this.productRelationship = productRelationship;
    }

    public List<String> getBaseProductErrors() {
        return baseProductErrors;
    }

    public void setBaseProductErrors(List<String> baseProductErrors) {
        this.baseProductErrors = baseProductErrors;
    }
}
