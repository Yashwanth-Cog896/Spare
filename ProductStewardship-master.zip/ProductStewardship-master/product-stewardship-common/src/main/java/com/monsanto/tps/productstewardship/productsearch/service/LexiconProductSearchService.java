package com.monsanto.tps.productstewardship.productsearch.service;



import com.monsanto.tps.productstewardship.transfer.Product;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 14, 2011
 * Time: 2:54:18 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface LexiconProductSearchService {
    @WebMethod(operationName = "productSearchPaged")
    public ProductSearchResults productSearch(@WebParam(name = "searchCriteria")LexiconProductSearchCriteria productSearchCriteria,@WebParam(name="pageSize")int pageSize,@WebParam(name="pageNumber")int pageNumber);
    @WebMethod(operationName = "productStageSearchPaged")
    public ProductStageSearchResults productStageSearch(@WebParam(name = "searchCriteria")LexiconProductSearchCriteria productSearchCriteria,@WebParam(name="pageSize")int pageSize,@WebParam(name="pageNumber")int pageNumber);
    @WebMethod(operationName = "productSearch")
    public List<Product> productSearch(@WebParam(name = "searchCriteria")LexiconProductSearchCriteria productSearchCriteria)
            throws TooManyResultsException;
}
