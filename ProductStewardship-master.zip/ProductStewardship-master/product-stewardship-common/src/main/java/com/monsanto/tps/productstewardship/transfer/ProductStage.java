package com.monsanto.tps.productstewardship.transfer;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jul 25, 2011
 * Time: 4:41:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductStage {
    private long id;
    private String pubkey;
    private String exceptionPubkey;
    private String country;
    private String stage;
    private boolean active;
    private String brand;
    private String commercialName;
    private boolean primary;
    private boolean preferredName;
    private Double commercialMaturity;
    private String commercialTrait;
    private String oecdRegistrationName;
    private boolean logicalDelete;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Double getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(Double commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public void setCommercialName(String commercialName) {
        this.commercialName = commercialName;
    }

    public String getCommercialTrait() {
        return commercialTrait;
    }

    public void setCommercialTrait(String commercialTrait) {
        this.commercialTrait = commercialTrait;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getExceptionPubkey() {
        return exceptionPubkey;
    }

    public void setExceptionPubkey(String exceptionPubkey) {
        this.exceptionPubkey = exceptionPubkey;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getOecdRegistrationName() {
        return oecdRegistrationName;
    }

    public void setOecdRegistrationName(String oecdRegistrationName) {
        this.oecdRegistrationName = oecdRegistrationName;
    }

    public boolean isPreferredName() {
        return preferredName;
    }

    public void setPreferredName(boolean preferredName) {
        this.preferredName = preferredName;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public boolean isLogicalDelete() {
      return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
      this.logicalDelete = logicalDelete;
    }
}
