package com.monsanto.tps.productstewardship.productpcname.service;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;

/**
 * Created with IntelliJ IDEA.
 * User: rlcasw
 * Date: 1/28/13
 * Time: 1:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignedGermplasm {
    private long germplasmId;
    private boolean preferred;


    @XmlElement
    @XmlSchemaType(name="string")
    public long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(long germplasmId) {
        this.germplasmId = germplasmId;
    }

    @XmlElement
    public boolean isPreferred() {
        return preferred;
    }

    public void setPreferred(boolean preferred) {
        this.preferred = preferred;
    }
}
