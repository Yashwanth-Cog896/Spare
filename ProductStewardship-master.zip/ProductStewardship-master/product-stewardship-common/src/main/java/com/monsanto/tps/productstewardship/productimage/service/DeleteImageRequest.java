package com.monsanto.tps.productstewardship.productimage.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * vvkalu - Mar 11, 2010 10:03:11 AM
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType
public class DeleteImageRequest {

    private long imageId;

    public long getImageId() {
        return imageId;
    }

    public void setImageId(long imageId) {
        this.imageId = imageId;
    }
}
