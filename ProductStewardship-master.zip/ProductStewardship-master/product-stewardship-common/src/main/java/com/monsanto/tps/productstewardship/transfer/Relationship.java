package com.monsanto.tps.productstewardship.transfer;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 1, 2011
 * Time: 9:30:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class Relationship {
    private String productionStatus;
    private String traitVersion;
    private String manufacturingName;
    private String baseManufacturingName;
    private Boolean logicalDelete;


    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public void setBaseManufacturingName(String baseManufacturingName) {
        this.baseManufacturingName = baseManufacturingName;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getProductionStatus() {
        return productionStatus;
    }

    public void setProductionStatus(String productionStatus) {
        this.productionStatus = productionStatus;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    public Boolean getLogicalDelete() {
      return logicalDelete;
    }

    public void setLogicalDelete(Boolean logicalDelete) {
      this.logicalDelete = logicalDelete;
    }
}
