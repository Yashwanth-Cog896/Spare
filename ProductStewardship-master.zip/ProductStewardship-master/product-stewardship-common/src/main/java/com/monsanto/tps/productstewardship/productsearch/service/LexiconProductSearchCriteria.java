package com.monsanto.tps.productstewardship.productsearch.service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 14, 2011
 * Time: 2:56:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductSearchCriteria {

    private List<String> productPubkeys = new ArrayList<String>();
    private NameType nameType;
    private List<String> productNames = new ArrayList<String>();
    private List<String> productStagePubkeys = new ArrayList<String>();
    private LexiconProductType productType;
    private boolean activeProductsOnly;


    private StageType stageType;
    private List<String> brandNames = new ArrayList<String>();
    private List<String> countries = new ArrayList<String>();
    private List<String> stages = new ArrayList<String>();
    private List<String> crops = new ArrayList<String>();
    private List<String> commercialTraits = new ArrayList<String>();

    private String exceptionCode;
    private String origin;
    private String lineCode;

    private boolean traitsAnd;

    private String classificationFamily;
    private String classificationMaterialGroup;
    private String classificationMaterialPricingGroup;
    private String classificationProductionEnvironment;
    private String classificationProductType;
    private boolean retrieveParents;
    private boolean retrieveGermplasm;
    private boolean includeLogicalDelete;
    private boolean includeSourceData = true;

    public List<String> getProductPubkeys() {
        return productPubkeys;
    }

    public void setProductPubkeys(List<String> productPubkeys) {
        this.productPubkeys = productPubkeys;
    }

    public LexiconProductType getProductType() {
        return productType;
    }

    public void setProductType(LexiconProductType productType) {
        this.productType = productType;
    }



    public boolean isActiveProductsOnly() {
        return activeProductsOnly;
    }

    public void setActiveProductsOnly(boolean activeProductsOnly) {
        this.activeProductsOnly = activeProductsOnly;
    }

    public List<String> getProductNames() {
        return productNames;
    }

    public void setProductNames(List<String> productNames) {
        this.productNames = productNames;
    }

    public StageType getStageType() {
        return stageType;
    }

    public void setStageType(StageType stageType) {
        this.stageType = stageType;
    }

    public List<String> getBrandNames() {
        return brandNames;
    }

    public void setBrandNames(List<String> brandNames) {
        this.brandNames = brandNames;
    }

    public List<String> getCountries() {
        return countries;
    }

    public void setCountries(List<String> countries) {
        this.countries = countries;
    }

    public List<String> getStages() {
        return stages;
    }

    public void setStages(List<String> stages) {
        this.stages = stages;
    }

    public List<String> getCommercialTraits() {
        return commercialTraits;
    }

    public void setCommercialTraits(List<String> commercialTraits) {
        this.commercialTraits = commercialTraits;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public boolean isTraitsAnd() {
        return traitsAnd;
    }

    public void setTraitsAnd(boolean traitsAnd) {
        this.traitsAnd = traitsAnd;
    }

    public NameType getNameType() {
        return nameType;
    }

    public void setNameType(NameType nameType) {
        this.nameType = nameType;
    }

    public List<String> getProductStagePubkeys() {
        return productStagePubkeys;
    }

    public void setProductStagePubkeys(List<String> productStagePubkeys) {
        this.productStagePubkeys = productStagePubkeys;
    }

    public List<String> getCrops() {
        return crops;
    }

    public void setCrops(List<String> crops) {
        this.crops = crops;
    }

    public String getExceptionCode() {
        return exceptionCode;
    }

    public void setExceptionCode(String exceptionCode) {
        this.exceptionCode = exceptionCode;
    }

    public String getClassificationFamily() {
        return classificationFamily;
    }

    public void setClassificationFamily(String classificationFamily) {
        this.classificationFamily = classificationFamily;
    }

    public String getClassificationMaterialGroup() {
        return classificationMaterialGroup;
    }

    public void setClassificationMaterialGroup(String classificationMaterialGroup) {
        this.classificationMaterialGroup = classificationMaterialGroup;
    }

    public String getClassificationMaterialPricingGroup() {
        return classificationMaterialPricingGroup;
    }

    public void setClassificationMaterialPricingGroup(String classificationMaterialPricingGroup) {
        this.classificationMaterialPricingGroup = classificationMaterialPricingGroup;
    }

    public String getClassificationProductionEnvironment() {
        return classificationProductionEnvironment;
    }

    public void setClassificationProductionEnvironment(String classificationProductionEnvironment) {
        this.classificationProductionEnvironment = classificationProductionEnvironment;
    }

    public String getClassificationProductType() {
        return classificationProductType;
    }

    public void setClassificationProductType(String classificationProductType) {
        this.classificationProductType = classificationProductType;
    }

    public boolean isRetrieveParents() {
        return retrieveParents;
    }

    public void setRetrieveParents(boolean retrieveParents) {
        this.retrieveParents = retrieveParents;
    }

    public boolean isRetrieveGermplasm() {
        return retrieveGermplasm;
    }

    public void setRetrieveGermplasm(boolean retrieveGermplasm) {
        this.retrieveGermplasm = retrieveGermplasm;
    }

    public boolean isIncludeLogicalDelete() {
      return includeLogicalDelete;
    }

    public void setIncludeLogicalDelete(boolean includeLogicalDelete) {
      this.includeLogicalDelete = includeLogicalDelete;
    }

    public boolean isIncludeSourceData() {
        return includeSourceData;
    }

    public void setIncludeSourceData(boolean includeSourceData) {
        this.includeSourceData = includeSourceData;
    }
}
