package com.monsanto.tps.productstewardship.audit.service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 4:42 PM
 * To change this template use File | Settings | File Templates.
 */
public interface AuditService {

    List<AuditInfo> retrieveAuditInfo(AuditReportQueryParams auditReportQueryParams);

}
