package com.monsanto.tps.productstewardship.transfer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 30, 2011
 * Time: 1:55:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class Product  implements Serializable {
    private long id;
    private String pubkey;
    private String crop;
    private String preCommercialName;
    private String varietyName;
    private Boolean royalty;
    private Boolean hybrid;
    private Boolean logicalDelete;
    private ProductClassification classification;
    private List<ProductGermplasm> productGermplasms = new ArrayList<ProductGermplasm>();
    private List<ProductStage> productStages= new ArrayList<ProductStage>();
    private List<Relationship> relationships= new ArrayList<Relationship>();


    public ProductClassification getClassification() {
        return classification;
    }

    public void setClassification(ProductClassification classification) {
        this.classification = classification;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }



    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public List<ProductGermplasm> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(List<ProductGermplasm> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public List<ProductStage> getProductStages() {
        return productStages;
    }

    public void setProductStages(List<ProductStage> productStages) {
        this.productStages = productStages;
    }

    public String getPubkey() {
        return pubkey;
    }

    public void setPubkey(String pubkey) {
        this.pubkey = pubkey;
    }

    public Boolean getRoyalty() {
        return royalty;
    }

    public void setRoyalty(Boolean royalty) {
        this.royalty = royalty;
    }



    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }


    public List<Relationship> getRelationships() {
        return relationships;
    }

    public void setRelationships(List<Relationship> relationships) {
        this.relationships = relationships;
    }

    public Boolean getHybrid() {
        return hybrid;
    }

    public void setHybrid(Boolean hybrid) {
        this.hybrid = hybrid;
    }

    public Boolean getLogicalDelete() {
      return logicalDelete;
    }

    public void setLogicalDelete(Boolean logicalDelete) {
      this.logicalDelete = logicalDelete;
    }
}
