package com.monsanto.tps.productstewardship.transfer;


import java.util.List;

public class UserCrops
{
    private String userLoginId;
    private List<String> authorizedCropPubkeys;

    public String getUserLoginId() {
        return userLoginId;
    }

    public void setUserLoginId(String userLoginId) {
        this.userLoginId = userLoginId;
    }

    public List<String> getAuthorizedCropPubkeys() {
        return authorizedCropPubkeys;
    }

    public void setAuthorizedCropPubkeys(List<String> authorizedCropPubkeys) {
        this.authorizedCropPubkeys = authorizedCropPubkeys;
    }
}
