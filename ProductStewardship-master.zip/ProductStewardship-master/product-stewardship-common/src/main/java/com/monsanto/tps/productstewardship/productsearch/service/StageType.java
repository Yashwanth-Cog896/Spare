package com.monsanto.tps.productstewardship.productsearch.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Aug 4, 2011
 * Time: 9:42:54 AM
 * To change this template use File | Settings | File Templates.
 */
public enum StageType {
    COMMERCIAL,
    PRECOMMERCIAL;
}
