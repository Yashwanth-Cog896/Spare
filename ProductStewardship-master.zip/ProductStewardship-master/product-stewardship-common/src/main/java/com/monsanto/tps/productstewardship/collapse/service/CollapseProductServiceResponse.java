package com.monsanto.tps.productstewardship.collapse.service;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 6/27/11
 * Time: 5:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class CollapseProductServiceResponse {

    private List<String> errorDetails;
    private List<String> warnings;

}
