package com.monsanto.tps.productstewardship.transfer;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 4:13:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductRelationshipXrefGermplasm {

    private String origin;
    private String lineCode;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }
}
