package com.monsanto.tps.productstewardship.productedit.service;

import com.monsanto.tps.productstewardship.transfer.ProductClassification;
import com.monsanto.tps.productstewardship.transfer.ValidationResult;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Product  implements Serializable {

    private String productPubkey;
    private String preCommercialName;
    private Boolean parentProduct;
    private String manufacturingName;
    private String traitVersion;
    private String varietyName;
    private String lexiconCropName;
    
    private List<ProductGermplasm> assignedGermplasms = new ArrayList<ProductGermplasm>();
    private String productClassificationCode;
    private String supplyChainGroupOwnerCode;
    private List<ProductStage>  productStages = new ArrayList<ProductStage>();

    private  List<ValidationResult>  validationResults = new ArrayList<ValidationResult>();

    public List<ProductGermplasm> getAssignedGermplasms() {
        return assignedGermplasms;
    }

    public void setAssignedGermplasms(List<ProductGermplasm> assignedGermplasms) {
        this.assignedGermplasms = assignedGermplasms;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public Boolean getParentProduct() {
        return parentProduct;
    }

    public void setParentProduct(Boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public String getProductClassificationCode() {
        return productClassificationCode;
    }

    public void setProductClassificationCode(String productClassificationCode) {
        this.productClassificationCode = productClassificationCode;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public List<ProductStage> getProductStages() {
        return productStages;
    }

    public void setProductStages(List<ProductStage> productStages) {
        this.productStages = productStages;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public String getLexiconCropName() {
        return lexiconCropName;
    }

    public void setLexiconCropName(String lexiconCropName) {
        this.lexiconCropName = lexiconCropName;
    }

    public String getSupplyChainGroupOwnerCode() {
        return supplyChainGroupOwnerCode;
    }

    public void setSupplyChainGroupOwnerCode(String supplyChainGroupOwnerCode) {
        this.supplyChainGroupOwnerCode = supplyChainGroupOwnerCode;
    }

    public List<ValidationResult> getValidationResults() {
        return validationResults;
    }

    public void setValidationResults(List<ValidationResult> validationResults) {
        this.validationResults = validationResults;
    }
}
