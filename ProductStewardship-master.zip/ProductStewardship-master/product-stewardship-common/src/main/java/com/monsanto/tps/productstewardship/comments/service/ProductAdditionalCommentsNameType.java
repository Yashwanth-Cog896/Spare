package com.monsanto.tps.productstewardship.comments.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 5, 2011
 * Time: 8:58:30 AM
 * To change this template use File | Settings | File Templates.
 */
public enum ProductAdditionalCommentsNameType {
   PRE_COMMERCIAL("Precommercial"),
   VARIETY("Variety");
   private final String value;
    ProductAdditionalCommentsNameType(String value) {
        this.value=value;
    }
    public String getValue(){
        return value;
    }
    public String getName(){
        return this.name();
    }
}
