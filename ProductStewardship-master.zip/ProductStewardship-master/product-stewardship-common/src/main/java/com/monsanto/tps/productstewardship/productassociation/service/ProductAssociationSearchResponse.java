package com.monsanto.tps.productstewardship.productassociation.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 2:44:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductAssociationSearchResponse {

    private String baseManufacturingName;
    private String manufacturingName;
    private String preCommercialName;
    private String varietyName;

    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public void setBaseManufacturingName(String baseManufacturingName) {
        this.baseManufacturingName = baseManufacturingName;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }
}
