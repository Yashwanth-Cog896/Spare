package com.monsanto.tps.productstewardship.baseproduct.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 4:59:53 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface BaseProductService {

    @WebMethod
    public List<BaseProduct> findBaseProduct(@WebParam(name = "searchType")BaseProductSearchType searchType,
                                             @WebParam(name = "name")List<String> names);
    @WebMethod
    public List<BaseProduct> saveProductBaseProducts(@WebParam(name = "baseProducts")List<BaseProduct> baseProducts);

}
