package com.monsanto.tps.productstewardship.productpcname.service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: rlcasw
 * Date: 1/28/13
 * Time: 1:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPrecommercialNameRequestValues {

    private List<String> countryPubkeys = new ArrayList<String>();
    private String stageTypePubkey;
    private String traitStackPubkey;
    private String commercialMaturity;
    private String manufacturingName;
    private String traitVersion;
    private String preComlName;
    private String cropName;
    private String  productClassificationCode;
    private boolean isParentProduct;
    private String tagVarietyName;
    private List<AssignedGermplasm> assignedGermplasm = new ArrayList<AssignedGermplasm>();
    private String supplyChainOwner;
    private String ownerRegion;
    private String cascade;

    public String getStageTypePubkey() {
        return stageTypePubkey;
    }

    public void setStageTypePubkey(String stageTypePubkey) {
        this.stageTypePubkey = stageTypePubkey;
    }

    public String getTraitStackPubkey() {
        return traitStackPubkey;
    }

    public void setTraitStackPubkey(String traitStackPubkey) {
        this.traitStackPubkey = traitStackPubkey;
    }

    public String getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(String commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getProductClassificationCode() {
        return productClassificationCode;
    }

    public void setProductClassificationCode(String productClassificationCode) {
        this.productClassificationCode = productClassificationCode;
    }

    public boolean isParentProduct() {
        return isParentProduct;
    }

    public void setParentProduct(boolean parentProduct) {
        isParentProduct = parentProduct;
    }

    public String getTagVarietyName() {
        return tagVarietyName;
    }

    public void setTagVarietyName(String tagVarietyName) {
        this.tagVarietyName = tagVarietyName;
    }

    public List<String> getCountryPubkeys() {
        return countryPubkeys;
    }

    public void setCountryPubkeys(List<String> countryPubkeys) {
        this.countryPubkeys = countryPubkeys;
    }

    public List<AssignedGermplasm> getAssignedGermplasm() {
        return assignedGermplasm;
    }

    public void setAssignedGermplasm(List<AssignedGermplasm> assignedGermplasm) {
        this.assignedGermplasm = assignedGermplasm;
    }

    public String getSupplyChainOwner() {
        return supplyChainOwner;
    }

    public void setSupplyChainOwner(String supplyChainOwner) {
        this.supplyChainOwner = supplyChainOwner;
    }

    public String getOwnerRegion() {
        return ownerRegion;
    }

    public void setOwnerRegion(String ownerRegion) {
        this.ownerRegion = ownerRegion;
    }

    public String getCascade() {
        return cascade;
    }

    public void setCascade(String cascade) {
        this.cascade = cascade;
    }
}
