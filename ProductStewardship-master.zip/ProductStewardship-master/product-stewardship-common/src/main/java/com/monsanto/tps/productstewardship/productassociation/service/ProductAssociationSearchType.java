package com.monsanto.tps.productstewardship.productassociation.service;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Jun 22, 2011
 * Time: 2:50:27 PM
 */
public enum ProductAssociationSearchType {

    BASE_MANUFACTURING_NAME("BASE_MANUFACTURING_NAME"),
    MANUFACTURING_NAME("MANUFACTURING_NAME"),
    PRECOMMERCIAL_NAME("PRECOMMERCIAL_NAME"),
    VARIETY_NAME("VARIETY_NAME");

    private String searchType;

    ProductAssociationSearchType(String searchType) {
        this.searchType = searchType;
    }

    public String getSearchType() {
        return searchType;
    }

    public ProductAssociationSearchType findSearchTypeEnum(String searchType){
        if (BASE_MANUFACTURING_NAME.getSearchType().equals(searchType)){
            return BASE_MANUFACTURING_NAME;
        }
        else if (MANUFACTURING_NAME.getSearchType().equals(searchType)){
            return MANUFACTURING_NAME;
        }
        else if (PRECOMMERCIAL_NAME.getSearchType().equals(searchType)){
            return PRECOMMERCIAL_NAME;
        }
        else if (VARIETY_NAME.getSearchType().equals(searchType)){
            return VARIETY_NAME;
        }
        return null;
    }
}
