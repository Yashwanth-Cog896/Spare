declare namespace functx = "http://www.functx.com"; 
declare function functx:trim 
  ( $arg as xs:string? )  as xs:string {
       
   replace(replace($arg,'\s+$',''),'^\s+','')
 } ;

declare variable $arg as  xs:string? external;

functx:trim($arg)