declare namespace monisd = "urn:ecms:function:isd"; 
(: Note this function assumes that the input dateTime is expressed in a timezone that makes sense to the user.
   It ignores the timezone. :)
declare function monisd:formatDateTimeAsMMDDYY 
  ( $arg as xs:dateTime? )  as xs:string {
   let $dt := fn:string($arg)
   return fn:concat(
      fn:substring($dt, 6, 2), '/',
      fn:substring($dt, 9, 2), '/',
      fn:substring($dt, 1, 4), ' ',
      fn:substring($dt, 12, 8)
   )
 } ;

declare variable $arg as  xs:dateTime? external;

monisd:formatDateTimeAsMMDDYY($arg)