<routing>

   <row>
      <Domain>test4.elementk</Domain>
      <UserName>servacct_t4ek</UserName>
      <Password>c2VydmFjY3Q0</Password>
   </row>

   <row>
      <Domain>test6.elementk</Domain>
      <UserName>servacct_t6ek</UserName>
      <Password>c2VydmFjY3Q2</Password>
   </row>

   <row>
      <Domain>test7.elementk</Domain>
      <UserName>servacct_t7ek</UserName>
      <Password>c2VydmFjY3Q3</Password>
   </row>

   <row>
      <Domain>test8.elementk</Domain>
      <UserName>servacct_t8ek</UserName>
      <Password>c2VydmFjY3Q4</Password>
   </row>

   <row>
      <Domain>Monsanto_Chemistry_University</Domain>
      <UserName>seedproWS</UserName>
      <Password>MVdTc2VlZHBybyE=</Password>
   </row>

   <row>
      <Domain>Monsanto Seedpro</Domain>
      <UserName>seedproWS</UserName>
      <Password>MVdTc2VlZHBybyE=</Password>
   </row>

   <row>
      <Domain>Seed_Professional_University_ASI</Domain>
      <UserName>seedproWS</UserName>
      <Password>MVdTc2VlZHBybyE=</Password>
   </row>

   <row>
      <Domain>Asgrow_and_DEKALB_University</Domain>
      <UserName>seedproWS</UserName>
      <Password>MVdTc2VlZHBybyE=</Password>
   </row>

</routing>