declare namespace xf = "http://tempuri.org/GPOS_TO_TESTHARNESS_CONSUMER/genericTransform/";
declare namespace ns0 = "http://www.monsanto.com/test_harness_consumer";
declare namespace ns-1 = "http://www.monsanto.com/common_test_harness";

declare function xf:genericTransform($scenarioId as xs:string)
    as element(ns0:TestHarnessConsumerRequest) {
        <ns0:TestHarnessConsumerRequest>
            <ns-1:TestHarnessId>{ $scenarioId }</ns-1:TestHarnessId>
        </ns0:TestHarnessConsumerRequest>
};

declare variable $scenarioId as xs:string external;

xf:genericTransform($scenarioId)