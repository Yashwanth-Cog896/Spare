declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
(: declare namespace ecms = "urn:ecms:schema:errors:1:0"; :)
declare function monisd:formatEcmsFaultMessageNotValid 
  ( $fault as node() )  as node() {

(:
MAS 8/28/08: Need to add ecms namespace prefix declaration to faultcode element,
but apparent bugs in ALSB QName-related functions prevent doing it via normal XQuery,
so doing as a string using fn-bea:inlinedXML() below.

    element { xs:QName("soapenv:Fault") }
      { element { "faultcode" } {"ecms:MessageNotXValid"},
         element { "faultstring" } {"Schema validation errors in Response, please see body of this message for details"},
         element { "details" } {$fault}
      }
:)

    let $faultcodeElement := fn-bea:inlinedXML(fn:concat(
      '<faultcode xmlns:ecms="urn:ecms:schema:errors:1:0">',
      'ecms:MessageNotValid',
      '</faultcode>'))

    let $soapFault :=
    element { xs:QName("soapenv:Fault") }
      { $faultcodeElement,
         element { "faultstring" } {"Schema validation errors in Response, please see body of this message for details"},
         element { "details" } {$fault}
      }

    return $soapFault
 } ;

declare variable $fault as node() external;

monisd:formatEcmsFaultMessageNotValid($fault)