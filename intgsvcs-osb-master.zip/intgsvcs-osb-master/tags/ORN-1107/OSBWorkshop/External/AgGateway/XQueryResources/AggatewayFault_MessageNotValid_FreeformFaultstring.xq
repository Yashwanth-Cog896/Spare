declare namespace monisd = "urn:ecms:function:isd"; 
declare function monisd:formatAggatewayFaultMessageNotValid 
  ( $faultstringText as xs:string? )  as node() {

(:
MAS 9/23/08: Need to add aggateway namespace prefix declaration to faultcode element,
but apparent bugs in ALSB QName-related functions prevent doing it via normal XQuery,
so doing as a string using fn-bea:inlinedXML() below.

    element { xs:QName("soapenv:Fault") }
      { element { "faultcode" } {"aggateway:MessageNotValid"},
         element { "faultstring" } {$faultstringText}
      }
:)

    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:aggateway="urn:aggateway:names:ws:docexchange">',
      'aggateway:MessageNotValid',
      '</faultcode>',
      '<faultstring>', 
      $faultstringText, 
      '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $faultstringText as xs:string? external;

monisd:formatAggatewayFaultMessageNotValid($faultstringText)