declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
declare function monisd:formatAgFaultMessageNotValid 
  ( $fault as node() )  as node() {

(:
MAS 9/24/08: Need to add aggateway namespace prefix declaration to faultcode element,
but apparent bugs in ALSB QName-related functions prevent doing it via normal XQuery,
so doing as a string using fn-bea:inlinedXML() below.

    element { xs:QName("soapenv:Fault") }
      { element { "faultcode" } {"aggateway:MessageNotXValid"},
         element { "faultstring" } {"Schema validation errors, please see body of this message for details"},
         element { "details" } {$fault}
      }
:)

    let $faultcodeElement := fn-bea:inlinedXML(fn:concat(
      '<faultcode xmlns:aggateway="urn:aggateway:names:ws:docexchange">',
      'aggateway:MessageNotValid',
      '</faultcode>'))

    let $soapFault :=
    element { xs:QName("soapenv:Fault") }
      { $faultcodeElement,
         element { "faultstring" } {"Schema validation errors, please see body of this message for details"},
         element { "details" } {$fault}
      }

    return $soapFault
 } ;

declare variable $fault as node() external;

monisd:formatAgFaultMessageNotValid($fault)