(: XQuery by Priscilla Walmsley (c) O'Reilly Media 2007 :)
(: Example 9-6. Useful function: change-elem-names :)
(: See also: http://www.xqueryfunctions.com :)

(: MAS 7/8/08 After spending about an hour, I am unable to figure out how to pass an
   XQuery sequence in ALSB, i.e. for the values of $old-names and $new-names.  Giving up
   and just calling this function twice rather than continuing to waste time on what may be
   just an ALSB limitation or bug. :)

declare function local:change-elem-names
  ($nodes as node()*, $old-names as xs:string+,
   $new-names as xs:string+) as node()* {

  if (count($old-names) != count($new-names))
  then error(xs:QName("Different_Number_Of_Names"))
  else for $node in $nodes
       return if ($node instance of element())
              then let $newName :=
                     if (local-name($node) = $old-names)
                     then $new-names[index-of($old-names, local-name($node))]
                     else local-name($node)
                   return element {$newName}
                     {$node/@*,
                      local:change-elem-names($node/node(),
                                              $old-names, $new-names)}
              else $node
};

declare variable $nodes as node()* external;
declare variable $old-names as xs:string+ external;
declare variable $new-names as xs:string+ external;

local:change-elem-names($nodes, $old-names, $new-names)