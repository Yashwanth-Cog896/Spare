declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace monalert = "urn:ecms:log:alert";
declare namespace monsh="urn:ecms:soap:header";
declare function monisd:formatAlertEntryWithHeaderBodyFaultAndMessage
  ( $header as node(), $body as node(), $fault as node(), $message as xs:string )  as node() {
    let $myReturn := element { xs:QName("monalert:Alert") }
      { 
         element { xs:QName("monalert:Message") } {$message},
         element { xs:QName("monalert:Header") } {$header},
         element { xs:QName("monalert:Body") } {$body},
         element { xs:QName("monalert:Fault") } {$fault}
      }
    return $myReturn
 } ;

declare variable $header as node() external;
declare variable $body as node() external;
declare variable $fault as node() external;
declare variable $message as xs:string external;

monisd:formatAlertEntryWithHeaderBodyFaultAndMessage($header, $body, $fault, $message)