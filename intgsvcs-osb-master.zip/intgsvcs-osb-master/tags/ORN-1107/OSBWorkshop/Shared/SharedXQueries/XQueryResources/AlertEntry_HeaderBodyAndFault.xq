declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace monalert = "urn:ecms:log:alert";
declare namespace monsh="urn:ecms:soap:header";
declare function monisd:formatAlertEntryWithHeaderBodyAndFault
  ( $header as node(), $body as node(), $fault as node() )  as node() {
    (: Getting intMessageId out of header is not adding much value as Console seems to always display
        header anyway.  Maybe if alot of other stuff was added to header and it no longer fully displayed,
        we could reconsider.
    let $intMessageIdTag := $header/monsh:intMessageId
    :)
    let $myReturn := element { xs:QName("monalert:Alert") }
      { 
         (: element { xs:QName("monalert:IntMessageId") } {$intMessageIdTag}, :)
         element { xs:QName("monalert:Header") } {$header},
         element { xs:QName("monalert:Body") } {$body},
         element { xs:QName("monalert:Fault") } {$fault}
      }
    return $myReturn
 } ;

declare variable $header as node() external;
declare variable $body as node() external;
declare variable $fault as node() external;

monisd:formatAlertEntryWithHeaderBodyAndFault($header, $body, $fault)