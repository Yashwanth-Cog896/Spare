declare namespace monisd = "urn:ecms:function:isd"; 
(: declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/"; :)
(: declare namespace ecms = "urn:ecms:schema:errors:1:0"; :)
declare function monisd:formatEcmsFaultNotSupported 
  ( $faultstring as xs:string? )  as node() {

(:
MAS 8/28/08: Need to add ecms namespace prefix declaration to faultcode element,
but apparent bugs in ALSB QName-related functions prevent doing it via normal XQuery,
so doing as a string using fn-bea:inlinedXML() below.

    element { xs:QName("soapenv:Fault") }
      { element { "faultcode" } {"ecms:NotSupported"},
         element { "faultstring" } {$faultstring}
      }
:)

    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:ecms="urn:ecms:schema:errors:1:0">',
      'ecms:NotSupported',
      '</faultcode>',
      '<faultstring>', $faultstring, '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $faultstring as xs:string? external;

monisd:formatEcmsFaultNotSupported($faultstring)