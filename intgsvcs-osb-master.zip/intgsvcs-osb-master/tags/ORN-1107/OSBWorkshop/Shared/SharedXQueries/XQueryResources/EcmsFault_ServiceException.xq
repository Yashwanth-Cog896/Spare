declare namespace monisd = "urn:ecms:function:isd"; 
(: declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/"; :)
(: declare namespace ecms = "urn:ecms:schema:errors:1:0"; :)
declare function monisd:formatEcmsFaultServiceException 
  ( $serviceName as xs:string? )  as node() {

(:
MAS 8/28/08: Need to add ecms namespace prefix declaration to faultcode element,
but apparent bugs in ALSB QName-related functions prevent doing it via normal XQuery,
so doing as a string using fn-bea:inlinedXML() below.

    element { xs:QName("soapenv:Fault") }
      { element { "faultcode" } {"ecms:ServiceException"},
         element { "faultstring" } {"An error occurred processing the request to ", $serviceName}
      }
:)

    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:ecms="urn:ecms:schema:errors:1:0">',
      'ecms:ServiceException',
      '</faultcode>',
      '<faultstring>', 
      'An error occurred processing the request to ', $serviceName, 
      '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $serviceName as xs:string? external;

monisd:formatEcmsFaultServiceException($serviceName)