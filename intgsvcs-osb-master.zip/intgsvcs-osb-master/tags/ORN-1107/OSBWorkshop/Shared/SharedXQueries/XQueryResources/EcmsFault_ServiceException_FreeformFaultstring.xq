declare namespace monisd = "urn:ecms:function:isd"; 
(: declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/"; :)
(: declare namespace ecms = "urn:ecms:schema:errors:1:0"; :)
declare function monisd:formatEcmsFaultServiceExceptionFreeformFaultstring 
  ( $faultstringText as xs:string? )  as node() {

(:
MAS 9/15/08: Need to add ecms namespace prefix declaration to faultcode element,
but apparent bugs in ALSB QName-related functions prevent doing it via normal XQuery,
so doing as a string using fn-bea:inlinedXML() below.

    element { xs:QName("soapenv:Fault") }
      { element { "faultcode" } {"ecms:ServiceException"},
         element { "faultstring" } {$faultstringText}
      }
:)

    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:ecms="urn:ecms:schema:errors:1:0">',
      'ecms:ServiceException',
      '</faultcode>',
      '<faultstring>', 
      $faultstringText, 
      '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $faultstringText as xs:string? external;

monisd:formatEcmsFaultServiceExceptionFreeformFaultstring($faultstringText)