declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace monrpt = "urn:ecms:log:report";
declare function monisd:formatReportEntryWithBodyAndFault
  ( $body as node(), $fault as node() )  as node() {
    element { xs:QName("monrpt:Report") }
      { element { xs:QName("monrpt:Body") } {$body},
         element { xs:QName("monrpt:Fault") } {$fault}
      }
 } ;

declare variable $body as node() external;
declare variable $fault as node() external;

monisd:formatReportEntryWithBodyAndFault($body, $fault)