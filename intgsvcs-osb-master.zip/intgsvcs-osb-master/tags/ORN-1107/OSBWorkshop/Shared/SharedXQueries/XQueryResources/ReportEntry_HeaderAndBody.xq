declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace monrpt = "urn:ecms:log:report";
declare function monisd:formatReportEntryWithHeaderAndBody 
  ( $header as node(), $body as node() )  as node() {
    element { xs:QName("monrpt:Report") }
      { element { xs:QName("monrpt:Header") } {$header},
         element { xs:QName("monrpt:Body") } {$body}
      }
 } ;

declare variable $header as node() external;
declare variable $body as node() external;

monisd:formatReportEntryWithHeaderAndBody($header, $body)