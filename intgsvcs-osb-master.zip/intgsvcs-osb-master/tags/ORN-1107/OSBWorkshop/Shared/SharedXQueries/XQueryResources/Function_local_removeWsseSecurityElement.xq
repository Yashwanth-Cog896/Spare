(: XQuery by Priscilla Walmsley (c) O'Reilly Media 2007 :)
(: Example 9-4. Useful function: remove-elements-deep :)
(: See also: http://www.xqueryfunctions.com :)

(: Adapted by MAS for Monsanto.  As of initial implementation Sept. 16, 2008,
the wsse:Security element must be named literally that, with "wsse" for the
prefix.  If clients send messages with a different prefix, this would need to be 
adapted to find the correct prefix. :)

declare function local:remove-wsse-security-element
 ($element as element()) as element() {
   element {node-name($element)}
           {$element/@*,
            for $child in $element/node()
            return if ($child instance of element())
                   then if ($child[name() = 'wsse:Security'])
                        then ()
                        else local:remove-wsse-security-element($child)
                   else $child }
};

declare variable $element as element() external;

local:remove-wsse-security-element($element)