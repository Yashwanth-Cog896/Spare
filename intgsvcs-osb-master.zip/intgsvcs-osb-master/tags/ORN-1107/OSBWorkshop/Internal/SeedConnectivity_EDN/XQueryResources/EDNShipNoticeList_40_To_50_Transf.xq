declare namespace xf = "http://tempuri.org/Samples/XQueryTransformations/EDN_ShipNoticeList_4-0_To_5-0/";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace ns-1 = "urn:cidx:names:specification:ces:schema:all:4:0";
declare namespace ns1 = "urn:ecms:schema:shipnotice:response:1:0";

declare function xf:EDN_ShipNoticeList_4-0_To_5-0($shipNoticeList1 as element(ns1:ShipNoticeList))
    as element(ns0:ShipNoticeList) {
        <ns0:ShipNoticeList Version = "5.0">
            <ns0:Header>
                <ns0:ThisDocumentIdentifier>
                    <ns0:DocumentIdentifier>{ data($shipNoticeList1/ns-1:Header/ns-1:ThisDocumentIdentifier/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                </ns0:ThisDocumentIdentifier>
                <ns0:ThisDocumentDateTime>
                    <ns0:DateTime DateTimeQualifier = "{ data($shipNoticeList1/ns-1:Header/ns-1:ThisDocumentDateTime/ns-1:DateTime/@DateTimeQualifier) }">{ data($shipNoticeList1/ns-1:Header/ns-1:ThisDocumentDateTime/ns-1:DateTime) }</ns0:DateTime>
                </ns0:ThisDocumentDateTime>
                <ns0:From>
                    <ns0:PartnerInformation>
                        {
                            for $PartnerName in $shipNoticeList1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:PartnerName
                            return
                                <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                        }
                        <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($shipNoticeList1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($shipNoticeList1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                        {
                            for $ContactInformation in $shipNoticeList1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:ContactInformation
                            return
                                <ns0:ContactInformation>
                                    {
                                        for $ContactName in $ContactInformation/ns-1:ContactName
                                        return
                                            <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                    }
                                    {
                                        for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                        return
                                            <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                    }
                                                                        {
                                        for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                        return
                                            <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                    }
                                    {
                                        for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                        return
                                            <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                    }
                                    {
                                        for $AlternativeCommunicationMethod in $ContactInformation/ns-1:AlternativeCommunicationMethod
                                        return
                                            <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns0:AlternativeCommunicationMethod>
                                    }
                                </ns0:ContactInformation>
                        }
                        {
	                        for $AddressInformation in $shipNoticeList1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation
	                        return
	                            <ns0:AddressInformation>
	                                {
	                                    for $AddressLine in $AddressInformation/ns-1:AddressLine
	                                    return
	                                        <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
	                                }
	                                <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber>
	                                <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
	                                {
	                                    for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
	                                    return
	                                        <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
	                                }
	                                {
	                                    for $PostalCode in $AddressInformation/ns-1:PostalCode
	                                    return
	                                        <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
	                                }
	                                <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
	                                {
	                                    for $LocationCode in $AddressInformation/ns-1:LocationCode
	                                    return
	                                        <ns0:LocationCode Domain = "{ data($LocationCode/@Domain) }">{ data($LocationCode) }</ns0:LocationCode>
	                                }
	                                {
	                                    for $Comment in $AddressInformation/ns-1:Comment
	                                    return
	                                        <ns0:Comment>
	                                            <ns0:Content>{ data($Comment/ns-1:Content) }</ns0:Content>
	                                            <ns0:ExternalReference>{ data($Comment/ns-1:ExternalReference) }</ns0:ExternalReference>
	                                        </ns0:Comment>
	                                }
	                            </ns0:AddressInformation>
	                    }
                    </ns0:PartnerInformation>
                </ns0:From>
                <ns0:To>
                    {
                        for $PartnerInformation in $shipNoticeList1/ns-1:Header/ns-1:To/ns-1:PartnerInformation
                        where data($PartnerInformation/ns-1:PartnerIdentifier/@Agency) = data($PartnerInformation/ns-1:PartnerIdentifier/@Agency)
                        return
                            <ns0:PartnerInformation>
                                {
                                    for $PartnerName in $PartnerInformation/ns-1:PartnerName
                                    return
                                        <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                                }
                                <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                                {
                                    for $ContactInformation in $PartnerInformation/ns-1:ContactInformation
                                    return
                                        <ns0:ContactInformation>
                                            {
                                                for $ContactName in $ContactInformation/ns-1:ContactName
                                                return
                                                    <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                            }
                                            {
                                                for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                                return
                                                    <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                            }
                                            {
                                                for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                                return
                                                    <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                            }
                                            {
                                                for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                                return
                                                    <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                            }
                                            {
                                                for $AlternativeCommunicationMethod in $ContactInformation/ns-1:AlternativeCommunicationMethod
                                                return
                                                    <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns0:AlternativeCommunicationMethod>
                                            }
                                        </ns0:ContactInformation>
                                }
                                {
                                    for $AddressInformation in $PartnerInformation/ns-1:AddressInformation
                                    return
                                        <ns0:AddressInformation>
                                            {
                                                for $AddressLine in $AddressInformation/ns-1:AddressLine
                                                return
                                                    <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                            }
                                            <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber>
                                            <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                            {
                                                for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                                return
                                                    <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                            }
                                            {
                                                for $PostalCode in $AddressInformation/ns-1:PostalCode
                                                return
                                                    <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                            }
                                            <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                            {
                                                for $LocationCode in $AddressInformation/ns-1:LocationCode
                                                return
                                                    <ns0:LocationCode>{ data($LocationCode) }</ns0:LocationCode>
                                            }
                                            {
                                                for $Comment in $AddressInformation/ns-1:Comment
                                                return
                                                    <ns0:Comment/>
                                            }
                                        </ns0:AddressInformation>
                                }
                            </ns0:PartnerInformation>
                    }
                </ns0:To>
            </ns0:Header>
            {
                let $ShipNoticeListBody := $shipNoticeList1/ns1:ShipNoticeListBody
                return
                    <ns0:ShipNoticeListBody>
                        {
                            let $ShipNoticeListProperties := $ShipNoticeListBody/ns1:ShipNoticeListProperties
                            return
                                <ns0:ShipNoticeListProperties/>
                        }
                        {
                            let $ShipNoticeListDetails := $ShipNoticeListBody/ns1:ShipNoticeListDetails
                            return
                                <ns0:ShipNoticeListDetails>
                                    {
                                        for $ShipNoticeBody in $ShipNoticeListDetails/ns-1:ShipNoticeBody
                                        return
                                            <ns0:ShipNoticeBody>
                                                <ns0:ShipNoticeProperties>
                                                    <ns0:ShipmentIdentification>
                                                        <ns0:DocumentReference>
                                                            <ns0:DocumentIdentifier>{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentIdentification/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                            {
                                                                for $DateTime in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentIdentification/ns-1:DocumentReference/ns-1:DateTime
                                                                return
                                                                    <ns0:DateTime DateTimeQualifier = "{ data($DateTime/@DateTimeQualifier) }">{ data($DateTime) }</ns0:DateTime>
                                                            }
                                                            {
                                                                for $ReferenceItem in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentIdentification/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                return
                                                                    <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                            }
                                                            {
                                                                for $ReleaseNumber in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentIdentification/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                return
                                                                    <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                            }
                                                        </ns0:DocumentReference>
                                                    </ns0:ShipmentIdentification>
                                                    <ns0:ShipDate>
                                                        <ns0:DateTime DateTimeQualifier = "{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipDate/ns-1:DateTime/@DateTimeQualifier) }">{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipDate/ns-1:DateTime) }</ns0:DateTime>
                                                    </ns0:ShipDate>
                                                    {
                                                        for $LoadTenderInformation in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:LoadTenderInformation
                                                        return
                                                            <ns0:LoadTenderInformation>
                                                                <ns0:DocumentReference>
                                                                    <ns0:DocumentIdentifier>{ data($LoadTenderInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                                    {
                                                                        for $DateTime in $LoadTenderInformation/ns-1:DocumentReference/ns-1:DateTime
                                                                        return
                                                                            <ns0:DateTime DateTimeQualifier = "{ data($DateTime/@DateTimeQualifier) }">{ data($DateTime) }</ns0:DateTime>
                                                                    }
                                                                    {
                                                                        for $ReferenceItem in $LoadTenderInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                        return
                                                                            <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                                    }
                                                                    {
                                                                        for $ReleaseNumber in $LoadTenderInformation/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                        return
                                                                            <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                                    }
                                                                </ns0:DocumentReference>
                                                            </ns0:LoadTenderInformation>
                                                    }
                                                    {
                                                        for $PurchaseOrderInformation in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:PurchaseOrderInformation
                                                        return
                                                            <ns0:PurchaseOrderInformation>
                                                                <ns0:DocumentReference>
                                                                    <ns0:DocumentIdentifier>{ data($PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                                    {
                                                                        for $DateTime in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DateTime
                                                                        return
                                                                            <ns0:DateTime DateTimeQualifier = "{ data($DateTime/@DateTimeQualifier) }">{ data($DateTime) }</ns0:DateTime>
                                                                    }
                                                                    {
                                                                        for $ReferenceItem in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                        return
                                                                            <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                                    }
                                                                    {
                                                                        for $ReleaseNumber in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                        return
                                                                            <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                                    }
                                                                </ns0:DocumentReference>
                                                            </ns0:PurchaseOrderInformation>
                                                    }
                                                    <ns0:TransportMethodCode Domain = "{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:TransportMethodCode/@Domain) }">{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:TransportMethodCode) }</ns0:TransportMethodCode>
                                                    {
                                                        for $MarketPlaceInformation in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:MarketPlaceInformation
                                                        return
                                                            <ns0:MarketPlaceInformation>
                                                                <ns0:MarketPlaceIdentifier>{ data($MarketPlaceInformation/ns-1:MarketPlaceIdentifier) }</ns0:MarketPlaceIdentifier>
                                                                <ns0:MarketPlaceDocumentReference>
                                                                    {
                                                                        <ns0:DocumentReference>
                                                                        <ns0:DocumentIdentifier>{ data($MarketPlaceInformation/ns-1:MarketPlaceDocumentReference/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                                        {
                                                                        for $ReferenceItem in $MarketPlaceInformation/ns-1:MarketPlaceDocumentReference/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                        return
                                                                        <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                                        }
                                                                        {
                                                                        for $ReleaseNumber in $MarketPlaceInformation/ns-1:MarketPlaceDocumentReference/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                        return
                                                                        <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                                        }
                                                                        </ns0:DocumentReference>
                                                                    }
</ns0:MarketPlaceDocumentReference>
                                                                <ns0:MarketPlaceSellerIdentifier>{ data($MarketPlaceInformation/ns-1:MarketPlaceSellerIdentifier) }</ns0:MarketPlaceSellerIdentifier>
                                                                <ns0:MarketPlaceBuyerIdentifier>{ data($MarketPlaceInformation/ns-1:MarketPlaceBuyerIdentifier) }</ns0:MarketPlaceBuyerIdentifier>
                                                            </ns0:MarketPlaceInformation>
                                                    }
                                                    {
                                                        for $RoutingInstructions in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:RoutingInstructions
                                                        return
                                                            <ns0:RoutingInstructions>
                                                                <ns0:Comment>
                                                                    <ns0:Content>{ data($RoutingInstructions/ns-1:Comment/ns-1:Content) }</ns0:Content>
                                                                    <ns0:ExternalReference>{ data($RoutingInstructions/ns-1:Comment/ns-1:ExternalReference) }</ns0:ExternalReference>
                                                                </ns0:Comment>
                                                            </ns0:RoutingInstructions>
                                                    }
                                                    {
                                                        for $ReferenceInformation in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ReferenceInformation
                                                        return
                                                            <ns0:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                                                <ns0:DocumentReference>
                                                                    <ns0:DocumentIdentifier>{ data($ReferenceInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                                    {
                                                                        for $DateTime in $ReferenceInformation/ns-1:DocumentReference/ns-1:DateTime
                                                                        return
                                                                            <ns0:DateTime DateTimeQualifier = "{ data($DateTime/@DateTimeQualifier) }">{ data($DateTime) }</ns0:DateTime>
                                                                    }
                                                                    {
                                                                        for $ReferenceItem in $ReferenceInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                        return
                                                                            <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                                    }
                                                                    {
                                                                        for $ReleaseNumber in $ReferenceInformation/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                        return
                                                                            <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                                    }
                                                                </ns0:DocumentReference>
                                                            </ns0:ReferenceInformation>
                                                    }
                                                    {
                                                        for $ShipmentMethodOfPaymentCode in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentMethodOfPaymentCode
                                                        return
                                                            <ns0:ShipmentMethodOfPaymentCode Domain = "{ data($ShipmentMethodOfPaymentCode/@Domain) }">{ data($ShipmentMethodOfPaymentCode) }</ns0:ShipmentMethodOfPaymentCode>
                                                    }
                                                    {
                                                        for $DeliveryTerms in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:DeliveryTerms
                                                        return
                                                            <ns0:DeliveryTerms>
                                                                <ns0:DeliveryTermsCode Domain = "{ data($DeliveryTerms/ns-1:DeliveryTermsCode/@Domain) }">{ data($DeliveryTerms/ns-1:DeliveryTermsCode) }</ns0:DeliveryTermsCode>
                                                                <ns0:DeliveryTermsLocation>{ data($DeliveryTerms/ns-1:DeliveryTermsLocation) }</ns0:DeliveryTermsLocation>
                                                            </ns0:DeliveryTerms>
                                                    }
                                                    {
                                                        for $ConveyanceInformation in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ConveyanceInformation
                                                        return
                                                            <ns0:ConveyanceInformation>
                                                                <ns0:ConveyanceNameOrIdentifier>{ data($ConveyanceInformation/ns-1:ConveyanceNameOrIdentifier) }</ns0:ConveyanceNameOrIdentifier>
                                                                {
                                                                    for $VoyageTripNumber in $ConveyanceInformation/ns-1:VoyageTripNumber
                                                                    return
                                                                        <ns0:VoyageTripNumber SelectionQualifier = "{ data($VoyageTripNumber/@SelectionQualifier) }">{ data($VoyageTripNumber) }</ns0:VoyageTripNumber>
                                                                }
                                                                {
                                                                    for $EstimatedTimeOfDepartureDate in $ConveyanceInformation/ns-1:EstimatedTimeOfDepartureDate
                                                                    return
                                                                        <ns0:EstimatedTimeOfDepartureDate>
                                                                            <ns0:DateTimeInformation>
                                                                                <ns0:DateTime DateTimeQualifier = "{ data($EstimatedTimeOfDepartureDate/ns-1:DateTimeInformation/ns-1:DateTime/@DateTimeQualifier) }">{ data($EstimatedTimeOfDepartureDate/ns-1:DateTimeInformation/ns-1:DateTime) }</ns0:DateTime>
                                                                            </ns0:DateTimeInformation>
                                                                        </ns0:EstimatedTimeOfDepartureDate>
                                                                }
                                                                {
                                                                    for $EstimatedTimeOfArrivalDate in $ConveyanceInformation/ns-1:EstimatedTimeOfArrivalDate
                                                                    return
                                                                        <ns0:EstimatedTimeOfArrivalDate>
                                                                            <ns0:DateTimeInformation>
                                                                                <ns0:DateTime DateTimeQualifier = "{ data($EstimatedTimeOfArrivalDate/ns-1:DateTimeInformation/ns-1:DateTime/@DateTimeQualifier) }">{ data($EstimatedTimeOfArrivalDate/ns-1:DateTimeInformation/ns-1:DateTime) }</ns0:DateTime>
                                                                            </ns0:DateTimeInformation>
                                                                        </ns0:EstimatedTimeOfArrivalDate>
                                                                }
                                                            </ns0:ConveyanceInformation>
                                                    }
                                                    {
                                                        for $PortOfLoadingCode in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:PortOfLoadingCode
                                                        return
                                                            <ns0:PortOfLoadingCode Domain = "{ data($PortOfLoadingCode/@Domain) }">{ data($PortOfLoadingCode) }</ns0:PortOfLoadingCode>
                                                    }
                                                    {
                                                        for $MovementType in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:MovementType
                                                        return
                                                            <ns0:MovementType>{ data($MovementType) }</ns0:MovementType>
                                                    }
                                                    {
                                                        for $PortOfDischargeCode in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:PortOfDischargeCode
                                                        return
                                                            <ns0:PortOfDischargeCode Domain = "{ data($PortOfDischargeCode/@Domain) }">{ data($PortOfDischargeCode) }</ns0:PortOfDischargeCode>
                                                    }
                                                    {
                                                        for $SpecialInstructions in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:SpecialInstructions
                                                        return
                                                            <ns0:SpecialInstructions InstructionType = "{ data($SpecialInstructions/@InstructionType) }">{ data($SpecialInstructions) }</ns0:SpecialInstructions>
                                                    }
                                                    <ns0:ShipNoticeDate>
                                                        <ns0:DateTime DateTimeQualifier = "{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipNoticeDate/ns-1:DateTime/@DateTimeQualifier) }">{ data($ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipNoticeDate/ns-1:DateTime) }</ns0:DateTime>
                                                    </ns0:ShipNoticeDate>
                                                    {
                                                        for $ShipNoticeStatus in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipNoticeStatus
                                                        return
                                                            <ns0:ShipNoticeStatus>{ data($ShipNoticeStatus) }</ns0:ShipNoticeStatus>
                                                    }
                                                    {
                                                        for $RequestedDocument in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:RequestedDocument
                                                        return
                                                            <ns0:RequestedDocument>
                                                                <ns0:RequestedDocumentTypeCode>{ data($RequestedDocument/ns-1:RequestedDocumentTypeCode) }</ns0:RequestedDocumentTypeCode>
                                                                {
                                                                    for $DocumentRecipientInformation in $RequestedDocument/ns-1:DocumentRecipientInformation
                                                                    return
                                                                        <ns0:DocumentRecipientInformation DeliveryMethodQualifier = "{ data($DocumentRecipientInformation/@DeliveryMethodQualifier) }">
                                                                            <ns0:DocumentRecipientPartner PartnerRole = "{ data($DocumentRecipientInformation/ns-1:DocumentRecipientPartner/@PartnerRole) }">
                                                                                <ns0:PartnerInformation>
                                                                                    {
                                                                                        for $PartnerName in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:PartnerName
                                                                                        return
                                                                                            <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                                                                                    }
                                                                                    <ns0:PartnerIdentifier>{ data($DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                                                                                    {
                                                                                        for $ContactInformation in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:ContactInformation
                                                                                        return
                                                                                            <ns0:ContactInformation/>
                                                                                    }
                                                                                    {
                                                                                        for $AddressInformation in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:AddressInformation
                                                                                        return
                                                                                            <ns0:AddressInformation/>
                                                                                    }
                                                                                    {
                                                                                        for $TaxInformation in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:TaxInformation
                                                                                        return
                                                                                            <ns0:TaxInformation/>
                                                                                    }
                                                                                    {
                                                                                        for $URL in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:URL
                                                                                        return
                                                                                            <ns0:URL>{ data($URL) }</ns0:URL>
                                                                                    }
                                                                                    {
                                                                                        for $PartnerReference in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:PartnerReference
                                                                                        return
                                                                                            <ns0:PartnerReference/>
                                                                                    }
                                                                                    {
                                                                                        for $LoadingPoint in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:LoadingPoint
                                                                                        return
                                                                                            <ns0:LoadingPoint/>
                                                                                    }
                                                                                    {
                                                                                        for $UnloadingPoint in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:UnloadingPoint
                                                                                        return
                                                                                            <ns0:UnloadingPoint/>
                                                                                    }
                                                                                    {
                                                                                        for $AccountInformation in $DocumentRecipientInformation/ns-1:DocumentRecipientPartner/ns-1:PartnerInformation/ns-1:AccountInformation
                                                                                        return
                                                                                            <ns0:AccountInformation/>
                                                                                    }
                                                                                </ns0:PartnerInformation>
                                                                            </ns0:DocumentRecipientPartner>
                                                                            {
                                                                                for $DocumentDeliveryMethod in $DocumentRecipientInformation/ns-1:DocumentDeliveryMethod
                                                                                return
                                                                                    <ns0:DocumentDeliveryMethod>{ data($DocumentDeliveryMethod) }</ns0:DocumentDeliveryMethod>
                                                                            }
                                                                            {
                                                                                for $LanguageCode in $DocumentRecipientInformation/ns-1:LanguageCode
                                                                                return
                                                                                    <ns0:LanguageCode Domain = "{ data($LanguageCode/@Domain) }">{ data($LanguageCode) }</ns0:LanguageCode>
                                                                            }
                                                                            {
                                                                                for $NumberOfOriginals in $DocumentRecipientInformation/ns-1:NumberOfOriginals
                                                                                return
                                                                                    <ns0:NumberOfOriginals>{ data($NumberOfOriginals) }</ns0:NumberOfOriginals>
                                                                            }
                                                                            {
                                                                                for $NumberOfCopies in $DocumentRecipientInformation/ns-1:NumberOfCopies
                                                                                return
                                                                                    <ns0:NumberOfCopies>{ data($NumberOfCopies) }</ns0:NumberOfCopies>
                                                                            }
                                                                        </ns0:DocumentRecipientInformation>
                                                                }
                                                            </ns0:RequestedDocument>
                                                    }
                                                    {
                                                        for $LanguageCode in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:LanguageCode
                                                        return
                                                            <ns0:LanguageCode Domain = "{ data($LanguageCode/@Domain) }">{ data($LanguageCode) }</ns0:LanguageCode>
                                                    }
                                                    {
                                                        for $ShipmentStopType in $ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentStopType
                                                        return
                                                            <ns0:ShipmentStopType>{ data($ShipmentStopType) }</ns0:ShipmentStopType>
                                                    }
                                                </ns0:ShipNoticeProperties>
                                                <ns0:ShipNoticePartners>
                                                    <ns0:Buyer>
                                                        <ns0:PartnerInformation>
                                                            {
                                                                for $PartnerName in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerName
                                                                return
                                                                    <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                                                            }
                                                            <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                                                            {
                                                                for $ContactInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:ContactInformation
                                                                return
                                                                    <ns0:ContactInformation>
                                                                        {
                                                                            for $ContactName in $ContactInformation/ns-1:ContactName
                                                                            return
                                                                                <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                                                        }
                                                                        {
                                                                            for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                                                            return
                                                                                <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                                                        }
                                                                        {
                                                                            for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                                                            return
                                                                                <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                                                        }
                                                                        {
                                                                            for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                                                            return
                                                                                <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                                                        }
                                                                        {
                                                                            for $AlternativeCommunicationMethod in $ContactInformation/ns-1:AlternativeCommunicationMethod
                                                                            return
                                                                                <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns0:AlternativeCommunicationMethod>
                                                                        }
                                                                    </ns0:ContactInformation>
                                                            }
                                                            {
                                                                for $AddressInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:AddressInformation
                                                                return
                                                                    <ns0:AddressInformation>
                                                                        {
                                                                            for $AddressLine in $AddressInformation/ns-1:AddressLine
                                                                            return
                                                                                <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                                                        }
                                                                        {
                                                                        	for $PostBoxNumber in $AddressInformation/ns-1:PostBoxNumber 
                                                                        	return 
                                                                        		<ns0:PostBoxNumber>{ data($PostBoxNumber) }</ns0:PostBoxNumber> 		
                                                                        }
                                                                        <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                                                        {
                                                                            for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                                                            return
                                                                                <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                                                        }
                                                                        {
                                                                            for $PostalCode in $AddressInformation/ns-1:PostalCode
                                                                            return
                                                                                <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                                                        }
                                                                        <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                                                        {
                                                                            for $LocationCode in $AddressInformation/ns-1:LocationCode
                                                                            return
                                                                                <ns0:LocationCode Domain = "{ data($LocationCode/@Domain) }">{ data($LocationCode) }</ns0:LocationCode>
                                                                        }
                                                                        {
                                                                            for $Comment in $AddressInformation/ns-1:Comment
                                                                            return
                                                                                <ns0:Comment>
                                                                                    <ns0:Content>{ data($Comment/ns-1:Content) }</ns0:Content>
                                                                                    <ns0:ExternalReference>{ data($Comment/ns-1:ExternalReference) }</ns0:ExternalReference>
                                                                                </ns0:Comment>
                                                                        }
                                                                    </ns0:AddressInformation>
                                                            }
                                                            {
                                                                for $TaxInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:TaxInformation
                                                                return
                                                                    <ns0:TaxInformation/>
                                                            }
                                                            {
                                                                for $URL in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:URL
                                                                return
                                                                    <ns0:URL>{ data($URL) }</ns0:URL>
                                                            }
                                                            {
                                                                for $PartnerReference in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerReference
                                                                return
                                                                    <ns0:PartnerReference/>
                                                            }
                                                            {
                                                                for $LoadingPoint in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:LoadingPoint
                                                                return
                                                                    <ns0:LoadingPoint/>
                                                            }
                                                            {
                                                                for $UnloadingPoint in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:UnloadingPoint
                                                                return
                                                                    <ns0:UnloadingPoint/>
                                                            }
                                                            {
                                                                for $AccountInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:AccountInformation
                                                                return
                                                                    <ns0:AccountInformation/>
                                                            }
                                                        </ns0:PartnerInformation>
                                                    </ns0:Buyer>
                                                    <ns0:Seller>
                                                        <ns0:PartnerInformation>
                                                            {
                                                                for $PartnerName in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerName
                                                                return
                                                                    <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                                                            }
                                                            <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                                                            {
                                                                for $ContactInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:ContactInformation
                                                                return
                                                                    <ns0:ContactInformation>
                                                                        {
                                                                            for $ContactName in $ContactInformation/ns-1:ContactName
                                                                            return
                                                                                <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                                                        }
                                                                        {
                                                                            for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                                                            return
                                                                                <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                                                        }
                                                                        {
                                                                            for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                                                            return
                                                                                <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                                                        }
                                                                        {
                                                                            for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                                                            return
                                                                                <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                                                        }
                                                                        {
                                                                            for $AlternativeCommunicationMethod in $ContactInformation/ns-1:AlternativeCommunicationMethod
                                                                            return
                                                                                <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns0:AlternativeCommunicationMethod>
                                                                        }
                                                                    </ns0:ContactInformation>
                                                            }
                                                            {
                                                                for $AddressInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:AddressInformation
                                                                return
                                                                    <ns0:AddressInformation>
                                                                        {
                                                                            for $AddressLine in $AddressInformation/ns-1:AddressLine
                                                                            return
                                                                                <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                                                        }
                                                                        {
                                                                            for $PostBoxNumber in $AddressInformation/ns-1:PostBoxNumber
                                                                            return
                                                                                <ns0:PostBoxNumber>{ data($PostBoxNumber) }</ns0:PostBoxNumber>
                                                                        }
                                                                        (:comment <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                                                                        <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                                                        {
                                                                            for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                                                            return
                                                                                <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                                                        }
                                                                        {
                                                                            for $PostalCode in $AddressInformation/ns-1:PostalCode
                                                                            return
                                                                                <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                                                        }
                                                                        <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                                                        {
                                                                            for $LocationCode in $AddressInformation/ns-1:LocationCode
                                                                            return
                                                                                <ns0:LocationCode Domain = "{ data($LocationCode/@Domain) }">{ data($LocationCode) }</ns0:LocationCode>
                                                                        }
                                                                        {
                                                                            for $Comment in $AddressInformation/ns-1:Comment
                                                                            return
                                                                                <ns0:Comment>
                                                                                    <ns0:Content>{ data($Comment/ns-1:Content) }</ns0:Content>
                                                                                    <ns0:ExternalReference>{ data($Comment/ns-1:ExternalReference) }</ns0:ExternalReference>
                                                                                </ns0:Comment>
                                                                        }
                                                                    </ns0:AddressInformation>
                                                            }
                                                            {
                                                                for $TaxInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:TaxInformation
                                                                return
                                                                    <ns0:TaxInformation/>
                                                            }
                                                            {
                                                                for $URL in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:URL
                                                                return
                                                                    <ns0:URL>{ data($URL) }</ns0:URL>
                                                            }
                                                            {
                                                                for $PartnerReference in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerReference
                                                                return
                                                                    <ns0:PartnerReference/>
                                                            }
                                                            {
                                                                for $LoadingPoint in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:LoadingPoint
                                                                return
                                                                    <ns0:LoadingPoint/>
                                                            }
                                                            {
                                                                for $UnloadingPoint in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:UnloadingPoint
                                                                return
                                                                    <ns0:UnloadingPoint/>
                                                            }
                                                            {
                                                                for $AccountInformation in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:AccountInformation
                                                                return
                                                                    <ns0:AccountInformation/>
                                                            }
                                                        </ns0:PartnerInformation>
                                                    </ns0:Seller>
                                                    {
                                                        for $OtherPartner in $ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:OtherPartner
                                                        return
                                                            <ns0:OtherPartner PartnerRole = "{ data($OtherPartner/@PartnerRole) }">
                                                                <ns0:PartnerInformation>
                                                                    {
                                                                        for $PartnerName in $OtherPartner/ns-1:PartnerInformation/ns-1:PartnerName
                                                                        return
                                                                            <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                                                                    }
                                                                    <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($OtherPartner/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($OtherPartner/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                                                                    <ns0:ContactInformation>
                                                                        {
                                                                            for $ContactName in $OtherPartner/ns-1:PartnerInformation/ns-1:ContactInformation[1]/ns-1:ContactName
                                                                            return
                                                                                <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                                                        }
                                                                        {
                                                                            for $ContactDescription in $OtherPartner/ns-1:PartnerInformation/ns-1:ContactInformation[1]/ns-1:ContactDescription
                                                                            return
                                                                                <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                                                        }
                                                                        {
                                                                            for $ContactNumber in $OtherPartner/ns-1:PartnerInformation/ns-1:ContactInformation[1]/ns-1:ContactNumber
                                                                            return
                                                                                <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                                                        }
                                                                        {
                                                                            for $EmailAddress in $OtherPartner/ns-1:PartnerInformation/ns-1:ContactInformation[1]/ns-1:EmailAddress
                                                                            return
                                                                                <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                                                        }
                                                                    </ns0:ContactInformation>
                                                                    {
                                                                        for $AddressInformation in $OtherPartner/ns-1:PartnerInformation/ns-1:AddressInformation
                                                                        return
                                                                            <ns0:AddressInformation>
                                                                                {
                                                                                    for $AddressLine in $AddressInformation/ns-1:AddressLine
                                                                                    return
                                                                                        <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                                                                }
                                                                                {
                                                                                    for $PostBoxNumber in $AddressInformation/ns-1:PostBoxNumber
                                                                                    return
                                                                                        <ns0:PostBoxNumber>{ data($PostBoxNumber) }</ns0:PostBoxNumber>
                                                                                }
                                                                                (:comment <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                                                                                <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                                                                {
                                                                                    for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                                                                    return
                                                                                        <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                                                                }
                                                                                {
                                                                                    for $PostalCode in $AddressInformation/ns-1:PostalCode
                                                                                    return
                                                                                        <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                                                                }
                                                                                <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                                                                {
                                                                                    for $LocationCode in $AddressInformation/ns-1:LocationCode
                                                                                    return
                                                                                        <ns0:LocationCode Domain = "{ data($LocationCode/@Domain) }">{ data($LocationCode) }</ns0:LocationCode>
                                                                                }
                                                                                {
                                                                                    for $Comment in $AddressInformation/ns-1:Comment
                                                                                    return
                                                                                        <ns0:Comment>
                                                                                            <ns0:Content>{ data($Comment/ns-1:Content) }</ns0:Content>
                                                                                            <ns0:ExternalReference>{ data($Comment/ns-1:ExternalReference) }</ns0:ExternalReference>
                                                                                        </ns0:Comment>
                                                                                }
                                                                            </ns0:AddressInformation>
                                                                    }
                                                                    {
                                                                        for $TaxInformation in $OtherPartner/ns-1:PartnerInformation/ns-1:TaxInformation
                                                                        return
                                                                            <ns0:TaxInformation/>
                                                                    }
                                                                    {
                                                                        for $URL in $OtherPartner/ns-1:PartnerInformation/ns-1:URL
                                                                        return
                                                                            <ns0:URL>{ data($URL) }</ns0:URL>
                                                                    }
                                                                    {
                                                                        for $PartnerReference in $OtherPartner/ns-1:PartnerInformation/ns-1:PartnerReference
                                                                        return
                                                                            <ns0:PartnerReference/>
                                                                    }
                                                                    {
                                                                        for $LoadingPoint in $OtherPartner/ns-1:PartnerInformation/ns-1:LoadingPoint
                                                                        return
                                                                            <ns0:LoadingPoint/>
                                                                    }
                                                                    {
                                                                        for $UnloadingPoint in $OtherPartner/ns-1:PartnerInformation/ns-1:UnloadingPoint
                                                                        return
                                                                            <ns0:UnloadingPoint/>
                                                                    }
                                                                    {
                                                                        for $AccountInformation in $OtherPartner/ns-1:PartnerInformation/ns-1:AccountInformation
                                                                        return
                                                                            <ns0:AccountInformation/>
                                                                    }
                                                                </ns0:PartnerInformation>
                                                            </ns0:OtherPartner>
                                                    }
                                                </ns0:ShipNoticePartners>
                                                <ns0:ShipNoticeDetails>
                                                    {
                                                        for $EquipmentDetails in $ShipNoticeBody/ns-1:ShipNoticeDetails/ns-1:EquipmentDetails
                                                        return
                                                            <ns0:EquipmentDetails>
                                                                <ns0:LineNumber>{ data($EquipmentDetails/ns-1:LineNumber) }</ns0:LineNumber>
                                                                {
                                                                    for $ProductLineItemLineNumber in $EquipmentDetails/ns-1:ProductLineItemLineNumber
                                                                    return
                                                                        <ns0:ProductLineItemLineNumber>{ data($ProductLineItemLineNumber) }</ns0:ProductLineItemLineNumber>
                                                                }
                                                                {
                                                                    for $EquipmentIdentifier in $EquipmentDetails/ns-1:EquipmentIdentifier
                                                                    return
                                                                        <ns0:EquipmentIdentifier>{ data($EquipmentIdentifier) }</ns0:EquipmentIdentifier>
                                                                }
                                                                {
                                                                    for $CarrierEquipmentCode in $EquipmentDetails/ns-1:CarrierEquipmentCode
                                                                    return
                                                                        <ns0:CarrierEquipmentCode Domain = "{ data($CarrierEquipmentCode/@Domain) }">{ data($CarrierEquipmentCode) }</ns0:CarrierEquipmentCode>
                                                                }
                                                                {
                                                                    for $EquipmentOwnershipCode in $EquipmentDetails/ns-1:EquipmentOwnershipCode
                                                                    return
                                                                        <ns0:EquipmentOwnershipCode Domain = "{ data($EquipmentOwnershipCode/@Domain) }">{ data($EquipmentOwnershipCode) }</ns0:EquipmentOwnershipCode>
                                                                }
                                                                {
                                                                    for $NumberOfUnits in $EquipmentDetails/ns-1:NumberOfUnits
                                                                    return
                                                                        <ns0:NumberOfUnits>
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NumberOfUnits/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($NumberOfUnits/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($NumberOfUnits/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NumberOfUnits/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:NumberOfUnits>
                                                                }
                                                                {
                                                                    for $SpecialInstructions in $EquipmentDetails/ns-1:SpecialInstructions
                                                                    return
                                                                        <ns0:SpecialInstructions InstructionType = "{ data($SpecialInstructions/@InstructionType) }">{ data($SpecialInstructions) }</ns0:SpecialInstructions>
                                                                }
                                                                {
                                                                    for $Height in $EquipmentDetails/ns-1:Height
                                                                    return
                                                                        <ns0:Height>
                                                                            <ns0:MeasurementInformation>
                                                                                <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($Height/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                    <ns0:Measurement>
                                                                                        <ns0:MeasurementValue>{ data($Height/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                        <ns0:UnitOfMeasureCode Domain = "{ data($Height/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($Height/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                    </ns0:Measurement>
                                                                                </ns0:SpecifiedMeasurement>
                                                                                <ns0:MeasurementRange>
                                                                                    <ns0:MinimumMeasurement>
                                                                                        <ns0:Measurement>
                                                                                            <ns0:MeasurementValue>{ data($Height/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MinimumMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                            <ns0:UnitOfMeasureCode Domain = "{ data($Height/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MinimumMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($Height/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MinimumMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                        </ns0:Measurement>
                                                                                    </ns0:MinimumMeasurement>
                                                                                    <ns0:MaximumMeasurement>
                                                                                        <ns0:Measurement>
                                                                                            <ns0:MeasurementValue>{ data($Height/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MaximumMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                            <ns0:UnitOfMeasureCode Domain = "{ data($Height/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MaximumMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($Height/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MaximumMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                        </ns0:Measurement>
                                                                                    </ns0:MaximumMeasurement>
                                                                                </ns0:MeasurementRange>
                                                                            </ns0:MeasurementInformation>
                                                                        </ns0:Height>
                                                                }
                                                                {
                                                                    for $Width in $EquipmentDetails/ns-1:Width
                                                                    return
                                                                        <ns0:Width>
                                                                            <ns0:MeasurementInformation>
                                                                                <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($Width/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                    <ns0:Measurement>
                                                                                        <ns0:MeasurementValue>{ data($Width/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                        <ns0:UnitOfMeasureCode>{ data($Width/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                    </ns0:Measurement>
                                                                                </ns0:SpecifiedMeasurement>
                                                                            </ns0:MeasurementInformation>
                                                                        </ns0:Width>
                                                                }
                                                                {
                                                                    for $Length in $EquipmentDetails/ns-1:Length
                                                                    return
                                                                        <ns0:Length>
                                                                            <ns0:MeasurementInformation>
                                                                                <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($Length/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                    <ns0:Measurement>
                                                                                        <ns0:MeasurementValue>{ data($Length/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                        <ns0:UnitOfMeasureCode Domain = "{ data($Length/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($Length/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                    </ns0:Measurement>
                                                                                </ns0:SpecifiedMeasurement>
                                                                            </ns0:MeasurementInformation>
                                                                        </ns0:Length>
                                                                }
                                                                {
                                                                    for $NetWeight in $EquipmentDetails/ns-1:NetWeight
                                                                    return
                                                                        <ns0:NetWeight>
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NetWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:NetWeight>
                                                                }
                                                                {
                                                                    for $TareWeight in $EquipmentDetails/ns-1:TareWeight
                                                                    return
                                                                        <ns0:TareWeight TareWeightQualifier = "{ data($TareWeight/@TareWeightQualifier) }">
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($TareWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($TareWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($TareWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($TareWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:TareWeight>
                                                                }
                                                                {
                                                                    for $GrossWeight in $EquipmentDetails/ns-1:GrossWeight
                                                                    return
                                                                        <ns0:GrossWeight>
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:GrossWeight>
                                                                }
                                                                {
                                                                    for $NetVolume in $EquipmentDetails/ns-1:NetVolume
                                                                    return
                                                                        <ns0:NetVolume>
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NetVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:NetVolume>
                                                                }
                                                                {
                                                                    for $GrossVolume in $EquipmentDetails/ns-1:GrossVolume
                                                                    return
                                                                        <ns0:GrossVolume>
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:GrossVolume>
                                                                }
                                                                {
                                                                    for $SealNumber in $EquipmentDetails/ns-1:SealNumber
                                                                    return
                                                                        <ns0:SealNumber>{ data($SealNumber) }</ns0:SealNumber>
                                                                }
                                                                {
                                                                    for $EquipmentLoadEmptyStatus in $EquipmentDetails/ns-1:EquipmentLoadEmptyStatus
                                                                    return
                                                                        <ns0:EquipmentLoadEmptyStatus>{ data($EquipmentLoadEmptyStatus) }</ns0:EquipmentLoadEmptyStatus>
                                                                }
                                                                {
                                                                    for $AssociatedEquipment in $EquipmentDetails/ns-1:AssociatedEquipment
                                                                    where data($AssociatedEquipment/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MaximumMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) = data($AssociatedEquipment/ns-1:MeasurementInformation/ns-1:MeasurementRange/ns-1:MaximumMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode)
                                                                    return
                                                                        <ns0:AssociatedEquipment>
                                                                            <ns0:EquipmentIdentifier>{ data($AssociatedEquipment/ns-1:EquipmentIdentifier) }</ns0:EquipmentIdentifier>
                                                                            {
                                                                                for $NumberOfUnits in $AssociatedEquipment/ns-1:NumberOfUnits
                                                                                return
                                                                                    <ns0:NumberOfUnits>
                                                                                        {
                                                                                            let $SpecifiedMeasurement := $NumberOfUnits/ns-1:SpecifiedMeasurement
                                                                                            return
                                                                                                <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                                    {
                                                                                                        let $Measurement := $SpecifiedMeasurement/ns-1:Measurement
                                                                                                        return
                                                                                                            <ns0:Measurement>
                                                                                                                <ns0:MeasurementValue>{ data($Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                                            </ns0:Measurement>
                                                                                                    }
                                                                                                </ns0:SpecifiedMeasurement>
                                                                                        }
                                                                                    </ns0:NumberOfUnits>
                                                                            }
                                                                            <ns0:MeasurementInformation>
                                                                                <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($AssociatedEquipment/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                    <ns0:Measurement>
                                                                                        <ns0:MeasurementValue>{ data($AssociatedEquipment/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                        <ns0:UnitOfMeasureCode Domain = "{ data($AssociatedEquipment/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($AssociatedEquipment/ns-1:MeasurementInformation/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                    </ns0:Measurement>
                                                                                </ns0:SpecifiedMeasurement>
                                                                            </ns0:MeasurementInformation>
                                                                            {
                                                                                for $SpecialInstructions in $AssociatedEquipment/ns-1:SpecialInstructions
                                                                                return
                                                                                    <ns0:SpecialInstructions InstructionType = "{ data($SpecialInstructions/@InstructionType) }">{ data($SpecialInstructions) }</ns0:SpecialInstructions>
                                                                            }
                                                                        </ns0:AssociatedEquipment>
                                                                }
                                                            </ns0:EquipmentDetails>
                                                    }
                                                    {
                                                        for $ShipNoticeProductLineItem in $ShipNoticeBody/ns-1:ShipNoticeDetails/ns-1:ShipNoticeProductLineItem
                                                        return
                                                            <ns0:ShipNoticeProductLineItem>
                                                                <ns0:LineNumber>{ data($ShipNoticeProductLineItem/ns-1:LineNumber) }</ns0:LineNumber>
                                                                {
                                                                    for $EquipmentDetailsLineNumber in $ShipNoticeProductLineItem/ns-1:EquipmentDetailsLineNumber
                                                                    return
                                                                        <ns0:EquipmentDetailsLineNumber>{ data($EquipmentDetailsLineNumber) }</ns0:EquipmentDetailsLineNumber>
                                                                }
                                                                {
                                                                    for $ProductIdentification in $ShipNoticeProductLineItem/ns-1:ProductIdentification
                                                                    return
                                                                        <ns0:ProductIdentification>
                                                                            <ns0:ProductIdentifier Agency = "{ data($ProductIdentification/ns-1:ProductIdentifier/@Agency) }">{ data($ProductIdentification/ns-1:ProductIdentifier) }</ns0:ProductIdentifier>
                                                                            {
                                                                                for $ProductName in $ProductIdentification/ns-1:ProductName
                                                                                return
                                                                                    <ns0:ProductName>{ data($ProductName) }</ns0:ProductName>
                                                                            }
                                                                            {
                                                                                for $Trademark in $ProductIdentification/ns-1:Trademark
                                                                                return
                                                                                    <ns0:Trademark>{ data($Trademark) }</ns0:Trademark>
                                                                            }
                                                                            {
                                                                                for $ProductDescription in $ProductIdentification/ns-1:ProductDescription
                                                                                return
                                                                                    <ns0:ProductDescription>{ data($ProductDescription) }</ns0:ProductDescription>
                                                                            }
                                                                            {
                                                                                for $ProductGradeDescription in $ProductIdentification/ns-1:ProductGradeDescription
                                                                                return
                                                                                    <ns0:ProductGradeDescription>{ data($ProductGradeDescription) }</ns0:ProductGradeDescription>
                                                                            }
                                                                            {
                                                                                for $ProductClassification in $ProductIdentification/ns-1:ProductClassification
                                                                                return
                                                                                    <ns0:ProductClassification>{ data($ProductClassification) }</ns0:ProductClassification>
                                                                            }
                                                                        </ns0:ProductIdentification>
                                                                }
                                                                <ns0:ShippedQuantity>
                                                                    <ns0:Measurement>
                                                                        <ns0:MeasurementValue>{ data($ShipNoticeProductLineItem/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                        <ns0:UnitOfMeasureCode Domain = "{ data($ShipNoticeProductLineItem/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($ShipNoticeProductLineItem/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                    </ns0:Measurement>
                                                                </ns0:ShippedQuantity>
                                                                {
                                                                    for $InvoiceQuantity in $ShipNoticeProductLineItem/ns-1:InvoiceQuantity
                                                                    return
                                                                        <ns0:InvoiceQuantity>
                                                                            <ns0:Measurement>
                                                                                <ns0:MeasurementValue>{ data($InvoiceQuantity/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($InvoiceQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($InvoiceQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                            </ns0:Measurement>
                                                                        </ns0:InvoiceQuantity>
                                                                }
                                                                {
                                                                    for $PurchaseOrderInformation in $ShipNoticeProductLineItem/ns-1:PurchaseOrderInformation
                                                                    return
                                                                        <ns0:PurchaseOrderInformation>
                                                                            <ns0:DocumentReference>
                                                                                <ns0:DocumentIdentifier>{ data($PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                                                (:comment <ns0:DateTime DateTimeQualifier = "{ data($PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DateTime/@DateTimeQualifier) }">{ data($PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DateTime) }</ns0:DateTime> :)
                                                                                {
                                                                                    for $ReferenceItem in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                                    return
                                                                                        <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                                                }
                                                                                {
                                                                                    for $ReleaseNumber in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                                    return
                                                                                        <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                                                }
                                                                            </ns0:DocumentReference>
                                                                        </ns0:PurchaseOrderInformation>
                                                                }
                                                                {
                                                                    for $CumulativeTotalQuantity in $ShipNoticeProductLineItem/ns-1:CumulativeTotalQuantity
                                                                    return
                                                                        <ns0:CumulativeTotalQuantity>
                                                                            <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($CumulativeTotalQuantity/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($CumulativeTotalQuantity/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($CumulativeTotalQuantity/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($CumulativeTotalQuantity/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:SpecifiedMeasurement>
                                                                        </ns0:CumulativeTotalQuantity>
                                                                }
                                                                {
                                                                    for $ShipmentMethodOfPaymentCode in $ShipNoticeProductLineItem/ns-1:ShipmentMethodOfPaymentCode
                                                                    return
                                                                        <ns0:ShipmentMethodOfPaymentCode Domain = "{ data($ShipmentMethodOfPaymentCode/@Domain) }">{ data($ShipmentMethodOfPaymentCode) }</ns0:ShipmentMethodOfPaymentCode>
                                                                }
                                                                {
                                                                    for $DeliveryTerms in $ShipNoticeProductLineItem/ns-1:DeliveryTerms
                                                                    return
                                                                        <ns0:DeliveryTerms>
                                                                            <ns0:DeliveryTermsCode Domain = "{ data($DeliveryTerms/ns-1:DeliveryTermsCode/@Domain) }">{ data($DeliveryTerms/ns-1:DeliveryTermsCode) }</ns0:DeliveryTermsCode>
                                                                            <ns0:DeliveryTermsLocation>{ data($DeliveryTerms/ns-1:DeliveryTermsLocation) }</ns0:DeliveryTermsLocation>
                                                                        </ns0:DeliveryTerms>
                                                                }
                                                                {
                                                                    for $ReferenceInformation in $ShipNoticeProductLineItem/ns-1:ReferenceInformation
                                                                    return
                                                                        <ns0:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                                                            <ns0:DocumentReference>
                                                                                <ns0:DocumentIdentifier>{ data($ReferenceInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                                                (:comment <ns0:DateTime DateTimeQualifier = "{ data($ReferenceInformation/ns-1:DocumentReference/ns-1:DateTime/@DateTimeQualifier) }">{ data($ReferenceInformation/ns-1:DocumentReference/ns-1:DateTime) }</ns0:DateTime> :)
                                                                                {
                                                                                    for $ReferenceItem in $ReferenceInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                                                                    return
                                                                                        <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                                                }
                                                                                {
                                                                                    for $ReleaseNumber in $ReferenceInformation/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                                                    return
                                                                                        <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                                                }
                                                                            </ns0:DocumentReference>
                                                                        </ns0:ReferenceInformation>
                                                                }
                                                                {
                                                                    for $ShipmentIndicatorCode in $ShipNoticeProductLineItem/ns-1:ShipmentIndicatorCode
                                                                    return
                                                                        <ns0:ShipmentIndicatorCode Domain = "{ data($ShipmentIndicatorCode/@Domain) }">{ data($ShipmentIndicatorCode) }</ns0:ShipmentIndicatorCode>
                                                                }
                                                                {
                                                                    for $PercentActive in $ShipNoticeProductLineItem/ns-1:PercentActive
                                                                    return
                                                                        <ns0:PercentActive>{ data($PercentActive) }</ns0:PercentActive>
                                                                }
                                                                {
                                                                    for $SpecialInstructions in $ShipNoticeProductLineItem/ns-1:SpecialInstructions
                                                                    return
                                                                        <ns0:SpecialInstructions InstructionType = "{ data($SpecialInstructions/@InstructionType) }">{ data($SpecialInstructions) }</ns0:SpecialInstructions>
                                                                }
                                                                {
                                                                    for $InventoryLocation in $ShipNoticeProductLineItem/ns-1:InventoryLocation
                                                                    return
                                                                        <ns0:InventoryLocation>
                                                                            <ns0:Company>{ data($InventoryLocation/ns-1:Company) }</ns0:Company>
                                                                            {
                                                                                for $Plant in $InventoryLocation/ns-1:Plant
                                                                                return
                                                                                    <ns0:Plant>{ data($Plant) }</ns0:Plant>
                                                                            }
                                                                            {
                                                                                for $StorageLocation in $InventoryLocation/ns-1:StorageLocation
                                                                                return
                                                                                    <ns0:StorageLocation>{ data($StorageLocation) }</ns0:StorageLocation>
                                                                            }
                                                                        </ns0:InventoryLocation>
                                                                }
                                                                {
                                                                    for $ProductSubLineItems in $ShipNoticeProductLineItem/ns-1:ProductSubLineItems
                                                                    return
                                                                        <ns0:ProductSubLineItems>
                                                                            <ns0:SubLineItemNumber>{ data($ProductSubLineItems/ns-1:SubLineItemNumber) }</ns0:SubLineItemNumber>
                                                                            {
                                                                                for $ManufacturingIdentificationDetails in $ProductSubLineItems/ns-1:ManufacturingIdentificationDetails
                                                                                return
                                                                                    <ns0:ManufacturingIdentificationDetails>
                                                                                        <ns0:ManufacturingIdentificationType>{ data($ManufacturingIdentificationDetails/ns-1:ManufacturingIdentificationType) }</ns0:ManufacturingIdentificationType>
                                                                                        <ns0:ManufacturingIdentificationNumber>{ data($ManufacturingIdentificationDetails/ns-1:ManufacturingIdentificationNumber) }</ns0:ManufacturingIdentificationNumber>
                                                                                        {
                                                                                            for $ParentManufacturingIdentificationNumber in $ManufacturingIdentificationDetails/ns-1:ParentManufacturingIdentificationNumber
                                                                                            return
                                                                                                <ns0:ParentManufacturingIdentificationNumber>{ data($ParentManufacturingIdentificationNumber) }</ns0:ParentManufacturingIdentificationNumber>
                                                                                        }
                                                                                    </ns0:ManufacturingIdentificationDetails>
                                                                            }
                                                                            {
                                                                                for $GrossVolume in $ProductSubLineItems/ns-1:GrossVolume
                                                                                return
                                                                                    <ns0:GrossVolume>
                                                                                        <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                            <ns0:Measurement>
                                                                                                <ns0:MeasurementValue>{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                            </ns0:Measurement>
                                                                                        </ns0:SpecifiedMeasurement>
                                                                                    </ns0:GrossVolume>
                                                                            }
                                                                            {
                                                                                for $NetVolume in $ProductSubLineItems/ns-1:NetVolume
                                                                                return
                                                                                    <ns0:NetVolume>
                                                                                        <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NetVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                            <ns0:Measurement>
                                                                                                <ns0:MeasurementValue>{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                            </ns0:Measurement>
                                                                                        </ns0:SpecifiedMeasurement>
                                                                                    </ns0:NetVolume>
                                                                            }
                                                                            {
                                                                                for $GrossWeight in $ProductSubLineItems/ns-1:GrossWeight
                                                                                return
                                                                                    <ns0:GrossWeight>
                                                                                        <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                            <ns0:Measurement>
                                                                                                <ns0:MeasurementValue>{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                            </ns0:Measurement>
                                                                                        </ns0:SpecifiedMeasurement>
                                                                                    </ns0:GrossWeight>
                                                                            }
                                                                            {
                                                                                for $NetWeight in $ProductSubLineItems/ns-1:NetWeight
                                                                                return
                                                                                    <ns0:NetWeight>
                                                                                        <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NetWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                            <ns0:Measurement>
                                                                                                <ns0:MeasurementValue>{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                            </ns0:Measurement>
                                                                                        </ns0:SpecifiedMeasurement>
                                                                                    </ns0:NetWeight>
                                                                            }
                                                                            {
                                                                                for $InventoryLocation in $ProductSubLineItems/ns-1:InventoryLocation
                                                                                return
                                                                                    <ns0:InventoryLocation>
                                                                                        <ns0:Company>{ data($InventoryLocation/ns-1:Company) }</ns0:Company>
                                                                                        {
                                                                                            for $Plant in $InventoryLocation/ns-1:Plant
                                                                                            return
                                                                                                <ns0:Plant>{ data($Plant) }</ns0:Plant>
                                                                                        }
                                                                                        {
                                                                                            for $StorageLocation in $InventoryLocation/ns-1:StorageLocation
                                                                                            return
                                                                                                <ns0:StorageLocation>{ data($StorageLocation) }</ns0:StorageLocation>
                                                                                        }
                                                                                    </ns0:InventoryLocation>
                                                                            }
                                                                        </ns0:ProductSubLineItems>
                                                                }
                                                                {
                                                                    for $ShippingServiceLevelCode in $ShipNoticeProductLineItem/ns-1:ShippingServiceLevelCode
                                                                    return
                                                                        <ns0:ShippingServiceLevelCode Domain = "{ data($ShippingServiceLevelCode/@Domain) }">{ data($ShippingServiceLevelCode) }</ns0:ShippingServiceLevelCode>
                                                                }
                                                            </ns0:ShipNoticeProductLineItem>
                                                    }
                                                    {
                                                        for $ShipmentPackaging in $ShipNoticeBody/ns-1:ShipNoticeDetails/ns-1:ShipmentPackaging
                                                        return
                                                            <ns0:ShipmentPackaging>
                                                                <ns0:LineNumber>{ data($ShipmentPackaging/ns-1:LineNumber) }</ns0:LineNumber>
                                                                {
                                                                    for $PackagingItems in $ShipmentPackaging/ns-1:PackagingItems
                                                                    return
                                                                        <ns0:PackagingItems>
                                                                            <ns0:ProductLineItemLineNumber>{ data($PackagingItems/ns-1:ProductLineItemLineNumber) }</ns0:ProductLineItemLineNumber>
                                                                            <ns0:ShippedQuantity>
                                                                                <ns0:Measurement>
                                                                                    <ns0:MeasurementValue>{ data($PackagingItems/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                    <ns0:UnitOfMeasureCode Domain = "{ data($PackagingItems/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($PackagingItems/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                </ns0:Measurement>
                                                                            </ns0:ShippedQuantity>
                                                                            {
                                                                                for $ProductSubLineItems in $PackagingItems/ns-1:ProductSubLineItems
                                                                                return
                                                                                    <ns0:ProductSubLineItems>
                                                                                        <ns0:SubLineItemNumber>{ data($ProductSubLineItems/ns-1:SubLineItemNumber) }</ns0:SubLineItemNumber>
                                                                                        {
                                                                                            for $ManufacturingIdentificationDetails in $ProductSubLineItems/ns-1:ManufacturingIdentificationDetails
                                                                                            return
                                                                                                <ns0:ManufacturingIdentificationDetails>
                                                                                                    <ns0:ManufacturingIdentificationType>{ data($ManufacturingIdentificationDetails/ns-1:ManufacturingIdentificationType) }</ns0:ManufacturingIdentificationType>
                                                                                                    <ns0:ManufacturingIdentificationNumber>{ data($ManufacturingIdentificationDetails/ns-1:ManufacturingIdentificationNumber) }</ns0:ManufacturingIdentificationNumber>
                                                                                                    {
                                                                                                        for $ParentManufacturingIdentificationNumber in $ManufacturingIdentificationDetails/ns-1:ParentManufacturingIdentificationNumber
                                                                                                        return
                                                                                                            <ns0:ParentManufacturingIdentificationNumber>{ data($ParentManufacturingIdentificationNumber) }</ns0:ParentManufacturingIdentificationNumber>
                                                                                                    }
                                                                                                </ns0:ManufacturingIdentificationDetails>
                                                                                        }
                                                                                        {
                                                                                            for $GrossVolume in $ProductSubLineItems/ns-1:GrossVolume
                                                                                            return
                                                                                                <ns0:GrossVolume>
                                                                                                    <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                                        <ns0:Measurement>
                                                                                                            <ns0:MeasurementValue>{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                            <ns0:UnitOfMeasureCode Domain = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                                        </ns0:Measurement>
                                                                                                    </ns0:SpecifiedMeasurement>
                                                                                                </ns0:GrossVolume>
                                                                                        }
                                                                                        {
                                                                                            for $NetVolume in $ProductSubLineItems/ns-1:NetVolume
                                                                                            return
                                                                                                <ns0:NetVolume>
                                                                                                    <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NetVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                                        <ns0:Measurement>
                                                                                                            <ns0:MeasurementValue>{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                            <ns0:UnitOfMeasureCode Domain = "{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NetVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                                        </ns0:Measurement>
                                                                                                    </ns0:SpecifiedMeasurement>
                                                                                                </ns0:NetVolume>
                                                                                        }
                                                                                        {
                                                                                            for $GrossWeight in $ProductSubLineItems/ns-1:GrossWeight
                                                                                            return
                                                                                                <ns0:GrossWeight>
                                                                                                    <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                                        <ns0:Measurement>
                                                                                                            <ns0:MeasurementValue>{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                            <ns0:UnitOfMeasureCode Domain = "{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                                        </ns0:Measurement>
                                                                                                    </ns0:SpecifiedMeasurement>
                                                                                                </ns0:GrossWeight>
                                                                                        }
                                                                                        {
                                                                                            for $NetWeight in $ProductSubLineItems/ns-1:NetWeight
                                                                                            return
                                                                                                <ns0:NetWeight>
                                                                                                    <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($NetWeight/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
                                                                                                        <ns0:Measurement>
                                                                                                            <ns0:MeasurementValue>{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                                            <ns0:UnitOfMeasureCode Domain = "{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($NetWeight/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                                                        </ns0:Measurement>
                                                                                                    </ns0:SpecifiedMeasurement>
                                                                                                </ns0:NetWeight>
                                                                                        }
                                                                                        {
                                                                                            for $InventoryLocation in $ProductSubLineItems/ns-1:InventoryLocation
                                                                                            return
                                                                                                <ns0:InventoryLocation>
                                                                                                    <ns0:Company>{ data($InventoryLocation/ns-1:Company) }</ns0:Company>
                                                                                                    {
                                                                                                        for $Plant in $InventoryLocation/ns-1:Plant
                                                                                                        return
                                                                                                            <ns0:Plant>{ data($Plant) }</ns0:Plant>
                                                                                                    }
                                                                                                    {
                                                                                                        for $StorageLocation in $InventoryLocation/ns-1:StorageLocation
                                                                                                        return
                                                                                                            <ns0:StorageLocation>{ data($StorageLocation) }</ns0:StorageLocation>
                                                                                                    }
                                                                                                </ns0:InventoryLocation>
                                                                                        }
                                                                                    </ns0:ProductSubLineItems>
                                                                            }
                                                                        </ns0:PackagingItems>
                                                                }
                                                                <ns0:PackagingTypeCode Domain = "{ data($ShipmentPackaging/ns-1:PackagingTypeCode/@Domain) }">{ data($ShipmentPackaging/ns-1:PackagingTypeCode) }</ns0:PackagingTypeCode>
                                                                <ns0:PackagingQuantity>
                                                                    <ns0:Measurement>
                                                                        <ns0:MeasurementValue>{ data($ShipmentPackaging/ns-1:PackagingQuantity/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                        <ns0:UnitOfMeasureCode Domain = "{ data($ShipmentPackaging/ns-1:PackagingQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($ShipmentPackaging/ns-1:PackagingQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                    </ns0:Measurement>
                                                                </ns0:PackagingQuantity>
                                                                <ns0:PackagingWeight>
                                                                    <ns0:Measurement>
                                                                        <ns0:MeasurementValue>{ data($ShipmentPackaging/ns-1:PackagingWeight/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                        <ns0:UnitOfMeasureCode Domain = "{ data($ShipmentPackaging/ns-1:PackagingWeight/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($ShipmentPackaging/ns-1:PackagingWeight/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                    </ns0:Measurement>
                                                                </ns0:PackagingWeight>
                                                                {
                                                                    for $PackagingVolume in $ShipmentPackaging/ns-1:PackagingVolume
                                                                    return
                                                                        <ns0:PackagingVolume>
                                                                            <ns0:Measurement>
                                                                                <ns0:MeasurementValue>{ data($PackagingVolume/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                                                                <ns0:UnitOfMeasureCode Domain = "{ data($PackagingVolume/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($PackagingVolume/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                                                            </ns0:Measurement>
                                                                        </ns0:PackagingVolume>
                                                                }
                                                                {
                                                                    for $PackagingDimensions in $ShipmentPackaging/ns-1:PackagingDimensions
                                                                    return
                                                                        <ns0:PackagingDimensions>
                                                                            {
                                                                                for $Height in $PackagingDimensions/ns-1:Height
                                                                                return
                                                                                    <ns0:Height/>
                                                                            }
                                                                            {
                                                                                for $Length in $PackagingDimensions/ns-1:Length
                                                                                return
                                                                                    <ns0:Length/>
                                                                            }
                                                                            {
                                                                                for $Width in $PackagingDimensions/ns-1:Width
                                                                                return
                                                                                    <ns0:Width/>
                                                                            }
                                                                        </ns0:PackagingDimensions>
                                                                }
                                                                {
                                                                    for $PackagingDisposition in $ShipmentPackaging/ns-1:PackagingDisposition
                                                                    return
                                                                        <ns0:PackagingDisposition>{ data($PackagingDisposition) }</ns0:PackagingDisposition>
                                                                }
                                                                {
                                                                    for $ShippingLabelInformation in $ShipmentPackaging/ns-1:ShippingLabelInformation
                                                                    return
                                                                        <ns0:ShippingLabelInformation>
                                                                            {
                                                                                for $ShippingLabelNumber in $ShippingLabelInformation/ns-1:ShippingLabelNumber
                                                                                return
                                                                                    <ns0:ShippingLabelNumber BarCodeSymbology = "{ data($ShippingLabelNumber/@BarCodeSymbology) }">{ data($ShippingLabelNumber) }</ns0:ShippingLabelNumber>
                                                                            }
                                                                            {
                                                                                for $BarCodeDataIdentifier in $ShippingLabelInformation/ns-1:BarCodeDataIdentifier
                                                                                return
                                                                                    <ns0:BarCodeDataIdentifier>{ data($BarCodeDataIdentifier) }</ns0:BarCodeDataIdentifier>
                                                                            }
                                                                        </ns0:ShippingLabelInformation>
                                                                }
                                                                {
                                                                    for $ContainerSerialInformation in $ShipmentPackaging/ns-1:ContainerSerialInformation
                                                                    return
                                                                        <ns0:ContainerSerialInformation>
                                                                            {
                                                                                for $ContainerSerialNumber in $ContainerSerialInformation/ns-1:ContainerSerialNumber
                                                                                return
                                                                                    <ns0:ContainerSerialNumber BarCodeSymbology = "{ data($ContainerSerialNumber/@BarCodeSymbology) }">{ data($ContainerSerialNumber) }</ns0:ContainerSerialNumber>
                                                                            }
                                                                            {
                                                                                for $BarCodeDataIdentifier in $ContainerSerialInformation/ns-1:BarCodeDataIdentifier
                                                                                return
                                                                                    <ns0:BarCodeDataIdentifier>{ data($BarCodeDataIdentifier) }</ns0:BarCodeDataIdentifier>
                                                                            }
                                                                        </ns0:ContainerSerialInformation>
                                                                }
                                                                {
                                                                    for $PackagingStackability in $ShipmentPackaging/ns-1:PackagingStackability
                                                                    return
                                                                        <ns0:PackagingStackability>{ data($PackagingStackability) }</ns0:PackagingStackability>
                                                                }
                                                                {
                                                                    for $ShipmentPackaging0 in $ShipmentPackaging/ns-1:ShipmentPackaging
                                                                    return
                                                                        <ns0:ShipmentPackaging>
                                                                            <ns0:LineNumber>{ data($ShipmentPackaging0/ns-1:LineNumber) }</ns0:LineNumber>
                                                                            {
                                                                                for $PackagingItems in $ShipmentPackaging0/ns-1:PackagingItems
                                                                                return
                                                                                    <ns0:PackagingItems/>
                                                                            }
                                                                            <ns0:PackagingTypeCode>{ data($ShipmentPackaging0/ns-1:PackagingTypeCode) }</ns0:PackagingTypeCode>
                                                                            {
                                                                                for $PackagingVolume in $ShipmentPackaging0/ns-1:PackagingVolume
                                                                                return
                                                                                    <ns0:PackagingVolume/>
                                                                            }
                                                                            {
                                                                                for $PackagingDimensions in $ShipmentPackaging0/ns-1:PackagingDimensions
                                                                                return
                                                                                    <ns0:PackagingDimensions/>
                                                                            }
                                                                            {
                                                                                for $PackagingDisposition in $ShipmentPackaging0/ns-1:PackagingDisposition
                                                                                return
                                                                                    <ns0:PackagingDisposition>{ data($PackagingDisposition) }</ns0:PackagingDisposition>
                                                                            }
                                                                            {
                                                                                for $ShippingLabelInformation in $ShipmentPackaging0/ns-1:ShippingLabelInformation
                                                                                return
                                                                                    <ns0:ShippingLabelInformation/>
                                                                            }
                                                                            {
                                                                                for $ContainerSerialInformation in $ShipmentPackaging0/ns-1:ContainerSerialInformation
                                                                                return
                                                                                    <ns0:ContainerSerialInformation/>
                                                                            }
                                                                            {
                                                                                for $PackagingStackability in $ShipmentPackaging0/ns-1:PackagingStackability
                                                                                return
                                                                                    <ns0:PackagingStackability>{ data($PackagingStackability) }</ns0:PackagingStackability>
                                                                            }
                                                                            {
                                                                                for $ShipmentPackaging1 in $ShipmentPackaging0/ns-1:ShipmentPackaging
                                                                                return
                                                                                    <ns0:ShipmentPackaging/>
                                                                            }
                                                                        </ns0:ShipmentPackaging>
                                                                }
                                                            </ns0:ShipmentPackaging>
                                                    }
                                                </ns0:ShipNoticeDetails>
                                            </ns0:ShipNoticeBody>
                                    }
                                </ns0:ShipNoticeListDetails>
                        }
                    </ns0:ShipNoticeListBody>
            }
        </ns0:ShipNoticeList>
};

declare function local:getAgencyCode(
$actual as xs:string?) as xs:string?
{
  let $retVal := if ($actual = "EAN") then "GLN" else $actual
  return $retVal  
};

declare variable $shipNoticeList1 as element(ns1:ShipNoticeList) external;

xf:EDN_ShipNoticeList_4-0_To_5-0($shipNoticeList1)