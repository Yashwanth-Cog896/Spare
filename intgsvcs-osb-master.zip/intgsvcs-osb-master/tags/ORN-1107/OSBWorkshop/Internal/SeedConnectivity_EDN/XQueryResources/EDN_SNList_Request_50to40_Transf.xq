declare namespace xf = "http://tempuri.org/Samples/XQueryTransformations/EDN_SNListReq_50_To_40/";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:4:0";
declare namespace ns1 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace ns-1 = "urn:ecms:schema:shipnotice:request:1:0";

declare function xf:EDN_SNListReq_50_To_40($shipNoticeListRequest1 as element(ns1:ShipNoticeListRequest))
    as element(ns-1:ShipNoticeListRequest) {
        <ns-1:ShipNoticeListRequest Version = "1.0" xmlns:cidx="urn:cidx:names:specification:ces:schema:all:4:0">
            <ns0:Header>
                {
                    let $ThisDocumentIdentifier := $shipNoticeListRequest1/ns1:Header/ns1:ThisDocumentIdentifier
                    return
                        <ns0:ThisDocumentIdentifier>
                            <ns0:DocumentIdentifier>{ data($ThisDocumentIdentifier/ns1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                        </ns0:ThisDocumentIdentifier>
                }
                {
                    let $ThisDocumentDateTime := $shipNoticeListRequest1/ns1:Header/ns1:ThisDocumentDateTime
                    return
                        <ns0:ThisDocumentDateTime>
                            <ns0:DateTime DateTimeQualifier = "{ data($ThisDocumentDateTime/ns1:DateTime/@DateTimeQualifier) }">{ data($ThisDocumentDateTime/ns1:DateTime) }</ns0:DateTime>
                        </ns0:ThisDocumentDateTime>
                }
                <ns0:From>
                    <ns0:PartnerInformation>
                        {
                            for $PartnerName in $shipNoticeListRequest1/ns1:Header/ns1:From/ns1:PartnerInformation/ns1:PartnerName
                            return
                                <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                        }
                        <ns0:PartnerIdentifier Agency = "{ data($shipNoticeListRequest1/ns1:Header/ns1:From/ns1:PartnerInformation/ns1:PartnerIdentifier[1]/@Agency) }">{ data($shipNoticeListRequest1/ns1:Header/ns1:From/ns1:PartnerInformation/ns1:PartnerIdentifier[1]) }</ns0:PartnerIdentifier>
                        {
                            for $ContactInformation in $shipNoticeListRequest1/ns1:Header/ns1:From/ns1:PartnerInformation/ns1:ContactInformation
                            return
                                <ns0:ContactInformation>
                                    {
                                        for $ContactName in $ContactInformation/ns1:ContactName
                                        return
                                            <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                    }
                                    {
                                        for $ContactDescription in $ContactInformation/ns1:ContactDescription
                                        return
                                            <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                    }
                                </ns0:ContactInformation>
                        }
                    </ns0:PartnerInformation>
                </ns0:From>
                <ns0:To>
                    <ns0:PartnerInformation>
                        {
                            for $PartnerName in $shipNoticeListRequest1/ns1:Header/ns1:To/ns1:PartnerInformation/ns1:PartnerName
                            return
                                <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                        }
                        <ns0:PartnerIdentifier Agency = "{ data($shipNoticeListRequest1/ns1:Header/ns1:To/ns1:PartnerInformation/ns1:PartnerIdentifier[1]/@Agency) }">{ data($shipNoticeListRequest1/ns1:Header/ns1:To/ns1:PartnerInformation/ns1:PartnerIdentifier[1]) }</ns0:PartnerIdentifier>
                    </ns0:PartnerInformation>
                </ns0:To>
            </ns0:Header>
            <ns-1:ShipNoticeListRequestBody>
                {
                    let $ShipNoticeListRequestProperties := $shipNoticeListRequest1/ns1:ShipNoticeListRequestBody/ns1:ShipNoticeListRequestProperties
                    return
                        <ns-1:ShipNoticeListRequestProperties/>
                }
                <ns-1:ShipNoticeListRequestPartners>
                    <ns0:Seller>
                        <ns0:PartnerInformation>
                            {
                                for $PartnerName in $shipNoticeListRequest1/ns1:ShipNoticeListRequestBody/ns1:ShipNoticeListRequestPartners/ns1:Seller/ns1:PartnerInformation/ns1:PartnerName
                                return
                                    <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                            }
                            <ns0:PartnerIdentifier Agency = "{ data($shipNoticeListRequest1/ns1:ShipNoticeListRequestBody/ns1:ShipNoticeListRequestPartners/ns1:Seller/ns1:PartnerInformation/ns1:PartnerIdentifier[1]/@Agency) }">{ data($shipNoticeListRequest1/ns1:ShipNoticeListRequestBody/ns1:ShipNoticeListRequestPartners/ns1:Seller/ns1:PartnerInformation/ns1:PartnerIdentifier[1]) }</ns0:PartnerIdentifier>
                        </ns0:PartnerInformation>
                    </ns0:Seller>
                </ns-1:ShipNoticeListRequestPartners>
                {
                    let $ShipNoticeListRequestDetails := $shipNoticeListRequest1/ns1:ShipNoticeListRequestBody/ns1:ShipNoticeListRequestDetails
                    return
                        <ns-1:ShipNoticeListRequestDetails/>
                }
            </ns-1:ShipNoticeListRequestBody>
        </ns-1:ShipNoticeListRequest>
};

declare variable $shipNoticeListRequest1 as element(ns1:ShipNoticeListRequest) external;

xf:EDN_SNListReq_50_To_40($shipNoticeListRequest1)