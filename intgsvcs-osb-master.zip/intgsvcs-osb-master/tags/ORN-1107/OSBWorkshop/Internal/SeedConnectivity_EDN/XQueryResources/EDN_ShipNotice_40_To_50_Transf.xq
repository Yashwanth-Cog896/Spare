declare namespace xf = "http://tempuri.org/Samples/XQueryTransformations/ShipNotice_40_To_50/";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace ns-1 = "urn:cidx:names:specification:ces:schema:all:4:0";

declare function xf:ShipNotice_40_To_50($shipNotice1 as element(ns-1:ShipNotice))
    as element(ns0:ShipNotice) {
        <ns0:ShipNotice Version = "5.0" xmlns="urn:cidx:names:specification:ces:schema:all:5:0">
            <ns0:Header>
                <ns0:ThisDocumentIdentifier>
                    <ns0:DocumentIdentifier>{ data($shipNotice1/ns-1:Header/ns-1:ThisDocumentIdentifier/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                </ns0:ThisDocumentIdentifier>
                <ns0:ThisDocumentDateTime>
                    <ns0:DateTime DateTimeQualifier = "{ data($shipNotice1/ns-1:Header/ns-1:ThisDocumentDateTime/ns-1:DateTime/@DateTimeQualifier) }">{ data($shipNotice1/ns-1:Header/ns-1:ThisDocumentDateTime/ns-1:DateTime) }</ns0:DateTime>
                </ns0:ThisDocumentDateTime>
                <ns0:From>
                    <ns0:PartnerInformation>
                        {
                            for $PartnerName in $shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:PartnerName
                            return
                                <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                        }
                        <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                        {
                            for $ContactInformation in $shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:ContactInformation
                            return
                                <ns0:ContactInformation>
                                    {
                                        for $ContactName in $ContactInformation/ns-1:ContactName
                                        return
                                            <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                    }
                                    {
                                        for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                        return
                                            <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                    }
                                    {
                                        for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                        return
                                            <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                    }
                                    {
                                        for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                        return
                                            <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                    }
                                    {
                                        for $AlternativeCommunicationMethod in $ContactInformation/ns-1:AlternativeCommunicationMethod
                                        return
                                            <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns0:AlternativeCommunicationMethod>
                                    }
                                </ns0:ContactInformation>
                        }
                        <ns0:AddressInformation>
                            {
                            	if (data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:PostBoxNumber) != "") then 
                            	
                            	<ns0:PostBoxNumber>{ data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> else 
                            	
                            	for $AddressLine in $shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:AddressLine
                                return
                                    <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>	
                            }
                            (:comment <ns0:PostBoxNumber>{ data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                            <ns0:CityName>{ data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:CityName) }</ns0:CityName>
                            {
                                for $StateOrProvince in $shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:StateOrProvince
                                return
                                    <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                            }
                            {
                                for $PostalCode in $shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:PostalCode
                                return
                                    <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                            }
                            <ns0:PostalCountry>{ data($shipNotice1/ns-1:Header/ns-1:From/ns-1:PartnerInformation/ns-1:AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                        </ns0:AddressInformation>
                    </ns0:PartnerInformation>
                </ns0:From>
                <ns0:To>
                    <ns0:PartnerInformation>
                        {
                            for $PartnerName in $shipNotice1/ns-1:Header/ns-1:To/ns-1:PartnerInformation/ns-1:PartnerName
                            return
                                <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                        }
                        <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($shipNotice1/ns-1:Header/ns-1:To/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($shipNotice1/ns-1:Header/ns-1:To/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                        {
                            for $ContactInformation in $shipNotice1/ns-1:Header/ns-1:To/ns-1:PartnerInformation/ns-1:ContactInformation
                            return
                                <ns0:ContactInformation>
                                    {
                                        for $ContactName in $ContactInformation/ns-1:ContactName
                                        return
                                            <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                    }
                                    {
                                        for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                        return
                                            <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                    }
                                    {
                                        for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                        return
                                            <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                    }
                                    {
                                        for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                        return
                                            <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                    }
                                    {
                                        for $AlternativeCommunicationMethod in $ContactInformation/ns-1:AlternativeCommunicationMethod
                                        return
                                            <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns0:AlternativeCommunicationMethod>
                                    }
                                </ns0:ContactInformation>
                        }
                        {
                            for $AddressInformation in $shipNotice1/ns-1:Header/ns-1:To/ns-1:PartnerInformation/ns-1:AddressInformation
                            return
                                <ns0:AddressInformation>
                                    {
                                    	if (data($AddressInformation/ns-1:PostBoxNumber) != "") then 
                                    		<ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> else 
                                    			for $AddressLine in $AddressInformation/ns-1:AddressLine
                                        		return
                                            		<ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                    }
                                    (:comment <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                                    <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                    {
                                        for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                        return
                                            <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                    }
                                    {
                                        for $PostalCode in $AddressInformation/ns-1:PostalCode
                                        return
                                            <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                    }
                                    <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                </ns0:AddressInformation>
                        }
                    </ns0:PartnerInformation>
                </ns0:To>
            </ns0:Header>
            <ns0:ShipNoticeBody>
                <ns0:ShipNoticeProperties>
                    <ns0:ShipmentIdentification>
                        <ns0:DocumentReference>
                            <ns0:DocumentIdentifier>{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipmentIdentification/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                        </ns0:DocumentReference>
                    </ns0:ShipmentIdentification>
                    <ns0:ShipDate>
                        <ns0:DateTime DateTimeQualifier = "{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipDate/ns-1:DateTime/@DateTimeQualifier) }">{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipDate/ns-1:DateTime) }</ns0:DateTime>
                    </ns0:ShipDate>
                    <ns0:PurchaseOrderInformation>
                        <ns0:DocumentReference>
                            <ns0:DocumentIdentifier>{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                            {
                                for $ReferenceItem in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                return
                                    <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                            }
                        </ns0:DocumentReference>
                    </ns0:PurchaseOrderInformation>
                    <ns0:TransportMethodCode Domain = "{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:TransportMethodCode/@Domain) }">{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:TransportMethodCode) }</ns0:TransportMethodCode>
                    {
                        for $ReferenceInformation in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ReferenceInformation
                        return
                            <ns0:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                <ns0:DocumentReference>
                                    <ns0:DocumentIdentifier>{ data($ReferenceInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                </ns0:DocumentReference>
                            </ns0:ReferenceInformation>
                    }
                    <ns0:ConveyanceInformation>
                        <ns0:ConveyanceNameOrIdentifier>{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ConveyanceInformation/ns-1:ConveyanceNameOrIdentifier) }</ns0:ConveyanceNameOrIdentifier>
                        <ns0:EstimatedTimeOfArrivalDate>
                            <ns0:DateTimeInformation>
                                <ns0:DateTime DateTimeQualifier = "{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ConveyanceInformation/ns-1:EstimatedTimeOfArrivalDate/ns-1:DateTimeInformation/ns-1:DateTime/@DateTimeQualifier) }">{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ConveyanceInformation/ns-1:EstimatedTimeOfArrivalDate/ns-1:DateTimeInformation/ns-1:DateTime) }</ns0:DateTime>
                            </ns0:DateTimeInformation>
                        </ns0:EstimatedTimeOfArrivalDate>
                    </ns0:ConveyanceInformation>
                    {
                        let $ShipNoticeDate := $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeProperties/ns-1:ShipNoticeDate
                        return
                            <ns0:ShipNoticeDate>
                                <ns0:DateTime DateTimeQualifier = "{ data($ShipNoticeDate/ns-1:DateTime/@DateTimeQualifier) }">{ data($ShipNoticeDate/ns-1:DateTime) }</ns0:DateTime>
                            </ns0:ShipNoticeDate>
                    }
                </ns0:ShipNoticeProperties>
                <ns0:ShipNoticePartners>
                    <ns0:Buyer>
                        <ns0:PartnerInformation>
                            {
                                for $PartnerName in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerName
                                return
                                    <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                            }
                            <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                            {
                                for $ContactInformation in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:ContactInformation
                                return
                                    <ns0:ContactInformation>
                                        {
                                            for $ContactName in $ContactInformation/ns-1:ContactName
                                            return
                                                <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                        }
                                        {
                                            for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                            return
                                                <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                        }
                                        {
                                            for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                            return
                                                <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                        }
                                        {
                                            for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                            return
                                                <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                        }
                                        <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($ContactInformation/ns-1:AlternativeCommunicationMethod[1]/@CommunicationMethodType) }"/>
                                    </ns0:ContactInformation>
                            }
                            {
                                for $AddressInformation in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Buyer/ns-1:PartnerInformation/ns-1:AddressInformation
                                return
                                    <ns0:AddressInformation>
                                        {
                                        	if (data($AddressInformation/ns-1:PostBoxNumber) != "") then 
                                        		<ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> else 
                                        			for $AddressLine in $AddressInformation/ns-1:AddressLine
                                            		return
                                                		<ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                        		
                                        }
                                        (:comment <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                                        <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                        {
                                            for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                            return
                                                <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                        }
                                        {
                                            for $PostalCode in $AddressInformation/ns-1:PostalCode
                                            return
                                                <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                        }
                                        <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                    </ns0:AddressInformation>
                            }
                        </ns0:PartnerInformation>
                    </ns0:Buyer>
                    <ns0:Seller>
                        <ns0:PartnerInformation>
                            {
                                for $PartnerName in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerName
                                return
                                    <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                            }
                            <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                            {
                                for $ContactInformation in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:ContactInformation
                                return
                                    <ns0:ContactInformation>
                                        {
                                            for $ContactName in $ContactInformation/ns-1:ContactName
                                            return
                                                <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                        }
                                        {
                                            for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                            return
                                                <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                        }
                                        {
                                            for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                            return
                                                <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                        }
                                        {
                                            for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                            return
                                                <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                        }
                                        <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($ContactInformation/ns-1:AlternativeCommunicationMethod[1]/@CommunicationMethodType) }"/>
                                    </ns0:ContactInformation>
                            }
                            {
                                for $AddressInformation in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:Seller/ns-1:PartnerInformation/ns-1:AddressInformation
                                return
                                    <ns0:AddressInformation>
                                        {
                                        	if (data($AddressInformation/ns-1:PostBoxNumber) != "") then 
                                        		<ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> else 
                                        			for $AddressLine in $AddressInformation/ns-1:AddressLine
                                            return
                                                <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                        }
                                        (:comment <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                                        <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                        {
                                            for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                            return
                                                <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                        }
                                        {
                                            for $PostalCode in $AddressInformation/ns-1:PostalCode
                                            return
                                                <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                        }
                                        <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                    </ns0:AddressInformation>
                            }
                        </ns0:PartnerInformation>
                    </ns0:Seller>
                    {
                        for $OtherPartner in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticePartners/ns-1:OtherPartner
                        return
                            <ns0:OtherPartner PartnerRole = "{ data($OtherPartner/@PartnerRole) }">
                                <ns0:PartnerInformation>
                                    {
                                        for $PartnerName in $OtherPartner/ns-1:PartnerInformation/ns-1:PartnerName
                                        return
                                            <ns0:PartnerName>{ data($PartnerName) }</ns0:PartnerName>
                                    }
                                    <ns0:PartnerIdentifier Agency = "{ local:getAgencyCode(data($OtherPartner/ns-1:PartnerInformation/ns-1:PartnerIdentifier/@Agency)) }">{ data($OtherPartner/ns-1:PartnerInformation/ns-1:PartnerIdentifier) }</ns0:PartnerIdentifier>
                                    {
                                        for $ContactInformation in $OtherPartner/ns-1:PartnerInformation/ns-1:ContactInformation
                                        return
                                            <ns0:ContactInformation>
                                                {
                                                    for $ContactName in $ContactInformation/ns-1:ContactName
                                                    return
                                                        <ns0:ContactName>{ data($ContactName) }</ns0:ContactName>
                                                }
                                                {
                                                    for $ContactDescription in $ContactInformation/ns-1:ContactDescription
                                                    return
                                                        <ns0:ContactDescription>{ data($ContactDescription) }</ns0:ContactDescription>
                                                }
                                                {
                                                    for $ContactNumber in $ContactInformation/ns-1:ContactNumber
                                                    return
                                                        <ns0:ContactNumber>{ data($ContactNumber) }</ns0:ContactNumber>
                                                }
                                                {
                                                    for $EmailAddress in $ContactInformation/ns-1:EmailAddress
                                                    return
                                                        <ns0:EmailAddress>{ data($EmailAddress) }</ns0:EmailAddress>
                                                }
                                                <ns0:AlternativeCommunicationMethod CommunicationMethodType = "{ data($ContactInformation/ns-1:AlternativeCommunicationMethod[1]/@CommunicationMethodType) }"/>
                                            </ns0:ContactInformation>
                                    }
                                    {
                                        for $AddressInformation in $OtherPartner/ns-1:PartnerInformation/ns-1:AddressInformation
                                        return
                                            <ns0:AddressInformation>
                                                {
                                                	if (data($AddressInformation/ns-1:PostBoxNumber) != "") then 
                                                	
                                                	<ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> else 
                                                	
                                                	for $AddressLine in $AddressInformation/ns-1:AddressLine
                                                    return
                                                        <ns0:AddressLine>{ data($AddressLine) }</ns0:AddressLine>
                                                }
                                                (:comment <ns0:PostBoxNumber>{ data($AddressInformation/ns-1:PostBoxNumber) }</ns0:PostBoxNumber> :)
                                                <ns0:CityName>{ data($AddressInformation/ns-1:CityName) }</ns0:CityName>
                                                {
                                                    for $StateOrProvince in $AddressInformation/ns-1:StateOrProvince
                                                    return
                                                        <ns0:StateOrProvince>{ data($StateOrProvince) }</ns0:StateOrProvince>
                                                }
                                                {
                                                    for $PostalCode in $AddressInformation/ns-1:PostalCode
                                                    return
                                                        <ns0:PostalCode>{ data($PostalCode) }</ns0:PostalCode>
                                                }
                                                <ns0:PostalCountry>{ data($AddressInformation/ns-1:PostalCountry) }</ns0:PostalCountry>
                                            </ns0:AddressInformation>
                                    }
                                </ns0:PartnerInformation>
                            </ns0:OtherPartner>
                    }
                </ns0:ShipNoticePartners>
                <ns0:ShipNoticeDetails>
                    {
                        for $ShipNoticeProductLineItem in $shipNotice1/ns-1:ShipNoticeBody/ns-1:ShipNoticeDetails/ns-1:ShipNoticeProductLineItem
                        return
                            <ns0:ShipNoticeProductLineItem>
                                <ns0:LineNumber>{ data($ShipNoticeProductLineItem/ns-1:LineNumber) }</ns0:LineNumber>
                                {
                                    for $EquipmentDetailsLineNumber in $ShipNoticeProductLineItem/ns-1:EquipmentDetailsLineNumber
                                    return
                                        <ns0:EquipmentDetailsLineNumber>{ data($EquipmentDetailsLineNumber) }</ns0:EquipmentDetailsLineNumber>
                                }
                                {
                                    for $ProductIdentification in $ShipNoticeProductLineItem/ns-1:ProductIdentification
                                    return
                                        <ns0:ProductIdentification>
                                            <ns0:ProductIdentifier Agency = "{ data($ProductIdentification/ns-1:ProductIdentifier/@Agency) }">{ data($ProductIdentification/ns-1:ProductIdentifier) }</ns0:ProductIdentifier>
                                            {
                                                for $ProductName in $ProductIdentification/ns-1:ProductName
                                                return
                                                    <ns0:ProductName>{ data($ProductName) }</ns0:ProductName>
                                            }
                                            {
                                                for $Trademark in $ProductIdentification/ns-1:Trademark
                                                return
                                                    <ns0:Trademark>{ data($Trademark) }</ns0:Trademark>
                                            }
                                            {
                                                for $ProductDescription in $ProductIdentification/ns-1:ProductDescription
                                                return
                                                    <ns0:ProductDescription>{ data($ProductDescription) }</ns0:ProductDescription>
                                            }
                                            {
                                                for $ProductGradeDescription in $ProductIdentification/ns-1:ProductGradeDescription
                                                return
                                                    <ns0:ProductGradeDescription>{ data($ProductGradeDescription) }</ns0:ProductGradeDescription>
                                            }
                                            {
                                                for $ProductClassification in $ProductIdentification/ns-1:ProductClassification
                                                return
                                                    <ns0:ProductClassification>{ data($ProductClassification) }</ns0:ProductClassification>
                                            }
                                        </ns0:ProductIdentification>
                                }
                                <ns0:ShippedQuantity>
                                    <ns0:Measurement>
                                        <ns0:MeasurementValue>{ data($ShipNoticeProductLineItem/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
                                        <ns0:UnitOfMeasureCode Domain = "{ data($ShipNoticeProductLineItem/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($ShipNoticeProductLineItem/ns-1:ShippedQuantity/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
                                    </ns0:Measurement>
                                </ns0:ShippedQuantity>
                	            {
                                	for $PurchaseOrderInformation in $ShipNoticeProductLineItem/ns-1:PurchaseOrderInformation
                                    return 
                                    	<ns0:PurchaseOrderInformation>
                                            <ns0:DocumentReference>
                                                <ns0:DocumentIdentifier>{ data($PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                                {
                                                    for $DateTime in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:DateTime
                                                    return
                                                        <ns0:DateTime DateTimeQualifier = "{ data($DateTime/@DateTimeQualifier) }">{data($DateTime)}</ns0:DateTime>
                                                }
                                                {
                                                    for $ReferenceItem in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReferenceItem
                                                    return
                                                        <ns0:ReferenceItem>{ data($ReferenceItem) }</ns0:ReferenceItem>
                                                }
                                                {
                                                    for $ReleaseNumber in $PurchaseOrderInformation/ns-1:DocumentReference/ns-1:ReleaseNumber
                                                    return
                                                        <ns0:ReleaseNumber>{ data($ReleaseNumber) }</ns0:ReleaseNumber>
                                                }
                                            </ns0:DocumentReference>
                                        </ns0:PurchaseOrderInformation>
                                }
                                {
                                    for $ReferenceInformation in $ShipNoticeProductLineItem/ns-1:ReferenceInformation
                                    return
                                        <ns0:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                            <ns0:DocumentReference>
                                                <ns0:DocumentIdentifier>{ data($ReferenceInformation/ns-1:DocumentReference/ns-1:DocumentIdentifier) }</ns0:DocumentIdentifier>
                                            </ns0:DocumentReference>
                                        </ns0:ReferenceInformation>
                                }
                                {
                                    for $ProductSubLineItems in $ShipNoticeProductLineItem/ns-1:ProductSubLineItems
                                    return
                                        <ns0:ProductSubLineItems>
                                            <ns0:SubLineItemNumber>{ data($ProductSubLineItems/ns-1:SubLineItemNumber) }</ns0:SubLineItemNumber>
                                            {
                                            	for $ManufacturingIdentificationDetails in $ProductSubLineItems/ns-1:ManufacturingIdentificationDetails
                                                return
                                                    <ns0:ManufacturingIdentificationDetails>
                                                        <ns0:ManufacturingIdentificationType>{ data($ManufacturingIdentificationDetails/ns-1:ManufacturingIdentificationType) }</ns0:ManufacturingIdentificationType>
                                                        <ns0:ManufacturingIdentificationNumber>{ data($ManufacturingIdentificationDetails/ns-1:ManufacturingIdentificationNumber) }</ns0:ManufacturingIdentificationNumber>
                                                        {
                                                            for $ParentManufacturingIdentificationNumber in $ManufacturingIdentificationDetails/ns-1:ParentManufacturingIdentificationNumber
                                                            return
                                                                <ns0:ParentManufacturingIdentificationNumber>{ data($ParentManufacturingIdentificationNumber) }</ns0:ParentManufacturingIdentificationNumber>
                                                        }
                                                    </ns0:ManufacturingIdentificationDetails>
                                            }
                                            {
                                            	for $GrossVolume in $ProductSubLineItems/ns-1:GrossVolume 
                                            	return 
		                                            <ns0:GrossVolume>
		                                                <ns0:SpecifiedMeasurement MeasurementQualifier = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/@MeasurementQualifier) }">
		                                                    <ns0:Measurement>
		                                                        <ns0:MeasurementValue>{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:MeasurementValue) }</ns0:MeasurementValue>
		                                                        <ns0:UnitOfMeasureCode Domain = "{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode/@Domain) }">{ data($GrossVolume/ns-1:SpecifiedMeasurement/ns-1:Measurement/ns-1:UnitOfMeasureCode) }</ns0:UnitOfMeasureCode>
		                                                    </ns0:Measurement>
		                                                </ns0:SpecifiedMeasurement>
		                                            </ns0:GrossVolume>
		                                	}
                                        </ns0:ProductSubLineItems>
                                }
                            </ns0:ShipNoticeProductLineItem>
                    }
                </ns0:ShipNoticeDetails>
            </ns0:ShipNoticeBody>
        </ns0:ShipNotice>
};

declare function local:getAgencyCode(
$actual as xs:string?) as xs:string?
{
  let $retVal := if ($actual = "EAN") then "GLN" else $actual
  return $retVal  
};

declare function local:getPOBox(
$inpVal as xs:string?) as xs:string?
{
  let $retVal := if ($inpVal != "") then $inpVal else "NA"
  return $retVal  
};

declare variable $shipNotice1 as element(ns-1:ShipNotice) external;

xf:ShipNotice_40_To_50($shipNotice1)