declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
declare namespace nex = "http://integration.nexuse2e.org/NEXUSe2eUtilities/";
(:
The purpose of this function is to format a request to the Nexus containsPartner web service (WS), wrapped in a
SOAP Body tag.

The Nexus containsPartner WS has two functions.  (1) If passed only a partnerId, it returns true or false
according to whether the partnerId is a valid Nexus partner ID.  (2) If passed both a partnerId and a
choreographyName, it returns true only if the partnerId is a valid Nexus partner who is registered for the
specified choreographyName.  A "choreography" in Nexus is a particular business flow, for example choreography
"SeedShipNotice" sends out shipment notices, and choreography "SeedInvoice" sends out invoices.

So, this function should always be passed a partnerId. (As of October 2008, all Nexus partner IDs are DUNS+4
numbers, which are the same as EBIDs.  In the future, GLNs may be added.)  To prepare a request for function (1), pass the
$choreographyName parameter as an empty string or empty sequence.  To prepare a request for function (2),
pass a non-empty choreography name such as "SeedInvoice".
:)
declare function monisd:formatNexusContainsPartnerRequest 
  ( $partnerId as xs:string?, $choreographyName as xs:string? )  as node() {

    if (string($choreographyName) != "")
    then
    element { xs:QName("soapenv:Body") }
      { element { xs:QName("nex:containsPartner") }
        { element { "partnerId" } {$partnerId},
           element { "choreographyName" } {$choreographyName}
        }
      }
    else
    element { xs:QName("soapenv:Body") }
      { element { xs:QName("nex:containsPartner") }
        { element { "partnerId" } {$partnerId}
        }
      }

 } ;

declare variable $partnerId as xs:string? external;
declare variable $choreographyName as xs:string? external;

monisd:formatNexusContainsPartnerRequest($partnerId, $choreographyName )