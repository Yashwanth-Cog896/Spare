xquery version "1.0" encoding "Cp1252";
(:: pragma  type="xs:anyType" ::)


declare function local:Function_local_AddLeadingZeros($originalString as xs:string)
as xs:string {
	let $length := string-length($originalString)
	let $difference := (10 - $length)
	
	let $tenZeros := "0000000000"
	let $newString := concat($tenZeros, $originalString)
	let $startPosition := (string-length($newString)) - 9
	let $finalString := substring($newString, $startPosition)
	
	return 
	if ($length < 10) then 
		$finalString	
		
	else($originalString)
		
};


declare variable $originalString as xs:string external;
local:Function_local_AddLeadingZeros($originalString)
