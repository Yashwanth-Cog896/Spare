declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
declare namespace ns="urn:monsanto:serviceadmin:services:outage";

declare function local:AuthenticationFault($fault)
as element() 
{
	element {xs:QName("soapenv:Fault")}
      {
      	element {"faultcode"} {"soapenv:Client"},
        element {"faultstring"} {"Response failed schema validation, see details in the body of this message."},
        element {"detail"} {$fault}
      }
};

declare variable $fault external;

local:AuthenticationFault($fault)