declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";

declare function local:AuthenticationFault($roleCheckedString as xs:string)
as element() 
{
	element {xs:QName("soapenv:Fault")}
      {
      	element {"faultcode"} {"soapenv:Client"},
        element {"faultstring"} {"Failed authorization on user account.  No valid role to access service."},
        element {xs:QName("detail")}
        {
        	element {"message"} {fn:concat("User does not have the proper roles of: ", $roleCheckedString, " to access the service")}
        }
      }
};

declare variable $roleCheckedString as xs:string external;

local:AuthenticationFault($roleCheckedString)