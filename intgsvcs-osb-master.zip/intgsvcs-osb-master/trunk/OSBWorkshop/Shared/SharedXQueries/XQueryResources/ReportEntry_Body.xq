declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace monrpt = "urn:ecms:log:report";
declare function monisd:formatReportEntryWithBody 
  ($body as node() )  as node() {
    element { xs:QName("monrpt:Report") }
      { element { xs:QName("monrpt:Body") } {$body}
      }
 } ;

declare variable $body as node() external;

monisd:formatReportEntryWithBody($body)