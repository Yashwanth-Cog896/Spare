declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace spoe = "urn:spoe:schema:errors:1:0";
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";

declare function monisd:formatEcmsFaultServiceException 
	($serviceName as xs:string?)  as node() {
	
	element {xs:QName("soapenv:Fault")}
		{element{"faultcode"} {"ServiceException"},
        	element {"faultstring"} {"An error occurred processing the request to ", $serviceName}
		}
 };

declare variable $serviceName as xs:string? external;

monisd:formatEcmsFaultServiceException($serviceName)