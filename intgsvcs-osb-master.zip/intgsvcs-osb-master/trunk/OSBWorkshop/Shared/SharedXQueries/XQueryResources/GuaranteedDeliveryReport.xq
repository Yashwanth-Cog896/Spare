declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace monrpt = "urn:ecms:log:report";

declare function monisd:formatReportEntryWithHeaderAndBody 
  ( $errorQueue as xs:string, $correlationId as xs:string, $body as node() )  as element() {
	element {xs:QName("monrpt:Report")}
      {
      	element {"ErrorQueue"} {$errorQueue},
        element {"CorrelationID"} {$correlationId},
        element { xs:QName("Body") } {$body}
      }
 } ;

declare variable $errorQueue as xs:string external;
declare variable $correlationId as xs:string external;
declare variable $body as node() external;


monisd:formatReportEntryWithHeaderAndBody($errorQueue, $correlationId, $body)