declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";

declare function local:AuthenticationFault($fault)
as element() 
{
	element {xs:QName("soapenv:Fault")}
      {
      	element {"faultcode"} {"soapenv:Client"},
        element {"faultstring"} {"Failed authentication on username, password lookup."},
        element {"detail"} {$fault}
      }
};

declare variable $fault external;

local:AuthenticationFault($fault)