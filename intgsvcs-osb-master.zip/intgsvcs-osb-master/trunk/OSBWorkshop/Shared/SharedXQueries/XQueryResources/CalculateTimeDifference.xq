xquery version "1.0" encoding "Cp1252";


declare function local:CalculateTimeDifference($startTime as xs:time, $endTime as xs:time)
as xs:decimal {

let $startSeconds := fn:seconds-from-time($startTime)
let $endSeconds := fn:seconds-from-time($endTime)
let $startMinutes := fn:minutes-from-time($startTime)
let $endMinutes := fn:minutes-from-time($endTime)
let $startHours := fn:hours-from-time($startTime)
let $endHours := fn:hours-from-time($endTime)

return
if($startHours = $endHours) then

	if($startMinutes = $endMinutes) then
		$endSeconds - $startSeconds

	else((($endMinutes - ($startMinutes + 1)) * 60) + ($endSeconds + (60 - $startSeconds)))

else(($endMinutes * 60) + $endSeconds + (60 * (60 - ($startMinutes + 1))) + ($endSeconds + (60 - $startSeconds)))

};

declare variable $startTime as xs:time external;
declare variable $endTime as xs:time external;

local:CalculateTimeDifference($startTime, $endTime)