declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
declare namespace ns="urn:monsanto:serviceadmin:services:outage";

declare function local:AuthenticationFault($OutageResponse)
as element() 
{
	element {xs:QName("soapenv:Fault")}
      {
      	element {"faultcode"} {"soapenv:Server"},
        element {"faultstring"} {"Service is in scheduled outage."},
        element {"detail"} {$OutageResponse/ns:GetOutageResponseBody}
      }
};

declare variable $OutageResponse external;

local:AuthenticationFault($OutageResponse)