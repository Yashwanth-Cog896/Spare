xquery version "1.0" encoding "Cp1252";

declare namespace xf = "http://tempuri.org/SharedXQueries/XQueryResources/DecodeURI/";

declare function xf:DecodeURI($input as xs:string)
as xs:string {
fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(fn:replace(
$input,
'%20', ' '),
'%21', '!'),
'%22', '"'),
'%23', '#'),
'%25', '%'),
'%26', '&amp;'),
'%27', '&quot;'),
'%28', '('),
'%29', ')'),
'%2A', '*'),
'%2B', '+'),
'%2C', ','),
'%2D', '-'),
'%2E', '.'),
'%2F', '/'),
'%3A', ':'),
'%3B', ';'),
'%3C','<'), 
'%3D', '='),
'%3E', '>'),
'%3F', '?'),
'%40', '@'),
'%5B', '['),
'%5D', ']'),
'%5E', '^'),
'%5F', '_'),
'%7B', '{'),
'%7C', '|'),
'%7D', '}'),
'\+',' '),
'%0D', ' '),
'%0A', ' ')
};

declare variable $input as xs:string external;
xf:DecodeURI($input)
