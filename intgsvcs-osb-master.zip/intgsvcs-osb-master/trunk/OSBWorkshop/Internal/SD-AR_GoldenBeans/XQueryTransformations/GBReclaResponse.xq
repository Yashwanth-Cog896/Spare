(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YlasPyGbreclaResponse" location="../WSDLs/YES_Y_LAS_PY_GBRECLA.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyGbreclaResponse" location="../WSDLs/YES_Y_LAS_PY_GBRECLA_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GBReclaResponse/";

declare function xf:GBReclaResponse($response as element(ns0:YlasPyGbreclaResponse))
    as element(ns0:YlasPyGbreclaResponse) {
        <ns0:YlasPyGbreclaResponse>
            <EDoc>{ data($response/EDoc) }</EDoc>
            <EGjahr>{ data($response/EGjahr) }</EGjahr>
            <EMessage>{ data($response/EMessage) }</EMessage>
            <EXblnr>{ data($response/EXblnr) }</EXblnr>
        </ns0:YlasPyGbreclaResponse>
};

declare variable $response as element(ns0:YlasPyGbreclaResponse) external;

xf:GBReclaResponse($response)
