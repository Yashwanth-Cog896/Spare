(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFiarGbcredit" location="../WSDLs/yes_y_fiar_gbcredit_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFiarGbcredit" location="../WSDLs/yes_y_fiar_gbcredit.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GBCreditRequest/";

declare function xf:GBCreditRequest($request as element(ns0:YFiarGbcredit))
    as element(ns0:YFiarGbcredit) {
        <ns0:YFiarGbcredit>
            {
                for $IBelnr in $request/IBelnr
                return
                    <IBelnr>{ data($IBelnr) }</IBelnr>
            }
            {
                for $IBudatF in $request/IBudatF
                return
                    <IBudatF>{ data($IBudatF) }</IBudatF>
            }
            {
                for $IBudatT in $request/IBudatT
                return
                    <IBudatT>{ data($IBudatT) }</IBudatT>
            }
            {
                for $IBukrs in $request/IBukrs
                return
                    <IBukrs>{ data($IBukrs) }</IBukrs>
            }
            {
                for $IDocsenv in $request/IDocsenv
                return
                    <IDocsenv>{ data($IDocsenv) }</IDocsenv>
            }
            {
                for $IGjahr in $request/IGjahr
                return
                    <IGjahr>{ data($IGjahr) }</IGjahr>
            }
            {
                for $IGsber in $request/IGsber
                return
                    <IGsber>{ data($IGsber) }</IGsber>
            }
            {
                for $IKunnr in $request/IKunnr
                return
                    <IKunnr>{ data($IKunnr) }</IKunnr>
            }
            {
                for $IRev in $request/IRev
                return
                    <IRev>{ data($IRev) }</IRev>
            }
            {
                for $ItBlart in $request/ItBlart
                return
                    <ItBlart>
                        {
                            for $item in $ItBlart/item
                            return
                                <item>{ $item/@* , $item/node() }</item>
                        }
                    </ItBlart>
            }
            {
                for $ItXblnr in $request/ItXblnr
                return
                    <ItXblnr>
                        {
                            for $item in $ItXblnr/item
                            return
                                <item>{ $item/@* , $item/node() }</item>
                        }
                    </ItXblnr>
            }
        </ns0:YFiarGbcredit>
};

declare variable $request as element(ns0:YFiarGbcredit) external;

xf:GBCreditRequest($request)
