(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YlasPyDownInvSapToGbResponse" location="../WSDLs/YES_YLAS_PY_DOWN_INV_SAP_TO_GB.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyDownInvSapToGbResponse" location="../WSDLs/YES_YLAS_PY_DOWN_INV_SAP_TO_GB_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/DownResponse/";

declare function xf:DownResponse($response as element(ns0:YlasPyDownInvSapToGbResponse))
    as element(ns0:YlasPyDownInvSapToGbResponse) {
        <ns0:YlasPyDownInvSapToGbResponse>
            <EpMessageResult>{ data($response/EpMessageResult) }</EpMessageResult>
            <EtYlaspyGldnBns>{ $response/EtYlaspyGldnBns/@* , $response/EtYlaspyGldnBns/node() }</EtYlaspyGldnBns>
        </ns0:YlasPyDownInvSapToGbResponse>
};

declare variable $response as element(ns0:YlasPyDownInvSapToGbResponse) external;

xf:DownResponse($response)
