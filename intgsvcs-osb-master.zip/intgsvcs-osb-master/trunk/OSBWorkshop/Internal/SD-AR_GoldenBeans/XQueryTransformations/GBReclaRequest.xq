(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YlasPyGbrecla" location="../WSDLs/YES_Y_LAS_PY_GBRECLA_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyGbrecla" location="../WSDLs/YES_Y_LAS_PY_GBRECLA.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GBReclaRequest/";

declare function xf:GBReclaRequest($request as element(ns0:YlasPyGbrecla))
    as element(ns0:YlasPyGbrecla) {
        <ns0:YlasPyGbrecla>
            {
                for $IPrice in $request/IPrice
                return
                    <IPrice>{ data($IPrice) }</IPrice>
            }
            {
                for $IVbeln in $request/IVbeln
                return
                    <IVbeln>{ data($IVbeln) }</IVbeln>
            }
            {
                for $IXblnr in $request/IXblnr
                return
                    <IXblnr>{ data($IXblnr) }</IXblnr>
            }
        </ns0:YlasPyGbrecla>
};

declare variable $request as element(ns0:YlasPyGbrecla) external;

xf:GBReclaRequest($request)
