(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YlasPyGenSoGbToSap" location="../WSDLs/YES_YLAS_PY_GEN_SO_GB_TO_SAP_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyGenSoGbToSap" location="../WSDLs/YES_YLAS_PY_GEN_SO_GB_TO_SAP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GenRequest/";

declare function xf:GenRequest($request as element(ns0:YlasPyGenSoGbToSap))
    as element(ns0:YlasPyGenSoGbToSap) {
        <ns0:YlasPyGenSoGbToSap>
            <IpAmountWIva>{ data($request/IpAmountWIva) }</IpAmountWIva>
            <IpAmountWoIva>{ data($request/IpAmountWoIva) }</IpAmountWoIva>
            <IpIdTransaction>{ data($request/IpIdTransaction) }</IpIdTransaction>
            <IpIva>{ data($request/IpIva) }</IpIva>
            <IpPeriod>{ data($request/IpPeriod) }</IpPeriod>
            <IpQuantity>{ data($request/IpQuantity) }</IpQuantity>
            <IpReference>{ data($request/IpReference) }</IpReference>
            <IpRuc>{ data($request/IpRuc) }</IpRuc>
            <IpServiceType>{ data($request/IpServiceType) }</IpServiceType>
        </ns0:YlasPyGenSoGbToSap>
};

declare variable $request as element(ns0:YlasPyGenSoGbToSap) external;

xf:GenRequest($request)
