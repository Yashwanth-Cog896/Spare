(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YbapiFtrFtdCreateResponse" location="../WSDLs/YES_YBAPI_FTR_FTD_CREATE.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFtdCreateResponse" location="../WSDLs/YES_YBAPI_FTR_FTD_CREATE_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FTD_Create_Response/";

declare function xf:FTD_Create_Response($response as element(ns0:YbapiFtrFtdCreateResponse))
    as element(ns0:YbapiFtrFtdCreateResponse) {
        <ns0:YbapiFtrFtdCreateResponse>
            <Companycode>{ data($response/Companycode) }</Companycode>
            <Financialtransaction>{ data($response/Financialtransaction) }</Financialtransaction>
            <Return>{ $response/Return/@* , $response/Return/node() }</Return>
        </ns0:YbapiFtrFtdCreateResponse>
};

declare variable $response as element(ns0:YbapiFtrFtdCreateResponse) external;

xf:FTD_Create_Response($response)