(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YbapiFtrFtdRolloverResponse" location="../WSDLs/YES_YBAPI_FTR_FTD_ROLLOVER.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFtdRolloverResponse" location="../WSDLs/YES_YBAPI_FTR_FTD_ROLLOVER_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FTD_Rollover_Response/";

declare function xf:FTD_Rollover_Response($response as element(ns0:YbapiFtrFtdRolloverResponse))
    as element(ns0:YbapiFtrFtdRolloverResponse) {
        <ns0:YbapiFtrFtdRolloverResponse>
            <Return>{ $response/Return/@* , $response/Return/node() }</Return>
            <Returncompanycode>{ data($response/Returncompanycode) }</Returncompanycode>
            <Returnfinancialtransaction>{ data($response/Returnfinancialtransaction) }</Returnfinancialtransaction>
        </ns0:YbapiFtrFtdRolloverResponse>
};

declare variable $response as element(ns0:YbapiFtrFtdRolloverResponse) external;

xf:FTD_Rollover_Response($response)