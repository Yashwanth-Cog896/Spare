(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YbapiFtrFxtCreateResponse" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATE.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFxtCreateResponse" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATE_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FXT_Create_Response/";

declare function xf:FXT_Create_Response($response as element(ns0:YbapiFtrFxtCreateResponse))
    as element(ns0:YbapiFtrFxtCreateResponse) {
        <ns0:YbapiFtrFxtCreateResponse>
            <Companycode>{ data($response/Companycode) }</Companycode>
            <Financialtransaction>{ data($response/Financialtransaction) }</Financialtransaction>
            <Return>{ $response/Return/@* , $response/Return/node() }</Return>
        </ns0:YbapiFtrFxtCreateResponse>
};

declare variable $response as element(ns0:YbapiFtrFxtCreateResponse) external;

xf:FXT_Create_Response($response)