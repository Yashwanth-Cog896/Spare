(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YbapiFtrFxtCreate" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATE_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFxtCreate" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATE.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FXT_Create_Request/";

declare function xf:FXT_Create_Request($request as element(ns0:YbapiFtrFxtCreate))
    as element(ns0:YbapiFtrFxtCreate) {
        <ns0:YbapiFtrFxtCreate>
            {
                for $ActivityCategory in $request/ActivityCategory
                return
                    <ActivityCategory>{ data($ActivityCategory) }</ActivityCategory>
            }
            <Forex>{ $request/Forex/@* , $request/Forex/node() }</Forex>
            <Generalcontractdata>
                <CompanyCode>{ data($request/Generalcontractdata/CompanyCode) }</CompanyCode>
                <ProductType>{ data($request/Generalcontractdata/ProductType) }</ProductType>
                <TransactionType>{ data($request/Generalcontractdata/TransactionType) }</TransactionType>
                <ExternalTransactionNumber>{ data($request/Generalcontractdata/ExternalTransactionNumber) }</ExternalTransactionNumber>
                <Partner>{ local:Function_local_AddLeadingZeros(data($request/Generalcontractdata/Partner))  }</Partner>
                <ContractDate>{ data($request/Generalcontractdata/ContractDate) }</ContractDate>
                <ContractTime>{ data($request/Generalcontractdata/ContractTime) }</ContractTime>
                <ContactPerson>{ data($request/Generalcontractdata/ContactPerson) }</ContactPerson>
                <Trader>{ data($request/Generalcontractdata/Trader) }</Trader>
                <AcctAssignmentRef>{ data($request/Generalcontractdata/AcctAssignmentRef) }</AcctAssignmentRef>
                <Portfolio>{ data($request/Generalcontractdata/Portfolio) }</Portfolio>
                <FinanceProject>{ data($request/Generalcontractdata/FinanceProject) }</FinanceProject>
                <Guarantor>{ data($request/Generalcontractdata/Guarantor) }</Guarantor>
                <MasterAgreement>{ data($request/Generalcontractdata/MasterAgreement) }</MasterAgreement>
                <Assignment>{ data($request/Generalcontractdata/Assignment) }</Assignment>
                <ExternalReference>{ data($request/Generalcontractdata/ExternalReference) }</ExternalReference>
                <InternalReference>{ data($request/Generalcontractdata/InternalReference) }</InternalReference>
                <Characteristics>{ data($request/Generalcontractdata/Characteristics) }</Characteristics>
                <AuthGroup>{ data($request/Generalcontractdata/AuthGroup) }</AuthGroup>
                <CreateUser>{ data($request/Generalcontractdata/CreateUser) }</CreateUser>
                <EntryDate>{ data($request/Generalcontractdata/EntryDate) }</EntryDate>
                <Facility>{ data($request/Generalcontractdata/Facility) }</Facility>
                <FacilityCompanyCode>{ data($request/Generalcontractdata/FacilityCompanyCode) }</FacilityCompanyCode>
                <ValuationClass>{ data($request/Generalcontractdata/ValuationClass) }</ValuationClass>
                <ExpenseKey>{ data($request/Generalcontractdata/ExpenseKey) }</ExpenseKey>
            </Generalcontractdata>
            {
                for $Return in $request/Return
                return
                    <Return>{ $Return/@* , $Return/node() }</Return>
            }
            {
                for $Testrun in $request/Testrun
                return
                    <Testrun>{ data($Testrun) }</Testrun>
            }
        </ns0:YbapiFtrFxtCreate>
};

declare function local:Function_local_AddLeadingZeros($originalString as xs:string)
as xs:string {
	let $length := string-length($originalString)
	let $difference := (10 - $length)
	
	let $tenZeros := "0000000000"
	let $newString := concat($tenZeros, $originalString)
	let $startPosition := (string-length($newString)) - 9
	let $finalString := substring($newString, $startPosition)
	
	return 
	if ($length < 10) then 
		$finalString	
		
	else($originalString)
		
};


declare variable $request as element(ns0:YbapiFtrFxtCreate) external;

xf:FXT_Create_Request($request)
