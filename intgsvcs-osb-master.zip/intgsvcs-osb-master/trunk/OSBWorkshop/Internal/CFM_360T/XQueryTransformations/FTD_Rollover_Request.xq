(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YbapiFtrFtdRollover" location="../WSDLs/YES_YBAPI_FTR_FTD_ROLLOVER_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFtdRollover" location="../WSDLs/YES_YBAPI_FTR_FTD_ROLLOVER.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FTD_Rollover_Request/";

declare function xf:FTD_Rollover_Request($request as element(ns0:YbapiFtrFtdRollover))
    as element(ns0:YbapiFtrFtdRollover) {
        <ns0:YbapiFtrFtdRollover>
            <Companycode>{ data($request/Companycode) }</Companycode>
            {
                for $ContactPerson in $request/ContactPerson
                return
                    <ContactPerson>{ data($ContactPerson) }</ContactPerson>
            }
            {
                for $ContractDate in $request/ContractDate
                return
                    <ContractDate>{ data($ContractDate) }</ContractDate>
            }
            {
                for $ExternalReference in $request/ExternalReference
                return
                    <ExternalReference>{ data($ExternalReference) }</ExternalReference>
            }
            <Financialtransaction>{ data($request/Financialtransaction) }</Financialtransaction>
            <Fixedtermdeposit>{ $request/Fixedtermdeposit/@* , $request/Fixedtermdeposit/node() }</Fixedtermdeposit>
            <Fixedtermdepositx>{ $request/Fixedtermdepositx/@* , $request/Fixedtermdepositx/node() }</Fixedtermdepositx>
            {
                for $Return in $request/Return
                return
                    <Return>{ $Return/@* , $Return/node() }</Return>
            }
            {
                for $Testrun in $request/Testrun
                return
                    <Testrun>{ data($Testrun) }</Testrun>
            }
            {
                for $Trader in $request/Trader
                return
                    <Trader>{ data($Trader) }</Trader>
            }
        </ns0:YbapiFtrFtdRollover>
};

declare variable $request as element(ns0:YbapiFtrFtdRollover) external;

xf:FTD_Rollover_Request($request)