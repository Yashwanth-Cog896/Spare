(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YbapiFtrFxtCreateswapResponse" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATESWAP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFxtCreateswapResponse" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATESWAP_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FXT_CreateSwap_Response/";

declare function xf:FXT_CreateSwap_Response($response as element(ns0:YbapiFtrFxtCreateswapResponse))
    as element(ns0:YbapiFtrFxtCreateswapResponse) {
        <ns0:YbapiFtrFxtCreateswapResponse>
            <Companycode>{ data($response/Companycode) }</Companycode>
            <Financialtransaction>{ data($response/Financialtransaction) }</Financialtransaction>
            <Financialtransaction2>{ data($response/Financialtransaction2) }</Financialtransaction2>
            <Return>{ $response/Return/@* , $response/Return/node() }</Return>
        </ns0:YbapiFtrFxtCreateswapResponse>
};

declare variable $response as element(ns0:YbapiFtrFxtCreateswapResponse) external;

xf:FXT_CreateSwap_Response($response)