(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YbapiFtrCreateFxoptionsResponse" location="../WSDLs/YES_YBAPI_FTR_CREATE_FXOPTIONS.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrCreateFxoptionsResponse" location="../WSDLs/YES_YBAPI_FTR_CREATE_FXOPTIONS_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FA_360T/XQueryTranformations/Create_FXOptions_Response/";

declare function xf:Create_FXOptions_Response($response as element(ns0:YbapiFtrCreateFxoptionsResponse))
    as element(ns0:YbapiFtrCreateFxoptionsResponse) {
        <ns0:YbapiFtrCreateFxoptionsResponse>
            <Companycode>{ data($response/Companycode) }</Companycode>
            <Financialtransaction>{ data($response/Financialtransaction) }</Financialtransaction>
            <Return>{ $response/Return/@* , $response/Return/node() }</Return>
        </ns0:YbapiFtrCreateFxoptionsResponse>
};

declare variable $response as element(ns0:YbapiFtrCreateFxoptionsResponse) external;

xf:Create_FXOptions_Response($response)