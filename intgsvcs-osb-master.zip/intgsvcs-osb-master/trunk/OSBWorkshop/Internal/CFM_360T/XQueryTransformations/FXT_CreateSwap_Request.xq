(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YbapiFtrFxtCreateswap" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATESWAP_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YbapiFtrFxtCreateswap" location="../WSDLs/YES_YBAPI_FTR_FXT_CREATESWAP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CFM_360T/XQueryTranformations/FXT_CreateSwap/";

declare function xf:FXT_CreateSwap($request as element(ns0:YbapiFtrFxtCreateswap))
    as element(ns0:YbapiFtrFxtCreateswap) {
        <ns0:YbapiFtrFxtCreateswap>
            {
                for $ActivityCategory in $request/ActivityCategory
                return
                    <ActivityCategory>{ data($ActivityCategory) }</ActivityCategory>
            }
            <Forex_1>{ $request/Forex_1/@* , $request/Forex_1/node() }</Forex_1>
            <Forex_2>{ $request/Forex_2/@* , $request/Forex_2/node() }</Forex_2>
            <Generalcontractdata_1>
                <CompanyCode>{ data($request/Generalcontractdata_1/CompanyCode) }</CompanyCode>
                <ProductType>{ data($request/Generalcontractdata_1/ProductType) }</ProductType>
                <TransactionType>{ data($request/Generalcontractdata_1/TransactionType) }</TransactionType>
                <ExternalTransactionNumber>{ data($request/Generalcontractdata_1/ExternalTransactionNumber) }</ExternalTransactionNumber>
                <Partner>{ local:Function_local_AddLeadingZeros(data($request/Generalcontractdata_1/Partner))  }</Partner>
                <ContractDate>{ data($request/Generalcontractdata_1/ContractDate) }</ContractDate>
                <ContractTime>{ data($request/Generalcontractdata_1/ContractTime) }</ContractTime>
                <ContactPerson>{ data($request/Generalcontractdata_1/ContactPerson) }</ContactPerson>
                <Trader>{ data($request/Generalcontractdata_1/Trader) }</Trader>
                <AcctAssignmentRef>{ data($request/Generalcontractdata_1/AcctAssignmentRef) }</AcctAssignmentRef>
                <Portfolio>{ data($request/Generalcontractdata_1/Portfolio) }</Portfolio>
                <FinanceProject>{ data($request/Generalcontractdata_1/FinanceProject) }</FinanceProject>
                <Guarantor>{ data($request/Generalcontractdata_1/Guarantor) }</Guarantor>
                <MasterAgreement>{ data($request/Generalcontractdata_1/MasterAgreement) }</MasterAgreement>
                <Assignment>{ data($request/Generalcontractdata_1/Assignment) }</Assignment>
                <ExternalReference>{ data($request/Generalcontractdata_1/ExternalReference) }</ExternalReference>
                <InternalReference>{ data($request/Generalcontractdata_1/InternalReference) }</InternalReference>
                <Characteristics>{ data($request/Generalcontractdata_1/Characteristics) }</Characteristics>
                <AuthGroup>{ data($request/Generalcontractdata_1/AuthGroup) }</AuthGroup>
                <CreateUser>{ data($request/Generalcontractdata_1/CreateUser) }</CreateUser>
                <EntryDate>{ data($request/Generalcontractdata_1/EntryDate) }</EntryDate>
                <Facility>{ data($request/Generalcontractdata_1/Facility) }</Facility>
                <FacilityCompanyCode>{ data($request/Generalcontractdata_1/FacilityCompanyCode) }</FacilityCompanyCode>
                <ValuationClass>{ data($request/Generalcontractdata_1/ValuationClass) }</ValuationClass>
                <ExpenseKey>{ data($request/Generalcontractdata_1/ExpenseKey) }</ExpenseKey>
            </Generalcontractdata_1>
            <Generalcontractdata_2>
                <CompanyCode>{ data($request/Generalcontractdata_2/CompanyCode) }</CompanyCode>
                <ProductType>{ data($request/Generalcontractdata_2/ProductType) }</ProductType>
                <TransactionType>{ data($request/Generalcontractdata_2/TransactionType) }</TransactionType>
                <ExternalTransactionNumber>{ data($request/Generalcontractdata_2/ExternalTransactionNumber) }</ExternalTransactionNumber>
                <Partner>{ local:Function_local_AddLeadingZeros(data($request/Generalcontractdata_2/Partner))  }</Partner>
                <ContractDate>{ data($request/Generalcontractdata_2/ContractDate) }</ContractDate>
                <ContractTime>{ data($request/Generalcontractdata_2/ContractTime) }</ContractTime>
                <ContactPerson>{ data($request/Generalcontractdata_2/ContactPerson) }</ContactPerson>
                <Trader>{ data($request/Generalcontractdata_2/Trader) }</Trader>
                <AcctAssignmentRef>{ data($request/Generalcontractdata_2/AcctAssignmentRef) }</AcctAssignmentRef>
                <Portfolio>{ data($request/Generalcontractdata_2/Portfolio) }</Portfolio>
                <FinanceProject>{ data($request/Generalcontractdata_2/FinanceProject) }</FinanceProject>
                <Guarantor>{ data($request/Generalcontractdata_2/Guarantor) }</Guarantor>
                <MasterAgreement>{ data($request/Generalcontractdata_2/MasterAgreement) }</MasterAgreement>
                <Assignment>{ data($request/Generalcontractdata_2/Assignment) }</Assignment>
                <ExternalReference>{ data($request/Generalcontractdata_2/ExternalReference) }</ExternalReference>
                <InternalReference>{ data($request/Generalcontractdata_2/InternalReference) }</InternalReference>
                <Characteristics>{ data($request/Generalcontractdata_2/Characteristics) }</Characteristics>
                <AuthGroup>{ data($request/Generalcontractdata_2/AuthGroup) }</AuthGroup>
                <CreateUser>{ data($request/Generalcontractdata_2/CreateUser) }</CreateUser>
                <EntryDate>{ data($request/Generalcontractdata_2/EntryDate) }</EntryDate>
                <Facility>{ data($request/Generalcontractdata_2/Facility) }</Facility>
                <FacilityCompanyCode>{ data($request/Generalcontractdata_2/FacilityCompanyCode) }</FacilityCompanyCode>
                <ValuationClass>{ data($request/Generalcontractdata_2/ValuationClass) }</ValuationClass>
            </Generalcontractdata_2>
            {
                for $Return in $request/Return
                return
                    <Return>{ $Return/@* , $Return/node() }</Return>
            }
            <SwapAdditions>{ $request/SwapAdditions/@* , $request/SwapAdditions/node() }</SwapAdditions>
            {
                for $Testrun in $request/Testrun
                return
                    <Testrun>{ data($Testrun) }</Testrun>
            }
        </ns0:YbapiFtrFxtCreateswap>
};

declare function local:Function_local_AddLeadingZeros($originalString as xs:string)
as xs:string {
	let $length := string-length($originalString)
	let $difference := (10 - $length)
	
	let $tenZeros := "0000000000"
	let $newString := concat($tenZeros, $originalString)
	let $startPosition := (string-length($newString)) - 9
	let $finalString := substring($newString, $startPosition)
	
	return 
	if ($length < 10) then 
		$finalString	
		
	else($originalString)
		
};

declare variable $request as element(ns0:YbapiFtrFxtCreateswap) external;

xf:FXT_CreateSwap($request)
