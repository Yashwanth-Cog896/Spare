(:: pragma bea:global-element-parameter parameter="$modelMasterHeader1" element="ns0:modelMasterHeader" location="../WSDL/W_ARd_GTMHTSInbound_A_OB.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:YmmInboundHtsProcessing" location="../WSDL/W_ECC_GTMHTSInbound_A_IN.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://monsanto.com/MM/GTMHTSInbound";
declare namespace xf = "http://tempuri.org/US_MM_GTMHTSInbound/XQuery/XQ_ARd_GTMHTSInbound_To_ECC_HTSInbound/";

declare function xf:XQ_ARd_GTMHTSInbound_To_ECC_HTSInbound($modelMasterHeader1 as element(ns0:modelMasterHeader))
    as element(ns1:YmmInboundHtsProcessing) {
        <ns1:YmmInboundHtsProcessing>
            <LAction>{ data($modelMasterHeader1/modelMaster/action) }</LAction>
            <LBatchid>{ data($modelMasterHeader1/batchID) }</LBatchid>
            <LPmatnr>{ data($modelMasterHeader1/modelMaster/partNumber) }</LPmatnr>
            <LtUpdateSet>
                {
                    for $productCountry in $modelMasterHeader1/modelMaster/productCountry
                    return
                        <item>
                            <Yyland1>{ data($productCountry/countryCode) }</Yyland1>
                            <Yypcstawn>{ data($productCountry/hs) }</Yypcstawn>
                            <Yypccomcddet>{ data($productCountry/hsExtension) }</Yypccomcddet>
                            <Yypcexstawn>{ data($productCountry/exportHarmonizedTariffNumber) }</Yypcexstawn>
                            <Yypcexcomcddet>{ data($productCountry/exportHSextension) }</Yypcexcomcddet>
                            <Yyuseimpasexp>{ data($productCountry/useImpHSasExportHS) }</Yyuseimpasexp>
                        </item>
                }
            </LtUpdateSet>
        </ns1:YmmInboundHtsProcessing>
};

declare variable $modelMasterHeader1 as element(ns0:modelMasterHeader) external;

xf:XQ_ARd_GTMHTSInbound_To_ECC_HTSInbound($modelMasterHeader1)
