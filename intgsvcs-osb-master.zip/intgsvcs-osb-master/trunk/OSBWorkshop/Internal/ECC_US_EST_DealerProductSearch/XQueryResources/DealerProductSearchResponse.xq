(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstDlrprodsrchResponse" location="../WSDLs/DealerProductSearch_ECC.WSDL" ::)
(:: pragma bea:global-element-return element="ns0:DealerProductSearchResponse" location="../Schemas/DealerProductSearch.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerProductSearch";
declare namespace xf = "http://tempuri.org/ECC_US_ElectronicStockTransfer_DealerProductSearch/XQueryResources/DealerProductSearchResponse/";

declare function xf:DealerProductSearchResponse($response as element(ns2:YSdsaUsseedEstDlrprodsrchResponse))
    as element(ns0:DealerProductSearchResponse) {
        <ns0:DealerProductSearchResponse Version="1.0">
            <ns0:DealerProductSearchResponseBody RequestType = "{ data($response/DlrHeader/YreqType) }">
                <ns0:DealerProductSearchResponseProperties>
                    <ns0:DealerEntity>
                        <ns0:PartnerIdentifier Type="SAP_ID">{ data($response/DlrHeader/Yykunnr) }</ns0:PartnerIdentifier>
                        <ns0:PartnerName>{ data($response/DlrHeader/Yyname1) }</ns0:PartnerName>
                    </ns0:DealerEntity>
                    {
                    if(data($response/DlrHeader/Yyyear)!='0000') then (                    
                    <ns0:SeedYear>{ xs:integer( data($response/DlrHeader/Yyyear) ) }</ns0:SeedYear>
                    ) else()
                    }
                </ns0:DealerProductSearchResponseProperties>
                <ns0:DealerProductSearchResponseDetails>
                    {
                        for $item in $response/SeedMatlDtls/item
                        return
                            <ns0:DealerProductSearchResponseDetail>
                                <ns0:ProductInformation>
                                    <ns0:ProductIdentification>
                                        <ns0:ProductIdentifier Type="SAP">{ data($item/Yymatnr) }</ns0:ProductIdentifier>
                                        <ns0:ProductName>{ data($item/YysalesTxt) }</ns0:ProductName>
                                    </ns0:ProductIdentification>
                                    <ns0:ProductCrop>{ data($item/Yycrop) }</ns0:ProductCrop>
                                    <ns0:BrandName>{ data($item/YybrandDesc) }</ns0:BrandName>
                                    <ns0:ProductVariety>{ data($item/Yyacronym) }</ns0:ProductVariety>
                                    <ns0:ProductTrait>{ data($item/YytraitDesc) }</ns0:ProductTrait>
                                    <ns0:SeedSize>{ data($item/Yygrdsize) }</ns0:SeedSize>
                                    <ns0:UPC>{ data($item/YyupcCode) }</ns0:UPC>
                                    <ns0:GTIN>{ data($item/Yygtin) }</ns0:GTIN>
                                    <ns0:ProductTreatment>{ data($item/Yyspctrtmtds) }</ns0:ProductTreatment>
                                    <ns0:PackageSizeName>{ data($item/Yypkgsizds) }</ns0:PackageSizeName>
                                    <ns0:PackageTypeDescription>{ data($item/Yypkgtypds) }</ns0:PackageTypeDescription>
                                    <ns0:BaseQuantity>
                                    {
                                        if(data($item/Yysordunit)!='') then (
                                        <ns0:Measurement>
                                            <ns0:MeasurementValue>{ xs:decimal( data($item/Yvsordqty) ) }</ns0:MeasurementValue>
                                            <ns0:UnitOfMeasureCode >{ data($item/Yysordunit) }</ns0:UnitOfMeasureCode>
                                        </ns0:Measurement>
                                        )else()
                                     }
                                    </ns0:BaseQuantity>
                                    {
                                    if(data($response/DlrHeader/YreqType)='HAULBACK') then (
                                    <ns0:ProductPrice>
                                        {if(data($item/Yvpricecuky) !='' )then(
                                        <ns0:MonetaryAmount>                                            
                                            <ns0:MonetaryValue>{ data($item/Yvprice) }</ns0:MonetaryValue>
                                            <ns0:CurencyCode>{ data($item/Yvpricecuky) }</ns0:CurencyCode>
                                        </ns0:MonetaryAmount>
                                         ) else()
                                            }
                                    </ns0:ProductPrice>
                                    ) else()
                                    }
                                </ns0:ProductInformation>
                                {
                                    for $item0 in $response/SeedBtchDtls/item,
                                        $item1 in $item
                                    where data($item0/Yymatnr) = data($item1/Yymatnr)
                                    return
                                        <ns0:LotInformation>
                                            <ns0:LotNumber>{ data($item0/Yycharg) }</ns0:LotNumber>
                                            {if(data($item0/YyseedLb)!='')then(
                                            <ns0:SeedsPerPound>{ xs:integer( data($item0/YyseedLb) ) }</ns0:SeedsPerPound>
                                            )else()
                                            }
                                            {
                                  		  	if(data($response/DlrHeader/YreqType)='HAULBACK') then (
                                            <ns0:DeliveredQuantity>
                                            { if(data($item0/Yymeins)!='') then (
                                                <ns0:Measurement>
                                                    <ns0:MeasurementValue>{ data($item0/Yylfimg) }</ns0:MeasurementValue>
                                                    <ns0:UnitOfMeasureCode>{ data($item0/Yymeins) }</ns0:UnitOfMeasureCode>
                                                </ns0:Measurement>
                                                )else()
                                                }
                                            </ns0:DeliveredQuantity>
                                            )else()
                                            }
                                             {
                                  		  	if(data($response/DlrHeader/YreqType)='HAULBACK') then (
                                            <ns0:SubmittedQuantity>
                                            {
                                            	if(data($item0/YysalesUnit)!='') then(
                                                <ns0:Measurement>
                                                    <ns0:MeasurementValue>{ data($item0/YypreviousSubmi) }</ns0:MeasurementValue>
                                                    <ns0:UnitOfMeasureCode>{ data($item0/YysalesUnit) }</ns0:UnitOfMeasureCode>
                                                </ns0:Measurement>
                                                )else()
                                              }
                                            </ns0:SubmittedQuantity>
                                            )else()
                                            }
                                        </ns0:LotInformation>
                                        
                                }
                                 {
                                    
                                  	if(data($response/DlrHeader/YreqType)='TRANSFER') then (
                                    for $item0 in $response/SeedPkgDtls/item
                                    return
                                    if(data($item0/Yymatnr)!='' and data($item/Yymatnr)= data($item0/Yymatnr))then(
                                        <ns0:PackageInformation>
                                            <ns0:PackageIdentification>
                                                <ns0:PackageIdentifier Type="SAP">{ data($item0/Yymatnrpkg) }</ns0:PackageIdentifier>
                                                <ns0:PackageName>{ data($item0/YysalesTxtpkg) }</ns0:PackageName>
                                            </ns0:PackageIdentification>
                                            <ns0:LotNumber>{ data($item0/Yycharg) }</ns0:LotNumber>
                                            <ns0:PackageCrop>{ data($item0/Yycroppkg) }</ns0:PackageCrop>
                                            <ns0:PackageMaterialGroup>{ data($item0/Yymatklpkg) }</ns0:PackageMaterialGroup>
                                        </ns0:PackageInformation>
                                        )else()
                                      )else()
                                }
                            </ns0:DealerProductSearchResponseDetail>
                    }
               
                   {
                        if(data($response/DlrHeader/YreqType)='TRANSFER') then (
                        for $item in $response/SeedPkgDtls/item
                        return
                        if(data($item/Yymatnr)='')then(
                            <ns0:PackageInformation>
                                <ns0:PackageIdentification>
                                    <ns0:PackageIdentifier Type="SAP">{ data($item/Yymatnrpkg) }</ns0:PackageIdentifier>
                                    <ns0:PackageName>{ data($item/YysalesTxtpkg) }</ns0:PackageName>
                                </ns0:PackageIdentification>
                                <ns0:LotNumber>{ data($item/Yycharg) }</ns0:LotNumber>
                                <ns0:PackageCrop>{ data($item/Yycroppkg) }</ns0:PackageCrop>
                                <ns0:PackageMaterialGroup>{ data($item/Yymatklpkg) }</ns0:PackageMaterialGroup>
                            </ns0:PackageInformation>
                            ) else()
                            )else()
                    }
                </ns0:DealerProductSearchResponseDetails>
            </ns0:DealerProductSearchResponseBody>
            <ns0:DealerProductSearchResponseError>
                <ns0:ErrorType>{ 
                  if (data($response/Messages/item[1]/Type) = "S") then
                            ("Success")
                        else 
                            if (data($response/Messages/item[1]/Type) = "E") then
                                ("Error")
                            else 
                                if (data($response/Messages/item[1]/Type) = "W") then
                                    ("Warning")
                                else 
                                    if (data($response/Messages/item[1]/Type) = "I") then
                                        ("Info")
                                    else 
                                        if (data($response/Messages/item[1]/Type) = "A") then
                                            ("Abort")
                                        else 
                                            ()
                	}
                </ns0:ErrorType>
                <ns0:ErrorMessageClass>{ data($response/Messages/item[1]/Id) }</ns0:ErrorMessageClass>
                {
                if(data($response/Messages/item[1]/Number)!='')then(
                <ns0:ErrorMessageNumber>{ xs:integer( data($response/Messages/item[1]/Number) ) }</ns0:ErrorMessageNumber>
                )else()
                }
                <ns0:ErrorMessageObject>{ data($response/Messages/item[1]/MsgObject) }</ns0:ErrorMessageObject>
                <ns0:ErrorMessageText>{ data($response/Messages/item[1]/ErrDesc) }</ns0:ErrorMessageText>
                <ns0:ErrorMessageDisplayText>{ data($response/Messages/item[1]/ErrDescDisp) }</ns0:ErrorMessageDisplayText>
            </ns0:DealerProductSearchResponseError>           
        </ns0:DealerProductSearchResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstDlrprodsrchResponse) external;

xf:DealerProductSearchResponse($response)
