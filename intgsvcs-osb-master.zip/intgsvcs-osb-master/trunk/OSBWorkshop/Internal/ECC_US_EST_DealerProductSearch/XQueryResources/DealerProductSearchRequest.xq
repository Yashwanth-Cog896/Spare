(:: pragma bea:global-element-parameter parameter="$request" element="ns0:DealerProductSearchRequest" location="../Schemas/DealerProductSearch.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstDlrprodsrch" location="../WSDLs/DealerProductSearch_ECC.WSDL" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerProductSearch";
declare namespace xf = "http://tempuri.org/ECC_US_ElectronicStockTransfer_DealerProductSearch/XQueryResources/DealerProductSearchRequest/";

declare function xf:DealerProductSearchRequest($request as element(ns0:DealerProductSearchRequest))
    as element(ns2:YSdsaUsseedEstDlrprodsrch) {
        <ns2:YSdsaUsseedEstDlrprodsrch>
            <DealerNumber>{ xs:string( data($request/ns0:DealerProductSearchRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier) ) }</DealerNumber>
            {
                for $SpecieCode in $request/ns0:DealerProductSearchRequestBody/ns0:SpecieCode
                return
                    <Specie>{ data($SpecieCode) }</Specie>
            }
            {
                for $SeedYear in $request/ns0:DealerProductSearchRequestBody/ns0:SeedYear
                return
                    <Year>{ xs:string( data($SeedYear) ) }</Year>
            }
            <YreqType>{ xs:string( data($request/ns0:DealerProductSearchRequestBody/@RequestType) ) }</YreqType>
        </ns2:YSdsaUsseedEstDlrprodsrch>
};

declare variable $request as element(ns0:DealerProductSearchRequest) external;

xf:DealerProductSearchRequest($request)
