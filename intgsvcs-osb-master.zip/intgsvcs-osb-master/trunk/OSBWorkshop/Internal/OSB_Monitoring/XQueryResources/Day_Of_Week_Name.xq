declare namespace functx = "http://www.functx.com";

declare function functx:day-of-week-name-en 
  ( $day-of-week-offset as xs:integer? )  as xs:string? {

	if ($day-of-week-offset = 0) then
		'Sunday'
	else
		if ($day-of-week-offset = 1) then
			'Monday'
		else
			if ($day-of-week-offset = 2) then
				'Tuesday'
			else
				if ($day-of-week-offset = 3) then
					'Wednesday'
				else
					if ($day-of-week-offset = 4) then
						'Thursday'
					else
						if ($day-of-week-offset = 5) then
							'Friday'
						else
							'Saturday'
 } ;
  
declare variable $day-of-week-offset as xs:integer external;

functx:day-of-week-name-en ($day-of-week-offset)