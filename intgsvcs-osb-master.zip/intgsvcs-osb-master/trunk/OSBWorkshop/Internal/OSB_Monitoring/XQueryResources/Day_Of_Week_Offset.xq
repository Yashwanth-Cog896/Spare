declare namespace functx = "http://www.functx.com";

declare function functx:day-of-week-offset
  ( $date as xs:date? )  as xs:integer? {

	(xs:integer(($date - xs:date('1901-01-06')) div xdt:dayTimeDuration('P1D')) mod 7)
 } ;
  
declare variable $date as xs:date external;

functx:day-of-week-offset ($date)