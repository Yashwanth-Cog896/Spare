declare namespace urn="urn:monsanto:serviceadmin:services:outage"; 
declare namespace urn1="urn:monsanto:uscomm:service:header";

declare function urn:outageServiceBuildXMLResponse 
  ($appOutaged as xs:string,
   $docId as xs:string,
   $dateTime as xs:string,
   $partnerName as xs:string)  as node() {


   fn-bea:inlinedXML(
      fn:concat(
         '<urn:GetOutageResponse xmlns:urn="urn:monsanto:serviceadmin:services:outage" xmlns:urn1="urn:monsanto:uscomm:service:header">',
            '<urn1:Header>',
               '<urn1:DocumentIdentifier>', $docId, '</urn1:DocumentIdentifier>',
               '<urn1:DocumentDateTime>', $dateTime, '</urn1:DocumentDateTime>',
               '<urn1:From>',
                  '<urn1:PartnerName>Integration Services</urn1:PartnerName>',
                  '<urn1:ContactInformation>',
                     '<urn1:EmailAddress>integration.services.support@monsanto.com</urn1:EmailAddress>',
                  '</urn1:ContactInformation>',
               '</urn1:From>',
               '<urn1:To>',
                  '<urn1:PartnerName>', fn:replace($partnerName, $partnerName, "OutageRequest") , '</urn1:PartnerName>',
               '</urn1:To>',
            '</urn1:Header>',
            '<urn:GetOutageResponseBody >',
               '<urn:ApplicationOutaged>', $appOutaged, '</urn:ApplicationOutaged>',
            '</urn:GetOutageResponseBody>',
         '</urn:GetOutageResponse>'
      )
   )
 };

declare variable $appOutaged as xs:string external;
declare variable $docId as xs:string external;
declare variable $dateTime as xs:string external;
declare variable $partnerName as xs:string external;

urn:outageServiceBuildXMLResponse ($appOutaged, $docId, $dateTime, $partnerName)