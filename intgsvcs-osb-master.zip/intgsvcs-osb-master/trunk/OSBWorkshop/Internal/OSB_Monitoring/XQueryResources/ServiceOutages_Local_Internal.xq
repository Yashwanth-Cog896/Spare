(:
=====================================================================================================================
Template for Outage Service

To add a new system to be in outage add the tags <system> through </system> to the ServiceOutages routing table.
Fill in each ? mark with the appropriate data.

<outages>
	<system>
		<systemName>?</systemName>
		<regularOutageEvent>
			<dayOfWeek>?</dayOfWeek>
			<outageFrom>?</outageFrom>
			<outageTo>?</outageTo>
		</regularOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>?</outageFrom>
			<outageTo>?</outageTo>
		</exceptionOutageEvent>
	</system>
</outages>

Here is an example
	<system>
		<!-- For System ECC -->
		<!-- The regularOutageEvent and exceptionOutageEvent tags can occur more than once -->
		<systemName>ECC</systemName>
		<regularOutageEvent>
			<!-- Regular outage occurs every Sunday from 5am to 7am St. Louis time -->
			<!-- dayOfWeek can be any combination of upper or lowercase letters -->
			<!-- From and To must be in the form HH:MM:SS -->
			<dayOfWeek>Sunday</dayOfWeek>
			<outageFrom>05:00:00</outageFrom>
			<outageTo>07:00:00</outageTo>
		</regularOutageEvent>
		<exceptionOutageEvent>
			<!-- Additional exception outage on 4/17/12 from 5am to 10am St. Louis time -->
			<!-- From and To must be in the form YYYY-MM-DDTHH:MM:SS -->
			<outageFrom>2012-04-15T05:00:00</outageFrom>
			<outageTo>2012-04-15T10:00:00</outageTo>
		</exceptionOutageEvent>
	</system>
=====================================================================================================================
:)

<outages>
	<system>
		<systemName>ECC</systemName>
		<regularOutageEvent>
			<dayOfWeek>Sunday</dayOfWeek>
			<outageFrom>05:00:00</outageFrom>
			<outageTo>23:59:00</outageTo>
		</regularOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-05-13T05:00:00</outageFrom>
			<outageTo>2012-05-13T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-06-17T05:00:00</outageFrom>
			<outageTo>2012-06-17T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-07-15T05:00:00</outageFrom>
			<outageTo>2012-07-15T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-08-19T05:00:00</outageFrom>
			<outageTo>2012-08-19T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-09-16T05:00:00</outageFrom>
			<outageTo>2012-09-16T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-10-14T05:00:00</outageFrom>
			<outageTo>2012-10-14T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-11-18T05:00:00</outageFrom>
			<outageTo>2012-11-18T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-12-16T05:00:00</outageFrom>
			<outageTo>2012-12-16T10:00:00</outageTo>
		</exceptionOutageEvent>
	</system>
	<system>
		<systemName>PI</systemName>
		<exceptionOutageEvent>
			<outageFrom>2012-05-07T05:00:00</outageFrom>
			<outageTo>2012-05-07T23:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-06-17T05:00:00</outageFrom>
			<outageTo>2012-06-17T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-07-15T05:00:00</outageFrom>
			<outageTo>2012-07-15T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-08-19T05:00:00</outageFrom>
			<outageTo>2012-08-19T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-09-16T05:00:00</outageFrom>
			<outageTo>2012-09-16T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-10-14T05:00:00</outageFrom>
			<outageTo>2012-10-14T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-11-18T05:00:00</outageFrom>
			<outageTo>2012-11-18T10:00:00</outageTo>
		</exceptionOutageEvent>
		<exceptionOutageEvent>
			<outageFrom>2012-12-16T05:00:00</outageFrom>
			<outageTo>2012-12-16T10:00:00</outageTo>
		</exceptionOutageEvent>
	</system>
</outages>