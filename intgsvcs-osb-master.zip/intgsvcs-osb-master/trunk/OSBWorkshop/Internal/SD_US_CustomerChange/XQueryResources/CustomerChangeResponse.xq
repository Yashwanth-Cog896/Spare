(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YRdsCustomerChgResponse" location="../WSDLs/39579-YES_Y_RDS_CUSTOMER_CHG.wsdl" ::)
(:: pragma bea:global-element-return element="Y_RDS_CUSTOMER_CHG_OUTPUT" location="../Schemas/IRDCustomerChangeResponse.xsd" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD_US_CustomerChange/XQueryResources/CustomerChangeResponse/";

declare function xf:CustomerChangeResponse($response as element(ns0:YRdsCustomerChgResponse))
    as element(Y_RDS_CUSTOMER_CHG_OUTPUT) {
        <Y_RDS_CUSTOMER_CHG_OUTPUT>
            {
                for $item in $response/ErrorTable/item
                return
                    <ERROR_TABLE>{ data($item/Msgtext) }</ERROR_TABLE>
            }
        </Y_RDS_CUSTOMER_CHG_OUTPUT>
};

declare variable $response as element(ns0:YRdsCustomerChgResponse) external;

xf:CustomerChangeResponse($response)
