(:: pragma bea:global-element-parameter parameter="$request" element="Y_RDS_CUSTOMER_CHG_INPUT" location="../Schemas/IRDCustomerChangeRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns0:YRdsCustomerChg" location="../WSDLs/39579-YES_Y_RDS_CUSTOMER_CHG.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD_US_CustomerChange/XQueryResources/CustomerChangeRequest/";

declare function xf:CustomerChangeRequest($request as element(Y_RDS_CUSTOMER_CHG_INPUT))
    as element(ns0:YRdsCustomerChg) {
        <ns0:YRdsCustomerChg>
            <CustomerInfo>
                {
                    for $Y_YVCUSTCHGI_ROW in $request/Y_YVCUSTCHGI_TABLE/Y_YVCUSTCHGI_ROW
                    return
                        <item>
                            <Yyrdsstgid>{ data($Y_YVCUSTCHGI_ROW/YYRDSSTGID_PARM) }</Yyrdsstgid>
                            <Yykunnr>{ data($Y_YVCUSTCHGI_ROW/YYKUNNR_PARM) }</Yykunnr>
                            <Yyname1>{ data($Y_YVCUSTCHGI_ROW/YYNAME1_PARM) }</Yyname1>
                            <Yyname2>{ data($Y_YVCUSTCHGI_ROW/YYNAME2_PARM) }</Yyname2>
                            <Yyname3>{ data($Y_YVCUSTCHGI_ROW/YYNAME3_PARM) }</Yyname3>
                            <Yystras>{ data($Y_YVCUSTCHGI_ROW/YYSTRAS_PARM) }</Yystras>
                            <Yyname4>{ data($Y_YVCUSTCHGI_ROW/YYNAME4_PARM) }</Yyname4>
                            <Yyort01>{ data($Y_YVCUSTCHGI_ROW/YYORT01_PARM) }</Yyort01>
                            <Yyregio>{ data($Y_YVCUSTCHGI_ROW/YYREGIO_PARM) }</Yyregio>
                            <Yypstlz>{ data($Y_YVCUSTCHGI_ROW/YYPSTLZ_PARM) }</Yypstlz>
                            <Yytelf1>{ data($Y_YVCUSTCHGI_ROW/YYTELF1_PARM) }</Yytelf1>
                            <Yytelfx>{ data($Y_YVCUSTCHGI_ROW/YYTELFX_PARM) }</Yytelfx>
                            <Yyland1>{ data($Y_YVCUSTCHGI_ROW/YYLAND1_PARM) }</Yyland1>
                            <Yypfach>{ data($Y_YVCUSTCHGI_ROW/YYPFACH_PARM) }</Yypfach>
                            <Yypstl2>{ data($Y_YVCUSTCHGI_ROW/YYPSTL2_PARM) }</Yypstl2>
                            <Yypfort>{ data($Y_YVCUSTCHGI_ROW/YYPFORT_PARM) }</Yypfort>
                            <Yycounc>{ data($Y_YVCUSTCHGI_ROW/YYCOUNC_PARM) }</Yycounc>
                            <Yysortl>{ data($Y_YVCUSTCHGI_ROW/YYSORTL_PARM) }</Yysortl>
                            <Yyaddr3>{ data($Y_YVCUSTCHGI_ROW/YYADDR3_PARM) }</Yyaddr3>
                            <Yyaddr1b>{ data($Y_YVCUSTCHGI_ROW/YYADDR1B_PARM) }</Yyaddr1b>
                            <Yyaddr2b>{ data($Y_YVCUSTCHGI_ROW/YYADDR2B_PARM) }</Yyaddr2b>
                            <Yyaddr3b>{ data($Y_YVCUSTCHGI_ROW/YYADDR3B_PARM) }</Yyaddr3b>
                            <Yycityb>{ data($Y_YVCUSTCHGI_ROW/YYCITYB_PARM) }</Yycityb>
                            <Yyregionb>{ data($Y_YVCUSTCHGI_ROW/YYREGIONB_PARM) }</Yyregionb>
                            <Yyzipb>{ data($Y_YVCUSTCHGI_ROW/YYZIPB_PARM) }</Yyzipb>
                            <Yycountryb>{ data($Y_YVCUSTCHGI_ROW/YYCOUNTRYB_PARM) }</Yycountryb>
                            <Yycountyb>{ data($Y_YVCUSTCHGI_ROW/YYCOUNTYB_PARM) }</Yycountyb>
                            <YychgTyp>{ data($Y_YVCUSTCHGI_ROW/YYCHG_TYP_PARM) }</YychgTyp>
                            <YyacctId>{ data($Y_YVCUSTCHGI_ROW/YYACCT_ID_PARM) }</YyacctId>
                        </item>
                }
            </CustomerInfo>
            {
            <ErrorTable>
                <item>
                    <Msgtext>EMPTY</Msgtext>
                </item>
            </ErrorTable>
            }
        </ns0:YRdsCustomerChg>
};

declare variable $request as element(Y_RDS_CUSTOMER_CHG_INPUT) external;

xf:CustomerChangeRequest($request)
