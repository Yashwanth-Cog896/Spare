declare namespace xf = "http://tempuri.org/DOCUSIGN_TO_EMTSASTATUS/push_to_status/";
declare namespace ns0 = "urn:monsanto:uscomm:isd:emtsa:status:1:0";
declare namespace ns-1 = "http://www.docusign.net/API/3.0";

declare function xf:push_to_status($envelopeStatus1 as element(ns-1:EnvelopeStatus))
    as element(ns0:EnvelopeStatus) {
        <ns0:EnvelopeStatus xmlns="urn:monsanto:uscomm:isd:emtsa:status:1:0">
           <EnvelopeId>{ data($envelopeStatus1/ns-1:EnvelopeID) }</EnvelopeId>			            				
            {
            for $RecipientStatus in $envelopeStatus1/ns-1:RecipientStatuses/ns-1:RecipientStatus
            order by $RecipientStatus/ns-1:RoutingOrder
            return            	
	            	if(data($RecipientStatus/ns-1:RoutingOrder)="1") 
	            	then             	
						(<FormNumber>{ data($RecipientStatus/ns-1:CustomFields/ns-1:CustomField[1]) }</FormNumber>,
						if(data($RecipientStatus/ns-1:RecipientAuthenticationStatus/ns-1:IDQuestionsResult/ns-1:Status)="Failed")
		            	then <GrowerStatus>{ data($RecipientStatus/ns-1:RecipientAuthenticationStatus/ns-1:IDQuestionsResult/ns-1:Status) }</GrowerStatus>
		            	else <GrowerStatus>{ data($RecipientStatus/ns-1:Status) }</GrowerStatus>
		            	)            	
	            	else if(data($RecipientStatus/ns-1:RoutingOrder)="2" and data($RecipientStatus/ns-1:Type)="Signer")
                    then
     					(<CoSignerStatus>{ data($RecipientStatus/ns-1:Status) }</CoSignerStatus>
		     			,
		     			for $TabStatuses in $RecipientStatus/ns-1:TabStatuses
		                return
		                  for $TabStatus in $TabStatuses/ns-1:TabStatus
		                  return
		                    if(data($TabStatus/ns-1:TabName)="LICENSE NUMBER")
		                    then <LicenseNumber>{ data($TabStatus/ns-1:TabValue) }</LicenseNumber>                    
		                    else ()
		                )
                    else()    
			}			
		</ns0:EnvelopeStatus>	
};

declare variable $envelopeStatus1 as element(ns-1:EnvelopeStatus) external;

xf:push_to_status($envelopeStatus1)