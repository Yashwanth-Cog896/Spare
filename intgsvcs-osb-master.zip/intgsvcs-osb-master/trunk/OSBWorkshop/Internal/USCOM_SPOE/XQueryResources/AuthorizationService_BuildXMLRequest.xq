declare function local:authorizationServiceBuildXMLRequest($accountNumberText as xs:string, $docId as xs:string, $dateTime as xs:string, $partnerName as xs:string)
as element() 
{
<urn:GetAuthorizationRequest xmlns:urn="urn:monsanto:serviceadmin:services:authorization">
	<mon:Header xmlns:mon="urn:monsanto:uscomm:service:header">
		<mon:DocumentIdentifier>{$docId}</mon:DocumentIdentifier>
		<mon:DocumentDateTime>{$dateTime}</mon:DocumentDateTime>
		<mon:From>
			<mon:PartnerName>{$partnerName}</mon:PartnerName>
		</mon:From>
	</mon:Header>
	<urn:GetAuthorizationRequestBody>
		<urn:UserId>{$accountNumberText}</urn:UserId>
		<urn:AuthorizationRequestType>
           	<urn:RequestType>Role</urn:RequestType>
		</urn:AuthorizationRequestType>
	</urn:GetAuthorizationRequestBody>
</urn:GetAuthorizationRequest>
};

declare variable $accountNumberText as xs:string external;
declare variable $docId as xs:string external;
declare variable $dateTime as xs:string external;
declare variable $partnerName as xs:string external;

local:authorizationServiceBuildXMLRequest($accountNumberText, $docId, $dateTime, $partnerName)