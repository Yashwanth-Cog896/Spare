(:	Template for SinglePointOfEntry

To add a new service add the tags <service> through </service> to the ServiceOptions routing table.
Fill in each ? mark with the appropriate field.  T/F for all attributes.  Based on whether the attributes
are true or false will determine if a value between the tags is needed.  Refer to the SinglePointOfEntry.docx 
on teamsite on how to use the SinglePointOfEntry Proxy Service.

	<service>
		<rootNode Version="?">?</rootNode>
		<security CheckMessageLevelAuthentication="?">
			<authorizationPipeline CheckAuthorization="?">?</authorizationPipeline>
		</security>
		<outageName CheckForOutage="?">?</outageName>
		<validationRequestProxy ValidateRequest="?">?</validationRequestProxy>
		<responseValidation ValidateResponse="?">
			<validationResponseProxy>?</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>?</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>?</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>?</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>?</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="?"></transformRequest>
		<transformResponse ExecuteTransformation="?"></transformResponse>
		<messageReporting ReportRequestResponse="?" ReportErrors="?">
			<serviceName InboundService="?" ExternalService="?" NexusService="?">?</serviceName>
			<headerType>?</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>?</alertEmailAddressDefault>
			<alertEmailAddressPS>?</alertEmailAddressPS>
			<alertEmailAddressIT>?</alertEmailAddressIT>
			<alertEmailAddressDevl>?</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="?">?</routeToBS>
		<QoS ExactlyOnce="?">
			<retryCount BestEffort="?">?</retryCount>
			<intervalTimeSeconds>?</intervalTimeSeconds>
		</QoS>
	</service>	
:)

<serviceOptions>

		<service>
		<rootNode Version="0.0">Z_ZCLAIMS_CIS_UPDATE_INPUT</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F">US_SD_ZClaimsCISUpadte/ProxyServices/PS_KMM_ZClaimsCISUpdate_Req</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy>US_SD_ZClaimsCISUpadte/ProxyServices/PS_KMM_ZClaimsCISUpdate_Rsp</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">US_SD_ZClaimsCISUpadte/XQuery/MM_KMM_To_ECC_ZClaimsCISUpadte_Req</transformRequest>
		<transformResponse ExecuteTransformation="T">US_SD_ZClaimsCISUpadte/XQuery/MM_KMM_To_ECC_ZClaimsCISUpadte_Rsp</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="F" NexusService="F">KMMZClaimsCISUpdate</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-US-SeedsandTraits-SAPOTC@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">US_SD_ZClaimsCISUpadte/BuisnessServices/BS_ECC_ZClaimsCISUpdate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
		
	<service>
		<rootNode Version="1.0">MassTransferRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Product/ProxyServices/MassTransfer</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Product/ProxyServices/MassTransferResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">USCOM_Product/XQueryResources/MassTransferRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">USCOM_Product/XQueryResources/MassTransferResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">MassTransfer</serviceName>
			<headerType>CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="YSdsaSalesdocMassAsi">USCOM_Product/BusinessServices/MassTransfer</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
		
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSO_ListShipTos_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/ListShipTos</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/ListShipTosResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ListShipTos</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/ListShipTos</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSO_OrderChange_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/OrderChange</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/OrderChangeResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderChange</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/OrderChange</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderCreate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/OrderCreate</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/OrderCreateResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderCreate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/OrderCreate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderDetails_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/OrderDetails</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/OrderDetailsResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderDetails</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/OrderDetails</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderDetailsModify_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/OrderDetailsModify</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/OrderDetailsModifyResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderDetailsModify</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/OrderDetailsModify</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderSummary_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/OrderSummary</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/OrderSummaryResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderSummary</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/OrderSummary</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOProductSelection_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/ProductSelection</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/ProductSelectionResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ProductSelection</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/ProductSelection</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOSalesRepSoldTos_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_SeedOrdering/ProxyServices/SalesRepSoldTos</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_SeedOrdering/ProxyServices/SalesRepSoldTosResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SalesRepSoldTos</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_SeedOrdering/BusinessServices/SalesRepSoldTos</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">saveAnalytics</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Analytics/ProxyServices/SeedTrakClient</validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">STAnalyticsClient</serviceName>
			<headerType>uscom</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SeedTrak-Developers@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Analytics/BusinessServices/SeedTrakClient</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">uploadAnalyticsData</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Analytics/ProxyServices/SeedTrakMobile</validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">STAnalyticsMobile</serviceName>
			<headerType>uscom</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SeedTrak-Developers@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Analytics/BusinessServices/SeedTrakMobile</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="2.0.2">OrderCreate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_ChemOrders/ProxyServices/OrderCreate</validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="T">ChemOrderCreate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-AG-ITEcommerceB2B@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_ChemOrders/BusinessServices/OrderCreate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">TreatmentComponentsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/AcceleronService_ComponentsAndTraits</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/AcceleronService_ComponentsAndTraitsResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ComponentsAndTraits</serviceName>
			<headerType>cidx50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/AcceleronService_ComponentsAndTraits</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronReconciliationReporting_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/AcceleronService_ReconciliationReporting</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/AcceleronService_ReconciliationReportingResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReconciliationReporting</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/AcceleronService_ReconciliationReporting</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">MT_AcceleronYearEndReportingDisplay_OSB_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/AcceleronService_YearEndReportingDisplay</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/AcceleronService_YearEndReportingDisplayResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">YearEndReportingDisplay</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/AcceleronService_YearEndReportingDisplay</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_AcceleronYearEndReportingSaveSubmit_OSB_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/AcceleronService_YearEndReportingSaveSubmit</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/AcceleronService_YearEndReportingSaveSubmitResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">YearEndReportingSaveSubmit</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/AcceleronService_YearEndReportingSaveSubmit</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GeneticsFavoritesSave_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_GeneticsFavoritesSave</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_GeneticsFavoritesSaveResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_GeneticsFavoritesSave</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_GeneticsFavoritesSave</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GeneticsHistoryDetail_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_GeneticsHistoryDetail</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_GeneticsHistoryDetailResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_GeneticsHistoryDetail</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_GeneticHistoryDetail</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GeneticsHistorySummary_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_GeneticsHistorySummary</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_GeneticsHistorySummaryResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_GeneticsHistorySummary</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_GeneticsHistorySummary</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GeneticsLicensBrandRetri_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_GeneticsLicenseeBrandsRetrieve</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_GeneticsLicenseeBrandsRetrieveResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_GeneticsLicenseeBrandsRetrieve</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_GeneticsLicenseeBrandsRetrieve</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GenetcProdMastrFavorRetri_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_GeneticsProductMaster</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_GeneticsProductMasterResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_GeneticsProductMaster</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_GeneticsProductMaster</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GeneticsUOMRetrieve_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_GeneticsUnitOfMeasurementRetrieve</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_GeneticsUnitOfMeasurementRetrieveResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_GeneticsUnitOfMeasurementRetrieve</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_GeneticsUnitOfMeasurementRetrieve</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_RRTraitAdjustment_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_TraitAdjustment</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_TraitAdjustmentResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_TraitAdjustment</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_TraitAdjustment</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_RRTraitHistory_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Trait/ProxyServices/CSRFS_TraitHistory</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Trait/ProxyServices/CSRFS_TraitHistoryResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CSRFS_TraitHistory</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Trait/BusinessServices/CSRFS_TraitHistory</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">FIDORequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FIDO/ProxyServices/FIDOFieldScore</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>FIDO/ProxyServices/FIDOFieldScoreResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>global.support.fido@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="F" NexusService="F">FIDOFieldScore</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>global.support.fido@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FIDO/BusinessServices/FIDOFieldScore</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">FIDOPlantingRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FIDO/ProxyServices/FIDOPlantingTrips</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>FIDO/ProxyServices/FIDOPlantingTripsResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>global.support.fido@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="F" NexusService="F">FIDOPlantingTrips</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>global.support.fido@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FIDO/BusinessServices/FIDOPlantingTrips</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">SeminisFIDORequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FIDO/ProxyServices/FIDOSeminisEstYield</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>FIDO/ProxyServices/FIDOSeminisEstYieldResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>global.support.fido@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="F" NexusService="F">FIDOSeminisEstYield</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>global.support.fido@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FIDO/BusinessServices/FIDOSeminisEstYield</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">GetMinuteHistory</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/CommodityPrice_CBOT</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="F" ExternalService="F" NexusService="F">CommodityPrice_CBOT</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-IT-CBOT@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="GetMinuteHistory">USCOM_Seed/BusinessServices/CommodityPrice_CBOT</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_WLASampleRetrieval_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_QM/ProxyServices/SampleRetrieval</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_QM/ProxyServices/SampleRetrievalResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>qm.team.sap@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SampleRetrieval</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>qm.team.sap@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_QM/BusinessServices/SampleRetrieval</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_WLAPlantingDate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_QM/ProxyServices/PlantingDate</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_QM/ProxyServices/PlantingDateResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>qm.team.sap@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">PlantingDate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>qm.team.sap@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_QM/BusinessServices/PlantingDate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GROrder_Details_SRX_OB</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECOM_GrowerOrders/ProxyServices/GrowerOrderDetails_1-0</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>ECOM_GrowerOrders/ProxyServices/GrowerOrderDetailsResponse_1-0</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GrowerOrderDetails_1-0</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECOM_GrowerOrders/BusinessServices/GrowerOrderDetails_1-0</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_GROrder_List_SRX_OB</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECOM_GrowerOrders/ProxyServices/GrowerOrderList_1-0</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>ECOM_GrowerOrders/ProxyServices/GrowerOrderListResponse_1-0</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GrowerOrderList_1-0</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECOM_GrowerOrders/BusinessServices/GrowerOrderList_1-0</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">dealerDetail</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/GOTDealerDetail</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GOTDealerDetail</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/GOTDealer</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">dealerSummary</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/GOTDealerSummary</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GOTDealerSummary</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/GOTDealer</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">Y_FIAR_BZ_CREDIT_FD32</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAS_Customer/ProxyServices/Credit</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">LASCredit</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-LA-505001OSBINTERFACE@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAS_Customer/BusinessServices/Credit</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">Y_SDSA_BILL_CREATE_APL</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAS_SalesDoc/ProxyServices/BillCreate</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">LASBillCreate</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-LA-505001OSBINTERFACE@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAS_SalesDoc/BusinessServices/BillCreate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">BAPI_SALESDOCU_CREATEFROMDATA1</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAS_SalesDoc/ProxyServices/SalesOrder1</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">LASSalesOrder1</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-LA-505001OSBINTERFACE@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAS_SalesDoc/BusinessServices/SalesOrder1</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">BAPI_SALESORDER_CREATEFROMDAT2</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAS_SalesDoc/ProxyServices/SalesOrder2</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">LASSalesOrder2</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-LA-505001OSBINTERFACE@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAS_SalesDoc/BusinessServices/SalesOrder2</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">Y_SDSA_SO_CHANGE_APL2</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAS_SalesDoc/ProxyServices/SalesOrderChange</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">LASSalesOrderChange</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-LA-505001OSBINTERFACE@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAS_SalesDoc/BusinessServices/SalesOrderChange</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_TreaterOrderSummary_OSB_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/AcceleronService_TreaterOrderSummaryECCRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/AcceleronService_TreaterOrderSummaryECCResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@Monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">USCOM_Seed/XQueryResources/TreaterOrderSummaryRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">USCOM_Seed/XQueryResources/TreaterOrderSummaryResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">TreaterOrderSummaryToECC</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@Monsanto.com,integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/AcceleronService_TreaterOrderSummaryECC</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronProductService_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/ProductServiceRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/ProductServiceResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ProductService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com,integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/ProductService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronOrderDetail_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/OrderDetailRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/OrderDetailResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderDetail</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com,integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/OrderDetail</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronOrderUpdate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/OrderUpdateRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/OrderUpdateResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>DL-1000-SEEDTRMT-IT@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">OrderUpdate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com,integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/OrderUpdate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	<service>
		<rootNode Version="0.0">CSRStatusLookup_CRM_Sync</rootNode>
		<security CheckMessageLevelAuthentication="F">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CIC_Telephony/ProxyServices/CICTelephonyRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>CIC_Telephony/ProxyServices/CICTelephonyResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CIC_Telephony/XQueryResources/CICRequest_Transformation</transformRequest>
		<transformResponse ExecuteTransformation="T">CIC_Telephony/XQueryResources/CICResponse_Transformation</transformResponse>
		<messageReporting ReportRequestResponse="F" ReportErrors="F">
			<serviceName InboundService="F" ExternalService="T" NexusService="F">CICTelephony_Service</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="F">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CIC_Telephony/BusinessServices/CICTelephony</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">findGrower</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/GrowerLookupRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Grower/ProxyServices/GrowerLookupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/GrowerLookup</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">findProgramsParticipating</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/GrowerLookupRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Grower/ProxyServices/GrowerLookupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/GrowerLookup</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">version</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/GrowerLookupRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Grower/ProxyServices/GrowerLookupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/GrowerLookup</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">findGrowerBySalesAssociate</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/GrowerLookupRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Grower/ProxyServices/GrowerLookupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/GrowerLookup</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">FileUploadStatusUpdateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Seed/ProxyServices/FileUploadStatusRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Seed/ProxyServices/FileUploadStatusResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FileUploadStatus</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Seed/BusinessServices/FileUploadStatus</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_PCICustomerHeaderAck</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_PCI/ProxyServices/PriceSheetAcknowledgementRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_PCI/ProxyServices/PriceSheetAcknowledgementResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="T">PriceSheetAcknowledgement</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-AG-ITEcommerceB2B@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_PCI/BusinessServices/PriceSheetAcknowledgement</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">ProductPricingRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F">USCOM_Product/ProxyServices/GetProductPricingRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy>USCOM_Product/ProxyServices/GetProductPricingResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GetProductPricing</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Product/BusinessServices/GetProductPricing</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	<service>
		<rootNode Version="0.0">accountLinkCheckRequest</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Grower/ProxyServices/SingleSignOnRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_Grower/ProxyServices/SingleSignOnResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SingleSignOn</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Grower/BusinessServices/SingleSignOn</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AllocationRequest_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_DFS_Migration/ProxyServices/AllocationRequest_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_DFS_Migration/ProxyServices/AllocationRequest_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">AllocationRequest</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_DFS_Migration/BusinessServices/AllocationRequest</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AllocationUpdate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_DFS_Migration/ProxyServices/AllocationUpdateRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_DFS_Migration/ProxyServices/AllocationUpdateResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">AllocationUpdate</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_DFS_Migration/BusinessServices/AllocationUpdate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	<service>
		<rootNode Version="1.0">FuturesPricingRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">MM_US_SoybeanHedg_FuturePrices/ProxyServices/FuturesPricingRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>MM_US_SoybeanHedg_FuturePrices/ProxyServices/FuturesPricingResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">MM_US_SoybeanHedg_FuturePrices/XQueryResources/FuturePricingRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">MM_US_SoybeanHedg_FuturePrices/XQueryResources/FuturePricingResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FuturesPricing</serviceName>
			<headerType SaveHeaderForResponse="T">PIBLANK</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">MM_US_SoybeanHedg_FuturePrices/BusinessServices/FuturesPricing</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="0.0">YbapiFtrCreateFxoptions</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CFM_360T/ProxyServices/Create_FXOptions_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>CFM_360T/ProxyServices/Create_FXOptions_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CFM_360T/XQueryTransformations/Create_FXOptions_Request</transformRequest>
		<transformResponse ExecuteTransformation="T">CFM_360T/XQueryTransformations/Create_FXOptions_Response</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">360T_CreateFXOptions</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CFM_360T/BusinessServices/Create_FXOptions</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	<service>
		<rootNode Version="0.0">YbapiFtrFtdCreate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CFM_360T/ProxyServices/FTD_Create_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>CFM_360T/ProxyServices/FTD_Create_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CFM_360T/XQueryTransformations/FTD_Create_Request</transformRequest>
		<transformResponse ExecuteTransformation="T">CFM_360T/XQueryTransformations/FTD_Create_Response</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">360T_FTDCreate</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CFM_360T/BusinessServices/FTD_Create</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFtdRollover</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CFM_360T/ProxyServices/FTD_Rollover_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>CFM_360T/ProxyServices/FTD_Rollover_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CFM_360T/XQueryTransformations/FTD_Rollover_Request</transformRequest>
		<transformResponse ExecuteTransformation="T">CFM_360T/XQueryTransformations/FTD_Rollover_Response</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">360T_FTDRollover</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CFM_360T/BusinessServices/FTD_Rollover</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFxtCreate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CFM_360T/ProxyServices/FXT_Create_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>CFM_360T/ProxyServices/FXT_Create_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CFM_360T/XQueryTransformations/FXT_Create_Request</transformRequest>
		<transformResponse ExecuteTransformation="T">CFM_360T/XQueryTransformations/FXT_Create_Response</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">360T_FXTCreate</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CFM_360T/BusinessServices/FXT_Create</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFxtCreateswap</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CFM_360T/ProxyServices/FXT_CreateSwap_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>CFM_360T/ProxyServices/FXT_CreateSwap_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CFM_360T/XQueryTransformations/FXT_CreateSwap_Request</transformRequest>
		<transformResponse ExecuteTransformation="T">CFM_360T/XQueryTransformations/FXT_CreateSwap_Response</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">360T_FXTCreateSwap</serviceName>
			<headerType SaveHeaderForResponse="T">piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CFM_360T/BusinessServices/FXT_CreateSwap</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">SoybeanHedgingListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">MM_US_SoybeanHedg_ElevHistory/ProxyServices/SoybeanHedgingListRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>MM_US_SoybeanHedg_ElevHistory/ProxyServices/SoybeanHedgingListResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">MM_US_SoybeanHedg_ElevHistory/XQueryResources/ElevHistoryRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">MM_US_SoybeanHedg_ElevHistory/XQueryResources/ElevHistoryResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SoybeanHedgingList</serviceName>
			<headerType SaveHeaderForResponse="T">PIBLANK</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">MM_US_SoybeanHedg_ElevHistory/BusinessServices/SoybeanHedgingList</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="1.0">SoybeanHedgingChangeRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">MM_US_SoybeanHedg_CreateUpdateDelete/ProxyServices/SoybeanHedgingChangeRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>MM_US_SoybeanHedg_CreateUpdateDelete/ProxyServices/SoybeanHedgingChangeResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">MM_US_SoybeanHedg_CreateUpdateDelete/XQueryResources/SoybeanHedgingChangeRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">MM_US_SoybeanHedg_CreateUpdateDelete/XQueryResources/SoybeanHedgingChangeResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SoybeanHedgingChange</serviceName>
			<headerType SaveHeaderForResponse="T">PIBLANK</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">MM_US_SoybeanHedg_CreateUpdateDelete/BusinessServices/SoybeanHedgingChange</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="0.0">getCropsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getProductsBySalesTerritoriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getSubCountriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getSubSubCountriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getSupportedYearsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getIPlotPdfReportRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getIPlotReportDataRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">harvestReportDomainRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsByCRDsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsByPostalCodeAndRadiusRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsBySubCountriesAndSubsubCountriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsByTerritorySalesManagersRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">smartServiceDomainRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/IPlotDataService_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/IPlotDataService_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/IPlotDataService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="0.0">seedingRateVersion</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">US_AGS_SeedingRateService/ProxyServices/AGSSeedingRateServiceRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>US_AGS_SeedingRateService/ProxyServices/AGSSeedingRateServiceResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SeedingRateService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">US_AGS_SeedingRateService/BusinessServices/AGSSeedingRateService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	<service>
		<rootNode Version="0.0">calculateSeedingRate</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">US_AGS_SeedingRateService/ProxyServices/AGSSeedingRateServiceRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>US_AGS_SeedingRateService/ProxyServices/AGSSeedingRateServiceResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SeedingRateService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">US_AGS_SeedingRateService/BusinessServices/AGSSeedingRateService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getProductHPIDetails</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">US_AGS_SeedProductDetails/ProxyServices/AGSSeedProductDetailsRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>US_AGS_SeedProductDetails/ProxyServices/AGSSeedProductDetailsResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ProductHPIStabilityService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">US_AGS_SeedProductDetails/BusinessServices/AGSSeedProductDetails</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getProductStabilityDetails</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">US_AGS_SeedProductDetails/ProxyServices/AGSSeedProductDetailsRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>US_AGS_SeedProductDetails/ProxyServices/AGSSeedProductDetailsResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ProductHPIStabilityService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">US_AGS_SeedProductDetails/BusinessServices/AGSSeedProductDetails</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="0.0">Z_ATMS_AUTO_FILLUP_RFC_INPUT</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="F">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">SD_US_ATMS_AutoFillup/ProxyServices/ATMS_AutoFillupRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>SD_US_ATMS_AutoFillup/ProxyServices/ATMS_AutoFillupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">SD_US_ATMS_AutoFillup/XQueryTransformations/ATMSRequestTransformation</transformRequest>
		<transformResponse ExecuteTransformation="T">SD_US_ATMS_AutoFillup/XQueryTransformations/ATMSResponseTransformation</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="F" NexusService="F">ATMS_AutoFillup</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">SD_US_ATMS_AutoFillup/BusinessServices/ATMS_AutoFillupSPOE</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">Y_RDS_CUSTOMER_CHG_INPUT</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForSSL="F">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">SD_US_CustomerChange/ProxyServices/IRDCustomerChangeRequest</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>SD_US_CustomerChange/ProxyServices/IRDCustomerChangeResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
			<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
			<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
			<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
			<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">SD_US_CustomerChange/XQueryResources/CustomerChangeRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">SD_US_CustomerChange/XQueryResources/CustomerChangeResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="F" NexusService="F">IRDCustomerChange</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">SD_US_CustomerChange/BusinessServices/CustomerChange</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getBrandsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getMonsantoProductsBySalesTerritoriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getMonsantoProductsBySubCountryRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getProductsBySubCountryRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getUomListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_CropPerformance/ProxyServices/ReferenceData_Request</validationRequestProxy>
		<responseValidation ValidateResponse="T">
			<validationResponseProxy>USCOM_CropPerformance/ProxyServices/ReferenceData_Response</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T" MaskErrors="F">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_CropPerformance/BusinessServices/ReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="2.0">ApplicationAnalyticsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USCOM_Analytics/ProxyServices/ApplicationAnalytics</validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ApplicationAnalyticsService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SeedTrak-Developers@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USCOM_Analytics/BusinessServices/ApplicationAnalytics</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiQuotCreatefromdata2</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F"></validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">QuotationCreatefromdata2</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_BZ_MobileApp/BusinessServices/QuotationCreateFromData2</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	<service>
		<rootNode Version="0.0">YBrStatusPreorderGet</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F"></validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>integration.services.delivery@monsanto.com</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>integration.services.delivery@monsanto.com</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>integration.services.delivery@monsanto.com</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">StatusPreorderGet</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_BZ_MobileApp/BusinessServices/StatusPreOrderGet</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerLocationRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_DealerLocation/ProxyServices/DealerLocationRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_ElectronicStockTransfer_DealerLocation/ProxyServices/DealerLocationResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_DealerLocation/XQueryResources/DealerLocationRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_DealerLocation/XQueryResources/DealerLocationResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_DealerLocation</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_DealerLocation/BusinessServices/DealerLocation</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerLookupRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="T">WS_DLRLKUP</outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_DealerLookup/ProxyServices/DealerLookupRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_DealerLookup/ProxyServices/DealerLookupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_DealerLookup/XQueryResources/DealerLookupRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_DealerLookup/XQueryResources/DealerLookupResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_DealerLookup</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_DealerLookup/BusinessServices/DealerLookup</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerProductSearchRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_DealerProductSearch/ProxyServices/DealerProductSearchRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_DealerProductSearch/ProxyServices/DealerProductSearchResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_DealerProductSearch/XQueryResources/DealerProductSearchRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_DealerProductSearch/XQueryResources/DealerProductSearchResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_DealerProductSearch</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_DealerProductSearch/BusinessServices/DealerProductSearch</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">AdvanceProductSearchRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_AdvanceProductSearch/ProxyServices/AdvanceProductSearchRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_AdvanceProductSearch/ProxyServices/AdvanceProductSearchResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_AdvanceProductSearch/XQueryResources/AdvanceProductSearchRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_AdvanceProductSearch/XQueryResources/AdvanceProductSearchResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_AdvanceProductSearch</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_AdvanceProductSearch/BusinessServices/AdvanceProductSearch</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">StockTransferListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
			<USSTAuthorization CheckAuthorization="T">
				<role>ELECTRONIC STOCK TRANSFER SERVICE ACCESS</role>
				<ignoreDataSource>MYMON_ONLINE</ignoreDataSource>
				<!--<ignoreDatasource>Send Another to have multiple</ignoreDatasource>-->
			</USSTAuthorization>			
		</security>
		<outageName CheckForOutage="T">WS_TRNSLIST</outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_StockTransferList/ProxyServices/StockTransferListRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_StockTransferList/ProxyServices/StockTransferListResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_StockTransferList/XQueryResources/StockTransferListRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>				
		<transformResponse ExecuteTransformation="T">ECC_US_EST_StockTransferList/XQueryResources/StockTransferListResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_StockTransferList</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_StockTransferList/BusinessServices/StockTransferListService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">StockTransferUpdateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
			<USSTAuthorization CheckAuthorization="T">
				<role>ELECTRONIC STOCK TRANSFER SERVICE ACCESS</role>
				<ignoreDataSource>MYMON_ONLINE</ignoreDataSource>
				<ignoreDataSource>MYMON_FILE_UPLOAD</ignoreDataSource>
			</USSTAuthorization>
		</security>
		<outageName CheckForOutage="T">WS_TRNSUPDATE</outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_StockTransferUpdate/ProxyServices/StockTransferUpdateRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_StockTransferUpdate/ProxyServices/StockTransferUpdateResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_StockTransferUpdate/XQueryResources/StockTransferUpdateRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_StockTransferUpdate/XQueryResources/StockTransferUpdateResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_UpdateService</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_StockTransferUpdate/BusinessServices/StockTransferUpdate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="1.0">StockTransferDetailsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
			<USSTAuthorization CheckAuthorization="T">
				<role>ELECTRONIC STOCK TRANSFER SERVICE ACCESS</role>
				<ignoreDataSource>MYMON_ONLINE</ignoreDataSource>
			</USSTAuthorization>
		</security>
		<outageName CheckForOutage="T">WS_TRNSDETAIL</outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_StockTransferDetails/ProxyServices/StockTransferDetailsRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_StockTransferDetails/ProxyServices/StockTransferDetailsResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_StockTransferDetails/XQueryResources/StockTransferDetailsRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_StockTransferDetails/XQueryResources/StockTransferDetailsResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_DetailsService</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_StockTransferDetails/BusinessServices/StockTransferDetails</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="1.0">DealerFavoritesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_DealerFavorites/ProxyServices/DealerFavoritesRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_DealerFavorites/ProxyServices/DealerFavoritesResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_DealerFavorites/XQueryResourses/DealerFavoritesRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_DealerFavorites/XQueryResourses/DealerFavoritesResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectronicStockTransfer_DealerFavorites</serviceName>
			<headerType SaveHeaderForResponse="F">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_DealerFavorites/BusinessServices/DealerFavorites</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="1.0">DealerEmailRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_EST_DealerEmail/ProxyServices/DealerEmailRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_EST_DealerEmail/ProxyServices/DealerEmailResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_EST_DealerEmail/XQueryResources/DealerEmailRequest</transformRequest>
		<validationTransformedRequestProxy ValidateRequest="F"></validationTransformedRequestProxy>
		<transformResponse ExecuteTransformation="T">ECC_US_EST_DealerEmail/XQueryResources/DealerEmailResponse</transformResponse>
		<validationTransformedResponseProxy ValidateResponse="F"></validationTransformedResponseProxy>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ElectrnoicStockTransfer_DealerEmail</serviceName>
			<headerType SaveHeaderForResponse="T">USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_EST_DealerEmail/BusinessServices/DealerEmail</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtRfcTradcontract</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>			
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/TradeContractRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/TradeContractResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/TradeContractRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/TradeContractResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_TradeContract</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/TradeContract</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtRfcBarterCampaign</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/CampaignRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/CampaigntResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/CampaignRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/CampaignResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_Campaign</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/Campaign</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtBarterCancelSo</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/CancelSalesOrderRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/CancelSalesOrderResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/CancelSalesOrderRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/CancelSalesOrderResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_CancelSalesOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/CancelSalesOrder</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtContrSimul</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/ContractSimulationRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/ContractSimulationResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/ContractSimulationRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/ContractSimulationResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_ContractSimulation</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/ContractSimulation</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">productChanged</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">US_Lexicon_ProductChangeListner/ProxyServices/ProductChangeListenerServiceRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>US_Lexicon_ProductChangeListner/ProxyServices/ProductChangeListenerServiceResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ProductChangeListenerService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">US_Lexicon_ProductChangeListner/BusinessServices/ProductChangeListenerService</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtCreditCheck</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/CreditCheckRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/CreditCheckResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/CreditCheckRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/CreditCheckResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_CreditCheck</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/CreditCheck</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtQuotaOrder</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/QuotaOrderRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/QuotaOrderResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/QuotaOrderRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/QuotaOrderResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_QuotaOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/QuotaOrder</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtStatusBarter</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/SimulationStatusRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/SimulationStatusResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/SimulationStatusRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/SimulationStatusResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_SimulationStatus</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/SimulationStatus</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtTermsData</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/TermsDataRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/TermsDataResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/TermsDataRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/TermsDataResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_TermsData</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/TermsData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
<service>
		<rootNode Version="0.0">YFibtStatusContract</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/StatusContractRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/StatusContractResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/StatusContractRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/StatusContractResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_StatusContract</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/StatusContract</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YFibtSupportCellInfo</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/SupportCellInfoRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/SupportCellInfoResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/SupportCellInfoRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/SupportCellInfoResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_SupportCellInfo</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/SupportCellInfo</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YFibtTermsOrder</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/TermsOrderRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/TermsOrderResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/TermsOrderRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/TermsOrderResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_TermsOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/TermsOrder</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">AutenticaUsuario</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F">FI-AR_Brazil_Barter/ProxyServices/ProcessBarterRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/ProcessBarterResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_ProcessBarter</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/ProcessBarter</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">IniciarProcesso</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F">FI-AR_Brazil_Barter/ProxyServices/ProcessBarterRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/ProcessBarterResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_ProcessBarter</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/ProcessBarter</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtChangeOrder</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/ChangeSalesOrderRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/ChangeSalesOrderResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/ChangeSalesOrderRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/ChangeSalesOrderResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_ChangeSalesOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/ChangeSalesOrder</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YFibtSalesOrderSimulate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-AR_Brazil_Barter/ProxyServices/SalesOrderSimulationRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-AR_Brazil_Barter/ProxyServices/SalesOrderSimulationResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/SalesOrderSimulationRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-AR_Brazil_Barter/XQueryTransformations/SalesOrderSimulationResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">BrazilBarter_SalesOrderSimulation</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-AR_Brazil_Barter/BusinessServices/SalesOrderSimulation</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="0.0">YFiarGbcredit</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-SD_GoldenBeans/ProxyServices/GBCreditRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-SD_GoldenBeans/ProxyServices/GBCreditResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GBCreditRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GBCreditResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GoldenBeans_GBCredit</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-SD_GoldenBeans/BusinessServices/GBCredit</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YlasPyGbrecla</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-SD_GoldenBeans/ProxyServices/GBReclaRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-SD_GoldenBeans/ProxyServices/GBReclaResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GBReclaRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GBReclaResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GoldenBeans_GBRecla</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-SD_GoldenBeans/BusinessServices/GBRecla</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	

	<service>
		<rootNode Version="0.0">YlasPyGenSoGbToSap</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-SD_GoldenBeans/ProxyServices/GenRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-SD_GoldenBeans/ProxyServices/GenResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GenRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GenResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GoldenBeans_Gen</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-SD_GoldenBeans/BusinessServices/Gen</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	
	<service>
		<rootNode Version="0.0">YlasPyDownInvSapToGb</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-SD_GoldenBeans/ProxyServices/DownRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-SD_GoldenBeans/ProxyServices/DownResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/DownRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/DownResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GoldenBeans_Down</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-SD_GoldenBeans/BusinessServices/Down</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	
	<service>
		<rootNode Version="0.0">YlasPyGbcollect</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">FI-SD_GoldenBeans/ProxyServices/GBCollectRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>FI-SD_GoldenBeans/ProxyServices/GBCollectResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GBCollectRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">FI-SD_GoldenBeans/XQueryTransformations/GBCollectResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GoldenBeans_GBCollect</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">FI-SD_GoldenBeans/BusinessServices/GBCollect</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">RequisitionCreate</rootNode>
		<security CheckMessageLevelAuthentication="F">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">IBM_BPM_PoC/ProxyServices/RequisitionRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>IBM_BPM_PoC/ProxyServices/RequisitionResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">IBM_BPM_PoC/XQueryTransformations/RequisitionRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">IBM_BPM_PoC/XQueryTransformations/RequisitionResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Requisition</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="F">
			<alertEmailAddressDefault></alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">IBM_BPM_PoC/BusinessServices/Requisition</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">SHUpdateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_SHB_DataUpdate/ProxyServices/SHDataUpdateRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_SHB_DataUpdate/ProxyServices/SHDataUpdateResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_SHB_DataUpdate/XQueryResources/SHDataUpdateRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">ECC_US_SHB_DataUpdate/XQueryResources/SHDataUpdateResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SHUpdate</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_SHB_DataUpdate/BusinessServices/SHDataUpdate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
		<service>
		<rootNode Version="1.0">SHDataRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">ECC_US_SHB_DataRequest/ProxyServices/SHDataRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>ECC_US_SHB_DataRequest/ProxyServices/SHDataResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">ECC_US_SHB_DataRequest/XQueryResources/SHDataRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">ECC_US_SHB_DataRequest/XQueryResources/SHDataRequestResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">SHDataRequest</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">ECC_US_SHB_DataRequest/BusinessServices/SHDataRequest</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">CreateSpecialDiscountRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAN_Marketing_SpecialDiscountApprovals/ProxyServices/SpecialDiscountApprovalRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>LAN_Marketing_SpecialDiscountApprovals/ProxyServices/SpecialDiscountApprovalResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">CreateSpecialDiscount</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAN_Marketing_SpecialDiscountApprovals/BusinessServices/SpecialDiscountApproval</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">GetSpecialDiscountApprovalStatusRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAN_Marketing_SpecialDiscountApprovals/ProxyServices/SpecialDiscountApprovalRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>LAN_Marketing_SpecialDiscountApprovals/ProxyServices/SpecialDiscountApprovalResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GetSpecialDiscountApprovalStatus</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAN_Marketing_SpecialDiscountApprovals/BusinessServices/SpecialDiscountApproval</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">GetAccrualsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">LAN_Marketing_SpecialDiscountApprovals/ProxyServices/SpecialDiscountApprovalRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>LAN_Marketing_SpecialDiscountApprovals/ProxyServices/SpecialDiscountApprovalResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">GetAccruals</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">LAN_Marketing_SpecialDiscountApprovals/BusinessServices/SpecialDiscountApproval</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">onServiceResponseUpdated</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">JCAPS_BELGIUM_PLDAWebservice/ProxyServices/PLDAWebserviceRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>JCAPS_BELGIUM_PLDAWebservice/ProxyServices/PLDAWebserviceResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">PLDAWebservice</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">JCAPS_BELGIUM_PLDAWebservice/BusinessServices/PLDAWebservice</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
<service>
		<rootNode Version="1.0">LicenseStatusAdvanceRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USST_MobilityProject/ProxyServices/LicenseStatusRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USST_MobilityProject/ProxyServices/LicenseStatusResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Mobility_LicenseStatus</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USST_MobilityProject/BusinessServices/LicenseStatus</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
<service>
		<rootNode Version="1.0">LicenseStatusIDRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USST_MobilityProject/ProxyServices/LicenseStatusRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USST_MobilityProject/ProxyServices/LicenseStatusResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Mobility_LicenseStatus</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USST_MobilityProject/BusinessServices/LicenseStatus</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	

<service>
		<rootNode Version="1.0">LicenseStatusPostalCodeRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USST_MobilityProject/ProxyServices/LicenseStatusRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USST_MobilityProject/ProxyServices/LicenseStatusResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Mobility_LicenseStatus</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USST_MobilityProject/BusinessServices/LicenseStatus</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	

<service>
		<rootNode Version="1.0">AccountLookupRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USST_MobilityProject/ProxyServices/AccountLookupRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USST_MobilityProject/ProxyServices/AccountLookupResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Mobility_AccountLookup</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USST_MobilityProject/BusinessServices/AccountLookup</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
<service>
		<rootNode Version="1.0">AllBrandProductAvailabilityRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">USST_MobilityProject/ProxyServices/AllBrandProductAvailabilityRequest</validationRequestProxy>
		<ResponseValidation ValidateResponse="T">
			<validationResponseProxy>USST_MobilityProject/ProxyServices/AllBrandProductAvailabilityResponse</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="F"></transformRequest>
		<transformResponse ExecuteTransformation="F"></transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Mobility_AllBrandProductAvailability</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USST_MobilityProject/BusinessServices/AllBrandProductAvailability</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
<service>
		<rootNode Version="2.0">ProductAvailabilityNBRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="F"></validationRequestProxy>
		<ResponseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="F">
				<validationResponseEmailAlertDefault></validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</ResponseValidation>
		<transformRequest ExecuteTransformation="T">USST_MobilityProject/XQueryTransformations/ProductAvailabilityNBRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">USST_MobilityProject/XQueryTransformations/ProductAvailabilityNBResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">Mobility_ProductAvailabilityNB</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">USST_MobilityProject/BusinessServices/ProductAvailabilityNB</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
</serviceOptions>