declare function local:outageServiceBuildXMLRequest ($serviceNameText as xs:string, $docId as xs:string, $dateTime as xs:string, $partnerName as xs:string)  
as element() 
{
<urn:GetOutageRequest xmlns:urn="urn:monsanto:serviceadmin:services:outage">
	<mon:Header xmlns:mon="urn:monsanto:uscomm:service:header">
		<mon:DocumentIdentifier>{$docId}</mon:DocumentIdentifier>
		<mon:DocumentDateTime>{$dateTime}</mon:DocumentDateTime>
		<mon:From>
			<mon:PartnerName>{$partnerName}</mon:PartnerName>
		</mon:From>
	</mon:Header>
	<urn:GetOutageRequestBody>
   		<urn:ApplicationName>{$serviceNameText}</urn:ApplicationName>
	</urn:GetOutageRequestBody>		      		 
</urn:GetOutageRequest>
};

declare variable $serviceNameText as xs:string external;
declare variable $docId as xs:string external;
declare variable $dateTime as xs:string external;
declare variable $partnerName as xs:string external;

local:outageServiceBuildXMLRequest ($serviceNameText, $docId, $dateTime, $partnerName)