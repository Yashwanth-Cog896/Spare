package com.alsb.pojo;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NTCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;

/**
 * @author RRTELL This class is hooked into the java callout hook of the Oracle
 *         Service Bus to communicate with services secured by NTLM security.
 *         This class has a dependency on the following jars:
 *         commons-codec-1.4.jar
 *         ,commons-httpclient-3.1.jar,commons-logging-1.1.1.jar Be sure to
 *         place these jars in the classpath
 */
public class ApacheNTLMClinet {

	/**
	 * @param endPoint
	 *            the endPoint where the business service is running
	 * @param message
	 *            the request message that needs to be forwarded to the business
	 *            service
	 * @param userName
	 *            the user name for NTLM authentication
	 * @param password
	 *            the password for NTLM authentication
	 * @param host
	 *            the host name of the machine on which this call is running
	 * @param domain
	 *            the domain to which the host belongs to
	 * @return the response message from the business service
	 */
	public static String NTLMAuthenticator(String endPoint, String message,
			String userName, String password, String host, String domain) {
		System.out.println("Request message:" + message);
		System.out.println("Endpoint:" + endPoint);
		System.out.println("User Name:" + userName);
		System.out.println("Host:" + host);
		System.out.println("Domain:" + domain);
		HttpClient client = new HttpClient();
		PostMethod postMethod = new PostMethod(endPoint.trim());
		String responseBodyString = "";
		String errroMessage = "";
		try {
			postMethod.setRequestEntity(new StringRequestEntity(message.trim(),
					"application/soap+xml; charset=utf-8", null));
			NTCredentials ntCredentials = new NTCredentials(
					userName.toString(), password.trim(), host.trim(), domain
							.trim());
			client.getState().setCredentials(new AuthScope(null, -1, null),
					ntCredentials);
			int statusCode = client.executeMethod(postMethod);

			if (statusCode != HttpStatus.SC_OK) {
				errroMessage = "Method failed: " + postMethod.getStatusLine();
				System.err.println(errroMessage);

			}

			responseBodyString = postMethod.getResponseBodyAsString();
			System.out.println("Response Message:" + responseBodyString);

		} catch (Exception e) {
			errroMessage = "Fatal protocol violation: " + e.getMessage();
			System.err.println(errroMessage);
			e.printStackTrace();
			responseBodyString = errroMessage;

		} finally {

			postMethod.releaseConnection();
		}

		return responseBodyString;

	}

}
