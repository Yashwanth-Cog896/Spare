(:: pragma bea:global-element-parameter parameter="$priceSheetRequest1" element="ns1:PriceSheetRequest" location="../Schemas/PriceSheetRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns0:PriceSheetRequest" location="../Schemas/PriceSheet.xsd" ::)

declare namespace ns1 = "urn:mon:pricesheetrequest:5:1:1";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:1:1";
declare namespace xf = "http://tempuri.org/US_SeedB2B_PriceSheets/XQueryResources/RequestTransformation/";

declare function xf:RequestTransformation($priceSheetRequest1 as element(ns1:PriceSheetRequest))
    as element(ns0:PriceSheetRequest) {
        let $PriceSheetRequest := $priceSheetRequest1
        return
            <ns0:PriceSheetRequest>
                <ns0:Header>{ $PriceSheetRequest/ns0:Header/@* , $PriceSheetRequest/ns0:Header/node() }</ns0:Header>
                {
                    let $PriceSheetRequestBody := $PriceSheetRequest/ns1:PriceSheetRequestBody
                    return
                        <PriceSheetRequestBody>
                            {
                                let $PriceSheetRequestProperties := $PriceSheetRequestBody/ns1:PriceSheetRequestProperties
                                return
                                    <PriceSheetRequestProperties>
                                        <ns0:CurrencyCode Domain = "{ data($PriceSheetRequestProperties/ns0:CurrencyCode/@Domain) }">{ data($PriceSheetRequestProperties/ns0:CurrencyCode) }</ns0:CurrencyCode>
                                        <ns0:LanguageCode Domain = "{ data($PriceSheetRequestProperties/ns0:LanguageCode/@Domain) }">{ data($PriceSheetRequestProperties/ns0:LanguageCode) }</ns0:LanguageCode>
                                        {
                                            let $LastRequestDate := $PriceSheetRequestProperties/ns1:LastRequestDate
                                            return
                                                <LastRequestDate>
                                                    <ns0:DateTime DateTimeQualifier = "{ data($LastRequestDate/ns0:DateTime/@DateTimeQualifier) }">{ data($LastRequestDate/ns0:DateTime) }</ns0:DateTime>
                                                </LastRequestDate>
                                        }
                                        <ns0:ZoneID>{ data($PriceSheetRequestProperties/ns0:ZoneID) }</ns0:ZoneID>
                                        <ns0:ProductClassification>{ data($PriceSheetRequestProperties/ns0:ProductClassification) }</ns0:ProductClassification>
                                    </PriceSheetRequestProperties>
                            }
                            {
                                let $PriceSheetRequestPartners := $PriceSheetRequestBody/ns1:PriceSheetRequestPartners
                                return
                                    <PriceSheetRequestPartners>
                                        <ns0:Buyer>{ $PriceSheetRequestPartners/ns0:Buyer/@* , $PriceSheetRequestPartners/ns0:Buyer/node() }</ns0:Buyer>
                                    </PriceSheetRequestPartners>
                            }
                        </PriceSheetRequestBody>
                }
            </ns0:PriceSheetRequest>
};

declare variable $priceSheetRequest1 as element(ns1:PriceSheetRequest) external;

xf:RequestTransformation($priceSheetRequest1)
