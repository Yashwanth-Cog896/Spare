(:: pragma bea:global-element-parameter parameter="$request" element="Z_ZCLAIMS_CIS_UPDATE_INPUT" location="../WSDLs/SI_OSB_ZClaimsCISUpdate_S_IB.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:ZZclaimsCisUpdate" location="../WSDLs/SI_OSB_ZClaimsCISUpdate_S_OB.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://monsanto.com/SD/ZClaimsCISUpadte";
declare namespace xf = "http://tempuri.org/US_SD_ZClaimsCISUpadte/XQuery/MM_KMM_To_ECC_ZClaimsCISUpadte_Req/";

declare function xf:MM_KMM_To_ECC_ZClaimsCISUpadte_Req($request as element(Z_ZCLAIMS_CIS_UPDATE_INPUT))
    as element(ns1:ZZclaimsCisUpdate) {
        <ns1:ZZclaimsCisUpdate>
            <ZclaimsIn>
                {
                    for $Z_ZCLAIMS_IN_TAB_ROW in $request/Z_ZCLAIMS_IN_TAB_TABLE/Z_ZCLAIMS_IN_TAB_ROW
                    return
                        <item>
                            <Zzpomethod>{ data($Z_ZCLAIMS_IN_TAB_ROW/ZZPOMETHOD_PARM) }</Zzpomethod>
                            <Zzsrcsysno>{ data($Z_ZCLAIMS_IN_TAB_ROW/ZZSRCSYSNO_PARM) }</Zzsrcsysno>
                            <Zzrectype>{ data($Z_ZCLAIMS_IN_TAB_ROW/ZZRECTYPE_PARM) }</Zzrectype>
                            <Zzfiller>{ data($Z_ZCLAIMS_IN_TAB_ROW/ZZFILLER_PARM) }</Zzfiller>
                        </item>
                }
            </ZclaimsIn>
        </ns1:ZZclaimsCisUpdate>
};

declare variable $request as element(Z_ZCLAIMS_CIS_UPDATE_INPUT) external;

xf:MM_KMM_To_ECC_ZClaimsCISUpadte_Req($request)
