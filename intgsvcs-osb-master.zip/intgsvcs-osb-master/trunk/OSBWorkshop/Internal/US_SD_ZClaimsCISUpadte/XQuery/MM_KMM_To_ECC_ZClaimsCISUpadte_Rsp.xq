(:: pragma bea:global-element-parameter parameter="$response" element="ns1:ZZclaimsCisUpdateResponse" location="../WSDLs/SI_OSB_ZClaimsCISUpdate_S_OB.wsdl" ::)
(:: pragma bea:global-element-return element="Z_ZCLAIMS_CIS_UPDATE_OUTPUT" location="../WSDLs/SI_OSB_ZClaimsCISUpdate_S_IB.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://monsanto.com/SD/ZClaimsCISUpadte";
declare namespace xf = "http://tempuri.org/US_SD_ZClaimsCISUpadte/XQuery/MM_KMM_To_ECC_ZClaimsCISUpadte_Rsp/";

declare function xf:MM_KMM_To_ECC_ZClaimsCISUpadte_Rsp($response as element(ns1:ZZclaimsCisUpdateResponse))
    as element(Z_ZCLAIMS_CIS_UPDATE_OUTPUT) {
        <Z_ZCLAIMS_CIS_UPDATE_OUTPUT>
            <ERROR_MESSAGE_PARM>{ data($response/ErrorMessage) }</ERROR_MESSAGE_PARM>
            <STATUS_MESSAGE_PARM>{ data($response/StatusMessage) }</STATUS_MESSAGE_PARM>
        </Z_ZCLAIMS_CIS_UPDATE_OUTPUT>
};

declare variable $response as element(ns1:ZZclaimsCisUpdateResponse) external;

xf:MM_KMM_To_ECC_ZClaimsCISUpadte_Rsp($response)
