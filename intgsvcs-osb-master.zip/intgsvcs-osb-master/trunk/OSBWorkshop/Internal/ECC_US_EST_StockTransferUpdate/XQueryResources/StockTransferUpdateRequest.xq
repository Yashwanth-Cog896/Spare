(:: pragma bea:global-element-parameter parameter="$request" element="ns0:StockTransferUpdateRequest" location="../Schemas/StockTransferUpdate.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstUpdate" location="../WSDLs/YES_Y_SDSA_USSEED_EST_UPDATE.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:StockTransferUpdate";
declare namespace xf = "http://tempuri.org/ECC_US_EST_StockTransferUpdate/XQueryResources/StockTransferUpdateRequest/";

declare function xf:StockTransferUpdateRequest($request as element(ns0:StockTransferUpdateRequest))
    as element(ns2:YSdsaUsseedEstUpdate) {
        <ns2:YSdsaUsseedEstUpdate>
            <ItHdr>
                {
                    for $StockTransferUpdateRequestDetails in $request/ns0:StockTransferUpdateRequestBody/ns0:StockTransferUpdateRequestDetails
                    return
                        <item>
                        {
                        	                   	                  	
                        	if($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]/@Type ='SALES_ORDER_NUMBER') then (
                        	    <YheaderId>{xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]) )}</YheaderId>			                   
                          		) else if (($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]/@Type ='CLIENT_TRANSACTION_ID') and (fn:empty(data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[2])))) then (
                          		
                          		<YheaderId>{xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]) )}</YheaderId>
                          		) else if ($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]/@Type ='CLIENT_TRANSACTION_ID' and $StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[2]/@Type ='SALES_ORDER_NUMBER') then (
                          		<YheaderId>{xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[2]) )}</YheaderId>
                          		) else()
                          		
                        }    
                        {
                        	for $TransferIdentifier in $StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier
                        	return
                        	if($TransferIdentifier/@Type = 'SALES_ORDER_NUMBER') then (
                        	<Yvbeln>{xs:string( $TransferIdentifier/text()) }</Yvbeln>
                        	) else if($TransferIdentifier/@Type = 'CLIENT_TRANSACTION_ID')then (
                        	<Ytransid>{xs:string( $TransferIdentifier/text()) }</Ytransid>
                        	) else()                  	
                        	
                        }                                 
                            <Yyear>{ xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:SeedYear) ) }</Yyear>
                            <YspartType>{ xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferFrom/ns0:DealerEntity/ns0:PartnerIdentifier[1]/@Type) ) }</YspartType>
                            <Yskunnr>{ xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferFrom/ns0:DealerEntity/ns0:PartnerIdentifier[1]) ) }</Yskunnr>
                            <YrpartType>{ xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferTo/ns0:DealerEntity/ns0:PartnerIdentifier[1]/@Type) ) }</YrpartType>
                            <Yrkunnr>{ xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferTo/ns0:DealerEntity/ns0:PartnerIdentifier[1]) ) }</Yrkunnr>
                            <Ysponum>{ data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferFrom/ns0:PurchaseOrderNumber) }</Ysponum>
                            <Yrponum>{ data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferTo/ns0:PurchaseOrderNumber) }</Yrponum>
                            <Ystatus>{ xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:Status) ) }</Ystatus>
                            <YuserType>{ data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:UserType) }</YuserType>
                            <YuserName>{ data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:UserID) }</YuserName>
                            <YhdrTxt>{ data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:DisputeDescription) }</YhdrTxt>
                        </item>
                }
            </ItHdr>
            <ItItm>
                {
                   for $StockTransferUpdateRequestDetails in $request/ns0:StockTransferUpdateRequestBody/ns0:StockTransferUpdateRequestDetails
                   for $StockTransferUpdateLineItem in $StockTransferUpdateRequestDetails/ns0:StockTransferUpdateLineItem
                    return
                        <item>
                        {
                        	                   	                  	
                        	if($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]/@Type ='SALES_ORDER_NUMBER') then (
                        	    <YheaderId>{xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]) )}</YheaderId>			                   
                          		) else if (($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]/@Type ='CLIENT_TRANSACTION_ID') and (fn:empty(data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[2])))) then (
                          		
                          		<YheaderId>{xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]) )}</YheaderId>
                          		) else if ($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[1]/@Type ='CLIENT_TRANSACTION_ID' and $StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[2]/@Type ='SALES_ORDER_NUMBER') then (
                          		<YheaderId>{xs:string( data($StockTransferUpdateRequestDetails/ns0:StockTransferUpdateRequestProperties/ns0:TransferIdentifier[2]) )}</YheaderId>
                          		) else()
                          		
                        }   
                            <YitmInd>{ xs:string( data($StockTransferUpdateLineItem/@Action) ) }</YitmInd>
                            <Yitmno>{ xs:string( data($StockTransferUpdateLineItem/ns0:ItemNumber) ) }</Yitmno>
                            <YrefItm>{ xs:string( data($StockTransferUpdateLineItem/ns0:ReferenceItemNumber) ) }</YrefItm>
                            <YmatInd>{ xs:string( data($StockTransferUpdateLineItem/ns0:ProductIdentification/ns0:ProductIdentifier/@Type) ) }</YmatInd>
                            <Ymatnr>{ xs:string( data($StockTransferUpdateLineItem/ns0:ProductIdentification/ns0:ProductIdentifier) ) }</Ymatnr>
                            <Ycharg>{ data($StockTransferUpdateLineItem/ns0:LotNumber) }</Ycharg>
                            <Ykwmeng>{ data($StockTransferUpdateLineItem/ns0:TransferQuantity/ns0:Measurement/ns0:MeasurementValue) }</Ykwmeng>
                            <Yvrkme>{ xs:string( data($StockTransferUpdateLineItem/ns0:TransferQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yvrkme>
                        </item>
                }
            </ItItm>
            <Yind>{ xs:string( data($request/ns1:Header/ns1:DocumentIdentifier) ) }</Yind>
            <Ysource>{ data($request/ns1:Header/ns1:DataSource) }</Ysource>
        </ns2:YSdsaUsseedEstUpdate>
};

declare variable $request as element(ns0:StockTransferUpdateRequest) external;

xf:StockTransferUpdateRequest($request)
