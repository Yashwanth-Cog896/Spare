(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstUpdateResponse" location="../WSDLs/YES_Y_SDSA_USSEED_EST_UPDATE.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:StockTransferUpdateResponse" location="../Schemas/StockTransferUpdate.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:StockTransferUpdate";
declare namespace xf = "http://tempuri.org/ECC_US_EST_StockTransferUpdate/XQueryResources/StockTransferUpdateResponse/";

declare function xf:StockTransferUpdateResponse($response as element(ns2:YSdsaUsseedEstUpdateResponse))
    as element(ns0:StockTransferUpdateResponse) {
        <ns0:StockTransferUpdateResponse Version="1.0">           
            <ns0:StockTransferUpdateResponseBody>
                {
                    for $item in $response/ItRes/item
                    return
                        <ns0:StockTransferUpdateResponseDetails>
                        	{
								if(data($item/Yvbeln) !='') then (
								<ns0:TransferIdentifier Type="SALES_ORDER_NUMBER">{ data($item/Yvbeln) }</ns0:TransferIdentifier>
								) else()
                            }
                            {
								if(data($item/Ytransid) !='') then (
								<ns0:TransferIdentifier Type="CLIENT_TRANSACTION_ID">{ data($item/Ytransid) }</ns0:TransferIdentifier>
								) else()
                            }
                            {
								if(data($item/Yponum) !='') then (
								<ns0:TransferIdentifier Type="PURCHASE_ORDER_NUMBER">{ data($item/Yponum) }</ns0:TransferIdentifier>
								) else()
                            }
                            <ns0:SeedYear>{ xs:integer( data($item/Yyear) ) }</ns0:SeedYear>
                        </ns0:StockTransferUpdateResponseDetails>
                }
            </ns0:StockTransferUpdateResponseBody>
            {
                for $item in $response/ItError/item
                return             
                    <ns0:StockTransferUpdateResponseError>
                        <ns0:ErrorType>
                        	{                          
		                        if (data($item/Type) = "S") then
		                            ("Success")
		                        else 
		                            if (data($item/Type) = "E") then
		                                ("Error")
		                            else 
		                                if (data($item/Type) = "W") then
		                                    ("Warning")
		                                else 
		                                    if (data($item/Type) = "I") then
		                                        ("Info")
		                                    else 
		                                        if (data($item/Type) = "A") then
		                                            ("Abort")
		                                        else 
		                                            ()
                    		}  
                     	</ns0:ErrorType>
                        <ns0:ItemNumber>{ data($item/Id) }</ns0:ItemNumber>
                        {
	                		if(data($item/Number)!='')then(
	                       		<ns0:ErrorMessageNumber>{ xs:integer( data($item/Number) ) }</ns0:ErrorMessageNumber>
	                       	)else()
                       	}	
                        <ns0:TransferIdentifier Type = "{ data($item/ErrDesc) }">{ data($item/MsgObject) }</ns0:TransferIdentifier>
                        <ns0:ErrorMessageDisplayText>{ data($item/ErrDescDisp) }</ns0:ErrorMessageDisplayText>
                    </ns0:StockTransferUpdateResponseError>
                
            }
        </ns0:StockTransferUpdateResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstUpdateResponse) external;

xf:StockTransferUpdateResponse($response)
