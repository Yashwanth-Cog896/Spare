(:: pragma bea:global-element-parameter parameter="$request" element="ns0:SoybeanHedgingChangeRequest" location="../Schemas/SoybeanHedgingChangeRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns1:YFhdElevUpdate" location="../WSDLs/YES_Y_FHD_ELEV_UPDATE.WSDL" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:soybeanhedgingchangerequest:request:1:0";
declare namespace xf = "http://tempuri.org/MM_US_SoybeanHedg_CreateUpdateDelete/XQueryTranformations/SoybeanHedgingChangeRequest/";

declare function xf:SoybeanHedgingChangeRequest($request as element(ns0:SoybeanHedgingChangeRequest))
    as element(ns1:YFhdElevUpdate) {
        <ns1:YFhdElevUpdate>
            <InAction>{ xs:string( data($request/ns0:SoybeanHedgingChangeRequestBody[1]/ns0:SoybeanHedgingChangeProperties/ns0:ActionRequest) ) }</InAction>
            <InElevUpdate>
                {
                    for $SoybeanHedgingChangeRequestBody in $request/ns0:SoybeanHedgingChangeRequestBody
                    return
                        <item>
                            <YyelevCustNbr>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorSAPNumber) }</YyelevCustNbr>
                            <Yytrdtktno>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingChangeProperties/ns0:TradeTicketNumber) ) }</Yytrdtktno>
                            <Yytrdtktyr>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:TradeTicketYear) ) }</Yytrdtktyr>
                            <Yyplant>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:PlantCode) ) }</Yyplant>
                            <YydateEntered>
                                {
                                    fn:substring($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:CreateDateTime/ns0:DateTime,
                                    1,
                                    10)
                                }
</YydateEntered>
                            <YytimeEntered>
                                {
                                    fn:substring($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:CreateDateTime/ns0:DateTime,
                                    12,
                                    8)
                                }
</YytimeEntered>
                            <YyexchMktDate>
                                {
                                    fn:substring($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:MarketDateTime/ns0:DateTime,
                                    1,
                                    10)
                                }
</YyexchMktDate>
                            <YyfuturesMo>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:FuturesMonth) ) }</YyfuturesMo>
                            <YyfuturesYr>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:FuturesYear) ) }</YyfuturesYr>
                            <YynbrContracts>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:Contracts) ) }</YynbrContracts>
                            <YyhedgeQty>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:HedgeQuantity/ns0:MeasurementValue) }</YyhedgeQty>
                            <YyhedgeUom>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:HedgeQuantity/ns0:UnitOfMeasureCode) ) }</YyhedgeUom>
                            <YyfuturePrice>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:FuturesPrice/ns0:MonetaryAmount/ns0:MonetaryValue) }</YyfuturePrice>
                            <YypriceBasis>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:PriceBasis/ns0:MonetaryAmount/ns0:MonetaryValue) }</YypriceBasis>
                            <YyhedgeCurrency>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:FuturesPrice/ns0:MonetaryAmount/ns0:CurencyCode) ) }</YyhedgeCurrency>
                            <YybrokerCode>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingAdminDetails/ns0:MonsantoBrokerCode) }</YybrokerCode>
                            <Yytrdnam>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorContactInformation/ns0:ContactName) }</Yytrdnam>
                            <Yystatus>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingChangeProperties/ns0:Status) ) }</Yystatus>
                            <Yycomments>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:Comments) }</Yycomments>
                            <YycreatedBy>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:CreatedBy) }</YycreatedBy>
                            <Yycompany>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingAdminDetails/ns0:CompanyCode) }</Yycompany>
                            <YychangedBy>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingChangeProperties/ns0:ChangedBy) }</YychangedBy>
                            <Yychngdat>
                                {
                                    fn:substring($request/ns0:SoybeanHedgingChangeRequestBody[1]/ns0:SoybeanHedgingChangeProperties/ns0:ChangeDateTime/ns0:DateTime,
                                    1,
                                    10)
                                }
</Yychngdat>
                            <Yychngtim>
                                {
                                    fn:substring($request/ns0:SoybeanHedgingChangeRequestBody[1]/ns0:SoybeanHedgingChangeProperties/ns0:ChangeDateTime/ns0:DateTime,
                                    12,
                                    8)
                                }
</Yychngtim>
                            <YyelevBrkName>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorBrokerInformation/ns0:BrokerName) }</YyelevBrkName>
                            <YyelevBrkId>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorBrokerInformation/ns0:AccountID) }</YyelevBrkId>
                            <YyelevName>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorName) }</YyelevName>
                            <Yytrdnamid>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorContactInformation/ns0:AccountID) }</Yytrdnamid>
                            <Yyseasyear>{ xs:string( data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingAdminDetails/ns0:CropYear) ) }</Yyseasyear>
                            <YyelevPrice>{ data($SoybeanHedgingChangeRequestBody/ns0:SoybeanHedgingElevatorDetails/ns0:ElevatorPrice/ns0:MonetaryAmount/ns0:MonetaryValue) }</YyelevPrice>
                        </item>
                }
            </InElevUpdate>
        </ns1:YFhdElevUpdate>
};

declare variable $request as element(ns0:SoybeanHedgingChangeRequest) external;

xf:SoybeanHedgingChangeRequest($request)
