(:: pragma bea:global-element-parameter parameter="$response" element="ns1:YFhdElevUpdateResponse" location="../WSDLs/YES_Y_FHD_ELEV_UPDATE.WSDL" ::)
(:: pragma bea:global-element-return element="ns0:SoybeanHedgingChangeResponse" location="../Schemas/SoybeanHedgingChangeResponse.xsd" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:soybeanhedgingchangeresponse:response:1:0";
declare namespace xf = "http://tempuri.org/MM_US_SoybeanHedg_CreateUpdateDelete/XQueryTranformations/SoybeanHedgingChangeResponse/";

declare function xf:SoybeanHedgingChangeResponse($response as element(ns1:YFhdElevUpdateResponse))
    as element(ns0:SoybeanHedgingChangeResponse) {
        <ns0:SoybeanHedgingChangeResponse>
            {
                for $item in $response/OutErrors/item
                return
                    <ns0:SoybeanHedgingChangeResponseError>
                        <ns0:ErrorType>{ data($item/YymsgType) }</ns0:ErrorType>
                        <ns0:ErrorMessageClass>{ data($item/YymsgId) }</ns0:ErrorMessageClass>
                        <ns0:ErrorMessageNumber>{ xs:integer( data($item/YymsgNbr) ) }</ns0:ErrorMessageNumber>
                        <ns0:ErrorMessageObject>{ data($item/YymsgObject) }</ns0:ErrorMessageObject>
                        <ns0:ErrorMessageText>{ data($item/YymsgDescInt) }</ns0:ErrorMessageText>
                        <ns0:ErrorMessageDisplayText>{ data($item/YymsgDescExt) }</ns0:ErrorMessageDisplayText>
                    </ns0:SoybeanHedgingChangeResponseError>
            }
        </ns0:SoybeanHedgingChangeResponse>
};

declare variable $response as element(ns1:YFhdElevUpdateResponse) external;

xf:SoybeanHedgingChangeResponse($response)