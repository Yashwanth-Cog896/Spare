(:: pragma bea:global-element-parameter parameter="$request" element="ns0:SHDataRequest" location="../Schemas/DataRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YsdsaHaulbackDatarequest" location="../WSDLs/ECC_SHDataRequest.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:SHDataRequest";
declare namespace xf = "http://tempuri.org/ECC_US_SHB_DataRequest/XQueryResources/SHDataRequest/";

declare function xf:SHDataRequest($request as element(ns0:SHDataRequest))
    as element(ns2:YsdsaHaulbackDatarequest) {
        <ns2:YsdsaHaulbackDatarequest>
            <IYyacctTyp>{ xs:string( data($request/ns0:SHDataRequestBody/ns0:SoldTo/ns0:PartnerIdentifier/@Type) ) }</IYyacctTyp>
            <IYydealer>{ data($request/ns0:SHDataRequestBody/ns0:SoldTo/ns0:PartnerIdentifier) }</IYydealer>
            <IYyvkorg>{ xs:string( data($request/ns0:SHDataRequestBody/ns0:SalesOrg) ) }</IYyvkorg>
            <ItYytransactionId>
                {
                    for $TransactionId in $request/ns0:SHDataRequestBody/ns0:TransactionId
                    return
                        <item>{ xs:string( data($TransactionId) ) }</item>
                }
            </ItYytransactionId>
        </ns2:YsdsaHaulbackDatarequest>
};

declare variable $request as element(ns0:SHDataRequest) external;

xf:SHDataRequest($request)
