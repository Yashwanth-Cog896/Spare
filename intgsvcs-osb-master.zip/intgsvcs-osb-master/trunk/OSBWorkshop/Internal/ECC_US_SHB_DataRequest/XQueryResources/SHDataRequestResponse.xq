(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YsdsaHaulbackDatarequestResponse" location="../WSDLs/ECC_SHDataRequest.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:SHDataResponse" location="../Schemas/DataRequest.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:SHDataRequest";
declare namespace xf = "http://tempuri.org/ECC_US_SHB_DataRequest/XQueryResources/SHDataRequestResponse/";

declare function xf:SHDataRequestResponse($response as element(ns2:YsdsaHaulbackDatarequestResponse))
    as element(ns0:SHDataResponse) {
        <ns0:SHDataResponse>
            <ns0:SHDataResponseBody>
                {
                if ($response/EsResThresholdValue/Yydcithreshold/text ()!='') then (
                <ns0:DCIThreshold>{ xs:integer( data($response/EsResThresholdValue/Yydcithreshold) ) }</ns0:DCIThreshold>
                ) else ()
                }
                <ns0:CBOTThreshold>{ data($response/EsResThresholdValue/Yycbotthreshold) }</ns0:CBOTThreshold>
                {
                if ($response/EsResThresholdValue/YyeditFlag/text()!='') then (
                  if ($response/EsResThresholdValue/YyeditFlag/text()='Y') then (
                 <ns0:Editable>{xs:boolean(1)}</ns0:Editable>
                 )else (<ns0:Editable>{xs:boolean(0)}</ns0:Editable>)
                 ) else ()
                  }
                { if($response/EsResThresholdValue/Yysalesyear/text()!='') then(
                <ns0:SalesYear>{ data($response/EsResThresholdValue/Yysalesyear) }</ns0:SalesYear>
                ) else()
                }
                <ns0:SurveyDetails>
                    <ns0:Survey>
                        <ns0:ReturnIndicator>{ data($response/EsResSurveyInfo/Yysbreturns) }</ns0:ReturnIndicator>
                        <ns0:MultipleShipTo>{ data($response/EsResSurveyInfo/YymultiSh) }</ns0:MultipleShipTo>
                        <ns0:EstHaulbackQty>{ data($response/EsResSurveyInfo/YyhbQty) }</ns0:EstHaulbackQty>
                        <ns0:BulkSoybeanReturn>{ data($response/EsResSurveyInfo/Yybulkreturn) }</ns0:BulkSoybeanReturn>
                        {
                        if($response/EsResSurveyInfo/YysurveyTaken/text()!='')then(
                          if ($response/EsResSurveyInfo/YysurveyTaken/text()='Y') then (
                               <ns0:SurveyTaken>{xs:boolean(1)}</ns0:SurveyTaken>
                    	) else(<ns0:SurveyTaken>{xs:boolean(0)}</ns0:SurveyTaken>)
                    	)else()
                    	}
                    </ns0:Survey>
                </ns0:SurveyDetails>
                <ns0:HaulbackTransactions>
                    {
                        for $item in $response/EtResTranDetlHdr/item
                        return
                            <ns0:Transaction>
                                <ns0:TransactionId>{ data($item/YytransactionId) }</ns0:TransactionId>
                                <ns0:ShipTo>
                                    <ns0:PartnerIdentifier Type = "{ data($item/YyacctTyp) }">{ data($item/YyshipTo) }</ns0:PartnerIdentifier>
                                    <ns0:PartnerName>{ data($item/Yyname1) }</ns0:PartnerName>
                                    <ns0:Street>{ data($item/Yystras) }</ns0:Street>
                                    <ns0:City>{ data($item/Yyort01) }</ns0:City>
                                    <ns0:State>{ data($item/Yyregio) }</ns0:State>
                                    <ns0:Zip>{ data($item/Yypstlz) }</ns0:Zip>
                                    <ns0:Phone>{ data($item/Yytelf1) }</ns0:Phone>
                                </ns0:ShipTo>
                                <ns0:TotalQuantityReturned>{ data($item/YytotalQtyRet) }</ns0:TotalQuantityReturned>
                                <ns0:DocumentIdentifiers>
                                    <ns0:PONumber>{ data($item/YypurchaseOrder) }</ns0:PONumber>
                                    <ns0:SalesNumber>{ data($item/YyorderNumber) }</ns0:SalesNumber>
                                    <ns0:InvoiceNumber>{ data($item/YyinvoiceNumber) }</ns0:InvoiceNumber>
                                </ns0:DocumentIdentifiers>
                                <ns0:Estimates>
                                    <ns0:CreditEstimate>{ data($item/YytotalEstCr) }</ns0:CreditEstimate>
                                    <ns0:DebitEstimate>{ data($item/YytotalEstDb) }</ns0:DebitEstimate>
                                    <ns0:NetCreditEstimate>{ data($item/YytotEstNetCr) }</ns0:NetCreditEstimate>
                                </ns0:Estimates>
                                <ns0:TransactionInformation>
                                    <ns0:Status>{ data($item/Yystatus) }</ns0:Status>
                                    <ns0:StatusDescription>{ data($item/YystatusDesc) }</ns0:StatusDescription>
                                    <ns0:CreatedBy>{ data($item/Yycreatedby) }</ns0:CreatedBy>
                                    {
                                    if ($item/YycreateDate/text()!='') then (
                                    <ns0:CreatedDate>{ xs:date( data($item/YycreateDate) ) }</ns0:CreatedDate>
                                    ) else ()
                                    }
                                    {
                                    if ($item/YycreateTime/text()!='') then(
                                    <ns0:CreatedTime>{ xs:time( data($item/YycreateTime) ) }</ns0:CreatedTime>
                                    ) else ()
                                    }
                                    <ns0:UpdatedBy>{ data($item/Yyupdatedby) }</ns0:UpdatedBy>
                                    {
                                    if ($item/YyupdateDate/text()!='') then (
                                    <ns0:LastModifyDate>{ xs:date( data($item/YyupdateDate) ) }</ns0:LastModifyDate>
                                    ) else ()
                                    }
                                    <ns0:LastModifyTime>{ xs:time( data($item/YyupdateTime) ) }</ns0:LastModifyTime>
                                    <ns0:SubmittedBy>{ data($item/Yysubmittedby) }</ns0:SubmittedBy>
                                    {
									if(fn:contains(xs:string(data($item/YysubmitDate)),'0000')) then(                  
									) else(
									<ns0:SubmitDate>{ xs:date( data($item/YysubmitDate) ) }</ns0:SubmitDate>
									)
								    }
								    {
								    if(fn:contains(xs:string(data($item/YysubmitTime)),'00:00:00')) then(
								    ) else(
								    <ns0:SubmitTime>{ xs:time( data($item/YysubmitTime) ) }</ns0:SubmitTime>
								    )
								    }
								    
                                </ns0:TransactionInformation>
                                <ns0:DCIValues>
                                    <ns0:Threshold>{ xs:integer( data($item/Yydcithreshold) ) }</ns0:Threshold>
                                     {
                                    if ($item/YyholdDciThres/text()='X') then (
                                    <ns0:ExceedsDCIThreshold>{xs:boolean(1)}</ns0:ExceedsDCIThreshold>)
                                    else if($item/YyholdDciThres/text()='') then (
                                    <ns0:ExceedsDCIThreshold>{xs:boolean(0)}</ns0:ExceedsDCIThreshold>)
                                    else ()
                                    }
                                    {
                                    if ($item/YyholdCrThres/text()='X') then (
                                    <ns0:ExceedsCreditThreshold>{xs:boolean(1)}</ns0:ExceedsCreditThreshold>)
                                    else if($item/YyholdCrThres/text()='') then (
                                    <ns0:ExceedsCreditThreshold>{xs:boolean(0)}</ns0:ExceedsCreditThreshold>)
                                    else ()
                                    }
                                </ns0:DCIValues>
                            {
                                    for $item0 in $response/EtResTranDetlItm/item
                                    return
                                        if(data($item/YytransactionId) = data($item0/YytransactionId))then(
                                        <ns0:TransactionDetails>
                                         {
                                         if ($item0/YyitemNo/text()!='') then (
                                            <ns0:ItemNumber>{ xs:integer( data($item0/YyitemNo) ) }</ns0:ItemNumber>
                                          ) else ()
                                          }     
											<ns0:ProductIdentification>
                                                <ns0:ProductIdentifier Type = "{ data($item0/YymatTyp ) }">{ data($item0/Yymaterial ) }</ns0:ProductIdentifier>
                                                <ns0:ProductIdentifier Type = "{ data($item0/YymatTyp2) }">{ data($item0/YyupcCode ) }</ns0:ProductIdentifier>
                                                <ns0:ProductIdentifier Type = "{ data($item0/YymatTyp3) }">{ data( $item0/Yygtin) }</ns0:ProductIdentifier>
                                                <ns0:ProductName>{ data($item0/YymaterialDescr) }</ns0:ProductName>
                                            </ns0:ProductIdentification>
                                             <ns0:SalesUnit>
                                                <ns0:Measurement>
                                                    <ns0:MeasurementValue>{ data($item0/YyorderUnit) }</ns0:MeasurementValue>
                                                    <ns0:UnitOfMeasureCode>{ data($item0/YysalesUnit) }</ns0:UnitOfMeasureCode>
                                                </ns0:Measurement>
                                            </ns0:SalesUnit>
											<ns0:Price>
                                        <ns0:MonetaryValue>{ data($item0/YyhbPrice) }</ns0:MonetaryValue>
                                        <ns0:CurrencyCode>{ data($item0/Yypricecuky) }</ns0:CurrencyCode>
                                    </ns0:Price>
                                            <ns0:SeedPerPound>{ xs:integer( data($item0/YyseedLb) ) }</ns0:SeedPerPound>
                                            <ns0:BatchNumber>{ data($item0/Yybatch) }</ns0:BatchNumber>
                                            <ns0:NetDeliveredQty>{ data($item0/YynetDelivered) }</ns0:NetDeliveredQty>
                                            <ns0:PreviousSubmittedQty>{ data($item0/YypreviousSubmi) }</ns0:PreviousSubmittedQty>
                                            <ns0:HaulbackQtyReturned>{ data($item0/YyqtyReturn) }</ns0:HaulbackQtyReturned>
                                            {
											if(fn:contains(xs:string(data($item0/YyelevatorDump)),'0000')) then(                  
											) else(
											<ns0:ElevatorDumpDate>{ xs:date( data($item0/YyelevatorDump) ) }</ns0:ElevatorDumpDate>
											)
								    		}
                                            <ns0:ElevatorCommodityPrice>{ data($item0/YycommodityPric) }</ns0:ElevatorCommodityPrice>
                                            <ns0:EstimatedCredit>{ data($item0/YyestCredit) }</ns0:EstimatedCredit>
                                            <ns0:EstimatedDebit>{ data($item0/YyestDebit) }</ns0:EstimatedDebit>
                                            <ns0:EstimatedNetCredit>{ data($item0/YyestNetCredit) }</ns0:EstimatedNetCredit>
                                            {
                                            if ($item0/YyholdSearchBa/text()='X') then (
                                            <ns0:SearchedByBatch>{ xs:boolean(1) }</ns0:SearchedByBatch>)
                                            else if ($item0/YyholdSearchBa/text()= '') then (
                                            <ns0:SearchedByBatch>{ xs:boolean(0) }</ns0:SearchedByBatch>)
                                            else ()
                                            }
                                        </ns0:TransactionDetails>
                                )else()
                                }
                            </ns0:Transaction>
                    }
                </ns0:HaulbackTransactions>
            </ns0:SHDataResponseBody>
        {
            if(data($response/EtMessages/item[1]/YymsgType/text()) != '') then (
            <ns0:SHDataResponseError>
                <ns0:ErrorType> 
                	 {
                        if (data($response/EtMessages/item[1]/YymsgType) = "S") then
                            ("Success")
                        else 
                            if (data($response/EtMessages/item[1]/YymsgType) = "E") then
                                ("Error")
                            else 
                                if (data($response/EtMessages/item[1]/YymsgType) = "W") then
                                    ("Warning")
                					else()   
                }</ns0:ErrorType>
                <ns0:ErrorMessageClass>{ data($response/EtMessages/item[1]/YymsgId) }</ns0:ErrorMessageClass>
                 {
                if(data($response/EtMessages/item[1]/YymsgNo/text())!='')then(
                <ns0:ErrorMessageNumber>{ xs:integer( data($response/EtMessages/item[1]/YymsgNo) ) }</ns0:ErrorMessageNumber>
                )else()
                }
                <ns0:ErrorMessageObject>{ data($response/EtMessages/item[1]/YymsgObject) }</ns0:ErrorMessageObject>
                <ns0:ErrorMessageText>{ data($response/EtMessages/item[1]/YymsgDescInt) }</ns0:ErrorMessageText>
                <ns0:ErrorMessageDisplayText>{ data($response/EtMessages/item[1]/YymsgDescExt) }</ns0:ErrorMessageDisplayText>
            </ns0:SHDataResponseError>
            )else()
            }
        </ns0:SHDataResponse>
};

declare variable $response as element(ns2:YsdsaHaulbackDatarequestResponse) external;

xf:SHDataRequestResponse($response)
