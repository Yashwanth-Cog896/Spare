(:: pragma bea:global-element-parameter parameter="$request" element="ns0:DealerEmailRequest" location="../Schemas/DealerEmail.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstUpdateemail" location="../WSDLs/Dealer_Emails.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerEmail";
declare namespace xf = "http://tempuri.org/ECC_US_EST_DealerEmail/XQueryResources/DealerEmailRequest/";

declare function xf:DealerEmailRequest($request as element(ns0:DealerEmailRequest))
    as element(ns2:YSdsaUsseedEstUpdateemail) {
        <ns2:YSdsaUsseedEstUpdateemail>
            <IsReqDlremail>
                <Yykunnr>{ xs:string( data($request/ns0:DealerEmailRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier[1]) ) }</Yykunnr>
                <Yypartype>{ xs:string( data($request/ns0:DealerEmailRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier[1]/@Type) ) }</Yypartype>
                <YyreqType>{ xs:string( data($request/ns0:DealerEmailRequestBody/@Action) ) }</YyreqType>
                {
                	if($request/ns0:DealerEmailRequestBody/ns0:DealerEmailAddress/ns0:EmailAddress[1]/text()!='')then(
                	<Yychgemail1>{ xs:string( data($request/ns0:DealerEmailRequestBody/ns0:DealerEmailAddress/ns0:EmailAddress[1]) ) }</Yychgemail1>
                	)else ()
                }
                {
                	if($request/ns0:DealerEmailRequestBody/ns0:DealerEmailAddress/ns0:EmailAddress[2]/text()!='')then(
                	<Yychgemail2>{ xs:string( data($request/ns0:DealerEmailRequestBody/ns0:DealerEmailAddress/ns0:EmailAddress[2]) ) }</Yychgemail2>
                	)else ()
                }
                {
                	if($request/ns0:DealerEmailRequestBody/ns0:DealerEmailAddress/ns0:EmailAddress[3]/text()!='')then(
                	<Yychgemail3>{ xs:string( data($request/ns0:DealerEmailRequestBody/ns0:DealerEmailAddress/ns0:EmailAddress[3]) ) }</Yychgemail3>
                	)else ()
            	}
            </IsReqDlremail>
        </ns2:YSdsaUsseedEstUpdateemail>
};

declare variable $request as element(ns0:DealerEmailRequest) external;

xf:DealerEmailRequest($request)
