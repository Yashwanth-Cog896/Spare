(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstUpdateemailResponse" location="../WSDLs/Dealer_Emails.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:DealerEmailResponse" location="../Schemas/DealerEmail.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerEmail";
declare namespace xf = "http://tempuri.org/ECC_US_EST_StockTransferUpdate/XQueryResources/DealerEmailResponse/";

declare function xf:DealerEmailResponse($response as element(ns2:YSdsaUsseedEstUpdateemailResponse))
    as element(ns0:DealerEmailResponse) {
        <ns0:DealerEmailResponse Version="1.0">
            <ns0:DealerEmailResponseBody>
                <ns0:DealerEntity>
                    <ns0:PartnerIdentifier Type = "{ data($response/EsResDlremail/Yypartype) }">{ data($response/EsResDlremail/Yykunnr) }</ns0:PartnerIdentifier>
                </ns0:DealerEntity>
                <ns0:DealerEmailAddress>
					{
						if($response/EsResDlremail/Yychgemail1/text()!='')then (
                    	<ns0:EmailAddress>{ data($response/EsResDlremail/Yychgemail1) }</ns0:EmailAddress>
                    	) else()
                    }
                    {
                    	if($response/EsResDlremail/Yychgemail2/text()!='')then (
                    	<ns0:EmailAddress>{ data($response/EsResDlremail/Yychgemail2) }</ns0:EmailAddress>
                    	) else()
                    }
                    {
                    	if($response/EsResDlremail/Yychgemail3/text()!='')then (
                    	<ns0:EmailAddress>{ data($response/EsResDlremail/Yychgemail3) }</ns0:EmailAddress>
                    	) else()
                	}
                </ns0:DealerEmailAddress>
            </ns0:DealerEmailResponseBody>
           
            <ns0:DealerEmailResponseError>
                <ns0:ErrorType>{ 
                		
                  if (data($response/EtMessages/item[1]/YymsgType) = "S") then
                            ("Success")
                        else 
                            if (data($response/EtMessages/item[1]/YymsgType) = "E") then
                                ("Error")
                            else 
                                if (data($response/EtMessages/item[1]/YymsgType) = "W") then
                                    ("Warning")
                                else 
                                    if (data($response/EtMessages/item[1]/YymsgType) = "I") then
                                        ("Info")
                                    else 
                                        if (data($response/EtMessages/item[1]/YymsgType) = "A") then
                                            ("Abort")
                                        else 
                                            ()
                
                
                }</ns0:ErrorType>
                <ns0:ErrorMessageClass>{ data($response/EtMessages/item[1]/YymsgId) }</ns0:ErrorMessageClass>
                {
                if(data($response/Messages/item[1]/Number)!='')then(
                <ns0:ErrorMessageNumber>{ xs:integer( data($response/EtMessages/item[1]/Number) ) }</ns0:ErrorMessageNumber>
                )else()
                }
                <ns0:ErrorMessageObject>{ data($response/EtMessages/item[1]/YymsgObject) }</ns0:ErrorMessageObject>
                <ns0:ErrorMessageText>{ data($response/EtMessages/item[1]/YymsgDescInt) }</ns0:ErrorMessageText>
                <ns0:ErrorMessageDisplayText>{ data($response/EtMessages/item[1]/YymsgDescExt) }</ns0:ErrorMessageDisplayText>
            </ns0:DealerEmailResponseError>
         
        </ns0:DealerEmailResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstUpdateemailResponse) external;

xf:DealerEmailResponse($response)
