(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtTermsOrder" location="../WSDLs/RFC_TermsOrder_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtTermsOrder" location="../WSDLs/RFC_TermsOrder.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/TermsOrderRequest/";

declare function xf:TermsOrderRequest($request as element(ns0:YFibtTermsOrder))
    as element(ns0:YFibtTermsOrder) {
        <ns0:YFibtTermsOrder>
            <IYybartope>{ data($request/IYybartope) }</IYybartope>
            <IYycomid>{ data($request/IYycomid) }</IYycomid>
            <IYycontn>{ data($request/IYycontn) }</IYycontn>
            <IYydelpla>{ data($request/IYydelpla) }</IYydelpla>
            <IYydzmeng>{ data($request/IYydzmeng) }</IYydzmeng>
            <IYygrpribg>{ data($request/IYygrpribg) }</IYygrpribg>
            <IYykunnrtra>{ data($request/IYykunnrtra) }</IYykunnrtra>
            <IYylocware>{ data($request/IYylocware) }</IYylocware>
            <IYysimuid>{ data($request/IYysimuid) }</IYysimuid>
            <ItReqDocs>
                {
                    for $item in $request/ItReqDocs/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItReqDocs>
        </ns0:YFibtTermsOrder>
};

declare variable $request as element(ns0:YFibtTermsOrder) external;

xf:TermsOrderRequest($request)
