(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtStatusBarterResponse" location="../WSDLs/RFC_Status.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtStatusBarterResponse" location="../WSDLs/RFC_Status_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/SimulationStatusResponse/";

declare function xf:SimulationStatusResponse($response as element(ns0:YFibtStatusBarterResponse))
    as element(ns0:YFibtStatusBarterResponse) {
        <ns0:YFibtStatusBarterResponse>
            <EtBarter>
                {
                    for $item in $response/EtBarter/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtBarter>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtStatusBarterResponse>
};

declare variable $response as element(ns0:YFibtStatusBarterResponse) external;

xf:SimulationStatusResponse($response)
