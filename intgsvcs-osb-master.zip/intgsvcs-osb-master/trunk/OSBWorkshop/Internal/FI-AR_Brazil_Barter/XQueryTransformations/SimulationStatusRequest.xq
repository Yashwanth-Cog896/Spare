(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtStatusBarter" location="../WSDLs/RFC_Status_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtStatusBarter" location="../WSDLs/RFC_Status.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/SimulationStatusRequest/";

declare function xf:SimulationStatusRequest($request as element(ns0:YFibtStatusBarter))
    as element(ns0:YFibtStatusBarter) {
        <ns0:YFibtStatusBarter>
            {
                for $ISimuid in $request/ISimuid
                return
                    <ISimuid>{ data($ISimuid) }</ISimuid>
            }
        </ns0:YFibtStatusBarter>
};

declare variable $request as element(ns0:YFibtStatusBarter) external;

xf:SimulationStatusRequest($request)
