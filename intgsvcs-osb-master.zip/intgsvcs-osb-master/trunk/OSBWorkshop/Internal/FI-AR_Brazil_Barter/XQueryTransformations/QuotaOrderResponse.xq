(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtQuotaOrderResponse" location="../WSDLs/RFC_QuotaOrder.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtQuotaOrderResponse" location="../WSDLs/RFC_QuotaOrder_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/QuotaOrderResponse/";

declare function xf:QuotaOrderResponse($response as element(ns0:YFibtQuotaOrderResponse))
    as element(ns0:YFibtQuotaOrderResponse) {
        <ns0:YFibtQuotaOrderResponse>
            <EQuotedoc>{ data($response/EQuotedoc) }</EQuotedoc>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtQuotaOrderResponse>
};

declare variable $response as element(ns0:YFibtQuotaOrderResponse) external;

xf:QuotaOrderResponse($response)
