(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtSalesOrderSimulate" location="../WSDLs/RFC_SOSimul_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtSalesOrderSimulate" location="../WSDLs/RFC_SOSimul.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/SalesOrderSimulationRequest/";

declare function xf:SalesOrderSimulationRequest($request as element(ns0:YFibtSalesOrderSimulate))
    as element(ns0:YFibtSalesOrderSimulate) {
        <ns0:YFibtSalesOrderSimulate>
            {
                for $ConvertParvwAuart in $request/ConvertParvwAuart
                return
                    <ConvertParvwAuart>{ data($ConvertParvwAuart) }</ConvertParvwAuart>
            }
            {
                for $Extensionin in $request/Extensionin
                return
                    <Extensionin>{ $Extensionin/@* , $Extensionin/node() }</Extensionin>
            }
            {
                for $Messagetable in $request/Messagetable
                return
                    <Messagetable>{ $Messagetable/@* , $Messagetable/node() }</Messagetable>
            }
            {
                for $NfmetallitmsEx in $request/NfmetallitmsEx
                return
                    <NfmetallitmsEx>{ $NfmetallitmsEx/@* , $NfmetallitmsEx/node() }</NfmetallitmsEx>
            }
            {
                for $NfmetallitmsIm in $request/NfmetallitmsIm
                return
                    <NfmetallitmsIm>{ $NfmetallitmsIm/@* , $NfmetallitmsIm/node() }</NfmetallitmsIm>
            }
            {
                for $OrderCcard in $request/OrderCcard
                return
                    <OrderCcard>{ $OrderCcard/@* , $OrderCcard/node() }</OrderCcard>
            }
            {
                for $OrderCcardEx in $request/OrderCcardEx
                return
                    <OrderCcardEx>{ $OrderCcardEx/@* , $OrderCcardEx/node() }</OrderCcardEx>
            }
            {
                for $OrderCfgsBlob in $request/OrderCfgsBlob
                return
                    <OrderCfgsBlob>{ $OrderCfgsBlob/@* , $OrderCfgsBlob/node() }</OrderCfgsBlob>
            }
            {
                for $OrderCfgsInst in $request/OrderCfgsInst
                return
                    <OrderCfgsInst>{ $OrderCfgsInst/@* , $OrderCfgsInst/node() }</OrderCfgsInst>
            }
            {
                for $OrderCfgsPartOf in $request/OrderCfgsPartOf
                return
                    <OrderCfgsPartOf>{ $OrderCfgsPartOf/@* , $OrderCfgsPartOf/node() }</OrderCfgsPartOf>
            }
            {
                for $OrderCfgsRef in $request/OrderCfgsRef
                return
                    <OrderCfgsRef>{ $OrderCfgsRef/@* , $OrderCfgsRef/node() }</OrderCfgsRef>
            }
            {
                for $OrderCfgsValue in $request/OrderCfgsValue
                return
                    <OrderCfgsValue>{ $OrderCfgsValue/@* , $OrderCfgsValue/node() }</OrderCfgsValue>
            }
            {
                for $OrderConditionEx in $request/OrderConditionEx
                return
                    <OrderConditionEx>{ $OrderConditionEx/@* , $OrderConditionEx/node() }</OrderConditionEx>
            }
            <OrderHeaderIn>{ $request/OrderHeaderIn/@* , $request/OrderHeaderIn/node() }</OrderHeaderIn>
            {
                for $OrderIncomplete in $request/OrderIncomplete
                return
                    <OrderIncomplete>{ $OrderIncomplete/@* , $OrderIncomplete/node() }</OrderIncomplete>
            }
            <OrderItemsIn>{ $request/OrderItemsIn/@* , $request/OrderItemsIn/node() }</OrderItemsIn>
            {
                for $OrderItemsOut in $request/OrderItemsOut
                return
                    <OrderItemsOut>
                        {
                            for $item in $OrderItemsOut/item
                            return
                                <item>
                                    <ItmNumber>{ data($item/ItmNumber) }</ItmNumber>
                                    <PoItmNo>{ data($item/PoItmNo) }</PoItmNo>
                                    <Material>{ data($item/Material) }</Material>
                                    <MatEntrd>{ data($item/MatEntrd) }</MatEntrd>
                                    <ShortText>{ data($item/ShortText) }</ShortText>
                                    <NetValue>{ data($item/NetValue) }</NetValue>
                                    <Currency>{ data($item/Currency) }</Currency>
                                    <Subtotal1>{ data($item/Subtotal1) }</Subtotal1>
                                    <Subtotal2>{ data($item/Subtotal2) }</Subtotal2>
                                    <Subtotal3>{ data($item/Subtotal3) }</Subtotal3>
                                    <Subtotal4>{ data($item/Subtotal4) }</Subtotal4>
                                    <Subtotal5>{ data($item/Subtotal5) }</Subtotal5>
                                    <Subtotal6>{ data($item/Subtotal6) }</Subtotal6>
                                    <SalesUnit>{ data($item/SalesUnit) }</SalesUnit>
                                    <QtyReqDt>{ data($item/QtyReqDt) }</QtyReqDt>
                                    <DlvDate>{ data($item/DlvDate) }</DlvDate>
                                    <ReplTime>{ data($item/ReplTime) }</ReplTime>
                                    <Configured>{ data($item/Configured) }</Configured>
                                    <PurchNoC>{ data($item/PurchNoC) }</PurchNoC>
                                    <PurchDate>{ data($item/PurchDate) }</PurchDate>
                                    <PoMethod>{ data($item/PoMethod) }</PoMethod>
                                    <Ref1>{ data($item/Ref1) }</Ref1>
                                    <PurchNoS>{ data($item/PurchNoS) }</PurchNoS>
                                    <PoDatS>{ data($item/PoDatS) }</PoDatS>
                                    <PoMethS>{ data($item/PoMethS) }</PoMethS>
                                    <Ref1S>{ data($item/Ref1S) }</Ref1S>
                                    <PoItmNoS>{ data($item/PoItmNoS) }</PoItmNoS>
                                    <NetValue1>{ data($item/NetValue1) }</NetValue1>
                                    <CurrIso>{ data($item/CurrIso) }</CurrIso>
                                    <SUnitIso>{ data($item/SUnitIso) }</SUnitIso>
                                    <ReqQty>{ data($item/ReqQty) }</ReqQty>
                                    <Plant>{ data($item/Plant) }</Plant>
                                    <TxDocCur>{ data($item/TxDocCur) }</TxDocCur>
                                    <MatExt>{ data($item/MatExt) }</MatExt>
                                    <MatGuid>{ data($item/MatGuid) }</MatGuid>
                                    <MatVers>{ data($item/MatVers) }</MatVers>
                                    <MatEExt>{ data($item/MatEExt) }</MatEExt>
                                    <MatEGuid>{ data($item/MatEGuid) }</MatEGuid>
                                    <MatEVers>{ data($item/MatEVers) }</MatEVers>
                                    <TargetQty>{ data($item/TargetQty) }</TargetQty>
                                    <TargetQu>{ data($item/TargetQu) }</TargetQu>
                                    <TUnitIso>{ data($item/TUnitIso) }</TUnitIso>
                                    <ItemCateg>{ data($item/ItemCateg) }</ItemCateg>
                                    <ShipPoint>{ data($item/ShipPoint) }</ShipPoint>
                                    <HgLvItem>{ data($item/HgLvItem) }</HgLvItem>
                                    <CustMat>{ data($item/CustMat) }</CustMat>
                                    <PartDlv>{ data($item/PartDlv) }</PartDlv>
                                    <ReasonRej>{ data($item/ReasonRej) }</ReasonRej>
                                    <BillBlock>{ data($item/BillBlock) }</BillBlock>
                                    <StgeLoc>{ data($item/StgeLoc) }</StgeLoc>
                                    <ProdHier>{ data($item/ProdHier) }</ProdHier>
                                    <MatlGroup>{ data($item/MatlGroup) }</MatlGroup>
                                    <SUBTOTAL1>{ data($item/SUBTOT1) }</SUBTOTAL1>
                                    <SUBTOTAL2>{ data($item/SUBTOT2) }</SUBTOTAL2>
                                    <SUBTOTAL3>{ data($item/SUBTOT3) }</SUBTOTAL3>
                                    <SUBTOTAL4>{ data($item/SUBTOT4) }</SUBTOTAL4>
                                    <SUBTOTAL5>{ data($item/SUBTOT5) }</SUBTOTAL5>
                                    <SUBTOTAL6>{ data($item/SUBTOT6) }</SUBTOTAL6>
                                </item>
                        }
                    </OrderItemsOut>
            }
            <OrderPartners>{ $request/OrderPartners/@* , $request/OrderPartners/node() }</OrderPartners>
            {
                for $OrderScheduleEx in $request/OrderScheduleEx
                return
                    <OrderScheduleEx>{ $OrderScheduleEx/@* , $OrderScheduleEx/node() }</OrderScheduleEx>
            }
            {
                for $OrderScheduleIn in $request/OrderScheduleIn
                return
                    <OrderScheduleIn>{ $OrderScheduleIn/@* , $OrderScheduleIn/node() }</OrderScheduleIn>
            }
            {
                for $Partneraddresses in $request/Partneraddresses
                return
                    <Partneraddresses>{ $Partneraddresses/@* , $Partneraddresses/node() }</Partneraddresses>
            }
        </ns0:YFibtSalesOrderSimulate>
};

declare variable $request as element(ns0:YFibtSalesOrderSimulate) external;

xf:SalesOrderSimulationRequest($request)
