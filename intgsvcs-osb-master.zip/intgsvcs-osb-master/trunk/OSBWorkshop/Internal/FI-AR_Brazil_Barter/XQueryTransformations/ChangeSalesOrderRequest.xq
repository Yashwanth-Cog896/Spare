(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtChangeOrder" location="../WSDLs/RFC_ChangeOrder_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtChangeOrder" location="../WSDLs/RFC_ChangeOrder.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/ChangeSalesOrderRequest/";

declare function xf:ChangeSalesOrderRequest($request as element(ns0:YFibtChangeOrder))
    as element(ns0:YFibtChangeOrder) {
        <ns0:YFibtChangeOrder>
            <IsReqPanbarter>{ $request/IsReqPanbarter/@* , $request/IsReqPanbarter/node() }</IsReqPanbarter>
        </ns0:YFibtChangeOrder>
};

declare variable $request as element(ns0:YFibtChangeOrder) external;

xf:ChangeSalesOrderRequest($request)
