(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtCreditCheckResponse" location="../WSDLs/RFC_CreditCheck.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtCreditCheckResponse" location="../WSDLs/RFC_CreditCheck_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/CreditCheckResponse/";

declare function xf:CreditCheckResponse($response as element(ns0:YFibtCreditCheckResponse))
    as element(ns0:YFibtCreditCheckResponse) {
        <ns0:YFibtCreditCheckResponse>
            <EResult>{ data($response/EResult) }</EResult>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtCreditCheckResponse>
};

declare variable $response as element(ns0:YFibtCreditCheckResponse) external;

xf:CreditCheckResponse($response)
