(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtChangeOrderResponse" location="../WSDLs/RFC_ChangeOrder.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtChangeOrderResponse" location="../WSDLs/RFC_ChangeOrder_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/ChangeSalesOrderResponse/";

declare function xf:ChangeSalesOrderResponse($response as element(ns0:YFibtChangeOrderResponse))
    as element(ns0:YFibtChangeOrderResponse) {
        <ns0:YFibtChangeOrderResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtChangeOrderResponse>
};

declare variable $response as element(ns0:YFibtChangeOrderResponse) external;

xf:ChangeSalesOrderResponse($response)
