(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtContrSimul" location="../WSDLs/RFC_ContrSimul_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtContrSimul" location="../WSDLs/RFC_ContrSimul.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/ContractSimulationRequest/";

declare function xf:ContractSimulationRequest($request as element(ns0:YFibtContrSimul))
    as element(ns0:YFibtContrSimul) {
        <ns0:YFibtContrSimul>
            <IYycontn>{ data($request/IYycontn) }</IYycontn>
            <IYycountry>{ data($request/IYycountry) }</IYycountry>
            <IYysimuid>{ data($request/IYysimuid) }</IYysimuid>
        </ns0:YFibtContrSimul>
};

declare variable $request as element(ns0:YFibtContrSimul) external;

xf:ContractSimulationRequest($request)
