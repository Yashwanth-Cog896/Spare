(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtStatusContract" location="../WSDLs/RFC_StatusContract_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtStatusContract" location="../WSDLs/RFC_StatusContract.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/StatusContractRequest/";

declare function xf:StatusContractRequest($request as element(ns0:YFibtStatusContract))
    as element(ns0:YFibtStatusContract) {
        <ns0:YFibtStatusContract>
            {
                for $IDate in $request/IDate
                return
                    <IDate>{ data($IDate) }</IDate>
            }
        </ns0:YFibtStatusContract>
};

declare variable $request as element(ns0:YFibtStatusContract) external;

xf:StatusContractRequest($request)
