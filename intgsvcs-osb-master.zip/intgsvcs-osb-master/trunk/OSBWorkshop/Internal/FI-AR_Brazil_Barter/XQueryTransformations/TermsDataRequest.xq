(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtTermsData" location="../WSDLs/RFC_TermsData_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtTermsData" location="../WSDLs/RFC_TermsData.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/TermsDataRequest/";

declare function xf:TermsDataRequest($request as element(ns0:YFibtTermsData))
    as element(ns0:YFibtTermsData) {
        <ns0:YFibtTermsData>
            <IYysimuid>{ data($request/IYysimuid) }</IYysimuid>
        </ns0:YFibtTermsData>
};

declare variable $request as element(ns0:YFibtTermsData) external;

xf:TermsDataRequest($request)
