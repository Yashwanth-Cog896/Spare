(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtRfcTradcontractResponse" location="../WSDLs/RFC_TradeContract.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtRfcTradcontractResponse" location="../WSDLs/RFC_TradeContract_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/TradeContractResponse/";

declare function xf:TradeContractResponse($response as element(ns0:YFibtRfcTradcontractResponse))
    as element(ns0:YFibtRfcTradcontractResponse) {
        <ns0:YFibtRfcTradcontractResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtRfcTradcontractResponse>
};

declare variable $response as element(ns0:YFibtRfcTradcontractResponse) external;

xf:TradeContractResponse($response)
