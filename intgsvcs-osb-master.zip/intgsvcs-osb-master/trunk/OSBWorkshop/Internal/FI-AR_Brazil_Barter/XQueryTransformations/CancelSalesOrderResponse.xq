(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtBarterCancelSoResponse" location="../WSDLs/RFC_CancelSO.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtBarterCancelSoResponse" location="../WSDLs/RFC_CancelSO_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/CancelSalesOrderResponse/";

declare function xf:CancelSalesOrderResponse($response as element(ns0:YFibtBarterCancelSoResponse))
    as element(ns0:YFibtBarterCancelSoResponse) {
        <ns0:YFibtBarterCancelSoResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtBarterCancelSoResponse>
};

declare variable $response as element(ns0:YFibtBarterCancelSoResponse) external;

xf:CancelSalesOrderResponse($response)
