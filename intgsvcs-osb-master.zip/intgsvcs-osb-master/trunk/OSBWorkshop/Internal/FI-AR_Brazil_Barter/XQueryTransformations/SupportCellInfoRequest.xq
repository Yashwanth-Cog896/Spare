(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtSupportCellInfo" location="../WSDLs/RFC_SuppCellInfo_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtSupportCellInfo" location="../WSDLs/RFC_SuppCellInfo.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/SupportCellInfoRequest/";

declare function xf:SupportCellInfoRequest($request as element(ns0:YFibtSupportCellInfo))
    as element(ns0:YFibtSupportCellInfo) {
        <ns0:YFibtSupportCellInfo>
            <ItSuppCellInfo>{ $request/ItSuppCellInfo/@* , $request/ItSuppCellInfo/node() }</ItSuppCellInfo>
        </ns0:YFibtSupportCellInfo>
};

declare variable $request as element(ns0:YFibtSupportCellInfo) external;

xf:SupportCellInfoRequest($request)
