(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtTermsOrderResponse" location="../WSDLs/RFC_TermsOrder.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtTermsOrderResponse" location="../WSDLs/RFC_TermsOrder_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/TermsOrderResponse/";

declare function xf:TermsOrderResponse($response as element(ns0:YFibtTermsOrderResponse))
    as element(ns0:YFibtTermsOrderResponse) {
        <ns0:YFibtTermsOrderResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtTermsOrderResponse>
};

declare variable $response as element(ns0:YFibtTermsOrderResponse) external;

xf:TermsOrderResponse($response)
