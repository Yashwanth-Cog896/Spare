(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtSalesOrderSimulateResponse" location="../WSDLs/RFC_SOSimul.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtSalesOrderSimulateResponse" location="../WSDLs/RFC_SOSimul_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/SalesOrderSimulationResponse/";

declare function xf:SalesOrderSimulationResponse($response as element(ns0:YFibtSalesOrderSimulateResponse))
    as element(ns0:YFibtSalesOrderSimulateResponse) {
        <ns0:YFibtSalesOrderSimulateResponse>
            <BillingParty>{ $response/BillingParty/@* , $response/BillingParty/node() }</BillingParty>
            <Extensionin>{ $response/Extensionin/@* , $response/Extensionin/node() }</Extensionin>
            <Messagetable>{ $response/Messagetable/@* , $response/Messagetable/node() }</Messagetable>
            <NfmetallitmsEx>{ $response/NfmetallitmsEx/@* , $response/NfmetallitmsEx/node() }</NfmetallitmsEx>
            <NfmetallitmsIm>{ $response/NfmetallitmsIm/@* , $response/NfmetallitmsIm/node() }</NfmetallitmsIm>
            <OrderCcard>{ $response/OrderCcard/@* , $response/OrderCcard/node() }</OrderCcard>
            <OrderCcardEx>{ $response/OrderCcardEx/@* , $response/OrderCcardEx/node() }</OrderCcardEx>
            <OrderCfgsBlob>{ $response/OrderCfgsBlob/@* , $response/OrderCfgsBlob/node() }</OrderCfgsBlob>
            <OrderCfgsInst>{ $response/OrderCfgsInst/@* , $response/OrderCfgsInst/node() }</OrderCfgsInst>
            <OrderCfgsPartOf>{ $response/OrderCfgsPartOf/@* , $response/OrderCfgsPartOf/node() }</OrderCfgsPartOf>
            <OrderCfgsRef>{ $response/OrderCfgsRef/@* , $response/OrderCfgsRef/node() }</OrderCfgsRef>
            <OrderCfgsValue>{ $response/OrderCfgsValue/@* , $response/OrderCfgsValue/node() }</OrderCfgsValue>
            <OrderConditionEx>{ $response/OrderConditionEx/@* , $response/OrderConditionEx/node() }</OrderConditionEx>
            <OrderIncomplete>{ $response/OrderIncomplete/@* , $response/OrderIncomplete/node() }</OrderIncomplete>
            <OrderItemsIn>{ $response/OrderItemsIn/@* , $response/OrderItemsIn/node() }</OrderItemsIn>
            <OrderItemsOut>
                {
                    for $item in $response/OrderItemsOut/item
                    return
                        <item>
                            <ItmNumber>{ data($item/ItmNumber) }</ItmNumber>
                            <PoItmNo>{ data($item/PoItmNo) }</PoItmNo>
                            <Material>{ data($item/Material) }</Material>
                            <MatEntrd>{ data($item/MatEntrd) }</MatEntrd>
                            <ShortText>{ data($item/ShortText) }</ShortText>
                            <NetValue>{ data($item/NetValue) }</NetValue>
                            <Currency>{ data($item/Currency) }</Currency>
                            <Subtotal1>{ data($item/Subtotal1) }</Subtotal1>
                            <Subtotal2>{ data($item/Subtotal2) }</Subtotal2>
                            <Subtotal3>{ data($item/Subtotal3) }</Subtotal3>
                            <Subtotal4>{ data($item/Subtotal4) }</Subtotal4>
                            <Subtotal5>{ data($item/Subtotal5) }</Subtotal5>
                            <Subtotal6>{ data($item/Subtotal6) }</Subtotal6>
                            <SalesUnit>{ data($item/SalesUnit) }</SalesUnit>
                            <QtyReqDt>{ data($item/QtyReqDt) }</QtyReqDt>
                            <DlvDate>{ data($item/DlvDate) }</DlvDate>
                            <ReplTime>{ data($item/ReplTime) }</ReplTime>
                            <Configured>{ data($item/Configured) }</Configured>
                            <PurchNoC>{ data($item/PurchNoC) }</PurchNoC>
                            <PurchDate>{ data($item/PurchDate) }</PurchDate>
                            <PoMethod>{ data($item/PoMethod) }</PoMethod>
                            <Ref1>{ data($item/Ref1) }</Ref1>
                            <PurchNoS>{ data($item/PurchNoS) }</PurchNoS>
                            <PoDatS>{ data($item/PoDatS) }</PoDatS>
                            <PoMethS>{ data($item/PoMethS) }</PoMethS>
                            <Ref1S>{ data($item/Ref1S) }</Ref1S>
                            <PoItmNoS>{ data($item/PoItmNoS) }</PoItmNoS>
                            <NetValue1>{ data($item/NetValue1) }</NetValue1>
                            <CurrIso>{ data($item/CurrIso) }</CurrIso>
                            <SUnitIso>{ data($item/SUnitIso) }</SUnitIso>
                            <ReqQty>{ data($item/ReqQty) }</ReqQty>
                            <Plant>{ data($item/Plant) }</Plant>
                            <TxDocCur>{ data($item/TxDocCur) }</TxDocCur>
                            <MatExt>{ data($item/MatExt) }</MatExt>
                            <MatGuid>{ data($item/MatGuid) }</MatGuid>
                            <MatVers>{ data($item/MatVers) }</MatVers>
                            <MatEExt>{ data($item/MatEExt) }</MatEExt>
                            <MatEGuid>{ data($item/MatEGuid) }</MatEGuid>
                            <MatEVers>{ data($item/MatEVers) }</MatEVers>
                            <TargetQty>{ data($item/TargetQty) }</TargetQty>
                            <TargetQu>{ data($item/TargetQu) }</TargetQu>
                            <TUnitIso>{ data($item/TUnitIso) }</TUnitIso>
                            <ItemCateg>{ data($item/ItemCateg) }</ItemCateg>
                            <ShipPoint>{ data($item/ShipPoint) }</ShipPoint>
                            <HgLvItem>{ data($item/HgLvItem) }</HgLvItem>
                            <CustMat>{ data($item/CustMat) }</CustMat>
                            <PartDlv>{ data($item/PartDlv) }</PartDlv>
                            <ReasonRej>{ data($item/ReasonRej) }</ReasonRej>
                            <BillBlock>{ data($item/BillBlock) }</BillBlock>
                            <StgeLoc>{ data($item/StgeLoc) }</StgeLoc>
                            <ProdHier>{ data($item/ProdHier) }</ProdHier>
                            <MatlGroup>{ data($item/MatlGroup) }</MatlGroup>
                            <SUBTOT1>{ data($item/SUBTOTAL1) }</SUBTOT1>
                            <SUBTOT2>{ data($item/SUBTOTAL2) }</SUBTOT2>
                            <SUBTOT3>{ data($item/SUBTOTAL3) }</SUBTOT3>
                            <SUBTOT4>{ data($item/SUBTOTAL4) }</SUBTOT4>
                            <SUBTOT5>{ data($item/SUBTOTAL5) }</SUBTOT5>
                            <SUBTOT6>{ data($item/SUBTOTAL6) }</SUBTOT6>
                        </item>
                }
            </OrderItemsOut>
            <OrderPartners>{ $response/OrderPartners/@* , $response/OrderPartners/node() }</OrderPartners>
            <OrderScheduleEx>{ $response/OrderScheduleEx/@* , $response/OrderScheduleEx/node() }</OrderScheduleEx>
            <OrderScheduleIn>{ $response/OrderScheduleIn/@* , $response/OrderScheduleIn/node() }</OrderScheduleIn>
            <Partneraddresses>{ $response/Partneraddresses/@* , $response/Partneraddresses/node() }</Partneraddresses>
            <Return>{ $response/Return/@* , $response/Return/node() }</Return>
            <Salesdocument>{ data($response/Salesdocument) }</Salesdocument>
            <ShipToParty>{ $response/ShipToParty/@* , $response/ShipToParty/node() }</ShipToParty>
            <SoldToParty>{ $response/SoldToParty/@* , $response/SoldToParty/node() }</SoldToParty>
        </ns0:YFibtSalesOrderSimulateResponse>
};

declare variable $response as element(ns0:YFibtSalesOrderSimulateResponse) external;

xf:SalesOrderSimulationResponse($response)
