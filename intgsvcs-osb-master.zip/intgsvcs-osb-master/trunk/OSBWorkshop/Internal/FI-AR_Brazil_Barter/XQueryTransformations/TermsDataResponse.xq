(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtTermsDataResponse" location="../WSDLs/RFC_TermsData.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtTermsDataResponse" location="../WSDLs/RFC_TermsData_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/TermsDataResponse/";

declare function xf:TermsDataResponse($response as element(ns0:YFibtTermsDataResponse))
    as element(ns0:YFibtTermsDataResponse) {
        <ns0:YFibtTermsDataResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
            <EtOpenItems>
                {
                    for $item in $response/EtOpenItems/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtOpenItems>
        </ns0:YFibtTermsDataResponse>
};

declare variable $response as element(ns0:YFibtTermsDataResponse) external;

xf:TermsDataResponse($response)
