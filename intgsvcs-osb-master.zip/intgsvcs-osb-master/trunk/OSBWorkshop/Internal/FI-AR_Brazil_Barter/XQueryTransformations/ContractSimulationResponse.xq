(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtContrSimulResponse" location="../WSDLs/RFC_ContrSimul.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtContrSimulResponse" location="../WSDLs/RFC_ContrSimul_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/ContractSimulationResponse/";

declare function xf:ContractSimulationResponse($response as element(ns0:YFibtContrSimulResponse))
    as element(ns0:YFibtContrSimulResponse) {
        <ns0:YFibtContrSimulResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtContrSimulResponse>
};

declare variable $response as element(ns0:YFibtContrSimulResponse) external;

xf:ContractSimulationResponse($response)
