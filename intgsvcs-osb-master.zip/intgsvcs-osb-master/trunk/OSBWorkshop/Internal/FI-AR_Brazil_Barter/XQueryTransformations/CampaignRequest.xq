(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtRfcBarterCampaign" location="../WSDLs/RFC_Campaign_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtRfcBarterCampaign" location="../WSDLs/RFC_Campaign.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/CampaignRequest/";

declare function xf:CampaignRequest($request as element(ns0:YFibtRfcBarterCampaign))
    as element(ns0:YFibtRfcBarterCampaign) {
        <ns0:YFibtRfcBarterCampaign>
            <IAction>{ data($request/IAction) }</IAction>
            <IsReqCampaign>
                <Yymandt>{ data($request/IsReqCampaign/Yymandt) }</Yymandt>
                <Yycountry>{ data($request/IsReqCampaign/Yycountry) }</Yycountry>
                <Yybarcamid>{ data($request/IsReqCampaign/Yybarcamid) }</Yybarcamid>
                <Yyspart>{ data($request/IsReqCampaign/Yyspart) }</Yyspart>
                <Yybartnam>{ data($request/IsReqCampaign/Yybartnam) }</Yybartnam>
                <Yystardat>{ data($request/IsReqCampaign/Yystardat) }</Yystardat>
                <Yyenddat>{ data($request/IsReqCampaign/Yyenddat) }</Yyenddat>
                <Yybaseyear>{ data($request/IsReqCampaign/Yybaseyear) }</Yybaseyear>
                <Yymaxdapay>{ data($request/IsReqCampaign/Yymaxdapay) }</Yymaxdapay>
                <Yyincent>{ data($request/IsReqCampaign/Yyincent) }</Yyincent>
                <Yymaxamo>{ data($request/IsReqCampaign/Yymaxamo) }</Yymaxamo>
                <Yymaxinc>{ data($request/IsReqCampaign/Yymaxinc) }</Yymaxinc>
                <Yyconamon>{ data($request/IsReqCampaign/Yyconamon) }</Yyconamon>
                <Yycominc>{ data($request/IsReqCampaign/Yycominc) }</Yycominc>
                <Yycurren>{ data($request/IsReqCampaign/Yycurren) }</Yycurren>
                <Yyupduserid>{ data($request/IsReqCampaign/Yyupduserid) }</Yyupduserid>
                <Yyupddate>{ data($request/IsReqCampaign/Yyupddate) }</Yyupddate>
                <Yyupdtime>{ data($request/IsReqCampaign/Yyupdtime) }</Yyupdtime>
            </IsReqCampaign>
            <ItReqCampBrand>
                {
                    for $item in $request/ItReqCampBrand/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItReqCampBrand>
            <ItReqCampComm>
                {
                    for $item in $request/ItReqCampComm/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItReqCampComm>
            <ItReqCampSale>
                {
                    for $item in $request/ItReqCampSale/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItReqCampSale>
            <ItReqCampTrade>
                {
                    for $item in $request/ItReqCampTrade/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItReqCampTrade>
        </ns0:YFibtRfcBarterCampaign>
};

declare variable $request as element(ns0:YFibtRfcBarterCampaign) external;

xf:CampaignRequest($request)
