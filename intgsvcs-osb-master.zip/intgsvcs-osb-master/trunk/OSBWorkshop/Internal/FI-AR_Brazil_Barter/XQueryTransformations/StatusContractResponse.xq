(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtStatusContractResponse" location="../WSDLs/RFC_StatusContract.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtStatusContractResponse" location="../WSDLs/RFC_StatusContract_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/StatusContractResponse/";

declare function xf:StatusContractResponse($response as element(ns0:YFibtStatusContractResponse))
    as element(ns0:YFibtStatusContractResponse) {
        <ns0:YFibtStatusContractResponse>
            <EtBarterClose>
                {
                    for $item in $response/EtBarterClose/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtBarterClose>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtStatusContractResponse>
};

declare variable $response as element(ns0:YFibtStatusContractResponse) external;

xf:StatusContractResponse($response)
