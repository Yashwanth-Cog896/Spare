(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtRfcTradcontract" location="../WSDLs/RFC_TradeContract_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtRfcTradcontract" location="../WSDLs/RFC_TradeContract.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/TradeContractRequest/";

declare function xf:TradeContractRequest($request as element(ns0:YFibtRfcTradcontract))
    as element(ns0:YFibtRfcTradcontract) {
        <ns0:YFibtRfcTradcontract>
            <IsReqContract>{ $request/IsReqContract/@* , $request/IsReqContract/node() }</IsReqContract>
        </ns0:YFibtRfcTradcontract>
};

declare variable $request as element(ns0:YFibtRfcTradcontract) external;

xf:TradeContractRequest($request)
