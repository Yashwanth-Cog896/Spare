(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtRfcBarterCampaignResponse" location="../WSDLs/RFC_Campaign.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtRfcBarterCampaignResponse" location="../WSDLs/RFC_Campaign_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/CampaignResponse/";

declare function xf:CampaignResponse($response as element(ns0:YFibtRfcBarterCampaignResponse))
    as element(ns0:YFibtRfcBarterCampaignResponse) {
        <ns0:YFibtRfcBarterCampaignResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtRfcBarterCampaignResponse>
};

declare variable $response as element(ns0:YFibtRfcBarterCampaignResponse) external;

xf:CampaignResponse($response)
