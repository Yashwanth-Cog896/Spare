(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtCreditCheck" location="../WSDLs/RFC_CreditCheck_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtCreditCheck" location="../WSDLs/RFC_CreditCheck.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/CreditCheckRequest/";

declare function xf:CreditCheckRequest($request as element(ns0:YFibtCreditCheck))
    as element(ns0:YFibtCreditCheck) {
        <ns0:YFibtCreditCheck>
            <ICountry>{ data($request/ICountry) }</ICountry>
            <ICurrency>{ data($request/ICurrency) }</ICurrency>
            <ICustomer>{ data($request/ICustomer) }</ICustomer>
            <IOperationAmt>{ data($request/IOperationAmt) }</IOperationAmt>
        </ns0:YFibtCreditCheck>
};

declare variable $request as element(ns0:YFibtCreditCheck) external;

xf:CreditCheckRequest($request)
