(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFibtSupportCellInfoResponse" location="../WSDLs/RFC_SuppCellInfo.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtSupportCellInfoResponse" location="../WSDLs/RFC_SuppCellInfo_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/SupportCellInfoResponse/";

declare function xf:SupportCellInfoResponse($response as element(ns0:YFibtSupportCellInfoResponse))
    as element(ns0:YFibtSupportCellInfoResponse) {
        <ns0:YFibtSupportCellInfoResponse>
            <EtMessages>
                {
                    for $item in $response/EtMessages/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </EtMessages>
        </ns0:YFibtSupportCellInfoResponse>
};

declare variable $response as element(ns0:YFibtSupportCellInfoResponse) external;

xf:SupportCellInfoResponse($response)
