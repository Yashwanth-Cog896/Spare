(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtBarterCancelSo" location="../WSDLs/RFC_CancelSO_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtBarterCancelSo" location="../WSDLs/RFC_CancelSO.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/CancelSalesOrderRequest/";

declare function xf:CancelSalesOrderRequest($request as element(ns0:YFibtBarterCancelSo))
    as element(ns0:YFibtBarterCancelSo) {
        <ns0:YFibtBarterCancelSo>
            <IYycountry>{ data($request/IYycountry) }</IYycountry>
            <IYyordnum>{ data($request/IYyordnum) }</IYyordnum>
            <IYysimuid>{ data($request/IYysimuid) }</IYysimuid>
        </ns0:YFibtBarterCancelSo>
};

declare variable $request as element(ns0:YFibtBarterCancelSo) external;

xf:CancelSalesOrderRequest($request)
