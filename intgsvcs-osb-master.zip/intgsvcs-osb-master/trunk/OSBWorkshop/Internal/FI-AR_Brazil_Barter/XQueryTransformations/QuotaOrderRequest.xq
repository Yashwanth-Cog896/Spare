(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YFibtQuotaOrder" location="../WSDLs/RFC_QuotaOrder_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFibtQuotaOrder" location="../WSDLs/RFC_QuotaOrder.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/FI-AR_Brazil_Barter/XQueryTransformations/QuotaOrderRequest/";

declare function xf:QuotaOrderRequest($request as element(ns0:YFibtQuotaOrder))
    as element(ns0:YFibtQuotaOrder) {
        <ns0:YFibtQuotaOrder>
            <IsHeader>{ $request/IsHeader/@* , $request/IsHeader/node() }</IsHeader>
            <IsYfibtPanbarter>{ $request/IsYfibtPanbarter/@* , $request/IsYfibtPanbarter/node() }</IsYfibtPanbarter>
            <ItConditions>{ $request/ItConditions/@* , $request/ItConditions/node() }</ItConditions>
            <ItItems>{ $request/ItItems/@* , $request/ItItems/node() }</ItItems>
            <ItPartners>{ $request/ItPartners/@* , $request/ItPartners/node() }</ItPartners>
        </ns0:YFibtQuotaOrder>
};

declare variable $request as element(ns0:YFibtQuotaOrder) external;

xf:QuotaOrderRequest($request)
