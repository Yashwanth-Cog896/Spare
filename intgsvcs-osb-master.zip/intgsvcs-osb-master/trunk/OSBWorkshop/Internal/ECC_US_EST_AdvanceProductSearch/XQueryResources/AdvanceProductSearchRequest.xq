(:: pragma bea:global-element-parameter parameter="$request" element="ns1:AdvanceProductSearchRequest" location="../Schemas/AdvanceProductSearch.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstAdvprodsrch" location="../WSDLs/YES_Y_SDSA_USSEED_EST_ADVPROD.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "Monsanto:Service:AdvanceProductSearch";
declare namespace ns0 = "urn:monsanto:uscomm:service:header";
declare namespace xf = "http://tempuri.org/ECC_US_EST_AdvanceProductSearch/XQueryResources/AdvancedProductSearchRequest/";

declare function xf:AdvancedProductSearchRequest($request as element(ns1:AdvanceProductSearchRequest))
    as element(ns2:YSdsaUsseedEstAdvprodsrch) {
        <ns2:YSdsaUsseedEstAdvprodsrch>
            <Ybatch>{ fn:upper-case(data($request/ns1:AdvanceProductSearchRequestBody/ns1:LotNumber)) }</Ybatch>
            <Ydealer>{ data($request/ns1:AdvanceProductSearchRequestBody/ns1:DealerEntity/ns1:PartnerIdentifier) }</Ydealer>
            <YreqType>{ xs:string( data($request/ns1:AdvanceProductSearchRequestBody/@RequestType) ) }</YreqType>
            {
                for $SeedYear in $request/ns1:AdvanceProductSearchRequestBody/ns1:SeedYear
                return
                    <Yyear>{ xs:string( data($SeedYear) ) }</Yyear>
            }
        </ns2:YSdsaUsseedEstAdvprodsrch>
};

declare variable $request as element(ns1:AdvanceProductSearchRequest) external;

xf:AdvancedProductSearchRequest($request)
