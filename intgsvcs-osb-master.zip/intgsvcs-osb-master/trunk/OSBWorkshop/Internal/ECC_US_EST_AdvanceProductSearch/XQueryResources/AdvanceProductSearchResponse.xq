(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstAdvprodsrchResponse" location="../WSDLs/YES_Y_SDSA_USSEED_EST_ADVPROD.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:AdvanceProductSearchResponse" location="../Schemas/AdvanceProductSearch.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "Monsanto:Service:AdvanceProductSearch";
declare namespace ns0 = "urn:monsanto:uscomm:service:header";
declare namespace xf = "http://tempuri.org/ECC_US_EST_AdvanceProductSearch/XQueryResources/AdvancedProductSearchResponse/";

declare function xf:AdvancedProductSearchResponse($response as element(ns2:YSdsaUsseedEstAdvprodsrchResponse))
    as element(ns1:AdvanceProductSearchResponse) {
        <ns1:AdvanceProductSearchResponse Version = "1.0">
            <ns1:AdvanceProductSearchResponseBody RequestType = "{ data($response/SeedHdr/YreqType) }">
                <ns1:AdvanceProductSearchResponseProperties>
                    {
                    if(data($response/SeedHdr/YcropYear)!='0000')then(
                    <ns1:SeedYear>{ xs:integer( data($response/SeedHdr/YcropYear) ) }</ns1:SeedYear>
                    )else()
                    }
                </ns1:AdvanceProductSearchResponseProperties>
                <ns1:AdvanceProductSearchResponseDetails>
                    {
                        for $item0 in $response/SeedMatlDtls/item
                        return
                            <ns1:AdvanceProductSearchResponseDetail>
                                <ns1:ProductInformation>
                                    <ns1:ProductIdentification>
                                        <ns1:ProductIdentifier Type = "SAP">{ data($item0/Yymatnr) }</ns1:ProductIdentifier>
                                        <ns1:ProductName>{ data($item0/YysalesTxt) }</ns1:ProductName>
                                    </ns1:ProductIdentification>
                                    <ns1:ProductCrop>{ data($item0/Yycrop) }</ns1:ProductCrop>
                                    <ns1:BrandName>{ data($item0/YybrandDesc) }</ns1:BrandName>
                                    <ns1:ProductVariety>{ data($item0/Yyacronym) }</ns1:ProductVariety>
                                    <ns1:ProductTrait>{ data($item0/YytraitDesc) }</ns1:ProductTrait>
                                    <ns1:SeedSize>{ data($item0/Yygrdsize) }</ns1:SeedSize>
                                    <ns1:UPC>{ data($item0/YyupcCode) }</ns1:UPC>
                                    <ns1:GTIN>{ data($item0/Yygtin) }</ns1:GTIN>
                                    <ns1:ProductTreatment>{ data($item0/Yyspctrtmtds) }</ns1:ProductTreatment>
                                    <ns1:PackageSizeName>{ data($item0/Yypkgsizds) }</ns1:PackageSizeName>
                                    <ns1:PackageTypeDescription>{ data($item0/Yypkgtypds) }</ns1:PackageTypeDescription>
                                    <ns1:BaseQuantity>
                                    	{
                                    	if(data($item0/Yysordunit)!='')then(
                                        <ns1:Measurement>
                                            <ns1:MeasurementValue>{ data($item0/Yvsordqty) }</ns1:MeasurementValue>
                                            <ns1:UnitOfMeasureCode>{ data($item0/Yysordunit) }</ns1:UnitOfMeasureCode>
                                        </ns1:Measurement>
                                        )else()
                                        }
                                    </ns1:BaseQuantity>
                                    {
                                    	if($response/SeedHdr/YreqType/text()="HAULBACK") then (
		                                    <ns1:ProductPrice>
		                                    {if( data($item0/Yvpricecuky)!='')then(		                                    	
		                                        <ns1:MonetaryAmount>
		                                            <ns1:MonetaryValue>{ data($item0/Yvprice) }</ns1:MonetaryValue>
		                                            <ns1:CurencyCode>{ data($item0/Yvpricecuky) }</ns1:CurencyCode>
		                                        </ns1:MonetaryAmount>
		                                        )else()
		                                        }
		                                    </ns1:ProductPrice>
	                                    ) else()
                                    }
	                                </ns1:ProductInformation>
	                                {
	                                    for $item in $response/SeedBtchDtls/item,
	                                        $SeedMatlDtls in $response/SeedMatlDtls
	                                    where data($item/Ymatnr) = data($SeedMatlDtls/item[1]/Yymatnr)
	                                    return
	                                        <ns1:LotInformation>
	                                            <ns1:LotNumber>{ data($item/Ycharg) }</ns1:LotNumber>
	                                            {if(data($item/YyseedLb)!='')then(
	                                            <ns1:SeedsPerPound>{ xs:integer( data($item/YyseedLb) ) }</ns1:SeedsPerPound>
	                                            )else()}
	                                        </ns1:LotInformation>
	                                }
	                                {
	                                    if($response/SeedHdr/YreqType/text()="TRANSFER")then(
	                                    for $item in $response/SeedPkgDtls/item
	                                    return
	                                    	if(data($item0/Yymatnr)= data($item/Yymatnr))then(
	                                    	<ns1:PackageInformation>
	                                            <ns1:PackageIdentification>
	                                                <ns1:PackageIdentifier Type="SAP">{ data($item/Yymatnrpkg) }</ns1:PackageIdentifier>
	                                                <ns1:PackageName>{ data($item/YysalesTxtpkg) }</ns1:PackageName>
	                                            </ns1:PackageIdentification>
	                                            <ns1:LotNumber>{ data($item/Yycharg) }</ns1:LotNumber>
	                                            <ns1:PackageCrop>{ data($item/Yycroppkg) }</ns1:PackageCrop>
	                                            <ns1:PackageMaterialGroup>{ data($item/Yymatklpkg) }</ns1:PackageMaterialGroup>
	                                        </ns1:PackageInformation>
	                                        )else()
	                                    
	                                    )else()
	                                }
                            </ns1:AdvanceProductSearchResponseDetail>
                    }
                </ns1:AdvanceProductSearchResponseDetails>
            </ns1:AdvanceProductSearchResponseBody>
            <ns1:AdvanceProductSearchResponseError>
                <ns1:ErrorType>
                    {
                        if (data($response/Messages/item[1]/Type) = "S") then
                            ("Success")
                        else 
                            if (data($response/Messages/item[1]/Type) = "E") then
                                ("Error")
                            else 
                                if (data($response/Messages/item[1]/Type) = "W") then
                                    ("Warning")
                                else 
                                    if (data($response/Messages/item[1]/Type) = "I") then
                                        ("Info")
                                    else 
                                        if (data($response/Messages/item[1]/Type) = "A") then
                                            ("Abort")
                                        else 
                                            ()
                    }
				</ns1:ErrorType>
                <ns1:ErrorMessageClass>{ data($response/Messages/item[1]/Id) }</ns1:ErrorMessageClass>
                 {
        			if(data($response/Messages/item[1]/Number)!='')then(
                		<ns1:ErrorMessageNumber>{ xs:integer( data($response/Messages/item[1]/Number) ) }</ns1:ErrorMessageNumber>
                	)else()
                 }		
                <ns1:ErrorMessageText>{ data($response/Messages/item[1]/ErrDesc) }</ns1:ErrorMessageText>
                <ns1:ErrorMessageDisplayText>{ data($response/Messages/item[1]/ErrDescDisp) }</ns1:ErrorMessageDisplayText>
            </ns1:AdvanceProductSearchResponseError>
        </ns1:AdvanceProductSearchResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstAdvprodsrchResponse) external;

xf:AdvancedProductSearchResponse($response)
