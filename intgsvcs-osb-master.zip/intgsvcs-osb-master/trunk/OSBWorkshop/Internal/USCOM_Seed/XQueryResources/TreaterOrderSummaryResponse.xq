xquery version "1.0" encoding "Cp1252";
(:: pragma bea:global-element-parameter parameter="$response" element="ns1:YsaTosReport" location="../WSDLs/YES_YSA_TOS_REPORT.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:MT_TreaterOrderSummary_OSB_Rsp" location="../WSDLs/MI_AcceleronTreaterOrderSummary_OSB_S_Req.wsdl" ::)

declare namespace xf = "http://tempuri.org/USCOM_Seed/XQueryResources/TreaterOrderSummaryResponse/";
declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://monsanto.com/SD/AcceleronTreaterOrderSummary";

declare function xf:TreaterOrderSummaryResponse($response as element(ns1:YsaTosReportResponse))
    as element(ns0:MT_TreaterOrderSummary_OSB_Rsp) {
        <ns0:MT_TreaterOrderSummary_OSB_Rsp>
        <TreaterOrderSummaryResponseBody>
                {
                    for $TTreaterDemoOut in $response/TTreaterDemoOut/item
                    return
                        <TreaterDetails>
                            <TreaterID>{ data($TTreaterDemoOut/YyTreaterId) }</TreaterID>
                            <Location>
                                <Name>{ data($TTreaterDemoOut/YyTreaterName) }</Name>
                                <Street>{ data($TTreaterDemoOut/YyTreaterStreet) }</Street>
                                <City>{ data($TTreaterDemoOut/YyTreaterCity) }</City>
                                <State>{ data($TTreaterDemoOut/YyTreaterState) }</State>
                                <ZipCode>{ data($TTreaterDemoOut/YyTreaterZipcode) }</ZipCode>
                            </Location>
                        {
                        for $TTreaterCompOut in $response/TTreaterCompOut/item
                        return
                            if (data($TTreaterCompOut/YyTreaterId) = data($TTreaterDemoOut/YyTreaterId)) then
                            ( 
                            <ComponentDetails>
                                <ComponentName>{ data($TTreaterCompOut/YyCompName) }</ComponentName>
                                
                                
                                                       
                                {
                                    for $YY_TOT_CURRENT_YEAR in $TTreaterCompOut/YyTotCurrentYear
                                    return
                                                  if ( substring(data($YY_TOT_CURRENT_YEAR),string-length(data($YY_TOT_CURRENT_YEAR)),string-length(data($YY_TOT_CURRENT_YEAR))) = "-" ) then
                                                      <CurrentYear>{ substring(data($YY_TOT_CURRENT_YEAR),1,string-length(data($YY_TOT_CURRENT_YEAR)) - 1) }</CurrentYear>
                                                  else
                                                      <CurrentYear>{ data($YY_TOT_CURRENT_YEAR) }</CurrentYear>
                                }
                                
                                
                                {
                                    for $YY_TOT_CARRY_IN in $TTreaterCompOut/YyTotCarryIn
                                    return
                                                  if ( substring(data($YY_TOT_CARRY_IN),string-length(data($YY_TOT_CARRY_IN)),string-length(data($YY_TOT_CARRY_IN))) = "-" ) then
                                                      <CarryIn>{ substring(data($YY_TOT_CARRY_IN),1,string-length(data($YY_TOT_CARRY_IN)) - 1) }</CarryIn>
                                                  else
                                                      <CarryIn>{ data($YY_TOT_CARRY_IN) }</CarryIn>
                                }
                                
                                
                                {
                                    for $YY_TOT_ORDERED in $TTreaterCompOut/YyTotOrdered
                                    return
                                                  if ( substring(data($YY_TOT_ORDERED),string-length(data($YY_TOT_ORDERED)),string-length(data($YY_TOT_ORDERED))) = "-" ) then
                                                      <TotalOrdered>{ substring(data($YY_TOT_ORDERED),1,string-length(data($YY_TOT_ORDERED)) - 1) }</TotalOrdered>
                                                  else
                                                      <TotalOrdered>{ data($YY_TOT_ORDERED) }</TotalOrdered>
                                }
                                
                                
                                
                               
                                 {
                                    for $YY_TOT_SHIPPED in $TTreaterCompOut/YyTotShipped
                                    return
                                              if ( substring(data($YY_TOT_SHIPPED),string-length(data($YY_TOT_SHIPPED)),string-length(data($YY_TOT_SHIPPED))) = "-") then
                                                  <TotalShipped>{ substring(data($YY_TOT_SHIPPED),1,string-length(data($YY_TOT_SHIPPED)) - 1) }</TotalShipped>
                                              else
                                                  <TotalShipped>{ data($YY_TOT_SHIPPED) }</TotalShipped>
                                }
                                
                                
                                {
                                    for $YY_TOT_USED in $TTreaterCompOut/YyTotUsed
                                    return
                                              if ( substring(data($YY_TOT_USED),string-length(data($YY_TOT_USED)),string-length(data($YY_TOT_USED))) = "-") then
                                                  <TotalUsed>{ substring(data($YY_TOT_USED),1,string-length(data($YY_TOT_USED)) - 1) }</TotalUsed>
                                              else
                                                  <TotalUsed>{ data($YY_TOT_USED) }</TotalUsed>
                                }
                                
                                
                                {
                                    for $YY_REMAINING in $TTreaterCompOut/YyRemaining
                                    return
                                              if ( substring(data($YY_REMAINING),string-length(data($YY_REMAINING)),string-length(data($YY_REMAINING))) = "-") then
                                                  <Remaining>{ substring(data($YY_REMAINING),1,string-length(data($YY_REMAINING)) - 1) }</Remaining>
                                              else
                                                  <Remaining>{ data($YY_REMAINING) }</Remaining>
                                }
                                
                                {
                                    for $YY_ACTUAL in $TTreaterCompOut/YyActual
                                    return
                                              if ( substring(data($YY_ACTUAL),string-length(data($YY_ACTUAL)),string-length(data($YY_ACTUAL))) = "-") then
                                                  <Actual>{ substring(data($YY_ACTUAL),1,string-length(data($YY_ACTUAL)) - 1) }</Actual>
                                              else
                                                  <Actual>{ data($YY_ACTUAL) }</Actual>
                                }
                                
                                {
                                    for $YY_REPORTING_UOM in $TTreaterCompOut/YyReportingUom
                                    return
                                        <ReportingUOM>{ data($YY_REPORTING_UOM) }</ReportingUOM>
                                }
                                
                                {
                                    for $YY_PERCENT_DIFF in $TTreaterCompOut/YyPercentDiff
                                    return
                                        <PercentageDifference>{ data($YY_PERCENT_DIFF) }</PercentageDifference>
                                }
                                
                                {
                                	for $YY_EXPLANATION in $TTreaterCompOut/YyExplanation
                                	return
                                	<Explanation>{ data($YY_EXPLANATION) }</Explanation>
                                }
                            </ComponentDetails>                          
                            )
                            else
                            (
                            )
                        }
                        
                        
                        {
                        for $YYERROR in $response/TReturn/item
                              return
                            if (data($YYERROR/Id) = data($TTreaterDemoOut/YyTreaterId)) then (
                            <ErrorDetails>
                                <ErrorType>                            {
                                if (data($YYERROR/Type) = "S") then
                                    ('Success')
                                else 
                                    ('Error')
                            }</ErrorType>
                                <ErrorMessageClass>{ data($YYERROR/Id) }</ErrorMessageClass>
                                <ErrorMessageNumber>{ data($YYERROR/Number) }</ErrorMessageNumber>
                                <ErrorMessageText>{ data($YYERROR/Message) }</ErrorMessageText>
                            </ErrorDetails>
                           )
                           else ()
                        }
                        
                        
                        </TreaterDetails>
                }
            </TreaterOrderSummaryResponseBody>
        </ns0:MT_TreaterOrderSummary_OSB_Rsp>
};

declare variable $response as element(ns1:YsaTosReportResponse) external;

xf:TreaterOrderSummaryResponse($response)
