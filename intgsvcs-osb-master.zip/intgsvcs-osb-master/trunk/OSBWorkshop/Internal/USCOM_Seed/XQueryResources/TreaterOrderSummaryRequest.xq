(:: pragma bea:global-element-parameter parameter="$request" element="ns0:MT_TreaterOrderSummary_OSB_Req" location="../WSDLs/MI_AcceleronTreaterOrderSummary_OSB_S_Req.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:YsaTosReport" location="../WSDLs/YES_YSA_TOS_REPORT.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://monsanto.com/SD/AcceleronTreaterOrderSummary";
declare namespace xf = "http://tempuri.org/USCOM_Seed/XQueryResources/TreaterOrderSummaryRequest/";

declare function xf:TreaterOrderSummaryRequest($request as element(ns0:MT_TreaterOrderSummary_OSB_Req))
    as element(ns1:YsaTosReport) {
        <ns1:YsaTosReport>
            <IReporterId>{ data($request/TreaterOrderSummaryRequestBody/ReportingID) }</IReporterId>
          <TReturn>
            <item>
               <Type></Type>
               <Id></Id>
               <Number></Number>
               <Message></Message>
               <LogNo></LogNo>
               <LogMsgNo></LogMsgNo>
               <MessageV1></MessageV1>
               <MessageV2></MessageV2>
               <MessageV3></MessageV3>
               <MessageV4></MessageV4>
               <Parameter></Parameter>
               <Row></Row>
               <Field></Field>
               <System></System>
            </item>
         </TReturn>
         <TTreaterCompOut>   
            <item>
               <YyTreaterId></YyTreaterId>
               <YyCompName></YyCompName>
               <YyTotOrdered></YyTotOrdered>
               <YyTotShipped></YyTotShipped>
               <YyTotUsed></YyTotUsed>
               <YyRemaining></YyRemaining>
               <YyActual></YyActual>
               <YyReportingUom></YyReportingUom>
               <YyPercentDiff></YyPercentDiff>
               <YyExplanation></YyExplanation>
            </item>
         </TTreaterCompOut>        
         <TTreaterDemoOut>
            <item>
               <YyTreaterId></YyTreaterId>
               <YyTreaterName></YyTreaterName>
               <YyTreaterStreet></YyTreaterStreet>
               <YyTreaterCity></YyTreaterCity>
               <YyTreaterState></YyTreaterState>
               <YyTreaterZipcode></YyTreaterZipcode>
            </item>
         </TTreaterDemoOut> 
            <TTreaterIn>
            { for $treater in $request/TreaterOrderSummaryRequestBody/TreaterList
           	return
                <item>
                    <YyTreaterId>{ data($treater/TreaterID) }</YyTreaterId>
                    <YytreaterType>{ data($treater/TreaterType) }</YytreaterType>
                </item> 
            }
            </TTreaterIn>
        </ns1:YsaTosReport>
};

declare variable $request as element(ns0:MT_TreaterOrderSummary_OSB_Req) external;

xf:TreaterOrderSummaryRequest($request)
