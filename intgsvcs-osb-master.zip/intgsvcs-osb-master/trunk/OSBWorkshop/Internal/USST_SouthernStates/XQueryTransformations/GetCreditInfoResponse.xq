(:: pragma bea:global-element-parameter parameter="$yFiarGetCreditArInfoResponse" element="ns2:YFiarGetCreditArInfoResponse" location="../WSDLs/GetCreditInfo.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:GrowerCreditResponse" location="../WSDLs/GetCreditInfo_Java.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:GrowerCredit";
declare namespace xf = "http://tempuri.org/USST_SouthernStates/XQueryTransformations/GetCreditInfoResponse/";

declare function xf:GetCreditInfoResponse($yFiarGetCreditArInfoResponse as element(ns2:YFiarGetCreditArInfoResponse))
    as element(ns0:GrowerCreditResponse) {
        <ns0:GrowerCreditResponse>
            <ns0:GrowerCreditResponseBody>
            {for $item in($yFiarGetCreditArInfoResponse/TECreditArbalCh/item) return
                <ns0:GrowerCreditResponseDetails>
                	<ns0:GrowerIdentification>{data($item/Yygrower)}</ns0:GrowerIdentification>
                    <ns0:CreditLimit>{ data($item/Yyklimk) }</ns0:CreditLimit>
                    <ns0:AmountOfCreditUsed>{ data($item/Yywrbtr) }</ns0:AmountOfCreditUsed>
                </ns0:GrowerCreditResponseDetails>
            }
            </ns0:GrowerCreditResponseBody>
        </ns0:GrowerCreditResponse>
};

declare variable $yFiarGetCreditArInfoResponse as element(ns2:YFiarGetCreditArInfoResponse) external;

xf:GetCreditInfoResponse($yFiarGetCreditArInfoResponse)
