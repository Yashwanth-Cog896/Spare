(:: pragma bea:global-element-parameter parameter="$growerCreditRequest" element="ns0:GrowerCreditRequest" location="../WSDLs/GetCreditInfo_Java.wsdl" ::)
(:: pragma bea:global-element-return element="ns2:YFiarGetCreditArInfo" location="../WSDLs/GetCreditInfo.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:GrowerCredit";
declare namespace xf = "http://tempuri.org/USST_SouthernStates/XQueryTransformations/GetCreditInfoRequest/";

declare function xf:GetCreditInfoRequest($growerCreditRequest as element(ns0:GrowerCreditRequest))
    as element(ns2:YFiarGetCreditArInfo) {
        <ns2:YFiarGetCreditArInfo>
        	<ICreditControl>5180</ICreditControl>
        	<TECreditArbalCh></TECreditArbalCh>
        	<TEErrorCh></TEErrorCh>
            <TIGrowerListCh>
            { for $GrowerIdentification in ($growerCreditRequest/ns0:GrowerCreditRequestBody/ns0:GrowerList/ns0:GrowerIdentification) return
                <item>
                    <Yygrower>{xs:string( data($GrowerIdentification)) }</Yygrower>
                </item>
            }
            </TIGrowerListCh>
        </ns2:YFiarGetCreditArInfo>
};

declare variable $growerCreditRequest as element(ns0:GrowerCreditRequest) external;

xf:GetCreditInfoRequest($growerCreditRequest)
