(:: pragma bea:global-element-parameter parameter="$aGIISProductExtract1" element="ns1:AGIISProductExtract" location="../WSDL/W_ClientContrl_AGIISProductUpdate_A_OB.wsdl" ::)
(:: pragma bea:global-element-return element="AGIISProductUpdate" location="../WSDL/W_PI_AGIISProductUpdate_A_IN.wsdl" ::)

declare namespace ns1 = "urn:agiis:schema:all:2:0";
declare namespace ns0 = "urn:cidx:names:DRAFT_0014:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/XQueryProject/XQueryResources/ProductList/";

declare function xf:ProductList($aGIISProductExtract1 as element(ns1:AGIISProductExtract))
    as element(AGIISProductUpdate) {
        <AGIISProductUpdate Version = "2.0">
            <Header>
                <ThisDocumentIdentifier>
                    <DocumentIdentifier>{ fn:substring(xs:string(data($aGIISProductExtract1/ns0:Header/ns0:ThisDocumentDateTime/ns0:DateTime)), 1, 19) }</DocumentIdentifier>
                </ThisDocumentIdentifier>
                <ThisDocumentDateTime>
                    <DateTime DateTimeQualifier = "{ xs:string( data($aGIISProductExtract1/ns0:Header/ns0:ThisDocumentDateTime/ns0:DateTime/@DateTimeQualifier) ) }">{ xs:string( data($aGIISProductExtract1/ns0:Header/ns0:ThisDocumentDateTime/ns0:DateTime) ) }</DateTime>
                </ThisDocumentDateTime>
                <From>
                    <PartnerInformation>
                        <PartnerName>Monsanto Company</PartnerName>
                        <PartnerIdentifier Agency = "EBID">0062668030000</PartnerIdentifier>
                        <ContactInformation>
                            <ContactName>Andrew Jeremiah</ContactName>
                            <TelephoneNumber>
                                <NationalTelephoneNumber>(314)694-2918</NationalTelephoneNumber>
                            </TelephoneNumber>
                            <EmailAddress>andrew.r.jeremiah@monsanto.com</EmailAddress>
                        </ContactInformation>
                    </PartnerInformation>
                </From>
                <To>
                    <PartnerInformation>
                        <PartnerName>Covansys</PartnerName>
                        <PartnerIdentifier Agency = "EBID">1324108090000</PartnerIdentifier>
                        <ContactInformation>
                            <ContactName>Josh Wall</ContactName>
                            <TelephoneNumber>
                                <NationalTelephoneNumber>(866)251-8618</NationalTelephoneNumber>
                            </TelephoneNumber>
                            <EmailAddress>helpdesk@agiis.org</EmailAddress>
                        </ContactInformation>
                    </PartnerInformation>
                </To>
            </Header>
            <Body>
                <AGIISProductUpdateDetails>
                    <CompanyInformation ActiveFlag = "Active">
                        <PartnerName>Monsanto Company</PartnerName>
                        <PartnerIdentifier Agency = "EBID">0062668030000</PartnerIdentifier>
                        <CompanyPrefixCode ActiveFlag = "Active">0070183</CompanyPrefixCode>
                        <CompanyPrefixCode ActiveFlag = "Active">0883580</CompanyPrefixCode>
                        {
                            for $ProductInformation in $aGIISProductExtract1/ns1:Body/ns1:AGIISProductExtractDetails/ns1:CompanyInformation[1]/ns1:ProductInformation
                            return
                                <ProductInformation ActionRequest = "{ if ((data($ProductInformation/@ActionRequest) = 'Add' or data($ProductInformation/@ActionRequest) = 'Replace')) then
                                                                           ('AddOrReplace')
                                                                       else 
                                                                           data($ProductInformation/@ActionRequest) }"
                                                    ActiveFlag = "Active">
                                    <ProductIdentification>
                                        <ProductIdentifier>{ data($ProductInformation/ns1:ProductIdentification/ns1:ProductIdentifier) }</ProductIdentifier>
                                        <ProductName>{ data($ProductInformation/ns1:ProductIdentification/ns1:ProductName) }</ProductName>
                                    </ProductIdentification>
                                    {
                                        for $BrandName in $ProductInformation/ns1:BrandName
                                        return
                                            <BrandName>{ data($BrandName) }</BrandName>
                                    }
                                    {
                                        for $ProductVariety in $ProductInformation/ns1:ProductVariety
                                        return
                                            <ProductVariety>{ data($ProductVariety) }</ProductVariety>
                                    }
                                    {
                                        for $ProductMaturity in $ProductInformation/ns1:ProductMaturity
                                        return
                                            <ProductMaturity>{ data($ProductMaturity) }</ProductMaturity>
                                    }
                                    {
                                        for $ProductTraits in $ProductInformation/ns1:ProductTraits
                                        return
                                            <ProductTraits>{ data($ProductTraits) }</ProductTraits>
                                    }
                                    {
                                        for $ProductCrop in $ProductInformation/ns1:ProductCrop
                                        return
                                            <ProductCrop>{ data($ProductCrop) }</ProductCrop>
                                    }
                                    {
                                        for $ProductTreatments in $ProductInformation/ns1:ProductTreatments
                                        return
                                            <ProductTreatments>{ data($ProductTreatments) }</ProductTreatments>
                                    }
                                    {
                                        for $EPARegistrationNumber in $ProductInformation/ns1:EPARegistrationNumber
                                        return
                                            <EPARegistrationNumber>{ data($EPARegistrationNumber) }</EPARegistrationNumber>
                                    }
                                    {
                                        for $UserDefinedField1 in $ProductInformation/ns1:UserDefinedField1
                                        return
                                            <UserDefinedField1>{ data($UserDefinedField1) }</UserDefinedField1>
                                    }
                                    {
                                        for $UserDefinedField2 in $ProductInformation/ns1:UserDefinedField2
                                        return
                                            <UserDefinedField2>{ data($UserDefinedField2) }</UserDefinedField2>
                                    }
                                    {
                                        for $UserDefinedField3 in $ProductInformation/ns1:UserDefinedField3
                                        return
                                            <UserDefinedField3>{ data($UserDefinedField3) }</UserDefinedField3>
                                    }
                                    <PrimaryProductSegmentCode>{ data($ProductInformation/ns1:PrimaryProductSegmentCode) }</PrimaryProductSegmentCode>
                                    {
                                        for $UserDefinedField1 in $ProductInformation/ns1:UserDefinedField1
                                        return
                                            let $__nullable := ( $UserDefinedField1 )
                                            return
                                                if (fn:boolean($__nullable))
                                                then
                                                    <LinkedAgreementInformation>
                                                        <AgreementIdentifier>
                                                            <PartnerIdentifier Agency = "{ if (fn:boolean("true")) then
                                                                                               ('EBID')
                                                                                           else 
                                                                                               () }">
                                                                {
                                                                    if (fn:boolean("true")) then
                                                                        ('0062668030000')
                                                                    else 
                                                                        ()
                                                                }
</PartnerIdentifier>
                                                            <AgreementCode>
                                                                {
                                                                    if (fn:boolean("true")) then
                                                                        (data($UserDefinedField1))
                                                                    else 
                                                                        ()
                                                                }
</AgreementCode>
                                                        </AgreementIdentifier>
                                                        <AgreementName>
                                                            {
                                                                if (data($UserDefinedField1) = 'MTA1') then
                                                                    ('Monsanto Technology / Stewardship Agreement - Cotton Traits')
                                                                else 
                                                                    if (data($UserDefinedField1) = 'MTA2') then
                                                                        ('Monsanto Technology / Stewardship Agreement -  all traits except Cotton')
                                                                    else 
                                                                        ()
                                                            }
</AgreementName>
                                                    </LinkedAgreementInformation>
                                                else
                                                    ()
                                    }
                                    {
                                        for $PackageSizeInformation in $ProductInformation/ns1:PackageSizeInformation
                                        return
                                            <PackageSizeInformation ActionRequest = "{ if ((data($PackageSizeInformation/@ActionRequest) = 'Add' or data($PackageSizeInformation/@ActionRequest) = 'Replace')) then
                                                                                           ('AddOrReplace')
                                                                                       else 
                                                                                           data($PackageSizeInformation/@ActionRequest) }"
                                                                    ActiveFlag = "Active">
                                                <CompanyPrefixCode>{ data($PackageSizeInformation/ns1:CompanyPrefixCode) }</CompanyPrefixCode>
                                                <PackageSizeCode>{ data($PackageSizeInformation/ns1:PackageSizeCode) }</PackageSizeCode>
                                                <PackageSizeName>{ data($PackageSizeInformation/ns1:PackageSizeName) }</PackageSizeName>
                                                {
                                                    let $__nullable := ( data($PackageSizeInformation/ns1:ShortDescription) )
                                                    return
                                                        if (fn:boolean($__nullable))
                                                        then
                                                            <ShortDescription>{ $__nullable }</ShortDescription>
                                                        else
                                                            ()
                                                }
                                                <BaseQuantity>
                                                    <Measurement>
                                                        <MeasurementValue>
                                                            {
                                                                if (data($ProductInformation/ns1:PrimaryProductSegmentCode) = 'Seed') then
                                                                    if (fn:boolean("true")) then
                                                                        (xs:decimal( data($PackageSizeInformation/ns1:PackageConfigurationInformation[1]/ns1:UserDefinedField2) ))
                                                                    else 
                                                                        ()
                                                                else 
                                                                    data($PackageSizeInformation/ns1:BaseQuantity/ns1:Measurement/ns1:MeasurementValue)
                                                            }
</MeasurementValue>
                                                        <UnitOfMeasureCode Domain = "UN REC 20">
                                                            {
                                                                if (data($ProductInformation/ns1:PrimaryProductSegmentCode) = 'Seed') then
                                                                    ("UN")
                                                                else 
                                                                    data($PackageSizeInformation/ns1:BaseQuantity/ns1:Measurement/ns1:UnitOfMeasureCode)
                                                            }
</UnitOfMeasureCode>
                                                    </Measurement>
                                                </BaseQuantity>
                                                <PackageUnitOfMeasureCode Domain = "UN REC 20">
                                                    {
                                                        if (data($ProductInformation/ns1:PrimaryProductSegmentCode) = 'Seed') then
                                                            ("BG")
                                                        else 
                                                            data($PackageSizeInformation/ns1:PackageUnitOfMeasureCode)
                                                    }
</PackageUnitOfMeasureCode>
                                                {
                                                    for $ReportingUnitOfMeasureCode in $PackageSizeInformation/ns1:ReportingUnitOfMeasureCode
                                                    return
                                                        <ReportingUnitOfMeasureCode Domain = "UN REC 20">
                                                            {
                                                                if ((data($ReportingUnitOfMeasureCode) = 'SS' or data($ReportingUnitOfMeasureCode) = 'US')) then
                                                                    ('UN')
                                                                else 
                                                                    data($ReportingUnitOfMeasureCode)
                                                            }
</ReportingUnitOfMeasureCode>
                                                }
                                                {
                                                    for $SeedSize in $PackageSizeInformation/ns1:SeedSize
                                                    return
                                                        <SeedSize>{ data($SeedSize) }</SeedSize>
                                                }
                                                {
                                                    for $UserDefinedField1 in $PackageSizeInformation/ns1:UserDefinedField1
                                                    return
                                                        <UserDefinedField1>{ data($UserDefinedField1) }</UserDefinedField1>
                                                }
                                                {
                                                    for $UserDefinedField2 in $PackageSizeInformation/ns1:UserDefinedField2
                                                    return
                                                        <UserDefinedField2>{ data($UserDefinedField2) }</UserDefinedField2>
                                                }
                                                {
                                                    for $UserDefinedField3 in $PackageSizeInformation/ns1:UserDefinedField3
                                                    return
                                                        <UserDefinedField3>{ data($UserDefinedField3) }</UserDefinedField3>
                                                }
                                                {
                                                    for $PackageConfigurationInformation in $PackageSizeInformation/ns1:PackageConfigurationInformation
                                                    return
                                                        <PackageConfigurationInformation ActionRequest = "{ if ((data($PackageConfigurationInformation/@ActionRequest) = 'Add' or data($PackageConfigurationInformation/@ActionRequest) = 'Replace')) then
                                                                                                                ("AddOrReplace")
                                                                                                            else 
                                                                                                                data($PackageConfigurationInformation/@ActionRequest) }"
                                                                                         ActiveFlag = "Active">
                                                            {
                                                                for $PackageLevelCode in $PackageConfigurationInformation/ns1:PackageLevelCode
                                                                return
                                                                    <PackageLevelCode>{ data($PackageLevelCode) }</PackageLevelCode>
                                                            }
                                                            {
                                                                for $CompanyPrefixCode in $PackageConfigurationInformation/ns1:CompanyPrefixCode
                                                                return
                                                                    <CompanyPrefixCode>{ data($CompanyPrefixCode) }</CompanyPrefixCode>
                                                            }
                                                            {
                                                                for $PackageSizeCode in $PackageConfigurationInformation/ns1:PackageSizeCode
                                                                return
                                                                    <PackageSizeCode>{ data($PackageSizeCode) }</PackageSizeCode>
                                                            }
                                                            {
                                                                for $CheckDigit in $PackageConfigurationInformation/ns1:CheckDigit
                                                                return
                                                                    <CheckDigit>{ data($CheckDigit) }</CheckDigit>
                                                            }
                                                            {
                                                                for $GTIN in $PackageConfigurationInformation/ns1:GTIN
                                                                return
                                                                    let $__nullable := ( if (data($ProductInformation/ns1:PrimaryProductSegmentCode) != 'Seed') then
                                                                                             (data($GTIN))
                                                                                         else 
                                                                                             () )
                                                                    return
                                                                        if (fn:boolean($__nullable))
                                                                        then
                                                                            <GTIN>{ $__nullable }</GTIN>
                                                                        else
                                                                            ()
                                                            }
                                                            {
                                                                for $PackageUnitOfMeasureCode in $PackageConfigurationInformation/ns1:PackageUnitOfMeasureCode
                                                                return
                                                                    <PackageUnitOfMeasureCode Domain = "UN REC 20">
                                                                        {
                                                                            if ((data($PackageUnitOfMeasureCode) = 'SS' or data($PackageUnitOfMeasureCode) = 'US')) then
                                                                                ('UN')
                                                                            else 
                                                                                data($PackageUnitOfMeasureCode)
                                                                        }
</PackageUnitOfMeasureCode>
                                                            }
                                                            {
                                                                for $ReportingIdentifier in $PackageConfigurationInformation/ns1:ReportingIdentifier
                                                                return
                                                                    <ReportingIdentifier>{ data($ReportingIdentifier) }</ReportingIdentifier>
                                                            }
                                                            <BasePackageQuantity>
                                                                <Measurement>
                                                                    <MeasurementValue>{ data($PackageConfigurationInformation/ns1:BasePackageQuantity/ns1:Measurement/ns1:MeasurementValue) }</MeasurementValue>
                                                                    <UnitOfMeasureCode Domain = "UN REC 20">
                                                                        {
                                                                            if ((data($PackageConfigurationInformation/ns1:BasePackageQuantity/ns1:Measurement/ns1:UnitOfMeasureCode) = 'SS' or data($PackageConfigurationInformation/ns1:BasePackageQuantity/ns1:Measurement/ns1:UnitOfMeasureCode) = 'US')) then
                                                                                ('UN')
                                                                            else 
                                                                                data($PackageConfigurationInformation/ns1:BasePackageQuantity/ns1:Measurement/ns1:UnitOfMeasureCode)
                                                                        }
</UnitOfMeasureCode>
                                                                </Measurement>
                                                            </BasePackageQuantity>
                                                            {
                                                                for $CalculatedVolumeQuantity in $PackageConfigurationInformation/ns1:CalculatedVolumeQuantity
                                                                return
                                                                    <CalculatedVolumeQuantity>{ data($CalculatedVolumeQuantity) }</CalculatedVolumeQuantity>
                                                            }
                                                            {
                                                                for $WeightGross in $PackageConfigurationInformation/ns1:WeightGross
                                                                return
                                                                    <WeightGross>{ data($WeightGross) }</WeightGross>
                                                            }
                                                            {
                                                                for $WeightTare in $PackageConfigurationInformation/ns1:WeightTare
                                                                return
                                                                    <WeightTare>{ data($WeightTare) }</WeightTare>
                                                            }
                                                            {
                                                                for $WeightNet in $PackageConfigurationInformation/ns1:WeightNet
                                                                return
                                                                    <WeightNet>{ data($WeightNet) }</WeightNet>
                                                            }
                                                            {
                                                                for $WeightUnitOfMeasureCode in $PackageConfigurationInformation/ns1:WeightUnitOfMeasureCode
                                                                return
                                                                    <WeightUnitOfMeasureCode Domain = "UN REC 20">
                                                                        {
                                                                            if ((data($WeightUnitOfMeasureCode) = 'SS' or data($WeightUnitOfMeasureCode) = 'US')) then
                                                                                ('UN')
                                                                            else 
                                                                                data($WeightUnitOfMeasureCode)
                                                                        }
</WeightUnitOfMeasureCode>
                                                            }
                                                            {
                                                                for $DimensionLength in $PackageConfigurationInformation/ns1:DimensionLength
                                                                return
                                                                    <DimensionLength>{ data($DimensionLength) }</DimensionLength>
                                                            }
                                                            {
                                                                for $DimensionWidth in $PackageConfigurationInformation/ns1:DimensionWidth
                                                                return
                                                                    <DimensionWidth>{ data($DimensionWidth) }</DimensionWidth>
                                                            }
                                                            {
                                                                for $DimensionHeight in $PackageConfigurationInformation/ns1:DimensionHeight
                                                                return
                                                                    <DimensionHeight>{ data($DimensionHeight) }</DimensionHeight>
                                                            }
                                                            {
                                                                for $DimensionUnitOfMeasureCode in $PackageConfigurationInformation/ns1:DimensionUnitOfMeasureCode
                                                                return
                                                                    <DimensionUnitOfMeasureCode Domain = "UN REC 20">
                                                                        {
                                                                            if ((data($DimensionUnitOfMeasureCode) = 'SS' or data($DimensionUnitOfMeasureCode) = 'US')) then
                                                                                ('UN')
                                                                            else 
                                                                                data($DimensionUnitOfMeasureCode)
                                                                        }
</DimensionUnitOfMeasureCode>
                                                            }
                                                            <SquareArea>
                                                                <Measurement>
                                                                    <MeasurementValue>{ data($PackageConfigurationInformation/ns1:SquareArea/ns1:Measurement/ns1:MeasurementValue) }</MeasurementValue>
                                                                    <UnitOfMeasureCode Domain = "UN REC 20">
                                                                        {
                                                                            if ((data($PackageConfigurationInformation/ns1:SquareArea/ns1:Measurement/ns1:UnitOfMeasureCode) = 'SS' or data($PackageConfigurationInformation/ns1:SquareArea/ns1:Measurement/ns1:UnitOfMeasureCode) = 'US')) then
                                                                                ('UN')
                                                                            else 
                                                                                data($PackageConfigurationInformation/ns1:SquareArea/ns1:Measurement/ns1:UnitOfMeasureCode)
                                                                        }
</UnitOfMeasureCode>
                                                                </Measurement>
                                                            </SquareArea>
                                                            <CubicDimension>
                                                                <Measurement>
                                                                    <MeasurementValue>{ data($PackageConfigurationInformation/ns1:CubicDimension/ns1:Measurement/ns1:MeasurementValue) }</MeasurementValue>
                                                                    <UnitOfMeasureCode Domain = "UN REC 20">
                                                                        {
                                                                            if ((data($PackageConfigurationInformation/ns1:CubicDimension/ns1:Measurement/ns1:UnitOfMeasureCode) = 'SS' or data($PackageConfigurationInformation/ns1:CubicDimension/ns1:Measurement/ns1:UnitOfMeasureCode) = 'US')) then
                                                                                ('UN')
                                                                            else 
                                                                                data($PackageConfigurationInformation/ns1:CubicDimension/ns1:Measurement/ns1:UnitOfMeasureCode)
                                                                        }
</UnitOfMeasureCode>
                                                                </Measurement>
                                                            </CubicDimension>
                                                            {
                                                                for $StackingHeight in $PackageConfigurationInformation/ns1:StackingHeight
                                                                return
                                                                    <StackingHeight>{ data($StackingHeight) }</StackingHeight>
                                                            }
                                                            {
                                                                for $UserDefinedField2 in $PackageConfigurationInformation/ns1:UserDefinedField2
                                                                return
                                                                    <UserDefinedField1>{ data($UserDefinedField2) }</UserDefinedField1>
                                                            }
                                                            {
                                                                for $UserDefinedField2 in $ProductInformation/ns1:UserDefinedField2
                                                                return
                                                                    <UserDefinedField2>{ data($UserDefinedField2) }</UserDefinedField2>
                                                            }
                                                        </PackageConfigurationInformation>
                                                }
                                            </PackageSizeInformation>
                                    }
                                </ProductInformation>
                        }
                    </CompanyInformation>
                </AGIISProductUpdateDetails>
            </Body>
        </AGIISProductUpdate>
};

declare variable $aGIISProductExtract1 as element(ns1:AGIISProductExtract) external;

xf:ProductList($aGIISProductExtract1)