(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstDlrlookupResponse" location="../WSDLs/DealerLookup_ECC.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:DealerLookupResponse" location="../Schemas/DealerLookup.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerLookup";
declare namespace xf = "http://tempuri.org/ECC_US_ElectronicStockTransfer_DealerLookup/XQueryResources/DealerLookupResponse/";

declare function xf:DealerLookupResponse($response as element(ns2:YSdsaUsseedEstDlrlookupResponse))
    as element(ns0:DealerLookupResponse) {
        <ns0:DealerLookupResponse Version="1.0">
            <ns0:DealerLookupResponseBody>
                {
                    for $item in $response/TDealerList/item
                    return
                        <ns0:DealerInformation>
                            <ns0:DealerEntity>
                                <ns0:PartnerIdentifier Type = "{ data($item/Yyreqtyp) }">{ data($item/Yykunnr) }</ns0:PartnerIdentifier>
                                <ns0:PartnerName>{ data($item/Yyname1) }</ns0:PartnerName>
                            </ns0:DealerEntity>
                            <ns0:AddressInformation>
                                <ns0:AddressLine>{ data($item/Yystreet) }</ns0:AddressLine>
                                <ns0:CityName>{ data($item/Yycity1) }</ns0:CityName>
                                <ns0:State>{ data($item/Yyregion) }</ns0:State>
                                <ns0:PostalCode>{ data($item/YypostCode1) }</ns0:PostalCode>
                            </ns0:AddressInformation>
                            <ns0:PhoneNumber>{ data($item/YytelNumber) }</ns0:PhoneNumber>
                            <ns0:IBSDIndicator>{ data($item/Yyibsd) }</ns0:IBSDIndicator>
                            <ns0:PORequiredIndicator>{ data($item/Yypoflag) }</ns0:PORequiredIndicator>
                        </ns0:DealerInformation>
                }
            </ns0:DealerLookupResponseBody>           
            {
            if(data($response/TError/item[1]/Type)!='')then (
            <ns0:DealerLookupResponseError>
                <ns0:ErrorType>{ 
                
                	  if (data($response/TError/item[1]/Type) = "S") then
                            ("Success")
                        else 
                            if (data($response/TError/item[1]/Type) = "E") then
                                ("Error")
                            else 
                                if (data($response/TError/item[1]/Type) = "W") then
                                    ("Warning")
                                else 
                                    if (data($response/TError/item[1]/Type) = "I") then
                                        ("Info")
                                    else 
                                        if (data($response/TError/item[1]/Type) = "A") then
                                            ("Abort")
                                        else 
                                            ()
                	
                	}                                
                </ns0:ErrorType>
                <ns0:ErrorMessageClass>{ data($response/TError/item[1]/Id) }</ns0:ErrorMessageClass>
                {
                if(data($response/TError/item[1]/Number)!='')then(
                <ns0:ErrorMessageNumber>{ xs:integer( data($response/TError/item[1]/Number) ) }</ns0:ErrorMessageNumber>
                )else()
                }
                <ns0:ErrorMessageObject>{ data($response/TError/item[1]/MsgObject) }</ns0:ErrorMessageObject>
                <ns0:ErrorMessageText>{ data($response/TError/item[1]/ErrDesc) }</ns0:ErrorMessageText>
                <ns0:ErrorMessageDisplayText>{ data($response/TError/item[1]/ErrDescDisp) }</ns0:ErrorMessageDisplayText>
            </ns0:DealerLookupResponseError>
           )else()
           }
        </ns0:DealerLookupResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstDlrlookupResponse) external;

xf:DealerLookupResponse($response)