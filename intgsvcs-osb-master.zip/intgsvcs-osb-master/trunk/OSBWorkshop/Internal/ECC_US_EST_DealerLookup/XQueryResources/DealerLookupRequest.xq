(:: pragma bea:global-element-parameter parameter="$request" element="ns0:DealerLookupRequest" location="../Schemas/DealerLookup.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstDlrlookup" location="../WSDLs/DealerLookup_ECC.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerLookup";
declare namespace xf = "http://tempuri.org/ECC_US_ElectronicStockTransfer_DealerLookup/XQueryResources/DealerLookupRequest/";

declare function xf:DealerLookupRequest($request as element(ns0:DealerLookupRequest))
    as element(ns2:YSdsaUsseedEstDlrlookup) {
        <ns2:YSdsaUsseedEstDlrlookup>
            {
                for $CityName in $request/ns0:DealerLookupRequestBody/ns0:AddressInformation/ns0:CityName
                return
                    <ICity>{ data($CityName) }</ICity>
            }
            {
                let $result :=
                    for $PartnerIdentifier in $request/ns0:DealerLookupRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier
                    return
                        <IKunnr>{ data($PartnerIdentifier) }</IKunnr>
                return
                    $result[1]
            }
            {
                for $PartnerName in $request/ns0:DealerLookupRequestBody/ns0:DealerEntity/ns0:PartnerName
                return
                    <IName>{ data($PartnerName) }</IName>
            }
            {
                for $AgreementType in $request/ns0:DealerLookupRequestBody/ns0:AgreementType
                return
                    <IReqtyp>{ data($AgreementType) }</IReqtyp>
            }
            {
                for $Region in $request/ns0:DealerLookupRequestBody/ns0:Region
                return
                    <ISalesArea>{ data($Region) }</ISalesArea>
            }
            {
                for $State in $request/ns0:DealerLookupRequestBody/ns0:AddressInformation/ns0:State
                return
                    <IState>{ data($State) }</IState>
            }
            {
                for $PhoneNumber in $request/ns0:DealerLookupRequestBody/ns0:PhoneNumber
                return
                    <ITelno>{ data($PhoneNumber) }</ITelno>
            }
            {
                for $PostalCode in $request/ns0:DealerLookupRequestBody/ns0:AddressInformation/ns0:PostalCode
                return
                    <IZip>{ data($PostalCode) }</IZip>
            }
        </ns2:YSdsaUsseedEstDlrlookup>
};

declare variable $request as element(ns0:DealerLookupRequest) external;

xf:DealerLookupRequest($request)
