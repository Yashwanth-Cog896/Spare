(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YlasPyGenSoGbToSapResponse" location="../WSDLs/YES_YLAS_PY_GEN_SO_GB_TO_SAP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyGenSoGbToSapResponse" location="../WSDLs/YES_YLAS_PY_GEN_SO_GB_TO_SAP_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GenResponse/";

declare function xf:GenResponse($response as element(ns0:YlasPyGenSoGbToSapResponse))
    as element(ns0:YlasPyGenSoGbToSapResponse) {
        <ns0:YlasPyGenSoGbToSapResponse>
            <EpIdTransaction>{ data($response/EpIdTransaction) }</EpIdTransaction>
            <EpResult>{ data($response/EpResult) }</EpResult>
        </ns0:YlasPyGenSoGbToSapResponse>
};

declare variable $response as element(ns0:YlasPyGenSoGbToSapResponse) external;

xf:GenResponse($response)