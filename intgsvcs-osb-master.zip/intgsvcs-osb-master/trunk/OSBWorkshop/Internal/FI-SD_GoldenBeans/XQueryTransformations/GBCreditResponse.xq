(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YFiarGbcreditResponse" location="../WSDLs/yes_y_fiar_gbcredit.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YFiarGbcreditResponse" location="../WSDLs/yes_y_fiar_gbcredit_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GBCreditResponse/";

declare function xf:GBCreditResponse($response as element(ns0:YFiarGbcreditResponse))
    as element(ns0:YFiarGbcreditResponse) {
        <ns0:YFiarGbcreditResponse>
            <EMessage>{ data($response/EMessage) }</EMessage>
            <EtFidocuments>{ $response/EtFidocuments/@* , $response/EtFidocuments/node() }</EtFidocuments>
        </ns0:YFiarGbcreditResponse>
};

declare variable $response as element(ns0:YFiarGbcreditResponse) external;

xf:GBCreditResponse($response)