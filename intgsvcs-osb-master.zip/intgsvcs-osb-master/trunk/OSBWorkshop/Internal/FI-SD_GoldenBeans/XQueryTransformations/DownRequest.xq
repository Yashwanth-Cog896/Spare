(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YlasPyDownInvSapToGb" location="../WSDLs/YES_YLAS_PY_DOWN_INV_SAP_TO_GB_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyDownInvSapToGb" location="../WSDLs/YES_YLAS_PY_DOWN_INV_SAP_TO_GB.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/DownRequest/";

declare function xf:DownRequest($request as element(ns0:YlasPyDownInvSapToGb))
    as element(ns0:YlasPyDownInvSapToGb) {
        <ns0:YlasPyDownInvSapToGb>
            {
                for $EtYlaspyGldnBns in $request/EtYlaspyGldnBns
                return
                    <EtYlaspyGldnBns>{ $EtYlaspyGldnBns/@* , $EtYlaspyGldnBns/node() }</EtYlaspyGldnBns>
            }
            <IpBillingDate>{ data($request/IpBillingDate) }</IpBillingDate>
            <IpBillingDocument>{ data($request/IpBillingDocument) }</IpBillingDocument>
            <IpBillingType>{ data($request/IpBillingType) }</IpBillingType>
            <IpIncludeInvoicesSent>{ data($request/IpIncludeInvoicesSent) }</IpIncludeInvoicesSent>
            <IpMaterial>{ data($request/IpMaterial) }</IpMaterial>
            <IpPayer>{ data($request/IpPayer) }</IpPayer>
            <IpReference>{ data($request/IpReference) }</IpReference>
            <IpServiceType>{ data($request/IpServiceType) }</IpServiceType>
        </ns0:YlasPyDownInvSapToGb>
};

declare variable $request as element(ns0:YlasPyDownInvSapToGb) external;

xf:DownRequest($request)