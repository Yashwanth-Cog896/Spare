(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YlasPyGbcollectResponse" location="../WSDLs/yes_ylas_py_gbcollect.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyGbcollectResponse" location="../WSDLs/yes_ylas_py_gbcollect_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GBCollectResponse/";

declare function xf:GBCollectResponse($response as element(ns0:YlasPyGbcollectResponse))
    as element(ns0:YlasPyGbcollectResponse) {
        <ns0:YlasPyGbcollectResponse>
            <EMessage>{ data($response/EMessage) }</EMessage>
            <EtCollections>{ $response/EtCollections/@* , $response/EtCollections/node() }</EtCollections>
        </ns0:YlasPyGbcollectResponse>
};

declare variable $response as element(ns0:YlasPyGbcollectResponse) external;

xf:GBCollectResponse($response)