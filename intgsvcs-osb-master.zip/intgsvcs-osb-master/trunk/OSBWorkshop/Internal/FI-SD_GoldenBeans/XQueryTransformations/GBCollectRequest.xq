(:: pragma bea:global-element-parameter parameter="$request" element="ns0:YlasPyGbcollect" location="../WSDLs/yes_ylas_py_gbcollect_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YlasPyGbcollect" location="../WSDLs/yes_ylas_py_gbcollect.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD-AR_GoldenBeans/XQueryTransformations/GBCollectRequest/";

declare function xf:GBCollectRequest($request as element(ns0:YlasPyGbcollect))
    as element(ns0:YlasPyGbcollect) {
        <ns0:YlasPyGbcollect>
            {
                for $IBelnr in $request/IBelnr
                return
                    <IBelnr>{ data($IBelnr) }</IBelnr>
            }
            {
                for $IBudatF in $request/IBudatF
                return
                    <IBudatF>{ data($IBudatF) }</IBudatF>
            }
            {
                for $IBudatT in $request/IBudatT
                return
                    <IBudatT>{ data($IBudatT) }</IBudatT>
            }
            {
                for $IBukrs in $request/IBukrs
                return
                    <IBukrs>{ data($IBukrs) }</IBukrs>
            }
            {
                for $IDocsenv in $request/IDocsenv
                return
                    <IDocsenv>{ data($IDocsenv) }</IDocsenv>
            }
            {
                for $IGjahr in $request/IGjahr
                return
                    <IGjahr>{ data($IGjahr) }</IGjahr>
            }
            {
                for $IGsber in $request/IGsber
                return
                    <IGsber>{ data($IGsber) }</IGsber>
            }
            {
                for $IKunnr in $request/IKunnr
                return
                    <IKunnr>{ data($IKunnr) }</IKunnr>
            }
            {
                for $IRev in $request/IRev
                return
                    <IRev>{ data($IRev) }</IRev>
            }
            <ItBlart>
                {
                    for $item in $request/ItBlart/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItBlart>
            <ItXblnr>
                {
                    for $item in $request/ItXblnr/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </ItXblnr>
        </ns0:YlasPyGbcollect>
};

declare variable $request as element(ns0:YlasPyGbcollect) external;

xf:GBCollectRequest($request)