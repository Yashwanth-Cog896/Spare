declare namespace mongateway = "urn:mongateway:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";

declare function mongateway:formatMonGatewayFaultMessageNotValid 
  ( $faultstringText as xs:string? )  as node() {


    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:monGateway="urn:mongateway:errors">',
      'mongateway:InvalidLookUp',
      '</faultcode>',
      '<faultstring>', 
	  $faultstringText,
	   '</faultstring>', 
      '</soapenv:Fault>'))
           

 } ;

declare variable $faultstringText as xs:string? external;

mongateway:formatMonGatewayFaultMessageNotValid($faultstringText)