declare namespace mongateway = "urn:mongateway:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";

declare function mongateway:formatMonGatewayFaultHeaderNotValid 
  ( $fault as node() )  as node() {

    let $faultcodeElement := fn-bea:inlinedXML(fn:concat(
      '<faultcode xmlns:mongateway="urn:mongateway:schema:errors:1:0">',
      'mongateway:HeaderNotValid',
      '</faultcode>'))

    let $soapFault :=
    element { xs:QName("soapenv:Fault") }
      { $faultcodeElement,
         element { "faultstring" } {"Schema validation errors in Request, please see body of this message for details and make sure there is not missing information Routing Element"},
         element { "details" } {$fault}
      }

    return $soapFault
 } ;

declare variable $fault as node() external;

mongateway:formatMonGatewayFaultHeaderNotValid($fault)