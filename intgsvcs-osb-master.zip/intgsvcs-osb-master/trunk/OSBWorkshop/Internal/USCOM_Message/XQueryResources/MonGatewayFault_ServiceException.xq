declare namespace mongateway = "urn:mongateway:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";

declare function mongateway:formatMonGatewayFaultMessageNotValid 
    ( $serviceInfo as xs:string?, $fault as node() )  as node() {


    let $faultcodeElement := fn-bea:inlinedXML(fn:concat(
      '<faultcode xmlns:mongateway="urn:mongateway:schema:errors:1:0">',
      'mongateway:HeaderNotValid',
      '</faultcode>'))

    let $soapFault :=
    element { xs:QName("soapenv:Fault") }
      { $faultcodeElement,
         element { "faultstring" } {$serviceInfo},
         element { "details" } {$fault}
      }

    return $soapFault
 } ;

declare variable $fault as node() external;
declare variable $serviceInfo  as xs:string? external;

mongateway:formatMonGatewayFaultMessageNotValid( $serviceInfo , $fault )