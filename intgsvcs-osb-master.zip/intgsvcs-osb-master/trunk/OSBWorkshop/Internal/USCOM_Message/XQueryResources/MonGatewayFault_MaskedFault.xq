declare namespace mongateway = "urn:mongateway:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";


declare function mongateway:formatMonGatewayFaultServiceException
( $serviceInfo as xs:string? )  as node() {


    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:mongateway="urn:mongateway:schema:errors">',
      'mongateway:ServiceException',
      '</faultcode>',
      '<faultstring>', 
      'An error occurred processing the request to ', $serviceInfo, 
      '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $serviceInfo as xs:string? external;

mongateway:formatMonGatewayFaultServiceException($serviceInfo)