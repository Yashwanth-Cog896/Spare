(:: pragma bea:global-element-parameter parameter="$orderResponse" element="OrderResponse" location="../WSDLs/SI_OSB_OrderResponseOB_A_IN.wsdl" ::)
(:: pragma bea:global-element-return element="OrderResponse" location="../WSDLs/SI_OSB_OrderResponseOB_A_IN.wsdl" ::)

declare namespace xf = "http://tempuri.org/USCOM_ChemOrders/XQueryTransformations/OrderCreateResponse/";

declare function xf:OrderCreateResponse($orderResponse as element(OrderResponse))
    as element(OrderResponse) {
        let $OrderResponse := $orderResponse
        return
            <OrderResponse Version = "{ data($OrderResponse/@Version) }">
                <Header>{ $OrderResponse/Header/@* , $OrderResponse/Header/node() }</Header>
                <OrderResponseBody>
                    <OrderResponseProperties>{ $OrderResponse/OrderResponseBody/OrderResponseProperties/@* , $OrderResponse/OrderResponseBody/OrderResponseProperties/node() }</OrderResponseProperties>
                    <OrderResponsePartners>{ $OrderResponse/OrderResponseBody/OrderResponsePartners/@* , $OrderResponse/OrderResponseBody/OrderResponsePartners/node() }</OrderResponsePartners>
                    <OrderResponseDetails>
                        {
                            for $OrderResponseProductLineItem in $OrderResponse/OrderResponseBody/OrderResponseDetails/OrderResponseProductLineItem
                            return
                                <OrderResponseProductLineItem>
                                    <LineNumber>{ data($OrderResponseProductLineItem/LineNumber) }</LineNumber>
                                    {
                                        for $LineItemType in $OrderResponseProductLineItem/LineItemType
                                        return
                                            <LineItemType>{ data($LineItemType) }</LineItemType>
                                    }
                                    <PurchaseOrderLineItemNumber>{ data($OrderResponseProductLineItem/PurchaseOrderLineItemNumber) }</PurchaseOrderLineItemNumber>
                                    {
                                        for $ReleaseNumber in $OrderResponseProductLineItem/ReleaseNumber
                                        return
                                            <ReleaseNumber>{ data($ReleaseNumber) }</ReleaseNumber>
                                    }
                                    {
                                        for $ProductIdentification in $OrderResponseProductLineItem/ProductIdentification
                                        return
                                            <ProductIdentification>{ $ProductIdentification/@* , $ProductIdentification/node() }</ProductIdentification>
                                    }
                                    {
                                        for $ReferenceInformation in $OrderResponseProductLineItem/ReferenceInformation
                                        return
                                            <ReferenceInformation>{ $ReferenceInformation/@* , $ReferenceInformation/node() }</ReferenceInformation>
                                    }
                                    {
                                        for $SalesOrderIdentifier in $OrderResponseProductLineItem/SalesOrderIdentifier
                                        return
                                            <SalesOrderIdentifier>{ $SalesOrderIdentifier/@* , $SalesOrderIdentifier/node() }</SalesOrderIdentifier>
                                    }
                                    <ProductQuantity>{ $OrderResponseProductLineItem/ProductQuantity/@* , $OrderResponseProductLineItem/ProductQuantity/node() }</ProductQuantity>
                                    {
                                        for $PackagingQuantity in $OrderResponseProductLineItem/PackagingQuantity
                                        return
                                            <PackagingQuantity>{ $PackagingQuantity/@* , $PackagingQuantity/node() }</PackagingQuantity>
                                    }
                                    {
                                        for $BatchNumber in $OrderResponseProductLineItem/BatchNumber
                                        return
                                            <BatchNumber>{  $BatchNumber/@* , $BatchNumber/node() }</BatchNumber>
                                    }
                                    {
                                        for $CountryOfOriginCode in $OrderResponseProductLineItem/CountryOfOriginCode
                                        return
                                            <CountryOfOriginCode>{  $CountryOfOriginCode/@* , $CountryOfOriginCode/node() }</CountryOfOriginCode>
                                    }
                                    {
                                        for $ShipTo in $OrderResponseProductLineItem/ShipTo
                                        return
                                            <ShipTo>{ $ShipTo/@* , $ShipTo/node() }</ShipTo>
                                    }
                                    {
                                        for $OtherPartner in $OrderResponseProductLineItem/OtherPartner
                                        return
                                            <OtherPartner>{ $OtherPartner/@* , $OtherPartner/node() }</OtherPartner>
                                    }
                                    {
                                        for $DeliveryTolerances in $OrderResponseProductLineItem/DeliveryTolerances
                                        return
                                            <DeliveryTolerances>{ $DeliveryTolerances/@* , $DeliveryTolerances/node() }</DeliveryTolerances>
                                    }
                                    {
                                        for $ShipmentTerms in $OrderResponseProductLineItem/ShipmentTerms
                                        return
                                            <ShipmentTerms>{ $ShipmentTerms/@* , $ShipmentTerms/node() }</ShipmentTerms>
                                    }
                                    {
                                        for $TransportInformation in $OrderResponseProductLineItem/TransportInformation
                                        return
                                            <TransportInformation>{ $TransportInformation/@* , $TransportInformation/node() }</TransportInformation>
                                    }
                                    {
                                        for $ConfirmedPrice in $OrderResponseProductLineItem/ConfirmedPrice
                                        return
                                            <ConfirmedPrice>{ $ConfirmedPrice/@* , $ConfirmedPrice/node() }</ConfirmedPrice>
                                    }
                                    {
                                        for $PaymentTerms in $OrderResponseProductLineItem/PaymentTerms
                                        return
                                            <PaymentTerms>{ $PaymentTerms/@* , $PaymentTerms/node() }</PaymentTerms>
                                    }
                                    {
                                        for $TaxableFlag in $OrderResponseProductLineItem/TaxableFlag
                                        return
                                            <TaxableFlag>{ data($TaxableFlag) }</TaxableFlag>
                                    }
                                    {
                                        for $RequestedDocument in $OrderResponseProductLineItem/RequestedDocument
                                        return
                                            <RequestedDocument>{ $RequestedDocument/@* , $RequestedDocument/node() }</RequestedDocument>
                                    }
                                    {
                                        for $Routing in $OrderResponseProductLineItem/Routing
                                        return
                                            <Routing>{ data($Routing) }</Routing>
                                    }
                                    {
                                        for $BalanceItemFlag in $OrderResponseProductLineItem/BalanceItemFlag
                                        return
                                            <BalanceItemFlag>{ data($BalanceItemFlag) }</BalanceItemFlag>
                                    }
                                    {
                                        for $DutyStatus in $OrderResponseProductLineItem/DutyStatus
                                        return
                                            <DutyStatus>{ data($DutyStatus) }</DutyStatus>
                                    }
                                    {
                                        for $ImportLicenseNeededFlag in $OrderResponseProductLineItem/ImportLicenseNeededFlag
                                        return
                                            <ImportLicenseNeededFlag>{ data($ImportLicenseNeededFlag) }</ImportLicenseNeededFlag>
                                    }
                                    {
                                        for $ImportLicenseAvailableFlag in $OrderResponseProductLineItem/ImportLicenseAvailableFlag
                                        return
                                            <ImportLicenseAvailableFlag>{ data($ImportLicenseAvailableFlag) }</ImportLicenseAvailableFlag>
                                    }
                                    {
                                        for $SecondWeightFlag in $OrderResponseProductLineItem/SecondWeightFlag
                                        return
                                            <SecondWeightFlag>{ data($SecondWeightFlag) }</SecondWeightFlag>
                                    }
                                    {
                                        for $CustomerRequestedDeliveryHoldFlag in $OrderResponseProductLineItem/CustomerRequestedDeliveryHoldFlag
                                        return
                                            <CustomerRequestedDeliveryHoldFlag>{ data($CustomerRequestedDeliveryHoldFlag) }</CustomerRequestedDeliveryHoldFlag>
                                    }
                                    {
                                        for $AccompanyingSampleIndicator in $OrderResponseProductLineItem/AccompanyingSampleIndicator
                                        return
                                            <AccompanyingSampleIndicator>{ data($AccompanyingSampleIndicator) }</AccompanyingSampleIndicator>
                                    }
                                    {
                                        for $SpecialFulfillmentRequestCode in $OrderResponseProductLineItem/SpecialFulfillmentRequestCode
                                        return
                                            <SpecialFulfillmentRequestCode>{ $SpecialFulfillmentRequestCode/@* , $SpecialFulfillmentRequestCode/node() }</SpecialFulfillmentRequestCode>
                                    }
                                    {
                                        for $CountryOfFinalDestinationCode in $OrderResponseProductLineItem/CountryOfFinalDestinationCode
                                        return
                                            <CountryOfFinalDestinationCode>{ $CountryOfFinalDestinationCode/@* , $CountryOfFinalDestinationCode/node() }</CountryOfFinalDestinationCode>
                                    }
                                    {
                                        for $DeliveryGroup in $OrderResponseProductLineItem/DeliveryGroup
                                        return
                                            <DeliveryGroup>{ data($DeliveryGroup) }</DeliveryGroup>
                                    }
                                    {
                                        for $SpecialInstructions in $OrderResponseProductLineItem/SpecialInstructions
                                        return
                                            <SpecialInstructions>{ $SpecialInstructions/@* , $SpecialInstructions/node()  }</SpecialInstructions>
                                            
                                    }
									<ResponseStatus>
										<ResponseStatusReasonIdentifier Agency="ResponseCode">{$OrderResponseProductLineItem/SpecialInstructions[1]/text()}</ResponseStatusReasonIdentifier>
										<ResponseStatusReasonDescription>{$OrderResponseProductLineItem/SpecialInstructions[2]/text()}</ResponseStatusReasonDescription>
									</ResponseStatus>
                                    
                                    {
                                        for $LineStatus in $OrderResponseProductLineItem/LineStatus
                                        return
                                            <LineStatus>{ fn:concat(fn:substring(data($LineStatus),1,1),fn:lower-case(fn:substring(data($LineStatus),2)))  }</LineStatus>
                                    }
                                </OrderResponseProductLineItem>
                        }
                    </OrderResponseDetails>
                </OrderResponseBody>
            </OrderResponse>
};

declare variable $orderResponse as element(OrderResponse) external;

xf:OrderCreateResponse($orderResponse)
