(:: pragma bea:global-element-parameter parameter="$orderCreate1" element="OrderCreate" location="../WSDLs/SI_OSB_OrderCreateIB_A_OB.wsdl" ::)
(:: pragma bea:global-element-return element="OrderCreate" location="../WSDLs/SI_OSB_OrderCreateIB_A_OB.wsdl" ::)

declare namespace xf = "http://tempuri.org/USCOM_ChemOrders/XQueryTransformations/OrderCreateTransformation/";

declare function xf:OrderCreateTransformation($orderCreate1 as element(OrderCreate))
    as element(OrderCreate) {
        <OrderCreate Version = "2.0.2">
            <Header>{ $orderCreate1/Header/@* , $orderCreate1/Header/node() }</Header>
            <OrderCreateBody>
                <OrderCreateProperties>
                    <PurchaseOrderNumber>{ $orderCreate1/OrderCreateBody/OrderCreateProperties/PurchaseOrderNumber/@* , $orderCreate1/OrderCreateBody/OrderCreateProperties/PurchaseOrderNumber/node() }</PurchaseOrderNumber>
                    <PurchaseOrderTypeCode>{ data($orderCreate1/OrderCreateBody/OrderCreateProperties/PurchaseOrderTypeCode) }</PurchaseOrderTypeCode>
                    <PurchaseOrderIssuedDate>{ $orderCreate1/OrderCreateBody/OrderCreateProperties/PurchaseOrderIssuedDate/@* , $orderCreate1/OrderCreateBody/OrderCreateProperties/PurchaseOrderIssuedDate/node() }</PurchaseOrderIssuedDate>
                    <LanguageCode>{ $orderCreate1/OrderCreateBody/OrderCreateProperties/LanguageCode/@*, $orderCreate1/OrderCreateBody/OrderCreateProperties/LanguageCode/node()}</LanguageCode>
                    <CurrencyCode>{ $orderCreate1/OrderCreateBody/OrderCreateProperties/CurrencyCode/@*, $orderCreate1/OrderCreateBody/OrderCreateProperties/CurrencyCode/node() }</CurrencyCode>
                    <BuyerSequenceNumber>{ data($orderCreate1/OrderCreateBody/OrderCreateProperties/BuyerSequenceNumber) }</BuyerSequenceNumber>
                    {
                        for $ReferenceInformation in $orderCreate1/OrderCreateBody/OrderCreateProperties/ReferenceInformation
                        return
                            <ReferenceInformation>{ $ReferenceInformation/@* , $ReferenceInformation/node() }</ReferenceInformation>
                    }
                    {
                        for $ReleaseNumber in $orderCreate1/OrderCreateBody/OrderCreateProperties/ReleaseNumber
                        return
                            <ReleaseNumber>{ data($ReleaseNumber) }</ReleaseNumber>
                    }
                    {
                        for $MarketPlaceInformation in $orderCreate1/OrderCreateBody/OrderCreateProperties/MarketPlaceInformation
                        return
                            <MarketPlaceInformation>{ $MarketPlaceInformation/@* , $MarketPlaceInformation/node() }</MarketPlaceInformation>
                    }
                    {
                        for $SpecialInstructions in $orderCreate1/OrderCreateBody/OrderCreateProperties/SpecialInstructions
                        return
                            <SpecialInstructions>{ data($SpecialInstructions) }</SpecialInstructions>
                    }
                    {
                        for $TransportMethodCode in $orderCreate1/OrderCreateBody/OrderCreateProperties/TransportMethodCode
                        return
                            <TransportMethodCode Domain="ANSI ASC X12 91">{ "CE" }</TransportMethodCode>
                    }
                    {
                        for $ShipmentTerms in $orderCreate1/OrderCreateBody/OrderCreateProperties/ShipmentTerms
                        return
                            <ShipmentTerms>{ $ShipmentTerms/@* , $ShipmentTerms/node() }</ShipmentTerms>
                    }
                    {
                        for $RequestedPrice in $orderCreate1/OrderCreateBody/OrderCreateProperties/RequestedPrice
                        return
                            <RequestedPrice>{ $RequestedPrice/@* , $RequestedPrice/node() }</RequestedPrice>
                    }
                    {
                        for $PaymentTerms in $orderCreate1/OrderCreateBody/OrderCreateProperties/PaymentTerms
                        return
                            <PaymentTerms>{ $PaymentTerms/@* , $PaymentTerms/node() }</PaymentTerms>
                    }
                    {
                        for $Routing in $orderCreate1/OrderCreateBody/OrderCreateProperties/Routing
                        return
                            <Routing>{ data($Routing) }</Routing>
                    }
                    {
                        for $ShipWithPurchaseOrder in $orderCreate1/OrderCreateBody/OrderCreateProperties/ShipWithPurchaseOrder
                        return
                            <ShipWithPurchaseOrder>{ $ShipWithPurchaseOrder/@* , $ShipWithPurchaseOrder/node() }</ShipWithPurchaseOrder>
                    }
                    {
                        for $LetterOfCreditInformation in $orderCreate1/OrderCreateBody/OrderCreateProperties/LetterOfCreditInformation
                        return
                            <LetterOfCreditInformation>{ $LetterOfCreditInformation/@* , $LetterOfCreditInformation/node() }</LetterOfCreditInformation>
                    }
                    {
                        for $CarrierToExclude in $orderCreate1/OrderCreateBody/OrderCreateProperties/CarrierToExclude
                        return
                            <CarrierToExclude>{ $CarrierToExclude/@* , $CarrierToExclude/node() }</CarrierToExclude>
                    }
                    {
                        for $CountryOfFinalDestinationCode in $orderCreate1/OrderCreateBody/OrderCreateProperties/CountryOfFinalDestinationCode
                        return
                            <CountryOfFinalDestinationCode>{ data($CountryOfFinalDestinationCode) }</CountryOfFinalDestinationCode>
                    }
                </OrderCreateProperties>
                <OrderCreatePartners>{ $orderCreate1/OrderCreateBody/OrderCreatePartners/@* , $orderCreate1/OrderCreateBody/OrderCreatePartners/node() }</OrderCreatePartners>
                <OrderCreateDetails>
                    {
                        for $OrderCreateProductLineItem in $orderCreate1/OrderCreateBody/OrderCreateDetails/OrderCreateProductLineItem
                        return
                            <OrderCreateProductLineItem>
                                <LineNumber>{ data($OrderCreateProductLineItem/LineNumber) }</LineNumber>
                                {
                                    for $LineItemType in $OrderCreateProductLineItem/LineItemType
                                    return
                                        <LineItemType>{ $LineItemType/@* , $LineItemType/node() }</LineItemType>
                                }
                                <PurchaseOrderLineItemNumber>{ data($OrderCreateProductLineItem/PurchaseOrderLineItemNumber) }</PurchaseOrderLineItemNumber>
                                {
                                    for $ReleaseNumber in $OrderCreateProductLineItem/ReleaseNumber
                                    return
                                        <ReleaseNumber>{ $ReleaseNumber/@* , $ReleaseNumber/node() }</ReleaseNumber>
                                }
                                {
                                    for $ProductIdentification in $OrderCreateProductLineItem/ProductIdentification
                                    return
                                <ProductIdentification>{$ProductIdentification/ProductIdentifier/@*}
                                            <ProductIdentifier>{ data($ProductIdentification/ProductIdentifier) }</ProductIdentifier>
                                            <ProductName>{ data($ProductIdentification/ProductName) }</ProductName>
                                            <ProductDescription>{ data($ProductIdentification/ProductDescription) }</ProductDescription>
                                            <ProductGradeDescription>{ data($ProductIdentification/ProductGradeDescription) }</ProductGradeDescription>
                                            <ProductClassification>{ data($ProductIdentification/ProductClassification) }</ProductClassification>
                                        </ProductIdentification>
                                }
                                {
                                    for $ReferenceInformation in $OrderCreateProductLineItem/ReferenceInformation
                                    return
                                        <ReferenceInformation>{ $ReferenceInformation/@* , $ReferenceInformation/node() }</ReferenceInformation>
                                }
                                {
                                    let $ProductQuantity := $OrderCreateProductLineItem/ProductQuantity
                                    return
                                        <ProductQuantity>{$ProductQuantity/@* , $ProductQuantity/node()}</ProductQuantity>
                                }
                                {
                                    for $PackagingQuantity in $OrderCreateProductLineItem/PackagingQuantity
                                    return
                                        <PackagingQuantity>{ $PackagingQuantity/@* , $PackagingQuantity/node() }</PackagingQuantity>
                                }
                                {
                                    for $BatchNumber in $OrderCreateProductLineItem/BatchNumber
                                    return
                                        <BatchNumber>{ $BatchNumber/@* , $BatchNumber/node() }</BatchNumber>
                                }
                                {
                                    for $CountryOfOriginCode in $OrderCreateProductLineItem/CountryOfOriginCode
                                    return
                                        <CountryOfOriginCode>{ $CountryOfOriginCode/@* , $CountryOfOriginCode/node() }</CountryOfOriginCode>
                                }
                                {
                                    for $ScheduleDateTimeInformation in $OrderCreateProductLineItem/ScheduleDateTimeInformation
                                    return
                                        <ScheduleDateTimeInformation>{ $ScheduleDateTimeInformation/@* , $ScheduleDateTimeInformation/node() }</ScheduleDateTimeInformation>
                                }
                                {
                                    for $ShipTo in $OrderCreateProductLineItem/ShipTo
                                    return
                                        <ShipTo>{ $ShipTo/@* , $ShipTo/node() }</ShipTo>
                                }
                                {
                                    for $OtherPartner in $OrderCreateProductLineItem/OtherPartner
                                    return
                                        <OtherPartner>{ $OtherPartner/@* , $OtherPartner/node() }</OtherPartner>
                                }
                                {
                                    for $DeliveryTolerances in $OrderCreateProductLineItem/DeliveryTolerances
                                    return
                                        <DeliveryTolerances>{ $DeliveryTolerances/@* , $DeliveryTolerances/node() }</DeliveryTolerances>
                                }
                                {
                                    for $ShipmentTerms in $OrderCreateProductLineItem/ShipmentTerms
                                    return
                                        <ShipmentTerms>{ $ShipmentTerms/@* , $ShipmentTerms/node() }</ShipmentTerms>
                                }
                                {
                                    for $TransportInformation in $OrderCreateProductLineItem/TransportInformation
                                    return
                                        <TransportInformation>{ $TransportInformation/@* , $TransportInformation/node() }</TransportInformation>
                                }
                                {
                                    for $RequestedPrice in $OrderCreateProductLineItem/RequestedPrice
                                    return
                                        <RequestedPrice>{ $RequestedPrice/@* , $RequestedPrice/node() }</RequestedPrice>
                                }
                                {
                                    for $PaymentTerms in $OrderCreateProductLineItem/PaymentTerms
                                    return
                                        <PaymentTerms>{ $PaymentTerms/@* , $PaymentTerms/node() }</PaymentTerms>
                                }
                                {
                                    for $TaxableFlag in $OrderCreateProductLineItem/TaxableFlag
                                    return
                                        <TaxableFlag>{ $TaxableFlag/@* , $TaxableFlag/node() }</TaxableFlag>
                                }
                                {
                                    for $RequestedDocument in $OrderCreateProductLineItem/RequestedDocument
                                    return
                                        <RequestedDocument>{ $RequestedDocument/@* , $RequestedDocument/node() }</RequestedDocument>
                                }
                                {
                                    for $Routing in $OrderCreateProductLineItem/Routing
                                    return
                                        <Routing>{ $Routing/@* , $Routing/node() }</Routing>
                                }
                                {
                                    for $BalanceItemFlag in $OrderCreateProductLineItem/BalanceItemFlag
                                    return
                                        <BalanceItemFlag>{ $BalanceItemFlag/@* , $BalanceItemFlag/node() }</BalanceItemFlag>
                                }
                                {
                                    for $DutyStatus in $OrderCreateProductLineItem/DutyStatus
                                    return
                                        <DutyStatus>{ $DutyStatus/@* , $DutyStatus/node() }</DutyStatus>
                                }
                                {
                                    for $ImportLicenseNeededFlag in $OrderCreateProductLineItem/ImportLicenseNeededFlag
                                    return
                                        <ImportLicenseNeededFlag>{ $ImportLicenseNeededFlag/@* , $ImportLicenseNeededFlag/node() }</ImportLicenseNeededFlag>
                                }
                                {
                                    for $ImportLicenseAvailableFlag in $OrderCreateProductLineItem/ImportLicenseAvailableFlag
                                    return
                                        <ImportLicenseAvailableFlag>{ $ImportLicenseAvailableFlag/@* , $ImportLicenseAvailableFlag/node() }</ImportLicenseAvailableFlag>
                                }
                                {
                                    for $SecondWeightFlag in $OrderCreateProductLineItem/SecondWeightFlag
                                    return
                                        <SecondWeightFlag>{ $SecondWeightFlag/@* , $SecondWeightFlag/node() }</SecondWeightFlag>
                                }
                                {
                                    for $CustomerRequestedDeliveryHoldFlag in $OrderCreateProductLineItem/CustomerRequestedDeliveryHoldFlag
                                    return
                                        <CustomerRequestedDeliveryHoldFlag>{ $CustomerRequestedDeliveryHoldFlag/@* , $CustomerRequestedDeliveryHoldFlag/node() }</CustomerRequestedDeliveryHoldFlag>
                                }
                                {
                                    for $AccompanyingSampleIndicator in $OrderCreateProductLineItem/AccompanyingSampleIndicator
                                    return
                                        <AccompanyingSampleIndicator>{ $AccompanyingSampleIndicator/@* , $AccompanyingSampleIndicator/node() }</AccompanyingSampleIndicator>
                                }
                                {
                                    for $SpecialFulfillmentRequestCode in $OrderCreateProductLineItem/SpecialFulfillmentRequestCode
                                    return
                                        <SpecialFulfillmentRequestCode>{ $SpecialFulfillmentRequestCode/@* , $SpecialFulfillmentRequestCode/node() }</SpecialFulfillmentRequestCode>
                                }
                                {
                                    for $CountryOfFinalDestinationCode in $OrderCreateProductLineItem/CountryOfFinalDestinationCode
                                    return
                                        <CountryOfFinalDestinationCode>{ $CountryOfFinalDestinationCode/@* , $CountryOfFinalDestinationCode/node() }</CountryOfFinalDestinationCode>
                                }
                                {
                                    for $DeliveryGroup in $OrderCreateProductLineItem/DeliveryGroup
                                    return
                                        <DeliveryGroup>{ $DeliveryGroup/@* , $DeliveryGroup/node() }</DeliveryGroup>
                                }
                                {
                                    for $SpecialInstructions in $OrderCreateProductLineItem/SpecialInstructions
                                    return
                                        <SpecialInstructions>{ $SpecialInstructions/@* , $SpecialInstructions/node() }</SpecialInstructions>
                                }
                            </OrderCreateProductLineItem>
                    }
                </OrderCreateDetails>
            </OrderCreateBody>
        </OrderCreate>
};

declare variable $orderCreate1 as element(OrderCreate) external;

xf:OrderCreateTransformation($orderCreate1)
