<Partners>
	<ebid>0089646370000</ebid>
</Partners>