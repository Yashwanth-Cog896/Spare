(:: pragma bea:global-element-parameter parameter="$request" element="ns0:StockTransferListRequest" location="../Schemas/StockTransferList.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstList" location="../WSDLs/YES_Y_SDSA_USSEED_EST_LIST.WSDL" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:StockTransferList";
declare namespace xf = "http://tempuri.org/ECC_US_EST_StockTransferList/XQueryResources/StockTransferListRequest/";

declare function xf:StockTransferListRequest($request as element(ns0:StockTransferListRequest))
    as element(ns2:YSdsaUsseedEstList) {
        <ns2:YSdsaUsseedEstList>
            <DlrReqStatus>
                {
                    for $Status in $request/ns0:StockTransferListRequestBody/ns0:StatusList/ns0:Status
                    return
                        <item>
                            <Yystatus>{ data($Status) }</Yystatus>
                        </item>
                }
            </DlrReqStatus>
            <Yyind>{ xs:string( data($request/ns0:StockTransferListRequestBody/ns0:TransferIndicator) ) }</Yyind>
            <Yykunnr>{ data($request/ns0:StockTransferListRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier) }</Yykunnr>
            <YyreqType>{ xs:string( data($request/ns0:StockTransferListRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type) ) }</YyreqType>
            <Yyyear>{ xs:string( data($request/ns0:StockTransferListRequestBody/ns0:SeedYear) ) }</Yyyear>
        </ns2:YSdsaUsseedEstList>
};

declare variable $request as element(ns0:StockTransferListRequest) external;

xf:StockTransferListRequest($request)
