(:: pragma bea:global-element-parameter parameter="$request" element="ns2:DealerLocationRequest" location="../Schemas/DealerLocation.xsd" ::)
(:: pragma bea:global-element-return element="ns1:YSdsaUsseedEstDlrlocation" location="../WSDLs/DealerLocation_ECC.WSDL" ::)

declare namespace ns2 = "Monsanto:Service:DealerLocation";
declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:monsanto:uscomm:service:header";
declare namespace xf = "http://tempuri.org/ECC_US_ElectronicStockTransfer_DealerLocation/XQueryResources/DealerLocationRequest/";

declare function xf:DealerLocationRequest($request as element(ns2:DealerLocationRequest))
    as element(ns1:YSdsaUsseedEstDlrlocation) {
        <ns1:YSdsaUsseedEstDlrlocation>
            <ReqDealer>
                <Dealer>{ data($request/ns2:DealerLocationRequestBody/ns2:PartnerIdentifier) }</Dealer>
                <RequestType>{ data($request/ns2:DealerLocationRequestBody/ns2:AgreementType) }</RequestType>
            </ReqDealer>
        </ns1:YSdsaUsseedEstDlrlocation>
};

declare variable $request as element(ns2:DealerLocationRequest) external;

xf:DealerLocationRequest($request)