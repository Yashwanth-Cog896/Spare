(:: pragma bea:global-element-parameter parameter="$response" element="ns1:YSdsaUsseedEstDlrlocationResponse" location="../WSDLs/DealerLocation_ECC.WSDL" ::)
(:: pragma bea:global-element-return element="ns2:DealerLocationResponse" location="../Schemas/DealerLocation.xsd" ::)

declare namespace ns2 = "Monsanto:Service:DealerLocation";
declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:monsanto:uscomm:service:header";
declare namespace xf = "http://tempuri.org/ECC_US_ElectronicStockTransfer_DealerLocation/XQueryResources/DealerLocationResponse/";

declare function xf:DealerLocationResponse($response as element(ns1:YSdsaUsseedEstDlrlocationResponse))
    as element(ns2:DealerLocationResponse) {
        <ns2:DealerLocationResponse Version = "1.0">
            <ns2:DealerLocationResponseBody>
                {
                    for $item in $response/Bupatab/item
                    return
                        <ns2:DealerInformation>
                            <ns2:DealerEntity>
                                <ns2:PartnerIdentifier Type = "SAP_ID">{ data($item/Dealer) }</ns2:PartnerIdentifier>
                                <ns2:PartnerName>{ data($item/Name1) }</ns2:PartnerName>
                            </ns2:DealerEntity>
                            <ns2:AddressInformation>
                                <ns2:AddressLine>{ data($item/Street) }</ns2:AddressLine>
                                <ns2:CityName>{ data($item/City) }</ns2:CityName>
                                <ns2:State>{ data($item/Region) }</ns2:State>
                                <ns2:PostalCode>{ data($item/PostlCod1) }</ns2:PostalCode>
                            </ns2:AddressInformation>
                            <ns2:PhoneNumber>{ data($item/Tel1Number) }</ns2:PhoneNumber>
                            <ns2:EmailAddress>{ data($item/EMail) }</ns2:EmailAddress>
                            <ns2:IBSDIndicator>{ data($item/Ibsd) }</ns2:IBSDIndicator>
                            <ns2:SendDealerPORequired>{ data($item/Poflag) }</ns2:SendDealerPORequired>
                            <ns2:RecDealerPORequired>{ data($item/Rpoflag) }</ns2:RecDealerPORequired>
                        </ns2:DealerInformation>
                }
            </ns2:DealerLocationResponseBody>
            <ns2:DealerLocationResponseError>
                <ns2:ErrorType>
                    {
                        if (data($response/Messages/Type) = "S") then
                            ("Success")
                        else 
                            if (data($response/Messages/Type) = "E") then
                                ("Error")
                            else 
                                if (data($response/Messages/Type) = "W") then
                                    ("Warning")
                                else 
                                    if (data($response/Messages/Type) = "I") then
                                        ("Info")
                                    else 
                                        if (data($response/Messages/Type) = "A") then
                                            ("Abort")
                                        else 
                                            ()
                    }
				</ns2:ErrorType>
                <ns2:ErrorMessageClass>{ data($response/Messages/Id) }</ns2:ErrorMessageClass>
                {
                if(data($response/Messages/Number)!='')then(
                <ns2:ErrorMessageNumber>{ xs:integer( data($response/Messages/Number) ) }</ns2:ErrorMessageNumber>
                )else()
                }
                <ns2:ErrorMessageObject>{ data($response/Messages/MsgObject) }</ns2:ErrorMessageObject>
                <ns2:ErrorMessageText>{ data($response/Messages/ErrDesc) }</ns2:ErrorMessageText>
                <ns2:ErrorMessageDisplayText>{ data($response/Messages/ErrDescDisp) }</ns2:ErrorMessageDisplayText>
            </ns2:DealerLocationResponseError>
        </ns2:DealerLocationResponse>
};

declare variable $response as element(ns1:YSdsaUsseedEstDlrlocationResponse) external;

xf:DealerLocationResponse($response)