(:: pragma bea:global-element-parameter parameter="$request" element="ns0:SHUpdateRequest" location="../Schemas/SHDataUpdate.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YsdsaHaulbackDataupdate" location="../WSDLs/ECC_DataUpdate.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:SHDataUpdate";
declare namespace xf = "http://tempuri.org/ECC_US_SHB_DataUpdate/XQueryResources/SHDataUpdateRequest/";

declare function xf:SHDataUpdateRequest($request as element(ns0:SHUpdateRequest))
    as element(ns2:YsdsaHaulbackDataupdate) {
        <ns2:YsdsaHaulbackDataupdate>
            <ItHeader>
                {
                    for $Transaction in $request/ns0:SHUpdateRequestBody/ns0:HaulbackTransactions/ns0:Transaction
                    return
                        <item>
                            <Yykunnr>{ data($Transaction/ns0:SoldTo/ns0:PartnerIdentifier) }</Yykunnr>
                            <YysoldToTyp>{ xs:string( data($Transaction/ns0:SoldTo/ns0:PartnerIdentifier/@Type) ) }</YysoldToTyp>
                            <Yyaction>{ xs:string( data($Transaction/ns0:Action) ) }</Yyaction>
                            { 
                             if($Transaction/ns0:TransactionId/@Type= 'HaulbackId')then 
                              (<YytransactionId>{ xs:string( data($Transaction/ns0:TransactionId) ) }</YytransactionId>)
                               else if ($Transaction/ns0:TransactionId/@Type= 'ClientReference')then 
                                (<YyclientRef>{ xs:string( data($Transaction/ns0:TransactionId) ) }</YyclientRef>)
                                 else ()
                            }
                              <YyshipTo>{ data($Transaction/ns0:ShipTo/ns0:PartnerIdentifier) }</YyshipTo>
                            <YyshipToTyp>{ xs:string( data($Transaction/ns0:ShipTo/ns0:PartnerIdentifier/@Type) ) }</YyshipToTyp>
                            <YypurchaseOrder>{ xs:string( data($Transaction/ns0:PONumber) ) }</YypurchaseOrder>
                            <YytotalQtyRet>{ data($Transaction/ns0:QuantityReturned) }</YytotalQtyRet>
                            <YytotalEstCr>{ data($Transaction/ns0:CreditEstimate) }</YytotalEstCr>
                            <YytotalEstDb>{ data($Transaction/ns0:DebitEstimate) }</YytotalEstDb>
                            <YytotEstNetCr>{ data($Transaction/ns0:NetCreditEstimate) }</YytotEstNetCr>
                            <Yyupdatedby>{ xs:string( data($Transaction/ns0:UpdatedBy) ) }</Yyupdatedby>
                            <Yycreatedby>{ xs:string( data($Transaction/ns0:CreatedBy) ) }</Yycreatedby>
                        </item>
                }
            </ItHeader>
            <ItItem>
                {
                    for $Transaction1 in $request/ns0:SHUpdateRequestBody/ns0:HaulbackTransactions/ns0:Transaction
                    for $TransactionDetails in $Transaction1/ns0:TransactionDetails
                    return
                        <item>
                            {
                            if($Transaction1/ns0:TransactionId/@Type= 'HaulbackId')then 
                              (<YytransactionId>{ xs:string( data($Transaction1/ns0:TransactionId))}</YytransactionId> )
                               else if ($Transaction1/ns0:TransactionId/@Type= 'ClientReference')then 
                                (<YyclientRef>{ xs:string( data($Transaction1/ns0:TransactionId) ) }</YyclientRef>)
                                 else ()
                            }
                             <YyitemNo>{ xs:string( data($TransactionDetails/ns0:ItemNumber) ) }</YyitemNo>
                            <Yymaterial>{ xs:string( data($TransactionDetails/ns0:ProductIdentification/ns0:ProductIdentifier[1]) ) }</Yymaterial>
                            <YymatTyp>{ xs:string( data($TransactionDetails/ns0:ProductIdentification/ns0:ProductIdentifier[1]/@Type) ) }</YymatTyp>
                            <YymaterialDescr>{ data($TransactionDetails/ns0:ProductIdentification/ns0:ProductName) }</YymaterialDescr>
                            <YysalesUnit>{ xs:string( data($TransactionDetails/ns0:SalesUnit/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</YysalesUnit>
                            <YyorderUnit>{ data($TransactionDetails/ns0:SalesUnit/ns0:Measurement/ns0:MeasurementValue) }</YyorderUnit>
                            <YyseedLb>{ xs:string( data($TransactionDetails/ns0:SeedPerPound) ) }</YyseedLb>
                            <Yybatch>{ data($TransactionDetails/ns0:BatchNumber) }</Yybatch>
                            <YynetDelivered>{ data($TransactionDetails/ns0:NetDeliveredQty) }</YynetDelivered>
                            <YypreviousSubmi>{ data($TransactionDetails/ns0:PreviousSubmittedQty) }</YypreviousSubmi>
                            <YyqtyReturn>{ data($TransactionDetails/ns0:HaulbackQtyReturned) }</YyqtyReturn>
                            <YyelevatorDump>{ xs:string( data($TransactionDetails/ns0:ElevatorDumpDate) ) }</YyelevatorDump>
                            <YycommodityPric>{ data($TransactionDetails/ns0:ElevatorCommodityPrice) }</YycommodityPric>
                            <YyestCredit>{ data($TransactionDetails/ns0:EstimatedCredit) }</YyestCredit>
                            <YyestDebit>{ data($TransactionDetails/ns0:EstimatedDebit) }</YyestDebit>
                            <YyestNetCredit>{ data($TransactionDetails/ns0:EstimatedNetCredit) }</YyestNetCredit>
							<YyhbPrice>{ data($TransactionDetails/ns0:Price/ns0:MonetaryValue) }</YyhbPrice>
                            <Yypricecuky>{ xs:string( data($TransactionDetails/ns0:Price/ns0:CurrencyCode) ) }</Yypricecuky>
                            {
                            if ($TransactionDetails/ns0:SearchedByBatch/text()='true') then (
                            <YyholdSearchBa>X</YyholdSearchBa>
                            ) else if($TransactionDetails/ns0:SearchedByBatch/text()='false') then (
                             <YyholdSearchBa></YyholdSearchBa>)
                             else ()
                             }
                        </item>
                }
            </ItItem>
            <ItSurvey>
                {
                    for $Survey in $request/ns0:SHUpdateRequestBody/ns0:SurveyDetails/ns0:Survey
                    return
                        <item>
                            <Yykunnr>{ data($Survey/ns0:SoldTo/ns0:PartnerIdentifier) }</Yykunnr>
                            <YyacctTyp>{ xs:string( data($Survey/ns0:SoldTo/ns0:PartnerIdentifier/@Type) ) }</YyacctTyp>
                            <Yysbreturns>{ xs:string( data($Survey/ns0:ReturnIndicator) ) }</Yysbreturns>
                            <YyqtyExcDci>{ xs:string( data($Survey/ns0:ExceedsThreshold) ) }</YyqtyExcDci>
                            <YymultiSh>{ xs:string( data($Survey/ns0:MultipleShipTo) ) }</YymultiSh>
                            <YyhbQty>{ xs:decimal( data($Survey/ns0:EstHaulbackQty) ) }</YyhbQty>
                            <Yybulkreturn>{ xs:string( data($Survey/ns0:BulkSoybeanReturn) ) }</Yybulkreturn>
                            <Ycreatedby>{ xs:string( data($Survey/ns0:CreatedBy) ) }</Ycreatedby>
                        </item>
                }
            </ItSurvey>
            <IvVkorg>{ xs:string( data($request/ns0:SHUpdateRequestBody/ns0:SalesOrg) ) }</IvVkorg>
            <IvYear>{ xs:string( data($request/ns0:SHUpdateRequestBody/ns0:SalesYear) ) }</IvYear>
        </ns2:YsdsaHaulbackDataupdate>
};

declare variable $request as element(ns0:SHUpdateRequest) external;

xf:SHDataUpdateRequest($request)
