(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YsdsaHaulbackDataupdateResponse" location="../WSDLs/ECC_DataUpdate.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:SHUpdateResponse" location="../Schemas/SHDataUpdate.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:SHDataUpdate";
declare namespace xf = "http://tempuri.org/ECC_US_SHB_DataUpdate/XQueryResources/SHDataUpdateResponse/";

declare function xf:SHDataUpdateResponse($response as element(ns2:YsdsaHaulbackDataupdateResponse))
    as element(ns0:SHUpdateResponse) {
        <ns0:SHUpdateResponse>
            <ns0:SHUpdateResponseBody>
                {
                    for $item in $response/EtReturn/item
                    return
                        <ns0:TranactionStatus>
                            <ns0:SoldTo>
                                <ns0:PartnerIdentifier Type = "{ data($item/YyacctTyp) }">{ data($item/Yykunnr) }</ns0:PartnerIdentifier>
                            </ns0:SoldTo>
                            { if ($response/EtReturn/item/YytransactionId/text()!='') then (
                            <ns0:TransactionId Type = 'HaulbackId'>{ data($item/YytransactionId) }</ns0:TransactionId>)
                            else()}
                            { if ($response/EtReturn/item/YyclientRef/text()!='') then (
                            <ns0:ClientReferenceId>
                                <ns0:TransactionId Type ='CleintRefence'>{ data($item/YyclientRef) }</ns0:TransactionId>
                            </ns0:ClientReferenceId> )
                            else () }
                            <ns0:ResponseCode>{ data($item/YyresponseCode) }</ns0:ResponseCode>
                            <ns0:ResponseDescription>{ data($item/YyerrDesc) }</ns0:ResponseDescription>
                        </ns0:TranactionStatus>
                }
            </ns0:SHUpdateResponseBody>
        </ns0:SHUpdateResponse>
};

declare variable $response as element(ns2:YsdsaHaulbackDataupdateResponse) external;

xf:SHDataUpdateResponse($response)
