(:: pragma bea:global-element-parameter parameter="$request" element="ns0:CSRStatusLookup_CRM_Sync" location="../WSDLs/CSRStatusLookup_CRM_Sync.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YicCtiuserGetattr" location="../WSDLs/CRM_WSDL.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CIC_Telephony/XQueryResources/CICRequest_Transformation/";

declare function xf:CICRequest_Transformation($request as element(ns0:CSRStatusLookup_CRM_Sync))
    as element(ns0:YicCtiuserGetattr) {
        <ns0:YicCtiuserGetattr>
            <Userid>{ data(upper-case($request/SAPId)) }</Userid>
        </ns0:YicCtiuserGetattr>
};

declare variable $request as element(ns0:CSRStatusLookup_CRM_Sync) external;

xf:CICRequest_Transformation($request)
