(:: pragma bea:global-element-parameter parameter="$response" element="ns0:YicCtiuserGetattrResponse" location="../WSDLs/CRM_WSDL.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:CSRStatusLookup_CRM_SyncResponse" location="../WSDLs/CSRStatusLookup_CRM_Sync.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CIC_Telephony/XQueryResources/CICResponse_Tranformation/";

declare function xf:CICResponse_Tranformation($response as element(ns0:YicCtiuserGetattrResponse))
    as element(ns0:CSRStatusLookup_CRM_SyncResponse) {
        <ns0:CSRStatusLookup_CRM_SyncResponse>
            <Currentworkmode>
                <Id>{ data($response/Currentworkmode/Id) }</Id>
                <Description>{ data($response/Currentworkmode/Description) }</Description>
            </Currentworkmode>
            <Errormessage>{ data($response/Errormessage) }</Errormessage>
            <Workmodes>
                {
                    for $item in $response/Workmodes/item
                    return
                        <item>{ $item/@* , $item/node() }</item>
                }
            </Workmodes>
        </ns0:CSRStatusLookup_CRM_SyncResponse>
};

declare variable $response as element(ns0:YicCtiuserGetattrResponse) external;

xf:CICResponse_Tranformation($response)
