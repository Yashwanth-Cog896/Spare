declare namespace urn="urn:monsanto:serviceadmin:services:outage"; 
declare namespace urn1="urn:monsanto:uscomm:service:header";

declare function urn:outageServiceBuildXMLRequest 
  ($accountNumberText as xs:string,
   $docId as xs:string,
   $dateTime as xs:string,
   $partnerName as xs:string)  as node() {


    fn-bea:inlinedXML(
    fn:concat(
      '<urn:GetAuthorizationRequest xmlns:urn="urn:monsanto:serviceadmin:services:authorization" xmlns:urn1="urn:monsanto:uscomm:service:header">',
       	'<urn1:Header>',
            '<urn1:DocumentIdentifier>', $docId, '</urn1:DocumentIdentifier>',
            '<urn1:DocumentDateTime>', $dateTime, '</urn1:DocumentDateTime>',
            '<urn1:From>',
               '<urn1:PartnerName>', fn:replace($partnerName, $partnerName, "AuthorizationRequest"), '</urn1:PartnerName>',
            '</urn1:From>',
        '</urn1:Header>',
      '<urn:GetAuthorizationRequestBody>',
      	'<urn:UserId>',
      	 	$accountNumberText,
      	 '</urn:UserId>',
      	 '<urn:AuthorizationRequestType>',
           '<urn:RequestType>Role</urn:RequestType>',
         '</urn:AuthorizationRequestType>',
		'</urn:GetAuthorizationRequestBody>',		      		 
      '</urn:GetAuthorizationRequest>'
      ))

 };

declare variable $accountNumberText as xs:string external;
declare variable $docId as xs:string external;
declare variable $dateTime as xs:string external;
declare variable $partnerName as xs:string external;

urn:outageServiceBuildXMLRequest ($accountNumberText, $docId, $dateTime, $partnerName)