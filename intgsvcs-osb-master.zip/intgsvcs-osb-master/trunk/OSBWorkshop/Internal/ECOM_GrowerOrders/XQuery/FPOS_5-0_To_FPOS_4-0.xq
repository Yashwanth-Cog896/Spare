(:: pragma bea:global-element-parameter parameter="$productMovementReport1" element="ns0:ProductMovementReport" location="../../SharedSchemas/Schemas/CIDX/5-0Final/CIDX_5.0.xsd" ::)
(:: pragma bea:global-element-return element="ns1:ProductMovementReport" location="../../SharedSchemas/Schemas/Ag-eStandards/4-0/CIDX_CeS_v4.0_Message_ProductMovementReport.xsd" ::)

declare namespace ns1 = "urn:cidx:names:specification:ces:schema:all:4:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/ECOM_GrowerOrders/XQueryTransformations/FPOS_5-0_To_FPOS_4-0/";

declare function xf:FPOS_5-0_To_FPOS_4-0($productMovementReport1 as element(ns0:ProductMovementReport))
    as element(ns1:ProductMovementReport) {
        <ns1:ProductMovementReport Version = "4.0">
            {
                let $Header := $productMovementReport1/ns0:Header
                return
                    <ns1:Header>
                        <ns1:ThisDocumentIdentifier>
                            <ns1:DocumentIdentifier>{ data($Header/ns0:ThisDocumentIdentifier/ns0:DocumentIdentifier) }</ns1:DocumentIdentifier>
                        </ns1:ThisDocumentIdentifier>
                        <ns1:ThisDocumentDateTime>
                            <ns1:DateTime DateTimeQualifier = "{ data($Header/ns0:ThisDocumentDateTime/ns0:DateTime/@DateTimeQualifier) }">{ $Header/ns0:ThisDocumentDateTime/ns0:DateTime/text() }</ns1:DateTime>
                        </ns1:ThisDocumentDateTime>
                        {
                            for $RequestingDocumentIdentifier in $Header/ns0:RequestingDocumentIdentifier
                            return
                                <ns1:RequestingDocumentIdentifier>
                                    <ns1:DocumentIdentifier>{ data($RequestingDocumentIdentifier/ns0:DocumentIdentifier) }</ns1:DocumentIdentifier>
                                </ns1:RequestingDocumentIdentifier>
                        }
                        {
                            for $RequestingDocumentDateTime in $Header/ns0:RequestingDocumentDateTime
                            return
                                <ns1:RequestingDocumentDateTime>
                                    <ns1:DateTime DateTimeQualifier = "{ data($RequestingDocumentDateTime/ns0:DateTime/@DateTimeQualifier) }"/>
                                </ns1:RequestingDocumentDateTime>
                        }
                        <ns1:From>
                            <ns1:PartnerInformation>
                                {
                                    for $PartnerName in $Header/ns0:From/ns0:PartnerInformation/ns0:PartnerName
                                    return
                                        <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                }
                                <ns1:PartnerIdentifier Agency = "{ data($Header/ns0:From/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($Header/ns0:From/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                {
                                    for $ContactInformation in $Header/ns0:From/ns0:PartnerInformation/ns0:ContactInformation
                                    return
                                        <ns1:ContactInformation>
                                            {
                                                for $ContactName in $ContactInformation/ns0:ContactName
                                                return
                                                    <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                            }
                                            {
                                                for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                return
                                                    <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                            }
                                            {
                                                for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                return
                                                    <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                            }
                                            {
                                                for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                return
                                                    <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                            }
                                            {
                                                for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                return
                                                    <ns1:AlternativeCommunicationMethod CommunicationMethodType = "{ data($AlternativeCommunicationMethod/@CommunicationMethodType) }">{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                            }
                                        </ns1:ContactInformation>
                                }
                                {
                                    for $AddressInformation in $Header/ns0:From/ns0:PartnerInformation/ns0:AddressInformation
                                    return
                                        <ns1:AddressInformation>
                                            <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                            {
                                                for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                return
                                                    <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                            }
                                            {
                                                for $PostalCode in $AddressInformation/ns0:PostalCode
                                                return
                                                    <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                            }
                                            <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                            {
                                                for $LocationCode in $AddressInformation/ns0:LocationCode
                                                return
                                                    <ns1:LocationCode Domain = "{ data($LocationCode/@Domain) }">{ data($LocationCode) }</ns1:LocationCode>
                                            }
                                            {
                                                for $Comment in $AddressInformation/ns0:Comment
                                                return
                                                    <ns1:Comment/>
                                            }
                                        </ns1:AddressInformation>
                                }
                                {
                                    for $TaxInformation in $Header/ns0:From/ns0:PartnerInformation/ns0:TaxInformation
                                    return
                                        <ns1:TaxInformation>
                                            <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                            {
                                                for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                return
                                                    <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                            }
                                            {
                                                for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                return
                                                    <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                            }
                                            {
                                                for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                return
                                                    <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                            }
                                            {
                                                for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                return
                                                    <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                            }
                                            {
                                                for $TaxRate in $TaxInformation/ns0:TaxRate
                                                return
                                                    <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                            }
                                            {
                                                for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                return
                                                    <ns1:EffectiveDates>
                                                        {
                                                            for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                            return
                                                                <ns1:DateTimeInformation/>
                                                        }
                                                    </ns1:EffectiveDates>
                                            }
                                        </ns1:TaxInformation>
                                }
                                {
                                    for $URL in $Header/ns0:From/ns0:PartnerInformation/ns0:URL
                                    return
                                        <ns1:URL>{ data($URL) }</ns1:URL>
                                }
                                {
                                    for $PartnerReference in $Header/ns0:From/ns0:PartnerInformation/ns0:PartnerReference
                                    return
                                        <ns1:PartnerReference>
                                            <ns1:PartnerIdentifier Agency = "{ data($PartnerReference/ns0:PartnerIdentifier/@Agency) }">{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                        </ns1:PartnerReference>
                                }
                                {
                                    for $LoadingPoint in $Header/ns0:From/ns0:PartnerInformation/ns0:LoadingPoint
                                    return
                                        <ns1:LoadingPoint/>
                                }
                                {
                                    for $UnloadingPoint in $Header/ns0:From/ns0:PartnerInformation/ns0:UnloadingPoint
                                    return
                                        <ns1:UnloadingPoint/>
                                }
                                {
                                    for $AccountInformation in $Header/ns0:From/ns0:PartnerInformation/ns0:AccountInformation
                                    return
                                        <ns1:AccountInformation>
                                            {
                                                for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                return
                                                    <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                            }
                                        </ns1:AccountInformation>
                                }
                            </ns1:PartnerInformation>
                        </ns1:From>
                        <ns1:To>
                            <ns1:PartnerInformation>
                                {
                                    for $PartnerName in $Header/ns0:To/ns0:PartnerInformation/ns0:PartnerName
                                    return
                                        <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                }
                                <ns1:PartnerIdentifier Agency = "{ data($Header/ns0:To/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($Header/ns0:To/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                {
                                    for $ContactInformation in $Header/ns0:To/ns0:PartnerInformation/ns0:ContactInformation
                                    return
                                        <ns1:ContactInformation>
                                            {
                                                for $ContactName in $ContactInformation/ns0:ContactName
                                                return
                                                    <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                            }
                                            {
                                                for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                return
                                                    <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                            }
                                            {
                                                for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                return
                                                    <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                            }
                                            {
                                                for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                return
                                                    <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                            }
                                            {
                                                for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                return
                                                    <ns1:AlternativeCommunicationMethod>{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                            }
                                        </ns1:ContactInformation>
                                }
                                {
                                    for $AddressInformation in $Header/ns0:To/ns0:PartnerInformation/ns0:AddressInformation
                                    return
                                        <ns1:AddressInformation>
                                            <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                            {
                                                for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                return
                                                    <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                            }
                                            {
                                                for $PostalCode in $AddressInformation/ns0:PostalCode
                                                return
                                                    <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                            }
                                            <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                            {
                                                for $LocationCode in $AddressInformation/ns0:LocationCode
                                                return
                                                    <ns1:LocationCode>{ data($LocationCode) }</ns1:LocationCode>
                                            }
                                            {
                                                for $Comment in $AddressInformation/ns0:Comment
                                                return
                                                    <ns1:Comment/>
                                            }
                                        </ns1:AddressInformation>
                                }
                                {
                                    for $TaxInformation in $Header/ns0:To/ns0:PartnerInformation/ns0:TaxInformation
                                    return
                                        <ns1:TaxInformation>
                                            <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                            {
                                                for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                return
                                                    <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                            }
                                            {
                                                for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                return
                                                    <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                            }
                                            {
                                                for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                return
                                                    <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                            }
                                            {
                                                for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                return
                                                    <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                            }
                                            {
                                                for $TaxRate in $TaxInformation/ns0:TaxRate
                                                return
                                                    <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                            }
                                            {
                                                for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                return
                                                    <ns1:EffectiveDates>
                                                        {
                                                            for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                            return
                                                                <ns1:DateTimeInformation/>
                                                        }
                                                    </ns1:EffectiveDates>
                                            }
                                        </ns1:TaxInformation>
                                }
                                {
                                    for $URL in $Header/ns0:To/ns0:PartnerInformation/ns0:URL
                                    return
                                        <ns1:URL>{ data($URL) }</ns1:URL>
                                }
                                {
                                    for $PartnerReference in $Header/ns0:To/ns0:PartnerInformation/ns0:PartnerReference
                                    return
                                        <ns1:PartnerReference>
                                            <ns1:PartnerIdentifier>{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                        </ns1:PartnerReference>
                                }
                                {
                                    for $LoadingPoint in $Header/ns0:To/ns0:PartnerInformation/ns0:LoadingPoint
                                    return
                                        <ns1:LoadingPoint/>
                                }
                                {
                                    for $UnloadingPoint in $Header/ns0:To/ns0:PartnerInformation/ns0:UnloadingPoint
                                    return
                                        <ns1:UnloadingPoint/>
                                }
                                {
                                    for $AccountInformation in $Header/ns0:To/ns0:PartnerInformation/ns0:AccountInformation
                                    return
                                        <ns1:AccountInformation>
                                            {
                                                for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                return
                                                    <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                            }
                                        </ns1:AccountInformation>
                                }
                            </ns1:PartnerInformation>
                        </ns1:To>
                    </ns1:Header>
            }
            {
                let $ProductMovementReportBody := $productMovementReport1/ns0:ProductMovementReportBody
                return
                    <ns1:ProductMovementReportBody>
                        {
                            for $ProductMovementReportProperties in $ProductMovementReportBody/ns0:ProductMovementReportProperties
                            return
                                <ns1:ProductMovementReportProperties>
                                    <ns1:CurrencyCode Domain = "{ data($ProductMovementReportProperties/ns0:CurrencyCode/@Domain) }">{ data($ProductMovementReportProperties/ns0:CurrencyCode) }</ns1:CurrencyCode>
                                    <ns1:LanguageCode Domain = "{ data($ProductMovementReportProperties/ns0:LanguageCode/@Domain) }">{ data($ProductMovementReportProperties/ns0:LanguageCode) }</ns1:LanguageCode>
                                    {
                                        for $MarketPlaceInformation in $ProductMovementReportProperties/ns0:MarketPlaceInformation
                                        return
                                            <ns1:MarketPlaceInformation>
                                                <ns1:MarketPlaceIdentifier>{ data($MarketPlaceInformation/ns0:MarketPlaceIdentifier) }</ns1:MarketPlaceIdentifier>
                                                <ns1:MarketPlaceDocumentReference ReferenceType = "{ data($MarketPlaceInformation/ns0:MarketPlaceDocumentReference/@ReferenceType) }">
                                                    <ns1:DocumentReference>
                                                        <ns1:DocumentIdentifier>{ data($MarketPlaceInformation/ns0:MarketPlaceDocumentReference/ns0:DocumentReference/ns0:DocumentIdentifier) }</ns1:DocumentIdentifier>
                                                        {
                                                            for $DateTime in $MarketPlaceInformation/ns0:MarketPlaceDocumentReference/ns0:DocumentReference/ns0:DateTime
                                                            return
                                                                <ns1:DateTime DateTimeQualifier = "{ data($DateTime/@DateTimeQualifier) }"/>
                                                        }
                                                        {
                                                            for $ReferenceItem in $MarketPlaceInformation/ns0:MarketPlaceDocumentReference/ns0:DocumentReference/ns0:ReferenceItem
                                                            return
                                                                <ns1:ReferenceItem>{ data($ReferenceItem) }</ns1:ReferenceItem>
                                                        }
                                                        {
                                                            for $ReleaseNumber in $MarketPlaceInformation/ns0:MarketPlaceDocumentReference/ns0:DocumentReference/ns0:ReleaseNumber
                                                            return
                                                                <ns1:ReleaseNumber>{ data($ReleaseNumber) }</ns1:ReleaseNumber>
                                                        }
                                                    </ns1:DocumentReference>
                                                </ns1:MarketPlaceDocumentReference>
                                                <ns1:MarketPlaceSellerIdentifier>{ data($MarketPlaceInformation/ns0:MarketPlaceSellerIdentifier) }</ns1:MarketPlaceSellerIdentifier>
                                                <ns1:MarketPlaceBuyerIdentifier>{ data($MarketPlaceInformation/ns0:MarketPlaceBuyerIdentifier) }</ns1:MarketPlaceBuyerIdentifier>
                                            </ns1:MarketPlaceInformation>
                                    }
                                </ns1:ProductMovementReportProperties>
                        }
                        {
                            for $ProductMovementReportDetails in $ProductMovementReportBody/ns0:ProductMovementReportDetails
                            return
                                <ns1:ProductMovementReportDetails>
                                    <ns1:ReportingEntity>
                                        <ns1:PartnerInformation>
                                            {
                                                for $PartnerName in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:PartnerName
                                                return
                                                    <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                            }
                                            <ns1:PartnerIdentifier Agency = "{ data($ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                            {
                                                for $ContactInformation in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:ContactInformation
                                                return
                                                    <ns1:ContactInformation>
                                                        {
                                                            for $ContactName in $ContactInformation/ns0:ContactName
                                                            return
                                                                <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                                        }
                                                        {
                                                            for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                            return
                                                                <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                                        }
                                                        {
                                                            for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                            return
                                                                <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                                        }
                                                        {
                                                            for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                            return
                                                                <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                                        }
                                                        {
                                                            for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                            return
                                                                <ns1:AlternativeCommunicationMethod>{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                                        }
                                                    </ns1:ContactInformation>
                                            }
                                            {
                                                for $AddressInformation in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:AddressInformation
                                                return
                                                    <ns1:AddressInformation>
                                                        <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                                        {
                                                            for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                            return
                                                                <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                                        }
                                                        {
                                                            for $PostalCode in $AddressInformation/ns0:PostalCode
                                                            return
                                                                <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                                        }
                                                        <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                                        {
                                                            for $LocationCode in $AddressInformation/ns0:LocationCode
                                                            return
                                                                <ns1:LocationCode>{ data($LocationCode) }</ns1:LocationCode>
                                                        }
                                                        {
                                                            for $Comment in $AddressInformation/ns0:Comment
                                                            return
                                                                <ns1:Comment/>
                                                        }
                                                    </ns1:AddressInformation>
                                            }
                                            {
                                                for $TaxInformation in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:TaxInformation
                                                return
                                                    <ns1:TaxInformation>
                                                        <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                                        {
                                                            for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                            return
                                                                <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                                        }
                                                        {
                                                            for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                            return
                                                                <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                                        }
                                                        {
                                                            for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                            return
                                                                <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                                        }
                                                        {
                                                            for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                            return
                                                                <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                                        }
                                                        {
                                                            for $TaxRate in $TaxInformation/ns0:TaxRate
                                                            return
                                                                <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                                        }
                                                        {
                                                            for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                            return
                                                                <ns1:EffectiveDates>
                                                                    {
                                                                        for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                                        return
                                                                            <ns1:DateTimeInformation/>
                                                                    }
                                                                </ns1:EffectiveDates>
                                                        }
                                                    </ns1:TaxInformation>
                                            }
                                            {
                                                for $URL in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:URL
                                                return
                                                    <ns1:URL>{ data($URL) }</ns1:URL>
                                            }
                                            {
                                                for $PartnerReference in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:PartnerReference
                                                return
                                                    <ns1:PartnerReference>
                                                        <ns1:PartnerIdentifier>{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                                    </ns1:PartnerReference>
                                            }
                                            {
                                                for $LoadingPoint in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:LoadingPoint
                                                return
                                                    <ns1:LoadingPoint/>
                                            }
                                            {
                                                for $UnloadingPoint in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:UnloadingPoint
                                                return
                                                    <ns1:UnloadingPoint/>
                                            }
                                            {
                                                for $AccountInformation in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:PartnerInformation/ns0:AccountInformation
                                                return
                                                    <ns1:AccountInformation>
                                                        {
                                                            for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                            return
                                                                <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                                        }
                                                    </ns1:AccountInformation>
                                            }
                                        </ns1:PartnerInformation>
                                        {
                                            for $ReferenceInformation in $ProductMovementReportDetails/ns0:ReportingEntity/ns0:ReferenceInformation
                                            return
                                                <ns1:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                                    <ns1:DocumentReference>
                                                        <ns1:DocumentIdentifier>{ data($ReferenceInformation/ns0:DocumentReference/ns0:DocumentIdentifier) }</ns1:DocumentIdentifier>
                                                        {
                                                            for $DateTime in $ReferenceInformation/ns0:DocumentReference/ns0:DateTime
                                                            return
                                                                <ns1:DateTime/>
                                                        }
                                                        {
                                                            for $ReferenceItem in $ReferenceInformation/ns0:DocumentReference/ns0:ReferenceItem
                                                            return
                                                                <ns1:ReferenceItem>{ data($ReferenceItem) }</ns1:ReferenceItem>
                                                        }
                                                        {
                                                            for $ReleaseNumber in $ReferenceInformation/ns0:DocumentReference/ns0:ReleaseNumber
                                                            return
                                                                <ns1:ReleaseNumber>{ data($ReleaseNumber) }</ns1:ReleaseNumber>
                                                        }
                                                    </ns1:DocumentReference>
                                                </ns1:ReferenceInformation>
                                        }
                                    </ns1:ReportingEntity>
                                    <ns1:ProductMovementTransactions ProductMovementReportType = "{ data($ProductMovementReportDetails/ns0:ProductMovementTransactions/@ProductMovementReportType) }">
                                        {
                                            for $ProductMovementTransaction in $ProductMovementReportDetails/ns0:ProductMovementTransactions/ns0:ProductMovementTransaction
                                            return
                                                <ns1:ProductMovementTransaction>
                                                    <ns1:ProductMovementTransactionProperties ProductMovementType = "{ data($ProductMovementTransaction/ns0:ProductMovementTransactionProperties/@ProductMovementType) }"
                                                                                              SaleOrReturnType = "{ data($ProductMovementTransaction/ns0:ProductMovementTransactionProperties/@SaleOrReturnType) }">
                                                        {
                                                            for $ReferenceInformation in $ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:ReferenceInformation
                                                            return
                                                                <ns1:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                                                    <ns1:DocumentReference>
                                                                        <ns1:DocumentIdentifier>{ data($ReferenceInformation/ns0:DocumentReference/ns0:DocumentIdentifier) }</ns1:DocumentIdentifier>
                                                                        {
                                                                            for $DateTime in $ReferenceInformation/ns0:DocumentReference/ns0:DateTime
                                                                            return
                                                                                <ns1:DateTime/>
                                                                        }
                                                                        {
                                                                            for $ReferenceItem in $ReferenceInformation/ns0:DocumentReference/ns0:ReferenceItem
                                                                            return
                                                                                <ns1:ReferenceItem>{ data($ReferenceItem) }</ns1:ReferenceItem>
                                                                        }
                                                                        {
                                                                            for $ReleaseNumber in $ReferenceInformation/ns0:DocumentReference/ns0:ReleaseNumber
                                                                            return
                                                                                <ns1:ReleaseNumber>{ data($ReleaseNumber) }</ns1:ReleaseNumber>
                                                                        }
                                                                    </ns1:DocumentReference>
                                                                </ns1:ReferenceInformation>
                                                        }
                                                        {
                                                            for $EventDateTime in $ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:EventDateTime
                                                            return
                                                                <ns1:EventDateTime EventDateType = "{ data($EventDateTime/@EventDateType) }">
                                                                    <ns1:DateTime DateTimeQualifier = "{ data($EventDateTime/ns0:DateTime/@DateTimeQualifier) }">{$EventDateTime/ns0:DateTime/text()}</ns1:DateTime>
                                                                </ns1:EventDateTime>
                                                        }
                                                        <ns1:LanguageCode Domain = "{ data($ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:LanguageCode/@Domain) }">{ data($ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:LanguageCode) }</ns1:LanguageCode>
                                                        <ns1:CurrencyCode Domain = "{ data($ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:CurrencyCode/@Domain) }">{ data($ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:CurrencyCode) }</ns1:CurrencyCode>
                                                        {
                                                            for $InvoiceTotal in $ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:InvoiceTotal
                                                            return
                                                                <ns1:InvoiceTotal>
                                                                    <ns1:MonetaryAmount>
                                                                        <ns1:MonetaryValue>{ data($InvoiceTotal/ns0:MonetaryAmount/ns0:MonetaryValue) }</ns1:MonetaryValue>
                                                                        <ns1:CurrencyCode Domain = "{ data($InvoiceTotal/ns0:MonetaryAmount/ns0:CurrencyCode/@Domain) }">{ data($InvoiceTotal/ns0:MonetaryAmount/ns0:CurrencyCode) }</ns1:CurrencyCode>
                                                                    </ns1:MonetaryAmount>
                                                                </ns1:InvoiceTotal>
                                                        }
                                                        {
                                                            for $SpecialInstructions in $ProductMovementTransaction/ns0:ProductMovementTransactionProperties/ns0:SpecialInstructions
                                                            return
                                                                <ns1:SpecialInstructions InstructionType = "{ data($SpecialInstructions/@InstructionType) }">{ data($SpecialInstructions) }</ns1:SpecialInstructions>
                                                        }
                                                    </ns1:ProductMovementTransactionProperties>
                                                    <ns1:ProductMovementTransactionPartners>
                                                        <ns1:ShipTo>
                                                            <ns1:PartnerInformation>
                                                                {
                                                                    for $PartnerName in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:PartnerName
                                                                    return
                                                                        <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                                                }
                                                                <ns1:PartnerIdentifier Agency = "{ data($ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                                                {
                                                                    for $ContactInformation in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:ContactInformation
                                                                    return
                                                                        <ns1:ContactInformation>
                                                                            {
                                                                                for $ContactName in $ContactInformation/ns0:ContactName
                                                                                return
                                                                                    <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                                                            }
                                                                            {
                                                                                for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                                                return
                                                                                    <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                                                            }
                                                                            {
                                                                                for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                                                return
                                                                                    <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                                                            }
                                                                            {
                                                                                for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                                                return
                                                                                    <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                                                            }
                                                                            {
                                                                                for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                                                return
                                                                                    <ns1:AlternativeCommunicationMethod>{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                                                            }
                                                                        </ns1:ContactInformation>
                                                                }
                                                                {
                                                                    for $AddressInformation in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:AddressInformation
                                                                    return
                                                                        <ns1:AddressInformation>
                                                                            <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                                                            {
                                                                                for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                                                return
                                                                                    <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                                                            }
                                                                            {
                                                                                for $PostalCode in $AddressInformation/ns0:PostalCode
                                                                                return
                                                                                    <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                                                            }
                                                                            <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                                                            {
                                                                                for $LocationCode in $AddressInformation/ns0:LocationCode
                                                                                return
                                                                                    <ns1:LocationCode>{ data($LocationCode) }</ns1:LocationCode>
                                                                            }
                                                                            {
                                                                                for $Comment in $AddressInformation/ns0:Comment
                                                                                return
                                                                                    <ns1:Comment/>
                                                                            }
                                                                        </ns1:AddressInformation>
                                                                }
                                                                {
                                                                    for $TaxInformation in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:TaxInformation
                                                                    return
                                                                        <ns1:TaxInformation>
                                                                            <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                                                            {
                                                                                for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                                                return
                                                                                    <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                                                            }
                                                                            {
                                                                                for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                                                return
                                                                                    <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                                                            }
                                                                            {
                                                                                for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                                                return
                                                                                    <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                                                            }
                                                                            {
                                                                                for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                                                return
                                                                                    <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                                                            }
                                                                            {
                                                                                for $TaxRate in $TaxInformation/ns0:TaxRate
                                                                                return
                                                                                    <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                                                            }
                                                                            {
                                                                                for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                                                return
                                                                                    <ns1:EffectiveDates>
                                                                                        {
                                                                                            for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                                                            return
                                                                                                <ns1:DateTimeInformation/>
                                                                                        }
                                                                                    </ns1:EffectiveDates>
                                                                            }
                                                                        </ns1:TaxInformation>
                                                                }
                                                                {
                                                                    for $URL in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:URL
                                                                    return
                                                                        <ns1:URL>{ data($URL) }</ns1:URL>
                                                                }
                                                                {
                                                                    for $PartnerReference in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:PartnerReference
                                                                    return
                                                                        <ns1:PartnerReference>
                                                                            <ns1:PartnerIdentifier Agency = "{ data($PartnerReference/ns0:PartnerIdentifier/@Agency) }">{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                                                        </ns1:PartnerReference>
                                                                }
                                                                {
                                                                    for $LoadingPoint in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:LoadingPoint
                                                                    return
                                                                        <ns1:LoadingPoint/>
                                                                }
                                                                {
                                                                    for $UnloadingPoint in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:UnloadingPoint
                                                                    return
                                                                        <ns1:UnloadingPoint/>
                                                                }
                                                                {
                                                                    for $AccountInformation in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:ShipTo/ns0:PartnerInformation/ns0:AccountInformation
                                                                    return
                                                                        <ns1:AccountInformation>
                                                                            {
                                                                                for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                                                return
                                                                                    <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                                                            }
                                                                        </ns1:AccountInformation>
                                                                }
                                                            </ns1:PartnerInformation>
                                                        </ns1:ShipTo>
                                                        {
                                                            for $Splits in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:Splits
                                                            return
                                                                <ns1:Splits>
                                                                    {
                                                                        for $Split in $Splits/ns0:Split
                                                                        return
                                                                            <ns1:Split>
                                                                                <ns1:PartnerInformation>
                                                                                    {
                                                                                        for $PartnerName in $Split/ns0:PartnerInformation/ns0:PartnerName
                                                                                        return
                                                                                            <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                                                                    }
                                                                                    <ns1:PartnerIdentifier>{ data($Split/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                                                                    {
                                                                                        for $ContactInformation in $Split/ns0:PartnerInformation/ns0:ContactInformation
                                                                                        return
                                                                                            <ns1:ContactInformation>
                                                                                                {
                                                                                                    for $ContactName in $ContactInformation/ns0:ContactName
                                                                                                    return
                                                                                                        <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                                                                                }
                                                                                                {
                                                                                                    for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                                                                    return
                                                                                                        <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                                                                                }
                                                                                                {
                                                                                                    for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                                                                    return
                                                                                                        <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                                                                                }
                                                                                                {
                                                                                                    for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                                                                    return
                                                                                                        <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                                                                                }
                                                                                                {
                                                                                                    for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                                                                    return
                                                                                                        <ns1:AlternativeCommunicationMethod>{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                                                                                }
                                                                                            </ns1:ContactInformation>
                                                                                    }
                                                                                    {
                                                                                        for $AddressInformation in $Split/ns0:PartnerInformation/ns0:AddressInformation
                                                                                        return
                                                                                            <ns1:AddressInformation>
                                                                                                <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                                                                                {
                                                                                                    for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                                                                    return
                                                                                                        <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                                                                                }
                                                                                                {
                                                                                                    for $PostalCode in $AddressInformation/ns0:PostalCode
                                                                                                    return
                                                                                                        <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                                                                                }
                                                                                                <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                                                                                {
                                                                                                    for $LocationCode in $AddressInformation/ns0:LocationCode
                                                                                                    return
                                                                                                        <ns1:LocationCode>{ data($LocationCode) }</ns1:LocationCode>
                                                                                                }
                                                                                                {
                                                                                                    for $Comment in $AddressInformation/ns0:Comment
                                                                                                    return
                                                                                                        <ns1:Comment/>
                                                                                                }
                                                                                            </ns1:AddressInformation>
                                                                                    }
                                                                                    {
                                                                                        for $TaxInformation in $Split/ns0:PartnerInformation/ns0:TaxInformation
                                                                                        return
                                                                                            <ns1:TaxInformation>
                                                                                                <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                                                                                {
                                                                                                    for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                                                                    return
                                                                                                        <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                                                                                }
                                                                                                {
                                                                                                    for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                                                                    return
                                                                                                        <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                                                                                }
                                                                                                {
                                                                                                    for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                                                                    return
                                                                                                        <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                                                                                }
                                                                                                {
                                                                                                    for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                                                                    return
                                                                                                        <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                                                                                }
                                                                                                {
                                                                                                    for $TaxRate in $TaxInformation/ns0:TaxRate
                                                                                                    return
                                                                                                        <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                                                                                }
                                                                                                {
                                                                                                    for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                                                                    return
                                                                                                        <ns1:EffectiveDates>
                                                                                                            {
                                                                                                                for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                                                                                return
                                                                                                                    <ns1:DateTimeInformation/>
                                                                                                            }
                                                                                                        </ns1:EffectiveDates>
                                                                                                }
                                                                                            </ns1:TaxInformation>
                                                                                    }
                                                                                    {
                                                                                        for $URL in $Split/ns0:PartnerInformation/ns0:URL
                                                                                        return
                                                                                            <ns1:URL>{ data($URL) }</ns1:URL>
                                                                                    }
                                                                                    {
                                                                                        for $PartnerReference in $Split/ns0:PartnerInformation/ns0:PartnerReference
                                                                                        return
                                                                                            <ns1:PartnerReference>
                                                                                                <ns1:PartnerIdentifier>{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                                                                            </ns1:PartnerReference>
                                                                                    }
                                                                                    {
                                                                                        for $LoadingPoint in $Split/ns0:PartnerInformation/ns0:LoadingPoint
                                                                                        return
                                                                                            <ns1:LoadingPoint/>
                                                                                    }
                                                                                    {
                                                                                        for $UnloadingPoint in $Split/ns0:PartnerInformation/ns0:UnloadingPoint
                                                                                        return
                                                                                            <ns1:UnloadingPoint/>
                                                                                    }
                                                                                    {
                                                                                        for $AccountInformation in $Split/ns0:PartnerInformation/ns0:AccountInformation
                                                                                        return
                                                                                            <ns1:AccountInformation>
                                                                                                {
                                                                                                    for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                                                                    return
                                                                                                        <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                                                                                }
                                                                                            </ns1:AccountInformation>
                                                                                    }
                                                                                </ns1:PartnerInformation>
                                                                                <ns1:SplitFactor>{ data($Split/ns0:SplitFactor) }</ns1:SplitFactor>
                                                                            </ns1:Split>
                                                                    }
                                                                </ns1:Splits>
                                                        }
                                                        {
                                                            for $OtherPartner in $ProductMovementTransaction/ns0:ProductMovementTransactionPartners/ns0:OtherPartner
                                                            return
                                                                <ns1:OtherPartner PartnerRole = "{ data($OtherPartner/@PartnerRole) }">
                                                                    <ns1:PartnerInformation>
                                                                        {
                                                                            for $PartnerName in $OtherPartner/ns0:PartnerInformation/ns0:PartnerName
                                                                            return
                                                                                <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                                                        }
                                                                        <ns1:PartnerIdentifier Agency = "{ data($OtherPartner/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($OtherPartner/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                                                        {
                                                                            for $ContactInformation in $OtherPartner/ns0:PartnerInformation/ns0:ContactInformation
                                                                            return
                                                                                <ns1:ContactInformation>
                                                                                    {
                                                                                        for $ContactName in $ContactInformation/ns0:ContactName
                                                                                        return
                                                                                            <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                                                                    }
                                                                                    {
                                                                                        for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                                                        return
                                                                                            <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                                                                    }
                                                                                    {
                                                                                        for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                                                        return
                                                                                            <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                                                                    }
                                                                                    {
                                                                                        for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                                                        return
                                                                                            <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                                                                    }
                                                                                    {
                                                                                        for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                                                        return
                                                                                            <ns1:AlternativeCommunicationMethod>{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                                                                    }
                                                                                </ns1:ContactInformation>
                                                                        }
                                                                        {
                                                                            for $AddressInformation in $OtherPartner/ns0:PartnerInformation/ns0:AddressInformation
                                                                            return
                                                                                <ns1:AddressInformation>
                                                                                    <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                                                                    {
                                                                                        for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                                                        return
                                                                                            <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                                                                    }
                                                                                    {
                                                                                        for $PostalCode in $AddressInformation/ns0:PostalCode
                                                                                        return
                                                                                            <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                                                                    }
                                                                                    <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                                                                    {
                                                                                        for $LocationCode in $AddressInformation/ns0:LocationCode
                                                                                        return
                                                                                            <ns1:LocationCode>{ data($LocationCode) }</ns1:LocationCode>
                                                                                    }
                                                                                    {
                                                                                        for $Comment in $AddressInformation/ns0:Comment
                                                                                        return
                                                                                            <ns1:Comment/>
                                                                                    }
                                                                                </ns1:AddressInformation>
                                                                        }
                                                                        {
                                                                            for $TaxInformation in $OtherPartner/ns0:PartnerInformation/ns0:TaxInformation
                                                                            return
                                                                                <ns1:TaxInformation>
                                                                                    <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                                                                    {
                                                                                        for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                                                        return
                                                                                            <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                                                                    }
                                                                                    {
                                                                                        for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                                                        return
                                                                                            <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                                                                    }
                                                                                    {
                                                                                        for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                                                        return
                                                                                            <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                                                                    }
                                                                                    {
                                                                                        for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                                                        return
                                                                                            <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                                                                    }
                                                                                    {
                                                                                        for $TaxRate in $TaxInformation/ns0:TaxRate
                                                                                        return
                                                                                            <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                                                                    }
                                                                                    {
                                                                                        for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                                                        return
                                                                                            <ns1:EffectiveDates>
                                                                                                {
                                                                                                    for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                                                                    return
                                                                                                        <ns1:DateTimeInformation/>
                                                                                                }
                                                                                            </ns1:EffectiveDates>
                                                                                    }
                                                                                </ns1:TaxInformation>
                                                                        }
                                                                        {
                                                                            for $URL in $OtherPartner/ns0:PartnerInformation/ns0:URL
                                                                            return
                                                                                <ns1:URL>{ data($URL) }</ns1:URL>
                                                                        }
                                                                        {
                                                                            for $PartnerReference in $OtherPartner/ns0:PartnerInformation/ns0:PartnerReference
                                                                            return
                                                                                <ns1:PartnerReference>
                                                                                    <ns1:PartnerIdentifier>{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                                                                </ns1:PartnerReference>
                                                                        }
                                                                        {
                                                                            for $LoadingPoint in $OtherPartner/ns0:PartnerInformation/ns0:LoadingPoint
                                                                            return
                                                                                <ns1:LoadingPoint/>
                                                                        }
                                                                        {
                                                                            for $UnloadingPoint in $OtherPartner/ns0:PartnerInformation/ns0:UnloadingPoint
                                                                            return
                                                                                <ns1:UnloadingPoint/>
                                                                        }
                                                                        {
                                                                            for $AccountInformation in $OtherPartner/ns0:PartnerInformation/ns0:AccountInformation
                                                                            return
                                                                                <ns1:AccountInformation>
                                                                                    {
                                                                                        for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                                                        return
                                                                                            <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                                                                    }
                                                                                </ns1:AccountInformation>
                                                                        }
                                                                    </ns1:PartnerInformation>
                                                                </ns1:OtherPartner>
                                                        }
                                                    </ns1:ProductMovementTransactionPartners>
                                                    <ns1:ProductMovementTransactionDetails>
                                                        {
                                                            for $ProductMovementProductLineItem in $ProductMovementTransaction/ns0:ProductMovementTransactionDetails/ns0:ProductMovementProductLineItem
                                                            return
                                                                <ns1:ProductMovementProductLineItem>
                                                                    <ns1:LineNumber>{ data($ProductMovementProductLineItem/ns0:LineNumber) }</ns1:LineNumber>
                                                                    {
                                                                        for $ReferenceInformation in $ProductMovementProductLineItem/ns0:ReferenceInformation
                                                                        return
                                                                            <ns1:ReferenceInformation ReferenceType = "{ data($ReferenceInformation/@ReferenceType) }">
                                                                                <ns1:DocumentReference>
                                                                                    <ns1:DocumentIdentifier>{ data($ReferenceInformation/ns0:DocumentReference/ns0:DocumentIdentifier) }</ns1:DocumentIdentifier>
                                                                                    {
                                                                                        for $DateTime in $ReferenceInformation/ns0:DocumentReference/ns0:DateTime
                                                                                        return
                                                                                            <ns1:DateTime/>
                                                                                    }
                                                                                    {
                                                                                        for $ReferenceItem in $ReferenceInformation/ns0:DocumentReference/ns0:ReferenceItem
                                                                                        return
                                                                                            <ns1:ReferenceItem>{ data($ReferenceItem) }</ns1:ReferenceItem>
                                                                                    }
                                                                                    {
                                                                                        for $ReleaseNumber in $ReferenceInformation/ns0:DocumentReference/ns0:ReleaseNumber
                                                                                        return
                                                                                            <ns1:ReleaseNumber>{ data($ReleaseNumber) }</ns1:ReleaseNumber>
                                                                                    }
                                                                                </ns1:DocumentReference>
                                                                            </ns1:ReferenceInformation>
                                                                    }
                                                                    {
                                                                        for $ProductIdentification in $ProductMovementProductLineItem/ns0:ProductIdentification
                                                                        return
                                                                            <ns1:ProductIdentification>
                                                                                <ns1:ProductIdentifier Agency = "{ data($ProductIdentification/ns0:ProductIdentifier/@Agency) }">{ data($ProductIdentification/ns0:ProductIdentifier) }</ns1:ProductIdentifier>
                                                                                {
                                                                                    for $ProductName in $ProductIdentification/ns0:ProductName
                                                                                    return
                                                                                        <ns1:ProductName>{ data($ProductName) }</ns1:ProductName>
                                                                                }
                                                                                {
                                                                                    for $Trademark in $ProductIdentification/ns0:Trademark
                                                                                    return
                                                                                        <ns1:Trademark>{ data($Trademark) }</ns1:Trademark>
                                                                                }
                                                                                {
                                                                                    for $ProductDescription in $ProductIdentification/ns0:ProductDescription
                                                                                    return
                                                                                        <ns1:ProductDescription>{ data($ProductDescription) }</ns1:ProductDescription>
                                                                                }
                                                                                {
                                                                                    for $ProductGradeDescription in $ProductIdentification/ns0:ProductGradeDescription
                                                                                    return
                                                                                        <ns1:ProductGradeDescription>{ data($ProductGradeDescription) }</ns1:ProductGradeDescription>
                                                                                }
                                                                                {
                                                                                    for $ProductClassification in $ProductIdentification/ns0:ProductClassification
                                                                                    return
                                                                                        <ns1:ProductClassification>{ data($ProductClassification) }</ns1:ProductClassification>
                                                                                }
                                                                            </ns1:ProductIdentification>
                                                                    }
                                                                    <ns1:ProductQuantity>
                                                                        <ns1:Measurement>
                                                                            <ns1:MeasurementValue>{ data($ProductMovementProductLineItem/ns0:ProductQuantity/ns0:Measurement/ns0:MeasurementValue) }</ns1:MeasurementValue>
                                                                            <ns1:UnitOfMeasureCode Domain = "{ data($ProductMovementProductLineItem/ns0:ProductQuantity/ns0:Measurement/ns0:UnitOfMeasureCode/@Domain) }">{ data($ProductMovementProductLineItem/ns0:ProductQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) }</ns1:UnitOfMeasureCode>
                                                                        </ns1:Measurement>
                                                                    </ns1:ProductQuantity>
                                                                    {
                                                                        for $Splits in $ProductMovementProductLineItem/ns0:Splits
                                                                        return
                                                                            <ns1:Splits>
                                                                                {
                                                                                    for $Split in $Splits/ns0:Split
                                                                                    return
                                                                                        <ns1:Split>
                                                                                            <ns1:PartnerInformation>
                                                                                                {
                                                                                                    for $PartnerName in $Split/ns0:PartnerInformation/ns0:PartnerName
                                                                                                    return
                                                                                                        <ns1:PartnerName>{ data($PartnerName) }</ns1:PartnerName>
                                                                                                }
                                                                                                <ns1:PartnerIdentifier>{ data($Split/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns1:PartnerIdentifier>
                                                                                                {
                                                                                                    for $ContactInformation in $Split/ns0:PartnerInformation/ns0:ContactInformation
                                                                                                    return
                                                                                                        <ns1:ContactInformation>
                                                                                                            {
                                                                                                                for $ContactName in $ContactInformation/ns0:ContactName
                                                                                                                return
                                                                                                                    <ns1:ContactName>{ data($ContactName) }</ns1:ContactName>
                                                                                                            }
                                                                                                            {
                                                                                                                for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                                                                                                return
                                                                                                                    <ns1:ContactDescription>{ data($ContactDescription) }</ns1:ContactDescription>
                                                                                                            }
                                                                                                            {
                                                                                                                for $ContactNumber in $ContactInformation/ns0:ContactNumber
                                                                                                                return
                                                                                                                    <ns1:ContactNumber>{ data($ContactNumber) }</ns1:ContactNumber>
                                                                                                            }
                                                                                                            {
                                                                                                                for $EmailAddress in $ContactInformation/ns0:EmailAddress
                                                                                                                return
                                                                                                                    <ns1:EmailAddress>{ data($EmailAddress) }</ns1:EmailAddress>
                                                                                                            }
                                                                                                            {
                                                                                                                for $AlternativeCommunicationMethod in $ContactInformation/ns0:AlternativeCommunicationMethod
                                                                                                                return
                                                                                                                    <ns1:AlternativeCommunicationMethod>{ data($AlternativeCommunicationMethod) }</ns1:AlternativeCommunicationMethod>
                                                                                                            }
                                                                                                        </ns1:ContactInformation>
                                                                                                }
                                                                                                {
                                                                                                    for $AddressInformation in $Split/ns0:PartnerInformation/ns0:AddressInformation
                                                                                                    return
                                                                                                        <ns1:AddressInformation>
                                                                                                            <ns1:CityName>{ data($AddressInformation/ns0:CityName) }</ns1:CityName>
                                                                                                            {
                                                                                                                for $StateOrProvince in $AddressInformation/ns0:StateOrProvince
                                                                                                                return
                                                                                                                    <ns1:StateOrProvince>{ data($StateOrProvince) }</ns1:StateOrProvince>
                                                                                                            }
                                                                                                            {
                                                                                                                for $PostalCode in $AddressInformation/ns0:PostalCode
                                                                                                                return
                                                                                                                    <ns1:PostalCode>{ data($PostalCode) }</ns1:PostalCode>
                                                                                                            }
                                                                                                            <ns1:PostalCountry>{ data($AddressInformation/ns0:PostalCountry) }</ns1:PostalCountry>
                                                                                                            {
                                                                                                                for $LocationCode in $AddressInformation/ns0:LocationCode
                                                                                                                return
                                                                                                                    <ns1:LocationCode>{ data($LocationCode) }</ns1:LocationCode>
                                                                                                            }
                                                                                                            {
                                                                                                                for $Comment in $AddressInformation/ns0:Comment
                                                                                                                return
                                                                                                                    <ns1:Comment/>
                                                                                                            }
                                                                                                        </ns1:AddressInformation>
                                                                                                }
                                                                                                {
                                                                                                    for $TaxInformation in $Split/ns0:PartnerInformation/ns0:TaxInformation
                                                                                                    return
                                                                                                        <ns1:TaxInformation>
                                                                                                            <ns1:TaxIdentifierNumber>{ data($TaxInformation/ns0:TaxIdentifierNumber) }</ns1:TaxIdentifierNumber>
                                                                                                            {
                                                                                                                for $Jurisdiction in $TaxInformation/ns0:Jurisdiction
                                                                                                                return
                                                                                                                    <ns1:Jurisdiction>{ data($Jurisdiction) }</ns1:Jurisdiction>
                                                                                                            }
                                                                                                            {
                                                                                                                for $TaxCertificateType in $TaxInformation/ns0:TaxCertificateType
                                                                                                                return
                                                                                                                    <ns1:TaxCertificateType>{ data($TaxCertificateType) }</ns1:TaxCertificateType>
                                                                                                            }
                                                                                                            {
                                                                                                                for $TaxCertificateNumber in $TaxInformation/ns0:TaxCertificateNumber
                                                                                                                return
                                                                                                                    <ns1:TaxCertificateNumber>{ data($TaxCertificateNumber) }</ns1:TaxCertificateNumber>
                                                                                                            }
                                                                                                            {
                                                                                                                for $TaxBasis in $TaxInformation/ns0:TaxBasis
                                                                                                                return
                                                                                                                    <ns1:TaxBasis>{ data($TaxBasis) }</ns1:TaxBasis>
                                                                                                            }
                                                                                                            {
                                                                                                                for $TaxRate in $TaxInformation/ns0:TaxRate
                                                                                                                return
                                                                                                                    <ns1:TaxRate>{ data($TaxRate) }</ns1:TaxRate>
                                                                                                            }
                                                                                                            {
                                                                                                                for $EffectiveDates in $TaxInformation/ns0:EffectiveDates
                                                                                                                return
                                                                                                                    <ns1:EffectiveDates>
                                                                                                                        {
                                                                                                                            for $DateTimeInformation in $EffectiveDates/ns0:DateTimeInformation
                                                                                                                            return
                                                                                                                                <ns1:DateTimeInformation/>
                                                                                                                        }
                                                                                                                    </ns1:EffectiveDates>
                                                                                                            }
                                                                                                        </ns1:TaxInformation>
                                                                                                }
                                                                                                {
                                                                                                    for $URL in $Split/ns0:PartnerInformation/ns0:URL
                                                                                                    return
                                                                                                        <ns1:URL>{ data($URL) }</ns1:URL>
                                                                                                }
                                                                                                {
                                                                                                    for $PartnerReference in $Split/ns0:PartnerInformation/ns0:PartnerReference
                                                                                                    return
                                                                                                        <ns1:PartnerReference>
                                                                                                            <ns1:PartnerIdentifier>{ data($PartnerReference/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
                                                                                                        </ns1:PartnerReference>
                                                                                                }
                                                                                                {
                                                                                                    for $LoadingPoint in $Split/ns0:PartnerInformation/ns0:LoadingPoint
                                                                                                    return
                                                                                                        <ns1:LoadingPoint/>
                                                                                                }
                                                                                                {
                                                                                                    for $UnloadingPoint in $Split/ns0:PartnerInformation/ns0:UnloadingPoint
                                                                                                    return
                                                                                                        <ns1:UnloadingPoint/>
                                                                                                }
                                                                                                {
                                                                                                    for $AccountInformation in $Split/ns0:PartnerInformation/ns0:AccountInformation
                                                                                                    return
                                                                                                        <ns1:AccountInformation>
                                                                                                            {
                                                                                                                for $AccountHolderName in $AccountInformation/ns0:AccountHolderName
                                                                                                                return
                                                                                                                    <ns1:AccountHolderName>{ data($AccountHolderName) }</ns1:AccountHolderName>
                                                                                                            }
                                                                                                        </ns1:AccountInformation>
                                                                                                }
                                                                                            </ns1:PartnerInformation>
                                                                                            <ns1:SplitFactor>{ data($Split/ns0:SplitFactor) }</ns1:SplitFactor>
                                                                                        </ns1:Split>
                                                                                }
                                                                            </ns1:Splits>
                                                                    }
                                                                    {
                                                                        for $PackagingQuantity in $ProductMovementProductLineItem/ns0:PackagingQuantity
                                                                        return
                                                                            <ns1:PackagingQuantity>
                                                                                <ns1:Measurement>
                                                                                    <ns1:MeasurementValue>{ data($PackagingQuantity/ns0:Measurement/ns0:MeasurementValue) }</ns1:MeasurementValue>
                                                                                    <ns1:UnitOfMeasureCode>{ data($PackagingQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) }</ns1:UnitOfMeasureCode>
                                                                                </ns1:Measurement>
                                                                            </ns1:PackagingQuantity>
                                                                    }
                                                                    {
                                                                        for $ConfirmedPrice in $ProductMovementProductLineItem/ns0:ConfirmedPrice
                                                                        return
                                                                            <ns1:ConfirmedPrice>
                                                                                {
                                                                                    for $Pricing in $ConfirmedPrice/ns0:Pricing
                                                                                    return
                                                                                        <ns1:Pricing PriceType = "{ data($Pricing/@PriceType) }">
                                                                                            {
                                                                                                let $PricingLumpSum := $Pricing/ns0:PricingLumpSum
                                                                                                return
                                                                                                    <ns1:PricingLumpSum>
                                                                                                        <ns1:MonetaryAmount>
                                                                                                            <ns1:MonetaryValue>{ data($PricingLumpSum/ns0:MonetaryAmount/ns0:MonetaryValue) }</ns1:MonetaryValue>
                                                                                                            <ns1:CurrencyCode Domain = "{ data($PricingLumpSum/ns0:MonetaryAmount/ns0:CurrencyCode/@Domain) }">{ data($PricingLumpSum/ns0:MonetaryAmount/ns0:CurrencyCode) }</ns1:CurrencyCode>
                                                                                                        </ns1:MonetaryAmount>
                                                                                                    </ns1:PricingLumpSum>
                                                                                            }
                                                                                            {
                                                                                                for $PriceReason in $Pricing/ns0:PriceReason
                                                                                                return
                                                                                                    <ns1:PriceReason>{ data($PriceReason) }</ns1:PriceReason>
                                                                                            }
                                                                                        </ns1:Pricing>
                                                                                }
                                                                            </ns1:ConfirmedPrice>
                                                                    }
                                                                    {
                                                                        for $Characteristic in $ProductMovementProductLineItem/ns0:Characteristic
                                                                        return
                                                                            <ns1:Characteristic>
                                                                                {
                                                                                    for $CharacteristicCode in $Characteristic/ns0:CharacteristicCode
                                                                                    return
                                                                                        <ns1:CharacteristicCode Domain = "{ data($CharacteristicCode/@Domain) }">{ data($CharacteristicCode) }</ns1:CharacteristicCode>
                                                                                }
                                                                                {
                                                                                    for $CharacteristicDescription in $Characteristic/ns0:CharacteristicDescription
                                                                                    return
                                                                                        <ns1:CharacteristicDescription>{ data($CharacteristicDescription) }</ns1:CharacteristicDescription>
                                                                                }
                                                                                {
                                                                                    for $SurfaceLayerPositionCode in $Characteristic/ns0:SurfaceLayerPositionCode
                                                                                    return
                                                                                        <ns1:SurfaceLayerPositionCode>{ data($SurfaceLayerPositionCode) }</ns1:SurfaceLayerPositionCode>
                                                                                }
                                                                                {
                                                                                    for $SourceSubqualifier in $Characteristic/ns0:SourceSubqualifier
                                                                                    return
                                                                                        <ns1:SourceSubqualifier>{ data($SourceSubqualifier) }</ns1:SourceSubqualifier>
                                                                                }
                                                                            </ns1:Characteristic>
                                                                    }
                                                                    {
                                                                        for $BatchNumbers in $ProductMovementProductLineItem/ns0:BatchNumbers
                                                                        return
                                                                            <ns1:BatchNumbers>
                                                                                <ns1:Measurement>
                                                                                    <ns1:MeasurementValue>{ data($BatchNumbers/ns0:Measurement/ns0:MeasurementValue) }</ns1:MeasurementValue>
                                                                                    <ns1:UnitOfMeasureCode>{ data($BatchNumbers/ns0:Measurement/ns0:UnitOfMeasureCode) }</ns1:UnitOfMeasureCode>
                                                                                </ns1:Measurement>
                                                                                <ns1:BatchNumber BatchNumberCreator = "{ data($BatchNumbers/ns0:BatchNumber/@BatchNumberCreator) }">{ data($BatchNumbers/ns0:BatchNumber) }</ns1:BatchNumber>
                                                                            </ns1:BatchNumbers>
                                                                    }
                                                                    {
                                                                        for $SerialNumbers in $ProductMovementProductLineItem/ns0:SerialNumbers
                                                                        return
                                                                            <ns1:SerialNumbers>
                                                                                <ns1:Measurement>
                                                                                    <ns1:MeasurementValue>{ data($SerialNumbers/ns0:Measurement/ns0:MeasurementValue) }</ns1:MeasurementValue>
                                                                                    <ns1:UnitOfMeasureCode>{ data($SerialNumbers/ns0:Measurement/ns0:UnitOfMeasureCode) }</ns1:UnitOfMeasureCode>
                                                                                </ns1:Measurement>
                                                                                <ns1:SerialNumber>{ data($SerialNumbers/ns0:SerialNumber) }</ns1:SerialNumber>
                                                                            </ns1:SerialNumbers>
                                                                    }
                                                                    {
                                                                        for $PackagingContainerInformation in $ProductMovementProductLineItem/ns0:PackagingContainerInformation
                                                                        return
                                                                            <ns1:PackagingContainerInformation>
                                                                                <ns1:ContainerType>{ data($PackagingContainerInformation/ns0:ContainerType) }</ns1:ContainerType>
                                                                                {
                                                                                    for $ContainerDescription in $PackagingContainerInformation/ns0:ContainerDescription
                                                                                    return
                                                                                        <ns1:ContainerDescription>{ data($ContainerDescription) }</ns1:ContainerDescription>
                                                                                }
                                                                                {
                                                                                    for $ContainerIdentifier in $PackagingContainerInformation/ns0:ContainerIdentifier
                                                                                    return
                                                                                        <ns1:ContainerIdentifier Agency = "{ data($ContainerIdentifier/@Agency) }">{ data($ContainerIdentifier) }</ns1:ContainerIdentifier>
                                                                                }
                                                                            </ns1:PackagingContainerInformation>
                                                                    }
                                                                    {
                                                                        for $CountryOfOrginCode in $ProductMovementProductLineItem/ns0:CountryOfOrginCode
                                                                        return
                                                                            <ns1:CountryOfOrginCode Domain = "{ data($CountryOfOrginCode/@Domain) }">{ data($CountryOfOrginCode) }</ns1:CountryOfOrginCode>
                                                                    }
                                                                    {
                                                                        for $SpecialInstructions in $ProductMovementProductLineItem/ns0:SpecialInstructions
                                                                        return
                                                                            <ns1:SpecialInstructions InstructionType = "{ data($SpecialInstructions/@InstructionType) }">{ data($SpecialInstructions) }</ns1:SpecialInstructions>
                                                                    }
                                                                </ns1:ProductMovementProductLineItem>
                                                        }
                                                    </ns1:ProductMovementTransactionDetails>
                                                </ns1:ProductMovementTransaction>
                                        }
                                    </ns1:ProductMovementTransactions>
                                </ns1:ProductMovementReportDetails>
                        }
                    </ns1:ProductMovementReportBody>
            }
        </ns1:ProductMovementReport>
};

declare variable $productMovementReport1 as element(ns0:ProductMovementReport) external;

xf:FPOS_5-0_To_FPOS_4-0($productMovementReport1)
