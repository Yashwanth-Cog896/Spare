<urn:versionResponse  xmlns:urn="urn:com:monsanto:usit:ifs:integrationPlatform:dataNotificationService">
    <urn:version>1.0</urn:version>
</urn:versionResponse>
