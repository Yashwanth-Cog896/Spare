<ns2:VistiveProcessorList xmlns:ns2="urn:ecms:schema:vistiveprocessorlist:1:0" xmlns="urn:cidx:names:specification:ces:schema:all:5:0">
	<Header>
		<ThisDocumentIdentifier>
			<DocumentIdentifier>FromUSCOM_TestHarness</DocumentIdentifier>
		</ThisDocumentIdentifier>
		<ThisDocumentDateTime>
			<DateTime>2010-09-08T09:14:44</DateTime>
		</ThisDocumentDateTime>
		<From>
			<PartnerInformation>
				<PartnerName>US Commercial Services Development Team</PartnerName>
				<ContactInformation>
					<EmailAddress>dl-1000-ISDTeam@monsanto.com</EmailAddress>
				</ContactInformation>
			</PartnerInformation>
		</From>
		<To>
			<PartnerInformation>
				<PartnerName>OKAW CROP CARE INC</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">1288770450000</PartnerIdentifier>
			</PartnerInformation>
		</To>
	</Header>
	<ns2:VistiveProcessorListBody>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>ADVANCED AGRI SOL OSGOOD OH</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">1396418070000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>17 MAIN ST</AddressLine>
					<CityName>OSGOOD</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>45351</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">17214</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-12T11:06:28</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
	</ns2:VistiveProcessorListBody>
</ns2:VistiveProcessorList>
