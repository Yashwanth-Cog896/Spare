<urn:assetAvailableResponse xmlns:urn="urn:com:monsanto:usit:ifs:integrationPlatform:dataNotificationService">
    <urn:requestStatus>SUCCESS</urn:requestStatus>
</urn:assetAvailableResponse>
