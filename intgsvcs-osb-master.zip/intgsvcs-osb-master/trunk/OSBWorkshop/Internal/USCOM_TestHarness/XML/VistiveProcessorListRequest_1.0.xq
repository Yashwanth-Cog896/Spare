<ns2:VistiveProcessorList xmlns:ns2="urn:ecms:schema:vistiveprocessorlist:1:0" xmlns="urn:cidx:names:specification:ces:schema:all:5:0">
	<Header>
		<ThisDocumentIdentifier>
			<DocumentIdentifier>FromUSCOM_TestHarness</DocumentIdentifier>
		</ThisDocumentIdentifier>
		<ThisDocumentDateTime>
			<DateTime>2010-09-08T09:14:44</DateTime>
		</ThisDocumentDateTime>
		<From>
			<PartnerInformation>
				<PartnerName>US Commercial Services Development Team</PartnerName>
				<ContactInformation>
					<EmailAddress>dl-1000-ISDTeam@monsanto.com</EmailAddress>
				</ContactInformation>
			</PartnerInformation>
		</From>
		<To>
			<PartnerInformation>
				<PartnerName>OKAW CROP CARE INC</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">1288770450000</PartnerIdentifier>
			</PartnerInformation>
		</To>
	</Header>
	<ns2:VistiveProcessorListBody>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>ADVANCED AGRI SOL OSGOOD OH</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">1396418070000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>17 MAIN ST</AddressLine>
					<CityName>OSGOOD</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>45351</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">17214</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-12T11:06:28</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>AG PARTNERS EMMETSBURG IA</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0379307810000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>1800 11TH ST</AddressLine>
					<CityName>EMMETSBURG</CityName>
					<StateOrProvince>IA</StateOrProvince>
					<PostalCode>50536</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">415144</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-10T11:44:37</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>ASHTABULA COUNTY JEFFERSON OH</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">9260386960000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>COURT HOUSE</AddressLine>
					<CityName>JEFFERSON</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>44047</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">2197</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-10T15:03:23</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>BUNGE NORTH AMERICA MARION OH</PartnerName>
				<AddressInformation>
					<AddressLine>RR 1</AddressLine>
					<CityName>MARION</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>43302</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">50346346</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2010-06-07T08:09:21</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>CARGILL INC SD  BLOOMINGTON IL</PartnerName>
				<AddressInformation>
					<AddressLine>2603 INTERLOCKEN DR</AddressLine>
					<CityName>BLOOMINGTON</CityName>
					<StateOrProvince>IL</StateOrProvince>
					<PostalCode>61704</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">49821</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-09-15T13:03:15</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>CARGILL W DES MOINE IA</PartnerName>
				<AddressInformation>
					<AddressLine>1415 28TH ST</AddressLine>
					<CityName>WEST DES MOINES</CityName>
					<StateOrProvince>IA</StateOrProvince>
					<PostalCode>50266</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">50402265</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2010-07-09T08:18:41</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>COOPERATIVE SUPPLY DODGE NE</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0827224140000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>239 FRONT ST</AddressLine>
					<CityName>DODGE</CityName>
					<StateOrProvince>NE</StateOrProvince>
					<PostalCode>68633</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">16245</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-12T11:04:51</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>FARMERS COOP AFTON IA</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0220014990000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>196 E RAILROAD ST</AddressLine>
					<CityName>AFTON</CityName>
					<StateOrProvince>IA</StateOrProvince>
					<PostalCode>50830</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">3144</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-12T11:09:26</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>FARMERS COOPERATIVE GRAFTON IA</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0221780810000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>208 3RD ST</AddressLine>
					<CityName>GRAFTON</CityName>
					<StateOrProvince>IA</StateOrProvince>
					<PostalCode>50440</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">50049455</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2010-05-25T16:15:09</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>HARVEST LAND COLLEGE CORNR OH</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0178708820000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>6505 COLLEGE CORNER PIKE</AddressLine>
					<CityName>COLLEGE CORNER</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>45003</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">2253</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-12T11:07:54</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>KAUP'S SEED &amp; FE WEST POINT NE</PartnerName>
				<AddressInformation>
					<AddressLine>1101 S BEEMER ST</AddressLine>
					<CityName>WEST POINT</CityName>
					<StateOrProvince>NE</StateOrProvince>
					<PostalCode>68788</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">881266</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-09-09T15:26:24</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>MERCER LANDMARK ROCKFORD OH</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0487877090000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>202 S MAIN ST</AddressLine>
					<CityName>ROCKFORD</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>45882</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">2336</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-01-08T09:29:34</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>MONSANTO VISTIV SAINT LOUIS MO</PartnerName>
				<AddressInformation>
					<AddressLine>800 N LINDBERGH BLVD</AddressLine>
					<CityName>SAINT LOUIS</CityName>
					<StateOrProvince>MO</StateOrProvince>
					<PostalCode>63167</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">50460463</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2010-08-12T13:47:56</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>PANDORA GRAIN PANDORA OH</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">1757982060000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>305 S JEFFERSON</AddressLine>
					<CityName>PANDORA</CityName>
					<StateOrProvince>OH</StateOrProvince>
					<PostalCode>45877</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">10634</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-08-12T11:08:41</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>SCRIBNER GRAIN SCRIBNER NE</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0519545920000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>PO BOX 289</AddressLine>
					<CityName>SCRIBNER</CityName>
					<StateOrProvince>NE</StateOrProvince>
					<PostalCode>68057</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">6032</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2010-04-14T10:01:20</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
		<ns2:VistiveProcessorEntity ActiveFlag="True">
			<PartnerInformation>
				<PartnerName>ZEELAND FARM SERV ZEELAND MI</PartnerName>
				<PartnerIdentifier Agency="AGIIS-EBID">0049514710000</PartnerIdentifier>
				<AddressInformation>
					<AddressLine>2468 84TH AVE</AddressLine>
					<CityName>ZEELAND</CityName>
					<StateOrProvince>MI</StateOrProvince>
					<PostalCode>49464</PostalCode>
				</AddressInformation>
				<PartnerReference>
					<PartnerIdentifier Agency="AssignedBySeller">9111</PartnerIdentifier>
				</PartnerReference>
			</PartnerInformation>
			<ns2:LastModifiedDateTime>2009-09-17T11:42:15</ns2:LastModifiedDateTime>
			<ns2:VistiveProcessorCode>VSSP</ns2:VistiveProcessorCode>
		</ns2:VistiveProcessorEntity>
	</ns2:VistiveProcessorListBody>
</ns2:VistiveProcessorList>
