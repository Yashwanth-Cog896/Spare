(:: pragma bea:global-element-parameter parameter="$y_SDSA_GET_LONGALERT_DATAResponse" element="ns1:Y_SDSA_GET_LONGALERT_DATAResponse" location="../WSDLs/LongAlertDataService_SAP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:LongShortResponse" location="../Schemas/LongShort.xsd" ::)

declare namespace ns1 = "urn:sap-com:document:sap:rfc:functions";
declare namespace ns0 = "mon:services:longshort";
declare namespace xf = "http://tempuri.org/US_SD_MyMon_Services/XQueryResources/LongAlertData_Response/";

declare function xf:LongAlertData_Response($y_SDSA_GET_LONGALERT_DATAResponse as element(ns1:Y_SDSA_GET_LONGALERT_DATAResponse))
    as element(ns0:LongShortResponse) {
        <ns0:LongShortResponse>
            {
                for $item in $y_SDSA_GET_LONGALERT_DATAResponse/ET_LONGALERT/item
                return
                    <ns0:LongShortEntry>
                        <ns0:PartnerId>{ data($item/YYKUNNR) }</ns0:PartnerId>
                        <ns0:ProductId>{ data($item/YYMATNR) }</ns0:ProductId>
                        <ns0:SeedYear>{ data($item/YYSEEDDYR) }</ns0:SeedYear>
                        <ns0:LongQty>{ data($item/YYLA_QTY) }</ns0:LongQty>
                        <ns0:UOM>{ data($item/YYVRKME) }</ns0:UOM>
                        <ns0:ProductDescription>{ data($item/YYMAKTX) }</ns0:ProductDescription>
                        <ns0:LastChangedBy>{ data($item/YYUPD_USER) }</ns0:LastChangedBy>
                        <ns0:LastChangedDate>{ data($item/YYUPD_DATE) }</ns0:LastChangedDate>
                        <ns0:LastChangedTime>{ data($item/YYUPD_TIME) }</ns0:LastChangedTime>
                        <ns0:TimeStamp>{ data($item/YYTIMESTAMP) }</ns0:TimeStamp>
                    </ns0:LongShortEntry>
            }
            {
                for $item in $y_SDSA_GET_LONGALERT_DATAResponse/ET_ERRORS/item
                return
                    <ns0:LongShortError>
                        <ns0:ErrorType>{ data($item/YYTYPE) }</ns0:ErrorType>
                        <ns0:ErrorMessageClass>{ data($item/YYID) }</ns0:ErrorMessageClass>
                        <ns0:ErrorMessageNumber>{ data($item/YYNUMBER) }</ns0:ErrorMessageNumber>
                        <ns0:ErrorMessageText>{ data($item/YYMESSAGE) }</ns0:ErrorMessageText>
                    </ns0:LongShortError>
            }
        </ns0:LongShortResponse>
};

declare variable $y_SDSA_GET_LONGALERT_DATAResponse as element(ns1:Y_SDSA_GET_LONGALERT_DATAResponse) external;

xf:LongAlertData_Response($y_SDSA_GET_LONGALERT_DATAResponse)
