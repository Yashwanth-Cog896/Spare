(:: pragma bea:global-element-parameter parameter="$longShortRequest" element="ns0:LongShortRequest" location="../Schemas/LongShort.xsd" ::)
(:: pragma bea:global-element-return element="ns2:Y_SDSA_GET_LONGALERT_DATA" location="../WSDLs/LongAlertDataService_SAP.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:rfc:functions";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "mon:services:longshort";
declare namespace xf = "http://tempuri.org/US_SD_MyMon_Services/XQueryResources/LongAlertData_Request/";

declare function xf:LongAlertData_Request($longShortRequest as element(ns0:LongShortRequest))
    as element(ns2:Y_SDSA_GET_LONGALERT_DATA) {
        <ns2:Y_SDSA_GET_LONGALERT_DATA>
            <YYKUNNR>
                {
                    for $SAPId in $longShortRequest/ns0:LongShortRequestDetails/ns0:SAPId
                    return
                        <item>{ data($SAPId) }</item>
                }
            </YYKUNNR>
            <YYSEEDDYR>{ data($longShortRequest/ns0:LongShortRequestDetails/ns0:SeedYear) }</YYSEEDDYR>
        </ns2:Y_SDSA_GET_LONGALERT_DATA>
};

declare variable $longShortRequest as element(ns0:LongShortRequest) external;

xf:LongAlertData_Request($longShortRequest)
