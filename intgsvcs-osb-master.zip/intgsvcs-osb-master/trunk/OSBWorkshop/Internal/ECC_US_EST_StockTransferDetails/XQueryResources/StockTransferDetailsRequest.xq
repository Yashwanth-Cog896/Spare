(:: pragma bea:global-element-parameter parameter="$request" element="ns0:StockTransferDetailsRequest" location="../Schemas/StockTransferDetails.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstDetail" location="../WSDLs/YES_Y_SDSA_USSEED_EST_DETAIL.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:StockTransferDetails";
declare namespace xf = "http://tempuri.org/ECC_US_EST_StockTransferDetails/XQueryResources/StockTransferDetailsRequest/";

declare function xf:StockTransferDetailsRequest($request as element(ns0:StockTransferDetailsRequest))
    as element(ns2:YSdsaUsseedEstDetail) {
        <ns2:YSdsaUsseedEstDetail>
            <Dealer>{ xs:string( data($request/ns0:StockTransferDetailsRequestBody/ns0:StockTransferDetailsProperties/ns0:DealerEntity/ns0:PartnerIdentifier[1]) ) }</Dealer>
            <IDlrOrdStatus>
                {
                    if($request/ns0:StockTransferDetailsRequestBody/ns0:StockTransferDetailsProperties/ns0:StatusList/ns0:Status[1]/text()!='') then (
                    for $Status in $request/ns0:StockTransferDetailsRequestBody/ns0:StockTransferDetailsProperties/ns0:StatusList/ns0:Status
                    return
                        <item>
                            <Ystat>{ xs:string( data($Status) ) }</Ystat>
                        </item>
                        ) else if($request/ns0:StockTransferDetailsRequestBody/ns0:TransferIdentifierList/ns0:TransferIdentifier[1]/text()!='') then (
	                        for $TransferIdentifier in $request/ns0:StockTransferDetailsRequestBody/ns0:TransferIdentifierList/ns0:TransferIdentifier
	                    	return
	                        <item>
	                            <Yvbeln>{ xs:string( data($TransferIdentifier) ) }</Yvbeln>
	                        </item>
                        )else()
                }
            </IDlrOrdStatus>
            {
                for $TransferIndicator in $request/ns0:StockTransferDetailsRequestBody/ns0:StockTransferDetailsProperties/ns0:TransferIndicator
                return
                    <Indicator>{ xs:string( data($TransferIndicator) ) }</Indicator>
            }
            <ReqType>{ xs:string( data($request/ns0:StockTransferDetailsRequestBody/ns0:StockTransferDetailsProperties/ns0:DealerEntity/ns0:PartnerIdentifier[1]/@Type) ) }</ReqType>
            {
                for $SeedYear in $request/ns0:StockTransferDetailsRequestBody/ns0:StockTransferDetailsProperties/ns0:SeedYear
                return
                    <Year>{ xs:string( data($SeedYear) ) }</Year>
            }
        </ns2:YSdsaUsseedEstDetail>
};

declare variable $request as element(ns0:StockTransferDetailsRequest) external;

xf:StockTransferDetailsRequest($request)
