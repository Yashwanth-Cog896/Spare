(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstDetailResponse" location="../WSDLs/YES_Y_SDSA_USSEED_EST_DETAIL.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:StockTransferDetailsResponse" location="../Schemas/StockTransferDetails.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns4 = "";
declare namespace ns0 = "Monsanto:Service:StockTransferDetails";
declare namespace xf = "http://tempuri.org/ECC_US_EST_StockTransferDetails/XQueryResources/StockTransferDetailsResponse/";

declare function xf:StockTransferDetailsResponse($response as element(ns2:YSdsaUsseedEstDetailResponse))
    as element(ns0:StockTransferDetailsResponse) {
        <ns0:StockTransferDetailsResponse Version = "1.0">
            <ns0:StockTransferDetailsResponseBody>
                {
                    for $item in $response/OrdHdr/item
                    return
                        <ns0:StockTransferDetailsResponseDetail>
                            <ns0:StockTransferDetailsResponseProperties>
                             {
									if(data($item/Yyvbeln) !='') then (
									<ns0:TransferIdentifier Type="SALES_ORDER_NUMBER">{ data($item/Yyvbeln) }</ns0:TransferIdentifier>
									) else()
	                            }
	                            {
									if(data($item/Yytrnum) !='') then (
									<ns0:TransferIdentifier Type="PURCHASE_ORDER_NUMBER">{ data($item/Yytrnum) }</ns0:TransferIdentifier>
									) else()
	                            }
	                            {
									if(data($item/Yybname) !='') then (
									<ns0:TransferIdentifier Type="CLIENT_TRANSACTION_ID">{ data($item/Yybname) }</ns0:TransferIdentifier>
									) else()
	                            }
	                            {
									if(data($item/Yybillno) !='') then (
									<ns0:TransferIdentifier Type="BILLING_DOC_NUMBER">{ data($item/Yybillno) }</ns0:TransferIdentifier>
									) else()
                          		}
                                <ns0:SeedYear>{ xs:integer( data($item/Yyyear) ) }</ns0:SeedYear>
                                <ns0:TransferFrom>
                                    <ns0:DealerEntity>
                                        <ns0:PartnerIdentifier Type = "{ data($item/YysreqType) }">{ data($item/Yyskunnr) }</ns0:PartnerIdentifier>
                                        <ns0:PartnerName>{ data($item/Yysname1) }</ns0:PartnerName>
                                    </ns0:DealerEntity>
                                    <ns0:PurchaseOrderNumber>{ data($item/Yysponum) }</ns0:PurchaseOrderNumber>
                                    <ns0:AddressInformation>
                                        <ns0:AddressLine>{ data($item/Yysstras) }</ns0:AddressLine>
                                        <ns0:CityName>{ data($item/Yysort01) }</ns0:CityName>
                                        <ns0:State>{ data($item/Yysregio) }</ns0:State>
                                        <ns0:PostalCode>{ data($item/Yyspstlz) }</ns0:PostalCode>
                                    </ns0:AddressInformation>
                                    <ns0:PhoneNumber>{ data($item/Yysphone) }</ns0:PhoneNumber>
                                </ns0:TransferFrom>
                                <ns0:TransferTo>
                                    <ns0:DealerEntity>
                                        <ns0:PartnerIdentifier Type = "{ data($item/YyrreqType) }">{ data($item/Yyrkunnr) }</ns0:PartnerIdentifier>
                                        <ns0:PartnerName>{ data($item/Yyrname1) }</ns0:PartnerName>
                                    </ns0:DealerEntity>
                                    <ns0:PurchaseOrderNumber>{ data($item/Yyrponum) }</ns0:PurchaseOrderNumber>
                                    <ns0:AddressInformation>
                                        <ns0:AddressLine>{ data($item/Yyrstras) }</ns0:AddressLine>
                                        <ns0:CityName>{ data($item/Yyrort01) }</ns0:CityName>
                                        <ns0:State>{ data($item/Yyrregio) }</ns0:State>
                                        <ns0:PostalCode>{ data($item/Yyrpstlz) }</ns0:PostalCode>
                                    </ns0:AddressInformation>
                                    <ns0:PhoneNumber>{ data($item/Yyrphone) }</ns0:PhoneNumber>
                                </ns0:TransferTo>
                                <ns0:Status>{ data($item/Yystatus) }</ns0:Status>
                                <ns0:InitiatedUserId>{ data($item/Yycreate) }</ns0:InitiatedUserId>
                                <ns0:InitiatedDate>{ xs:date( data($item/Yycredate) ) }</ns0:InitiatedDate>
                                <ns0:ChangedByUserId>{ data($item/Yychng) }</ns0:ChangedByUserId>
                                
                                   {
									if(fn:contains(xs:string(data($item/Yychngdate)),'0000')) then(                  
									) else(
									<ns0:ChangedDate>{ xs:date( data($item/Yychngdate) ) }</ns0:ChangedDate>
									)
									}
								    {
									if(fn:contains(xs:string(data($item/Yybilldate)),'0000')) then(                  
									) else(
									<ns0:BillingDate>{xs:date(data($item/Yybilldate))}</ns0:BillingDate>
									)
									}
                                <ns0:TransferIndicator>{ data($item/Yyind) }</ns0:TransferIndicator>
                                <ns0:DisputeDescription>{ data($item/YydisReason) }</ns0:DisputeDescription>
                            </ns0:StockTransferDetailsResponseProperties>
                            {
                                for $item0 in $item,
                                    $item1 in $response/OrdItm/item
                                where data($item0/Yyvbeln) = data($item1/Yvbeln)
                                return
                                    <ns0:StockTransferDetailsLineItem>
                                        <ns0:ItemNumber>{ data($item1/Yposnr) }</ns0:ItemNumber>
                                        {
                                        if(data($item1/Ygrpos)!='')then(
                                        <ns0:ReferenceItemNumber>{ xs:integer( data($item1/Ygrpos) ) }</ns0:ReferenceItemNumber>
                                        )else()
                                        }
                                        <ns0:ProductIdentification>
                                        { 
												if(data($item1/Ymatnr)!='') then(
												<ns0:ProductIdentifier Type="SAP">{ data($item1/Ymatnr)  }</ns0:ProductIdentifier>
												) else()
                                            }
                                            { 
												if(data($item1/Yygtin)!='') then(
												<ns0:ProductIdentifier Type="GTIN">{ data($item1/Yygtin) }</ns0:ProductIdentifier>
												) else()
                                            }
                                            { 
												if(data($item1/YyupcCode)!='') then(
												<ns0:ProductIdentifier Type="UPC">{ data($item1/YyupcCode) }</ns0:ProductIdentifier>
												) else()
                                            }
                                            <ns0:ProductName>{ data($item1/YysalesTxt) }</ns0:ProductName>
                                        </ns0:ProductIdentification>
                                        <ns0:ProductCrop>{ data($item1/Ycrop) }</ns0:ProductCrop>
                                        <ns0:LotNumber>{ data($item1/Ykdmat) }</ns0:LotNumber>
                                        <ns0:TransferQuantity>
                                        {if(data($item1/Yzieme)!='')then(
                                            <ns0:Measurement>
                                                <ns0:MeasurementValue>{ data($item1/Yzmeng) }</ns0:MeasurementValue>
                                                <ns0:UnitOfMeasureCode>{ data($item1/Yzieme) }</ns0:UnitOfMeasureCode>
                                            </ns0:Measurement>
                                            )else()
                                            }
                                        </ns0:TransferQuantity>
                                        <ns0:ItemStatus>{ data($item1/Yabgru) }</ns0:ItemStatus>
                                    </ns0:StockTransferDetailsLineItem>
                            }
                        </ns0:StockTransferDetailsResponseDetail>
                }
            </ns0:StockTransferDetailsResponseBody>
            {
                for $item in $response/Messages/item
                return
                                 <ns0:StockTransferDetailsResponseError>
                        <ns0:ErrorType>
	                        {                          
		                        if (data($item/Type) = "S") then
		                            ("Success")
		                        else 
		                            if (data($item/Type) = "E") then
		                                ("Error")
		                            else 
		                                if (data($item/Type) = "W") then
		                                    ("Warning")
		                                else 
		                                    if (data($item/Type) = "I") then
		                                        ("Info")
		                                    else 
		                                        if (data($item/Type) = "A") then
		                                            ("Abort")
		                                        else 
		                                            ()
	                    	} 
                        </ns0:ErrorType>
                        <ns0:ItemNumber>{ data($item/Id) }</ns0:ItemNumber>
                       {
	                		if(data($item/Number)!='')then(
	                       		<ns0:ErrorMessageNumber>{ xs:integer( data($item/Number) ) }</ns0:ErrorMessageNumber>
	                       	)else()
                       	}
                        <ns0:TransferIdentifier Type = "{ data($item/ErrDesc) }">{ data($item/MsgObject) }</ns0:TransferIdentifier>
                        <ns0:ErrorMessageDisplayText>{ data($item/ErrDescDisp) }</ns0:ErrorMessageDisplayText>
                    </ns0:StockTransferDetailsResponseError>
               
            }
        </ns0:StockTransferDetailsResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstDetailResponse) external;

xf:StockTransferDetailsResponse($response)
