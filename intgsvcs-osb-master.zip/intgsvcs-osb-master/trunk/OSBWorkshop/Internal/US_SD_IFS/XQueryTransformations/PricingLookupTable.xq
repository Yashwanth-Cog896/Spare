<PriceTable>
	<Crop Type="CORN">
		<Price Brand="DEKALB">10</Price>
	</Crop>
</PriceTable>	