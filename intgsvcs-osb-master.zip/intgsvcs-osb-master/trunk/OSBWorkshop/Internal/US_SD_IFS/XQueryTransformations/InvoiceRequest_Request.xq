(:: pragma bea:global-element-parameter parameter="$iFSInvoiceRequest" element="ns0:IFSInvoiceRequest" location="../WSDLs/InvoiceRequest_Java_UTP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YsdsaIfsInvoiceRequest" location="../WSDLs/InvoiceRequest_SAP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/US_SD_IFS/XQueryTransformations/InvoiceRequest_Request/";

declare function xf:InvoiceRequest_Request($iFSInvoiceRequest as element(ns0:IFSInvoiceRequest))
    as element(ns0:YsdsaIfsInvoiceRequest) {
        <ns0:YsdsaIfsInvoiceRequest>
            {
                let $prescription := $iFSInvoiceRequest/prescription
                return
                    <ItPrescription>
                        {
                            for $item in $prescription/item
                            return
                                <item>
                                    <YyprescrId>{ data($item/prescriptionId) }</YyprescrId>
                                    <Yycrop>{ data($item/agxCropName) }</Yycrop>
                                    <Yyhybrid>{ data($item/certifiedProductId) }</Yyhybrid>
                                    <YyprescrName>{ data($item/prescriptionName) }</YyprescrName>
                                    <Yyqty>{ data($item/fieldArea) }</Yyqty>
                                    <Yyuom>{ data($item/salesUnitUom) }</Yyuom>
                                    <Yyprimary>{ data($item/isPrimary) }</Yyprimary>
                                    <YyextunitPrice>{ data($item/unitPrice) }</YyextunitPrice>
                                    <YyextItemPrice>{ data($item/totalPrice) }</YyextItemPrice>
                                    <YypriceInd>{ data($item/priceIndicator) }</YypriceInd>
                                    <Yycurrency>{ data($item/currency) }</Yycurrency>
                                </item>
                        }
                    </ItPrescription>
            }
            <IvAgent>{ data($iFSInvoiceRequest/agentId) }</IvAgent>
            {
                for $agentType in $iFSInvoiceRequest/agentType
                return
                    <IvAgentType>{ data($agentType) }</IvAgentType>
            }
            <IvBrand>{ data($iFSInvoiceRequest/brand) }</IvBrand>
            {
                for $farmId in $iFSInvoiceRequest/farmId
                return
                    <IvFarmId>{ data($farmId) }</IvFarmId>
            }
            {
                for $farmName in $iFSInvoiceRequest/farmName
                return
                    <IvFarmName>{ data($farmName) }</IvFarmName>
            }
            <IvFieldId>{ data($iFSInvoiceRequest/fieldId) }</IvFieldId>
            {
                for $fieldName in $iFSInvoiceRequest/fieldName
                return
                    <IvFieldName>{ data($fieldName) }</IvFieldName>
            }
            <IvOrderId>{ data($iFSInvoiceRequest/orderId) }</IvOrderId>
            {
                for $orderName in $iFSInvoiceRequest/orderName
                return
                    <IvOrderName>{ data($orderName) }</IvOrderName>
            }
            <IvPurchaseDate>{ data($iFSInvoiceRequest/purchaseDate) }</IvPurchaseDate>
            {
                for $purchaseOrder in $iFSInvoiceRequest/purchaseOrder
                return
                    <IvPurchaseOrder>{ data($purchaseOrder) }</IvPurchaseOrder>
            }
            <IvPurchaseTime>{ data($iFSInvoiceRequest/purchaseTime) }</IvPurchaseTime>
            <IvShipTo>{ data($iFSInvoiceRequest/shipTo) }</IvShipTo>
            <IvShipToType>{ data($iFSInvoiceRequest/shipToType) }</IvShipToType>
            <IvSoldTo>{ data($iFSInvoiceRequest/soldTo) }</IvSoldTo>
            <IvSoldToType>{ data($iFSInvoiceRequest/soldToType) }</IvSoldToType>
            <IvSource>{ data($iFSInvoiceRequest/sourceSystem) }</IvSource>
            {
                for $targetPlantingDate in $iFSInvoiceRequest/targetPlantingDate
                return
                    <IvTargetDate>{ data($targetPlantingDate) }</IvTargetDate>
            }
            {
                for $seasonId in $iFSInvoiceRequest/seasonId
                return
                    <IvYear>{ data($seasonId) }</IvYear>
            }
        </ns0:YsdsaIfsInvoiceRequest>
};

declare variable $iFSInvoiceRequest as element(ns0:IFSInvoiceRequest) external;

xf:InvoiceRequest_Request($iFSInvoiceRequest)
