(:: pragma bea:global-element-parameter parameter="$ysdsaIfsInvoiceRequestResponse" element="ns0:YsdsaIfsInvoiceRequestResponse" location="../WSDLs/InvoiceRequest_SAP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:IFSInvoiceRequestResponse" location="../WSDLs/InvoiceRequest_Java_UTP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/US_SD_IFS/XQueryTransformations/InvoiceRequest_Response/";

declare function xf:InvoiceRequest_Response($ysdsaIfsInvoiceRequestResponse as element(ns0:YsdsaIfsInvoiceRequestResponse))
    as element(ns0:IFSInvoiceRequestResponse) {
        <ns0:IFSInvoiceRequestResponse>
            {
                let $EtMessage := $ysdsaIfsInvoiceRequestResponse/EtMessage
                return
                    <invoiceOrderErrorReturn>
                        {
                            for $item in $EtMessage/item
                            return
                                <item>
                                    <messageType>{ data($item/YymsgType) }</messageType>
                                    <messageNumber>{ data($item/YymsgNo) }</messageNumber>
                                    <messageId>{ data($item/YymsgId) }</messageId>
                                    <messageObject>{ data($item/YymsgObject) }</messageObject>
                                    <messageDescriptionInternal>{ data($item/YymsgDescInt) }</messageDescriptionInternal>
                                    <messageDescriptionExternal>{ data($item/YymsgDescExt) }</messageDescriptionExternal>
                                </item>
                        }
                    </invoiceOrderErrorReturn>
            }
            <orderId>{ data($ysdsaIfsInvoiceRequestResponse/EvOrderId) }</orderId>
            <currency>{ data($ysdsaIfsInvoiceRequestResponse/EvSapCurrency) }</currency>
            <sapOrderId>{ data($ysdsaIfsInvoiceRequestResponse/EvSapOrderId) }</sapOrderId>
            <sapOrderPrice>{ data($ysdsaIfsInvoiceRequestResponse/EvSapPrice) }</sapOrderPrice>
        </ns0:IFSInvoiceRequestResponse>
};

declare variable $ysdsaIfsInvoiceRequestResponse as element(ns0:YsdsaIfsInvoiceRequestResponse) external;

xf:InvoiceRequest_Response($ysdsaIfsInvoiceRequestResponse)
