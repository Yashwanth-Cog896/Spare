xquery version "1.0" encoding "Cp1252";
(:: pragma bea:global-element-parameter parameter="$request" element="ns0:ProductAvailabilityNBRequest" location="../WSDLs/ProductAvailabilityNB.wsdl" ::)
(:: pragma bea:global-element-return element="ns2:PriceAndAvailabilityRequest" location="../WSDLs/ProductAvailability_PI.wsdl" ::)

declare namespace xf = "http://tempuri.org/USST_MobilityProject/XQueryTransformations/ProductAvailabilityNBRequest/";
declare namespace ns2 = "urn:ecms:schema:pal:request:2:0";
declare namespace ns1 = "urn:cidx:names:DRAFT_0014:ces:schema:all:5:0";
declare namespace ns3 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:ProductAvailabilityNB";

declare function xf:ProductAvailabilityNBRequest($request as element(ns0:ProductAvailabilityNBRequest))
    as element(ns2:PriceAndAvailabilityRequest) {
      <ns2:PriceAndAvailabilityRequest Version = "{ data($request/@Version) }">
        <ns1:Header  xmlns="urn:cidx:names:DRAFT_0014:ces:schema:all:5:0">
        	<ThisDocumentIdentifier>
        		<DocumentIdentifier>{data($request/ns3:Header/ns3:DocumentIdentifier)}</DocumentIdentifier>
        	</ThisDocumentIdentifier>
        	<ThisDocumentDateTime>
        		<DateTime DateTimeQualifier="On">{data($request/ns3:Header/ns3:DocumentDateTime)}</DateTime>
        	</ThisDocumentDateTime>
        	<From>
        		<PartnerInformation>
        			<PartnerName>{data($request/ns3:Header/ns3:From/ns3:PartnerName)}</PartnerName>
        			<PartnerIdentifier Agency="ACCT_ID">{data($request/ns3:Header/ns3:From/ns3:PartnerIdentifier)}</PartnerIdentifier>
        			<ContactInformation>
        				<ContactName>{data($request/ns3:Header/ns3:From/ns3:ContactInformation/ns3:ContactName)}</ContactName>
        				<ContactDescription>{data($request/ns3:Header/ns3:From/ns3:ContactInformation/ns3:ContactDescription)}</ContactDescription>
        				<ContactNumber>{data($request/ns3:Header/ns3:From/ns3:ContactInformation/ns3:ContactPhoneNumber)}</ContactNumber>
        				<EmailAddress>{data($request/ns3:Header/ns3:From/ns3:ContactInformation/ns3:EmailAddress)}</EmailAddress>       				
        			</ContactInformation>
        		</PartnerInformation>
        	</From>
        	<To>
        		<PartnerInformation>
        			<PartnerName>{data($request/ns3:Header/ns3:To/ns3:PartnerName)}</PartnerName>
        			<PartnerIdentifier Agency="ACCT_ID">{data($request/ns3:Header/ns3:To/ns3:PartnerIdentifier)}</PartnerIdentifier>
        			<ContactInformation>
        				<ContactName>{data($request/ns3:Header/ns3:To/ns3:ContactInformation/ns3:ContactName)}</ContactName>
        				<ContactDescription>{data($request/ns3:Header/ns3:To/ns3:ContactInformation/ns3:ContactDescription)}</ContactDescription>
        				<ContactNumber>{data($request/ns3:Header/ns3:To/ns3:ContactInformation/ns3:ContactPhoneNumber)}</ContactNumber>
        				<EmailAddress>{data($request/ns3:Header/ns3:To/ns3:ContactInformation/ns3:EmailAddress)}</EmailAddress>       				
        			</ContactInformation>
        		</PartnerInformation>
        	</To>
        </ns1:Header>
        <ns2:PriceAndAvailabilityRequestBody>
        	<ns2:PriceAndAvailabilityRequestProperties>
        	        <ns1:RequisitionNumber>
                        <ns1:DocumentIdentifier>1</ns1:DocumentIdentifier>
                     </ns1:RequisitionNumber>
        			<ns2:RequisitionTypeCode Domain="ANSI-ASC-X12-92">DEALRPAL</ns2:RequisitionTypeCode>
        			<ns1:LanguageCode Domain="ISO-639-2T">eng</ns1:LanguageCode>
                    <ns1:CurrencyCode Domain="ISO-4217">USD</ns1:CurrencyCode>       			
        	</ns2:PriceAndAvailabilityRequestProperties>
        	
        	<ns2:PriceAndAvailabilityRequestPartners>
        		<ns1:Buyer>
        			<ns1:PartnerInformation>
        				<ns1:PartnerName>{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerName) }</ns1:PartnerName>
        				<ns1:PartnerIdentifier Agency="{if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "SAP_ID") then "AssignedByPapiNet" else if ($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "EBID") then "AGIIS_EBID" else if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "ACCT_ID") then "AssignedBySeller" else()}">{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
        			</ns1:PartnerInformation>
        		</ns1:Buyer>
        		
        		<ns1:Seller>
        			<ns1:PartnerInformation>
        				<ns1:PartnerName>Monsanto Company</ns1:PartnerName>
        				<ns1:PartnerIdentifier Agency="{if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "SAP_ID") then "AssignedByPapiNet" else if ($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "EBID") then "AGIIS_EBID" else if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "ACCT_ID") then "AssignedBySeller" else()}">0062668030000</ns1:PartnerIdentifier>
        			</ns1:PartnerInformation>
        		</ns1:Seller>
        		
        		<ns1:ShipTo>
        			<ns1:PartnerInformation>
        				<ns1:PartnerName>{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerName) }</ns1:PartnerName>
        				<ns1:PartnerIdentifier Agency="{if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "SAP_ID") then "AssignedByPapiNet" else if ($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "EBID") then "AGIIS_EBID" else if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "ACCT_ID") then "AssignedBySeller" else()}">{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
        			</ns1:PartnerInformation>
        		</ns1:ShipTo>
        		
        		<ns1:Payer>
        			<ns1:PartnerInformation>
        				<ns1:PartnerName>{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerName) }</ns1:PartnerName>
        				<ns1:PartnerIdentifier Agency="{if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "SAP_ID") then "AssignedByPapiNet" else if ($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "EBID") then "AGIIS_EBID" else if($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier/@Type = "ACCT_ID") then "AssignedBySeller" else()}">{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:DealerEntity/ns0:PartnerIdentifier) }</ns1:PartnerIdentifier>
        			</ns1:PartnerInformation>
        		</ns1:Payer>
        	</ns2:PriceAndAvailabilityRequestPartners>        	
        	<ns2:PriceAndAvailabilityRequestDetails>       	
        		<ns2:PriceAndAvailabilityRequestProductLineItem>
        			<ns1:LineNumber>1</ns1:LineNumber>
                    <ns1:RequisitionLineItemNumber>1</ns1:RequisitionLineItemNumber>       			       		        			
        			<ns2:ProductSelection>
        			{ for $ProductTraitCode in $request/ns0:ProductAvailabilityNBRequestBody/ns0:ProductTraitsCodeList/ns0:ProductTraitsCode return
        				<ns1:ProductIdentification>    					
        					<ns1:ProductClassification>{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:ProductCropCode) }</ns1:ProductClassification>
        					<ns1:Trademark>{ data($ProductTraitCode)}</ns1:Trademark>         					     					
        				</ns1:ProductIdentification>      				
        			}
        			   	<ns2:ProductHierarchy>
        					<ns1:ProductGradeDescription>{ data($request/ns0:ProductAvailabilityNBRequestBody/ns0:ProductVariety)}</ns1:ProductGradeDescription>
        				</ns2:ProductHierarchy>
        			</ns2:ProductSelection>
        		</ns2:PriceAndAvailabilityRequestProductLineItem>        	
        	</ns2:PriceAndAvailabilityRequestDetails>
        </ns2:PriceAndAvailabilityRequestBody>
        
      </ns2:PriceAndAvailabilityRequest>
};	

declare variable $request as element(ns0:ProductAvailabilityNBRequest) external;

xf:ProductAvailabilityNBRequest($request)
