xquery version "1.0" encoding "Cp1252";
(:: pragma bea:global-element-parameter parameter="$response" element="ns2:PriceAndAvailabilityResponse" location="../WSDLs/ProductAvailability_PI.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:ProductAvailabilityNBResponse" location="../WSDLs/ProductAvailabilityNB.wsdl" ::)

declare namespace xf = "http://tempuri.org/USST_MobilityProject/XQueryTransformations/ProductAvailabilityNBResponse/";
declare namespace ns2 = "urn:ecms:schema:pal:response:2:0";
declare namespace ns1 = "urn:cidx:names:DRAFT_0014:ces:schema:all:5:0";
declare namespace ns3 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:ProductAvailabilityNB";

declare function xf:ProductAvailabilityNBResponse($response as element(ns2:PriceAndAvailabilityResponse))
    as element(ns0:ProductAvailabilityNBResponse) {
        <ns0:ProductAvailabilityNBResponse>
        	<Header xmlns="urn:monsanto:uscomm:service:header">
        		<DocumentIdentifier>{data ($response/ns1:Header/ns1:ThisDocumentIdentifier/ns1:DocumentIdentifier)}</DocumentIdentifier>
        		<DocumentDateTime>{data ($response/ns1:Header/ns1:ThisDocumentDateTime/ns1:DateTime)}</DocumentDateTime>
        		<From>
        			<PartnerName>{data ($response/ns1:Header/ns1:From/ns1:PartnerInformation/ns1:PartnerName)}</PartnerName>
        			<PartnerIdentifier>{data ($response/ns1:Header/ns1:From/ns1:PartnerInformation/ns1:PartnerIdentifier)}</PartnerIdentifier>
        		</From>
        		<To>
        			<PartnerName>{data ($response/ns1:Header/ns1:To/ns1:PartnerInformation/ns1:PartnerName)}</PartnerName>
        			<PartnerIdentifier>{data ($response/ns1:Header/ns1:To/ns1:PartnerInformation/ns1:PartnerIdentifier)}</PartnerIdentifier>
        		</To>       	
        	</Header>
        	<ProductAvailabilityNBResponseBody xmlns="Monsanto:Service:ProductAvailabilityNB">
        		<DealerEntity>
        			<PartnerIdentifier Type="{if($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponsePartners/ns1:Buyer/ns1:PartnerInformation/ns1:PartnerIdentifier/@Agency = "AssignedByPapiNet") then "SAP_ID" else if ($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponsePartners/ns1:Buyer/ns1:PartnerInformation/ns1:PartnerIdentifier/@Agency = "AGIIS_EBID") then "EBID" else if($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponsePartners/ns1:Buyer/ns1:PartnerInformation/ns1:PartnerIdentifier/@Agency = "AssignedBySeller") then "ACCT_ID" else()}">{data($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponsePartners/ns1:Buyer/ns1:PartnerInformation/ns1:PartnerIdentifier)}</PartnerIdentifier>
        			<PartnerName>{data($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponsePartners/ns1:Buyer/ns1:PartnerInformation/ns1:PartnerName)}</PartnerName>
        		</DealerEntity>
        		<ProductCropCode>{data($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponseDetails/ns2:PriceAndAvailabilityResponseProductLineItem[1]/ns1:ProductIdentification[1]/ns1:ProductClassification)}</ProductCropCode>
        		<ProductTraitsCode>{data($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponseDetails/ns2:PriceAndAvailabilityResponseProductLineItem[1]/ns1:ProductIdentification[1]/ns1:Trademark)}</ProductTraitsCode>
        		<ProductVariety>{data($response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponseDetails/ns2:PriceAndAvailabilityResponseProductLineItem[1]/ns1:ProductIdentification[1]/ns1:ProductGradeDescription)}</ProductVariety>
        		
        		{ for $LineItem in $response/ns2:PriceAndAvailabilityResponseBody/ns2:PriceAndAvailabilityResponseDetails/ns2:PriceAndAvailabilityResponseProductLineItem return
        		
        		<ProductAvailabilityNBResponseDetails>
        			<ProductIdentification>
        				<ProductIdentifier Type="{if($LineItem/ns1:ProductIdentification[1]/ns1:ProductIdentifier/@Agency="UPC") then "UPC" else( "GTIN")}">{data($LineItem/ns1:ProductIdentification[1]/ns1:ProductIdentifier)}</ProductIdentifier>
        				<ProductIdentifier Type="{if($LineItem/ns1:ProductIdentification[2]/ns1:ProductIdentifier/@Agency="UPC") then "UPC" else( "GTIN")}">{data($LineItem/ns1:ProductIdentification[2]/ns1:ProductIdentifier)}</ProductIdentifier>
        				<ProductName>{data($LineItem/ns1:ProductIdentification[1]/ns1:ProductName)}</ProductName>
        			</ProductIdentification>
        			<AvailableQuantity>
        				<Measurement>
        					<MeasurementValue>{data($LineItem/ns1:ProductQuantity/ns1:Measurement/ns1:MeasurementValue)}</MeasurementValue>
        					<UnitOfMeasureCode>{data($LineItem/ns1:ProductQuantity/ns1:Measurement/ns1:UnitOfMeasureCode )}</UnitOfMeasureCode>
        				</Measurement>
        			</AvailableQuantity>
        			<AvailabilityLevelDescription>{data($LineItem/ns2:ProductQuantityInformation/ns1:Comment/ns1:Content)}</AvailabilityLevelDescription>
        			{ for $ProductCharacteristic in $LineItem/ns2:ProductCharacteristics return
        			 if($ProductCharacteristic/@Agency = "Maturity") then
        			<RelativeMaturityValue>{data($ProductCharacteristic)}</RelativeMaturityValue>
        			else ()
        			}
        		</ProductAvailabilityNBResponseDetails> 
        	}	      	
        	</ProductAvailabilityNBResponseBody>
                  
        </ns0:ProductAvailabilityNBResponse>
};

declare variable $response as element(ns2:PriceAndAvailabilityResponse) external;

xf:ProductAvailabilityNBResponse($response)
