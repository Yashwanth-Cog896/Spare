(:: pragma bea:global-element-parameter parameter="$response" element="ns1:ZAtmsAutoFillupRfcResponse" location="../WSDLs/YES_Z_ATMS_AUTO_FILLUP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:Z_ATMS_AUTO_FILLUP_RFC_OUTPUT" location="../WSDLs/ATMSWSDL.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://monsanto.com/ATMSAutoFillup";
declare namespace xf = "http://tempuri.org/SD_US_ATMS_AutoFillup/XQueryTransformations/ATMSResponseTransformation/";

declare function xf:ATMSResponseTransformation($response as element(ns1:ZAtmsAutoFillupRfcResponse))
    as element(Z_ATMS_AUTO_FILLUP_RFC_OUTPUT) {
        <Z_ATMS_AUTO_FILLUP_RFC_OUTPUT>
            <STATUS_CODE_PARM>{ data($response/StatusCode) }</STATUS_CODE_PARM>
            <STATUS_DESC_PARM>{ data($response/StatusDesc) }</STATUS_DESC_PARM>
        </Z_ATMS_AUTO_FILLUP_RFC_OUTPUT>
};

declare variable $response as element(ns1:ZAtmsAutoFillupRfcResponse) external;

xf:ATMSResponseTransformation($response)
