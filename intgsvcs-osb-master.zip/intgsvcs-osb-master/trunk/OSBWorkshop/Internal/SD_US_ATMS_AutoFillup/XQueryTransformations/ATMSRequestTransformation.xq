(:: pragma bea:global-element-parameter parameter="$request" element="Z_ATMS_AUTO_FILLUP_RFC_INPUT" location="../WSDLs/ATMSWSDL.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:ZAtmsAutoFillupRfc" location="../WSDLs/YES_Z_ATMS_AUTO_FILLUP.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/SD_US_ATMS_AutoFillup/XQueryTransformations/ATMSRequestTransformation/";

declare function xf:ATMSRequestTransformation($request as element(Z_ATMS_AUTO_FILLUP_RFC_INPUT))
    as element(ns0:ZAtmsAutoFillupRfc) {
        <ns0:ZAtmsAutoFillupRfc>
            <Zatms01Tab>
                {
                    for $ZATMS01_TAB_ROW in $request/ZATMS01_TAB_TABLE/ZATMS01_TAB_ROW
                    return
                        <item>
                            <Mandt>{ data($ZATMS01_TAB_ROW/MANDT_PARM) }</Mandt>
                            <Zzseq>{ data($ZATMS01_TAB_ROW/ZZSEQ_PARM) }</Zzseq>
                            <Zzshipto>{ data($ZATMS01_TAB_ROW/ZZSHIPTO_PARM) }</Zzshipto>
                            <Zzprod>{ data($ZATMS01_TAB_ROW/ZZPROD_PARM) }</Zzprod>
                            <Zzreordqty>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZREORDQTY_PARM) ) }</Zzreordqty>
                            <Zzmaxqty>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZMAXQTY_PARM) ) }</Zzmaxqty>
                            <Zzcapacity>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZCAPACITY_PARM) ) }</Zzcapacity>
                            <Zzcrtordfg>{ data($ZATMS01_TAB_ROW/ZZCRTORDFG_PARM) }</Zzcrtordfg>
                            <Zzconflg>{ data($ZATMS01_TAB_ROW/ZZCONFLG_PARM) }</Zzconflg>
                            <Zzphysqty>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZPHYSQTYP_PARM) ) }</Zzphysqty>
                            <Zzlstcaldt>{ data($ZATMS01_TAB_ROW/ZZLSTCALDT_PARM) }</Zzlstcaldt>
                            <Zzlstcaltm>{ data($request/ZATMS01_TAB_TABLE/ZATMS01_TAB_ROW[1]/ZZLSTCALTM_PARM) }</Zzlstcaltm>
                            <Zzminqty>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZMINQTY_PARM) ) }</Zzminqty>
                            <Zzforecast>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZFORECAST_PARM) ) }</Zzforecast>
                            <Zzusage>{ xs:decimal( data($ZATMS01_TAB_ROW/ZZUSAGE_PARM) ) }</Zzusage>
                            <Zzstartdt>{ data($ZATMS01_TAB_ROW/ZZSTARTDT_PARM) }</Zzstartdt>
                            <Zzenddate>{ data($ZATMS01_TAB_ROW/ZZENDDATE_PARM) }</Zzenddate>
                            <Zzdte>{ data($ZATMS01_TAB_ROW/ZZDTE_PARM) }</Zzdte>
                            <Zztime>{ data($request/ZATMS01_TAB_TABLE/ZATMS01_TAB_ROW[1]/ZZTIME_PARM) }</Zztime>
                            <Zzrqdeldt>{ data($ZATMS01_TAB_ROW/ZZRQDELDT_PARM) }</Zzrqdeldt>
                            <Zzinactive>{ data($ZATMS01_TAB_ROW/ZZINACTIVE) }</Zzinactive>
                        </item>
                }
            </Zatms01Tab>
        </ns0:ZAtmsAutoFillupRfc>
};

declare variable $request as element(Z_ATMS_AUTO_FILLUP_RFC_INPUT) external;

xf:ATMSRequestTransformation($request)
