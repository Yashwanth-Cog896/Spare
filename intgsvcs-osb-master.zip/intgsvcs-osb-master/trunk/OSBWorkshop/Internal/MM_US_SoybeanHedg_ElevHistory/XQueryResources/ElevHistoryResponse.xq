(:: pragma bea:global-element-parameter parameter="$response" element="ns1:YFhdElevHistoryResponse" location="../WSDLs/YES_Y_FHD_ELEV_HISTORY.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:SoybeanHedgingListResponse" location="../Schemas/SoybeanHedgingListResponse.xsd" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:soybeanhedginglistresponse:response:1:0";
declare namespace xf = "http://tempuri.org/MM_US_SoybeanHedg_ElevHistory/XQueryResources/ElevHistoryResponse/";

declare function xf:ElevHistoryResponse($response as element(ns1:YFhdElevHistoryResponse))
    as element(ns0:SoybeanHedgingListResponse) {
        <ns0:SoybeanHedgingListResponse>
            {
                for $item in $response/OutElevHistory/item
                return
                    <ns0:SoybeanHedgingListResponseBody>
                        <ns0:ElevatorSAPNumber>{ data($item/YyelevCustNbr) }</ns0:ElevatorSAPNumber>
                        <ns0:ElevatorName>{ data($item/YyelevName) }</ns0:ElevatorName>
                        <ns0:TradeTicketNumber>{ xs:integer( data($item/Yytrdtktno) ) }</ns0:TradeTicketNumber>
                        <ns0:Contracts>{ xs:integer( data($item/YynbrContracts) ) }</ns0:Contracts>
                        <ns0:PlantCode>{ data($item/Yyplant) }</ns0:PlantCode>
                        <ns0:MarketDateTime>
                            <ns0:DateTime>
                                {
                                    fn:concat($item/YyexchMktDate,
                                    "T00:00:00Z")
                                }
</ns0:DateTime>
                        </ns0:MarketDateTime>
                        <ns0:FuturesMonth>{ xs:integer( data($item/YyfuturesMo) ) }</ns0:FuturesMonth>
                        <ns0:FuturesYear>{ xs:integer( data($item/YyfuturesYr) ) }</ns0:FuturesYear>
                        <ns0:FuturesPrice>
                            <ns0:MonetaryAmount>
                                <ns0:MonetaryValue>
                                    {
                                        fn-bea:format-number($item/YyfuturePrice,
                                        "0.0000")
                                    }
</ns0:MonetaryValue>
                                <ns0:CurencyCode>{ data($item/YyhedgeCurrency) }</ns0:CurencyCode>
                            </ns0:MonetaryAmount>
                        </ns0:FuturesPrice>
                        <ns0:PriceBasis>
                            <ns0:MonetaryAmount>
                                <ns0:MonetaryValue>
                                    {
                                        fn-bea:format-number($item/YypriceBasis,
                                        "0.0000")
                                    }
</ns0:MonetaryValue>
                                <ns0:CurencyCode>{ data($item/YyhedgeCurrency) }</ns0:CurencyCode>
                            </ns0:MonetaryAmount>
                        </ns0:PriceBasis>
                        <ns0:Status>{ data($item/Yystatus) }</ns0:Status>
                        <ns0:Comments>{ data($item/Yycomments) }</ns0:Comments>
                        <ns0:ElevatorContactInformation>
                            <ns0:ContactName>{ data($item/Yytrdnam) }</ns0:ContactName>
                            <ns0:AccountID>{ data($item/Yytrdnamid) }</ns0:AccountID>
                        </ns0:ElevatorContactInformation>
                        <ns0:ElevatorBrokerInformation>
                            <ns0:BrokerName>{ data($item/YyelevBrkName) }</ns0:BrokerName>
                            <ns0:AccountID>{ data($item/YyelevBrkId) }</ns0:AccountID>
                        </ns0:ElevatorBrokerInformation>
                    </ns0:SoybeanHedgingListResponseBody>
            }
            {
                for $item in $response/OutErrors/item
                return
                    <ns0:SoybeanHedgingListResponseError>
                        <ns0:ErrorType>{ data($item/YymsgType) }</ns0:ErrorType>
                        <ns0:ErrorMessageClass>{ data($item/YymsgId) }</ns0:ErrorMessageClass>
                        <ns0:ErrorMessageNumber>{ xs:integer( data($item/YymsgNbr) ) }</ns0:ErrorMessageNumber>
                        <ns0:ErrorMessageObject>{ data($item/YymsgObject) }</ns0:ErrorMessageObject>
                        <ns0:ErrorMessageText>{ data($item/YymsgDescInt) }</ns0:ErrorMessageText>
                        <ns0:ErrorMessageDisplayText>{ data($item/YymsgDescExt) }</ns0:ErrorMessageDisplayText>
                    </ns0:SoybeanHedgingListResponseError>
            }
        </ns0:SoybeanHedgingListResponse>
};

declare variable $response as element(ns1:YFhdElevHistoryResponse) external;

xf:ElevHistoryResponse($response)
