(:: pragma bea:global-element-parameter parameter="$request" element="ns0:SoybeanHedgingListRequest" location="../Schemas/SoybeanHedgingListRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns1:YFhdElevHistory" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:soybeanhedginglistrequest:request:1:0";
declare namespace xf = "http://tempuri.org/MM_US_SoybeanHedg_ElevHistory/XQueryResources/ElevHistoryRequest/";

declare function xf:ElevHistoryRequest($request as element(ns0:SoybeanHedgingListRequest))
    as element(ns1:YFhdElevHistory) {
        <ns1:YFhdElevHistory>
            <AdminId>{ data($request/ns0:SoybeanHedgingListRequestBody/ns0:AdminID) }</AdminId>
            <Datetime>{ xs:string( data($request/ns0:SoybeanHedgingListRequestBody/ns0:DateTime) ) }</Datetime>
            <ElevatorNumber>{ data($request/ns0:SoybeanHedgingListRequestBody/ns0:ElevatorSAPNumber) }</ElevatorNumber>
            <InStatus>
                {
                    for $StatusList in $request/ns0:SoybeanHedgingListRequestBody/ns0:StatusList
                    return
                        <item>
                            <Yystatus>{ xs:string( data($StatusList/ns0:Status) ) }</Yystatus>
                        </item>
                }
            </InStatus>
        </ns1:YFhdElevHistory>
};

declare variable $request as element(ns0:SoybeanHedgingListRequest) external;

xf:ElevHistoryRequest($request)
