(:: pragma bea:global-element-parameter parameter="$request" element="ns0:FuturesPricingRequest" location="../Schemas/FuturesPricingRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns1:YFhdCbotPricing" location="../WSDLs/FuturesPricingECC.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:futurespricingrequest:request:1:0";
declare namespace xf = "http://tempuri.org/MM_US_SoybeanHedg_FuturePrices/XQueryResources/FuturePricingRequest/";

declare function xf:FuturePricingRequest($request as element(ns0:FuturesPricingRequest))
    as element(ns1:YFhdCbotPricing) {
        <ns1:YFhdCbotPricing>
            <InDatetime>{ xs:string( data($request/ns0:FuturesPricingRequestBody/ns0:DateTime) ) }</InDatetime>
            <InExchange>{ xs:string( data($request/ns0:FuturesPricingRequestBody/ns0:MarketExchangeCode) ) }</InExchange>
        </ns1:YFhdCbotPricing>
};

declare variable $request as element(ns0:FuturesPricingRequest) external;

xf:FuturePricingRequest($request)
