(:: pragma bea:global-element-parameter parameter="$response" element="ns1:YFhdCbotPricingResponse" location="../WSDLs/FuturesPricingECC.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:FuturesPricingResponse" location="../Schemas/FuturesPricingResponse.xsd" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:futurespricingresponse:response:1:0";
declare namespace xf = "http://tempuri.org/MM_US_SoybeanHedg_FuturePrices/XQueryResources/FuturePricingResponse/";

declare function xf:FuturePricingResponse($response as element(ns1:YFhdCbotPricingResponse))
    as element(ns0:FuturesPricingResponse) {
        <ns0:FuturesPricingResponse>
       		{if(data($response/OutCbotPricing/item[1]/Yyspecie)='SB')then(
            <ns0:FuturesPricingResponseBody>
                <ns0:FuturesPricingProperties>
                    <ns0:ProductCropCode>{ data($response/OutCbotPricing/item[1]/Yyspecie) }</ns0:ProductCropCode>
                    <ns0:ProductCropDescription>{ data($response/OutCbotPricing/item[1]/Yyspeciedesc) }</ns0:ProductCropDescription>
                    <ns0:MarketDateTime>
                        <ns0:DateTime>{ fn:concat(($response/OutCbotPricing/item[1]/Yymktdate),"T00:00:00Z") }</ns0:DateTime>
                    </ns0:MarketDateTime>
                </ns0:FuturesPricingProperties>
                {
                    for $item0 in $response/OutCbotPricing/item
                    return
                    if(data($item0/Yyspecie)='SB') then(
                        <ns0:FuturesPricingDetails>
                            <ns0:PriceMonth>{ data($item0/YypriceMo) }</ns0:PriceMonth>
                            <ns0:PriceYear>{ xs:integer( data($item0/YypriceYr) ) }</ns0:PriceYear>
                            <ns0:MarketClosePrice>
                                <ns0:MonetaryAmount>
                                    <ns0:MonetaryValue>
                                        {
                                            fn-bea:format-number($item0/YyclosePrice,
                                            "0.0000")
                                        }
							</ns0:MonetaryValue>
                                    <ns0:CurencyCode>{ data($item0/Yycurrency) }</ns0:CurencyCode>
                                </ns0:MonetaryAmount>
                            </ns0:MarketClosePrice>
                            <ns0:MarketHighPrice>
                                <ns0:MonetaryAmount>
                                    <ns0:MonetaryValue>
                                        {
                                            fn-bea:format-number($item0/YyhighPrice,
                                            "0.0000")
                                        }
							</ns0:MonetaryValue>
                                    <ns0:CurencyCode>{ data($item0/Yycurrency) }</ns0:CurencyCode>
                                </ns0:MonetaryAmount>
                            </ns0:MarketHighPrice>
                        </ns0:FuturesPricingDetails>
                     )else()
                     
                }
                </ns0:FuturesPricingResponseBody>
               )else()
               }
            {
                for $item in $response/OutErrors/item
                return
                    <ns0:FuturesPricingResponseError>
                        <ns0:ErrorType>{ data($item/YymsgType) }</ns0:ErrorType>
                        <ns0:ErrorMessageClass>{ data($item/YymsgId) }</ns0:ErrorMessageClass>
                        <ns0:ErrorMessageNumber>{ xs:integer( data($item/YymsgNbr) ) }</ns0:ErrorMessageNumber>
                        <ns0:ErrorMessageObject>{ data($item/YymsgObject) }</ns0:ErrorMessageObject>
                        <ns0:ErrorMessageText>{ data($item/YymsgDescInt) }</ns0:ErrorMessageText>
                        <ns0:ErrorMessageDisplayText>{ data($item/YymsgDescExt) }</ns0:ErrorMessageDisplayText>
                    </ns0:FuturesPricingResponseError>
            }
        </ns0:FuturesPricingResponse>
};

declare variable $response as element(ns1:YFhdCbotPricingResponse) external;

xf:FuturePricingResponse($response)
