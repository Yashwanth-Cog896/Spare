(:: pragma bea:global-element-parameter parameter="$ySdsaSwReadAllocationResponse1" element="ns0:YSdsaSwReadAllocationResponse" location="../WSDLs/SW_Read_06-12%20ECC%20to%20OSb.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:ReadAllocationResponse" location="../WSDLs/SupplyAllocations_read_update.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/PDP/XQueryResources/ReadResponse/";

declare function xf:ReadResponse($ySdsaSwReadAllocationResponse1 as element(ns0:YSdsaSwReadAllocationResponse))
    as element(ns0:ReadAllocationResponse) {
        <ns0:ReadAllocationResponse>
            {
                let $result :=
                    for $item in $ySdsaSwReadAllocationResponse1/EtSwReadAllocationResErr/item
                    return
                        <error>
                            <errorCode>{ data($item/YymsgType) }</errorCode>
                            <errorMessage>{ data($item/YymsgDescExt) }</errorMessage>
                        </error>
                return
                    $result[1]
            }
            {
                for $item in $ySdsaSwReadAllocationResponse1/EtSwReadAllocationResMain/item
                return
                    <readAllocationItemList>
                        <country>{ data($item/Yycountry) }</country>
                        <brand>{ data($item/Yybrand) }</brand>
                        <endMonth>{ data($item/Yyendmonth) }</endMonth>
                        <allocationSeason>{ data($item/Yyalseason) }</allocationSeason>
                        <totalDescription>{ data($item/Yytotaldesc) }</totalDescription>
                        <allocationData>
                            <org>
                                <org1>{ data($item/Yyo1) }</org1>
                                <org2>{ data($item/Yyo2) }</org2>
                                <org3>{ data($item/Yyo3) }</org3>
                                <org4>{ data($item/Yyo4) }</org4>
                            </org>
                            <product>
                                <hybrid>{ data($item/Yyacroynm) }</hybrid>
                                <globalName>{ data($item/Yyglobal) }</globalName>
                                <gradeSize>{ data($item/Yygradesizdc) }</gradeSize>
                                <treatment>{ data($item/Yytreatment) }</treatment>
                                <allocationUnit>{ data($item/Yyallocunit) }</allocationUnit>
                            </product>
                            <prodAllocationQty>{ data($item/Yykcqty) }</prodAllocationQty>
                            <incomingOrderQty>{ data($item/Yyaemenge) }</incomingOrderQty>
                            <customerRequirement>{ data($item/Yykcreq) }</customerRequirement>
                            <openProdAllocationQty>{ data($item/Yykltbk) }</openProdAllocationQty>
                            <reserveQty>{ data($item/Yyreskcqty) }</reserveQty>
                            <openStatus>{ data($item/Yyopenstatus) }</openStatus>
                            <openMessage>{ data($item/Yyopenmessage) }</openMessage>
                        </allocationData>
                        <errorMessage>{ data($item/Yyerror1) }</errorMessage>
                    </readAllocationItemList>
            }
        </ns0:ReadAllocationResponse>
};

declare variable $ySdsaSwReadAllocationResponse1 as element(ns0:YSdsaSwReadAllocationResponse) external;

xf:ReadResponse($ySdsaSwReadAllocationResponse1)
