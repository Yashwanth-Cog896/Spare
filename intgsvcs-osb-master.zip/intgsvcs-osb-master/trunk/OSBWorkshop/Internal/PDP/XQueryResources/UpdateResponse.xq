(:: pragma bea:global-element-parameter parameter="$ySdsaSwUpdateAllocationResponse1" element="ns0:YSdsaSwUpdateAllocationResponse" location="../WSDLs/SW_Update_06-12%20ecc%20to%20OSB.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:UpdateAllocationResponse" location="../WSDLs/SupplyAllocations_read_update.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/PDP/XQueryResources/UpdateResponse/";

declare function xf:UpdateResponse($ySdsaSwUpdateAllocationResponse1 as element(ns0:YSdsaSwUpdateAllocationResponse))
    as element(ns0:UpdateAllocationResponse) {
        <ns0:UpdateAllocationResponse>
            <updateAllocationResponseHeader>
                <allocatoinHeader>
                    <requestType>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yyrequesttype) }</requestType>
                    <crop>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yycrop) }</crop>
                    <brand>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yybrand) }</brand>
                    <country>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yycountry) }</country>
                    <groupOfCountry>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yygrpcountry) }</groupOfCountry>
                </allocatoinHeader>
                <endMonth>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yyendmonth) }</endMonth>
                <allocationSeason>{ data($ySdsaSwUpdateAllocationResponse1/IsSwUpdateAllocResHead/Yyalseason) }</allocationSeason>
            </updateAllocationResponseHeader>
            {
                for $item in $ySdsaSwUpdateAllocationResponse1/ItSwUpdateAllocResItem/item
                return
                    <updateAllocationItemListWithError>
                        <UpdateAllocationItem>
                            <org>
                                <org1>{ data($item/Yyorg1) }</org1>
                                <org2>{ data($item/Yyorg2) }</org2>
                                <org3>{ data($item/Yyorg3) }</org3>
                                <org4>{ data($item/Yyorg4) }</org4>
                            </org>
                            <product>
                                <hybrid>{ data($item/Yyacroynm) }</hybrid>
                                <globalName>{ data($item/Yyglobal) }</globalName>
                                <gradeSize>{ data($item/Yygradesizdc) }</gradeSize>
                                <treatment>{ data($item/Yytreatment) }</treatment>
                                <allocationUnit>{ data($item/Allocationunit) }</allocationUnit>
                            </product>
                            <prodAllocationQty>{ data($item/YykcqtyN) }</prodAllocationQty>
                            <customerRequirement>{ data($item/Yykcreq) }</customerRequirement>
                            <openProdAllocationQty>{ data($item/Yykltbk) }</openProdAllocationQty>
                            <reserveQty>{ data($item/Yyreskcqty) }</reserveQty>
                            <openStatus>{ data($item/Yyopenstatus) }</openStatus>
                        </UpdateAllocationItem>
                        <error>
                            <errorCode>{ data($item/Yyerrorcode) }</errorCode>
                            <errorMessage>{ data($item/Yyerrormessage) }</errorMessage>
                        </error>
                    </updateAllocationItemListWithError>
            }
        </ns0:UpdateAllocationResponse>
};

declare variable $ySdsaSwUpdateAllocationResponse1 as element(ns0:YSdsaSwUpdateAllocationResponse) external;

xf:UpdateResponse($ySdsaSwUpdateAllocationResponse1)
