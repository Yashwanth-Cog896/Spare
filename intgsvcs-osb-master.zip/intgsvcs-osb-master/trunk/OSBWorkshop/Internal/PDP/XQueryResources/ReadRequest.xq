(:: pragma bea:global-element-parameter parameter="$readAllocationRequest1" element="ns0:ReadAllocationRequest" location="../WSDLs/SupplyAllocations_read_update.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YSdsaSwReadAllocation" location="../WSDLs/SW_Read_06-12%20ECC%20to%20OSb.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/PDP/XQueryResources/Read/";

declare function xf:Read($readAllocationRequest1 as element(ns0:ReadAllocationRequest))
    as element(ns0:YSdsaSwReadAllocation) {
        <ns0:YSdsaSwReadAllocation>
            <IsSwReadAllocationReqHead>
                <Yyreqtype>{ data($readAllocationRequest1/readAllocationHeader/allocatoinHeader/requestType) }</Yyreqtype>
                <Yycrop>{ data($readAllocationRequest1/readAllocationHeader/allocatoinHeader/crop) }</Yycrop>
                <Yyyear>{ data($readAllocationRequest1/readAllocationHeader/year) }</Yyyear>
                <Yybrand>{ data($readAllocationRequest1/readAllocationHeader/allocatoinHeader/brand) }</Yybrand>
                <Yycountry>{ data($readAllocationRequest1/readAllocationHeader/allocatoinHeader/country) }</Yycountry>
                <Yygrpcountry>{ data($readAllocationRequest1/readAllocationHeader/allocatoinHeader/groupOfCountry) }</Yygrpcountry>
            </IsSwReadAllocationReqHead>
            <ItSwReadAllocationReqMat>
                {
                    for $productList in $readAllocationRequest1/productList
                    return
                        <item>
                            <Yyacroynm>{ data($productList/hybrid) }</Yyacroynm>
                            <Yyglobal>{ data($productList/globalName) }</Yyglobal>
                            <Yygradesizdc>{ data($productList/gradeSize) }</Yygradesizdc>
                            <Yytreatment>{ data($productList/treatment) }</Yytreatment>
                            <Yyallocunit>{ data($productList/allocationUnit) }</Yyallocunit>
                        </item>
                }
            </ItSwReadAllocationReqMat>
            <ItSwReadAllocationReqOrg>
                {
                    for $orgList in $readAllocationRequest1/orgList
                    return
                        <item>
                            <Yyo1>{ data($orgList/org1) }</Yyo1>
                            <Yyo2>{ data($orgList/org2) }</Yyo2>
                            <Yyo3>{ data($orgList/org3) }</Yyo3>
                            <Yyo4>{ data($orgList/org4) }</Yyo4>
                        </item>
                }
            </ItSwReadAllocationReqOrg>
        </ns0:YSdsaSwReadAllocation>
};

declare variable $readAllocationRequest1 as element(ns0:ReadAllocationRequest) external;

xf:Read($readAllocationRequest1)
