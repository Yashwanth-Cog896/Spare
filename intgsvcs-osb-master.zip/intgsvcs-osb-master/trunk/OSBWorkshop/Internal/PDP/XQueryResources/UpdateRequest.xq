(:: pragma bea:global-element-parameter parameter="$updateAllocationRequest1" element="ns0:UpdateAllocationRequest" location="../WSDLs/SupplyAllocations_read_update.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:YSdsaSwUpdateAllocation" location="../WSDLs/SW_Update_06-12%20ecc%20to%20OSB.wsdl" ::)

declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/PDP/XQueryResources/UpdateRequest/";

declare function xf:UpdateRequest($updateAllocationRequest1 as element(ns0:UpdateAllocationRequest))
    as element(ns0:YSdsaSwUpdateAllocation) {
        <ns0:YSdsaSwUpdateAllocation>
            <IsSwUpdateAllocReqHead>
                <Yyrequesttype>{ data($updateAllocationRequest1/updateAllocationRequestHeader/allocatoinHeader/requestType) }</Yyrequesttype>
                <Yycrop>{ data($updateAllocationRequest1/updateAllocationRequestHeader/allocatoinHeader/crop) }</Yycrop>
                <Yyendmonth>{ data($updateAllocationRequest1/updateAllocationRequestHeader/endMonth) }</Yyendmonth>
                <Yyalseason>{ data($updateAllocationRequest1/updateAllocationRequestHeader/allocationSeason) }</Yyalseason>
                <Yycountry>{ data($updateAllocationRequest1/updateAllocationRequestHeader/allocatoinHeader/country) }</Yycountry>
                <Yybrand>{ data($updateAllocationRequest1/updateAllocationRequestHeader/allocatoinHeader/brand) }</Yybrand>
                <Yygrpcountry>{ data($updateAllocationRequest1/updateAllocationRequestHeader/allocatoinHeader/groupOfCountry) }</Yygrpcountry>
            </IsSwUpdateAllocReqHead>
            <ItSwUpdateAllocReqItem>
                {
                    for $updateAllocationItemList in $updateAllocationRequest1/updateAllocationItemList
                    return
                        <item>
                            <Yyorg1>{ data($updateAllocationItemList/org/org1) }</Yyorg1>
                            <Yyorg2>{ data($updateAllocationItemList/org/org2) }</Yyorg2>
                            <Yyorg3>{ data($updateAllocationItemList/org/org3) }</Yyorg3>
                            <Yyorg4>{ data($updateAllocationItemList/org/org4) }</Yyorg4>
                            <Yyacroynm>{ data($updateAllocationItemList/product/hybrid) }</Yyacroynm>
                            <Yyglobal>{ data($updateAllocationItemList/product/globalName) }</Yyglobal>
                            <Yygradesizdc>{ data($updateAllocationItemList/product/gradeSize) }</Yygradesizdc>
                            <Yytreatment>{ data($updateAllocationItemList/product/treatment) }</Yytreatment>
                            <Yyallocunit>{ data($updateAllocationItemList/product/allocationUnit) }</Yyallocunit>
                            <YykcqtyN>{ data($updateAllocationItemList/prodAllocationQty) }</YykcqtyN>
                            <Yykcreq>{ data($updateAllocationItemList/customerRequirement) }</Yykcreq>
                            <Yykltbk>{ data($updateAllocationItemList/openProdAllocationQty) }</Yykltbk>
                            <Yyreskcqty>{ data($updateAllocationItemList/reserveQty) }</Yyreskcqty>
                            <Yyopenstatus>{ data($updateAllocationItemList/openStatus) }</Yyopenstatus>
                        </item>
                }
            </ItSwUpdateAllocReqItem>
        </ns0:YSdsaSwUpdateAllocation>
};

declare variable $updateAllocationRequest1 as element(ns0:UpdateAllocationRequest) external;

xf:UpdateRequest($updateAllocationRequest1)
