(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaUsseedEstDlrfavoritesResponse" location="../WSDLs/YES_Y_SDSA_USSEED_EST_DLRFAVRT.WSDL" ::)
(:: pragma bea:global-element-return element="ns0:DealerFavoritesResponse" location="../Schemas/DealerFavorites.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerFavorites";
declare namespace xf = "http://tempuri.org/ECC_US_EST_DealerFavorites/XQueryResourses/DealerFavoritesResponse/";

declare function xf:DealerFavoritesResponse($response as element(ns2:YSdsaUsseedEstDlrfavoritesResponse))
    as element(ns0:DealerFavoritesResponse) {
        <ns0:DealerFavoritesResponse Version="1.0">
            <ns0:DealerFavoritesResponseBody>
                {
                    for $item in $response/DlrLocation/item
                    return
                        <ns0:DealerInformation>
                            <ns0:DealerEntity>
                                <ns0:PartnerIdentifier Type="SAP_ID">{ data($item/Dealer) }</ns0:PartnerIdentifier>
                                <ns0:PartnerName>{ data($item/Name1) }</ns0:PartnerName>
                            </ns0:DealerEntity>
                            <ns0:AddressInformation>
                                <ns0:AddressLine>{ data($item/Street) }</ns0:AddressLine>
                                <ns0:CityName>{ data($item/City) }</ns0:CityName>
                                <ns0:State>{ data($item/Region) }</ns0:State>
                                <ns0:PostalCode>{ data($item/PostlCod1) }</ns0:PostalCode>
                            </ns0:AddressInformation>
                            {
                            if($item/Tel1Number/text()!='') then(
                            <ns0:PhoneNumber>{ data($item/Tel1Number) }</ns0:PhoneNumber>
                            ) else()
                            }
                        </ns0:DealerInformation>
                }
            </ns0:DealerFavoritesResponseBody>
            
            <ns0:DealerFavoritesResponseError>
                  <ns0:ErrorType>{ 
                  if (data($response/Messages/item[1]/Type) = "S") then
                            ("Success")
                        else 
                            if (data($response/Messages/item[1]/Type) = "E") then
                                ("Error")
                            else 
                                if (data($response/Messages/item[1]/Type) = "W") then
                                    ("Warning")
                                else 
                                    if (data($response/Messages/item[1]/Type) = "I") then
                                        ("Info")
                                    else 
                                        if (data($response/Messages/item[1]/Type) = "A") then
                                            ("Abort")
                                        else 
                                            ()
                	}
                </ns0:ErrorType>
                <ns0:ErrorMessageClass>{ data($response/Messages/item[1]/Id) }</ns0:ErrorMessageClass>
                {
                if(data($response/Messages/item[1]/Number)!='')then(
                <ns0:ErrorMessageNumber>{ xs:integer( data($response/Messages/item[1]/Number) ) }</ns0:ErrorMessageNumber>
                )else()
                }
                <ns0:ErrorMessageObject>{ data($response/Messages/item[1]/MsgObject) }</ns0:ErrorMessageObject>
                <ns0:ErrorMessageText>{ data($response/Messages/item[1]/ErrDesc) }</ns0:ErrorMessageText>
                <ns0:ErrorMessageDisplayText>{ data($response/Messages/item[1]/ErrDescDisp) }</ns0:ErrorMessageDisplayText>
            </ns0:DealerFavoritesResponseError>
              
        </ns0:DealerFavoritesResponse>
};

declare variable $response as element(ns2:YSdsaUsseedEstDlrfavoritesResponse) external;

xf:DealerFavoritesResponse($response)
