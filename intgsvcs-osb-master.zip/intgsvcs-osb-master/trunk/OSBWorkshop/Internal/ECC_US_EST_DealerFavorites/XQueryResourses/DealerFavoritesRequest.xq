(:: pragma bea:global-element-parameter parameter="$request" element="ns0:DealerFavoritesRequest" location="../Schemas/DealerFavorites.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaUsseedEstDlrfavorites" location="../WSDLs/YES_Y_SDSA_USSEED_EST_DLRFAVRT.WSDL" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:monsanto:uscomm:service:header";
declare namespace ns0 = "Monsanto:Service:DealerFavorites";
declare namespace xf = "http://tempuri.org/ECC_US_EST_DealerFavorites/XQueryResourses/DealerFavoritesRequest/";

declare function xf:DealerFavoritesRequest($request as element(ns0:DealerFavoritesRequest))
    as element(ns2:YSdsaUsseedEstDlrfavorites) {
        <ns2:YSdsaUsseedEstDlrfavorites>
            <Dealer>{ xs:string( data($request/ns0:DealerFavoritesRequestBody/ns0:PartnerIdentifier) ) }</Dealer>
        </ns2:YSdsaUsseedEstDlrfavorites>
};

declare variable $request as element(ns0:DealerFavoritesRequest) external;

xf:DealerFavoritesRequest($request)
