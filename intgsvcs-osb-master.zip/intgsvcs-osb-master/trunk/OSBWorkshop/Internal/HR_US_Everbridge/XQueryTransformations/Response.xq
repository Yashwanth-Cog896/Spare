(:: pragma bea:global-element-parameter parameter="$manageMemberResponse1" element="ns0:manageMemberResponse" location="../WSDLs/Everbridge.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:YHrpaEverbridgeResponse" location="../WSDLs/Everbridge_SAPv2.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://com/everbridge/ws3";
declare namespace xf = "http://tempuri.org/HR_US_Everbridge/XQueryTransformations/Response/";

declare function xf:Response($manageMemberResponse1 as element(ns0:manageMemberResponse))
    as element(ns1:YHrpaEverbridgeResponse) {
        <ns1:YHrpaEverbridgeResponse>
            {
                for $batchId in $manageMemberResponse1/ns0:return/ns0:batchId
                return
                    <batchId>{ data($batchId) }</batchId>
            }
            {
                for $memberInfoBeans in $manageMemberResponse1/ns0:return/ns0:memberInfoBeans
                return
                    <item>
                        <insertUpdateFlag>{ data($memberInfoBeans/ns0:insertUpdateFlag) }</insertUpdateFlag>
                        <firstName>{ data($memberInfoBeans/ns0:firstName) }</firstName>
                        <middleName>{ data($memberInfoBeans/ns0:middleName) }</middleName>
                        <lastName>{ data($memberInfoBeans/ns0:lastName) }</lastName>
                        <suffix>{ data($memberInfoBeans/ns0:suffix) }</suffix>
                        <externalMemberId>{ data($memberInfoBeans/ns0:externalMemberId) }</externalMemberId>
                        <businessStreet>{ data($memberInfoBeans/ns0:businessStreet) }</businessStreet>
                        <businessStreet2>{ data($memberInfoBeans/ns0:businessStreet2) }</businessStreet2>
                        <businessCity>{ data($memberInfoBeans/ns0:businessCity) }</businessCity>
                        <businessState>{ data($memberInfoBeans/ns0:businessState) }</businessState>
                        <businessPostalCode>{ data($memberInfoBeans/ns0:businessPostalCode) }</businessPostalCode>
                        <businessCountry>{ data($memberInfoBeans/ns0:businessCountry) }</businessCountry>
                        <groupX>{ data($memberInfoBeans/ns0:groupX) }</groupX>
                        <group2>{ data($memberInfoBeans/ns0:group2) }</group2>
                        <group3>{ data($memberInfoBeans/ns0:group3) }</group3>
                        <groups>{ data($memberInfoBeans/ns0:groups) }</groups>
                        <userAttrFieldName1>{ data($memberInfoBeans/ns0:userAttrFieldName1) }</userAttrFieldName1>
                        <userAttrValue1>{ data($memberInfoBeans/ns0:userAttrValue1) }</userAttrValue1>
                        <userAttrFieldName2>{ data($memberInfoBeans/ns0:userAttrFieldName2) }</userAttrFieldName2>
                        <userAttrValue2>{ data($memberInfoBeans/ns0:userAttrValue2) }</userAttrValue2>
                        <userAttrFieldName3>{ data($memberInfoBeans/ns0:userAttrFieldName3) }</userAttrFieldName3>
                        <userAttrValue3>{ data($memberInfoBeans/ns0:userAttrValue3) }</userAttrValue3>
                        <emailAddress>{ data($memberInfoBeans/ns0:emailAddress) }</emailAddress>
                        <businessPhone>{ data($memberInfoBeans/ns0:businessPhone) }</businessPhone>
                        <businessPhoneCountry>{ data($memberInfoBeans/ns0:businessPhoneCountry) }</businessPhoneCountry>
                        <mobilePhone>{ data($memberInfoBeans/ns0:mobilePhone) }</mobilePhone>
                        <mobilePhoneCountry>{ data($memberInfoBeans/ns0:mobilePhoneCountry) }</mobilePhoneCountry>
                        <homePhone>{ data($memberInfoBeans/ns0:homePhone) }</homePhone>
                        <homePhoneCountry>{ data($memberInfoBeans/ns0:homePhoneCountry) }</homePhoneCountry>
                        <RecordStatus>{ data($memberInfoBeans/ns0:status) }</RecordStatus>
                        <ErrorMessage>{ data($memberInfoBeans/ns0:statusMessage) }</ErrorMessage>
                        <END>{ data($memberInfoBeans/ns0:endLine) }</END>
                    </item>
            }
            {
                for $status in $manageMemberResponse1/ns0:return/ns0:status
                return
                    <status>{ data($status) }</status>
            }
            {
                for $statusMessage in $manageMemberResponse1/ns0:return/ns0:statusMessage
                return
                    <statusMessage>{ data($statusMessage) }</statusMessage>
            }
        </ns1:YHrpaEverbridgeResponse>
};

declare variable $manageMemberResponse1 as element(ns0:manageMemberResponse) external;

xf:Response($manageMemberResponse1)
