(:: pragma bea:global-element-parameter parameter="$yHrpaEverbridge1" element="ns1:YHrpaEverbridge" location="../WSDLs/Everbridge_SAPv2.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:manageMember" location="../WSDLs/Everbridge.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "http://com/everbridge/ws3";
declare namespace xf = "http://tempuri.org/HR_US_Everbridge/XQueryTransformations/Request/";

declare function xf:Request($yHrpaEverbridge1 as element(ns1:YHrpaEverbridge))
    as element(ns0:manageMember) {
        <ns0:manageMember>
            {
                for $item in $yHrpaEverbridge1/EtOutput/item
                return
                    <ns0:x>
                        <ns0:businessCity>{ data($item/Yyort01) }</ns0:businessCity>
                        <ns0:businessCountry>{ data($item/Yyland1) }</ns0:businessCountry>
                        <ns0:businessPhone>{ data($item/YybusPhone) }</ns0:businessPhone>
                        <ns0:businessPhoneCountry>{ data($item/YybusPhoneCod) }</ns0:businessPhoneCountry>
                        <ns0:businessPostalCode>{ data($item/Yypstlz) }</ns0:businessPostalCode>
                        <ns0:businessState>{ data($item/Yystate) }</ns0:businessState>
                        <ns0:businessStreet>{ data($item/Yystras) }</ns0:businessStreet>
                        <ns0:businessStreet2>{ data($item/Yylocat) }</ns0:businessStreet2>
                        <ns0:emailAddress>{ data($item/Yyemail) }</ns0:emailAddress>
                        <ns0:externalMemberId>{ data($item/Yypernr) }</ns0:externalMemberId>
                        <ns0:firstName>{ data($item/Yyvorna) }</ns0:firstName>
                        <ns0:group2>{ data($item/Yyland1It351) }</ns0:group2>
                        <ns0:group3>{ data($item/YybtrtlBtext) }</ns0:group3>
                        <ns0:groupX>{ data($item/YyworldArea) }</ns0:groupX>
                        <ns0:groups>{ data($item/YyallEmployeeHrd) }</ns0:groups>
                        <ns0:homePhone>{ data($item/YyhomPhone) }</ns0:homePhone>
                        <ns0:homePhoneCountry>{ data($item/YyhomPhoneCod) }</ns0:homePhoneCountry>
                        <ns0:insertUpdateFlag>{ data($item/Yyaction) }</ns0:insertUpdateFlag>
                        <ns0:lastName>{ data($item/Yynachn) }</ns0:lastName>
                        <ns0:middleName>{ data($item/Yymidnm) }</ns0:middleName>
                        <ns0:mobilePhone>{ data($item/YymobPhone) }</ns0:mobilePhone>
                        <ns0:mobilePhoneCountry>{ data($item/YymobPhoneCod) }</ns0:mobilePhoneCountry>                       
                        <ns0:smsDevice1>{ data($item/YymobPhone) }</ns0:smsDevice1>
                        <ns0:smsDevice1Country>{ data($item/YymobPhoneCod) }</ns0:smsDevice1Country>
                        <ns0:suffix>{ data($item/Yynamzu) }</ns0:suffix>
                        <ns0:userAttrFieldName1>{ data($item/YystateProvinceHrd) }</ns0:userAttrFieldName1>
                        <ns0:userAttrFieldName2>{ data($item/YymailStopHrd) }</ns0:userAttrFieldName2>
                        <ns0:userAttrFieldName3>{ data($item/YypostalCode) }</ns0:userAttrFieldName3>
                        <ns0:userAttrValue1>{ data($item/YystateIt6) }</ns0:userAttrValue1>
                        <ns0:userAttrValue2>{ data($item/Yymailstop) }</ns0:userAttrValue2>
                        <ns0:userAttrValue3>{ data($item/YypstlzSnd) }</ns0:userAttrValue3>
                    </ns0:x>
            }
        </ns0:manageMember>
};

declare variable $yHrpaEverbridge1 as element(ns1:YHrpaEverbridge) external;

xf:Request($yHrpaEverbridge1)
