(:: pragma bea:global-element-parameter parameter="$ySdsaAsiMatExclusionCallResponse" element="ns2:YSdsaAsiMatExclusionCallResponse" location="../WSDLs/YES_SDSA_ASI_MAT_EXCLUSION.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:ExclusionListResponse" location="../Schemas/ExclusionListResponse.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:exclusionlistresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/USCOM_Product/XQueryResources/MaterialExclusionListReponse/";

declare function xf:MaterialExclusionListReponse($ySdsaAsiMatExclusionCallResponse as element(ns2:YSdsaAsiMatExclusionCallResponse))
    as element(ns1:ExclusionListResponse) {
        <ns1:ExclusionListResponse>
            <ns1:ExclusionListResponseBody>
                <ns1:BrandInformation>
                    <ns1:BrandIdentifier>{ data($ySdsaAsiMatExclusionCallResponse/EtMatExc/item[1]/Yyvkorg) }</ns1:BrandIdentifier>
                </ns1:BrandInformation>
                {
                    for $item in $ySdsaAsiMatExclusionCallResponse/EtMatExc/item
                    return
                        <ns1:ExclusionListAttributes>
                            <ns1:DistributionChannel>{ data($item/Yyvtweg) }</ns1:DistributionChannel>
                            <ns1:SalesYear>{ data($item/Yycropyear) }</ns1:SalesYear>
                            <ns1:Crop>{ data($item/Yyspecie) }</ns1:Crop>
                            <ns1:Dealer>{ data($item/Yykunzy) }</ns1:Dealer>
                            <ns1:Customer>{ data($item/Yykunag) }</ns1:Customer>
                            <ns1:DSM>{ data($item/Yyvkgrp) }</ns1:DSM>
                            <ns1:Product>{ data($item/Yyacronym) }</ns1:Product>
                            <ns1:TraitCode>{ data($item/Yylabor) }</ns1:TraitCode>
                            <ns1:TreatmentCode>{ data($item/Yyspctrtmt) }</ns1:TreatmentCode>
                            <ns1:Material>{ data($item/Yymatnr) }</ns1:Material>
                            <ns1:ValidTo>{ xs:date( data($item/Yydatbi) ) }</ns1:ValidTo>
                            <ns1:ValidFrom>{ xs:date( data($item/Yydatab) ) }</ns1:ValidFrom>
                            <ns1:ConditionTable>{ data($item/Yykotabnr) }</ns1:ConditionTable>
                        </ns1:ExclusionListAttributes>
                }
            </ns1:ExclusionListResponseBody>
            {
                for $item in $ySdsaAsiMatExclusionCallResponse/EtError/item
                return
                    <ns1:ExclusionListResponseError>
                        <ns1:ErrorType>{ data($item/YymsgType) }</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/YymsgId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ xs:integer( data($item/YymsgNo) ) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ data($item/YymsgObject) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/YymsgDescInt) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/YymsgDescExt) }</ns1:ErrorMessageDisplayText>
                    </ns1:ExclusionListResponseError>
            }
        </ns1:ExclusionListResponse>
};

declare variable $ySdsaAsiMatExclusionCallResponse as element(ns2:YSdsaAsiMatExclusionCallResponse) external;

xf:MaterialExclusionListReponse($ySdsaAsiMatExclusionCallResponse)
