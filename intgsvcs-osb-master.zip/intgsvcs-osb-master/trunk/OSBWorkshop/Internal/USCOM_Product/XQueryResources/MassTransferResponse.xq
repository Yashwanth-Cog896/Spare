(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YSdsaSalesdocMassAsiResponse" location="../WSDLs/YES_Y_SDSA_SALESDOC_MASS_ASI_RFC.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:MassTransferResponse" location="../WSDLs/YES_Y_SDSA_SALESDOC_MASS_ASI.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:masstransferresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/USCOM_Product/XQueryResources/MassTransferResponse/";

declare function xf:MassTransferResponse($response as element(ns2:YSdsaSalesdocMassAsiResponse))
    as element(ns1:MassTransferResponse) {
        <ns1:MassTransferResponse>
            <ns1:MassTransferResponseBody>
                <ns1:MassTransferResponseProperties>
                    <ns1:ProcessCompleteStatus>{ data($response/EYyprostatus) }</ns1:ProcessCompleteStatus>
                </ns1:MassTransferResponseProperties>
                {
                    for $item in $response/EtResMassItm/item
                    return
                        <ns1:MassTransferResponseDetails>
                            <ns1:SalesDocumentIdentifier>
                                <ns1:SalesDocumentType>{ data($item/Yytranstype) }</ns1:SalesDocumentType>
                                <ns0:DocumentReference>
                                    <ns0:DocumentIdentifier>{ data($item/Yyvbeln) }</ns0:DocumentIdentifier>
                                </ns0:DocumentReference>
                            </ns1:SalesDocumentIdentifier>
                            <ns1:LockingInformation>
                                <ns1:LockStatus>{ data($item/Yylckfail) }</ns1:LockStatus>
                                <ns1:InternalNameLock>{ data($item/Yysapname) }</ns1:InternalNameLock>
                                <ns1:ExternalUserIdLock>{ data($item/Yywebuserid) }</ns1:ExternalUserIdLock>
                            </ns1:LockingInformation>
                        </ns1:MassTransferResponseDetails>
                }
            </ns1:MassTransferResponseBody>
            {
                for $item in $response/EtMessage/item
                return
                    <ns1:MassTransferResponseError>
                        <ns1:ErrorType>{ data($item/YymsgType) }</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/YymsgId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ xs:integer( data($item/YymsgNo) ) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ data($item/YymsgObject) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/YymsgDescInt) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/YymsgDescExt) }</ns1:ErrorMessageDisplayText>
                    </ns1:MassTransferResponseError>
            }
        </ns1:MassTransferResponse>
};

declare variable $response as element(ns2:YSdsaSalesdocMassAsiResponse) external;

xf:MassTransferResponse($response)
