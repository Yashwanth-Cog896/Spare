(:: pragma bea:global-element-parameter parameter="$exclusionListRequest" element="ns1:ExclusionListRequest" location="../Schemas/ExclusionListRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaAsiMatExclusionCall" location="../WSDLs/YES_SDSA_ASI_MAT_EXCLUSION.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:exclusionlistrequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/USCOM_Product/XQueryResources/MaterialExclusionListRequest/";

declare function xf:MaterialExclusionListRequest($exclusionListRequest as element(ns1:ExclusionListRequest))
    as element(ns2:YSdsaAsiMatExclusionCall) {
        <ns2:YSdsaAsiMatExclusionCall>
            <Yycropyear>{ data($exclusionListRequest/ns1:ExclusionListRequestBody/ns1:FiscalYear) }</Yycropyear>
            <Yyvkorg>
                <item>{ data($exclusionListRequest/ns1:ExclusionListRequestBody/ns1:BrandInformation/ns1:BrandIdentifier) }</item>
            </Yyvkorg>
        </ns2:YSdsaAsiMatExclusionCall>
};

declare variable $exclusionListRequest as element(ns1:ExclusionListRequest) external;

xf:MaterialExclusionListRequest($exclusionListRequest)
