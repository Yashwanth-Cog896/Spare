(:: pragma bea:global-element-parameter parameter="$request" element="ns1:MassTransferRequest" location="../WSDLs/YES_Y_SDSA_SALESDOC_MASS_ASI.wsdl" ::)
(:: pragma bea:global-element-return element="ns2:YSdsaSalesdocMassAsi" location="../WSDLs/YES_Y_SDSA_SALESDOC_MASS_ASI_RFC.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:masstransferrequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/USCOM_Product/XQueryResources/MassTransferRequest/";

declare function xf:MassTransferRequest($request as element(ns1:MassTransferRequest))
    as element(ns2:YSdsaSalesdocMassAsi) {
        let $request := $request
        return
            <ns2:YSdsaSalesdocMassAsi>
                <IYyhdrchgtype>{ data($request/ns1:MassTransferRequestBody/ns1:MassTransferRequestProperties/ns1:ChangeType) }</IYyhdrchgtype>
                <IYysessionid>{ substring(data($request/ns1:MassTransferRequestBody/ns1:MassTransferRequestProperties/ns1:SessionIdentifier),1,50) }</IYysessionid>
                <IYywebuserid>{ data($request/ns1:MassTransferRequestBody/ns1:MassTransferRequestProperties/ns1:UserId) }</IYywebuserid>
                <ItReqMassItm>
                    {
                        for $MassTransferRequestDetails  in ($request/ns1:MassTransferRequestBody/ns1:MassTransferRequestDetails)  
                        return
                            for $MassTransferLineItem  in ($MassTransferRequestDetails/ns1:MassTransferLineItem)  
                            return
                                (<item>
                                <Yyvbeln>{ xs:string( data($MassTransferRequestDetails/ns1:SalesDocumentIdentifier/ns0:DocumentReference/ns0:DocumentIdentifier) ) }</Yyvbeln>
                                <Yyitmchgtype>{ data($MassTransferLineItem/ns1:ItemChangeType) }</Yyitmchgtype>
                                <Yymatnr>{ xs:string( data($MassTransferLineItem/ns1:ProductIdentification/ns0:ProductIdentifier) ) }</Yymatnr>
                                <Yyvrkme>{ concat($MassTransferLineItem/ns1:ReturnToSeedCompany/ns1:ReturnToSeedCompanyUnits/ns0:Measurement/ns0:UnitOfMeasureCode , $MassTransferLineItem/ns1:DealerOrderTransfer/ns1:OrderUnits/ns0:Measurement/ns0:UnitOfMeasureCode , $MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:OrderUnits/ns0:Measurement/ns0:UnitOfMeasureCode) }</Yyvrkme>
                                <Yyposnr>{ xs:string( data($MassTransferLineItem/ns0:LineNumber) ) }</Yyposnr>
                                <YykwmengPrshrtn>{ xs:decimal( data($MassTransferLineItem/ns1:ReturnToSeedCompany/ns1:ReturnToSeedCompanyUnits/ns0:Measurement/ns0:MeasurementValue) ) }</YykwmengPrshrtn>
                                <YykwmengGo2do>{ xs:decimal( data($MassTransferLineItem/ns1:DealerOrderTransfer/ns1:OrderUnits/ns0:Measurement/ns0:MeasurementValue) ) }</YykwmengGo2do>
                                <YykwmengGo2go>{ xs:decimal( data($MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:OrderUnits/ns0:Measurement/ns0:MeasurementValue) ) }</YykwmengGo2go>
                                <Yytargetgo>{ xs:string( data($MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:SalesDocumentIdentifier/ns0:DocumentReference/ns0:DocumentIdentifier) ) }</Yytargetgo>
                                <YykunnrSp>{ data($MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:GrowerIdNumber) }</YykunnrSp>
                                <YykunnrDlr>{ concat($MassTransferLineItem/ns1:DealerOrderTransfer/ns1:DealerIdNumber , $MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:DealerIdNumber) }</YykunnrDlr>
                                <Yycorlot>{ concat($MassTransferLineItem/ns1:ReturnToSeedCompany/ns1:LotNumber , $MassTransferLineItem/ns1:DealerOrderTransfer/ns1:LotNumber , $MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:LotNumber) }</Yycorlot>
                                <Yydlvdate>{ xs:string( fn:tokenize(data($MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:DeliveredDate/ns0:DateTime), 'T')[1] ) }</Yydlvdate>
                                <Yydlvflag>{ xs:string( data($MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:DeliveredIndicator) ) }</Yydlvflag>
                                <Yydiscnt>{ xs:string( data($MassTransferLineItem/ns1:GrowerOrderTransfer/ns1:DiscountTransferIndicator) ) }</Yydiscnt>
                                  </item>)
                    }
</ItReqMassItm>
                <ItReqMassOrd>
                    {
                        for $MassTransferRequestDetails in $request/ns1:MassTransferRequestBody/ns1:MassTransferRequestDetails
                        return
                            <item>
                                <Yyordertype>{ data($MassTransferRequestDetails/ns1:SalesDocumentIdentifier/ns1:SalesDocumentType) }</Yyordertype>
                                <Yyvbeln>{ xs:string( data($MassTransferRequestDetails/ns1:SalesDocumentIdentifier/ns0:DocumentReference/ns0:DocumentIdentifier) ) }</Yyvbeln>
                            </item>
                    }
                </ItReqMassOrd>
            </ns2:YSdsaSalesdocMassAsi>
};

declare variable $request as element(ns1:MassTransferRequest) external;

xf:MassTransferRequest($request)