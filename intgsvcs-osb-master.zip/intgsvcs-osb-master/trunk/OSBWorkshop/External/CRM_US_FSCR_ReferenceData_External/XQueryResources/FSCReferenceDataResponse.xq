(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YfscGetDropdownListsResponse" location="../WSDLs/FSCRReferenceDataCRM.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:FSCReferenceDataResponse" location="../Schemas/FSCReferenceDataResponse.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fscreferencedataresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_ReferenceData/XQueryResources/FSCReferenceDataResponse/";

declare function xf:FSCReferenceDataResponse($response as element(ns2:YfscGetDropdownListsResponse))
    as element(ns1:FSCReferenceDataResponse) {
        <ns1:FSCReferenceDataResponse>
            <ns1:FSCReferenceDataResponseBody>
                {
                    for $item in $response/EtPrimaryconcernlist/item
                    return
                        <ns1:PrimaryConcernList>
                            <ns1:ConcernCode>{ data($item/YyconcernCode) }</ns1:ConcernCode>
                            <ns1:ConcernDescription>{ data($item/YyconcernText) }</ns1:ConcernDescription>
                        </ns1:PrimaryConcernList>
                }
                {
                    for $item in $response/EtSettlementlist/item
                    return
                        <ns1:SettlementList>
                            <ns1:SettlementCode>{ data($item/YysettlemntCode) }</ns1:SettlementCode>
                            <ns1:SettlementDescription>{ data($item/YysettlemntDesc) }</ns1:SettlementDescription>
                            <ns1:SettlementType>{ data($item/YysettlementTyp) }</ns1:SettlementType>
                        </ns1:SettlementList>
                }
                {
                    for $item in $response/EtStatuslist/item
                    return
                        <ns1:StatusList>
                            <ns1:StatusCode>{ data($item/YystatusCode) }</ns1:StatusCode>
                            <ns1:StatusProfile>{ data($item/YystatusProfile) }</ns1:StatusProfile>
                            <ns1:StatusShortDescription>{ data($item/YystatusSdesc) }</ns1:StatusShortDescription>
                            <ns1:StatusLongDescription>{ data($item/YystatusLdesc) }</ns1:StatusLongDescription>
                        </ns1:StatusList>
                }
                {
                    for $item in $response/EtPartnerlist/item
                    return
                        <ns1:PartnerFunctionList>
                            <ns1:PartnerFunctionCode>{ data($item/YypartnerFn) }</ns1:PartnerFunctionCode>
                            <ns1:PartnerFunctionDescription>{ data($item/YypartnerDesc) }</ns1:PartnerFunctionDescription>
                        </ns1:PartnerFunctionList>
                }
                {
                    for $item in $response/EtDatelist/item
                    return
                        <ns1:DateTypeList>
                            <ns1:DateTypeCode>{ data($item/YydatetypeId) }</ns1:DateTypeCode>
                            <ns1:DateTypeDescription>{ data($item/YydatetypeDesc) }</ns1:DateTypeDescription>
                        </ns1:DateTypeList>
                }
                {
                    for $item in $response/EtTextlist/item
                    return
                        <ns1:TextIDList>
                            <ns1:TextCode>{ data($item/YytextId) }</ns1:TextCode>
                            <ns1:TextDescription>{ data($item/YytextDesc) }</ns1:TextDescription>
                        </ns1:TextIDList>
                }
            </ns1:FSCReferenceDataResponseBody>
            {
                let $result :=
                    for $item in $response/EtErrorlist/item
                    return
                        <ns1:FSCReferenceDataResponseError>
                            <ns1:ErrorType>{ data($item/Type) }</ns1:ErrorType>
                            <ns1:ErrorMessageClass>{ data($item/Code) }</ns1:ErrorMessageClass>
                            <ns1:ErrorMessageNumber>{ xs:integer( data($item/LogMsgNo) ) }</ns1:ErrorMessageNumber>
                            <ns1:ErrorMessageObject>{ data($item/LogNo) }</ns1:ErrorMessageObject>
                            <ns1:ErrorMessageText>{ data($item/Message) }</ns1:ErrorMessageText>
                            <ns1:ErrorMessageDisplayText>{ concat($item/MessageV1 , $item/MessageV2 , $item/MessageV3 , $item/MessageV4) }</ns1:ErrorMessageDisplayText>
                        </ns1:FSCReferenceDataResponseError>
                return
                    $result[1]
            }
        </ns1:FSCReferenceDataResponse>
};

declare variable $response as element(ns2:YfscGetDropdownListsResponse) external;

xf:FSCReferenceDataResponse($response)
