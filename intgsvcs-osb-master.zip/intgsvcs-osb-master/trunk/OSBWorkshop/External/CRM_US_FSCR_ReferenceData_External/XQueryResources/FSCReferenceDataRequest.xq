(:: pragma bea:global-element-parameter parameter="$request" element="ns1:FSCReferenceDataRequest" location="../Schemas/FSCReferenceDataRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YfscGetDropdownLists" location="../WSDLs/FSCRReferenceDataCRM.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fscreferencedatarequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_ReferenceData/XQueryResources/FSCReferenceDataRequest/";

declare function xf:FSCReferenceDataRequest($request as element(ns1:FSCReferenceDataRequest))
    as element(ns2:YfscGetDropdownLists) {
        <ns2:YfscGetDropdownLists>
            <IProcessType>{ xs:string( data($request/ns1:FSCReferenceDataRequestBody/ns1:ProcessType) ) }</IProcessType>
        </ns2:YfscGetDropdownLists>
};

declare variable $request as element(ns1:FSCReferenceDataRequest) external;

xf:FSCReferenceDataRequest($request)
