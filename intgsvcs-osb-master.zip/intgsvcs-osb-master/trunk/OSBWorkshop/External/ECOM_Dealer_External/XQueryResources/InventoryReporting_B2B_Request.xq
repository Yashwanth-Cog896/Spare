(:: pragma bea:global-element-parameter parameter="$request" element="ns0:InventoryActualUsage" location="../Schemas/InventoryActualUsageRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns1:InventoryMobile" location="../Schemas/InventoryReportingRequest_1-0.xsd" ::)

declare namespace ns2 = "urn:cidx:names:specification:ces:schema:all:4:0";
declare namespace ns1 = "urn:ecms:schema:inventory:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:1";
declare namespace xf = "http://tempuri.org/ECOM_Dealer_External/XQueryResources/InventoryReporting_B2B_Request/";

declare function xf:InventoryReporting_B2B_Request($request as element(ns0:InventoryActualUsage))
    as element(ns1:InventoryMobile) {
        <ns1:InventoryMobile>
            <ns2:Header>
                <ns2:ThisDocumentIdentifier>
                    <ns2:DocumentIdentifier>{ data($request/ns0:Header/ns0:ThisDocumentIdentifier/ns0:DocumentIdentifier) }</ns2:DocumentIdentifier>
                </ns2:ThisDocumentIdentifier>
                <ns2:ThisDocumentDateTime>
                    <ns2:DateTime DateTimeQualifier = "On">{ data($request/ns0:Header/ns0:ThisDocumentDateTime/ns0:DateTime) }</ns2:DateTime>
                </ns2:ThisDocumentDateTime>
                <ns2:From>
                    <ns2:PartnerInformation>
                        {
                            for $PartnerName in $request/ns0:Header/ns0:From/ns0:PartnerInformation/ns0:PartnerName
                            return
                                <ns2:PartnerName>{ data($PartnerName) }</ns2:PartnerName>
                        }
                        <ns2:PartnerIdentifier Agency = "{ data($request/ns0:Header/ns0:From/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($request/ns0:Header/ns0:From/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns2:PartnerIdentifier>
                        {
                            for $ContactInformation in $request/ns0:Header/ns0:From/ns0:PartnerInformation/ns0:ContactInformation
                            return
                                <ns2:ContactInformation>
                                    {
                                        for $ContactName in $ContactInformation/ns0:ContactName
                                        return
                                            <ns2:ContactName>{ data($ContactName) }</ns2:ContactName>
                                    }
                                    {
                                        for $ContactDescription in $ContactInformation/ns0:ContactDescription
                                        return
                                            <ns2:ContactDescription>{ data($ContactDescription) }</ns2:ContactDescription>
                                    }
                                </ns2:ContactInformation>
                        }
                    </ns2:PartnerInformation>
                </ns2:From>
                <ns2:To>
                    <ns2:PartnerInformation>
                        {
                            for $PartnerName in $request/ns0:Header/ns0:To/ns0:PartnerInformation/ns0:PartnerName
                            return
                                <ns2:PartnerName>{ data($PartnerName) }</ns2:PartnerName>
                        }
                        <ns2:PartnerIdentifier Agency = "{ data($request/ns0:Header/ns0:To/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) }">{ data($request/ns0:Header/ns0:To/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) }</ns2:PartnerIdentifier>
                    </ns2:PartnerInformation>
                </ns2:To>
            </ns2:Header>
            <ns1:InventoryPartners OwnerID = "{ xs:string( data($request/ns0:InventoryActualUsageBody/ns0:InventoryActualUsagePartners/ns0:Buyer/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) ) }"
                                   OwnerQual = "{ xs:string( data($request/ns0:InventoryActualUsageBody/ns0:InventoryActualUsagePartners/ns0:Buyer/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) ) }">
                <ns1:OwnerName>{ xs:string( data($request/ns0:InventoryActualUsageBody/ns0:InventoryActualUsagePartners/ns0:Buyer/ns0:PartnerInformation/ns0:PartnerName[1]) ) }</ns1:OwnerName>
            </ns1:InventoryPartners>
            <ns1:InventoryDetails>
                {
                    for $InventoryUsageLineItem at $countLineItem in $request/ns0:InventoryActualUsageBody/ns0:InventoryActualUsageDetails/ns0:InventoryUsageLineItem,
                     $InventoryUsageInformation at $countUsageInfo in $InventoryUsageLineItem/ns0:InventoryUsageInformation
                    return
                        <ns1:InventoryDetail LocationID = "{ xs:string( data($InventoryUsageLineItem/ns0:InventoryUsageLocation/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) ) }"
                                             LocationQual = "{ xs:string( data($InventoryUsageLineItem/ns0:InventoryUsageLocation/ns0:PartnerInformation/ns0:PartnerIdentifier[1]/@Agency) ) }"
                                             GTIN = "{ data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryProduct/ns0:ProductIdentification[1]/ns0:ProductIdentifier) }"
                                             LotNumber = "{ data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryProduct/ns0:ProductIdentification[1]/ns0:ProductClassification) }"
                                             PhysicalCountIND = "false"
                                             ProductUOM = "{ data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryLevel/ns0:InventoryOnSite/ns0:InventoryOther/ns0:MeasurementInformation/ns0:SpecifiedMeasurement/ns0:Measurement/ns0:UnitOfMeasureCode) }"
                                             Quantity = "{ data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryLevel/ns0:InventoryOnSite/ns0:InventoryOther/ns0:MeasurementInformation/ns0:SpecifiedMeasurement/ns0:Measurement/ns0:MeasurementValue) }"
                                             AsOFDate = "{ data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryLevel/ns0:DateTime) }"
                                             SoldNotDel = "{ xs:string(data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryUsageActual/ns0:InventoryUsage/ns0:MeasurementInformation/ns0:SpecifiedMeasurement/ns0:Measurement/ns0:MeasurementValue)) }"
                                             DateChanged = "{ data($InventoryUsageLineItem/ns0:InventoryUsageInformation[$countUsageInfo]/ns0:InventoryUsageActual/ns0:DateTimeRange/ns0:ToDateTime) }">
                            <ns1:LocationName>{ xs:string( data($InventoryUsageLineItem/ns0:InventoryUsageLocation/ns0:PartnerInformation/ns0:PartnerName[1]) ) }</ns1:LocationName>
                        </ns1:InventoryDetail>
                }
            </ns1:InventoryDetails>
       
        </ns1:InventoryMobile>
};

declare variable $request as element(ns0:InventoryActualUsage) external;

xf:InventoryReporting_B2B_Request($request)