(:: pragma bea:global-element-parameter parameter="$request" element="ns1:RecordLockingRequest" location="../Schemas/RecordLockingRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns2:YfscLockUnlockComplaint" location="../WSDLs/FSCRecordLockUnlockCRM.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:recordlockingrequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_RecordLockUnlock/XQueryResources/FSCRecordLockUnlockRequest/";

declare function xf:FSCRecordLockUnlockRequest($request as element(ns1:RecordLockingRequest))
    as element(ns2:YfscLockUnlockComplaint) {
        <ns2:YfscLockUnlockComplaint>
            <ILockflg>{ data($request/ns1:RecordLockingRequestBody/ns1:LockIndicator) }</ILockflg>
            <IObjectId>{ xs:string( data($request/ns1:RecordLockingRequestBody/ns1:SalesDocumentIdentifier[1]/ns0:DocumentReference/ns0:DocumentIdentifier) ) }</IObjectId>
            <ISessionid>{ data($request/ns1:RecordLockingRequestBody/ns1:SessionIdentifier) }</ISessionid>
            <IWebuserid>{ data($request/ns1:RecordLockingRequestBody/ns1:UserId) }</IWebuserid>
        </ns2:YfscLockUnlockComplaint>
};

declare variable $request as element(ns1:RecordLockingRequest) external;

xf:FSCRecordLockUnlockRequest($request)
