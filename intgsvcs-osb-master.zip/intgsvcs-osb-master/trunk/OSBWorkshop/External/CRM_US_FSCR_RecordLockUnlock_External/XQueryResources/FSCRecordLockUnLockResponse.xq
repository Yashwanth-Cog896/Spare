(:: pragma bea:global-element-parameter parameter="$response" element="ns2:YfscLockUnlockComplaintResponse" location="../WSDLs/FSCRecordLockUnlockCRM.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:RecordLockingResponse" location="../Schemas/RecordLockingResponse.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:recordlockingresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_RecordLockUnlock/XQueryResources/FSCRecordLockUnLock/";

declare function xf:FSCRecordLockUnLock($response as element(ns2:YfscLockUnlockComplaintResponse))
    as element(ns1:RecordLockingResponse) {
        <ns1:RecordLockingResponse>
            <ns1:RecordLockingResponseBody>
                <ns1:LockStatus>{ data($response/ELckstatus) }</ns1:LockStatus>
                <ns1:InternalNameLock>{ data($response/ESapname) }</ns1:InternalNameLock>
                <ns1:ExternalUserIdLock>{ data($response/EWebuserid) }</ns1:ExternalUserIdLock>
            </ns1:RecordLockingResponseBody>
            {
                for $item in $response/EtMessage/item
                return
                    <ns1:RecordLockingResponseError>
                        <ns1:ErrorType>
                            {
                                if (data($item/YymsgType) = "3") then
                                    ("S")
                                else 
                                    if (data($item/YymsgType) = "5") then
                                        ("E")
                                            else 
                                                data($item/YymsgType)
                            }
</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/YymsgId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ xs:integer( data($item/YymsgNo) ) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ data($item/YymsgObject) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/YymsgDescInt) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/YymsgDescExt) }</ns1:ErrorMessageDisplayText>
                    </ns1:RecordLockingResponseError>
            }
        </ns1:RecordLockingResponse>
};

declare variable $response as element(ns2:YfscLockUnlockComplaintResponse) external;

xf:FSCRecordLockUnLock($response)
