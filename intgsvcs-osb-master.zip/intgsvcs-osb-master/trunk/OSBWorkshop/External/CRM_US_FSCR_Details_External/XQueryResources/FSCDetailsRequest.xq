(:: pragma bea:global-element-parameter parameter="$request" element="ns0:FSCDetailsRequest" location="../Schemas/FSCDetailsRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns1:_-crmost_-yesCustcmplidqrRead" location="../WSDLs/FSCDetailsCRM.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:otc:schema:fscdetailsrequest:request:1:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_Details/XQueryResources/FSCDetailsRequest/";

declare function xf:FSCDetailsRequest($request as element(ns0:FSCDetailsRequest))
    as element(ns1:_-crmost_-yesCustcmplidqrRead) {
        <ns1:_-crmost_-yesCustcmplidqrRead>
            <Input>
                <YesCustcmplidqr>
                    <ObjectId>{ xs:string( data($request/ns0:FSCDetailsRequestBody/ns0:FSCNumber )) }</ObjectId>
                    <ProcessType>{ xs:string( data($request/ns0:FSCDetailsRequestBody/ns0:ProcessType) ) }</ProcessType>
                </YesCustcmplidqr>
            </Input>
        </ns1:_-crmost_-yesCustcmplidqrRead>
};

declare variable $request as element(ns0:FSCDetailsRequest) external;

xf:FSCDetailsRequest($request)
