(:: pragma bea:global-element-parameter parameter="$response" element="ns2:_-crmost_-yesCustcmplidqrReadResponse" location="../WSDLs/FSCDetailsCRM.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:FSCDetailsResponse" location="../Schemas/FSCDetailsResponse.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fscdetailsresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_Details/XQueryResources/test/";

declare function xf:test($response as element(ns2:_-crmost_-yesCustcmplidqrReadResponse))
    as element(ns1:FSCDetailsResponse) {
        <ns1:FSCDetailsResponse Version = "1.0">
            <ns1:FSCDetailsResponseBody>
                <ns1:FSCDetailsResponseProperties>
                    <ns1:ProcessType>{ data($response/Output/YesCustcmplidqr/ProcessType) }</ns1:ProcessType>
                    <ns1:FSCNumber>{ data($response/Output/YesCustcmplidqr/ObjectId) }</ns1:FSCNumber>
                    <ns1:FSCUUID>{ data($response/Output/YesCustcmplidqr/CrmGuid) }</ns1:FSCUUID>
                    <ns1:FSCStatus>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Statusofheader/All/item[1]/StatusCode) }</ns1:FSCStatus>
                    <ns1:FSCStatusProfile>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Statusofheader/All/item[1]/RefUserStatusProfileCode) }</ns1:FSCStatusProfile>
                    <ns1:BrandInformation>
                        <ns1:BrandIdentifier>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Organizationaldataofheader/SalesOrganisationID) }</ns1:BrandIdentifier>
                    </ns1:BrandInformation>
                    <ns1:DistrictSalesManagerNumber>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Organizationaldataofheader/SalesGroupID) }</ns1:DistrictSalesManagerNumber>
                    <ns1:FiscalYear>{ xs:integer( data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Customerextensionofheader/YymarketYear) ) }</ns1:FiscalYear>
                    <ns1:ConcernDescription>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Description) }</ns1:ConcernDescription>
                    <ns1:PrimaryConcern>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Refobjandsubjofheader/Service/Allsubjects/item[1]/Code) }</ns1:PrimaryConcern>
                    <ns1:Latitude>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Serviceofheader/Yyfld00000k) }</ns1:Latitude>
                    <ns1:Longitude>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Serviceofheader/Yyfld00000p) }</ns1:Longitude>
                    <ns1:RetailerName>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Serviceofheader/Yyfld00001a) }</ns1:RetailerName>
                    <ns1:RetailerCityName>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Serviceofheader/Yyfld00001b) }</ns1:RetailerCityName>
                    <ns1:RetailerState>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Serviceofheader/Yyfld00001k) }</ns1:RetailerState>
                    {
                        for $item in $response/Output/YesCustcmplidqr/CustomerComplaintHeader/Partiesinvolvedofheader/Data/item
                        return
                            <ns1:FSCPartnerInformation>
                                <ns1:PartnerUUID>{ data($item/PartnerGuid) }</ns1:PartnerUUID>
                                <ns1:PartnerRoleCode>{ data($item/RefPartnerFct) }</ns1:PartnerRoleCode>
                                <ns1:PartnerID>{ data($item/RefPartnerNo) }</ns1:PartnerID>
                                <ns1:PartnerFullName>{ data($item/FormattedName) }</ns1:PartnerFullName>
                            </ns1:FSCPartnerInformation>
                    }
                    <ns1:FSCTextInformation>
                        <ns1:FSCTextUUID>{ data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/Btheadertextset/UUID) }</ns1:FSCTextUUID>
                        {
                            for $item in $response/Output/YesCustcmplidqr/CustomerComplaintHeader/Btheadertextset/Text/item
                            return
                                <ns1:FSCTextDetails>
                                    <ns1:FSCProblemTextID>{ data($item/TextTypeCode) }</ns1:FSCProblemTextID>
                                    <ns1:FSCProblemText>{ data($item/ContentText) }</ns1:FSCProblemText>
                                </ns1:FSCTextDetails>
                        }
                    </ns1:FSCTextInformation>
                    <ns1:FSCCreateDate>
                        <ns0:DateTime DateTimeQualifier = "On">
                            {
                                if (data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime/text()) != '') then
                                    (fn:concat(fn:substring(data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime),1,4),'-',
                                    fn:substring(data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime),5,2),'-',
                                    fn:substring(data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime),7,2),'T',
                                    fn:substring(data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime),9,2),':',
                                    fn:substring(data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime),11,2),':',
                                    fn:substring(data($response/Output/YesCustcmplidqr/CustomerComplaintHeader/CreationDateTime),13,2),'Z'))
                                else 
                                    ()
                            }
</ns0:DateTime>
                    </ns1:FSCCreateDate>
                </ns1:FSCDetailsResponseProperties>
                {
                    for $item in $response/Output/YesCustcmplidqr/CustomerComplaintHeader/Itemsofheader/Data/item
                    return
                        <ns1:FSCProblemProductDetails>
                            <ns1:ItemUUID>{ data($item/UUID) }</ns1:ItemUUID>
                            <ns1:ProductIdentifier>{ data($item/ProductID) }</ns1:ProductIdentifier>
                            <ns1:ProductName>{ data($item/Description) }</ns1:ProductName>
                            <ns1:ProductItemID>{ data($item/ItemID) }</ns1:ProductItemID>
                            <ns1:ParentIdentifier>{ xs:integer( data($item/ParentItemID) ) }</ns1:ParentIdentifier>
                            <ns1:SettlementType>{ data($item/ProcessingTypeCode) }</ns1:SettlementType>
                            {
                                for $item0 in $item/ScheduleLine/Data/item
                                return
                                    <ns1:FSCProductQuantityUUID>{ data($item0/Guid) }</ns1:FSCProductQuantityUUID>
                            }
                             {
                              if(data($item/ScheduleLine/Data/item[1]/Quantity/text())!='') then (
                              <ns1:FSCProductQuantity>
                                <ns0:MeasurementValue>{ xs:double( data($item/ScheduleLine/Data/item[1]/Quantity) ) }</ns0:MeasurementValue>
                            </ns1:FSCProductQuantity>
                              ) else()
                            }
                            
                            <ns1:PlantingInformation>
                                <ns1:PlantingDateUUID>{ data($item/TimePointAndDurationTerms/UUID) }</ns1:PlantingDateUUID>
                               {
                               
                                if (data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo/text()) != '') then
                                    (
                                     <ns1:PlantingDate>
                                    	<ns0:DateTime>{ 
                                    		 fn:concat(fn:substring(data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo),1,4),'-',
			                                    fn:substring(data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo),5,2),'-',
			                                    fn:substring(data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo),7,2),'T',
			                                    fn:substring(data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo),9,2),':',
			                                    fn:substring(data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo),11,2),':',
			                                    fn:substring(data($item/TimePointAndDurationTerms/Alldates/item[1]/TimestampTo),13,2),'Z')
                                    	
                                    	 }</ns0:DateTime>
                                	 </ns1:PlantingDate>
                                    
                                   )
                                else 
                                    ()
                               
                                }
                                <ns1:PlantingRoleCode>{ data($item/TimePointAndDurationTerms/Alldates/item[1]/ApptType) }</ns1:PlantingRoleCode>
                                <ns1:AcresPlantedQuantity>
                                    <ns0:Measurement>
                                        <ns0:MeasurementValue>{ xs:double( data($item/Product/Yyfld00000y) ) }</ns0:MeasurementValue>
                                        <ns0:UnitOfMeasureCode>{ data($item/Product/Yyfld00000z) }</ns0:UnitOfMeasureCode>
                                    </ns0:Measurement>
                                </ns1:AcresPlantedQuantity>
                                <ns1:PlantedRateQuantity>
                                    <ns0:Measurement>
                                        <ns0:MeasurementValue>{ xs:double( data($item/Product/Yyfld000010) ) }</ns0:MeasurementValue>
                                        <ns0:UnitOfMeasureCode>{ data($item/Product/Yyfld000011) }</ns0:UnitOfMeasureCode>
                                    </ns0:Measurement>
                                </ns1:PlantedRateQuantity>
                                <ns1:PlantPopulationQuantity>
                                    <ns0:Measurement>
                                        <ns0:MeasurementValue>{ xs:double( data($item/Product/Yyfld000012) ) }</ns0:MeasurementValue>
                                        <ns0:UnitOfMeasureCode>{ data($item/Product/Yyfld000013) }</ns0:UnitOfMeasureCode>
                                    </ns0:Measurement>
                                </ns1:PlantPopulationQuantity>
                                <ns1:PercentAffected>{ data($item/Product/Yyfld00000t) }</ns1:PercentAffected>
                                <ns1:LotNumber>{ data($item/Product/BatchId) }</ns1:LotNumber>
                            </ns1:PlantingInformation>
                            <ns1:RequestedCompensationAmount>
                                <ns0:MonetaryAmount>
                                    <ns0:MonetaryValue>{ data($item/PriceAndTaxCalculation/Data/item[1]/RateAmount) }</ns0:MonetaryValue>
                                    <ns0:CurrencyCode>{ data($item/PriceAndTaxCalculation/Data/item[1]/RateAmountCurrencyCode) }</ns0:CurrencyCode>
                                </ns0:MonetaryAmount>
                                <ns1:RequestedCompensationAmountUUID>{ data($item/PriceAndTaxCalculation/Data/item[1]/Knumv) }</ns1:RequestedCompensationAmountUUID>
                            </ns1:RequestedCompensationAmount>
                            <ns1:ProblemProductStatus>{ data($item/Status/All/item[1]/RefStatusCode) }</ns1:ProblemProductStatus>
                        </ns1:FSCProblemProductDetails>
                }
            </ns1:FSCDetailsResponseBody>
            {
                for $item in $response/Output/Log/Item/item
                return
                    <ns1:FSCDetailsResponseError>
                        <ns1:ErrorType>
                            {
                                if (data($response/Output/Log/ProcessingResultCode) = "3") then
                                    ("S")
                                else 
                                    if (data($response/Output/Log/ProcessingResultCode) = "5") then
                                        ("E")
                                    else 
                                        data($response/Output/Log/ProcessingResultCode)
                            }
</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/TypeId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ fn:substring(data($item/TypeId) ,1,3) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ fn:substring(data($item/TypeId),5,fn:string-length(data($item/TypeId))-5) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/Note) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/Note) }</ns1:ErrorMessageDisplayText>
                    </ns1:FSCDetailsResponseError>
            }
        </ns1:FSCDetailsResponse>
};

declare variable $response as element(ns2:_-crmost_-yesCustcmplidqrReadResponse) external;

xf:test($response)
