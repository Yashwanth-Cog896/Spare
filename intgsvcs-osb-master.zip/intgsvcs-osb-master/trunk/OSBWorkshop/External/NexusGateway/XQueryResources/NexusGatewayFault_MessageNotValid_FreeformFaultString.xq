declare namespace monisd = "urn:ecms:function:isd"; 
declare function monisd:formatNexusGatewayFaultMessageNotValid 
  ( $faultstringText as xs:string? )  as node() {


    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:nexusGateway="urn:nexusgateway:names:ws:docexchange">',
      'nexusgateway:MessageNotValid',
      '</faultcode>',
      '<faultstring>', 
      $faultstringText, 
      '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $faultstringText as xs:string? external;

monisd:formatNexusGatewayFaultMessageNotValid($faultstringText)