declare namespace monisd = "urn:ecms:function:isd"; 
declare namespace soapenv="http://schemas.xmlsoap.org/soap/envelope/";
declare function monisd:formatNexusFaultMessageNotValid 
  ( $fault as node() )  as node() {

    let $faultcodeElement := fn-bea:inlinedXML(fn:concat(
      '<faultcode xmlns:nexusGateway="urn:nexusgateway:names:ws:docexchange">',
      'nexusgateway:MessageNotValid',
      '</faultcode>'))

    let $soapFault :=
    element { xs:QName("soapenv:Fault") }
      { $faultcodeElement,
         element { "faultstring" } {"Schema validation errors, please see body of this message for details"},
         element { "details" } {$fault}
      }

    return $soapFault
 } ;

declare variable $fault as node() external;

monisd:formatNexusFaultMessageNotValid($fault)