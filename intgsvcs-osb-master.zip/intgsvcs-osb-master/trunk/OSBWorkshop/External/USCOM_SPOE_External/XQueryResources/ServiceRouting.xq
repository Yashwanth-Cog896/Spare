(:	Template for SinglePointOfEntry_External

To add a new service add the tags <service> through </service> to the ServiceOptions routing table.
Fill in each ? mark with the appropiate field.  T/F for all attributes.  Based on whether the attributes
are true or false will determine if a value between the tags is needed.  Refer to the SinglePointOfEntry.docx 
on teamsite on how to use the SinglePointOfEntry_External Proxy Service.

	<service>
		<rootNode Version="?">?</rootNode>
		<security CheckMessageLevelAuthentication="?" checkForNonZMT0Request="?">
			<authorizationPipeline CheckAuthorization="?">?</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="?">
			<serviceName>?</serviceName>
			<headerType>?</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>?</alertEmailAddressDefault>
			<alertEmailAddressPS>?</alertEmailAddressPS>
			<alertEmailAddressIT>?</alertEmailAddressIT>
			<alertEmailAddressDevl>?</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="?">
			<retryCount BestEffort="?">?</retryCount>
			<intervalTimeSeconds>?</intervalTimeSeconds>
		</QoS>
	</service>	
:)

<serviceOptions>
	<service>
		<rootNode Version="1.0">MassTransferRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>MassTransfer</serviceName>
			<headerType>CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSO_ListShipTos_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ListShipTos</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSO_OrderChange_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderChange</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderCreate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderCreate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderDetails_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderDetails</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderDetailsModify_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderDetailsModify</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOOrderSummary_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderSummary</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOProductSelection_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ProductSelection</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_CSOSOSalesRepSoldTos_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SalesRepSoldTos</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-AG-FarmSourceApplicationTeam@stl.Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>DL-1000-AG-MyMonsantoNonProdApplicationError@Monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">saveAnalytics</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>STAnalyticsClient</serviceName>
			<headerType>uscom</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SeedTrak-Developers@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">uploadAnalyticsData</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>STAnalyticsMobile</serviceName>
			<headerType>uscom</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SeedTrak-Developers@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_WLASampleRetrieval_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SampleRetrieval</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>qm.team.sap@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_WLAPlantingDate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>PlantingDate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>qm.team.sap@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronProductService_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ProductService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronOrderDetail_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderDetail</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">MT_OSB_AcceleronOrderUpdate_Req</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>OrderUpdate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">FileUploadStatusUpdateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>FileUploadStatus</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SEEDTRMT-IT@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">findGrowerBySalesAssociate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">USCOM_Grower_External/ProxyServices/GrowerLookup</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">version</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">USCOM_Grower_External/ProxyServices/GrowerLookup</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">findProgramsParticipating</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">USCOM_Grower_External/ProxyServices/GrowerLookup</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">findGrower</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">USCOM_Grower_External/ProxyServices/GrowerLookup</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GrowerLookup</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	
	<service>
		<rootNode Version="0.0">accountLinkCheckRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">USCOM_Grower_External/ProxyServices/SingleSignOn</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SingleSignOn</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">FuturesPricingRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>FuturesPricing</serviceName>
			<headerType>PIBLANK</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">SoybeanHedgingListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SoybeanHedgingList</serviceName>
			<headerType>PIBLANK</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">SoybeanHedgingChangeRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SoybeanHedgingChange</serviceName>
			<headerType>PIBLANK</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getCropsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getProductsBySalesTerritoriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getSubCountriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getSubSubCountriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getSupportedYearsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrCreateFxoptions</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>360T_CreateFXOptions</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFtdCreate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>360T_FTDCreate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFtdRollover</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>360T_FTDRollover</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFxtCreate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>360T_FXTCreate</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiFtrFxtCreateswap</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>360T_FXTCreateSwap</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,sap.support.finance.procurement@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	<service>
		<rootNode Version="0.0">getIPlotPdfReportRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getIPlotReportDataRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">harvestReportDomainRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsByCRDsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsByPostalCodeAndRadiusRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsBySubCountriesAndSubsubCountriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">searchIPlotRptsByTerritorySalesManagersRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">smartServiceDomainRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>IPlotDataService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	
	<service>
		<rootNode Version="0.0">getProductHPIDetails</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">US_AGS_SeedProductDetails_External/ProxyServices/AGSSeedProductDetails</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ProductHPIStabilityService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	

	<service>
		<rootNode Version="0.0">getProductStabilityDetails</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">US_AGS_SeedProductDetails_External/ProxyServices/AGSSeedProductDetails</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ProductHPIStabilityService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">seedingRateVersion</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">US_AGS_SeedingRateService_External/ProxyServices/AGSSeedingRateService</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SeedingRateService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">calculateSeedingRate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="T">US_AGS_SeedingRateService_External/ProxyServices/AGSSeedingRateService</authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SeedingRateService</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">getUomListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getProductsBySubCountryRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getMonsantoProductsBySubCountryRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getMonsantoProductsBySalesTerritoriesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">getBrandsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ReferenceData_CropPerformance</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,DL-TSA-ADMINS@Monsanto.com,DL-USST-CFA-MarketingApps-Dev@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="2.0">ApplicationAnalyticsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ApplicationAnalyticsService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>DL-1000-SeedTrak-Developers@Monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS></alertEmailAddressPS>
			<alertEmailAddressIT></alertEmailAddressIT>
			<alertEmailAddressDevl></alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YbapiQuotCreatefromdata2</rootNode>
		<security CheckMessageLevelAuthentication="T" CheckForNonZMT0Request="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>QuotationCreatefromdata2</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YBrStatusPreorderGet</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>StatusPreorderGet</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerLocationRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_DealerLocation</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerLookupRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_DealerLookup</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerProductSearchRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_DealerProductSearch</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
		
	<service>
		<rootNode Version="1.0">AdvanceProductSearchRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_AdvanceProductSearch</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">ProductSearchRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ProductSearch</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">StockTransferListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_StockTransferList</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	<service>
		<rootNode Version="1.0">StockTransferUpdateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_UpdateService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">StockTransferDetailsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_DetailsService</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerFavoritesRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectronicStockTransfer_DealerFavorites</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">DealerEmailRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>ElectrnoicStockTransfer_DealerEmail</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtRfcTradcontract</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_TradeContract</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtRfcBarterCampaign</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_Campaign</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtBarterCancelSo</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_CancelSalesOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtContrSimul</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_ContractSimulation</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtCreditCheck</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_CreditCheck</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtQuotaOrder</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_QuotaOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtStatusBarter</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_SimulationStatus</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtTermsData</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_TermsData</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtStatusContract</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_StatusContract</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtSupportCellInfo</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_SupportCellInfo</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtTermsOrder</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_TermsOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">AutenticaUsuario</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_ProcessBarter</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">IniciarProcesso</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_ProcessBarter</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YFibtChangeOrder</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_ChangeSalesOrder</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YFibtSalesOrderSimulate</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>BrazilBarter_SalesOrderSimulation</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com,commodities.brasil@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	
	<service>
		<rootNode Version="0.0">YFiarGbcredit</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GoldenBeans_GBCredit</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YlasPyGbrecla</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GoldenBeans_GBRecla</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YlasPyGenSoGbToSap</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GGoldenBeans_Gen</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="0.0">YlasPyDownInvSapToGb</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GoldenBeans_Down</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">YlasPyGbcollect</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GoldenBeans_GBCollect</serviceName>
			<headerType>piblank</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">SHUpdateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SHUpdate</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
		<service>
		<rootNode Version="1.0">SHDataRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>SHDataRequest</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	
	<service>
		<rootNode Version="0.0">CreateSpecialDiscountRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>CreateSpecialDiscount</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">GetSpecialDiscountApprovalStatusRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GetSpecialDiscountApprovalStatus</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">GetAccrualsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>GetAccruals</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="0.0">onServiceResponseUpdated</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>PLDAWebservice</serviceName>
			<headerType>emptyHeader</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
<service>
		<rootNode Version="1.0">LicenseStatusAdvanceRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>Mobility_LicenseStatus</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	<service>
		<rootNode Version="1.0">LicenseStatusIDRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>Mobility_LicenseStatus</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
	<service>
		<rootNode Version="1.0">LicenseStatusPostalCodeRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>Mobility_LicenseStatus</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	<service>
		<rootNode Version="1.0">AccountLookupRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>Mobility_AccountLookup</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>

	
	<service>
		<rootNode Version="1.0">AllBrandProductAvailabilityRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName>Mobility_AllBrandProductAvailability</serviceName>
			<headerType>USCOM</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>  
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
</serviceOptions>