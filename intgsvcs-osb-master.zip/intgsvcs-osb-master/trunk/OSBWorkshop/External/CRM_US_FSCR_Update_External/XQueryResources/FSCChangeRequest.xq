(:: pragma bea:global-element-parameter parameter="$request" element="ns1:FSCChangeRequest" location="../Schemas/FSCChangeRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns2:_-crmost_-yesCustcmplchgrcChg" location="../WSDLs/FSCUpdate_CRM.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fscchangerequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_Update/XQueryResources/FSCChangeRequest/";

declare function xf:FSCChangeRequest($request as element(ns1:FSCChangeRequest))
    as element(ns2:_-crmost_-yesCustcmplchgrcChg) {
        <ns2:_-crmost_-yesCustcmplchgrcChg>
            <Input>
                <YesCustcmplchgrc>
                    <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                    <ProcessingTypeCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:ProcessType) ) }</ProcessingTypeCode>
                    <ObjectId>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCNumber) ) }</ObjectId>
                    <CustomerComplaintHeader>
                        <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                        <ObjectId>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCNumber) ) }</ObjectId>
                        <ProcessType>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:ProcessType) ) }</ProcessType>
                        <Description>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:ConcernDescription) }</Description>
                        <Guid>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCUUID) }</Guid>
                        <Itemsofheader>
                            <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                            <UUID>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCUUID) }</UUID>
                            <Data>
                                {
                                    for $FSCChangeProblemProductDetails in $request/ns1:FSCChangeRequestBody/ns1:FSCChangeProblemProductDetails
                                    return
                                        <item>
                                            <ActionCode>{ xs:string( data($FSCChangeProblemProductDetails/ns1:ProblemProductActionCode) ) }</ActionCode>
                                            <ItemID>{ data($FSCChangeProblemProductDetails/ns1:ProductItemID) }</ItemID>
                                            <ObjectId>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCNumber) ) }</ObjectId>
                                            <ProcessType>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:ProcessType) ) }</ProcessType>
                                            <ProcessingTypeCode>{ data($FSCChangeProblemProductDetails/ns1:SettlementType) }</ProcessingTypeCode>
                                            <ParentItemID>{ xs:string( data($FSCChangeProblemProductDetails/ns1:ParentIdentifier) ) }</ParentItemID>
                                            <ProductID>{ data($FSCChangeProblemProductDetails/ns1:ProductIdentifier) }</ProductID>
                                            <PriceAndTaxCalculation>
                                                <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns1:RequestedCompensationAmountActionCode) }</ActionCode>
                                                <UUID>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns1:ProductItemReferenceUUID) }</UUID>
                                                <Data>
                                                    <item>
                                                        <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns1:RequestedCompensationAmountActionCode) }</ActionCode>
                                                        <Kposn>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns1:ProductItemReferenceUUID) }</Kposn>
                                                        <Knumv>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns1:RequestedCompensationAmountUUID) }</Knumv>
                                                        <RefGuid>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns1:ProductItemReferenceUUID) }</RefGuid>
                                                        <RateAmountCurrencyCode>{ xs:string( data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns0:MonetaryAmount/ns0:CurrencyCode) ) }</RateAmountCurrencyCode>
                                                        <RateAmount>{ data($FSCChangeProblemProductDetails/ns1:RequestedCompensationAmount/ns0:MonetaryAmount/ns0:MonetaryValue) }</RateAmount>
                                                    </item>
                                                </Data>
                                            </PriceAndTaxCalculation>
                                            <TimePointAndDurationTerms>
                                                <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantingDateActionCode) }</ActionCode>
                                                <UUID>{ data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantingDateUUID) }</UUID>
                                                <All>
                                                    <item>
                                                        <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantingDateActionCode) }</ActionCode>
                                                        <ApptType>{ xs:string( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantingRoleCode) ) }</ApptType>
                                                        <RefGuid>{ data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantingDateUUID) }</RefGuid>
                                                        <FromDateTime>{ fn:replace(fn:replace(fn:replace(fn:replace(data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantingDate/ns0:DateTime), 'Z', '') , 'T','') , ':',''),'-','') }</FromDateTime>
                                                    </item>
                                                </All>
                                            </TimePointAndDurationTerms>
                                            {
											if(data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode/text())='01') 
											then (  if ( fn:empty(data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity))) 
														then() 
														else (
															<ScheduleLine>
											                                                <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode) }</ActionCode>
																					  <Data>
																						  	 <item>
																									 <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode) }</ActionCode>
																									 <Quantity>{ xs:decimal( data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns0:MeasurementValue) ) }</Quantity>
																							</item>
																						</Data>
															</ScheduleLine>
																)	
											
											
											) else(
												
													if(fn:empty(data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity))) 
													then () 
													else (
												
														if(data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode/text())='01') 
														then (
																<ScheduleLine>
											                                                <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode) }</ActionCode>
											                                                <UUID>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductItemReferenceUUID) }</UUID>
																					  <Data>
																						  	 <item>
																									 <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode) }</ActionCode>
																									 <RefGuid>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductItemReferenceUUID) }</RefGuid>
																									 <Quantity>{ xs:decimal( data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns0:MeasurementValue) ) }</Quantity>
																									 
																							</item>
																						</Data>
															</ScheduleLine>
														) 
														else (
																<ScheduleLine>
											                                                <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode) }</ActionCode>
											                                                <UUID>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductItemReferenceUUID) }</UUID>
											                                                <Data>
											                                                    {
											                                                        for $FSCProductQuantityUUID in $FSCChangeProblemProductDetails/ns1:FSCProductQuantityUUID
											                                                        return
											                                                            <item>
											                                                                <ActionCode>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductQuantityActionCode) }</ActionCode>
											                                                                <Guid>{ data($FSCProductQuantityUUID) }</Guid>
											                                                                <RefGuid>{ data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns1:ProductItemReferenceUUID) }</RefGuid>
											                                                                <Quantity>{ xs:decimal( data($FSCChangeProblemProductDetails/ns1:FSCProductQuantity/ns0:MeasurementValue) ) }</Quantity>
											                                                            </item>
											                                                    }
											                                                </Data>
																</ScheduleLine>
														)
														
													)
											)
											}
                                            <Product>
                                                <ActionCode>{ xs:string( data($FSCChangeProblemProductDetails/ns1:ProblemProductActionCode) ) }</ActionCode>
                                                <Guid>{ data($FSCChangeProblemProductDetails/ns1:ItemUUID) }</Guid>
                                                <Yyfld000013>{ xs:string( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantPopulationQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yyfld000013>
                                                <Yyfld000012>{ xs:decimal( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantPopulationQuantity/ns0:Measurement/ns0:MeasurementValue) ) }</Yyfld000012>
                                                <Yyfld000011>{ xs:string( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantedRateQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yyfld000011>
                                                <Yyfld000010>{ xs:decimal( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PlantedRateQuantity/ns0:Measurement/ns0:MeasurementValue) ) }</Yyfld000010>
                                                <Yyfld00000z>{ xs:string( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:AcresPlantedQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yyfld00000z>
                                                <Yyfld00000y>{ xs:decimal( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:AcresPlantedQuantity/ns0:Measurement/ns0:MeasurementValue) ) }</Yyfld00000y>
                                                <Yyfld00000t>{ data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:PercentAffected) }</Yyfld00000t>
                                                <BatchId>{ xs:string( data($FSCChangeProblemProductDetails/ns1:PlantingInformation/ns1:LotNumber) ) }</BatchId>
                                            </Product>
                                        </item>
                                }
                            </Data>
                        </Itemsofheader>
                        <Partiesinvolvedofheader>
                            <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPartnerInformation[1]/ns1:PartnerActionCode) ) }</ActionCode>
                            <UUID>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPartnerInformation[1]/ns1:PartnerUUID) }</UUID>
                            <Data>
                                <item>
                                    <RefPartnerNo>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPartnerInformation[1]/ns1:PartnerID) ) }</RefPartnerNo>
                                    <RefPartnerFct>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPartnerInformation[1]/ns1:PartnerRoleCode) }</RefPartnerFct>
                                    <Communication>
                                        <EMailURI>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPartnerInformation[1]/ns0:EmailAddress) ) }</EMailURI>
                                    </Communication>
                                </item>
                            </Data>
                        </Partiesinvolvedofheader>
                        <Statusofheader>
                            <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                            <UUID>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCUUID) }</UUID>
                            <All>
                                <item>
                                    <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                                    <RefUserStatusProfileCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCStatusProfile) ) }</RefUserStatusProfileCode>
                                    <RefGuid>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCUUID) }</RefGuid>
                                    <StatusCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCStatus) ) }</StatusCode>
                                </item>
                            </All>
                        </Statusofheader>
                        <Refobjandsubjofheader>
                            <Service>
                                <Allsubjects>
                                    <item>
                                        <Code>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:PrimaryConcern) ) }</Code>
                                    </item>
                                </Allsubjects>
                            </Service>
                        </Refobjandsubjofheader>
                        <Btheadertextset>
                            <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                            <UUID>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCTextInformation/ns1:FSCTextUUID) }</UUID>
                            <Text>
                                {
                                    for $FSCTextDetails in $request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCTextInformation/ns1:FSCTextDetails
                                    return
                                        <item>
                                            <ActionCode>{ xs:string( data($FSCTextDetails/ns1:FSCTextActionCode) ) }</ActionCode>
                                            <TextTypeCode>{ data($FSCTextDetails/ns1:FSCProblemTextID) }</TextTypeCode>
                                            <RefGuid>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCTextInformation/ns1:FSCTextUUID) }</RefGuid>
                                            <ContentText>{ data($FSCTextDetails/ns1:FSCProblemText) }</ContentText>
                                        </item>
                                }
                            </Text>
                        </Btheadertextset>
                        <Organizationaldataofheader>
                            <SalesOrganisationID>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:BrandInformation/ns1:BrandIdentifier) }</SalesOrganisationID>
                        </Organizationaldataofheader>
                        <Serviceofheader>
                            <ActionCode>{ xs:string( data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCPropertiesActionCode) ) }</ActionCode>
                            <Guid>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:FSCUUID) }</Guid>
                            <Yyfld00000k>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:Latitude) }</Yyfld00000k>
                            <Yyfld00000p>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:Longitude) }</Yyfld00000p>
                            <Yyfld00001a>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:RetailerName) }</Yyfld00001a>
                            <Yyfld00001b>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:RetailerCityName) }</Yyfld00001b>
                            <Yyfld00001k>{ data($request/ns1:FSCChangeRequestBody/ns1:FSCChangeRequestProperties/ns1:RetailerState) }</Yyfld00001k>
                        </Serviceofheader>
                    </CustomerComplaintHeader>
                </YesCustcmplchgrc>
            </Input>
        </ns2:_-crmost_-yesCustcmplchgrcChg>
};

declare variable $request as element(ns1:FSCChangeRequest) external;

xf:FSCChangeRequest($request)
