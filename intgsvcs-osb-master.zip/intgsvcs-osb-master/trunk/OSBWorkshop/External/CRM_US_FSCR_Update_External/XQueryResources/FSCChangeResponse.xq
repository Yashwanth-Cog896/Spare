(:: pragma bea:global-element-parameter parameter="$response" element="ns2:_-crmost_-yesCustcmplchgrcChgResponse" location="../WSDLs/FSCUpdate_CRM.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:FSCChangeResponse" location="../Schemas/FSCChangeResponse.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fscchangeresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_Update/XQueryResources/FSCChangeResponse/";

declare function xf:FSCChangeResponse($response as element(ns2:_-crmost_-yesCustcmplchgrcChgResponse))
    as element(ns1:FSCChangeResponse) {
        <ns1:FSCChangeResponse>
            <ns1:FSCChangeResponseBody>
                <ns1:ProcessType>{ data($response/Output/YesCustcmplchgrc/ProcessType) }</ns1:ProcessType>
                <ns1:FSCNumber>{ data($response/Output/YesCustcmplchgrc/ObjectId) }</ns1:FSCNumber>
            </ns1:FSCChangeResponseBody>
            {
                for $item in $response/Output/Log/Item/item
                return
                    <ns1:FSCChangeResponseError>
                        <ns1:ErrorType>
                            {
                                if (data($response/Output/Log/ProcessingResultCode) = 3) then
                                    ("S")
                                else 
                                    if (data($response/Output/Log/ProcessingResultCode) = 5) then
                                        ("E")
                                    else 
                                        data($response/Output/Log/ProcessingResultCode)
                            }
						</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/TypeId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ fn:substring(data($item/TypeId) ,1,3) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ fn:substring(data($item/TypeId),5,fn:string-length(data($item/TypeId))-5) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/Note) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/Note) }</ns1:ErrorMessageDisplayText>
                    </ns1:FSCChangeResponseError>
            }
        </ns1:FSCChangeResponse>
};

declare variable $response as element(ns2:_-crmost_-yesCustcmplchgrcChgResponse) external;

xf:FSCChangeResponse($response)
