(:: pragma bea:global-element-parameter parameter="$productBooking" element="ns0:ProductBooking" location="../Schemas/ProductBooking.xsd" ::)
(:: pragma bea:global-element-return element="ns1:YSaGetGrowerOrder" location="../WSDLs/YES_Y_SA_GET_GROWER_ORDER.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:3";
declare namespace xf = "http://tempuri.org/CRM_B2B_ProductBookingSummary/XQueryResources/ProductBooking_Request/";

declare function xf:ProductBooking_Request($productBooking as element(ns0:ProductBooking))
    as element(ns1:YSaGetGrowerOrder) {
        <ns1:YSaGetGrowerOrder>        	
	         <IvCustomerH>X</IvCustomerH>       
	         <IvCustomerI></IvCustomerI>          
	         <IvIbsd></IvIbsd>          
	         <IvMode></IvMode>        
	         <IvOtherAtt></IvOtherAtt>         
	         <IvPartner>X</IvPartner>         
	         <IvProduct></IvProduct>         	
	         <IvReporttype>GODCY</IvReporttype> 
	         <IvSales>X</IvSales>         
	         <IvSchedlin>X</IvSchedlin> 
	         <IvSeedyear>{ xs:string( data($productBooking/ns0:ProductBookingBody[1]/ns0:ProductBookingProperties/ns0:ProductYear) ) }</IvSeedyear>
	         <IvSoldTo>{ xs:string( data($productBooking/ns0:ProductBookingBody[1]/ns0:ProductBookingPartners/ns0:SoldTo/ns0:PartnerInformation/ns0:PartnerIdentifier[1]) ) }</IvSoldTo>
	         <IvStatusH></IvStatusH>            
        </ns1:YSaGetGrowerOrder>
};

declare variable $productBooking as element(ns0:ProductBooking) external;

xf:ProductBooking_Request($productBooking)
