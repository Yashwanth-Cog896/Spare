<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0"
				xmlns:urn="urn:cidx:names:specification:ces:schema:all:5:3">
   
   <xsl:param name="partnerName"/>
   <xsl:param name="partnerIdentifier"/>
   <xsl:param name="partnerAgency"/>  

   
   <!-- Identity transform -->
   <xsl:template match="@* | node()">
      <xsl:copy>
         <xsl:apply-templates select="@* | node()"/>
      </xsl:copy>
   </xsl:template>

   <xsl:template match="urn:ProductBookingResponsePartners">
      <xsl:copy>
          <urn:Buyer>
	         <urn:PartnerInformation>
	            <urn:PartnerName><xsl:value-of select="$partnerName"/></urn:PartnerName>
	            <urn:PartnerIdentifier> 
	            	<xsl:attribute name="Agency">
	            		<xsl:value-of select="$partnerAgency"/>
	            	</xsl:attribute>
	            	<xsl:value-of select="$partnerIdentifier"></xsl:value-of>
	            </urn:PartnerIdentifier>
	          </urn:PartnerInformation>
	      </urn:Buyer>
	      <urn:Seller>
	      	<urn:PartnerInformation>
	            <urn:PartnerName>Monsanto</urn:PartnerName>
	            <urn:PartnerIdentifier><xsl:attribute name="Agency">AGIIS-EBID</xsl:attribute>0062668030000</urn:PartnerIdentifier>
	          </urn:PartnerInformation>
	      </urn:Seller>
	      <urn:ShipTo>
	      	<urn:PartnerInformation>
	            <urn:PartnerName><xsl:value-of select="$partnerName"/></urn:PartnerName>
	            <urn:PartnerIdentifier> 
	            	<xsl:attribute name="Agency">
	            		<xsl:value-of select="$partnerAgency"/>
	            	</xsl:attribute>
	            	<xsl:value-of select="$partnerIdentifier"></xsl:value-of>
	            </urn:PartnerIdentifier>
	          </urn:PartnerInformation>
	      </urn:ShipTo>
	      <urn:SoldTo>
	      	<urn:PartnerInformation>
	            <urn:PartnerName><xsl:value-of select="$partnerName"/></urn:PartnerName>
	            <urn:PartnerIdentifier> 
	            	<xsl:attribute name="Agency">
	            		<xsl:value-of select="$partnerAgency"/>
	            	</xsl:attribute>
	            	<xsl:value-of select="$partnerIdentifier"></xsl:value-of>
	            </urn:PartnerIdentifier>
	          </urn:PartnerInformation>
	      </urn:SoldTo>
	      <urn:Payer>
	      	<urn:PartnerInformation>
	            <urn:PartnerName><xsl:value-of select="$partnerName"/></urn:PartnerName>
	            <urn:PartnerIdentifier> 
	            	<xsl:attribute name="Agency">
	            		<xsl:value-of select="$partnerAgency"/>
	            	</xsl:attribute>
	            	<xsl:value-of select="$partnerIdentifier"></xsl:value-of>
	            </urn:PartnerIdentifier>
	          </urn:PartnerInformation>
	      </urn:Payer>
	       <xsl:apply-templates/>
      </xsl:copy>
   </xsl:template>
  
</xsl:stylesheet>