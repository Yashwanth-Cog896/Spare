xquery version "1.0" encoding "Cp1252";
(:: pragma bea:global-element-parameter parameter="$ySaGetGrowerOrderResponse" element="ns1:YSaGetGrowerOrderResponse" location="../WSDLs/YES_Y_SA_GET_GROWER_ORDER.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:ProductBookingResponse" location="../Schemas/ProductBooking.xsd" ::)

declare namespace xf = "http://tempuri.org/CRM_B2B_ProductBookingSummary_External/XQueryResources/ProductBooking_Response/";
declare namespace ns1 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:3";

declare function xf:ProductBooking_Response($ySaGetGrowerOrderResponse as element(ns1:YSaGetGrowerOrderResponse))
    as element(ns0:ProductBookingResponse) {
        <ns0:ProductBookingResponse>
        {      
               for $item in distinct-values($ySaGetGrowerOrderResponse/EtGrowerOrder/item/ObjectId) 
               return
               		let  $item2 := ($ySaGetGrowerOrderResponse/EtGrowerOrder/item[ObjectId = $item])[1]
               		return
                	<ns0:ProductBookingResponseBody>
                    	 <ns0:ProductBookingResponseProperties>
                            <ns0:ProductBookingType>SummaryRequest</ns0:ProductBookingType>
                            <ns0:ProductBookingOrderNumber>{xs:string( data($item2/ObjectId))}</ns0:ProductBookingOrderNumber>
                            <ns0:ProductBookingOrderTypeCode>ZZ</ns0:ProductBookingOrderTypeCode>
                            <ns0:ProductBookingOrderIssuedDate>
                                <ns0:DateTime DateTimeQualifier = "On">
                                {
                                	fn:concat(fn:substring(data($item2/CreatedAt),1,4),'-',
												fn:substring(data($item2/CreatedAt),5,2),'-',
												fn:substring(data($item2/CreatedAt),7,2),'T',
												fn:substring(data($item2/CreatedAt),9,2),':',
												fn:substring(data($item2/CreatedAt),11,2),':',
												fn:substring(data($item2/CreatedAt),13,2),'Z')
                                }
                                 </ns0:DateTime>
                            </ns0:ProductBookingOrderIssuedDate>
                            <ns0:LanguageCode>eng</ns0:LanguageCode>
                            <ns0:CurrencyCode>USD</ns0:CurrencyCode>
                        </ns0:ProductBookingResponseProperties>
                        <ns0:ProductBookingResponsePartners>                        	
                        </ns0:ProductBookingResponsePartners>
                        <ns0:ProductBookingResponseDetails>
                            {
		                        for $item0 in $ySaGetGrowerOrderResponse/EtGrowerOrder/item		                        	                           
		                        return
		                             if(data($item0/ObjectId) =  $item) then (
		                                    <ns0:ProductBookingResponseProductLineItem>
				                                <ns0:LineNumber>{ xs:string(data($item0/NumberInt)) }</ns0:LineNumber>
				                                <ns0:ProductBookingOrderLineItemNumber>{ xs:string(data($item0/NumberInt)) }</ns0:ProductBookingOrderLineItemNumber>
				                                <ns0:ProductIdentification>
				                                    <ns0:ProductIdentifier Agency = "AGIIS-ProductID">{ xs:string(data($item0/Yygtin)) }</ns0:ProductIdentifier>
				                                    <ns0:ProductName>{ xs:string (data($item0/Pdescription)) }</ns0:ProductName>
				                                </ns0:ProductIdentification>
				                                <ns0:ProductQuantity>
				                                    <ns0:Measurement>
				                                        <ns0:MeasurementValue >{ xs:string(data($item0/Quantity)) }</ns0:MeasurementValue>
				                                        {
				                                        for  $item1 in $ySaGetGrowerOrderResponse/ProductSummaryOut/item
				                                        return				                                        
				                                        if(data($item0/OrderedProd) = data($item1/YyorderedProd)) then(
				                                        <ns0:UnitOfMeasureCode>{ xs:string(data($item1/YysalesUom)) }</ns0:UnitOfMeasureCode>
				                                        )
				                                        else()
				                                        }
				                                    </ns0:Measurement>
				                                </ns0:ProductQuantity>
				                            </ns0:ProductBookingResponseProductLineItem>
		                                    )
		                                    else()                                
		                            
		                    		}
                 		</ns0:ProductBookingResponseDetails>
                    </ns0:ProductBookingResponseBody>
                	                	}
        </ns0:ProductBookingResponse>
};


declare variable $ySaGetGrowerOrderResponse as element(ns1:YSaGetGrowerOrderResponse) external;

xf:ProductBooking_Response($ySaGetGrowerOrderResponse)
