<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:urn="urn:cidx:names:specification:ces:schema:all:5:3"  exclude-result-prefixes="urn">
<xsl:output method="xml" indent="yes" omit-xml-declaration="yes" />
	 <xsl:template match="/">
	 	<xsl:for-each select="urn:ProductBookingBody">
	 			<IRDSERVICE_REQ>
		 			  <REQUEST>
		 				<xsl:attribute name="KEY">ICNAPDTOSAP</xsl:attribute>
		 				<xsl:attribute name="ID"><xsl:value-of select="position()" /></xsl:attribute>
		 				<FIELD>
		 					<xsl:attribute name="NAME">IC_NAPD</xsl:attribute>
							<xsl:value-of select="urn:ProductBookingPartners/urn:SoldTo/urn:PartnerInformation/urn:PartnerIdentifier" />
						</FIELD>	 				
		 			  </REQUEST>
		 		</IRDSERVICE_REQ>
	 	 </xsl:for-each>
	  </xsl:template>
</xsl:stylesheet>