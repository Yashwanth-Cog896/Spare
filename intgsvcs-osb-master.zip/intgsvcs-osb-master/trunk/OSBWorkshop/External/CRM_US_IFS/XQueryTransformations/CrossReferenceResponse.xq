(:: pragma bea:global-element-parameter parameter="$yCRM_IFS_BP_DETAILSResponse1" element="ns1:YCRM_IFS_BP_DETAILSResponse" location="../WSDLs/CrossReference_SAP.wsdl" ::)
(:: pragma bea:global-element-return element="ns0:BusinessPartnerDetailsResponse" location="../WSDLs/CrossReference_Java.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:rfc:functions";
declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CRM_US_IFS/XQueryTransformations/CrossReferenceResponse/";

declare function xf:CrossReferenceResponse($yCRM_IFS_BP_DETAILSResponse1 as element(ns1:YCRM_IFS_BP_DETAILSResponse))
    as element(ns0:BusinessPartnerDetailsResponse) {
        <ns0:BusinessPartnerDetailsResponse>
            {
                let $GT_ERR := $yCRM_IFS_BP_DETAILSResponse1/GT_ERR
                return
                    <Errors>
                        {
                            for $item in $GT_ERR/item
                            return
                                <item>
                                    <MessageType>{ data($item/YYMSG_TYPE) }</MessageType>
                                    <MessageNumber>{ data($item/YYMSG_NO) }</MessageNumber>
                                    <MessageID>{ data($item/YYMSG_ID) }</MessageID>
                                    <MessageObject>{ data($item/YYMSG_OBJECT) }</MessageObject>
                                    <InternalDescription>{ data($item/YYMSG_DESC_INT) }</InternalDescription>
                                    <ExternalDescription>{ data($item/YYMSG_DESC_EXT) }</ExternalDescription>
                                </item>
                        }
                    </Errors>
            }
            {
                let $GT_FINAL := $yCRM_IFS_BP_DETAILSResponse1/GT_FINAL
                return
                    <Details>
                        {
                            for $item in $GT_FINAL/item
                            return
                                <item>
                                    <BusinessPartnerNum>{ data($item/YBP_NO) }</BusinessPartnerNum>
                                    <NotFound>{ data($item/YNOT_FOUND) }</NotFound>
                                    <DealerCertFlag>{ data($item/YDEALER_CERT) }</DealerCertFlag>
                                    <AgentCertFlag>{ data($item/YAGENT_CERT) }</AgentCertFlag>
                                    <EBID>{ data($item/YEBID) }</EBID>
                                    <GLN>{ data($item/YGLN) }</GLN>
                                    <PPID>{ data($item/YPP) }</PPID>
                                    <SSTID>{ data($item/YSST) }</SSTID>
                                    <MonsantoID>{ data($item/YMONID) }</MonsantoID>
                                    <PartnerGUID>{ data($item/YGUID) }</PartnerGUID>
                                </item>
                        }
                    </Details>
            }
        </ns0:BusinessPartnerDetailsResponse>
};

declare variable $yCRM_IFS_BP_DETAILSResponse1 as element(ns1:YCRM_IFS_BP_DETAILSResponse) external;

xf:CrossReferenceResponse($yCRM_IFS_BP_DETAILSResponse1)
