(:: pragma bea:global-element-parameter parameter="$businessPartnerDetailsRequest1" element="ns0:BusinessPartnerDetailsRequest" location="../WSDLs/CrossReference_Java.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:YCRM_IFS_BP_DETAILS" location="../WSDLs/CrossReference_SAP.wsdl" ::)

declare namespace ns1 = "urn:sap-com:document:sap:rfc:functions";
declare namespace ns0 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace xf = "http://tempuri.org/CRM_US_IFS/XQueryTransformations/CrossReferenceRequest/";

declare function xf:CrossReferenceRequest($businessPartnerDetailsRequest1 as element(ns0:BusinessPartnerDetailsRequest))
    as element(ns1:YCRM_IFS_BP_DETAILS) {
        <ns1:YCRM_IFS_BP_DETAILS>
            {
                for $GtBp in $businessPartnerDetailsRequest1/GtBp
                return
                    <GT_BP>
                        {
                            for $item in $GtBp/item
                            return
                                <item>
                                    <YBP_NO>{ data($item/BusinessPartnerNum) }</YBP_NO>
                                </item>
                        }
                    </GT_BP>
            }
            {
                for $GtEbid in $businessPartnerDetailsRequest1/GtEbid
                return
                    <GT_EBID>
                        {
                            for $item in $GtEbid/item
                            return
                                <item>
                                    <YEBID>{ data($item/EBID) }</YEBID>
                                </item>
                        }
                    </GT_EBID>
            }
            {
                for $GtGln in $businessPartnerDetailsRequest1/GtGln
                return
                    <GT_GLN>
                        {
                            for $item in $GtGln/item
                            return
                                <item>
                                    <YGLN>{ data($item/GLN) }</YGLN>
                                </item>
                        }
                    </GT_GLN>
            }
            {
                for $GtMon in $businessPartnerDetailsRequest1/GtMon
                return
                    <GT_MON>
                        {
                            for $item in $GtMon/item
                            return
                                <item>
                                    <YMON_ID>{ data($item/MonsantoID) }</YMON_ID>
                                </item>
                        }
                    </GT_MON>
            }
            {
                for $GtPp in $businessPartnerDetailsRequest1/GtPp
                return
                    <GT_PP>
                        {
                            for $item in $GtPp/item
                            return
                                <item>
                                    <YPP_NUM>{ data($item/PPID) }</YPP_NUM>
                                </item>
                        }
                    </GT_PP>
            }
            {
                for $GtSst in $businessPartnerDetailsRequest1/GtSst
                return
                    <GT_SST>
                        {
                            for $item in $GtSst/item
                            return
                                <item>
                                    <YSST>{ data($item/SSTID) }</YSST>
                                </item>
                        }
                    </GT_SST>
            }
            <GV_DATE>{ data($businessPartnerDetailsRequest1/GvDate) }</GV_DATE>
        </ns1:YCRM_IFS_BP_DETAILS>
};

declare variable $businessPartnerDetailsRequest1 as element(ns0:BusinessPartnerDetailsRequest) external;

xf:CrossReferenceRequest($businessPartnerDetailsRequest1)
