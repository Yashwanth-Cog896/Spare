(:: pragma bea:global-element-parameter parameter="$response" element="ns2:_-crmost_-yes002btqcompl001dqResponse" location="../WSDLs/FSCListCRM.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:FSCListResponse" location="../WSDLs/FSCList.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fsclistresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_List/XQueryResources/FSCListRes/";

declare function xf:FSCListRes($response as element(ns2:_-crmost_-yes002btqcompl001dqResponse))
    as element(ns1:FSCListResponse) {
        <ns1:FSCListResponse>
            {
                for $item in $response/Output/Queryforcomplaints/item
                return
                    <ns1:FSCListResponseBody>
                        <ns1:DealerEntity>
                            <ns0:PartnerInformation>
                                <ns0:PartnerName>{ data($item/Yydealer) }</ns0:PartnerName>
                            </ns0:PartnerInformation>
                        </ns1:DealerEntity>
                        <ns1:GrowerEntity>
                            <ns1:GrowerAccountInformation>
                                <ns1:AccountName>{ data($item/SoldToPartyList) }</ns1:AccountName>
                                <ns1:AccountNumber>{ data($item/SoldToParty) }</ns1:AccountNumber>
                            </ns1:GrowerAccountInformation>
                        </ns1:GrowerEntity>
                        <ns1:FSCInformation>
                            <ns1:FSCNumber>{ data($item/ObjectId) }</ns1:FSCNumber>
                            <ns1:FSCStatus>{ data($item/Concatstatuser) }</ns1:FSCStatus>
                            <ns1:FSCDescription>{ data($item/Description) }</ns1:FSCDescription>
                            <ns1:FSCDateTime>
                                <ns0:DateTime>{ fn:concat(fn:substring(data($item/YycreateDate),1,4),'-',
                                    fn:substring(data($item/YycreateDate),5,2),'-',
                                    fn:substring(data($item/YycreateDate),7,2),'T',
                                    fn:substring(data($item/YycreateDate),9,2),':',
                                    fn:substring(data($item/YycreateDate),11,2),':',
                                    fn:substring(data($item/YycreateDate),13,2),'Z') }</ns0:DateTime>
                            </ns1:FSCDateTime>
                        </ns1:FSCInformation>
                    </ns1:FSCListResponseBody>
            }
            {
                for $item in $response/Output/Log/Item/item
                return
                    <ns1:FSCListResponseError>
                        <ns1:ErrorType>
                            {
                                if (data($response/Output/Log/ProcessingResultCode) = "3") then
                                    ("S")
                                else 
                                    if (data($response/Output/Log/ProcessingResultCode) = "5") then
                                        ("E")
                                    else 
                                        data($response/Output/Log/ProcessingResultCode)
                            }
</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/TypeId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ fn:substring(data($item/TypeId) ,1,3) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ fn:substring(data($item/TypeId),5,fn:string-length(data($item/TypeId))-5) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/Note) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/Note) }</ns1:ErrorMessageDisplayText>
                    </ns1:FSCListResponseError>
            }
        </ns1:FSCListResponse>
};

declare variable $response as element(ns2:_-crmost_-yes002btqcompl001dqResponse) external;

xf:FSCListRes($response)
