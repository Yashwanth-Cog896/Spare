xquery version "1.0" encoding "Cp1252";
(:: pragma bea:global-element-parameter parameter="$request" element="ns1:FSCListRequest" location="../WSDLs/FSCList.wsdl" ::)
(:: pragma bea:global-element-return element="ns2:_-crmost_-yes002btqcompl001dq" location="../WSDLs/FSCListCRM.wsdl" ::)

declare namespace xf = "http://tempuri.org/CRM_US_FSCR_List/XQueryResources/FSCListReq/";
declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fsclistrequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";

declare function xf:FSCListReq($request as element(ns1:FSCListRequest))
    as element(ns2:_-crmost_-yes002btqcompl001dq) {
        <ns2:_-crmost_-yes002btqcompl001dq>
            <Input>
                <Queryforcomplaints>
                    <BuPartner>
                        <Low>{ xs:string( data($request/ns1:FSCListRequestBody/ns1:DealerIdNumber) ) }</Low>
                    </BuPartner>
                    <SalesGroup>
                        <Low>{ xs:string( data($request/ns1:FSCListRequestBody/ns1:DistrictSalesManagerNumber) ) }</Low>
                    </SalesGroup>
                    <SalesOrg>
                        <Low>{ data($request/ns1:FSCListRequestBody/ns1:BrandInformation/ns1:BrandIdentifier) }</Low>
                    </SalesOrg>
                    <SoldToParty>
                        <Low>{ xs:string( data($request/ns1:FSCListRequestBody/ns1:CustomerNumber) ) }</Low>
                    </SoldToParty>
                    <StatusCommon>
                        <Low>{ xs:string( data($request/ns1:FSCListRequestBody/ns1:Status) ) }</Low>
                    </StatusCommon>
                    <YyitemType>
                        <Low>{ xs:string( data($request/ns1:FSCListRequestBody/ns1:SettlementType) ) }</Low>
                    </YyitemType>
                    <YymarketYear>
                        <Low>{ xs:string( data($request/ns1:FSCListRequestBody/ns1:FiscalYear) ) }</Low>
                    </YymarketYear>
                </Queryforcomplaints>
            </Input>
        </ns2:_-crmost_-yes002btqcompl001dq>
};

declare variable $request as element(ns1:FSCListRequest) external;

xf:FSCListReq($request)
