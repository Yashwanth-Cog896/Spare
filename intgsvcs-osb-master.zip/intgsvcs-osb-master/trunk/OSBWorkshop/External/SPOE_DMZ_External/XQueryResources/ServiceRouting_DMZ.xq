(:	Template for SinglePointOfEntry

To add a new service add the tags <service> through </service> to the ServiceOptions routing table.
Fill in each ? mark with the appropriate field.  T/F for all attributes.  Based on whether the attributes
are true or false will determine if a value between the tags is needed.  Refer to the SinglePointOfEntry.docx 
on teamsite on how to use the SinglePointOfEntry Proxy Service.

	<service>
		<rootNode Version="?">?</rootNode>
		<security CheckMessageLevelAuthentication="?">
			<authorizationPipeline CheckAuthorization="?">?</authorizationPipeline>
		</security>
		<outageName CheckForOutage="?">?</outageName>
		<validationRequestProxy ValidateRequest="?">?</validationRequestProxy>
		<responseValidation ValidateResponse="?">
			<validationResponseProxy>?</validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>?</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS>?</validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT>?</validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl>?</validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="?"></transformRequest>
		<transformResponse ExecuteTransformation="?"></transformResponse>
		<messageReporting ReportRequestResponse="?" ReportErrors="?">
			<serviceName InboundService="?" ExternalService="?" NexusService="?">?</serviceName>
			<headerType>?</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>?</alertEmailAddressDefault>
			<alertEmailAddressPS>?</alertEmailAddressPS>
			<alertEmailAddressIT>?</alertEmailAddressIT>
			<alertEmailAddressDevl>?</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="?">?</routeToBS>
		<QoS ExactlyOnce="?">
			<retryCount BestEffort="?">?</retryCount>
			<intervalTimeSeconds>?</intervalTimeSeconds>
		</QoS>
	</service>	
:)

<serviceOptions>

	<service>
		<rootNode Version="1.0">FSCListRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CRM_US_FSCR_List_External/ProxyServices/FSCListRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CRM_US_FSCR_List_External/XQueryResources/FSCListReq</transformRequest>
		<transformResponse ExecuteTransformation="T">CRM_US_FSCR_List_External/XQueryResources/FSCListRes</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FSCList</serviceName>
			<headerType SaveHeaderForResponse="T">CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CRM_US_FSCR_List_External/BusinessServices/FSCList</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">FSCReferenceDataRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CRM_US_FSCR_ReferenceData_External/ProxyServices/FSCReferenceDataRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CRM_US_FSCR_ReferenceData_External/XQueryResources/FSCReferenceDataRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">CRM_US_FSCR_ReferenceData_External/XQueryResources/FSCReferenceDataResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">ReferenceData</serviceName>
			<headerType SaveHeaderForResponse="T">CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CRM_US_FSCR_ReferenceData_External/BusinessServices/FSCReferenceData</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
		
	<service>
		<rootNode Version="1.0">FSCDetailsRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CRM_US_FSCR_Details_External/ProxyServices/FSCDetailsRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CRM_US_FSCR_Details_External/XQueryResources/FSCDetailsRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">CRM_US_FSCR_Details_External/XQueryResources/FSCDetailsResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FSCDetails</serviceName>
			<headerType SaveHeaderForResponse="T">CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CRM_US_FSCR_Details_External/BusinessServices/FSCDetails</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">RecordLockingRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CRM_US_FSCR_RecordLockUnlock_External/ProxyServices/FSCRecordLockUnlockRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CRM_US_FSCR_RecordLockUnlock_External/XQueryResources/FSCRecordLockUnlockRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">CRM_US_FSCR_RecordLockUnlock_External/XQueryResources/FSCRecordLockUnLockResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FSCRecordLockUnlock</serviceName>
			<headerType SaveHeaderForResponse="T">CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CRM_US_FSCR_RecordLockUnlock_External/BusinessServices/FSCRecordLockUnlock</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	<service>
		<rootNode Version="1.0">FSCCreateRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CRM_US_FSCR_Create_External/ProxyServices/FSCCreateRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CRM_US_FSCR_Create_External/XQueryResources/FSCCreateRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">CRM_US_FSCR_Create_External/XQueryResources/FSCCreateResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FSCCreate</serviceName>
			<headerType SaveHeaderForResponse="T">CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CRM_US_FSCR_Create_External/BusinessServices/FSCCreate</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>	
	
	<service>
		<rootNode Version="1.0">FSCChangeRequest</rootNode>
		<security CheckMessageLevelAuthentication="T">
			<authorizationPipeline CheckAuthorization="F"></authorizationPipeline>
		</security>
		<outageName CheckForOutage="F"></outageName>
		<validationRequestProxy ValidateRequest="T">CRM_US_FSCR_Update_External/ProxyServices/FSCChangeRequest</validationRequestProxy>
		<responseValidation ValidateResponse="F">
			<validationResponseProxy></validationResponseProxy>
			<validationResponseEmailAlert SendErrorEmails="T">
				<validationResponseEmailAlertDefault>integration.services.support@monsanto.com</validationResponseEmailAlertDefault>
				<validationResponseEmailAlertPS></validationResponseEmailAlertPS>
				<validationResponseEmailAlertIT></validationResponseEmailAlertIT>
				<validationResponseEmailAlertDevl></validationResponseEmailAlertDevl>
			</validationResponseEmailAlert>
		</responseValidation>
		<transformRequest ExecuteTransformation="T">CRM_US_FSCR_Update_External/XQueryResources/FSCChangeRequest</transformRequest>
		<transformResponse ExecuteTransformation="T">CRM_US_FSCR_Update_External/XQueryResources/FSCChangeResponse</transformResponse>
		<messageReporting ReportRequestResponse="T" ReportErrors="T">
			<serviceName InboundService="T" ExternalService="T" NexusService="F">FSCChange</serviceName>
			<headerType SaveHeaderForResponse="T">CIDX50</headerType>
		</messageReporting>
		<alertEmailAddress SendErrorEmails="T">
			<alertEmailAddressDefault>integration.services.support@monsanto.com</alertEmailAddressDefault>
			<alertEmailAddressPS>integration.services.delivery@monsanto.com</alertEmailAddressPS>
			<alertEmailAddressIT>integration.services.delivery@monsanto.com</alertEmailAddressIT>
			<alertEmailAddressDevl>integration.services.delivery@monsanto.com</alertEmailAddressDevl>
		</alertEmailAddress>
		<routeToBS Operation="execute">CRM_US_FSCR_Update_External/BusinessServices/FSCChange</routeToBS>
		<QoS ExactlyOnce="T">
			<retryCount BestEffort="F"></retryCount>
			<intervalTimeSeconds></intervalTimeSeconds>
		</QoS>
	</service>
	
	
		
</serviceOptions>