declare namespace urn="urn:monsanto:serviceadmin:services:outage"; 
declare namespace urn1="urn:monsanto:uscomm:service:header";

declare function urn:outageServiceBuildXMLRequest 
  ($serviceNameText as xs:string,
   $docId as xs:string,
   $dateTime as xs:string,
   $partnerName as xs:string)  as node() {


    fn-bea:inlinedXML(
    fn:concat(
      '<urn:GetOutageRequest xmlns:urn="urn:monsanto:serviceadmin:services:outage" xmlns:urn1="urn:monsanto:uscomm:service:header">',
       	'<urn1:Header>',
            '<urn1:DocumentIdentifier>', $docId, '</urn1:DocumentIdentifier>',
            '<urn1:DocumentDateTime>', $dateTime, '</urn1:DocumentDateTime>',
            '<urn1:From>',
               '<urn1:PartnerName>', $partnerName, '</urn1:PartnerName>',
            '</urn1:From>',
        '</urn1:Header>',
      '<urn:GetOutageRequestBody >',
      	'<urn:ApplicationName>',
      	 	$serviceNameText,
      	 '</urn:ApplicationName>',
		'</urn:GetOutageRequestBody>',		      		 
      '</urn:GetOutageRequest>'
      ))

 };

declare variable $serviceNameText as xs:string external;
declare variable $docId as xs:string external;
declare variable $dateTime as xs:string external;
declare variable $partnerName as xs:string external;

urn:outageServiceBuildXMLRequest ($serviceNameText, $docId, $dateTime, $partnerName)