declare namespace monisd = "urn:ecms:function:isd"; 
declare function monisd:formatEmailRoutingFaultMessageNotValid 
  ( $faultstringText as xs:string? )  as node() {


    fn-bea:inlinedXML(fn:concat(
      '<soapenv:Fault  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">', 
      '<faultcode xmlns:EmailRouting="urn:emailrouting:names:ws:docexchange">',
      'EmailRouting:MessageNotValid',
      '</faultcode>',
      '<faultstring>', 
      $faultstringText, 
      '</faultstring>',
      '</soapenv:Fault>'))

 } ;

declare variable $faultstringText as xs:string? external;

monisd:formatEmailRoutingFaultMessageNotValid($faultstringText)