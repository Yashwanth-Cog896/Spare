declare function local:remove-soap-header
 ($XML as element()) as element() {
   element {node-name($XML)}
           {$XML/@*,
            for $child in $XML/node()
            return if ($child instance of element())
                   then if ($child[name() = 'soapenv:Header'])
                        then ()
                        else local:remove-soap-header($child)
                   else $child }
};

declare variable $XML as element() external;

local:remove-soap-header($XML)