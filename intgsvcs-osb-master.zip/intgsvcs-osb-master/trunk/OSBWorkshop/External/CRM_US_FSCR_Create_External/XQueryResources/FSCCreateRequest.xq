(:: pragma bea:global-element-parameter parameter="$request" element="ns1:FSCCreateRequest" location="../Schemas/FSCCreateRequest.xsd" ::)
(:: pragma bea:global-element-return element="ns2:_-crmost_-yesCustcmplcrrcCrt" location="../WSDLs/FSCCreate_CRM.wsdl" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fsccreaterequest:request:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_Create/XQueryResources/FSCCreateRequest/";

declare function xf:FSCCreateRequest($request as element(ns1:FSCCreateRequest))
    as element(ns2:_-crmost_-yesCustcmplcrrcCrt) {
        <ns2:_-crmost_-yesCustcmplcrrcCrt>
            <Input>
                <YesCustcmplcrrc>
                    <ProcessingTypeCode>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:ProcessType) ) }</ProcessingTypeCode>
                    <CustomerComplaintHeader>
                        <ProcessingTypeCode>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:ProcessType) ) }</ProcessingTypeCode>
                        <Description>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:ConcernDescription) }</Description>
                        <Itemsofheader>
                            <Data>
                                {
                                    for $FSCCreateProblemProductDetails in $request/ns1:FSCCreateRequestBody/ns1:FSCCreateProblemProductDetails
                                    return
                                        <item>
                                            <ItemID>{ data($FSCCreateProblemProductDetails/ns1:ProductItemID) }</ItemID>
                                            <ProcessingTypeCode>{ data($FSCCreateProblemProductDetails/ns1:SettlementType) }</ProcessingTypeCode>
                                            <ParentItemID>{ xs:string( data($FSCCreateProblemProductDetails/ns1:ParentIdentifier) ) }</ParentItemID>
                                            <ProductID>{ data($FSCCreateProblemProductDetails/ns1:ProductIdentifier) }</ProductID>
                                            <PriceAndTaxCalculation>
                                                <Data>
                                                    <item>
                                                        <RateAmountCurrencyCode>{ xs:string( data($FSCCreateProblemProductDetails/ns1:RequestedCompensationAmount/ns0:MonetaryAmount/ns0:CurrencyCode) ) }</RateAmountCurrencyCode>
                                                        <RateAmount>{ data($FSCCreateProblemProductDetails/ns1:RequestedCompensationAmount/ns0:MonetaryAmount/ns0:MonetaryValue) }</RateAmount>
                                                    </item>
                                                </Data>
                                            </PriceAndTaxCalculation>
                                            <TimePointAndDurationTerms>
                                                <All>
                                                    <item>
                                                        <ApptType>{ xs:string( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PlantingRoleCode) ) }</ApptType>
                                                        <FromDateTime>{ fn:replace(fn:replace(fn:replace(	fn:replace(data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PlantingDate/ns0:DateTime), 'Z', '') , 'T','') , ':',''),'-','') }</FromDateTime>
                                                    </item>
                                                </All>
                                            </TimePointAndDurationTerms>
                                            <ScheduleLine>
                                                <Data>
                                                    <item>
                                                        <Quantity>{ xs:decimal( data($FSCCreateProblemProductDetails/ns1:FSCProductQuantity/ns0:MeasurementValue) ) }</Quantity>
                                                    </item>
                                                </Data>
                                            </ScheduleLine>
                                            <Product>
                                                <Yyfld000013>{ xs:string( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PlantPopulationQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yyfld000013>
                                                <Yyfld000012>{ xs:decimal( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PlantPopulationQuantity/ns0:Measurement/ns0:MeasurementValue) ) }</Yyfld000012>
                                                <Yyfld000011>{ xs:string( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PlantedRateQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yyfld000011>
                                                <Yyfld000010>{ xs:decimal( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PlantedRateQuantity/ns0:Measurement/ns0:MeasurementValue) ) }</Yyfld000010>
                                                <Yyfld00000z>{ xs:string( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:AcresPlantedQuantity/ns0:Measurement/ns0:UnitOfMeasureCode) ) }</Yyfld00000z>
                                                <Yyfld00000y>{ xs:decimal( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:AcresPlantedQuantity/ns0:Measurement/ns0:MeasurementValue) ) }</Yyfld00000y>
                                                <Yyfld00000t>{ data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:PercentAffected) }</Yyfld00000t>
                                                <ProcessedQuantityUnitCode>{ xs:string( data($FSCCreateProblemProductDetails/ns1:FSCProductQuantity/ns0:UnitOfMeasureCode) ) }</ProcessedQuantityUnitCode>
                                                <BatchId>{ xs:string( data($FSCCreateProblemProductDetails/ns1:PlantingInformation/ns1:LotNumber) ) }</BatchId>
                                            </Product>
                                        </item>
                                }
                            </Data>
                        </Itemsofheader>
                        <Partiesinvolvedofheader>
                            <Data>
                                {
                                    for $FSCPartnerInformation in $request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:FSCPartnerInformation
                                    return
                                        <item>
                                            <ID>{ xs:string( data($FSCPartnerInformation/ns1:PartnerID) ) }</ID>
                                            <RoleCode>{ data($FSCPartnerInformation/ns1:PartnerRoleCode) }</RoleCode>
                                            <Communication>
                                                <EMailURI>{ xs:string( data($FSCPartnerInformation/ns0:EmailAddress) ) }</EMailURI>
                                            </Communication>
                                        </item>
                                }
                            </Data>
                        </Partiesinvolvedofheader>
                        <Statusofheader>
                            <All>
                                <item>
                                    <Status>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:FSCStatus) ) }</Status>
                                    <RefUserStatusProfileCode>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:FSCStatusProfile) ) }</RefUserStatusProfileCode>
                                </item>
                            </All>
                        </Statusofheader>
                        <Refobjandsubjofheader>
                            <Service>
                                <Allsubjects>
                                    <item>
                                        <Code>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:PrimaryConcern) ) }</Code>
                                    </item>
                                </Allsubjects>
                            </Service>
                        </Refobjandsubjofheader>
                        <Btheadertextset>
                            <Text>
                                {
                                    for $FSCTextDetails in $request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:FSCTextInformation/ns1:FSCTextDetails
                                    return
                                        <item>
                                            <TextTypeCode>{ data($FSCTextDetails/ns1:FSCProblemTextID) }</TextTypeCode>
                                            <ContentText>{ data($FSCTextDetails/ns1:FSCProblemText) }</ContentText>
                                        </item>
                                }
                            </Text>
                        </Btheadertextset>
                        <Customerextensionofheader>
                            <YymarketYear>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:FiscalYear) ) }</YymarketYear>
                        </Customerextensionofheader>
                        <Organizationaldataofheader>
                            <SalesOrganisationID>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:BrandInformation/ns1:BrandIdentifier) }</SalesOrganisationID>
                            <SalesGroupID>{ xs:string( data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:DistrictSalesManagerNumber) ) }</SalesGroupID>
                        </Organizationaldataofheader>
                        <Serviceofheader>
                            <Yyfld00000k>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:Latitude) }</Yyfld00000k>
                            <Yyfld00000p>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:Longitude) }</Yyfld00000p>
                            <Yyfld00001a>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:RetailerName) }</Yyfld00001a>
                            <Yyfld00001b>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:RetailerCityName) }</Yyfld00001b>
                            <Yyfld00001k>{ data($request/ns1:FSCCreateRequestBody/ns1:FSCCreateRequestProperties/ns1:RetailerState) }</Yyfld00001k>
                        </Serviceofheader>
                    </CustomerComplaintHeader>
                </YesCustcmplcrrc>
            </Input>
        </ns2:_-crmost_-yesCustcmplcrrcCrt>
};

declare variable $request as element(ns1:FSCCreateRequest) external;

xf:FSCCreateRequest($request)
