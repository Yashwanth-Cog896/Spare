(:: pragma bea:global-element-parameter parameter="$response" element="ns2:_-crmost_-yesCustcmplcrrcCrtResponse" location="../WSDLs/FSCCreate_CRM.wsdl" ::)
(:: pragma bea:global-element-return element="ns1:FSCCreateResponse" location="../Schemas/FSCCreateResponse.xsd" ::)

declare namespace ns2 = "urn:sap-com:document:sap:soap:functions:mc-style";
declare namespace ns1 = "urn:otc:schema:fsccreateresponse:response:1:0";
declare namespace ns0 = "urn:cidx:names:specification:ces:schema:all:5:0";
declare namespace xf = "http://tempuri.org/CRM_US_FSCR_Create/XQueryResources/FSCCreateResponse/";

declare function xf:FSCCreateResponse($response as element(ns2:_-crmost_-yesCustcmplcrrcCrtResponse))
    as element(ns1:FSCCreateResponse) {
        <ns1:FSCCreateResponse>
            <ns1:FSCCreateResponseBody>
                <ns1:ProcessType>{ data($response/Output/YesCustcmplcrrc/ProcessType) }</ns1:ProcessType>
                <ns1:FSCNumber>{ data($response/Output/YesCustcmplcrrc/ObjectId) }</ns1:FSCNumber>
            </ns1:FSCCreateResponseBody>
            {
                for $item in $response/Output/Log/Item/item
                return
                    <ns1:FSCCreateResponseError>
                        <ns1:ErrorType>
                            {
                                if (data($response/Output/Log/ProcessingResultCode) = "3") then
                                    ("S")
                                else 
                                    if (data($response/Output/Log/ProcessingResultCode) = "5") then
                                        ("E")
                                            else 
                                                data($response/Output/Log/ProcessingResultCode)
                            }
</ns1:ErrorType>
                        <ns1:ErrorMessageClass>{ data($item/TypeId) }</ns1:ErrorMessageClass>
                        <ns1:ErrorMessageNumber>{ fn:substring(data($item/TypeId) ,1,3) }</ns1:ErrorMessageNumber>
                        <ns1:ErrorMessageObject>{ fn:substring(data($item/TypeId),5,fn:string-length(data($item/TypeId))-5) }</ns1:ErrorMessageObject>
                        <ns1:ErrorMessageText>{ data($item/Note) }</ns1:ErrorMessageText>
                        <ns1:ErrorMessageDisplayText>{ data($item/Note) }</ns1:ErrorMessageDisplayText>
                    </ns1:FSCCreateResponseError>
            }
        </ns1:FSCCreateResponse>
};

declare variable $response as element(ns2:_-crmost_-yesCustcmplcrrcCrtResponse) external;

xf:FSCCreateResponse($response)
