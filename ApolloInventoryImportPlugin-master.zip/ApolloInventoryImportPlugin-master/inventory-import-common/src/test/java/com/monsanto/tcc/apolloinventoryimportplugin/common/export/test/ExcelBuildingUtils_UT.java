/*
 ExcelBuildingUtils_UT was created on Apr 5, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import junit.framework.TestCase;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ExcelBuildingUtils;

import java.io.File;
import java.io.OutputStream;

/**
 * Filename:    $RCSfile: ExcelBuildingUtils_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2007-04-05 06:54:48 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class ExcelBuildingUtils_UT extends TestCase {
  public ExcelBuildingUtils_UT(String name) {
    super(name);
  }

  public void testCreateInstanceOfFileFromTemplateEnsureFileCanBeDeleted() throws Exception {
    String testFileName = this.getClass().getName().replace('.', File.separatorChar) + ".xls";

    new ExcelBuildingUtils().createInstanceOfFileFromTemplate(testFileName);

    assertTrue(new File(testFileName).exists());
    File file = new File(testFileName);
    if (file.exists()) {
      file.delete();
    }
    assertFalse(new File(testFileName).exists());
  }

  public void testInstanceOfOutputStreamUsingTemplate() throws Exception {
    String testFileName = this.getClass().getName().replace('.', File.separatorChar) + ".xls";

    OutputStream outputStream = new ExcelBuildingUtils().getInstanceOfOutputStreamUsingTemplate(testFileName);

    assertNotNull(outputStream);
    assertTrue(new File(testFileName).exists());

    outputStream.close();
    outputStream = null;
    File file = new File(testFileName);
    if (file.exists()) {
      file.delete();
    }
    assertFalse(new File(testFileName).exists());
  }
}