/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.DateCell;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.Calendar;

/**
 * Filename:    $RCSfile: DateCell_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $    	 On:	$Date: 2007-10-10 19:17:46 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class DateCell_UT extends TestCase {
  public void testDateCellReturnsDate() throws Exception {
    HSSFWorkbook book = new HSSFWorkbook();
    HSSFSheet sheet = book.createSheet("Sheet1");
    HSSFRow row = sheet.createRow(1);
    HSSFCell expectedCell = row.createCell((short)0);

    HSSFCellStyle cellStyle = book.createCellStyle();
    cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy h:mm"));
    Calendar calendar = Calendar.getInstance();
    calendar.set(2007, 3, 10);
    expectedCell.setCellValue(calendar.getTime());
    expectedCell.setCellStyle(cellStyle);

    assertEquals("04/10/2007", new DateCell(expectedCell).getValue());
  }
}