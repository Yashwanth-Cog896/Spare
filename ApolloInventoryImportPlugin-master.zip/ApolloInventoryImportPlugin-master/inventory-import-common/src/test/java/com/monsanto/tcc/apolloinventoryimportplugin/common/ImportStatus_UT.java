package com.monsanto.tcc.apolloinventoryimportplugin.common;

import org.junit.runner.RunWith;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.Test;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.is;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class ImportStatus_UT {
    private static final String DESCRIPTION = "description";
    private static final String STATUS_CODE = "status code";
    private static final long ID = 3L;

    @Test
    public void coverage() {
        ImportStatus importStatus = new ImportStatus();
        importStatus.setId(ID);
        importStatus.setDescription(DESCRIPTION);
        importStatus.setStatusCode(STATUS_CODE);

        assertThat(importStatus.getId(), is(ID));
        assertThat(importStatus.getDescription(), is(DESCRIPTION));
        assertThat(importStatus.getStatusCode(), is(STATUS_CODE));
    }
}
