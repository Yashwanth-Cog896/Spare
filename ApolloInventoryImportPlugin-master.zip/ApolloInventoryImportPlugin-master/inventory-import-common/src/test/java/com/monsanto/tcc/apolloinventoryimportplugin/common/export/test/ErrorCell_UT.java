/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ErrorCell;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: ErrorCell_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $    	 On:	$Date: 2009-06-05 14:08:02 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class ErrorCell_UT extends TestCase {
    private HSSFCell expectedCell;

    protected void setUp() throws Exception {
        super.setUp();
        HSSFWorkbook book = new HSSFWorkbook();
        HSSFSheet sheet = book.createSheet("Sheet1");
        HSSFRow row = sheet.createRow(1);
        expectedCell = row.createCell((short) 0);
    }

    public void testByteValueReturnsValue() throws Exception {
        expectedCell.setCellType(HSSFCell.CELL_TYPE_ERROR);
        expectedCell.setCellErrorValue((byte) 7);

        String sourceString = new ErrorCell(expectedCell).getValue();
        assertNotNull(sourceString);
        assertEquals("7", sourceString);
    }

    public void testNoValueReturnsDefaultValueZero() throws Exception {
        expectedCell.setCellType(HSSFCell.CELL_TYPE_ERROR);

        String sourceString = new ErrorCell(expectedCell).getValue();
        assertNotNull(sourceString);
        assertEquals("15", sourceString);
    }
}