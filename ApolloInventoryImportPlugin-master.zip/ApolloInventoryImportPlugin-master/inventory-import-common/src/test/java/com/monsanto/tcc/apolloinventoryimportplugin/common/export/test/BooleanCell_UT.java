/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.BooleanCell;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;

/**
 * Filename:    $RCSfile: BooleanCell_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $    	 On:	$Date: 2007-10-23 21:03:47 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class BooleanCell_UT extends TestCase {
  public void testFalseBooleanValueReturnsF() throws Exception {
    HSSFWorkbook book = new HSSFWorkbook();
    HSSFSheet sheet = book.createSheet("Sheet1");
    HSSFRow row = sheet.createRow(1);
    HSSFCell expectedCell = row.createCell((short)0);
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BOOLEAN);
    expectedCell.setCellValue(false);

    String sourceString = new BooleanCell(expectedCell).getValue();
    assertNotNull(sourceString);
    assertEquals("F", sourceString);
  }

  public void testTrueBooleanValueReturnsT() throws Exception {
    HSSFWorkbook book = new HSSFWorkbook();
    HSSFSheet sheet = book.createSheet("Sheet1");
    HSSFRow row = sheet.createRow(1);
    HSSFCell expectedCell = row.createCell((short)0);
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BOOLEAN);
    expectedCell.setCellValue(true);

    String sourceString = new BooleanCell(expectedCell).getValue();
    assertNotNull(sourceString);
    assertEquals("T", sourceString);
  }

  public void testNoValueReturnsF() throws Exception {
    HSSFWorkbook book = new HSSFWorkbook();
    HSSFSheet sheet = book.createSheet("Sheet1");
    HSSFRow row = sheet.createRow(1);
    HSSFCell expectedCell = row.createCell((short)0);

    String sourceString = new BooleanCell(expectedCell).getValue();
    assertNotNull(sourceString);
    assertEquals("F", sourceString);
  }
}