package com.monsanto.tcc.apolloinventoryimportplugin.common;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

import java.util.Date;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class ImportedTemplateEntity_UT {
    private static final String CROP_NAME = "crop name";
    private static final String MATERIAL_TYPE = "material type";
    private static final String TEMPLATE_NAME = "template name";

    @Test
    public void coverage() {
        Date createdDate = new Date();

        ImportedTemplateEntity entity = new ImportedTemplateEntity();
        entity.setCreatedDate(createdDate);
        entity.setCropName(CROP_NAME);
        entity.setMaterialType(MATERIAL_TYPE);
        entity.setTemplateName(TEMPLATE_NAME);

        assertThat(entity.getCreatedDate(), sameInstance(createdDate));
        assertThat(entity.getCropName(), is(CROP_NAME));
        assertThat(entity.getMaterialType(), is(MATERIAL_TYPE));
        assertThat(entity.getTemplateName(), is(TEMPLATE_NAME));
        assertThat(entity.getID(), nullValue());
    }
}
