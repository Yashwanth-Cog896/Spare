package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.*;

import java.util.Date;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class XMLDateConverter_UT {
    private XMLDateConverter converter;
    private HierarchicalStreamWriter writer;
    private HierarchicalStreamReader reader;

    @Before
    public void setUp() throws Exception {
        converter = new XMLDateConverter();
        writer = mock(HierarchicalStreamWriter.class);
        reader = mock(HierarchicalStreamReader.class);
    }

    @Test
    public void marshall() {
        converter.marshal(new Date(), writer, null);

        verify(writer).setValue(anyString());
    }

    @Test
    public void unmarshall() {
        when(reader.getValue()).thenReturn("2010-05-10T00:00:00-05:00");

        Object object = converter.unmarshal(reader, null);

        assertThat(object, notNullValue());
        assertThat(object, is(Date.class));
    }
}
