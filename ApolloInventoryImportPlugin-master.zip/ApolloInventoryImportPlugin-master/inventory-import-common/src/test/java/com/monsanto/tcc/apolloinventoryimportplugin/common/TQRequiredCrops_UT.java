package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.google.common.collect.Lists;
import com.monsanto.tps.regulatory.traitquality.isolation.CropTO;
import org.junit.Test;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 9/14/12
 * Time: 2:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class TQRequiredCrops_UT {

    @Test
    public void testGetRequiredCrops() throws Exception {
        TQRequiredCrops.loadTQRequiredCrops(new String[]{"OSR-Canola", "Corn", "Cotton", "Soybeans", "Tomato", "Squash", "Wheat"});
        String[] results = TQRequiredCrops.getRequiredCrops();

        assertNotNull(results);
        assertThat(results.length, is(7));
    }

    @Test
    public void testIsCropTQRequired() throws Exception {
        assertThat(TQRequiredCrops.isCropTQRequired("Corn"), is(true));
        assertThat(TQRequiredCrops.isCropTQRequired("Cor"), is(false));
    }

    @Test
    public void testLoadTQRequiredCrops_string() throws Exception {
        String[] crops = new String[]{"ABC"};
        TQRequiredCrops.loadTQRequiredCrops(crops);

        assertThat(TQRequiredCrops.isCropTQRequired("ABC"), is(true));
        assertThat(TQRequiredCrops.isCropTQRequired("Corn"), is(false));
    }

    @Test
    public void testLoadTQRequiredCrops_list() throws Exception {
        List<CropTO> crops = Lists.newArrayList();
        CropTO crop1 = new CropTO();
        crop1.setName("ABC");
        crops.add(crop1);
        TQRequiredCrops.loadTQRequiredCrops(crops);

        assertThat(TQRequiredCrops.isCropTQRequired("ABC"), is(true));
        assertThat(TQRequiredCrops.isCropTQRequired("Corn"), is(false));
    }

    @Test
    public void testLoadTQRequiredCrops_nullList() throws Exception {
        TQRequiredCrops.loadTQRequiredCrops(new String[]{});
        List<CropTO> nullResults = null;
        TQRequiredCrops.loadTQRequiredCrops(nullResults);

        assertThat(TQRequiredCrops.isCropTQRequired("ABC"), is(false));
        assertThat(TQRequiredCrops.isCropTQRequired("Corn"), is(false));
    }
}
