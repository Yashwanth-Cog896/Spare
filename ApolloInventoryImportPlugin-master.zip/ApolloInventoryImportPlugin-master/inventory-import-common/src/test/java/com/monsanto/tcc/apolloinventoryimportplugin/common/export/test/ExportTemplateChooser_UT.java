package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.AbstractTemplate;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ExcelExportException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ExportTemplateChooser;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ExportTemplateChooser_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    On: $Date: 2007-04-20 06:25:41 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class ExportTemplateChooser_UT extends TestCase {
  public static final String COMMERCIAL_TEMPLATE_CLASS_NAME = "com.monsanto.tcc.apolloinventoryimportplugin.common.export.CommercialTemplate";
  public static final String COMPETITOR_TEMPLATE_CLASS_NAME = "com.monsanto.tcc.apolloinventoryimportplugin.common.export.CompetitorTemplate";
  public static final String CODED_TEMPLATE_CLASS_NAME = "com.monsanto.tcc.apolloinventoryimportplugin.common.export.CodedTemplate";
  public static final String FINISHED_TEMPLATE_CLASS_NAME = "com.monsanto.tcc.apolloinventoryimportplugin.common.export.FinishedTemplate";
  public static final String SEGPOP_TEMPLATE_CLASS_NAME = "com.monsanto.tcc.apolloinventoryimportplugin.common.export.SegpopTemplate";
  public static final String HYBRID_TEMPLATE_CLASS_NAME = "com.monsanto.tcc.apolloinventoryimportplugin.common.export.HybridTemplate";

  public ExportTemplateChooser_UT(String name) {
    super(name);
  }

  public void setUp() throws Exception {
    super.setUp();
  }

  public void tearDown() throws Exception {
    super.tearDown();
  }

  public void testGetCommercialTemplate() throws Exception {
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    AbstractTemplate commercialTemplate = exportTemplateChooser.getTemplate("Commercial");
    assertTrue(COMMERCIAL_TEMPLATE_CLASS_NAME.equals(commercialTemplate.getClass().getName()));
  }

  public void testGetCompetitorTemplate() throws Exception {
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    AbstractTemplate competitorTemplate = exportTemplateChooser.getTemplate("Competitor");
    assertTrue(COMPETITOR_TEMPLATE_CLASS_NAME.equals(competitorTemplate.getClass().getName()));
  }

  public void testGetCodedTemplateSouldFail() throws Exception {
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    AbstractTemplate codedTemplate = exportTemplateChooser.getTemplate("Coded");
    assertTrue(CODED_TEMPLATE_CLASS_NAME.equals(codedTemplate.getClass().getName()));
  }

  public void testGetFinishedTemplateShouldFail() throws Exception {
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    AbstractTemplate finishedTemplate = exportTemplateChooser.getTemplate("Finished");
    assertTrue(FINISHED_TEMPLATE_CLASS_NAME.equals(finishedTemplate.getClass().getName()));
  }

  public void testGetSegpopTemplate() throws Exception {
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    AbstractTemplate segpopTemplate = exportTemplateChooser.getTemplate("Segpop");
    assertTrue(SEGPOP_TEMPLATE_CLASS_NAME.equals(segpopTemplate.getClass().getName()));
  }

  public void testGetHybridTemplate() throws Exception {
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    AbstractTemplate hybridTemplate = exportTemplateChooser.getTemplate("Hybrid");
    assertTrue(HYBRID_TEMPLATE_CLASS_NAME.equals(hybridTemplate.getClass().getName()));
  }

  public void testGetUnknownTemplate() throws Exception {
    String templateName = "Unknown";
    ExportTemplateChooser exportTemplateChooser = new ExportTemplateChooser();
    try {
      exportTemplateChooser.getTemplate(templateName);
      fail("Expected ExcelExportException");
    }
    catch (ExcelExportException e) {
      assertEquals(ExportTemplateChooser.UNKNOWN_TYPE_MSG + templateName, e.getMessage());
    }
  }
}