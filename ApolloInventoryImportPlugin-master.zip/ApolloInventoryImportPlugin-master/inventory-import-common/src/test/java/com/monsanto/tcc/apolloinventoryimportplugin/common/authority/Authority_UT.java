package com.monsanto.tcc.apolloinventoryimportplugin.common.authority;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class Authority_UT {
    private static final long MIDAS_USER_ID = 33L;
    private static final String LOGIN_ID = "login id";
    private static final String FIRST = "first";
    private static final String MIDDLE = "middle";
    private static final String LAST = "last";

    @Test
    public void coverage() {
        Authority authority = new Authority();
        authority.setMidasUserId(MIDAS_USER_ID);
        authority.setLoginId(LOGIN_ID);
        authority.setFirstName(FIRST);
        authority.setMiddleName(MIDDLE);
        authority.setLastName(LAST);

        assertThat(authority.getMidasUserId(), is(MIDAS_USER_ID));
        assertThat(authority.getLoginId(), is(LOGIN_ID));
        assertThat(authority.getID(), nullValue());
        assertThat(authority.getFirstName(), is(FIRST));
        assertThat(authority.getMiddleName(), is(MIDDLE));
        assertThat(authority.getLastName(), is(LAST));
    }
}
