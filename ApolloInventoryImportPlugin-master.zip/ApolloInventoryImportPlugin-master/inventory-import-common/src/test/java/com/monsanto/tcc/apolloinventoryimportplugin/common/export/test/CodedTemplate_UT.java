package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.CodedTemplate;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: CodedTemplate_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-02-23 20:42:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class CodedTemplate_UT extends TestCase {
  private HSSFWorkbook workBook = null;
  private HSSFSheet workSheet = null;

  public CodedTemplate_UT(String name) {
    super(name);
  }

  public void setUp() throws Exception {
    super.setUp();
    workBook = new HSSFWorkbook();
    workSheet = workBook.createSheet();
  }

  public void tearDown() throws Exception {
    workBook = null;
    workSheet = null;
    super.tearDown();
  }

  public void testConstructorNullFirstArgumentShouldFail() throws Exception {
    try {
      CodedTemplate codedTemplate = new CodedTemplate(null, workSheet);
      fail("Should throw IllegalArgumentException");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void testConstructorNullSecondArgumentShouldFail() throws Exception {
    try {
      CodedTemplate codedTemplate = new CodedTemplate(workBook, null);
      fail("Should throw IllegalArgumentException");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void testConstructorWithValidArguments() throws Exception {
    CodedTemplate codedTemplate = new CodedTemplate(workBook, workSheet);
    assertNotNull(codedTemplate);
  }

}
