/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.BlankCell;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.BooleanCell;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.CellFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.NullCell;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.NumericCell;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.StringCell;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.FormulaCell;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ErrorCell;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: CellFactory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $    	 On:	$Date:
 * 2007/10/10 19:17:46 $
 *
 * @author ddbrow5
 * @version $Revision: 1.7 $
 */
public class CellFactory_UT extends TestCase {
  private HSSFCell expectedCell;

  protected void setUp() throws Exception {
    super.setUp();
    HSSFWorkbook book = new HSSFWorkbook();
    HSSFSheet sheet = book.createSheet("Sheet1");
    HSSFRow row = sheet.createRow(1);
    expectedCell = row.createCell((short) 0);
  }

  public void testNullCellValueReturnsNullCell() throws Exception {
    assertTrue(new CellFactory().createCell(null) instanceof NullCell);
  }

  public void testBooleanCellTypeAndValueReturnsBooleanCell() throws Exception {
    expectedCell.setCellValue(true);
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BOOLEAN);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof BooleanCell);
  }

  public void testBooleanCellTypeAndNullValueReturnsBooleanCell() throws Exception {
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BOOLEAN);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof BooleanCell);
  }

  public void testStringCellTypeAndValueReturnsStringCell() throws Exception {
    expectedCell.setCellValue("Some String");
    expectedCell.setCellType(HSSFCell.CELL_TYPE_STRING);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof StringCell);
  }

  public void testEmptyStringCellValueReturnsStringCell() throws Exception {
    expectedCell.setCellValue("");
    expectedCell.setCellType(HSSFCell.CELL_TYPE_STRING);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof StringCell);
  }

  public void testStringCellTypeAndNullValueReturnsStringCell() throws Exception {
    expectedCell.setCellType(HSSFCell.CELL_TYPE_STRING);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof StringCell);
  }

  public void testNumericCellTypeAndValueReturnsNumericCell() throws Exception {
    expectedCell.setCellValue(1.0);
    expectedCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof NumericCell);
  }

  public void testNumericCellTypeAndNullValueReturnsNumericCell() throws Exception {
    expectedCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof NumericCell);
  }

  public void testBlankCellTypeWithNullValueReturnsBlankCell() throws Exception {
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BLANK);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof BlankCell);
  }

  public void testBlankCellTypeWithNumericValueReturnsBlankCell() throws Exception {
    expectedCell.setCellValue(1.0);
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BLANK);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof BlankCell);
  }

  public void testBlankCellTypeWithStringValueReturnsBlankCell() throws Exception {
    expectedCell.setCellValue("Some string");
    expectedCell.setCellType(HSSFCell.CELL_TYPE_BLANK);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof BlankCell);
  }

  public void testEmptyCellReturnsBlankCell() throws Exception {
    assertTrue(new CellFactory().createCell(expectedCell) instanceof BlankCell);
  }
  
  public void testFormulaTypeReturnsFormulaCell() throws Exception {
    expectedCell.setCellType(HSSFCell.CELL_TYPE_FORMULA);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof FormulaCell);
  }

  public void testErrorTypeReturnsErrorCell() throws Exception {
    expectedCell.setCellType(HSSFCell.CELL_TYPE_ERROR);

    assertTrue(new CellFactory().createCell(expectedCell) instanceof ErrorCell);
  }
}