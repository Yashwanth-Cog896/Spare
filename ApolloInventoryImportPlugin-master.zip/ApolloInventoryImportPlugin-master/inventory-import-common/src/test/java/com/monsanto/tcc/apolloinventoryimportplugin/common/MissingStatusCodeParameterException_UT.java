package com.monsanto.tcc.apolloinventoryimportplugin.common;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class MissingStatusCodeParameterException_UT {
    private static final String MESSAGE = "message";

    @SuppressWarnings({"ThrowableInstanceNeverThrown"})
    @Test
    public void coverage() {
        MissingStatusCodeParameterException exception = new MissingStatusCodeParameterException(MESSAGE);

        assertThat(exception.getMessage(), is(MESSAGE));
    }
}