/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.BlankCell;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: BlankCell_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $    	 On:	$Date: 2007-10-16 17:51:13 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class BlankCell_UT extends TestCase {
  public void testBlankCellReturnsEmptyString() throws Exception {
    String sourceString = new BlankCell().getValue();
    assertNotNull(sourceString);
    assertEquals("", sourceString);
  }
}