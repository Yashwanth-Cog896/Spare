package com.monsanto.tcc.apolloinventoryimportplugin.common;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class ImportTypeEntity_UT {
    @Test
    public void coverage() {
        ImportType importType = new ImportType();
        importType.setId(3L);
        importType.setDescription("description");

        ImportTypeEntity entity = new ImportTypeEntity(importType);

        assertThat(entity.getImportType(), sameInstance(importType));
        assertThat(entity.getID(), is((Object) importType.getId()));
        assertThat(entity.toString(), is(importType.getDescription()));
    }
}
