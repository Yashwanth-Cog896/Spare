package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.HybridTemplate;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: HybridTemplate_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-02-23 20:42:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class HybridTemplate_UT extends TestCase {
  private HSSFWorkbook workBook = null;
  private HSSFSheet workSheet = null;

  public HybridTemplate_UT(String name) {
    super(name);
  }

  public void setUp() throws Exception {
    super.setUp();
    workBook = new HSSFWorkbook();
    workSheet = workBook.createSheet();
  }

  public void tearDown() throws Exception {
    workBook = null;
    workSheet = null;
    super.tearDown();
  }

  public void testConstructorNullFirstArgumentShouldFail() throws Exception {
    try {
      HybridTemplate hybridTemplate = new HybridTemplate(null, workSheet);
      fail("Should throw IllegalArgumentException");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void testConstructorNullSecondArgumentShouldFail() throws Exception {
    try {
      HybridTemplate hybridTemplate = new HybridTemplate(workBook, null);
      fail("Should throw IllegalArgumentException");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void testConstructorWithValidArguments() throws Exception {
    HybridTemplate hybridTemplate = new HybridTemplate(workBook, workSheet);
    assertNotNull(hybridTemplate);
  }

  public void testFillTemplateCellsWithDataFromViewWithNullListShouldFail() throws Exception {
    try {
      HybridTemplate hybridTemplate = new HybridTemplate(workBook, workSheet);
      hybridTemplate.fillTemplateCellsWithDataFromView(null);
      fail("Should have thrown ExcelExportException");
    }
    catch (Exception e) {
    }
  }


  public void testFillTemplateCellsWithDataFromViewWithEmptyList() throws Exception {
    HybridTemplate hybridTemplate = new HybridTemplate(workBook, workSheet);
    hybridTemplate.fillTemplateCellsWithDataFromView(new ArrayList());
  }
}