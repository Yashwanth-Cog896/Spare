package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ExcelExportException;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: ExcelExportException_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-02-23 20:42:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class ExcelExportException_UT extends TestCase {
  public ExcelExportException_UT(String name) {
    super(name);
  }

  public void setUp() throws Exception {
    super.setUp();
  }

  public void tearDown() throws Exception {
    super.tearDown();
  }

  public void testConstructor() {
    ExcelExportException excelExportException = new ExcelExportException("An exception");
    assertNotNull(excelExportException);
  }
}
