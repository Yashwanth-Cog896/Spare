package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.ExcelTemplateBuilder;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.junit.After;
import static org.junit.Assert.assertTrue;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: ExcelTemplateBuilder_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ssnall $    On: $Date: 2009-06-05 14:08:02 $
 *
 * @author DDBROW5
 * @version $Revision: 1.22 $
 * @noinspection OverlyLongMethod,MethodWithTooManyParameters,deprecation
 */
@RunWith(JUnit4ClassRunner.class)
public class ExcelTemplateBuilder_UT {
    public static final int NUMBER_OF_COMMERCIAL = 10;
    public static final int NUMBER_OF_COMPETITOR = 10;
    public static final int NUMBER_OF_FINISHED = 10;
    public static final int NUMBER_OF_CODED = 10;
    public static final int NUMBER_OF_SEGPOP = 10;
    public static final int NUMBER_OF_HYBRID = 10;
    private static final String COMMERCIAL = MaterialTypeConstants.COMMERCIAL_PRODUCT;
    private static final String COMPETITOR = MaterialTypeConstants.COMPETITOR_PRODUCT;
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String CODED = MaterialTypeConstants.CODED_LINES;
    private static final String SEGPOP = MaterialTypeConstants.SEGPOP_LINES;
    private static final String HYBRID = MaterialTypeConstants.HYBRID_LINES;

    @After
    public void tearDown() throws Exception {
        deleteExistingTempFiles();
    }

    @Test
    public void testCommericalStagingInventory() throws Exception {
        Set stagingInventorySet = getCommercialStagingInventorySet();

        File xlsFile = File.createTempFile("ExcelTemplateBuilder_UT_" + COMMERCIAL, ".xls");

        ExcelTemplateBuilder excelTemplateBuilder = new ExcelTemplateBuilder(stagingInventorySet);
        excelTemplateBuilder.saveToFile(xlsFile.getAbsolutePath());

        assertTrue(isXLSFileCorrect(xlsFile, stagingInventorySet, COMMERCIAL));
    }

    @Test
    public void testCompetitorStagingInventory() throws Exception {
        Set stagingInventorySet = getCompetitorStagingInventorySet();

        File xlsFile = File.createTempFile("ExcelTemplateBuilder_UT_" + COMPETITOR, ".xls");

        ExcelTemplateBuilder excelTemplateBuilder = new ExcelTemplateBuilder(stagingInventorySet);
        excelTemplateBuilder.saveToFile(xlsFile.getAbsolutePath());

        assertTrue(isXLSFileCorrect(xlsFile, stagingInventorySet, COMPETITOR));
    }

    @Ignore
    @Test
    public void testFinishedStagingInventory() throws Exception {
        Set stagingInventorySet = getFinishedStagingInventorySet();

        File xlsFile = File.createTempFile("ExcelTemplateBuilder_UT_" + FINISHED, ".xls");

        ExcelTemplateBuilder excelTemplateBuilder = new ExcelTemplateBuilder(stagingInventorySet);
        excelTemplateBuilder.saveToFile(xlsFile.getAbsolutePath());

        assertTrue(isXLSFileCorrect(xlsFile, stagingInventorySet, FINISHED));
    }

    @Ignore
    @Test
    public void testCodedStagingInventory() throws Exception {
        Set stagingInventorySet = getCodedStagingInventorySet();

        File xlsFile = File.createTempFile("ExcelTemplateBuilder_UT_" + CODED, ".xls");

        ExcelTemplateBuilder excelTemplateBuilder = new ExcelTemplateBuilder(stagingInventorySet);
        excelTemplateBuilder.saveToFile(xlsFile.getAbsolutePath());
        assertTrue(isXLSFileCorrect(xlsFile, stagingInventorySet, CODED));
    }

    @Ignore
    @Test
    public void testSegpopStagingInventory() throws Exception {
        Set stagingInventorySet = getSegpopStagingInventorySet();

        File xlsFile = File.createTempFile("ExcelTemplateBuilder_UT_" + SEGPOP, ".xls");

        ExcelTemplateBuilder excelTemplateBuilder = new ExcelTemplateBuilder(stagingInventorySet);
        excelTemplateBuilder.saveToFile(xlsFile.getAbsolutePath());

        assertTrue(isXLSFileCorrect(xlsFile, stagingInventorySet, SEGPOP));
    }

    @Ignore
    @Test
    public void testHybridStagingInventory() throws Exception {
        Set stagingInventorySet = getHybridStagingInventorySet();

        File xlsFile = File.createTempFile("ExcelTemplateBuilder_UT_" + HYBRID, ".xls");

        ExcelTemplateBuilder excelTemplateBuilder = new ExcelTemplateBuilder(stagingInventorySet);
        excelTemplateBuilder.saveToFile(xlsFile.getAbsolutePath());

        assertTrue(isXLSFileCorrect(xlsFile, stagingInventorySet, HYBRID));
    }

    @Test(expected = IllegalArgumentException.class)
    public void createBuilder_nullSet() {
        new ExcelTemplateBuilder(null);
    }

    private boolean isXLSFileCorrect(File XLSFile, Set stagingInventorySetToVerify, String importTypeAbbreviation) throws IOException {
        boolean returnStatus = true;
        FileInputStream inputStream = null;
        HSSFWorkbook workbook;
        try {
            inputStream = new FileInputStream(XLSFile);
            workbook = getWorkbook(getPOIFSFileSystem(inputStream));
            int numberOfSheets = workbook.getNumberOfSheets();
            HSSFSheet sheet = null;
            for (int i = 0; i < numberOfSheets; i++) {
                HSSFSheet currentSheet = workbook.getSheetAt(i);
                if (importTypeAbbreviation.equals(workbook.getSheetName(i))) {
                    sheet = currentSheet;
                } else {
                    int firstRowNum = currentSheet.getFirstRowNum();
                    int lastRowNum = currentSheet.getLastRowNum();
                    if (0 != firstRowNum && 0 != lastRowNum) {
                        returnStatus = false;
                        break;
                    }
                }
            }

            if (returnStatus) {
                returnStatus = isValidSheet(sheet, stagingInventorySetToVerify, importTypeAbbreviation);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
            returnStatus = false;
        }
        finally {
            if (null != inputStream) {
                inputStream.close();
            }
        }
        return returnStatus;
    }

    private boolean isValidSheet(HSSFSheet sheet, Set stagingInventorySetToVerify, String importTypeAbbreviation) {
        boolean returnStatus = true;
        if (MaterialTypeConstants.COMMERCIAL_PRODUCT.equals(importTypeAbbreviation)) {
            returnStatus = isValidCommercialSheet(stagingInventorySetToVerify, sheet);
        } else if (MaterialTypeConstants.COMPETITOR_PRODUCT.equals(importTypeAbbreviation)) {
            returnStatus = isValidCompetitorSheet(stagingInventorySetToVerify, sheet);
        } else if (MaterialTypeConstants.FINISHED_LINES.equals(importTypeAbbreviation)) {
            returnStatus = isValidFinishedSheet(stagingInventorySetToVerify, sheet);
        } else if (MaterialTypeConstants.CODED_LINES.equals(importTypeAbbreviation)) {
            returnStatus = isValidCodedSheet(stagingInventorySetToVerify, sheet);
        } else if (MaterialTypeConstants.SEGPOP_LINES.equals(importTypeAbbreviation)) {
            returnStatus = isValidSegpopSheet(stagingInventorySetToVerify, sheet);
        } else if (MaterialTypeConstants.HYBRID_LINES.equals(importTypeAbbreviation)) {
            returnStatus = isValidHybridSheet(stagingInventorySetToVerify, sheet);
        }
        return returnStatus;
    }

    private boolean isValidCommercialSheet(Set stagingInventorySetToVerify, HSSFSheet sheet) {
        boolean status = true;
        int rowNum = 1;
        for (Object aStagingInventorySetToVerify : stagingInventorySetToVerify) {
            StagingInventory stagingInventory = (StagingInventory) aStagingInventorySetToVerify;
            HSSFRow row = sheet.getRow(rowNum);
            status = isValidCommercialRow(stagingInventory, row);
            if (!status) {
                break;
            }
            rowNum++;
        }
        return status;
    }

    private boolean isValidCompetitorSheet(Set stagingInventorySetToVerify, HSSFSheet sheet) {
        boolean status = true;
        int rowNum = 1;
        for (Object aStagingInventorySetToVerify : stagingInventorySetToVerify) {
            StagingInventory stagingInventory = (StagingInventory) aStagingInventorySetToVerify;
            HSSFRow row = sheet.getRow(rowNum);
            status = isValidCompetitorRow(stagingInventory, row);
            if (!status) {
                break;
            }
            rowNum++;
        }
        return status;
    }

    private boolean isValidFinishedSheet(Set stagingInventorySetToVerify, HSSFSheet sheet) {
        boolean status = true;
        int rowNum = 1;
        for (Object aStagingInventorySetToVerify : stagingInventorySetToVerify) {
            StagingInventory stagingInventory = (StagingInventory) aStagingInventorySetToVerify;
            HSSFRow row = sheet.getRow(rowNum);
            status = isValidFinishedRow(stagingInventory, row);
            if (!status) {
                break;
            }
            rowNum++;
        }
        return status;
    }

    private boolean isValidCodedSheet(Set stagingInventorySetToVerify, HSSFSheet sheet) {
        return isValidFinishedSheet(stagingInventorySetToVerify, sheet);
    }

    private boolean isValidSegpopSheet(Set stagingInventorySetToVerify, HSSFSheet sheet) {
        boolean status = true;
        int rowNum = 1;
        for (Object aStagingInventorySetToVerify : stagingInventorySetToVerify) {
            StagingInventory stagingInventory = (StagingInventory) aStagingInventorySetToVerify;
            HSSFRow row = sheet.getRow(rowNum);
            status = isValidSegpopRow(stagingInventory, row);
            if (!status) {
                break;
            }
            rowNum++;
        }
        return status;
    }

    private boolean isValidHybridSheet(Set stagingInventorySetToVerify, HSSFSheet sheet) {
        boolean status = true;
        int rowNum = 1;
        for (Object aStagingInventorySetToVerify : stagingInventorySetToVerify) {
            StagingInventory stagingInventory = (StagingInventory) aStagingInventorySetToVerify;
            HSSFRow row = sheet.getRow(rowNum);
            status = isValidHybridRow(stagingInventory, row);
            if (!status) {
                break;
            }
            rowNum++;
        }
        return status;
    }

    private boolean isValidCommercialRow(StagingInventory stagingInventoryToVerify, HSSFRow row) {
        HSSFCell cell = row.getCell((short) 0);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getProductName(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 1);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOrigin(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 2);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineType(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 3);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 4);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getInventoryOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 5);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort1(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 6);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort2(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 7);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort3(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 8);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort4(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 9);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort5(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 10);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort1(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 11);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort2(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 12);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort3(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 13);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort4(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 14);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort5(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 15);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSrcLotNumber(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 16);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getComments(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 17);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getFemaleParentSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 18);
        return isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getMaleParentSource(), cell.getStringCellValue());
    }

    private boolean isValidCompetitorRow(StagingInventory stagingInventoryToVerify, HSSFRow row) {
        HSSFCell cell = row.getCell((short) 0);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getProductName(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 1);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 2);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getInventoryOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 3);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort1(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 4);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort2(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 5);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort3(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 6);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort4(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 7);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort5(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 8);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort1(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 9);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort2(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 10);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort3(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 11);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort4(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 12);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort5(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 13);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSrcLotNumber(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 14);
        return isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getComments(), cell.getStringCellValue());
    }

    private boolean isValidFinishedRow(StagingInventory stagingInventoryToVerify, HSSFRow row) {
        HSSFCell cell = row.getCell((short) 0);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGermplasmOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 1);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineCode(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 2);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 3);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getInventoryOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 4);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOrigin(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 5);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineage(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 6);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGeneration(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 7);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineFunction(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 8);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getCytoplasmDonorPedigree(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 9);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getCytoplasmDonorSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 10);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOldPedigree(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 11);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort1(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 12);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort2(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 13);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort3(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 14);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort4(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 15);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort5(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 16);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort1(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 17);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort2(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 18);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort3(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 19);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort4(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 20);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort5(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 21);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSrcLotNumber(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 22);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getEvent(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 23);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getComments(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 24);
        return isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getBuildParentage(), cell.getStringCellValue());

    }

/*
    private boolean isValidCodedRow(StagingInventory stagingInventoryToVerify, HSSFRow row) {
        return isValidFinishedRow(stagingInventoryToVerify, row);
    }
*/

    private boolean isValidSegpopRow(StagingInventory stagingInventoryToVerify, HSSFRow row) {
        HSSFCell cell = row.getCell((short) 0);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGermplasmOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 1);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOrigin(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 2);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineage(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 3);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGeneration(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 4);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 5);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getInventoryOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 6);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineFunction(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 9);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOldPedigree(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 7);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getCytoplasmDonorPedigree(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 8);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getCytoplasmDonorSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 9);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOldPedigree(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 10);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort1(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 11);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort2(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 12);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort3(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 13);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort4(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 14);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort5(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 15);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort1(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 16);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort2(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 17);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort3(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 18);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort4(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 19);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort5(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 20);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSrcLotNumber(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 21);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getEvent(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 22);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getComments(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 23);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getBuildParentage(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 24);
        String sources = getDelimitedParentalSourcesString(stagingInventoryToVerify.getParentalSources());
        return isStagingInventoryValueSameAsCellValue(sources, cell.getStringCellValue());
    }

    private String getDelimitedParentalSourcesString(Set parentalSources) {
        StringBuffer sources = new StringBuffer("");
        if (null != parentalSources) {
            for (Object parentalSource : parentalSources) {
                if (0 != sources.toString().length()) {
                    sources.append(";");
                }
                sources.append((String) parentalSource);
            }
        }
        return sources.toString();
    }

    private boolean isValidHybridRow(StagingInventory stagingInventoryToVerify, HSSFRow row) {
        HSSFCell cell = row.getCell((short) 0);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGermplasmOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 1);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOrigin(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 2);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 3);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getInventoryOwner(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 4);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getLineFunction(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 5);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getOldPedigree(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 6);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort1(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 7);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort2(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 8);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort3(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 9);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort4(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 10);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getAsort5(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 11);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort1(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 12);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort2(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 13);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort3(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 14);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort4(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 15);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getNsort5(), cell.getNumericCellValue())) {
            return false;
        }

        cell = row.getCell((short) 16);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getSrcLotNumber(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 17);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getEvent(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 18);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getComments(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 19);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getFemaleParentSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 20);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGermplasmOwnerOfFemaleParent(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 21);
        if (!isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getMaleParentSource(), cell.getStringCellValue())) {
            return false;
        }

        cell = row.getCell((short) 22);
        return isStagingInventoryValueSameAsCellValue(stagingInventoryToVerify.getGermplasmOwnerOfMaleParent(), cell.getStringCellValue());
    }


    private boolean isStagingInventoryValueSameAsCellValue(String stagingInventoryValue, String cellValue) {
        String testingStagingInventoryValue = (null == stagingInventoryValue ? "" : stagingInventoryValue);
        String testingCellValue = (null == cellValue ? "" : cellValue);
        return testingStagingInventoryValue.equals(testingCellValue);
    }

/*
    private boolean isStagingInventoryValueSameAsCellValue(String stagingInventoryValue, double cellValue) {
        String testingStagingInventoryValue = (null == stagingInventoryValue ? "0.0" : stagingInventoryValue);
        String testingCellValue = Double.toString(cellValue);
        return testingStagingInventoryValue.equals(testingCellValue);
    }
*/

    private boolean isStagingInventoryValueSameAsCellValue(Double stagingInventoryValue, double cellValue) {
        Double testingStagingInventoryValue = (null == stagingInventoryValue ? (double) 0 : stagingInventoryValue);
        return testingStagingInventoryValue.equals(cellValue);
    }

    private POIFSFileSystem getPOIFSFileSystem(FileInputStream inputStream) throws IOException {
        return new POIFSFileSystem(inputStream);
    }

    private HSSFWorkbook getWorkbook(POIFSFileSystem poiFSFileSystem) throws IOException {
        return new HSSFWorkbook(poiFSFileSystem);
    }

    private Set<StagingInventory> getCommercialStagingInventorySet() {
        Set<StagingInventory> commercialStagingInventortSet = new HashSet<StagingInventory>();
        int i;
        for (i = 0; i < NUMBER_OF_COMMERCIAL; i++) {
            commercialStagingInventortSet.add(createStagingInventory("Commercial ProductName " + i,
                    "C/O" + i,
                    "Commercial-Line-Code-" + i,
                    null,
                    "Com",
                    "Commercial Source " + i,
                    "Com",
                    "Approved", "Corn", COMMERCIAL, COMMERCIAL, "N", null, null, null, null, null));
        }
        return commercialStagingInventortSet;
    }

    private Set<StagingInventory> getCompetitorStagingInventorySet() {
        Set<StagingInventory> competitorStagingInventortSet = new HashSet<StagingInventory>();
        int i;
        for (i = 0; i < NUMBER_OF_COMPETITOR; i++) {
            competitorStagingInventortSet.add(createStagingInventory(COMPETITOR + " ProductName " + i,
                    "C/P" + i,
                    COMPETITOR + "-Line-Code-" + i,
                    COMPETITOR + " Old Pedigree " + i,
                    "Cpt",
                    COMPETITOR + " Source " + i,
                    "Cpt",
                    "Pending", "Corn", COMPETITOR, COMPETITOR, "N", null, null, null, null, null));
        }
        return competitorStagingInventortSet;
    }

    private Set<StagingInventory> getFinishedStagingInventorySet() {
        Set<StagingInventory> finishedStagingInventortSet = new HashSet<StagingInventory>();
        int i;
        for (i = 0; i < NUMBER_OF_FINISHED; i++) {
            finishedStagingInventortSet.add(createStagingInventory(FINISHED + " ProductName " + i,
                    "F/I" + i,
                    FINISHED + "-Line-Code-" + i,
                    FINISHED + " Old Pedigree " + i,
                    "Fin",
                    FINISHED + " Source " + i,
                    "Fin",
                    "Valid", "Corn", FINISHED, FINISHED, "Y", null, null, null, null, null));
        }
        return finishedStagingInventortSet;
    }

    private Set<StagingInventory> getCodedStagingInventorySet() {
        Set<StagingInventory> codedStagingInventortSet = new HashSet<StagingInventory>();
        int i;
        for (i = 0; i < NUMBER_OF_CODED; i++) {
            codedStagingInventortSet.add(createStagingInventory(CODED + " ProductName " + i,
                    "C/D" + i,
                    CODED + "-Line-Code-" + i,
                    CODED + " Old Pedigree " + i,
                    "Cod",
                    CODED + " Source " + i,
                    "Cod",
                    "New", "Corn", CODED, CODED, "N", null, null, null, null, null));
        }
        return codedStagingInventortSet;
    }

    private Set<StagingInventory> getSegpopStagingInventorySet() {
        Set<StagingInventory> segpopStagingInventortSet = new HashSet<StagingInventory>();
        int i;
        for (i = 0; i < NUMBER_OF_SEGPOP; i++) {
            segpopStagingInventortSet.add(createStagingInventory(SEGPOP + " ProductName " + i,
                    "S/P" + i,
                    SEGPOP + "-Line-Code-" + i,
                    SEGPOP + " Old Pedigree " + i,
                    "Seg",
                    SEGPOP + " Source " + i,
                    "Seg",
                    "New", "Corn", SEGPOP, SEGPOP, "Y", null, null, null, null, null));
        }
        return segpopStagingInventortSet;
    }

    private Set<StagingInventory> getHybridStagingInventorySet() {
        Set<StagingInventory> hybridStagingInventortSet = new HashSet<StagingInventory>();
        int i;
        for (i = 0; i < NUMBER_OF_HYBRID; i++) {
            hybridStagingInventortSet.add(createStagingInventory(HYBRID + " ProductName " + i,
                    "H/Y" + i,
                    HYBRID + "-Line-Code-" + i,
                    HYBRID + " Old Pedigree " + i,
                    "Hyb",
                    HYBRID + " Source " + i,
                    "Hyb",
                    "New", "Corn", HYBRID + " Finished", HYBRID, "N", "F" + i, i + "P", "M" + i, i + "M", "S"));
        }
        return hybridStagingInventortSet;
    }

    private ImportType getImportType(String abbrev) {
        ImportType importType = new ImportType();
        importType.setAbbreviation(abbrev);
        return importType;
    }

    private ImportStatus getImportStatus(String statusCode) {
        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode(statusCode);
        return importStatus;
    }

    private StagingInventoryHeader createStagingInventoryHeader(String crop, String typeAbbrev) {
        ImportType importType = getImportType(typeAbbrev);
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setBatchDate(new Date());
        stagingInventoryHeader.setCropName(crop);
        stagingInventoryHeader.setTemplateName("ApprovedStagingInventory.xls");
        stagingInventoryHeader.setUserId("ddbrow5");
        stagingInventoryHeader.setImportType(importType);
        return stagingInventoryHeader;
    }

    private StagingInventory createStagingInventory(String productName, String origin, String lineCode,
                                                    String oldPedigree, String germplasmOwner, String source,
                                                    String owner, String statusCode, String crop, String typeAbbrev,
                                                    String headerTypeAbbrev, String buildParentage,
                                                    String femaleParentSource, String germplasmOwnerOfFemaleParent,
                                                    String maleParentSource, String germplasmOwnerOfMaleParent,
                                                    String lineFunctionRefId) {
        StagingInventoryHeader stagingInventoryHeader = createStagingInventoryHeader(crop, headerTypeAbbrev);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(stagingInventoryHeader);
        inventory.setImportStatus(getImportStatus(statusCode));
        inventory.setImportType(getImportType(typeAbbrev));
        inventory.setProductName(productName);
        inventory.setOrigin(origin);
        inventory.setLineCode(lineCode);
        inventory.setOldPedigree(oldPedigree);
        inventory.setGermplasmOwner(germplasmOwner);
        inventory.setSource(source);
        inventory.setInventoryOwner(owner);
        inventory.setBuildParentage(buildParentage);
        inventory.setFemaleParentSource(femaleParentSource);
        inventory.setGermplasmOwnerOfFemaleParent(germplasmOwnerOfFemaleParent);
        inventory.setMaleParentSource(maleParentSource);
        inventory.setGermplasmOwnerOfMaleParent(germplasmOwnerOfMaleParent);
        inventory.setLineFunction(lineFunctionRefId);
        return inventory;
    }

    private void deleteExistingTempFiles() {
        final String tmpDir = System.getProperty("java.io.tmpdir");
        File dir = new File(tmpDir);
        FilenameFilter filter = new ExcelTemplateFilenameFilter();
        String[] ls = dir.list(filter);
        for (int i = 0; null != ls && i < ls.length; i++) {
            File xlsFile = new File(tmpDir + File.separator + ls[i]);
            if (xlsFile.exists() && xlsFile.isFile()) {
                System.out.print("Attemping to delete " + ls[i]);
                boolean deleteResult = xlsFile.delete();
                System.out.println("  Was it deleted?: " + (deleteResult ? "yes" : "no"));
            }
        }
    }

    class ExcelTemplateFilenameFilter implements FilenameFilter {
        public boolean accept(File dir, String name) {
            return (name.startsWith("ExcelTemplateBuilder_UT_") && name.endsWith(".xls"));
        }
    }
}