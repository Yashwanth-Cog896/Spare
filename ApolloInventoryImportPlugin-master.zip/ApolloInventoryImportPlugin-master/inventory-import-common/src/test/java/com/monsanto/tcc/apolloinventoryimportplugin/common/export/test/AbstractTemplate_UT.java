package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.AbstractTemplate;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.junit.Ignore;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AbstractTemplate_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2008-05-06 17:21:00 $
 *
 * @author ddbrow5
 * @version $Revision: 1.7 $
 */
public class AbstractTemplate_UT extends TestCase {
    public static final String SAMPLE_TEMPLATE_FILE = "com/monsanto/tcc/apolloinventoryimportplugin/common/export/test/SampleTemplate.xls";
    private HSSFWorkbook workBook = null;
    private HSSFSheet workSheet = null;

    public AbstractTemplate_UT(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
        workBook = new HSSFWorkbook();
        workSheet = workBook.createSheet();
    }

    public void tearDown() throws Exception {
        workBook = null;
        workSheet = null;
        super.tearDown();
    }

    public void testFillTemplateCellsWithDataFromViewNullDataNullWorkbookShouldFail() throws Exception {
        try {
            AbstractTemplate abstractTemplate = new MockAbstractTemplate(null, workSheet);
            abstractTemplate.fillTemplateCellsWithDataFromView(new ArrayList());
            fail("Should have thrown ExcelExportException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testFillTemplateCellsWithDataFromViewNullDataNullWorksheetShouldFail() throws Exception {
        try {
            AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, null);
            abstractTemplate.fillTemplateCellsWithDataFromView(new ArrayList());
            fail("Should have thrown ExcelExportException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testFillTemplateCellsWithDataFromViewNullDataShouldFail() throws Exception {
        try {
            AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
            abstractTemplate.fillTemplateCellsWithDataFromView(null);
            fail("Should have thrown ExcelExportException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testFillTemplateCellsWithDataFromViewNullDataEmptyData() throws Exception {
        AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
        abstractTemplate.fillTemplateCellsWithDataFromView(new ArrayList());
    }

    public void testFillTemplateCellsWithDataFromViewNullDataInvalidDataShouldFail() throws Exception {
        List<Integer> invalidDataList = new ArrayList<Integer>();
        invalidDataList.add(new Integer(1));
        try {
            AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
            abstractTemplate.fillTemplateCellsWithDataFromView(invalidDataList);
            fail("Should have thrown ClassCastException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testFillTemplateCellsWithDataFromViewValidButDefaultStagingInventoryValues() throws Exception {
        List<StagingInventory> validDataList = new ArrayList<StagingInventory>();
        StagingInventory stagingInventory = new StagingInventory();
        assertNotNull(stagingInventory);
        validDataList.add(stagingInventory);
        AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
        abstractTemplate.fillTemplateCellsWithDataFromView(validDataList);
    }

    public void testFillTemplateCellsWithDataFromViewValidButDefaultStagingInventoryValuesNotNullFirstTwoRows() throws Exception {
        HSSFRow row = workSheet.createRow(0);
        row.createCell((short) 0);
        row.createCell((short) 1);
        row.createCell((short) 2);
        workSheet.createRow(1);
        List<StagingInventory> validDataList = new ArrayList<StagingInventory>();
        StagingInventory stagingInventory = new StagingInventory();
        assertNotNull(stagingInventory);
        validDataList.add(stagingInventory);
        AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
        abstractTemplate.fillTemplateCellsWithDataFromView(validDataList);
    }

    public void testFillTemplateCellsWithDataFromViewValidButDefaultStagingInventoryValuesNotNullFirstTwoRowsAndFirstCellOfSecondRow() throws Exception {
        HSSFRow row1 = workSheet.createRow(0);
        row1.createCell((short) 0);
        row1.createCell((short) 1);
        row1.createCell((short) 2);
        HSSFRow row2 = workSheet.createRow(1);
        row2.createCell((short) 0);
        List<StagingInventory> validDataList = new ArrayList<StagingInventory>();
        StagingInventory stagingInventory = new StagingInventory();
        assertNotNull(stagingInventory);
        validDataList.add(stagingInventory);
        AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
        abstractTemplate.fillTemplateCellsWithDataFromView(validDataList);
    }

    @Ignore
    public void testWriteToSystemFile() throws Exception {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        File sampleTemplateFile = getSampleTemplateFile();
        HSSFWorkbook sampleWorkBook = getSampleTemplateWorkbook(sampleTemplateFile);
        HSSFSheet sampleWorkSheet = sampleWorkBook.getSheetAt(0);

        List<StagingInventory> validDataList = new ArrayList<StagingInventory>();
        StagingInventory stagingInventory = new StagingInventory();

        validDataList.add(stagingInventory);
        AbstractTemplate abstractTemplate = new MockAbstractTemplate(sampleWorkBook, sampleWorkSheet);
        abstractTemplate.fillTemplateCellsWithDataFromView(validDataList);
        abstractTemplate.writeToOutputStream(byteArrayOutputStream);
        assertTrue(byteArrayOutputStream.toByteArray().length != sampleTemplateFile.length());
    }


    public void testGetBytesInTemplate() throws Exception {
        List<StagingInventory> validDataList = new ArrayList<StagingInventory>();
        StagingInventory stagingInventory = new StagingInventory();
        assertNotNull(stagingInventory);

        validDataList.add(stagingInventory);
        AbstractTemplate abstractTemplate = new MockAbstractTemplate(workBook, workSheet);
        byte[] bytesBeforeInsertingData = abstractTemplate.getBytesInTemplate();
        abstractTemplate.fillTemplateCellsWithDataFromView(validDataList);
        byte[] bytesAfterInsertingData = abstractTemplate.getBytesInTemplate();
        assertTrue(bytesBeforeInsertingData.length < bytesAfterInsertingData.length);
    }

    private HSSFWorkbook getSampleTemplateWorkbook(File file) {
        if (null != file) {
            try {
                POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(file));
                workBook = new HSSFWorkbook(fs);
            }
            catch (FileNotFoundException fnfe) {
                fnfe.printStackTrace();
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
        return workBook;
    }

    private File getSampleTemplateFile() {
        URL templateFileURL = AbstractTemplate_UT.class.getClassLoader().getResource(SAMPLE_TEMPLATE_FILE);
        File file = null;
        if (null != templateFileURL) {
            file = new File(templateFileURL.getFile());
            if (!file.exists()) {
                file = null;
            }
        }
        return file;
    }
}
