package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.FinishedTemplate;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.ArrayList;

/**
 * Filename:    $RCSfile: FinishedTemplate_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-02-23 20:42:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class FinishedTemplate_UT extends TestCase {
  private HSSFWorkbook workBook = null;
  private HSSFSheet workSheet = null;

  public FinishedTemplate_UT(String name) {
    super(name);
  }

  public void setUp() throws Exception {
    super.setUp();
    workBook = new HSSFWorkbook();
    workSheet = workBook.createSheet();
  }

  public void tearDown() throws Exception {
    workBook = null;
    workSheet = null;
    super.tearDown();
  }

  public void testConstructorNullFirstArgumentShouldFail() throws Exception {
    try {
      FinishedTemplate finishedTemplate = new FinishedTemplate(null, workSheet);
      fail("Should throw IllegalArgumentException");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void testConstructorNullSecondArgumentShouldFail() throws Exception {
    try {
      FinishedTemplate finishedTemplate = new FinishedTemplate(workBook, null);
      fail("Should throw IllegalArgumentException");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void testConstructorWithValidArguments() throws Exception {
    FinishedTemplate finishedTemplate = new FinishedTemplate(workBook, workSheet);
    assertNotNull(finishedTemplate);
  }

  public void testFillTemplateCellsWithDataFromViewWithNullListShouldFail() throws Exception {
    try {
      FinishedTemplate finishedTemplate = new FinishedTemplate(workBook, workSheet);
      finishedTemplate.fillTemplateCellsWithDataFromView(null);
      fail("Should have thrown ExcelExportException");
    }
    catch (Exception e) {
    }
  }


  public void testFillTemplateCellsWithDataFromViewWithEmptyList() throws Exception {
    FinishedTemplate finishedTemplate = new FinishedTemplate(workBook, workSheet);
    finishedTemplate.fillTemplateCellsWithDataFromView(new ArrayList());
  }
}
