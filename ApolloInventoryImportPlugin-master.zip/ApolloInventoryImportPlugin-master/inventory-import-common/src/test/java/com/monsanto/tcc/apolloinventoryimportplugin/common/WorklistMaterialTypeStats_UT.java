package com.monsanto.tcc.apolloinventoryimportplugin.common;

import org.junit.runner.RunWith;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.Test;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.is;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class WorklistMaterialTypeStats_UT {
    private static final int ELIGIBLE_COUNT = 1;
    private static final String MATERIAL_TYPE = "material type";
    private static final int APPROVED_COUNT = 2;
    private static final int PROCESSED_COUNT = 3;

    @Test
    public void coverage() {
        WorklistMaterialTypeStats worklistMaterialTypeStats = new WorklistMaterialTypeStats();
        worklistMaterialTypeStats.setEligibleToSendToAuthorityCount(ELIGIBLE_COUNT);
        worklistMaterialTypeStats.setMaterialType(MATERIAL_TYPE);
        worklistMaterialTypeStats.setWaitingToBeApprovedCount(APPROVED_COUNT);
        worklistMaterialTypeStats.setWaitingToBeProcessedCount(PROCESSED_COUNT);
        
        assertThat(worklistMaterialTypeStats.getEligibleToSendToAuthorityCount(), is(ELIGIBLE_COUNT));
        assertThat(worklistMaterialTypeStats.getMaterialType(), is(MATERIAL_TYPE));
        assertThat(worklistMaterialTypeStats.getWaitingToBeApprovedCount(), is(APPROVED_COUNT));
        assertThat(worklistMaterialTypeStats.getWaitingToBeProcessedCount(), is(PROCESSED_COUNT));
    }
}
