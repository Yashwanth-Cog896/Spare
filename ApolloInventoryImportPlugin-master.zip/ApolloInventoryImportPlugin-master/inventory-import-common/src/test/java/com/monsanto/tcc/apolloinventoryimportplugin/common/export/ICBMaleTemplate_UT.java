package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.mock;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class ICBMaleTemplate_UT {
    private HSSFWorkbook workBook;
    private HSSFSheet workSheet;

    @Before
    public void setUp() throws Exception {
        workBook = new HSSFWorkbook();
        workSheet = workBook.createSheet();
    }

    @Test
    public void createTemplate() {
        new ICBMaleTemplate(workBook, workSheet);
    }

    @Test(expected = IllegalArgumentException.class)
    public void createTemplate_nullWorkbook() {
        new ICBMaleTemplate(null, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void createTemplate_nullWorksheet() {
        new ICBMaleTemplate(workBook, null);
    }
}
