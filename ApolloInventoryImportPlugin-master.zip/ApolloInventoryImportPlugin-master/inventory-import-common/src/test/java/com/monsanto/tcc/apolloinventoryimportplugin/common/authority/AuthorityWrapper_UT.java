package com.monsanto.tcc.apolloinventoryimportplugin.common.authority;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.runner.RunWith;

/**
 * @author <a href="mailto:eric.d.turcotte@monsanto.com">Eric Turcotte</a>
 */
@RunWith(JUnit4ClassRunner.class)
public class AuthorityWrapper_UT {
    private static final int ALL_RECORD_COUNT = 33;
    private static final int MAIN_RECORD_COUNT = 3;

    @Test
    public void coverage() {
        Authority authority = new Authority();

        AuthorityWrapper wrapper = new AuthorityWrapper(authority);
        wrapper.setAuthority(authority);
        wrapper.setAllRecordCount(ALL_RECORD_COUNT);
        wrapper.setMainRecordCount(MAIN_RECORD_COUNT);

        assertThat(wrapper.getAuthority(), sameInstance(authority));
        assertThat(wrapper.getID(), nullValue());
        assertThat(wrapper.getMainRecordCount(), is(MAIN_RECORD_COUNT));
        assertThat(wrapper.getAllRecordCount(), is(ALL_RECORD_COUNT));
    }
}
