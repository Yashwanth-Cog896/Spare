package com.monsanto.tcc.apolloinventoryimportplugin.common.export.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.export.AbstractTemplate;
import com.monsanto.tcc.apolloinventoryimportplugin.common.export.CommercialTemplate;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import junit.framework.TestCase;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: CommercialTemplate_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2008-05-06 17:24:06 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
@SuppressWarnings({"OverlyLongMethod"})
public class CommercialTemplate_UT extends TestCase {
    public static final String SAMPLE_TEMPLATE_FILE = "com/monsanto/tcc/apolloinventoryimportplugin/common/export/test/SampleTemplate.xls";
    private HSSFWorkbook workBook = null;
    private HSSFSheet workSheet = null;

    public CommercialTemplate_UT(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
        workBook = new HSSFWorkbook();
        workSheet = workBook.createSheet();
    }

    public void tearDown() throws Exception {
        workBook = null;
        workSheet = null;
        super.tearDown();
    }

    public void testConstructorNullFirstArgumentShouldFail() throws Exception {
        try {
            new CommercialTemplate(null, workSheet);
            fail("Should throw IllegalArgumentException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testConstructorNullSecondArgumentShouldFail() throws Exception {
        try {
            new CommercialTemplate(workBook, null);
            fail("Should throw IllegalArgumentException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testConstructorWithValidArguments() throws Exception {
        CommercialTemplate commercialTemplate = new CommercialTemplate(workBook, workSheet);
        assertNotNull(commercialTemplate);
    }

    public void testFillTemplateCellsWithDataFromViewWithNullListShouldFail() throws Exception {
        try {
            CommercialTemplate commercialTemplate = new CommercialTemplate(workBook, workSheet);
            commercialTemplate.fillTemplateCellsWithDataFromView(null);
            fail("Should have thrown ExcelExportException");
        }
        catch (Exception e) {
            // not handled intentionally
        }
    }

    public void testFillTemplateCellsWithDataFromViewWithEmptyList() throws Exception {
        CommercialTemplate commercialTemplate = new CommercialTemplate(workBook, workSheet);
        commercialTemplate.fillTemplateCellsWithDataFromView(new ArrayList());
    }

    public void testWriteToSystemFileCheckAlternateValueOriginVsLineCode() throws Exception {
        String workSheetName = "Commercial";
        String productName = "Product Name";
        String lineType = "XYZ";
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            File sampleTemplateFile = getSampleTemplateFile();
            HSSFWorkbook sampleWorkBook = getTemplateWorkbook(new FileInputStream(sampleTemplateFile));
            HSSFSheet sampleWorkSheet = sampleWorkBook.getSheet(workSheetName);

            List<StagingInventory> validDataList = new ArrayList<StagingInventory>();
            StagingInventory stagingInventory = new StagingInventory();
            assertNotNull(stagingInventory);
            stagingInventory.setProductName(productName);
            stagingInventory.setLineCode(lineType);

            validDataList.add(stagingInventory);
            AbstractTemplate abstractTemplate = new CommercialTemplate(sampleWorkBook, sampleWorkSheet);
            abstractTemplate.fillTemplateCellsWithDataFromView(validDataList);
            abstractTemplate.writeToOutputStream(byteArrayOutputStream);

            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            HSSFWorkbook writtenWorkBook = getTemplateWorkbook(byteArrayInputStream);
            if (null != writtenWorkBook) {
                HSSFSheet writtenWorkSheet = writtenWorkBook.getSheet(workSheetName);
                assertNotNull(writtenWorkSheet);
                HSSFRow row = writtenWorkSheet.getRow(1);
                assertNotNull(row);
                HSSFCell cell = row.getCell((short) 0);
                assertNotNull(cell);
                assertEquals(stagingInventory.getProductName(), cell.getStringCellValue());
                cell = row.getCell((short) 1);
                assertNotNull(cell);
                assertEquals(stagingInventory.getLineCode(), cell.getStringCellValue());
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    private HSSFWorkbook getTemplateWorkbook(InputStream stream) {
        HSSFWorkbook thisWorkBook = null;
        if (null != stream) {
            try {
                POIFSFileSystem fs = new POIFSFileSystem(stream);
                thisWorkBook = new HSSFWorkbook(fs);
            }
            catch (FileNotFoundException fnfe) {
                fnfe.printStackTrace();
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
        return thisWorkBook;
    }

    private File getSampleTemplateFile() {
        URL templateFileURL = AbstractTemplate_UT.class.getClassLoader().getResource(SAMPLE_TEMPLATE_FILE);
        File file = null;
        if (null != templateFileURL) {
            file = new File(templateFileURL.getFile());
            if (!file.exists()) {
                file = null;
            }
        }
        return file;
    }
}