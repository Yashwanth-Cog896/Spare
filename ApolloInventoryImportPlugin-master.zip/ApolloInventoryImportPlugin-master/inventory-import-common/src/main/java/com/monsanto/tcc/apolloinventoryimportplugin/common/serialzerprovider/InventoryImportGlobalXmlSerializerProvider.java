/*
 InventoryImportGlobalXmlSerializerProvider was created on Jan 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.serialzerprovider;

import com.monsanto.services.client.common.envelope.EnvelopeXmlSerializerBuilderMappingRegister;
import com.monsanto.services.client.common.filter.FilterXmlSerializerBuilderMappingRegister;
import com.monsanto.services.domain.breeding.Crop;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportTypeEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.XMLDateConverter;
import com.monsanto.tcc.apolloinventoryimportplugin.common.authority.Authority;
import com.monsanto.tcc.apolloinventoryimportplugin.common.authority.AuthorityWrapper;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventoryEntity;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.xmlserialization.XmlSerializerBuilderMappingRegister;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * Filename:    $RCSfile: InventoryImportGlobalXmlSerializerProvider.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: AAGOSW $     On:$Date: 2008-03-04 23:07:38 $
 *
 * @author SRKARNA
 * @version $Revision: 1.10 $
 */
public class InventoryImportGlobalXmlSerializerProvider implements XmlSerializerProvider {
    public static final String NAMESPACE = "http://www.monsanto.com/inventoryimport/POS";

    public XmlSerializer getXmlSerializer() {
        XmlSerializerBuilder builder = new XmlSerializerBuilder();
        builder.setClassLoader(getClass().getClassLoader());

        registerEnvelopeMappings(builder);
        registerFilterMappings(builder);

        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "crop", Crop.class);
        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "importTypeEntity",
                ImportTypeEntity.class);
        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "authority", Authority.class);
        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "authorityWrapper", AuthorityWrapper.class);
        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "stagingInventoryEntity",
                StagingInventoryEntity.class);
        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "staginginventoryheader",
                StagingInventoryHeader.class);
        builder.registerMapping(InventoryImportGlobalXmlSerializerProvider.NAMESPACE, "staginginventory",
                StagingInventory.class);

//    builder.addConverter(new ISO8601DateConverter()); // To fix schema validation problems with date fields
        builder.addConverter(new XMLDateConverter());
        return builder.createSerializer();
    }

    private void registerEnvelopeMappings(XmlSerializerBuilder builder) {
        createEnvelopeMappingRegister().registerMappings(builder, InventoryImportGlobalXmlSerializerProvider.NAMESPACE);
    }

    private XmlSerializerBuilderMappingRegister createEnvelopeMappingRegister() {
        return new EnvelopeXmlSerializerBuilderMappingRegister();
    }

    private void registerFilterMappings(XmlSerializerBuilder builder) {
        createFilterMappingRegister().registerMappings(builder, InventoryImportGlobalXmlSerializerProvider.NAMESPACE);
    }

    private FilterXmlSerializerBuilderMappingRegister createFilterMappingRegister() {
        return new FilterXmlSerializerBuilderMappingRegister();
    }
}