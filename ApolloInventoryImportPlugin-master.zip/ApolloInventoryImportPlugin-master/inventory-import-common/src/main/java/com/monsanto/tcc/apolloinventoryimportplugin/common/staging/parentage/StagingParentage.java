/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: StagingParentage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-02-20 18:43:08 $
 *
 * @author SSPEYY
 * @version $Revision: 1.3 $
 */
public class StagingParentage {
    private Long id;
    private StagingInventory childInventory;
    private StagingInventory parentInventory;
    private StagingInventory mainInventory;
    private String parentalRole;
    private Long recordLevel;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public StagingInventory getChildInventory() {
        return childInventory;
    }

    public void setChildInventory(StagingInventory childInventory) {
        this.childInventory = childInventory;
    }

    public StagingInventory getParentInventory() {
        return parentInventory;
    }

    public void setParentInventory(StagingInventory parentInventory) {
        this.parentInventory = parentInventory;
    }

    public StagingInventory getMainInventory() {
        return mainInventory;
    }

    public void setMainInventory(StagingInventory mainInventory) {
        this.mainInventory = mainInventory;
    }

    public String getParentalRole() {
        return parentalRole;
    }

    public void setParentalRole(String parentalRole) {
        this.parentalRole = parentalRole;
    }

    public Long getRecordLevel() {
        return recordLevel;
    }

    public void setRecordLevel(Long recordLevel) {
        this.recordLevel = recordLevel;
    }
}