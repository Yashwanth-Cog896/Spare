/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception;

/**
 * Filename:    $RCSfile: OriginLineageDosageMismatchException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-15 15:09:33 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class OriginLineageDosageMismatchException extends Exception {
    public OriginLineageDosageMismatchException() {
    }

    public OriginLineageDosageMismatchException(Throwable cause) {
        super(cause);
    }

    public OriginLineageDosageMismatchException(String message) {
        super(message);
    }

    public OriginLineageDosageMismatchException(String message, Throwable cause) {
        super(message, cause);
    }
}