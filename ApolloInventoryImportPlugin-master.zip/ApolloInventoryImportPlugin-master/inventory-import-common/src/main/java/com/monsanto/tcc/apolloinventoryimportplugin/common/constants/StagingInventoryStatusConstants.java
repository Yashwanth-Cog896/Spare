/*
 StagingInventoryStatusConstants was created on Mar 3, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: StagingInventoryStatusConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna
 * $     On:$Date: 2007-10-05 14:00:22 $
 *
 * @author SRKARNA
 * @version $Revision: 1.8 $
 */
public class StagingInventoryStatusConstants {
    public static final String NEW = "New";
    public static final String VALID = "Valid";
    public static final String INVALID = "Invalid";
    public static final String CONDITIONALVALID = "ConditionalValid";
    public static final String AUTHORITY_EDIT_INVALID = "Pending-Invalid";
    public static final String APPROVED = "Approved";
    public static final String REJECTED = "Rejected";
    public static final String REJECTED_DELETE = "Rejected-Delete";
    public static final String PENDING = "Pending";
    public static final String PENDING_EDIT = "Pending-Edit";
    public static final String PENDING_INVALID = "Pending-Invalid";
    public static final String UNPROCESSED = "Unprocessed";
    public static final String IMPORTED = "Imported";
    public static final String IMPORT_INVALID = "Import-Invalid";
}