/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.parentage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: PedigreeNameBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $ On:$Date:
 * 2007/03/12 18:54:39 $
 *
 * @author skumar5
 * @version $Revision: 1.1 $
 */
public class PedigreeNameBuilder {
    public static final String PROGRAM_PEDIGREE_SEPARATOR_SYMBOL = "_";
    public static final String LINEAGE_SYMBOL = ":";
    public static final String LINE_CODE_SYMBOL = "|";
    public static final String HYBRID_CROSS_SYMBOL = "+";
    public static final String BREEDING_CROSS_SYMBOL = "/";
    public static final String LINE_TYPE_REQUIRED_MSG = "lineTypeRefID is required.";


    public String createPedigreeNameForInventoryImport(StagingInventory stagingInventory) {
        return createPedigreeNameForInventoryImport(stagingInventory.getLineType(), stagingInventory.getOrigin(),
                stagingInventory.getLineage(), stagingInventory.getLineCode(), stagingInventory.getProductName(),
                stagingInventory.getGermplasmOwner());
    }

    public String createPedigreeNameForInventoryImport(String lineTypeRefID, String origin, String lineage,
                                                       String lineCode,
                                                       String productName, String ownerProgram) {
        boolean prefixOwnerProgram = false;

        if (lineTypeRefID.equalsIgnoreCase(LineTypeRef.SEGPOP) || lineTypeRefID.equalsIgnoreCase(LineTypeRef.CODED)) {
            prefixOwnerProgram = true;
        }

        return createPedigreeName(lineTypeRefID, origin, lineage, lineCode, productName, ownerProgram, prefixOwnerProgram);
    }

    public String createPedigreeName(String lineTypeRefID, String origin, String lineage, String lineCode,
                                     String productName, String ownerProgram) {
        return createPedigreeName(lineTypeRefID, origin, lineage, lineCode, productName, ownerProgram, true);
    }

    public String createPedigreeName(String lineTypeRefID, String origin, String lineage, String lineCode,
                                     String productName, String ownerProgram, boolean prefixOwnerProgram) {
        if (StringUtils.isNullOrEmpty(lineTypeRefID)) {
            throw new IllegalArgumentException(LINE_TYPE_REQUIRED_MSG);
        }

        StringBuffer pedigree = new StringBuffer();

        if (lineTypeRefID.equalsIgnoreCase(LineTypeRef.SEGPOP) ||
                lineTypeRefID.equalsIgnoreCase(LineTypeRef.HYBRID) ||
                lineTypeRefID.equalsIgnoreCase(LineTypeRef.OP_VAR)) {
            if (prefixOwnerProgram) {
                pedigree.append(ownerProgram);
                pedigree.append(PROGRAM_PEDIGREE_SEPARATOR_SYMBOL);
            }
            pedigree.append(originAndLineagePedigree(origin, lineage));
        } else if (lineTypeRefID.equalsIgnoreCase(LineTypeRef.CODED)) {
            if (prefixOwnerProgram) {
                pedigree.append(ownerProgram);
                pedigree.append(PROGRAM_PEDIGREE_SEPARATOR_SYMBOL);
            }
            pedigree.append(productOrLineCodeOrOriginAndLineagePedigree(origin, lineage, productName, lineCode));

        } else if (lineTypeRefID.equalsIgnoreCase(LineTypeRef.FINISHED)) {
            pedigree.append(productOrLineCodeOrOriginPedigree(origin, lineCode, productName));
        }

        if (pedigree.length() == 0) {
            return null;
        }
        return pedigree.toString();
    }

    private String productOrLineCodeOrOriginAndLineagePedigree(String origin, String lineage, String productName,
                                                               String lineCode) {
        String parentagePart = productOrLineCodeOrOriginPedigree(origin, lineCode, productName);
        String lineagePart = "";

        if (lineage != null && lineage.length() > 0) {
            int idxLastPipe = lineage.lastIndexOf(LINE_CODE_SYMBOL);
            if (idxLastPipe != -1 && !lineage.endsWith(LINE_CODE_SYMBOL)) {
                lineagePart = LINEAGE_SYMBOL + lineage.substring(idxLastPipe + 1);
            } else if (idxLastPipe == -1) {
                lineagePart = LINEAGE_SYMBOL + lineage;
            }
        }

        return parentagePart + lineagePart;
    }

    private String productOrLineCodeOrOriginPedigree(String origin, String lineCode, String productName) {
        if (productName != null && productName.length() > 0) {
            return productName;
        } else if (lineCode != null && lineCode.length() > 0) {
            return lineCode;
        } else {
            return origin;
        }
    }

    private String originAndLineagePedigree(String origin, String lineage) {
        String parentagePart = origin;
        String lineagePart = "";

        if (lineage != null && lineage.length() > 0) {
            lineagePart = LINEAGE_SYMBOL + lineage;
        }
        return parentagePart + lineagePart;
    }
}