/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: CrossOperatorConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-11-01 16:23:49 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class CrossOperatorConstants {
    public static final String TEST_CROSS_OPERATOR = "+";
    public static final String DEV_CROSS_OPERATOR = "/";
    public static final String CLINE_DEV_CROSS_OPERATOR = "\\";
}