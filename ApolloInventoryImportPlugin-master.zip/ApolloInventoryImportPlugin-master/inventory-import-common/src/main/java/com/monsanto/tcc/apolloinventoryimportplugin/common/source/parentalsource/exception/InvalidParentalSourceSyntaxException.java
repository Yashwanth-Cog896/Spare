/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.source.parentalsource.exception;

/**
 * Filename:    $RCSfile: InvalidParentalSourceSyntaxException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2007-04-11 23:56:30 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class InvalidParentalSourceSyntaxException extends Exception {

    public InvalidParentalSourceSyntaxException(String message) {
        super(message);
    }
}