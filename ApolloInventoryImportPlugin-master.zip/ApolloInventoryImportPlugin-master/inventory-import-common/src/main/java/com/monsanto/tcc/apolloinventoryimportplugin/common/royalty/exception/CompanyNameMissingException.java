package com.monsanto.tcc.apolloinventoryimportplugin.common.royalty.exception;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 23, 2010
 * Time: 6:32:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyNameMissingException extends Exception {
    public CompanyNameMissingException(String message) {
        super(message);
    }
}
