package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.builder;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 9, 2009
 * Time: 10:52:33 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GenerationBuilder {
    String getGenerationStringFromLineage(String lineage);
}
