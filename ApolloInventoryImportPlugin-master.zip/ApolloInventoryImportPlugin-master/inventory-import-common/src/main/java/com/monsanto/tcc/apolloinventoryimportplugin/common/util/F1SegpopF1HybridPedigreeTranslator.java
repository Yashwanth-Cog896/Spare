/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree.PedigreeParser;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Filename:    $RCSfile: F1SegpopF1HybridPedigreeTranslator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-06-16 21:48:52 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class F1SegpopF1HybridPedigreeTranslator {
    private static final Log logger = LogFactory.getLog(F1SegpopF1HybridPedigreeTranslator.class);
    private static final String PEDIGREE_REQ_MSG = "pedigree is required";
    private static final String LINEAGE_DELIMITER = ":";
    private static final String OWNER_DELIMITER = "_";
    private PedigreeParser pedigreeParser;

    public String translate(String originalPedigree) {
        if (StringUtils.isNullOrEmpty(originalPedigree)) {
            throw new IllegalArgumentException(PEDIGREE_REQ_MSG);
        }
        pedigreeParser = new PedigreeParser(originalPedigree);
        String translatedOrigin = translateOrigin();
        return createPedigreeString(getOwner(), translatedOrigin, getLineage());
    }

    protected String getOwner() {
        String owner = pedigreeParser.getGermplasmOwnerString();
        return !StringUtils.isNullOrEmpty(owner) ? owner : "";
    }

    protected String getLineage() {
        String lineage = pedigreeParser.getLineageString();
        return !StringUtils.isNullOrEmpty(lineage) ? lineage : "";
    }

    protected String getOrigin() {
        String origin = pedigreeParser.getOriginOrLineCodeString();
        return !StringUtils.isNullOrEmpty(origin) ? origin : "";
    }

    private String translateOrigin() {
        String translatedOrigin = getOrigin();
        if (StringUtils.isNullOrEmpty(translatedOrigin)) {
            return "";
        }
        try {
            translatedOrigin = new F1SegpopF1HybridOriginTranslator().translate(getOrigin());
        } catch (InvalidOriginSyntaxException e) {
            logger.error("An error occurred translating the orifgin: " + e);
        }
        return translatedOrigin;
    }

    private String createPedigreeString(String owner, String origin, String lineage) {
        return createOwnerPrefix(owner) + createOriginString(origin) + createLineageSuffix(lineage);
    }

    private String createOwnerPrefix(String owner) {
        return StringUtils.isNullOrEmpty(owner) ? "" : owner + OWNER_DELIMITER;
    }

    private String createOriginString(String origin) {
        return StringUtils.isNullOrEmpty(origin) ? "" : origin;
    }

    private String createLineageSuffix(String lineage) {
        return StringUtils.isNullOrEmpty(lineage) ? "" : LINEAGE_DELIMITER + lineage;
    }
}