/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

/**
 * Filename:    $RCSfile: RowDefinitionFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: sspeyy $     On:$Date: 2007-07-13 17:02:04 $
 *
 * @author DDBROW5
 * @version $Revision: 1.3 $
 */
public class RowDefinitionFactory {
    public static final String MATERIAL_TYPE_REQUIRED_MSG = "materialType is required";

    public RowDefinition createRowDefintion(String materialType) {
        RowDefinition rowDefinition = null;
        if (StringUtils.isNullOrEmpty(materialType)) {
            throw new IllegalArgumentException(MATERIAL_TYPE_REQUIRED_MSG);
        }
//        if (materialType.equals(MaterialTypeConstants.COMMERCIAL_PRODUCT)) {
//            //rowDefinition = new CommercialRowDefinition();
//        } else if (materialType.equals(MaterialTypeConstants.COMPETITOR_PRODUCT)) {
//            //rowDefinition = new CompetitorRowDefinition();
//        } else if (materialType.equals(MaterialTypeConstants.FINISHED_LINES)) {
//            //rowDefinition = new CompetitorRowDefinition();
//        } else if (materialType.equals(MaterialTypeConstants.CODED_LINES)) {
//            //rowDefinition = new CompetitorRowDefinition();
//        } else if (materialType.equals(MaterialTypeConstants.SEGPOP_LINES)) {
//            //rowDefinition = new CompetitorRowDefinition();
//        } else
        if (materialType.equals(MaterialTypeConstants.HYBRID_LINES)) {
            rowDefinition = new HybridRowDefinition();
        } else if (materialType.equals(MaterialTypeConstants.ICB_MALE)) {
            rowDefinition = new ICBMaleRowDefinition();
        }
        return rowDefinition;
    }
}