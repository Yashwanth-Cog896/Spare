/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints.DefaultConstraint;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints.NotNullConstraint;

/**
 * Filename:    $RCSfile: ICBMaleRowDefinition.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-03-18 16:42:03 $
 *
 * @author SSPEYY
 * @version $Revision: 1.10 $
 */
public class ICBMaleRowDefinition implements RowDefinition {
    private static final String ROW_TYPE = MaterialTypeConstants.ICB_MALE;
    private static final boolean APPEARS_IN_TABLE = true;
    private static final boolean DOES_NOT_APPEAR_IN_TABLE = false;
    private static final boolean APPEARS_IN_TEMPLATE = true;
    private static final boolean APPEARS_IN_EXPORT_TEMPLATE = true;
    private static final boolean DOES_NOT_APPEAR_IN_TEMPLATE = false;
    private RowMetaData rowMetaData = null;
    private String cropName;

    public ICBMaleRowDefinition() {
        rowMetaData = new RowMetaData();
        rowMetaData.addColumn("Pedigree", "pedigreeName", CELL_TYPE_STRING, new NotNullConstraint("Pedigree"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Source", "source", CELL_TYPE_STRING, new NotNullConstraint("Source"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("ICB Male", "icbMale", CELL_TYPE_STRING, new NotNullConstraint("ICB Male"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Line Function", "lineFunction", CELL_TYPE_STRING, new DefaultConstraint("Line Function"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Reason for Rejection", "rejectionReason", CELL_TYPE_STRING, new DefaultConstraint("Reason for Rejection"), DOES_NOT_APPEAR_IN_TABLE, DOES_NOT_APPEAR_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Validation Message", "validationMessage", CELL_TYPE_STRING, new DefaultConstraint("Validation Message"), DOES_NOT_APPEAR_IN_TABLE, DOES_NOT_APPEAR_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
    }

    public RowMetaData getRowMetaData() {
        return rowMetaData;
    }

    public int getRowCount() {
        return rowMetaData.size();
    }

    public String getRowType() {
        return ROW_TYPE;
    }

    @Override
    public String getCropName() {
        return this.cropName;
    }

    @Override
    public void setCropName(String cropName) {
        this.cropName = cropName;
    }
}