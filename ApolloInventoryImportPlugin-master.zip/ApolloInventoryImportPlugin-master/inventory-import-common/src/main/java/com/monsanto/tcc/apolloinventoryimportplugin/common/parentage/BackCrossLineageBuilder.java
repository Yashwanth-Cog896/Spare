/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.parentage;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: BackCrossLineageBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2007-08-09 15:50:05 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.2 $
 */
public class BackCrossLineageBuilder implements LineageBuilder {

    public List BuildLineage(String lineage) {
        if (lineage == null || "".equals(lineage)) {
            throw new IllegalArgumentException("Lineage value is missing.");
        }
        ArrayList aList = new ArrayList();

        String lastLineageSection;
        while (!"".equals(lineage)) {
            lastLineageSection = getLastLineageSection(lineage);
            if (checkLastLineageSectionIsPipe(getLastLineageSection(lineage))) {
                int removePipePlusDot = 2;
                if ("|".equals(lineage)) {
                    removePipePlusDot = 0;
                }
                lineage = lineage.substring(0, lineage.length() - removePipePlusDot);
                lastLineageSection = getLastLineageSection(lineage);
            }
            lineage = getParent(lineage, lastLineageSection);
            aList.add(lineage);
        }
        return aList;
    }

    private String getParent(String lineage, String lastLineageSection) {
        return lineage.substring(0, lineage.lastIndexOf(lastLineageSection));
    }


    private boolean checkLastLineageSectionIsPipe(String lastLineage) {
        return (lastLineage.equals(PedigreeConstants.LINEAGE_SEPARATOR));
    }

    private String getLastLineageSection(String lineage) {
        StringBuffer section = new StringBuffer();
        for (int index = lineage.length() - 1; index >= 0; index--) {
            char current = lineage.charAt(index);
            if (includeCharacterInLastLineageSection(index, lineage, current)) {
                section.append(current);
            } else {
                break;
            }
        }
        return section.reverse().toString();
    }

    private boolean includeCharacterInLastLineageSection(int index, String lineage, char current) {
        return isLastCharacter(index, lineage) || !isBreakInLineageSymbol(current);
    }

    private boolean isLastCharacter(int index, String lineage) {
        return index == lineage.length() - 1;
    }

    private boolean isBreakInLineageSymbol(char character) {
        return character == PedigreeConstants.SELF_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.SIB_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.OPEN_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.INDUCE_HAPLOID_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.DEVCROSS_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.TESTCROSS_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.BACKCROSS_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.SINGLE_SEED_SYMBOL.toCharArray()[0] ||
                character == PedigreeConstants.LINEAGE_SEPARATOR.toCharArray()[0];
    }
}