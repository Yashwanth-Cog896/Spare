package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.builder;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Sep 20, 2009
 * Time: 1:15:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class MassOpenOperationsParser {
    public List<String> parse(String generation) {
        List<String> opeartions = new ArrayList<String>();

        Pattern pattern = Pattern.compile("[FM]\\d{1,}");
        Matcher matcher = pattern.matcher(generation);
        while (matcher.find()) {
            String matchingString = matcher.group();
            String noOfOperations = matchingString.substring(1);
            if (noOfOperations != null && noOfOperations.length() > 0) {
                int noOfOperationsIntValue = Integer.parseInt(noOfOperations);
                for (int liCounter = 0; liCounter < noOfOperationsIntValue; liCounter++) {
                    opeartions.add(matchingString.substring(0, 1));
                }
            }
        }
        return opeartions;
    }
}
