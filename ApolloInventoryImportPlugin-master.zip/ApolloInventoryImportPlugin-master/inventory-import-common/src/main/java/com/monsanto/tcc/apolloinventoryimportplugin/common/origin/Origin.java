/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: Origin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/05 22:25:51 $
 *
 * @author SSPEYY
 * @version $Revision: 1.5 $
 */
public class Origin {
    private static final String HYBRID_DELIMETER = "+";
    private OriginSyntaxVerifier originSyntaxVerifier;
    private OriginEntity originTree;
    protected String originString;

    public Origin(String originString) throws InvalidOriginSyntaxException {
        originSyntaxVerifier = new OriginSyntaxVerifier(originString);
        originTree = originSyntaxVerifier.getOriginTree();
        this.originString = originString;
    }

    protected Origin() {
    }

    public boolean isHybrid() {
        return originTree.getOperator() != null && originTree.getOperator().startsWith(HYBRID_DELIMETER);
    }

    protected OriginEntity getOriginTree() {
        return originTree;
    }

    public String getOriginString() {
        return originString;
    }

    public int getDosage() {
        Integer dosage = originSyntaxVerifier.getDosage();
        return (dosage != null) ? dosage.intValue() : 0;
    }
}