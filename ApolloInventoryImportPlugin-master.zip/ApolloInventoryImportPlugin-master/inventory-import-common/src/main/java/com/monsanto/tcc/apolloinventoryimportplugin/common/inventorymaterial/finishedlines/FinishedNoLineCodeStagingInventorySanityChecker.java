/*
 FinishedNoLineCodeStagingInventorySanityChecker was created on Apr 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.finishedlines;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.StagingInventorySanityCheckException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.ALineFunctionCytoplasmCheckForNonProductLines;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionNonHybridNonProductCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.NonALineFunctionCytoplasmNonProductLinesCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.ALineLineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidALineMSCLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: FinishedNoLineCodeStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ssnall $     On:$Date: 2009-06-05 14:08:07 $
 *
 * @author SRKARNA
 * @version $Revision: 1.13 $
 */
public class FinishedNoLineCodeStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    public static final String INVALID_A_LINE_FUNCTION_GENERATION = "Invalid generation for A line function";
    private StagingInventory stagingInventory = null;

    public FinishedNoLineCodeStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);
        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getGermplasmOwner())) {
            msgList.add(MANDATORY_CHECK_MSG + "Germplasm Owner");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getLineCode())) {
            msgList.add(MANDATORY_CHECK_MSG + "Line Code");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getOrigin())) {
            msgList.add(MANDATORY_CHECK_MSG + "Origin");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getGeneration())) {
            msgList.add(MANDATORY_CHECK_MSG + "Generation");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getLineage())) {
            msgList.add(MANDATORY_CHECK_MSG + "Lineage");
        }
        if (isLineFunctionA(stagingInventory.getLineFunction())) {
            if (!stagingInventory.isSubRecord()) {
                new ALineFunctionCytoplasmCheckForNonProductLines(stagingInventory.getCytoplasmDonorPedigree(),
                        stagingInventory.getCytoplasmDonorSource(), stagingInventory.getBuildParentage()).check(msgList);
                try {
                    validateGeneration(stagingInventory.getGeneration(),
                            stagingInventory.getBuildParentage(), stagingInventory.getLineage(), stagingInventory.getLineFunction());
                } catch (StagingInventorySanityCheckException e) {
                    msgList.add(e.getMessage());
                }
                catch (InvalidALineMSCLineageException e) {
                    msgList.add(e.getMessage());
                }
            }
        } else {
            new NonALineFunctionCytoplasmNonProductLinesCheck(stagingInventory.getCytoplasmDonorPedigree(),
                    stagingInventory.getCytoplasmDonorSource()).check(msgList);
        }
        new AllowedLineFunctionNonHybridNonProductCheck(stagingInventory.getLineFunction()).check(msgList);
    }

    private void validateGeneration(String generation, String buildParentage, String lineage, String lineFunctionRefId)
            throws StagingInventorySanityCheckException, InvalidALineMSCLineageException {

        if (!"|".equalsIgnoreCase(lineage)) {
            new ALineLineage(stagingInventory.getLineage());
            validateMSCGeneration(generation);
        } else {
            if (!isBuildParentageFlagRequested(buildParentage)) {
                if (isALineFunction(lineFunctionRefId)) {
                    checkGenerationIsEmptyOrNotMSCAndNotInbred(generation);
                } else {
                    checkGenerationIsInbred(generation);
                }
            } else { //| and BP = Y
                throw new StagingInventorySanityCheckException(INVALID_A_LINE_FUNCTION_GENERATION);
            }
        }
    }

    private void checkGenerationIsInbred(String generation) throws StagingInventorySanityCheckException {
        if (!"INBRED".equalsIgnoreCase(generation)) {
            throw new StagingInventorySanityCheckException(INVALID_A_LINE_FUNCTION_GENERATION);
        }
    }

    private void checkGenerationIsEmptyOrNotMSCAndNotInbred(String generation) throws StagingInventorySanityCheckException {
        if (StringUtils.isNullOrEmpty(generation) ||
                (!isGenerationValidMSC(generation) && !"INBRED".equalsIgnoreCase(generation))) {
            throw new StagingInventorySanityCheckException(INVALID_A_LINE_FUNCTION_GENERATION);
        }
    }

    private void validateMSCGeneration(String generation) throws StagingInventorySanityCheckException {
        if (StringUtils.isNullOrEmpty(generation) || !isGenerationValidMSC(generation)) {
            throw new StagingInventorySanityCheckException(INVALID_A_LINE_FUNCTION_GENERATION);
        }
    }

    private boolean isGenerationValidMSC(String generation) {
        String mscPatternString = "^MSC[0-9]+$";
        Pattern mscPattern = Pattern.compile(mscPatternString);
        Matcher mscMatcher = mscPattern.matcher(generation);
        return mscMatcher.matches();
    }

    private boolean isLineFunctionA(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) &&
                LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }

}