/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Filename:    $RCSfile: NullConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date:
 * 2007/10/25 20:16:05 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NullConstraint implements DataConstraint {
    private String subject = null;
    private String messageToDisplayOnFailure;

    public NullConstraint(String subject) {
        if (StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject is required.");
        }

        this.subject = subject;
        messageToDisplayOnFailure = "Value for " + subject + " must be null";
    }

    public boolean validate(Map dataSource) {
        return StringUtils.isNullOrEmpty((String) dataSource.get(subject));
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        this.messageToDisplayOnFailure = messageToDisplayOnFailure;
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}