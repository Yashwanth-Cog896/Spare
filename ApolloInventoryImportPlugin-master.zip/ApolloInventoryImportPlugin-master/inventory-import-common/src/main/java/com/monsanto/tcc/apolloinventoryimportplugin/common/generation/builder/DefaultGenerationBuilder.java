/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.builder;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: GenerationBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $ On:$Date:
 * 2007/12/19 17:32:05 $
 *
 * @author APATRO
 * @version $Revision: 1.3 $
 */
public class DefaultGenerationBuilder extends AbstractGenerationBuilder {

    public DefaultGenerationBuilder() {
        super(null, null);
    }

    public DefaultGenerationBuilder(String mainRecordGeneration) {
        super(mainRecordGeneration, null);
    }

    public DefaultGenerationBuilder(String mainRecordGeneration, String lineFunction) {
        super(mainRecordGeneration, lineFunction);
    }


    protected String getSimpleGeneration(String lineage) {
        int slCount = 1;
        Matcher slMatcher = getSimpleLineagePattern().matcher(lineage);
        while (slMatcher.find()) {
            slCount++;
        }
        String simpleGeneration = null;
        if (slCount > 1) {
            simpleGeneration = "F" + slCount;
        }
        return simpleGeneration;
    }

    protected Pattern getSimpleLineagePattern() {
        String simpleLineagePattern = "[.#$!]";
        return Pattern.compile(simpleLineagePattern);
    }

}