/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions;

import com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints.DataConstraint;


/**
 * Filename:    $RCSfile: RowMetaDataEntry.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    On: $Date: 2008-02-12 20:22:31 $
 *
 * @author ddbrow5
 * @version $Revision: 1.5 $
 * @noinspection MethodWithTooManyParameters
 */
public class RowMetaDataEntry {
  private String displayName = null;
  private String alternateDisplayName = null;
  private String attributeName = null;
  private String alternateAttributeName = null;
  private int hssfCellType = -1;
  private int alternateHSSFCellType = -1;
  private DataConstraint constraint;
  private DataConstraint alternateConstraint;
  private boolean isAlternateDataPresent = false;
  private boolean appearsInTable = false;
  private boolean appearsInTemplate = false;
  private boolean appearsInExportTemplate = false;
  public static final String ATTR_NAME_REQ_FIRST_MSG = "Attribute name must be set first.";

  public RowMetaDataEntry() {
  }

  public RowMetaDataEntry(String displayName, String attributeName, int hssfCellType, DataConstraint constraint, boolean appearsInTable, boolean appearsInTemplate) {
    setDisplayName(displayName);
    setAttributeName(attributeName);
    setHSSFCellType(hssfCellType);
    setConstraint(constraint);
    this.appearsInTable = appearsInTable;
    this.appearsInTemplate = appearsInTemplate;
    this.appearsInExportTemplate = appearsInTemplate;
  }

  public RowMetaDataEntry(String displayName, String attributeName, int hssfCellType, DataConstraint constraint, boolean appearsInTable, boolean appearsInTemplate,  boolean appearsInExportTemplate) {
    setDisplayName(displayName);
    setAttributeName(attributeName);
    setHSSFCellType(hssfCellType);
    setConstraint(constraint);
    this.appearsInTable = appearsInTable;
    this.appearsInTemplate = appearsInTemplate;
    this.appearsInExportTemplate = appearsInExportTemplate;
  }

  public RowMetaDataEntry(String displayName, String attributeName, int hssfCellType, DataConstraint constraint,
                          String alternateDisplayName, String alternateAttributeName, int alternateHSSFCellType, DataConstraint alternateConstraint,
                          boolean appearsInTable, boolean appearsInTemplate) {
    setDisplayName(displayName);
    setAttributeName(attributeName);
    setHSSFCellType(hssfCellType);
    setConstraint(constraint);
    setAlternateDisplayName(alternateDisplayName);
    setAlternateAttributeName(alternateAttributeName);
    setAlternateHSSFCellType(alternateHSSFCellType);
    setAlternateConstraint(alternateConstraint);
    this.appearsInTable = appearsInTable;
    this.appearsInTemplate = appearsInTemplate;
    this.appearsInExportTemplate = appearsInTemplate;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getAlternateDisplayName() {
    this.isAlternateDataPresent = true;
    return alternateDisplayName;
  }

  public void setAlternateDisplayName(String alternateDisplayName) {
    this.isAlternateDataPresent = true;
    this.alternateDisplayName = alternateDisplayName;
  }

  public void setAttributeName(String name) {
    if (null != name) {
      name = name.trim();
    }
    this.attributeName = name;
  }

  public String getAttributeName() {
    return this.attributeName;
  }

  public void setAlternateAttributeName(String name) {
    if (null != name) {
      name = name.trim();
    }
    this.isAlternateDataPresent = true;
    this.alternateAttributeName = name;
  }

  public String getAlternateAttributeName() {
    return this.alternateAttributeName;
  }

  public void setHSSFCellType(int hssfCellType) {
    this.hssfCellType = hssfCellType;
  }

  public int getHSSFCellType() {
    return this.hssfCellType;
  }

  public void setAlternateHSSFCellType(int type) {
    this.isAlternateDataPresent = true;
    this.alternateHSSFCellType = type;
  }

  public int getAlternateHSSFCellType() {
    return this.alternateHSSFCellType;
  }

  public DataConstraint getConstraint() {
    return constraint;
  }

  public void setConstraint(DataConstraint constraint) {
    this.constraint = constraint;
  }

  public DataConstraint getAlternateConstraint() {
    return alternateConstraint;
  }

  public void setAlternateConstraint(DataConstraint alternateConstraint) {
    this.isAlternateDataPresent = true;
    this.alternateConstraint = alternateConstraint;
  }

  public boolean isAlternateDataPresent() {
    return this.isAlternateDataPresent;
  }

  public boolean isAppearsInTable() {
    return appearsInTable;
  }

  public boolean isAppearsInTemplate() {
    return appearsInTemplate;
  }

  public boolean isAppearsInExportTemplate() {
    return appearsInExportTemplate;
  }
}