package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

public class TransgenicConstraint {
    public static DataConstraint getConstraint(String cropName) {
        return new AndDataConstraint(
                new DataConstraint[]{
                        new CropConstraint("Transgenic?", cropName),
                        new PredicateDataConstraint(
                                new DataConstraint[]{
                                        new CheckConstraint("Transgenic?", "T")
                                },
                                new DataConstraint[]{
                                        new NotNullConstraint("Are Allergens Present?"),
                                        new NotNullConstraint("Are Toxins Present?"),
                                        new NotNullConstraint("Contains Animal Gene?"),
                                        new NotNullConstraint("Contains Mini Chromosome?")
                                }
                        ),
                        new PredicateDataConstraint(
                                new DataConstraint[]{
                                        new NotNullConstraint("Event")
                                },
                                new DataConstraint[]{
                                        new CheckConstraint("Transgenic?", "T", "Transgenic must be T if Event exists")
                                }
                        )
                });
    }
}
