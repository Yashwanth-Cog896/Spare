/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.authority.Authority;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: SendMaterialToAuthorityPOSClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-01 20:19:01 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class SendMaterialToAuthorityPOSClient extends AbstractPOSClient {
    private static final String POS_ACTIVITY = "SendMaterialToAuthority";

    public SendMaterialToAuthorityPOSClient() {
        super.setPosActivityName(POS_ACTIVITY);
    }

    public void sendMaterialToAuthority(StagingInventory[] stagingInventories) throws ActivityClientException {
        sendToPos(createCompositeObject(stagingInventories));
    }

    private CompositeObject createCompositeObject(StagingInventory[] stagingInventory) {
        CompositeObject payload = new CompositeObject();
        payload.add(getFilterWithDefaultFilterId());
        Authority authority = new Authority();
        authority.setLoginId(System.getProperty("user.name"));
        payload.add(authority);
        for (int i = 0; i < stagingInventory.length; i++) {
            StagingInventory inventory = stagingInventory[i];
            StagingInventory dummyInventory = new StagingInventory();
            dummyInventory.setId(inventory.getId());
            payload.add(dummyInventory);
        }
        return payload;
    }
}