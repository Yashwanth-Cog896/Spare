/*
 HybridLinesStagingInventorySanityChecker was created on May 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.hybridlines;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionValuesHybridCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridLinesStagingInventorySanityChecker.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:09 $
 *
 * @author SRKARNA
 * @version $Revision: 1.5 $
 */
public class HybridLinesStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    protected StagingInventory stagingInventory = null;

    public HybridLinesStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);
        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getGermplasmOwner())) {
            msgList.add(MANDATORY_CHECK_MSG + "Germplasm Owner");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getOrigin())) {
            msgList.add(MANDATORY_CHECK_MSG + "Origin");
        }

        if (!MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(stagingInventory.getLineType())) {
            msgList.add(stagingInventory.getLineType() + DATA_BOUNDARY_CHECK_MSG + "Line Type");
        }
        new AllowedLineFunctionValuesHybridCheck(stagingInventory.getLineFunction()).check(msgList);
    }
}