/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree;

/**
 * Filename:    $RCSfile: PedigreeSyntaxException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-06-17 17:28:47 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class PedigreeSyntaxException extends Exception {
    public PedigreeSyntaxException(Throwable cause) {
        super(cause);
    }

    public PedigreeSyntaxException(String message) {
        super(message);
    }

    public PedigreeSyntaxException(String message, Throwable cause) {
        super(message, cause);
    }
}