/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.CLineGeneration;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.Generation;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;

/**
 * Filename:    $RCSfile: CLineLineageSyntaxChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-04 22:06:48 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class CLineLineageSyntaxChecker {
    private static final String PIPE_STRING = "|";
    private static final String LIN_NULL_GEN_NOT_MSC0_MSG = "When lineage is null generation must be MSC0";
    private static final String GEN_MSC0_LIN_MUST_BE_NULL_MSG = "When generation is MSC0 lineage must be null";
    private static final String LIN_PIPE_GEN_INBRED_MSG = "Lineage must be | when generation is INBRED";
    private static final String GEN_MUST_BE_INBRED_LIN_PIPE_MSG = "Generation must be INBRED when lineage is |";
    private static final String GEN_NOT_MSC0_INBRED_OR_BC = "Generation can only be null, MSC0, INBRED, or BCn";
    private Generation generation;

    public void validate(String lineage, String generationString) throws InvalidLineageException {
        try {
            generation = new CLineGeneration(generationString);
        } catch (InvalidCLineGenerationException e) {
            throw new InvalidLineageException(GEN_NOT_MSC0_INBRED_OR_BC);
        }

        if (isLineageNullOrEmpty(lineage)) {
            if (!generation.isMSC0()) {
                throw new InvalidLineageException(LIN_NULL_GEN_NOT_MSC0_MSG);
            }
        } else {
            new CLineLineage(lineage);
            if (generation.isMSC0()) {
                throw new InvalidLineageException(GEN_MSC0_LIN_MUST_BE_NULL_MSG);
            }
            if (generation.isInbred() && !isLineagePipe(lineage)) {
                throw new InvalidLineageException(LIN_PIPE_GEN_INBRED_MSG);
            }
            if (!generation.isInbred() && isLineagePipe(lineage)) {
                throw new InvalidLineageException(GEN_MUST_BE_INBRED_LIN_PIPE_MSG);
            }
        }
    }

    private boolean isLineageNullOrEmpty(String lineage) {
        return StringUtils.isNullOrEmpty(lineage);
    }

    private boolean isLineagePipe(String lineage) {
        return PIPE_STRING.equals(lineage);
    }
}