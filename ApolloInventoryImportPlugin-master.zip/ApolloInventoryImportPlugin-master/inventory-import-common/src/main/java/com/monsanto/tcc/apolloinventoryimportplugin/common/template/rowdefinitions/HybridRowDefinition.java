/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints.*;

/**
 * Filename:    $RCSfile: HybridRowDefinition.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $ On:$Date:
 * 2007/10/31 16:36:06 $
 *
 * @author ddbrow5
 * @version $Revision: 1.18 $
 */
public class HybridRowDefinition implements RowDefinition {
    private static final String ROW_TYPE = MaterialTypeConstants.HYBRID_LINES;
    private static final boolean APPEARS_IN_TABLE = true;
    private static final boolean DOES_NOT_APPEAR_IN_TABLE = false;
    private static final boolean APPEARS_IN_TEMPLATE = true;
    private static final boolean APPEARS_IN_EXPORT_TEMPLATE = true;
    private static final boolean DOES_NOT_APPEAR_IN_TEMPLATE = false;
    private static final boolean DOES_NOT_APPEAR_IN_EXPORT_TEMPLATE = false;
    private RowMetaData rowMetaData = null;
    private String cropName;

    public HybridRowDefinition() {
        rowMetaData = new RowMetaData();
        rowMetaData.addColumn("Germplasm Owner", "germplasmOwner", CELL_TYPE_STRING,
                new NotNullConstraint("Germplasm Owner"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Origin", "origin", CELL_TYPE_STRING, new NotNullConstraint("Origin"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Pedigree Name", "pedigreeName", CELL_TYPE_STRING,
                new DefaultConstraint("Pedigree Name"), APPEARS_IN_TABLE, DOES_NOT_APPEAR_IN_TEMPLATE);
        rowMetaData.addColumn("Source", "source", CELL_TYPE_STRING, new NotNullConstraint("Source"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Inventory Owner", "inventoryOwner", CELL_TYPE_STRING,
                new NotNullConstraint("Inventory Owner"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Vegetative Structure", "vegetativeStructure", CELL_TYPE_STRING,
                new NotNullConstraint("Vegetative Structure"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Transgenic?", "transgenic", CELL_TYPE_STRING_DEFAULT, TransgenicConstraint.getConstraint(getCropName()),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Is Exposure History Known?", "exposureHistoryKnown", CELL_TYPE_STRING_DEFAULT, new CropConstraint("Is Exposure History Known?", getCropName()),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Are Allergens Present?", "allergensPresent", CELL_TYPE_STRING_DEFAULT, new DefaultConstraint("Are Allergens Present?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Are Toxins Present?", "toxinsPresent", CELL_TYPE_STRING_DEFAULT, new DefaultConstraint("Are Toxins Present?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Contains Animal Gene?", "animalGenePresent", CELL_TYPE_STRING_DEFAULT, new DefaultConstraint("Contains Animal Gene?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Contains Mini Chromosome?", "miniChromosome", CELL_TYPE_STRING_DEFAULT, new DefaultConstraint("Contains Mini Chromosome?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("From Manufacturing?", "fromMfg", CELL_TYPE_STRING_DEFAULT, FromManufacturingConstraint.getConstraint(getCropName()),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Manufacturing Batch #?", "mfgBatchNumber", CELL_TYPE_STRING, new DefaultConstraint("Manufacturing Batch #?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Manufacturing Acronym #?", "mfgAcronymNumber", CELL_TYPE_STRING, new DefaultConstraint("Manufacturing Acronym #?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Manufacturing Material #?", "mfgMaterialNumber", CELL_TYPE_STRING_DEFAULT, new DefaultConstraint("Manufacturing Material #?"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Line Function", "lineFunction", CELL_TYPE_STRING, new DefaultConstraint("Line Function"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Royalty", "royalty", CELL_TYPE_STRING, new DefaultConstraint("Royalty"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Company", "company", CELL_TYPE_STRING, new DefaultConstraint("Company"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("External Germplasm Name", "externalGermplasmName", CELL_TYPE_STRING, new DefaultConstraint("External Germplasm Name"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Old Pedigree", "oldPedigree", CELL_TYPE_STRING,
                new DefaultConstraint("Old Pedigree"), APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Seed Quantity", "seedQuantity", CELL_TYPE_NUMERIC, new DefaultConstraint("Seed Quantity"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Seed Quantity_UOM", "seedQuantityUOM", CELL_TYPE_STRING, new DefaultConstraint("Seed Quantity_UOM"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("ASRT1", "asort1", CELL_TYPE_STRING, new DefaultConstraint("ASRT1"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("ASRT2", "asort2", CELL_TYPE_STRING, new DefaultConstraint("ASRT2"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("ASRT3", "asort3", CELL_TYPE_STRING, new DefaultConstraint("ASRT3"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("ASRT4", "asort4", CELL_TYPE_STRING, new DefaultConstraint("ASRT4"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("ASRT5", "asort5", CELL_TYPE_STRING, new DefaultConstraint("ASRT5"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("#SRT1", "nsort1", CELL_TYPE_NUMERIC, new DefaultConstraint("#SRT1"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("#SRT2", "nsort2", CELL_TYPE_NUMERIC, new DefaultConstraint("#SRT2"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("#SRT3", "nsort3", CELL_TYPE_NUMERIC, new DefaultConstraint("#SRT3"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("#SRT4", "nsort4", CELL_TYPE_NUMERIC, new DefaultConstraint("#SRT4"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("#SRT5", "nsort5", CELL_TYPE_NUMERIC, new DefaultConstraint("#SRT5"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("SRC Lot#", "srcLotNumber", CELL_TYPE_STRING, new DefaultConstraint("SRC Lot#"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Event", "event", CELL_TYPE_STRING, new DefaultConstraint("Event"), APPEARS_IN_TABLE,
                APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Comments", "comments", CELL_TYPE_STRING, new DefaultConstraint("Comments"),
                APPEARS_IN_TABLE, APPEARS_IN_TEMPLATE, APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Source of Female Parent", "femaleParentSource", CELL_TYPE_STRING,
                new DefaultConstraint("Source of Female Parent"), DOES_NOT_APPEAR_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("GP Owner of Female Parent", "germplasmOwnerOfFemaleParent", CELL_TYPE_STRING,
                new DefaultConstraint("GP Owner of Female Parent"), DOES_NOT_APPEAR_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Source of Male Parent", "maleParentSource", CELL_TYPE_STRING,
                new DefaultConstraint("Source of Male Parent"), DOES_NOT_APPEAR_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("GP Owner of Male Parent", "germplasmOwnerOfMaleParent", CELL_TYPE_STRING,
                new DefaultConstraint("GP Owner of Male Parent"), DOES_NOT_APPEAR_IN_TABLE, APPEARS_IN_TEMPLATE);
        rowMetaData.addColumn("Reason for Rejection", "rejectionReason", CELL_TYPE_STRING,
                new DefaultConstraint("Reason for Rejection"), DOES_NOT_APPEAR_IN_TABLE, DOES_NOT_APPEAR_IN_TEMPLATE,
                APPEARS_IN_EXPORT_TEMPLATE);
        rowMetaData.addColumn("Validation Message", "validationMessage", CELL_TYPE_STRING,
                new DefaultConstraint("Validation Message"), DOES_NOT_APPEAR_IN_TABLE, DOES_NOT_APPEAR_IN_TEMPLATE,
                APPEARS_IN_EXPORT_TEMPLATE);
    }

    public RowMetaData getRowMetaData() {
        return rowMetaData;
    }

    public int getRowCount() {
        return rowMetaData.size();
    }

    public String getRowType() {
        return ROW_TYPE;
    }

    @Override
    public String getCropName() {
        return this.cropName;
    }

    @Override
    public void setCropName(String cropName) {
        this.cropName = cropName;
    }
}
