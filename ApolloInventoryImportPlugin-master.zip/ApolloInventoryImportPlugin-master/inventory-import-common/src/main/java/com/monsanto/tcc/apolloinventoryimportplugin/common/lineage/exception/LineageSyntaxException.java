/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception;

/**
 * Filename:    $RCSfile: LineageSyntaxException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-03-19 21:59:48 $
 *
 * @author APATRO
 * @version $Revision: 1.1 $
 */
public class LineageSyntaxException extends Exception {
    public LineageSyntaxException(String message, Throwable cause) {
        super(message, cause);
    }

    public LineageSyntaxException(String message) {
        super(message);
    }
}