/*
 CommercialStagingInventory was created on Mar 13, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.commercialproducts;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.ParentalRoleConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: CommercialStagingInventory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-03-13 20:33:58 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class CommercialStagingInventory {
    private static final String STAGING_INVENTORY_IS_REQUIRED = "stagingInventory is required.";
    private StagingInventory stagingInventory;

    public CommercialStagingInventory(StagingInventory stagingInventory) {
        if (null == stagingInventory) {
            throw new IllegalArgumentException(STAGING_INVENTORY_IS_REQUIRED);
        }
        this.stagingInventory = stagingInventory;
    }

    public String getParentSource(String parentalRole) {
        String parentSource = null;

        if (ParentalRoleConstants.FEMALE_PARENTAL_ROLE.equalsIgnoreCase(parentalRole)) {
            parentSource = getFemaleParentSource(stagingInventory);
        } else if (ParentalRoleConstants.MALE_PARENTAL_ROLE.equalsIgnoreCase(parentalRole)) {
            parentSource = getMaleParentSource(stagingInventory);
        }

        return parentSource;
    }

    private String getMaleParentSource(StagingInventory stagingInventory) {
        return StringUtils.isNullOrEmpty(stagingInventory.getMaleParentSource()) ? SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE : stagingInventory.getMaleParentSource();
    }

    private String getFemaleParentSource(StagingInventory stagingInventory) {
        return StringUtils.isNullOrEmpty(stagingInventory.getFemaleParentSource()) ? SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE : stagingInventory.getFemaleParentSource();
    }

}