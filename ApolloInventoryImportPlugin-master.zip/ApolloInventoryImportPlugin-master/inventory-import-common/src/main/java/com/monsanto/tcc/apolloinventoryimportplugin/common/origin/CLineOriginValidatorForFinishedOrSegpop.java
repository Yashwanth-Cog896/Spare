/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.CLineGeneration;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.Generation;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.CLineLineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.Lineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: CLineOriginValidatorForFinishedOrSegpop.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:$Date:
 * 2008/03/12 15:29:38 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class CLineOriginValidatorForFinishedOrSegpop extends CLineOriginValidator {
    private static final String INBRED_ORIGIN_LONE_ENTITY = "When line type is Segpop or Finished, build parentage is not requested and the origin is a lone entity the generation/lineage must be MSC0/null or INBRED/|";
    private static final String INBRED_ORIGIN_NOT_LONE_ENTITY = "When line type is Segpop or Finished, build parentage is not requested and the origin is not a lone entity the generation/lineage cannot be INBRED/|";
    private static final String MSC0_ORIGIN_NOT_LONE_ENTITY = "When line type is Segpop or Finished, build parentage is not requested and the origin is not a lone entity the generation/lineage cannot be MSC0/null";

    public void validateOriginSyntax(String origin, String lineage, String generation, String buildParentage) throws
            InvalidOriginSyntaxException {
        super.validateOriginSyntax(origin, lineage, generation, buildParentage);

        try {
            validateFinishedOrSegpopOrigin(origin, lineage, generation, buildParentage);
        } catch (InvalidCLineGenerationException e) {
            throw new InvalidOriginSyntaxException(e.getMessage());
        } catch (InvalidLineageException e) {
            throw new InvalidOriginSyntaxException(e.getMessage());
        }
    }

    private void validateFinishedOrSegpopOrigin(String origin, String lineage, String generationString,
                                                String buildParentage) throws InvalidCLineGenerationException,
            InvalidLineageException, InvalidOriginSyntaxException {
        if (!isBuildParentageRequested(buildParentage)) {
            CLineOrigin cLineOrigin = new CLineOrigin(origin);
            Generation generation = new CLineGeneration(generationString);
            Lineage cLineLineage = new CLineLineage(lineage);
            validateLoneEntityOrigin(cLineOrigin, generation, cLineLineage);
            validateNonLoneEntityOrigin(cLineOrigin, generation, cLineLineage);
        }
    }

    private void validateLoneEntityOrigin(CLineOrigin cLineOrigin, Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (cLineOrigin.isLoneEntity()) {
            failWhenGenerationIsInbredAndLineageIsNotPipe(generation, cLineLineage);
            failWhenGenerationIsMSC0AndLineageIsNotEmpty(generation, cLineLineage);
        }
    }

    private void validateNonLoneEntityOrigin(CLineOrigin cLineOrigin, Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (!cLineOrigin.isLoneEntity()) {
            failWhenGenerationIsInbredAndLineageIsPipe(generation, cLineLineage);
            failWhenGenerationIsMSC0AndLineageIsEmpty(generation, cLineLineage);
            failWhenGenerationIsInbreadAndLineageIsEmpty(generation, cLineLineage);
            failWhenGenerationIsMSC0AndLineageIsPipe(generation, cLineLineage);
        }
    }

    private void failWhenGenerationIsInbredAndLineageIsNotPipe(Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (generation.isInbred() && !cLineLineage.isLineagePipe()) {
            throw new InvalidOriginSyntaxException(INBRED_ORIGIN_LONE_ENTITY);
        }
    }

    private void failWhenGenerationIsInbreadAndLineageIsEmpty(Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (generation.isInbred() && cLineLineage.isLineageNullOrEmpty()) {
            throw new InvalidOriginSyntaxException(INBRED_ORIGIN_NOT_LONE_ENTITY);
        }
    }

    private void failWhenGenerationIsInbredAndLineageIsPipe(Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (generation.isInbred() && cLineLineage.isLineagePipe()) {
            throw new InvalidOriginSyntaxException(INBRED_ORIGIN_NOT_LONE_ENTITY);
        }
    }

    private void failWhenGenerationIsMSC0AndLineageIsNotEmpty(Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (generation.isMSC0() && !cLineLineage.isLineageNullOrEmpty()) {
            throw new InvalidOriginSyntaxException(INBRED_ORIGIN_LONE_ENTITY);
        }
    }

    private void failWhenGenerationIsMSC0AndLineageIsEmpty(Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (generation.isMSC0() && cLineLineage.isLineageNullOrEmpty()) {
            throw new InvalidOriginSyntaxException(MSC0_ORIGIN_NOT_LONE_ENTITY);
        }
    }

    private void failWhenGenerationIsMSC0AndLineageIsPipe(Generation generation, Lineage cLineLineage) throws
            InvalidOriginSyntaxException {
        if (generation.isMSC0() && cLineLineage.isLineagePipe()) {
            throw new InvalidOriginSyntaxException(INBRED_ORIGIN_NOT_LONE_ENTITY);
        }
    }
}