/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.linecode.exception;

/**
 * Filename:    $RCSfile: LineCodeSyntaxException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-06-12 20:06:34 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class LineCodeSyntaxException extends Exception {
    public LineCodeSyntaxException(String message, Throwable cause) {
        super(message, cause);
    }

    public LineCodeSyntaxException(String message) {
        super(message);
    }
}