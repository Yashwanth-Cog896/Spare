/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

/**
 * Filename:    $RCSfile: NullLineage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/22 16:29:52 $
 *
 * @author ddbrow5
 * @version $Revision: 1.8 $
 */
public class NullLineage implements Lineage {
    public int getDosage() {
        return 0;
    }

    public int getNumberOfCycleMarkers() {
        return 0;
    }

    public boolean isBackcross() {
        return false;
    }

    public boolean isLineageNullOrPipe() {
        return isLineageNullOrEmpty() || isLineagePipe();
    }

    public boolean isLineageNullOrEmpty() {
        return true;
    }

    public boolean isLineagePipe() {
        return false;
    }

    public String[] getCycleMarkers() {
        return null;
    }
}