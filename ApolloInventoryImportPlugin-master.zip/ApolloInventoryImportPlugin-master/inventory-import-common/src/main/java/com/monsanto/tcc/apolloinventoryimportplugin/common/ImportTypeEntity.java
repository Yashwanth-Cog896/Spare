/*
 ImportTypeEntity was created on Dec 29, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.services.domain.common.Entity;

/**
 * Filename:    $RCSfile: ImportTypeEntity.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-12 16:59:51 $
 *
 * @author SRKARNA
 * @version $Revision: 1.4 $
 */
public class ImportTypeEntity implements Entity {
    private ImportType importType;

    public ImportTypeEntity(ImportType importType) {
        this.importType = importType;
    }

    public Object getID() {
        return importType.getId();
    }

    public String toString() {
        return importType.getDescription();
    }

    public ImportType getImportType() {
        return importType;
    }
}