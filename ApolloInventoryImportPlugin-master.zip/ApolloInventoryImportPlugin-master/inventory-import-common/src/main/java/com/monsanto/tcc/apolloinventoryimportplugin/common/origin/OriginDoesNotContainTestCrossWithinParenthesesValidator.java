package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Jun 23, 2008 Time: 6:56:15 AM To change this template use File |
 * Settings | File Templates.
 */
public class OriginDoesNotContainTestCrossWithinParenthesesValidator {

    public static final String EXCEPTION_MSG = "Origin cannot contain plus inside parentheses";

    public void validate(String origin) throws InvalidOriginSyntaxException {
        String[] components = new OriginSyntaxVerifier(origin).getEntities();
        for (String component : components) {
            if (checkIfComponentContainsPlusInsideParentheses(component)) {
                throw new InvalidOriginSyntaxException(EXCEPTION_MSG);
            }
        }
    }

    private boolean checkIfComponentContainsPlusInsideParentheses(String originComponent) {
        return originComponent.startsWith("(") && originComponent.endsWith(")") && originComponent.indexOf("+") > -1;
    }
}
