/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.linecode.LineCodeSyntaxVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.linecode.exception.LineCodeSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginSyntaxVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.SourceSyntaxVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.exception.InvalidSourceSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentageComparator;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

/**
 * Filename:    $RCSfile: StagingInventory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $ On:$Date:
 * 2007/04/02 21:50:46 $
 *
 * @author SSPEYY
 * @version $Revision: 1.66 $
 * @noinspection ReturnOfCollectionOrArrayField
 */
public class StagingInventory {
    private static final int MAX_ASORT_VALUE_SIZE = 255;
    private static final int MAX_AUTHORITY_PROCESSED_SIZE = 32;
    private static final int MAX_AUTHORITY_REQUESTED_SIZE = 32;
    private static final int MAX_COMMENTS_VALUE_SIZE = 512;
    private static final int MAX_FEMALE_PARENT_SOURCE_SIZE = 255;
    private static final int MAX_GENERATION_VALUE_SIZE = 255;
    private static final int MAX_LINEAGE_SIZE = 2000;
    private static final int MAX_LINECODE_VALUE_SIZE = 50;
    private static final int MAX_LINETYPE_VALUE_SIZE = 50;
    private static final int MAX_MALE_PARENT_SOURCE_SIZE = 255;
    private static final double MAX_NSORT_VALUE = 200000.00;
    private static final double MIN_NSORT_VALUE = 1.00;
    private static final double MAX_QUANTITY_VALUE = 999999999.99;
    private static final double MIN_QUANTITY_VALUE = 0.0;
    private static final int MAX_OLD_PEDIGREE_SIZE = 3200;
    private static final int MAX_ORIGIN_VALUE_SIZE = 2000;
    private static final int MAX_OWNER_VALUE_SIZE = 3;
    private static final int MAX_VEGETATIVE_STRUCTURE_VALUE_SIZE = 30;
    private static final int MAX_QUANTITY_UOM_VALUE_SIZE = 30;
    private static final int MAX_PEDIGREE_VALUE_SIZE = 3200;
    private static final int MAX_PRODUCTNAME_VALUE_SIZE = 50;
    private static final int MAX_REJECTION_REASON_SIZE = 512;
    private static final int MAX_SOURCE_SIZE = 255;
    private static final int MAX_SRCLOT_VALUE_SIZE = 50;
    private static final int MAX_VALIDATION_MESSAGE_SIZE = 2000;
    private static final int MAX_EVENT_SIZE = 2000;
    private static final int MAX_LINE_FUNCTION_SIZE = 1;
    private static final int MAX_CYTOPLASM_DONOR_PED_SIZE = 3200;
    private static final int MAX_BRAND_NAME_VALUE_SIZE = 50;
    private static final int MAX_CYTOPLASM_DONOR_SOURCE_SIZE = MAX_SOURCE_SIZE;
    private static final int MAX_COMPANY_SIZE = 50;
    private static final int MAX_EXTERNAL_GERMPLASM_NAME = 250;
    private static final int MAX_TRANSGENIC_SIZE = 1;
    private static final int MAX_EXPOSURE_HISTORY_KNOWN_SIZE = 1;
    private static final int MAX_ALLERGENS_PRESENT_SIZE = 1;
    private static final int MAX_TOXINS_PRESENT_SIZE = 1;
    private static final int MAX_ANIMAL_GENE_PRESENT_SIZE = 1;
    private static final int MAX_MINI_CHROMO_C_PRESENT_SIZE = 1;
    private static final int MAX_FROM_MFG_SIZE = 1;
    private static final int MAX_MFG_BATCH_NUMBER = 50;
    private static final int MAX_MFG_ACRONYM_NUMBER = 50;
    private static final int MAX_MFG_MATERIAL_NUMBER = 50;

    private Long id;
    private String productName;
    private String origin;
    private String lineCode;
    private String codedLineCode;
    private String lineType;
    private String oldPedigree;
    private String source;
    private String inventoryOwner;
    private String vegetativeStructure;
    private String femaleParentSource;
    private String maleParentSource;
    private String asort1;
    private String asort2;
    private String asort3;
    private String asort4;
    private String asort5;
    private Double nsort1;
    private Double nsort2;
    private Double nsort3;
    private Double nsort4;
    private Double nsort5;
    private String srcLotNumber;
    private String comments;
    private Date validationDate;
    private String authorityRequested;
    private String rejectionReason;
    private Date approvalProcessDate;
    private StagingInventoryHeader inventoryHeader;
    private ImportStatus importStatus;
    private ImportType importType;
    private String germplasmOwner;
    private String lineage;
    private String buildParentage;
    private String validationMessage;
    private String generation;
    private String pedigreeName;
    private boolean subRecord = false;
    private Date approvalRequestDate;
    private String authorityProcessed;
    private String authorityComments;
    private Set stagingParentage;
    private Date creationDate;
    private String userSpecifiedSource;
    private Set parentalSources = new HashSet();
    private String germplasmOwnerOfFemaleParent;
    private String germplasmOwnerOfMaleParent;
    private String icbMale;
    private String event;
    private String lineFunction;
    private String cytoplasmDonorPedigree;
    private String cytoplasmDonorSource;
    private String brandName;
    private String royalty;
    private String company;
    private String externalGermplasmName;
    private Double seedQuantity;
    private String seedQuantityUOM;
    private String transgenic;
    private String exposureHistoryKnown;
    private String allergensPresent;
    private String toxinsPresent;
    private String animalGenePresent;
    private String miniChromosome;
    private String fromMfg;
    private String mfgBatchNumber;
    private String mfgAcronymNumber;
    private String mfgMaterialNumber;

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        brandName = trimIfNotNull(brandName);
        validateSize(brandName, MAX_BRAND_NAME_VALUE_SIZE, "brandName");
        this.brandName = (null != brandName) ? brandName.toUpperCase() : null;
    }

    public String getBuildParentage() {
        return buildParentage;
    }

    public void setBuildParentage(String buildParentage) {
        this.buildParentage = trimIfNotNull(buildParentage);
    }

    public String getGermplasmOwner() {
        return germplasmOwner;
    }

    public void setGermplasmOwner(String germplasmOwner) {
        germplasmOwner = trimIfNotNull(germplasmOwner);
        validateSize(germplasmOwner, MAX_OWNER_VALUE_SIZE, "germplasmOwner");
        this.germplasmOwner = (null != germplasmOwner) ? germplasmOwner.toUpperCase() : null;
    }

    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        if (lineage != null) {
            lineage = trimIfNotNull(lineage);
            validateSize(lineage, MAX_LINEAGE_SIZE, "lineage");
        }
        this.lineage = lineage;
    }

    public Double getNsort1() {
        return nsort1;
    }

    public void setNsort1(Double nsort1) throws IllegalArgumentException {
        validateNumericalValue(nsort1, MIN_NSORT_VALUE, MAX_NSORT_VALUE, "nsort1");
        this.nsort1 = nsort1;
    }

    public Double getNsort2() {
        return nsort2;
    }

    public void setNsort2(Double nsort2) throws IllegalArgumentException {
        validateNumericalValue(nsort2, MIN_NSORT_VALUE, MAX_NSORT_VALUE, "nsort2");
        this.nsort2 = nsort2;
    }

    public Double getNsort3() {
        return nsort3;
    }

    public void setNsort3(Double nsort3) throws IllegalArgumentException {
        validateNumericalValue(nsort3, MIN_NSORT_VALUE, MAX_NSORT_VALUE, "nsort3");
        this.nsort3 = nsort3;
    }

    public Double getNsort4() {
        return nsort4;
    }

    public void setNsort4(Double nsort4) throws IllegalArgumentException {
        validateNumericalValue(nsort4, MIN_NSORT_VALUE, MAX_NSORT_VALUE, "nsort4");
        this.nsort4 = nsort4;
    }

    public Double getNsort5() {
        return nsort5;
    }

    public void setNsort5(Double nsort5) throws IllegalArgumentException {
        validateNumericalValue(nsort5, MIN_NSORT_VALUE, MAX_NSORT_VALUE, "nsort5");
        this.nsort5 = nsort5;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) throws IllegalArgumentException {
        productName = trimIfNotNull(productName);
        validateSize(productName, MAX_PRODUCTNAME_VALUE_SIZE, "productName");
        this.productName = (null != productName) ? productName.toUpperCase() : null;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) throws IllegalArgumentException {
        origin = trimIfNotNull(origin);
        validateSize(origin, MAX_ORIGIN_VALUE_SIZE, "origin");
        this.origin = (null != origin) ? formatOrigin(origin) : null;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) throws IllegalArgumentException {
        lineCode = trimIfNotNull(lineCode);
        validateSize(lineCode, MAX_LINECODE_VALUE_SIZE, "lineCode");
        this.lineCode =
                (!StringUtils.isNullOrEmpty(lineCode)) ? validateLineCodeSyntax("Line Code", lineCode.toUpperCase()) : null;
    }

    public String getCodedLineCode() {
        return codedLineCode;
    }

    public void setCodedLineCode(String codedLineCode) throws IllegalArgumentException {
        codedLineCode = trimIfNotNull(codedLineCode);
        validateSize(codedLineCode, MAX_LINECODE_VALUE_SIZE, "codedLineCode");
        this.codedLineCode = (!StringUtils.isNullOrEmpty(codedLineCode)) ?
                validateLineCodeSyntax("Coded Line Code", codedLineCode.toUpperCase()) : null;
    }

    private String validateLineCodeSyntax(String fieldName, String lineCode) {
        LineCodeSyntaxVerifier verifier = new LineCodeSyntaxVerifier(lineCode);
        try {
            verifier.validateLineCodeSyntax();
        } catch (LineCodeSyntaxException e) {
            throw new IllegalArgumentException(fieldName + ": " + e.getMessage());
        }
        return lineCode;
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) throws IllegalArgumentException {
        lineType = trimIfNotNull(lineType);
        validateSize(lineType, MAX_LINETYPE_VALUE_SIZE, "lineType");
        this.lineType = lineType;
    }

    public String getOldPedigree() {
        return oldPedigree;
    }

    public void setOldPedigree(String oldPedigree) {
        oldPedigree = trimIfNotNull(oldPedigree);
        validateSize(oldPedigree, MAX_OLD_PEDIGREE_SIZE, "oldPedigree");
        this.oldPedigree = oldPedigree;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        rejectionReason = trimIfNotNull(rejectionReason);
        validateSize(rejectionReason, MAX_REJECTION_REASON_SIZE, "rejectionReason");
        this.rejectionReason = rejectionReason;
    }

    public Date getApprovalProcessDate() {
        return approvalProcessDate;
    }

    public void setApprovalProcessDate(Date approvalProcessDate) {
        this.approvalProcessDate = approvalProcessDate;
    }

    public ImportStatus getImportStatus() {
        return importStatus;
    }

    public void setImportStatus(ImportStatus importStatus) {
        this.importStatus = importStatus;
    }

    public StagingInventoryHeader getInventoryHeader() {
        return inventoryHeader;
    }

    public void setInventoryHeader(StagingInventoryHeader inventoryHeader) {
        this.inventoryHeader = inventoryHeader;
    }

    public String getAuthorityRequested() {
        return authorityRequested;
    }

    public void setAuthorityRequested(String authorityRequested) {
        authorityRequested = trimIfNotNull(authorityRequested);
        validateSize(authorityRequested, MAX_AUTHORITY_REQUESTED_SIZE, "authorityRequested");
        this.authorityRequested = authorityRequested;
    }

    public ImportType getImportType() {
        return importType;
    }

    public void setImportType(ImportType importType) {
        this.importType = importType;
    }

    public Date getValidationDate() {
        return validationDate;
    }

    public void setValidationDate(Date validationDate) {
        this.validationDate = validationDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        source = trimIfNotNull(source);
        validateSize(source, MAX_SOURCE_SIZE, "source");
        validateSourceSyntax(source);
        this.source = source;
    }

    public String getInventoryOwner() {
        return inventoryOwner;
    }

    public void setInventoryOwner(String inventoryOwner) {
        inventoryOwner = trimIfNotNull(inventoryOwner);
        validateSize(inventoryOwner, MAX_OWNER_VALUE_SIZE, "inventoryOwner");
        this.inventoryOwner = (null != inventoryOwner) ? inventoryOwner.toUpperCase() : null;
    }

    public String getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(String vegetativeStructure) {
        vegetativeStructure = trimIfNotNull(vegetativeStructure);
        validateSize(vegetativeStructure, MAX_VEGETATIVE_STRUCTURE_VALUE_SIZE, "vegetativeStructure");
        this.vegetativeStructure = vegetativeStructure;
    }

    public String getFemaleParentSource() {
        return femaleParentSource;
    }

    public void setFemaleParentSource(String femaleParentSource) {
        femaleParentSource = trimIfNotNull(femaleParentSource);
        validateSize(femaleParentSource, MAX_FEMALE_PARENT_SOURCE_SIZE, "femaleParentSource");
        validateSourceSyntax(femaleParentSource);
        this.femaleParentSource = femaleParentSource;
    }

    public String getMaleParentSource() {
        return maleParentSource;
    }

    public void setMaleParentSource(String maleParentSource) {
        maleParentSource = trimIfNotNull(maleParentSource);
        validateSize(maleParentSource, MAX_MALE_PARENT_SOURCE_SIZE, "maleParentSource");
        validateSourceSyntax(maleParentSource);
        this.maleParentSource = maleParentSource;
    }

    public String getAsort1() {
        return asort1;
    }

    public void setAsort1(String asort1) throws IllegalArgumentException {
        asort1 = trimIfNotNull(asort1);
        validateSize(asort1, MAX_ASORT_VALUE_SIZE, "Asort1");
        this.asort1 = asort1;
    }


    public String getAsort2() {
        return asort2;
    }

    public void setAsort2(String asort2) throws IllegalArgumentException {
        asort2 = trimIfNotNull(asort2);
        validateSize(asort2, MAX_ASORT_VALUE_SIZE, "Asort2");
        this.asort2 = asort2;
    }

    public String getAsort3() {
        return asort3;
    }

    public void setAsort3(String asort3) throws IllegalArgumentException {
        asort3 = trimIfNotNull(asort3);
        validateSize(asort3, MAX_ASORT_VALUE_SIZE, "Asort3");
        this.asort3 = asort3;
    }

    public String getAsort4() {
        return asort4;
    }

    public void setAsort4(String asort4) throws IllegalArgumentException {
        asort4 = trimIfNotNull(asort4);
        validateSize(asort4, MAX_ASORT_VALUE_SIZE, "Asort4");
        this.asort4 = asort4;
    }

    public String getAsort5() {
        return asort5;
    }

    public void setAsort5(String asort5) throws IllegalArgumentException {
        asort5 = trimIfNotNull(asort5);
        validateSize(asort5, MAX_ASORT_VALUE_SIZE, "Asort5");
        this.asort5 = asort5;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) throws IllegalArgumentException {
        comments = trimIfNotNull(comments);
        validateSize(comments, MAX_COMMENTS_VALUE_SIZE, "comments");
        this.comments = comments;
    }

    public String getSrcLotNumber() {
        return srcLotNumber;
    }

    public void setSrcLotNumber(String srcLotNumber) throws IllegalArgumentException {
        srcLotNumber = trimIfNotNull(srcLotNumber);
        validateSize(srcLotNumber, MAX_SRCLOT_VALUE_SIZE, "srcLotNumber");
        this.srcLotNumber = srcLotNumber;
    }

    public String getValidationMessage() {
        return validationMessage;
    }

    public void setValidationMessage(String validationMessage) {
        validationMessage = trimIfNotNull(validationMessage);
        validateSize(validationMessage, MAX_VALIDATION_MESSAGE_SIZE, "validationMessage");
        this.validationMessage = validationMessage;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        generation = trimIfNotNull(generation);
        validateSize(generation, MAX_GENERATION_VALUE_SIZE, "generation");
        this.generation = (null != generation) ? generation.toUpperCase() : null;

    }

    public void setPedigreeName(String pedigreeName) {
        pedigreeName = trimIfNotNull(pedigreeName);
        validateSize(pedigreeName, MAX_PEDIGREE_VALUE_SIZE, "pedigreeName");
        this.pedigreeName = pedigreeName;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public String getIcbMale() {
        return icbMale;
    }

    public void setIcbMale(String icbMale) {
        this.icbMale = trimIfNotNull(icbMale);
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        event = trimIfNotNull(event);
        validateSize(event, MAX_EVENT_SIZE, "event");
        this.event = (null != event) ? event.toUpperCase() : null;
    }

    public String getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(String lineFunction) {
        lineFunction = trimIfNotNull(lineFunction);
        validateSize(lineFunction, MAX_LINE_FUNCTION_SIZE, "lineFunction");
        this.lineFunction = (null != lineFunction) ? lineFunction.toUpperCase() : null;
    }

    public String getCytoplasmDonorPedigree() {
        return cytoplasmDonorPedigree;
    }

    public void setCytoplasmDonorPedigree(String cytoplasmDonorPedigree) {
        cytoplasmDonorPedigree = trimIfNotNull(cytoplasmDonorPedigree);
        validateSize(cytoplasmDonorPedigree, MAX_CYTOPLASM_DONOR_PED_SIZE, "cytoplasmDonorPedigree");
        this.cytoplasmDonorPedigree = cytoplasmDonorPedigree;
    }

    public String getCytoplasmDonorSource() {
        return cytoplasmDonorSource;
    }

    public void setCytoplasmDonorSource(String cytoplasmDonorSource) {
        cytoplasmDonorSource = trimIfNotNull(cytoplasmDonorSource);
        validateSize(cytoplasmDonorSource, MAX_CYTOPLASM_DONOR_SOURCE_SIZE, "cytoplasmDonorSource");
        this.cytoplasmDonorSource = cytoplasmDonorSource;
    }

    private void validateSize(String subject, int size, String subjectName) {
        if (!StringUtils.isNullOrEmpty(subject) && (subject.length() > size)) {
            throw new IllegalArgumentException(subjectName + " can only contain at most " + size + " characters.");
        }
    }

    private void validateNumericalValue(Double subject, double minSize, double maxSize, String subjectName) {
        if (subject != null && (subject.doubleValue() < minSize || subject.doubleValue() > maxSize)) {
            throw new IllegalArgumentException(
                    subjectName + " value should be no smaller than " + formatNsortDouble(minSize) +
                            " and no larger than " + formatNsortDouble(maxSize));
        }
    }

    private String formatNsortDouble(Double value) {
        String formattedValue = null;
        if (value != null) {
            NumberFormat formatter = new DecimalFormat("#.00");
            formattedValue = formatter.format(value);
        }
        return formattedValue;
    }

    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }

        if (obj == this) {
            return true;
        }

        final StagingInventory stagingInventory = (StagingInventory) obj;
        if (stagingInventory.getId() == null || this.getId() == null) {
            return false;
        }

        return stagingInventory.getId().longValue() == this.getId().longValue();
    }

    public int hashCode() {
//    int result;
//    result = (int) (id.longValue() ^ (id.longValue() >>> 32)); //TODO: Replace this with a more robust mechanism
        return (id != null) ? id.hashCode() : super.hashCode();
    }

    public void setSubRecord(boolean flag) {
        subRecord = flag;
    }

    public boolean isSubRecord() {
        return subRecord;
    }

    public Date getApprovalRequestDate() {
        return approvalRequestDate;
    }

    public void setApprovalRequestDate(Date approvalRequestDate) {
        this.approvalRequestDate = approvalRequestDate;
    }

    public String getAuthorityProcessed() {
        return authorityProcessed;
    }

    public void setAuthorityProcessed(String authorityProcessed) {
        authorityProcessed = trimIfNotNull(authorityProcessed);
        validateSize(authorityProcessed, MAX_AUTHORITY_PROCESSED_SIZE, "authorityProcessed");
        this.authorityProcessed = authorityProcessed;
    }

    public String getAuthorityComments() {
        return authorityComments;
    }

    public void setAuthorityComments(String authorityComments) {
        authorityComments = trimIfNotNull(authorityComments);
        validateSize(authorityComments, MAX_COMMENTS_VALUE_SIZE, "authorityComments");
        this.authorityComments = authorityComments;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Set getStagingParentage() {
        return stagingParentage;
    }

    public void setStagingParentage(Set stagingParentage) {
        this.stagingParentage = stagingParentage;
    }

    public String getUserSpecifiedSource() {
        return userSpecifiedSource;
    }

    public void setUserSpecifiedSource(String userSpecifiedSource) {
        this.userSpecifiedSource = trimIfNotNull(userSpecifiedSource);
    }

    public Set getParentalSources() {
        return parentalSources;
    }

    public void setParentalSources(Set parentalSources) {
        this.parentalSources = parentalSources;
    }

    public String getGermplasmOwnerOfFemaleParent() {
        return germplasmOwnerOfFemaleParent;
    }

    public void setGermplasmOwnerOfFemaleParent(String germplasmOwnerOfFemaleParent) {
        germplasmOwnerOfFemaleParent = trimIfNotNull(germplasmOwnerOfFemaleParent);
        validateSize(germplasmOwnerOfFemaleParent, MAX_OWNER_VALUE_SIZE, "germplasmOwnerOfFemaleParent");
        this.germplasmOwnerOfFemaleParent = germplasmOwnerOfFemaleParent;
    }

    public String getGermplasmOwnerOfMaleParent() {
        return germplasmOwnerOfMaleParent;
    }

    public void setGermplasmOwnerOfMaleParent(String germplasmOwnerOfMaleParent) {
        germplasmOwnerOfMaleParent = trimIfNotNull(germplasmOwnerOfMaleParent);
        validateSize(germplasmOwnerOfMaleParent, MAX_OWNER_VALUE_SIZE, "germplasmOwnerOfMaleParent");
        this.germplasmOwnerOfMaleParent = germplasmOwnerOfMaleParent;
    }

    public StagingParentage[] getSubRecords() {
        StagingParentage[] parentage = null;
        if (stagingParentage != null) {
            parentage = (StagingParentage[]) stagingParentage.toArray(new StagingParentage[0]);

            Arrays.sort(parentage, new StagingParentageComparator());
        }
        return parentage;
    }

    private String trimIfNotNull(String value) {
        if (value != null) {
            value = value.trim();
        }
        return value;
    }

    private void validateSourceSyntax(String source) {
        SourceSyntaxVerifier verifier = new SourceSyntaxVerifier(source);
        try {
            verifier.verify();
        } catch (InvalidSourceSyntaxException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }


    private String formatOrigin(String origin) {
        if ("".equalsIgnoreCase(origin)) {
            return origin;
        }
        StringBuffer buf = new StringBuffer(origin);
        try {
            String[] components = new OriginSyntaxVerifier(origin).getEntities();
            Map<Integer, Integer> charactersMatched = new HashMap();
            for (int i = 0; i < components.length; i++) {
                String component = components[i];
                int index = getIndexOfComponent(origin, component, charactersMatched);
                if (!insideParentheses(component)) {
                    buf.replace(index, index + component.length(), component.toUpperCase());
                }
                charactersMatched.put(index, index + component.length());
            }
        } catch (InvalidOriginSyntaxException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
        return buf.toString();
    }

    private int getIndexOfComponent(String origin, String component, Map<Integer, Integer> charactersMatched) {
        int index = -1;
        boolean indexAlreadyMatched = true;
        while (indexAlreadyMatched) {
            indexAlreadyMatched = false;
            index = origin.indexOf(component, index + 1);
            for (Map.Entry entry : charactersMatched.entrySet()) {
                if (index >= (Integer) entry.getKey() && index < (Integer) entry.getValue()) {
                    indexAlreadyMatched = true;
                    break;
                }
            }
        }
        return index;
    }

    private boolean insideParentheses(String entityString) {
        if (isStringStartsWith(entityString, "(") && isStringEndsWith(entityString, ")")) {
            return true;
        }
        return false;
    }

    private boolean isStringStartsWith(String string, String comparison) {
        return !StringUtils.isNullOrEmpty(string) && string.trim().startsWith(comparison);
    }

    private boolean isStringEndsWith(String string, String comparison) {
        return !StringUtils.isNullOrEmpty(string) && string.trim().endsWith(comparison);
    }

    public String getRoyalty() {
        return royalty;
    }

    public void setRoyalty(String royalty) {
        this.royalty = trimIfNotNull(royalty);
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) throws IllegalArgumentException {
        company = trimIfNotNull(company);
        validateSize(company, MAX_COMPANY_SIZE, "company");
        this.company = company;
    }

    public String getExternalGermplasmName() {
        return externalGermplasmName;
    }

    public void setExternalGermplasmName(String externalGermplasmName) throws IllegalArgumentException {
        externalGermplasmName = trimIfNotNull(externalGermplasmName);
        validateSize(externalGermplasmName, MAX_EXTERNAL_GERMPLASM_NAME, "external germplasm name");
        this.externalGermplasmName = externalGermplasmName;
    }

    public Double getSeedQuantity() {
        return seedQuantity;
    }

    public void setSeedQuantity(Double seedQuantity) {
        validateNumericalValue(seedQuantity, MIN_QUANTITY_VALUE, MAX_QUANTITY_VALUE, "Seed Quantity");
        this.seedQuantity = seedQuantity;
    }

    public String getSeedQuantityUOM() {
        return seedQuantityUOM;
    }

    public void setSeedQuantityUOM(String quantityUOM) {
        quantityUOM = trimIfNotNull(quantityUOM);
        validateSize(quantityUOM, MAX_QUANTITY_UOM_VALUE_SIZE, "Seed Quantity UOM");
        this.seedQuantityUOM = quantityUOM;
    }

    public String getTransgenic() {
        return transgenic;
    }

    public void setTransgenic(String transgenic) {
        transgenic = trimIfNotNull(transgenic);
        validateSize(transgenic, MAX_TRANSGENIC_SIZE, "Transgenic");
        this.transgenic = (null != transgenic) ? transgenic.toUpperCase() : null;
    }

    public String getExposureHistoryKnown() {
        return exposureHistoryKnown;
    }

    public void setExposureHistoryKnown(String exposureHistoryKnown) {
        exposureHistoryKnown = trimIfNotNull(exposureHistoryKnown);
        validateSize(exposureHistoryKnown, MAX_EXPOSURE_HISTORY_KNOWN_SIZE, "Exposure History Known");
        this.exposureHistoryKnown = (null != exposureHistoryKnown) ? exposureHistoryKnown.toUpperCase() : null;
    }

    public String getAllergensPresent() {
        return allergensPresent;
    }

    public void setAllergensPresent(String allergensPresent) {
        allergensPresent = trimIfNotNull(allergensPresent);
        validateSize(allergensPresent, MAX_ALLERGENS_PRESENT_SIZE, "Allergens Present");
        this.allergensPresent = (null != allergensPresent) ? allergensPresent.toUpperCase() : null;
    }

    public String getToxinsPresent() {
        return toxinsPresent;
    }

    public void setToxinsPresent(String toxinsPresent) {
        toxinsPresent = trimIfNotNull(toxinsPresent);
        validateSize(toxinsPresent, MAX_TOXINS_PRESENT_SIZE, "Toxins Present");
        this.toxinsPresent = (null != toxinsPresent) ? toxinsPresent.toUpperCase() : null;
    }

    public String getAnimalGenePresent() {
        return animalGenePresent;
    }

    public void setAnimalGenePresent(String animalGenePresent) {
        animalGenePresent = trimIfNotNull(animalGenePresent);
        validateSize(animalGenePresent, MAX_ANIMAL_GENE_PRESENT_SIZE, "Animal Gene Present");
        this.animalGenePresent = (null != animalGenePresent) ? animalGenePresent.toUpperCase() : null;
    }

    public String getMiniChromosome() {
        return miniChromosome;
    }

    public void setMiniChromosome(String miniChromosome) {
        miniChromosome = trimIfNotNull(miniChromosome);
        validateSize(miniChromosome, MAX_MINI_CHROMO_C_PRESENT_SIZE, "Contains Mini Chromosome");
        this.miniChromosome = (null != miniChromosome) ? miniChromosome.toUpperCase() : null;
    }

    public String getFromMfg() {
        return fromMfg;
    }

    public void setFromMfg(String fromMfg) {
        fromMfg = trimIfNotNull(fromMfg);
        validateSize(fromMfg, MAX_FROM_MFG_SIZE, "From Mfg.");
        this.fromMfg = (null != fromMfg) ? fromMfg.toUpperCase() : null;
    }

    public String getMfgBatchNumber() {
        return mfgBatchNumber;
    }

    public void setMfgBatchNumber(String mfgBatchNumber) {
        mfgBatchNumber = trimIfNotNull(mfgBatchNumber);
        validateSize(mfgBatchNumber, MAX_MFG_BATCH_NUMBER, "Mfg. Batch Number");
        this.mfgBatchNumber = mfgBatchNumber;
    }

    public String getMfgAcronymNumber() {
        return mfgAcronymNumber;
    }

    public void setMfgAcronymNumber(String mfgAcronymNumber) {
        mfgAcronymNumber = trimIfNotNull(mfgAcronymNumber);
        validateSize(mfgAcronymNumber, MAX_MFG_ACRONYM_NUMBER, "Mfg. Acronym Number");
        this.mfgAcronymNumber = mfgAcronymNumber;
    }

    public String getMfgMaterialNumber() {
        return mfgMaterialNumber;
    }

    public void setMfgMaterialNumber(String mfgMaterialNumber) {
        mfgMaterialNumber = trimIfNotNull(mfgMaterialNumber);
        validateSize(mfgMaterialNumber, MAX_MFG_MATERIAL_NUMBER, "Mfg. Material Number");
        this.mfgMaterialNumber = mfgMaterialNumber;
    }
}