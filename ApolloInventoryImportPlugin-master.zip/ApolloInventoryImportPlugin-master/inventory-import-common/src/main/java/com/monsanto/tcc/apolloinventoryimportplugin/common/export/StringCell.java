/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;

/**
 * Filename:    $RCSfile: StringCell.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-10 20:14:33 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class StringCell implements Cell {
    private HSSFCell cell;

    public StringCell(HSSFCell cell) {
        this.cell = cell;
    }

    public String getValue() {
        return cell.getStringCellValue().trim();
    }
}