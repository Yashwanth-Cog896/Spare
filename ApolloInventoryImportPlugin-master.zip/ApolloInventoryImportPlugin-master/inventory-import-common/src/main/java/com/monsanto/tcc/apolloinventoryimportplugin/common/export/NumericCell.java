/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;

/**
 * Filename:    $RCSfile: NumericCell.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/10 19:56:42 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class NumericCell implements Cell {
    private HSSFCell cell;

    public NumericCell(HSSFCell cell) {
        this.cell = cell;
    }

    public String getValue() {
        return String.valueOf(cell.getNumericCellValue());
    }
}