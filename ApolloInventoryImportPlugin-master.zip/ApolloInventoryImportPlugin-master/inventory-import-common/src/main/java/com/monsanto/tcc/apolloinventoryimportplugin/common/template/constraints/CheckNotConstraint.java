/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Filename:    $RCSfile: CheckNotConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-12 20:22:31 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class CheckNotConstraint implements DataConstraint {
    private String checkVal;
    private String subject = null;
    private String messageToDisplayOnFailure;

    public CheckNotConstraint(String subject, String notCheckVal) {
        if (StringUtils.isNullOrEmpty(notCheckVal) || StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject, checkVal is required.");
        }

        this.subject = subject;
        this.checkVal = notCheckVal;
        messageToDisplayOnFailure = "Value for " + subject + " is invalid";
    }

    public boolean validate(Map dataSource) {
        return !checkVal.equals((String) dataSource.get(subject));
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        this.messageToDisplayOnFailure = messageToDisplayOnFailure;
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}