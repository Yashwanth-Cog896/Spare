package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginBuilder;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginSyntaxVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: May 23, 2008 Time: 6:37:36 AM To change this template use File |
 * Settings | File Templates.
 */
public class F1Determiner {

    public boolean isParentRecordF1(StagingParentage parentage) {
        StagingInventory parent = parentage.getParentInventory();

        if ("F1".equals(parent.getGeneration())) {
            String parentOrigin = parent.getOrigin();
            String mainOrigin = parentage.getMainInventory().getOrigin();
            if (StringUtils.isNullOrEmpty(parentOrigin) && StringUtils.isNullOrEmpty(mainOrigin)) {
                throw new IllegalArgumentException("Either parent origin or main origin is required");
            }
            if ((StringUtils.isNullOrEmpty(parentOrigin) && !StringUtils.isNullOrEmpty(mainOrigin)) ||
                    (!StringUtils.isNullOrEmpty(parentOrigin) && StringUtils.isNullOrEmpty(mainOrigin))) {
                return false;
            }
            String simpleParentOrigin = getSimpleOrigin(parentOrigin);
            String simpleMainOrigin = getSimpleOrigin(mainOrigin);
            if (areOriginComponentsSame(simpleParentOrigin, simpleMainOrigin)) {
                return true;
            }
        } else if ("MSC0".equals(parent.getGeneration()) &&
                LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(parent.getLineFunction())) {
            return true;
        }
        return false;
    }

    private String getSimpleOrigin(String origin) {
        String simpleOrigin = origin;
        try {
            OriginSyntaxVerifier originSyntaxVerifier = new OriginSyntaxVerifier(origin);
            if (originSyntaxVerifier.getDosage() != null && originSyntaxVerifier.getDosage() > 1) {
                OriginBuilder originBuilder = new OriginBuilder(originSyntaxVerifier.getOriginTree());
                simpleOrigin = originBuilder.buildOrigin(1);
            }
        } catch (InvalidOriginSyntaxException e) {
            throw new IllegalArgumentException("Encountered InvalidOriginSyntaxException: " + e.getMessage());
        }
        return simpleOrigin;
    }

    private boolean areOriginComponentsSame(String parentOrigin, String mainOrigin) {
        try {
            String[] parentOriginComponents = new OriginSyntaxVerifier(parentOrigin).getEntities();
            String[] mainOriginComponents = new OriginSyntaxVerifier(mainOrigin).getEntities();
            if (parentOriginComponents.length != mainOriginComponents.length) {
                return false;
            }
            for (int i = 0; i < mainOriginComponents.length; i++) {
                String parentOriginComponent = parentOriginComponents[i];
                String mainOriginComponent = mainOriginComponents[i];
                if (!parentOriginComponent.equalsIgnoreCase(mainOriginComponent)) {
                    return false;
                }
            }
        }
        catch (InvalidOriginSyntaxException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
        return true;
    }

//  private String removeDosageIfExists(String origin) {
//    String simpleOrigin = origin;
//    try {
//      OriginSyntaxVerifier originSyntaxVerifier = new OriginSyntaxVerifier(origin);
//      if (originSyntaxVerifier.getDosage() != null && originSyntaxVerifier.getDosage() > 1) {
//        OriginBuilder originBuilder = new OriginBuilder(originSyntaxVerifier.getOriginTree());
//        simpleOrigin = originBuilder.buildOrigin(1);
//      }
//    } catch (InvalidOriginSyntaxException e) {
//      throw new IllegalArgumentException("Encountered InvalidOriginSyntaxException: " + e.getMessage());
//    }
//    return simpleOrigin;
//  }
}

