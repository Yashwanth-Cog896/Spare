/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineageSyntaxConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidALineMSCLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.parentage.PedigreeConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: ALineLineage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/22 16:29:52 $
 *
 * @author SRKARNA
 * @version $Revision: 1.15 $
 */
public class ALineLineage implements Lineage {
    private static final String LINEAGE_REQ_MSG = "Lineage for an \"A\" Line is required.";
    private static final String INVALID_ALINE_LINEAGE_MSG = "Lineage is not a valid MSC \"A\" Line lineage.";
    private static final String CYCLE_MARKER_PATTERN_STRING = "[" + LineageSyntaxConstants.CYCLE_MARKERS + "]";
    private static final String MSC_ALINE_CHAR = ">";
    private static final String PIPE_STRING = "|";
    protected String aLineLineage = null;

    public ALineLineage(String aLineLineage) throws InvalidALineMSCLineageException {
        if (StringUtils.isNullOrEmpty(aLineLineage)) {
            throw new InvalidALineMSCLineageException(LINEAGE_REQ_MSG);
        }
        this.aLineLineage = aLineLineage.trim();
        validate();
    }

    protected String getLineageWithoutALineSuffix() {
        return aLineLineage.replaceAll(LineageSyntaxConstants.ALINE_SUFFIX_PATTERN_STRING, "");
    }

    private void validate() throws InvalidALineMSCLineageException {
        checkForInvalidCharacters();
        String[] cycleMarkers = getCycleMarkers(aLineLineage);
        if (cycleMarkers == null || cycleMarkers.length == 0) {
            throw new InvalidALineMSCLineageException(INVALID_ALINE_LINEAGE_MSG);
        }
        int indexOfLastCycleMarker = cycleMarkers.length - 1;
        if (indexOfLastCycleMarker < 0 || !cycleMarkers[indexOfLastCycleMarker].equals(MSC_ALINE_CHAR)) {
            throw new InvalidALineMSCLineageException(INVALID_ALINE_LINEAGE_MSG);
        }
    }

    public int getDosage() {
        return !StringUtils.isNullOrEmpty(getLineageWithoutALineSuffix()) ?
                new NotNullLineage(getLineageWithoutALineSuffix()).getDosage() :
                0;
    }

    public int getNumberOfCycleMarkers() {
        return getCycleMarkers().length;
    }

    private String[] getCycleMarkers(String lineage) {
        List cycleMarkerList = new ArrayList();
        Pattern pattern = Pattern.compile(CYCLE_MARKER_PATTERN_STRING);
        Matcher lineageMatcher = pattern.matcher(lineage);
        while (lineageMatcher.find()) {
            cycleMarkerList.add(lineageMatcher.group());
        }

        return (String[]) cycleMarkerList.toArray(new String[0]);
    }

    public String[] getCycleMarkers() {
        return getCycleMarkers(getLineageWithoutALineSuffix());
    }

    public boolean isBackcross() {
        List cycleMarkersList = Arrays.asList(getCycleMarkers());
        return cycleMarkersList.contains(PedigreeConstants.BACKCROSS_SYMBOL);
    }

    public boolean isLineageNullOrPipe() {
        return isLineageNullOrEmpty() || isLineagePipe();
    }

    public boolean isLineageNullOrEmpty() {
        return StringUtils.isNullOrEmpty(aLineLineage);
    }

    public boolean isLineagePipe() {
        return getLineageWithoutALineSuffix().equals(PIPE_STRING);
    }

    private void checkForInvalidCharacters() throws InvalidALineMSCLineageException {
        if (!StringUtils.isNullOrEmpty(aLineLineage)) {
            try {
                new LineageSyntaxChecker(aLineLineage).validateLineageHasValidCharacters();
            } catch (LineageSyntaxException e) {
                throw new InvalidALineMSCLineageException(e);
            }
        }
    }
}