/*
 AppInfoConstants was created on Apr 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: AppInfoConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:$Date:
 * 2007/07/26 14:47:54 $
 *
 * @author SRKARNA
 * @version $Revision: 1.154 $
 */
public class AppInfoConstants {
    public static final String APPLICATION_NAME = "Inventory Import"; // Same as InventoryImportPOSController.INVENTORY_IMPORT

    public static final String VERSION = "7.01.20";

    public static final int DEFAULT_TRANSACTION_SIZE = 5;
}
