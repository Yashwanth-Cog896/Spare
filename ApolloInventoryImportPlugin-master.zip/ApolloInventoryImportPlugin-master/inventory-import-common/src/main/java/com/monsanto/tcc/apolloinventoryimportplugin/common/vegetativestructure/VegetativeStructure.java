package com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Feb 25, 2009
 * Time: 1:26:49 PM
 */
public class VegetativeStructure {

    private Long vegetativeStructureId;
    private String name;
    private String refCode;
    private String refActive;


    public Long getVegetativeStructureId() {
        return vegetativeStructureId;
    }

    public void setVegetativeStructureId(Long vegetativeStructureId) {
        this.vegetativeStructureId = vegetativeStructureId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefCode() {
        return refCode;
    }

    public void setRefCode(String refCode) {
        this.refCode = refCode;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}
