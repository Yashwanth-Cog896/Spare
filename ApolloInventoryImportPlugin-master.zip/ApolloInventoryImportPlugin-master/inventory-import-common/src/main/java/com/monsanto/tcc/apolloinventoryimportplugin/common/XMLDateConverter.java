/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: XMLDateConverter.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $ On:$Date:
 * 2007/10/08 19:46:36 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class XMLDateConverter implements Converter {
    private static final Log logger = LogFactory.getLog(XMLDateConverter.class);
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss'-05:00'");

    public boolean canConvert(Class clazz) {
        //return (clazz.isInstance(new Date()));
        return (clazz.isInstance(new Date()) || clazz.isInstance(new Timestamp(98724573287540L)));
    }

    public void marshal(Object value, HierarchicalStreamWriter writer, MarshallingContext context) {
        Date date = (Date) value;
        writer.setValue(simpleDateFormat.format(date));
    }

    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
        Date date = null;
        try {
            date = simpleDateFormat.parse(reader.getValue());
        } catch (ParseException e) {
            logger.error("An error occurred: " + e);
        }
        return date;
    }
}