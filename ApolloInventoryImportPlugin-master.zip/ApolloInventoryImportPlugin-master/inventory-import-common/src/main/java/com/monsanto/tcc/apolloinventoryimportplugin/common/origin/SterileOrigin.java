/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginForSterileLineFunction;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: SterileOrigin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date:
 * 2007/10/24 21:50:52 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class SterileOrigin extends Origin {
    public static final String INVALID_ORIGIN_MSG = "Invalid origin for S Line Function";
    List maleEnityList = new ArrayList();

    public SterileOrigin(String originString) throws InvalidOriginSyntaxException, InvalidOriginForSterileLineFunction {
        super(originString);
        buildMaleEntityList(getOriginTree());
        checkOrigin();
    }

    private void checkOrigin() throws InvalidOriginSyntaxException, InvalidOriginForSterileLineFunction {
        verifyAllMaleParentsAreLoneEntities();
    }

    private void verifyAllMaleParentsAreLoneEntities() throws InvalidOriginSyntaxException,
            InvalidOriginForSterileLineFunction {
        if (maleEnityList == null || maleEnityList.size() == 0) {
            throw new InvalidOriginForSterileLineFunction(INVALID_ORIGIN_MSG);
        }
        for (int i = 0; i < maleEnityList.size(); i++) {
            OriginEntity maleOriginEntity = (OriginEntity) maleEnityList.get(i);
            if (maleOriginEntity == null || !StringUtils.isNullOrEmpty(maleOriginEntity.getOperator())) {
                throw new InvalidOriginForSterileLineFunction(INVALID_ORIGIN_MSG);
            }
        }
    }

    private void buildMaleEntityList(OriginEntity currentEntity) throws InvalidOriginSyntaxException {
        if (currentEntity != null) {
            if ("M".equalsIgnoreCase(currentEntity.getParentalRole())) {
                maleEnityList.add(currentEntity);
            }
            buildMaleEntityList(currentEntity.getFemaleParent());
            buildMaleEntityList(currentEntity.getMaleParent());
        }

    }
}