/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.services.domain.common.filter.BinaryExpression;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.services.domain.common.filter.operator.OperatorDirectory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.FilterConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.filters.CropFilter;
import com.monsanto.tcc.apolloinventoryimportplugin.common.filters.MaterialTypeFilter;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventoryEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    $RCSfile: GetStagingInventoryPOSClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-01 19:23:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class GetStagingInventoryPOSClient extends AbstractPOSClient {
    private static final String POS_ACTIVITY = "GetStagingInventory";

    public GetStagingInventoryPOSClient() {
        super.setPosActivityName(POS_ACTIVITY);
    }

    public StagingInventoryEntity[] getStagingInventories(String cropName, String materialType,
                                                          String[] statusCode) throws ActivityClientException {
        sendToPos(createCompositeObject(cropName, materialType, statusCode));
        return getStagingInventories();
    }

    private StagingInventoryEntity[] getStagingInventories() {
        List<StagingInventoryEntity> list = (List<StagingInventoryEntity>) getResponseEnvelope().get(StagingInventoryEntity.class);

        return (list != null && list.size() > 0) ? (StagingInventoryEntity[]) list.toArray(new StagingInventoryEntity[list.size()]) :
                null;
    }

    private CompositeObject createCompositeObject(String cropName, String materialType, String[] statusCode) {
        CompositeObject compositeObject = new CompositeObject();
        Filter filter = new Filter();

        List<String> values = new ArrayList<String>();
        values.addAll(Arrays.asList(statusCode));

        filter.addExpression(new BinaryExpression(OperatorDirectory.IN_OPERATOR.getRefId(),
                FilterConstants.STATUS_CODE_OPERAND, values));

        new CropFilter(cropName).collectCropFilter(filter);
        new MaterialTypeFilter(materialType).collectMaterialFilter(filter);
        compositeObject.add(filter);
        CompositeObject payload = new CompositeObject();

        payload.add(filter);
        return payload;
    }
}