/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.common.F1Determiner;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;

import java.util.*;

/**
 * Filename:    $RCSfile: StagingInventoryParentage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:$Date: 2009-07-09 19:48:29 $
 *
 * @author apatro
 * @version $Revision: 1.13 $
 */
public class StagingInventoryParentage {
    private Set stagingParentageSet;
    public static final String REQUIRED_MSG = "stagingParentageSet is required";

    public StagingInventoryParentage(Set stagingParentageSet) {
        if (null == stagingParentageSet) {
            throw new IllegalArgumentException(REQUIRED_MSG);
        }
        this.stagingParentageSet = stagingParentageSet;
    }

    public StagingInventory[] getDirectParents(StagingInventory stagingInventory) {
        List directParentsList = new ArrayList();
        Iterator iterator = stagingParentageSet.iterator();
        while (iterator.hasNext()) {
            StagingParentage parentage = (StagingParentage) iterator.next();
            if (parentage.getChildInventory().equals(stagingInventory)) {
                directParentsList.add(parentage.getParentInventory());
            }
        }
        return (directParentsList.size() > 0) ? (StagingInventory[]) directParentsList.toArray(new StagingInventory[0]) :
                null;
    }

    public StagingInventory[] getDirectSeedParents(StagingInventory stagingInventory) {
        List directParentsList = new ArrayList();
        Iterator iterator = stagingParentageSet.iterator();
        while (iterator.hasNext()) {
            StagingParentage parentage = (StagingParentage) iterator.next();
            if (parentage.getChildInventory().equals(stagingInventory)) {
                directParentsList.add(parentage.getParentInventory());
            }
        }
        List<StagingInventory> seedParents = getSeedParents(directParentsList);
        return (seedParents.size() > 0) ? seedParents.toArray(new StagingInventory[0]) :
                null;
    }

    private List<StagingInventory> getSeedParents(List directParentsList) {
        List<StagingInventory> seedStagingInventories = new ArrayList<StagingInventory>();
        for (Iterator iterator = directParentsList.iterator(); iterator.hasNext();) {
            StagingInventory stagingInventory = (StagingInventory) iterator.next();
            if (!"Seed".equalsIgnoreCase(stagingInventory.getVegetativeStructure())) {
                StagingInventory[] parents = getDirectParents(stagingInventory);
                if (parents != null && parents.length > 0) {
                    for (StagingInventory parent : parents) {
                        seedStagingInventories.add(parent);
                    }
                }
            } else {
                seedStagingInventories.add(stagingInventory);
            }
        }
        return seedStagingInventories;
    }

    public Set getDirectParentsSet(StagingInventory stagingInventory) {
        Set directParentsSet = new HashSet();
        Iterator iterator = stagingParentageSet.iterator();
        while (iterator.hasNext()) {
            StagingParentage parentage = (StagingParentage) iterator.next();
            if (parentage.getChildInventory().equals(stagingInventory)) {
                directParentsSet.add(parentage);
            }
        }
        return (directParentsSet.size() > 0) ? directParentsSet : null;
    }

    public String getParentalRole(StagingInventory stagingInventory) {
        String parentalRole = null;
        Iterator iterator = stagingParentageSet.iterator();
        while (iterator.hasNext()) {
            StagingParentage parentage = (StagingParentage) iterator.next();
            if (parentage.getParentInventory().equals(stagingInventory)) {
                parentalRole = parentage.getParentalRole();
                break;
            }
        }
        return parentalRole;
    }

    public StagingInventory getF1SegpopRecord() {
        return getFirstRecordMatchingGeneration("F1");
    }

    public StagingInventory getMSC0SegpopRecord() {
        return getFirstRecordMatchingGeneration("MSC0");
    }

    private StagingInventory getFirstRecordMatchingGeneration(String generation) {
        StagingInventory f1SegpopStagingInventory = null;

        for (Iterator iter = stagingParentageSet.iterator(); iter.hasNext();) {
            StagingParentage parentage = (StagingParentage) iter.next();
            StagingInventory parent = parentage.getParentInventory();
            if (generation.equals(parent.getGeneration())) {
                f1SegpopStagingInventory = parent;
                break;
            }
        }
        return f1SegpopStagingInventory;
    }

    public List<StagingInventory> getF1SegpopRecordsWithParentage() {
        List<StagingInventory> f1SegpopStagingInventories = new ArrayList<StagingInventory>();
        Set f1SegpopParentage = null;

        for (Iterator iter = stagingParentageSet.iterator(); iter.hasNext();) {
            StagingParentage parentage = (StagingParentage) iter.next();
            StagingInventory parent = parentage.getParentInventory();
            if (isF1Segpop(parent)) {
                f1SegpopParentage = getF1SegpopParentage(parentage.getRecordLevel());
                parent.setStagingParentage(f1SegpopParentage);
                f1SegpopStagingInventories.add(parent);
            }
        }
        return f1SegpopStagingInventories;
    }

    public StagingInventory getMSC0SegpopRecordWithParentage() {
        return getFirstRecordMatchingGenerationWithParentage("MSC0");
    }


    private StagingInventory getFirstRecordMatchingGenerationWithParentage(String generation) {
        StagingInventory f1SegpopStagingInventory = null;
        Set f1SegpopParentage = null;

        for (Iterator iter = stagingParentageSet.iterator(); iter.hasNext();) {
            StagingParentage parentage = (StagingParentage) iter.next();
            StagingInventory parent = parentage.getParentInventory();
            if (generation.equals(parent.getGeneration())) {
                f1SegpopParentage = getF1SegpopParentage(parentage.getRecordLevel());
                f1SegpopStagingInventory = parent;
                break;
            }
        }

        if (null != f1SegpopStagingInventory) {
            f1SegpopStagingInventory.setStagingParentage(f1SegpopParentage);
        }

        return f1SegpopStagingInventory;
    }

    // todo: what is the side effect of modifying this?

    private Set getF1SegpopParentage(Long recordLevel) {
        Set f1SegpopParentage = new HashSet();
        for (Iterator iter = stagingParentageSet.iterator(); iter.hasNext();) {
            StagingParentage parentage = (StagingParentage) iter.next();
            if (parentage.getRecordLevel().compareTo(recordLevel) > 0) {
                f1SegpopParentage.add(parentage);
            }
        }

        return ((0 == f1SegpopParentage.size()) ? null : f1SegpopParentage);
    }

    private boolean isF1Segpop(StagingInventory stagingInventory) {
        return MaterialTypeConstants.SEGPOP_LINES.equalsIgnoreCase(stagingInventory.getLineType()) &&
                "F1".equalsIgnoreCase(stagingInventory.getGeneration());
    }

    public List<StagingInventory> getF1RecordsWithParentage() {
        List<StagingInventory> f1StagingInventories = new ArrayList<StagingInventory>();
        Set f1Parentage = null;

        for (Iterator iter = stagingParentageSet.iterator(); iter.hasNext();) {
            StagingParentage parentage = (StagingParentage) iter.next();
            if (new F1Determiner().isParentRecordF1(parentage)) {
                f1Parentage = getF1SegpopParentage(parentage.getRecordLevel());
                StagingInventory parent = parentage.getParentInventory();
                parent.setStagingParentage(f1Parentage);
                f1StagingInventories.add(parent);
            }
        }

        return f1StagingInventories;
    }

    public StagingInventory getDefaultVegetativeStructureF1RecordWithParentage() {
        StagingInventory f1StagingInventory = null;
        Set f1Parentage = null;

        for (Iterator iter = stagingParentageSet.iterator(); iter.hasNext();) {
            StagingParentage parentage = (StagingParentage) iter.next();
            if (new F1Determiner().isParentRecordF1(parentage) && isDefaultVegetativeStructureParent(parentage)) {
                f1Parentage = getF1SegpopParentage(parentage.getRecordLevel());
                StagingInventory parent = parentage.getParentInventory();
                parent.setStagingParentage(f1Parentage);
                f1StagingInventory = parent;
            }
        }

        return f1StagingInventory;
    }

    private boolean isDefaultVegetativeStructureParent(StagingParentage parentage) {
        return "Seed".equalsIgnoreCase(parentage.getParentInventory().getVegetativeStructure());
    }
}