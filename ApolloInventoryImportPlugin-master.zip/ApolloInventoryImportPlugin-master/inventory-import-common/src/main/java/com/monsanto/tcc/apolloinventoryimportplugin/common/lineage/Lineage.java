/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

/**
 * Filename:    $RCSfile: Lineage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/22 16:29:52 $
 *
 * @author ddbrow5
 * @version $Revision: 1.9 $
 */
public interface Lineage {

    int getDosage();

    int getNumberOfCycleMarkers();

    boolean isBackcross();

    boolean isLineageNullOrPipe();

    boolean isLineageNullOrEmpty();

    boolean isLineagePipe();

    public String[] getCycleMarkers();
}