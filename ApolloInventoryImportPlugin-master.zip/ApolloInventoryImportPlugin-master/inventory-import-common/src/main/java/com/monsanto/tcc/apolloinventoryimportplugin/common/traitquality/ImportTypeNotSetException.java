package com.monsanto.tcc.apolloinventoryimportplugin.common.traitquality;

/**
 * Created by IntelliJ IDEA.
 * User: MTJOHN1
 * Date: 2/17/12
 * Time: 4:23 PM
 */
public class ImportTypeNotSetException extends Exception {
    public ImportTypeNotSetException(String msg) {
        super(msg);
    }
}
