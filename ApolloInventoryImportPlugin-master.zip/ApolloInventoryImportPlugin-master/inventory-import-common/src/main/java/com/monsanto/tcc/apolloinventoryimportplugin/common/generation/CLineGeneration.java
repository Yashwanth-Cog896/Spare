/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: CLineGeneration.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-04 21:30:52 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class CLineGeneration implements Generation {
    private Generation generation;
    private String generationString;
    private static final String BC_GENERATION_PATTERN_STRING = "^BC(\\d+)$";
    private static final String VALID_GENERATION_MSG = "C line generation can be one of: null, BCn, MSC0, or INBRED";

    public CLineGeneration(String generationString) throws InvalidCLineGenerationException {
        if (StringUtils.isNullOrEmpty(generationString)) {
            generation = new NullGeneration();
            this.generationString = "";
        } else {
            generation = new NonNullGeneration(generationString);
            this.generationString = generationString;
        }
        validate();
    }

    private void validate() throws InvalidCLineGenerationException {
        if (!isMSC0() && !isBackcross() && !isNull() && !isInbred()) {
            throw new InvalidCLineGenerationException(VALID_GENERATION_MSG);
        }
    }

    public boolean isMSC() {
        return generation.isMSC();
    }

    public boolean isMSC0() {
        return generation.isMSC0();
    }

    public boolean isBackcross() {
        return isCLineBackcross();
    }

    public boolean isNull() {
        return generation.isNull();
    }

    public boolean isInbred() {
        return generation.isInbred();
    }

    public int getGeneration() {
        return generation.getGeneration();
    }

    private boolean isCLineBackcross() {
        return createMatcher().matches();
    }

    private Pattern createPattern() {
        return Pattern.compile(BC_GENERATION_PATTERN_STRING);
    }

    private Matcher createMatcher() {
        return createPattern().matcher(generationString);
    }
}