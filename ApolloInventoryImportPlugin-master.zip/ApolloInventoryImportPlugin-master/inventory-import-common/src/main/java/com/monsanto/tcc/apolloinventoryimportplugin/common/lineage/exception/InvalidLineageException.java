/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception;

/**
 * Filename:    $RCSfile: InvalidLineageException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-11-14 20:22:28 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class InvalidLineageException extends Exception {
    public InvalidLineageException() {
    }

    public InvalidLineageException(String message) {
        super(message);
    }

    public InvalidLineageException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidLineageException(Throwable cause) {
        super(cause);
    }
}