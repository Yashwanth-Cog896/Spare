/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

/**
 * Filename:    $RCSfile: InvalidDosageNumberException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-03-27 16:41:25 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class InvalidDosageNumberException extends Exception {
    public InvalidDosageNumberException(String msg) {
        super(msg);
    }
}