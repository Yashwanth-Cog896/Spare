/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree.MSCPedigreeSyntaxValidation;
import com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree.PedigreeSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.BuildParentageFlagEvaluator;

import java.util.List;

/**
 * Filename:    $RCSfile: ALineFunctionCytoplasmCheckForNonProductLines.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: ssnall $ On:$Date: 2009-06-05 14:08:03 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class ALineFunctionCytoplasmCheckForNonProductLines {
    private String cytoplasmPedigree;
    private String cytoplasmSource;
    private String buildParentage;
    public static final String CYTOPLASM_DONOR_PEDIGREE_OR_SOURCE = "Cytoplasm Donor Pedigree Or Source";
    public static final String CYTOPLASM_DONOR_PEDIGREE = "Cytoplasm Donor Pedigree";
    public static final String PEDIGREE_REQ_MSG = "Cytoplasm Donor Pedigree Or Source";


    public ALineFunctionCytoplasmCheckForNonProductLines(String cytoplasmPedigree, String cytoplasmSource,
                                                         String buildParentage) {
        this.cytoplasmPedigree = cytoplasmPedigree;
        this.cytoplasmSource = cytoplasmSource;
        this.buildParentage = buildParentage;
    }

    public void check(List msgList) {
        if (isBuildParentageFlagRequested(buildParentage)) {
            if (StringUtils.isNullOrEmpty(cytoplasmPedigree) || StringUtils.isNullOrEmpty(cytoplasmSource)) {
                msgList.add(AbstractStagingInventorySanityChecker.MANDATORY_CHECK_MSG + CYTOPLASM_DONOR_PEDIGREE_OR_SOURCE +
                        " (both required when build parentage is \"Y\")");
            }
        } else if (StringUtils.isNullOrEmpty(cytoplasmPedigree)) {
            msgList.add(AbstractStagingInventorySanityChecker.MANDATORY_CHECK_MSG + CYTOPLASM_DONOR_PEDIGREE +
                    " (required when build parentage is \"N\")");
        } else {
            try {
                new MSCPedigreeSyntaxValidation(cytoplasmPedigree);
            } catch (IllegalArgumentException e) {
                msgList.add(e.getMessage() + " (cytoplasm donor pedigree)");
            } catch (PedigreeSyntaxException e) {
                msgList.add(e.getMessage() + " (cytoplasm donor pedigree)");
            }
        }
    }

    private boolean isBuildParentageFlagRequested(String buildParentageFlag) {
        return getConvertedBuildParentageValue(buildParentageFlag).equals(BuildParentageFlagEvaluator.BUILD_PARENTAGE_YES);
    }

    private String getConvertedBuildParentageValue(String buildParentageFlag) {
        return new BuildParentageFlagEvaluator(buildParentageFlag).getValue();
    }
}