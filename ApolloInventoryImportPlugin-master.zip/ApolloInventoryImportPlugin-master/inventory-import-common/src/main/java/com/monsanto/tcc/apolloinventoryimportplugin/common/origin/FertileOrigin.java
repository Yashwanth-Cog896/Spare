/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: FertileOrigin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/24 21:51:32 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class FertileOrigin extends Origin {
    public static final String INVALID_ORIGIN_MSG = "Invalid origin for F Line Function";

    public FertileOrigin(String originString) throws InvalidOriginSyntaxException {
        super(originString);
        if (isMaleEntityCLine()) {
            throw new InvalidOriginSyntaxException(INVALID_ORIGIN_MSG);
        }
        if (isMaleEntityLone() || isFemaleEntityLone()) {
            if (isMaleEntityLone() && !isFemaleEntityLone() && isFemaleEntityCLine()) {
                throw new InvalidOriginSyntaxException(INVALID_ORIGIN_MSG);
            } else if (!isMaleEntityLone() && isFemaleEntityLone() && !isFemaleEntityCLine()) {
                throw new InvalidOriginSyntaxException(INVALID_ORIGIN_MSG);
            }
        } else {
            throw new InvalidOriginSyntaxException(INVALID_ORIGIN_MSG);
        }
    }

    private boolean isFemaleEntityLone() {
        return isEntityLone(getOriginTree().getFemaleParent());
    }

    private boolean isMaleEntityLone() {
        return isEntityLone(getOriginTree().getMaleParent());
    }

    private boolean isFemaleEntityCLine() {
        return isOriginStringCLine(getOriginTree().getFemaleParent().getOrigin());
    }

    private boolean isMaleEntityCLine() {
        return isOriginStringCLine(getOriginTree().getMaleParent().getOrigin());
    }

    private boolean isEntityLone(OriginEntity originEntity) {
        if (originEntity == null || !StringUtils.isNullOrEmpty(originEntity.getOperator())) {
            return false;
        }
        return true;
    }

    private boolean isOriginStringCLine(String originString) {
        return !StringUtils.isNullOrEmpty(originString) && originString.indexOf("\\") >= 0;
    }
}