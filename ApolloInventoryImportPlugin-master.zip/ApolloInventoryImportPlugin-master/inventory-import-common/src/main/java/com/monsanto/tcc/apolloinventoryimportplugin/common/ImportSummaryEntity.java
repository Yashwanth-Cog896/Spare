/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.services.domain.common.Entity;

/**
 * Filename:    $RCSfile: ImportSummaryEntity.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2008-04-15 21:53:42 $
 *
 * @author skumar5
 * @version $Revision: 1.5 $
 */
public class ImportSummaryEntity implements Entity {
    private String materialTypeDescription;
    private int totalImportedRowCount;
    private int successfullyImportedRowCount;
    private int failedToImportRowCount;
    private int blankRowsCount;
    private String cropName;

    public String getMaterialTypeDescription() {
        return materialTypeDescription;
    }

    public void setMaterialTypeDescription(String materialTypeDescription) {
        this.materialTypeDescription = materialTypeDescription;
    }

    public int getTotalImportedRowCount() {
        return totalImportedRowCount;
    }

    public void setTotalImportedRowCount(int totalImportedRowCount) {
        this.totalImportedRowCount = totalImportedRowCount;
    }

    public int getSuccessfullyImportedRowCount() {
        return successfullyImportedRowCount;
    }

    public void setSuccessfullyImportedRowCount(int successfullyImportedRowCount) {
        this.successfullyImportedRowCount = successfullyImportedRowCount;
    }

    public int getFailedToImportRowCount() {
        return failedToImportRowCount;
    }

    public void setFailedToImportRowCount(int failedToImportRowCount) {
        this.failedToImportRowCount = failedToImportRowCount;
    }

    public int getBlankRowsCount() {
        return blankRowsCount;
    }

    public void setBlankRowsCount(int blankRowsCount) {
        this.blankRowsCount = blankRowsCount;
    }

    public Object getID() {
        return getMaterialTypeDescription();
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public void reset() {
        setCropName(null);
        setMaterialTypeDescription(null);
        setBlankRowsCount(0);
        setFailedToImportRowCount(0);
        setSuccessfullyImportedRowCount(0);
        setTotalImportedRowCount(0);
    }
}