/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginForSterileLineFunction;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: OriginFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/24 21:49:35 $
 *
 * @author SSPEYY
 * @version $Revision: 1.6 $
 */
public class OriginFactory {

    public static final String INVALID_LINE_FUNCTION_MSG = "Invalid line function - ";

    public Origin createOrigin(String lineType, String lineFunction, String originString) throws
            InvalidOriginSyntaxException,
            InvalidOriginForSterileLineFunction {
        Origin originType;

        if (StringUtils.isNullOrEmpty(originString)) {
            originType = new NullOrigin();
        } else if (StringUtils.isNullOrEmpty(lineFunction)) {
            originType = new Origin(originString);
        } else if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType)) {
            if (LineFunctionConstants.S_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
                originType = new SterileOrigin(originString);
            } else if (LineFunctionConstants.F_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
                originType = new FertileOrigin(originString);
            } else {
                throw new IllegalArgumentException(INVALID_LINE_FUNCTION_MSG + lineFunction);
            }
        } else if (LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
            originType = new ALineOrigin(originString);
        } else {
            originType = new Origin(originString);
        }

//    if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType) && StringUtils.isNullOrEmpty(lineFunction)) {
//      originType = new Origin(originString);
//    } else if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType) &&
//        LineFunctionConstants.S_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
//      originType = new SterileOrigin(originString);
//    } else if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType) &&
//        LineFunctionConstants.F_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
//      originType = new FertileOrigin(originString);
//    } else
//    if (!MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType) && !StringUtils.isNullOrEmpty(lineFunction) &&
//        lineFunction.equalsIgnoreCase(LineFunctionConstants.A_LINE_FUNCTION)) {
//      originType = new ALineOrigin(originString);
//    } else {
//      throw new IllegalArgumentException(INVALID_LINE_FUNCTION_MSG + lineFunction);
//    }
        return originType;
    }

    public Origin createOrigin(String originString) throws InvalidOriginSyntaxException {
        Origin originType;
        if (isBackcross(originString)) {
            originType = new BackcrossOrigin(originString);
        } else {
            originType = new Origin(originString);
        }
        return originType;
    }

    private boolean isBackcross(String originString) throws InvalidOriginSyntaxException {
        OriginSyntaxVerifier verifier = new OriginSyntaxVerifier(originString);
        return (verifier.getDosage() != null && verifier.getDosage().intValue() > 0);
    }
}