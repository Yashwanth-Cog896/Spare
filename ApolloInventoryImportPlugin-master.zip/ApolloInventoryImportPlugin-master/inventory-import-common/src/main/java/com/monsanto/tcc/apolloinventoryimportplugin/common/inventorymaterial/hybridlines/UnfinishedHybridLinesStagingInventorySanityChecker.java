/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.hybridlines;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;

/**
 * Filename:    $RCSfile: UnfinishedHybridLinesStagingInventorySanityChecker.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2007-05-16 21:46:01 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class UnfinishedHybridLinesStagingInventorySanityChecker extends HybridLinesStagingInventorySanityChecker {
    public UnfinishedHybridLinesStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);
    }

    protected void performMaterialSpecificChecks(List msgList) {
        super.performMaterialSpecificChecks(msgList);
        if (StringUtils.isNullOrEmpty(stagingInventory.getFemaleParentSource())) {
            msgList.add(MANDATORY_CHECK_MSG + "Source of Female Parent");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getGermplasmOwnerOfFemaleParent())) {
            msgList.add(MANDATORY_CHECK_MSG + "Germplasm Owner of Female Parent");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getMaleParentSource())) {
            msgList.add(MANDATORY_CHECK_MSG + "Source of Male Parent");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getGermplasmOwnerOfMaleParent())) {
            msgList.add(MANDATORY_CHECK_MSG + "Germplasm Owner of Male Parent");
        }
    }

}