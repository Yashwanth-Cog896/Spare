package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: May 6, 2010
 * Time: 8:37:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class VegetativeStructureConstants {
    public static final String VEGETATIVE_STRUCTURE_SEED = "Seed";
    public static final String VEGETATIVE_STRUCTURE_SEEDCANE = "Seed Cane";
}
