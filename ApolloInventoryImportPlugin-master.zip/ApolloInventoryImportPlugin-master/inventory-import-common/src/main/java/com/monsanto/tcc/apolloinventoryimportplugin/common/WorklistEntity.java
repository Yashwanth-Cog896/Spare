/*
 WorklistEntity was created on Feb 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.services.domain.common.Entity;

/**
 * Filename:    $RCSfile: WorklistEntity.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2008-04-15 20:03:53 $
 *
 * @author SRKARNA
 * @version $Revision: 1.6 $
 */
public class WorklistEntity implements Entity {
    private String cropName;
    private String materialTypeDescription;
    private int waitingToBeProcessedCount;
    private int eligibleToSendToAuthorityCount;
    private int waitingToBeApprovedCount;
    private int toBeApprovedCount;
    private int approvedCount;
    private int rejectedCount;

    public String getMaterialTypeDescription() {
        return materialTypeDescription;
    }

    public void setMaterialTypeDescription(String materialTypeDescription) {
        this.materialTypeDescription = materialTypeDescription;
    }

    public int getWaitingToBeProcessedCount() {
        return waitingToBeProcessedCount;
    }

    public void setWaitingToBeProcessedCount(int waitingToBeProcessedCount) {
        this.waitingToBeProcessedCount = waitingToBeProcessedCount;
    }

    public int getEligibleToSendToAuthorityCount() {
        return eligibleToSendToAuthorityCount;
    }

    public void setEligibleToSendToAuthorityCount(int eligibleToSendToAuthorityCount) {
        this.eligibleToSendToAuthorityCount = eligibleToSendToAuthorityCount;
    }

    public int getWaitingToBeApprovedCount() {
        return waitingToBeApprovedCount;
    }

    public void setWaitingToBeApprovedCount(int waitingToBeApprovedCount) {
        this.waitingToBeApprovedCount = waitingToBeApprovedCount;
    }

    public int getRejectedCount() {
        return rejectedCount;
    }

    public void setRejectedCount(int rejectedCount) {
        this.rejectedCount = rejectedCount;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public Object getID() {
        return getCropName();
    }

    public int getApprovedCount() {
        return approvedCount;
    }

    public void setApprovedCount(int approvedCount) {
        this.approvedCount = approvedCount;
    }

    public int getToBeApprovedCount() {
        return toBeApprovedCount;
    }

    public void setToBeApprovedCount(int toBeApprovedCount) {
        this.toBeApprovedCount = toBeApprovedCount;
    }

    public int getTotalOfAllCounts() {
        return approvedCount + eligibleToSendToAuthorityCount + rejectedCount + toBeApprovedCount +
                waitingToBeApprovedCount + waitingToBeProcessedCount;
    }
}