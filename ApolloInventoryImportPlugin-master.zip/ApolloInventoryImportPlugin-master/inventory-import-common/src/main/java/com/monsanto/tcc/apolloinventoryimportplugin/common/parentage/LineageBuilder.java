/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.parentage;

import java.util.List;

/**
 * Filename:    $RCSfile: LineageBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date:
 * 2007/02/01 12:14:09 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.1 $
 */
public interface LineageBuilder {
    List BuildLineage(String lineage);
}