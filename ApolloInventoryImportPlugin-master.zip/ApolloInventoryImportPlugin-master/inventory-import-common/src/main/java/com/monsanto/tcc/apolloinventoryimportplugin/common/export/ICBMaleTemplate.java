/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions.RowDefinition;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions.RowDefinitionFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions.RowMetaData;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: ICBMaleTemplate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-07-09 19:36:08 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class ICBMaleTemplate extends AbstractTemplate {
    public ICBMaleTemplate(HSSFWorkbook workBook, HSSFSheet workSheet) {
        if (null == workBook) {
            throw new IllegalArgumentException("Work book cannot be null");
        }
        if (null == workSheet) {
            throw new IllegalArgumentException("Work sheet cannot be null");
        }
        this.workBook = workBook;
        this.workSheet = workSheet;
        createWorkSheetMetaData();
        numberOfColumns = workSheetMetaData.size();
    }

    private void createWorkSheetMetaData() {
        workSheetMetaData = new WorkSheetMetaData();
        RowDefinitionFactory rowDefinitionFactory = new RowDefinitionFactory();
        RowDefinition rowDefinition = rowDefinitionFactory.createRowDefintion(MaterialTypeConstants.ICB_MALE);
        RowMetaData rowMetaData = rowDefinition.getRowMetaData();
        int rowCount = rowDefinition.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            if (rowMetaData.isAppearsInTemplate(i) || rowMetaData.isAppearsInExportTemplate(i)) {
                workSheetMetaData.addColumn(rowMetaData.getGetMethodName(i), rowMetaData.getHSSFCellType(i));
            }
        }
    }
}