/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;


import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: WordWrap.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-10-08 19:31:16 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class WordWrap {
    private static final String DEFAULT_WRAP_CHAR = "\n";
    private int lineLength = 0;
    private String wrapCharacter = DEFAULT_WRAP_CHAR;

    public WordWrap(int lineLength) {
        this.lineLength = lineLength;
    }

    public void setWrapCharacter(final String wrapCharacter) {
        this.wrapCharacter = wrapCharacter;
    }

    public String wrapText(final String originalString) {
        if (originalString == null) {
            return null;
        }
        List list = new LinkedList();
        Matcher m = getWrappingPattern().matcher(originalString);

        while (m.find()) {
            list.add(m.group());
        }

        return joinStringArray((String[]) list.toArray(new String[list.size()]));
    }

    private Pattern getWrappingPattern() {
        return Pattern.compile("(\\S\\S{" + lineLength + ",}|.{1," + lineLength + "})(\\s+|$)");
    }

    private String joinStringArray(final String[] strings) {
        StringBuffer buf = new StringBuffer("");
        for (int i = 0; i < strings.length; i++) {
            if (null != strings[i] && strings[i].trim().length() > 0) {
                addWrapCharacterToBuffer(buf);
                buf.append(strings[i].trim());
            }
        }
        return buf.toString();
    }

    private void addWrapCharacterToBuffer(final StringBuffer buf) {
        if (buf != null && buf.length() > 0) {
            buf.append(wrapCharacter);
        }
    }
}