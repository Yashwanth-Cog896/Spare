/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity;

import com.monsanto.Util.StringUtils;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: AllowedLineFunctionValuesCheck.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:03 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public abstract class AllowedLineFunctionValuesCheck {
    public static final String ALLOWED_VALUES = "Allowed values for line function are: ";
    protected String lineFunctionRefId;

    protected AllowedLineFunctionValuesCheck(String lineFunctionRefId) {
        this.lineFunctionRefId = trimIfNotNull(lineFunctionRefId);
        this.lineFunctionRefId = getEmptyStringIfNull(this.lineFunctionRefId);
    }

    protected abstract Set getSetOfAllowedLineFunctionValues();

    public void check(List msgList) {
        Set allowedValues = getSetOfAllowedLineFunctionValues();
        if (!allowedValues.contains(lineFunctionRefId)) {
            msgList.add(ALLOWED_VALUES + getDelimitedStringOfAllowedLineFunctionValues(allowedValues));
        }
    }

    protected String getDelimitedStringOfAllowedLineFunctionValues(Set allowedValuesSet) {
        StringBuffer buf = new StringBuffer("null");
        for (Iterator iter = allowedValuesSet.iterator(); iter.hasNext();) {
            appendStringToStringBufferIfNotEmpty(buf, (String) iter.next());
        }
        return buf.toString();
    }

    private void appendStringToStringBufferIfNotEmpty(StringBuffer buf, String value) {
        if (!StringUtils.isNullOrEmpty(value)) {
            buf.append(", \"").append(value).append("\"");
        }
    }

    protected String getEmptyStringIfNull(String value) {
        return value == null ? "" : value;
    }

    protected String trimIfNotNull(String value) {
        return value == null ? value : value.trim();
    }
}