/*
 MaterialTypeConstants was created on Feb 20, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: MaterialTypeConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $
 * On:$Date: 2008-01-30 16:18:22 $
 *
 * @author SRKARNA
 * @version $Revision: 1.11 $
 */
public class MaterialTypeConstants {
    public static final String COMMERCIAL_PRODUCT = "Commercial";
    public static final String COMPETITOR_PRODUCT = "Competitor";
    public static final String FINISHED_LINES = "Finished";
    public static final String CODED_LINES = "Coded";
    public static final String SEGPOP_LINES = "Segpop";
    public static final String HYBRID_LINES = "Hybrid";
    public static final String ICB_MALE = "ICB Male";
    public static final String HYBRID_FINISHED_LINES = "Hybrid-Finished";
    public static final String HYBRID_UNFINISHED_LINES = "Hybrid-Unfinished";
    public static final String F1_SEGPOP_FINISHED_LINES = "F1Segpop-Finished";
    public static final String F1_SEGPOP_UNFINISHED_LINES = "F1Segpop-Unfinished";
    public static final String CLINEFUNCTION_MSC0_SEGPOP_FINISHED_LINES = "CLineMSC0Segpop-Finished";
    public static final String CLINEFUNCTION_MSC0_SEGPOP_UNFINISHED_LINES = "CLineMSC0Segpop-Unfinished";
}