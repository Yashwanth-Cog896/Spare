/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.source.parentalsource;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.SourceContentVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.exception.InvalidSourceStringContentException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.parentalsource.exception.InvalidParentalSourceSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: ParentalSourceParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $ On:$Date:
 * 2008/01/22 20:02:55 $
 *
 * @author SSPEYY
 * @version $Revision: 1.11 $
 */
public class ParentalSourceParser {
    private String rawParentalSource;
    private List<VegetativeStructure> vegetativeStructures;
    private String stagingInventoryVegetativeStructure;
    private String[] components;
    private List parentalSources = null;

    private static final String DELIMITER = ";";
    private static final String DEFAULT_SOURCE = "";
    private static final String PARENT_SEPERATOR = "&";
    private static final String VEGETATIVE_STRUCTURE_SEPERATOR = "\"";
    private static final String FEMALE = "F";
    private static final String MALE = "M";
    private static final String CONSECUTIVE_PARENT_SEPERATORS = "&&";
    private static final String INVALID_PARENTAL_SOURCE_MSG = "Invalid Parental Source String.";


    public ParentalSourceParser(String parentalSource, String stagingInventoryVegetativeStructure, List<VegetativeStructure> vegetativeStructuresByCrop) throws InvalidParentalSourceSyntaxException {
        if (parentalSource != null) {
            this.rawParentalSource = parentalSource.trim();
            this.vegetativeStructures = vegetativeStructuresByCrop;
            this.stagingInventoryVegetativeStructure = stagingInventoryVegetativeStructure;
            parse();
            doBasicValidations();
            getParentsFromComponents();
            validateParentalSources();
            setDefaultSourceOnEmptyParentalSources();
        }
    }

    private void doBasicValidations() throws InvalidParentalSourceSyntaxException {
        if (consecutiveParentSeperatorsExist() || moreThanOneParentSeperatorExistBetweenDelimiter() || moreThanOneVegetativeStructureSeperatorExistBetweenDelimiter()) {
            throw new InvalidParentalSourceSyntaxException(INVALID_PARENTAL_SOURCE_MSG);
        }
    }

    private boolean moreThanOneParentSeperatorExistBetweenDelimiter() {
        for (int i = 0; i < components.length; i++) {
            if (getSeperatorCount(components[i], PARENT_SEPERATOR) > 1) {
                return true;
            }
        }
        return false;
    }

    private boolean moreThanOneVegetativeStructureSeperatorExistBetweenDelimiter() {
        for (int i = 0; i < components.length; i++) {
            String[] subComponents = components[i].split("\\s*" + PARENT_SEPERATOR + "\\s*", -1);
            for (String subComponent : subComponents) {
                if (getSeperatorCount(subComponent, VEGETATIVE_STRUCTURE_SEPERATOR) > 1) {
                    return true;
                }
            }
        }
        return false;
    }

    private int getSeperatorCount(String component, String seperator) {
        int parentSeperator = 0;
        char[] cChar = component.toCharArray();
        for (int j = 0; j < cChar.length; j++) {
            char c = cChar[j];
            if (seperator.equals(String.valueOf(c))) {
                parentSeperator++;
            }
        }
        return parentSeperator;
    }

    private boolean consecutiveParentSeperatorsExist() {
        return rawParentalSource.indexOf(CONSECUTIVE_PARENT_SEPERATORS) > -1;
    }

    private void getParentsFromComponents() throws InvalidParentalSourceSyntaxException {
        parentalSources = new ArrayList();
        int componentIndex = 0;

        int recordLevel = 2;
        VegetativeStructure firstVegtativeStructure = vegetativeStructures.get(0);
        if (vegetativeStructures.size() > 1 && stagingInventoryVegetativeStructure.equals(firstVegtativeStructure.getName())) {
            parentalSources.add(buildParentalSource(components[componentIndex], 1, vegetativeStructures.get(1)));
            componentIndex++;
        }
        for (int i = componentIndex; i < components.length; i++, recordLevel++) {
            String currentComponent = components[i];
            if (doesComponentHasTwoParents(currentComponent)) {
                String[] parentSources = currentComponent.split("\\s*" + PARENT_SEPERATOR + "\\s*", -1);
                buildParentalResources(parentSources[0], recordLevel, FEMALE);
                buildParentalResources(parentSources[1], recordLevel, MALE);
            } else {
                String[] subComponents = currentComponent.split("\\s*" + VEGETATIVE_STRUCTURE_SEPERATOR + "\\s*", -1);
                validateSufficientVegetativeStructuresExist(subComponents);
                for (int j = 0; j < subComponents.length; j++) {
                    parentalSources.add(buildParentalSource(subComponents[j], recordLevel, vegetativeStructures.get(j)));
                }
            }
        }
    }

    private void validateSufficientVegetativeStructuresExist(String[] subComponents) throws InvalidParentalSourceSyntaxException {
        if (vegetativeStructures == null || vegetativeStructures.size() < subComponents.length) {
            throw new InvalidParentalSourceSyntaxException(INVALID_PARENTAL_SOURCE_MSG);
        }
    }

    private void buildParentalResources(String parentSource, int level, String gender) throws InvalidParentalSourceSyntaxException {
        String[] femaleSubComponents = parentSource.split("\\s*" + VEGETATIVE_STRUCTURE_SEPERATOR + "\\s*", -1);
        validateSufficientVegetativeStructuresExist(femaleSubComponents);
        for (int j = 0; j < femaleSubComponents.length; j++) {
            parentalSources.add(buildGenderBasedParentalSource(femaleSubComponents[j], level, gender, vegetativeStructures.get(j)));
        }
    }

    private ParentalSource buildParentalSource(String currentComponent, int level, VegetativeStructure vegetativeStructure) {
        ParentalSource parentalSource = new ParentalSource();
        if (currentComponent == null || "".equals(currentComponent.trim())) {
            parentalSource.setSource(DEFAULT_SOURCE);
        } else {
            parentalSource.setSource(currentComponent.trim());
        }
        parentalSource.setRecordLevel(new Integer(level));
        parentalSource.setParentalRole(FEMALE);
        parentalSource.setVegetativeStructure(vegetativeStructure.getName());
        return parentalSource;
    }

    private ParentalSource buildGenderBasedParentalSource(String currentComponent, int level, String gender, VegetativeStructure vegetativeStructure) {
        ParentalSource parentalSource = new ParentalSource();
        parentalSource.setParentalRole(gender);
        parentalSource.setSource(currentComponent);
        parentalSource.setRecordLevel(new Integer(level));
        parentalSource.setVegetativeStructure(vegetativeStructure.getName());
        return parentalSource;
    }

    private ParentalSource buildMaleParentalSource(String currentComponent, int level) {
        ParentalSource parentalSourceMale = new ParentalSource();
        parentalSourceMale.setParentalRole(MALE);
        parentalSourceMale.setSource(currentComponent);
        parentalSourceMale.setRecordLevel(new Integer(level));
        return parentalSourceMale;
    }

    private ParentalSource buildFemaleParentalSource(String currentComponent, int level) {
        ParentalSource parentalSourceFemale = new ParentalSource();
        parentalSourceFemale.setParentalRole(FEMALE);
        parentalSourceFemale.setSource(currentComponent);
        parentalSourceFemale.setRecordLevel(new Integer(level));
        return parentalSourceFemale;
    }

    private boolean doesComponentHasTwoParents(String currentComponent) {
        return currentComponent.indexOf(PARENT_SEPERATOR) > -1;
    }

    private boolean doesComponentHasTwoVegetativeStructureSources(String currentComponent) {
        return currentComponent.indexOf(VEGETATIVE_STRUCTURE_SEPERATOR) > -1;
    }

    private void parse() {
        components = rawParentalSource.split("\\s*" + DELIMITER + "\\s*", -1);
    }

    public ParentalSource[] getParentalSources() {
        if (parentalSources == null) {
            return new ParentalSource[0];
        }
        return (ParentalSource[]) parentalSources.toArray(new ParentalSource[parentalSources.size()]);
    }

    private void setDefaultSourceOnEmptyParentalSources() {
        if (parentalSources != null) {
            for (Object o : parentalSources) {
                ParentalSource s = (ParentalSource) o;
                if (StringUtils.isNullOrEmpty(s.getSource())) {
                    s.setSource(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
                }
            }
        }
    }

    private void validateParentalSources() throws InvalidParentalSourceSyntaxException {
        if (parentalSources != null) {
            for (Object s : parentalSources) {
                validateSourceDoNotContainInvalidContent(((ParentalSource) s).getSource());
            }
        }
    }

    private void validateSourceDoNotContainInvalidContent(String source) throws InvalidParentalSourceSyntaxException {
        if (StringUtils.isNullOrEmpty(source)) {
            return;
        }
        SourceContentVerifier verifier = new SourceContentVerifier();
        try {
            verifier.verify(source);
        } catch (InvalidSourceStringContentException e) {
            throw new InvalidParentalSourceSyntaxException(e.getMessage());
        }
    }
}