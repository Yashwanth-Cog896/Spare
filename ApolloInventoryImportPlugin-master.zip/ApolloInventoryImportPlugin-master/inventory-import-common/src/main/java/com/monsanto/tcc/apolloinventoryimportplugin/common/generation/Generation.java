package com.monsanto.tcc.apolloinventoryimportplugin.common.generation;

/**
 * Filename:    $RCSfile: Generation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-04 21:13:55 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public interface Generation {
    public boolean isMSC();

    public boolean isMSC0();

    public boolean isBackcross();

    public boolean isNull();

    public boolean isInbred();

    public int getGeneration();
}
