/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.parentage;

/**
 * Filename:    $RCSfile: PedigreeConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $
 * On:$Date: 2007-03-13 17:02:49 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.1 $
 */
public class PedigreeConstants {
    public static final String SELF_SYMBOL = ".";
    public static final String SIB_SYMBOL = "#";
    public static final String OPEN_SYMBOL = "!";
    public static final String INDUCE_HAPLOID_SYMBOL = "%";
    public static final String SINGLE_SEED_SYMBOL = "$";
    public static final String DEVCROSS_SYMBOL = "/";
    public static final String BACKCROSS_SYMBOL = ">";
    public static final String TESTCROSS_SYMBOL = "+";
    public static final String LINEAGE_SYMBOL = ":";
    public static final String LINEAGE_SEPARATOR = "|";
    public static final String DOSAGE_SYMBOL = "*";
    public static final String BULK_SYMBOL = "@";
    public static final String TI_BACKCROSS_DOSAGE_SYMBOL = "~";
    public static final String MSC_CROSS = "\\";
    public static final String CREATE_SINGLE_SEED_SYMBOL = "-";
}