/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.Set;
import java.util.TreeSet;

/**
 * Filename:    $RCSfile: AllowedLineFunctionValuesCommercialCheck.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:03 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class AllowedLineFunctionValuesCommercialCheck extends AllowedLineFunctionValuesCheck {
    private static final String LINE_TYPE_VALUE_REQ_MSG = "Line Type value is required";
    private String lineType;

    public AllowedLineFunctionValuesCommercialCheck(String lineFunctionRefId, String lineType) {
        super(lineFunctionRefId);
        if (StringUtils.isNullOrEmpty(lineType)) {
            throw new IllegalArgumentException(LINE_TYPE_VALUE_REQ_MSG);
        }
        this.lineType = lineType;
    }

    protected Set getSetOfAllowedLineFunctionValues() {
        if (!StringUtils.isNullOrEmpty(lineType) && MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType.trim())) {
            return getSetOfAllowedLineFunctionValuesForHybridLineType();
        }
        return getSetOfAllowedLineFunctionValuesForNonHybridLineType();
    }

    private Set getSetOfAllowedLineFunctionValuesForHybridLineType() {
        Set allowedValueSet = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        allowedValueSet.add("");
        allowedValueSet.add(LineFunctionConstants.F_LINE_FUNCTION);
        allowedValueSet.add(LineFunctionConstants.S_LINE_FUNCTION);
        return allowedValueSet;
    }

    private Set getSetOfAllowedLineFunctionValuesForNonHybridLineType() {
        Set allowedValueSet = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        allowedValueSet.add("");
        allowedValueSet.add(LineFunctionConstants.B_LINE_FUNCTION);
        allowedValueSet.add(LineFunctionConstants.R_LINE_FUNCTION);
        allowedValueSet.add(LineFunctionConstants.A_LINE_FUNCTION);
        allowedValueSet.add(LineFunctionConstants.C_LINE_FUNCTION);
        return allowedValueSet;
    }
}