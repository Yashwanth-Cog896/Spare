/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.MSCGeneration;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidMSCGenerationException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;

/**
 * Filename:    $RCSfile: MSCLineageAndGenerationValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5
 * $     On:$Date: 2008-01-29 19:57:13 $
 *
 * @author ddbrow5
 * @version $Revision: 1.7 $
 */
public class MSCLineageAndGenerationValidator {
    private static final String LINEAGE_REQ_MSG = "Lineage value is required";
    private static final String GENERATION_REQ_MSG = "Generation value is required";
    public static final String LINEAGE_GENERATION_MISMATCH_MSG = "Lineage of A line with specified MSC generation " +
            "value does not support building parentage.  Please import the line without building parentage.";
    private Lineage lineage;
    private String generation;

    public MSCLineageAndGenerationValidator(String lineage, String generation) {
        if (StringUtils.isNullOrEmpty(lineage)) {
            throw new IllegalArgumentException(LINEAGE_REQ_MSG);
        }
        if (StringUtils.isNullOrEmpty(generation)) {
            throw new IllegalArgumentException(GENERATION_REQ_MSG);
        }

        this.lineage = createLineage(lineage);
        this.generation = generation.trim();
    }

    private Lineage createLineage(String lineageString) {
        Lineage localLineage = null;
        try {
            localLineage = new LineageFactory().createLineage(LineFunctionConstants.A_LINE_FUNCTION, lineageString);
        } catch (InvalidLineageException e) {
            throw new IllegalArgumentException(e.getMessage());
        }
        return localLineage;
    }

    public void validate() throws MSCLineageAndGenerationException {
        MSCGeneration mscGeneration = getMSCGeneration();
        if (mscGeneration.getGenerationNumber() > lineage.getNumberOfCycleMarkers()) {
            throw new MSCLineageAndGenerationException(LINEAGE_GENERATION_MISMATCH_MSG);
        }
    }

    private MSCGeneration getMSCGeneration() throws MSCLineageAndGenerationException {
        MSCGeneration mscGeneration = null;
        try {
            mscGeneration = new MSCGeneration(generation);
        } catch (InvalidMSCGenerationException e) {
            throw new MSCLineageAndGenerationException(e.getMessage(), e);
        }
        return mscGeneration;
    }
}