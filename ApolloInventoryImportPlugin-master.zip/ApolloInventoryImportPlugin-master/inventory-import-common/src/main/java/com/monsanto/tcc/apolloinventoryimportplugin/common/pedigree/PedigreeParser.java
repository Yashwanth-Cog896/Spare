/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree;

import com.monsanto.Util.StringUtils;

/**
 * Filename:    $RCSfile: PedigreeParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: AAGOSW $     On:$Date: 2008-09-29 21:53:09 $
 *
 * @author SSPEYY
 * @version $Revision: 1.11 $
 */
public class PedigreeParser {
    private static final String COLON = ":";
    private static final String UNDERSCORE = "_";
    private static final String LEFT_PARENTHESIS = "(";
    private static final String RIGHT_PARENTHESIS = ")";
    public static final String PEDIGREE_REQUIRED_MSG = "Pedgiree is required";
    public static final String INVALID_PEDIGREE_MSG = "Pedgiree is invalid";
    private String lineageString;
    private String originOrLineCodeString;
    private String germplasmOwnerString;
    private boolean wasGermplasmOwnerParsed = false;
    private boolean wasLineagerParsed = false;
    private boolean wasOriginLineCodeParsed = false;
    private StringBuffer pedigreeBeingParsed = null;

    public PedigreeParser(String pedigree) {
        if (StringUtils.isNullOrEmpty(pedigree)) {
            throw new IllegalArgumentException(PEDIGREE_REQUIRED_MSG);
        }
        pedigree = trimIfNotNull(pedigree);
        this.pedigreeBeingParsed = new StringBuffer(pedigree);
        extractComponents();
    }

    public String getGermplasmOwnerString() {
        return germplasmOwnerString;
    }

    public String getLineageString() {
        return lineageString;
    }

    public String getOriginOrLineCodeString() {
        return originOrLineCodeString;
    }

    private void extractComponents() {
        populateGermplasmOwner();
        populateLineage();
        populateOrigin();
    }

    private void populateGermplasmOwner() {
        if (!wasGermplasmOwnerParsed) {
            int underscoreIndex = pedigreeBeingParsed.indexOf(UNDERSCORE);
            if (characterWasFound(underscoreIndex)) {
                germplasmOwnerString = pedigreeBeingParsed.substring(0, underscoreIndex);
                germplasmOwnerString = StringUtils.isNullOrEmpty(germplasmOwnerString) ? null : germplasmOwnerString;
                pedigreeBeingParsed.delete(0, underscoreIndex + 1);
            }
            wasGermplasmOwnerParsed = true;
        }
    }

    private void populateLineage() {
        if (!wasLineagerParsed && wasGermplasmOwnerParsed) {
            int colonIndex = pedigreeBeingParsed.lastIndexOf(COLON);
            if (characterWasFound(colonIndex) && !isIndexPointingToLastCharacter(colonIndex)) {
                final String lineageBeingParsed = pedigreeBeingParsed.substring(colonIndex + 1, pedigreeBeingParsed.length());
                if (!isLineageInsideParentheses(lineageBeingParsed)) {
                    lineageString = lineageBeingParsed;
                    pedigreeBeingParsed.delete(colonIndex, pedigreeBeingParsed.length());
                }
            }
            wasLineagerParsed = true;
        }
    }

    private void populateOrigin() {
        if (!wasOriginLineCodeParsed && wasGermplasmOwnerParsed && wasLineagerParsed) {
            String stringBeingParsed = pedigreeBeingParsed.toString();
            stringBeingParsed = removeTrailingColon(stringBeingParsed);
            stringBeingParsed = removeOuterParentheses(stringBeingParsed);
            originOrLineCodeString = StringUtils.isNullOrEmpty(stringBeingParsed) ? null : stringBeingParsed;
            wasOriginLineCodeParsed = true;
        }
    }

    private boolean isIndexPointingToLastCharacter(int index) {
        return index == pedigreeBeingParsed.length() - 1;
    }

    private boolean isLineageInsideParentheses(String lineageString) {
        return !StringUtils.isNullOrEmpty(lineageString) && lineageString.indexOf(RIGHT_PARENTHESIS) > -1;
    }

    private String trimIfNotNull(String stringToBeTrimmed) {
        return !StringUtils.isNullOrEmpty(stringToBeTrimmed) ? stringToBeTrimmed.trim() : stringToBeTrimmed;
    }

    private boolean characterWasFound(int index) {
        return index > -1;
    }

    private String removeTrailingColon(String stringFromWhichColonIsToBeRemoved) {
        return stringFromWhichColonIsToBeRemoved.endsWith(COLON) ?
                stringFromWhichColonIsToBeRemoved.substring(0, stringFromWhichColonIsToBeRemoved.length() - 1) :
                stringFromWhichColonIsToBeRemoved;
    }

    private String removeOuterParentheses(String stringFromWhichOuterParenthesesIsToBeRemoved) {
        return stringFromWhichOuterParenthesesIsToBeRemoved.startsWith(LEFT_PARENTHESIS) && (findEndIndexOfRightParentheses(stringFromWhichOuterParenthesesIsToBeRemoved) == stringFromWhichOuterParenthesesIsToBeRemoved.length() - 1) ?
                stringFromWhichOuterParenthesesIsToBeRemoved.substring(1, stringFromWhichOuterParenthesesIsToBeRemoved.length() - 1) : stringFromWhichOuterParenthesesIsToBeRemoved;
    }

    private int findEndIndexOfRightParentheses(CharSequence string) {
        int index = 1;
        int withinNestedParentheses = 0;
        while (index < string.length()) {
            if (substringMatch(string, index, RIGHT_PARENTHESIS)) {
                if (withinNestedParentheses > 0) {
                    withinNestedParentheses--;
                    index++;
                } else {
                    return index;
                }
            } else if (substringMatch(string, index, LEFT_PARENTHESIS)) {
                withinNestedParentheses++;
                index++;
            } else {
                index++;
            }
        }
        return -1;
    }

    public boolean substringMatch(CharSequence str, int index, CharSequence substring) {
        return str.charAt(index) == substring.charAt(0);
    }

}