package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

public class InventoryImportConstants {
    public static final String TRUE_STRING = "T";
    public static final String FALSE_STRING = "F";
    public static final String UNKNOWN_STRING = "U";
    public static final String DEFAULT_STRING = "-";
}
