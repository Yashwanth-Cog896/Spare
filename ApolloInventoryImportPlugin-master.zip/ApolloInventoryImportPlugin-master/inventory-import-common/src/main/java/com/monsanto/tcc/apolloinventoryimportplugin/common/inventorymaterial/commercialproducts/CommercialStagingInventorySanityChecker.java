/*
 CommercialStagingInventorySanityChecker was created on Apr 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.commercialproducts;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.ALineFunctionCytoplasmCheckCompetitorCommercialLines;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionValuesCommercialCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.NonALineFunctionCytoplasmCompetitorCommercialLinesCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;

/**
 * Filename:    $RCSfile: CommercialStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $     On:$Date: 2009-06-05 14:08:09 $
 *
 * @author SRKARNA
 * @version $Revision: 1.6 $
 */
public class CommercialStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    private StagingInventory stagingInventory = null;

    public CommercialStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);
        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getProductName())) {
            msgList.add(MANDATORY_CHECK_MSG + "Product Name");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getLineType())) {
            msgList.add(MANDATORY_CHECK_MSG + "Line Type");
        } else {
            performLineTypeBasedChecks(msgList);
        }
        if (isLineFunctionA(stagingInventory.getLineFunction())) {
            new ALineFunctionCytoplasmCheckCompetitorCommercialLines(
                    stagingInventory.getCytoplasmDonorPedigree()).check(msgList);
        } else {
            new NonALineFunctionCytoplasmCompetitorCommercialLinesCheck(
                    stagingInventory.getCytoplasmDonorPedigree()).check(msgList);
        }
    }

    private boolean isLineFunctionA(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) &&
                LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }

    private void performLineTypeBasedChecks(List msgList) {
        if (!checkAllowedLineType(stagingInventory.getLineType())) {
            msgList.add(stagingInventory.getLineType() + DATA_BOUNDARY_CHECK_MSG + "Line Type");
        } else if (isFinished(stagingInventory.getLineType())) {
            if (StringUtils.isNullOrEmpty(stagingInventory.getLineCode())) {
                msgList.add(MANDATORY_CHECK_MSG + "Line Code");
            }
            new AllowedLineFunctionValuesCommercialCheck(stagingInventory.getLineFunction(),
                    MaterialTypeConstants.FINISHED_LINES).check(msgList);
        } else if (isHybrid(stagingInventory.getLineType())) {
            if (StringUtils.isNullOrEmpty(stagingInventory.getOrigin())) {
                msgList.add(MANDATORY_CHECK_MSG + "Origin");
            }
            new AllowedLineFunctionValuesCommercialCheck(stagingInventory.getLineFunction(),
                    MaterialTypeConstants.HYBRID_LINES).check(msgList);
        }
    }

    private void validLineTypeCheck(String lineType) {
    }

    private boolean isHybrid(String lineType) {
        return MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType);
    }

    private boolean isFinished(String lineType) {
        return MaterialTypeConstants.FINISHED_LINES.equalsIgnoreCase(lineType);
    }

    private boolean checkAllowedLineType(String lineType) {
        return isFinished(lineType) || isHybrid(lineType);
    }
}