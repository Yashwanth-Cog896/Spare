package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: WorkSheetMetaData.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-02-23 20:42:58 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class WorkSheetMetaData {
  private List entities = null;

  public WorkSheetMetaData() {
    entities = new ArrayList();
  }

  public void addColumn(String getMethodName, int type) {
    entities.add(new WorkSheetMetaDataEntity(getMethodName, type));
  }

  public void addColumn(String getMethodName, int type, String alternateGetMethodName, int alternateType) {
    WorkSheetMetaDataEntity workSheetMetaDataEntity = new WorkSheetMetaDataEntity(getMethodName, type);
    workSheetMetaDataEntity.setAlternateGetMethodName(alternateGetMethodName);
    workSheetMetaDataEntity.setAlternateType(alternateType);
    entities.add(workSheetMetaDataEntity);
  }

  public int size() {
    return null == entities ? 0 : entities.size();
  }

  public String getGetMethodName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((WorkSheetMetaDataEntity) entities.get(index)).getGetMethodName();
  }

  public int getColumnType(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((WorkSheetMetaDataEntity) entities.get(index)).getType();
  }

  public boolean isAlternateDataPresent(int index) {
    return ((WorkSheetMetaDataEntity) entities.get(index)).isAlternateDataPresent();
  }

  public String getAlternateGetMethodName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return isAlternateDataPresent(index) ? ((WorkSheetMetaDataEntity) entities.get(index)).getAlternateGetMethodName()
            : null;
  }

  public int getAlternateColumnType(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return isAlternateDataPresent(index) ? ((WorkSheetMetaDataEntity) entities.get(index)).getAlternateType()
            : -1;
  }

}
