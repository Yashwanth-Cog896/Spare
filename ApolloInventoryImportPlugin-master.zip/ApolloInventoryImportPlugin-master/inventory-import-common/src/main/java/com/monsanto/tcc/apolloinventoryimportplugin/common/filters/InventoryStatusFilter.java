/*
 InventoryStatusFilter was created on Feb 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.filters;

import com.monsanto.services.domain.common.filter.BinaryExpression;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.services.domain.common.filter.operator.OperatorDirectory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.FilterConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: InventoryStatusFilter.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-12 17:00:02 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class InventoryStatusFilter {
    public static final String STATUS_INTERESTED_NEW = "New";
    public static final String STATUS_INTERESTED_INVALID = "Invalid";

    public void collectStatusFilterForProcessMaterial(Filter filter) {
        List values = new ArrayList();
        values.add(STATUS_INTERESTED_NEW);
        values.add(STATUS_INTERESTED_INVALID);

        filter.addExpression(new BinaryExpression(OperatorDirectory.IN_OPERATOR.getRefId(),
                FilterConstants.STATUS_CODE_OPERAND, values));
    }
}