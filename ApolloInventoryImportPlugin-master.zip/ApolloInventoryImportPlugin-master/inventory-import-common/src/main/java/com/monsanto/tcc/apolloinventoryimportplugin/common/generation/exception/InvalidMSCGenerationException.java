/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception;

/**
 * Filename:    $RCSfile: InvalidMSCGenerationException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-11-12 18:14:22 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class InvalidMSCGenerationException extends Exception {
    public InvalidMSCGenerationException() {
    }

    public InvalidMSCGenerationException(String message) {
        super(message);
    }

    public InvalidMSCGenerationException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidMSCGenerationException(Throwable cause) {
        super(cause);
    }
}