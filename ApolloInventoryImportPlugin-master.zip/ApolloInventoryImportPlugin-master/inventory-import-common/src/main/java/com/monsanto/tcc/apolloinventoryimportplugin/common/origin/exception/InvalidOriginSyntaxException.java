package com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception;

/**
 * Filename:    $RCSfile: InvalidOriginSyntaxException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2008-01-29 20:25:10 $
 *
 * @author DDBROW5
 * @version $Revision: 1.3 $
 */
public class InvalidOriginSyntaxException extends Exception {
    public InvalidOriginSyntaxException(String msg) {
        super(msg);
    }
}
