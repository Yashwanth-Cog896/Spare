package com.monsanto.tcc.apolloinventoryimportplugin.common.authority;

import com.monsanto.services.domain.common.Entity;

/**
 * User: AAGOSW
 * Date: Mar 3, 2008
 * Time: 7:42:49 AM
 */
public class AuthorityWrapper implements Entity {

    private Authority authority;
    private int mainRecordCount;
    private int allRecordCount;

    public AuthorityWrapper(Authority authority) {
        this.authority = authority;
    }

    public Authority getAuthority() {
        return this.authority;
    }

    public void setAuthority(Authority authority) {
        this.authority = authority;
    }

    public int getMainRecordCount() {
        return mainRecordCount;
    }

    public void setMainRecordCount(int mainRecordCount) {
        this.mainRecordCount = mainRecordCount;
    }

    public int getAllRecordCount() {
        return allRecordCount;
    }

    public void setAllRecordCount(int allRecordCount) {
        this.allRecordCount = allRecordCount;
    }


    public Object getID() {
        return null;
    }
}
