/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: ValidateStagingInventoryPOSClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-01 20:19:01 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class ValidateStagingInventoryPOSClient extends AbstractPOSClient {
    private static final String POS_ACTIVITY = "ValidateStagingInventoryData";

    public ValidateStagingInventoryPOSClient() {
        super.setPosActivityName(POS_ACTIVITY);
    }

    public void validateStagingInventory(StagingInventory stagingInventory) throws ActivityClientException {
        sendToPos(createCompositeObject(stagingInventory));
    }

    private CompositeObject createCompositeObject(StagingInventory stagingInventory) {
        CompositeObject payload = new CompositeObject();
        payload.add(getFilterWithDefaultFilterId());
        stagingInventory.getInventoryHeader().setStagingInventory(null);
        stagingInventory.setImportType(null);
        payload.add(stagingInventory);
        return payload;
    }

}