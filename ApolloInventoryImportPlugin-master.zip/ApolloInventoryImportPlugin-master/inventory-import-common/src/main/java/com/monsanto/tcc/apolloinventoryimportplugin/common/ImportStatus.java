/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

/**
 * Filename:    $RCSfile: ImportStatus.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: skumar5 $     On:$Date: 2007-01-03 19:52:48 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class ImportStatus {
    private Long id;
    private String statusCode;
    private String description;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}