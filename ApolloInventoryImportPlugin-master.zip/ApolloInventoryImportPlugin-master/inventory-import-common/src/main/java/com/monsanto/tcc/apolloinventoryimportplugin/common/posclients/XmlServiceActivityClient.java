/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.client.common.activity.ActivityClient;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.tcc.constellation.serviceconnection.ServiceUrlResolver;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnection;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceRequest;
import com.monsanto.tcc.constellation.serviceconnection.DefaultXmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.CompressedXmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.StandaloneKerberosXmlServiceRequest;
import org.ietf.jgss.GSSException;

/**
 * Filename:    $RCSfile: XmlServiceActivityClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-01 19:23:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class XmlServiceActivityClient extends ActivityClient {
  private ServiceUrlResolver serviceUrlResolver;
  private XmlServiceRequest serviceRequest;
  private boolean compressData;

  public XmlServiceActivityClient(ServiceUrlResolver serviceUrlResolver,
                                  XmlServiceRequest serviceRequest, boolean compressData) {
    this.serviceUrlResolver = serviceUrlResolver;
    this.serviceRequest = serviceRequest;
    this.compressData = compressData;
  }

  public ResponseEnvelope perform(RequestEnvelope requestEnvelope, String serviceName,
                                  XmlSerializer xmlSerializer) throws ActivityClientException {
    XmlServiceConnection connection;
    try {
      connection = getConnection(serviceName, xmlSerializer);
      return (ResponseEnvelope) connection.call(requestEnvelope);
    } catch (Exception e) {
      throw new ActivityClientException(e.getMessage(), e);
    }
  }

  private XmlServiceConnection getConnection(String serviceName, XmlSerializer xmlSerializer) throws GSSException, InstantiationException, IllegalAccessException {
    if(compressData) {
      return getCompressionEnabledConnection(serviceName, xmlSerializer);
    }
    return getConnectionWithoutCompression(serviceName, xmlSerializer);
  }

  protected XmlServiceConnection getConnectionWithoutCompression(String serviceName, XmlSerializer xmlSerializer) throws GSSException, IllegalAccessException,
      InstantiationException {
    return new XmlServiceConnection(serviceName, serviceUrlResolver,
        new DefaultXmlServiceConnectionInterpreter(xmlSerializer), serviceRequest);

  }

  // Note that for compressed data the POS has to be set up to handle it
  protected XmlServiceConnection getCompressionEnabledConnection(String serviceName, XmlSerializer xmlSerializer) throws IllegalAccessException,
      InstantiationException {
    return new XmlServiceConnection(serviceName, serviceUrlResolver,
        new CompressedXmlServiceConnectionInterpreter(xmlSerializer), new StandaloneKerberosXmlServiceRequest());
  }
}