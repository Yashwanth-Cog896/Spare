/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    $RCSfile: OriginBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date:
 * 2007/04/03 19:24:09 $
 *
 * @author SSPEYY
 * @version $Revision: 1.6 $
 */
public class OriginBuilder {
    private static final String ASTERISK = "*";

    private List preOrderEntityList = new ArrayList();
    private int indexOfRecurringParent = -1;

    public OriginBuilder(String origin) throws InvalidOriginSyntaxException {
        init(getOriginTreeEntity(origin));
    }

    public OriginBuilder(OriginEntity originEntity) {
        init(originEntity);
    }

    public String buildOrigin(int newDosage) throws InvalidOriginSyntaxException {
        return getOrigin(newDosage);
    }

    private String getOrigin(int newDosage) {
        String newOrigin;
        if (indexOfRecurringParent > -1) {
            String newRecurringParent = buildNewRecurringParent((String) preOrderEntityList.get(indexOfRecurringParent),
                    newDosage);
            newOrigin = buildNewOrigin(newRecurringParent);
        } else {
            newOrigin = convertListToString(preOrderEntityList);
        }
        return newOrigin;
    }

    public String getOriginWithDosageReplacedByPercent() {
        String likeOrigin = null;
        if (indexOfRecurringParent > -1) {
            String recurringParent = (String) preOrderEntityList.get(indexOfRecurringParent);
            String newRecurrentParent = recurringParent.substring(0, recurringParent.lastIndexOf(ASTERISK) + 1) + "%";
            likeOrigin = buildNewOrigin(newRecurrentParent);
        }
        return likeOrigin;
    }

    private void init(OriginEntity originTreeEntity) {
        buildLinearListFromTree(originTreeEntity);
        initRecurringParentIndex();
    }

    private void initRecurringParentIndex() {
        for (int i = 0; i < preOrderEntityList.size(); i++) {
            String originComponent = (String) preOrderEntityList.get(i);
            if (!originComponent.endsWith(")") && originComponent.lastIndexOf(ASTERISK) >
                    0) { // > 0 check was used for ASTERISK as origin cannot start with it!
                indexOfRecurringParent = i;
                break;
            }
        }
    }

    private OriginEntity getOriginTreeEntity(String origin) throws InvalidOriginSyntaxException {
        OriginSyntaxVerifier originSyntaxVerifier = new OriginSyntaxVerifier(origin);
        return originSyntaxVerifier.getOriginTree();
    }

    private void buildLinearListFromTree(OriginEntity originTreeNode) {
        if (originTreeNode != null) {
            if (originTreeNode.isLeafEntity()) {
                preOrderEntityList.add(originTreeNode.getOrigin());
            }
            if ("\\".equals(originTreeNode.getOperator())) {
                buildListForCtype(originTreeNode);
            } else {
                buildList(originTreeNode);
            }
        }
    }

    private void buildList(OriginEntity originTreeNode) {
        buildLinearListFromTree(originTreeNode.getFemaleParent());
        if (originTreeNode.getFemaleParent() != null) {
            preOrderEntityList.add(originTreeNode.getOperator());
        }
        buildLinearListFromTree(originTreeNode.getMaleParent());
    }

    private void buildListForCtype(OriginEntity originTreeNode) {
        buildLinearListFromTree(originTreeNode.getMaleParent());
        if (originTreeNode.getMaleParent() != null) {
            preOrderEntityList.add(originTreeNode.getOperator());
        }
        buildLinearListFromTree(originTreeNode.getFemaleParent());
    }

    private String buildNewOrigin(String newRecurringParent) {
        List newEntityList = Arrays.asList(preOrderEntityList.toArray(new String[0]));
        newEntityList.set(indexOfRecurringParent, newRecurringParent);
        return convertListToString(newEntityList);
    }

    private String convertListToString(List currentList) {
        StringBuffer newOrigin = new StringBuffer();
        for (int i = 0; i < currentList.size(); i++) {
            newOrigin.append((String) currentList.get(i));
        }
        return newOrigin.toString();
    }

    private String buildNewRecurringParent(String oldRecurrentParent, int newDosage) {
        String newRecurrentParent;
        if (newDosage > 1) {
            newRecurrentParent = oldRecurrentParent.substring(0, oldRecurrentParent.lastIndexOf(ASTERISK) + 1) + newDosage;
        } else {
            newRecurrentParent = oldRecurrentParent.substring(0, oldRecurrentParent.lastIndexOf(ASTERISK));
        }

        return newRecurrentParent;
    }
}