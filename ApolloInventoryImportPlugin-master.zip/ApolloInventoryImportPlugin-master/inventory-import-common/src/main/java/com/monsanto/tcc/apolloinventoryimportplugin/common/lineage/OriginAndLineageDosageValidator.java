/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginSyntaxVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: OriginAndLineageDosageValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna
 * $ On:$Date: 2007-03-30 23:09:32 $
 *
 * @author APATRO
 * @version $Revision: 1.8 $
 */
public class OriginAndLineageDosageValidator {
    public boolean originDosageMatchesLineage(StagingInventory stagingInventory) {
        return originDosageMatchesLineage(stagingInventory.getOrigin(), stagingInventory.getLineage());
    }

    public boolean originDosageMatchesLineage(String origin, String lineage) {

        int originDosage = 0;
        try {
            originDosage = getDosageFromOrigin(origin);
        } catch (InvalidOriginSyntaxException e) {
            return false;
        } catch (Exception e) {
            return false;
        }

        int generationDosage = getDosageFromLineage(lineage);

        if (originDosage != generationDosage) {
            return false;
        }

        return true;
    }

    public boolean validateOriginSyntax(String origin) {

        try {
            OriginSyntaxVerifier originSyntaxVerifier = new OriginSyntaxVerifier(origin);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private int getDosageFromLineage(String lineage) {
        int dosage = 0;

        String regex = ">";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        while (matcher.find()) {
            dosage++;
        }

        if (dosage > 0) {
            dosage++;
        }  // because dosage is number of '>' + 1

        return dosage;
    }

    private int getDosageFromOrigin(String origin) throws Exception {
        Integer dosage = null;

        if (null != origin) {
//      OriginSyntaxValidator originSyntaxValidator = new OriginSyntaxValidator(origin);
//      dosage = originSyntaxValidator.getDosage();
            OriginSyntaxVerifier originSyntaxVerifier = new OriginSyntaxVerifier(origin);
            dosage = originSyntaxVerifier.getDosage();

        }

        return (dosage != null) ? dosage.intValue() : 0;
    }
}