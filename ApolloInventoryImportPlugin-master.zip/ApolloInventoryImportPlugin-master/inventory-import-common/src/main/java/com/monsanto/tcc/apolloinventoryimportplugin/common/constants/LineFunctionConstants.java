/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: LineFunctionConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-10-24 21:51:32 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class LineFunctionConstants {
    public static final String A_LINE_FUNCTION = "A";
    public static final String B_LINE_FUNCTION = "B";
    public static final String C_LINE_FUNCTION = "C";
    public static final String R_LINE_FUNCTION = "R";
    public static final String S_LINE_FUNCTION = "S";
    public static final String F_LINE_FUNCTION = "F";
}