package com.monsanto.tcc.apolloinventoryimportplugin.common.serialzerprovider;

import com.monsanto.services.client.common.envelope.EnvelopeXmlSerializerBuilderMappingRegister;
import com.monsanto.services.client.common.filter.FilterXmlSerializerBuilderMappingRegister;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportedTemplateEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.WorklistEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.XMLDateConverter;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventoryEntity;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.xmlserialization.XmlSerializerBuilderMappingRegister;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * Filename:    $RCSfile: RejectedInventoryImportXmlSerializerProvider.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: AAGOSW $     On:$Date: 2008-06-18 14:55:45 $
 *
 * @author DDBROW5
 * @version $Revision: 1.5 $
 */
public class RejectedInventoryImportXmlSerializerProvider implements XmlSerializerProvider {
    public static final String NAMESPACE = "http://www.monsanto.com/inventoryimport/POS";

    public XmlSerializer getXmlSerializer() {
        XmlSerializerBuilder builder = new XmlSerializerBuilder();
        builder.setClassLoader(getClass().getClassLoader());

        registerEnvelopeMappings(builder);
        registerFilterMappings(builder);

        builder.registerMapping(RejectedInventoryImportXmlSerializerProvider.NAMESPACE, "stagingInventoryEntity",
                StagingInventoryEntity.class);
        builder.registerMapping(RejectedInventoryImportXmlSerializerProvider.NAMESPACE, "worklistEntity",
                WorklistEntity.class);
        builder.registerMapping(RejectedInventoryImportXmlSerializerProvider.NAMESPACE, "importedTemplateEntity",
                ImportedTemplateEntity.class);
        builder.addConverter(new XMLDateConverter());
        return builder.createSerializer();
    }

    private void registerEnvelopeMappings(XmlSerializerBuilder builder) {
        createEnvelopeMappingRegister().registerMappings(builder, RejectedInventoryImportXmlSerializerProvider.NAMESPACE);
    }

    private XmlSerializerBuilderMappingRegister createEnvelopeMappingRegister() {
        return new EnvelopeXmlSerializerBuilderMappingRegister();
    }

    private void registerFilterMappings(XmlSerializerBuilder builder) {
        createFilterMappingRegister().registerMappings(builder, RejectedInventoryImportXmlSerializerProvider.NAMESPACE);
    }

    private FilterXmlSerializerBuilderMappingRegister createFilterMappingRegister() {
        return new FilterXmlSerializerBuilderMappingRegister();
    }
}