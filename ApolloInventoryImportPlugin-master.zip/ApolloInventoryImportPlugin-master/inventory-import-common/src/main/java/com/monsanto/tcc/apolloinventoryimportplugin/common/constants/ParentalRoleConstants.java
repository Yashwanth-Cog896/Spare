/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: ParentalRoleConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-11-01 16:23:49 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class ParentalRoleConstants {
    public static final String MALE_PARENTAL_ROLE = "M";
    public static final String FEMALE_PARENTAL_ROLE = "F";
}