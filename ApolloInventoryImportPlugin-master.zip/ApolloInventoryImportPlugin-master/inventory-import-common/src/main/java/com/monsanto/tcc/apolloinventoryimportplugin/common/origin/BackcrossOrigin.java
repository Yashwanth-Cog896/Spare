/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Filename:    $RCSfile: BackcrossOrigin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/11/06 21:08:24 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class BackcrossOrigin extends Origin {
    private static final Log logger = LogFactory.getLog(BackcrossOrigin.class);

    public BackcrossOrigin(String originString) throws InvalidOriginSyntaxException {
        super(originString);
    }

    public String getOriginString() {
        return buildBaseOriginWithoutDosage();
    }

    private String buildBaseOriginWithoutDosage() {
        String originWithoutDosage = null;
        try {
            OriginBuilder builder = new OriginBuilder(originString);
            originWithoutDosage = builder.buildOrigin(0);
        } catch (InvalidOriginSyntaxException e) {
            logger.error("An error occurred building the origin: " + e);
        }
        return originWithoutDosage;
    }
}