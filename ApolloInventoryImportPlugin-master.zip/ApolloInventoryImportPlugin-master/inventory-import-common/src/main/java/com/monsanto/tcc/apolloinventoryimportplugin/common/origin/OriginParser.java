/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.*;

/**
 * Filename:    $RCSfile: OriginParser.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPEYY $     On:$Date:
 * 2007/03/28 20:13:46 $
 *
 * @author apatro
 * @version $Revision: 1.20 $
 */
public class OriginParser {
    private static final Log logger = LogFactory.getLog(OriginParser.class);
    public static final String INVALID_CHARACTERS = "'\"=~?|` ";
    public static final String ASTERISK = "*";
    public static final String VALID_CHARACTERS = "-_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    public static final String INVALID_CHARACTER_MSG = "Found Invalid Character - ";
    public static final String UNBALANCED_PARANTHESIS_MSG = "Found unbalanced parentheses.";
    public static final String INVALID_DELIMITER_MSG = "Found invalid delimiter - ";
    public static final String INVALID_CHARACTER_OTP_MSG = "Found invalid character outside the parentheses - ";
    public static final String ILLEGAL_ARG_EXCEP_MSG = "Origin is required";
    public static final String MORE_THAN_ONE_COMPONENT = "Invalid Origin.More than one component exists in the given origin.";

    private static final String BEGIN_ENCLOSURE = "[";
    private static final String END_ENCLOSURE = "]";

    private static final String DELIMETERS = "/+";
    private static final String OPEN_PARENTHESIS = ")";
    private static final String CLOSED_PARENTHESIS = "(";
    private static final char NULL_CHAR = '\0';
    private static final String DELIMITER_DIGITS = "3456789";

    private String[] VALID_DELIMITERS;
    private List componentList;

    private StringBuffer component;
    private boolean foundDelimeter;
    private boolean foundAsterisk;
    private Stack stack;

    private String validDelimiters = DELIMETERS;
    private String invalidDelimiters = "";
    private boolean delimitersSet = false;


    private OriginEntity entity;
    private int entityDisplayLevel = 0;
    private String[] delimitersInCurrentOrigin;
    private Map validDelimiterIndexMap;
    private List componentListForOriginalOrigin;
    private String backSlashDelimiter = C_LINE_DELIMITER;
    private static final String NON_HYBRID_DELIMITERS = "/\\";
    private static final String HYBRID_DELIMITER = "+";
    private static final String DEV_CROSS_DELIMITER = "/";
    private static final String C_LINE_DELIMITER = "\\";

    public OriginParser(String origin) throws InvalidOriginSyntaxException {
        this(origin, 0);
    }

    public OriginParser(String origin, int initialEntityDisplayLevel) throws InvalidOriginSyntaxException {
        entityDisplayLevel = initialEntityDisplayLevel;
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(ILLEGAL_ARG_EXCEP_MSG);
        }
        componentList = new ArrayList();
        parse(origin);
        componentListForOriginalOrigin = componentList;

        if (NON_HYBRID_DELIMITERS.equals(validDelimiters)) {
            VALID_DELIMITERS = new String[]{DEV_CROSS_DELIMITER, "//", "/3/", "/4/", "/5/", "/6/", "/7/", "/8/", "/9/",
                    C_LINE_DELIMITER};
        } else {
            VALID_DELIMITERS = new String[]{HYBRID_DELIMITER, "++", "+3+", "+4+", "+5+", "+6+", "+7+", "+8+", "+9+"};
        }
        multipleComponentCheck();
        entity = new OriginEntity(origin);
        entity.setLevel(entityDisplayLevel);
        generateOrigins(entity);
    }

    private void multipleComponentCheck() throws InvalidOriginSyntaxException {
        boolean delimeterEncountered = true;
        String[] components = getComponents();
        for (int i = 0; i < components.length; i++) {
            String s = components[i];
            if (s.startsWith(ASTERISK)) {
                delimeterEncountered = true;
            } else if (isDelimiter(s)) {
                delimeterEncountered = true;
            } else {
                checkForMultipleComponents(delimeterEncountered);
                delimeterEncountered = false;
            }
        }
    }

    private void checkForMultipleComponents(boolean delimeterEncountered) throws InvalidOriginSyntaxException {
        if (!delimeterEncountered) {
            throw new InvalidOriginSyntaxException(MORE_THAN_ONE_COMPONENT);
        }

    }


    public String[] getComponents() {
        return (String[]) componentListForOriginalOrigin.toArray(new String[0]);
    }

    private String[] getCurrentComponentArray() {
        return (String[]) componentList.toArray(new String[0]);
    }

    public String[] getValidDelimiters() {
        return (String[]) VALID_DELIMITERS.clone();
    }

    public OriginEntity getOriginTree() {
        return entity;
    }

    private void generateOrigins(OriginEntity entity) {
        try {
            if (entity != null && entity.getOrigin().length() > 0) {
                delimitersInCurrentOrigin = (String[]) new ArrayList().toArray(new String[0]);
                componentList = new ArrayList();
                parse(entity.getOrigin());
                initValidDelimiterIndexMap(getValidDelimiters());
                initDelimiters();
                buildOrigin(entity);
            }
        } catch (InvalidOriginSyntaxException e) {
            logger.error("An error occurred generating origins: " + e);
        }
    }

    private void buildOrigin(OriginEntity entity) {
        String highestOrderDelimiter = getHighestOrderDelimiter();
        if (highestOrderDelimiter != null) {

            entity.setOperator(highestOrderDelimiter);
            entity.setDelimitersInOrigin(delimitersInCurrentOrigin);
            String leftEntityString = getLeftEntityStringOfHighestOrder(highestOrderDelimiter);

            OriginEntity leftEntity = new OriginEntity(leftEntityString);
            leftEntity.setChildEntity(entity);

            String rightEntityString = getRightEntityStringOfHigestOrder(highestOrderDelimiter);
            OriginEntity rightEntity = new OriginEntity(rightEntityString);
            rightEntity.setChildEntity(entity);

            if ("\\".equals(highestOrderDelimiter)) {
                entity.setMaleParent(leftEntity);
                entity.setFemaleParent(rightEntity);
            } else {
                entity.setFemaleParent(leftEntity);
                entity.setMaleParent(rightEntity);
            }
            entity.getFemaleParent().setLevel(++entityDisplayLevel);
            entity.getFemaleParent().setParentalRole("F");
            generateOrigins(entity.getFemaleParent());
            entity.getMaleParent().setLevel(++entityDisplayLevel);
            entity.getMaleParent().setParentalRole("M");
            generateOrigins(entity.getMaleParent());

        } else {
            entity.setLeafEntity(true);
        }

    }

    private String getLeftEntityStringOfHighestOrder(String highestOrderDelimiter) {
        int hoValidDelimiterIndex = getIndexOfHighestOrderDelimiter(getCurrentComponentArray(), highestOrderDelimiter);
        StringBuffer femaleEntity = new StringBuffer();
        for (int i = 0; i < hoValidDelimiterIndex; i++) {
            femaleEntity.append(getCurrentComponentArray()[i]);
        }
        return femaleEntity.toString();
    }

    private String getRightEntityStringOfHigestOrder(String highestOrderDelimiter) {
        int hoValidDelimiterIndex = getIndexOfHighestOrderDelimiter(getCurrentComponentArray(), highestOrderDelimiter);
        StringBuffer maleEntity = new StringBuffer();
        if (hoValidDelimiterIndex > -1) {
            for (int i = hoValidDelimiterIndex + 1; i < getCurrentComponentArray().length; i++) {
                maleEntity.append(getCurrentComponentArray()[i]);
            }
        }
        return maleEntity.toString();
    }

    private void initValidDelimiterIndexMap(String[] validDelimiters) {
        validDelimiterIndexMap = new HashMap();
        for (int i = 0; i < validDelimiters.length; i++) {
            String validDelimiter = validDelimiters[i];
            validDelimiterIndexMap.put(validDelimiter, new Integer(i));
        }
    }

    private void initDelimiters() {
        List delimiterList = new ArrayList();
        for (int i = 0; i < getCurrentComponentArray().length; i++) {
            String component = getCurrentComponentArray()[i];
            if (isDelimiter(component)) {
                delimiterList.add(component);
            }
        }
        if (delimiterList.size() > 0) {
            delimitersInCurrentOrigin = (String[]) delimiterList.toArray(new String[0]);
        }
    }

    private boolean isDelimiter(String s) {
        for (int i = 0; i < getValidDelimiters().length; i++) {
            String validDelimiter = getValidDelimiters()[i];
            if (validDelimiter.equals(s)) {
                return true;
            }
        }
        return false;
    }

    private String getHighestOrderDelimiter() {
        int maxIndex = -1;
        if (delimitersInCurrentOrigin != null) {
            for (int i = 0; i < delimitersInCurrentOrigin.length; i++) {
                String delimiter = delimitersInCurrentOrigin[i];
                maxIndex = Math.max(maxIndex, ((Integer) validDelimiterIndexMap.get(delimiter)).intValue());
            }
        }

        return (maxIndex > -1) ? getValidDelimiters()[maxIndex] : null;
    }

    private int getIndexOfHighestOrderDelimiter(String[] componentArray, String highestOrderDelimiter) {
        if (componentArray != null) {
            for (int i = 0; i < componentArray.length; i++) {
                if (componentArray[i].equals(highestOrderDelimiter)) {
                    return i;
                }
            }
        }
        return -1;
    }


    private void parse(String origin) throws InvalidOriginSyntaxException {
        char[] originChar = origin.toCharArray();

        initializeStack();
        initializeComponent();
        foundDelimeter = false;
        foundAsterisk = false;
        int originLength = originChar.length;
        for (int i = 0; i < originLength; i++) {
            char c = originChar[i];

            if (matchesInvalidCharacter(c)) {
                throw new InvalidOriginSyntaxException(INVALID_CHARACTER_MSG + BEGIN_ENCLOSURE + c + END_ENCLOSURE);
            }

            char lookAheadChar = getLookAheadChar(originChar, i);

            if (matchesOpenParenthesis(c)) {
                pushParenthesis(c);
            } else if (matchesClosedParenthesis(c)) {
                popParenthesis(c);
            } else if (insideParenthesis()) {
                addToComponent(c);
            } else {
                matchOutsideParenthesis(c, lookAheadChar);
            }
        }

        if (insideParenthesis()) {
            throw new InvalidOriginSyntaxException(UNBALANCED_PARANTHESIS_MSG);
        } else if (getComponentLength() > 0) {
            addComponentTolist();
        }
    }

    private char getLookAheadChar(char[] origin, int currentIndex) {
        int maxIndex = Math.min(currentIndex + 2, origin.length);
        int length = maxIndex - (currentIndex + 1);
        char lookAheadChar = NULL_CHAR;
        if (length > 0) {
            for (int i = currentIndex + 1; i < maxIndex; i++) {
                lookAheadChar = origin[i];
            }
        }

        return lookAheadChar;
    }

    private boolean insideParenthesis() {
        return !stack.empty();
    }

    private void popParenthesis(char c) throws InvalidOriginSyntaxException {
        if (insideParenthesis()) {
            stack.pop();
        } else {
            throw new InvalidOriginSyntaxException(UNBALANCED_PARANTHESIS_MSG);
        }
        addToComponent(c);
        if (stack.empty()) {
            addComponentToListAndReinitialize();
        }
    }

    private void pushParenthesis(char c) {
        if (getComponentLength() > 0 && stack.empty()) {
            addComponentToListAndReinitialize();
        }
        stack.push(new Character(c));
        addToComponent(c);
    }

    private void matchOutsideParenthesis(char c, char lookAheadChar) throws InvalidOriginSyntaxException {
        if (matchesAsterisk(c) && !foundAsterisk) {
            if (getComponentLength() > 0) {
                addComponentToListAndReinitialize();
            }
            foundAsterisk = true;
            addToComponent(c);
        } else if (matchesInvalidDelimeter(c)) {
            throw new InvalidOriginSyntaxException(INVALID_DELIMITER_MSG + BEGIN_ENCLOSURE + c + END_ENCLOSURE);
        } else if (matchesValidDelimeter(c)) {
            foundAsterisk = false;
            if (getComponentLength() > 0 && !foundDelimeter) {
                addComponentToListAndReinitialize();
            }
            addToComponent(c);
            foundDelimeter = true;
        } else if (foundAsterisk) {
            addToComponent(c);
        } else {
            if (foundDelimeter) {
                if (lookAheadIsPartOfExtendedDelimiter(lookAheadChar, c)) {
                    addToComponent(c);
                    return;
                }
                foundDelimeter = false;
                addComponentToListAndReinitialize();
            }
            if (!matchesValidCharacter(c)) {
                throw new InvalidOriginSyntaxException(INVALID_CHARACTER_OTP_MSG + BEGIN_ENCLOSURE + c + END_ENCLOSURE);
            }
            addToComponent(c);
        }
    }

    private void initializeStack() {
        stack = new Stack();
    }

    private void initializeComponent() {
        component = new StringBuffer();
    }

    private void addToComponent(char c) {
        component.append(c);
    }

    private int getComponentLength() {
        return component.length();
    }

    private void addComponentToListAndReinitialize() {
        addComponentTolist();
        initializeComponent();
    }

    private void addComponentTolist() {
        componentList.add(component.toString());
    }

    private boolean lookAheadIsPartOfExtendedDelimiter(char lookAheadChar, char c) {
        if (lookAheadChar != NULL_CHAR && matchesValidDelimeter(lookAheadChar)) {
            if (matchesDigit(c) && getComponentLength() == 1) {
                return true;
            }
        }
        return false;
    }

    private boolean matchesDigit(char c) {
        return DELIMITER_DIGITS.indexOf(c) > -1;
    }

    private boolean matchesValidCharacter(char c) {
        return VALID_CHARACTERS.indexOf(c) > -1;
    }

    private boolean matchesAsterisk(char c) {
        return ASTERISK.indexOf(c) > -1;
    }

    private boolean matchesValidDelimeter(char c) {
        boolean matched = validDelimiters.indexOf(c) > -1 || backSlashDelimiter.indexOf(c) > -1;

        if (!delimitersSet && matched) {
            //invalidDelimiters = getInvalidDelimiters(c);
            if (DEV_CROSS_DELIMITER.equals(new String(new char[]{c})) || C_LINE_DELIMITER.equals(new String(new char[]{c}))) {
                validDelimiters = NON_HYBRID_DELIMITERS;
                invalidDelimiters = HYBRID_DELIMITER;
            } else {
                validDelimiters = new String(new char[]{c});
                invalidDelimiters = NON_HYBRID_DELIMITERS;
            }
            delimitersSet = true;
        }
        return matched;
    }

    private boolean matchesInvalidDelimeter(char c) {
        return invalidDelimiters.indexOf(c) > -1;
    }

    private boolean matchesClosedParenthesis(char c) {
        return OPEN_PARENTHESIS.indexOf(c) > -1;
    }

    private boolean matchesOpenParenthesis(char c) {
        return CLOSED_PARENTHESIS.indexOf(c) > -1;
    }

    private boolean matchesInvalidCharacter(char c) {
        return INVALID_CHARACTERS.indexOf(c) > -1;
    }


}