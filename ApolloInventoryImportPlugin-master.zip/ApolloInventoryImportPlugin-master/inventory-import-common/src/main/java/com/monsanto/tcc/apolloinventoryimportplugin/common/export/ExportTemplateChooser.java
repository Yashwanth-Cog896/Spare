package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;

/**
 * Filename:    $RCSfile: ExportTemplateChooser.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: sspeyy $     On:$Date: 2007-07-09 19:35:43 $
 *
 * @author DDBROW5
 * @version $Revision: 1.7 $
 */
public class ExportTemplateChooser {
    private static final Log logger = LogFactory.getLog(ExportTemplateChooser.class);

    public static final String DEFAULT_TEMPLATE_FILE = "Template.xls";
    public static final String UNKNOWN_TYPE_MSG = "Cannot determine the template from material type: ";
    public static final String NULL_MATERIAL_TYPE_MSG = "Cannot determine the template from null material type.";

    protected HSSFWorkbook workBook = null;
    protected Hashtable workSheets = null;

    public ExportTemplateChooser() throws ExcelExportException {
        workSheets = new Hashtable();
        openWorkBook(DEFAULT_TEMPLATE_FILE);
    }

    private void openWorkBook(String fileName) throws ExcelExportException {
        if (null == fileName || 0 == fileName.trim().length()) {
            throw new ExcelExportException("File name cannot be null");
        }
        InputStream inpStream = this.getClass().getResourceAsStream(fileName);
        if (null != inpStream) {
            try {
                POIFSFileSystem fs = new POIFSFileSystem(inpStream);
                workBook = new HSSFWorkbook(fs);
                int i;
                int numberOfSheets = workBook.getNumberOfSheets();
                for (i = 0; i < numberOfSheets; i++) {
                    workSheets.put(workBook.getSheetName(i).toUpperCase(), workBook.getSheetAt(i));
                }
            }
            catch (FileNotFoundException fnfe) {
                logger.error("Error finding template: " + fnfe);
                throw new ExcelExportException("Cannot find template file '" + fileName + "' to open.");
            }
            catch (IOException ioe) {
                logger.error("Error reading template: " + ioe);
                throw new ExcelExportException("Cannot read template file '" + fileName + "'.");
            }
        }
    }

    public AbstractTemplate getTemplate(String workSheetName) throws ExcelExportException {
        if (null == workSheetName) {
            throw new ExcelExportException(NULL_MATERIAL_TYPE_MSG);
        }
        AbstractTemplate template = null;
        if (workSheets.containsKey(workSheetName.toUpperCase())) {
            HSSFSheet sheet = (HSSFSheet) workSheets.get(workSheetName.toUpperCase());
            if ("COMMERCIAL".equals(workSheetName.toUpperCase())) {
                template = new CommercialTemplate(workBook, sheet);
            } else if ("COMPETITOR".equals(workSheetName.toUpperCase())) {
                template = new CompetitorTemplate(workBook, sheet);
            } else if ("FINISHED".equals(workSheetName.toUpperCase())) {
                template = new FinishedTemplate(workBook, sheet);
            } else if ("CODED".equals(workSheetName.toUpperCase())) {
                template = new CodedTemplate(workBook, sheet);
            } else if ("SEGPOP".equals(workSheetName.toUpperCase())) {
                template = new SegpopTemplate(workBook, sheet);
            } else if ("HYBRID".equals(workSheetName.toUpperCase())) {
                template = new HybridTemplate(workBook, sheet);
            } else if ("ICB MALE".equals(workSheetName.toUpperCase())) {
                template = new ICBMaleTemplate(workBook, sheet);
            }
        }
        if (null == template) {
            throw new ExcelExportException(UNKNOWN_TYPE_MSG + workSheetName);
        }
        return template;
    }

}
