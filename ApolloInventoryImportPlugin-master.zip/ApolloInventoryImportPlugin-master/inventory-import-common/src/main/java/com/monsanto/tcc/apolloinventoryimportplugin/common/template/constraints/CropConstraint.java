package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.TQRequiredCrops;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.InventoryImportConstants;

import java.util.Arrays;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MTJOHN1
 * Date: 2/14/12
 * Time: 4:22 PM
 */
public class CropConstraint implements DataConstraint {
    private String subject;
    //    private String[] checkedCrops;
    private String thisCrop;
    private String messageToDisplayOnFailure;

    public CropConstraint(String subject, String thisCrop) {
        if (StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject is required.");
        }

        this.subject = subject;
//        this.checkedCrops = checkedCrops;
        this.thisCrop = thisCrop;
        this.messageToDisplayOnFailure = "No value is specified for " + subject;
    }

    @Override
    public boolean validate(Map dataSource) {
        if (!Arrays.asList(TQRequiredCrops.getRequiredCrops()).contains(thisCrop)) {
            return true;
        } else {
            return !(StringUtils.isNullOrEmpty((String) dataSource.get(subject))
                    || dataSource.get(subject).equals(InventoryImportConstants.DEFAULT_STRING));
        }
    }

    @Override
    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        this.messageToDisplayOnFailure = messageToDisplayOnFailure;
    }

    @Override
    public String getMessageToDisplayOnFailure() {
        return this.messageToDisplayOnFailure;
    }

    public String getCropName() {
        return thisCrop;
    }

    public void setCropName(String cropName) {
        this.thisCrop = cropName;
    }
}
