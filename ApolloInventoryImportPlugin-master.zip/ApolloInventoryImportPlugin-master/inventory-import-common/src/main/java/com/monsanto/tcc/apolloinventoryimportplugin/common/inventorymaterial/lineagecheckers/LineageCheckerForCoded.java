/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.lineagecheckers;

import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.LineageSyntaxChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;

import java.util.List;

/**
 * Filename:    $RCSfile: LineageCheckerForCoded.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-06-19 15:32:39 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class LineageCheckerForCoded {
    public static final String LINEAGE_HAS_MORE_THAN_ONE_PIPE_MSG = "Coded lines can contain only one pipe " +
            "in the lineage.";
    public static final String LINEAGE_IS_PIPE_MSG = "Lineage cannot be just a pipe";
    public static final String ONE_PIPE_REQ_MSG = "Lineage must have at least one pipe.";
    private String lineage;
    private String lineFunctionRefId;

    public LineageCheckerForCoded(String lineage, String lineFunctionRefId) {
        this.lineage = lineage;
        this.lineFunctionRefId = lineFunctionRefId;
    }

    public void check(List msgList) {
        LineageSyntaxChecker lineageSyntaxChecker = new LineageSyntaxChecker(lineage);

        if (lineageSyntaxChecker.checkLineageIsAPipe()) {
            msgList.add(LINEAGE_IS_PIPE_MSG);
            return;
        }


        if (!lineageSyntaxChecker.checkLineageHasAtleastOnePipe()) {
            msgList.add(ONE_PIPE_REQ_MSG);
            return;
        }

        try {
            lineageSyntaxChecker.validateLineageHasValidCharacters();
            lineageSyntaxChecker.validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbols(lineFunctionRefId);
            lineageSyntaxChecker.checkLineageHasNoMoreThanOnePipe();
            lineageSyntaxChecker.validateLineageBeginsWithAtCharOrNumberWithOptionalAlphaCharacters();
            lineageSyntaxChecker.validateLineageHasCycleMarkersWithValidPrefix();
        }
        catch (LineageSyntaxException e) {
            msgList.add(e.getMessage());
            return;
        }
    }
}