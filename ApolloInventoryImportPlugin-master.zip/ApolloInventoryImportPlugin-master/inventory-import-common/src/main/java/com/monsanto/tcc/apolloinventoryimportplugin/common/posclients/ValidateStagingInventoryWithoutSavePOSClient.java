/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: ValidateStagingInventoryWithoutSavePOSClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-03 20:41:48 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class ValidateStagingInventoryWithoutSavePOSClient extends AbstractPOSClient {
    private static final String POS_ACTIVITY = "ValidateStagingInventoryDataWithoutSave";

    public ValidateStagingInventoryWithoutSavePOSClient() {
        super.setPosActivityName(POS_ACTIVITY);
    }

    public StagingInventory validateStagingInventory(StagingInventory stagingInventory) throws ActivityClientException {
        sendToPos(createCompositeObject(stagingInventory));
        checkForErrorResponse();
        return getValidatedStagingInventory();
    }

    private StagingInventory getValidatedStagingInventory() {
        return (StagingInventory) getResponseEnvelope().getFirst(StagingInventory.class);
    }

    private CompositeObject createCompositeObject(StagingInventory stagingInventory) {
        CompositeObject payload = new CompositeObject();
        payload.add(getFilterWithDefaultFilterId());
        unsetInventoryOnHeader(stagingInventory);
        setImportType(stagingInventory);
        payload.add(stagingInventory);
        return payload;
    }

    private void unsetInventoryOnHeader(StagingInventory inventory) {
        if (inventory != null && inventory.getInventoryHeader() != null) {
            inventory.getInventoryHeader().setStagingInventory(null);
        }
    }

    private void setImportType(StagingInventory inventory) {
        if (inventory != null && inventory.getImportType() != null) {
            inventory.setImportType(getNewImportType(inventory.getImportType()));
        }
    }

    private ImportType getNewImportType(ImportType importType) {
        ImportType newImportType = new ImportType();
        newImportType.setAbbreviation(importType.getAbbreviation());
        return newImportType;
    }
}