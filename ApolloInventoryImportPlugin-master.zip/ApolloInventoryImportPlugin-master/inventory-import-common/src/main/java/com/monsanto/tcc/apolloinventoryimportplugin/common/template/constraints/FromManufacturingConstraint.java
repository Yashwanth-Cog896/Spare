package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

/**
 * Created by IntelliJ IDEA.
 * User: MTJOHN1
 * Date: 2/24/12
 * Time: 3:24 PM
 */
public class FromManufacturingConstraint {
    public static DataConstraint getConstraint(String cropName) {
        return new AndDataConstraint(
                new DataConstraint[]{
                        new CropConstraint("From Manufacturing?", cropName),
                        new PredicateDataConstraint(
                                new DataConstraint[]{
                                        new CheckConstraint("From Manufacturing?", "T")
                                },
                                new DataConstraint[]{
                                        new NotNullConstraint("Manufacturing Batch #?")
                                }
                        )
                });
    }
}
