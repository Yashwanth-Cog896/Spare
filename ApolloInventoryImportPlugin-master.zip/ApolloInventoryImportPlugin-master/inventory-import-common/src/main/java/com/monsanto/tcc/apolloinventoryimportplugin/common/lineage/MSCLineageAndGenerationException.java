/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

/**
 * Filename:    $RCSfile: MSCLineageAndGenerationException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-11-12 20:54:44 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class MSCLineageAndGenerationException extends Exception {
    public MSCLineageAndGenerationException() {
    }

    public MSCLineageAndGenerationException(String message) {
        super(message);
    }

    public MSCLineageAndGenerationException(String message, Throwable cause) {
        super(message, cause);
    }

    public MSCLineageAndGenerationException(Throwable cause) {
        super(cause);
    }
}