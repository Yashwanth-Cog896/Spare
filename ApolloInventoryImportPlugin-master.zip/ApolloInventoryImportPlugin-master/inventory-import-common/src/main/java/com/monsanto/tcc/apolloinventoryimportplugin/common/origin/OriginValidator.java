/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.LineageFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.OriginLineageDosageMismatchException;

/**
 * Filename:    $RCSfile: OriginValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:$Date:
 * 2007/03/29 23:32:16 $
 *
 * @author APATRO
 * @version $Revision: 1.14 $
 */
public class OriginValidator {
    private static final String ORIGIN_LINEAGE_DOSAGE_MISMATCH = "Origin does not match the given Lineage";

    public void validateOriginSyntax(String origin, String lineage, String generation, String buildParentage) throws
            InvalidOriginSyntaxException, InvalidLineageException, OriginLineageDosageMismatchException {
        if (getDosageFromOrigin(origin) != getDosageFromLineage(lineage)) {
            throw new OriginLineageDosageMismatchException(ORIGIN_LINEAGE_DOSAGE_MISMATCH);
        }
    }

    protected int getDosageFromLineage(String lineage) throws InvalidLineageException {
        return new LineageFactory().createLineage(lineage).getDosage();
    }

    protected int getDosageFromOrigin(String origin) throws InvalidOriginSyntaxException {
        return new OriginFactory().createOrigin(origin).getDosage();
    }
}