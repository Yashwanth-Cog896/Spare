package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 9, 2009
 * Time: 9:28:47 AM
 * To change this template use File | Settings | File Templates.
 */

/**
 * Filename:    $RCSfile: CLineLineage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-11-05 20:47:22 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class CLineLineage implements Lineage {
    public static final String DOSAGE_PATTERN_STRING = ">";
    public static final String PIPE_STRING = "|";
    public static final String BACKCROSS_ONLY_CYCLE_MARKER_ERROR = DOSAGE_PATTERN_STRING + " is the only valid C line lineage cycle marker";
    public static final String SINGLE_LINEAGE_NULL_OR_PIPE_ERROR = PIPE_STRING + " is the only valid single character C line lineage";
    private String lineage;

    public CLineLineage(String lineage) throws InvalidLineageException {
        this.lineage = lineage;
        trimLineageIfNotNull();
        validate();
    }

    private void validate() throws InvalidLineageException {
        checkForInvalidCharacters();
        if (!isBackcrossOnlyCycleMarker()) {
            throw new InvalidLineageException(BACKCROSS_ONLY_CYCLE_MARKER_ERROR);
        }
        if (getLengthOfLineageString() == 1 && !isLineageNullOrPipe()) {
            throw new InvalidLineageException(SINGLE_LINEAGE_NULL_OR_PIPE_ERROR);
        }
    }

    public int getDosage() {
        if (isLineageNullOrEmpty()) {
            return new NullLineage().getDosage();
        }
        return new NotNullLineage(lineage).getDosage();
    }

    public int getNumberOfCycleMarkers() {
        return getCycleMarkers() != null ? getCycleMarkers().length : 0;
    }

    public boolean isBackcross() {
        if (isLineageNullOrEmpty()) {
            return new NullLineage().isBackcross();
        }
        return new NotNullLineage(lineage).isBackcross();
    }

    public boolean isLineageNullOrPipe() {
        return isLineageNullOrEmpty() || isLineagePipe();
    }

    public boolean isLineagePipe() {
        if (isLineageNullOrEmpty()) {
            return new NullLineage().isLineagePipe();
        }
        return new NotNullLineage(lineage).isLineagePipe();
    }

    public String[] getCycleMarkers() {
        String[] cycleMarkers = new String[0];
        if (!isLineageNullOrEmpty()) {
            cycleMarkers = new NotNullLineage(lineage).getCycleMarkers();
        }
        return cycleMarkers;
    }

    private boolean isBackcrossOnlyCycleMarker() {
        boolean status = true;
        if (getCycleMarkers() != null) {
            String[] cycleMarkers = getCycleMarkers();
            for (int i = 0; i < cycleMarkers.length; i++) {
                if (!DOSAGE_PATTERN_STRING.equals(cycleMarkers[i])) {
                    status = false;
                    break;
                }
            }
        }
        return status;
    }

    public boolean isLineageNullOrEmpty() {
        return StringUtils.isNullOrEmpty(lineage);
    }

    private void checkForInvalidCharacters() throws InvalidLineageException {
        if (!StringUtils.isNullOrEmpty(lineage)) {
            try {
                new LineageSyntaxChecker(lineage).validateLineageHasValidCharacters();
            } catch (LineageSyntaxException e) {
                throw new InvalidLineageException(e);
            }
        }
    }

    private int getLengthOfLineageString() {
        return lineage == null ? 0 : lineage.length();
    }

    private void trimLineageIfNotNull() {
        if (!isLineageNullOrEmpty()) {
            lineage = lineage.trim();
        }
    }
}

