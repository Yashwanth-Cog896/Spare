package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: CommercialTemplate.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:08 $
 *
 * @author DDBROW5
 * @version $Revision: 1.9 $
 */
public class CommercialTemplate extends AbstractTemplate {
    public CommercialTemplate(HSSFWorkbook workBook, HSSFSheet workSheet) {
        if (null == workBook) {
            throw new IllegalArgumentException("Work book cannot be null");
        }
        if (null == workSheet) {
            throw new IllegalArgumentException("Work sheet cannot be null");
        }
        this.workBook = workBook;
        this.workSheet = workSheet;
        workSheetMetaData = new WorkSheetMetaData();
        workSheetMetaData.addColumn("getProductName", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getOrigin", HSSFCell.CELL_TYPE_STRING, "getLineCode", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getLineType", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getSource", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getInventoryOwner", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getVegetativeStructure", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getLineFunction", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getCytoplasmDonorPedigree", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getBrandName", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getTransgenic", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getMfgBatchNumber", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getRoyalty", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getCompany", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getExternalGermplasmName", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getSeedQuantity", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getSeedQuantityUOM", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getAsort1", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getAsort2", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getAsort3", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getAsort4", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getAsort5", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getNsort1", HSSFCell.CELL_TYPE_NUMERIC);
        workSheetMetaData.addColumn("getNsort2", HSSFCell.CELL_TYPE_NUMERIC);
        workSheetMetaData.addColumn("getNsort3", HSSFCell.CELL_TYPE_NUMERIC);
        workSheetMetaData.addColumn("getNsort4", HSSFCell.CELL_TYPE_NUMERIC);
        workSheetMetaData.addColumn("getNsort5", HSSFCell.CELL_TYPE_NUMERIC);
        workSheetMetaData.addColumn("getSrcLotNumber", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getComments", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getFemaleParentSource", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getMaleParentSource", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getValidationMessage", HSSFCell.CELL_TYPE_STRING);
        workSheetMetaData.addColumn("getRejectionReason", HSSFCell.CELL_TYPE_STRING);
        numberOfColumns = workSheetMetaData.size();
    }
}
