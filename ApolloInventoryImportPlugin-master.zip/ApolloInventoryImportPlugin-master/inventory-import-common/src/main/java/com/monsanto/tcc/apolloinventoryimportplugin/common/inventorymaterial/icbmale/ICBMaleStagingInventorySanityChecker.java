/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.icbmale;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionValuesICBMaleSanityCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;

/**
 * Filename:    $RCSfile: ICBMaleStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:09 $
 *
 * @author SSPEYY
 * @version $Revision: 1.3 $
 */
public class ICBMaleStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    private StagingInventory stagingInventory = null;

    public ICBMaleStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);
        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getSource())) {
            msgList.add(MANDATORY_CHECK_MSG + "Source");
        }
        if (StringUtils.isNullOrEmpty(stagingInventory.getPedigreeName())) {
            msgList.add(MANDATORY_CHECK_MSG + "Pedigree");
        }
        if (StringUtils.isNullOrEmpty(stagingInventory.getIcbMale())) {
            msgList.add(MANDATORY_CHECK_MSG + "ICB Male");
        }
        new AllowedLineFunctionValuesICBMaleSanityCheck(stagingInventory.getLineFunction()).check(msgList);
    }
}