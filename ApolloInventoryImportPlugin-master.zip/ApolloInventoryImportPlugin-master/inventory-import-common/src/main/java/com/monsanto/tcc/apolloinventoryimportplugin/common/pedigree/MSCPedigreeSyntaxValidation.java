/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.CrossOperatorConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.ALineLineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.LineageSyntaxChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidALineMSCLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.Origin;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginParser;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: MSCPedigreeSyntaxValidation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2008-06-19 16:07:24 $
 *
 * @author SSPEYY
 * @version $Revision: 1.7 $
 */
public class MSCPedigreeSyntaxValidation {
    public static final String INVALID_PEDIGREE_MSG = "Invalid pedigree string";
    public static final String PEDIGREE_REQUIRED_MSG = "Pedigree is required";
    public static final String INVALID_GERMPLASM_OWNER_MSG = " Germplasm Owner can only contain at most 3 characters.";
    private String pedigree;
    private String lineageString;
    private String originOrLineCodeString;
    private String germplasmOwnerString;
    private PedigreeParser pedigreeParser;

    public MSCPedigreeSyntaxValidation(String pedigree) throws PedigreeSyntaxException {
        if (StringUtils.isNullOrEmpty(pedigree)) {
            throw new IllegalArgumentException(PEDIGREE_REQUIRED_MSG);
        }
        pedigreeParser = new PedigreeParser(pedigree);
        this.pedigree = pedigree;
        init();
        doBasicPedigreeValidations();
        validateRequiredElements();
    }

    private void init() {
        germplasmOwnerString = pedigreeParser.getGermplasmOwnerString();
        lineageString = pedigreeParser.getLineageString();
        originOrLineCodeString = pedigreeParser.getOriginOrLineCodeString();
    }

    private void doBasicPedigreeValidations() throws PedigreeSyntaxException {
        validateGermplasmOwner();
        validateOrigin();
        validateLineage();
    }

    private void validateRequiredElements() throws PedigreeSyntaxException {
        if (isGermplasmOwnerNull() && !isOriginOrLineCodeNull() && isLineageNull()) {
            try {
                if (!isOriginValid()) {
                    throw new PedigreeSyntaxException(INVALID_PEDIGREE_MSG + ".  Origin cannot appear alone [" + pedigree + "]");
                }
            } catch (InvalidOriginSyntaxException e) {
                throw new PedigreeSyntaxException(INVALID_PEDIGREE_MSG + ".  " + e.getMessage() + " [" + pedigree + "]");
            }
        }
    }

    private void validateLineage() throws PedigreeSyntaxException {
        if (!StringUtils.isNullOrEmpty(lineageString)) {
            try {
                LineageSyntaxChecker lineageSyntaxChecker = new LineageSyntaxChecker(lineageString);
                lineageSyntaxChecker.validateLineageHasValidCharacters();
                lineageSyntaxChecker.validateLineageBeginsWithAtCharOrNumberWithOptionalAlphaCharacters();
                lineageSyntaxChecker.validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbols(LineFunctionConstants.A_LINE_FUNCTION);
                new ALineLineage(lineageString);
            } catch (LineageSyntaxException e) {
                throw new PedigreeSyntaxException(e);
            } catch (InvalidALineMSCLineageException e) {
                throw new PedigreeSyntaxException(INVALID_PEDIGREE_MSG + " [" + pedigree + "]");
            }
        } else {
            if (pedigree.endsWith(":")) {
                throw new PedigreeSyntaxException(INVALID_PEDIGREE_MSG + " [" + pedigree + "]");
            }
        }
    }

    private void validateOrigin() throws PedigreeSyntaxException {
        if (!StringUtils.isNullOrEmpty(originOrLineCodeString)) {
            try {
                new Origin(originOrLineCodeString);
            } catch (InvalidOriginSyntaxException e) {
                throw new PedigreeSyntaxException(e);
            }
        } else {
            throw new PedigreeSyntaxException(INVALID_PEDIGREE_MSG + " [" + pedigree + "]");
        }
    }

    private void validateGermplasmOwner() throws PedigreeSyntaxException {
        if (!StringUtils.isNullOrEmpty(germplasmOwnerString) && germplasmOwnerString.length() > 3) {
            throw new PedigreeSyntaxException(INVALID_GERMPLASM_OWNER_MSG);
        }
    }

    private boolean isGermplasmOwnerNull() {
        return StringUtils.isNullOrEmpty(germplasmOwnerString);
    }

    private boolean isOriginOrLineCodeNull() {
        return StringUtils.isNullOrEmpty(originOrLineCodeString);
    }

    private boolean isLineageNull() {
        return StringUtils.isNullOrEmpty(lineageString);
    }

    private boolean isOriginValid() throws InvalidOriginSyntaxException {
        boolean isOriginValid = true;
        if (!StringUtils.isNullOrEmpty(originOrLineCodeString)) {
            isOriginValid = isOriginLineCode(getOriginTree()) && !isOriginSegpop(getOriginTree());
        }
        return isOriginValid;
    }


    private boolean isOriginLineCode(OriginEntity originTree) throws InvalidOriginSyntaxException {
        return StringUtils.isNullOrEmpty(originTree.getOperator());
    }

    private boolean isOriginSegpop(OriginEntity originTree) throws InvalidOriginSyntaxException {
        return !StringUtils.isNullOrEmpty(originTree.getOperator()) &&
                CrossOperatorConstants.DEV_CROSS_OPERATOR.equals(originTree.getOperator());
    }

    private OriginEntity getOriginTree() throws InvalidOriginSyntaxException {
        return getOriginParser().getOriginTree();
    }

    private OriginParser getOriginParser() throws InvalidOriginSyntaxException {
        return new OriginParser(originOrLineCodeString);
    }
}