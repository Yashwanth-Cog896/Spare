/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception;

/**
 * Filename:    $RCSfile: InvalidCLineGenerationException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $
 * On:$Date: 2008-01-30 20:52:21 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class InvalidCLineGenerationException extends Exception {
    public InvalidCLineGenerationException(String invalidGenerationMsg) {
        super(invalidGenerationMsg);
    }
}