package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: ExcelTemplateBuilder.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-07-05 17:45:12 $
 *
 * @author ddbrow5
 * @version $Revision: 1.10 $
 */
public class ExcelTemplateBuilder {
    private static final Log logger = LogFactory.getLog(ExcelTemplateBuilder.class);
    private Set stagingInventoriesSet;
    private Hashtable stagingInventoryByType;
    private List worksheetNameList;
    private ExportTemplateChooser exportTemplateChooser;

    public ExcelTemplateBuilder(Set stagingInventory) {
        if (null == stagingInventory) {
            throw new IllegalArgumentException("Staging inventory set cannot be null");
        }

        try {
            exportTemplateChooser = new ExportTemplateChooser();
        }
        catch (ExcelExportException e) {
            logger.error("An error occured creating the ExportTemplateChooser: " + e);
            throw new IllegalStateException("The export template chooser cannot be been created.");
        }

        this.stagingInventoriesSet = stagingInventory;
        worksheetNameList = new ArrayList();
        stagingInventoryByType = setUpImportTypeToStagingInventoryMapping();
    }

    public void setStagingInventoriesSet(Set stagingInventoriesSet) {
        if (null == stagingInventoriesSet) {
            throw new IllegalArgumentException("Staging inventory set cannot be null");
        }
        this.stagingInventoriesSet = stagingInventoriesSet;
    }

    public void saveToFile(String fileName) throws ExcelExportException, IOException {
        HSSFWorkbook workbook = ExcelBuildingUtils.createCopyOfDefaultTemplate(fileName);
        writeDataToWorkbook(workbook);
        OutputStream outputStream = null;
        try {
            outputStream = new BufferedOutputStream(new FileOutputStream(fileName));
            workbook.write(outputStream);
        } finally {
            if (null != outputStream) {
                outputStream.close();
            }
        }
    }

    public void saveToFile(File fileName) throws ExcelExportException, IOException {
        HSSFWorkbook workbook = ExcelBuildingUtils.createCopyOfDefaultTemplate(fileName);
        writeDataToWorkbook(workbook);
        OutputStream outputStream = null;
        try {
            outputStream = new BufferedOutputStream(new FileOutputStream(fileName));
            workbook.write(outputStream);
        } finally {
            if (null != outputStream) {
                outputStream.close();
            }
        }
    }

    private Hashtable setUpImportTypeToStagingInventoryMapping() {
        Hashtable stagingInventoryByTypeTable = new Hashtable();
        if (null != stagingInventoriesSet) {
            for (Object aStagingInventoriesSet : stagingInventoriesSet) {
                StagingInventory stagingInventory = (StagingInventory) aStagingInventoriesSet;
                if (!isImportTypeAbbreviationNull(stagingInventory)) {
                    String importTypeAbbreviation = stagingInventory.getInventoryHeader().getImportType().getAbbreviation();
                    if (!stagingInventoryByTypeTable.containsKey(importTypeAbbreviation)) {
                        stagingInventoryByTypeTable.put(importTypeAbbreviation, new ArrayList());
                    }
                    ((List) stagingInventoryByTypeTable.get(importTypeAbbreviation)).add(stagingInventory);
                }
            }
        }
        return stagingInventoryByTypeTable;
    }

    private boolean isImportTypeAbbreviationNull(StagingInventory stagingInventory) {
        return null == stagingInventory ||
                null == stagingInventory.getInventoryHeader() ||
                null == stagingInventory.getInventoryHeader().getImportType() ||
                null == stagingInventory.getInventoryHeader().getImportType().getAbbreviation();
    }

    private void extractNamesOfWorksheets(HSSFWorkbook workbook) {
        int i;
        int numberOfSheets = workbook.getNumberOfSheets();
        for (i = 0; i < numberOfSheets; i++) {
            worksheetNameList.add(workbook.getSheetName(i));
        }
    }

    private void writeDataToWorkbook(HSSFWorkbook workbook) throws ExcelExportException {
        extractNamesOfWorksheets(workbook);

        int numberOfWorksheetsInDefaultTemplate = worksheetNameList.size();
        int i;
        for (i = 0; i < numberOfWorksheetsInDefaultTemplate; i++) {
            String worksheetName = (String) worksheetNameList.get(i);
            HSSFSheet newSheet = workbook.getSheet(worksheetName);
            populateSheetFromStagingInventories(worksheetName, newSheet);
        }
    }

    private void populateSheetFromStagingInventories(String worksheetName, HSSFSheet newSheet) throws ExcelExportException {
        int groupNumber = 0;
        if (stagingInventoryByType.containsKey(worksheetName)) {
            List stagingInventories = (List) stagingInventoryByType.get(worksheetName);
            AbstractTemplate template = getTemplate(exportTemplateChooser, worksheetName);
            fillWorksheet(template, groupNumber, newSheet, stagingInventories);
            groupNumber++;
        }

    }

    private AbstractTemplate getTemplate(ExportTemplateChooser exportTemplateChooser, String worksheetName) throws ExcelExportException {
        return exportTemplateChooser.getTemplate(worksheetName);
    }

    private void fillWorksheet(AbstractTemplate template, int groupNumber, HSSFSheet newSheet, List stagingInventoryList) throws ExcelExportException {
        template.setGroupNumber(groupNumber);
        template.fillTemplateCellsWithDataFromView(newSheet, stagingInventoryList);

    }
}
