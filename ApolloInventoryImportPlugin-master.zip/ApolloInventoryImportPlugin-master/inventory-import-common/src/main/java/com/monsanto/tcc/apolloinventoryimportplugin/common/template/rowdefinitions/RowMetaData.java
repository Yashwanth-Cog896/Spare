/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions;


import com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints.DataConstraint;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: RowMetaData.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $   On: $Date: 2008-02-12 20:22:31 $
 *
 * @author ddbrow5
 * @version $Revision: 1.5 $
 * @noinspection MethodWithTooManyParameters
 */
public class RowMetaData {
  public static final String ATTR_NAME_REQ_FIRST_MSG = "Attribute name must be set first.";
  private List entities = null;

  public RowMetaData() {
    entities = new ArrayList();
  }

  public void addColumn(String displayName, String attributeName, int hssfCellType, DataConstraint constraint, boolean appearsInTable, boolean appearsInTemplate) {
    entities.add(new RowMetaDataEntry(displayName, attributeName, hssfCellType, constraint, appearsInTable, appearsInTemplate));
  }

  public void addColumn(String displayName, String attributeName, int hssfCellType, DataConstraint constraint, boolean appearsInTable, boolean appearsInTemplate, boolean appearsInExportTemplate) {
    entities.add(new RowMetaDataEntry(displayName, attributeName, hssfCellType, constraint, appearsInTable, appearsInTemplate, appearsInExportTemplate));
  }

  public void addColumn(String displayName, String attributeName, int hssfCellType, DataConstraint constraint, String alternateDislpayName, String alternateAttributeName, int alternateHSSFCellType, DataConstraint alternateConstraint, boolean appearsInTable, boolean appearsInTemplate) {
    entities.add(new RowMetaDataEntry(displayName, attributeName, hssfCellType, constraint, alternateDislpayName, alternateAttributeName, alternateHSSFCellType, alternateConstraint, appearsInTable, appearsInTemplate));
  }

  public int size() {
    return null == entities ? 0 : entities.size();
  }

  public String getDisplayName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).getDisplayName();
  }

  public String getAlternateDisplayName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return isAlternateDataPresent(index) ? ((RowMetaDataEntry) entities.get(index)).getAlternateDisplayName()
        : null;
  }

  public String getAttributeName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).getAttributeName();
  }

  public String getAlternateAttributeName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return isAlternateDataPresent(index) ? ((RowMetaDataEntry) entities.get(index)).getAlternateAttributeName()
        : null;
  }

  public String getGetMethodName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return getMethodName("get", getAttributeName(index));
  }

  public String getAlternateGetMethodName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return getMethodName("get", getAlternateAttributeName(index));
  }

  public String getSetMethodName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return getMethodName("set", getAttributeName(index));
  }

  public String getAlternateSetMethodName(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return getMethodName("set", getAlternateAttributeName(index));
  }

  public int getHSSFCellType(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).getHSSFCellType();
  }

  public int getAlternateHSSFCellType(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return isAlternateDataPresent(index) ? ((RowMetaDataEntry) entities.get(index)).getAlternateHSSFCellType()
        : -1;
  }

  public DataConstraint getConstraint(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).getConstraint();
  }

  public DataConstraint getAlternateConstraint(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return isAlternateDataPresent(index) ? ((RowMetaDataEntry) entities.get(index)).getAlternateConstraint()
        : null;
  }

  public boolean isAlternateDataPresent(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).isAlternateDataPresent();
  }

  public Iterator appearsInTableIterator() {
    List appearsInTableList = new ArrayList();
    for (int i = 0; i < entities.size(); i++) {
      if (isAppearsInTable(i)) {
        appearsInTableList.add(entities.get(i));
      }
    }
    return appearsInTableList.iterator();
  }

  public boolean isAppearsInTable(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).isAppearsInTable();
  }

  public Iterator appearsInTemplateIterator() {
    List appearsInTemplateList = new ArrayList();
    for (int i = 0; i < entities.size(); i++) {
      if (isAppearsInTemplate(i)) {
        appearsInTemplateList.add(entities.get(i));
      }
    }
    return appearsInTemplateList.iterator();
  }

  public boolean isAppearsInTemplate(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).isAppearsInTemplate();
  }

  public Iterator appearsInExportTemplateIterator() {
    List appearsInExportTemplateList = new ArrayList();
    for (int i = 0; i < entities.size(); i++) {
      if (isAppearsInExportTemplate(i)) {
        appearsInExportTemplateList.add(entities.get(i));
      }
    }
    return appearsInExportTemplateList.iterator();
  }

  public boolean isAppearsInExportTemplate(int index) {
    if (index < 0 || index > entities.size()) {
      throw new IndexOutOfBoundsException();
    }
    return ((RowMetaDataEntry) entities.get(index)).isAppearsInExportTemplate();
  }

  public int getIndexByDisplayName(String displayName) {
    int index = -1;
    if (null != displayName) {
      for (int i = 0; i < size(); i++) {
        if (displayName.equals(((RowMetaDataEntry) entities.get(i)).getDisplayName())) {
          index = i;
          break;
        }
      }
    }
    return index;
  }

  public int getIndexByAttributeName(String attributeName) {
    int index = -1;
    if (null != attributeName) {
      for (int i = 0; i < size(); i++) {
        if (attributeName.equals(((RowMetaDataEntry) entities.get(i)).getAttributeName())) {
          index = i;
          break;
        }
      }
    }
    return index;
  }

  public int getIndexByAlternateAttributeName(String attributeName) {
    int index = -1;
    if (null != attributeName) {
      for (int i = 0; i < size(); i++) {
        if (attributeName.equals(((RowMetaDataEntry) entities.get(i)).getAlternateAttributeName())) {
          index = i;
          break;
        }
      }
    }
    return index;
  }

  private String getMethodName(String prefix, String attributeName) {
    return null == attributeName ? null : prefix + getInitialCapAttributeName(attributeName);
  }

  private String getInitialCapAttributeName(String attributeName) {
    String initialCapAttributeName = attributeName;
    if (null == attributeName) {
      throw new IllegalStateException(ATTR_NAME_REQ_FIRST_MSG);
    }
    if (1 < attributeName.length()) {
      initialCapAttributeName = attributeName.substring(0, 1).toUpperCase() + attributeName.substring(1);
    }
    return initialCapAttributeName;
  }
}