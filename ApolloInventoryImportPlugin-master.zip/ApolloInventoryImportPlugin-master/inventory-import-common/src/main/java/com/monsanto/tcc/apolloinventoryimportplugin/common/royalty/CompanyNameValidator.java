package com.monsanto.tcc.apolloinventoryimportplugin.common.royalty;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.royalty.exception.CompanyNameMissingException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.RoyaltyFlagEvaluator;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 23, 2010
 * Time: 6:27:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyNameValidator {
    private static final String COMPANY_IS_NOT_VALID = "Company name is not valid. Please verify the company name";


    public void validate(String royalty, String companyName) throws CompanyNameMissingException {
        if (new RoyaltyFlagEvaluator(royalty).isRoyaltySelected() && StringUtils.isNullOrEmpty(companyName)) {
            throw new CompanyNameMissingException("Company is required when royalty selected.");
        }

        if ("MONSANTO".equalsIgnoreCase(companyName)) {
            throw new CompanyNameMissingException(COMPANY_IS_NOT_VALID);
        }

    }

}

