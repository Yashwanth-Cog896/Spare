package com.monsanto.tcc.apolloinventoryimportplugin.common.traitquality;

/**
 * Created by IntelliJ IDEA.
 * User: MTJOHN1
 * Date: 2/17/12
 * Time: 4:05 PM
 */
public class TraitQualitySyntaxException extends Exception {
    public TraitQualitySyntaxException(String msg) {
        super(msg);
    }
}
