/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.services.domain.common.filter.BinaryExpression;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.services.domain.common.filter.operator.OperatorDirectory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.FilterConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryFetchStrategyConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: ApprovedStagingInventoryActivityClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-03 20:41:48 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class ApprovedStagingInventoryActivityClient extends AbstractPOSClient {
    private static final String POS_ACTIVITY = "GetStagingInventoryByStatusCodes";
    public static final String MATERIAL_STATUS_FILTER = "status";
    public static final String STATUS_APPROVED = StagingInventoryStatusConstants.APPROVED;

    public ApprovedStagingInventoryActivityClient() {
        super.setPosActivityName(POS_ACTIVITY);
    }

    public StagingInventory[] getApprovedStagingInventories() throws ActivityClientException {
        return getApprovedStagingInventories(0);
    }

    public StagingInventory[] getApprovedStagingInventories(int requestedFetchSize) throws ActivityClientException {
        sendToPos(createCompositeObject(createRequestFilter(requestedFetchSize)));
        checkForErrorResponse();
        return getStagingInventories();
    }

    private CompositeObject createCompositeObject(Filter filter) {
        CompositeObject payload = new CompositeObject();
        payload.add(filter);
        return payload;
    }

    private StagingInventory[] getStagingInventories() {
        StagingInventory[] inventories = null;
        Iterator iterator = getResponseEnvelope().getItems();
        List<StagingInventory> list = new ArrayList<StagingInventory>();
        while (iterator.hasNext()) {
            list.add((StagingInventory) iterator.next());
        }
        if (list.size() > 0) {
            inventories = (StagingInventory[]) list.toArray(new StagingInventory[list.size()]);
        }

        return inventories;
    }

    private Filter createRequestFilter(int requestedFetchSize) {
        Filter filter = new Filter(MATERIAL_STATUS_FILTER);

        List<String> values = new ArrayList<String>();
        values.add(STATUS_APPROVED);

        filter.addExpression(new BinaryExpression(OperatorDirectory.EQUALS_OPERATOR.getRefId(),
                FilterConstants.STATUS_CODE_OPERAND, values));

        filter.addExpression(new BinaryExpression(OperatorDirectory.EQUALS_OPERATOR.getRefId(),
                FilterConstants.STAGING_INVENTORY_FETCH_OPERAND,
                StagingInventoryFetchStrategyConstants.INVENTORY_FETCH_STRATEGY_ECBII));

        filter.addExpression(new BinaryExpression(OperatorDirectory.EQUALS_OPERATOR.getRefId(),
                FilterConstants.STAGING_INVENTORY_REQ_FETCH_SIZE, new Integer(requestedFetchSize).toString()));

        return filter;
    }
}