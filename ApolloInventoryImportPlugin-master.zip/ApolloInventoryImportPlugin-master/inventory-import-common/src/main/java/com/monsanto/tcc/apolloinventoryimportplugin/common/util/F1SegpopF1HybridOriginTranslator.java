/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginSyntaxVerifier;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: F1SegpopF1HybridOriginTranslator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5
 * $ On:          $Date: 2008-05-15 16:01:11 $
 *
 * @author ddbrow5
 * @version $Revision: 1.5 $
 */
public class F1SegpopF1HybridOriginTranslator {
    private static final String ORIGIN_REQ_MSG = "Origin is required";
    private static final String SEGPOP_OPERATOR = "/";
    private static final String SEGPOP_OPERATOR_PATTERN = "\\" + SEGPOP_OPERATOR;
    private static final String HYBRID_OPERATOR = "+";
    private static final String HYBRID_OPERATOR_PATTERN = "\\" + HYBRID_OPERATOR;
    private List<String> originStrings = new ArrayList<String>();
    private String[] operators;

    public String translate(String originalOrigin) throws InvalidOriginSyntaxException {
        if (StringUtils.isNullOrEmpty(originalOrigin)) {
            throw new IllegalArgumentException(ORIGIN_REQ_MSG);
        }
        OriginEntity originalOriginTree = getOriginTree(originalOrigin);
        initializeOperators(originalOriginTree);
        translateOriginTree(originalOriginTree);

        String translatedOriginString = generateTranslatedOriginString();
        verifyTranslatedOriginStringHasValidSyntax(translatedOriginString);
        return translatedOriginString;
    }

    private void translateOriginTree(OriginEntity originTree) throws InvalidOriginSyntaxException {
        if (originTree != null) {
            processFemaleParentOriginTree(getFemaleParentOriginTree(originTree));
            processMaleParentOriginTree(getMaleParentOriginTree(originTree));
            addOriginAndOperatorToLists(originTree);
        }
    }

    private void processFemaleParentOriginTree(OriginEntity femaleParentOriginTree) throws InvalidOriginSyntaxException {
        if (femaleParentOriginTree != null) {
            translateOriginTree(femaleParentOriginTree);
        }
    }

    private void processMaleParentOriginTree(OriginEntity maleParentOriginTree) throws InvalidOriginSyntaxException {
        if (maleParentOriginTree != null) {
            translateOriginTree(maleParentOriginTree);
        }
    }

    private void addOriginAndOperatorToLists(OriginEntity originTree) throws InvalidOriginSyntaxException {
        if (isLeafEntity(originTree)) {
            originStrings.add(originTree.getOrigin());
        }
    }

    protected String generateTranslatedOriginString() throws InvalidOriginSyntaxException {
        String translatedOriginString = "";
        if (operators != null) {
            for (int i = 0; i < operators.length; i++) {
                translatedOriginString += getOriginStringFromOriginStringsList(i) +
                        translateOperator(getOperatorFromOperatorsList(i));
            }
        }
        translatedOriginString += getOriginStringFromOriginStringsList(originStrings.size() - 1);
        return translatedOriginString;
    }

    private void verifyTranslatedOriginStringHasValidSyntax(String translatedOrigin) throws InvalidOriginSyntaxException {
        try {
            getOriginTree(translatedOrigin);
        } catch (InvalidOriginSyntaxException e) {
            throw new InvalidOriginSyntaxException("Translated origin '" + translatedOrigin + "' is not valid: "
                    + e.getMessage());
        }
    }

    private String getOriginStringFromOriginStringsList(int index) {
        return originStrings != null && index >= 0 && index < originStrings.size() ? originStrings.get(index) : "";
    }

    private void initializeOperators(OriginEntity originalOriginTree) {
        if (originalOriginTree != null) {
            operators = originalOriginTree.getDelimitersInOrigin();
        }
    }

    private String getOperatorFromOperatorsList(int index) {
        return operators != null && index < operators.length ? operators[index] : "";
    }

    private OriginEntity getFemaleParentOriginTree(OriginEntity originTree) {
        return originTree == null ? null : originTree.getFemaleParent();
    }

    private OriginEntity getMaleParentOriginTree(OriginEntity originTree) {
        return originTree == null ? null : originTree.getMaleParent();
    }

    private String translateOperator(String operator) throws InvalidOriginSyntaxException {
        String translatedOperator = null;
        if (StringUtils.isNullOrEmpty(operator)) {
            return null;
        }
        if (operator.startsWith(SEGPOP_OPERATOR)) {
            translatedOperator = translateSgpopDelimiterToHybridDelimiter(operator);
        }
        if (operator.startsWith(HYBRID_OPERATOR)) {
            translatedOperator = translateHybridDelimiterToSegpopDelimiter(operator);
        }
        return translatedOperator;
    }

    private String translateSgpopDelimiterToHybridDelimiter(String segpopDelimiter) {
        return !StringUtils.isNullOrEmpty(segpopDelimiter)
                ? segpopDelimiter.replaceAll(SEGPOP_OPERATOR_PATTERN, HYBRID_OPERATOR)
                : "";
    }

    private String translateHybridDelimiterToSegpopDelimiter(String hybridDelimiter) {
        return !StringUtils.isNullOrEmpty(hybridDelimiter)
                ? hybridDelimiter.replaceAll(HYBRID_OPERATOR_PATTERN, SEGPOP_OPERATOR)
                : "";
    }

    private boolean isLeafEntity(OriginEntity originTree) {
        return originTree != null && originTree.isLeafEntity();
    }

    private OriginEntity getOriginTree(String originString) throws InvalidOriginSyntaxException {
        return getOriginSyntaxVerifier(originString).getOriginTree();
    }

    private OriginSyntaxVerifier getOriginSyntaxVerifier(String originString) throws InvalidOriginSyntaxException {
        return new OriginSyntaxVerifier(originString);
    }
}