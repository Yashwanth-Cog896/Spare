/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;

/**
 * Filename:    $RCSfile: ErrorCell.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-23 21:51:45 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class ErrorCell implements Cell {
    private HSSFCell cell;

    public ErrorCell(HSSFCell cell) {
        this.cell = cell;
    }

    public String getValue() {
        return new Byte(cell.getErrorCellValue()).toString();
    }
}