/*
 CheckConstraint was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Filename:    $RCSfile: CheckConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-12 20:22:31 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class CheckConstraint implements DataConstraint {
    private String checkVal;
    private String subject = null;
    private String messageToDisplayOnFailure;

    public CheckConstraint(String subject, String checkVal) {
        if (StringUtils.isNullOrEmpty(checkVal) || StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject, checkVal is required.");
        }

        this.subject = subject;
        this.checkVal = checkVal;
        messageToDisplayOnFailure = "Value for " + subject + " is invalid";
    }

    public CheckConstraint(String subject, String checkVal, String message) {
        if (StringUtils.isNullOrEmpty(checkVal) || StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject, checkVal is required.");
        }

        this.subject = subject;
        this.checkVal = checkVal;
        messageToDisplayOnFailure = message;
    }

    public boolean validate(Map dataSource) {
        return checkVal.equalsIgnoreCase((String) dataSource.get(subject));
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        this.messageToDisplayOnFailure = messageToDisplayOnFailure;
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}