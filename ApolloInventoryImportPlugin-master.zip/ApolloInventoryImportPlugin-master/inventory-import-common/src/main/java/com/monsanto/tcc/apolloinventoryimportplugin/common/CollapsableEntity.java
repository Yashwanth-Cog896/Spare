/*
 CollapsableEntity was created on Jun 16, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.services.domain.common.Entity;

import java.util.Collection;

/**
 * Filename:    $RCSfile: CollapsableEntity.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: aaanna $     On:$Date: 2008-06-18 03:49:47 $
 *
 * @author AAANNA
 * @version $Revision: 1.1 $
 */
public interface CollapsableEntity extends Entity {
    public boolean isCollapsed();

    public void setCollapsed(boolean collapsed);

    public Collection<Object> getCollapsableRecords();

    public boolean isCollapsable();
}
/*
* Revision Log
* : $
*/
