/*
 OrDataConstraint was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Filename:    $RCSfile: OrDataConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-12 20:22:31 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class PredicateDataConstraint implements DataConstraint {
    private DataConstraint[] predicates;
    private DataConstraint[] constraints;
    private String messageToDisplayOnFailure;
    private boolean isMessageToDisplayOnFailureDefaultValue = true;

    public PredicateDataConstraint(DataConstraint[] predicates, DataConstraint[] constraints) {
        if (null == predicates) {
            throw new IllegalArgumentException("predicates is required.");
        }
        if (null == constraints) {
            throw new IllegalArgumentException("constraints is required.");
        }

        this.predicates = predicates;
        this.constraints = constraints;
        this.messageToDisplayOnFailure = "";
    }

    public boolean validate(Map dataSource) {
        boolean predicateStatus = true;
        boolean constraintStatus = true;
        this.messageToDisplayOnFailure = "";

        for (DataConstraint predicate : predicates) {
            predicateStatus &= isConstraintValid(predicate, dataSource);
        }

        if (predicateStatus) {
            for (DataConstraint constraint : constraints) {
                constraintStatus &= isConstraintValid(constraint, dataSource);
            }
        }
        else {
            return true;
        }

        return constraintStatus;
    }

    private boolean isConstraintValid(DataConstraint constraint, Map dataSource) {
        if (!constraint.validate(dataSource)) {
            appendToMessageToDisplayOnFailureIfDefaultValueHasNotBeenSet(constraint.getMessageToDisplayOnFailure());
            return false;
        }
        return true;
    }

    private void appendToMessageToDisplayOnFailureIfDefaultValueHasNotBeenSet(String message) {
        if (!isMessageToDisplayOnFailureDefaultValue) {
            return;
        }
        if (!StringUtils.isNullOrEmpty(messageToDisplayOnFailure)) {
            messageToDisplayOnFailure += ";";
        }
        messageToDisplayOnFailure += message;
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        throw new UnsupportedOperationException("Cannot set messages at this level.");
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}