/*
 InventoryImportXmlSerializerProvider was created on Jan 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.serialzerprovider;

import com.monsanto.services.client.common.envelope.EnvelopeXmlSerializerBuilderMappingRegister;
import com.monsanto.services.client.common.filter.FilterXmlSerializerBuilderMappingRegister;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportedTemplateEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.WorklistEntity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.XMLDateConverter;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventoryEntity;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.xmlserialization.XmlSerializerBuilderMappingRegister;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * Filename:    $RCSfile: InventoryImportXmlSerializerProvider.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $     On:$Date: 2008-06-18 14:55:22 $
 *
 * @author SRKARNA
 * @version $Revision: 1.6 $
 */
public class InventoryImportXmlSerializerProvider implements XmlSerializerProvider {
    public static final String NAMESPACE = "http://www.monsanto.com/inventoryimport/POS";

    public XmlSerializer getXmlSerializer() {
        XmlSerializerBuilder builder = new XmlSerializerBuilder();
        builder.setClassLoader(getClass().getClassLoader());

        registerEnvelopeMappings(builder);
        registerFilterMappings(builder);

        builder.registerMapping(InventoryImportXmlSerializerProvider.NAMESPACE, "stagingInventoryEntity",
                StagingInventoryEntity.class);
        builder.registerMapping(InventoryImportXmlSerializerProvider.NAMESPACE, "worklistEntity", WorklistEntity.class);
        builder.registerMapping(InventoryImportXmlSerializerProvider.NAMESPACE, "importedTemplateEntity",
                ImportedTemplateEntity.class);
        builder.addConverter(new XMLDateConverter());
        return builder.createSerializer();
    }

    private void registerEnvelopeMappings(XmlSerializerBuilder builder) {
        createEnvelopeMappingRegister().registerMappings(builder, InventoryImportXmlSerializerProvider.NAMESPACE);
    }

    private XmlSerializerBuilderMappingRegister createEnvelopeMappingRegister() {
        return new EnvelopeXmlSerializerBuilderMappingRegister();
    }

    private void registerFilterMappings(XmlSerializerBuilder builder) {
        createFilterMappingRegister().registerMappings(builder, InventoryImportXmlSerializerProvider.NAMESPACE);
    }

    private FilterXmlSerializerBuilderMappingRegister createFilterMappingRegister() {
        return new FilterXmlSerializerBuilderMappingRegister();
    }
}