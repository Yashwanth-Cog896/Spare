/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation;

/**
 * Filename:    $RCSfile: NullGeneration.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-04 21:13:55 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NullGeneration implements Generation {
    public boolean isMSC() {
        return false;
    }

    public boolean isMSC0() {
        return false;
    }

    public boolean isBackcross() {
        return false;
    }

    public boolean isNull() {
        return true;
    }

    public boolean isInbred() {
        return false;
    }

    public int getGeneration() {
        return 0;
    }
}