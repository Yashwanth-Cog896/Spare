/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.coded;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.lineagecheckers.LineageCheckerForCoded;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.ALineFunctionCytoplasmCheckForNonProductLines;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionNonHybridNonProductCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.NonALineFunctionCytoplasmNonProductLinesCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.ALineLineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidALineMSCLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: CodedStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $     On:$Date: 2009-06-05 14:08:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.14 $
 */
public class CodedStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    public static final String LINEAGE_MUST_CONTAIN_PIPE_MSG = "The lineage of a coded line must contain at least " +
            "one pipe. Please edit the lineage to include a pipe and re-validate.";
    public static final String INVALID_A_LINE_FUNCTION_GENERATION = "Invalid generation for A line function";

    private StagingInventory stagingInventory;

    public CodedStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);

        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getGermplasmOwner())) {
            msgList.add(MANDATORY_CHECK_MSG + "Germplasm Owner");
        }
        if (StringUtils.isNullOrEmpty(stagingInventory.getLineCode())) {
            msgList.add(MANDATORY_CHECK_MSG + "Line Code");
        }
        if (StringUtils.isNullOrEmpty(stagingInventory.getOrigin())) {
            msgList.add(MANDATORY_CHECK_MSG + "Origin");
        }
        if (StringUtils.isNullOrEmpty(stagingInventory.getLineage())) {
            msgList.add(MANDATORY_CHECK_MSG + "Lineage");
        }
        if (StringUtils.isNullOrEmpty(stagingInventory.getGeneration())) {
            msgList.add(MANDATORY_CHECK_MSG + "Generation");
        }
        if (isLineFunctionA(stagingInventory.getLineFunction())) {
            if (!stagingInventory.isSubRecord()) {
                new ALineFunctionCytoplasmCheckForNonProductLines(stagingInventory.getCytoplasmDonorPedigree(),
                        stagingInventory.getCytoplasmDonorSource(), stagingInventory.getBuildParentage()).check(msgList);
                if (StringUtils.isNullOrEmpty(stagingInventory.getGeneration()) ||
                        !isGenerationValidMSC(stagingInventory.getGeneration())) {
                    msgList.add(INVALID_A_LINE_FUNCTION_GENERATION);
                }

                try {
                    new ALineLineage(stagingInventory.getLineage());
                } catch (InvalidALineMSCLineageException e) {
                    msgList.add(e.getMessage());
                }
            }
        } else {
            new NonALineFunctionCytoplasmNonProductLinesCheck(stagingInventory.getCytoplasmDonorPedigree(),
                    stagingInventory.getCytoplasmDonorSource()).check(msgList);
        }
        new AllowedLineFunctionNonHybridNonProductCheck(stagingInventory.getLineFunction()).check(msgList);
        checkLineage(msgList, stagingInventory.getLineage(), stagingInventory.getLineFunction());
    }

    private boolean isGenerationValidMSC(String generation) {
        String mscPatternString = "^MSC[0-9]+$";
        Pattern mscPattern = Pattern.compile(mscPatternString);
        Matcher mscMatcher = mscPattern.matcher(generation);
        return mscMatcher.matches();
    }

    private void checkLineage(List msgList, String lineage, String lineFunctionRefId) {
        if (StringUtils.isNullOrEmpty(lineage)) {
            return;
        }
        new LineageCheckerForCoded(lineage, lineFunctionRefId).check(msgList);
    }

    private boolean isLineFunctionA(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) &&
                LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }
}