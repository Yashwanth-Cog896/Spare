package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.builder;

import java.util.List;
import java.util.Stack;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Sep 4, 2009
 * Time: 3:30:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class BiennialGenerationBuilder extends AbstractGenerationBuilder {

    public BiennialGenerationBuilder() {
        super(null, null);
    }

    public BiennialGenerationBuilder(String mainRecordGeneration, String lineFunction) {
        super(mainRecordGeneration, lineFunction);
    }

    public BiennialGenerationBuilder(String mainRecordGeneration) {
        super(mainRecordGeneration, null);
    }

    protected String getSimpleGeneration(String lineage) {
        MassOpenOperationsParser massOpenOperationsParser = new MassOpenOperationsParser();
        List<String> openMassOperations = massOpenOperationsParser.parse(getMainRecordGeneration());
        String generation;
        Stack<String> stackWithOperations = populateStackWithOperationsFromLineage(lineage, openMassOperations);
        String tempGeneration = buildGeneration(stackWithOperations);
        generation = tempGeneration.trim().length() != 0 ? tempGeneration : null;
        return generation;
    }

    private String buildGeneration(Stack<String> tempStack) {
        String tempGeneration = "";
        int slCount = 0;
        if (!tempStack.isEmpty()) {
            String topElement = tempStack.peek();
            if (!"F".equals(topElement)) {
                tempGeneration = "F1";
            } else {
                slCount++;
            }
        }
        String privousString = "";
        while (!tempStack.empty()) {
            String currentElement = tempStack.pop();
            if ((privousString.length() > 0 && !privousString.equals(currentElement))) {
                tempGeneration += privousString + slCount;
                slCount = 0;
            }
            slCount++;
            privousString = currentElement;
        }
        if (privousString.length() > 0) {
            tempGeneration += privousString + slCount;
        }
        return tempGeneration;
    }

    private Stack<String> populateStackWithOperationsFromLineage(String lineage, List<String> openMassOperations) {
        int openMassOperationCounter = openMassOperations.size() - 1;
        Stack<String> tempStack = new Stack<String>();
        for (int i = lineage.length(); i > 0; i--) {
            String tempString = lineage.substring(i - 1, i);
            if (tempString.matches("[.$#]")) {
                tempStack.push("S");
            } else if (tempString.matches("[!]")) {
                String openMassPrefix = "F";
                if (openMassOperations.size() > openMassOperationCounter && openMassOperationCounter > 0) {
                    openMassPrefix = openMassOperations.get(openMassOperationCounter);
                }
                tempStack.push(openMassPrefix);
                openMassOperationCounter--;
            }

        }
        return tempStack;
    }

    protected Pattern getSimpleLineagePattern() {
        String simpleLineagePattern = "[.#$]";
        return Pattern.compile(simpleLineagePattern);
    }

}
