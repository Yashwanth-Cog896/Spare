package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Created by IntelliJ IDEA. User: aagosw Date: Sep 22, 2008 Time: 4:14:37 PM To change this template use File |
 * Settings | File Templates.
 */
public class OriginIsSingleEntityAndDoesnotContainDosageValidator {

    public static final String ERROR_MSG = "Backcrossing requires 2 parents.  Please correct the origin and re-import.";

    public void validate(String origin) throws InvalidOriginSyntaxException {
        if (origin == null) {
            throw new IllegalArgumentException("Origin is required");
        }

        String[] components = new OriginSyntaxVerifier(origin).getEntities();
        if (components.length == 1 && components[0].indexOf("*") > -1) {
            throw new InvalidOriginSyntaxException(ERROR_MSG);
        }

    }
}
