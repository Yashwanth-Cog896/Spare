package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import java.io.*;

/**
 * Filename:    $RCSfile: ExcelBuildingUtils.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    On: $Date: 2007-04-05 06:54:21 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class ExcelBuildingUtils {
    public static final String DEFAULT_TEMPLATE_FILE = "Template.xls";

    public static HSSFWorkbook createCopyOfDefaultTemplate(String fileName) throws IOException {
        HSSFWorkbook workbook = getDefaultWorkbook();
        workbook.write(new BufferedOutputStream(new FileOutputStream(fileName)));
        return workbook;
    }

    public static HSSFWorkbook createCopyOfDefaultTemplate(File fileName) throws IOException {
        HSSFWorkbook workbook = getDefaultWorkbook();
        workbook.write(new BufferedOutputStream(new FileOutputStream(fileName)));
        return workbook;
    }

    public static HSSFWorkbook getDefaultWorkbook() throws IOException {
        HSSFWorkbook workbook = null;
        try {
            POIFSFileSystem fs = getPOIFSFileSystem();
            workbook = new HSSFWorkbook(fs);
        }
        catch (IOException e) {
            throw new IOException();
        }
        return workbook;
    }

    private static POIFSFileSystem getPOIFSFileSystem() throws IOException {
        POIFSFileSystem poifsFileSystem = null;

        try {
            InputStream inputStream = ExcelBuildingUtils.class.getResourceAsStream(DEFAULT_TEMPLATE_FILE);
            poifsFileSystem = new POIFSFileSystem(inputStream);
        }
        catch (FileNotFoundException fnfe) {
            throw new FileNotFoundException();
        }
        catch (IOException ioe) {
            throw new IOException();
        }
        return poifsFileSystem;
    }

    public void createInstanceOfFileFromTemplate(String fileName) throws IOException {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = ExcelBuildingUtils.class.getResourceAsStream(DEFAULT_TEMPLATE_FILE);
            POIFSFileSystem poifsFileSystem = new POIFSFileSystem(inputStream);
            HSSFWorkbook workbook = new HSSFWorkbook(poifsFileSystem);
            outputStream = new BufferedOutputStream(new FileOutputStream(fileName));
            workbook.write(outputStream);
        } finally {
            if (null != inputStream) {
                inputStream.close();
                inputStream = null;
            }

            if (null != outputStream) {
                outputStream.close();
                outputStream = null;
            }
        }
    }

    public OutputStream getInstanceOfOutputStreamUsingTemplate(String fileName) throws IOException {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            inputStream = ExcelBuildingUtils.class.getResourceAsStream(DEFAULT_TEMPLATE_FILE);
            POIFSFileSystem poifsFileSystem = new POIFSFileSystem(inputStream);
            HSSFWorkbook workbook = new HSSFWorkbook(poifsFileSystem);
            outputStream = new BufferedOutputStream(new FileOutputStream(fileName));
            workbook.write(outputStream);
        } finally {
            if (null != inputStream) {
                inputStream.close();
                inputStream = null;
            }
        }

        return outputStream;
    }
}
