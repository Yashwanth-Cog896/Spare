/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;

import java.util.List;

/**
 * Filename:    $RCSfile: NonALineFunctionCytoplasmCompetitorCommercialLinesCheck.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:03 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class NonALineFunctionCytoplasmCompetitorCommercialLinesCheck {
    public static final String CYTOPLASM_DONOR_PEDIGREE = "Cytoplasm Donor Pedigree";
    private String cytoplasmPedigree;

    public NonALineFunctionCytoplasmCompetitorCommercialLinesCheck(String cytoplasmPedigree) {
        this.cytoplasmPedigree = cytoplasmPedigree;
    }

    public void check(List msgList) {
        if (!StringUtils.isNullOrEmpty(cytoplasmPedigree)) {
            msgList.add(AbstractStagingInventorySanityChecker.NOT_ALLOWED_CHECK_MSG + CYTOPLASM_DONOR_PEDIGREE);
        }
    }
}