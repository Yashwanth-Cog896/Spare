/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

/**
 * Filename:    $RCSfile: CharacterEncodingException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $
 * On:$Date: 2007-09-06 19:35:52 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class CharacterEncodingException extends Exception {
    public CharacterEncodingException(String message) {
        super(message);
    }
}