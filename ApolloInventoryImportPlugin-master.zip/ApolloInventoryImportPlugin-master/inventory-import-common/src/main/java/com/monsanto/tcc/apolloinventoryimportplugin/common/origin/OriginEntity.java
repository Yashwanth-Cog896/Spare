/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

/**
 * Filename:    $RCSfile: OriginEntity.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date:
 * 2007/05/11 17:31:15 $
 *
 * @author SSPEYY
 * @version $Revision: 1.9 $
 */
public class OriginEntity implements Cloneable {
    private String operator;
    private int level;
    private OriginEntity femaleParent;
    private OriginEntity maleParent;
    private String origin;
    private String parentalRole;
    private String[] delimitersInOrigin;
    private OriginEntity childEntity;
    private boolean isLeafEntity;

    public OriginEntity(String origin) {
        this.origin = origin;
    }

    public boolean isLeafEntity() {
        return isLeafEntity;
    }

    public void setLeafEntity(boolean leafEntity) {
        isLeafEntity = leafEntity;
    }

    public String[] getDelimitersInOrigin() {
        if (delimitersInOrigin == null) {
            return null;
        }
        String[] copy = new String[delimitersInOrigin.length];
        System.arraycopy(delimitersInOrigin, 0, copy, 0, delimitersInOrigin.length);
        return copy;
    }

    public void setDelimitersInOrigin(String[] delimitersInOrigin) {
        this.delimitersInOrigin = delimitersInOrigin;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public OriginEntity getFemaleParent() {
        return femaleParent;
    }

    public void setFemaleParent(OriginEntity femaleParent) {
        this.femaleParent = femaleParent;
    }

    public OriginEntity getMaleParent() {
        return maleParent;
    }

    public void setMaleParent(OriginEntity maleParent) {
        this.maleParent = maleParent;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getParentalRole() {
        return parentalRole;
    }

    public void setParentalRole(String parentalRole) {
        this.parentalRole = parentalRole;
    }

    public OriginEntity getChildEntity() {
        return childEntity;
    }

    public void setChildEntity(OriginEntity childEntity) {
        this.childEntity = childEntity;
    }

    public Object clone() throws CloneNotSupportedException {
        OriginEntity object = (OriginEntity) super.clone();

        OriginEntity femaleParentEntity = object.getFemaleParent();
        if (femaleParentEntity != null) {
            OriginEntity clonedFemaleParentEntity = (OriginEntity) femaleParentEntity.clone();
            clonedFemaleParentEntity.setChildEntity(object);
            object.setFemaleParent(clonedFemaleParentEntity);
        }

        OriginEntity maleParentEntity = object.getMaleParent();
        if (maleParentEntity != null) {
            OriginEntity clonedMaleParentEntity = (OriginEntity) maleParentEntity.clone();
            clonedMaleParentEntity.setChildEntity(object);
            object.setMaleParent(clonedMaleParentEntity);
        }

        return object;
    }
}