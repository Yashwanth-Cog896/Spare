package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

/**
 * Filename:    $RCSfile: ExcelExportException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2007-02-23 20:42:58 $
 *
 * @author DDBROW5
 * @version $Revision: 1.1 $
 */
public class ExcelExportException extends Exception {
    public ExcelExportException(String message) {
        super(message);
    }
}
