/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.linecode;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.linecode.exception.LineCodeSyntaxException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: LineCodeSyntaxVerifier.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-06-12 19:49:11 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class LineCodeSyntaxVerifier {


    private String lineCode;
    public static final String ILLEGAL_ARG_EXCEP_MSG = "Line Code is required and cannot be empty";
    private static final String INVALID_LINECODE_MSG = "Line code can contain only letters, numbers and dash";

    public LineCodeSyntaxVerifier(String lineCode) {
        if (StringUtils.isNullOrEmpty(lineCode)) {
            throw new IllegalArgumentException(ILLEGAL_ARG_EXCEP_MSG);
        }
        this.lineCode = lineCode;
    }

    public void validateLineCodeSyntax() throws LineCodeSyntaxException {
        String regex = "^[-a-zA-Z0-9]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineCode);

        if (!matcher.find()) {
            throw new LineCodeSyntaxException(INVALID_LINECODE_MSG);
        }
    }
}