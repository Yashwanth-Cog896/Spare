/*
 NotNullConstraint was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.InventoryImportConstants;

import java.util.Map;

/**
 * Filename:    $RCSfile: NotNullConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-12 20:22:31 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class NotNullConstraint implements DataConstraint {
    private String subject = null;
    private String messageToDisplayOnFailure;

    public NotNullConstraint(String subject) {
        if (StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject is required.");
        }

        this.subject = subject;
        messageToDisplayOnFailure = "No value is specified for " + subject;
    }

    public NotNullConstraint(String subject, String message) {
        if (StringUtils.isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject is required.");
        }

        this.subject = subject;
        messageToDisplayOnFailure = message;
    }

    public boolean validate(Map dataSource) {
        return !(StringUtils.isNullOrEmpty((String) dataSource.get(subject))
                || dataSource.get(subject).equals(InventoryImportConstants.DEFAULT_STRING));
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        this.messageToDisplayOnFailure = messageToDisplayOnFailure;
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}