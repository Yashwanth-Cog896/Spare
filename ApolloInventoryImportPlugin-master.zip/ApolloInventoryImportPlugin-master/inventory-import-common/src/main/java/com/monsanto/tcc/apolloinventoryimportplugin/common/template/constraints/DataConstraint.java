/*
 DataConstraint was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import java.util.Map;

/**
 * Filename:    $RCSfile: DataConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date:
 * 2007/03/17 05:39:15 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public interface DataConstraint {
    boolean validate(Map dataSource);

    void setMessageToDisplayOnFailure(String messageToDisplayOnFailure);

    String getMessageToDisplayOnFailure();
}