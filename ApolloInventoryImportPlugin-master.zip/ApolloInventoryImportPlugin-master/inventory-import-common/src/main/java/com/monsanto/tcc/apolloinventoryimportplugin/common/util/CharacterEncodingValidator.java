/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import com.monsanto.Util.StringUtils;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

/**
 * Filename:    $RCSfile: CharacterEncodingValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $
 * On:$Date: 2007-09-06 21:06:22 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class CharacterEncodingValidator {
    private CharsetEncoder encoder;

    public CharacterEncodingValidator(String charsetEncoding) {
        encoder = Charset.forName(charsetEncoding).newEncoder();
    }

    public void validate(String validationString) throws CharacterEncodingException {
        if (!StringUtils.isNullOrEmpty(validationString) && !encoder.canEncode(validationString)) {
            throw new CharacterEncodingException(
                    "String " + validationString + " does not confirm to " + encoder.charset().toString() + " encoding");
        }
    }
}