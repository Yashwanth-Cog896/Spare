/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.CLineOrigin;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.CLineOriginValidator;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: CLineGenerationValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-11-10 21:52:39 $
 *
 * @author SSPEYY
 * @version $Revision: 1.6 $
 */
public class CLineGenerationValidator {
    public static final String INVALID_GENERATION_MSG = "Invalid generation for C Lines";
    public static final String GENERATION_EMPTY_MSG = "Generation cannot be null or empty";

    private CLineGeneration generation;
    private String lineage;
    private String origin;


    public CLineGenerationValidator(String generationString, String lineage, String origin) throws
            InvalidCLineGenerationException {
        generation = getCLineGeneration(generationString);
        this.lineage = lineage;
        this.origin = origin;
    }

    private CLineGeneration getCLineGeneration(String generationString) throws InvalidCLineGenerationException {
        try {
            return new CLineGeneration(generationString);
        } catch (InvalidCLineGenerationException e) {
            throw new InvalidCLineGenerationException(INVALID_GENERATION_MSG);
        }
    }

    public void validateGeneration() throws InvalidCLineGenerationException {
        checkGenerationForNullLineage();
        checkGenerationForPipeLineage();
        checkGenerationWhenNoDosageInLineage();
        checkGenerationWithDosageInLineage();
        checkGenerationWhenOriginIsLoneEntity();
    }

    private void checkGenerationWithDosageInLineage() throws InvalidCLineGenerationException {
        try {
            if (getDosageFromLineage() > 1) {
                if (!generation.isBackcross()) {
                    throw new InvalidCLineGenerationException(INVALID_GENERATION_MSG);
                }
            }
        } catch (InvalidLineageException e) {
            throw new InvalidCLineGenerationException(e.getMessage());
        }
    }


    private void checkGenerationWhenNoDosageInLineage() throws InvalidCLineGenerationException {
        try {
            if (!"|".equals(lineage) && getDosageFromLineage() < 2) {
                if (!generation.isMSC0()) {
                    throw new InvalidCLineGenerationException(INVALID_GENERATION_MSG);
                }
            }
        } catch (InvalidLineageException e) {
            throw new InvalidCLineGenerationException(e.getMessage());
        }
    }


    private void checkGenerationForNullLineage() throws InvalidCLineGenerationException {
        if (StringUtils.isNullOrEmpty(lineage)) {
            if (!generation.isMSC0()) {
                throw new InvalidCLineGenerationException(INVALID_GENERATION_MSG);
            }
        }
    }

    private void checkGenerationForPipeLineage() throws InvalidCLineGenerationException {
        if ("|".equals(lineage)) {
            if (!generation.isInbred()) {
                throw new InvalidCLineGenerationException(INVALID_GENERATION_MSG);
            }
        }
    }

    private void checkGenerationWhenOriginIsLoneEntity() throws InvalidCLineGenerationException {
        try {
            if (!StringUtils.isNullOrEmpty(origin) && new CLineOrigin(origin).isLoneEntity()) {
                if (!generation.isMSC0() && !generation.isInbred()) {
                    throw new InvalidCLineGenerationException(INVALID_GENERATION_MSG);
                }
            }
        } catch (InvalidOriginSyntaxException e) {
            throw new InvalidCLineGenerationException(e.getMessage());
        }
    }

    private int getDosageFromLineage() throws InvalidLineageException {
        return new CLineOriginValidator().getDosageFromLineage(lineage);
    }
}