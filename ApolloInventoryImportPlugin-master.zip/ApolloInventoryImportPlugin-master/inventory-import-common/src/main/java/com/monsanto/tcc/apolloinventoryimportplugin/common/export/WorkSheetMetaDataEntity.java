package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

/**
 * Filename:    $RCSfile: WorkSheetMetaDataEntity.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2007-02-23 20:42:58 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class WorkSheetMetaDataEntity {
  private String getMethodName = null;
  private int columnType = -1;
  private String altermateGetMethodName = null;
  private int alternateColumnType = -1;
  private boolean isAlternateDataPresent = false;

  public WorkSheetMetaDataEntity() {
  }

  public WorkSheetMetaDataEntity(String getMethodName, int type) {
    this.getMethodName = getMethodName;
    this.columnType = type;
  }

  public void setGetMethodName(String name) {
    this.getMethodName = name;
  }

  public String getGetMethodName() {
    return this.getMethodName;
  }

  public void setAlternateGetMethodName(String name) {
    this.isAlternateDataPresent = true;
    this.altermateGetMethodName = name;
  }

  public String getAlternateGetMethodName() {
    return this.altermateGetMethodName;
  }

  public void setType(int type) {
    this.columnType = type;
  }

  public int getType() {
    return this.columnType;
  }

  public void setAlternateType(int type) {
    this.isAlternateDataPresent = true;
    this.alternateColumnType = type;
  }

  public int getAlternateType() {
    return this.alternateColumnType;
  }

  public boolean isAlternateDataPresent() {
    return this.isAlternateDataPresent;
  }
}
