/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineageSyntaxConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: LineageSyntaxChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2008-06-19 15:04:46 $
 *
 * @author apatro
 * @version $Revision: 1.14 $
 */
public class LineageSyntaxChecker {
    private final String cycleMarkerPrefix = "(@|\\d+[a-z]*)";
    public static final String LINEAGE_HAS_BOTH_DH_BC_MSG = "Lineage cannot contain both % and > symbols";
    private String lineage;
    public static final String ILLEGAL_ARG_EXCEP_MSG = "Lineage is required and cannot be empty";
    public static final String INVALID_LINEAGE_STRING_EXCEP_MSG = "Lineage must begin with a number or a '@' symbol and must have a valid cycle marker between the first character and the first pipe to be able to build parentage. Please edit the lineage and re-validate record.";
    public static final String NO_CYCLE_MARKERS_BETWN_PIPES_MSG = "No cycle markers found between two pipes.";
    public static final String INVALID_CYCLE_MARKERS_FOUND_MSG = "Invalid cycle markers found - ";
    public static final String INVALID_LINEAGE_BEGINNING_MSG = "Lineage must begin with a valid cycle marker.";
    public static final String MORE_THAN_TWO_PIPES_MSG = "Lineage cannot have more than two pipes.";
    private static final String LINEAGE_HAS_MORE_THAN_ONE_PIPE_MSG = "Coded lines can contain only one pipe in the lineage.";
    public static final String ILLEGAL_BACKCROSS_AFTER_FINISHING_PIPE = "Lineage is not valid for a finished backcross record.  Please modify the lineage so that there are no backcross cycles after the finishing pipe.�";
    public static final String INVALID_CHARACTER_MSG = "Lineage contains invalid character";


    public LineageSyntaxChecker(String lineage) {
        if (StringUtils.isNullOrEmpty(lineage)) {
            throw new IllegalArgumentException(ILLEGAL_ARG_EXCEP_MSG);
        }

        this.lineage = lineage;
    }

    public void checkLineageHasNoMoreThanOnePipe() throws LineageSyntaxException {
        String regex = "\\|";
        int count = 0;
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        while (matcher.find()) {
            count++;
        }

        if (count > 1) {
            throw new LineageSyntaxException(LINEAGE_HAS_MORE_THAN_ONE_PIPE_MSG);
        }

    }

    public void validateLineageBeginsWithAtCharOrNumberWithOptionalAlphaCharacters() throws LineageSyntaxException {
        String regex = "^" + cycleMarkerPrefix + "[" + LineageSyntaxConstants.CYCLE_MARKERS + "]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        if (!matcher.find()) {
            throw new LineageSyntaxException(INVALID_LINEAGE_BEGINNING_MSG);
        }
    }

    private boolean checkCycleMarkerHasValidPrefix(String cycleMarkerStringWithPrefix) {
        String regex = cycleMarkerPrefix + "[" + LineageSyntaxConstants.CYCLE_MARKERS + "]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(cycleMarkerStringWithPrefix);

        return matcher.find();
    }

    public void validateLineageHasCycleMarkersWithValidPrefix() throws LineageSyntaxException {
        String[] invalidCycleMarkers = getInvalidCycleMarkerStrings(lineage);
        if (null != invalidCycleMarkers && invalidCycleMarkers.length > 0) {
            throw new LineageSyntaxException(INVALID_CYCLE_MARKERS_FOUND_MSG + getString(invalidCycleMarkers));
        }
    }

    private String[] getInvalidCycleMarkerStrings(String lineage) {
        String regex = "([^" + LineageSyntaxConstants.CYCLE_MARKERS + "|]+[" + LineageSyntaxConstants.CYCLE_MARKERS +
                "]?)|([" + LineageSyntaxConstants.CYCLE_MARKERS + "])";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        List list = new ArrayList();
        while (matcher.find()) {
            String cycleMarkerString = matcher.group();
            if (!checkCycleMarkerHasValidPrefix(cycleMarkerString)) {
                list.add(cycleMarkerString);
            }
        }

        return (list.isEmpty()) ? null : (String[]) list.toArray(new String[0]);
    }

    public boolean validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbols() throws LineageSyntaxException {
        return validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbolsInternal(lineage);
    }

    public boolean validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbols(String lineFunctionRefId) throws
            LineageSyntaxException {
        String lineageOfBLineParent = lineage;
        if (LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunctionRefId)) {
            lineageOfBLineParent = getBLineLineage(lineageOfBLineParent);
        }
        return validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbolsInternal(lineageOfBLineParent);
    }

    private boolean validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbolsInternal(String lineage) throws
            LineageSyntaxException {
        String regex = ">.*%|%.*>";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        if (matcher.find()) {
            throw new LineageSyntaxException(LINEAGE_HAS_BOTH_DH_BC_MSG);
        }

        return true;
    }

    protected String getBLineLineage(String lineage) {
        return !StringUtils.isNullOrEmpty(lineage) ?
                lineage.replaceAll(LineageSyntaxConstants.ALINE_SUFFIX_PATTERN_STRING, "") : lineage;
    }

    public boolean checkLineageIsAPipe() {
        return "|".equals(lineage);
    }

    public boolean checkLineageHasAtleastOnePipe() {
        String regex = "\\|";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        return matcher.find();
    }

    public void validateLineageHasNoMoreThanTwoPipesThatAreSeparatedByOneOrMoreCycles() throws LineageSyntaxException {
        String regex = "\\|([^\\|]*)\\|";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        String[] invalidCycleMarkers = null;
        String stringBetweenPipes;
        int numberOfPipes = 0;
        int startIndex = 0;
        while (matcher.find(startIndex)) {
            startIndex = matcher.end() - 1;
            numberOfPipes += 2;
            stringBetweenPipes = matcher.group();
            if (numberOfPipes > 2) {
                throw new LineageSyntaxException(MORE_THAN_TWO_PIPES_MSG);
            }
            if (!"||".equals(stringBetweenPipes)) {
                invalidCycleMarkers = getInvalidCycleMarkerStrings(stringBetweenPipes);
            } else {
                throw new LineageSyntaxException(NO_CYCLE_MARKERS_BETWN_PIPES_MSG);
            }
        }

        if (null != invalidCycleMarkers && invalidCycleMarkers.length > 0) {
            throw new LineageSyntaxException(INVALID_CYCLE_MARKERS_FOUND_MSG + getString(invalidCycleMarkers));
        }
    }

    private String getString(String[] strings) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < strings.length; i++) {
            buffer.append(strings[i]);
            buffer.append(" ");
        }

        return buffer.toString().trim();
    }

    public boolean checkLineageDoesNotHaveConsecutivePipes() {
        String regex = "^[^\\|]+\\|\\|[^\\|]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        return !matcher.find();
    }

    public boolean checkLineageHasMoreThanTwoPipes() {
        String regex = "((.?)+\\|){3}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);

        return matcher.find();
    }

    //Just a wrapper for different msg

    public void checkLineageHasValidCharactersAndCycleMarkersForCoded() throws LineageSyntaxException {
        try {
            validateLineageBeginsWithAtCharOrNumberWithOptionalAlphaCharacters();
        } catch (LineageSyntaxException e) {
            throw new LineageSyntaxException(INVALID_LINEAGE_STRING_EXCEP_MSG);
        }
    }

    public void validateLineageHasValidCharacters() throws LineageSyntaxException {
        String message = null;
        Pattern pattern = Pattern.compile(LineageSyntaxConstants.VALID_CHARACTERS_PATTERN_STRING);
        Matcher matcher = pattern.matcher(lineage);

        if (matcher.find()) {
            message = " - found character [" + matcher.group() + "] at character " + (matcher.start() + 1);
        }

        if (message != null) {
            throw new LineageSyntaxException(INVALID_CHARACTER_MSG + message);
        }
    }
}
