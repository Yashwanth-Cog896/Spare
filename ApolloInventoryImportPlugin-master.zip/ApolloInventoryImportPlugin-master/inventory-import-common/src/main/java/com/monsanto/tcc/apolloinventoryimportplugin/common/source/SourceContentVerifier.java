package com.monsanto.tcc.apolloinventoryimportplugin.common.source;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.exception.InvalidSourceStringContentException;

import java.util.Arrays;

/**
 * Created by IntelliJ IDEA. User: aagosw Date: Sep 26, 2008 Time: 11:29:40 AM To change this template use File |
 * Settings | File Templates.
 */
public class SourceContentVerifier {
    public static final String Invalid_Source_String_Content = "Inventory_Import_Parent is an invalid Source for incoming records. Please write a more specific source.";
    private String[] invalidSourceStrings = {"inventoryimportparent", "inventory import parent",
            "inventory_import_parent"};

    public void verify(String source) throws InvalidSourceStringContentException {
        if (!StringUtils.isNullOrEmpty(source) && Arrays.asList(invalidSourceStrings).contains(source.trim().toLowerCase())) {
            throw new InvalidSourceStringContentException(Invalid_Source_String_Content);
        }
    }
}
