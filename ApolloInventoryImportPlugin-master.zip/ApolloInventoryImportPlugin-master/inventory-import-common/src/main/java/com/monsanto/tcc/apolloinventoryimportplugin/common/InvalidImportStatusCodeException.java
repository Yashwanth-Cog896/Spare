/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

/**
 * Filename:    $RCSfile: InvalidImportStatusCodeException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: skumar5 $     On:$Date: 2007-01-03 19:52:48 $
 *
 * @author skumar5
 * @version $Revision: 1.1 $
 */
public class InvalidImportStatusCodeException extends Exception {
    public InvalidImportStatusCodeException(String msg) {
        super(msg);
    }
}