package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.builder;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 9, 2009
 * Time: 11:02:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class GenerationBuilderFactory {

    public static GenerationBuilder getGenerationBuilder(boolean isBiennailCrop, String mainRecordGeneration, String lineFunction) {
        return isBiennailCrop ? createBiennialGenerationBuilder(mainRecordGeneration, lineFunction) : createDefaultGenerationBuilder(mainRecordGeneration, lineFunction);
    }

    public static GenerationBuilder getGenerationBuilder(boolean isBiennailCrop, String mainRecordGeneration) {
        return isBiennailCrop ? createBiennialGenerationBuilder(mainRecordGeneration, null) : createDefaultGenerationBuilder(mainRecordGeneration, null);
    }

    public static GenerationBuilder getGenerationBuilder(boolean isBiennailCrop) {
        return isBiennailCrop ? createBiennialGenerationBuilder(null, null) : createDefaultGenerationBuilder(null, null);
    }

    private static GenerationBuilder createDefaultGenerationBuilder(String mainRecordGeneration, String lineFunction) {
        return new DefaultGenerationBuilder(mainRecordGeneration, lineFunction);

    }

    private static GenerationBuilder createBiennialGenerationBuilder(String mainRecordGeneration, String lineFunction) {
        return new BiennialGenerationBuilder(mainRecordGeneration, lineFunction);
    }
}
