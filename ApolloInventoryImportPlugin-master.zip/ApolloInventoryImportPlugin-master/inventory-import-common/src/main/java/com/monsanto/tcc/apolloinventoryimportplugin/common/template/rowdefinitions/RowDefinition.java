/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions;

/**
 * Filename:    $RCSfile: RowDefinition.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2008-03-18 16:41:33 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public interface RowDefinition {
    public static final int CELL_TYPE_STRING = 0;
    public static final int CELL_TYPE_NUMERIC = 1;
    public static final int CELL_TYPE_STRING_DEFAULT = 2;

    public abstract RowMetaData getRowMetaData();

    public abstract int getRowCount();

    public abstract String getRowType();

    public abstract String getCropName();

    public abstract void setCropName(String cropName);
}