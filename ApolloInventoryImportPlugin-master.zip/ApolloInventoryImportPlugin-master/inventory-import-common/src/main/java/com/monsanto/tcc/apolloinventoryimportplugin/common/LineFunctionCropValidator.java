/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;

/**
 * Filename:    $RCSfile: LineFunctionCropValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-08 20:44:38 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class LineFunctionCropValidator {
    private static final String C_CORN_MSG = "C line function can be used only with Corn";

    public void validateCropLineFunction(String lineFunctionRefId, String cropName) throws LineFunctionCropException {
        if (LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(lineFunctionRefId)) {
            if (!"Corn".equalsIgnoreCase(cropName)) {
                throw new LineFunctionCropException(C_CORN_MSG);
            }
        }
    }
}