/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;

/**
 * Filename:    $RCSfile: FormulaCell.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-23 21:42:46 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class FormulaCell implements Cell {
    private HSSFCell cell;

    public FormulaCell(HSSFCell cell) {
        this.cell = cell;
    }

    public String getValue() {
        // Formulae are not supported in POI at this time.
        // From the API: DONT USE FORMULAS IN THIS RELEASE WE'LL THROW YOU A RUNTIME EXCEPTION IF YOU DO
        return "";
    }
}