/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

/**
 * Filename:    $RCSfile: NullOrigin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-01-30 18:05:20 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NullOrigin extends Origin {
    public boolean isHybrid() {
        return false;
    }

    protected OriginEntity getOriginTree() {
        return new OriginEntity(null);
    }

    public String getOriginString() {
        return "";
    }

    public int getDosage() {
        return 0;
    }
}