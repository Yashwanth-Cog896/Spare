/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

import java.util.*;

/**
 * Filename:    $RCSfile: OriginSyntaxVerifier.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $ On:$Date:
 * 2008/01/28 20:45:21 $
 *
 * @author SSPEYY
 * @version $Revision: 1.14 $
 */
public class OriginSyntaxVerifier {
    public static final String DOSAGE_ERROR = "More than one dosage exists in the given origin";
    public static final String DOSAGE_PARSE_EXCEP_MSG = "Backcross dosage must be a numeric value greater than Zero";
    public static final String MORE_THAN_ONE_COMPONENT = "Invalid Origin.More than one component exists in the given origin.";
    public static final String STARTING_WITH_NON_ENTITY_MSG = "Origin cannot start with a * or any of ";
    public static final String ENDING_WITH_NON_ENTITY_MSG = "Origin cannot end with a * or any of ";
    public static final String MISSING_LEFT_DELIMITERS_MSG = "Not all lower order delimiters found to the LEFT of the highest order delimiter ";
    public static final String MISSING_RIGHT_DELIMITERS_MSG = "Not all lower order delimiters found to the RIGHT of the highest order delimiter ";
    public static final String MULTIPLE_HIGH_ORDER_DELIM_MSG = "Found more than once the highest order delimiter - ";
    public static final String MULTIPLE_LEFT_DELIMITERS_MSG = "Found the same lower order delimiter more than once on the LEFT of highest order delimiter.";
    public static final String MULTIPLE_RIGHT_DELIMITERS_MSG = "Found the same lower order delimiter more than once on the RIGHT of highest order delimiter.";
    public static final String MISSING_LOWER_ORDER_DELIM_MSG = "No lower order delimiters found on either side of the highest order delimiter.";
    public static final String NOT_ENOUGH_DELIMETERS_MSG = "The count of expected lower order delimiters on the LEFT or RIGHT of highest order delimiter does not match - ";
    public static final String NUMBERFORMAT_EXCEP_MSG = "Encountered NumberFormatExpression while parsing dosage - ";
    public static final String INVALID_ORIGIN = "Invalid Origin";
    public static final String ROW_LEVEL_TOO_SMALL_MSG = "Row level cannot be less than 0";

    private static final String ASTERISK = "*";

    private Integer dosage;
    private String[] validDelimiters;
    private Map validDelimiterIndexMap;

    private List entityList = new ArrayList();
    private String recurringEntity;
    private static final String OPEN_PARENTHESIS = "(";

    private static final String CLOSE_PARANTHESIS = ")";
    private String[] delimitersInOrigin;
    private List preOrderEntityList = new ArrayList();
    private OriginEntity originRootEntity;
    private boolean isTreeValid = false;

    public OriginSyntaxVerifier(String origin) throws InvalidOriginSyntaxException {
        this(new OriginParser(origin));
    }

    public OriginSyntaxVerifier(String origin, int initialEntityDisplayLevel) throws InvalidOriginSyntaxException {
        this(new OriginParser(origin, initialEntityDisplayLevel));
    }

    public OriginSyntaxVerifier(OriginParser originParser) throws InvalidOriginSyntaxException {
        isTreeValid = false;
        if (null == originParser) {
            throw new IllegalArgumentException("OriginParser is required");
        }

        originRootEntity = originParser.getOriginTree();
        validDelimiters = originParser.getValidDelimiters();
        initValidDelimiterIndexMap(validDelimiters);
        validateEachTreeNodeInPREOrder(originRootEntity);
        buildEntities(originRootEntity);
        buildRecurringParentAndDosage();
        isTreeValid = true;
    }

    public OriginEntity getOriginTree() throws InvalidOriginSyntaxException {
        if (isTreeValid) {
            return originRootEntity;
        } else {
            throw new InvalidOriginSyntaxException(INVALID_ORIGIN);
        }
    }

    public OriginEntity getOriginTree(int desiredRowLevel) throws InvalidOriginSyntaxException {
        if (desiredRowLevel < 0) {
            throw new IllegalArgumentException(ROW_LEVEL_TOO_SMALL_MSG);
        }
        OriginEntity copy = null;
        try {
            copy = (OriginEntity) originRootEntity.clone();
            reduceEntityTree(copy.getFemaleParent(), 0, desiredRowLevel - 1);
            reduceEntityTree(copy.getMaleParent(), 0, desiredRowLevel - 1);
        } catch (CloneNotSupportedException e) {
            throw new IllegalStateException(e.getMessage());
        }
        return copy;
    }

    private void reduceEntityTree(OriginEntity entityTree, int currentRowLevel, int desiredRowLevel) {
        if (currentRowLevel > desiredRowLevel) {
            return;
        }
        if (entityTree != null) {
            if (currentRowLevel == desiredRowLevel) {
                entityTree.setFemaleParent(null);
                entityTree.setMaleParent(null);
            }
            reduceEntityTree(entityTree.getFemaleParent(), currentRowLevel + 1, desiredRowLevel);
            reduceEntityTree(entityTree.getMaleParent(), currentRowLevel + 1, desiredRowLevel);
        }
    }

    private void initValidDelimiterIndexMap(String[] validDelimiters) {
        validDelimiterIndexMap = new HashMap();
        for (int i = 0; i < validDelimiters.length; i++) {
            String validDelimiter = validDelimiters[i];
            validDelimiterIndexMap.put(validDelimiter, new Integer(i));
        }
    }

    private void validateEachTreeNodeInPREOrder(OriginEntity currentEntity) throws InvalidOriginSyntaxException {
        if (currentEntity != null) {
            doValidations(currentEntity);
            validateEachTreeNodeInPREOrder(currentEntity.getFemaleParent());
            validateEachTreeNodeInPREOrder(currentEntity.getMaleParent());
        }
    }

    private void doValidations(OriginEntity currentEntity) throws InvalidOriginSyntaxException {
        checkForInvalidStartAndEndCharacters(currentEntity.getOrigin());
        validateDelimiterRules(currentEntity);
    }

    private void checkForInvalidStartAndEndCharacters(String currentOrigin) throws InvalidOriginSyntaxException {
        if (currentOrigin.startsWith(ASTERISK) || originStartsWithDelimiter(currentOrigin)) {
            throw new InvalidOriginSyntaxException(
                    STARTING_WITH_NON_ENTITY_MSG + Arrays.asList(validDelimiters));
        } else if (currentOrigin.endsWith(ASTERISK) ||
                originEndsWithDelimiter(currentOrigin)) {
            throw new InvalidOriginSyntaxException(ENDING_WITH_NON_ENTITY_MSG + Arrays.asList(validDelimiters));
        }
    }

    private boolean originStartsWithDelimiter(String currentOrigin) {
        for (int i = 0; i < validDelimiters.length; i++) {
            String validDelimiter = validDelimiters[i];
            if (currentOrigin.startsWith(validDelimiter)) {
                return true;
            }
        }
        return false;
    }

    private boolean originEndsWithDelimiter(String currentOrigin) {
        for (int i = 0; i < validDelimiters.length; i++) {
            String validDelimiter = validDelimiters[i];
            if (currentOrigin.endsWith(validDelimiter)) {
                return true;
            }
        }

        return false;
    }

    private void validateDelimiterRules(OriginEntity currentEntity) throws InvalidOriginSyntaxException {

        initializeDelimitersInCurrentOrigin(currentEntity.getDelimitersInOrigin());

        String highestOrderDelimiter = getHighestOrderDelimiter();

        if (highestOrderDelimiter == null) {
            return;
        } // Nothing to validate - TODO: Is this okay?

        if (getCountOfHighestOrderDelimiter(highestOrderDelimiter) > 1) {
            throw new InvalidOriginSyntaxException(MULTIPLE_HIGH_ORDER_DELIM_MSG + "[" + highestOrderDelimiter + "]");
        }
        if (!"\\".equals(highestOrderDelimiter)) {
            if ((getIndexOfHighestOrderDelimiter(validDelimiters, highestOrderDelimiter) + 1) !=
                    (maxDepth(currentEntity) - 1)) {
                throw new InvalidOriginSyntaxException(NOT_ENOUGH_DELIMETERS_MSG);
            }
        }
    }

    private int maxDepth(OriginEntity node) {
        if (node == null) {
            return (0);
        } else {
            int lDepth = maxDepth(node.getFemaleParent());
            int rDepth = maxDepth(node.getMaleParent());
            return (Math.max(lDepth, rDepth) + 1);
        }
    }

    private void initializeDelimitersInCurrentOrigin(String[] delimitersInOrigin) {
        this.delimitersInOrigin = delimitersInOrigin;
    }

    private String getHighestOrderDelimiter() {
        int maxIndex = -1;
        if (delimitersInOrigin != null) {
            for (int i = 0; i < delimitersInOrigin.length; i++) {
                String delimiter = delimitersInOrigin[i];
                maxIndex = Math.max(maxIndex, ((Integer) validDelimiterIndexMap.get(delimiter)).intValue());
            }
        }

        return (maxIndex > -1) ? validDelimiters[maxIndex] : null;
    }

    private int getCountOfHighestOrderDelimiter(String highestOrderDelimiter) {
        int count = 0;

        for (int i = 0; i < delimitersInOrigin.length; i++) {
            if (delimitersInOrigin[i].equals(highestOrderDelimiter)) {
                count++;
            }
        }

        return count;
    }

    private int getIndexOfHighestOrderDelimiter(String[] delimiters, String highestOrderDelimiter) {
        if (delimiters != null) {
            for (int i = 0; i < delimiters.length; i++) {
                if (delimiters[i].equals(highestOrderDelimiter)) {
                    return i;
                }
            }
        }

        return -1;
    }

    private void buildEntities(OriginEntity originRootEntity) throws InvalidOriginSyntaxException {

        if (originRootEntity != null) {
            if (originRootEntity.isLeafEntity()) {
                preOrderEntityList.add(originRootEntity);
            }
            if ("\\".equals(originRootEntity.getOperator())) {
                buildEntities(originRootEntity.getMaleParent());
                buildEntities(originRootEntity.getFemaleParent());
            } else {
                buildEntities(originRootEntity.getFemaleParent());
                buildEntities(originRootEntity.getMaleParent());
            }
        }
    }

    private void buildRecurringParentAndDosage() throws InvalidOriginSyntaxException {
        String rParent;
        List recurringParentList = buildRecurringParentList();
        if (recurringParentList.size() > 1) {
            throw new InvalidOriginSyntaxException(DOSAGE_ERROR);
        } else if (recurringParentList.size() > 0 && recurringParentList.size() <= 1) {
            rParent = (String) recurringParentList.get(0);
            recurringEntity = rParent.substring(0, rParent.lastIndexOf(ASTERISK));
            dosage = getDosageFromString(rParent.substring(rParent.lastIndexOf(ASTERISK), rParent.length()));
        } else {
            recurringEntity = null;
        }
    }

    private List buildRecurringParentList() {
        List recurringParentList = new ArrayList();
        String tempOrigin;
        for (int i = 0; i < preOrderEntityList.size(); i++) {
            String currentOrigin = ((OriginEntity) preOrderEntityList.get(i)).getOrigin();
            if (currentOrigin.lastIndexOf(CLOSE_PARANTHESIS) > -1) {
                tempOrigin = currentOrigin
                        .substring((currentOrigin.lastIndexOf(CLOSE_PARANTHESIS) + 1), currentOrigin.length());
            } else {
                tempOrigin = currentOrigin;
            }
            if (tempOrigin.indexOf(ASTERISK) > -1) {
                recurringParentList.add(currentOrigin);
            }
        }
        return recurringParentList;
    }

    private Integer getDosageFromString(String dosageString) throws InvalidOriginSyntaxException {
        if (dosageString != null && dosageString.length() > 0) {
            dosageString = dosageString.substring(1, dosageString.length());
        }

        Integer dosageInteger;
        try {
            dosageInteger = new Integer(dosageString);
        } catch (NumberFormatException e) {
            throw new InvalidOriginSyntaxException(NUMBERFORMAT_EXCEP_MSG + e.getMessage());
        }

        if (dosageInteger != null && dosageInteger.intValue() == 0) {
            throw new InvalidOriginSyntaxException(DOSAGE_PARSE_EXCEP_MSG);
        }

        return dosageInteger;
    }

    private void removeStartingAndEndingParenthesis() {
        if (recurringEntity != null && recurringEntity.startsWith(OPEN_PARENTHESIS)) {
            recurringEntity = recurringEntity.substring(1, recurringEntity.length() - 1);
        }
    }

    public String getRecurringEntity() {
        removeStartingAndEndingParenthesis();
        return recurringEntity;
    }

    public String[] getEntities() {
        getOriginsFromEntityList();
        return (String[]) entityList.toArray(new String[0]);
    }

    private void getOriginsFromEntityList() {
        if (preOrderEntityList != null) {
            for (int i = 0; i < preOrderEntityList.size(); i++) {
                entityList.add(((OriginEntity) preOrderEntityList.get(i)).getOrigin());
            }
        }
    }

    public List getPreOrderEntityList() {
        return new ArrayList(preOrderEntityList);
    }

    public Integer getDosage() {
        return dosage;
    }
}