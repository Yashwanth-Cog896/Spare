/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header;

import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;

import java.util.Date;
import java.util.Set;

/**
 * Filename:    $RCSfile: StagingInventoryHeader.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2007-02-19 18:34:37 $
 *
 * @author skumar5
 * @version $Revision: 1.2 $
 */
public class StagingInventoryHeader {
    private Long id;
    private String userId;
    private String cropName;
    private String templateName;
    private Date batchDate;
    private ImportType importType;
    private Set stagingInventory;

    public Date getBatchDate() {
        return batchDate;
    }

    public void setBatchDate(Date batchDate) {
        this.batchDate = batchDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public Set getStagingInventory() {
        return stagingInventory;
    }

    public void setStagingInventory(Set stagingInventory) {
        this.stagingInventory = stagingInventory;
    }

    public ImportType getImportType() {
        return importType;
    }

    public void setImportType(ImportType importType) {
        this.importType = importType;
    }
}