/*
 StagingInventoryEntity was created on Jan 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory;

import com.monsanto.services.domain.common.Entity;
import com.monsanto.tcc.apolloinventoryimportplugin.common.CollapsableEntity;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: StagingInventoryEntity.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: aaanna $     On:$Date: 2008-07-11 08:31:57 $
 *
 * @author SRKARNA
 * @version $Revision: 1.12 $
 */
public class StagingInventoryEntity implements Entity, CollapsableEntity {
    private StagingInventory stagingInventory;
    private int level = 0;
    private boolean subRecord = false;
    private String userId;
    private Set parentIds = new LinkedHashSet();
    private boolean collapsed;
    private boolean approveEvent = false;
    private boolean selection = true;


    public StagingInventoryEntity(StagingInventory stagingInventory) {
        this.stagingInventory = stagingInventory;
    }

    public Object getID() {
        return stagingInventory.getId();
    }

    public StagingInventory getStagingInventory() {
        return stagingInventory;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public boolean isSubRecord() {
        return subRecord;
    }

    public void setSubRecord(boolean subRecord) {
        this.subRecord = subRecord;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getNumberOfParents() {
        return null == parentIds ? 0 : parentIds.size();
    }

    public void addParentId(Long parentId) {
        if (null == parentIds) {
            this.parentIds = new LinkedHashSet();
        }
        this.parentIds.add(parentId);
    }

    public void setParentIds(Set parentIds) {
        this.parentIds = parentIds;
    }

    public Set getParentIds() {
        return new LinkedHashSet(this.parentIds);
    }

    public boolean isCollapsed() {
        return collapsed;
    }

    public void setCollapsed(boolean collapsed) {
        this.collapsed = collapsed;
    }

    public Collection<Object> getCollapsableRecords() {
        return parentIds;
    }

    public boolean isCollapsable() {
        return (getNumberOfParents() != 0);
    }

    public boolean isApproveEvent() {
        return approveEvent;
    }

    public void setApproveEvent(boolean approveEvent) {
        this.approveEvent = approveEvent;
    }

    public boolean isSelection() {
        return selection;
    }

    public void setSelection(boolean selection) {
        this.selection = selection;
    }
}