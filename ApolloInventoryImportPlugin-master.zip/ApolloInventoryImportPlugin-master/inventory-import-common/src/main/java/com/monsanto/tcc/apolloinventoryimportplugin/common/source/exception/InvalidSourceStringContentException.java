package com.monsanto.tcc.apolloinventoryimportplugin.common.source.exception;

/**
 * Created by IntelliJ IDEA. User: aagosw Date: Sep 26, 2008 Time: 11:31:53 AM To change this template use File |
 * Settings | File Templates.
 */
public class InvalidSourceStringContentException extends Exception {
    public InvalidSourceStringContentException(String message) {
        super(message);
    }
}
