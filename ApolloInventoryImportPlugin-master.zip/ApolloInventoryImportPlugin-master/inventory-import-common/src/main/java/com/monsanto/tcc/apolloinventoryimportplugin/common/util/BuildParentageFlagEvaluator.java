/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import com.monsanto.Util.StringUtils;

/**
 * Filename:    $RCSfile: BuildParentageFlagEvaluator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-11-13 17:02:18 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class BuildParentageFlagEvaluator {
    public static final String BUILD_PARENTAGE_YES = "Y";
    public static final String BUILD_PARENTAGE_NO = "N";
    private String buildParentageFlag;

    public BuildParentageFlagEvaluator(String buildParentageFlag) {
        this.buildParentageFlag = buildParentageFlag;
    }

    public String getValue() {
        if (!StringUtils.isNullOrEmpty(buildParentageFlag) &&
                buildParentageFlag.trim().toUpperCase().startsWith(BUILD_PARENTAGE_YES)) {
            return BUILD_PARENTAGE_YES;
        }
        return BUILD_PARENTAGE_NO;
    }
}