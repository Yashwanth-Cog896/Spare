/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: LineageSyntaxConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-06-19 15:23:31 $
 *
 * @author ddbrow5
 * @version $Revision: 1.6 $
 */
public class LineageSyntaxConstants {
    public static final String CYCLE_MARKERS = ".#!$%>";
    public static final String ALINE_SUFFIX_PATTERN_STRING = "@>$|[0-9]+[a-zA-Z]*>\\|?$|[0-9]+>$|[0-9]*>\\|$|@>\\|";
    public static final String VALID_CHARACTERS_PATTERN_STRING = "[^a-z0-9\\.!%#\\$>\\|@]";
}