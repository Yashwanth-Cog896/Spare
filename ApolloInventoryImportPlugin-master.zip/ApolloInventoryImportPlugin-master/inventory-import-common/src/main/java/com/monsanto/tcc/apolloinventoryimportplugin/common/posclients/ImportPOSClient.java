/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;

/**
 * Filename:    $RCSfile: ImportPOSClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-01 20:19:01 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class ImportPOSClient extends AbstractPOSClient {
    private static final String POS_ACTIVITY = "ImportStagingInventoryData";

    public ImportPOSClient() {
        super.setPosActivityName(POS_ACTIVITY);
    }

    public void importStagingInventories(StagingInventoryHeader inventoryHeader,
                                         StagingInventory[] stagingInventory) throws ActivityClientException {
        sendToPos(createCompositeObject(inventoryHeader, stagingInventory));
    }

    public int getImportFailedRecordCount() {
        List stagingInventoryList = getImportFailedRecords();
        return (null != stagingInventoryList) ? stagingInventoryList.size() : 0;
    }

    public List getImportFailedRecords() {
        return (List) getResponseEnvelope().get(StagingInventory.class);
    }

    private CompositeObject createCompositeObject(StagingInventoryHeader inventoryHeader,
                                                  StagingInventory[] stagingInventory) {
        CompositeObject payload = new CompositeObject();
        payload.add(getFilterWithDefaultFilterId());
        inventoryHeader.setStagingInventory(null);
        payload.add(inventoryHeader);

        for (int i = 0; i < stagingInventory.length; i++) {
            StagingInventory inventory = stagingInventory[i];
            inventory.setInventoryHeader(null);
            payload.add(inventory);
        }
        return payload;
    }
}