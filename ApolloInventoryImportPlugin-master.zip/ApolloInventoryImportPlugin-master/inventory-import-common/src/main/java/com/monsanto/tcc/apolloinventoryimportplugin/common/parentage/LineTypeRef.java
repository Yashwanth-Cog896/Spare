/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.parentage;

/**
 * Filename:    $RCSfile: LineTypeRef.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date:
 * 2007/02/06 02:54:32 $
 *
 * @author skumar5
 * @version $Revision: 1.1 $
 */
public interface LineTypeRef {
    public static final String SEGPOP = "SEGPOP";
    public static final String HYBRID = "HYBRID";
    public static final String OP_VAR = "OP_VAR";
    public static final String CODED = "CODED";
    public static final String FINISHED = "FINISHED";
    public static final String INBRED = "INBRED";

}