/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;

/**
 * Filename:    $RCSfile: LineageFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/11/14 17:19:57 $
 *
 * @author ddbrow5
 * @version $Revision: 1.6 $
 */
public class LineageFactory {
    public Lineage createLineage(String lineFunction, String lineageString) throws InvalidLineageException {
        if (!StringUtils.isNullOrEmpty(lineFunction)) {
            if (lineFunction.trim().equalsIgnoreCase(LineFunctionConstants.A_LINE_FUNCTION)) {
                return new ALineLineage(lineageString);
            }
            if (lineFunction.trim().equalsIgnoreCase(LineFunctionConstants.C_LINE_FUNCTION)) {
                return new CLineLineage(lineageString);
            }
        }
        return createLineage(lineageString);
    }

    public Lineage createLineage(String lineageString) {
        if (StringUtils.isNullOrEmpty(lineageString)) {
            return new NullLineage();
        }
        return new NotNullLineage(lineageString);
    }
}