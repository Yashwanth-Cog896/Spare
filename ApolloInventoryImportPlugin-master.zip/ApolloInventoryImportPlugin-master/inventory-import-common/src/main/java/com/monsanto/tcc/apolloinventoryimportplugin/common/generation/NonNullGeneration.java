/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;

/**
 * Filename:    $RCSfile: NonNullGeneration.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-05 15:13:35 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class NonNullGeneration implements Generation {
    protected String generation;
    private static final String MALE_STERILE_PREFIX = "MSC";
    private static final String BACKCROSS_PREFIX = "BC";
    private static final String INBRED_STRING = "INBRED";
    private static final String INVALID_MSC_MSG = "Invalid format of MSC generation (must include generation number)";
    private static final String INVALID_BC_MSG = "Invalid format of BC generation (must include generation number)";

    public NonNullGeneration(String generation) throws InvalidCLineGenerationException {
        this.generation = generation.toUpperCase().trim();
        validate();
    }

    private void validate() throws InvalidCLineGenerationException {
        if (isMSC()) {
            if (generation.length() <= MALE_STERILE_PREFIX.length()) {
                throw new InvalidCLineGenerationException(INVALID_MSC_MSG);
            }
        }
        if (isBackcross()) {
            if (generation.length() <= BACKCROSS_PREFIX.length()) {
                throw new InvalidCLineGenerationException(INVALID_BC_MSG);
            }
        }
    }

    public boolean isMSC() {
        return generation.startsWith(MALE_STERILE_PREFIX);
    }

    public boolean isMSC0() {
        return generation.equals(MALE_STERILE_PREFIX + "0");
    }

    public boolean isBackcross() {
        return generation.startsWith(BACKCROSS_PREFIX);
    }

    public boolean isNull() {
        return StringUtils.isNullOrEmpty(generation);
    }

    public boolean isInbred() {
        return generation.equals(INBRED_STRING);
    }

    public int getGeneration() {
        int generationValue = 0;
        if (!isInbred() && !isNull()) {
            if (isBackcross()) {
                generationValue = getBackcrossGeneration();
            } else if (isMSC()) {
                generationValue = getMaleSterileGeneration();
            } else {
                generationValue = getNonBackcrossNonMaleSterileGeneration();
            }
        }
        return generationValue;
    }

    private int getBackcrossGeneration() {
        int generationValue = 0;
        if (generation.length() > 2) {
            generationValue = getIntFromString(generation.substring(2));
        }
        return generationValue;
    }

    private int getMaleSterileGeneration() {
        int generationValue = 0;
        if (generation.length() > 3) {
            generationValue = getIntFromString(generation.substring(3));
        }
        return generationValue;
    }

    private int getNonBackcrossNonMaleSterileGeneration() {
        int generationValue = 0;
        if (generation.length() > 0) {
            generationValue = getIntFromString(generation.replaceAll("^[^0-9]+", ""));
        }
        return generationValue;
    }

    private int getIntFromString(String str) {
        int value = 0;
        if (!StringUtils.isNullOrEmpty(str)) {
            try {
                value = Integer.parseInt(str);
            } catch (NumberFormatException e) {
                // not handled on purpose
            }
        }
        return value;
    }
}