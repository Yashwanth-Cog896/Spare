/*
 CompetitorStagingInventorySanityChecker was created on Apr 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.competitorproducts;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.ALineFunctionCytoplasmCheckCompetitorCommercialLines;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionValuesCompetitorCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.NonALineFunctionCytoplasmCompetitorCommercialLinesCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;

/**
 * Filename:    $RCSfile: CompetitorStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $     On:$Date: 2009-06-05 14:08:09 $
 *
 * @author SRKARNA
 * @version $Revision: 1.6 $
 */
public class CompetitorStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    private StagingInventory stagingInventory;

    public CompetitorStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);

        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getProductName())) {
            msgList.add(MANDATORY_CHECK_MSG + "Product Name");
        }
        new AllowedLineFunctionValuesCompetitorCheck(stagingInventory.getLineFunction()).check(msgList);

        if (isLineFunctionA(stagingInventory.getLineFunction())) {
            new ALineFunctionCytoplasmCheckCompetitorCommercialLines(
                    stagingInventory.getCytoplasmDonorPedigree()).check(msgList);
        } else {
            new NonALineFunctionCytoplasmCompetitorCommercialLinesCheck(
                    stagingInventory.getCytoplasmDonorPedigree()).check(msgList);
        }
    }

    private boolean isLineFunctionA(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) &&
                LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }
}
