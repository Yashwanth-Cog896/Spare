/*
 DefaultConstraint was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import java.util.Map;

/**
 * Filename:    $RCSfile: DefaultConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-12 20:22:31 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class DefaultConstraint implements DataConstraint {
    private String messageToDisplayOnFailure;

    public DefaultConstraint(String subject) {
        messageToDisplayOnFailure = "";
    }

    public boolean validate(Map dataSource) {
        return true;
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        this.messageToDisplayOnFailure = messageToDisplayOnFailure;
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}