/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: CollectionSplitter.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-04-06 21:58:24 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class CollectionSplitter {
    public static final String ILLEGAL_SPLIT_SIZE_MSG = "splitSize must be greater than zero";

    public static Set[] split(Set set, int splitSize) {
        if (null == set) {
            return null;
        } else if (splitSize <= 0) {
            throw new IllegalArgumentException(ILLEGAL_SPLIT_SIZE_MSG);
        }

        int splitArraySize = getSplitArraySize(set.size(), splitSize);
        Set[] subSets = new Set[splitArraySize];
        Object[] objects = set.toArray();
        for (int i = 0; i < subSets.length; i++) {
            int elementsLeft = (set.size() - i * splitSize);
            int copySize = Math.min(splitSize, elementsLeft);
            Object[] subObjects = new Object[copySize];
            System.arraycopy(objects, splitSize * i, subObjects, 0, copySize);
            subSets[i] = new HashSet(Arrays.asList(subObjects));
        }

        return subSets;
    }

    private static int getSplitArraySize(int originalSetSize, int splitSize) {
        int arraySize = originalSetSize / splitSize;
        if (arraySize > -1 && arraySize * splitSize < originalSetSize) {
            arraySize += 1;
        }
        return arraySize;
    }
}