package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 13, 2008 Time: 3:12:46 PM To change this template use File |
 * Settings | File Templates.
 */
public class FinishedLinesLineageSyntaxChecker extends LineageSyntaxChecker {

    private String lineage;

    public FinishedLinesLineageSyntaxChecker(String lineage) {
        super(lineage);
        this.lineage = lineage;
    }

    public void validateLineFunctionDoesNotHaveBackCrossAfterFinishingPipeForFinishedLines(String lineFunction) throws
            LineageSyntaxException {
        String lineageToValidate = lineage;
        if (LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
            if ('|' == (lineageToValidate.charAt(lineageToValidate.length() - 1))) {
                return;
            }
            lineageToValidate = getBLineLineage(lineageToValidate);
        }
        validateLineFunctionDoesNotHaveBackCrossAfterFinishingPipeForFinishedLinesInternal(lineageToValidate);

    }

    private void validateLineFunctionDoesNotHaveBackCrossAfterFinishingPipeForFinishedLinesInternal(String lineage) throws
            LineageSyntaxException {
        String regex = "\\|([^>\\|])*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(lineage);
        if (!matcher.find()) {
            throw new LineageSyntaxException(ILLEGAL_BACKCROSS_AFTER_FINISHING_PIPE);
        }
    }
}
