/*
 StagingInventorySanityChecker was created on Apr 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial;

/**
 * Filename:    $RCSfile: StagingInventorySanityChecker.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2007-04-22 05:39:37 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public interface StagingInventorySanityChecker {
    void check() throws StagingInventorySanityCheckException;
}