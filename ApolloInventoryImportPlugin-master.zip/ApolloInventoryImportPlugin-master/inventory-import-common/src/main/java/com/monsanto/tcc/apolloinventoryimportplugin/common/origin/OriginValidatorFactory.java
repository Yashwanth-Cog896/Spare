/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

/**
 * Filename:    $RCSfile: OriginValidatorFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2008-11-10 21:37:22 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class OriginValidatorFactory {
    public OriginValidator createOriginValidator(String lineFunction, String lineType) {
        if (!StringUtils.isNullOrEmpty(lineFunction)) {
            if (lineFunction.equalsIgnoreCase(LineFunctionConstants.A_LINE_FUNCTION)) {
                return new ALineOriginValidator();
            }
            if (lineFunction.equalsIgnoreCase(LineFunctionConstants.C_LINE_FUNCTION)) {
                if (MaterialTypeConstants.FINISHED_LINES.equalsIgnoreCase(lineType) ||
                        MaterialTypeConstants.SEGPOP_LINES.equalsIgnoreCase(lineType)) {
                    return new CLineOriginValidatorForFinishedOrSegpop();
                }
                return new CLineOriginValidator();
            }
        }
        return new OriginValidator();
    }
}