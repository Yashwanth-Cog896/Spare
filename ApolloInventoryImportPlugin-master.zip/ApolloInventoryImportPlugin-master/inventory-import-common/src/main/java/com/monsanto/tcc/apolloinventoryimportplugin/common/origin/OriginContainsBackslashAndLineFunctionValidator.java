/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: OriginContainsBackslashAndLineFunctionValidator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $
 * On:          $Date: 2008-04-02 05:55:18 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class OriginContainsBackslashAndLineFunctionValidator {
    public void validate(String origin, String lineFunctionRefId) throws InvalidOriginSyntaxException {
        if (!isLineFunctionRefIdC(lineFunctionRefId) && isOriginHighestDelimiterBackslash(origin)) {
            throw new InvalidOriginSyntaxException("Origin cannot have \\ unless the line function is C");
        }
    }

    private boolean isOriginHighestDelimiterBackslash(String origin) throws InvalidOriginSyntaxException {
        if (doesOriginContainsBackslashDelimiter(origin)) {
            return true;
        }
        return false;
        //return !StringUtils.isNullOrEmpty(origin) && origin.indexOf("\\") > -1;
    }

    private boolean doesOriginContainsBackslashDelimiter(String originString) throws InvalidOriginSyntaxException {
        boolean status = false;
        if (StringUtils.isNullOrEmpty(originString)) {
            return status;
        }

        Origin origin = new Origin(originString);

        OriginEntity originTree = origin.getOriginTree();
        if (originTree != null && !StringUtils.isNullOrEmpty(originTree.getOperator())) {
            status = "\\".equals(originTree.getOperator()) ? true : false;
        }
        return status;
    }

    private boolean isLineFunctionRefIdC(String lineFunctionRefId) {
        return LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(lineFunctionRefId);
    }
}