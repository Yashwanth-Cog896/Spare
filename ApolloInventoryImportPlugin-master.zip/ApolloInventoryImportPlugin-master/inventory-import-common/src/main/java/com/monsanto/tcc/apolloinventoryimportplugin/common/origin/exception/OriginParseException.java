/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception;

/**
 * Filename:    $RCSfile: OriginParseException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-03-28 20:13:46 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class OriginParseException extends Exception {
    public OriginParseException(String msg) {
        super(msg);
    }
}