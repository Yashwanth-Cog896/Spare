/*
 Lineage was created on Feb 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: NotNullLineage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/22 16:29:52 $
 *
 * @author SRKARNA
 * @version $Revision: 1.12 $
 */
public class NotNullLineage implements Lineage {
    private static final String LINEAGE_REQ_MSG = "Lineage value is required.";
    private static final String CYCLE_MARKER_PATTERN_STRING = "[-.#!%$/>+:*~\\\\]";
    private static final String DOSAGE_PATTERN_STRING = ">";
    private static final String PIPE_STRING = "|";
    protected String lineage = null;

    public NotNullLineage(String lineage) {
        if (StringUtils.isNullOrEmpty(lineage)) {
            throw new IllegalArgumentException(LINEAGE_REQ_MSG);
        }
        this.lineage = lineage.trim();
        checkForInvalidCharacters();
    }

    public int getDosage() {
        int dosage = 0;
        Pattern pattern = Pattern.compile(DOSAGE_PATTERN_STRING);
        if (null != lineage) {
            Matcher matcher = pattern.matcher(lineage);
            while (matcher.find()) {
                dosage++;
            }
        }
        if (dosage > 0) {
            dosage++;
        } // because dosage is number of '>' + 1
        return dosage;
    }

    public int getNumberOfCycleMarkers() {
        return getCycleMarkers().length;
    }

    public String[] getCycleMarkers() {
        List cycleMarkerList = new ArrayList();
        Pattern pattern = Pattern.compile(CYCLE_MARKER_PATTERN_STRING);
        Matcher lineageMatcher = pattern.matcher(lineage);
        while (lineageMatcher.find()) {
            cycleMarkerList.add(lineageMatcher.group());
        }

        return (String[]) cycleMarkerList.toArray(new String[0]);
    }

    public boolean isBackcross() {
        boolean result = false;
        if (StringUtils.isNullOrEmpty(lineage)) {
            result = false;
        } else if (lineage.indexOf(DOSAGE_PATTERN_STRING) >= 0) {
            result = true;
        }

        return result;
    }

    public boolean isLineageNullOrPipe() {
        return isLineageNullOrEmpty() || isLineagePipe();
    }

    public boolean isLineageNullOrEmpty() {
        return StringUtils.isNullOrEmpty(lineage);
    }

    public boolean isLineagePipe() {
        return lineage.equals(PIPE_STRING);
    }

    private void checkForInvalidCharacters() {
        if (!StringUtils.isNullOrEmpty(lineage)) {
            try {
                new LineageSyntaxChecker(lineage).validateLineageHasValidCharacters();
            } catch (LineageSyntaxException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }
}