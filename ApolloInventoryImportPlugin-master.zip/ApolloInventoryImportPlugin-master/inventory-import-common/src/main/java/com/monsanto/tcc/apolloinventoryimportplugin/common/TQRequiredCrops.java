package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.tps.regulatory.traitquality.isolation.CropTO;

import java.util.Arrays;
import java.util.Collection;

public class TQRequiredCrops {
    public static String[] DEFAULT_REQUIRED_CROPS = {"OSR-Canola", "Corn", "Cotton", "Soybeans", "Tomato", "Squash", "Wheat"};
    private static String[] requiredCrops = {};

    private TQRequiredCrops() {
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Not supported for singleton");
    }

    public static String[] getRequiredCrops() {
        return requiredCrops;
    }

    public static boolean isCropTQRequired(String cropName) {
        return Arrays.asList(requiredCrops).contains(cropName);
    }

    public static void loadTQRequiredCrops(Collection<CropTO> requiredCrops) {
        int i = 0;
        if (requiredCrops != null) {
            String[] crops = new String[requiredCrops.size()];
            for (CropTO requiredCrop : requiredCrops) {
                crops[i++] = requiredCrop.getName();
            }
            TQRequiredCrops.requiredCrops = crops;
        }
    }

    public static void loadTQRequiredCrops(String[] requiredCrops) {
        TQRequiredCrops.requiredCrops = requiredCrops;
    }
}