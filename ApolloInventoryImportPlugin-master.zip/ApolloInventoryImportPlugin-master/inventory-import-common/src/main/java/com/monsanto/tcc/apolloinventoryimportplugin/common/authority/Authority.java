/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.authority;

import com.monsanto.Util.StringUtils;
import com.monsanto.services.domain.common.Entity;

/**
 * Filename:    $RCSfile: Authority.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-12 16:59:51 $
 *
 * @author SSPEYY
 * @version $Revision: 1.7 $
 */
public class Authority implements Entity {
    private Long midasUserId;
    private String loginId;
    private String firstName;
    private String middleName;
    private String lastName;

    public Long getMidasUserId() {
        return midasUserId;
    }

    public void setMidasUserId(Long midasUserId) {
        this.midasUserId = midasUserId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public Object getID() {
        return null;
    }

    public String toString() {
        return lastName + ", " + firstName
                + (StringUtils.isNullOrEmpty(middleName) ? "" : " " + middleName)
                + " (" + loginId + ")";
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}