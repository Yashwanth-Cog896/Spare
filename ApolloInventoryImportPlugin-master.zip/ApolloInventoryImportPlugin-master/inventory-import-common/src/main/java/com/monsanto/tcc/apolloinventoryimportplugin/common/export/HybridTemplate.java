package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions.RowDefinition;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions.RowDefinitionFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.template.rowdefinitions.RowMetaData;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * Filename:    $RCSfile: HybridTemplate.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2007-06-12 22:51:36 $
 *
 * @author DDBROW5
 * @version $Revision: 1.7 $
 */
public class HybridTemplate extends AbstractTemplate {
    public HybridTemplate(HSSFWorkbook workBook, HSSFSheet workSheet) {
        if (null == workBook) {
            throw new IllegalArgumentException("Work book cannot be null");
        }
        if (null == workSheet) {
            throw new IllegalArgumentException("Work sheet cannot be null");
        }
        this.workBook = workBook;
        this.workSheet = workSheet;
        createWorkSheetMetaData();
        numberOfColumns = workSheetMetaData.size();
    }

    private void createWorkSheetMetaData() {
        workSheetMetaData = new WorkSheetMetaData();
        RowDefinitionFactory rowDefinitionFactory = new RowDefinitionFactory();
        RowDefinition rowDefinition = rowDefinitionFactory.createRowDefintion(MaterialTypeConstants.HYBRID_LINES);
        RowMetaData rowMetaData = rowDefinition.getRowMetaData();
        int rowCount = rowDefinition.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            if (rowMetaData.isAppearsInTemplate(i) || rowMetaData.isAppearsInExportTemplate(i)) {
                workSheetMetaData.addColumn(rowMetaData.getGetMethodName(i), rowMetaData.getHSSFCellType(i));
            }
        }
    }
}
