/*
 OrDataConstraint was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.template.constraints;

import com.monsanto.Util.StringUtils;

import java.util.Map;

/**
 * Filename:    $RCSfile: OrDataConstraint.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-12 20:22:31 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class OrDataConstraint implements DataConstraint {
    private DataConstraint[] dataConstraints;
    private String messageToDisplayOnFailure;
    private boolean isMessageToDisplayOnFailureDefaultValue = true;

    public OrDataConstraint(DataConstraint[] dataConstraints) {
        if (null == dataConstraints) {
            throw new IllegalArgumentException("dataConstraints is required.");
        }

        this.dataConstraints = dataConstraints;
        this.messageToDisplayOnFailure = "";
    }

    public boolean validate(Map dataSource) {
        boolean status = false;
        this.messageToDisplayOnFailure = "";

        for (int i = 0; i < dataConstraints.length; i++) {
            status |= isConstraintValid(dataConstraints[i], dataSource);
        }

        return status;
    }

    private boolean isConstraintValid(DataConstraint constraint, Map dataSource) {
        if (!constraint.validate(dataSource)) {
            appendToMessageToDisplayOnFailureIfDefaultValueHasNotBeenSet(constraint.getMessageToDisplayOnFailure());
            return false;
        }
        return true;
    }

    private void appendToMessageToDisplayOnFailureIfDefaultValueHasNotBeenSet(String message) {
        if (!isMessageToDisplayOnFailureDefaultValue) {
            return;
        }
        if (!StringUtils.isNullOrEmpty(messageToDisplayOnFailure)) {
            messageToDisplayOnFailure += ";";
        }
        messageToDisplayOnFailure += message;
    }

    public void setMessageToDisplayOnFailure(String messageToDisplayOnFailure) {
        throw new UnsupportedOperationException("Cannot set messages at this level.");
    }

    public String getMessageToDisplayOnFailure() {
        return messageToDisplayOnFailure;
    }
}