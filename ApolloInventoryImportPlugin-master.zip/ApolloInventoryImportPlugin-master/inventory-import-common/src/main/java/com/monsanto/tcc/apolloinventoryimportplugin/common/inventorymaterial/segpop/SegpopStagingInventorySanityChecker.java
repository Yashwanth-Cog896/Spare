/*
 SegpopStagingInventorySanityChecker was created on Apr 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.segpop;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.CLineGenerationValidator;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.AbstractStagingInventorySanityChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.lineagecheckers.LineageCheckerForSegpop;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.ALineFunctionCytoplasmCheckForNonProductLines;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.AllowedLineFunctionNonHybridNonProductCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity.NonALineFunctionCytoplasmNonProductLinesCheck;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.ALineLineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidALineMSCLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: SegpopStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * srkarna $     On:$Date: 2009-06-05 14:08:07 $
 *
 * @author SRKARNA
 * @version $Revision: 1.19 $
 */
public class SegpopStagingInventorySanityChecker extends AbstractStagingInventorySanityChecker {
    private StagingInventory stagingInventory = null;
    public static final String INVALID_A_LINE_FUNCTION_GENERATION = "Invalid generation for A line function";

    public SegpopStagingInventorySanityChecker(StagingInventory stagingInventory) {
        super(stagingInventory);

        this.stagingInventory = stagingInventory;
    }

    protected void performMaterialSpecificChecks(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getGermplasmOwner())) {
            msgList.add(MANDATORY_CHECK_MSG + "Germplasm Owner");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getOrigin()) && !isLineFunctionC(stagingInventory.getLineFunction())) {
            msgList.add(MANDATORY_CHECK_MSG + "Origin");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getGeneration())) {
            msgList.add(MANDATORY_CHECK_MSG + "Generation");
        }

        if (StringUtils.isNullOrEmpty(stagingInventory.getLineage())
                && !isF1Generation() && !isLineFunctionC(stagingInventory.getLineFunction())) {
            msgList.add(MANDATORY_CHECK_MSG + "Lineage");
        }
        if (isLineFunctionA(stagingInventory.getLineFunction())) {
            if (!stagingInventory.isSubRecord()) {
                new ALineFunctionCytoplasmCheckForNonProductLines(stagingInventory.getCytoplasmDonorPedigree(),
                        stagingInventory.getCytoplasmDonorSource(), stagingInventory.getBuildParentage()).check(msgList);

                try {
                    new ALineLineage(stagingInventory.getLineage());
                } catch (InvalidALineMSCLineageException e) {
                    msgList.add(e.getMessage());
                }

                if (StringUtils.isNullOrEmpty(stagingInventory.getGeneration()) ||
                        !isGenerationValidMSC(stagingInventory.getGeneration())) {
                    msgList.add(INVALID_A_LINE_FUNCTION_GENERATION);
                }
            }
        } else {
            new NonALineFunctionCytoplasmNonProductLinesCheck(stagingInventory.getCytoplasmDonorPedigree(),
                    stagingInventory.getCytoplasmDonorSource()).check(msgList);
        }
        // TODO: AllowedLineFunctionValuesForSegpopSanityChecker was created for this iteration when we are implementing
        // TODO: C lines in Segpop
        // TODO: When we implement C line functions for Finished and Coded, modify
        // TODO: AllowedLineFunctionNonHybridNonProductCheck accordingly and replace this class.
        new AllowedLineFunctionNonHybridNonProductCheck(stagingInventory.getLineFunction()).check(msgList);
        checkLineage(msgList);
        validateGenerationForCLineFunction(msgList, stagingInventory.getLineFunction(), stagingInventory.getLineage(),
                stagingInventory.getGeneration(), stagingInventory.getOrigin());
    }

    private void validateGenerationForCLineFunction(List msgList, String lineFunction, String lineage, String generation,
                                                    String origin) {
        if (LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
            try {
                CLineGenerationValidator validator = new CLineGenerationValidator(generation, lineage, origin);
                validator.validateGeneration();
            } catch (InvalidCLineGenerationException e) {
                msgList.add(e.getMessage());
            }
        }
    }

    private boolean isLineFunctionA(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) &&
                LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }

    private boolean isLineFunctionC(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) &&
                LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }

    private void checkLineage(List msgList) {
        new LineageCheckerForSegpop(stagingInventory.getLineage(), stagingInventory.getGeneration(),
                stagingInventory.getLineFunction()).check(msgList);
    }

    private boolean isGenerationValidMSC(String generation) {
        String mscPatternString = "^MSC[0-9]+$";
        Pattern mscPattern = Pattern.compile(mscPatternString);
        Matcher mscMatcher = mscPattern.matcher(generation);
        return mscMatcher.matches();
    }

    private boolean isF1Generation() {
        return "F1".equalsIgnoreCase(stagingInventory.getGeneration());
    }
}