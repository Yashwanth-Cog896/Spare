/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.source.parentalsource;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;

import java.util.*;

/**
 * Filename:    $RCSfile: BuildParentalSourceString.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $
 * On:$Date: 2008-03-17 17:52:58 $
 *
 * @author SSPEYY
 * @version $Revision: 1.3 $
 */
public class BuildParentalSourceString {
    private static final String PARENT_SEPERATOR = "&";
    private static final String DELIMITER = ";";
    private static final String DEFAULT_SOURCE = SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE;

    private Set parentalSourcesSet;

    public BuildParentalSourceString(Set parentalSourcesSet) {
        this.parentalSourcesSet = parentalSourcesSet;
    }

    public String getParentalSourcesOriginalString() {
        if (parentalSourcesSet == null || parentalSourcesSet.size() == 0) {
            return "";
        }
        String psString = convertListToString(sortSetByLevelAndParentalRole());
        return replaceDefaultSources(psString);
    }

    private String replaceDefaultSources(String psString) {
        return psString.replaceAll(DEFAULT_SOURCE, "");
    }

    private String convertListToString(List list) {
        StringBuffer parentalSourcesStringBuffer = new StringBuffer();
        Iterator i = list.iterator();
        while (i.hasNext()) {
            parentalSourcesStringBuffer.append(i.next());
        }
        return parentalSourcesStringBuffer.toString();
    }

    private List sortSetByLevelAndParentalRole() {
        List parentalSourceList = sortSetAndConvertToList();
        return insertParentSeperatorsAndSourceDelimeters(parentalSourceList);

    }

    private List insertParentSeperatorsAndSourceDelimeters(List parentalSourcesList) {
        List sourceStringList = new ArrayList();

        for (int i = 0; i < parentalSourcesList.size(); i++) {
            ParentalSource currentParentalSource = (ParentalSource) parentalSourcesList.get(i);
            sourceStringList.add(currentParentalSource.getSource());
            if (i + 1 < parentalSourcesList.size()) {
                ParentalSource nextParentalSource = (ParentalSource) parentalSourcesList.get(i + 1);
                if (nextParentalSource.getRecordLevel().intValue() == currentParentalSource.getRecordLevel().intValue()) {
                    sourceStringList.add(PARENT_SEPERATOR);
                } else {
                    sourceStringList.add(DELIMITER);
                }
            }
        }
        return sourceStringList;
    }

    private List sortSetAndConvertToList() {
        List psList = new ArrayList();
        psList.addAll(parentalSourcesSet);
        Collections.sort(psList);
        return psList;
    }
}