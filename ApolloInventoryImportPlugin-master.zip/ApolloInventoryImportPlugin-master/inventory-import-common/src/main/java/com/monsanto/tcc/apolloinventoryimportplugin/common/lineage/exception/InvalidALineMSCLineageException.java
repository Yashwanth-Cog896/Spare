/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception;

/**
 * Filename:    $RCSfile: InvalidALineMSCLineageException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5
 * $     On:$Date: 2007-11-14 20:25:39 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class InvalidALineMSCLineageException extends InvalidLineageException {
    public InvalidALineMSCLineageException() {
    }

    public InvalidALineMSCLineageException(String message) {
        super(message);
    }

    public InvalidALineMSCLineageException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidALineMSCLineageException(Throwable cause) {
        super(cause);
    }
}