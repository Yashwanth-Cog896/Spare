/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.generation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidMSCGenerationException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: MSCGeneration.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-11-12 18:14:22 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class MSCGeneration {
    private static final String INVALID_MSC_GENERATION_MSG = "Generation is not a valid MSC generation.";
    private static final String GENERATION_STRING_REQ_MSG = "Generation string is required";
    private static final String MSC_GENERATION_PATTERN_STRING = "^MSC(\\d+)$";
    private String generationString;
    private Matcher matcher;

    public MSCGeneration(String generationString) throws InvalidMSCGenerationException {
        if (StringUtils.isNullOrEmpty(generationString)) {
            throw new IllegalArgumentException(GENERATION_STRING_REQ_MSG);
        }
        this.generationString = generationString.trim();
        matcher = createMatcher();
        validate();
    }

    private Pattern createPattern() {
        return Pattern.compile(MSC_GENERATION_PATTERN_STRING);
    }

    private Matcher createMatcher() {
        return createPattern().matcher(generationString);
    }

    private boolean validate() throws InvalidMSCGenerationException {
        if (!matcher.matches()) {
            throw new InvalidMSCGenerationException(INVALID_MSC_GENERATION_MSG);
        }
        return true;
    }

    public int getGenerationNumber() {
        return new Integer(matcher.group(1)).intValue();
    }
}