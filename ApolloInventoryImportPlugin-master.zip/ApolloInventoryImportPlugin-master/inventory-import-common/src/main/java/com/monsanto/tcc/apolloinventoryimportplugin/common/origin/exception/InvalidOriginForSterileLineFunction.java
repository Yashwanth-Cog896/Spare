/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception;

/**
 * Filename:    $RCSfile: InvalidOriginForSterileLineFunction.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy $     On:$Date: 2007-10-24 21:51:32 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class InvalidOriginForSterileLineFunction extends Exception {
    public InvalidOriginForSterileLineFunction(String invalidOriginMsg) {
        super(invalidOriginMsg);
    }
}