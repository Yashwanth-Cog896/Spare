/*
 AbstractStagingInventorySanityChecker was created on Apr 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.LineFunctionCropException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.LineFunctionCropValidator;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.OriginContainsBackslashAndLineFunctionValidator;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.traitquality.ImportTypeNotSetException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.traitquality.TraitQualitySyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.traitquality.TraitQualityValidator;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.BuildParentageFlagEvaluator;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: AbstractStagingInventorySanityChecker.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspeyy $     On:$Date: 2008-02-14 20:49:58 $
 *
 * @author SRKARNA
 * @version $Revision: 1.8 $
 */
public abstract class AbstractStagingInventorySanityChecker implements StagingInventorySanityChecker {
    public static final String REQUIRED_MSG = "stagingInventory is required.";
    public static final String MANDATORY_CHECK_MSG = "No value is specified for ";
    public static final String NOT_ALLOWED_CHECK_MSG = "Values not allowed for ";
    public static final String DATA_BOUNDARY_CHECK_MSG = " is not valid value for ";
    private StagingInventory stagingInventory = null;

    public AbstractStagingInventorySanityChecker(StagingInventory stagingInventory) {
        if (null == stagingInventory) {
            throw new IllegalArgumentException(REQUIRED_MSG);
        }

        this.stagingInventory = stagingInventory;
    }

    public void check() throws StagingInventorySanityCheckException {
        List msgList = new ArrayList();

        performChecksForAllMaterialTypes(msgList);
        performMaterialSpecificChecks(msgList);

        if (msgList.size() > 0) {
            throw new StagingInventorySanityCheckException(msgList.toString());
        }
    }

    protected abstract void performMaterialSpecificChecks(List msgList);

    private void performChecksForAllMaterialTypes(List msgList) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getSource())) {
            msgList.add(MANDATORY_CHECK_MSG + "Source");
        }
        if (null != stagingInventory.getInventoryHeader() &&
                null != stagingInventory.getInventoryHeader().getImportType() &&
                !"ICB Male".equalsIgnoreCase(stagingInventory.getInventoryHeader().getImportType().getAbbreviation())) {
            if (StringUtils.isNullOrEmpty(stagingInventory.getInventoryOwner())) {
                msgList.add(MANDATORY_CHECK_MSG + "Inventory Owner");
            }
        }
        checkLineFunctionCanBeUsedWithCrop(msgList);
        checkOriginCanHaveBackslash(msgList);
        checkTraitQualityValues(msgList);
    }

    protected boolean isALineFunction(String lineFunction) {
        return !StringUtils.isNullOrEmpty(lineFunction) && LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction);
    }

    protected boolean isBuildParentageFlagRequested(String buildParentageFlag) {
        return getConvertedBuildParentageValue(buildParentageFlag).equals(BuildParentageFlagEvaluator.BUILD_PARENTAGE_YES);
    }

    private String getConvertedBuildParentageValue(String buildParentageFlag) {
        return new BuildParentageFlagEvaluator(buildParentageFlag).getValue();
    }

    protected void checkLineFunctionCanBeUsedWithCrop(List msgList) {
        try {
            new LineFunctionCropValidator().validateCropLineFunction(stagingInventory.getLineFunction(),
                    stagingInventory.getInventoryHeader().getCropName());
        } catch (LineFunctionCropException e) {
            msgList.add(e.getMessage());
        }
    }

    protected void checkOriginCanHaveBackslash(List msgList) {
        try {
            new OriginContainsBackslashAndLineFunctionValidator().validate(stagingInventory.getOrigin(), stagingInventory.getLineFunction());
        } catch (InvalidOriginSyntaxException e) {
            msgList.add(e.getMessage());
        }
    }

    protected void checkTraitQualityValues(List msgList) {
        try {
            new TraitQualityValidator().validate(stagingInventory);
        } catch (TraitQualitySyntaxException e) {
            msgList.add(e.getMessage());
        } catch (ImportTypeNotSetException e) {
            msgList.add(e.getMessage());
        }
    }
}