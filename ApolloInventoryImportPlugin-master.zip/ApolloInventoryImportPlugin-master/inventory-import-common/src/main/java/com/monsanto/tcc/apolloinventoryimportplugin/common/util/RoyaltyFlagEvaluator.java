package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 14, 2010
 * Time: 3:44:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class RoyaltyFlagEvaluator {
    public static final String ROYALTY_TRUE = "T";
    public static final String ROYALTY_FALSE = "F";
    private String royaltyFlag;

    public RoyaltyFlagEvaluator(String royaltyFlag) {
        this.royaltyFlag = royaltyFlag;
    }

    public String getValue() {
        if (!StringUtils.isNullOrEmpty(royaltyFlag) &&
                (royaltyFlag.trim().toUpperCase().equals("Y") || royaltyFlag.trim().toUpperCase().equals("YES"))) {
            return ROYALTY_TRUE;
        }
        return ROYALTY_FALSE;
    }

    public boolean isRoyaltySelected() {
        return ROYALTY_TRUE.equals(getValue());
    }
}
