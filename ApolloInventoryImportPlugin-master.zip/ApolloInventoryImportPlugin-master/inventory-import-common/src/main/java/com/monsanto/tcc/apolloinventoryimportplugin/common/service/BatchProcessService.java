/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.service;

import javax.jws.WebMethod;
import javax.jws.WebService;


/**
 * Filename:    $RCSfile: BatchProcessService.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:05 $
 *
 * @author MDSPARK
 * @version $Revision: 1.2 $
 */
@WebService(targetNamespace = "http://service.common.apolloinventoryimport.tcc.monsanto.com/")
public interface BatchProcessService {
    @WebMethod(operationName = "perform")
    void perform();
}