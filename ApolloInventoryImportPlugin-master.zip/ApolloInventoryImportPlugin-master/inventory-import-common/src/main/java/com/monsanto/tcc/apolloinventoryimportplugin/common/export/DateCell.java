/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Filename:    $RCSfile: DateCell.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-10-10 19:56:42 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class DateCell implements Cell {
    private HSSFCell cell;

    public DateCell(HSSFCell cell) {
        this.cell = cell;
    }

    public String getValue() {
        Date javaDate = HSSFDateUtil.getJavaDate(cell.getNumericCellValue());
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        return dateFormat.format(javaDate);
    }
}