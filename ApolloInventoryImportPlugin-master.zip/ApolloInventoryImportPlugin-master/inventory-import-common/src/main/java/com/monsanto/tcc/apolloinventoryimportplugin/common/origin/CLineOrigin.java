/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: CLineOrigin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-02-15 16:05:37 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class CLineOrigin extends Origin {
    private static final String DOSAGE_MUST_BE_ON_MALE_MSG = "Dosage on C line origin must be on the male parent.";
    private static final String DELIMITERS_OTHER_THAN_BACKSLASH = "If a C line origin contains delimiters, there must be one \\ outside parentheses.";
    private Origin origin;

    public CLineOrigin(String originString) throws InvalidOriginSyntaxException {
        origin = new NullOrigin();
        if (!StringUtils.isNullOrEmpty(originString)) {
            origin = new Origin(originString);
        }
        validate();
    }

    private void validate() throws InvalidOriginSyntaxException {
        if (!isOriginContainsAtLeastBackslashDelimiter()) {
            throw new InvalidOriginSyntaxException(DELIMITERS_OTHER_THAN_BACKSLASH);
        }
        if (isLoneEntity()) {
            return;
        }
        if (isDosageOnFemale()) {
            throw new InvalidOriginSyntaxException(DOSAGE_MUST_BE_ON_MALE_MSG);
        }
    }

    public boolean isLoneEntity() {
        return getOriginTree() != null && StringUtils.isNullOrEmpty(getOriginTree().getOperator());
    }

    protected OriginEntity getOriginTree() {
        return origin.getOriginTree();
    }

    public String getOriginString() {
        return origin.getOriginString();
    }

    public int getDosage() {
        return origin.getDosage();
    }

    public boolean isHybrid() {
        return origin.isHybrid();
    }

    private OriginEntity getFemaleParent() {
        OriginEntity originTree = getOriginTree();
        if (originTree != null) {
            return originTree.getFemaleParent();
        }
        return null;
    }

    private boolean isDosageOnFemale() throws InvalidOriginSyntaxException {
        boolean status = false;
        OriginEntity femaleParent = getFemaleParent();
        if (femaleParent != null && !StringUtils.isNullOrEmpty(femaleParent.getOrigin())) {
            Origin femaleParentOrigin = new OriginFactory().createOrigin(femaleParent.getOrigin());
            if (femaleParentOrigin.getDosage() != 0) {
                status = true;
            }
        }
        return status;
    }

    private boolean isOriginContainsAtLeastBackslashDelimiter() {
        boolean status = true;
        OriginEntity originTree = getOriginTree();
        if (originTree != null && !StringUtils.isNullOrEmpty(originTree.getOperator())) {
            status = "\\".equals(originTree.getOperator()) ? true : false;
        }
        return status;
    }
}