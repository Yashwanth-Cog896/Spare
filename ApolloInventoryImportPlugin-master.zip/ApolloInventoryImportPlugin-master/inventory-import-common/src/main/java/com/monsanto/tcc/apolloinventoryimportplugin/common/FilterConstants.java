/*
 FilterConstants was created on Jan 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

/**
 * Filename:    $RCSfile: FilterConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: AAGOSW $ On:$Date:
 * 2007/03/13 06:08:09 $
 *
 * @author SRKARNA
 * @version $Revision: 1.7 $
 */
public class FilterConstants {
    public static final String STATUS_CODE_OPERAND = "statusCode";
    public static final String CROP_NAME_OPERAND = "cropName";
    public static final String MATERIAL_TYPE_OPERAND = "materialType";

    public static final String CROP_FILTER_ID = "crop";
    public static final String MATERIAL_TYPE_FILTER_ID = "materialType";
    public static final String STAGING_INVENTORY_FETCH_OPERAND = "StagingInventoryFetchStrategy";
    public static final String STAGING_INVENTORY_REQ_FETCH_SIZE = "StagingInventoryRequestFetchSize";
}