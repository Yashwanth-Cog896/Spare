package com.monsanto.tcc.apolloinventoryimportplugin.common.traitquality;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.InventoryImportConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MTJOHN1
 * Date: 2/17/12
 * Time: 3:59 PM
 */
public class TraitQualityValidator {
    private static final List<String> ALLOWED_VALUES = Arrays.asList(
            InventoryImportConstants.TRUE_STRING,
            InventoryImportConstants.TRUE_STRING.toLowerCase(),
            InventoryImportConstants.FALSE_STRING,
            InventoryImportConstants.FALSE_STRING.toLowerCase(),
            InventoryImportConstants.DEFAULT_STRING
    );
    private static final List<String> ALLOWED_VALUES_U = Arrays.asList(
            InventoryImportConstants.TRUE_STRING,
            InventoryImportConstants.TRUE_STRING.toLowerCase(),
            InventoryImportConstants.FALSE_STRING,
            InventoryImportConstants.FALSE_STRING.toLowerCase(),
            InventoryImportConstants.UNKNOWN_STRING,
            InventoryImportConstants.UNKNOWN_STRING.toLowerCase(),
            InventoryImportConstants.DEFAULT_STRING
    );
    private static final String DISPLAY_ALLOWED_VALUES = "T or F";
    private static final String DISPLAY_ALLOWED_VALUES_U = "T, F or U";

    public TraitQualityValidator() {
    }

    public void validate(StagingInventory stagingInventory) throws TraitQualitySyntaxException, ImportTypeNotSetException {
        if (getImportType(stagingInventory).equals("ICB Male")) {
            return;
        }
        checkSyntax(stagingInventory.getTransgenic(), "Transgenic", ALLOWED_VALUES, DISPLAY_ALLOWED_VALUES);
        if (!getImportType(stagingInventory).equals("Commercial")) {
            checkSyntax(stagingInventory.getExposureHistoryKnown(), "Exposure History Known", ALLOWED_VALUES_U, DISPLAY_ALLOWED_VALUES_U);
            if (!getImportType(stagingInventory).equals("Competitor")) {
                checkSyntax(stagingInventory.getFromMfg(), "From Manufacturing", ALLOWED_VALUES, DISPLAY_ALLOWED_VALUES);
                checkSyntax(stagingInventory.getAllergensPresent(), "Allergens Present", ALLOWED_VALUES_U, DISPLAY_ALLOWED_VALUES_U);
                checkSyntax(stagingInventory.getToxinsPresent(), "Toxins Present", ALLOWED_VALUES_U, DISPLAY_ALLOWED_VALUES_U);
                checkSyntax(stagingInventory.getAnimalGenePresent(), "Contains Animal Gene", ALLOWED_VALUES_U, DISPLAY_ALLOWED_VALUES_U);
                checkSyntax(stagingInventory.getMiniChromosome(), "Contains Mini Chromosome", ALLOWED_VALUES_U, DISPLAY_ALLOWED_VALUES_U);
            }
        }
    }

    private void checkSyntax(String value, String name, List<String> allowed, String display) throws TraitQualitySyntaxException {
        if (!allowed.contains(value)) {
            throw new TraitQualitySyntaxException(value + " is not a valid value for " + name + ", allowed values are " + display);
        }
    }

    private String getImportType(StagingInventory stagingInventory) throws ImportTypeNotSetException {
        if (null != stagingInventory.getInventoryHeader() &&
            null != stagingInventory.getInventoryHeader().getImportType()) {
            return stagingInventory.getInventoryHeader().getImportType().getAbbreviation();
        }
        else {
            throw new ImportTypeNotSetException("Import type not set for this inventory item.");
        }
    }
}
