/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.source;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.exception.InvalidSourceSyntaxException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: SourceSyntaxVerifier.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:$Date: 2009-06-05 14:08:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class SourceSyntaxVerifier {
    public static final String INVALID_SOURCE_MSG = "Source contains illegal character ";
    public static final String SOURCE_IS_REQUIRED_MSG = "Source is required";
    private String source;
    private static final String LEGAL_SOURCE_PATTERN_STRING = "([^- @{}_.!%#/+>\\[\\]\\\\<,~&:A-Za-z0-9$^\"]+)";
    private static final Pattern LEGAL_SOURCE_PATTERN = Pattern.compile(LEGAL_SOURCE_PATTERN_STRING);
    private static final String INVALID_CHAR_OPEN = "[";
    private static final String INVALID_CHAR_CLOSE = "]";

    public SourceSyntaxVerifier(String source) {
        this.source = source;
    }

    public void verify() throws InvalidSourceSyntaxException {
        if (StringUtils.isNullOrEmpty(source)) {
            return;
        }
        Matcher legalMatcher = LEGAL_SOURCE_PATTERN.matcher(source);
        if (legalMatcher.find()) {
            throw new InvalidSourceSyntaxException(INVALID_SOURCE_MSG + INVALID_CHAR_OPEN + legalMatcher.group() +
                    INVALID_CHAR_CLOSE);
        }
    }
}