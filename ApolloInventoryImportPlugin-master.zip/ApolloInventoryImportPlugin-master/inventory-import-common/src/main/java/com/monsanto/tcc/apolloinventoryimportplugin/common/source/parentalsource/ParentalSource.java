/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.source.parentalsource;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: ParentalSource.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date:
 * 2007/04/11 14:24:23 $
 *
 * @author SSPEYY
 * @version $Revision: 1.5 $
 */
public class ParentalSource implements Comparable {
    private Integer recordLevel;
    private String source;
    private String parentalRole;
    private Long parentalSourceId;
    private StagingInventory mainInventory;
    private Long inventoryId;
    private String vegetativeStructure;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getParentalRole() {
        return parentalRole;
    }

    public void setParentalRole(String parentalRole) {
        this.parentalRole = parentalRole;
    }

    public Integer getRecordLevel() {
        return recordLevel;
    }

    public void setRecordLevel(Integer recordLevel) {
        this.recordLevel = recordLevel;
    }

    public Long getParentalSourceId() {
        return parentalSourceId;
    }

    public void setParentalSourceId(Long parentalSourceId) {
        this.parentalSourceId = parentalSourceId;
    }

    public StagingInventory getMainInventory() {
        return mainInventory;
    }

    public void setMainInventory(StagingInventory mainInventory) {
        this.mainInventory = mainInventory;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(String vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public int compareTo(Object anotherParentalSource) {
        if (this.recordLevel < (((ParentalSource) anotherParentalSource).recordLevel)) {
            return -1;
        } else if (this.recordLevel > (((ParentalSource) anotherParentalSource).recordLevel)) {
            return 1;
        } else {
            return this.getParentalRole().compareTo((((ParentalSource) anotherParentalSource).parentalRole));
        }

    }
}