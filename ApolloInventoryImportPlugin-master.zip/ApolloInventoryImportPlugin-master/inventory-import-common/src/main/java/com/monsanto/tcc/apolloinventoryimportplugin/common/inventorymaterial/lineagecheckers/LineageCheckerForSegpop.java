/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.lineagecheckers;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.CLineLineageSyntaxChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.LineageSyntaxChecker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.LineageSyntaxException;

import java.util.List;

/**
 * Filename:    $RCSfile: LineageCheckerForSegpop.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-06-19 16:12:10 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public class LineageCheckerForSegpop {
    public static final String PIPE_IS_NOT_VALID_MSG = "Pipe is not valid in lineage";
    private String lineage;
    private String generation;
    private String lineFunctionRefId;

    public LineageCheckerForSegpop(String lineage, String generation, String lineFunctionRefId) {
        this.lineage = lineage;
        this.generation = generation;
        this.lineFunctionRefId = lineFunctionRefId;
    }

    public void check(List msgList) {
        if (LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(lineFunctionRefId)) {
            checkCLineLineage(msgList);
        } else {
            if (!StringUtils.isNullOrEmpty(lineage)) {
                checkNonCLineLineage(msgList);
            }
        }
    }

    private void checkNonCLineLineage(List msgList) {
        LineageSyntaxChecker lineageSyntaxChecker = new LineageSyntaxChecker(lineage);

        if (lineageSyntaxChecker.checkLineageHasAtleastOnePipe()) {
            msgList.add(PIPE_IS_NOT_VALID_MSG);
            return;
        }

        try {
            lineageSyntaxChecker.validateLineageHasValidCharacters();
            lineageSyntaxChecker.validateLineageBeginsWithAtCharOrNumberWithOptionalAlphaCharacters();
            lineageSyntaxChecker.validateLineageHasCycleMarkersWithValidPrefix();
            lineageSyntaxChecker.validateLineageDoesNotHaveBothBackcrossAndDiHaploidSymbols(lineFunctionRefId);
        }
        catch (LineageSyntaxException e) {
            msgList.add(e.getMessage());
        }
    }

    private void checkCLineLineage(List msgList) {
        CLineLineageSyntaxChecker checker = new CLineLineageSyntaxChecker();
        try {
            checker.validate(lineage, generation);
        } catch (InvalidLineageException e) {
            msgList.add(e.getMessage());
        }
    }
}