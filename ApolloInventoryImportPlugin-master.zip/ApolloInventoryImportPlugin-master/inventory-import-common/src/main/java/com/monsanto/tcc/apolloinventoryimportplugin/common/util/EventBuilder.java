/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.util;

import com.monsanto.Util.StringUtils;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/**
 * Filename:    $RCSfile: EventBuilder.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date:
 * 2007/08/23 15:05:50 $
 *
 * @author ddbrow5
 * @version $Revision: 1.7 $
 */
public class EventBuilder {
    private static final String EVENTS_DELIMITER = ",";
    private Set events;

    public EventBuilder() {
        events = new TreeSet();
    }

    public void addEvent(String event) {
        if (!StringUtils.isNullOrEmpty(event)) {
            String[] individualEvents = getIndividualEvents(event.trim());
            addEvent(individualEvents);
        }
    }

    private void addEvent(String[] events) {
        for (int i = 0; i < events.length; i++) {
            if (!StringUtils.isNullOrEmpty(events[i])) {
                this.events.add(events[i].toUpperCase());
            }
        }
    }

    public String toString() {
        return createFlattenedListOfEvents();
    }

    private String createFlattenedListOfEvents() {
        StringBuffer buf = new StringBuffer();
        Iterator iter = events.iterator();
        while (iter.hasNext()) {
            appendDelimiter(buf);
            buf.append((String) iter.next());
        }
        return buf.length() > 0 ? buf.toString() : null;
    }

    private String[] getIndividualEvents(String input) {
        return input.split("\\s*" + EVENTS_DELIMITER + "\\s*");
    }

    private void appendDelimiter(StringBuffer buf) {
        if (buf.length() > 0) {
            buf.append(EVENTS_DELIMITER);
        }
    }
}