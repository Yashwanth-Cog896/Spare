/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;

/**
 * Filename:    $RCSfile: CellFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/10/10 19:59:33 $
 *
 * @author ddbrow5
 * @version $Revision: 1.7 $
 */
public class CellFactory {
    public Cell createCell(HSSFCell cell) {
        Cell returnCell;
        if (isCellNull(cell)) {
            returnCell = new NullCell();
        } else {
            returnCell = buildNonNullCell(cell);
        }
        return returnCell;
    }

    private Cell buildNonNullCell(HSSFCell cell) {
        Cell returnCell = null;
        switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_BOOLEAN:
                returnCell = new BooleanCell(cell);
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                returnCell = new BlankCell();
                break;
            case HSSFCell.CELL_TYPE_STRING:
                returnCell = new StringCell(cell);
                break;
            case HSSFCell.CELL_TYPE_NUMERIC:
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    returnCell = new DateCell(cell);
                } else {
                    returnCell = new NumericCell(cell);
                }
                break;
            case HSSFCell.CELL_TYPE_FORMULA:
                returnCell = new FormulaCell(cell);
                break;
            case HSSFCell.CELL_TYPE_ERROR:
                returnCell = new ErrorCell(cell);
                break;
        }
        return returnCell;
    }

    private boolean isCellNull(HSSFCell cell) {
        return cell == null;
    }
}