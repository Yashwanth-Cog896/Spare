package com.monsanto.tcc.apolloinventoryimportplugin.common;

import com.monsanto.services.domain.common.Entity;

import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Jun 17, 2008 Time: 12:04:25 PM To change this template use File |
 * Settings | File Templates.
 */
public class ImportedTemplateEntity implements Entity {

    private String cropName;
    private String materialType;
    private String templateName;
    private Date createdDate;

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getMaterialType() {
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Object getID() {
        return null;
    }

}
