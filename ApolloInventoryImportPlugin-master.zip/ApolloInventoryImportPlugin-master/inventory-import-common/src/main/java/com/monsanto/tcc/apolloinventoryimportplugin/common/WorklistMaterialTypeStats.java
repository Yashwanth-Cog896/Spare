/*
 WorklistMaterialTypeStats was created on Feb 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common;

/**
 * Filename:    $RCSfile: WorklistMaterialTypeStats.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2007-02-16 19:05:40 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class WorklistMaterialTypeStats {
    private String materialType;
    private int waitingToBeProcessedCount;
    private int eligibleToSendToAuthorityCount;
    private int waitingToBeApprovedCount;

    public String getMaterialType() {
        return materialType;
    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public int getWaitingToBeProcessedCount() {
        return waitingToBeProcessedCount;
    }

    public void setWaitingToBeProcessedCount(int waitingToBeProcessedCount) {
        this.waitingToBeProcessedCount = waitingToBeProcessedCount;
    }

    public int getEligibleToSendToAuthorityCount() {
        return eligibleToSendToAuthorityCount;
    }

    public void setEligibleToSendToAuthorityCount(int eligibleToSendToAuthorityCount) {
        this.eligibleToSendToAuthorityCount = eligibleToSendToAuthorityCount;
    }

    public int getWaitingToBeApprovedCount() {
        return waitingToBeApprovedCount;
    }

    public void setWaitingToBeApprovedCount(int waitingToBeApprovedCount) {
        this.waitingToBeApprovedCount = waitingToBeApprovedCount;
    }
}