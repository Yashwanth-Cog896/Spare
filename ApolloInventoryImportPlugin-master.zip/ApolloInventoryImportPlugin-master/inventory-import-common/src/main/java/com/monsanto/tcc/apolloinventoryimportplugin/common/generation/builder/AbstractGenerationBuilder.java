package com.monsanto.tcc.apolloinventoryimportplugin.common.generation.builder;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 9, 2009
 * Time: 10:54:13 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractGenerationBuilder implements GenerationBuilder {
    protected String percentCycleMarkerGenerationPrefix = "DH";
    protected String generationOfNullLineage = "F1";
    protected static final String GENERATION_OF_PIPE_LINEAGE = "INBRED";
    private String mainRecordGeneration = "";


    public AbstractGenerationBuilder(String mainRecordGeneration, String lineFunction) {

        if (!StringUtils.isNullOrEmpty(mainRecordGeneration)) {
            this.mainRecordGeneration = mainRecordGeneration;
            if (mainRecordGeneration.startsWith("DD")) {
                percentCycleMarkerGenerationPrefix = "DD";
            }
        }

        if (LineFunctionConstants.C_LINE_FUNCTION.equalsIgnoreCase(lineFunction)) {
            generationOfNullLineage = "MSC0";
        }
    }

    @Override
    public String getGenerationStringFromLineage(String lineage) {
        String generation;
        if (StringUtils.isNullOrEmpty(lineage)) {
            generation = generationOfNullLineage;
        } else if ("|".equals(lineage)) {
            generation = GENERATION_OF_PIPE_LINEAGE;
        } else {
            generation = getGenetation(lineage);
        }
        return generation;
    }

    private String getGenetation(String lineage) {
        String generation;
        if (isHeploidSymbolPresent(lineage)) {
            generation = getDiHaploidGeneration(lineage);
        } else if (isBackCrossSymbolPresent(lineage)) {
            generation = getBackCrossGeneration(lineage);
            String slLineage = lineage.substring(lineage.lastIndexOf(">"), lineage.length());
            String simpleLineageGeneration = getSimpleGeneration(slLineage);
            generation += simpleLineageGeneration != null ? simpleLineageGeneration : "";
        } else {
            generation = getSimpleGeneration(lineage);
        }
        return generation;
    }

    protected abstract String getSimpleGeneration(String lineage);

    protected String getDiHaploidGeneration(String lineage) {
        String generation;
        lineage = lineage.substring(lineage.lastIndexOf("%"), lineage.length());
        if (isHeploidSymbolPresent(lineage) && isBackCrossSymbolPresent(lineage)) {
            generation = null;
        } else {
            int slCount = getSimpleOperationsCount(lineage);
            if (slCount > 1) {
                generation = (percentCycleMarkerGenerationPrefix + ((slCount - 1)));
            } else {
                generation = (percentCycleMarkerGenerationPrefix + "0");
            }
        }
        return generation;
    }

    private int getSimpleOperationsCount(String lineage) {
        int slCount = 1;
        String simpleLineagePattern = "[.#$!]";
        Pattern pattern = Pattern.compile(simpleLineagePattern);
        Matcher slMatcher = pattern.matcher(lineage);
        while (slMatcher.find()) {
            slCount++;
        }
        return slCount;
    }

    protected String getBackCrossGeneration(String lineage) {
        String generation;
        String tempLineage = lineage.substring(lineage.indexOf(">"), lineage.length());
        Matcher bcMatcher = getBackCrossPattern().matcher(tempLineage);
        int bcCount = 0;
        while (bcMatcher.find()) {
            bcCount++;
        }
        generation = ("BC" + bcCount);
        return generation;
    }

    private boolean isBackCrossSymbolPresent(String lineage) {
        return lineage.indexOf(">") >= 0;
    }

    private boolean isHeploidSymbolPresent(String lineage) {
        return lineage.indexOf("%") >= 0;
    }

    private Pattern getBackCrossPattern() {
        String backCrossPattern = "[>]";
        return Pattern.compile(backCrossPattern);
    }

    public String getMainRecordGeneration() {
        return mainRecordGeneration;
    }

    protected abstract Pattern getSimpleLineagePattern();
}
