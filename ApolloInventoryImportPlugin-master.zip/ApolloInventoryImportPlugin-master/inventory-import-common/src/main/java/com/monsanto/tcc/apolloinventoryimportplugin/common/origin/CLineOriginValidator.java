/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.CLineGeneration;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.Generation;
import com.monsanto.tcc.apolloinventoryimportplugin.common.generation.exception.InvalidCLineGenerationException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.CLineLineage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.BuildParentageFlagEvaluator;

/**
 * Filename:    $RCSfile: CLineOriginValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2008-11-10 21:32:27 $
 *
 * @author ddbrow5
 * @version $Revision: 1.10 $
 */
public class CLineOriginValidator extends OriginValidator {
    private static final String MSC0_SIMPLE_OR_BC_ORIGIN_MSG = "When generation is MSC0 or INBRED, origin must be simple (non-backcross) or a lone entity";
    private static final String VALID_GENERATIONS_MSG = "Only MSC0, INBRED, or Backcross generations are allowed for C lines";
    private static final String BC_ORIGIN_MSG = "When generation is BCn, origin must have dosage";
    private static final String ORIGIN_LIN_DOSAGE_MSG = "Origin dosage does not match lineage";
    private static final String ORIGIN_GEN_DOSAGE_MSG = "Origin dosage does not match generation";
    private static final String BACKCROSS_GENERATION_PREFIX = "BC";

    public void validateOriginSyntax(String origin, String lineage, String generationString, String buildParentage) throws
            InvalidOriginSyntaxException {
        Generation generation;
        try {
            generation = new CLineGeneration(generationString);
        } catch (InvalidCLineGenerationException e) {
            throw new InvalidOriginSyntaxException(VALID_GENERATIONS_MSG);
        }
        CLineOrigin cLineOrigin = new CLineOrigin(origin);
        if (isGenerationInbredOrMSC0(generation)) {
            validateInbredOrMSCOGeneration(cLineOrigin, buildParentage);
        } else if (generation.isBackcross()) {
            validateBackcrossGeneration(cLineOrigin, lineage, generation);
        } else {
            throw new InvalidOriginSyntaxException(VALID_GENERATIONS_MSG);
        }
    }

    public int getDosageFromLineage(String lineage) throws InvalidLineageException {
        if (StringUtils.isNullOrEmpty(lineage) || "|".equals(lineage)) {
            return 0;
        }
        return super.getDosageFromLineage(lineage);
    }

    protected int getDosageFromOrigin(String origin) throws InvalidOriginSyntaxException {
        return new CLineOrigin(origin).getDosage();
    }

    private void validateInbredOrMSCOGeneration(CLineOrigin cLineOrigin, String buildParentage) throws
            InvalidOriginSyntaxException {
        if (cLineOrigin.getDosage() != 0) {
            throw new InvalidOriginSyntaxException(MSC0_SIMPLE_OR_BC_ORIGIN_MSG);
        }
        validateBuildParentageNotRequested(cLineOrigin, buildParentage);
    }

    private void validateBuildParentageNotRequested(CLineOrigin cLineOrigin, String buildParentage) throws
            InvalidOriginSyntaxException {
        if (!isBuildParentageRequested(buildParentage)) {
            if (!isOriginLoneEntityOrNonBackcross(cLineOrigin)) {
                throw new InvalidOriginSyntaxException(MSC0_SIMPLE_OR_BC_ORIGIN_MSG);
            }
        }
    }

    private void validateBackcrossGeneration(CLineOrigin cLineOrigin, String lineage, Generation generation) throws
            InvalidOriginSyntaxException {
        if (cLineOrigin.isLoneEntity() || cLineOrigin.getDosage() == 0) {
            throw new InvalidOriginSyntaxException(BC_ORIGIN_MSG);
        }
        if (!isOriginDosageEqualLineageDosage(cLineOrigin, lineage)) {
            throw new InvalidOriginSyntaxException(ORIGIN_LIN_DOSAGE_MSG);
        }
        if (!isOriginDosageEqualGenerationDosage(cLineOrigin, generation)) {
            throw new InvalidOriginSyntaxException(ORIGIN_GEN_DOSAGE_MSG);
        }
    }

    private boolean isOriginDosageEqualLineageDosage(CLineOrigin cLineOrigin, String lineage) throws
            InvalidOriginSyntaxException {
        boolean status = true;
        try {
            int lineageDosage = new CLineLineage(lineage).getDosage();
            if (cLineOrigin.getDosage() != lineageDosage) {
                status = false;
            }
        } catch (InvalidLineageException e) {
            throw new InvalidOriginSyntaxException(e.getMessage());
        }
        return status;
    }

    private boolean isOriginDosageEqualGenerationDosage(CLineOrigin cLineOrigin, Generation generation) {
        return cLineOrigin.getDosage() == generation.getGeneration() + 1;
    }

    private boolean isGenerationInbredOrMSC0(Generation generation) {
        return generation.isInbred() || generation.isMSC0();
    }

    private boolean isOriginLoneEntityOrNonBackcross(CLineOrigin origin) {
        return origin.isLoneEntity() || origin.getDosage() == 0;
    }

    protected boolean isBuildParentageRequested(String buildParentage) {
        return BuildParentageFlagEvaluator.BUILD_PARENTAGE_YES
                .equals(getBuildParentageFlagEvaluator(buildParentage).getValue());
    }

    private BuildParentageFlagEvaluator getBuildParentageFlagEvaluator(String buildParentage) {
        return new BuildParentageFlagEvaluator(buildParentage);
    }

    protected int getDosageFromBackcrossGeneration(String generation) {
        int dosage = 0;
        if (!StringUtils.isNullOrEmpty(generation) &&
                generation.trim().toUpperCase().startsWith(BACKCROSS_GENERATION_PREFIX)) {
            String generationWithoutPrefix = generation.trim().replaceAll("^" + BACKCROSS_GENERATION_PREFIX, "");
            if (!StringUtils.isNullOrEmpty(generationWithoutPrefix)) {
                dosage = getIntFromString(generationWithoutPrefix);
            }
        }
        return dosage > 0 ? dosage + 1 : dosage;
    }

    private int getIntFromString(String stringIntValue) {
        int intValue = 0;
        try {
            intValue = Integer.parseInt(stringIntValue);
        } catch (NumberFormatException e) {
            // unhandled on purpose
        }
        return intValue;
    }
}