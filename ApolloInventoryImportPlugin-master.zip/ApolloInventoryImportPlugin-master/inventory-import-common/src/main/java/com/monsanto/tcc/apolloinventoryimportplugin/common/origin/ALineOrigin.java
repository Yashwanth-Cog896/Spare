/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;

/**
 * Filename:    $RCSfile: ALineOrigin.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2007-11-16 21:41:53 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */

public class ALineOrigin extends Origin {
    public ALineOrigin(String originString) throws InvalidOriginSyntaxException {
        super(originString);
    }

    public boolean isHybrid() {
        return false;
    }

    public String getOriginString() {
        return originString;
    }

    public int getDosage() {
        return 0;
    }
}