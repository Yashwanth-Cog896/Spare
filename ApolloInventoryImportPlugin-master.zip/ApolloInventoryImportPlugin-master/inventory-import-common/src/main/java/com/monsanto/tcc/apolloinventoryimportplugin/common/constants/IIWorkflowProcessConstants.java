/*
 IIWorkflowProcessConstants was created on Feb 21, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: IIWorkflowProcessConstants.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2007-07-30 21:09:43 $
 *
 * @author SRKARNA
 * @version $Revision: 1.4 $
 */
public class IIWorkflowProcessConstants {
    public static final String PROCESS_MATERIAL_ID = "add-material";
    public static final String SEND_TO_AUTHORITY_ID = "send-to-authority";
    public static final String APPROVE_RECORDS_ID = "approve-records";

    public static final String SELECTED_RECORDS_ID = "process-constant-add-material-data";
    public static final String SELECTED_APRV_EVT_RECORDS_ID = "process-constant-approve-event-data";

    public static final String SELECTION_CHANGED_ID = "selections-changed";
    public static final String SELECTION_NOT_CHANGED_ID = "no-change";
    public static final String STAGING_INVENTORY_DISP_FOR_CROP = "staging-inventory-data-model-crop";
    public static final String STAGING_INVENTORY_DISP_FOR_MATERIAL = "staging-inventory-data-model-materialType";
}