/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.linefunctionsanity;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;

import java.util.Set;
import java.util.TreeSet;

/**
 * Filename:    $RCSfile: AllowedLineFunctionValuesHybridCheck.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:03 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class AllowedLineFunctionValuesHybridCheck extends AllowedLineFunctionValuesCheck {
    public AllowedLineFunctionValuesHybridCheck(String lineFunctionRefId) {
        super(lineFunctionRefId);
    }

    protected Set getSetOfAllowedLineFunctionValues() {
        Set allowedValueSet = new TreeSet(String.CASE_INSENSITIVE_ORDER);
        allowedValueSet.add("");
        allowedValueSet.add(LineFunctionConstants.F_LINE_FUNCTION);
        allowedValueSet.add(LineFunctionConstants.S_LINE_FUNCTION);
        return allowedValueSet;
    }
}