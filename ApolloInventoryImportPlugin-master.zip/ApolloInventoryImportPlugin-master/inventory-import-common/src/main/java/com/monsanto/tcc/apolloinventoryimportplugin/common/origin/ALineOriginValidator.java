/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.origin;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.LineageFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidALineMSCLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.lineage.exception.InvalidLineageException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.InvalidOriginSyntaxException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.origin.exception.OriginLineageDosageMismatchException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.BuildParentageFlagEvaluator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: ALineOriginValidator.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: SSPEYY $
 * On:$Date: 2008-04-18 15:03:26 $
 *
 * @author APATRO
 * @version $Revision: 1.3 $
 */
public class ALineOriginValidator extends OriginValidator {
    private static final String ORIGIN_LINEAGE_DOSAGE_MISMATCH = "Origin does not match the given Lineage";
    private static final String MSC_GENERATION_PATTERN_STRING = "^MSC(\\d+)$";

    public void validateOriginSyntax(String origin, String lineage, String generation, String buildParentage) throws
            InvalidOriginSyntaxException, InvalidLineageException, OriginLineageDosageMismatchException {
        if (("|".equalsIgnoreCase(lineage) && isGenerationInbredOrMSC(generation) && isBuildParentageNo(buildParentage))) {
            return;
        }
        if (getDosageFromOrigin(origin) != getDosageFromLineage(lineage)) {
            throw new OriginLineageDosageMismatchException(ORIGIN_LINEAGE_DOSAGE_MISMATCH);
        }
    }


    private boolean isBuildParentageNo(String buildParentageFlag) {
        return getBuildParentageValue(buildParentageFlag).equals(BuildParentageFlagEvaluator.BUILD_PARENTAGE_NO);
    }

    protected String getBuildParentageValue(String buildParentageFlag) {
        return new BuildParentageFlagEvaluator(buildParentageFlag).getValue();
    }

    private boolean isGenerationInbredOrMSC(String generation) {
        return "INBRED".equalsIgnoreCase(generation) || isGenerationValidMSC(generation);
    }

    private boolean isGenerationValidMSC(String generation) {
        Pattern mscPattern = Pattern.compile(MSC_GENERATION_PATTERN_STRING);
        Matcher mscMatcher = mscPattern.matcher(generation);
        return mscMatcher.matches();
    }

    protected int getDosageFromLineage(String lineage) throws InvalidLineageException {
        try {
            return new LineageFactory().createLineage(LineFunctionConstants.A_LINE_FUNCTION, lineage).getDosage();
        } catch (InvalidALineMSCLineageException e) {
            throw new InvalidLineageException(e.getMessage());
        }
    }

    protected int getDosageFromOrigin(String origin) throws InvalidOriginSyntaxException {
        return new OriginFactory().createOrigin(origin).getDosage();
    }
}