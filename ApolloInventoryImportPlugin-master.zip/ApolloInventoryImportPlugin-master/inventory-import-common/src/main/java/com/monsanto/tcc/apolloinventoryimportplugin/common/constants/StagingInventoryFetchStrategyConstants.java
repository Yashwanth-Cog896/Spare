/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Filename:    $RCSfile: StagingInventoryFetchStrategyConstants.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $     On:$Date: 2007-04-25 17:37:24 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class StagingInventoryFetchStrategyConstants {
    public static final String INVENTORY_FETCH_STRATEGY_ECB = "EXCLUDE_CURRENT_BATCH";
    public static final String INVENTORY_FETCH_STRATEGY_ECBII = "EXCLUDE_CURRENT_BACTH_AND_INVALID_INVENTORY";
    public static final String INVENTORY_FETCH_STRATEGY_SIMPLE = "SIMPLE";
}