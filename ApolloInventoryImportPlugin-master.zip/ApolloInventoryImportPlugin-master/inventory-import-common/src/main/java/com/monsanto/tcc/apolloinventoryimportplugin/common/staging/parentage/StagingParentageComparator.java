package com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: May 18, 2009
 * Time: 4:07:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class StagingParentageComparator implements Comparator {

    public int compare(Object o1, Object o2) {
        StagingParentage sp1 = (StagingParentage) o1;
        StagingParentage sp2 = (StagingParentage) o2;

        int recordLevelDifference = sp1.getRecordLevel().intValue() - sp2.getRecordLevel().intValue();

        if (recordLevelDifference == 0) {
            String generation1 = sp1.getParentInventory().getGeneration();
            String generation2 = sp2.getParentInventory().getGeneration();
            if (generation1 != null && generation2 != null) {
                int generationDifferences = generation1.compareTo(generation2);
                if (generationDifferences == 0) {
                    return compareVegetativeStructures(sp1, sp2);
                }
                return generationDifferences;
            } else {
                return compareVegetativeStructures(sp1, sp2);
            }
        }
        return recordLevelDifference;
    }

    private int compareVegetativeStructures(StagingParentage sp1, StagingParentage sp2) {
        String sp1VegetativeStructure = sp1.getParentInventory().getVegetativeStructure();
        String sp2VegetativeStructure = sp2.getParentInventory().getVegetativeStructure();
        if (sp1VegetativeStructure == null || sp2VegetativeStructure == null) {
            return 0;
        } else {
            if ("Seed".equalsIgnoreCase(sp1VegetativeStructure)) {
                return 1;
            } else if ("Seed".equalsIgnoreCase(sp2VegetativeStructure)) {
                return -1;
            }
            return sp1VegetativeStructure.compareTo(sp2VegetativeStructure);
        }
    }
}
