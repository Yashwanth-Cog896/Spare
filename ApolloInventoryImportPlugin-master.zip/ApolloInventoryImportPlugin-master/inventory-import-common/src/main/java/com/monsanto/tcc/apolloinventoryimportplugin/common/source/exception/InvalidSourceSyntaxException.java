/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.source.exception;

/**
 * Filename:    $RCSfile: InvalidSourceSyntaxException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2007-09-11 14:29:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class InvalidSourceSyntaxException extends Exception {
    public InvalidSourceSyntaxException(String msg) {
        super(msg);
    }
}