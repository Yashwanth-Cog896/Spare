package com.monsanto.tcc.apolloinventoryimportplugin.common.export;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Filename:    $RCSfile: AbstractTemplate.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    On: $Date: 2008-09-26 17:35:19 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
public abstract class AbstractTemplate {
    private static final Log logger = LogFactory.getLog(AbstractTemplate.class);

    protected HSSFWorkbook workBook = null;
    protected HSSFSheet workSheet = null;
    protected int numberOfColumns = 0;
    protected int groupNumber = 1;
    protected WorkSheetMetaData workSheetMetaData;
    static final Object[] nullargs = new Object[]{};
    private static final String STRING_RETURN_VALUE = "java.lang.String";
    private static final String DOUBLE_RETURN_VALUE = "java.lang.Double";

    public void setGroupNumber(int groupNumber) {
        this.groupNumber = groupNumber;
    }

    public void fillTemplateCellsWithDataFromView(List stagingInventoryListFromView) throws ExcelExportException {
        if (null == workBook) {
            throw new ExcelExportException("Cannot open work book");
        }
        if (null == workSheet) {
            throw new ExcelExportException("Cannot open work sheet");
        }
        if (null == stagingInventoryListFromView) {
            throw new ExcelExportException("Data from view should not be null");
        }
        int numberOfRows = stagingInventoryListFromView.size();
        int i;
        for (i = 0; i < numberOfRows; i++) {
            StagingInventory stagingInventory = (StagingInventory) stagingInventoryListFromView.get(i);
            Class classToInvokeMethodOn = stagingInventory.getClass();

            // Row 0 is the column headers
            //
            HSSFRow row = workSheet.getRow(i + 1);
            if (null == row) {
                row = workSheet.createRow(i + 1);
            }

            int j;
            for (j = 0; j < numberOfColumns; j++) {
                // Cell 0 is Column A
                HSSFCell cell = row.getCell(j);
                if (cell == null) {
                    cell = row.createCell(j);
                }
                setCellValue(cell, classToInvokeMethodOn, stagingInventory, j);
            }
        }
    }

    public void fillTemplateCellsWithDataFromView(HSSFSheet destinationSheet, List stagingInventoryListFromView) throws ExcelExportException {
        if (null == destinationSheet) {
            throw new ExcelExportException("Cannot open destination work sheet");
        }
        if (null == stagingInventoryListFromView) {
            throw new ExcelExportException("Data from view should not be null");
        }
        int numberOfRows = stagingInventoryListFromView.size();
        int startAt = groupNumber * numberOfRows;
        numberOfRows += startAt;
        int inventoryIndex = 0;
        int i;
        for (i = startAt; i < numberOfRows; i++) {
            StagingInventory stagingInventory = (StagingInventory) stagingInventoryListFromView.get(inventoryIndex);
            Class classToInvokeMethodOn = stagingInventory.getClass();

            // Row 0 is the column headers
            //
            HSSFRow row = destinationSheet.getRow(i + 1);
            if (null == row) {
                row = destinationSheet.createRow(i + 1);
            }

            int j;
            for (j = 0; j < numberOfColumns; j++) {
                // Cell 0 is Column A
                HSSFCell cell = row.getCell(j);
                if (cell == null) {
                    cell = row.createCell(j);
                }
                setCellValue(cell, classToInvokeMethodOn, stagingInventory, j);
            }
            inventoryIndex++;
        }
    }

    public void writeToOutputStream(OutputStream stream) throws FileNotFoundException, IOException {
        if (null == workBook) {
            throw new IllegalStateException("Workbook is not available for saving");
        }
        try {
            workBook.write(stream);
        }
        finally {
            if (null != stream) {
                stream.close();
            }
        }
    }

    public byte[] getBytesInTemplate() {
        byte[] bytesInTemplate = new byte[]{};
        if (null != workBook) {
            bytesInTemplate = workBook.getBytes();
        }
        return bytesInTemplate;
    }

    private void setCellValue(HSSFCell cell, Class classToInvokeMethodOn, StagingInventory stagingInventory, int columnIndex) {
        try {
            Method method = classToInvokeMethodOn.getMethod(workSheetMetaData.getGetMethodName(columnIndex), null);
            Object value = method.invoke(stagingInventory, nullargs);
            String returnType = method.getReturnType().getName();

            if (STRING_RETURN_VALUE.equals(returnType)) {
                if (StringUtils.isNullOrEmpty((String) value)) {
                    setAlternateValueOnCell(cell, classToInvokeMethodOn, stagingInventory, columnIndex);
                } else {
                    setStringValueOnCell(cell, (String) value, columnIndex);
                }
            } else if (DOUBLE_RETURN_VALUE.equals(returnType)) {
                if (value == null) {
                    if (workSheetMetaData.isAlternateDataPresent(columnIndex)) {
                        setAlternateValueOnCell(cell, classToInvokeMethodOn, stagingInventory, columnIndex);
                    }
                } else {
                    setDoubleValueOnCell(cell, (Double) value, columnIndex);
                }
            }
        }
        catch (Exception e) {
            logger.error("An error occurred setting the cell value :" + e);
        }
    }

    private void setAlternateValueOnCell(HSSFCell cell, Class classToInvokeMethodOn, StagingInventory stagingInventory,
                                         int columnIndex) throws
            NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        if (workSheetMetaData.isAlternateDataPresent(columnIndex)) {
            Method method = classToInvokeMethodOn.getMethod(workSheetMetaData.getAlternateGetMethodName(columnIndex), null);
            Object value = method.invoke(stagingInventory, nullargs);
            setStringValueOnCellUsingMethod(method, cell, value, columnIndex);
            setDoubleValueOnCellUsingMethod(method, cell, value, columnIndex);
        }
    }

    private void setStringValueOnCellUsingMethod(Method method, HSSFCell cell, Object value, int columnIndex) {
        String returnType = method.getReturnType().getName();
        if (STRING_RETURN_VALUE.equals(returnType)) {
            int cellType = workSheetMetaData.getColumnType(columnIndex);
            setStringValueOnCell(cell, (String) value, cellType);
        }
    }

    private void setDoubleValueOnCellUsingMethod(Method method, HSSFCell cell, Object value, int columnIndex) {
        String returnType = method.getReturnType().getName();
        if (DOUBLE_RETURN_VALUE.equals(returnType)) {
            int cellType = workSheetMetaData.getColumnType(columnIndex);
            setDoubleValueOnCell(cell, (Double) value, cellType);
        }
    }

    private void setStringValueOnCell(HSSFCell cell, String value, int columnIndex) {
        int cellType = workSheetMetaData.getColumnType(columnIndex);
        cell.setCellType(cellType);
        cell.setCellValue(value);
    }

    private void setDoubleValueOnCell(HSSFCell cell, Double value, int columnIndex) {
        if (null != value) {
            cell.setCellValue(value.doubleValue());
        }
        int cellType = workSheetMetaData.getColumnType(columnIndex);
        cell.setCellType(cellType);
        cell.setCellStyle(getNumberFormatCellStyle());
    }

    private HSSFCellStyle getNumberFormatCellStyle() {
        HSSFDataFormat format = workBook.createDataFormat();
        HSSFCellStyle style = workBook.createCellStyle();
        style.setDataFormat(format.getFormat("0.00"));
        return style;
    }
}
