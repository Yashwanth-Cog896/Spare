/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.common.posclients;

import com.monsanto.Util.StringUtils;
import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.ResponseItem;
import com.monsanto.services.domain.common.ResponseItemType;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.apolloinventoryimportplugin.common.serialzerprovider.InventoryImportGlobalXmlSerializerProvider;
import com.monsanto.tcc.constellation.serviceconnection.CachingServiceUrlResolver;
import com.monsanto.tcc.constellation.serviceconnection.StandaloneKerberosXmlServiceRequest;

import java.util.Iterator;

/**
 * Filename:    $RCSfile: AbstractPOSClient.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-12-03 20:41:48 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public abstract class AbstractPOSClient {
    // Note that to send compressed data the POS has to be set up to handle it
    private static final boolean COMPRESS_DATA = false;
    private static final String POS_SERVICE = "DUInventoryImportPOS";
    private ResponseEnvelope responseEnvelope;
    private String posActivityName;
    private static String DEFAULT_FILTER_ID = "1";

    public void setPosActivityName(String posActivityName) {
        this.posActivityName = posActivityName;
    }

    public boolean isSuccess() {
        return StringUtils.isNullOrEmpty(getPOSErrorResponseMessage());
    }

    public String getPOSErrorResponseMessage() {
        return getPOSResponseMessage(ResponseItemType.ERROR);
    }

    public String getPOSSuccessResponseMessage() {
        return getPOSResponseMessage(ResponseItemType.SUCCESS);
    }

    protected ResponseEnvelope getResponseEnvelope() {
        return responseEnvelope;
    }

    protected void sendToPos(CompositeObject compositeObject) throws ActivityClientException {
        RequestEnvelope envelope = getRequestEnvelope(compositeObject);
        XmlServiceActivityClient client = getActivityClient();
        responseEnvelope = (ResponseEnvelope) client.perform(envelope, POS_SERVICE, new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer());
    }

    private RequestEnvelope getRequestEnvelope(CompositeObject compositeObject) {
        return new RequestEnvelope(new RequestOperation(posActivityName), compositeObject);
    }

    protected XmlServiceActivityClient getActivityClient() {
        return new XmlServiceActivityClient(new CachingServiceUrlResolver(), new StandaloneKerberosXmlServiceRequest(), COMPRESS_DATA);
    }

    protected Filter getFilterWithDefaultFilterId() {
        return new Filter(DEFAULT_FILTER_ID);
    }

    protected void checkForErrorResponse() throws ActivityClientException {
        String errorMessage = getPOSErrorResponseMessage();
        if (!StringUtils.isNullOrEmpty(errorMessage)) {
            throw new ActivityClientException(errorMessage);
        }
    }

    private String getPOSResponseMessage(ResponseItemType responseItemType) {
        StringBuffer buffer = new StringBuffer();
        if (responseEnvelope != null) {
            Iterator iterator = responseEnvelope.getItems(responseItemType);
            while (iterator.hasNext()) {
                ResponseItem item = (ResponseItem) iterator.next();
                buffer.append(item.getMessage()).append("\n\n");
            }
        }
        return buffer.toString();
    }
}