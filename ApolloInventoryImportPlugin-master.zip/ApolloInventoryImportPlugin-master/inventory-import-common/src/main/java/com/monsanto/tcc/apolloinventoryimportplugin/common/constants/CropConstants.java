package com.monsanto.tcc.apolloinventoryimportplugin.common.constants;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: May 5, 2010
 * Time: 9:02:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class CropConstants {
    public static final String CROP_SUGAR_CANE = "Sugar Cane";
}
