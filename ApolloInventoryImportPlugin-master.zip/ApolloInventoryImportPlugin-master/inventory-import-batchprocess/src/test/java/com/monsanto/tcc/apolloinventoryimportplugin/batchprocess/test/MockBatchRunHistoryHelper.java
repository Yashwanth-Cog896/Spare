/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.BatchRunHistoryHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProcessName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: MockBatchRunHistoryHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $    	 On:	$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 * @noinspection RefusedBequest
 */
public class MockBatchRunHistoryHelper extends BatchRunHistoryHelper {
  public MockBatchRunHistoryHelper(StagingInventory stagingInventory) {
    if (stagingInventory != null) addRecords(new StagingInventory[]{stagingInventory});
  }

  protected RunStatus getRunStatus(String statusCode) {
    RunStatus runStatus = new RunStatus();
    runStatus.setStatusCode(statusCode);
    return runStatus;
  }

  protected ProcessName getProcessName(String name) {
    ProcessName processName = new ProcessName();
    processName.setName(name);
    return processName;
  }

  public void saveRunHistory() {
  }

  public void saveRunDetails() {
  }

  public void saveRunDetails(StagingInventory stagingInvetory) {
  }
}