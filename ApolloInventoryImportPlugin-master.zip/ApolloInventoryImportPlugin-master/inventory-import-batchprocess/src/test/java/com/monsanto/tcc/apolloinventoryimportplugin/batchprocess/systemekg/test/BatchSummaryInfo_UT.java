/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.test;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchRunSummaryInfo;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: BatchSummaryInfo_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $ On:	$Date:
 * 2007/10/04 17:52:46 $
 *
 * @author APATRO
 * @version $Revision: 1.3 $
 */
public class BatchSummaryInfo_UT extends TestCase {
  private TestHelper testHelper;

  public BatchSummaryInfo_UT(String string) {
    super(string);
  }

  protected void setUp() throws Exception {
    super.setUp();
    testHelper = new TestHelper();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testBatchRunSummaryInfoCreationWithNullRunHistory() {

    try {
      new BatchRunSummaryInfo(null, null);
      fail("Expecting IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().indexOf(BatchRunSummaryInfo.RUN_HISTORY_REQUIRED_MSG) >= 0);
    }

  }

  /**
   * @noinspection MagicNumber
   */
  public void testBatchRunSummaryInfoNullStagingInventories() {
    StagingInventory[] stagingInventories = null;

    long expectedRunHistoryId = 5;
    Date expectedStartDate = new Date();
    Date expectedEndDate = new Date(expectedStartDate.getTime() + 30000);
    RunHistory runHistory = testHelper.createRunHistory(expectedRunHistoryId, expectedStartDate, expectedEndDate);

    BatchRunSummaryInfo batchRunSummaryInfo = new BatchRunSummaryInfo(stagingInventories, runHistory);

    assertEquals(expectedRunHistoryId, batchRunSummaryInfo.getBatchRunHistoryId());
    assertEquals(expectedStartDate.getTime(), batchRunSummaryInfo.getStartDate().getTime());
    assertEquals(expectedEndDate.getTime(), batchRunSummaryInfo.getEndDate().getTime());

    assertEquals(0, batchRunSummaryInfo.getRecordsToProcess());
    assertEquals(0, batchRunSummaryInfo.getRecordsProcessed());
    assertEquals(0, batchRunSummaryInfo.getValidationFailureRecords());
    assertEquals(0, batchRunSummaryInfo.getProcessExceptionRecords());
    assertEquals(0, batchRunSummaryInfo.getUnprocessedRecords());

    assertEquals(0, batchRunSummaryInfo.getSubRecordsToProcess());
    assertEquals(0, batchRunSummaryInfo.getSubRecordsProcessed());
    assertEquals(0, batchRunSummaryInfo.getValidationFailureSubRecords());
    assertEquals(0, batchRunSummaryInfo.getProcessExceptionSubRecords());
    assertEquals(0, batchRunSummaryInfo.getUnprocessedSubRecords());
  }


  /**
   * @noinspection MagicNumber
   */
  public void testBatchRunSummaryInfo() {
    StagingInventory[] stagingInventories = createStagingInventories();

    long expectedRunHistoryId = 5;
    Date expectedStartDate = new Date();
    Date expectedEndDate = new Date(expectedStartDate.getTime() + 30000);
    RunHistory runHistory = testHelper.createRunHistory(expectedRunHistoryId, expectedStartDate, expectedEndDate);

    BatchRunSummaryInfo batchRunSummaryInfo = new BatchRunSummaryInfo(stagingInventories, runHistory);

    assertEquals(expectedRunHistoryId, batchRunSummaryInfo.getBatchRunHistoryId());
    assertEquals(expectedStartDate.getTime(), batchRunSummaryInfo.getStartDate().getTime());
    assertEquals(expectedEndDate.getTime(), batchRunSummaryInfo.getEndDate().getTime());

    assertEquals(6, batchRunSummaryInfo.getRecordsToProcess());
    assertEquals(2, batchRunSummaryInfo.getRecordsProcessed());
    assertEquals(1, batchRunSummaryInfo.getValidationFailureRecords());
    assertEquals(2, batchRunSummaryInfo.getProcessExceptionRecords());
    assertEquals(1, batchRunSummaryInfo.getUnprocessedRecords());

    assertEquals(30, batchRunSummaryInfo.getSubRecordsToProcess());
    assertEquals(8, batchRunSummaryInfo.getSubRecordsProcessed());
    assertEquals(5, batchRunSummaryInfo.getValidationFailureSubRecords());
    assertEquals(10, batchRunSummaryInfo.getProcessExceptionSubRecords());
    assertEquals(7, batchRunSummaryInfo.getUnprocessedSubRecords());
  }

  private StagingInventory[] createStagingInventories() {
    StagingInventory mainAllApproved = testHelper.createStagingInventory(StagingInventoryStatusConstants.APPROVED, 5);
    StagingInventory mainAllImported = testHelper.createStagingInventory(StagingInventoryStatusConstants.IMPORTED, 5);
    StagingInventory mainAllUnprocessed = testHelper
        .createStagingInventory(StagingInventoryStatusConstants.UNPROCESSED, 5);

    StagingInventory mainInvalid = testHelper.createStagingInventory(StagingInventoryStatusConstants.APPROVED, 5);
    mainInvalid.setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.INVALID));

    StagingInventory mainApprovedAllImported = testHelper
        .createStagingInventory(StagingInventoryStatusConstants.IMPORTED, 5);
    mainApprovedAllImported.setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.APPROVED));

    StagingInventory mainImportedWithUnprocessedSub = testHelper
        .createStagingInventory(StagingInventoryStatusConstants.IMPORTED,
            5);
    StagingParentage[] stagingParentages = mainImportedWithUnprocessedSub.getSubRecords();
    stagingParentages[stagingParentages.length - 1].getParentInventory()
        .setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.UNPROCESSED));
    stagingParentages[stagingParentages.length - 2].getParentInventory()
        .setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.UNPROCESSED));

    return new StagingInventory[]{mainAllApproved, mainAllImported, mainAllUnprocessed,
        mainApprovedAllImported, mainImportedWithUnprocessedSub, mainInvalid};
  }
}