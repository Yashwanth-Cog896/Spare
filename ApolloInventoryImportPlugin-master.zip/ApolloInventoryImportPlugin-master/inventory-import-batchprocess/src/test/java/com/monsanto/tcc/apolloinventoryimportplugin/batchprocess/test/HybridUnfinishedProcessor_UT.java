/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.HybridUnfinishedProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.InventoryImportProcessorException;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

import java.util.*;

/**
 * Filename:    $RCSfile: HybridUnfinishedProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:08:03 $
 *
 * @author ddbrow5
 * @version $Revision: 1.37 $
 * @noinspection OverlyLongMethod,MethodWithTooManyParameters
 */
public class HybridUnfinishedProcessor_UT extends ProcessorTestCase {
    private static final int MAIN_INVENTORY_ID = 1999;
    private static final int INITIAL_PARENT_INVENTORY_ID = 2000;
    private static final int INITIAL_PARENTAGE_INVENTORY_ID = 3000;
    private static final String AUTHORITY_PROCESSED = "SRKARNA";
    private static final String AUTHORITY_REQUESTED = "SSPEYY";
    private static final String CROP_NAME = "Corn";
    private static final String GERMPLASM_OWNER = "17";
    private static final String INVENTORY_OWNER = "17";
    private static final String SOURCE_PREFIX = "SOURCE ";
    private static final String HYBRID = MaterialTypeConstants.HYBRID_LINES;
    private static final String HYBRID_UNFINISHED = MaterialTypeConstants.HYBRID_UNFINISHED_LINES;
    private String templateName;
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String SEGPOP = MaterialTypeConstants.SEGPOP_LINES;
    private static final String F1_SEGPOP_UNFINISHED_LINES = MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES;
    private Random random = new Random();

    public HybridUnfinishedProcessor_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventoryIntoMidas_SimpleWithParentageCoded() throws Exception {
        String femaleParentOrigin = "II-FEMALE-XYZ-123";
        String femaleParentSource = SOURCE_PREFIX + femaleParentOrigin;
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "II-MALE-XYZ-123";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String source = SOURCE_PREFIX + hybridOrigin;
        String germplasmOwner = "17";

        try {
            purgeGermplasm(MaterialTypeConstants.CODED_LINES, femaleParentOrigin, "ABC/ANDER",
                    femaleParentGPOwner + "_" + femaleParentOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleParentOrigin, "XYZ/ABDER", maleParentOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm germplasmA = appdaoTestHelper.createGermplasm(MaterialTypeConstants.CODED_LINES, femaleParentOrigin,
                    "ABC/ANDER", femaleParentGPOwner + "_" + femaleParentOrigin, femaleParentGPOwner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "F1", null);

            Germplasm germplasmB = appdaoTestHelper.createGermplasm(FINISHED, maleParentOrigin,
                    "XYZ/ABDER", maleParentOrigin, maleParentGPOwner, CROP_NAME, "F", "T");
            appdaoTestHelper.createGeneticMaterial(germplasmB, maleParentSource, "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_UNFINISHED,
                    hybridOrigin, source, femaleParentSource, maleParentSource, femaleParentGPOwner, maleParentGPOwner,
                    germplasmOwner, germplasmOwner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertProcessorOutput(midasContext, 1, 1, 1, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(MaterialTypeConstants.CODED_LINES, femaleParentOrigin, "ABC/ANDER",
                    femaleParentGPOwner + "_" + femaleParentOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleParentOrigin, "XYZ/ABDER", maleParentOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidas_SimpleWithParentageCodedInsideParenthesis() throws Exception {
        String sourceString = "II-FEMALE-XYZ-123:2.3.";
        String femaleParentOrigin = "(" + sourceString + ")";
        String femaleParentSource = SOURCE_PREFIX + sourceString;
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "II-MALE-XYZ-123";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String source = SOURCE_PREFIX + sourceString + "+" + maleParentOrigin;
        String lineCode = "";

        Germplasm germplasmA = appdaoTestHelper.createGermplasm(MaterialTypeConstants.CODED_LINES, "II-FEMALE-XYZ-123",
                "ABC/ANDER", femaleParentGPOwner + "_II-FEMALE-XYZ-123:2.3.", femaleParentGPOwner, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "F5", "@.1.|2.3.");

        Germplasm germplasmB = appdaoTestHelper.createGermplasm(FINISHED, maleParentOrigin,
                "XYZ/ABDER", maleParentOrigin, maleParentGPOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createGeneticMaterial(germplasmB, maleParentSource, "F5", "@.1.2.|3.|");

        StagingInventory mainRecord = createStagingInventory(GERMPLASM_OWNER, hybridOrigin, source, INVENTORY_OWNER,
                lineCode, femaleParentSource, femaleParentGPOwner, maleParentSource, maleParentGPOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                "17_II-FEMALE-XYZ-123:2.3.", MaterialTypeConstants.CODED_LINES,
                "II-MALE-XYZ-123", FINISHED);
        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = processor.processInventory(context);
        midasContext.save(session);
        session.flush();

        assertProcessorOutput(midasContext, 1, 1, 1, stagingParentageList.size());
    }

    public void testProcessInventoryIntoMidas_BackcrossWithParentage() throws Exception {
        String femaleParentOrigin = "(A*3/B:@>1>3.4.5.)";
        String femaleParentSource = SOURCE_PREFIX + "A/B:@>1>3.4.5.";
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "YABC";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String pedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String source = SOURCE_PREFIX + "A/B:@>1>3.4.5.";
        String lineCode = null;

        Germplasm germplasmA = appdaoTestHelper.createGermplasm(SEGPOP, null, "A*3/B",
                femaleParentGPOwner + "_A*3/B:@>1>3.4.5.", femaleParentGPOwner, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "BC2F4", "@>1>3.4.5.");

        Germplasm germplasmB = appdaoTestHelper.createGermplasm(FINISHED, maleParentOrigin,
                "XYZ/ABDER", maleParentOrigin, maleParentGPOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createGeneticMaterial(germplasmB, maleParentSource, "F5", "@.1.2.|3.|");

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, source, INVENTORY_OWNER,
                lineCode, femaleParentSource, femaleParentGPOwner, maleParentSource,
                maleParentGPOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                femaleParentGPOwner + "_A*3/B:@>1>3.4.5.", SEGPOP,
                maleParentOrigin, FINISHED);
        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = processor.processInventory(context);
        midasContext.save(session);
        session.flush();

        assertProcessorOutput(midasContext, 1, 1, 1, stagingParentageList.size());

        Germplasm unfinishedHybridGermplasm = midasContext.getGermplasm()[0];
        assertEquals(pedigreeName, unfinishedHybridGermplasm.getPedigreeName());
    }

    public void testProcessInventoryIntoMidas_SimpleArchivedMaterial() throws Exception {
        String sourceString = "4RMX314/4AIX622:@.@.007.";
        String femaleParentOrigin = "(" + sourceString + ")";
        String femaleParentSource = SOURCE_PREFIX + sourceString;
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "3114";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String pedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String source = SOURCE_PREFIX + sourceString + "+" + maleParentOrigin;
        String lineCode = null;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                pedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        GeneticMaterial geneticMaterial = appdaoTestHelper.createGeneticMaterial(germplasmHybrid, source, "F1", null);
        Inventory archivedInventory = appdaoTestHelper.createInventory(geneticMaterial, "T", INVENTORY_OWNER);
        assertEquals("T", archivedInventory.getArchivedMaterial());

        Germplasm germplasmA = appdaoTestHelper.createGermplasm(SEGPOP, null, "4RMX314/4AIX622",
                femaleParentGPOwner + "_4RMX314/4AIX622:@.@.007.", femaleParentGPOwner, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "F4", "@.@.007.");

        Germplasm germplasmB = appdaoTestHelper.createGermplasm(FINISHED, maleParentOrigin,
                "XYZ/ABDER", maleParentOrigin, maleParentGPOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createGeneticMaterial(germplasmB, maleParentSource, "F5", "@.1.2.|3.|");

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, source, INVENTORY_OWNER,
                lineCode, femaleParentSource, femaleParentGPOwner, maleParentSource,
                maleParentGPOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                femaleParentGPOwner + "_4RMX314/4AIX622:@.@.007.", SEGPOP,
                maleParentOrigin, FINISHED);
        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = processor.processInventory(context);
        midasContext.save(session);
        session.flush();

        assertProcessorOutput(midasContext, 0, 1, 0, stagingParentageList.size());
        assertEquals(archivedInventory.getInventoryId(), midasContext.getInventory()[0].getInventoryId());
        assertEquals("F", midasContext.getInventory()[0].getArchivedMaterial());
        assertProcessorOutputHistory(midasContext, 1);
    }

    public void testProcessInventoryIntoMidas_ExistingOriginInMidas() throws Exception {
        String sourceString = "4RMX314/4AIX622:@.@.007.";
        String femaleParentOrigin = "(" + sourceString + ")";
        String femaleParentSource = SOURCE_PREFIX + sourceString;
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "3114";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String pedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String source = SOURCE_PREFIX + sourceString + "+" + maleParentOrigin;
        String lineCode = null;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                pedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmHybrid, source, "F1", null);

        Germplasm germplasmA = appdaoTestHelper.createGermplasm(SEGPOP, null, "4RMX314/4AIX622",
                femaleParentGPOwner + "_4RMX314/4AIX622:@.@.007.", femaleParentGPOwner, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "F4", "@.@.007.");

        Germplasm germplasmB = appdaoTestHelper.createGermplasm(FINISHED, maleParentOrigin,
                "XYZ/ABDER", maleParentOrigin, maleParentGPOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createGeneticMaterial(germplasmB, maleParentSource, "F5", "@.1.2.|3.|");

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, source, INVENTORY_OWNER,
                lineCode, femaleParentSource, femaleParentGPOwner, maleParentSource,
                maleParentGPOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                femaleParentGPOwner + "_4RMX314/4AIX622:@.@.007.", SEGPOP,
                maleParentOrigin, FINISHED);
        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = processor.processInventory(context);
        midasContext.save(session);
        session.flush();

        assertProcessorOutput(midasContext, 0, 1, 0, stagingParentageList.size());
        assertEquals("F", midasContext.getInventory()[0].getArchivedMaterial());
        assertProcessorOutputHistory(midasContext, 1);
    }

    public void testProcessInventoryIntoMidas_NoParentageThrowsException() throws Exception {
        String sourceString = "Ax3/B:@>1>3.4.5.";
        String femaleParentOrigin = "(A*3/B:@>1>3.4.5.)";
        String femaleParentSource = SOURCE_PREFIX + sourceString;
        String femaleParentGPOwner = "9Q";
        String maleParentOrigin = "Y";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "9Z";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String source = "PLACE HOLDER - NO SEED SENT";
        String lineCode = null;

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, source, INVENTORY_OWNER,
                lineCode, femaleParentSource, femaleParentGPOwner, maleParentSource,
                maleParentGPOwner);
        mainRecord.setStagingParentage(new LinkedHashSet());

        try {
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            new HybridUnfinishedProcessor().processInventory(context);
            fail("Expected InventoryImportProcessorException");
        } catch (InventoryImportProcessorException e) {
            assertEquals(HybridUnfinishedProcessor.TWO_PARENTS_MUST_EXIST_MSG, e.getMessage());
        }
    }

    public void testProcessInventoryIntoMidas_MissingNonFinishedParentsInMidasThrowsException() throws Exception {
        String sourceString = "4RMX314/4AIX622:@.@.007.";
        String femaleParentOrigin = "(" + sourceString + ")";
        String femaleParentSource = SOURCE_PREFIX + sourceString;
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "3114";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String pedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String source = SOURCE_PREFIX + sourceString + "+" + maleParentOrigin;
        String lineCode = null;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                pedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmHybrid, source, "F1", null);

        Germplasm germplasmA = appdaoTestHelper.createGermplasm(SEGPOP, null, "4RMX314/4AIX622",
                femaleParentGPOwner + "_4RMX314/4AIX622:@.@.007.", femaleParentGPOwner, CROP_NAME, "F", "F");
        appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "F4", "@.@.007.");

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, source, INVENTORY_OWNER,
                lineCode, femaleParentSource, femaleParentGPOwner, maleParentSource,
                maleParentGPOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                femaleParentGPOwner + "_4RMX314/4AIX622:@.@.007.", SEGPOP,
                maleParentOrigin, MaterialTypeConstants.CODED_LINES);
        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        try {
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            new HybridUnfinishedProcessor().processInventory(context);
            fail("Expected InventoryImportProcessorException");
        } catch (InventoryImportProcessorException e) {
            assertEquals(HybridUnfinishedProcessor.PARENT_NOT_FOUND_IN_MIDAS, e.getMessage());
        }
    }

    public void testProcessInventoryIntoMidas_NullInventoryThrowsException() throws Exception {
        try {
            new HybridUnfinishedProcessor().processInventory(null);
            fail("Expected IllegalStateException");
        }
        catch (IllegalStateException e) {
            assertEquals(HybridUnfinishedProcessor.INVENTORY_CANNOT_BE_NULL_MSG, e.getMessage());
        }
    }


    public void testProcessInventoryIntoMidasWithEvents() throws Exception {
        String femaleParentOrigin = "II-FEMALE-XYZ-123";
        String femaleParentSource = SOURCE_PREFIX + femaleParentOrigin;
        String femaleParentGPOwner = "17";
        String maleParentOrigin = "II-MALE-XYZ-123";
        String maleParentSource = SOURCE_PREFIX + maleParentOrigin;
        String maleParentGPOwner = "17";
        String hybridOrigin = femaleParentOrigin + "+" + maleParentOrigin;
        String source = SOURCE_PREFIX + hybridOrigin;
        String germplasmOwner = "17";
        String eventName = "EVENT-FinishedIIProcessor_UT".toUpperCase();
        String eventConstructName = "CONST-FinishedIIProcessor_UT".toUpperCase();
        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        EventConstruct expectedEventConstruct = null;
        try {
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(MaterialTypeConstants.CODED_LINES, femaleParentOrigin, "ABC/ANDER",
                    femaleParentGPOwner + "_" + femaleParentOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleParentOrigin, "XYZ/ABDER", maleParentOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm germplasmA = appdaoTestHelper.createGermplasm(MaterialTypeConstants.CODED_LINES, femaleParentOrigin,
                    "ABC/ANDER", femaleParentGPOwner + "_" + femaleParentOrigin, femaleParentGPOwner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(germplasmA, femaleParentSource, "F1", null);

            Germplasm germplasmB = appdaoTestHelper.createGermplasm(FINISHED, maleParentOrigin,
                    "XYZ/ABDER", maleParentOrigin, maleParentGPOwner, CROP_NAME, "F", "T");
            appdaoTestHelper.createGeneticMaterial(germplasmB, maleParentSource, "INBRED", "|");

            EventConstruct eventConstruct = appdaoTestHelper
                    .createEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            expectedEventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "T");

            appdaoTestHelper.createGermplasmEventConstruct(germplasmA.getId(), eventConstruct.getEventConstructId());
            appdaoTestHelper.createGermplasmEventConstruct(germplasmA.getId(), expectedEventConstruct.getEventConstructId());
            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_UNFINISHED,
                    hybridOrigin, source, femaleParentSource, maleParentSource, femaleParentGPOwner, maleParentGPOwner,
                    germplasmOwner, germplasmOwner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "N", eventName);

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertProcessorOutput(midasContext, 1, 1, 1, mainRecord.getStagingParentage().size());

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(1, germplasms[0].getGermplasmEventConstruct().size());
            Iterator germplasmEventConstructIter = germplasms[0].getGermplasmEventConstruct().iterator();
            GermplasmEventConstruct actualGermplasmEventConstruct = (GermplasmEventConstruct) germplasmEventConstructIter
                    .next();
            assertEquals(actualGermplasmEventConstruct.getEventConstruct().getEventConstructId(),
                    expectedEventConstruct.getEventConstructId());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(MaterialTypeConstants.CODED_LINES, femaleParentOrigin, "ABC/ANDER",
                    femaleParentGPOwner + "_" + femaleParentOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleParentOrigin, "XYZ/ABDER", maleParentOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidas_FinishedParentGeneticMaterialIsOptional_FinishedParentSourceIsUserProvided_InventoryWillBeCreated() throws
            Exception {
        String germplasmOwner = "17";
        String segpopOrigin = "4RMX314/4AIX622";
        String segpopLineage = "@.@.007.";
        String segpopOriginPlusLineage = segpopOrigin + ":" + segpopLineage;
        String segpopParentOrigin = "(" + segpopOriginPlusLineage + ")";
        String segpopParentSource = SOURCE_PREFIX + segpopOriginPlusLineage;
        String segpopPedigree = germplasmOwner + "_" + segpopOriginPlusLineage;
        String finishedParentOrigin = "3114";
        String finishedLineCode = finishedParentOrigin + "-LC";
        String sourceOfNewlyCreatedGP = SOURCE_PREFIX + finishedParentOrigin;
        String hybridOrigin = segpopParentOrigin + "+" + finishedParentOrigin;
        String hybridPedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String hybridSource = SOURCE_PREFIX + segpopOriginPlusLineage + "+" + finishedParentOrigin;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                hybridPedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        GeneticMaterial hybridGM = appdaoTestHelper.createGeneticMaterial(germplasmHybrid, hybridSource, "F1", null);

        Germplasm segpopGP = appdaoTestHelper.createGermplasm(SEGPOP, null, segpopOrigin,
                segpopPedigree, germplasmOwner, CROP_NAME, "F", "F");
        GeneticMaterial segpopGM = appdaoTestHelper
                .createGeneticMaterial(segpopGP, segpopParentSource, "F4", segpopLineage);

        Germplasm finishedGP = appdaoTestHelper.createGermplasm(FINISHED, finishedLineCode,
                finishedParentOrigin, finishedLineCode, germplasmOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createInbredGeneticMaterial(finishedGP, "SOME SOURCE");

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, hybridSource, INVENTORY_OWNER,
                finishedLineCode, segpopParentSource, germplasmOwner, sourceOfNewlyCreatedGP, germplasmOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                segpopPedigree, SEGPOP, finishedLineCode, FINISHED);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory().setLineCode(finishedLineCode);

        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = new HybridUnfinishedProcessor().processInventory(context);
        assertMidasContext(midasContext, 0, 2, 1, 2);

        GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
        assertEquals(finishedGP.getId(), geneticMaterials[0].getGermplasm().getId());
        assertEquals("F", geneticMaterials[0].getIsAutogen());
        assertEquals(sourceOfNewlyCreatedGP, geneticMaterials[0].getSourceStr());

        Parentage[] parentage = midasContext.getParentage();
        assertEquals(hybridGM.getGeneticMaterialId(), parentage[0].getGeneticMaterial().getGeneticMaterialId());
        assertEquals(segpopGM.getGeneticMaterialId(), parentage[0].getParentGeneticMaterial().getGeneticMaterialId());
        assertEquals("F", parentage[0].getParentalRole().getParentalRoleRefId());

        assertEquals(parentage[1].getGeneticMaterial().getGeneticMaterialId(), hybridGM.getGeneticMaterialId());
        assertEquals(parentage[1].getParentGeneticMaterial().getGeneticMaterialId(),
                geneticMaterials[0].getGeneticMaterialId());
        assertEquals("M", parentage[1].getParentalRole().getParentalRoleRefId());
    }

    public void testProcessInventoryIntoMidas_FinishedParentGeneticMaterialIsOptional_FinishedParentSourceIsDefault_InventoryWillNotBeCreated() throws
            Exception {
        String germplasmOwner = "17";
        String segpopOrigin = "4RMX314/4AIX622";
        String segpopLineage = "@.@.007.";
        String segpopOriginPlusLineage = segpopOrigin + ":" + segpopLineage;
        String segpopParentOrigin = "(" + segpopOriginPlusLineage + ")";
        String segpopParentSource = SOURCE_PREFIX + segpopOriginPlusLineage;
        String segpopPedigree = germplasmOwner + "_" + segpopOriginPlusLineage;
        String finishedParentOrigin = "3114";
        String finishedLineCode = finishedParentOrigin + "-LC";
        String sourceOfNewlyCreatedGP = SOURCE_PREFIX + finishedParentOrigin;
        String hybridOrigin = segpopParentOrigin + "+" + finishedParentOrigin;
        String hybridPedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String hybridSource = SOURCE_PREFIX + segpopOriginPlusLineage + "+" + finishedParentOrigin;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                hybridPedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        GeneticMaterial hybridGM = appdaoTestHelper.createGeneticMaterial(germplasmHybrid, hybridSource, "F1", null);

        Germplasm segpopGP = appdaoTestHelper.createGermplasm(SEGPOP, null, segpopOrigin,
                segpopPedigree, germplasmOwner, CROP_NAME, "F", "F");
        GeneticMaterial segpopGM = appdaoTestHelper
                .createGeneticMaterial(segpopGP, segpopParentSource, "F4", segpopLineage);

        Germplasm finishedGP = appdaoTestHelper.createGermplasm(FINISHED, finishedLineCode,
                finishedParentOrigin, finishedLineCode, germplasmOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createInbredGeneticMaterial(finishedGP, "SOME SOURCE");

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, hybridSource, INVENTORY_OWNER,
                finishedLineCode, segpopParentSource, germplasmOwner, sourceOfNewlyCreatedGP, germplasmOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                segpopPedigree, SEGPOP, finishedLineCode, FINISHED);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory().setLineCode(finishedLineCode);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory()
                .setSource(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory().setUserSpecifiedSource("F");

        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = new HybridUnfinishedProcessor().processInventory(context);
        assertMidasContext(midasContext, 0, 1, 1, 2);

        GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
        assertEquals(finishedGP.getId(), geneticMaterials[0].getGermplasm().getId());
        assertEquals("T", geneticMaterials[0].getIsAutogen());
        assertEquals(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, geneticMaterials[0].getSourceStr());

        Parentage[] parentage = midasContext.getParentage();
        assertEquals(hybridGM.getGeneticMaterialId(), parentage[0].getGeneticMaterial().getGeneticMaterialId());
        assertEquals(segpopGM.getGeneticMaterialId(), parentage[0].getParentGeneticMaterial().getGeneticMaterialId());
        assertEquals("F", parentage[0].getParentalRole().getParentalRoleRefId());

        assertEquals(parentage[1].getGeneticMaterial().getGeneticMaterialId(), hybridGM.getGeneticMaterialId());
        assertEquals(parentage[1].getParentGeneticMaterial().getGeneticMaterialId(),
                geneticMaterials[0].getGeneticMaterialId());
        assertEquals("M", parentage[1].getParentalRole().getParentalRoleRefId());
    }

    public void testProcessInventoryIntoMidas_FinishedHybridParentGeneticMaterialIsOptional_FinishedHybridParentSourceIsUserProvided_InventoryWillBeCreated() throws
            Exception {
        String germplasmOwner = "17";
        String segpopOrigin = "4RMX314/4AIX622";
        String segpopLineage = "@.@.007.";
        String segpopOriginPlusLineage = segpopOrigin + ":" + segpopLineage;
        String segpopParentOrigin = "(" + segpopOriginPlusLineage + ")";
        String segpopParentSource = SOURCE_PREFIX + segpopOriginPlusLineage;
        String segpopPedigree = germplasmOwner + "_" + segpopOriginPlusLineage;

        String hybridParentOrigin = "8675309";
        String hybridParentPedigree = hybridParentOrigin;
        String hybridParentLineCode = hybridParentOrigin;

        String sourceOfNewlyCreatedGP = SOURCE_PREFIX + hybridParentOrigin;
        String hybridOrigin = segpopParentOrigin + "+" + hybridParentOrigin;
        String hybridPedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String hybridSource = SOURCE_PREFIX + segpopOriginPlusLineage + "+" + hybridParentOrigin;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                hybridPedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        GeneticMaterial hybridGM = appdaoTestHelper.createGeneticMaterial(germplasmHybrid, hybridSource, "F1", null);

        Germplasm segpopGP = appdaoTestHelper.createGermplasm(SEGPOP, null, segpopOrigin,
                segpopPedigree, germplasmOwner, CROP_NAME, "F", "F");
        GeneticMaterial segpopGM = appdaoTestHelper
                .createGeneticMaterial(segpopGP, segpopParentSource, "F4", segpopLineage);

        Germplasm hybridParentGP = appdaoTestHelper
                .createGermplasm(MaterialTypeConstants.HYBRID_LINES, hybridParentLineCode,
                        hybridParentOrigin, hybridParentPedigree, germplasmOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createGeneticMaterial(hybridParentGP, "SOME SOURCE", "INBRED", null);

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, hybridSource, INVENTORY_OWNER,
                hybridParentLineCode, segpopParentSource, germplasmOwner, sourceOfNewlyCreatedGP, germplasmOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                segpopPedigree, SEGPOP, hybridParentLineCode, MaterialTypeConstants.HYBRID_LINES);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory().setOrigin(hybridParentOrigin);

        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = new HybridUnfinishedProcessor().processInventory(context);
        assertMidasContext(midasContext, 0, 2, 1, 2);

        GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
        assertEquals(hybridParentGP.getId(), geneticMaterials[0].getGermplasm().getId());
        assertEquals("F", geneticMaterials[0].getIsAutogen());
        assertEquals(sourceOfNewlyCreatedGP, geneticMaterials[0].getSourceStr());

        Parentage[] parentage = midasContext.getParentage();
        assertEquals(hybridGM.getGeneticMaterialId(), parentage[0].getGeneticMaterial().getGeneticMaterialId());
        assertEquals(segpopGM.getGeneticMaterialId(), parentage[0].getParentGeneticMaterial().getGeneticMaterialId());
        assertEquals("F", parentage[0].getParentalRole().getParentalRoleRefId());

        assertEquals(hybridGM.getGeneticMaterialId(), parentage[1].getGeneticMaterial().getGeneticMaterialId());
        assertEquals(geneticMaterials[0].getGeneticMaterialId(),
                parentage[1].getParentGeneticMaterial().getGeneticMaterialId());
        assertEquals("M", parentage[1].getParentalRole().getParentalRoleRefId());
    }

    public void testProcessInventoryIntoMidas_FinishedHybridParentGeneticMaterialIsOptional_FinishedHybridParentSourceIsDefault_InventoryWillNotBeCreated() throws
            Exception {
        String germplasmOwner = "17";
        String segpopOrigin = "4RMX314/4AIX622";
        String segpopLineage = "@.@.007.";
        String segpopOriginPlusLineage = segpopOrigin + ":" + segpopLineage;
        String segpopParentOrigin = "(" + segpopOriginPlusLineage + ")";
        String segpopParentSource = SOURCE_PREFIX + segpopOriginPlusLineage;
        String segpopPedigree = germplasmOwner + "_" + segpopOriginPlusLineage;

        String hybridParentOrigin = "8675309";
        String hybridParentPedigree = hybridParentOrigin;
        String hybridParentLineCode = hybridParentOrigin;

        String sourceOfNewlyCreatedGP = SOURCE_PREFIX + hybridParentOrigin;
        String hybridOrigin = segpopParentOrigin + "+" + hybridParentOrigin;
        String hybridPedigreeName = GERMPLASM_OWNER + "_" + hybridOrigin;
        String hybridSource = SOURCE_PREFIX + segpopOriginPlusLineage + "+" + hybridParentOrigin;

        Germplasm germplasmHybrid = appdaoTestHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null, hybridOrigin,
                hybridPedigreeName, GERMPLASM_OWNER, CROP_NAME, "F", "F");
        GeneticMaterial hybridGM = appdaoTestHelper.createGeneticMaterial(germplasmHybrid, hybridSource, "F1", null);

        Germplasm segpopGP = appdaoTestHelper.createGermplasm(SEGPOP, null, segpopOrigin,
                segpopPedigree, germplasmOwner, CROP_NAME, "F", "F");
        GeneticMaterial segpopGM = appdaoTestHelper
                .createGeneticMaterial(segpopGP, segpopParentSource, "F4", segpopLineage);

        Germplasm hybridParentGP = appdaoTestHelper
                .createGermplasm(MaterialTypeConstants.HYBRID_LINES, hybridParentLineCode,
                        hybridParentOrigin, hybridParentPedigree, germplasmOwner, CROP_NAME, "F", "T");
        appdaoTestHelper.createGeneticMaterial(hybridParentGP, "SOME SOURCE", "INBRED", null);

        StagingInventory mainRecord = createStagingInventory(INVENTORY_OWNER, hybridOrigin, hybridSource, INVENTORY_OWNER,
                hybridParentLineCode, segpopParentSource, germplasmOwner, sourceOfNewlyCreatedGP, germplasmOwner);

        List<StagingParentage> stagingParentageList = createSubRecordsAndParentageLinkagesForSimpleLineage(mainRecord,
                segpopPedigree, SEGPOP, hybridParentLineCode, MaterialTypeConstants.HYBRID_LINES);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory().setOrigin(hybridParentOrigin);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory()
                .setSource(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
        ((StagingParentage) stagingParentageList.get(1)).getParentInventory().setUserSpecifiedSource("F");

        mainRecord.setStagingParentage(new LinkedHashSet<StagingParentage>(stagingParentageList));

        MockInventoryContext context = new MockInventoryContext(mainRecord);
        MidasContext midasContext = new HybridUnfinishedProcessor().processInventory(context);
        assertMidasContext(midasContext, 0, 1, 1, 2);

        GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
        assertEquals(hybridParentGP.getId(), geneticMaterials[0].getGermplasm().getId());
        assertEquals("T", geneticMaterials[0].getIsAutogen());
        assertEquals(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, geneticMaterials[0].getSourceStr());

        Parentage[] parentage = midasContext.getParentage();
        assertEquals(hybridGM.getGeneticMaterialId(), parentage[0].getGeneticMaterial().getGeneticMaterialId());
        assertEquals(segpopGM.getGeneticMaterialId(), parentage[0].getParentGeneticMaterial().getGeneticMaterialId());
        assertEquals("F", parentage[0].getParentalRole().getParentalRoleRefId());

        assertEquals(hybridGM.getGeneticMaterialId(), parentage[1].getGeneticMaterial().getGeneticMaterialId());
        assertEquals(geneticMaterials[0].getGeneticMaterialId(),
                parentage[1].getParentGeneticMaterial().getGeneticMaterialId());
        assertEquals("M", parentage[1].getParentalRole().getParentalRoleRefId());
    }

    public void testProcessInventoryIntoMidas_OneParentTranslatesToSegpop() throws Exception {
        String owner = "17";
        String femaleSegpopOrigin = "II-HYB-F/II-HYB-M";
        String femaleHybridOrigin = femaleSegpopOrigin.replaceAll("\\/", "+");
        String femaleParentSource = SOURCE_PREFIX + femaleSegpopOrigin;
        String maleParentLineCode = "II-INBRED-MALE-LC";
        String maleParentOrigin = "II-INBRED-FEMALE-LC/II-INBRED-MALE-LC";
        String maleParentSource = SOURCE_PREFIX + maleParentLineCode;
        String hybridOrigin = femaleHybridOrigin + "++" + maleParentLineCode;
        String hybridPedigree = owner + "_" + hybridOrigin;
        String source = SOURCE_PREFIX + hybridOrigin;

        GeneticMaterial segpopGm = null;
        GeneticMaterial inbredGm = null;
        try {
            purgeGermplasm(SEGPOP, femaleSegpopOrigin, femaleSegpopOrigin, owner + "_" + femaleSegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleParentLineCode, maleParentOrigin, maleParentLineCode, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm segpopGp = appdaoTestHelper.createGermplasm(SEGPOP, femaleSegpopOrigin, femaleSegpopOrigin,
                    owner + "_" + femaleSegpopOrigin, owner, CROP_NAME);
            segpopGm = appdaoTestHelper.createGeneticMaterial(segpopGp, femaleParentSource, "F1", null);

            Germplasm inbredGp = appdaoTestHelper.createInbred(maleParentLineCode, owner, CROP_NAME, maleParentOrigin);
            inbredGm = appdaoTestHelper.createInbredGeneticMaterial(inbredGp, maleParentSource);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_UNFINISHED,
                    hybridOrigin, source, femaleParentSource, maleParentSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertProcessorOutput(midasContext, 1, 1, 1, mainRecord.getStagingParentage().size());

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(hybridOrigin, germplasms[0].getOrigin());
            assertEquals(hybridPedigree, germplasms[0].getPedigreeName());
            assertEquals(HYBRID, germplasms[0].getLineType().getName());

            GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
            assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
            assertEquals("F", geneticMaterials[0].getIsAutogen());
            assertEquals(source, geneticMaterials[0].getSourceStr());

            Parentage[] parentage = midasContext.getParentage();
            assertEquals(geneticMaterials[0].getGeneticMaterialId(),
                    parentage[0].getGeneticMaterial().getGeneticMaterialId());
            assertEquals(segpopGm.getGeneticMaterialId(), parentage[0].getParentGeneticMaterial().getGeneticMaterialId());
            assertEquals("F", parentage[0].getParentalRole().getParentalRoleRefId());

            assertEquals(geneticMaterials[0].getGeneticMaterialId(),
                    parentage[1].getGeneticMaterial().getGeneticMaterialId());
            assertEquals(inbredGm.getGeneticMaterialId(), parentage[1].getParentGeneticMaterial().getGeneticMaterialId());
            assertEquals("M", parentage[1].getParentalRole().getParentalRoleRefId());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, femaleSegpopOrigin, femaleSegpopOrigin, owner + "_" + femaleSegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleParentLineCode, maleParentOrigin, maleParentLineCode, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidas_TwoParentTranslateToSegpop() throws Exception {
        String owner = "17";
        String femaleSegpopOrigin = "II-HYB-F/II-HYB-M";
        String femaleHybridOrigin = femaleSegpopOrigin.replaceAll("\\/", "+");
        String femaleParentSource = SOURCE_PREFIX + femaleSegpopOrigin;

        String maleSegpopOrigin = "II-HYB-F-2/II-HYB-M-2";
        String maleHybridOrigin = maleSegpopOrigin.replaceAll("\\/", "+");
        String maleParentSource = SOURCE_PREFIX + maleSegpopOrigin;
        String hybridOrigin = femaleHybridOrigin + "++" + maleHybridOrigin;
        String hybridPedigree = owner + "_" + hybridOrigin;
        String source = SOURCE_PREFIX + hybridOrigin;

        GeneticMaterial segpopFemaleGm = null;
        GeneticMaterial segpopMaleGm = null;
        try {
            purgeGermplasm(SEGPOP, femaleSegpopOrigin, femaleSegpopOrigin, owner + "_" + femaleSegpopOrigin, CROP_NAME);
            purgeGermplasm(SEGPOP, maleSegpopOrigin, maleSegpopOrigin, owner + "_" + maleSegpopOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm segpopFemaleGp = appdaoTestHelper.createGermplasm(SEGPOP, femaleSegpopOrigin, femaleSegpopOrigin,
                    owner + "_" + femaleSegpopOrigin, owner, CROP_NAME);
            segpopFemaleGm = appdaoTestHelper.createGeneticMaterial(segpopFemaleGp, femaleParentSource, "F1", null);

            Germplasm segpopMaleGp = appdaoTestHelper.createGermplasm(SEGPOP, maleSegpopOrigin, maleSegpopOrigin,
                    owner + "_" + maleSegpopOrigin, owner, CROP_NAME);
            segpopMaleGm = appdaoTestHelper.createGeneticMaterial(segpopMaleGp, maleParentSource, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_UNFINISHED,
                    hybridOrigin, source, femaleParentSource, maleParentSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            HybridUnfinishedProcessor processor = new HybridUnfinishedProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertProcessorOutput(midasContext, 1, 1, 1, mainRecord.getStagingParentage().size());

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(hybridOrigin, germplasms[0].getOrigin());
            assertEquals(hybridPedigree, germplasms[0].getPedigreeName());
            assertEquals(HYBRID, germplasms[0].getLineType().getName());

            GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
            assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
            assertEquals("F", geneticMaterials[0].getIsAutogen());
            assertEquals(source, geneticMaterials[0].getSourceStr());

            Parentage[] parentage = midasContext.getParentage();
            assertEquals(geneticMaterials[0].getGeneticMaterialId(),
                    parentage[0].getGeneticMaterial().getGeneticMaterialId());
            assertEquals(segpopFemaleGm.getGeneticMaterialId(),
                    parentage[0].getParentGeneticMaterial().getGeneticMaterialId());
            assertEquals("F", parentage[0].getParentalRole().getParentalRoleRefId());

            assertEquals(geneticMaterials[0].getGeneticMaterialId(),
                    parentage[1].getGeneticMaterial().getGeneticMaterialId());
            assertEquals(segpopMaleGm.getGeneticMaterialId(), parentage[1].getParentGeneticMaterial().getGeneticMaterialId());
            assertEquals("M", parentage[1].getParentalRole().getParentalRoleRefId());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, femaleSegpopOrigin, femaleSegpopOrigin, owner + "_" + femaleSegpopOrigin, CROP_NAME);
            purgeGermplasm(SEGPOP, maleSegpopOrigin, maleSegpopOrigin, owner + "_" + maleSegpopOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    private StagingInventory createStagingInventory(String germplasmOwner, String origin, String source,
                                                    String inventoryOwner, String lineCode, String femaleParentSource,
                                                    String gpOwnerOfFemale, String maleParentSource,
                                                    String gpOwnerOfMale) {
        StagingInventoryHeader invHdr = new StagingInventoryHeader();
        invHdr.setCropName(CROP_NAME);
        invHdr.setUserId(userId);
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.HYBRID_LINES);
        invHdr.setImportType(importType);

        StagingInventory mainRecord = new StagingInventory();
        mainRecord.setId(new Long(MAIN_INVENTORY_ID));
        mainRecord.setLineType("Hybrid");
        mainRecord.setGermplasmOwner(germplasmOwner);
        mainRecord.setOrigin(origin);
        mainRecord.setSource(source);
        mainRecord.setInventoryOwner(inventoryOwner);
        mainRecord.setFemaleParentSource(femaleParentSource);
        mainRecord.setGermplasmOwnerOfFemaleParent(gpOwnerOfFemale);
        mainRecord.setMaleParentSource(maleParentSource);
        mainRecord.setGermplasmOwnerOfMaleParent(gpOwnerOfMale);

        mainRecord.setGeneration("");
        mainRecord.setLineage("");
        mainRecord.setLineType(invHdr.getImportType().getAbbreviation());
        mainRecord.setPedigreeName(germplasmOwner + "_" + origin);
        mainRecord.setLineCode(lineCode);
        mainRecord.setInventoryHeader(invHdr);
        mainRecord.setApprovalProcessDate(new Date());
        mainRecord.setApprovalRequestDate(new Date());
        mainRecord.setValidationDate(new Date());
        mainRecord.setAuthorityRequested(AUTHORITY_REQUESTED);
        mainRecord.setAuthorityProcessed(AUTHORITY_PROCESSED);
        return mainRecord;
    }

    private List<StagingParentage> createSubRecordsAndParentageLinkagesForSimpleLineage(StagingInventory mainRecord,
                                                                                        String femaleParentPedigreeName,
                                                                                        String femaleParentLineType,
                                                                                        String maleParentPedigreeName,
                                                                                        String maleParentLineType) {
        MockStagingInventoryParentage stagingInventoryParentage = new MockStagingInventoryParentage(mainRecord,
                femaleParentPedigreeName, femaleParentLineType,
                maleParentPedigreeName, maleParentLineType);

        StagingInventory[] subRecordArray = stagingInventoryParentage.getSubRecords();
        StagingParentage[] stagingParentageArray = stagingInventoryParentage.getStagingParentageRecords();

        for (int i = 0; i < subRecordArray.length; i++) {
            StagingInventory stagingInventory = (StagingInventory) subRecordArray[i];
            stagingInventory.setId(new Long(INITIAL_PARENT_INVENTORY_ID + i));
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setValidationDate(new Date());
            stagingInventory.setAuthorityRequested(AUTHORITY_REQUESTED);
            stagingInventory.setAuthorityProcessed(AUTHORITY_PROCESSED);
//      if( 0 < i && 0 == i % 2 ) {
//        stagingInventory.setLineType("Segpop");
//      }
//      else {
//        stagingInventory.setLineType("Finished");
//      }
        }

        for (int i = 0; i < stagingParentageArray.length; i++) {
            stagingParentageArray[i].setId(new Long(INITIAL_PARENTAGE_INVENTORY_ID + i));
        }
        return Arrays.asList(stagingParentageArray);
    }

    class MockStagingInventoryParentage {
        private StagingInventory[] stagingInventories;
        private StagingParentage[] stagingParentages;

        public MockStagingInventoryParentage(StagingInventory mainRecord,
                                             String femaleParentPedigreeName, String femaleParentLineType,
                                             String maleParentPedigreeName, String maleParentLineType) {
            stagingInventories = new StagingInventory[2];
            stagingInventories[0] = new StagingInventory();
            stagingInventories[0].setInventoryHeader(mainRecord.getInventoryHeader());
            stagingInventories[0].setPedigreeName(femaleParentPedigreeName);
            stagingInventories[0].setSource(mainRecord.getFemaleParentSource());
            stagingInventories[0].setInventoryOwner(mainRecord.getGermplasmOwnerOfFemaleParent());
            stagingInventories[0].setLineType(femaleParentLineType);
            stagingInventories[1] = new StagingInventory();
            stagingInventories[1].setInventoryHeader(mainRecord.getInventoryHeader());
            stagingInventories[1].setPedigreeName(maleParentPedigreeName);
            stagingInventories[1].setSource(mainRecord.getMaleParentSource());
            stagingInventories[1].setInventoryOwner(mainRecord.getGermplasmOwnerOfMaleParent());
            stagingInventories[1].setLineType(maleParentLineType);

            stagingParentages = new StagingParentage[2];
            stagingParentages[0] = new StagingParentage();
            stagingParentages[0].setChildInventory(mainRecord);
            stagingParentages[0].setParentInventory(stagingInventories[0]);
            stagingParentages[0].setMainInventory(mainRecord);
            stagingParentages[0].setParentalRole("F");
            stagingParentages[1] = new StagingParentage();
            stagingParentages[1].setChildInventory(mainRecord);
            stagingParentages[1].setParentInventory(stagingInventories[1]);
            stagingParentages[1].setMainInventory(mainRecord);
            stagingParentages[1].setParentalRole("M");
        }

        public StagingInventory[] getSubRecords() {
            return stagingInventories;
        }

        public StagingParentage[] getStagingParentageRecords() {
            return stagingParentages;
        }
    }

    private void assertProcessorOutputHistory(MidasContext mockProcessor, int historyCount) {
        Inventory inventory = mockProcessor.getInventory()[0];
        Set historySet = inventory.getInventoryImportHistory();
        assertNotNull(historySet);
        assertEquals(historyCount, historySet.size());

        Iterator historyIter = historySet.iterator();
        InventoryImportHistory history = (InventoryImportHistory) historyIter.next();
        assertEquals(inventory, history.getInventory());
    }

    private void assertProcessorOutput(MidasContext mockProcessor,
                                       int expectedGermlasmCount, int expectedInventoryCount,
                                       int expectedGeneticMaterialCount, int expectedParentageCount
    ) {
        assertNotNull(mockProcessor.getGermplasm());
        assertEquals(expectedGermlasmCount, mockProcessor.getGermplasm().length);

        assertNotNull(mockProcessor.getInventory());
        assertEquals(expectedInventoryCount, mockProcessor.getInventory().length);

        assertNotNull(mockProcessor.getGeneticMatterial());
        assertEquals(expectedGeneticMaterialCount, mockProcessor.getGeneticMatterial().length);

        assertNotNull(mockProcessor.getParentage());
        assertEquals(expectedParentageCount, mockProcessor.getParentage().length);
    }
}