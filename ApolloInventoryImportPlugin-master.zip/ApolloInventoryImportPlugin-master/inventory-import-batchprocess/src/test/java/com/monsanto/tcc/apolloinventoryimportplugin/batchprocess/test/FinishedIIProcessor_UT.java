/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmEventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.FinishedIIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.IIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

import java.util.Date;
import java.util.Iterator;
import java.util.Random;

/**
 * Filename:    $RCSfile: FinishedIIProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspeyy $    	 On:	$Date: 2009-06-05 14:08:02 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class FinishedIIProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String CODED = MaterialTypeConstants.CODED_LINES;
    private String templateName;
    private Random random = new Random();

    public FinishedIIProcessor_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventoryIntoMidasWithoutSubRecordsForBackCross() throws Exception {
        FinishedIIProcessor processor = new FinishedIIProcessor();
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(1001));
        stagingInventory.setGeneration("BC2F3");
        stagingInventory.setGermplasmOwner("LT");
        stagingInventory.setLineage("@>0002>|0001.0002.|");
        stagingInventory.setOrigin("A*3/B");
        stagingInventory.setLineType("Finished");
        stagingInventory.setInventoryOwner("LT");
        stagingInventory.setLineCode("XYZABC");
        stagingInventory.setPedigreeName("XYZABC");
        StagingInventoryHeader invHdr = new StagingInventoryHeader();
        invHdr.setCropName(CROP_NAME);
        invHdr.setUserId("SKUMAR5");
        stagingInventory.setInventoryHeader(invHdr);
        stagingInventory.setSource("Test Source");
        stagingInventory.setApprovalProcessDate(new Date());
        stagingInventory.setApprovalRequestDate(new Date());
        stagingInventory.setValidationDate(new Date());
        stagingInventory.setAuthorityRequested("SSPEYY");
        stagingInventory.setAuthorityProcessed("SRKARNA");

        MockInventoryContext context = new MockInventoryContext(stagingInventory);
        MidasContext midasContext = processor.processInventory(context);
        session.getTransaction().rollback();

        assertMidasContext(midasContext, 1, 1, 1, 0);
    }

    public void testProcessInventoryIntoMidasWithoutSubRecordsForSimple() throws Exception {
        FinishedIIProcessor processor = new FinishedIIProcessor();
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(1001));
        stagingInventory.setGeneration("INBRED");
        stagingInventory.setGermplasmOwner("LT");
        stagingInventory.setLineage("|");
        stagingInventory.setOrigin("A/B");
        stagingInventory.setLineType("Finished");
        stagingInventory.setInventoryOwner("LT");
        stagingInventory.setLineCode("XYZABC");
        StagingInventoryHeader invHdr = new StagingInventoryHeader();
        invHdr.setCropName(CROP_NAME);
        invHdr.setUserId("SKUMAR5");
        stagingInventory.setInventoryHeader(invHdr);
        stagingInventory.setSource("Test Source");
        stagingInventory.setApprovalProcessDate(new Date());
        stagingInventory.setApprovalRequestDate(new Date());
        stagingInventory.setValidationDate(new Date());
        stagingInventory.setAuthorityRequested("SSPEYY");
        stagingInventory.setAuthorityProcessed("SRKARNA");

        MockInventoryContext context = new MockInventoryContext(stagingInventory);
        MidasContext midasContext = processor.processInventory(context);
        session.getTransaction().rollback();

        assertMidasContext(midasContext, 1, 1, 1, 0);
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForBackCross() throws Exception {
        String generation = "BC6F3";
        String germplasmOwner = "LT";
        String lineage = "@>001>002>003>|004.005.006>007>|008.009.";
        String origin = "A*7/B";
        String source = origin.replace('*', ' ') + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("A", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "B", "CSA/ASDA", "B", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;;;;;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 9, 3, 14, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForBackCrossWithExistingRecurrentParent() throws Exception {
        String generation = "BC6F3";
        String germplasmOwner = "LT";
        String lineage = "@>001>002>003>" +
                "|004.005.006>007>|008.009.";
        String origin = "A*7/B";
        String source = origin.replace('*', ' ') + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("A", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "B", "CSA/ASDA", "B", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;;;;;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 9, 3, 13, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimple() throws Exception {
        String generation = "F7";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.|5.";
        String origin = "A/B";
        String source = origin + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("A", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "B", "CSA/ASDA", "B", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 6, 3, 9, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimple() throws Exception {
        String generation = "F7";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.|5.";
        String origin = "A/B";
        String source = origin + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("A", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "B", "CSA/ASDA", "B", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");

            Germplasm dupGp = appdaoTestHelper
                    .createGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(dupGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F4", "@.1.2.|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 5, 3, 8, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsOnFinishedWithGenericSources() throws Exception {
        String generation = "F7";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.|5.6.";
        String origin = "AZ/BX";
        String source = origin + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABXC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "AZ", "ABC/XYZ", "AZ", CROP_NAME);
            purgeGermplasm(FINISHED, "BX", "CSA/ASDA", "BX", CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("AZ", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "BX", "CSA/ASDA", "BX", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");

            Germplasm dupGp = appdaoTestHelper
                    .createGermplasm(FINISHED, lineCode, origin, lineCode, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(dupGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F6", "@.1.2.|3.|5.");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 4, 3, 7, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "AZ", "ABC/XYZ", "AZ", CROP_NAME);
            purgeGermplasm(FINISHED, "BX", "CSA/ASDA", "BX", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsOnFinishedWithSpecificSources() throws Exception {
        String generation = "F7";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.|5.6.";
        String origin = "AZ/BX";
        String source = origin + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABXC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "AZ", "ABC/XYZ", "AZ", CROP_NAME);
            purgeGermplasm(FINISHED, "BX", "CSA/ASDA", "BX", CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("AZ", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "BX", "CSA/ASDA", "BX", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");

            Germplasm dupGp = appdaoTestHelper
                    .createGermplasm(FINISHED, lineCode, origin, lineCode, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(dupGp, "SRC1", "F6", "@.1.2.|3.|5.");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, "SRC1;SRC2;SRC3;SRC4;SRC5;SRC6;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 4, 8, 8, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "AZ", "ABC/XYZ", "AZ", CROP_NAME);
            purgeGermplasm(FINISHED, "BX", "CSA/ASDA", "BX", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimpleWithParentage() throws Exception {
        String generation = "F7";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.|5.";
        String origin = "A/B";
        String source = origin + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            purgeGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("A", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "B", "CSA/ASDA", "B", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");

            Germplasm dupGp = appdaoTestHelper
                    .createGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, germplasmOwner, CROP_NAME);
            GeneticMaterial dupGm = appdaoTestHelper
                    .createGeneticMaterial(dupGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F4", "@.1.2.|");
            appdaoTestHelper.createParentage(dupGm, null, "F");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 2, 1, 3, 3);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            purgeGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimpleWithSomeUserSpecifiedSources() throws
            Exception {
        String generation = "F7";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.|5.";
        String origin = "A/B";
        String source = origin + lineage.replace('|', ' ') + generation;
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;

        try {
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            purgeGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, CROP_NAME);

            Germplasm recGp = appdaoTestHelper.createInbred("A", "LT", CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "SXX");

            Germplasm f1SegFemaleGp = appdaoTestHelper.createGermplasm(FINISHED, "B", "CSA/ASDA", "B", "LT", CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "SXY", "INBRED", "|");

            Germplasm dupGp = appdaoTestHelper
                    .createGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(dupGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F4", "@.1.2.|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;S10;S11;S11F&S11M", "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);
            midasContext.save(session);
            session.flush();

            assertMidasContext(midasContext, 5, 5, 8, mainRecord.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, "A", "ABC/XYZ", "A", CROP_NAME);
            purgeGermplasm(FINISHED, "B", "CSA/ASDA", "B", CROP_NAME);
            purgeGermplasm(CODED, lineCode, "A/B", germplasmOwner + "_" + lineCode, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithEvents() throws Exception {
        String generation = "INBRED";
        String germplasmOwner = "17";
        String lineage = "|";
        String femaleOrigin = "F8675/309";
        String maleOrigin = "M8675/309";
        String femaleLineCode = "F8675309";
        String maleLineCode = "M8675309";
        String siOrigin = femaleLineCode + "/" + maleLineCode;
        String siLineCode = "LC-" + femaleLineCode + maleLineCode;
        String eventName = "EVENT-FinishedIIProcessor_UT".toUpperCase();
        String eventConstructName = "CONST-FinishedIIProcessor_UT".toUpperCase();
        String sourceStr = "SRC " + eventName;
        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        EventConstruct expectedEventConstruct = null;
        try {
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(FINISHED, femaleLineCode, femaleOrigin, femaleLineCode, CROP_NAME);
            purgeGermplasm(FINISHED, maleLineCode, maleOrigin, maleLineCode, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm femaleGP = appdaoTestHelper.createInbred(femaleLineCode, germplasmOwner, CROP_NAME, femaleOrigin);
            appdaoTestHelper.createInbred(maleLineCode, germplasmOwner, CROP_NAME, maleOrigin);

            EventConstruct eventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            expectedEventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "T");

            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), eventConstruct.getEventConstructId());
            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), expectedEventConstruct.getEventConstructId());
            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
            StagingInventory importedRecord = createStagingInventory(header, FINISHED, siOrigin, sourceStr, null, null, null,
                    null, germplasmOwner, germplasmOwner, FINISHED, userId, generation, lineage, siLineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, null, "N", eventName);

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory mainRecord = getStagingInventoryWithParentage(importedRecord);

            IIProcessor processor = new FinishedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(mainRecord);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 1, 1, 1, mainRecord.getStagingParentage().size());

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(1, germplasms[0].getGermplasmEventConstruct().size());
            Iterator germplasmEventConstructIter = germplasms[0].getGermplasmEventConstruct().iterator();
            GermplasmEventConstruct actualGermplasmEventConstruct = (GermplasmEventConstruct) germplasmEventConstructIter.next();
            assertEquals(actualGermplasmEventConstruct.getEventConstruct().getEventConstructId(), expectedEventConstruct.getEventConstructId());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(FINISHED, femaleLineCode, femaleOrigin, femaleLineCode, CROP_NAME);
            purgeGermplasm(FINISHED, maleLineCode, maleOrigin, maleLineCode, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }
}