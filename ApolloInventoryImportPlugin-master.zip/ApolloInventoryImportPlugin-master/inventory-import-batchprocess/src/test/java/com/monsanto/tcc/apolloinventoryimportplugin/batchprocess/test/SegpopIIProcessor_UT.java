/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmEventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.vegetativestructure.VegetativeStructure;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.SegpopIIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Filename:    $RCSfile: SegpopIIProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy
 * $    	 On:	$Date: 2009-06-05 14:08:03 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class SegpopIIProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private static final String LINE_TYPE = MaterialTypeConstants.FINISHED_LINES;
    private static final String MAIN_LINE_TYPE = MaterialTypeConstants.SEGPOP_LINES;
    private static final String RECUR_GP_LINE_CODE = "A2112";
    private static final String RECUR_GP_OWNER = "LT";
    private static final String RECUR_GP_ORIGIN = "ABC/XYZ";
    private static final String RECUR_GP_PEDIGREE_NAME = "A2112";
    private static final String RECUR_GP_B_LINE_CODE = "B8675309";
    private static final String RECUR_GP_B_OWNER = "LT";
    private static final String RECUR_GP_B_ORIGIN = "ABC/XYZ";
    private static final String MAIN_LINE_CODE = null;
    private static final String MAIN_GP_ORIGIN = RECUR_GP_LINE_CODE + "/" + RECUR_GP_B_LINE_CODE;
    private static final String MAIN_GP_OWNER = "LT";
    private String templateName;
    private Random random = new Random();

    public SegpopIIProcessor_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventoryIntoMidasWithoutSubRecordsForBackCross() throws Exception {
        SegpopIIProcessor processor = new SegpopIIProcessor();
        String generation = "BC2";
        String germplasmOwner = "LT";
        String lineage = "@>0002>";
        String origin = RECUR_GP_LINE_CODE + "*3/" + RECUR_GP_B_LINE_CODE;
        String source = "origin " + lineage + " " + generation;

        Germplasm recGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);

            recGp = appdaoTestHelper.createGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME,
                    germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(recGp, "Some Source", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
                    origin, source, null, null, null, null, germplasmOwner, germplasmOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    "s1;s2;s3;s4;s4f&s4m;s5;s6".toUpperCase(), "N");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 1, 1, 1, 0);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForBackCross() throws Exception {
        String generation = "BC4";
        String origin = RECUR_GP_LINE_CODE + "*5/" + RECUR_GP_B_LINE_CODE;
        String lineage = "@>002>003>004>";
        String germplasmOwner = "LT";
        String source = "origin " + lineage + " " + generation;
        String f1SegFemaleGpLineType = MaterialTypeConstants.CODED_LINES;
        String f1SegFemaleGpOrigin = "8675/309";
        String f1SegFemaleGpLineCode = RECUR_GP_B_LINE_CODE;
        String f1SegFemaleGpOwner = "LT";
        String f1SegFemaleGpPedigreeName = f1SegFemaleGpOwner + "_" + f1SegFemaleGpLineCode;

        Germplasm recGp = null;
        Germplasm f1SegFemaleGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(f1SegFemaleGpLineType, f1SegFemaleGpLineCode, f1SegFemaleGpOrigin, f1SegFemaleGpPedigreeName,
                    CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "S4F");

            f1SegFemaleGp = appdaoTestHelper.createGermplasm(f1SegFemaleGpLineType, f1SegFemaleGpLineCode,
                    f1SegFemaleGpOrigin, f1SegFemaleGpPedigreeName, f1SegFemaleGpOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "S4M", "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
                    origin, source, null, null, null, null, germplasmOwner, germplasmOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    "s1;s2;s3;s4;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            int expectedGermlasmCount = 5;
            int expectedInventoryCount = 5;
            int expectedGeneticMaterialCount = 6;  // 5 + 1 recurring genMat
            int expectedParentageCount = stagingInventoryRec.getStagingParentage().size();

            assertMidasContext(midasContext, expectedGermlasmCount, expectedInventoryCount, expectedGeneticMaterialCount,
                    expectedParentageCount);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(f1SegFemaleGpLineType, f1SegFemaleGpLineCode, f1SegFemaleGpOrigin, f1SegFemaleGpPedigreeName,
                    CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForBackCrossWithExistingRecurrentParent() throws Exception {
        String generation = "BC4";
        String origin = RECUR_GP_LINE_CODE + "*5/" + RECUR_GP_B_LINE_CODE;
        String lineage = "@>002>003>004>";
        String germplasmOwner = "LT";
        String source = "origin " + lineage + " " + generation;
        String f1SegFemaleGpLineType = MaterialTypeConstants.CODED_LINES;
        String f1SegFemaleGpLineCode = RECUR_GP_B_LINE_CODE;
        String f1SegFemaleGpOwner = "LT";
        String f1SegFemaleGpOrigin = "CSA/ASDA";
        String f1SegFemaleGpPedigreeName = f1SegFemaleGpOwner + "_" + RECUR_GP_B_LINE_CODE;

        Germplasm recGp = null;
        Germplasm f1SegFemaleGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(f1SegFemaleGpLineType, f1SegFemaleGpLineCode, f1SegFemaleGpOrigin, f1SegFemaleGpPedigreeName,
                    CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");
            appdaoTestHelper.createInbredGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "S4F");

            f1SegFemaleGp = appdaoTestHelper.createGermplasm(f1SegFemaleGpLineType, f1SegFemaleGpLineCode,
                    f1SegFemaleGpOrigin, f1SegFemaleGpPedigreeName, f1SegFemaleGpOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1SegFemaleGp, "S4M", "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
                    origin, source, null, null, null, null, germplasmOwner, germplasmOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            int expectedGermlasmCount = 5;
            int expectedInventoryCount = 1;
            int expectedGeneticMaterialCount = 5;  // 5 - reuse recurrent parent
            int expectedParentageCount = stagingInventoryRec.getStagingParentage().size();

            assertMidasContext(midasContext, expectedGermlasmCount, expectedInventoryCount, expectedGeneticMaterialCount,
                    expectedParentageCount);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(f1SegFemaleGpLineType, f1SegFemaleGpLineCode, f1SegFemaleGpOrigin, f1SegFemaleGpPedigreeName,
                    CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimple() throws Exception {
        String origin = RECUR_GP_LINE_CODE + "/" + RECUR_GP_B_LINE_CODE;
        String lineage = "@.1.2.";
        String generation = "F4";
        String germplasmOwner = "LT";
        String source = "origin " + lineage + " " + generation;

        Germplasm recGp = null;
        Germplasm recGpB = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    origin, source, null, null, null, null, germplasmOwner, germplasmOwner, MaterialTypeConstants.CODED_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 4, 3, 6, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimpleWithExactDuplicateOnDiffProgramWithoutParentage() throws
            Exception {
        String origin = RECUR_GP_LINE_CODE + "/" + RECUR_GP_B_LINE_CODE;
        String lineage = "@.1.2.";
        String generation = "F4";
        String germplasmOwner = "LT";
        String source = "origin " + lineage + " " + generation;
        String inventoryPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;
        String mainGpOwner = "17";
        String mainGpPedigreeName = mainGpOwner + "_" + MAIN_GP_ORIGIN + ":" + lineage;


        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    mainGpOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, generation, lineage);

            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    origin, source, null, null, null, null, germplasmOwner, germplasmOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(inventoryPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 4, 3, 6, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimpleWithExactDuplicateWithoutParentage() throws
            Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;

        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);

            appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, generation, lineage);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 3, 5, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimpleWithExistingParentageOnMain() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;

        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, generation, lineage);
            appdaoTestHelper.createParentage(mainGm, null, "F");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }
        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 0, 1, 0, 0);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimpleWithExistingInventory() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String germplasmOwner = "LT";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;

        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, generation, lineage);
            appdaoTestHelper.createInventory(mainGm, "F", germplasmOwner);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }
        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);
            midasContext.save(session);
            session.flush();

            assertMidasContext(midasContext, 3, 2, 5, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimpleWithExistingArchivedInventory() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;

        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, generation, lineage);
            appdaoTestHelper.createInventory(mainGm, "T", MAIN_GP_OWNER);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }
        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 3, 5, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimple() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN;

        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 3, 5, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimpleWithExistingParentage() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":@.";

        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            GeneticMaterial dupGm = appdaoTestHelper
                    .createGeneticMaterial(mainGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F2", "@.");
            appdaoTestHelper.createParentage(dupGm, null, "F");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 2, 1, 2, 2);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimpleWithUserSpecifiedSources() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":@.1.";

        Germplasm recGp = null;
        Germplasm recGpB = null;
        Germplasm mainGp = null;
        try {
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGp, "Some Source");

            recGpB = appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);
            appdaoTestHelper.createInbredGeneticMaterial(recGpB, "Some Source");

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, "S1", "F3", "@.1.");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    "s1;s2;s3;s4f&s4m;s5;s6".toUpperCase(), "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 5, 5, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithEvents() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN;
        String eventName = "EVENT-SegpopIIProcessor_UT".toUpperCase();
        String eventConstructName = "CONST-SegpopIIProcessor_UT".toUpperCase();
        String sourceStr = "SRC " + eventName;
        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm femaleGP = null;
        EventConstruct expectedEventConstruct = null;
        try {
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            femaleGP = appdaoTestHelper.createInbred(RECUR_GP_LINE_CODE, RECUR_GP_OWNER, CROP_NAME, RECUR_GP_ORIGIN);
            appdaoTestHelper.createInbred(RECUR_GP_B_LINE_CODE, RECUR_GP_B_OWNER, CROP_NAME, RECUR_GP_B_ORIGIN);

            EventConstruct eventConstruct = appdaoTestHelper
                    .createEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            expectedEventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "T");

            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), eventConstruct.getEventConstructId());
            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), expectedEventConstruct.getEventConstructId());
            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.SEGPOP_LINES,
                    MAIN_GP_ORIGIN, sourceStr, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    null, "N", eventName);

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 1, 1, 1, stagingInventoryRec.getStagingParentage().size());

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(1, germplasms[0].getGermplasmEventConstruct().size());
            Iterator germplasmEventConstructIter = germplasms[0].getGermplasmEventConstruct().iterator();
            GermplasmEventConstruct actualGermplasmEventConstruct = (GermplasmEventConstruct) germplasmEventConstructIter
                    .next();
            assertEquals(actualGermplasmEventConstruct.getEventConstruct().getEventConstructId(),
                    expectedEventConstruct.getEventConstructId());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(LINE_TYPE, RECUR_GP_LINE_CODE, RECUR_GP_ORIGIN, RECUR_GP_PEDIGREE_NAME, CROP_NAME);
            purgeGermplasm(LINE_TYPE, RECUR_GP_B_LINE_CODE, RECUR_GP_B_ORIGIN, RECUR_GP_B_LINE_CODE, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }


    public void testProcessInventoryIntoMidasWithVegetativeStructureAsBulbAndGermplasmPresent() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;

        Germplasm mainGp = null;
        try {
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);

            appdaoTestHelper.createGeneticMaterial(mainGp, "Junk", generation, lineage);

            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }
        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "N", null, "Bulb");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);
            midasContext.save(session);
            Criteria criteria = createCriteria(stagingInventoryRec.getVegetativeStructure(), session);
            List<VegetativeStructure> vegetativeStructures = criteria.list();
            VegetativeStructure structure = vegetativeStructures.get(0);
            session.flush();

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(1, germplasms.length);
            Germplasm germplasm = germplasms[0];
            assertEquals(mainGp.getId(), germplasm.getId());

            assertEquals(structure.getVegetativeStructureId(), midasContext.getInventory()[0].getVegetativeStructure().getVegetativeStructureId());
            assertMidasContext(midasContext, 1, 1, 1, 0);

        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    private Criteria createCriteria(String vegetativeStructureValue, Session session) {
        Criteria c = session.createCriteria(VegetativeStructure.class);
        c.add(Expression.eq("name", vegetativeStructureValue).ignoreCase());
        c.add(Expression.eq("refActive", "T"));
        return c;
    }

    public void testProcessInventoryIntoMidasWithVegetativeStructureAsSeedAndGermplasmPresent() throws Exception {
        String lineage = "@.1.2.";
        String generation = "F4";
        String source = "origin " + lineage + " " + generation;
        String mainGpPedigreeName = MAIN_GP_OWNER + "_" + MAIN_GP_ORIGIN + ":" + lineage;

        Germplasm mainGp = null;
        try {
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);

            mainGp = appdaoTestHelper.createGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName,
                    MAIN_GP_OWNER, CROP_NAME);

            appdaoTestHelper.createGeneticMaterial(mainGp, "Junk", generation, lineage);

            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }
        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    MAIN_GP_ORIGIN, source, null, null, null, null, MAIN_GP_OWNER, MAIN_GP_OWNER,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
                    ";;;s4f&s4m;s5;s6".toUpperCase(), "N", null, "Seed");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);
            stagingInventoryRec.setPedigreeName(mainGpPedigreeName);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);
            midasContext.save(session);
            session.flush();

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(1, germplasms.length);
            Germplasm germplasm = germplasms[0];
            assertTrue(mainGp.getId().equals(germplasm.getId()));

            assertMidasContext(midasContext, 1, 1, 1, 0);

        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(MAIN_LINE_TYPE, MAIN_LINE_CODE, MAIN_GP_ORIGIN, mainGpPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }


}