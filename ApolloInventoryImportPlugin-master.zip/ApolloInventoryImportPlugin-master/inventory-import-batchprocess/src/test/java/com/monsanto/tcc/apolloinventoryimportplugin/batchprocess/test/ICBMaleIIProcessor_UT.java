/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.CompICBMale;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.Random;

/**
 * Filename:    $RCSfile: ICBMaleIIProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $    	 On:	$Date: 2009-06-05 14:08:03 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class ICBMaleIIProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private String templateName;
    private Random random = new Random();

    public ICBMaleIIProcessor_UT(String string) {
        super(string);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventory_ActivateExistingCompICBMale() throws InventoryImportProcessorException {
        String lineType = MaterialTypeConstants.SEGPOP_LINES;
        String origin = "AXD/XCA";
        String germplasmOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String lineCode = null;
        String pedigreeName;
        pedigreeName = buildPedigreeName(lineType, germplasmOwner, origin, lineage, lineCode);
        String source = "SOME SOURCE " + pedigreeName;
        boolean compIcbMaleRefActive = false;

        CompICBMale compICBMale = createCompICBMale(lineType, lineCode, origin, pedigreeName, germplasmOwner, CROP_NAME,
                source, generation, lineage,
                compIcbMaleRefActive);
        assertEquals("F", compICBMale.getRefActive());

        StagingInventory stagingInventory = appdaoTestHelper
                .createICBMaleStagingInventory(CROP_NAME, userId, source, pedigreeName, templateName, true);

        IIProcessor processor = new ICBMaleIIProcessor();
        InventoryContext inventoryContext = new InventoryContext(stagingInventory,
                new MockBatchRunHistoryHelper(stagingInventory));

        MidasContext midasContext = processor.processInventory(inventoryContext);

        assertEquals(1, midasContext.getCompICBMale().length);
        assertEquals("T", midasContext.getCompICBMale()[0].getRefActive());
    }

    public void testProcessInventory_AddCompICBMale() throws InventoryImportProcessorException {
        String lineType = MaterialTypeConstants.SEGPOP_LINES;
        String origin = "AXD/XCA";
        String germplasmOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String lineCode = null;
        String pedigreeName;
        pedigreeName = buildPedigreeName(lineType, germplasmOwner, origin, lineage, lineCode);
        String source = "SOME SOURCE " + pedigreeName;

        Germplasm gp = appdaoTestHelper
                .createGermplasm(lineType, lineCode, origin, pedigreeName, germplasmOwner, CROP_NAME);
        appdaoTestHelper.createGeneticMaterial(gp, source, generation, lineage);

        StagingInventory stagingInventory = appdaoTestHelper
                .createICBMaleStagingInventory(CROP_NAME, userId, source, pedigreeName, templateName, true);

        IIProcessor processor = new ICBMaleIIProcessor();
        InventoryContext inventoryContext = new InventoryContext(stagingInventory,
                new MockBatchRunHistoryHelper(stagingInventory));

        MidasContext midasContext = processor.processInventory(inventoryContext);

        assertEquals(1, midasContext.getCompICBMale().length);
        assertEquals("T", midasContext.getCompICBMale()[0].getRefActive());
    }

    public void testProcessInventory_InactivateExistingCompICBMale() throws InventoryImportProcessorException {
        String lineType = MaterialTypeConstants.SEGPOP_LINES;
        String origin = "AXD/XCA";
        String germplasmOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String lineCode = null;
        String pedigreeName;
        pedigreeName = buildPedigreeName(lineType, germplasmOwner, origin, lineage, lineCode);
        String source = "SOME SOURCE " + pedigreeName;
        boolean compIcbMaleRefActive = true;

        CompICBMale compICBMale = createCompICBMale(lineType, lineCode, origin, pedigreeName, germplasmOwner, CROP_NAME,
                source, generation, lineage,
                compIcbMaleRefActive);
        assertEquals("T", compICBMale.getRefActive());

        StagingInventory stagingInventory = appdaoTestHelper
                .createICBMaleStagingInventory(CROP_NAME, userId, source, pedigreeName, templateName, false);

        IIProcessor processor = new ICBMaleIIProcessor();
        InventoryContext inventoryContext = new InventoryContext(stagingInventory,
                new MockBatchRunHistoryHelper(stagingInventory));

        MidasContext midasContext = processor.processInventory(inventoryContext);

        assertEquals(1, midasContext.getCompICBMale().length);
        assertEquals("F", midasContext.getCompICBMale()[0].getRefActive());
    }

    private CompICBMale createCompICBMale(String lineType, String lineCode, String origin, String pedigreeName,
                                          String germplasmOwner, String cropName, String source, String generation,
                                          String lineage, boolean compIcbMaleRefActive) {
        Germplasm gp = appdaoTestHelper.createGermplasm(lineType, lineCode, origin, pedigreeName, germplasmOwner, cropName);
        GeneticMaterial gm = appdaoTestHelper.createGeneticMaterial(gp, source, generation, lineage);
        return appdaoTestHelper.createCompIcbMale(gm, compIcbMaleRefActive);
    }

    private String buildPedigreeName(String lineType, String germplasmOwner, String origin, String lineage,
                                     String lineCode) {
        String pedigreeName;
        if (MaterialTypeConstants.SEGPOP_LINES.equals(lineType)) {
            pedigreeName = germplasmOwner + "_" + origin;
            if (!StringUtils.isNullOrEmpty(lineage)) {
                pedigreeName += lineage;
            }
        } else if (MaterialTypeConstants.CODED_LINES.equals(lineType)) {
            pedigreeName = germplasmOwner + "_" + lineCode;
            if (!StringUtils.isNullOrEmpty(lineage)) {
                pedigreeName += lineage.substring(lineage.indexOf('|') + 1);
            }
        } else { // Finished
            pedigreeName = lineCode;
        }
        return pedigreeName;
    }
}