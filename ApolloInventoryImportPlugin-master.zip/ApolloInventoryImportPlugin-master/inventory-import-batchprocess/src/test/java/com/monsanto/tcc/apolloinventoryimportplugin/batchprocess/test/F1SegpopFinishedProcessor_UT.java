/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

import java.util.Random;

/**
 * Filename:    $RCSfile: F1SegpopFinishedProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:08:03 $
 *
 * @author apatro
 * @version $Revision: 1.19 $
 */
public class F1SegpopFinishedProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private static final String SEGPOP = MaterialTypeConstants.SEGPOP_LINES;
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String HYBRID = MaterialTypeConstants.HYBRID_LINES;
    private static final String PRE_COM_COMPANY_NAME = "MONSANTO";
    private static final String PRE_COM_BRAND_NAME = "MONSANTO";
    private static final String COM_BRAND_NAME = "MONSANTO";
    private String templateName;
    private static final String USA = "United States of America";
    private Random random = new Random();

    public F1SegpopFinishedProcessor_UT(String string) {
        super(string);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testInventoryContextRequired() throws Exception {
        IIProcessor processor = new F1SegpopFinishedProcessor(new MidasContext(),
                new StagingParentageHelper(null));
        InventoryContext inventoryContext = null;
        try {
            processor.processInventory(inventoryContext);
            fail("Expecting IllegalStateException");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().indexOf(F1SegpopUnfinishedProcessor.INVENTORY_CANNOT_BE_NULL_MSG) >= 0);
        }
    }

    public void testMainRecordExistsWithParentage() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = null;
        String femaleSource = null;

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            }

            Germplasm segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", owner, CROP_NAME);
            GeneticMaterial parent1Gm = appdaoTestHelper
                    .createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            segpopGp = appdaoTestHelper
                    .createGermplasm("Segpop", null, "CCC/DDD", owner + "_CCC/DDD", owner, CROP_NAME);
            GeneticMaterial parent2Gm = appdaoTestHelper
                    .createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            appdaoTestHelper.createParentage(mainGm, parent1Gm, "F");
            appdaoTestHelper.createParentage(mainGm, parent2Gm, "M");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 0, 0, 0, 0);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithArchivedInventory() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = null;
        String femaleSource = null;

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);
            appdaoTestHelper.createInventory(mainGm, "T", owner);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            }
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            IIProcessor processor = new F1SegpopFinishedProcessor();
            MidasContext midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 0, 1, 0, 0);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithParentageUsingDefaultConstructor() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = null;
        String femaleSource = null;

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            }

            Germplasm segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", owner, CROP_NAME);
            GeneticMaterial parent1Gm = appdaoTestHelper
                    .createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            segpopGp = appdaoTestHelper
                    .createGermplasm("Segpop", null, "CCC/DDD", owner + "_CCC/DDD", owner, CROP_NAME);
            GeneticMaterial parent2Gm = appdaoTestHelper
                    .createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            appdaoTestHelper.createParentage(mainGm, parent1Gm, "F");
            appdaoTestHelper.createParentage(mainGm, parent2Gm, "M");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            IIProcessor processor = new F1SegpopFinishedProcessor();
            MidasContext midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 0, 0, 0, 0);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);

            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithoutParentageAndAllParentsPreExist() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = null;
        String femaleSource = null;

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "C/D", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            }

            Germplasm segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 0, 0, 0, 6);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithoutParentageAndWithGenericSourcesForTopLevelParents() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = null;
        String femaleSource = null;

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, "Inbred Source " + i);
            }
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 2, 0, 6, 6);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithoutParentageAndTopLevelParentsExist() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = f1SegpopOrigin + " MSRC";
        String femaleSource = f1SegpopOrigin + " FSRC";

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, "Inbred Source " + i);
            }

            Germplasm segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);

            segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(segpopGp, maleSource, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 0, 0, 4, 6);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "AAA/BBB", owner + "_AAA/BBB", CROP_NAME);
            purgeGermplasm(SEGPOP, null, "CCC/DDD", owner + "_CCC/DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithoutParentageAndAllInbredParentsExist() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = f1SegpopOrigin + " MSRC";
        String femaleSource = f1SegpopOrigin + " FSRC";

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/B", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CDD", "CDD/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            }
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 2, 2, 2, 6);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testThrowsExceptionWhenBothParentDoNotExistForASegpop() throws Exception {
        String owner = "17";
        String femaleParentOrigin = "AAA/BBB";
        String maleParentOrigin = "CCC/DDD";
        String f1SegpopOrigin = femaleParentOrigin + "//" + maleParentOrigin;
        String source = f1SegpopOrigin + " SRC1";
        String femaleParentPedigree = owner + "_" + femaleParentOrigin;
        String maleParentPedigree = owner + "_" + maleParentOrigin;
        String maleSource = f1SegpopOrigin + " MSRC";
        String femaleSource = f1SegpopOrigin + " FSRC";

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(SEGPOP, null, femaleParentOrigin, owner + "_" + femaleParentOrigin, CROP_NAME);
            purgeGermplasm(SEGPOP, null, maleParentOrigin, owner + "_" + maleParentOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, femaleParentOrigin, femaleParentPedigree, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);

            segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, maleParentOrigin, maleParentPedigree, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(segpopGp, maleSource, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);

            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            try {
                processor.processInventory(inventoryContext);
                fail("Expecting InventoryImportProcessorException");
            } catch (InventoryImportProcessorException e) {
                assertTrue(e.getMessage().indexOf(F1SegpopFinishedProcessor.TWO_PARENTS_MUST_EXIST_MSG) >= 0);
            }
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(SEGPOP, null, femaleParentOrigin, owner + "_" + femaleParentOrigin, CROP_NAME);
            purgeGermplasm(SEGPOP, null, maleParentOrigin, owner + "_" + maleParentOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithPreComercialCompetitorLineCodeFinishedThreeWay() throws Exception {
        String lineTypeOfGpOfProduct = MaterialTypeConstants.FINISHED_LINES;
        String femalePreComOrigin = "II-FEMALE-PRE-COM-ORIGIN";
        String maleCompOrigin = "II-MALE-COMP-ORIGIN";
        String maleLineCode = "II-MALE-LINE-CODE";
        String maleLineCode2 = "II-MALE-LINE-CODE-2";

        String precomProductName = femalePreComOrigin;
        String compProductName = maleCompOrigin;
        String precomBrandName = PRE_COM_BRAND_NAME;
        String precomCompanyName = PRE_COM_COMPANY_NAME;
        String compBrandName = COM_BRAND_NAME;
        String compCompanyName = "II-NOT-MONSANTO";

        String lineTypeOfInbred = MaterialTypeConstants.FINISHED_LINES;
        String importedOrigin = femalePreComOrigin + "/" + maleCompOrigin + "//" + maleLineCode + "/3/" + maleLineCode2;
        String importedSource = "II SOURCE";
        String gpOwner = "17";
        String lineage = null;
        String generation = "F1";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm precomProductGp = null;
        Germplasm compProductGp = null;
        Germplasm maleLCGp = null;
        Germplasm maleLCGp2 = null;
        try {
            purgeProduct(CROP_NAME, precomProductName, precomBrandName, precomCompanyName);
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, femalePreComOrigin, femalePreComOrigin, femalePreComOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleCompOrigin, maleCompOrigin, maleCompOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode, maleLineCode, maleLineCode, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode2, maleLineCode2, maleLineCode2, CROP_NAME);

            precomProductGp = appdaoTestHelper.createInbred(femalePreComOrigin, gpOwner, CROP_NAME, femalePreComOrigin);
            appdaoTestHelper
                    .createInbredGeneticMaterial(precomProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            compProductGp = appdaoTestHelper.createInbred(maleCompOrigin, gpOwner, CROP_NAME, maleCompOrigin);
            appdaoTestHelper.createInbredGeneticMaterial(compProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleLCGp = appdaoTestHelper.createInbred(maleLineCode, gpOwner, CROP_NAME, maleLineCode);
            appdaoTestHelper.createInbredGeneticMaterial(maleLCGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleLCGp2 = appdaoTestHelper.createInbred(maleLineCode2, gpOwner, CROP_NAME, maleLineCode2);
            appdaoTestHelper.createInbredGeneticMaterial(maleLCGp2, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            Product precomProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper
                    .createProductName(precomProductName, "T", precomBrandName, precomCompanyName, USA, precomProduct);
            appdaoTestHelper.createProductGermplasm(precomProduct, precomProductGp);

            Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(compProductName, "T", compBrandName, compCompanyName, USA, compProduct);
            appdaoTestHelper.createProductGermplasm(compProduct, compProductGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    importedOrigin, importedSource, "fp1", null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
                    userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            F1SegpopFinishedProcessor processor = new F1SegpopFinishedProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 2, 3, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, precomProductName, precomBrandName, precomCompanyName);
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, femalePreComOrigin, femalePreComOrigin, femalePreComOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleCompOrigin, maleCompOrigin, maleCompOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode, maleLineCode, maleLineCode, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode2, maleLineCode2, maleLineCode2, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testMainRecordExistsWithoutParentageOneF1ParentWasChangedToHybridSoItMustHaveExisted() throws Exception {
        String[] inbreds = new String[]{"AAA", "BBB", "CCC", "DDD"};
        String[] inbredOrigins = new String[]{"AAA/BBB", "BBB/AAA", "CCC/DDD", "DDD/CCC"};
        String f1SegpopOrigin = inbreds[0] + "/" + inbreds[1] + "//" + inbreds[2] + "/" + inbreds[3];
        String source = f1SegpopOrigin + " SRC1";
        String owner = "17";
        String maleSource = null;
        String femaleSource = null;

        try {
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(HYBRID, null, "CCC+DDD", "CCC+DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm mainGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

            Germplasm hybridGp = appdaoTestHelper
                    .createGermplasm(HYBRID, null, "CCC+DDD", "CCC+DDD", owner, CROP_NAME, "F", "T");
            appdaoTestHelper.createGeneticMaterial(hybridGp, "Inventory_Import_Parent", "F1", null);

            Germplasm[] inbredGps = appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            for (int i = 0; i < inbredGps.length; i++) {
                Germplasm inbredGp = inbredGps[i];
                appdaoTestHelper.createInbredGeneticMaterial(inbredGp, "Inbred Source " + i);
            }
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner,
                    MaterialTypeConstants.SEGPOP_LINES,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = new MidasContext();
            IIProcessor processor = new F1SegpopFinishedProcessor(midasContext,
                    new StagingParentageHelper(stagingInventory.getStagingParentage()));
            midasContext = processor.processInventory(inventoryContext);

            assertMidasContext(midasContext, 1, 0, 5, 6);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, "AAA", "AAA/BBB", "AAA", CROP_NAME);
            purgeGermplasm(FINISHED, "BBB", "BBB/AAA", "BBB", CROP_NAME);
            purgeGermplasm(FINISHED, "CCC", "CCC/DDD", "CCC", CROP_NAME);
            purgeGermplasm(FINISHED, "DDD", "DDD/CCC", "DDD", CROP_NAME);
            purgeGermplasm(HYBRID, null, "CCC+DDD", "CCC+DDD", CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

}