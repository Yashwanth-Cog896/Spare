/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.BatchRunHistoryHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.InventoryContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: MockInventoryContext.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $    	 On:	$Date: 2007-05-22 20:08:50 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class MockInventoryContext extends InventoryContext {
  public MockInventoryContext(StagingInventory stagingInventory, BatchRunHistoryHelper batchRunHistoryHelper) {
    super(stagingInventory, batchRunHistoryHelper);
  }

  public MockInventoryContext(StagingInventory stagingInventory) {
    this(stagingInventory, new MockBatchRunHistoryHelper(stagingInventory));
  }
}