/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;

import java.util.Random;

/**
 * Filename:    $RCSfile: F1SegpopUnfinishedProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: AAGOSW $
 * On:	$Date: 2008-07-22 18:02:09 $
 *
 * @author apatro
 * @version $Revision: 1.27 $
 */
@SuppressWarnings({"OverlyLongMethod"})
public class F1SegpopUnfinishedProcessor_UT extends ProcessorTestCase {
  private static final String CROP_NAME = "Corn";
  private static final String SEGPOP = MaterialTypeConstants.SEGPOP_LINES;
  private static final String CODED = MaterialTypeConstants.CODED_LINES;
  private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
  private static final String HYBRID = MaterialTypeConstants.HYBRID_LINES;
  private String templateName;
  private static final String USA = "United States of America";
  private Random random = new Random();

  public F1SegpopUnfinishedProcessor_UT(String string) {
    super(string);
  }

  protected void setUp() throws Exception {
    super.setUp();
    templateName = this.getClass().getName() + random.nextInt();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testInventoryContextRequired() throws Exception {
    F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(new MidasContext(),
        new StagingParentageHelper(null));
    InventoryContext inventoryContext = null;
    try {
      processor.processInventory(inventoryContext);
      fail("Expecting IllegalStateException");
    } catch (IllegalStateException e) {
      assertTrue(e.getMessage().indexOf(F1SegpopUnfinishedProcessor.INVENTORY_CANNOT_BE_NULL_MSG) >= 0);
    }
  }

  public void testMainRecordExistsWithArchivedInventory() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm mainGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
      GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);
      appdaoTestHelper.createInventory(mainGm, "T", owner);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor();
      MidasContext midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 0, 1, 0, 0);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testMainRecordExistsWithoutParentage() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm mainGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 0, 0, 0, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testMainRecordExistsWithParentage() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String templateName = "Unfinished_Segpop_" + f1SegpopOrigin + ".xls";
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm mainGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, owner, CROP_NAME);
      GeneticMaterial mainGm = appdaoTestHelper.createGeneticMaterial(mainGp, source, "F1", null);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      GeneticMaterial maleGm = appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      GeneticMaterial femaleGm = appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);

      appdaoTestHelper.createParentage(mainGm, maleGm, "M");
      appdaoTestHelper.createParentage(mainGm, femaleGm, "F");
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 0, 0, 0, 0);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(SEGPOP, null, f1SegpopOrigin, owner + "_" + f1SegpopOrigin, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testMainRecordWithGenericSource() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String templateName = "Unfinished_Segpop_" + f1SegpopOrigin + ".xls";
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);
      appdaoTestHelper.createGeneticMaterial(codedGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      appdaoTestHelper.createGeneticMaterial(segpopGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, null, null, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      stagingInventory.setUserSpecifiedSource("F");
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 0, 1, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithParentsMissingInMidas() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      try {
        processor.processInventory(inventoryContext);
        fail("Expecint InventoryImportProcessorException");
      } catch (InventoryImportProcessorException e) {
        assertTrue(e.getMessage().indexOf(F1SegpopUnfinishedProcessor.PARENT_NOT_FOUND_IN_MIDAS) >= 0);
      }
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithMissingParentsOnF1SegpopRecord() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "N");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      try {
        processor.processInventory(inventoryContext);
        fail("Expecint InventoryImportProcessorException");
      } catch (InventoryImportProcessorException e) {
        e.printStackTrace();
        assertTrue(e.getMessage().indexOf(F1SegpopUnfinishedProcessor.TWO_PARENTS_MUST_EXIST_MSG) >= 0);
      }
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }


  public void testSimpleWithOneParentAsCoded() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithOneParentAsCodedWithLineage() throws Exception {
    String codedLine = "ASC";
    String codedLineage = "@.1.|2.3.";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//(" + codedLine + ":2.3.)";
    String source = segpopLine + "-" + codedLine + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine + ":2.3.", CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper
          .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine + ":2.3.", owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F5", codedLineage);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine + ":2.3.", CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithOneParentAsCodedThatExistsAfterParentageIsCreated() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B";
    String f1SegpopOrigin = segpopLine + "//" + codedLine;
    String source = f1SegpopOrigin + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
      appdaoTestHelper.setMidasSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      try {
        Germplasm codedGp = appdaoTestHelper
            .createGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, owner, CROP_NAME);
        appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "F1", null);
        session.getTransaction().commit();
      } finally {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        appdaoTestHelper.setStagingSession(session);
      }

      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      purgeGermplasm(CODED, codedLine, "AXC/XYZ", owner + "_" + codedLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithOneParentAsSegpopWithLineage() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B:@.1.";
    String f1SegpopOrigin = "(" + segpopLine + ")/" + codedLine;
    String source = segpopLine + "-" + codedLine + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(FINISHED, codedLine, "AXC/XYZ", codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper.createGermplasm(FINISHED, codedLine, "AXC/XYZ", codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "INBRED", "|");

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(FINISHED, codedLine, "AXC/XYZ", codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithOneParentAsSegpopWithLineageUsingDefaultConstructor() throws Exception {
    String codedLine = "ASC";
    String segpopLine = "A/B:@.1.";
    String f1SegpopOrigin = "(" + segpopLine + ")/" + codedLine;
    String source = segpopLine + "-" + codedLine + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    try {
      purgeGermplasm(FINISHED, codedLine, "AXC/XYZ", codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm codedGp = appdaoTestHelper.createGermplasm(FINISHED, codedLine, "AXC/XYZ", codedLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(codedGp, maleSource, "INBRED", "|");

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor();
      MidasContext midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(FINISHED, codedLine, "AXC/XYZ", codedLine, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidasWithPreComercialProductName() throws Exception {
    String gpOwner = "17";
    String lineTypeOfTopLevelFemaleParent = MaterialTypeConstants.SEGPOP_LINES;
    String lineTypeOfTopLevelMaleParent = MaterialTypeConstants.FINISHED_LINES;
    String femaleOrigin = "II-FEMALE-ORIGIN";
    String maleOrigin = "II-MALE-ORIGIN";
    String maleLineCode = "II-MALE-LINE-CODE";
    String firstLineage = "@.1.";
    String topLevelMalePreComParentLineCode = "II-MALE-LINE-CODE-2";

    String precomBrandName = "MONSANTO";
    String precomCompanyName = "MONSANTO";

    String topLevelFemaleParentLineCode = null;
    String topLevelFemaleParentOrigin =
        "(" + femaleOrigin + "/" + maleOrigin + ":" + firstLineage + ")/" + maleLineCode;
    String topLevelFemaleParentPedigree = gpOwner + "_" + topLevelFemaleParentOrigin;
    String topLevelMaleParentPreComOrigin = topLevelMalePreComParentLineCode;
    String topLevelMalePreComParentPedigree = gpOwner + "_" + topLevelMalePreComParentLineCode;

    String importedOrigin = topLevelFemaleParentOrigin + "//" + topLevelMalePreComParentLineCode;
    String importedSource = "II SOURCE";
    String importedLineage = null;
    String importedGeneration = "F1";

    appdaoTestHelper = new TestHelper();
    appdaoTestHelper.beginTransaction();

    Germplasm topLevelFemaleGp = null;
    Germplasm topLevelMaleGp = null;
    try {
      purgeProduct(CROP_NAME, topLevelMalePreComParentLineCode, precomBrandName, precomCompanyName);
      purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
          topLevelFemaleParentPedigree, CROP_NAME);
      purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMalePreComParentLineCode, topLevelMaleParentPreComOrigin,
          topLevelMalePreComParentPedigree, CROP_NAME);

      topLevelFemaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode,
          topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, gpOwner, CROP_NAME, "F", "F");
      appdaoTestHelper
          .createGeneticMaterial(topLevelFemaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

      topLevelMaleGp = appdaoTestHelper.createInbred(topLevelMalePreComParentLineCode, gpOwner, CROP_NAME,
          topLevelMaleParentPreComOrigin);
      appdaoTestHelper.createInbredGeneticMaterial(topLevelMaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

      Product precomProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
      appdaoTestHelper.createProductName(topLevelMalePreComParentLineCode, "T", precomBrandName, precomCompanyName, USA,
          precomProduct);
      appdaoTestHelper.createProductGermplasm(precomProduct, topLevelMaleGp);

      appdaoTestHelper.endTransaction(true);
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      appdaoTestHelper = new TestHelper();
      appdaoTestHelper.beginTransaction();
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          MaterialTypeConstants.SEGPOP_LINES);
      StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          importedOrigin, importedSource, null, null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
          userId, importedGeneration, importedLineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
          null, "Y");

      importStagingInventory(header, mainRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
          userId);
      StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor();
      MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
      MidasContext midasContext = processor.processInventory(context);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      appdaoTestHelper.endTransaction(false);
      purgeProduct(CROP_NAME, topLevelMalePreComParentLineCode, precomBrandName, precomCompanyName);
      purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
          topLevelFemaleParentPedigree, CROP_NAME);
      purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMalePreComParentLineCode, topLevelMaleParentPreComOrigin,
          topLevelMalePreComParentPedigree, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidasWithCompetitorUnfinished() throws Exception {
    String gpOwner = "17";
    String lineTypeOfTopLevelFemaleParent = MaterialTypeConstants.SEGPOP_LINES;
    String lineTypeOfTopLevelMaleParent = MaterialTypeConstants.FINISHED_LINES;
    String femaleOrigin = "II-FEMALE-ORIGIN";
    String maleOrigin = "II-MALE-ORIGIN";
    String maleLineCode = "II-MALE-LINE-CODE";
    String firstLineage = "@.1.";
    String topLevelMaleParentLineCode = "II-MALE-LINE-CODE-2";

    String compBrandName = "MONSANTO";
    String compCompanyName = "II-NOT-MONSANTO";

    String topLevelFemaleParentLineCode = null;
    String topLevelFemaleParentOrigin =
        "(" + femaleOrigin + "/" + maleOrigin + ":" + firstLineage + ")/" + maleLineCode;
    String topLevelFemaleParentPedigree = gpOwner + "_" + topLevelFemaleParentOrigin;
    String topLevelMaleParentOrigin = topLevelMaleParentLineCode;
    String topLevelMaleParentPedigree = gpOwner + "_" + topLevelMaleParentLineCode;

    String importedOrigin = topLevelFemaleParentOrigin + "//" + topLevelMaleParentLineCode;
    String importedSource = "II SOURCE";
    String importedLineage = null;
    String importedGeneration = "F1";

    appdaoTestHelper = new TestHelper();
    appdaoTestHelper.beginTransaction();

    Germplasm topLevelFemaleGp = null;
    Germplasm topLevelMaleGp = null;
    try {
      purgeProduct(CROP_NAME, topLevelMaleParentLineCode, compBrandName, compCompanyName);
      purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
          topLevelFemaleParentPedigree, CROP_NAME);
      purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin,
          topLevelMaleParentPedigree, CROP_NAME);

      topLevelFemaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode,
          topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, gpOwner, CROP_NAME, "F", "F");
      appdaoTestHelper
          .createGeneticMaterial(topLevelFemaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

      topLevelMaleGp = appdaoTestHelper
          .createInbred(topLevelMaleParentLineCode, gpOwner, CROP_NAME, topLevelMaleParentOrigin);
      appdaoTestHelper.createInbredGeneticMaterial(topLevelMaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

      Product precomProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
      appdaoTestHelper
          .createProductName(topLevelMaleParentLineCode, "T", compBrandName, compCompanyName, USA, precomProduct);
      appdaoTestHelper.createProductGermplasm(precomProduct, topLevelMaleGp);

      appdaoTestHelper.endTransaction(true);
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      appdaoTestHelper = new TestHelper();
      appdaoTestHelper.beginTransaction();
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          MaterialTypeConstants.SEGPOP_LINES);
      StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          importedOrigin, importedSource, null, null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
          userId, importedGeneration, importedLineage, null, null, null, null, StagingInventoryStatusConstants.NEW,
          null, "Y");

      importStagingInventory(header, mainRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
          userId);
      StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor();
      MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
      MidasContext midasContext = processor.processInventory(context);

      assertMidasContext(midasContext, 1, 1, 1, 2);
    } finally {
      appdaoTestHelper.endTransaction(false);
      purgeProduct(CROP_NAME, topLevelMaleParentLineCode, compBrandName, compCompanyName);
      purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
          topLevelFemaleParentPedigree, CROP_NAME);
      purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin,
          topLevelMaleParentPedigree, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidasWithCompetitorHybridProductNameNotFound() throws Exception {
    String gpOwner = "17";
    String compBrandName = "MONSANTO";
    String compCompanyName = "II-NOT-MONSANTO";
    String lineTypeOfTopLevelFemaleParent = HYBRID;
    String lineTypeOfTopLevelMaleParent = SEGPOP;

    String topLevelFemaleParentOrigin = "II-TOP-LEVEL-FEMALE-ORIGIN";
    String topLevelFemaleParentPedigree = topLevelFemaleParentOrigin;
    String topLevelFemaleParentLineCode = null;

    String topLevelMaleParentLineage = "1.2.";
    String topLevelMaleParentOrigin = "II-TOP-LEVEL-MALE-PED/TOP-LEVEL-MALE-PED";
    String topLevelMaleParentPedigree = gpOwner + "_" + topLevelMaleParentOrigin + ":" + topLevelMaleParentLineage;
    String topLevelMaleParentLineCode = null;

    String importedOrigin =
        topLevelFemaleParentOrigin + "/(" + topLevelMaleParentOrigin + ":" + topLevelMaleParentLineage + ")";
    String importedLineCode = null;
    String importedGeneration = "F1";
    String importedLineage = null;

    String importedSource = "II SOURCE";

    appdaoTestHelper = new TestHelper();
    appdaoTestHelper.beginTransaction();

    Germplasm topLevelFemaleGp = null;
    Germplasm topLevelMaleGp = null;
    try {
      removeStagingInventoryTestData(templateName);
      purgeProduct(CROP_NAME, topLevelFemaleParentOrigin, compBrandName, compCompanyName);
      purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
          topLevelFemaleParentPedigree, CROP_NAME);
      purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin,
          topLevelMaleParentPedigree, CROP_NAME);

      topLevelFemaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode,
          topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, gpOwner, CROP_NAME, "F", "T");
      appdaoTestHelper
          .createGeneticMaterial(topLevelFemaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

      topLevelMaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentPedigree,
          topLevelMaleParentOrigin, topLevelMaleParentPedigree, gpOwner, CROP_NAME, "F", "F");
      appdaoTestHelper
          .createGeneticMaterial(topLevelMaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F3", "1.2.");

      Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
      appdaoTestHelper.createProductName(topLevelFemaleParentOrigin, "T", compBrandName, compCompanyName, USA,
          compProduct);
      appdaoTestHelper.createProductGermplasm(compProduct, topLevelFemaleGp);

      appdaoTestHelper.endTransaction(true);
    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      appdaoTestHelper = new TestHelper();
      appdaoTestHelper.beginTransaction();
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
          MaterialTypeConstants.SEGPOP_LINES);
      StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.SEGPOP_LINES,
          importedOrigin, importedSource, null, null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
          userId, importedGeneration, importedLineage, importedLineCode, null, null, null,
          StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, mainRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED,
          userId);
      StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

      F1SegpopUnfinishedProcessor processor = new MockF1SegpopUnfinishedProcessor();
      MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
      MidasContext midasContext = processor.processInventory(context);

      assertMidasContext(midasContext, 1, 1, 1, stagingInventoryRec.getStagingParentage().size());
    } finally {
      appdaoTestHelper.endTransaction(false);
      removeStagingInventoryTestData(templateName);
      purgeProduct(CROP_NAME, topLevelFemaleParentOrigin, compBrandName, compCompanyName);
      purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
          topLevelFemaleParentPedigree, CROP_NAME);
      purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin,
          topLevelMaleParentPedigree, CROP_NAME);
    }
  }

  public void testSimpleWithOneParentAsFinished_StagingInventoryHasUserProvidedSource_InventoryWillBeCreatedForThatParent() throws
      Exception {
    String finishedLineCode = "ASC";
    String segpopLine = "A/B:@.1.";
    String f1SegpopOrigin = "(" + segpopLine + ")/" + finishedLineCode;
    String source = segpopLine + "-" + finishedLineCode + " SRC1";
    String owner = "17";
    String maleSource = source + " MP";
    String femaleSource = source + " FP";

    Germplasm finishedGp = null;
    GeneticMaterial segpopGm = null;
    try {
      purgeGermplasm(FINISHED, finishedLineCode, "AXC/XYZ", finishedLineCode, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      finishedGp = appdaoTestHelper
          .createGermplasm(FINISHED, finishedLineCode, "AXC/XYZ", finishedLineCode, owner, CROP_NAME);
      appdaoTestHelper.createInbredGeneticMaterial(finishedGp, "SOME SOURCE");

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      segpopGm = appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 2, 2, 2);

      Germplasm[] germplasms = midasContext.getGermplasm();
      assertEquals(f1SegpopOrigin, germplasms[0].getOrigin());
      assertEquals(owner + "_" + f1SegpopOrigin, germplasms[0].getPedigreeName());
      assertEquals(SEGPOP.toUpperCase(), germplasms[0].getLineType().getLineTypeRefId());

      GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
      assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
      assertEquals("F", geneticMaterials[0].getIsAutogen());
      assertEquals(source, geneticMaterials[0].getSourceStr());

      assertEquals(finishedGp.getId(), geneticMaterials[1].getGermplasm().getId());
      assertEquals("F", geneticMaterials[1].getIsAutogen());
      assertEquals(maleSource, geneticMaterials[1].getSourceStr());

      Parentage[] parentage = midasContext.getParentage();
      assertEquals(parentage[0].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[0].getParentGeneticMaterial().getGeneticMaterialId(), segpopGm.getGeneticMaterialId());

      assertEquals(parentage[1].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[1].getParentGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[1].getGeneticMaterialId());
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(FINISHED, finishedLineCode, "AXC/XYZ", finishedLineCode, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testSimpleWithOneParentAsFinished_StagingInventoryHasDefaultSource_NoInventoryWillBeCreatedForThatParent() throws
      Exception {
    String finishedLineCode = "ASC";
    String segpopLine = "A/B:@.1.";
    String f1SegpopOrigin = "(" + segpopLine + ")/" + finishedLineCode;
    String source = segpopLine + "-" + finishedLineCode + " SRC1";
    String owner = "17";
    String femaleSource = source + " FP";

    Germplasm finishedGp = null;
    GeneticMaterial segpopGm = null;
    try {
      purgeGermplasm(FINISHED, finishedLineCode, "AXC/XYZ", finishedLineCode, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      finishedGp = appdaoTestHelper
          .createGermplasm(FINISHED, finishedLineCode, "AXC/XYZ", finishedLineCode, owner, CROP_NAME);
      appdaoTestHelper.createInbredGeneticMaterial(finishedGp, "SOME SOURCE");

      Germplasm segpopGp = appdaoTestHelper
          .createGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, owner, CROP_NAME);
      segpopGm = appdaoTestHelper.createGeneticMaterial(segpopGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, null, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 2, 2);

      Germplasm[] germplasms = midasContext.getGermplasm();
      assertEquals(f1SegpopOrigin, germplasms[0].getOrigin());
      assertEquals(owner + "_" + f1SegpopOrigin, germplasms[0].getPedigreeName());
      assertEquals(SEGPOP.toUpperCase(), germplasms[0].getLineType().getLineTypeRefId());

      GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
      assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
      assertEquals("F", geneticMaterials[0].getIsAutogen());
      assertEquals(source, geneticMaterials[0].getSourceStr());

      assertEquals(finishedGp.getId(), geneticMaterials[1].getGermplasm().getId());
      assertEquals("T", geneticMaterials[1].getIsAutogen());
      assertEquals(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, geneticMaterials[1].getSourceStr());

      Parentage[] parentage = midasContext.getParentage();
      assertEquals(parentage[0].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[0].getParentGeneticMaterial().getGeneticMaterialId(), segpopGm.getGeneticMaterialId());

      assertEquals(parentage[1].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[1].getParentGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[1].getGeneticMaterialId());
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(FINISHED, finishedLineCode, "AXC/XYZ", finishedLineCode, CROP_NAME);
      purgeGermplasm(SEGPOP, null, segpopLine, owner + "_" + segpopLine, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidas_SegpopParentGetsChangedToUnfinishedHybrid() throws Exception {
    String lineage = "@.1.";
    String inbredFemaleLineCodeHybrid = "II-INBRED-FEMALE-LC-HYB";
    String inbredMaleLineCodeHybrid = "II-INBRED-MALE-LC-HYB";
    String hybridOrigin = inbredFemaleLineCodeHybrid + "+" + inbredMaleLineCodeHybrid;
    String hybridOriginWithLineage = hybridOrigin + ":" + lineage;
    String segpopLineWithLineage = inbredFemaleLineCodeHybrid + "/" + inbredMaleLineCodeHybrid + ":" + lineage;

    String finishedLineCode = "II-INBRED-MALE-LC-FIN";
    String finishedOrigin = finishedLineCode + "-F/" + finishedLineCode + "-M";
    String f1SegpopOrigin = "(" + segpopLineWithLineage + ")/" + finishedLineCode;
    String source = segpopLineWithLineage + "-" + finishedLineCode + " SRC1";
    String owner = "17";
    String femaleSource = source + " FP";

    Germplasm finishedGp = null;
    GeneticMaterial hybridGm = null;
    try {
      purgeGermplasm(FINISHED, finishedLineCode, finishedOrigin, finishedLineCode, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin, owner + "_" + hybridOriginWithLineage, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      finishedGp = appdaoTestHelper
          .createGermplasm(FINISHED, finishedLineCode, finishedOrigin, finishedLineCode, owner, CROP_NAME);
      appdaoTestHelper.createInbredGeneticMaterial(finishedGp, "SOME SOURCE");

      Germplasm hybridGp = appdaoTestHelper
          .createGermplasm(HYBRID, null, hybridOrigin, owner + "_" + hybridOriginWithLineage, owner, CROP_NAME, "F",
              "F");
      hybridGm = appdaoTestHelper.createGeneticMaterial(hybridGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, null, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 2, 2);

      Germplasm[] germplasms = midasContext.getGermplasm();
      assertEquals(f1SegpopOrigin, germplasms[0].getOrigin());
      assertEquals(owner + "_" + f1SegpopOrigin, germplasms[0].getPedigreeName());
      assertEquals(SEGPOP.toUpperCase(), germplasms[0].getLineType().getLineTypeRefId());

      GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
      assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
      assertEquals("F", geneticMaterials[0].getIsAutogen());
      assertEquals(source, geneticMaterials[0].getSourceStr());

      assertEquals(finishedGp.getId(), geneticMaterials[1].getGermplasm().getId());
      assertEquals("T", geneticMaterials[1].getIsAutogen());
      assertEquals(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, geneticMaterials[1].getSourceStr());

      Parentage[] parentage = midasContext.getParentage();
      assertEquals(parentage[0].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[0].getParentGeneticMaterial().getGeneticMaterialId(), hybridGm.getGeneticMaterialId());

      assertEquals(parentage[1].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[1].getParentGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[1].getGeneticMaterialId());
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(FINISHED, finishedLineCode, finishedOrigin, finishedLineCode, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin, owner + "_" + hybridOriginWithLineage, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidas_SegpopParentGetsChangedToFinishedHybrid() throws Exception {
    String lineage = "@.1.";
    String inbredFemaleLineCodeHybrid = "II-INBRED-FEMALE-LC-HYB";
    String inbredMaleLineCodeHybrid = "II-INBRED-MALE-LC-HYB";
    String hybridOrigin = inbredFemaleLineCodeHybrid + "+" + inbredMaleLineCodeHybrid;
    String segpopLineWithLineage = inbredFemaleLineCodeHybrid + "/" + inbredMaleLineCodeHybrid + ":" + lineage;

    String finishedLineCode = "II-INBRED-MALE-LC-FIN";
    String finishedOrigin = finishedLineCode + "-F/" + finishedLineCode + "-M";
    String f1SegpopOrigin = "(" + segpopLineWithLineage + ")/" + finishedLineCode;
    String source = segpopLineWithLineage + "-" + finishedLineCode + " SRC1";
    String owner = "17";
    String femaleSource = source + " FP";

    Germplasm finishedGp = null;
    GeneticMaterial hybridGm = null;
    try {
      purgeGermplasm(FINISHED, finishedLineCode, finishedOrigin, finishedLineCode, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      finishedGp = appdaoTestHelper
          .createGermplasm(FINISHED, finishedLineCode, finishedOrigin, finishedLineCode, owner, CROP_NAME);
      appdaoTestHelper.createInbredGeneticMaterial(finishedGp, "SOME SOURCE");

      Germplasm hybridGp = appdaoTestHelper
          .createGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, owner, CROP_NAME, "F", "T");
      hybridGm = appdaoTestHelper.createGeneticMaterial(hybridGp, femaleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, null, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 2, 2);

      Germplasm[] germplasms = midasContext.getGermplasm();
      assertEquals(f1SegpopOrigin, germplasms[0].getOrigin());
      assertEquals(owner + "_" + f1SegpopOrigin, germplasms[0].getPedigreeName());
      assertEquals(SEGPOP.toUpperCase(), germplasms[0].getLineType().getLineTypeRefId());

      GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
      assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
      assertEquals("F", geneticMaterials[0].getIsAutogen());
      assertEquals(source, geneticMaterials[0].getSourceStr());

      assertEquals(finishedGp.getId(), geneticMaterials[1].getGermplasm().getId());
      assertEquals("T", geneticMaterials[1].getIsAutogen());
      assertEquals(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, geneticMaterials[1].getSourceStr());

      Parentage[] parentage = midasContext.getParentage();
      assertEquals(parentage[0].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[0].getParentGeneticMaterial().getGeneticMaterialId(), hybridGm.getGeneticMaterialId());

      assertEquals(parentage[1].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[1].getParentGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[1].getGeneticMaterialId());
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(FINISHED, finishedLineCode, finishedOrigin, finishedLineCode, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidas_BothParentsGetChangedToUnfinishedHybrid() throws Exception {
    String lineage1 = "@.1.";
    String inbredFemaleLineCodeHybrid = "II-INBRED-FEMALE-LC-HYB-1";
    String inbredMaleLineCodeHybrid = "II-INBRED-MALE-LC-HYB-1";
    String hybridOrigin = inbredFemaleLineCodeHybrid + "+" + inbredMaleLineCodeHybrid;
    String hybridOriginWithLineage = hybridOrigin + ":" + lineage1;
    String segpopLineWithLineageFemale = inbredFemaleLineCodeHybrid + "/" + inbredMaleLineCodeHybrid + ":" + lineage1;

    String lineage2 = "@.";
    String inbredFemaleLineCodeHybrid2 = "II-INBRED-FEMALE-LC-HYB-2";
    String inbredMaleLineCodeHybrid2 = "II-INBRED-MALE-LC-HYB-2";
    String hybridOrigin2 = inbredFemaleLineCodeHybrid2 + "+" + inbredMaleLineCodeHybrid2;
    String hybridOriginWithLineage2 = hybridOrigin2 + ":" + lineage2;
    String segpopLineWithLineageMale = inbredFemaleLineCodeHybrid2 + "/" + inbredMaleLineCodeHybrid2 + ":" + lineage2;

    String f1SegpopOrigin = "(" + segpopLineWithLineageFemale + ")/(" + segpopLineWithLineageMale + ")";
    String source = segpopLineWithLineageFemale + "-" + segpopLineWithLineageMale + " SRC1";
    String owner = "17";
    String femaleSource = source + " FP";
    String maleSource = source + " MP";

    GeneticMaterial hybridGmFemale = null;
    GeneticMaterial hybridGmMale = null;
    try {
      purgeGermplasm(HYBRID, null, hybridOrigin, owner + "_" + hybridOriginWithLineage, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin2, owner + "_" + hybridOriginWithLineage2, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm hybridGpFemale = appdaoTestHelper
          .createGermplasm(HYBRID, null, hybridOrigin, owner + "_" + hybridOriginWithLineage, owner, CROP_NAME, "F",
              "F");
      hybridGmFemale = appdaoTestHelper.createGeneticMaterial(hybridGpFemale, femaleSource, "F1", null);

      Germplasm hybridGpMale = appdaoTestHelper
          .createGermplasm(HYBRID, null, hybridOrigin2, owner + "_" + hybridOriginWithLineage2, owner, CROP_NAME, "F",
              "F");
      hybridGmMale = appdaoTestHelper.createGeneticMaterial(hybridGpMale, maleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);

      Germplasm[] germplasms = midasContext.getGermplasm();
      assertEquals(f1SegpopOrigin, germplasms[0].getOrigin());
      assertEquals(owner + "_" + f1SegpopOrigin, germplasms[0].getPedigreeName());
      assertEquals(SEGPOP.toUpperCase(), germplasms[0].getLineType().getLineTypeRefId());

      GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
      assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
      assertEquals("F", geneticMaterials[0].getIsAutogen());
      assertEquals(source, geneticMaterials[0].getSourceStr());

      Parentage[] parentage = midasContext.getParentage();
      assertEquals(parentage[0].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[0].getParentGeneticMaterial().getGeneticMaterialId(),
          hybridGmFemale.getGeneticMaterialId());

      assertEquals(parentage[1].getGeneticMaterial().getGermplasm().getPedigreeName(), owner + "_" + f1SegpopOrigin);
      assertEquals(parentage[1].getParentGeneticMaterial().getGermplasm().getPedigreeName(),
          hybridGmMale.getGermplasm().getPedigreeName());
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(HYBRID, null, hybridOrigin, owner + "_" + hybridOriginWithLineage, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin2, owner + "_" + hybridOriginWithLineage2, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  public void testProcessInventoryIntoMidas_BothParentsGetChangedToFinishedHybrid() throws Exception {
    String lineage1 = "@.1.";
    String inbredFemaleLineCodeHybrid = "II-INBRED-FEMALE-LC-HYB-1";
    String inbredMaleLineCodeHybrid = "II-INBRED-MALE-LC-HYB-1";
    String hybridOrigin = inbredFemaleLineCodeHybrid + "+" + inbredMaleLineCodeHybrid;
    String segpopLineWithLineageFemale = inbredFemaleLineCodeHybrid + "/" + inbredMaleLineCodeHybrid + ":" + lineage1;

    String lineage2 = "@.";
    String inbredFemaleLineCodeHybrid2 = "II-INBRED-FEMALE-LC-HYB-2";
    String inbredMaleLineCodeHybrid2 = "II-INBRED-MALE-LC-HYB-2";
    String hybridOrigin2 = inbredFemaleLineCodeHybrid2 + "+" + inbredMaleLineCodeHybrid2;
    String segpopLineWithLineageMale = inbredFemaleLineCodeHybrid2 + "/" + inbredMaleLineCodeHybrid2 + ":" + lineage2;

    String f1SegpopOrigin = "(" + segpopLineWithLineageFemale + ")/(" + segpopLineWithLineageMale + ")";
    String source = segpopLineWithLineageFemale + "-" + segpopLineWithLineageMale + " SRC1";
    String owner = "17";
    String femaleSource = source + " FP";
    String maleSource = source + " MP";

    GeneticMaterial hybridGmFemale = null;
    GeneticMaterial hybridGmMale = null;
    try {
      purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin2, hybridOrigin2, CROP_NAME);
      removeStagingInventoryTestData(templateName);

      Germplasm hybridGpFemale = appdaoTestHelper
          .createGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, owner, CROP_NAME, "F", "T");
      hybridGmFemale = appdaoTestHelper.createGeneticMaterial(hybridGpFemale, femaleSource, "F1", null);

      Germplasm hybridGpMale = appdaoTestHelper
          .createGermplasm(HYBRID, null, hybridOrigin2, hybridOrigin2, owner, CROP_NAME, "F", "T");
      hybridGmMale = appdaoTestHelper.createGeneticMaterial(hybridGpMale, maleSource, "F1", null);
      session.getTransaction().commit();
    } finally {
      session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      session.beginTransaction();
      appdaoTestHelper.setStagingSession(session);
    }

    try {
      StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, SEGPOP);
      StagingInventory importedRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
          f1SegpopOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, SEGPOP,
          userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

      importStagingInventory(header, importedRecord);
      preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
          StagingInventoryStatusConstants.APPROVED, userId);
      StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
      assertNotNull(stagingInventory.getStagingParentage());

      InventoryContext inventoryContext = new MockInventoryContext(stagingInventory);
      MidasContext midasContext = new MidasContext();
      F1SegpopUnfinishedProcessor processor = new F1SegpopUnfinishedProcessor(midasContext,
          new StagingParentageHelper(stagingInventory.getStagingParentage()));
      midasContext = processor.processInventory(inventoryContext);

      assertMidasContext(midasContext, 1, 1, 1, 2);

      Germplasm[] germplasms = midasContext.getGermplasm();
      assertEquals(f1SegpopOrigin, germplasms[0].getOrigin());
      assertEquals(owner + "_" + f1SegpopOrigin, germplasms[0].getPedigreeName());
      assertEquals(SEGPOP.toUpperCase(), germplasms[0].getLineType().getLineTypeRefId());

      GeneticMaterial[] geneticMaterials = midasContext.getGeneticMatterial();
      assertEquals(germplasms[0].getId(), geneticMaterials[0].getGermplasm().getId());
      assertEquals("F", geneticMaterials[0].getIsAutogen());
      assertEquals(source, geneticMaterials[0].getSourceStr());

      Parentage[] parentage = midasContext.getParentage();
      assertEquals(parentage[0].getGeneticMaterial().getGeneticMaterialId(),
          geneticMaterials[0].getGeneticMaterialId());
      assertEquals(parentage[0].getParentGeneticMaterial().getGeneticMaterialId(),
          hybridGmFemale.getGeneticMaterialId());

      assertEquals(parentage[1].getGeneticMaterial().getGermplasm().getPedigreeName(), owner + "_" + f1SegpopOrigin);
      assertEquals(parentage[1].getParentGeneticMaterial().getGermplasm().getPedigreeName(),
          hybridGmMale.getGermplasm().getPedigreeName());
    } finally {
      session.getTransaction().rollback();
      purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
      purgeGermplasm(HYBRID, null, hybridOrigin2, hybridOrigin2, CROP_NAME);
      removeStagingInventoryTestData(templateName);
    }
  }

  class MockF1SegpopUnfinishedProcessor extends F1SegpopUnfinishedProcessor {
    protected GeneticMaterial getGeneticMaterialFromProductName(String cropName,
                                                                LineFunctionCriteria lineFunctionCriteria,
                                                                StagingInventory stagingInventory) {
      return null;
    }
  }
}