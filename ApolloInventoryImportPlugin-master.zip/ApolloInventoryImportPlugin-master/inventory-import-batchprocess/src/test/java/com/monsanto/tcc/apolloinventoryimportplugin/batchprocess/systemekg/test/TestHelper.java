/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.test;

import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Filename:    $RCSfile: TestHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $ On:	$Date: 2008-02-17 22:58:08 $
 *
 * @author APATRO
 * @version $Revision: 1.2 $
 */
public class TestHelper {
  public RunHistory createRunHistory(long expectedRunHistoryId, Date expectedStartDate, Date expectedEndDate) {
    RunHistory runHistory = new RunHistory();
    runHistory.setId(new Long(expectedRunHistoryId));
    runHistory.setStartDate(new Timestamp(expectedStartDate.getTime()));
    runHistory.setEndDate(new Timestamp(expectedEndDate.getTime()));
    return runHistory;
  }

  public StagingInventory createStagingInventory(String statusCode, int numberOfParents) {
    StagingInventory main = createStagingInventory(statusCode);

    StagingInventory child = main;
    Set stagingParentageSet = new HashSet();
    for (int i = 0; i < numberOfParents; i++) {
      StagingInventory parent = createStagingInventory(statusCode);
      StagingParentage stagingParentage = createStagingParentage(child, parent, main, i + 1);
      child = parent;
      stagingParentageSet.add(stagingParentage);
    }

    main.setStagingParentage(stagingParentageSet);

    return main;
  }

  public StagingParentage createStagingParentage(StagingInventory child, StagingInventory parent,
                                                 StagingInventory main, int level) {
    StagingParentage stagingParentage = new StagingParentage();
    stagingParentage.setChildInventory(child);
    stagingParentage.setParentInventory(parent);
    stagingParentage.setMainInventory(main);
    stagingParentage.setParentalRole("F");
    stagingParentage.setRecordLevel(new Long(level));
    return stagingParentage;
  }

  public StagingInventory createStagingInventory(String statusCode) {
    StagingInventory stagingInventory = new StagingInventory();
    stagingInventory.setImportStatus(getImportStatus(statusCode));
    return stagingInventory;
  }

  public ImportStatus getImportStatus(String statusCode) {
    ImportStatus importStatus = new ImportStatus();
    importStatus.setStatusCode(statusCode);
    return importStatus;
  }
}