/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.AbstractStagingInventoryProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.InventoryContext;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.InventoryImportProcessorException;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.EventBuilder;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmEventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProductNameProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.FinishedGeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.HybridGeneticMaterialDAO;
import junit.framework.TestCase;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Filename:    $RCSfile: AbstractStagingInventory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspeyy $    	 On:	$Date: 2008-06-12 04:51:53 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class AbstractStagingInventory_UT extends TestCase {
  private static final String TEST_ORIGIN = "TEST/ORIGIN";
  private static final String TEST_PRODUCT_NAME = "TEST PRODUCT NAME";

  private Session session;

  protected void setUp() throws Exception {
    super.setUp();
    session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    session.beginTransaction();
  }

  protected void tearDown() throws Exception {
    session.getTransaction().rollback();
    super.tearDown();
  }

  public AbstractStagingInventory_UT(String name) {
    super(name);
  }

  public void testBuildInventoryBarCode() throws Exception {
    MockProcessor processor = new MockProcessor();

    StagingInventory stagingInventory = createStagingInventory();

    GeneticMaterial geneticMaterial = (GeneticMaterial) session.createCriteria(GeneticMaterial.class)
        .add(Restrictions.eq("geneticMaterialId", new Long("6645154447667")))
        .uniqueResult();
    Inventory inv = processor.createMidasInventory(stagingInventory, geneticMaterial);

    assertEquals(AbstractStagingInventoryProcessor.BARCODE_PADDING, inv.getBarCode().length());
    assertTrue(inv.getBarCode().startsWith("I" + inv.getProgram().getBrProgRefId()));
    assertTrue(inv.getBarCode().endsWith(inv.getInventoryId().toString()));
    assertTrue(
        inv.getBarCode().matches("I" + inv.getProgram().getBrProgRefId() + "[0]+" + inv.getInventoryId().toString()));
  }

  public void testCreateMidasInventoryAndHistory() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();

    GeneticMaterial geneticMaterial = (GeneticMaterial) session.createCriteria(GeneticMaterial.class)
        .add(Restrictions.eq("geneticMaterialId", new Long("6645154447667")))
        .uniqueResult();
    Inventory inv = processor.createMidasInventory(stagingInventory, geneticMaterial);
    System.out.println("inv.getInventoryId() = " + inv.getInventoryId());
    session.save(inv);
    session.flush();
    assertNotNull(inv.getInventoryImportHistory());
    assertTrue(inv.getInventoryImportHistory().size() > 0);
  }

  public void testCreateMidasGermplasmWithEvents() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();

    EventConstruct[] eventConstructs = getEventConstructs("Corn", 5);
    String eventString = getEventString(eventConstructs);
    stagingInventory.setEvent(eventString);

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);

    session.save(germplasm);
    session.flush();
    assertNotNull(germplasm);
    assertEquals("T", germplasm.getIsTransgenic());
    assertNotNull(germplasm.getGermplasmEventConstruct());
    assertTrue(germplasm.getGermplasmEventConstruct().size() >= 5);

    String newEventString = getEventString(germplasm.getGermplasmEventConstruct());
    assertEquals(eventString, newEventString);
  }

  public void testCreateMidasGermplasmWithoutEvents() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();

    stagingInventory.setEvent(null);

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);

    session.save(germplasm);
    session.flush();
    assertNotNull(germplasm);
    assertEquals("F", germplasm.getIsTransgenic());
    assertNull(germplasm.getGermplasmEventConstruct());
  }

  public void testCreateMidasGermplasmWithLineFunction() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "B";
    stagingInventory.setLineFunction(lineFunction);

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);

    session.save(germplasm);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
  }

  public void testCreateMidasGermplasmWithALineFunctionAndCytoplasmDonor() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "A";
    stagingInventory.setLineFunction(lineFunction);
    String cytoplasmDonor = "17_A/B:@.1.";
    stagingInventory.setCytoplasmDonorPedigree(cytoplasmDonor);

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);

    session.save(germplasm);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
    assertEquals(cytoplasmDonor, germplasm.getCytoplasmDonor());
  }

  public void testCreateMidasGermplasmWithoutLineFunction() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    stagingInventory.setLineFunction(null);

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);

    session.save(germplasm);
    session.flush();
    assertNotNull(germplasm);
    assertNull(germplasm.getLineFunction());
  }

  public void testCreateMidasGermplasmWithBlankLineFunction() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    stagingInventory.setLineFunction("");

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);

    session.save(germplasm);
    session.flush();
    assertNotNull(germplasm);
    assertNull(germplasm.getLineFunction());
  }

  public void testCreateMidasGeneticMaterialWithNonMSCLineFunction() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "B";
    stagingInventory.setLineFunction(lineFunction);
    stagingInventory.setLineage("@.1.2.3>");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("F4"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
    assertNotNull(geneticMaterial);
    assertEquals("@.1.2.3>", geneticMaterial.getLineage());
    assertEquals("BC1", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithCLineFunctionAndNullLineage() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "C";
    stagingInventory.setLineFunction(lineFunction);
    stagingInventory.setLineage(null);
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("F4"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
    assertNotNull(geneticMaterial);
    assertNull(geneticMaterial.getLineage());
    assertEquals("MSC0", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithNonMSCLineFunctionAndDiploidGeneration() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "B";
    stagingInventory.setLineFunction(lineFunction);
    stagingInventory.setLineage("@%1%2.3.");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("DD5"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
    assertNotNull(geneticMaterial);
    assertEquals("@%1%2.3.", geneticMaterial.getLineage());
    assertEquals("DD2", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithNonMSCLineFunctionAndPercentCycleMarker() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "B";
    stagingInventory.setLineFunction(lineFunction);
    stagingInventory.setLineage("@%1%2.3.");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("F3"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
    assertNotNull(geneticMaterial);
    assertEquals("@%1%2.3.", geneticMaterial.getLineage());
    assertEquals("DH2", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithALineFunctionAndCytoplasmDonor() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    String lineFunction = "A";
    stagingInventory.setLineFunction(lineFunction);
    String cytoplasmDonor = "17_A/B:@.1.";
    stagingInventory.setCytoplasmDonorPedigree(cytoplasmDonor);
    stagingInventory.setLineage("@.1.2.3>");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("MSC3");

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNotNull(germplasm.getLineFunction());
    assertEquals(lineFunction, germplasm.getLineFunction().getLineFunctionRefId());
    assertEquals(cytoplasmDonor, germplasm.getCytoplasmDonor());
    assertNotNull(geneticMaterial);
    assertEquals("@.1.2.3>", geneticMaterial.getLineage());
    assertEquals("MSC3", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithoutLineFunction() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    stagingInventory.setLineFunction(null);
    stagingInventory.setLineage("@.1.2.3>");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("F4"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNull(germplasm.getLineFunction());
    assertNotNull(geneticMaterial);
    assertEquals("@.1.2.3>", geneticMaterial.getLineage());
    assertEquals("BC1", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithoutLineFunctionAndDiploidGeneration() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    stagingInventory.setLineFunction(null);
    stagingInventory.setLineage("@%1%2.3.");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("DD3"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNull(germplasm.getLineFunction());
    assertNotNull(geneticMaterial);
    assertEquals("@%1%2.3.", geneticMaterial.getLineage());
    assertEquals("DD2", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithoutLineFunctionAndPercentCycleMarker() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    stagingInventory.setLineFunction(null);
    stagingInventory.setLineage("@%1%2.3.");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("F3"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNull(germplasm.getLineFunction());
    assertNotNull(geneticMaterial);
    assertEquals("@%1%2.3.", geneticMaterial.getLineage());
    assertEquals("DH2", geneticMaterial.getGeneration());
  }

  public void testCreateMidasGeneticMaterialWithBlankLineFunction() throws Exception {
    MockProcessor processor = new MockProcessor();
    StagingInventory stagingInventory = createStagingInventory();
    stagingInventory.setLineFunction("");
    stagingInventory.setLineage("@.1.2.3>");
    stagingInventory.setSource("SOME SRC");
    stagingInventory.setGeneration("F4"); // Incorrect generation

    Germplasm germplasm = processor.createMidasGermplasm(stagingInventory);
    GeneticMaterial geneticMaterial = processor.createMidasGeneticMaterial(stagingInventory, germplasm);

    session.save(germplasm);
    session.save(geneticMaterial);
    session.flush();
    assertNotNull(germplasm);
    assertNull(germplasm.getLineFunction());
    assertNotNull(geneticMaterial);
    assertEquals("@.1.2.3>", geneticMaterial.getLineage());
    assertEquals("BC1", geneticMaterial.getGeneration());
  }

  public void testGetGermplasmFromProductNameProductGermplasm() throws Exception {
    ProductNameProductGermplasm productNameProductGermplasm = new ProductNameProductGermplasm();
    ProductGermplasm productGermplasm = new ProductGermplasm();
    Germplasm expectedGermplasm = new Germplasm();
    expectedGermplasm.setId(new Long(222));
    productGermplasm.setGermplasm(expectedGermplasm);
    productNameProductGermplasm.setProductGermplasm(productGermplasm);

    MockProcessor processor = new MockProcessor();
    Germplasm actualGermplasm = processor.getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm);

    assertEquals(expectedGermplasm, actualGermplasm);
  }


  public void testGetGeneticMaterialFromProductName_Finished_ProductNameIsNull() throws Exception {
    StagingInventory inventory = new StagingInventory();
    inventory.setOrigin(TEST_ORIGIN);
    inventory.setLineType(MaterialTypeConstants.FINISHED_LINES);

    MockProcessor processor = new MockProcessor();
    GeneticMaterial actualGeneticMaterial = processor.getGeneticMaterialFromProductName("Corn", new NullLineFunctionCriteria(), inventory);

    assertNull(actualGeneticMaterial);
  }

  public void testGetGeneticMaterialFromProductName_Finished() throws Exception {
    StagingInventory inventory = new StagingInventory();
    inventory.setProductName(TEST_PRODUCT_NAME);
    inventory.setPedigreeName(TEST_ORIGIN);
    inventory.setLineType(MaterialTypeConstants.FINISHED_LINES);

    MockProcessor processor = new MockProcessor();
    GeneticMaterial actualGeneticMaterial = processor.getGeneticMaterialFromProductName("Corn", new NullLineFunctionCriteria(), inventory);

    assertNotNull(actualGeneticMaterial);
    assertNotNull(actualGeneticMaterial.getGermplasm());
    assertEquals(TEST_ORIGIN, actualGeneticMaterial.getGermplasm().getOrigin());
  }

  public void testGetGeneticMaterialFromProductName_Hybrid() throws Exception {
    StagingInventory inventory = new StagingInventory();
    inventory.setOrigin(TEST_ORIGIN);
    inventory.setLineType(MaterialTypeConstants.HYBRID_LINES);
    inventory.setProductName(TEST_PRODUCT_NAME);
    inventory.setPedigreeName(TEST_ORIGIN);
    inventory.setSource("SOME SRC");

    MockProcessor processor = new MockProcessor();
    GeneticMaterial actualGeneticMaterial = processor.getGeneticMaterialFromProductName("Corn", new NullLineFunctionCriteria(), inventory);

    assertNotNull(actualGeneticMaterial);
    assertNotNull(actualGeneticMaterial.getGermplasm());
    assertEquals(TEST_ORIGIN, actualGeneticMaterial.getGermplasm().getOrigin());
    assertEquals(inventory.getSource(), actualGeneticMaterial.getSourceStr());
  }

  private String getEventString(Set germplasmEventConstruct) {
    Iterator iterator = germplasmEventConstruct.iterator();
    EventBuilder eventBuilder = new EventBuilder();
    while (iterator.hasNext()) {
      String eventName = ((GermplasmEventConstruct) iterator.next()).getEventConstruct().getEventName();
      eventBuilder.addEvent(eventName);
    }

    return eventBuilder.toString();
  }

  private String getEventString(EventConstruct[] eventConstructs) {
    String eventString = null;

    if (eventConstructs != null && eventConstructs.length > 0) {
      EventBuilder eventBuilder = new EventBuilder();
      for (int i = 0; i < eventConstructs.length; i++) {
        EventConstruct eventConstruct = eventConstructs[i];
        eventBuilder.addEvent(eventConstruct.getEventName());
      }
      eventString = eventBuilder.toString();
    }

    return eventString;
  }

  private EventConstruct[] getEventConstructs(String cropName, int rowCount) {
    List list = session.createCriteria(EventConstruct.class)
        .createAlias("crop", "cr")
        .add(Restrictions.eq("cr.cropName", cropName))
        .add(Restrictions.eq("refActive", "T"))
        .add(Restrictions.isNotNull("eventName"))
        .add(Restrictions.isNotNull("constructName"))
        .list();

    EventConstruct[] eventConstructs = null;
    if (list != null && list.size() > 0) {
      Iterator iterator = list.iterator();
      List newList = new ArrayList();
      int count = 0;
      while (iterator.hasNext()) {
        if (count > rowCount) break;
        newList.add(iterator.next());
        count++;
      }
      eventConstructs = (EventConstruct[]) newList.toArray(new EventConstruct[0]);
    }

    return eventConstructs;
  }


  private StagingInventory createStagingInventory() {
    StagingInventory stagingInventory = new StagingInventory();
    stagingInventory.setId(new Long(10));
    stagingInventory.setGeneration("BC1");
    stagingInventory.setGermplasmOwner("LT");
    stagingInventory.setLineage("@>0002>");
    stagingInventory.setOrigin("A*2/B");
    stagingInventory.setLineType("Segpop");
    stagingInventory.setInventoryOwner("LT");
    StagingInventoryHeader invHdr = new StagingInventoryHeader();
    invHdr.setCropName("Corn");
    stagingInventory.setInventoryHeader(invHdr);
    stagingInventory.setSource("Test Source");
    stagingInventory.setApprovalProcessDate(new Date());
    stagingInventory.setApprovalRequestDate(new Date());
    stagingInventory.setValidationDate(new Date());
    stagingInventory.setAuthorityRequested("SSPEYY");
    stagingInventory.setAuthorityProcessed("SRKARNA");
    invHdr.setUserId("SKUMAR5");
    stagingInventory.setInventoryHeader(invHdr);
    return stagingInventory;
  }

  class MockProcessor extends AbstractStagingInventoryProcessor {
    public MidasContext processInventory(InventoryContext inventoryContext) throws
        InventoryImportProcessorException {

      return new MidasContext();
    }

    protected Inventory createMidasInventory(StagingInventory stagingInventory, GeneticMaterial geneticMaterial) {
      return super.createMidasInventory(stagingInventory, geneticMaterial);
    }

    protected Germplasm createMidasGermplasm(StagingInventory stagingInventory) {
      return super.createMidasGermplasm(stagingInventory);
    }

    protected GeneticMaterial createMidasGeneticMaterial(StagingInventory stagingInventory, Germplasm germplasm) {
      return super.createMidasGeneticMaterial(stagingInventory, germplasm);
    }

    protected Germplasm getGermplasmFromProductNameProductGermplasm(ProductNameProductGermplasm productNameProductGermplasm) {
      return super.getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm);
    }

    protected GeneticMaterial getGeneticMaterialFromProductName(String cropName, LineFunctionCriteria lineFunctionCriteria, StagingInventory stagingInventory) {
      return super.getGeneticMaterialFromProductName(cropName, lineFunctionCriteria, stagingInventory);
    }

    protected ProductNameProductGermplasm getProductNameProductGermplasmForExistingParentSubrecord(String cropName, String originComponent) {
      if(!TEST_ORIGIN.equals(originComponent)) {
        return super.getProductNameProductGermplasmForExistingParentSubrecord(cropName, originComponent);
      }
      ProductNameProductGermplasm productNameProductGermplasm = new ProductNameProductGermplasm();
      ProductName productName = new ProductName();
      productName.setName(TEST_PRODUCT_NAME);
      productNameProductGermplasm.setProductName(productName);

      Germplasm germplasm = new Germplasm();
      germplasm.setOrigin(TEST_ORIGIN);
      ProductGermplasm productGermplasm = new ProductGermplasm();
      productGermplasm.setGermplasm(germplasm);
      productNameProductGermplasm.setProductGermplasm(productGermplasm);
      return productNameProductGermplasm;
    }

    protected FinishedGeneticMaterialDAO createFinishedGeneticMaterialDAO(String cropName,
                                                                          LineFunctionCriteria lineFunctionCriteria) {
      return new MockFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria);
    }
    protected HybridGeneticMaterialDAO createHybridGeneticMaterialDAO(String source, String cropName) {
      return new MockHybridGeneticMaterialDAO(source, cropName);
    }
  }

  class MockFinishedGeneticMaterialDAO extends FinishedGeneticMaterialDAO {
    public MockFinishedGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
      super(cropName, lineFunctionCriteria);
    }
    public GeneticMaterial getPrimaryGeneticMaterial(Germplasm germplasm) {
      germplasm.setOrigin(TEST_ORIGIN);
      GeneticMaterial geneticMaterial = new GeneticMaterial();
      geneticMaterial.setGermplasm(germplasm);
      return geneticMaterial;
    }
    public GeneticMaterial getPrimaryGeneticMaterial(String lineCode, String source) {
      Germplasm germplasm = new Germplasm();
      germplasm.setOrigin(TEST_ORIGIN);
      return getPrimaryGeneticMaterial(germplasm);
    }
  }

  class MockHybridGeneticMaterialDAO extends HybridGeneticMaterialDAO {
    private String sourceStr;

    public MockHybridGeneticMaterialDAO(String source, String cropName) {
      super(source, cropName);
      this.sourceStr = source;
    }
    public GeneticMaterial getLowestGeneticMaterialMatchingGermplasm(Germplasm germplasm) {
      germplasm.setOrigin(TEST_ORIGIN);
      GeneticMaterial geneticMaterial = new GeneticMaterial();
      geneticMaterial.setGermplasm(germplasm);
      geneticMaterial.setSourceStr(sourceStr);
      return geneticMaterial;
    }
  }
}