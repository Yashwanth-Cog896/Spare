/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.BatchProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.BatchRunHistoryHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: ATBatchProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $    	 On:	$Date: 2008-02-14 23:06:29 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public final class ATBatchProcessor extends BatchProcessor {
  Map midasContextMap;

  public ATBatchProcessor() {
    super(false);
  }

  public ATBatchProcessor(boolean commit) {
    super(commit);
  }

  public BatchRunHistoryHelper getBatchRunHistoryHelper() {
    return super.getBatchRunHistoryHelper();
  }

  /**
   * @noinspection RefusedBequest
   */
  protected void validateAndProcessInventory(StagingInventory[] approvedStagingInventory) {
    midasContextMap = new HashMap();

    for (int i = 0; i < approvedStagingInventory.length; i++) {
      if ("Approved".equalsIgnoreCase(approvedStagingInventory[i].getImportStatus().getStatusCode())) {
        MidasContext midasContext = super.validateAndProcessInventory(approvedStagingInventory[i]);
        midasContextMap.put(approvedStagingInventory[i], midasContext);
      }
    }
  }

  public void process(StagingInventory[] approvedStagingInventory) {
    super.process(approvedStagingInventory);
  }

  public MidasContext getMidasContext(StagingInventory stagingInventory) {
    MidasContext midasContext = null;
    if (midasContextMap != null && ! midasContextMap.isEmpty()) {
      midasContext = (MidasContext) midasContextMap.get(stagingInventory);
    }
    return midasContext;
  }

  /**
   * @noinspection RefusedBequest
   */
  protected StagingInventory[] getStagingInventoryInApprovedStatus(int fetchSize) throws ActivityClientException {
    throw new RuntimeException("Method disabled in this class");
  }
}