/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;
/**
 *
 * Filename:    $RCSfile: BatchRunHistoryHelper_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    	 On:	$Date: 2008-12-01 22:35:53 $
 * @version $Revision: 1.20 $
 * @author APATRO
 */

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.BatchRunHistoryHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunDetail;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.posclients.ImportPOSClient;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.SimpleStagingInventoryByStatusCodesFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.Util.StringUtils;
import junit.framework.TestCase;
import org.hibernate.classic.Session;
import org.hibernate.Query;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Restrictions;

import java.util.*;

public class BatchRunHistoryHelper_UT extends TestCase {
  private Session appdaoSession;
  private TestHelper testHelper;
  private String userId;
  private String templateName;
  private Random random = new Random();

  public BatchRunHistoryHelper_UT(String name) {
    super(name);
    userId = System.getProperty("user.name");
  }

  protected void setUp() throws Exception {
    super.setUp();
    templateName = this.getClass().getName() + random.nextInt() ;
    appdaoSession = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    appdaoSession.beginTransaction();
    testHelper = new TestHelper(appdaoSession);
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  public void testCreateBatchRunHistoryHelper() {
    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    assertNotNull(helper);

    MockBatchRunHistoryHelper mockHelper = (MockBatchRunHistoryHelper) helper;

    assertNotNull(mockHelper.fetchRunHistory().getStartDate());
    assertNull(mockHelper.fetchRunHistory().getEndDate());
    assertEquals("Batch", mockHelper.fetchRunHistory().getProcessName().getName());
    assertEquals("Running", mockHelper.fetchRunHistory().getRunStatus().getStatusCode());
    assertEquals(0, mockHelper.fetchRunHistory().getRecordsProcessed().longValue());

    assertNull(mockHelper.fetchRunDetails());
  }

  public void testAddRecordsWithNoStagingInventories_Null() {
    StagingInventory[] stagingInventories = null;
    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    long recordsAdded = helper.addRecords(stagingInventories);

    assertEquals(0, recordsAdded);
  }

  public void testAddRecordsWithNoStagingInventories_Empty() {
    StagingInventory[] stagingInventories = new StagingInventory[0];
    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    long recordsAdded = helper.addRecords(stagingInventories);

    assertEquals(0, recordsAdded);
  }

  public void testAddRecords() {
    StagingInventory[] stagingInventories = createStagingInventoriesWithParentage();
    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    long totalNoRecords = getRecordCountIncludingParents(stagingInventories);

    long recordsAdded = helper.addRecords(stagingInventories);

    assertEquals(totalNoRecords, recordsAdded);

    MockBatchRunHistoryHelper mockHelper = (MockBatchRunHistoryHelper) helper;
    assertEquals(totalNoRecords, mockHelper.fetchRunDetails().length);
  }

  public void testGetRunDetailsForStagingInventoryThatWasNotAdded() {
    StagingInventory inv = new StagingInventory();
    inv.setId(new Long(1));

    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    assertNull(((MockBatchRunHistoryHelper) helper).fetchRunDetails(inv));
  }

  public void testGetRunDetailsForStagingInventoryThatWasAdded() {
    StagingInventory inv = new StagingInventory();
    inv.setId(new Long(1));

    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();
    helper.addRecords(new StagingInventory[]{inv});

    assertEquals(inv.getId(), ((MockBatchRunHistoryHelper) helper).fetchRunDetails(inv).getInventoryId());
  }

  public void testRemoveRunDetails() {
    StagingInventory inv = new StagingInventory();
    inv.setId(new Long(1));

    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();
    helper.addRecords(new StagingInventory[]{inv});

    assertEquals(inv.getId(), ((MockBatchRunHistoryHelper) helper).fetchRunDetails(inv).getInventoryId());

    helper.removeRunDetails(inv);

    assertNull(((MockBatchRunHistoryHelper) helper).fetchRunDetails(inv));
  }

  public void testSaveRunHistory() {
    StagingInventory inv = new StagingInventory();
    inv.setId(new Long(1));

    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();
    helper.addRecords(new StagingInventory[]{inv});

    //Initial save
    helper.saveRunHistory();
    appdaoSession.flush();

    //Update
    helper.setRecordsProcessed(10);
    helper.setRunStatus("Done");
    helper.stampEndDate();
    helper.saveRunHistory();
    appdaoSession.flush();

    MockBatchRunHistoryHelper mockHelper = (MockBatchRunHistoryHelper) helper;
    assertEquals(10, mockHelper.fetchRunHistory().getRecordsProcessed().longValue());
    assertEquals("Done", mockHelper.fetchRunHistory().getRunStatus().getStatusCode());
    assertNotNull(mockHelper.fetchRunHistory().getEndDate());
  }

  public void testSaveRunDetails() {
    SimpleStagingInventoryByStatusCodesFetchStrategy dao = new SimpleStagingInventoryByStatusCodesFetchStrategy();
    Session session1 = HibernateUtil.getSessionFactoryForStagingInventory().openSession();
    session1.beginTransaction();
    StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(new String[]{"New", "Approved"});
    session1.getTransaction().rollback();
    assertNotNull(stagingInventory);
    assertFalse(stagingInventory.length == 0);

    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    helper.addRecords(stagingInventory);

    helper.saveRunHistory(); // This needs to be done before saving run details
    helper.saveRunDetails(); // Mass save of initially created run detail records
//    session.flush();

    RunDetail runDetail = ((MockBatchRunHistoryHelper) helper).fetchRunDetails(stagingInventory[0]);
    RunHistory runHistory = ((MockBatchRunHistoryHelper) helper).fetchRunHistory();
    assertEquals(runHistory.getId(), runDetail.getRunHistory().getId());
    assertEquals(stagingInventory[0].getId(), runDetail.getInventoryId());

    helper.setProcessExceptionMessage(stagingInventory[0], "Not Processed");
    stagingInventory[0].setValidationMessage("Validation failed - Unknown Reason");
    helper.setValidationInfo(stagingInventory[0]);
    helper.saveRunDetails(stagingInventory[0]);
//    session.flush();
    assertEquals("Not Processed", runDetail.getProcessExceptionMsg());
    assertEquals(stagingInventory[0].getValidationMessage(), runDetail.getValidationExceptionMsg());
    assertEquals(stagingInventory[0].getImportStatus().getStatusCode(),
        runDetail.getValidationStatus().getStatusCode());
  }

  public void testSaveRunDetailsForStagingInventoryWithParentage() {
    createInbreds(new String[]{"A", "B"}, "17", "Corn", new String[]{"A/B", "B/A"});

    StagingInventoryHeader header = getStagingInventoryHeader( "Corn", userId, templateName, MaterialTypeConstants.HYBRID_LINES);
    StagingInventory inventory = createStagingInventoryForImport(header);

    try {
      importStagingInventory(header, inventory);

      inventory.setInventoryHeader(header);
      preprocessMainRecordAndParentageForBatchProcessing(inventory, StagingInventoryStatusConstants.NEW, userId);
      StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(inventory);

    assertNotNull(stagingInventoryRec);
    assertEquals(2, stagingInventoryRec.getStagingParentage().size());

    StagingInventory[] parentInventories = getParentInventories(stagingInventoryRec.getStagingParentage());

    assertNotNull(parentInventories);
    assertEquals(2, parentInventories.length);

    StagingInventory[] stagingInventory = new StagingInventory[]{stagingInventoryRec};

    BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

    helper.addRecords(stagingInventory);

    helper.saveRunHistory(); // This needs to be done before saving run details
    helper.saveRunDetails(); // Mass save of initially created run detail records
      appdaoSession.flush();

    RunDetail runDetail = ((MockBatchRunHistoryHelper) helper).fetchRunDetails(parentInventories[0]);
    RunHistory runHistory = ((MockBatchRunHistoryHelper) helper).fetchRunHistory();
    assertEquals(runHistory.getId(), runDetail.getRunHistory().getId());
    assertEquals(parentInventories[0].getId(), runDetail.getInventoryId());

    helper.setProcessExceptionMessage(parentInventories[0], "Not processed - validation error");
    parentInventories[0].setValidationMessage("Validation failed - not found in MIDAS");

    helper.setProcessExceptionMessage(stagingInventory[0], "Not Processed");
    stagingInventory[0].setValidationMessage("Validation failed - Parent validation failed");
    helper.setValidationInfo(stagingInventory[0]);

    helper.saveRunDetails(stagingInventory[0]);
      appdaoSession.flush();
      assertEquals("Not processed - validation error", runDetail.getProcessExceptionMsg());
      assertEquals(parentInventories[0].getValidationMessage(), runDetail.getValidationExceptionMsg());
      assertEquals(parentInventories[0].getImportStatus().getStatusCode(),
          runDetail.getValidationStatus().getStatusCode());
    } finally {
      destroyMidasTestData();
      // Rollback here. Otherwise the next call will hang when removing parentage.
      appdaoSession.getTransaction().rollback();
      removeStagingInventoryTestData();
    }
  }

  public void testRemoveRunDetailsForStagingInventoryWithParentage() {
    createInbreds(new String[]{"A", "B"}, "17", "Corn", new String[]{"A/B", "B/A"});

    StagingInventoryHeader header = getStagingInventoryHeader( "Corn", userId, templateName, MaterialTypeConstants.HYBRID_LINES);
    StagingInventory inventory = createStagingInventoryForImport(header);

    try {
      importStagingInventory(header, inventory);

      inventory.setInventoryHeader(header);
      preprocessMainRecordAndParentageForBatchProcessing(inventory, StagingInventoryStatusConstants.NEW, userId);
      StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(inventory);

      assertNotNull(stagingInventoryRec);
      assertEquals(2, stagingInventoryRec.getStagingParentage().size());

      StagingInventory[] parentInventories = getParentInventories(stagingInventoryRec.getStagingParentage());

      assertNotNull(parentInventories);
      assertEquals(2, parentInventories.length);

      StagingInventory[] stagingInventory = new StagingInventory[]{stagingInventoryRec};

      BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

      helper.addRecords(stagingInventory);

      helper.saveRunHistory(); // This needs to be done before saving run details
      helper.saveRunDetails(); // Mass save of initially created run detail records
      appdaoSession.flush();

      MockBatchRunHistoryHelper mockHelper = (MockBatchRunHistoryHelper) helper;

      assertNotNull(mockHelper.fetchRunDetails(stagingInventory[0]));
      assertNotNull(mockHelper.fetchRunDetails(parentInventories[0]));
      assertNotNull(mockHelper.fetchRunDetails(parentInventories[1]));

      helper.removeRunDetails(stagingInventory[0]);

      assertNull(mockHelper.fetchRunDetails(stagingInventory[0]));
      assertNull(mockHelper.fetchRunDetails(parentInventories[0]));
      assertNull(mockHelper.fetchRunDetails(parentInventories[1]));
    } finally {
      destroyMidasTestData();
      // Rollback here. Otherwise the next call will hang when removing parentage.
      appdaoSession.getTransaction().rollback();
      removeStagingInventoryTestData();
    }
  }

  public void testGetSetProcessExceptionMessage() {
    createInbreds(new String[]{"A", "B"}, "17", "Corn", new String[]{"A/B", "B/A"});

    StagingInventoryHeader header = getStagingInventoryHeader( "Corn", userId, templateName, MaterialTypeConstants.HYBRID_LINES);
    StagingInventory inventory = createStagingInventoryForImport(header);

    try {
      importStagingInventory(header, inventory);

      inventory.setInventoryHeader(header);
      preprocessMainRecordAndParentageForBatchProcessing(inventory, StagingInventoryStatusConstants.NEW, userId);
      StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(inventory);

      assertNotNull(stagingInventoryRec);
      assertEquals(2, stagingInventoryRec.getStagingParentage().size());

      StagingInventory[] parentInventories = getParentInventories(stagingInventoryRec.getStagingParentage());

      assertNotNull(parentInventories);
      assertEquals(2, parentInventories.length);

      StagingInventory[] stagingInventory = new StagingInventory[]{stagingInventoryRec};

      BatchRunHistoryHelper helper = new MockBatchRunHistoryHelper();

      helper.addRecords(stagingInventory);

      helper.saveRunHistory(); // This needs to be done before saving run details
      helper.saveRunDetails(); // Mass save of initially created run detail records
      appdaoSession.flush();

      RuntimeException runTimeException = new RuntimeException("Test RunTimeException Message");
      helper.setProcessExceptionMessage(stagingInventory[0], runTimeException);

      assertTrue(helper.getProcessExceptionMessage(stagingInventory[0]).indexOf(runTimeException.getMessage()) >= 0);
    } finally {
      destroyMidasTestData();
      // Rollback here. Otherwise the next call will hang when removing parentage.
      appdaoSession.getTransaction().rollback();
      removeStagingInventoryTestData();
    }
  }

  private StagingInventory createStagingInventoryForImport(StagingInventoryHeader header) {
    StagingInventory inventory = new StagingInventory();
    inventory.setInventoryHeader(header);
    inventory.setImportType(getImportTypeByAbbreviation(MaterialTypeConstants.HYBRID_FINISHED_LINES));
    inventory.setLineType(MaterialTypeConstants.HYBRID_LINES);
    inventory.setImportStatus(getImportStatusByStatusCode(StagingInventoryStatusConstants.NEW));
    inventory.setOrigin("A+B");
    inventory.setSource("ZZZ");
    inventory.setGermplasmOwner("17");
    inventory.setInventoryOwner("17");
    inventory.setFemaleParentSource("F SOURCE");
    inventory.setGermplasmOwnerOfFemaleParent("17");
    inventory.setMaleParentSource("M SOURCE");
    inventory.setGermplasmOwnerOfMaleParent("17");
    return inventory;
  }

  private StagingInventory[] getParentInventories(Set stagingParentage) {
    Iterator iterator = stagingParentage.iterator();
    List list = new ArrayList();
    while (iterator.hasNext()) {
      list.add(((StagingParentage) iterator.next()).getParentInventory());
    }

    return (list.size() > 0) ? (StagingInventory[]) list.toArray(new StagingInventory[0]) : null;
  }

  private long getRecordCountIncludingParents(StagingInventory[] stagingInventories) {
    long recordCount = stagingInventories.length;

    for (int i = 0; i < stagingInventories.length; i++) {
      Set spSet = stagingInventories[i].getStagingParentage();
      recordCount += (spSet != null) ? spSet.size() : 0;
    }

    return recordCount;
  }

  /**
   * @noinspection OverlyLongMethod,MagicNumber
   */
  private StagingInventory[] createStagingInventoriesWithParentage() {
    StagingInventory inv1 = new StagingInventory();
    inv1.setId(new Long(101));
    StagingInventory inv2 = new StagingInventory();
    inv2.setId(new Long(102));
    StagingInventory inv3 = new StagingInventory();
    inv3.setId(new Long(103));
    StagingInventory inv4 = new StagingInventory();
    inv4.setId(new Long(103101));
    StagingInventory inv5 = new StagingInventory();
    inv5.setId(new Long(103102));
    StagingInventory inv6 = new StagingInventory();
    inv6.setId(new Long(103103));
    StagingParentage sp1 = new StagingParentage();
    sp1.setChildInventory(inv3);
    sp1.setParentInventory(inv4);
    sp1.setMainInventory(inv3);
    sp1.setRecordLevel(new Long(1));
    sp1.setParentalRole("F");
    StagingParentage sp2 = new StagingParentage();
    sp2.setChildInventory(inv4);
    sp2.setParentInventory(inv5);
    sp2.setMainInventory(inv3);
    sp2.setRecordLevel(new Long(2));
    sp2.setParentalRole("F");
    StagingParentage sp3 = new StagingParentage();
    sp3.setChildInventory(inv5);
    sp3.setParentInventory(inv6);
    sp3.setMainInventory(inv3);
    sp3.setRecordLevel(new Long(3));
    sp3.setParentalRole("F");
    Set spSet = new HashSet();
    spSet.add(sp1);
    spSet.add(sp2);
    spSet.add(sp3);
    inv3.setStagingParentage(spSet);
    return new StagingInventory[]{inv1, inv2, inv3};
  }

  private void createInbreds(
      String[] pedigreeNames, String germplasmOwner, String cropName, String[] origins) {
    try {
      testHelper.createInbreds(pedigreeNames, germplasmOwner, cropName, origins);
      appdaoSession.getTransaction().commit();
    } finally {
      appdaoSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
      appdaoSession.beginTransaction();
      testHelper.setStagingSession(appdaoSession);
    }
  }

  private StagingInventoryHeader getStagingInventoryHeader(String cropName, String userId, String templateName, String importTypeAbbrev) {
    StagingInventoryHeader header = new StagingInventoryHeader();
    header.setCropName(cropName);
    header.setUserId(userId);
    header.setTemplateName(templateName);
    header.setImportType(getImportTypeByAbbreviation(importTypeAbbrev));
    return header;
  }

  private ImportType getImportTypeByAbbreviation(String importTypeAbbrev) {
    ImportType importType = new ImportType();
    importType.setAbbreviation(importTypeAbbrev);
    return importType;
  }

  private ImportStatus getImportStatusByStatusCode(String statusCode) {
    ImportStatus importStatus = new ImportStatus();
    importStatus.setStatusCode(statusCode);
    return importStatus;
  }

  private void importStagingInventory(StagingInventoryHeader inventoryHeader, StagingInventory inventory) {
    ImportPOSClient importPosClient = new ImportPOSClient();
    try {
      importPosClient.importStagingInventories(inventoryHeader, new StagingInventory[]{inventory});
      String errorResponse = importPosClient.getPOSErrorResponseMessage();
      assertTrue(StringUtils.isNullOrEmpty(errorResponse));
    } catch (Exception e) {
      e.printStackTrace();
      fail("Encountered unexpected exception - " + e);
    }
  }

  private StagingInventory getStagingInventoryWithParentage(
      StagingInventory inventory) {
    return testHelper.getStagingInventoryWithParentage(inventory.getInventoryHeader().getUserId(),
        inventory.getInventoryHeader().getCropName(), inventory.getInventoryHeader().getTemplateName());
  }

  private void preprocessMainRecordAndParentageForBatchProcessing(
      StagingInventory mainInventory, String statusCode,
      String userId) {
    testHelper.preprocessMainRecordAndParentageForBatchProcessing(mainInventory, statusCode, userId);
    appdaoSession.flush();
  }

  private void destroyMidasTestData() {
    testHelper.beginTransaction();
    testHelper.purgeMidasObjects();
    testHelper.endTransaction(true);
  }

  private void removeStagingInventoryTestData() {
    Session session = HibernateUtil.getSessionFactoryForStagingInventory()
        .openSession(); // This is okay as this should be done in a separate session
    session.beginTransaction();
    try {
      this.deleteStagingInventory(templateName, session);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    session.getTransaction().commit();
    session.close();
  }

  private void deleteStagingInventory(String templateName, Session session) {
    deleteFromRunDetail(session, templateName);
    deleteFromStagingParentage(session, templateName);
    deleteFromStagingInventory(session, templateName);
    deleteFromStagingInventoryHeader(session, templateName);
  }

  private void deleteFromRunDetail(org.hibernate.Session session, String templateName) {
    Query query = null;

    query = session.createQuery(
        "select rd " +
            "from RunDetail rd, StagingInventory si, StagingInventoryHeader ih " +
            "where ih.templateName = :templateName and si.inventoryHeader = ih and rd.inventoryId = si.id");
    query.setParameter("templateName", templateName);
    List runDetailsList = query.list();
    if (runDetailsList != null) {
      for (int i = 0; i < runDetailsList.size(); i++) {
        session.delete(runDetailsList.get(i));
      }
    }
    session.flush();
  }

  private void deleteFromStagingParentage(org.hibernate.Session session, String templateName) {
    Query query;

    query = session.createQuery(
        "select distinct si " +
            "from StagingParentage sp, StagingInventory si, StagingInventoryHeader ih " +
            "where ih.templateName = :templateName and si.inventoryHeader = ih and sp.mainInventory = si");
    query.setParameter("templateName", templateName);
    List stagingInventoryList = query.list();
    if (stagingInventoryList != null) {
      for (int i = 0; i < stagingInventoryList.size(); i++) {
        StagingInventory si = (StagingInventory) stagingInventoryList.get(i);
        session.delete(si);
      }
    }
    session.flush();
  }

  private void deleteFromStagingInventory(org.hibernate.Session session, String templateName) {
    Query query;
    List stagingInventoryList;

    query = session.createQuery(
        "select si " +
            "from StagingInventory si, StagingInventoryHeader ih " +
            "where ih.templateName = :templateName and si.inventoryHeader = ih");
    query.setParameter("templateName", templateName);
    stagingInventoryList = query.list();
    if (stagingInventoryList != null) {
      for (int i = 0; i < stagingInventoryList.size(); i++) {
        StagingInventory si = (StagingInventory) stagingInventoryList.get(i);
        session.delete(si);
      }
    }
    session.flush();
  }

  private void deleteFromStagingInventoryHeader(org.hibernate.Session session, String templateName) {
    List invHdrList = session.createCriteria(StagingInventoryHeader.class)
        .setFetchMode("stagingInventory", FetchMode.JOIN)
        .add(Restrictions.eq("templateName", templateName)).list();

    for (int i = 0; i < invHdrList.size(); i++) {
      StagingInventoryHeader invHdr = (StagingInventoryHeader) invHdrList.get(i);
      session.delete(invHdr);
    }

    session.flush();
  }

  class MockBatchRunHistoryHelper extends BatchRunHistoryHelper {
    public RunHistory fetchRunHistory() {
      return getRunHistory();
    }

    public RunDetail fetchRunDetails(StagingInventory stagingInventory) {
      return getRunDetails(stagingInventory);
    }

    public RunDetail[] fetchRunDetails() {
      return getRunDetails();
    }
  }

}