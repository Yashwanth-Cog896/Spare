/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmEventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.CodedIIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.IIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

import java.util.Date;
import java.util.Iterator;
import java.util.Random;

/**
 * Filename:    $RCSfile: CodedIIProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy
 * $    	 On:	$Date: 2009-06-05 14:08:02 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class CodedIIProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private String templateName;
    private Random random = new Random();

    public CodedIIProcessor_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventoryIntoMidasWithoutSubRecordsForBackCross() throws Exception {
        IIProcessor processor = new CodedIIProcessor();
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(1001));
        stagingInventory.setGeneration("BC2F3");
        stagingInventory.setGermplasmOwner("LT");
        stagingInventory.setLineage("@>0002>|0001.0002.");
        stagingInventory.setOrigin("A*3/B");
        stagingInventory.setLineType("Coded");
        stagingInventory.setInventoryOwner("LT");
        stagingInventory.setLineCode("XYZABC");
        stagingInventory.setPedigreeName("LT_XYZABC:0001.0002.");
        StagingInventoryHeader invHdr = new StagingInventoryHeader();
        invHdr.setCropName(CROP_NAME);
        invHdr.setUserId(userId);
        stagingInventory.setInventoryHeader(invHdr);
        stagingInventory.setSource("Test Source");
        stagingInventory.setApprovalProcessDate(new Date());
        stagingInventory.setApprovalRequestDate(new Date());
        stagingInventory.setValidationDate(new Date());
        stagingInventory.setAuthorityRequested("SSPEYY");
        stagingInventory.setAuthorityProcessed("SRKARNA");

        MockInventoryContext context = new MockInventoryContext(stagingInventory);
        MidasContext midasContext = processor.processInventory(context);
        session.getTransaction().rollback();

        assertMidasContext(midasContext, 1, 1, 1, 0);
    }

    public void testProcessInventoryIntoMidasWithoutSubRecordsForSimple() throws Exception {
        IIProcessor processor = new CodedIIProcessor();
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(1001));
        stagingInventory.setGeneration("F3");
        stagingInventory.setGermplasmOwner("LT");
        stagingInventory.setLineage("@.0001.|");
        stagingInventory.setOrigin("A/B");
        stagingInventory.setLineType("Finished");
        stagingInventory.setInventoryOwner("LT");
        stagingInventory.setLineCode("XYZABC");
        stagingInventory.setPedigreeName("LT_XYZABC");
        StagingInventoryHeader invHdr = new StagingInventoryHeader();
        invHdr.setCropName(CROP_NAME);
        invHdr.setUserId(userId);
        stagingInventory.setInventoryHeader(invHdr);
        stagingInventory.setSource("Test Source");
        stagingInventory.setApprovalProcessDate(new Date());
        stagingInventory.setApprovalRequestDate(new Date());
        stagingInventory.setValidationDate(new Date());
        stagingInventory.setAuthorityRequested("SSPEYY");
        stagingInventory.setAuthorityProcessed("SRKARNA");

        MockInventoryContext context = new MockInventoryContext(stagingInventory);
        MidasContext midasContext = processor.processInventory(context);
        session.getTransaction().rollback();

        assertMidasContext(midasContext, 1, 1, 1, 0);
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForBackCross() throws Exception {
        String generation = "BC6F3";
        String germplasmOwner = "LT";
        String lineage = "@>001>002>003>|004.005.006>007>008.009.";
        String origin = "A*7/B";
        String source = "A 7/B" + generation + lineage.replace('|', ' ');
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String recGpOrigin = "AZS/ASD";
        String recGpPedigreeName = "A";
        String recGpLineCode = "A";
        String f1GpBOrigin = "ZDF/ASD";
        String f1GpBPedigreeName = "B";
        String f1GpBLineCode = "B";

        Germplasm recGp = null;
        Germplasm f1GpB = null;
        try {
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(recGp, "Some Source", "INBRED", "|");

            f1GpB = appdaoTestHelper.createGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1GpB, "Some Source XYZ", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null, null, germplasmOwner,
                    germplasmOwner, MaterialTypeConstants.CODED_LINES, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;;;;;S12F&S12M", "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            IIProcessor processor = new CodedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 11, 3, 14, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForBackCrossWithExistingRecurrentParent() throws Exception {
        String generation = "BC6F3";
        String germplasmOwner = "LT";
        String lineage = "@>001>002>003>|004.005.006>007>008.009.";
        String origin = "A*7/B";
        String source = "A 7/B" + generation + lineage.replace('|', ' ');
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String recGpOrigin = "AZS/ASD";
        String recGpPedigreeName = "A";
        String recGpLineCode = "A";
        String f1GpBOrigin = "ZDF/ASD";
        String f1GpBPedigreeName = "B";
        String f1GpBLineCode = "B";

        Germplasm recGp = null;
        Germplasm f1GpB = null;
        try {
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(recGp, "Some Source", "INBRED", "|");
            appdaoTestHelper.createGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "INBRED", "|");

            f1GpB = appdaoTestHelper.createGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1GpB, "Some Source XYZ", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null, null, germplasmOwner,
                    germplasmOwner, MaterialTypeConstants.CODED_LINES, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;;;;;;S12F&S12M", "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);

            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            IIProcessor processor = new CodedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 11, 3, 13, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithSubRecordsForSimple() throws Exception {
        String generation = "F6";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.";
        String origin = "A/B";
        String source = origin + generation + lineage.replace('|', ' ');
        String lineCode = "XYZABC";
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String recGpOrigin = "AZS/ASD";
        String recGpPedigreeName = "A";
        String recGpLineCode = "A";
        String f1GpBOrigin = "ZDF/ASD";
        String f1GpBPedigreeName = "B";
        String f1GpBLineCode = "B";

        Germplasm recGp = null;
        Germplasm f1GpB = null;
        try {
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(recGp, "Some Source", "INBRED", "|");
            appdaoTestHelper.createGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "INBRED", "|");

            f1GpB = appdaoTestHelper.createGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1GpB, "Some Source XYZ", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, f1SubType, origin, source, null, null, null, null, germplasmOwner,
                    germplasmOwner, MaterialTypeConstants.CODED_LINES, userId, generation, lineage, lineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;S6F&S6M", "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);

            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            IIProcessor processor = new CodedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 6, 3, 8, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimple() throws Exception {
        String generation = "F6";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.";
        String dupGpOrigin = "A/B";
        String dupGpLineCode = "XYZABC";
        String dupGpPedigreeName = germplasmOwner + "_" + dupGpLineCode;
        String source = dupGpOrigin + generation + lineage.replace('|', ' ');
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String dupLineType = MaterialTypeConstants.CODED_LINES;
        String recGpOrigin = "AZS/ASD";
        String recGpPedigreeName = "A";
        String recGpLineCode = "A";
        String f1GpBOrigin = "ZDF/ASD";
        String f1GpBPedigreeName = "B";
        String f1GpBLineCode = "B";

        Germplasm recGp = null;
        Germplasm dupGp = null;
        Germplasm f1GpB = null;
        try {
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(dupLineType, dupGpLineCode, dupGpOrigin, dupGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(recGp, "Some Source", "INBRED", "|");
            appdaoTestHelper.createGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "INBRED", "|");

            dupGp = appdaoTestHelper
                    .createGermplasm(dupLineType, dupGpLineCode, dupGpOrigin, dupGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(dupGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F4", "@.1.2.|");

            f1GpB = appdaoTestHelper.createGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1GpB, "Some Source XYZ", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, f1SubType, dupGpOrigin, source, null, null, null, null, germplasmOwner,
                    germplasmOwner, MaterialTypeConstants.CODED_LINES, userId, generation, lineage, dupGpLineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;;;;S6F&S6M", "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);

            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            IIProcessor processor = new CodedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 5, 3, 7, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(dupLineType, dupGpLineCode, dupGpOrigin, dupGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithDuplicateSubRecordsForSimpleWithSomeUserSpecifiedSources() throws
            Exception {
        String generation = "F6";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.";
        String dupGpOrigin = "A/B";
        String dupGpLineCode = "XYZABC";
        String dupGpPedigreeName = germplasmOwner + "_" + dupGpLineCode;
        String source = dupGpOrigin + generation + lineage.replace('|', ' ');
        String f1SubType = MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES;
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String dupGpLineType = MaterialTypeConstants.CODED_LINES;
        String recGpOrigin = "AZS/ASD";
        String recGpPedigreeName = "A";
        String recGpLineCode = "A";
        String f1GpBOrigin = "ZDF/ASD";
        String f1GpBPedigreeName = "B";
        String f1GpBLineCode = "B";

        Germplasm recGp = null;
        Germplasm dupGp = null;
        Germplasm f1GpB = null;
        try {
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(dupGpLineType, dupGpLineCode, dupGpOrigin, dupGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);

            recGp = appdaoTestHelper.createGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(recGp, "Some Source", "INBRED", "|");
            appdaoTestHelper.createGeneticMaterial(recGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "INBRED", "|");

            dupGp = appdaoTestHelper
                    .createGermplasm(dupGpLineType, dupGpLineCode, dupGpOrigin, dupGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(dupGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F4", "@.1.2.|");

            f1GpB = appdaoTestHelper.createGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGeneticMaterial(f1GpB, "Some Source XYZ", "INBRED", "|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, f1SubType, dupGpOrigin, source, null, null, null, null, germplasmOwner,
                    germplasmOwner, MaterialTypeConstants.CODED_LINES, userId, generation, lineage, dupGpLineCode, null, null, null,
                    StagingInventoryStatusConstants.NEW, ";;S3;;;S6F&S6M", "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);

            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            IIProcessor processor = new CodedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 5, 4, 7, stagingInventoryRec.getStagingParentage().size());
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(dupGpLineType, dupGpLineCode, dupGpOrigin, dupGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }


    public void testProcessInventoryIntoMidasWithEvents() throws Exception {
        String generation = "F6";
        String germplasmOwner = "LT";
        String lineage = "@.1.2.|3.4.";
        String origin = "A/B";
        String lineCode = "XYZABC";
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String recGpOrigin = "AZS/ASD";
        String recGpPedigreeName = "A";
        String recGpLineCode = "A";
        String f1GpBOrigin = "ZDF/ASD";
        String f1GpBPedigreeName = "B";
        String f1GpBLineCode = "B";
        String eventName = "EVENT-FinishedIIProcessor_UT".toUpperCase();
        String eventConstructName = "CONST-FinishedIIProcessor_UT".toUpperCase();
        String sourceStr = "SRC " + eventName;
        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        EventConstruct expectedEventConstruct = null;
        try {
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm femaleGP = appdaoTestHelper.createGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, germplasmOwner, CROP_NAME);
            appdaoTestHelper.createGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, germplasmOwner, CROP_NAME);

            EventConstruct eventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            expectedEventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "T");

            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), eventConstruct.getEventConstructId());
            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), expectedEventConstruct.getEventConstructId());
            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, MaterialTypeConstants.CODED_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.CODED_LINES, origin, sourceStr,
                    null, null, null, null, germplasmOwner, germplasmOwner, MaterialTypeConstants.CODED_LINES, userId, generation,
                    lineage, lineCode, null, null, null, StagingInventoryStatusConstants.NEW, null, "N", eventName);

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);

            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            IIProcessor processor = new CodedIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 1, 1, 1, 0);

            Germplasm[] germplasms = midasContext.getGermplasm();
            assertEquals(1, germplasms[0].getGermplasmEventConstruct().size());
            Iterator germplasmEventConstructIter = germplasms[0].getGermplasmEventConstruct().iterator();
            GermplasmEventConstruct actualGermplasmEventConstruct = (GermplasmEventConstruct) germplasmEventConstructIter.next();
            assertEquals(actualGermplasmEventConstruct.getEventConstruct().getEventConstructId(), expectedEventConstruct.getEventConstructId());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(lineType, recGpLineCode, recGpOrigin, recGpPedigreeName, CROP_NAME);
            purgeGermplasm(lineType, f1GpBLineCode, f1GpBOrigin, f1GpBPedigreeName, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }
}