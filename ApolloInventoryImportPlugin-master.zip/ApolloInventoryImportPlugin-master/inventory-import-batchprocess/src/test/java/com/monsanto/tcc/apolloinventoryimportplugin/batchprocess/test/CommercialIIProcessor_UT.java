/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.CommercialIIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.InventoryImportProcessorException;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.InventoryImportGlobalXmlSerializerProvider;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.XmlSerializer;

import java.util.Date;
import java.util.Random;

/**
 * Filename: $Id: CommercialIIProcessor_UT.java,v 1.2 2009-06-05 14:08:03 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class CommercialIIProcessor_UT extends ProcessorTestCase {
    private String templateName;
    private Random random = new Random();

    public CommercialIIProcessor_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventoryIntoMidasWhereParentsDoNotPreExist() {
        try {
            StagingInventory stagingInventory = createApprovedStagingInventoryWhereParentsDoNotPreExist();
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setAuthorityRequested(userId);
            stagingInventory.setAuthorityProcessed(userId);
            stagingInventory.setValidationDate(new Date());
            String[] origins = stagingInventory.getOrigin().split("\\+");
            String femaleOrigin = origins[0];
            String maleOrigin = origins[1];
            CommercialIIProcessor iiProcessor = new CommercialIIProcessor();

            MockInventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = iiProcessor.processInventory(context);
            assertNotNull(midasContext);
            assertMidasContext(midasContext, 0, 3, 3, 2);

            Inventory femaleParentInventory = midasContext.getInventory()[0];
            assertNotNull(femaleParentInventory);
            assertTrue(femaleParentInventory.getInventoryId().longValue() > 0);
            assertEquals("T", femaleParentInventory.getIsActive());

            Inventory maleParentInventory = midasContext.getInventory()[1];
            assertNotNull(maleParentInventory);
            assertTrue(maleParentInventory.getInventoryId().longValue() > 0);
            assertEquals("T", maleParentInventory.getIsActive());

            Inventory mainRecordInventory = midasContext.getInventory()[2];
            assertNotNull(mainRecordInventory);
            assertTrue(mainRecordInventory.getInventoryId().longValue() > 0);
            assertEquals("T", mainRecordInventory.getIsActive());

            GeneticMaterial mainGenMat = midasContext.getGeneticMatterial()[0];
            assertEquals(mainRecordInventory.getGeneticMaterial().getGeneticMaterialId(), mainGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getSource(), mainGenMat.getSourceStr());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(stagingInventory.getOrigin(), mainGenMat.getGermplasm().getOrigin());
            assertEquals("F1", mainGenMat.getGeneration());
            assertNull(mainGenMat.getLineage());

            GeneticMaterial femaleParentGenMat = midasContext.getGeneticMatterial()[1];
            assertEquals(femaleParentInventory.getGeneticMaterial().getGeneticMaterialId(), femaleParentGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getFemaleParentSource(), femaleParentGenMat.getSourceStr());
            assertEquals(femaleOrigin, femaleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", femaleParentGenMat.getGeneration());
            assertEquals("|", femaleParentGenMat.getLineage());

            GeneticMaterial maleParentGenMat = midasContext.getGeneticMatterial()[2];
            assertEquals(maleParentInventory.getGeneticMaterial().getGeneticMaterialId(), maleParentGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getMaleParentSource(), maleParentGenMat.getSourceStr());
            assertEquals(maleOrigin, maleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", maleParentGenMat.getGeneration());
            assertEquals("|", maleParentGenMat.getLineage());
        } catch (DeserializationException e) {
            e.printStackTrace();
            fail("Deserialization of stagingInventory failed!");
        } catch (InventoryImportProcessorException e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        } finally {
            session.getTransaction().rollback();
        }
    }

    public void testProcessInventoryIntoMidasWhereMaleParentsPreExists() {
        try {
            StagingInventory stagingInventory = createApprovedStagingInventoryWhereMaleParentPreExists();
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setAuthorityRequested(userId);
            stagingInventory.setAuthorityProcessed(userId);
            stagingInventory.setValidationDate(new Date());
            String[] origins = stagingInventory.getOrigin().split("\\+");
            String femaleOrigin = origins[0];
            CommercialIIProcessor iiProcessor = new CommercialIIProcessor();

            MockInventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = iiProcessor.processInventory(context);
            assertNotNull(midasContext);
            assertMidasContext(midasContext, 0, 2, 2, 2);

            Inventory femaleParentInventory = midasContext.getInventory()[0];
            assertNotNull(femaleParentInventory);
            assertTrue(femaleParentInventory.getInventoryId().longValue() > 0);
            assertEquals("T", femaleParentInventory.getIsActive());

            Inventory mainInventory = midasContext.getInventory()[1];
            assertNotNull(mainInventory);
            assertTrue(mainInventory.getInventoryId().longValue() > 0);
            assertEquals("T", mainInventory.getIsActive());

            GeneticMaterial mainGenMat = midasContext.getGeneticMatterial()[0];
            assertEquals(stagingInventory.getSource(), mainGenMat.getSourceStr());
            assertEquals(mainInventory.getGeneticMaterial().getGeneticMaterialId(), mainGenMat.getGeneticMaterialId());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(stagingInventory.getOrigin(), mainGenMat.getGermplasm().getOrigin());
            assertEquals("F1", mainGenMat.getGeneration());
            assertNull(mainGenMat.getLineage());

            GeneticMaterial femaleParentGenMat = midasContext.getGeneticMatterial()[1];
            assertEquals(femaleParentInventory.getGeneticMaterial().getGeneticMaterialId(), femaleParentGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getFemaleParentSource(), femaleParentGenMat.getSourceStr());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(femaleOrigin, femaleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", femaleParentGenMat.getGeneration());
            assertEquals("|", femaleParentGenMat.getLineage());
        } catch (DeserializationException e) {
            e.printStackTrace();
            fail("Deserialization of stagingInventory failed!");
        } catch (InventoryImportProcessorException e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        } finally {
            session.getTransaction().rollback();
        }
    }

    public void testProcessInventoryIntoMidasWhereFemaleParentsPreExists() {
        try {
            StagingInventory stagingInventory = createApprovedStagingInventoryWhereFemaleParentsPreExists();
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setAuthorityRequested(userId);
            stagingInventory.setAuthorityProcessed(userId);
            stagingInventory.setValidationDate(new Date());
            String[] origins = stagingInventory.getOrigin().split("\\+");
            String maleOrigin = origins[1];
            CommercialIIProcessor iiProcessor = new CommercialIIProcessor();

            MockInventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = iiProcessor.processInventory(context);
            assertNotNull(midasContext);
            assertMidasContext(midasContext, 0, 2, 2, 2);

            Inventory maleParentInventory = midasContext.getInventory()[0];
            assertNotNull(maleParentInventory);
            assertTrue(maleParentInventory.getInventoryId().longValue() > 0);
            assertEquals("T", maleParentInventory.getIsActive());

            Inventory mainInventory = midasContext.getInventory()[1];
            assertNotNull(mainInventory);
            assertTrue(mainInventory.getInventoryId().longValue() > 0);
            assertEquals("T", mainInventory.getIsActive());

            GeneticMaterial mainGenMat = midasContext.getGeneticMatterial()[0];
            assertEquals(stagingInventory.getSource(), mainGenMat.getSourceStr());
            assertEquals(mainInventory.getGeneticMaterial().getGeneticMaterialId(), mainGenMat.getGeneticMaterialId());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(stagingInventory.getOrigin(), mainGenMat.getGermplasm().getOrigin());
            assertEquals("F1", mainGenMat.getGeneration());
            assertNull(mainGenMat.getLineage());

            GeneticMaterial maleParentGenMat = midasContext.getGeneticMatterial()[1];
            assertEquals(maleParentInventory.getGeneticMaterial().getGeneticMaterialId(), maleParentGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getMaleParentSource(), maleParentGenMat.getSourceStr());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(maleOrigin, maleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", maleParentGenMat.getGeneration());
            assertEquals("|", maleParentGenMat.getLineage());
        } catch (DeserializationException e) {
            e.printStackTrace();
            fail("Deserialization of stagingInventory failed!");
        } catch (InventoryImportProcessorException e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        } finally {
            session.getTransaction().rollback();
        }
    }

    public void testProcessInventoryIntoMidasWhereFemaleParentSourceIsNullSourceGetsSetToManufacturingSourceAndIsAutogenIsSetToTrue() {
        try {
            StagingInventory stagingInventory = createApprovedStagingInventoryWhereParentsDoNotPreExistFemaleParentSourceIsEmpty();
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setAuthorityRequested(userId);
            stagingInventory.setAuthorityProcessed(userId);
            stagingInventory.setValidationDate(new Date());
            String[] origins = stagingInventory.getOrigin().split("\\+");
            String femaleOrigin = origins[0];
            String maleOrigin = origins[1];
            CommercialIIProcessor processor = new CommercialIIProcessor();

            MockInventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = processor.processInventory(context);
            assertNotNull(midasContext);
            assertMidasContext(midasContext, 0, 2, 3, 2);

            Inventory inventoryForMaleParent = midasContext.getInventory()[0];
            assertNotNull(inventoryForMaleParent);
            assertTrue(inventoryForMaleParent.getInventoryId().longValue() > 0);
            assertEquals("T", inventoryForMaleParent.getIsActive());

            Inventory inventoryForMainRecord = midasContext.getInventory()[1];
            assertNotNull(inventoryForMainRecord);
            assertTrue(inventoryForMainRecord.getInventoryId().longValue() > 0);
            assertEquals("T", inventoryForMainRecord.getIsActive());

            GeneticMaterial mainGenMat = midasContext.getGeneticMatterial()[0];
            assertEquals(inventoryForMainRecord.getGeneticMaterial().getGeneticMaterialId(), mainGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getSource(), mainGenMat.getSourceStr());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(stagingInventory.getOrigin(), mainGenMat.getGermplasm().getOrigin());
            assertEquals("F1", mainGenMat.getGeneration());
            assertNull(mainGenMat.getLineage());

            GeneticMaterial femaleParentGenMat = midasContext.getGeneticMatterial()[1];
            assertEquals(SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE, femaleParentGenMat.getSourceStr());
            assertEquals(femaleOrigin, femaleParentGenMat.getGermplasm().getOrigin());
            assertEquals("T", femaleParentGenMat.getIsAutogen());
            assertEquals("INBRED", femaleParentGenMat.getGeneration());
            assertEquals("|", femaleParentGenMat.getLineage());

            GeneticMaterial maleParentGenMat = midasContext.getGeneticMatterial()[2];
            assertEquals(inventoryForMaleParent.getGeneticMaterial().getGeneticMaterialId(), maleParentGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getMaleParentSource(), maleParentGenMat.getSourceStr());
            assertEquals(maleOrigin, maleParentGenMat.getGermplasm().getOrigin());
            assertEquals("F", maleParentGenMat.getIsAutogen());
            assertEquals("INBRED", maleParentGenMat.getGeneration());
            assertEquals("|", maleParentGenMat.getLineage());
        } catch (DeserializationException e) {
            e.printStackTrace();
            fail("Deserialization of stagingInventory failed!");
        } catch (InventoryImportProcessorException e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        } finally {
            session.getTransaction().rollback();
        }
    }

    public void testProcessInventoryIntoMidasWhereMaleParentSourceIsNullSourceGetsSetToManufacturingSourceAndIsAutogenIsSetToTrue() {
        try {
            StagingInventory stagingInventory = createApprovedStagingInventoryWhereParentsDoNotPreExistMaleParentSourceIsEmpty();
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setAuthorityRequested(userId);
            stagingInventory.setAuthorityProcessed(userId);
            stagingInventory.setValidationDate(new Date());
            String[] origins = stagingInventory.getOrigin().split("\\+");
            String femaleOrigin = origins[0];
            String maleOrigin = origins[1];
            CommercialIIProcessor processor = new CommercialIIProcessor();

            MockInventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = processor.processInventory(context);
            assertNotNull(midasContext);
            assertMidasContext(midasContext, 0, 2, 3, 2);

            Inventory inventoryForFemaleParent = midasContext.getInventory()[0];
            assertNotNull(inventoryForFemaleParent);
            assertTrue(inventoryForFemaleParent.getInventoryId().longValue() > 0);
            assertEquals("T", inventoryForFemaleParent.getIsActive());

            Inventory inventoryForMainRecord = midasContext.getInventory()[1];
            assertNotNull(inventoryForMainRecord);
            assertTrue(inventoryForMainRecord.getInventoryId().longValue() > 0);
            assertEquals("T", inventoryForMainRecord.getIsActive());

            GeneticMaterial mainGenMat = midasContext.getGeneticMatterial()[0];
            assertEquals(stagingInventory.getSource(), mainGenMat.getSourceStr());
            assertEquals(inventoryForMainRecord.getGeneticMaterial().getGeneticMaterialId(), mainGenMat.getGeneticMaterialId());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(stagingInventory.getOrigin(), mainGenMat.getGermplasm().getOrigin());
            assertEquals("F1", mainGenMat.getGeneration());
            assertNull(mainGenMat.getLineage());

            GeneticMaterial femaleParentGenMat = midasContext.getGeneticMatterial()[1];
            assertEquals(inventoryForFemaleParent.getGeneticMaterial().getGeneticMaterialId(), femaleParentGenMat.getGeneticMaterialId());
            assertEquals(stagingInventory.getFemaleParentSource(), femaleParentGenMat.getSourceStr());
            assertEquals("F", femaleParentGenMat.getIsAutogen());
            assertEquals(femaleOrigin, femaleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", femaleParentGenMat.getGeneration());
            assertEquals("|", femaleParentGenMat.getLineage());

            GeneticMaterial maleParentGenMat = midasContext.getGeneticMatterial()[2];
            assertEquals(SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE, maleParentGenMat.getSourceStr());
            assertEquals("T", maleParentGenMat.getIsAutogen());
            assertEquals(maleOrigin, maleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", maleParentGenMat.getGeneration());
            assertEquals("|", maleParentGenMat.getLineage());
        } catch (DeserializationException e) {
            e.printStackTrace();
            fail("Deserialization of stagingInventory failed!");
        } catch (InventoryImportProcessorException e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        } finally {
            session.getTransaction().rollback();
        }
    }

    public void testProcessInventoryIntoMidasWhereBothParentSourcesAreNullBothSourcesGetSetToManufacturingSourceAndIsAutogenIsSetToTrue() {
        try {
            StagingInventory stagingInventory = createApprovedStagingInventoryWhereParentsDoNotPreExistBothParentSourcesAreEmpty();
            stagingInventory.setApprovalProcessDate(new Date());
            stagingInventory.setApprovalRequestDate(new Date());
            stagingInventory.setAuthorityRequested(userId);
            stagingInventory.setAuthorityProcessed(userId);
            stagingInventory.setValidationDate(new Date());
            String[] origins = stagingInventory.getOrigin().split("\\+");
            String femaleOrigin = origins[0];
            String maleOrigin = origins[1];
            CommercialIIProcessor processor = new CommercialIIProcessor();

            MockInventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = processor.processInventory(context);
            assertNotNull(midasContext);
            assertMidasContext(midasContext, 0, 1, 3, 2);

            Inventory midasInventory = midasContext.getInventory()[0];
            assertNotNull(midasInventory);
            assertTrue(midasInventory.getInventoryId().longValue() > 0);
            assertEquals("T", midasInventory.getIsActive());

            GeneticMaterial mainGenMat = midasContext.getGeneticMatterial()[0];
            assertEquals(stagingInventory.getSource(), mainGenMat.getSourceStr());
            assertEquals(midasInventory.getGeneticMaterial().getGeneticMaterialId(), mainGenMat.getGeneticMaterialId());
            assertEquals("F", mainGenMat.getIsAutogen());
            assertEquals(stagingInventory.getOrigin(), mainGenMat.getGermplasm().getOrigin());
            assertEquals("F1", mainGenMat.getGeneration());
            assertNull(mainGenMat.getLineage());

            GeneticMaterial femaleParentGenMat = midasContext.getGeneticMatterial()[1];
            assertEquals(SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE, femaleParentGenMat.getSourceStr());
            assertEquals("T", femaleParentGenMat.getIsAutogen());
            assertEquals(femaleOrigin, femaleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", femaleParentGenMat.getGeneration());
            assertEquals("|", femaleParentGenMat.getLineage());

            GeneticMaterial maleParentGenMat = midasContext.getGeneticMatterial()[2];
            assertEquals(SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE, maleParentGenMat.getSourceStr());
            assertEquals("T", maleParentGenMat.getIsAutogen());
            assertEquals(maleOrigin, maleParentGenMat.getGermplasm().getOrigin());
            assertEquals("INBRED", maleParentGenMat.getGeneration());
            assertEquals("|", maleParentGenMat.getLineage());
        } catch (DeserializationException e) {
            e.printStackTrace();
            fail("Deserialization of stagingInventory failed!");
        } catch (InventoryImportProcessorException e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        } finally {
            session.getTransaction().rollback();
        }
    }

    private StagingInventory createApprovedStagingInventoryWhereParentsDoNotPreExist() throws DeserializationException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<staginginventory xmlns=\"http://www.monsanto.com/inventoryimport/POS\">\n" +
                "<id>10028</id>\n" +
                "<productName>DK569IMI</productName>\n" +
                "<origin>2FACCIT+MBWZ</origin>\n" +
                "<lineType>Hybrid</lineType>\n" +
                "<source>test - happy path - ZZZZ</source>\n" +
                "<inventoryOwner>17</inventoryOwner>\n" +
                "<femaleParentSource>21200310140_ZZZZ</femaleParentSource>\n" +
                "<maleParentSource>ZM 2000 05 US IA AM BRPRO</maleParentSource>\n" +
                "<nsort1>0.0</nsort1>\n" +
                "<nsort2>0.0</nsort2>\n" +
                "<nsort3>0.0</nsort3>\n" +
                "<nsort4>0.0</nsort4>\n" +
                "<nsort5>0.0</nsort5>\n" +
                "<inventoryHeader>\n" +
                "<id>10025</id>\n" +
                "<userId>" + userId + "</userId>\n" +
                "<cropName>Corn</cropName>\n" +
                "<templateName>" + templateName + "</templateName>\n" +
                "</inventoryHeader>\n" +
                "<importStatus>\n" +
                "<id>10002</id>\n" +
                "<statusCode>Approved</statusCode>\n" +
                "<description>Approved</description>\n" +
                "</importStatus>\n" +
                "<importType>\n" +
                "<id>10008</id>\n" +
                "<abbreviation>Commercial</abbreviation>\n" +
                "<description>Commercial Products</description>\n" +
                "</importType>\n" +
                "</staginginventory>";

        XmlSerializer serializer = new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer();

        return (StagingInventory) serializer.fromXML(xmlString);
    }

    private StagingInventory createApprovedStagingInventoryWhereFemaleParentsPreExists() throws DeserializationException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<staginginventory xmlns=\"http://www.monsanto.com/inventoryimport/POS\">\n" +
                "<id>10028</id>\n" +
                "<productName>DK569IMI</productName>\n" +
                "<origin>2FACCIT+MBWZ</origin>\n" +
                "<lineType>Hybrid</lineType>\n" +
                "<source>test - happy path - ZZZZ</source>\n" +
                "<inventoryOwner>17</inventoryOwner>\n" +
                "<femaleParentSource>21200310140</femaleParentSource>\n" +
                "<maleParentSource>ZM 2000 05 US IA AM BRPRO</maleParentSource>\n" +
                "<nsort1>0.0</nsort1>\n" +
                "<nsort2>0.0</nsort2>\n" +
                "<nsort3>0.0</nsort3>\n" +
                "<nsort4>0.0</nsort4>\n" +
                "<nsort5>0.0</nsort5>\n" +
                "<inventoryHeader>\n" +
                "<id>10025</id>\n" +
                "<userId>" + userId + "</userId>\n" +
                "<cropName>Corn</cropName>\n" +
                "<templateName>" + templateName + "</templateName>\n" +
                "</inventoryHeader>\n" +
                "<importStatus>\n" +
                "<id>10002</id>\n" +
                "<statusCode>Approved</statusCode>\n" +
                "<description>Approved</description>\n" +
                "</importStatus>\n" +
                "<importType>\n" +
                "<id>10008</id>\n" +
                "<abbreviation>Commercial</abbreviation>\n" +
                "<description>Commercial Products</description>\n" +
                "</importType>\n" +
                "</staginginventory>";

        XmlSerializer serializer = new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer();

        return (StagingInventory) serializer.fromXML(xmlString);
    }

    private StagingInventory createApprovedStagingInventoryWhereMaleParentPreExists() throws DeserializationException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<staginginventory xmlns=\"http://www.monsanto.com/inventoryimport/POS\">\n" +
                "<id>10028</id>\n" +
                "<productName>DK569IMI</productName>\n" +
                "<origin>2FACCIT+MBWZ</origin>\n" +
                "<lineType>Hybrid</lineType>\n" +
                "<source>test - happy path - ZZZZ</source>\n" +
                "<inventoryOwner>17</inventoryOwner>\n" +
                "<femaleParentSource>21200310140_ZZZZ</femaleParentSource>\n" +
                "<maleParentSource>ZM 2000 05 US IA AM BRPRO 0011 00004 @ __ .</maleParentSource>\n" +
                "<nsort1>0.0</nsort1>\n" +
                "<nsort2>0.0</nsort2>\n" +
                "<nsort3>0.0</nsort3>\n" +
                "<nsort4>0.0</nsort4>\n" +
                "<nsort5>0.0</nsort5>\n" +
                "<inventoryHeader>\n" +
                "<id>10025</id>\n" +
                "<userId>" + userId + "</userId>\n" +
                "<cropName>Corn</cropName>\n" +
                "<templateName>" + templateName + "</templateName>\n" +
                "</inventoryHeader>\n" +
                "<importStatus>\n" +
                "<id>10002</id>\n" +
                "<statusCode>Approved</statusCode>\n" +
                "<description>Approved</description>\n" +
                "</importStatus>\n" +
                "<importType>\n" +
                "<id>10008</id>\n" +
                "<abbreviation>Commercial</abbreviation>\n" +
                "<description>Commercial Products</description>\n" +
                "</importType>\n" +
                "</staginginventory>";

        XmlSerializer serializer = new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer();

        return (StagingInventory) serializer.fromXML(xmlString);
    }

    private StagingInventory createApprovedStagingInventoryWhereParentsDoNotPreExistFemaleParentSourceIsEmpty() throws DeserializationException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<staginginventory xmlns=\"http://www.monsanto.com/inventoryimport/POS\">\n" +
                "<id>10028</id>\n" +
                "<productName>DK569IMI</productName>\n" +
                "<origin>2FACCIT+MBWZ</origin>\n" +
                "<lineType>Hybrid</lineType>\n" +
                "<source>test - happy path - ZZZZ</source>\n" +
                "<inventoryOwner>17</inventoryOwner>\n" +
                "<femaleParentSource></femaleParentSource>\n" +
                "<maleParentSource>ZM 2000 05 US IA AM BRPRO</maleParentSource>\n" +
                "<nsort1>0.0</nsort1>\n" +
                "<nsort2>0.0</nsort2>\n" +
                "<nsort3>0.0</nsort3>\n" +
                "<nsort4>0.0</nsort4>\n" +
                "<nsort5>0.0</nsort5>\n" +
                "<inventoryHeader>\n" +
                "<id>10025</id>\n" +
                "<userId>" + userId + "</userId>\n" +
                "<cropName>Corn</cropName>\n" +
                "<templateName>" + templateName + "</templateName>\n" +
                "</inventoryHeader>\n" +
                "<importStatus>\n" +
                "<id>10002</id>\n" +
                "<statusCode>Approved</statusCode>\n" +
                "<description>Approved</description>\n" +
                "</importStatus>\n" +
                "<importType>\n" +
                "<id>10008</id>\n" +
                "<abbreviation>Commercial</abbreviation>\n" +
                "<description>Commercial Products</description>\n" +
                "</importType>\n" +
                "</staginginventory>";

        XmlSerializer serializer = new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer();

        return (StagingInventory) serializer.fromXML(xmlString);
    }

    private StagingInventory createApprovedStagingInventoryWhereParentsDoNotPreExistMaleParentSourceIsEmpty() throws DeserializationException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<staginginventory xmlns=\"http://www.monsanto.com/inventoryimport/POS\">\n" +
                "<id>10028</id>\n" +
                "<productName>DK569IMI</productName>\n" +
                "<origin>2FACCIT+MBWZ</origin>\n" +
                "<lineType>Hybrid</lineType>\n" +
                "<source>test - happy path - ZZZZ</source>\n" +
                "<inventoryOwner>17</inventoryOwner>\n" +
                "<femaleParentSource>21200310140_ZZZZ</femaleParentSource>\n" +
                "<maleParentSource></maleParentSource>\n" +
                "<nsort1>0.0</nsort1>\n" +
                "<nsort2>0.0</nsort2>\n" +
                "<nsort3>0.0</nsort3>\n" +
                "<nsort4>0.0</nsort4>\n" +
                "<nsort5>0.0</nsort5>\n" +
                "<inventoryHeader>\n" +
                "<id>10025</id>\n" +
                "<userId>" + userId + "</userId>\n" +
                "<cropName>Corn</cropName>\n" +
                "<templateName>" + templateName + "</templateName>\n" +
                "</inventoryHeader>\n" +
                "<importStatus>\n" +
                "<id>10002</id>\n" +
                "<statusCode>Approved</statusCode>\n" +
                "<description>Approved</description>\n" +
                "</importStatus>\n" +
                "<importType>\n" +
                "<id>10008</id>\n" +
                "<abbreviation>Commercial</abbreviation>\n" +
                "<description>Commercial Products</description>\n" +
                "</importType>\n" +
                "</staginginventory>";

        XmlSerializer serializer = new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer();

        return (StagingInventory) serializer.fromXML(xmlString);
    }

    private StagingInventory createApprovedStagingInventoryWhereParentsDoNotPreExistBothParentSourcesAreEmpty() throws DeserializationException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<staginginventory xmlns=\"http://www.monsanto.com/inventoryimport/POS\">\n" +
                "<id>10028</id>\n" +
                "<productName>DK569IMI</productName>\n" +
                "<origin>2FACCIT+MBWZ</origin>\n" +
                "<lineType>Hybrid</lineType>\n" +
                "<source>test - happy path - ZZZZ</source>\n" +
                "<inventoryOwner>17</inventoryOwner>\n" +
                "<femaleParentSource></femaleParentSource>\n" +
                "<maleParentSource></maleParentSource>\n" +
                "<nsort1>0.0</nsort1>\n" +
                "<nsort2>0.0</nsort2>\n" +
                "<nsort3>0.0</nsort3>\n" +
                "<nsort4>0.0</nsort4>\n" +
                "<nsort5>0.0</nsort5>\n" +
                "<inventoryHeader>\n" +
                "<id>10025</id>\n" +
                "<userId>" + userId + "</userId>\n" +
                "<cropName>Corn</cropName>\n" +
                "<templateName>" + templateName + "</templateName>\n" +
                "</inventoryHeader>\n" +
                "<importStatus>\n" +
                "<id>10002</id>\n" +
                "<statusCode>Approved</statusCode>\n" +
                "<description>Approved</description>\n" +
                "</importStatus>\n" +
                "<importType>\n" +
                "<id>10008</id>\n" +
                "<abbreviation>Commercial</abbreviation>\n" +
                "<description>Commercial Products</description>\n" +
                "</importType>\n" +
                "</staginginventory>";

        XmlSerializer serializer = new InventoryImportGlobalXmlSerializerProvider().getXmlSerializer();

        return (StagingInventory) serializer.fromXML(xmlString);
    }
}
