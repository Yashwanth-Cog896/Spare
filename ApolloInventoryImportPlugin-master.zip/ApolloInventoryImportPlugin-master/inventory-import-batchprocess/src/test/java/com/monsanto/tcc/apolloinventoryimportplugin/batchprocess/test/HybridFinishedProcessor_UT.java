/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

import java.util.Iterator;
import java.util.Random;
import java.util.Set;

/**
 * Filename:    $RCSfile: HybridFinishedProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:08:02 $
 *
 * @author ddbrow5
 * @version $Revision: 1.30 $
 */
public class HybridFinishedProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String HYBRID = MaterialTypeConstants.HYBRID_LINES;
    private static final String SEGPOP = MaterialTypeConstants.SEGPOP_LINES;
    private static final String HYBRID_FINISHED = MaterialTypeConstants.HYBRID_FINISHED_LINES;
    private String templateName;
    private Random random = new Random();

    public HybridFinishedProcessor_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        templateName = this.getClass().getName() + random.nextInt();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testProcessInventory_NullInventoryThrowsException() throws Exception {
        try {
            IIProcessor processor = new HybridFinishedProcessor();
            processor.processInventory(null);
            fail("Expected IllegalStateException");
        }
        catch (IllegalStateException e) {
            assertEquals(HybridFinishedProcessor.INVENTORY_CANNOT_BE_NULL_MSG, e.getMessage());
        }
    }

    public void testHappyPathScenarioWithSimpleOrigin() throws Exception {
        String femaleInbredOrigin = "FXABC123";
        String femaleSource = "SOURCE FXABC123";
        String maleInbredOrigin = "MXABC123";
        String maleSource = "SOURCE MXABC123";
        String hybridOrigin = femaleInbredOrigin + "+" + maleInbredOrigin;
        String source = "SOURCE " + hybridOrigin;
        String owner = "17";

        try {
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            appdaoTestHelper.createInbred(femaleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbred(maleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                InventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(1, midasContext.getGermplasm().length);
                assertEquals(3, midasContext.getGeneticMatterial().length);
                assertEquals(3, midasContext.getInventory().length);
                assertEquals(2, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testHappyPathScenarioWithSimpleOriginWithMultipleMatchesOnFinishedGermplasm() throws Exception {
        String femaleInbredOrigin = "FXABC123";
        String femaleSource = "SOURCE FXABC123";
        String maleInbredOrigin = "MXABC123";
        String maleSource = "SOURCE MXABC123";
        String hybridOrigin = femaleInbredOrigin + "+" + maleInbredOrigin;
        String source = "SOURCE " + hybridOrigin;
        String owner = "17";

        GeneticMaterial gm2 = null;
        try {
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "XYZ/ABC", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            appdaoTestHelper.createInbred(femaleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");

            Germplasm gp1 = appdaoTestHelper.createInbred(maleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            GeneticMaterial gm1 = appdaoTestHelper.createGeneticMaterial(gp1, maleSource, "F4", "1.2.|3.|");

            Germplasm gp2 = appdaoTestHelper.createInbred(maleInbredOrigin, owner, CROP_NAME, "XYZ/ABC");
            gm2 = appdaoTestHelper.createGeneticMaterial(gp2, maleSource, "F4", "1.2.|3.|");
            GeneticMaterial gm3 = appdaoTestHelper.createGeneticMaterial(gp2, maleSource, "F4", "1.2.|3.|");
            GeneticMaterial gm4 = appdaoTestHelper.createGeneticMaterial(gp2, maleSource, "F4", "1.2.|3.|");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            InventoryContext context = new MockInventoryContext(stagingInventory);
            MidasContext midasContext = processor.processInventory(context);
            assertEquals(1, midasContext.getGermplasm().length);
            assertEquals(2, midasContext.getGeneticMatterial().length);
            assertEquals(2, midasContext.getInventory().length);
            assertEquals(2, midasContext.getParentage().length);

            Parentage[] parentages = midasContext.getParentage();
            GeneticMaterial inbredGMUsed = null;
            for (int i = 0; i < parentages.length; i++) {
                Parentage parentage = parentages[i];
                if (parentage.getParentGeneticMaterial().getSourceStr().equalsIgnoreCase(maleSource)) {
                    inbredGMUsed = parentage.getParentGeneticMaterial();
                }
            }
            assertGeneticMaterialEquals(gm2, inbredGMUsed);
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "XYZ/ABC", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testHappyPathScenarioWithSimpleOriginWithArchInventoryForDiffOwner() throws Exception {
        String femaleInbredOrigin = "FXABC123";
        String femaleSource = "SOURCE FXABC123";
        String maleInbredOrigin = "MXABC123";
        String maleSource = "SOURCE MXABC123";
        String hybridOrigin = femaleInbredOrigin + "+" + maleInbredOrigin;
        String source = "SOURCE " + hybridOrigin;
        String owner = "17";

        try {
            purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm hybridGermplasm = appdaoTestHelper
                    .createGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, owner, CROP_NAME, "F", "T");
            GeneticMaterial hybridGenMat = appdaoTestHelper.createGeneticMaterial(hybridGermplasm, source, "F1", null);
            appdaoTestHelper.createInventory(hybridGenMat, "T", owner);

            appdaoTestHelper.createInbred(femaleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbred(maleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, "16", owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                InventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(0, midasContext.getGermplasm().length);
                assertEquals(2, midasContext.getGeneticMatterial().length);
                assertEquals(3, midasContext.getInventory().length);
                assertEquals(2, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testHappyPathScenarioWithSimpleOriginWithExistingSourceOnMatchingUnfinishedOrigin() throws Exception {
        String femaleInbredOrigin = "FXABC123";
        String femaleSource = "SOURCE FXABC123";
        String maleInbredOrigin = "MXABC123";
        String maleSource = "SOURCE MXABC123";
        String hybridOrigin = femaleInbredOrigin + "+" + maleInbredOrigin;
        String source = "SOURCE " + hybridOrigin;
        String owner = "17";

        try {
            purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm hybridGermplasm = appdaoTestHelper
                    .createGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, owner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(hybridGermplasm, source, "F1", null);

            appdaoTestHelper.createInbred(femaleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbred(maleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, "16", owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                InventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(1, midasContext.getGermplasm().length);
                assertEquals(3, midasContext.getGeneticMatterial().length);
                assertEquals(3, midasContext.getInventory().length);
                assertEquals(2, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(HYBRID, null, hybridOrigin, hybridOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testHappyPathScenarioWithAComplexOrigin() throws Exception {
        String[] inbreds = new String[]{"INB1", "INB2", "INB3", "INB4", "INB5", "INB6", "INB7", "INB8"};
        String[] inbredOrigins = new String[]{"A/B", "B/A", "C/D", "D/C", "AA/BB", "BB/AA", "CC/DD", "DD/CC"};
        String hybridOrigin =
                inbreds[0] + "+" + inbreds[1] + "++" + inbreds[2] + "+3+" + inbreds[3] + "+4+" + inbreds[4] + "+3+" +
                        inbreds[5] + "++" + inbreds[6] + "+" + inbreds[7];
        String femaleSource = "SOURCE " + inbreds[0] + "+" + inbreds[1] + "++" + inbreds[2] + "+3+" + inbreds[3];
        String maleSource = "SOURCE " + inbreds[4] + "+3+" +
                inbreds[5] + "++" + inbreds[6] + "+" + inbreds[7];
        String source = "SOURCE " + hybridOrigin;
        String owner = "17";

        try {
            for (int i = 0; i < inbreds.length; i++) {
                purgeGermplasm(FINISHED, inbreds[i], inbredOrigins[i], inbreds[i], CROP_NAME);
            }
            removeStagingInventoryTestData(templateName);

            appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                MockInventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(7, midasContext.getGermplasm().length);
                assertEquals(15, midasContext.getGeneticMatterial().length);
                assertEquals(3, midasContext.getInventory().length);
                assertEquals(14, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            for (int i = 0; i < inbreds.length; i++) {
                purgeGermplasm(FINISHED, inbreds[i], inbredOrigins[i], inbreds[i], CROP_NAME);
            }
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testHappyPathScenarioWithAComplexOrigin_WhenAHybridAlreadyHasParentage() throws Exception {
        String[] inbreds = new String[]{"INB1", "INB2", "INB3", "INB4", "INB5", "INB6", "INB7", "INB8"};
        String[] inbredOrigins = new String[]{"A/B", "B/A", "C/D", "D/C", "AA/BB", "BB/AA", "CC/DD", "DD/CC"};
        String hybridOrigin =
                inbreds[0] + "+" + inbreds[1] + "++" + inbreds[2] + "+3+" + inbreds[3] + "+4+" + inbreds[4] + "+3+" +
                        inbreds[5] + "++" + inbreds[6] + "+" + inbreds[7];
        String femaleSource = "SOURCE " + inbreds[0] + "+" + inbreds[1] + "++" + inbreds[2] + "+3+" + inbreds[3];
        String maleSource = "SOURCE " + inbreds[4] + "+3+" +
                inbreds[5] + "++" + inbreds[6] + "+" + inbreds[7];
        String source = "SOURCE " + hybridOrigin;
        String dupeOrigin = "INB1+INB2++INB3";
        String dupeOrigin2 = "INB1+INB2";
        String owner = "17";

        try {
            for (int i = 0; i < inbreds.length; i++) {
                String pedigreeName = inbreds[i];
                String origin = inbredOrigins[i];
                purgeGermplasm(FINISHED, pedigreeName, origin, pedigreeName, CROP_NAME);
            }
            purgeGermplasm(HYBRID, null, dupeOrigin, dupeOrigin, CROP_NAME);
            purgeGermplasm(HYBRID, null, dupeOrigin2, dupeOrigin2, CROP_NAME);
            removeStagingInventoryTestData(templateName);


            Germplasm[] inbredGermplasms = new Germplasm[inbreds.length];
            for (int i = 0; i < inbreds.length; i++) {
                String pedigreeName = inbreds[i];
                String origin = inbredOrigins[i];
                inbredGermplasms[i] = appdaoTestHelper
                        .createGermplasm(FINISHED, pedigreeName, origin, pedigreeName, owner, "Corn");
            }
            GeneticMaterial[] inbredGeneticMaterial = new GeneticMaterial[inbredGermplasms.length];
            for (int i = 0; i < inbredGermplasms.length; i++) {
                Germplasm inbredGermplasm = inbredGermplasms[i];
                String pedigreeName = inbreds[i];
                inbredGeneticMaterial[i] = appdaoTestHelper
                        .createInbredGeneticMaterial(inbredGermplasm, "SOME SOURCE - " + pedigreeName);
            }

            GeneticMaterial gmINB1 = null, gmINB2 = null, gmINB3 = null;

            for (int i = 0; i < inbredGeneticMaterial.length; i++) {
                GeneticMaterial geneticMaterial = inbredGeneticMaterial[i];
                if ("INB1".equalsIgnoreCase(geneticMaterial.getGermplasm().getPedigreeName())) {
                    gmINB1 = geneticMaterial;
                }
                if ("INB2".equalsIgnoreCase(geneticMaterial.getGermplasm().getPedigreeName())) {
                    gmINB2 = geneticMaterial;
                }
                if ("INB3".equalsIgnoreCase(geneticMaterial.getGermplasm().getPedigreeName())) {
                    gmINB3 = geneticMaterial;
                }

            }
            Germplasm germplasm = appdaoTestHelper
                    .createGermplasm(HYBRID, null, dupeOrigin, dupeOrigin, owner, "Corn", "F", "T");
            GeneticMaterial geneticMaterial = appdaoTestHelper
                    .createGeneticMaterial(germplasm, "DUPE " + dupeOrigin + " SOURCE", "F1", null);

            Germplasm germplasm2 = appdaoTestHelper
                    .createGermplasm(HYBRID, null, dupeOrigin2, dupeOrigin2, owner, "Corn", "F", "T");
            GeneticMaterial geneticMaterial2 = appdaoTestHelper
                    .createGeneticMaterial(germplasm2, "DUPE " + dupeOrigin + " SOURCE", "F1", null);

            appdaoTestHelper.createInventory(geneticMaterial, "T", "30");
            appdaoTestHelper.createInventory(geneticMaterial2, "T", "30");

            appdaoTestHelper.createParentage(geneticMaterial, geneticMaterial2, "F");
            appdaoTestHelper.createParentage(geneticMaterial, gmINB3, "M");

            appdaoTestHelper.createParentage(geneticMaterial2, gmINB1, "F");
            appdaoTestHelper.createParentage(geneticMaterial, gmINB2, "M");
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            Set stagingParentageSet = stagingInventory.getStagingParentage();
            Iterator iterator = stagingParentageSet.iterator();
            while (iterator.hasNext()) {
                StagingParentage stagingParentage = (StagingParentage) iterator.next();
                StagingInventory parentInventory = stagingParentage.getParentInventory();
                if (dupeOrigin.equals(parentInventory.getOrigin())) {
                    parentInventory.setSource("DUPE " + dupeOrigin + " SOURCE");
                } else if (dupeOrigin2.equals(parentInventory.getOrigin())) {
                    parentInventory.setSource("DUPE " + dupeOrigin2 + " SOURCE");
                }

            }

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                MockInventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(5, midasContext.getGermplasm().length);
                assertEquals(3, midasContext.getInventory().length);
                assertEquals(10, midasContext.getGeneticMatterial().length);
                assertEquals(10, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            purgeGermplasm(HYBRID, null, dupeOrigin, dupeOrigin, CROP_NAME);
            purgeGermplasm(HYBRID, null, dupeOrigin2, dupeOrigin2, CROP_NAME);
            for (int i = 0; i < inbreds.length; i++) {
                String pedigreeName = inbreds[i];
                String origin = inbredOrigins[i];
                purgeGermplasm(FINISHED, pedigreeName, origin, pedigreeName, CROP_NAME);
            }
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithEvents() throws Exception {
        String femaleInbredOrigin = "FXABC123";
        String femaleSource = "SOURCE FXABC123";
        String maleInbredOrigin = "MXABC123";
        String maleSource = "SOURCE MXABC123";
        String hybridOrigin = femaleInbredOrigin + "+" + maleInbredOrigin;
        String source = "SOURCE " + hybridOrigin;
        String owner = "17";
        String eventName = "EVENT-FinishedIIProcessor_UT".toUpperCase();
        String eventConstructName = "CONST-FinishedIIProcessor_UT".toUpperCase();
        String sourceStr = "SRC " + eventName;
        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        EventConstruct expectedEventConstruct = null;
        try {
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            Germplasm femaleGP = appdaoTestHelper.createInbred(femaleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");
            appdaoTestHelper.createInbred(maleInbredOrigin, owner, CROP_NAME, "ABC/XYZ");

            EventConstruct eventConstruct = appdaoTestHelper
                    .createEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            expectedEventConstruct = appdaoTestHelper.createEventConstruct(CROP_NAME, eventName, eventConstructName, "T");

            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), eventConstruct.getEventConstructId());
            appdaoTestHelper.createGermplasmEventConstruct(femaleGP.getId(), expectedEventConstruct.getEventConstructId());
            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "N", eventName);

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                InventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertMidasContext(midasContext, 1, 3, 3, 2);

                Germplasm[] germplasms = midasContext.getGermplasm();
                assertEquals(1, germplasms[0].getGermplasmEventConstruct().size());
                Iterator germplasmEventConstructIter = germplasms[0].getGermplasmEventConstruct().iterator();
                GermplasmEventConstruct actualGermplasmEventConstruct = (GermplasmEventConstruct) germplasmEventConstructIter
                        .next();
                assertEquals(actualGermplasmEventConstruct.getEventConstruct().getEventConstructId(),
                        expectedEventConstruct.getEventConstructId());
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "F");
            purgeEventConstruct(CROP_NAME, eventName, eventConstructName, "T");
            purgeGermplasm(FINISHED, femaleInbredOrigin, "ABC/XYZ", femaleInbredOrigin, CROP_NAME);
            purgeGermplasm(FINISHED, maleInbredOrigin, "ABC/XYZ", maleInbredOrigin, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testHybridParentTranslatedToSegpop() throws Exception {
        String owner = "17";
        String[] inbreds = new String[]{"II-HYBRIDFINISHEDPROCESSOR-INBRED-1", "II-HYBRIDFINISHEDPROCESSOR-INBRED-2",
                "II-HYBRIDFINISHEDPROCESSOR-INBRED-3", "II-HYBRIDFINISHEDPROCESSOR-INBRED-4"};
        String[] inbredOrigins = new String[]{"II-HYBRIDFINISHEDPROCESSOR-A-1/II-HYBRIDFINISHEDPROCESSOR-B-1",
                "II-HYBRIDFINISHEDPROCESSOR-B-1/II-HYBRIDFINISHEDPROCESSOR-A-1",
                "II-HYBRIDFINISHEDPROCESSOR-C-2/II-HYBRIDFINISHEDPROCESSOR-D-2",
                "II-HYBRIDFINISHEDPROCESSOR-D-2/II-HYBRIDFINISHEDPROCESSOR-C-2"};
        String hybridOrigin =
                inbreds[0] + "+" + inbreds[1] + "++" + inbreds[2] + "+" + inbreds[3];
        String femaleSource = "SOURCE " + inbreds[0] + "+" + inbreds[1];
        String maleSource = "SOURCE " + inbreds[2] + "+" + inbreds[3];
        String source = "SOURCE " + hybridOrigin;
        String segpopOrigin = "II-HYBRIDFINISHEDPROCESSOR-INBRED-3/II-HYBRIDFINISHEDPROCESSOR-INBRED-4";
        String segpopPedigree = owner + "_" + segpopOrigin;

        try {
            for (int i = 0; i < inbreds.length; i++) {
                purgeGermplasm(FINISHED, inbreds[i], inbredOrigins[i], inbreds[i], CROP_NAME);
            }
            purgeGermplasm(SEGPOP, null, segpopOrigin, segpopPedigree, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);
            Germplasm segpopGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, segpopOrigin, segpopPedigree, owner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(segpopGp, maleSource, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                MockInventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(2, midasContext.getGermplasm().length);
                assertEquals(6, midasContext.getGeneticMatterial().length);
                assertEquals(2, midasContext.getInventory().length);
                assertEquals(6, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            for (int i = 0; i < inbreds.length; i++) {
                purgeGermplasm(FINISHED, inbreds[i], inbredOrigins[i], inbreds[i], CROP_NAME);
            }
            purgeGermplasm(SEGPOP, null, segpopOrigin, segpopPedigree, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testBothParehtsTranslatedToSegpop() throws Exception {
        String owner = "17";
        String[] inbreds = new String[]{"II-HYBRIDFINISHEDPROCESSOR-INBRED-1", "II-HYBRIDFINISHEDPROCESSOR-INBRED-2",
                "II-HYBRIDFINISHEDPROCESSOR-INBRED-3", "II-HYBRIDFINISHEDPROCESSOR-INBRED-4"};
        String[] inbredOrigins = new String[]{"II-HYBRIDFINISHEDPROCESSOR-A-1/II-HYBRIDFINISHEDPROCESSOR-B-1",
                "II-HYBRIDFINISHEDPROCESSOR-B-1/II-HYBRIDFINISHEDPROCESSOR-A-1",
                "II-HYBRIDFINISHEDPROCESSOR-C-2/II-HYBRIDFINISHEDPROCESSOR-D-2",
                "II-HYBRIDFINISHEDPROCESSOR-D-2/II-HYBRIDFINISHEDPROCESSOR-C-2"};
        String hybridOrigin =
                inbreds[0] + "+" + inbreds[1] + "++" + inbreds[2] + "+" + inbreds[3];
        String femaleSource = "SOURCE " + inbreds[0] + "+" + inbreds[1];
        String maleSource = "SOURCE " + inbreds[2] + "+" + inbreds[3];
        String source = "SOURCE " + hybridOrigin;
        String segpopOriginFemale = "II-HYBRIDFINISHEDPROCESSOR-INBRED-1/II-HYBRIDFINISHEDPROCESSOR-INBRED-2";
        String segpopPedigreeFemale = owner + "_" + segpopOriginFemale;
        String segpopOriginMale = "II-HYBRIDFINISHEDPROCESSOR-INBRED-3/II-HYBRIDFINISHEDPROCESSOR-INBRED-4";
        String segpopPedigreeMale = owner + "_" + segpopOriginMale;

        try {
            for (int i = 0; i < inbreds.length; i++) {
                purgeGermplasm(FINISHED, inbreds[i], inbredOrigins[i], inbreds[i], CROP_NAME);
            }
            purgeGermplasm(SEGPOP, null, segpopOriginFemale, segpopPedigreeFemale, CROP_NAME);
            purgeGermplasm(SEGPOP, null, segpopOriginMale, segpopPedigreeMale, CROP_NAME);
            removeStagingInventoryTestData(templateName);

            appdaoTestHelper.createInbreds(inbreds, owner, CROP_NAME, inbredOrigins);

            Germplasm segpopFemaleGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, segpopOriginFemale, segpopPedigreeFemale, owner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(segpopFemaleGp, femaleSource, "F1", null);

            Germplasm segpopMaleGp = appdaoTestHelper
                    .createGermplasm(SEGPOP, null, segpopOriginMale, segpopPedigreeMale, owner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(segpopMaleGp, maleSource, "F1", null);
            session.getTransaction().commit();
        } finally {
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            appdaoTestHelper.setStagingSession(session);
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId, HYBRID);
            StagingInventory importedRecord = createStagingInventory(header, HYBRID_FINISHED,
                    hybridOrigin, source, femaleSource, maleSource, owner, owner, owner, owner, HYBRID,
                    userId, "F1", null, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, importedRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, importedRecord,
                    StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventory = getStagingInventoryWithParentage(importedRecord);
            assertNotNull(stagingInventory.getStagingParentage());

            HybridFinishedProcessor processor = new HybridFinishedProcessor();

            try {
                MockInventoryContext context = new MockInventoryContext(stagingInventory);
                MidasContext midasContext = processor.processInventory(context);
                assertEquals(1, midasContext.getGermplasm().length);
                assertEquals(5, midasContext.getGeneticMatterial().length);
                assertEquals(1, midasContext.getInventory().length);
                assertEquals(6, midasContext.getParentage().length);
            } catch (InventoryImportProcessorException e) {
                e.printStackTrace();
                fail("Encountered InventoryImportProcessorException");
            }
        } finally {
            session.getTransaction().rollback();
            for (int i = 0; i < inbreds.length; i++) {
                purgeGermplasm(FINISHED, inbreds[i], inbredOrigins[i], inbreds[i], CROP_NAME);
            }
            purgeGermplasm(SEGPOP, null, segpopOriginFemale, segpopPedigreeFemale, CROP_NAME);
            purgeGermplasm(SEGPOP, null, segpopOriginMale, segpopPedigreeMale, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    private void assertGeneticMaterialEquals(GeneticMaterial expectedGM, GeneticMaterial actualGM) {
        assertNotNull(expectedGM);
        assertNotNull(actualGM);
        assertEquals(expectedGM.getGeneration(), actualGM.getGeneration());
        assertEquals(expectedGM.getLineage(), actualGM.getLineage());
        assertEquals(expectedGM.getIsAutogen(), actualGM.getIsAutogen());
        assertEquals(expectedGM.getSourceStr(), actualGM.getSourceStr());
        assertGermplasmEquals(expectedGM.getGermplasm(), actualGM.getGermplasm());
    }

    private void assertGermplasmEquals(Germplasm expectedGP, Germplasm actualGP) {
        assertNotNull(expectedGP);
        assertNotNull(actualGP);
        assertEquals(expectedGP.getOrigin(), actualGP.getOrigin());
        assertEquals(expectedGP.getLineCode(), actualGP.getLineCode());
        assertEquals(expectedGP.getPedigreeName(), actualGP.getPedigreeName());
        assertEquals(expectedGP.getFinishedOrFinishedChild(), actualGP.getFinishedOrFinishedChild());
        assertLineTypeEquals(expectedGP.getLineType(), actualGP.getLineType());
    }

    private void assertLineTypeEquals(LineType expectedLT, LineType actualLT) {
        if (expectedLT != null && actualLT != null) {
            assertEquals(expectedLT.getLineTypeRefId(), actualLT.getLineTypeRefId());
        } else {
            assertNotNull(expectedLT);
            assertNotNull(actualLT);

        }
    }
}