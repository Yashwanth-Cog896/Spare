package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.services.domain.common.activity.ActivityClientException;
import junit.framework.TestCase;
import org.ietf.jgss.GSSException;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 10, 2009
 * Time: 1:37:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class BatchProcessor_AT extends TestCase {
    private String[] args;


    public void testBatchProcess() throws GSSException, ActivityClientException, InstantiationException, IllegalAccessException {
        args = new String[2];
        args[0] = "commit";
        args[1] = "500";


//        BatchProcessor.AppMain(args);
    }
}
