/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;
/**
 * Filename: $Id: BatchProcessor_UT.java,v 1.26 2009-06-05 14:08:03 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.26 $
 */

import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProcessName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunDetail;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.SimpleStagingInventoryByStatusCodesFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.*;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchRunSummaryInfo;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchSystemEKGLogger;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.posclients.ApprovedStagingInventoryActivityClient;
import com.monsanto.tcc.apolloinventoryimportplugin.common.posclients.ValidateStagingInventoryWithoutSavePOSClient;
import junit.framework.TestCase;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.ietf.jgss.GSSException;

/**
 * @noinspection RefusedBequest
 */
public class BatchProcessor_UT extends TestCase {

    public void runAppMain() throws ActivityClientException, InventoryImportProcessorException, GSSException,
            InstantiationException, IllegalAccessException {
        BatchProcessor.AppMain(new String[]{"rollback", "500"});
    }

/*
  public void testValidateAndProcessStagingInventory_Prem_Tst() throws ActivityClientException,
      InventoryImportProcessorException {
    String[] statusCodes = new String[]{"Approved"};

    Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    session.beginTransaction();
    StagingInventory stagingInventory = null;
    stagingInventory = (StagingInventory)session.get(StagingInventory.class, new Long(71347));

//    List inventory = new InventoryByStatusCodesDAO().getStagingInventoryRecords(statusCodes, session);
    session.getTransaction().commit();

    assertNotNull(stagingInventory);
//    assertTrue(stagingInventory.size() > 0);

    BatchProcessor batchProcessor = new BatchProcessor(false);

    batchProcessor.validateAndProcessInventory(stagingInventory);
  }
*/

    public void testGetStagingInventoryInApprovedStatusReturningInventory() {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        try {
            StagingInventory[] approvedStagingInventory = batchProcessor
                    .getStagingInventoryInApprovedStatus(BatchProcessor.DEFAULT_FETCH_ALL_BLOCK_SIZE);
            assertEquals(3, approvedStagingInventory.length);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered ActivityClientExceptiom");
        }
    }

    public void testGetStagingInventoryInApprovedStatusThrowingException() {
        MockBatchProcessor batchProcessor = new MockBatchProcessorThrowsException(false);

        try {
            batchProcessor.getStagingInventoryInApprovedStatus(BatchProcessor.DEFAULT_FETCH_ALL_BLOCK_SIZE);
            fail("Expecting ActivityClientException");
        } catch (Exception e) {
            assertTrue(e.getMessage().indexOf("There was a problem connecting to the client") >= 0);
        }
    }

    public void testValidateStagingInventoryWithSuccessfulValidation() {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(-1L));
        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode("Approved");
        stagingInventory.setImportStatus(importStatus);
        try {
            assertTrue(batchProcessor.validateStagingInventory(stagingInventory));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered ActivityClientException");
        }
    }

    public void testValidateStagingInventoryWithUnsuccessfulValidation() {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(-1L));
        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode("Invalid");
        stagingInventory.setImportStatus(importStatus);
        try {
            assertFalse(batchProcessor.validateStagingInventory(stagingInventory));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered ActivityClientException");
        }
    }

    public void testValidateStagingInventoryThrowingException() {
        MockBatchProcessor batchProcessor = new MockBatchProcessorThrowsException(false);

        StagingInventory stagingInventory = new StagingInventory();
        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode("Invalid");
        stagingInventory.setImportStatus(importStatus);
        try {
            batchProcessor.validateStagingInventory(stagingInventory);
            fail("Expecting ActivityClientException");
        } catch (Exception e) {
            assertTrue(e.getMessage().indexOf("There was a problem with handling the request") >= 0);
        }
    }

    public void testProcessStagingInventoryIntoMidasSuccessfully() {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setId(new Long(-5));
        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode("Approved");
        stagingInventory.setImportStatus(importStatus);

        try {
            batchProcessor.processStagingInventoryIntoMidas(stagingInventory);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered InventoryImportProcessorException");
        }
    }

    public void testProcessStagingInventoryIntoMidasThrowingException() throws IllegalAccessException,
            InstantiationException {
        MockBatchProcessor batchProcessor = new MockBatchProcessorThrowsException(false);

        StagingInventory stagingInventory = new StagingInventory();

        try {
            batchProcessor.processStagingInventoryIntoMidas(stagingInventory);
            fail("Expecting InventoryImportProcessorException");
        } catch (InventoryImportProcessorException e) {
            assertTrue(e.getMessage().indexOf("Unable to process staging inventory") >= 0);
        }
    }

    public void testValidateAndProcessStagingInventoryPassingNullArgument() throws ActivityClientException,
            InventoryImportProcessorException {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        StagingInventory[] stagingInventory = null;

        try {
            batchProcessor.validateAndProcessInventory(stagingInventory);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered Exception - " + e.getMessage());
        }

    }

    public void testValidateAndProcessStagingInventoryPassingEmptyArray() throws ActivityClientException,
            InventoryImportProcessorException {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        StagingInventory[] stagingInventory = new StagingInventory[0];

        try {
            batchProcessor.validateAndProcessInventory(stagingInventory);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            fail("Encountered Exception - " + e.getMessage());
        }

    }


    public void testValidateAndProcessStagingInventory() throws ActivityClientException,
            InventoryImportProcessorException {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        ImportStatus approvedStatus = new ImportStatus();
        approvedStatus.setStatusCode("Approved");
        ImportStatus invalidStatus = new ImportStatus();
        invalidStatus.setStatusCode("Invalid");

        StagingInventory approvedStagingInventory = new StagingInventory();
        approvedStagingInventory.setImportStatus(approvedStatus);
        approvedStagingInventory.setId(new Long(-1L));
        StagingInventory invalidStagingInventory = new StagingInventory();
        invalidStagingInventory.setImportStatus(invalidStatus);
        invalidStagingInventory.setId(new Long(-2L));

        StagingInventory[] stagingInventory = new StagingInventory[]{approvedStagingInventory, invalidStagingInventory};

        batchProcessor.validateAndProcessInventory(stagingInventory);
        assertEquals("Imported".toLowerCase(), stagingInventory[0].getImportStatus().getStatusCode().toLowerCase());
        assertEquals("Invalid".toLowerCase(), stagingInventory[1].getImportStatus().getStatusCode().toLowerCase());
    }

    public void testGetImportStatusWhenStatusExistsInDB() {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession().beginTransaction();
        ImportStatus importStatus = batchProcessor.getImportStatus("Valid");
        HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession().beginTransaction();
        assertNotNull(importStatus);
        assertEquals("Valid".toUpperCase(), importStatus.getStatusCode().toUpperCase());
    }

    public void testGetImportStatusWhenStatusDoesNotExistInDB() {
        MockBatchProcessor batchProcessor = new MockBatchProcessor(false);

        HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession().beginTransaction();
        ImportStatus importStatus = batchProcessor.getImportStatus("JunkStatus");
        HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession().beginTransaction();
        assertNull(importStatus);
    }

    public void testRefreshStagingInventory() {
        BatchProcessor batchProcessor = new MockBatchProcessorExposingOnlyProtectedForTesting(false);

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        StagingInventory[] stagingInventories = new SimpleStagingInventoryByStatusCodesFetchStrategy(5)
                .getStagingInventoryRecords(new String[]{"New"});
        session.getTransaction().rollback();

        String invOwner = stagingInventories[0].getInventoryOwner();

        stagingInventories[0].setInventoryOwner("@@");

        ((MockBatchProcessorExposingOnlyProtectedForTesting) batchProcessor).refreshStagingInventory(stagingInventories[0]);

        assertEquals(invOwner, stagingInventories[0].getInventoryOwner());
    }

    public void testUpdateStagingInventory() {
        BatchProcessor batchProcessor = new MockBatchProcessorExposingOnlyProtectedForTesting(false);

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        StagingInventory[] stagingInventories = new SimpleStagingInventoryByStatusCodesFetchStrategy(5)
                .getStagingInventoryRecords(new String[]{"New", "Approved", "Valid"});
        ((MockBatchProcessorExposingOnlyProtectedForTesting) batchProcessor).getBatchRunHistoryHelper()
                .addRecords(stagingInventories);
        ImportStatus importedStatus = (ImportStatus) session.createCriteria(ImportStatus.class)
                .add(Restrictions.eq("statusCode", "Imported").ignoreCase()).uniqueResult();
        session.getTransaction().rollback();

        assertTrue(stagingInventories.length >= 2);

        stagingInventories[0].setImportStatus(importedStatus);

        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        ((MockBatchProcessorExposingOnlyProtectedForTesting) batchProcessor).updateStagingInventory(stagingInventories[0]);
        ((MockBatchProcessorExposingOnlyProtectedForTesting) batchProcessor).updateStagingInventory(stagingInventories[1]);
        session.getTransaction().rollback();

        MockBatchRunHistoryHelper helper = (MockBatchRunHistoryHelper) ((MockBatchProcessorExposingOnlyProtectedForTesting) batchProcessor)
                .getBatchRunHistoryHelper();

        assertNull(helper.fetchRunDetails(stagingInventories[0]).getProcessExceptionMsg());
    }

    public void testRunHistoryIsSetWhenThereAreNoInventoriesToProcess() {
        MockBatchProcessorExposingOnlyProtectedForTesting batchProcessor = new MockBatchProcessorExposingOnlyProtectedForTesting(
                false);

        batchProcessor.process(null);

        MockBatchRunHistoryHelper mockBatchRunHistoryHelper = (MockBatchRunHistoryHelper) batchProcessor
                .getBatchRunHistoryHelper();
        RunHistory runHistory = mockBatchRunHistoryHelper.fetchRunHistory();
        assertNotNull(runHistory);
        assertEquals(0, runHistory.getRecordsProcessed().longValue());
        assertEquals("Done", runHistory.getRunStatus().getStatusCode());
    }

    // Mocks
    class MockBatchProcessorExposingOnlyProtectedForTesting extends BatchProcessor {
        BatchRunHistoryHelper runHistoryHelper;

        public MockBatchProcessorExposingOnlyProtectedForTesting(boolean commit) {
            super(commit, 5);
        }

        protected BatchRunHistoryHelper createBatchRunHistoryHelper() {
            runHistoryHelper = new MockBatchRunHistoryHelper();
            return runHistoryHelper;
        }

        public void refreshStagingInventory(StagingInventory stagingInventory) {
            super.refreshStagingInventory(stagingInventory);
        }

        public void updateStagingInventory(StagingInventory processedStagingInventory) {
            super.updateStagingInventory(processedStagingInventory);
        }

        protected BatchRunHistoryHelper getBatchRunHistoryHelper() {
            return runHistoryHelper;
        }

        public void process(StagingInventory[] approvedStagingInventory) {
            super.process(approvedStagingInventory);
        }
    }

    class MockBatchProcessor extends BatchProcessor {

        MockBatchRunHistoryHelper runHistoryHelper;

        public MockBatchProcessor(boolean commit) {
            super(commit, 5);
            runHistoryHelper = new MockBatchRunHistoryHelper();
        }

        protected void refreshStagingInventory(StagingInventory stagingInventory) {
            //Do nothing as this is tested using the real object
        }

        protected ApprovedStagingInventoryActivityClient createApprovedStagingInventoryActivityClient() {
            return new MockApprovedStagingInventoryActivityClient();
        }

        protected ValidateStagingInventoryWithoutSavePOSClient createValidateStagingInventoryActivityClient() {
            return new MockValidateStagingInventoryActivityClient();
        }

        protected IIProcessor createInventoryImportProcessor(StagingInventory stagingInventory) {
            return new MockIIProcessor();
        }

        public ImportStatus getImportStatus(String statusCode) {
            return super.getImportStatus(statusCode);
        }

        public BatchRunHistoryHelper getBatchRunHistoryHelper() {
            return runHistoryHelper;
        }

        protected void updateStagingInventory(StagingInventory processedStagingInventory) {
            //do nothing as this tested with a real object
        }

        public StagingInventory[] getStagingInventoryInApprovedStatus(int fetchSize) throws ActivityClientException,
                GSSException, IllegalAccessException, InstantiationException {
            return super.getStagingInventoryInApprovedStatus(fetchSize);
        }

        public void validateAndProcessInventory(StagingInventory[] approvedStagingInventory) {
            super.validateAndProcessInventory(approvedStagingInventory);
        }

        public boolean validateStagingInventory(StagingInventory stagingInventory) throws ActivityClientException,
                GSSException, IllegalAccessException, InstantiationException {
            return super.validateStagingInventory(stagingInventory);
        }

        public MidasContext processStagingInventoryIntoMidas(StagingInventory stagingInventory) throws
                InventoryImportProcessorException, IllegalAccessException, InstantiationException {
            return super.processStagingInventoryIntoMidas(stagingInventory);
        }
    }

    class MockBatchRunHistoryHelper extends BatchRunHistoryHelper {
        private long id = 1;

        public RunDetail fetchRunDetails(StagingInventory stagingInventory) {
            return super.getRunDetails(stagingInventory);
        }

        public RunHistory fetchRunHistory() {
            return super.getRunHistory();
        }

        public RunDetail[] fetchRunDetails() {
            return super.getRunDetails();
        }

        public ProcessName getProcessName(String name) {
            ProcessName processName = new ProcessName();
            processName.setId(new Long(1));
            processName.setName(name);
            processName.setDescription("Some process name " + name);
            return processName;
        }

        public RunStatus getRunStatus(String statusCode) {
            RunStatus runStatus = new RunStatus();
            runStatus.setId(new Long(2));
            runStatus.setStatusCode(statusCode);
            runStatus.setDescription("Some Run Status code " + statusCode);
            return runStatus;
        }

        public void saveRunHistory() {
        }

        public void saveRunDetails() {
        }

        public void saveRunDetails(StagingInventory stagingInvetory) {
        }


        protected RunHistory createRunHistory() {
            RunHistory runHistory = new RunHistory();
            runHistory.setId(new Long(id++));
            return runHistory;
        }


        protected RunDetail createRunDetail() {
            RunDetail runDetail = new RunDetail();
            runDetail.setId(new Long(id++));
            return runDetail;
        }
    }

    class MockApprovedStagingInventoryActivityClient extends ApprovedStagingInventoryActivityClient {
        /**
         * @noinspection MagicNumber
         */
        public StagingInventory[] getApprovedStagingInventories(int fetchSize) throws ActivityClientException {
            StagingInventory inv1 = new StagingInventory();
            inv1.setId(new Long(101));
            StagingInventory inv2 = new StagingInventory();
            inv2.setId(new Long(102));
            StagingInventory inv3 = new StagingInventory();
            inv3.setId(new Long(103));
            return new StagingInventory[]{inv1, inv2, inv3};
        }
    }

    class MockBatchProcessorThrowsException extends MockBatchProcessor {

        public MockBatchProcessorThrowsException(boolean commit) {
            super(commit);
        }

        protected ApprovedStagingInventoryActivityClient createApprovedStagingInventoryActivityClient() {
            return new MockApprovedStagingInventoryActivityClientThrowsException();
        }

        protected ValidateStagingInventoryWithoutSavePOSClient createValidateStagingInventoryActivityClient() {
            return new MockValidateStagingInventoryActivityClientThrowsException();
        }

        protected IIProcessor createInventoryImportProcessor(StagingInventory stagingInventory) {
            return new MockIIProcessorThrowsException();
        }
    }

    class MockApprovedStagingInventoryActivityClientThrowsException extends ApprovedStagingInventoryActivityClient {
        public StagingInventory[] getApprovedStagingInventories(int fetchSize) throws ActivityClientException {
            throw new ActivityClientException("There was a problem connecting to the client", new Exception());
        }
    }

    class MockIIProcessor implements IIProcessor {

        public MidasContext processInventory(InventoryContext inventoryContext) throws
                InventoryImportProcessorException {
            ImportStatus status = new ImportStatus();
            status.setStatusCode("Imported");
            inventoryContext.getStagingInventory().setImportStatus(status);
            return new MidasContext();
        }

    }

    class MockIIProcessorThrowsException implements IIProcessor {

        public MidasContext processInventory(InventoryContext inventoryContext) throws
                InventoryImportProcessorException {
            throw new InventoryImportProcessorException("Unable to process staging inventory");
        }

    }

    class MockValidateStagingInventoryActivityClient extends ValidateStagingInventoryWithoutSavePOSClient {
        public StagingInventory validateStagingInventory(StagingInventory stagingInventory) throws ActivityClientException {
            return stagingInventory;
        }
    }

    class MockValidateStagingInventoryActivityClientThrowsException extends ValidateStagingInventoryWithoutSavePOSClient {
        public StagingInventory validateStagingInventory(StagingInventory stagingInventory) throws ActivityClientException {
            throw new ActivityClientException("There was a problem with handling the request", new Exception());
        }
    }

    class MockBatchSystemEKGLogger extends BatchSystemEKGLogger {
        public void log(BatchRunSummaryInfo batchRunSummaryInfo) {
            //do nothing
        }
    }
}