/*
 TestHelper was created on Feb 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test.testutil;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.MidasConnectionFactory;
import org.hibernate.Session;

/**
 * Filename:    $RCSfile: TestHelper.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-17 22:50:08 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class TestHelper {
  private Session midasSession;
  private boolean externalSession;
  private boolean transactionActive;

  public TestHelper() {
    externalSession = false;
  }

  private void initSessions() {
    midasSession = MidasConnectionFactory.getSessionFactoryForMidasDataPos().openSession();
  }

  public void beginTransaction() {
    if (!externalSession && !transactionActive) {
      initSessions();
      midasSession.beginTransaction();
      transactionActive = true;
    }
  }

  public void endTransaction(boolean commit) {
    if (!externalSession && transactionActive) {
      try {
        if (!commit) {
          midasSession.getTransaction().rollback();
        } else {
          midasSession.getTransaction().commit();
        }
      } finally {
        transactionActive = false;
        midasSession.close();
        //noinspection EmptyCatchBlock
      }
    }
  }

  public void endTransaction() {
    endTransaction(true);
  }

  public void rollbackTransaction() {
    endTransaction(false);
  }


  public void deleteMidasContext(MidasContext midasContext) {
    checkTransaction();

    if (midasContext != null) {
      delete(midasContext.getParentage());
      delete(midasContext.getCompICBMale());
      delete(midasContext.getInventory());
      delete(midasContext.getGeneticMatterial());
      delete(midasContext.getGermplasm());
    }
  }

  private void delete(Object[] objects) {
    if (objects != null && objects.length > 0) {
      for (int i = 0; i < objects.length; i++) {
        Object object = objects[i];
        midasSession.delete(object);
      }
      midasSession.flush();
    }
  }

  private void checkTransaction() {
    if (!externalSession && !transactionActive) {
      throw new RuntimeException("No active transaction found. Use beginTransaction() first!");
    }
  }
}