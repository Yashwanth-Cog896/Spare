/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.test;

import com.monsanto.appstatsclient.AsyncAppStatsLogger;
import com.monsanto.appstatscommon.ApplicationTask;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchRunSummaryInfo;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchSystemEKGLogger;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.AppInfoConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import junit.framework.TestCase;

import java.util.Date;

/**
 * Filename:    $RCSfile: BatchSystemEKGLogger_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $ On:	$Date: 2008-02-17 22:58:08 $
 *
 * @author APATRO
 * @version $Revision: 1.2 $
 */
public class BatchSystemEKGLogger_UT extends TestCase {
  private TestHelper testHelper;
  private ApplicationTask applicationTask;

  public BatchSystemEKGLogger_UT(String string) {
    super(string);
  }

  protected void setUp() throws Exception {
    super.setUp();
    testHelper = new TestHelper();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /**
   * @noinspection MagicNumber
   */
  public void testLogBatchRunSummaryInfo() {
    int expectedRunHistoryId = 5;
    Date expectedStartDate = new Date();
    Date expectedEndDate = new Date(expectedStartDate.getTime() + 40000);
    RunHistory runHistory = testHelper.createRunHistory(expectedRunHistoryId, expectedStartDate, expectedEndDate);
    BatchRunSummaryInfo batchRunSummaryInfo = new BatchRunSummaryInfo(createStagingInventories(), runHistory);

    BatchSystemEKGLogger sysEkgLogger = new MockBatchSystemEKGLogger();

    assertNull(applicationTask);

    sysEkgLogger.log(batchRunSummaryInfo);

    assertNotNull(applicationTask);

    assertEquals(AppInfoConstants.APPLICATION_NAME, applicationTask.getApplicationName());
    assertEquals(BatchSystemEKGLogger.SUMMARY_TASK_NAME, applicationTask.getTaskName());
    assertEquals(expectedStartDate.getTime(), applicationTask.getStartTime().getTime());
    assertEquals(expectedEndDate.getTime(), applicationTask.getEndTime().getTime());

    assertEquals(11, applicationTask.getDataPoints().length);

    assertEquals("6", applicationTask.getDataPoint(BatchSystemEKGLogger.TOTAL_MAIN_RECORDS).getStringValue());
    assertEquals("2", applicationTask.getDataPoint(BatchSystemEKGLogger.MAIN_RECORDS_PROCESSED).getStringValue());
    assertEquals("1",
        applicationTask.getDataPoint(BatchSystemEKGLogger.VALIDATION_FAILED_MAIN_RECORDS).getStringValue());
    assertEquals("2",
        applicationTask.getDataPoint(BatchSystemEKGLogger.PROCESS_EXCEPTION_MAIN_RECORDS).getStringValue());
    assertEquals("1", applicationTask.getDataPoint(BatchSystemEKGLogger.UNPROCESSED_MAIN_RECORDS).getStringValue());

    assertEquals("30", applicationTask.getDataPoint(BatchSystemEKGLogger.TOTAL_SUB_RECORDS).getStringValue());
    assertEquals("8", applicationTask.getDataPoint(BatchSystemEKGLogger.SUB_RECORDS_PROCESSED).getStringValue());
    assertEquals("5",
        applicationTask.getDataPoint(BatchSystemEKGLogger.VALIDATION_FAILED_SUB_RECORDS).getStringValue());
    assertEquals("10",
        applicationTask.getDataPoint(BatchSystemEKGLogger.PROCESS_EXCEPTION_SUB_RECORDS).getStringValue());
    assertEquals("7", applicationTask.getDataPoint(BatchSystemEKGLogger.UNPROCESSED_SUB_RECORDS).getStringValue());
  }

  private StagingInventory[] createStagingInventories() {
    StagingInventory mainAllApproved = testHelper.createStagingInventory(StagingInventoryStatusConstants.APPROVED, 5);
    StagingInventory mainAllImported = testHelper.createStagingInventory(StagingInventoryStatusConstants.IMPORTED, 5);
    StagingInventory mainAllUnprocessed = testHelper
        .createStagingInventory(StagingInventoryStatusConstants.UNPROCESSED, 5);

    StagingInventory mainInvalid = testHelper.createStagingInventory(StagingInventoryStatusConstants.APPROVED, 5);
    mainInvalid.setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.INVALID));

    StagingInventory mainApprovedAllImported = testHelper
        .createStagingInventory(StagingInventoryStatusConstants.IMPORTED, 5);
    mainApprovedAllImported.setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.APPROVED));

    StagingInventory mainImportedWithUnprocessedSub = testHelper
        .createStagingInventory(StagingInventoryStatusConstants.IMPORTED,
            5);
    StagingParentage[] stagingParentages = mainImportedWithUnprocessedSub.getSubRecords();
    stagingParentages[stagingParentages.length - 1].getParentInventory()
        .setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.UNPROCESSED));
    stagingParentages[stagingParentages.length - 2].getParentInventory()
        .setImportStatus(testHelper.getImportStatus(StagingInventoryStatusConstants.UNPROCESSED));

    return new StagingInventory[]{mainAllApproved, mainAllImported, mainAllUnprocessed,
        mainApprovedAllImported, mainImportedWithUnprocessedSub, mainInvalid};
  }


  class MockBatchSystemEKGLogger extends BatchSystemEKGLogger {
    /**
     * @noinspection RefusedBequest
     */
    protected AsyncAppStatsLogger createAsyncLogger() {
      return new MockAsyncAppStatsLogger();
    }
  }

  class MockAsyncAppStatsLogger extends AsyncAppStatsLogger {
    protected MockAsyncAppStatsLogger() {
    }

    /**
     * @noinspection RefusedBequest
     */
    public synchronized void post(ApplicationTask data) {
      applicationTask = (ApplicationTask) data;
    }

    /**
     * @noinspection RefusedBequest
     */
    protected void doWork(Object data) {
      applicationTask = (ApplicationTask) data;
    }
  }
}