/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.SegpopIIProcessor;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

/**
 * Filename:    $RCSfile: SegpopTopLevelParentsIIProcessor_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $ On:          $Date: 2009-06-05 14:08:02 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class SegpopTopLevelParentsIIProcessor_UT extends ProcessorTestCase {
    private static final String CROP_NAME = "Corn";
    private static final String USA = "United States of America";
    private String templateName;

    public SegpopTopLevelParentsIIProcessor_UT(String name) {
        super(name);
        templateName = this.getClass().getName();
    }

    protected void setUp() throws Exception {
        super.setUp();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }


    public void testProcessInventoryIntoMidasWithPreComercialFinishedLineCodeMatch() throws Exception {
        String lineTypeOfGpOfProduct = MaterialTypeConstants.FINISHED_LINES;
        String originOfGpOfProduct = "II-PRE-COM-ORIGIN";
        String lineCodeOfGpOfProduct = "II-PRE-COM-LINE-CODE-PEDIGREE";
        String pedigreeNameOfGpOfProduct = lineCodeOfGpOfProduct;
        String lineTypeOfInbred = MaterialTypeConstants.FINISHED_LINES;
        String originOfFemaleInbred = "II-PRE-COM-FEMALE-INBRED";
        String lineCodeOfFemaleInbred = "II-PRE-COM-FEMALE-INBRED";
        String pedigreeOfFemaleInbred = "II-PRE-COM-FEMALE-INBRED";
        String originOfMaleInbred = "II-PRE-COM-MALE-INBRED";
        String lineCodeOfMaleInbred = "II-PRE-COM-MALE-INBRED";
        String pedigreeOfMaleInbred = "II-PRE-COM-MALE-INBRED";
        String importedOrigin = originOfFemaleInbred + "/" + originOfMaleInbred + "//" + lineCodeOfGpOfProduct;
        String importedSource = "II PRE-COM FEMALE INBRED SOURCE - II PRE-COM MALE INBRED SOURCE";
        String gpOwner = "17";
        String lineage = "@.";
        String generation = "F2";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm precomProductGp = null;
        Germplasm femaleGp = null;
        Germplasm maleGp = null;
        try {
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);

            precomProductGp = appdaoTestHelper.createInbred(lineCodeOfGpOfProduct, gpOwner, CROP_NAME, originOfGpOfProduct);
            appdaoTestHelper.createInbredGeneticMaterial(precomProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            femaleGp = appdaoTestHelper.createInbred(lineCodeOfFemaleInbred, gpOwner, CROP_NAME, originOfFemaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(femaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleGp = appdaoTestHelper.createInbred(lineCodeOfMaleInbred, gpOwner, CROP_NAME, originOfMaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(maleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    importedOrigin, importedSource, "fp1", null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 1, 3, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithPreComercialFinishedProductNameMatch() throws Exception {
        String lineTypeOfGpOfProduct = MaterialTypeConstants.FINISHED_LINES;
        String precomProductName = "II-PRE-COM-PROD-NAME";
        String precomBrandName = "MONSANTO";
        String precomCompanyName = "MONSANTO";
        String originOfGpOfProduct = precomProductName;
        String lineCodeOfGpOfProduct = precomProductName;
        String pedigreeNameOfGpOfProduct = precomProductName;
        String lineTypeOfInbred = MaterialTypeConstants.FINISHED_LINES;
        String originOfFemaleInbred = "II-PRE-COM-FEMALE-INBRED";
        String lineCodeOfFemaleInbred = "II-PRE-COM-FEMALE-INBRED";
        String pedigreeOfFemaleInbred = "II-PRE-COM-FEMALE-INBRED";
        String originOfMaleInbred = "II-PRE-COM-MALE-INBRED";
        String lineCodeOfMaleInbred = "II-PRE-COM-MALE-INBRED";
        String pedigreeOfMaleInbred = "II-PRE-COM-MALE-INBRED";
        String importedOrigin = originOfFemaleInbred + "/" + originOfMaleInbred + "//" + lineCodeOfGpOfProduct;
        String importedSource = "II PRE-COM FEMALE INBRED SOURCE - II PRE-COM MALE INBRED SOURCE";
        String gpOwner = "17";
        String lineage = "@.";
        String generation = "F2";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm precomProductGp = null;
        Germplasm femaleGp = null;
        Germplasm maleGp = null;
        try {
            purgeProduct(CROP_NAME, precomProductName, precomBrandName, precomCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);

            precomProductGp = appdaoTestHelper.createInbred(lineCodeOfGpOfProduct, gpOwner, CROP_NAME, originOfGpOfProduct);
            appdaoTestHelper.createInbredGeneticMaterial(precomProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            femaleGp = appdaoTestHelper.createInbred(lineCodeOfFemaleInbred, gpOwner, CROP_NAME, originOfFemaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(femaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleGp = appdaoTestHelper.createInbred(lineCodeOfMaleInbred, gpOwner, CROP_NAME, originOfMaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(maleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(precomProductName, "T", precomBrandName, precomCompanyName, USA, compProduct);
            appdaoTestHelper.createProductGermplasm(compProduct, precomProductGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    importedOrigin, importedSource, "fp1", null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 1, 3, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, precomProductName, precomBrandName, precomCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithPreComercialCompetitorLineCodeFinishedThreeWay() throws Exception {
        String lineTypeOfGpOfProduct = MaterialTypeConstants.FINISHED_LINES;
        String femalePreComOrigin = "II-FEMALE-PRE-COM-ORIGIN";
        String maleCompOrigin = "II-MALE-COMP-ORIGIN";
        String maleLineCode = "II-MALE-LINE-CODE";
        String maleLineCode2 = "II-MALE-LINE-CODE-2";

        String precomProductName = femalePreComOrigin;
        String compProductName = maleCompOrigin;
        String precomBrandName = "MONSANTO";
        String precomCompanyName = "MONSANTO";
        String compBrandName = "MONSANTO";
        String compCompanyName = "II-NOT-MONSANTO";

        String lineTypeOfInbred = MaterialTypeConstants.FINISHED_LINES;
        String importedOrigin = femalePreComOrigin + "/" + maleCompOrigin + "//" + maleLineCode + "/3/" + maleLineCode2;
        String importedSource = "II SOURCE";
        String gpOwner = "17";
        String lineage = "@.1.";
        String generation = "F3";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm precomProductGp = null;
        Germplasm compProductGp = null;
        Germplasm maleLCGp = null;
        Germplasm maleLCGp2 = null;
        try {
            purgeProduct(CROP_NAME, precomProductName, precomBrandName, precomCompanyName);
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, femalePreComOrigin, femalePreComOrigin, femalePreComOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleCompOrigin, maleCompOrigin, maleCompOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode, maleLineCode, maleLineCode, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode2, maleLineCode2, maleLineCode2, CROP_NAME);

            precomProductGp = appdaoTestHelper.createInbred(femalePreComOrigin, gpOwner, CROP_NAME, femalePreComOrigin);
            appdaoTestHelper.createInbredGeneticMaterial(precomProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            compProductGp = appdaoTestHelper.createInbred(maleCompOrigin, gpOwner, CROP_NAME, maleCompOrigin);
            appdaoTestHelper.createInbredGeneticMaterial(compProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleLCGp = appdaoTestHelper.createInbred(maleLineCode, gpOwner, CROP_NAME, maleLineCode);
            appdaoTestHelper.createInbredGeneticMaterial(maleLCGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleLCGp2 = appdaoTestHelper.createInbred(maleLineCode2, gpOwner, CROP_NAME, maleLineCode2);
            appdaoTestHelper.createInbredGeneticMaterial(maleLCGp2, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            Product precomProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(precomProductName, "T", precomBrandName, precomCompanyName, USA, precomProduct);
            appdaoTestHelper.createProductGermplasm(precomProduct, precomProductGp);

            Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(compProductName, "T", compBrandName, compCompanyName, USA, compProduct);
            appdaoTestHelper.createProductGermplasm(compProduct, compProductGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    importedOrigin, importedSource, "fp1", null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 5, 1, 5, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, precomProductName, precomBrandName, precomCompanyName);
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, femalePreComOrigin, femalePreComOrigin, femalePreComOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleCompOrigin, maleCompOrigin, maleCompOrigin, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode, maleLineCode, maleLineCode, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, maleLineCode2, maleLineCode2, maleLineCode2, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithCompetitorFinishedProductNameMatch() throws Exception {
        String lineTypeOfGpOfProduct = MaterialTypeConstants.FINISHED_LINES;
        String compProductName = "II-COMP-PROD-NAME";
        String compBrandName = "MONSANTO";
        String compCompanyName = "II-NOT-MONSANTO";
        String originOfGpOfProduct = compProductName;
        String lineCodeOfGpOfProduct = compProductName;
        String pedigreeNameOfGpOfProduct = compProductName;
        String lineTypeOfInbred = MaterialTypeConstants.FINISHED_LINES;
        String originOfFemaleInbred = "II-COMP-FEMALE-INBRED";
        String lineCodeOfFemaleInbred = "II-COMP-FEMALE-INBRED";
        String pedigreeOfFemaleInbred = "II-COMP-FEMALE-INBRED";
        String originOfMaleInbred = "II-COMP-MALE-INBRED";
        String lineCodeOfMaleInbred = "II-COMP-MALE-INBRED";
        String pedigreeOfMaleInbred = "II-COMP-MALE-INBRED";
        String importedOrigin = originOfFemaleInbred + "/" + originOfMaleInbred + "//" + lineCodeOfGpOfProduct;
        String importedSource = "II COMP FEMALE INBRED SOURCE - II COMP MALE INBRED SOURCE";
        String gpOwner = "17";
        String lineage = "@.";
        String generation = "F2";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm compProductGp = null;
        Germplasm femaleGp = null;
        Germplasm maleGp = null;
        try {
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);

            compProductGp = appdaoTestHelper.createInbred(lineCodeOfGpOfProduct, gpOwner, CROP_NAME, originOfGpOfProduct);
            appdaoTestHelper.createInbredGeneticMaterial(compProductGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            femaleGp = appdaoTestHelper.createInbred(lineCodeOfFemaleInbred, gpOwner, CROP_NAME, originOfFemaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(femaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            maleGp = appdaoTestHelper.createInbred(lineCodeOfMaleInbred, gpOwner, CROP_NAME, originOfMaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(maleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(compProductName, "T", compBrandName, compCompanyName, USA, compProduct);
            appdaoTestHelper.createProductGermplasm(compProduct, compProductGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    importedOrigin, importedSource, "fp1", null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 1, 3, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithCompetitorHybridProductNameMatch() throws Exception {
        String lineTypeOfGpOfProduct = MaterialTypeConstants.HYBRID_LINES;
        String compProductName = "II-COMP-PROD-NAME";
        String compBrandName = "MONSANTO";
        String compCompanyName = "II-NOT-MONSANTO";
        String originOfGpOfProduct = compProductName;
        String lineCodeOfGpOfProduct = "II-COMP-PEDIGREE-LINE-CODE";
        String pedigreeNameOfGpOfProduct = "II-COMP-PEDIGREE-LINE-CODE";
        String lineTypeOfInbred = MaterialTypeConstants.FINISHED_LINES;
        String originOfFemaleInbred = "II-COMP-FEMALE-INBRED";
        String lineCodeOfFemaleInbred = "II-COMP-FEMALE-INBRED";
        String pedigreeOfFemaleInbred = "II-COMP-FEMALE-INBRED";
        String sourceOfFemaleInbred = "II COMP FEMALE INBRED SOURCE";
        String originOfMaleInbred = "II-COMP-MALE-INBRED";
        String lineCodeOfMaleInbred = "II-COMP-MALE-INBRED";
        String pedigreeOfMaleInbred = "II-COMP-MALE-INBRED";
        String sourceOfMaleInbred = "II COMP MALE INBRED SOURCE";
        String importedOrigin = originOfFemaleInbred + "/" + originOfMaleInbred + "//" + originOfGpOfProduct;
        String importedSource = sourceOfFemaleInbred + " - " + sourceOfMaleInbred;
        String gpOwner = "17";
        String lineage = "@.";
        String generation = "F2";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm compProductGp = null;
        Germplasm femaleGp = null;
        Germplasm maleGp = null;
        try {
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);

            compProductGp = appdaoTestHelper.createGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, gpOwner, CROP_NAME, "F", "T");

            femaleGp = appdaoTestHelper.createInbred(lineCodeOfFemaleInbred, gpOwner, CROP_NAME, originOfFemaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(femaleGp, sourceOfFemaleInbred);

            maleGp = appdaoTestHelper.createInbred(lineCodeOfMaleInbred, gpOwner, CROP_NAME, originOfMaleInbred);
            appdaoTestHelper.createInbredGeneticMaterial(maleGp, sourceOfMaleInbred);

            Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(compProductName, "T", compBrandName, compCompanyName, USA, compProduct);
            appdaoTestHelper.createProductGermplasm(compProduct, compProductGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES,
                    importedOrigin, importedSource, "fp1", null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, generation, lineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 1, 6, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, compProductName, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfGpOfProduct, lineCodeOfGpOfProduct, originOfGpOfProduct, pedigreeNameOfGpOfProduct, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfFemaleInbred, originOfFemaleInbred, pedigreeOfFemaleInbred, CROP_NAME);
            purgeGermplasm(lineTypeOfInbred, lineCodeOfMaleInbred, originOfMaleInbred, pedigreeOfMaleInbred, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithPreComercialProductNameUnfinished() throws Exception {
        String gpOwner = "17";
        String lineTypeOfTopLevelFemaleParent = MaterialTypeConstants.SEGPOP_LINES;
        String lineTypeOfTopLevelMaleParent = MaterialTypeConstants.FINISHED_LINES;
        String femaleOrigin = "II-FEMALE-ORIGIN";
        String maleOrigin = "II-MALE-ORIGIN";
        String maleLineCode = "II-MALE-LINE-CODE";
        String firstLineage = "@.1.";
        String topLevelMalePreComParentLineCode = "II-MALE-LINE-CODE-2";

        String precomBrandName = "MONSANTO";
        String precomCompanyName = "MONSANTO";

        String topLevelFemaleParentLineCode = null;
        String topLevelFemaleParentOrigin = "(" + femaleOrigin + "/" + maleOrigin + ":" + firstLineage + ")/" + maleLineCode;
        String topLevelFemaleParentPedigree = gpOwner + "_" + topLevelFemaleParentOrigin;
        String topLevelMaleParentPreComOrigin = topLevelMalePreComParentLineCode;
        String topLevelMalePreComParentPedigree = gpOwner + "_" + topLevelMalePreComParentLineCode;

        String importedOrigin = topLevelFemaleParentOrigin + "//" + topLevelMalePreComParentLineCode;
        String importedSource = "II SOURCE";
        String importedLineage = "1.2.";
        String importedGeneration = "F3";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm topLevelFemaleGp = null;
        Germplasm topLevelMaleGp = null;
        try {
            purgeProduct(CROP_NAME, topLevelMalePreComParentLineCode, precomBrandName, precomCompanyName);
            purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin,
                    topLevelFemaleParentPedigree, CROP_NAME);
            purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMalePreComParentLineCode, topLevelMaleParentPreComOrigin,
                    topLevelMalePreComParentPedigree, CROP_NAME);

            topLevelFemaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, gpOwner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(topLevelFemaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            topLevelMaleGp = appdaoTestHelper.createInbred(topLevelMalePreComParentLineCode, gpOwner, CROP_NAME,
                    topLevelMaleParentPreComOrigin);
            appdaoTestHelper.createInbredGeneticMaterial(topLevelMaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            Product precomProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(topLevelMalePreComParentLineCode, "T", precomBrandName, precomCompanyName, USA, precomProduct);
            appdaoTestHelper.createProductGermplasm(precomProduct, topLevelMaleGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
                    importedOrigin, importedSource, null, null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, importedGeneration, importedLineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 1, 3, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, topLevelMalePreComParentLineCode, precomBrandName, precomCompanyName);
            purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, CROP_NAME);
            purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMalePreComParentLineCode, topLevelMaleParentPreComOrigin,
                    topLevelMalePreComParentPedigree, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithCompetitorProductNameUnfinished() throws Exception {
        String gpOwner = "17";
        String lineTypeOfTopLevelFemaleParent = MaterialTypeConstants.SEGPOP_LINES;
        String lineTypeOfTopLevelMaleParent = MaterialTypeConstants.FINISHED_LINES;
        String femaleOrigin = "II-FEMALE-ORIGIN";
        String maleOrigin = "II-MALE-ORIGIN";
        String maleLineCode = "II-MALE-LINE-CODE";
        String firstLineage = "@.1.";
        String topLevelMaleParentLineCode = "II-MALE-LINE-CODE-2";

        String compBrandName = "MONSANTO";
        String compCompanyName = "II-NOT-MONSANTO";

        String topLevelFemaleParentLineCode = null;
        String topLevelFemaleParentOrigin = "(" + femaleOrigin + "/" + maleOrigin + ":" + firstLineage + ")/" + maleLineCode;
        String topLevelFemaleParentPedigree = gpOwner + "_" + topLevelFemaleParentOrigin;
        String topLevelMaleParentOrigin = topLevelMaleParentLineCode;
        String topLevelMaleParentPedigree = gpOwner + "_" + topLevelMaleParentLineCode;

        String importedOrigin = topLevelFemaleParentOrigin + "//" + topLevelMaleParentLineCode;
        String importedSource = "II SOURCE";
        String importedLineage = "@.1.2.";
        String importedGeneration = "F4";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm topLevelFemaleGp = null;
        Germplasm topLevelMaleGp = null;
        try {
            purgeProduct(CROP_NAME, topLevelMaleParentLineCode, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, CROP_NAME);
            purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin, topLevelMaleParentPedigree, CROP_NAME);

            topLevelFemaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, gpOwner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(topLevelFemaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            topLevelMaleGp = appdaoTestHelper.createInbred(topLevelMaleParentLineCode, gpOwner, CROP_NAME, topLevelMaleParentOrigin);
            appdaoTestHelper.createInbredGeneticMaterial(topLevelMaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);

            Product precomProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(topLevelMaleParentLineCode, "T", compBrandName, compCompanyName, USA, precomProduct);
            appdaoTestHelper.createProductGermplasm(precomProduct, topLevelMaleGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES,
                    importedOrigin, importedSource, null, null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, importedGeneration, importedLineage, null, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 4, 1, 4, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            purgeProduct(CROP_NAME, topLevelMaleParentLineCode, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, CROP_NAME);
            purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin, topLevelMaleParentPedigree, CROP_NAME);
            removeStagingInventoryTestData(templateName);
        }
    }

    public void testProcessInventoryIntoMidasWithCompetitorHybridProductNameUnfinished() throws Exception {
        String gpOwner = "17";
        String compBrandName = "MONSANTO";
        String compCompanyName = "II-NOT-MONSANTO";
        String lineTypeOfTopLevelFemaleParent = MaterialTypeConstants.HYBRID_LINES;
        String lineTypeOfTopLevelMaleParent = MaterialTypeConstants.SEGPOP_LINES;

        String topLevelFemaleParentOrigin = "II-TOP-LEVEL-FEMALE-ORIGIN";
        String topLevelFemaleParentPedigree = topLevelFemaleParentOrigin;
        String topLevelFemaleParentLineCode = null;

        String topLevelMaleParentLineage = "1.2.";
        String topLevelMaleParentOrigin = "II-TOP-LEVEL-MALE-PED/TOP-LEVEL-MALE-PED";
        String topLevelMaleParentPedigree = gpOwner + "_" + topLevelMaleParentOrigin + ":" + topLevelMaleParentLineage;
        String topLevelMaleParentLineCode = null;

        String importedOrigin = topLevelFemaleParentOrigin + "/(" + topLevelMaleParentOrigin + ":" + topLevelMaleParentLineage + ")";
        String importedLineCode = null;
        String importedGeneration = "F3";
        String importedLineage = "1.2.";

        String importedSource = "II SOURCE";

        appdaoTestHelper = new TestHelper();
        appdaoTestHelper.beginTransaction();

        Germplasm topLevelFemaleGp = null;
        Germplasm topLevelMaleGp = null;
        try {
            removeStagingInventoryTestData(templateName);
            purgeProduct(CROP_NAME, topLevelFemaleParentOrigin, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, CROP_NAME);
            purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin, topLevelMaleParentPedigree, CROP_NAME);

            topLevelFemaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, gpOwner, CROP_NAME, "F", "T");
            appdaoTestHelper.createGeneticMaterial(topLevelFemaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F1", null);

            topLevelMaleGp = appdaoTestHelper.createGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentPedigree, topLevelMaleParentOrigin, topLevelMaleParentPedigree, gpOwner, CROP_NAME, "F", "F");
            appdaoTestHelper.createGeneticMaterial(topLevelMaleGp, SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE, "F3", "1.2.");

            Product compProduct = appdaoTestHelper.createProduct(CROP_NAME, "T");
            appdaoTestHelper.createProductName(topLevelFemaleParentOrigin, "T", compBrandName, compCompanyName, USA,
                    compProduct);
            appdaoTestHelper.createProductGermplasm(compProduct, topLevelFemaleGp);

            appdaoTestHelper.endTransaction(true);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            appdaoTestHelper = new TestHelper();
            appdaoTestHelper.beginTransaction();
            session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
        }

        try {
            StagingInventoryHeader header = createStagingInventoryHeader(templateName, CROP_NAME, userId,
                    MaterialTypeConstants.SEGPOP_LINES);
            StagingInventory mainRecord = createStagingInventory(header, MaterialTypeConstants.SEGPOP_LINES,
                    importedOrigin, importedSource, null, null, null, null, gpOwner, gpOwner, MaterialTypeConstants.SEGPOP_LINES,
                    userId, importedGeneration, importedLineage, importedLineCode, null, null, null, StagingInventoryStatusConstants.NEW, null, "Y");

            importStagingInventory(header, mainRecord);
            preprocessMainRecordAndParentageForBatchProcessing(header, mainRecord, StagingInventoryStatusConstants.APPROVED, userId);
            StagingInventory stagingInventoryRec = getStagingInventoryWithParentage(mainRecord);

            SegpopIIProcessor processor = new SegpopIIProcessor();
            MockInventoryContext context = new MockInventoryContext(stagingInventoryRec);
            MidasContext midasContext = processor.processInventory(context);

            assertMidasContext(midasContext, 3, 1, 3, stagingInventoryRec.getStagingParentage().size());
        } finally {
            appdaoTestHelper.endTransaction(false);
            removeStagingInventoryTestData(templateName);
            purgeProduct(CROP_NAME, topLevelFemaleParentOrigin, compBrandName, compCompanyName);
            purgeGermplasm(lineTypeOfTopLevelFemaleParent, topLevelFemaleParentLineCode, topLevelFemaleParentOrigin, topLevelFemaleParentPedigree, CROP_NAME);
            purgeGermplasm(lineTypeOfTopLevelMaleParent, topLevelMaleParentLineCode, topLevelMaleParentOrigin, topLevelMaleParentPedigree, CROP_NAME);
        }
    }
}