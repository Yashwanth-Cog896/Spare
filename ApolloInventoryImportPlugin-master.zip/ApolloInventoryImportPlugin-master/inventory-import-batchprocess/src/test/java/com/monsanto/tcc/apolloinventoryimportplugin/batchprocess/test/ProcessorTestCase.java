/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.MidasContext;
import com.monsanto.tcc.apolloinventoryimportplugin.common.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.posclients.ImportPOSClient;
import junit.framework.TestCase;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Filename:    $RCSfile: ProcessorTestCase.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:08:03 $
 *
 * @author apatro
 * @version $Revision: 1.18 $
 */
public class ProcessorTestCase extends TestCase {
    protected Session session;
    protected TestHelper appdaoTestHelper;
    protected String userId;

    public ProcessorTestCase() {
        super();
    }

    public ProcessorTestCase(String string) {
        super(string);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        appdaoTestHelper = new TestHelper(session);
        userId = System.getProperty("user.name");
    }

    protected void tearDown() throws Exception {
        if (session != null && session.isOpen()) {
            session.getTransaction().rollback();
        }
        super.tearDown();
    }

    protected void assertMidasContext(MidasContext midasContext,
                                      int expectedGermlasmCount, int expectedInventoryCount,
                                      int expectedGeneticMaterialCount, int expectedParentageCount
    ) {
        assertNotNull(midasContext.getGermplasm());
        assertEquals(expectedGermlasmCount, midasContext.getGermplasm().length);

        assertNotNull(midasContext.getInventory());
        assertEquals(expectedInventoryCount, midasContext.getInventory().length);

        assertNotNull(midasContext.getGeneticMatterial());
        assertEquals(expectedGeneticMaterialCount, midasContext.getGeneticMatterial().length);

        assertNotNull(midasContext.getParentage());
        assertEquals(expectedParentageCount, midasContext.getParentage().length);
    }

    public StagingInventory createStagingInventory(StagingInventoryHeader inventoryHeader, String subImportType,
                                                   String origin, String source,
                                                   String femaleParentSource, String maleParentSource,
                                                   String femaleGpOwner, String maleGpOwner, String inventoryOwner,
                                                   String germplasmOwner, String lineType,
                                                   String userId, String generation, String lineage, String lineCode,
                                                   String lineFunctionRefId, String cytoplasmDonorSource,
                                                   String cytoplasmDonorPedigree, String importStatusCode,
                                                   String parentalSources, String buildParentage) throws
            InvalidParentalSourceSyntaxException {
        return createStagingInventory(inventoryHeader, subImportType, origin, source, femaleParentSource, maleParentSource,
                femaleGpOwner, maleGpOwner, inventoryOwner, germplasmOwner, lineType, userId, generation, lineage, lineCode,
                lineFunctionRefId, cytoplasmDonorSource, cytoplasmDonorPedigree, importStatusCode, parentalSources,
                buildParentage, null);
    }

    public StagingInventory createStagingInventory(StagingInventoryHeader inventoryHeader, String subImportType,
                                                   String origin, String source,
                                                   String femaleParentSource, String maleParentSource,
                                                   String femaleGpOwner, String maleGpOwner, String inventoryOwner,
                                                   String germplasmOwner, String lineType,
                                                   String userId, String generation, String lineage, String lineCode,
                                                   String lineFunctionRefId, String cytoplasmDonorSource,
                                                   String cytoplasmDonorPedigree, String importStatusCode,
                                                   String parentalSources, String buildParentage, String eventString) throws
            InvalidParentalSourceSyntaxException {
        return createStagingInventory(inventoryHeader, subImportType, origin, source, femaleParentSource, maleParentSource,
                femaleGpOwner, maleGpOwner, inventoryOwner,
                germplasmOwner, lineType,
                userId, generation, lineage, lineCode,
                lineFunctionRefId, cytoplasmDonorSource,
                cytoplasmDonorPedigree, importStatusCode,
                parentalSources, buildParentage,
                eventString,
                null);
    }

    public StagingInventory createStagingInventory(StagingInventoryHeader inventoryHeader, String subImportType,
                                                   String origin, String source,
                                                   String femaleParentSource, String maleParentSource,
                                                   String femaleGpOwner, String maleGpOwner, String inventoryOwner,
                                                   String germplasmOwner, String lineType,
                                                   String userId, String generation, String lineage, String lineCode,
                                                   String lineFunctionRefId, String cytoplasmDonorSource,
                                                   String cytoplasmDonorPedigree, String importStatusCode,
                                                   String parentalSources, String buildParentage,
                                                   String eventString,
                                                   String vegetativeStructure) throws
            InvalidParentalSourceSyntaxException {
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setSource(source);
        stagingInventory.setFemaleParentSource(femaleParentSource);
        stagingInventory.setMaleParentSource(maleParentSource);
        stagingInventory.setGermplasmOwnerOfFemaleParent(femaleGpOwner);
        stagingInventory.setGermplasmOwnerOfMaleParent(maleGpOwner);
        stagingInventory.setInventoryOwner(inventoryOwner);
        stagingInventory.setGermplasmOwner(germplasmOwner);
        stagingInventory.setGeneration(generation);
        stagingInventory.setLineage(lineage);
        stagingInventory.setLineType(lineType);
        stagingInventory.setLineCode(lineCode);
        stagingInventory.setInventoryHeader(inventoryHeader);
        stagingInventory.setImportType(getImportTypeByAbbreviation(subImportType));
        stagingInventory.setBuildParentage(buildParentage);
        stagingInventory.setAuthorityProcessed(userId);
        stagingInventory.setAuthorityRequested(userId);
        stagingInventory.setEvent(eventString);

        stagingInventory.setUserSpecifiedSource("T");

        stagingInventory.setImportStatus(getImportStatusByStatusCode(importStatusCode));
        stagingInventory.setLineFunction(lineFunctionRefId);
        stagingInventory.setCytoplasmDonorSource(cytoplasmDonorSource);
        stagingInventory.setCytoplasmDonorPedigree(cytoplasmDonorPedigree);

        if (!StringUtils.isNullOrEmpty(parentalSources)) {
            ParentalSource[] parentalSourceArray = new ParentalSourceParser(parentalSources).getParentalSources();
            for (int i = 0; i < parentalSourceArray.length; i++) {
                ParentalSource parentalSource = parentalSourceArray[i];
                parentalSource.setMainInventory(stagingInventory);
            }
            Set set = new HashSet();
            set.addAll(Arrays.asList(parentalSourceArray));
            stagingInventory.setParentalSources(set);
        }

        stagingInventory.setVegetativeStructure(vegetativeStructure);

        return stagingInventory;


    }

    public StagingInventoryHeader createStagingInventoryHeader(String templateFileName, String cropName, String userId,
                                                               String importTypeAbbrev) {
        StagingInventoryHeader inventoryHeader = new StagingInventoryHeader();
        inventoryHeader.setCropName(cropName);
        inventoryHeader.setUserId(userId);
        inventoryHeader.setBatchDate(new Date());
        inventoryHeader.setTemplateName(templateFileName);
        ImportType importType = new ImportType();
        importType.setAbbreviation(importTypeAbbrev);
        inventoryHeader.setImportType(importType);


        return inventoryHeader;
    }

    private ImportType getImportTypeByAbbreviation(String importTypeAbbrev) {
        ImportType importType = new ImportType();
        importType.setAbbreviation(importTypeAbbrev);
        return importType;
    }

    private ImportStatus getImportStatusByStatusCode(String statusCode) {
        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode(statusCode);
        return importStatus;
    }

    protected void importStagingInventory(StagingInventoryHeader inventoryHeader, StagingInventory inventory) {
        ImportPOSClient importPosClient = new ImportPOSClient();
        try {
            importPosClient.importStagingInventories(inventoryHeader, new StagingInventory[]{inventory});
            String errorResponse = importPosClient.getPOSErrorResponseMessage();
            assertTrue(StringUtils.isNullOrEmpty(errorResponse));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered unexpected exception - " + e);
        }
    }

    protected StagingInventory getStagingInventoryWithParentage(
            StagingInventory inventory) {
        return appdaoTestHelper.getStagingInventoryWithParentage(inventory.getInventoryHeader().getUserId(),
                inventory.getInventoryHeader().getCropName(), inventory.getInventoryHeader().getTemplateName());
    }

    protected void preprocessMainRecordAndParentageForBatchProcessing(StagingInventoryHeader header,
                                                                      StagingInventory mainInventory, String statusCode,
                                                                      String userId) {
        mainInventory.setInventoryHeader(header);
        appdaoTestHelper.preprocessMainRecordAndParentageForBatchProcessing(mainInventory, statusCode, userId);
        session.flush();
    }

    protected void purgeGermplasm(String lineType, String lineCode, String origin, String pedigreeName,
                                  String cropName) {
        appdaoTestHelper.purgeGermplasm(lineType, lineCode, origin, pedigreeName, cropName);
    }

    protected void purgeProduct(String cropName, String productNameString, String brandName, String companyName) {
        appdaoTestHelper.purgeProduct(cropName, productNameString, brandName, companyName);
    }

    protected void purgeEventConstruct(String cropName, String eventName, String constructName, String refActive) {
        appdaoTestHelper.purgeEventConstruct(cropName, eventName, constructName, refActive);
    }

    protected void removeStagingInventoryTestData(String templateName) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory()
                .openSession(); // This is okay as this should be done in a separate session
        session.beginTransaction();
        try {
            this.deleteStagingInventory(templateName, session);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        session.getTransaction().commit();
        session.close();
    }

    private void deleteStagingInventory(String templateName, Session session) {
        deleteFromStagingParentage(session, templateName);
        deleteFromStagingInventory(session, templateName);
        deleteFromStagingInventoryHeader(session, templateName);
        session.flush();
    }

    private void deleteFromStagingParentage(Session session, String templateName) {
        Query query;

        query = session.createQuery(
                "select distinct si " +
                        "from StagingParentage sp, StagingInventory si, StagingInventoryHeader ih " +
                        "where ih.templateName = :templateName and si.inventoryHeader = ih and sp.mainInventory = si");
        query.setParameter("templateName", templateName);
        List stagingInventoryList = query.list();
        if (stagingInventoryList != null) {
            for (int i = 0; i < stagingInventoryList.size(); i++) {
                StagingInventory si = (StagingInventory) stagingInventoryList.get(i);
                session.delete(si);
            }
        }
    }

    private void deleteFromStagingInventory(Session session, String templateName) {
        Query query;
        List stagingInventoryList;

        query = session.createQuery(
                "select si " +
                        "from StagingInventory si, StagingInventoryHeader ih " +
                        "where ih.templateName = :templateName and si.inventoryHeader = ih");
        query.setParameter("templateName", templateName);
        stagingInventoryList = query.list();
        if (stagingInventoryList != null) {
            for (int i = 0; i < stagingInventoryList.size(); i++) {
                StagingInventory si = (StagingInventory) stagingInventoryList.get(i);
                session.delete(si);
            }
        }
    }

    private void deleteFromStagingInventoryHeader(Session session, String templateName) {
        List invHdrList = session.createCriteria(StagingInventoryHeader.class)
                .setFetchMode("stagingInventory", FetchMode.JOIN)
                .add(Restrictions.eq("templateName", templateName)).list();

        for (int i = 0; i < invHdrList.size(); i++) {
            StagingInventoryHeader invHdr = (StagingInventoryHeader) invHdrList.get(i);
            session.delete(invHdr);
        }
    }
}