/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import junit.framework.TestCase;

/**
 * Filename: $Id: IIProcessorFactory_UT.java,v 1.2 2009-06-05 14:08:03 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class IIProcessorFactory_UT extends TestCase {
    public void testCreateCommercialInventoryImportProcessor() throws IllegalAccessException, InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.COMMERCIAL_PRODUCT);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof CommercialIIProcessor);
    }

    public void testCreateCompetitorInventoryImportProcessor() throws IllegalAccessException, InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.COMPETITOR_PRODUCT);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof CompetitorIIProcessor);
    }

    public void testCreateFinishedInventoryImportProcessor() throws IllegalAccessException, InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.FINISHED_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof FinishedIIProcessor);
    }

    public void testCreateCodedInventoryImportProcessor() throws IllegalAccessException, InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.CODED_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof CodedIIProcessor);
    }

    public void testCreateSegpopInventoryImportProcessor() throws IllegalAccessException, InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.SEGPOP_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        stagingInventory.setImportType(importType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof SegpopIIProcessor);
    }

    public void testCreateHybridFinishedInventoryImportProcessor() throws IllegalAccessException, InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.HYBRID_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        ImportType subImportType = new ImportType();
        subImportType.setAbbreviation(MaterialTypeConstants.HYBRID_FINISHED_LINES);
        stagingInventory.setImportType(subImportType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof HybridFinishedProcessor);
    }

    public void testCreateHybridUnfinishedInventoryImportProcessor() throws IllegalAccessException,
            InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.HYBRID_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        ImportType subImportType = new ImportType();
        subImportType.setAbbreviation(MaterialTypeConstants.HYBRID_UNFINISHED_LINES);
        stagingInventory.setImportType(subImportType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof HybridUnfinishedProcessor);
    }

    public void testCreateF1SegpopFinishedInventoryImportProcessor() throws IllegalAccessException,
            InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.SEGPOP_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        ImportType subImportType = new ImportType();
        subImportType.setAbbreviation(MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES);
        stagingInventory.setImportType(subImportType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof F1SegpopFinishedProcessor);
    }

    public void testCreateF1SegpopUnfinishedInventoryImportProcessor() throws IllegalAccessException,
            InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.SEGPOP_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        ImportType subImportType = new ImportType();
        subImportType.setAbbreviation(MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES);
        stagingInventory.setImportType(subImportType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof F1SegpopUnfinishedProcessor);
    }

    public void testCreateMsc0SegpopFinishedInventoryImportProcessor() throws IllegalAccessException,
            InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.SEGPOP_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        ImportType subImportType = new ImportType();
        subImportType.setAbbreviation(MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_FINISHED_LINES);
        stagingInventory.setImportType(subImportType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof F1SegpopFinishedProcessor);
    }

    public void testCreateMsc0SegpopUnfinishedInventoryImportProcessor() throws IllegalAccessException,
            InstantiationException {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        ImportType importType = new ImportType();
        importType.setAbbreviation(MaterialTypeConstants.SEGPOP_LINES);
        invHeader.setImportType(importType);
        stagingInventory.setInventoryHeader(invHeader);
        ImportType subImportType = new ImportType();
        subImportType.setAbbreviation(MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_UNFINISHED_LINES);
        stagingInventory.setImportType(subImportType);

        IIProcessor iip = IIProcessorFactory.createInventoryImportProcessor(stagingInventory);

        assertTrue(iip instanceof F1SegpopUnfinishedProcessor);
    }

    public void testCreateF1SegpopInventoryImportProcessor_Finished() throws InstantiationException {
        ImportType f1SegpopType = new ImportType();
        f1SegpopType.setAbbreviation(MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES);

        IIProcessor iip = IIProcessorFactory.createF1SegpopInventoryImportProcessor(
                f1SegpopType.getAbbreviation(), new MidasContext(), new StagingParentageHelper(null));

        assertTrue(iip instanceof F1SegpopFinishedProcessor);
    }

    public void testCreateF1SegpopInventoryImportProcessor_Unfinished() throws InstantiationException {
        ImportType f1SegpopType = new ImportType();
        f1SegpopType.setAbbreviation(MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES);

        IIProcessor iip = IIProcessorFactory.createF1SegpopInventoryImportProcessor(
                f1SegpopType.getAbbreviation(), new MidasContext(), new StagingParentageHelper(null));

        assertTrue(iip instanceof F1SegpopUnfinishedProcessor);
    }

    public void testCreateMsc0SegpopInventoryImportProcessor_Finished() throws InstantiationException {
        ImportType f1SegpopType = new ImportType();
        f1SegpopType.setAbbreviation(MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_FINISHED_LINES);

        IIProcessor iip = IIProcessorFactory.createF1SegpopInventoryImportProcessor(
                f1SegpopType.getAbbreviation(), new MidasContext(), new StagingParentageHelper(null));

        assertTrue(iip instanceof F1SegpopFinishedProcessor);
    }

    public void testCreateMsc0SegpopInventoryImportProcessor_Unfinished() throws InstantiationException {
        ImportType f1SegpopType = new ImportType();
        f1SegpopType.setAbbreviation(MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_UNFINISHED_LINES);

        IIProcessor iip = IIProcessorFactory.createF1SegpopInventoryImportProcessor(
                f1SegpopType.getAbbreviation(), new MidasContext(), new StagingParentageHelper(null));

        assertTrue(iip instanceof F1SegpopUnfinishedProcessor);
    }

    public void testCreateF1SegpopInventoryImportProcessor_ThrowsException() {
        ImportType f1SegpopType = new ImportType();
        f1SegpopType.setAbbreviation(MaterialTypeConstants.SEGPOP_LINES);

        try {
            IIProcessorFactory.createF1SegpopInventoryImportProcessor(f1SegpopType.getAbbreviation(),
                    new MidasContext(), new StagingParentageHelper(null));
            fail("Expecting InstantiationException");
        } catch (InstantiationException e) {
            assertTrue(e.getMessage().indexOf(f1SegpopType.getAbbreviation()) >= 0);
        }
    }

}
