/*
 CommercialHybrid_UT was created on Feb 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineType;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gm.GeneticMaterialOfGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gm.GeneticMaterialOfHybridGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gp.GermplasmPicker;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.CommercialHybrid;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.PrimaryGeneticMaterialNotFoundException;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.PrimaryGermplasmNotFoundException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: CommercialHybrid_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-03 22:31:27 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class CommercialHybrid_UT extends TestCase {
  public CommercialHybrid_UT(String name) {
    super(name);
  }

  public void testCreate_StagingInventoryMustBeHybrid() throws Exception {
    try {
      new CommercialHybrid(null);
      fail("expecting IllegalArgumentException");
    } catch(IllegalArgumentException e) {
      // expected path
    }

    try {
      new CommercialHybrid(new StagingInventory());
      fail("expecting IllegalArgumentException");
    } catch(IllegalArgumentException e) {
      // expected path
    }
  }

  public void testGetGermplasmOfFemaleParentOfPrimaryGeneticMaterial() throws Exception {
    StagingInventory stagingInventory = new StagingInventory();
    stagingInventory.setLineType(MaterialTypeConstants.HYBRID_LINES);
    CommercialHybrid commercialHybrid = new MockCommercialHybrid_Gp(stagingInventory);
    Germplasm germplasm = commercialHybrid.getGermplasmOfFemaleParentOfPrimaryGeneticMaterial();

    assertNotNull(germplasm);
  }

  public void testGetGermplasmOfFemaleParentOfPrimaryGeneticMaterial_No_Primary_Gp_Throws_Exception() throws Exception {
    StagingInventory stagingInventory = new StagingInventory();
    stagingInventory.setLineType(MaterialTypeConstants.HYBRID_LINES);
    try {
      CommercialHybrid commercialHybrid = new MockCommercialHybrid_NoPrimaryGp(stagingInventory);
      commercialHybrid.getGermplasmOfFemaleParentOfPrimaryGeneticMaterial();
      fail("expecting PrimaryGermplasmNotFoundException");
    } catch(PrimaryGermplasmNotFoundException e) {
      // expected path
    }
  }

  public void testGetGermplasmOfFemaleParentOfPrimaryGeneticMaterial_No_Primary_Gm_Throws_Exception() throws Exception {
    StagingInventory stagingInventory = new StagingInventory();
    stagingInventory.setLineType(MaterialTypeConstants.HYBRID_LINES);
    try {
      CommercialHybrid commercialHybrid = new MockCommercialHybrid_NoPrimaryGm(stagingInventory);
      commercialHybrid.getGermplasmOfFemaleParentOfPrimaryGeneticMaterial();
      fail("expecting PrimaryGeneticMaterialNotFoundException");
    } catch(PrimaryGeneticMaterialNotFoundException e) {
      // expected path
    }
  }
  
  public void testGetGeneticMaterialIdForSourceOfFemaleParent() throws Exception {
    StagingInventory stagingInventory = new StagingInventory();
    stagingInventory.setLineType(MaterialTypeConstants.HYBRID_LINES);
    CommercialHybrid commercialHybrid = new MockCommercialHybrid_Gm(stagingInventory);
    GeneticMaterial geneticMaterial = commercialHybrid.getGeneticMaterialForSourceOfFemaleParent();

    assertNotNull(geneticMaterial);
  }

  class MockCommercialHybrid_Gp extends CommercialHybrid {

    public MockCommercialHybrid_Gp(StagingInventory stagingInventory) {
      super(stagingInventory);
    }

    protected GermplasmPicker createGermplasmPicker() {
      return new MockGermplasmPicker();
    }

    protected GeneticMaterialOfHybridGermplasmDAO createGeneticMaterialOfHybridGermplasmDAO(Germplasm primaryGermplasm) {
      return new MockGeneticMaterialOfHybridGermplasmDAO(primaryGermplasm);
    }
  }

  class MockCommercialHybrid_Gm extends CommercialHybrid {

    public MockCommercialHybrid_Gm(StagingInventory stagingInventory) {
      super(stagingInventory);
    }


    protected Germplasm getGermplasmAssociatedToParentOfPrimaryGeneticMaterial(String parentalRole) throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
      return new Germplasm();
    }

    protected GeneticMaterialOfGermplasmDAO createGeneticMaterialOfGermplasmDAO(Germplasm germplasm) {
      return new MockGeneticMaterialOfGermplasmDAO(germplasm);
    }
  }

  class MockCommercialHybrid_NoPrimaryGp extends CommercialHybrid {

    public MockCommercialHybrid_NoPrimaryGp(StagingInventory stagingInventory) {
      super(stagingInventory);
    }


    protected GermplasmPicker createGermplasmPicker() {
      return new MockGermplasmPicker_NoPrimaryGp();
    }

    protected GeneticMaterialOfHybridGermplasmDAO createGeneticMaterialOfHybridGermplasmDAO(Germplasm primaryGermplasm) {
      return new MockGeneticMaterialOfHybridGermplasmDAO(primaryGermplasm);
    }
  }

  class MockCommercialHybrid_NoPrimaryGm extends CommercialHybrid {

    public MockCommercialHybrid_NoPrimaryGm(StagingInventory stagingInventory) {
      super(stagingInventory);
    }


    protected GermplasmPicker createGermplasmPicker() {
      return new MockGermplasmPicker();
    }

    protected GeneticMaterialOfHybridGermplasmDAO createGeneticMaterialOfHybridGermplasmDAO(Germplasm primaryGermplasm) {
      return new MockGeneticMaterialOfHybridGermplasmDAO_No_Primary_Gm(primaryGermplasm);
    }
  }

  class MockGermplasmPicker_NoPrimaryGp extends GermplasmPicker {

    public Germplasm getPrimaryGermplasm(StagingInventory stagingInventory, GermplasmListFetchStrategy germplasmListFetchStrategy) {
      return null;
    }
  }

  class MockGermplasmPicker extends GermplasmPicker {

    public Germplasm getPrimaryGermplasm(StagingInventory stagingInventory, GermplasmListFetchStrategy germplasmListFetchStrategy) {
      return createHybridGermplasm();
    }

    private Germplasm createHybridGermplasm() {
      LineType lineType = new LineType();
      lineType.setLineTypeRefId(MaterialTypeConstants.HYBRID_LINES);
      Germplasm germplasm = new Germplasm();
      germplasm.setLineType(lineType);
      return germplasm;
    }
  }

  class MockGeneticMaterialOfHybridGermplasmDAO extends GeneticMaterialOfHybridGermplasmDAO {

    public MockGeneticMaterialOfHybridGermplasmDAO(Germplasm germplasm) {
      super(germplasm);
    }


    public GeneticMaterial getParentOfPrimaryGeneticMaterial(String parentalRole) {
      GeneticMaterial geneticMaterial = new GeneticMaterial();
      geneticMaterial.setGermplasm(new Germplasm());
      return geneticMaterial;
    }
  }

  class MockGeneticMaterialOfHybridGermplasmDAO_No_Primary_Gm extends GeneticMaterialOfHybridGermplasmDAO {

    public MockGeneticMaterialOfHybridGermplasmDAO_No_Primary_Gm(Germplasm germplasm) {
      super(germplasm);
    }


    public GeneticMaterial getParentOfPrimaryGeneticMaterial(String parentalRole) {
      return null;
    }
  }

  class MockGeneticMaterialOfGermplasmDAO extends GeneticMaterialOfGermplasmDAO {

    public MockGeneticMaterialOfGermplasmDAO(Germplasm germplasm) {
      super(germplasm);
    }

    public GeneticMaterial getGeneticMaterial(String source) {
      return new GeneticMaterial();
    }
  }

}