/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.test;

import junit.framework.TestCase;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.StagingParentageHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.Set;
import java.util.HashSet;

/**
 * Filename:    $RCSfile: StagingParentageHelper_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-07-28 17:21:16 $
 *
 * @author ddbrow5
 * @version $Revision: 1.3 $
 */
public class StagingParentageHelper_UT extends TestCase {
  public void testIsInventoryRecurringParent_PipeInbred() throws Exception {
    StagingInventory inventory = getStagingInventory(0, null, "|", "INBRED", null, null, null);

    StagingParentageHelper helper = new StagingParentageHelper(null);
    assertTrue(helper.isInventoryRecurringParent(inventory));
  }

  public void testIsInventoryRecurringParent_F1Hybrid() throws Exception {
    StagingInventory inventory = getStagingInventory(5, "A", null, "F1", null, null, MaterialTypeConstants.HYBRID_LINES);

    Set parentageSet = getParentageSet(inventory);
    StagingParentageHelper helper = new StagingParentageHelper(parentageSet);
    assertTrue(helper.isInventoryRecurringParent(inventory));
  }

  private Set getParentageSet(StagingInventory f1Parent) {
    StagingInventory mainInventory = getStagingInventory(1, "A*2/B", null, "BC1", null, null, null);
    StagingInventory parentInventory = getStagingInventory(2, "A/B", null, "F1", null, null, null);
    StagingInventory parentOfF1_1 = getStagingInventory(3, "A", null, "INBRED", null, null, null);
    StagingInventory parentOfF1_2 = getStagingInventory(4, "B", null, "INBRED", null, null, null);

    Set<StagingParentage> parentageSet = new HashSet<StagingParentage>();
    parentageSet.add(getParentage(mainInventory, mainInventory, parentInventory, 1));
    parentageSet.add(getParentage(mainInventory, mainInventory, f1Parent, 1));
    parentageSet.add(getParentage(mainInventory, parentInventory, parentOfF1_1, 2));
    parentageSet.add(getParentage(mainInventory, parentInventory, parentOfF1_2, 3));

    return parentageSet;
  }

  private StagingInventory getStagingInventory(long id, String origin, String lineage, String generation,
                                               String lineCode, String source, String lineType) {
    StagingInventory inventory = new StagingInventory();
    inventory.setId(new Long(id));
    inventory.setOrigin(origin);
    inventory.setLineage(lineage);
    inventory.setGeneration(generation);
    inventory.setLineCode(lineCode);
    inventory.setLineType(lineType);
    inventory.setSource(source);
    return inventory;
  }

  private StagingParentage getParentage(StagingInventory mainInventory, StagingInventory childInventory, StagingInventory parentInventory, long recordLevel) {
    StagingParentage parentage = new StagingParentage();
    parentage.setParentInventory(parentInventory);
    parentage.setMainInventory(mainInventory);
    parentage.setChildInventory(childInventory);
    parentage.setRecordLevel(new Long(recordLevel));
    return parentage;
  }
}