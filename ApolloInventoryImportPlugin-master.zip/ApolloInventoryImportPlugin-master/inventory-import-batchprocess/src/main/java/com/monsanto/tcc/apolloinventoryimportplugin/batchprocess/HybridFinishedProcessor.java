/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.FinishedGeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.FinishedGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.HybridGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ParentageList;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.inventorymaterial.hybridlines.GermplasmListFetchStrategyFinishedHybrid;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridFinishedProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:	$Date: 2008-06-12 04:50:23 $
 *
 * @author ddbrow5
 * @version $Revision: 1.27 $
 * @noinspection UnusedDeclaration
 */
public class HybridFinishedProcessor extends AbstractStagingInventoryProcessor {
  public static final String INVENTORY_CANNOT_BE_NULL_MSG = "InventoryContext cannot be null.";
  public static final String SESSION_CANNOT_BE_NULL_MSG = "Session cannot be null.";
  public static final String TWO_PARENTS_MUST_EXIST_MSG = "Two parents must exist.";
  protected StagingParentageHelper stagingParentageHelper;

  public MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException {
    if (null == inventoryContext) {
      throw new IllegalStateException(INVENTORY_CANNOT_BE_NULL_MSG);
    }

    StagingInventory stagingInventory = inventoryContext.getStagingInventory();
    stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());
    if (processMainRecord(inventoryContext)) {
      processSubRecords(stagingInventory, inventoryContext);
    }

    return midasContext;
  }

  private boolean processMainRecord(StagingInventory stagingInventory, InventoryContext inventoryContext) {
    boolean parentageNotExists = true;
    GeneticMaterial geneticMaterial;

    Inventory inventory = new MidasInventoryDAO().getArchivedInventory(stagingInventory,
            createGermplasmFetchStrategyForFinishedHybrid());

    if (inventory != null) {
      geneticMaterial = inventory.getGeneticMaterial();
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        unarchiveMidasInventory(inventory, stagingInventory);
        addInventory(inventory);
      }
    } else {
      geneticMaterial = fetchExistingMatchingGeneticMaterial(stagingInventory);

      if (geneticMaterial == null) {
        Germplasm germplasm = fetchPrimaryGermplasm(stagingInventory);
        if (germplasm == null) {
          germplasm = createMidasGermplasm(stagingInventory);
          stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
          addGermplasm(germplasm);
        }
        geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
        addGeneticMaterial(geneticMaterial);
      } else if (parentageExists(geneticMaterial)) {
        parentageNotExists = false;
        inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
            geneticMaterial.getGeneticMaterialId());
      }
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        inventory = createMidasInventory(stagingInventory, geneticMaterial);
        addInventory(inventory);
      }
    }

    stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

    if (parentageNotExists) {
      stagingInventory.setImportStatus(getImportedStatus());
    } else {
      stagingInventory.setImportStatus(getUnprocessedStatus());
    }

    return parentageNotExists;
  }

  private boolean processMainRecord(InventoryContext inventoryContext) {
    StagingInventory stagingInventory = inventoryContext.getStagingInventory();
    return processMainRecord(stagingInventory, inventoryContext);
  }

  private Germplasm fetchPrimaryGermplasm(StagingInventory stagingInventory) {
    Germplasm germplasm;
    germplasm = stagingParentageHelper.getInventoryGermplasm(stagingInventory);
    if (germplasm == null) {
      germplasm = createHybridGermplasmDAO(stagingInventory.getInventoryHeader().getCropName(),
          stagingInventory)
          .getPrimaryGermplasm_FinishedHybridOriginExist(stagingInventory.getOrigin());
      if (germplasm != null) {
        stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
      }
    }

    return germplasm;
  }

  protected HybridGermplasmDAO createHybridGermplasmDAO(String cropName, StagingInventory stagingInventory) {
    LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
        .getLineFunctionCriteria();
    return new HybridGermplasmDAO(cropName, lineFunctionCriteria);
  }

  protected GermplasmListFetchStrategyFinishedHybrid createGermplasmFetchStrategyForFinishedHybrid() {
    return new GermplasmListFetchStrategyFinishedHybrid();
  }

  private GeneticMaterial fetchExistingMatchingGeneticMaterial(StagingInventory stagingInventory) {
    return new MidasInventoryDAO().getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(
            stagingInventory, createGermplasmFetchStrategyForFinishedHybrid());
  }


  private void processSubRecords(StagingInventory stagingInventory, InventoryContext inventoryContext) throws
      InventoryImportProcessorException {
    StagingInventory[] parentInventories = getParentInventoriesFromParentageHelper(stagingInventory);

    if (parentInventories != null) {
      for (int i = 0; i < parentInventories.length; i++) {
        StagingInventory parentInventory = parentInventories[i];
        if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(parentInventory.getLineType())) {
          if (processHybridParent(parentInventory, inventoryContext)) {
            processSubRecords(parentInventory, inventoryContext);
          }
        }
        else if (MaterialTypeConstants.SEGPOP_LINES.equalsIgnoreCase(parentInventory.getLineType())) {
          if (processSegpopParent(parentInventory, inventoryContext)) {
            processSubRecords(parentInventory, inventoryContext);
          }
        } else { // Finished
          processFinishedParent(parentInventory, inventoryContext);
        }
      }
      processParentage(stagingInventory, parentInventories);
    } else if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(stagingInventory.getLineType())) {
      if (!stagingInventory.equals(inventoryContext.getStagingInventory())) {
        inventoryContext.addMessage(stagingInventory, TWO_PARENTS_MUST_EXIST_MSG);
      }
      throw new InventoryImportProcessorException(TWO_PARENTS_MUST_EXIST_MSG);
    }
  }

  private void processFinishedParent(StagingInventory parentInventory, InventoryContext inventoryContext)
      throws InventoryImportProcessorException {
    try {
      GeneticMaterial geneticMaterial = getDuplicateFinishedParentGenMat(parentInventory);
      if (geneticMaterial == null) {
        Germplasm germplasm = getExistingFinishedParentGermplasm(parentInventory);
        geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
        addGeneticMaterial(geneticMaterial);
        if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
          addInventory(createMidasInventory(parentInventory, geneticMaterial));
        }
      }
      stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);
      setImportStatus(parentInventory, getImportedStatus());
    } catch (Exception e) {
      inventoryContext.addMessage(parentInventory, e);
      throw new InventoryImportProcessorException(
          "Finished Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
    }
  }

  private boolean processSegpopParent(StagingInventory parentInventory, InventoryContext inventoryContext)
      throws InventoryImportProcessorException {
    boolean success;
    try {
      success = processF1Segpop(parentInventory, inventoryContext);
    } catch (Exception e) {
      inventoryContext.addMessage(parentInventory, e);
      throw new InventoryImportProcessorException(
          "Segpop Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
    }

    return success;
  }

  private boolean processF1Segpop(StagingInventory stagingInventory, InventoryContext inventoryContext) {
    boolean parentageNotExists = true;

    GeneticMaterial geneticMaterial = fetchExistingMatchingGeneticMaterialForSegpopParent(stagingInventory);
    if (geneticMaterial == null) {
      Germplasm germplasm = createMidasGermplasm(stagingInventory);
      stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
      addGermplasm(germplasm);
      geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
      addGeneticMaterial(geneticMaterial);
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        Inventory inventory = createMidasInventory(stagingInventory, geneticMaterial);
        addInventory(inventory);
      }
    } else if (parentageExists(geneticMaterial)) {
      parentageNotExists = false;
      inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
          geneticMaterial.getGeneticMaterialId());
    }

    stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

    if (parentageNotExists) {
      setImportStatus(stagingInventory, getImportedStatus());
    } else {
      setImportStatus(stagingInventory, getUnprocessedStatus());
    }

    return parentageNotExists;
  }

  private GeneticMaterial fetchExistingMatchingGeneticMaterialForSegpopParent(StagingInventory stagingInventory) {
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String lineFunctionRefId = stagingInventory.getLineFunction();
    String pedigreeName = stagingInventory.getPedigreeName();
    String source = stagingInventory.getSource();
    String lineType = stagingInventory.getLineType();

    return createGeneticMaterialDAO(cropName, getLineFunctionCriteria(stagingInventory))
        .getGeneticMaterial(pedigreeName, source, lineType);
  }

  private GeneticMaterialDAO createGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
    return new GeneticMaterialDAO(cropName, lineFunctionCriteria);
  }

  private Germplasm getExistingFinishedParentGermplasm(StagingInventory parentInventory) {
    Germplasm germplasm;
    germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
    if (germplasm == null) {
      germplasm = createFinishedGermplasmDAO(parentInventory.getInventoryHeader().getCropName(),
          getLineFunctionCriteria(parentInventory)).getPrimaryGermplasm(parentInventory.getLineCode());
      if (germplasm != null) {
        stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
      }
    }
    return germplasm;
  }

  protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName,
                                                            LineFunctionCriteria lineFunctionCriteria) {
    return new FinishedGermplasmDAO(cropName, lineFunctionCriteria);
  }

  private GeneticMaterial getDuplicateFinishedParentGenMat(StagingInventory stagingInventory) {
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String lineCode = stagingInventory.getLineCode();
    String source = stagingInventory.getSource();
    LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(stagingInventory);

    return createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria).getPrimaryGeneticMaterial(lineCode, source);
  }

  protected FinishedGeneticMaterialDAO createFinishedGeneticMaterialDAO(String cropName,
                                                                        LineFunctionCriteria lineFunctionCriteria) {
    return new FinishedGeneticMaterialDAO(cropName, lineFunctionCriteria);
  }

  private boolean processHybridParent(StagingInventory parentInventory, InventoryContext inventoryContext)
      throws InventoryImportProcessorException {
    boolean success;
    try {
      success = processMainRecord(parentInventory, inventoryContext);
      setImportStatus(parentInventory, getImportedStatus());
    } catch (Exception e) {
      inventoryContext.addMessage(parentInventory, e);
      throw new InventoryImportProcessorException(
          "Hybrid Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
    }

    return success;
  }

  private StagingInventory[] getParentInventoriesFromParentageHelper(StagingInventory stagingInventory) {
    StagingInventory[] stagingInventories = new StagingInventory[0];
    if (null != stagingParentageHelper) {
      stagingInventories = stagingParentageHelper.getParentInventories(stagingInventory);
    }
    return stagingInventories;
  }

  private void processParentage(StagingInventory stagingInventory, StagingInventory[] parentInventories) {
    GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

    GeneticMaterial parentGenMat;
    String parentalRole;
    for (int i = 0; i < parentInventories.length; i++) {
      StagingInventory parentInventory = parentInventories[i];
      parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
      parentalRole = stagingParentageHelper.getInventoryParentalRole(parentInventory);
      Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
      addParentage(parentage);
    }
  }

  private void setImportStatus(StagingInventory stagingInventory, ImportStatus status) {
    stagingInventory.setImportStatus(status);
  }

  private boolean parentageExists(GeneticMaterial geneticMaterial) {
    List parentageList = new ParentageList().getParentage(geneticMaterial);
    return (parentageList != null) && parentageList.size() > 0;
  }

  /**
   * @noinspection RefusedBequest
   */
  protected String getIsFinishedOrFinishedChild(String lineType, String origin) {
    if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType)) {
      return TRUE_STRING;
    } else {
      return super.getIsFinishedOrFinishedChild(lineType, origin);
    }
  }
}