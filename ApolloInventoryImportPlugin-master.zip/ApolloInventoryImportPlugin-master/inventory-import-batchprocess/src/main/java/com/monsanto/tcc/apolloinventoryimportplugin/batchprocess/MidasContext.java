/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.CompICBMale;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.SharedInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.SharedGenMatlBrProg;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.SharedGenMatlBrProgPk;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.SharedInventoryPk;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: MidasContext.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $    	 On:	$Date:
 * 2007/07/16 04:35:20 $
 *
 * @author apatro
 * @version $Revision: 1.6 $
 */
public class MidasContext {
  private List inventoryList = new ArrayList();
  private List germplasmList = new ArrayList();
  private List geneticMaterialList = new ArrayList();
  private List parentageList = new ArrayList();
  private List compICBMaleList = new ArrayList();

  public void save(Session session) {
    saveGermplasm(session);
    saveGeneticMaterial(session);
    saveInventory(session);
    saveParentage(session);
    saveCompICBMale(session);
  }

  public void addInventory(Inventory inventory) {
    inventoryList.add(inventory);
  }

  public void addGeneticMaterial(GeneticMaterial subRecordGeneticMaterial) {
    geneticMaterialList.add(subRecordGeneticMaterial);
  }

  public void addGermplasm(Germplasm subRecordGermplasm) {
    germplasmList.add(subRecordGermplasm);
  }

  public void addParentage(Parentage parentage) {
    parentageList.add(parentage);
  }

  public void addCompICBMale(CompICBMale compICBMale) {
    compICBMaleList.add(compICBMale);
  }

  public Germplasm[] getGermplasm() {
    return (Germplasm[]) germplasmList.toArray(new Germplasm[0]);
  }

  public GeneticMaterial[] getGeneticMatterial() {
    return (GeneticMaterial[]) geneticMaterialList.toArray(new GeneticMaterial[0]);
  }

  public Inventory[] getInventory() {
    return (Inventory[]) inventoryList.toArray(new Inventory[0]);
  }

  public Parentage[] getParentage() {
    return (Parentage[]) parentageList.toArray(new Parentage[0]);
  }

  public CompICBMale[] getCompICBMale() {
    return (CompICBMale[]) compICBMaleList.toArray(new CompICBMale[0]);
  }

  private void save(List list, Session session) {
    for (int i = 0; i < list.size(); i++) {
      session.saveOrUpdate(list.get(i));
    }
  }

  private void saveGermplasm(Session session) {
    save(germplasmList, session);
  }

  private void saveGeneticMaterial(Session session) {
    save(geneticMaterialList, session);
  }

  private void saveInventory(Session session) {
    save(inventoryList, session);
    saveAnyMissingSharedInventoryAndGeneticMaterial(session);
  }

  private void saveParentage(Session session) {
    save(parentageList, session);
  }

  private void saveCompICBMale(Session session) {
    save(compICBMaleList, session);
  }

  private void saveAnyMissingSharedInventoryAndGeneticMaterial(Session session) {
    for (int i = 0; i < inventoryList.size(); i++) {
      Inventory inventory = (Inventory) inventoryList.get(i);
      checkAndSaveSharedInventory(inventory, session);
      checkAndSaveSharedGeneticMaterial(inventory, session);
    }
  }

  private void checkAndSaveSharedGeneticMaterial(Inventory inventory, Session session) {
    Set sharedGenMatlSet = inventory.getGeneticMaterial().getSharedGenMatlBrProg();
    if (null == sharedGenMatlSet || sharedGenMatlSet.isEmpty()) {
      SharedGenMatlBrProgPk pk = new SharedGenMatlBrProgPk(inventory.getGeneticMaterial(), inventory.getProgram());
      SharedGenMatlBrProg sharedGenMatlBrProg = (SharedGenMatlBrProg) session.get(SharedGenMatlBrProg.class, pk);
      if (sharedGenMatlBrProg == null) {
        sharedGenMatlBrProg = new SharedGenMatlBrProg();
        sharedGenMatlBrProg.setId(pk);
        session.save(sharedGenMatlBrProg);
      }
    }
  }

  private void checkAndSaveSharedInventory(Inventory inventory, Session session) {
    Set sharedInventorySet = inventory.getSharedInventory();
    if (null == sharedInventorySet || sharedInventorySet.isEmpty()) {
      SharedInventoryPk sharedInventoryPk = new SharedInventoryPk(inventory, inventory.getProgram());
      SharedInventory sharedInventory = (SharedInventory) session.get(SharedInventory.class, sharedInventoryPk);
      if (sharedInventory == null) {
        sharedInventory = new SharedInventory();
        sharedInventory.setId(sharedInventoryPk);
        session.save(sharedInventory);
      }
    }
  }
}