/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: ICBMaleIIProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:07:47 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class ICBMaleIIProcessor extends AbstractStagingInventoryProcessor {
    public MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException {
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();

        String cropName = stagingInventory.getInventoryHeader().getCropName();
        String source = stagingInventory.getSource();
        String pedigreeName = stagingInventory.getPedigreeName();
        String lineFunctionRefId = stagingInventory.getLineFunction();

        boolean deactivate = false;
        String isIcbMale = stagingInventory.getIcbMale();
        if (StringUtils.isNullOrEmpty(isIcbMale) || "N".equalsIgnoreCase(isIcbMale)) {
            deactivate = true;
        }
        CompICBMale[] compICBMales = createCompICBMaleDAO(cropName, lineFunctionCriteria)
                .getCompICBMale(source, pedigreeName, deactivate);

        if (compICBMales != null) {
            for (int i = 0; i < compICBMales.length; i++) {
                CompICBMale compICBMale = compICBMales[i];
                if (deactivate) {
                    deActivateCompICBMale(compICBMale);
                } else {
                    activateCompICBMale(compICBMale);
                }
                addCompICBMale(compICBMale);
            }
        } else {
            GeneticMaterial primaryGeneticMaterial = createICBMaleGermplasmGeneticMaterialDAO(cropName, lineFunctionRefId)
                    .getPrimaryGeneticMaterial(source, pedigreeName);
            CompICBMale compICBMale = createCompICBMale(primaryGeneticMaterial, "T");
            addCompICBMale(compICBMale);
        }

        stagingInventory.setImportStatus(getImportedStatus());

        return midasContext;
    }

    protected ICBMaleGermplasmGeneticMaterialDAO createICBMaleGermplasmGeneticMaterialDAO(String cropName,
                                                                                          String lineFunctionRefId) {
        return new ICBMaleGermplasmGeneticMaterialDAO(cropName, lineFunctionRefId);
    }

    protected CompICBMaleDAO createCompICBMaleDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        return new CompICBMaleDAO(cropName, lineFunctionCriteria);
    }
}