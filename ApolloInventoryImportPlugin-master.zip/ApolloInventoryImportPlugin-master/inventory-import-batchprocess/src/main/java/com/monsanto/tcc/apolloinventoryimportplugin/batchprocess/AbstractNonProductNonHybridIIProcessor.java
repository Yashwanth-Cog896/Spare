/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

/**
 * Filename:    $RCSfile: AbstractNonProductNonHybridIIProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: ssnall $    	 On:	$Date: 2009-06-05 14:07:48 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public abstract class AbstractNonProductNonHybridIIProcessor extends AbstractStagingInventoryProcessor {
    protected StagingParentageHelper stagingParentageHelper;

    protected void processF1orMsc0Segpop(StagingInventory f1Segpop, InventoryContext inventoryContext) throws
            InventoryImportProcessorException {
        IIProcessor IIProcessor;
        try {
            IIProcessor = IIProcessorFactory.createF1SegpopInventoryImportProcessor(
                    f1Segpop.getImportType().getAbbreviation(), midasContext, stagingParentageHelper);
        } catch (InstantiationException e) {
            throw new InventoryImportProcessorException("Cannot instantiate F1 Segpop Inventory Processor - ", e);
        }
        InventoryContext f1SegpopInventoryContext = inventoryContext.getInventoryContext(f1Segpop);
        IIProcessor.processInventory(f1SegpopInventoryContext);
    }

    protected boolean isF1OrMsc0Segpop(StagingInventory stagingInventory) {
        String importTypeAbbrev = stagingInventory.getImportType().getAbbreviation();
        return MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES.equalsIgnoreCase(importTypeAbbrev)
                || MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES.equalsIgnoreCase(importTypeAbbrev)
                || MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_FINISHED_LINES.equalsIgnoreCase(importTypeAbbrev)
                || MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_UNFINISHED_LINES.equalsIgnoreCase(importTypeAbbrev);
    }
}