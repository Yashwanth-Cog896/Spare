/*
 PrimaryGeneticMaterialNotFoundException was created on Mar 3, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial;

/**
 * Filename:    $RCSfile: PrimaryGeneticMaterialNotFoundException.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-03 20:35:42 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class PrimaryGeneticMaterialNotFoundException extends Exception {

  public PrimaryGeneticMaterialNotFoundException(String string) {
    super(string);
  }
}