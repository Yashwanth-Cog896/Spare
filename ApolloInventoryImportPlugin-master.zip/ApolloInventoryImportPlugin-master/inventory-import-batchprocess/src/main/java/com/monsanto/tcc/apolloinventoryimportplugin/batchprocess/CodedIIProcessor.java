/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.List;

/**
 * Filename:    $RCSfile: CodedIIProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:07:48 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class CodedIIProcessor extends AbstractNonProductNonHybridIIProcessor {
    public MidasContext processInventory(InventoryContext inventoryContext) throws
            InventoryImportProcessorException {
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();

        stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());

        if (processMainRecord(inventoryContext)) {
            processSubRecords(stagingInventory, inventoryContext);
        }

        return midasContext;
    }

    private boolean processMainRecord(InventoryContext inventoryContext) {
        boolean parentageNotExists = true;
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
        GeneticMaterial geneticMaterial = fetchMatchingGeneticMaterial(stagingInventory.getSource(),
                stagingInventory.getLineage(), stagingInventory.getGeneration(),
                stagingInventory.getInventoryHeader().getCropName(), stagingInventory.getOrigin(),
                stagingInventory.getLineCode(), lineFunctionCriteria);

        if (geneticMaterial == null) { // LineCode Does NOT exist
            Germplasm germplasm = createMidasGermplasm(stagingInventory);
            addGermplasm(germplasm);
            geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
            addGeneticMaterial(geneticMaterial);
            if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
                Inventory inventory = createMidasInventory(stagingInventory, geneticMaterial);
                addInventory(inventory);
            }
        } else if (parentageExists(geneticMaterial)) {
            inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
                    geneticMaterial.getGeneticMaterialId());
            parentageNotExists = false;
        }

        stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

        if (parentageNotExists) {
            stagingInventory.setImportStatus(getImportedStatus());
        } else {
            stagingInventory.setImportStatus(getUnprocessedStatus());
        }

        return parentageNotExists;
    }

    private GeneticMaterial fetchMatchingGeneticMaterial(String source, String lineage, String generation,
                                                         String cropName, String origin, String lineCode,
                                                         LineFunctionCriteria lineFunctionCriteria) {
        return createCodedGermplasmGeneticMaterialDAO(cropName, origin, lineCode, lineFunctionCriteria)
                .getGeneticMaterial(source, lineage, generation);
    }

    protected CodedGermplasmGeneticMaterialDAO createCodedGermplasmGeneticMaterialDAO(String cropName, String origin,
                                                                                      String lineCode,
                                                                                      LineFunctionCriteria lineFunctionCriteria) {
        return new CodedGermplasmGeneticMaterialDAO(cropName, origin, lineCode, lineFunctionCriteria);
    }

    private boolean processSubRecords(StagingInventory stagingInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        boolean success = true;

        StagingInventory[] parentInventories = stagingParentageHelper.getParentInventories(stagingInventory);

        if (parentInventories != null) {
            GeneticMaterial subRecordGeneticMaterial;
            for (int i = 0; i < parentInventories.length; i++) {
                StagingInventory parentInventory = parentInventories[i];
                if (stagingParentageHelper.isInventoryRecurringParent(parentInventory)) {
                    subRecordGeneticMaterial = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
                    if (subRecordGeneticMaterial == null) {
                        processRecurringInventory(parentInventory, inventoryContext);
                    }
                } else {
                    if (isF1OrMsc0Segpop(parentInventory)) {
                        processF1orMsc0Segpop(parentInventory, inventoryContext);
                    } else if (processNonRecurringInventory(parentInventory, inventoryContext)) {
                        success = processSubRecords(parentInventory, inventoryContext);
                    }
                }
            }
            if (success) {
                processParentage(stagingInventory, parentInventories);
                stagingInventory.setImportStatus(getImportedStatus());
            }
        }

        return success;
    }

    private boolean processNonRecurringInventory(StagingInventory parentInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        boolean success = true;
        try {
            GeneticMaterial subRecordGeneticMaterial;
            Germplasm subRecordGermplasm;
            subRecordGeneticMaterial = getDuplicateGeneticMaterial(parentInventory);

            if (subRecordGeneticMaterial == null) {
                subRecordGermplasm = createOrGetExistingGermplasm(parentInventory);
                subRecordGeneticMaterial = createMidasGeneticMaterial(parentInventory, subRecordGermplasm);
                addGeneticMaterial(subRecordGeneticMaterial);
                if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
                    addInventory(createMidasInventory(parentInventory, subRecordGeneticMaterial));
                }
                stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, subRecordGeneticMaterial);
            } else {
                stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, subRecordGeneticMaterial);
                if (parentageExists(subRecordGeneticMaterial)) {
                    inventoryContext.addMessage(parentInventory, "Parentage already exists for identified genetic_material - " +
                            subRecordGeneticMaterial.getGeneticMaterialId());
                    success = false;
                }
            }
        } catch (Exception e) {
            inventoryContext.addMessage(parentInventory, e);
            throw new InventoryImportProcessorException(
                    "Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
        }
        return success;
    }

    private void processRecurringInventory(StagingInventory parentInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        try {
            boolean userSpecifiedSource = isUserSpecifiedSource(parentInventory.getUserSpecifiedSource());

            GeneticMaterial geneticMaterial = fetchExistingRecurringParentGeneticMaterial(parentInventory);
            if (geneticMaterial == null) {
                Germplasm germplasm;
                germplasm = fetchExistingRecurringParentGermplasm(parentInventory);
                geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
                addGeneticMaterial(geneticMaterial);
                if (userSpecifiedSource) {
                    addInventory(createMidasInventory(parentInventory, geneticMaterial));
                }
            }

            stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);
        } catch (Exception e) {
            inventoryContext.addMessage(parentInventory, e);
            throw new InventoryImportProcessorException(
                    "Recurring Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
        }
    }

    private Germplasm fetchExistingRecurringParentGermplasm(
            StagingInventory parentInventory) {
        Germplasm germplasm;
        germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
        if (germplasm == null) {
            germplasm = fetchPrimaryRecurringParentGermplasm(parentInventory);
            if (germplasm != null) {
                stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
            }
        }
        return germplasm;
    }

    private Germplasm fetchPrimaryRecurringParentGermplasm(StagingInventory parentInventory) {
        String cropName = parentInventory.getInventoryHeader().getCropName();
        String pedigreeName = parentInventory.getPedigreeName();
        String productName = parentInventory.getProductName();
        String lineCode = parentInventory.getLineCode();
        Germplasm germplasm;

        ProductNameProductGermplasm productNameProductGermplasm = getProductNameProductGermplasm(cropName, lineCode,
                pedigreeName, productName);
        if (getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm) != null) {
            germplasm = getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm);
        } else {
            germplasm = createFinishedGermplasmDAO(cropName, getLineFunctionCriteria(parentInventory))
                    .getPrimaryGermplasm(lineCode);
        }
        return germplasm;
    }

    protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName,
                                                              LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGermplasmDAO(cropName, lineFunctionCriteria);
    }

    private GeneticMaterial getDuplicateGeneticMaterial(StagingInventory parentInventory) {
        String cropName = parentInventory.getInventoryHeader().getCropName();
        String pedigreeName = parentInventory.getPedigreeName();
        String source = parentInventory.getSource();
        String lineType = parentInventory.getLineType();

        return createGeneticMaterialDAO(cropName, parentInventory).getGeneticMaterial(pedigreeName, source, lineType);
    }

    protected GeneticMaterialDAO createGeneticMaterialDAO(String cropName, StagingInventory parentInventory) {
        return new GeneticMaterialDAO(cropName, getLineFunctionCriteria(parentInventory));
    }

    private Germplasm createOrGetExistingGermplasm(
            StagingInventory parentInventory) {
        Germplasm germplasm;
        germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
        if (germplasm == null) {
            germplasm = createMidasGermplasm(parentInventory);
            stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
            addGermplasm(germplasm);
        }
        return germplasm;
    }

    private void processParentage(StagingInventory stagingInventory,
                                  StagingInventory[] parentInventories) {
        GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

        GeneticMaterial parentGenMat;
        String parentalRole;
        for (int i = 0; i < parentInventories.length; i++) {
            StagingInventory parentInventory = parentInventories[i];
            parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
            parentalRole = stagingParentageHelper.getInventoryParentalRole(parentInventory);
            Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
            addParentage(parentage);
        }
    }

    private boolean parentageExists(GeneticMaterial geneticMaterial) {
        List parentageList = new ParentageList().getParentage(geneticMaterial);
        return (parentageList != null) && parentageList.size() > 0;
    }

    private GeneticMaterial fetchExistingRecurringParentGeneticMaterial(StagingInventory stagingInventory) {
        String cropName = stagingInventory.getInventoryHeader().getCropName();
        String source = stagingInventory.getSource();
        String lineCode = stagingInventory.getLineCode();
        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(stagingInventory);
        GeneticMaterial geneticMaterial = null;

        geneticMaterial = getGeneticMaterialFromProductName(cropName, lineFunctionCriteria, stagingInventory);
        if (geneticMaterial == null) {
            if (MaterialTypeConstants.FINISHED_LINES.equals(stagingInventory.getLineType())) {
                geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
                        .getPrimaryGeneticMaterial(lineCode, source);
            }
            if (MaterialTypeConstants.HYBRID_LINES.equals(stagingInventory.getLineType())) {
                geneticMaterial = createHybridGeneticMaterialDAO(stagingInventory.getSource(), cropName)
                        .getLowestGeneticMaterialMatchingPedigreeName(stagingInventory.getPedigreeName());
            }
        }

        return geneticMaterial;
    }

    protected FinishedGeneticMaterialDAO createFinishedGeneticMaterialDAO(String cropName,
                                                                          LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGeneticMaterialDAO(cropName, lineFunctionCriteria);
    }
}