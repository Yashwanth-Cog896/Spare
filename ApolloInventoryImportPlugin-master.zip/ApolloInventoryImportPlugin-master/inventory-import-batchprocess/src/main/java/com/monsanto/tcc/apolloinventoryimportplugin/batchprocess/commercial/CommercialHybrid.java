/*
 CommercialHybrid was created on Feb 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategyForCommercial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gm.GeneticMaterialOfGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gm.GeneticMaterialOfHybridGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gp.GermplasmPicker;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.ParentalRoleConstants;

/**
 * Filename:    $RCSfile: CommercialHybrid.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-03 22:31:27 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class CommercialHybrid {
  private static final String NO_PRIMARY_GP_EXCEPTION = "No primary germplasm found for the staging inventory.";
  private static final String NO_PRIMARY_GM_EXCEPTION = "No primary genetic material found.";
  private StagingInventory stagingInventory = null;

  public CommercialHybrid(StagingInventory stagingInventory) {
    if (isNull(stagingInventory) || !isHybrid(stagingInventory)) {
      throw new IllegalArgumentException("stagingInventory is not hybrid.");
    }

    this.stagingInventory = stagingInventory;
  }

  public Germplasm getGermplasmOfFemaleParentOfPrimaryGeneticMaterial() throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
    return getGermplasmAssociatedToParentOfPrimaryGeneticMaterial(ParentalRoleConstants.FEMALE_PARENTAL_ROLE);
  }

  public Germplasm getGermplasmOfMaleParentOfPrimaryGeneticMaterial() throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
    return getGermplasmAssociatedToParentOfPrimaryGeneticMaterial(ParentalRoleConstants.MALE_PARENTAL_ROLE);
  }

  public GeneticMaterial getGeneticMaterialForSourceOfFemaleParent() throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
    return getGeneticMaterialForSourceOfParent(ParentalRoleConstants.FEMALE_PARENTAL_ROLE, stagingInventory.getFemaleParentSource());
  }

  public GeneticMaterial getGeneticMaterialForSourceOfMaleParent() throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
    return getGeneticMaterialForSourceOfParent(ParentalRoleConstants.MALE_PARENTAL_ROLE, stagingInventory.getMaleParentSource());
  }

  protected Germplasm getGermplasmAssociatedToParentOfPrimaryGeneticMaterial(String parentalRole) throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
    Germplasm primaryGp = getPrimaryGermplasmForStagingInventory();
    if (null == primaryGp) {
      throw new PrimaryGermplasmNotFoundException(NO_PRIMARY_GP_EXCEPTION);
    }
    GeneticMaterial parentOfPrimaryGm = getParentOfPrimaryGeneticMaterial(primaryGp, parentalRole);
    if (null == parentOfPrimaryGm) {
      throw new PrimaryGeneticMaterialNotFoundException(NO_PRIMARY_GM_EXCEPTION);
    }

    return parentOfPrimaryGm.getGermplasm();
  }

  private GeneticMaterial getGeneticMaterialForSourceOfParent(String parentalRole, String parentSource) throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
    Germplasm parentGermplasm = getGermplasmAssociatedToParentOfPrimaryGeneticMaterial(parentalRole);

    return getGeneticMaterial(parentGermplasm, parentSource);
  }

  private GeneticMaterial getGeneticMaterial(Germplasm germplasm, String parentSource) {
    GeneticMaterialOfGermplasmDAO geneticMaterialDAO = createGeneticMaterialOfGermplasmDAO(germplasm);
    return geneticMaterialDAO.getGeneticMaterial(parentSource);
  }

  private GeneticMaterial getParentOfPrimaryGeneticMaterial(Germplasm primaryGermplasm, String parentalRole) {
    GeneticMaterialOfHybridGermplasmDAO hybridGermplasmDAO = createGeneticMaterialOfHybridGermplasmDAO(primaryGermplasm);
    return hybridGermplasmDAO.getParentOfPrimaryGeneticMaterial(parentalRole);
  }

  private Germplasm getPrimaryGermplasmForStagingInventory() {
    GermplasmListFetchStrategy germplasmListFetchStrategy = new GermplasmListFetchStrategyForCommercial();
    GermplasmPicker germplasmPicker = createGermplasmPicker();
    return germplasmPicker.getPrimaryGermplasm(stagingInventory, germplasmListFetchStrategy);
  }

  protected GeneticMaterialOfGermplasmDAO createGeneticMaterialOfGermplasmDAO(Germplasm germplasm) {
    return new GeneticMaterialOfGermplasmDAO(germplasm);
  }

  protected GeneticMaterialOfHybridGermplasmDAO createGeneticMaterialOfHybridGermplasmDAO(Germplasm primaryGermplasm) {
    return new GeneticMaterialOfHybridGermplasmDAO(primaryGermplasm);
  }

  protected GermplasmPicker createGermplasmPicker() {
    return new GermplasmPicker();
  }

  private boolean isHybrid(StagingInventory stagingInventory) {
    return MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(stagingInventory.getLineType());
  }

  private boolean isNull(StagingInventory stagingInventory) {
    return null == stagingInventory;
  }
}