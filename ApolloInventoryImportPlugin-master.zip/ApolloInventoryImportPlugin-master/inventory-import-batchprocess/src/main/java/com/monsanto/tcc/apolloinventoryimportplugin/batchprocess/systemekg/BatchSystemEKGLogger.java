/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg;

import com.monsanto.appstatsclient.AsyncAppStatsLogger;
import com.monsanto.appstatscommon.ApplicationTask;
import com.monsanto.appstatscommon.DataPoint;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.AppInfoConstants;

/**
 * Filename:    $RCSfile: BatchSystemEKGLogger.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $    	 On:	$Date: 2007-10-04 17:52:46 $
 *
 * @author APATRO
 * @version $Revision: 1.1 $
 */
public class BatchSystemEKGLogger {
  public static final String SUMMARY_TASK_NAME = "Batch Run Summary";
  public static final String BATCH_RUN_ID = "BATCH_RUN_ID";
  public static final String TOTAL_MAIN_RECORDS = "TOTAL_MAIN_RECORDS";
  public static final String MAIN_RECORDS_PROCESSED = "MAIN_RECORDS_PROCESSED";
  public static final String VALIDATION_FAILED_MAIN_RECORDS = "VALIDATION_FAILED_MAIN_RECORDS";
  public static final String PROCESS_EXCEPTION_MAIN_RECORDS = "PROCESS_EXCEPTION_MAIN_RECORDS";
  public static final String UNPROCESSED_MAIN_RECORDS = "UNPROCESSED_MAIN_RECORDS";
  public static final String TOTAL_SUB_RECORDS = "TOTAL_SUB_RECORDS";
  public static final String SUB_RECORDS_PROCESSED = "SUB_RECORDS_PROCESSED";
  public static final String VALIDATION_FAILED_SUB_RECORDS = "VALIDATION_FAILED_SUB_RECORDS";
  public static final String PROCESS_EXCEPTION_SUB_RECORDS = "PROCESS_EXCEPTION_SUB_RECORDS";
  public static final String UNPROCESSED_SUB_RECORDS = "UNPROCESSED_SUB_RECORDS";

  public void log(BatchRunSummaryInfo batchRunSummaryInfo) {
    if (batchRunSummaryInfo == null) return; //Silent

    ApplicationTask task = new ApplicationTask(AppInfoConstants.APPLICATION_NAME, AppInfoConstants.VERSION,
        SUMMARY_TASK_NAME, batchRunSummaryInfo.getStartDate(), batchRunSummaryInfo.getEndDate(),
        AppInfoConstants.APPLICATION_NAME + " " + SUMMARY_TASK_NAME);

    task.addDataPoint(new DataPoint(BATCH_RUN_ID, Long.toString(batchRunSummaryInfo.getBatchRunHistoryId()),
        DataPoint.NUMBER_TYPE));

    task.addDataPoint(new DataPoint(TOTAL_MAIN_RECORDS, Integer.toString(batchRunSummaryInfo.getRecordsToProcess()),
        DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(MAIN_RECORDS_PROCESSED,
        Integer.toString(batchRunSummaryInfo.getRecordsProcessed()), DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(VALIDATION_FAILED_MAIN_RECORDS,
        Integer.toString(batchRunSummaryInfo.getValidationFailureRecords()), DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(PROCESS_EXCEPTION_MAIN_RECORDS,
        Integer.toString(batchRunSummaryInfo.getProcessExceptionRecords()), DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(UNPROCESSED_MAIN_RECORDS,
        Integer.toString(batchRunSummaryInfo.getUnprocessedRecords()), DataPoint.NUMBER_TYPE));

    task.addDataPoint(new DataPoint(TOTAL_SUB_RECORDS, Integer.toString(batchRunSummaryInfo.getSubRecordsToProcess()),
        DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(SUB_RECORDS_PROCESSED,
        Integer.toString(batchRunSummaryInfo.getSubRecordsProcessed()), DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(VALIDATION_FAILED_SUB_RECORDS,
        Integer.toString(batchRunSummaryInfo.getValidationFailureSubRecords()), DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(PROCESS_EXCEPTION_SUB_RECORDS,
        Integer.toString(batchRunSummaryInfo.getProcessExceptionSubRecords()), DataPoint.NUMBER_TYPE));
    task.addDataPoint(new DataPoint(UNPROCESSED_SUB_RECORDS,
        Integer.toString(batchRunSummaryInfo.getUnprocessedSubRecords()), DataPoint.NUMBER_TYPE));

    logToSystemEKG(task);
  }

  private void logToSystemEKG(ApplicationTask task) {
    try {
      createAsyncLogger().post(task);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected AsyncAppStatsLogger createAsyncLogger() {
    return AsyncAppStatsLogger.getInstance();
  }
}