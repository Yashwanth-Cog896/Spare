/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gp.GermplasmPickerDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.MidasSequence;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.vegetativestructure.VegetativeStructure;
import com.monsanto.tcc.apolloinventoryimportplugin.common.GenerationBuilder;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.parentage.PedigreeNameBuilder;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.EventBuilder;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Filename:    $RCSfile: AbstractStagingInventoryProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro
 * $      On:  $Date: 2009-06-05 14:07:48 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public abstract class AbstractStagingInventoryProcessor implements IIProcessor {
    public static final int BARCODE_PADDING = 24;
    public static final String TRUE_STRING = "T";
    public static final String FALSE_STRING = "F";
    private ImportStatus importedStatus;
    private ImportStatus unprocessedStatus;
    protected MidasContext midasContext;

    protected AbstractStagingInventoryProcessor() {
        this.midasContext = new MidasContext();
    }

    protected void addInventory(Inventory inventory) {
        midasContext.addInventory(inventory);
    }

    protected void addGeneticMaterial(GeneticMaterial subRecordGeneticMaterial) {
        midasContext.addGeneticMaterial(subRecordGeneticMaterial);
    }

    protected void addGermplasm(Germplasm subRecordGermplasm) {
        midasContext.addGermplasm(subRecordGermplasm);
    }

    protected void addParentage(Parentage parentage) {
        midasContext.addParentage(parentage);
    }

    protected void addCompICBMale(CompICBMale compICBMale) {
        midasContext.addCompICBMale(compICBMale);
    }

    protected Germplasm createMidasGermplasm(StagingInventory stagingInventory) {
        Germplasm germplasm = new Germplasm();
        germplasm.setId(MidasSequence.getId());
        String cropName = stagingInventory.getInventoryHeader().getCropName();
        germplasm.setCrop(getCrop(cropName));
        germplasm.setIsDeleted(FALSE_STRING);
        germplasm.setIsFinishedOrFinishedChild(
                getIsFinishedOrFinishedChild(stagingInventory.getLineType(), stagingInventory.getOrigin()));
        germplasm.setLineType(getLineType(stagingInventory.getLineType()));
        germplasm.setOrigin(stagingInventory.getOrigin());
        germplasm.setPedigreeName(buildPedigreeName(stagingInventory));
        germplasm.setLineCode(stagingInventory.getLineCode());
        germplasm.setOldPedigree(stagingInventory.getOldPedigree());
        germplasm.setCytoplasmDonor(stagingInventory.getCytoplasmDonorPedigree());

        if (null != stagingInventory.getGermplasmOwner()) {
            germplasm.setOwnerBrProg(
                    getOwnerProg(stagingInventory.getGermplasmOwner(), stagingInventory.getInventoryHeader().getCropName()));
        }

        setEventAndRelatedAttributes(germplasm, stagingInventory.getEvent(), cropName);

        setLineFunction(germplasm, stagingInventory.getLineFunction());

        return germplasm;
    }

    private void setLineFunction(Germplasm germplasm, String lineFuncRefId) {
        if (!StringUtils.isNullOrEmpty(lineFuncRefId)) {
            LineFunction lineFunction = getLineFunction(lineFuncRefId);
            germplasm.setLineFunction(lineFunction);
        }
    }

    private LineFunction getLineFunction(String lineFuncRefId) {
        Session midasSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        return (LineFunction) midasSession.createCriteria(LineFunction.class)
                .add(Restrictions.eq("lineFunctionRefId", lineFuncRefId))
                .add(Restrictions.eq("refActive", TRUE_STRING))
                .uniqueResult();

    }

    private void setEventAndRelatedAttributes(Germplasm germplasm, String eventString, String cropName) {
        if (!StringUtils.isNullOrEmpty(eventString)) {
            germplasm.setIsTransgenic(TRUE_STRING);
            germplasm.setEventDisplay(eventString);

            GermplasmEventConstruct[] germplasmEventConstruct = createGermplasmEventConstruct(cropName,
                    eventString);

            setGermplasmOnGermplasmEventConstruct(germplasmEventConstruct, germplasm);

            germplasm.setGermplasmEventConstruct(createGermplasmEventConstructSet(germplasmEventConstruct));
            germplasm.setConstructDisplay(getConstructDisplay(germplasmEventConstruct));
        } else {
            germplasm.setIsTransgenic(FALSE_STRING);
        }
    }

    private void setGermplasmOnGermplasmEventConstruct(GermplasmEventConstruct[] germplasmEventConstruct,
                                                       Germplasm germplasm) {
        for (int i = 0; i < germplasmEventConstruct.length; i++) {
            GermplasmEventConstruct eventConstruct = germplasmEventConstruct[i];
            eventConstruct.setGermplasm(germplasm);
        }
    }

    private String getConstructDisplay(GermplasmEventConstruct[] germplasmEventConstruct) {
        String constructDisplay = null;
        if (germplasmEventConstruct != null && germplasmEventConstruct.length > 0) {
            EventBuilder eventBuilder = new EventBuilder();
            for (int i = 0; i < germplasmEventConstruct.length; i++) {
                String constructName = germplasmEventConstruct[i].getEventConstruct().getConstructName();
                if (!StringUtils.isNullOrEmpty(constructName)) {
                    eventBuilder.addEvent(constructName);
                }
            }
            constructDisplay = eventBuilder.toString();
        }

        return constructDisplay;
    }

    private Set createGermplasmEventConstructSet(GermplasmEventConstruct[] germplasmEventConstruct) {
        Set germplasmEventConstructSet = null;
        if (germplasmEventConstruct != null && germplasmEventConstruct.length > 0) {
            germplasmEventConstructSet = new HashSet();
            germplasmEventConstructSet.addAll(Arrays.asList(germplasmEventConstruct));
        }

        return germplasmEventConstructSet;
    }

    private GermplasmEventConstruct[] createGermplasmEventConstruct(String cropName, String eventString) {
        String[] events = getEvents(eventString);
        EventConstruct[] eventConstructs = createEventConstructDAO(cropName).getEventConstruct(events);
        return createGermplasmEventConstruct(eventConstructs);
    }

    private GermplasmEventConstruct[] createGermplasmEventConstruct(EventConstruct[] eventConstructs) {
        GermplasmEventConstruct[] germplasmEventConstructs = null;
        if (eventConstructs != null && eventConstructs.length > 0) {
            germplasmEventConstructs = new GermplasmEventConstruct[eventConstructs.length];
            for (int i = 0; i < eventConstructs.length; i++) {
                EventConstruct eventConstruct = eventConstructs[i];
                germplasmEventConstructs[i] = createGermplasmEventConstruct(eventConstruct);
            }
        }
        return germplasmEventConstructs;
    }

    private GermplasmEventConstruct createGermplasmEventConstruct(EventConstruct eventConstruct) {
        GermplasmEventConstruct germplasmEventConstruct = new GermplasmEventConstruct();
        germplasmEventConstruct.setGermplasmEventConstructId(MidasSequence.getId());
        germplasmEventConstruct.setEventConstruct(eventConstruct);
        return germplasmEventConstruct;
    }

    protected EventConstructDAO createEventConstructDAO(String cropName) {
        return new EventConstructDAO(cropName);
    }

    private String[] getEvents(String eventString) {
        return (StringUtils.isNullOrEmpty(eventString)) ? null : eventString.split(",");
    }

    protected String getIsFinishedOrFinishedChild(String lineType, String origin) {
        return ("Finished".equalsIgnoreCase(lineType)) ? TRUE_STRING : FALSE_STRING;
    }

    protected GeneticMaterial createMidasGeneticMaterial(StagingInventory stagingInventory, Germplasm germplasm) {
        GeneticMaterial geneticMaterial = new GeneticMaterial();
        geneticMaterial.setGeneticMaterialId(MidasSequence.getId());
        if (LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(stagingInventory.getLineFunction())) {
            geneticMaterial.setGeneration(stagingInventory.getGeneration());
        } else {
            geneticMaterial
                    .setGeneration(getGenerationFromLineage(stagingInventory.getGeneration(), stagingInventory.getLineFunction(),
                            stagingInventory.getLineage()));
        }
        geneticMaterial.setLineage(stagingInventory.getLineage());
        geneticMaterial.setSourceStr(stagingInventory.getSource());
        geneticMaterial.setSrcLotNumber(stagingInventory.getSrcLotNumber());
        geneticMaterial.setGermplasm(germplasm);

        Set sharedGenMatlBrProg = new HashSet();
        BrProg invOwnerProg = getOwnerProg(stagingInventory.getInventoryOwner(), stagingInventory.getInventoryHeader().getCropName());
        sharedGenMatlBrProg.add(createSharedGenMatlBrProg(geneticMaterial, invOwnerProg));
        geneticMaterial.setSharedGenMatlBrProg(sharedGenMatlBrProg);

        if (!isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
            geneticMaterial.setIsAutogen(TRUE_STRING);
        } else {
            geneticMaterial.setIsAutogen(FALSE_STRING);
        }

        return geneticMaterial;
    }

    private String getGenerationFromLineage(String generation, String lineFunction, String lineage) {
        return new GenerationBuilder(generation, lineFunction).getGenerationStringFromLineage(lineage);
    }

    protected void unarchiveMidasInventory(Inventory inventory, StagingInventory stagingInventory) {
        inventory.setArchivedMaterial(FALSE_STRING);

        inventory.setInventoryImportHistory(createInventoryImportHistorySet(inventory, stagingInventory, true));
    }

    protected Inventory createMidasInventory(StagingInventory stagingInventory, GeneticMaterial geneticMaterial) {
        Inventory inventory = new Inventory();

        inventory.setInventoryId(MidasSequence.getId());
        System.out.println("Midas Inventory_ID - " + inventory.getInventoryId());

        inventory.setGeneticMaterial(geneticMaterial);
        inventory.setProgram(
                getOwnerProg(stagingInventory.getInventoryOwner(), stagingInventory.getInventoryHeader().getCropName()));
        inventory.setCheckIndicator(FALSE_STRING);
        inventory.setArchivedMaterial(FALSE_STRING);
        inventory.setIsActive(TRUE_STRING);

        InventoryTypeDAO inventoryTypeDAO = new InventoryTypeDAO();
        InventoryType inventoryType = inventoryTypeDAO
                .getInventoryType(geneticMaterial.getGermplasm().getLineType().getLineTypeRefId(),
                        stagingInventory.getInventoryHeader().getCropName());
        inventory.setInventoryType(inventoryType);

        inventory.setAsort1(stagingInventory.getAsort1());
        inventory.setAsort2(stagingInventory.getAsort2());
        inventory.setAsort3(stagingInventory.getAsort3());
        inventory.setAsort4(stagingInventory.getAsort4());
        inventory.setAsort5(stagingInventory.getAsort5());

        inventory.setNsort1(stagingInventory.getNsort1());
        inventory.setNsort2(stagingInventory.getNsort2());
        inventory.setNsort3(stagingInventory.getNsort3());
        inventory.setNsort4(stagingInventory.getNsort4());
        inventory.setNsort5(stagingInventory.getNsort5());

        inventory.setCreationDate(new Date());

        inventory.setInventoryImportHistory(createInventoryImportHistorySet(inventory, stagingInventory, false));

        inventory.setSharedInventory(createSharedInventorySet(inventory));
        inventory.setVegetativeStructure(getVegetativeStructure(stagingInventory.getVegetativeStructure()));

        inventory.setBarCode(buildInventoryBarCode(inventory.getProgram().getBrProgRefId(), inventory.getInventoryId()));
        return inventory;
    }

    private Set createInventoryImportHistorySet(Inventory inventory, StagingInventory stagingInventory,
                                                boolean setUnarchiveDate) {
        Set inventoryImportHistorySet = new HashSet();
        inventoryImportHistorySet.add(createInventoryImportHistory(inventory, stagingInventory, setUnarchiveDate));
        return inventoryImportHistorySet;
    }

    protected Parentage createMidasParentage(GeneticMaterial currentGeneticMaterial,
                                             GeneticMaterial immediateParentGeneticMaterial, ParentalRole parentalRole) {
        Parentage parentage = new Parentage();
        parentage.setParentageId(MidasSequence.getId());
        parentage.setGeneticMaterial(currentGeneticMaterial);
        parentage.setParentGeneticMaterial(immediateParentGeneticMaterial);
        parentage.setParentalRole(parentalRole);
        parentage.setTester(TRUE_STRING);

        return parentage;
    }

    protected CompICBMale createCompICBMale(GeneticMaterial geneticMaterial, String refActive) {
        CompICBMale compICBMale = new CompICBMale();
        compICBMale.setCompICBMaleId(MidasSequence.getId());
        compICBMale.setGeneticMaterial(geneticMaterial);
        compICBMale.setCrop(geneticMaterial.getGermplasm().getCrop());
        compICBMale.setRefActive(refActive);

        return compICBMale;
    }

    protected void deActivateCompICBMale(CompICBMale compICBMale) {
        compICBMale.setRefActive(FALSE_STRING);
    }

    protected void activateCompICBMale(CompICBMale compICBMale) {
        compICBMale.setRefActive(TRUE_STRING);
    }

    private InventoryImportHistory createInventoryImportHistory(Inventory inventory, StagingInventory stagingInventory,
                                                                boolean setUnarchiveDate) {

        Session midasSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        InventoryImportHistory inventoryImportHistory = new InventoryImportHistory();
        inventoryImportHistory.setInventoryImportHistoryId(MidasSequence.getId());
        inventoryImportHistory.setInventory(inventory);
        if (setUnarchiveDate) inventoryImportHistory.setUnarchiveDate(new Date());
        try {
            inventoryImportHistory.setApproverUserId(getApproverId(stagingInventory.getAuthorityProcessed(), midasSession));
            inventoryImportHistory.setAuthorityUserId(getAuthorityId(stagingInventory.getAuthorityRequested(), midasSession));
            inventoryImportHistory
                    .setRequestorUserId(getRequestorId(stagingInventory.getInventoryHeader().getUserId(), midasSession));

            inventoryImportHistory.setRequestDate(stagingInventory.getApprovalRequestDate());
            inventoryImportHistory.setValidationDate(stagingInventory.getValidationDate());
            inventoryImportHistory.setApprovalDate(stagingInventory.getApprovalProcessDate());
        } catch (MidasUserNotActiveOrNotExistsException ex) {
            ex.printStackTrace();
        }
        return inventoryImportHistory;
    }

    private SharedGenMatlBrProg createSharedGenMatlBrProg(GeneticMaterial geneticMaterial, BrProg invOwnerProg) {
        SharedGenMatlBrProg sharedGenMatlBrProg = new SharedGenMatlBrProg();
        sharedGenMatlBrProg
                .setId(new SharedGenMatlBrProgPk(geneticMaterial, invOwnerProg));
        return sharedGenMatlBrProg;
    }

    private SharedInventory createSharedInventoryBrProg(Inventory inventory) {
        SharedInventory sharedInventory = new SharedInventory();
        sharedInventory.setId(new SharedInventoryPk(inventory, inventory.getProgram()));
        return sharedInventory;
    }

    private Set createSharedInventorySet(Inventory inventory) {
        Set sharedInventoryBrProgSet = new HashSet();
        sharedInventoryBrProgSet.add(createSharedInventoryBrProg(inventory));
        return sharedInventoryBrProgSet;
    }

    protected ImportStatus getImportedStatus() {
        if (null == importedStatus) {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
            importedStatus = (ImportStatus) session.createCriteria(ImportStatus.class)
                    .add(Restrictions.eq("statusCode", "Imported").ignoreCase())
                    .uniqueResult();
        }
        return importedStatus;
    }

    protected ImportStatus getUnprocessedStatus() {
        if (null == unprocessedStatus) {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
            unprocessedStatus = (ImportStatus) session.createCriteria(ImportStatus.class)
                    .add(Restrictions.eq("statusCode", "Unprocessed").ignoreCase())
                    .uniqueResult();
        }
        return unprocessedStatus;
    }

    protected ParentalRole getParentalRole(String parentalRole) {
        return new ParentageList().getParentalRole(parentalRole);
    }

    private Long getRequestorId(String requestorId, Session midasSession) throws MidasUserNotActiveOrNotExistsException {
        return getMidasUserId(requestorId, midasSession);
    }

    private Long getAuthorityId(String authorityRequested, Session midasSession) throws
            MidasUserNotActiveOrNotExistsException {
        return getMidasUserId(authorityRequested, midasSession);
    }

    private Long getApproverId(String approvalId, Session midasSession) throws MidasUserNotActiveOrNotExistsException {
        return getMidasUserId(approvalId, midasSession);
    }

    private Long getMidasUserId(String loginId, Session midasSession) throws MidasUserNotActiveOrNotExistsException {
        List list = midasSession.createCriteria(MidasUser.class, "mu")
                .add(Restrictions.eq("mu.loginId", loginId).ignoreCase())
                .add(Restrictions.eq("mu.refActive", TRUE_STRING))
                .list();
        if (list != null && list.size() > 0) {
            MidasUser midasUser = (MidasUser) list.get(0);
            if (midasUser != null)
                return midasUser.getMidasUserId();
        }
        throw new MidasUserNotActiveOrNotExistsException(
                "Given Midas Login Id '" + loginId + "' does not exist or Inactive");
    }

    private LineType getLineType(String lineType) {
        Session midasSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        return (LineType) midasSession.createCriteria(LineType.class)
                .add(Restrictions.eq("lineTypeRefId", lineType.toUpperCase()))
                .add(Restrictions.eq("refActive", TRUE_STRING))
                .uniqueResult();
    }

    private BrProg getOwnerProg(String ownerProg, String cropName) {
        Session midasSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        return (BrProg) midasSession.createCriteria(BrProg.class, "bp")
                .add(Restrictions.eq("brProgRefId", ownerProg.toUpperCase()))
                .add(Restrictions.eq("refActive", TRUE_STRING))
                .createAlias("bp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", TRUE_STRING))
                .uniqueResult();
    }

    private VegetativeStructure getVegetativeStructure(String vegetativeStructure) {
        Session midasSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        if (vegetativeStructure == null || vegetativeStructure.trim().length() == 0) {
            vegetativeStructure = "Seed";
        }
        return (VegetativeStructure) midasSession.createCriteria(VegetativeStructure.class)
                .add(Expression.eq("name", vegetativeStructure).ignoreCase())
                .add(Expression.eq("refActive", "T"))
                .uniqueResult();
    }


    private Crop getCrop(String cropName) {
        Session midasSession = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        return (Crop) midasSession.createCriteria(Crop.class)
                .add(Restrictions.eq("cropName", cropName).ignoreCase())
                .add(Restrictions.eq("refActive", TRUE_STRING))
                .uniqueResult();
    }

    protected String buildPedigreeName(StagingInventory stagingInventory) {
        return new PedigreeNameBuilder().createPedigreeNameForInventoryImport(stagingInventory.getLineType().toUpperCase(),
                stagingInventory.getOrigin(),
                stagingInventory.getLineage(), stagingInventory.getLineCode(), stagingInventory.getProductName(),
                stagingInventory.getGermplasmOwner());
    }

    private String buildInventoryBarCode(String brProgRefId, Long inventoryId) {
        String zeroPadding = "";
        int numberOfZerosToBePadded = ((inventoryId.toString().length()) + brProgRefId.length() + 1);
        for (int i = 0; i < BARCODE_PADDING - numberOfZerosToBePadded; i++)
            zeroPadding = zeroPadding + "0";

        return "I" + brProgRefId + zeroPadding + inventoryId;
    }

    protected boolean isUserSpecifiedSource(String userSpecifiedSource) {
        return !FALSE_STRING.equalsIgnoreCase(userSpecifiedSource);
    }

    protected LineFunctionCriteria getLineFunctionCriteria(StagingInventory stagingInventory) {
        return new LineFunctionCriteriaFactory(stagingInventory).getLineFunctionCriteria();
    }

    protected ProductNameProductGermplasm getProductNameProductGermplasmForExistingParentSubrecord(String cropName, String originComponent) {
        ParentageFetchStrategy[] parentageFetchStrategies = createParentageFetchStrategyAssembler(cropName)
                .getStrategiesForFetchingParentProductGermplasm();
        ProductNameProductGermplasm productNameProductGermplasm = null;
        for (ParentageFetchStrategy parentageFetchStrategy : parentageFetchStrategies) {
            productNameProductGermplasm = parentageFetchStrategy.fetchProductNameProductGermplasm(originComponent);
            if (productNameProductGermplasm != null)
                break;
        }
        return productNameProductGermplasm;
    }

    protected ProductGermplasm getProductGermplasmForExistingParentSubrecord(String cropName, String originComponent) {
        ParentageFetchStrategy[] parentageFetchStrategies = createParentageFetchStrategyAssembler(cropName)
                .getStrategiesForCheckingExistingParents();
        List productgermplasms = new ArrayList();
        for (ParentageFetchStrategy parentageFetchStrategy : parentageFetchStrategies) {
            productgermplasms = parentageFetchStrategy.fetchParentProductGermplasms(originComponent);
            if (productgermplasms != null && productgermplasms.size() > 0)
                break;
        }
        if ((productgermplasms == null) || (productgermplasms.size() == 0))
            return null;
        return getPrimaryProductGermplasmFromProductGermplasmList(productgermplasms);
    }

    private ParentageFetchStrategyAssembler createParentageFetchStrategyAssembler(String cropName) {
        return new ParentageFetchStrategyAssembler(cropName);
    }

    private ProductGermplasm getPrimaryProductGermplasmFromProductGermplasmList(List productGermplasmList) {
        if (productGermplasmList.size() == 1) {
            return (ProductGermplasm) productGermplasmList.get(0);
        }
        List<Germplasm> germplasms = getGermplasmListFromProductGermplasmList(productGermplasmList);
        GermplasmPickerDAO germplasmpicker = createGermplasmPickerDAO(germplasms);
        Germplasm germplasm = germplasmpicker.getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();
        return getProductGermplasmFromProductGermplasmList(productGermplasmList, germplasm);
    }

    private List<Germplasm> getGermplasmListFromProductGermplasmList(List productGermplasmList) {
        List<Germplasm> germplasmList = new ArrayList<Germplasm>();
        if (productGermplasmList != null && productGermplasmList.size() > 0) {
            for (Object aProductGermplasmList : productGermplasmList) {
                ProductGermplasm productGermplasm = (ProductGermplasm) aProductGermplasmList;
                germplasmList.add(productGermplasm.getGermplasm());
            }
        }
        return germplasmList;
    }

    private GermplasmPickerDAO createGermplasmPickerDAO(List<Germplasm> germplasms) {
        return new GermplasmPickerDAO((Germplasm[]) germplasms.toArray(new Germplasm[0]));
    }

    private ProductGermplasm getProductGermplasmFromProductGermplasmList(List productGermplasmList, Germplasm germplasm) {
        if (productGermplasmList != null && productGermplasmList.size() > 0) {
            for (Object aProductGermplasmList : productGermplasmList) {
                ProductGermplasm productGermplasm = (ProductGermplasm) aProductGermplasmList;
                if (productGermplasm.getGermplasm().getId().equals(germplasm.getId()))
                    return productGermplasm;
            }
        }
        return null;
    }

    protected Germplasm getGermplasmFromProductNameProductGermplasm(ProductNameProductGermplasm productNameProductGermplasm) {
        Germplasm germplasm = null;
        if (productNameProductGermplasm != null && productNameProductGermplasm.getProductGermplasm() != null && productNameProductGermplasm.getProductGermplasm().getGermplasm() != null) {
            germplasm = productNameProductGermplasm.getProductGermplasm().getGermplasm();
        }
        return germplasm;
    }

    protected GeneticMaterial getGeneticMaterialFromProductName(String cropName, LineFunctionCriteria lineFunctionCriteria, StagingInventory stagingInventory) {
        GeneticMaterial geneticMaterial = null;

        ProductNameProductGermplasm productNameProductGermplasm = getProductNameProductGermplasm(cropName,
                stagingInventory.getLineCode(), stagingInventory.getPedigreeName(), stagingInventory.getProductName());
        if (productNameProductGermplasm != null) {
            if (MaterialTypeConstants.FINISHED_LINES.equals(stagingInventory.getLineType())) {
                geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
                        .getPrimaryGeneticMaterial(productNameProductGermplasm.getProductGermplasm().getGermplasm());
            }
            if (MaterialTypeConstants.HYBRID_LINES.equals(stagingInventory.getLineType())) {
                geneticMaterial = createHybridGeneticMaterialDAO(stagingInventory.getSource(), cropName)
                        .getLowestGeneticMaterialMatchingGermplasm(productNameProductGermplasm.getProductGermplasm().getGermplasm());
            }
        }
        return geneticMaterial;
    }

    protected FinishedGeneticMaterialDAO createFinishedGeneticMaterialDAO(String cropName,
                                                                          LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGeneticMaterialDAO(cropName, lineFunctionCriteria);
    }

    protected HybridGeneticMaterialDAO createHybridGeneticMaterialDAO(String source, String cropName) {
        return new HybridGeneticMaterialDAO(source, cropName);
    }

    protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName,
                                                              LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGermplasmDAO(cropName, lineFunctionCriteria);
    }

    protected HybridGermplasmDAO createHybridGermplasmDAO(StagingInventory stagingInventory) {
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
        return new HybridGermplasmDAO(stagingInventory.getInventoryHeader().getCropName(), lineFunctionCriteria);
    }

    protected ProductNameProductGermplasm getProductNameProductGermplasm(String cropName, String lineCode,
                                                                         String pedigree, String productName) {
        if (StringUtils.isNullOrEmpty(productName)) {
            return null;
        }
        String originOrLineCode = pedigree;
        if (!StringUtils.isNullOrEmpty(pedigree) && pedigree.equalsIgnoreCase(lineCode)) {
            originOrLineCode = productName;
        }
        return getProductNameProductGermplasmForExistingParentSubrecord(cropName, originOrLineCode);
    }

    protected void setGenericNonProductSourceOnStagingInventoryIfNullOrEmpty(StagingInventory parentInventory) {
        if (StringUtils.isNullOrEmpty(parentInventory.getSource())) {
            parentInventory.setSource(SourceStringConstants.II_GENERIC_NON_PRODUCT_SOURCE);
            parentInventory.setUserSpecifiedSource(FALSE_STRING);
        }
    }
}
