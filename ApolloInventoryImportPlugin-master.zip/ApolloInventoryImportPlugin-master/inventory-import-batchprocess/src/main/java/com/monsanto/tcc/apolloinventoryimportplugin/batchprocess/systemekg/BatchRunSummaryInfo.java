/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;

import java.util.Date;
import java.util.Set;

/**
 * Filename:    $RCSfile: BatchRunSummaryInfo.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:	$Date: 2008-02-17 22:58:08 $
 *
 * @author APATRO
 * @version $Revision: 1.3 $
 */
public class BatchRunSummaryInfo {
  public static final String RUN_HISTORY_REQUIRED_MSG = "runHistory required";

  private Date startDate;
  private Date endDate;

  private int recordsToProcess;
  private int recordsProcessed;
  private int validationFailureRecords;
  private int processExceptionRecords;
  private int unprocessedRecords;

  private int subRecordsToProcess;
  private int subRecordsProcessed;
  private int validationFailureSubRecords;
  private int processExceptionSubRecords;
  private int unprocessedSubRecords;

  private long batchRunHistoryId;

  public BatchRunSummaryInfo(StagingInventory[] stagingInventories, RunHistory runHistory) {
    if (runHistory == null) {
      throw new IllegalArgumentException(RUN_HISTORY_REQUIRED_MSG);
    }

    batchRunHistoryId = runHistory.getId().longValue();
    startDate = runHistory.getStartDate();
    endDate = runHistory.getEndDate();

    if (stagingInventories != null && stagingInventories.length > 0) {
      initCounts(stagingInventories);
    }
  }

  private void initCounts(StagingInventory[] stagingInventories) {
    recordsToProcess = stagingInventories.length;
    setMainRecordCounts(stagingInventories);
  }

  private void setMainRecordCounts(StagingInventory[] stagingInventories) {
    for (int i = 0; i < stagingInventories.length; i++) {
      StagingInventory stagingInventory = stagingInventories[i];

      StagingParentage[] stagingParentages = getSubRecords(stagingInventory);
      subRecordsToProcess += stagingParentages.length;

      String statusCode = stagingInventory.getImportStatus().getStatusCode();
      if (StagingInventoryStatusConstants.UNPROCESSED.equalsIgnoreCase(statusCode)) {
        unprocessedRecords++;
        unprocessedSubRecords += stagingParentages.length;
      } else if (StagingInventoryStatusConstants.INVALID.equalsIgnoreCase(statusCode)) {
        validationFailureRecords++;
        validationFailureSubRecords += stagingParentages.length;
      } else if (StagingInventoryStatusConstants.APPROVED.equalsIgnoreCase(statusCode)) {
        processExceptionRecords++;
        processExceptionSubRecords += stagingParentages.length;
      } else if (StagingInventoryStatusConstants.IMPORTED.equalsIgnoreCase(statusCode)) {
        recordsProcessed++;
        setSubRecordCountsOnImportedMainRecord(stagingParentages);
      }
    }
  }

  private void setSubRecordCountsOnImportedMainRecord(StagingParentage[] stagingParentages) {
    if (stagingParentages != null) {
      for (int i = 0; i < stagingParentages.length; i++) {
        StagingParentage stagingParentage = stagingParentages[i];
        StagingInventory parentInventory = stagingParentage.getParentInventory();
        String statusCode = parentInventory.getImportStatus().getStatusCode();
        if (StagingInventoryStatusConstants.UNPROCESSED.equalsIgnoreCase(statusCode)) {
          unprocessedSubRecords++;
        } else if (StagingInventoryStatusConstants.IMPORTED.equalsIgnoreCase(statusCode)) {
          subRecordsProcessed++;
        }
      }
    }
  }

  private StagingParentage[] getSubRecords(StagingInventory stagingInventory) {
    StagingParentage[] stagingParentages = null;
    Set stagingParentageSet = stagingInventory.getStagingParentage();
    if (stagingParentageSet != null) {
      stagingParentages = (StagingParentage[]) stagingParentageSet.toArray(new StagingParentage[0]);
    }
    return stagingParentages;
  }


  public Date getStartDate() {
    return startDate;
  }

  public Date getEndDate() {
    return endDate;
  }

  public int getRecordsToProcess() {
    return recordsToProcess;
  }

  public int getValidationFailureRecords() {
    return validationFailureRecords;
  }

  public int getProcessExceptionRecords() {
    return processExceptionRecords;
  }

  public int getUnprocessedRecords() {
    return unprocessedRecords;
  }

  public int getSubRecordsToProcess() {
    return subRecordsToProcess;
  }

  public int getValidationFailureSubRecords() {
    return validationFailureSubRecords;
  }

  public int getProcessExceptionSubRecords() {
    return processExceptionSubRecords;
  }

  public int getUnprocessedSubRecords() {
    return unprocessedSubRecords;
  }

  public long getBatchRunHistoryId() {
    return batchRunHistoryId;
  }

  public int getRecordsProcessed() {
    return recordsProcessed;
  }

  public int getSubRecordsProcessed() {
    return subRecordsProcessed;
  }
}