/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategySegpop;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ParentageList;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.List;

/**
 * Filename:    $RCSfile: F1SegpopUnfinishedProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:   $Date: 2008-06-12 04:50:23 $
 *
 * @author apatro
 * @version $Revision: 1.27 $
 */
public class F1SegpopUnfinishedProcessor extends AbstractStagingInventoryProcessor {
  public static final String INVENTORY_CANNOT_BE_NULL_MSG = "InventoryContext cannot be null.";
  public static final String SESSION_CANNOT_BE_NULL_MSG = "Session cannot be null.";
  public static final String TWO_PARENTS_MUST_EXIST_MSG = "Two parents must exist.";
  private static final int NUMBER_OF_PARENTS = 2;
  private StagingParentageHelper stagingParentageHelper;
  public static final String PARENT_GENMAT_NOT_FOUND = "Existing Genetic_Material not found!";
  public static final String PARENT_NOT_FOUND_IN_MIDAS = "Parent(s) not found in MIDAS";

  private boolean f1SegpopIsMainRecord = false;

  public F1SegpopUnfinishedProcessor() {
    super();
    f1SegpopIsMainRecord = true;
  }

  public F1SegpopUnfinishedProcessor(MidasContext midasContext, StagingParentageHelper stagingParentageHelper) {
    super();
    this.midasContext = midasContext;
    this.stagingParentageHelper = stagingParentageHelper;
  }

  public MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException {
    if (null == inventoryContext) {
      throw new IllegalStateException(INVENTORY_CANNOT_BE_NULL_MSG);
    }

    StagingInventory stagingInventory = inventoryContext.getStagingInventory();
    if (stagingParentageHelper == null) {
      stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());
    }

    if (processMainRecord(inventoryContext)) {
      processSubRecords(stagingInventory, inventoryContext);
    }

    return midasContext;
  }

  private boolean processMainRecord(InventoryContext inventoryContext) {
    StagingInventory stagingInventory = inventoryContext.getStagingInventory();

    boolean processSubRecords = false;
    boolean archivedInventoryProcessed = false;

    if (f1SegpopIsMainRecord) {
      archivedInventoryProcessed = processArchivedInventory(stagingInventory);
    }

    if (!archivedInventoryProcessed) {
      processSubRecords = processF1Segpop(stagingInventory, inventoryContext);
    }

    return processSubRecords;
  }

  private boolean processArchivedInventory(StagingInventory stagingInventory) {
    boolean archivedInventoryFound = false;
    Inventory inventory = fetchExistingArchivedMidasInventory(stagingInventory);
    if (inventory != null) {
      archivedInventoryFound = true;
      unarchiveMidasInventory(inventory, stagingInventory);
      stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, inventory.getGeneticMaterial());
      addInventory(inventory);
    }
    return archivedInventoryFound;
  }

  private Inventory fetchExistingArchivedMidasInventory(StagingInventory stagingInventory) {
    return new MidasInventoryDAO().getArchivedInventory(stagingInventory,
        createGermplasmFetchStrategyForSegpop());
  }

  protected GermplasmListFetchStrategy createGermplasmFetchStrategyForSegpop() {
    return new GermplasmListFetchStrategySegpop();
  }

  private boolean processF1Segpop(StagingInventory stagingInventory, InventoryContext inventoryContext) {
    boolean parentageNotExists = true;

    GeneticMaterial geneticMaterial = fetchExistingMatchingGeneticMaterial(stagingInventory);
    if (geneticMaterial == null) {
      Germplasm germplasm = createMidasGermplasm(stagingInventory);
      addGermplasm(germplasm);
      stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
      geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
      addGeneticMaterial(geneticMaterial);
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        Inventory inventory = createMidasInventory(stagingInventory, geneticMaterial);
        addInventory(inventory);
      }
    } else if (parentageExists(geneticMaterial)) {
      parentageNotExists = false;
      inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
          geneticMaterial.getGeneticMaterialId());
    }

    stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

    if (parentageNotExists) {
      setImportStatus(stagingInventory, getImportedStatus());
    } else {
      setImportStatus(stagingInventory, getUnprocessedStatus());
    }

    return parentageNotExists;
  }

  private boolean parentageExists(GeneticMaterial geneticMaterial) {
    List parentageList = new ParentageList().getParentage(geneticMaterial);
    return (parentageList != null) && parentageList.size() > 0;
  }

  private GeneticMaterial fetchExistingMatchingGeneticMaterial(StagingInventory stagingInventory) {
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String pedigreeName = stagingInventory.getPedigreeName();
    String source = stagingInventory.getSource();
    String lineType = stagingInventory.getLineType();

    return createGeneticMaterialDAO(cropName, getLineFunctionCriteria(stagingInventory))
        .getGeneticMaterial(pedigreeName, source, lineType);
  }

  protected GeneticMaterialDAO createGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
    return new GeneticMaterialDAO(cropName, lineFunctionCriteria);
  }

  private void processSubRecords(StagingInventory stagingInventory, InventoryContext inventoryContext) throws
      InventoryImportProcessorException {
    StagingInventory[] parentInventories = stagingParentageHelper.getParentInventories(stagingInventory);

    if (null == parentInventories || parentInventories.length != NUMBER_OF_PARENTS) {
      throw new InventoryImportProcessorException(TWO_PARENTS_MUST_EXIST_MSG);
    }

    GeneticMaterial subRecordGeneticMaterial;
    boolean parentsFound = true;
    for (int i = 0; i < parentInventories.length; i++) {
      subRecordGeneticMaterial = getMatchingGeneticMaterial(parentInventories[i]);

      if (subRecordGeneticMaterial != null) {
        stagingParentageHelper.addInventoryGeneticMaterial(parentInventories[i], subRecordGeneticMaterial);
        setImportStatus(parentInventories[i], getImportedStatus());
      } else {
        if(MaterialTypeConstants.FINISHED_LINES.equalsIgnoreCase(parentInventories[i].getLineType())) {
          addGeneticMaterial(parentInventories[i]);
          setImportStatus(parentInventories[i], getImportedStatus());
        } else {
          inventoryContext.addMessage(parentInventories[i], PARENT_GENMAT_NOT_FOUND);
          parentsFound = false;
        }
      }
    }
    if (!parentsFound) {
      throw new InventoryImportProcessorException(PARENT_NOT_FOUND_IN_MIDAS);
    }
    processParentage(stagingInventory, parentInventories);
  }

  private void addGeneticMaterial(StagingInventory parentInventory) {
    setGenericNonProductSourceOnStagingInventoryIfNullOrEmpty(parentInventory);
    Germplasm germplasm = getExistingFinishedParentGermplasm(parentInventory);
    GeneticMaterial geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
    addGeneticMaterial(geneticMaterial);
    if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
      addInventory(createMidasInventory(parentInventory, geneticMaterial));
    }
    stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);
  }

  private Germplasm getExistingFinishedParentGermplasm(StagingInventory parentInventory) {
    Germplasm germplasm;
    germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
    if (germplasm == null) {
      germplasm = createFinishedGermplasmDAO(parentInventory.getInventoryHeader().getCropName(),
          getLineFunctionCriteria(parentInventory)).getPrimaryGermplasm(parentInventory.getLineCode());
      if (germplasm != null) {
        stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
      }
    }
    return germplasm;
  }

  private GeneticMaterial getMatchingGeneticMaterial(StagingInventory parentInventory) {
    GeneticMaterial geneticMaterial = null;
    String lineType = parentInventory.getLineType();
    String cropName = parentInventory.getInventoryHeader().getCropName();
    String source = parentInventory.getSource();
    String pedigreeName = parentInventory.getPedigreeName();
    LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(parentInventory);

    if (MaterialTypeConstants.SEGPOP_LINES.equalsIgnoreCase(lineType)) {
      if (StringUtils.isNullOrEmpty(pedigreeName)) pedigreeName = buildPedigreeName(parentInventory);
      geneticMaterial = createGeneticMaterialDAO(cropName, getLineFunctionCriteria(parentInventory))
          .getGeneticMaterial(pedigreeName, source, lineType);
    } else if (MaterialTypeConstants.CODED_LINES.equalsIgnoreCase(lineType)) {
      geneticMaterial = createGeneticMaterialDAO(cropName, getLineFunctionCriteria(parentInventory))
          .getGeneticMaterial(pedigreeName, source, lineType);
    } else {
      geneticMaterial = getGeneticMaterialFromProductName(cropName, lineFunctionCriteria, parentInventory);
      if(geneticMaterial == null) {
        if(MaterialTypeConstants.FINISHED_LINES.equals(lineType)) {
          geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
              .getPrimaryGeneticMaterial(pedigreeName, source);
        }
        if(MaterialTypeConstants.HYBRID_LINES.equals(lineType)) {
          geneticMaterial = createHybridGeneticMaterialDAO(source, cropName)
              .getLowestGeneticMaterialMatchingPedigreeName(pedigreeName);
        }
      }
    }
    return geneticMaterial;
  }

  private void processParentage(StagingInventory stagingInventory,
                                StagingInventory[] parentInventories) {
    GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

    GeneticMaterial parentGenMat;
    String parentalRole;
    for (int i = 0; i < parentInventories.length; i++) {
      StagingInventory parentInventory = parentInventories[i];
      parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
      parentalRole = stagingParentageHelper.getInventoryParentalRole(parentInventory);
      Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
      addParentage(parentage);
    }
  }

  private void setImportStatus(StagingInventory stagingInventory, ImportStatus status) {
    stagingInventory.setImportStatus(status);
  }
}