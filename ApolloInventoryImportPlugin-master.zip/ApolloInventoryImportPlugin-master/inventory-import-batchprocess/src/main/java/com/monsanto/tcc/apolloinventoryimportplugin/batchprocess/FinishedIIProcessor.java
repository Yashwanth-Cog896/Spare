/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.List;

/**
 * Filename: $Id: FinishedIIProcessor.java,v 1.2 2009-06-05 14:07:48 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class FinishedIIProcessor extends AbstractNonProductNonHybridIIProcessor {
    public MidasContext processInventory(InventoryContext inventoryContext) throws
            InventoryImportProcessorException {
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();

        if (stagingParentageHelper == null) {
            stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());
        }

        processMainRecord(inventoryContext);

        processSubRecords(inventoryContext.getStagingInventory(), inventoryContext);

        return midasContext;
    }

    private void processMainRecord(InventoryContext inventoryContext) {
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();

        Inventory inventory = fetchExistingArchivedMidasInventory(stagingInventory);

        GeneticMaterial geneticMaterial;
        if (inventory != null) { // Line_Code exists scenario
            geneticMaterial = inventory.getGeneticMaterial();
            if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
                unarchiveMidasInventory(inventory, stagingInventory);
                addInventory(inventory);
            }
        } else {
            geneticMaterial = fetchExistingMatchingGeneticMaterial(stagingInventory);

            if (geneticMaterial == null) {
                Germplasm germplasm = getExistingGermplasmForFinished(stagingInventory);
                if (germplasm == null) { // Line_Code does NOT exist scenario
                    germplasm = createMidasGermplasm(stagingInventory);
                    addGermplasm(germplasm);
                } // else Line_Code exists scenario
                stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
                geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
                addGeneticMaterial(geneticMaterial);
            } // else Line_Code exists scenario
            if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
                inventory = createMidasInventory(stagingInventory, geneticMaterial);
                addInventory(inventory);
            }
        }

        stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

        stagingInventory.setImportStatus(getImportedStatus());
    }

    private boolean processSubRecords(StagingInventory stagingInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        boolean success = true;

        StagingInventory[] parentInventories = stagingParentageHelper.getParentInventories(stagingInventory);

        if (parentInventories != null) {
            GeneticMaterial subRecordGeneticMaterial;
            for (int i = 0; i < parentInventories.length; i++) {
                StagingInventory parentInventory = parentInventories[i];
                if (stagingParentageHelper.isInventoryRecurringParent(parentInventory)) {
                    subRecordGeneticMaterial = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
                    if (subRecordGeneticMaterial == null) {
                        processRecurringInventory(parentInventory, inventoryContext);
                    }
                } else {
                    if (isF1OrMsc0Segpop(parentInventory)) {
                        processF1orMsc0Segpop(parentInventory, inventoryContext);
                    } else if (processNonRecurringInventory(parentInventory, inventoryContext)) {
                        success = processSubRecords(parentInventory, inventoryContext);
                    }
                }
            }
            if (success) {
                processParentage(stagingInventory, parentInventories);
                stagingInventory.setImportStatus(getImportedStatus());
            }
        }

        return success;
    }

    private boolean processNonRecurringInventory(StagingInventory parentInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        boolean success = true;
        try {
            GeneticMaterial subRecordGeneticMaterial;
            Germplasm subRecordGermplasm;
            subRecordGeneticMaterial = getDuplicateGeneticMaterial(parentInventory);

            if (subRecordGeneticMaterial == null) {
                subRecordGermplasm = createOrGetExistingGermplasm(parentInventory);
                subRecordGeneticMaterial = createMidasGeneticMaterial(parentInventory, subRecordGermplasm);
                addGeneticMaterial(subRecordGeneticMaterial);
                if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
                    addInventory(createMidasInventory(parentInventory, subRecordGeneticMaterial));
                }
                stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, subRecordGeneticMaterial);
                parentInventory.setImportStatus(getImportedStatus());
            } else {
                stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, subRecordGeneticMaterial);
                if (parentageExists(subRecordGeneticMaterial)) {
                    inventoryContext.addMessage(parentInventory, "Parentage already exists for identified genetic_material - " +
                            subRecordGeneticMaterial.getGeneticMaterialId());
                    success = false;
                    parentInventory.setImportStatus(getUnprocessedStatus());
                }
            }
        } catch (Exception e) {
            inventoryContext.addMessage(parentInventory, e);
            throw new InventoryImportProcessorException(
                    "Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
        }
        return success;
    }

    private void processRecurringInventory(StagingInventory parentInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        try {
            boolean userSpecifiedSource = isUserSpecifiedSource(parentInventory.getUserSpecifiedSource());

            GeneticMaterial geneticMaterial = fetchExistingMatchingGeneticMaterial(parentInventory);
            if (geneticMaterial == null) {
                Germplasm germplasm;
                germplasm = getExistingGermplasmForFinished(parentInventory);
                geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
                addGeneticMaterial(geneticMaterial);
                if (userSpecifiedSource) {
                    addInventory(createMidasInventory(parentInventory, geneticMaterial));
                }
            }

            stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);

            parentInventory.setImportStatus(getImportedStatus());
        } catch (Exception e) {
            inventoryContext.addMessage(parentInventory, e);
            throw new InventoryImportProcessorException(
                    "Recurring Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
        }
    }

    private Germplasm getExistingGermplasmForFinished(
            StagingInventory parentInventory) {
        Germplasm germplasm;
        germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
        if (germplasm == null) {
            germplasm = getPrimaryGermplasmForFinished(parentInventory);
            if (germplasm != null) {
                stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
            }
        }
        return germplasm;
    }

    private Germplasm getPrimaryGermplasmForFinished(StagingInventory parentInventory) {
        String cropName = parentInventory.getInventoryHeader().getCropName();
        String pedigreeName = parentInventory.getPedigreeName();
        String lineCode = parentInventory.getLineCode();
        String productName = parentInventory.getProductName();
        Germplasm germplasm;

        ProductNameProductGermplasm productNameProductGermplasm = getProductNameProductGermplasm(cropName, lineCode,
                pedigreeName, productName);
        if (getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm) != null) {
            germplasm = getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm);
        } else {
            germplasm = createFinishedGermplasmDAO(cropName, getLineFunctionCriteria(parentInventory))
                    .getPrimaryGermplasm(lineCode);
        }
        return germplasm;
    }

    protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName,
                                                              LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGermplasmDAO(cropName, lineFunctionCriteria);
    }

    private GeneticMaterial getDuplicateGeneticMaterial(StagingInventory parentInventory) {
        GeneticMaterial geneticMaterial;
        String lineType = parentInventory.getLineType();
        if (MaterialTypeConstants.SEGPOP_LINES.equalsIgnoreCase(lineType) ||
                MaterialTypeConstants.CODED_LINES.equalsIgnoreCase(lineType)) {
            String cropName = parentInventory.getInventoryHeader().getCropName();
            String pedigree = parentInventory.getPedigreeName();
            String source = parentInventory.getSource();

            geneticMaterial = createGeneticMaterialDAO(cropName, getLineFunctionCriteria(parentInventory))
                    .getGeneticMaterial(pedigree, source, lineType);
        } else {
            geneticMaterial = fetchExistingMatchingGeneticMaterial(parentInventory);
        }
        return geneticMaterial;
    }

    protected GeneticMaterialDAO createGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        return new GeneticMaterialDAO(cropName, lineFunctionCriteria);
    }

    private Germplasm createOrGetExistingGermplasm(
            StagingInventory parentInventory) {
        Germplasm germplasm;
        if (MaterialTypeConstants.FINISHED_LINES.equalsIgnoreCase(parentInventory.getLineType())) {
            germplasm = getExistingGermplasmForFinished(parentInventory);
        } else { // Segpop or Coded always create
            germplasm = createMidasGermplasm(parentInventory);
            stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
            addGermplasm(germplasm);
        }
        return germplasm;
    }

    private void processParentage(StagingInventory stagingInventory,
                                  StagingInventory[] parentInventories) {
        GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

        GeneticMaterial parentGenMat;
        String parentalRole;
        for (int i = 0; i < parentInventories.length; i++) {
            StagingInventory parentInventory = parentInventories[i];
            parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
            parentalRole = stagingParentageHelper.getInventoryParentalRole(parentInventory);
            Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
            addParentage(parentage);
        }
    }

    private boolean parentageExists(GeneticMaterial geneticMaterial) {
        List parentageList = new ParentageList().getParentage(geneticMaterial);
        return (parentageList != null) && parentageList.size() > 0;
    }

    private Inventory fetchExistingArchivedMidasInventory(StagingInventory stagingInventory) {
        return new MidasInventoryDAO().getArchivedInventory(stagingInventory,
                new GermplasmListFetchStrategyFinished());
    }

    private GeneticMaterial fetchExistingMatchingGeneticMaterial(StagingInventory stagingInventory) {
        String cropName = stagingInventory.getInventoryHeader().getCropName();
        String source = stagingInventory.getSource();
        String lineCode = stagingInventory.getLineCode();
        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(stagingInventory);
        GeneticMaterial geneticMaterial = null;

        geneticMaterial = getGeneticMaterialFromProductName(cropName, lineFunctionCriteria, stagingInventory);
        if (geneticMaterial == null) {
            if (MaterialTypeConstants.FINISHED_LINES.equals(stagingInventory.getLineType())) {
                geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
                        .getPrimaryGeneticMaterial(lineCode, source);
            }
            if (MaterialTypeConstants.HYBRID_LINES.equals(stagingInventory.getLineType())) {
                geneticMaterial = createHybridGeneticMaterialDAO(stagingInventory.getSource(), cropName)
                        .getLowestGeneticMaterialMatchingPedigreeName(stagingInventory.getPedigreeName());
            }
        }

        return geneticMaterial;
    }

    protected FinishedGeneticMaterialDAO createFinishedGeneticMaterialDAO(String cropName,
                                                                          LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGeneticMaterialDAO(cropName, lineFunctionCriteria);
    }
}