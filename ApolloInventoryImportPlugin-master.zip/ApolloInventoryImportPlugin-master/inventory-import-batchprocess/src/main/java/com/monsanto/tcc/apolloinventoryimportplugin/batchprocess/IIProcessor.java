/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

/**
 * Filename: $Id: IIProcessor.java,v 1.2 2009-06-05 14:07:48 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public interface IIProcessor {
    MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException;
}
