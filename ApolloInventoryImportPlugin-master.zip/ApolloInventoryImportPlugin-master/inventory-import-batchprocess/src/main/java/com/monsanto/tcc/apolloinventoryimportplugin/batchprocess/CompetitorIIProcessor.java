/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategyCompetitor;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gp.GermplasmPicker;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename: $Id: CompetitorIIProcessor.java,v 1.2 2009-06-05 14:07:48 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class CompetitorIIProcessor extends AbstractStagingInventoryProcessor {
    public MidasContext processInventory(InventoryContext inventoryContext) throws
            InventoryImportProcessorException {
        Inventory inventory = null;

        // Check for matching archived inventory - if found activate it
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();
        inventory = lookUpMatchingArchivedMidasInventory(stagingInventory);
        if (inventory != null) {
            unarchiveMidasInventory(inventory, stagingInventory);
        } else // Create new inventory record along with/without GeneticMaterial
        {
            GeneticMaterial genMatAssociatedWithNewInventory = lookUpMatchingGeneticMaterial(stagingInventory);

            if (genMatAssociatedWithNewInventory == null) {
                genMatAssociatedWithNewInventory = createGeneticMaterial(stagingInventory);
                addGeneticMaterial(genMatAssociatedWithNewInventory);
            }

            // Create new Inventory record
            inventory = createMidasInventory(stagingInventory, genMatAssociatedWithNewInventory);
        }
        addInventory(inventory);

        stagingInventory.setImportStatus(getImportedStatus());

        return midasContext;
    }

    private GeneticMaterial createGeneticMaterial(StagingInventory stagingInventory)
            throws InventoryImportProcessorException {
        GeneticMaterial geneticMaterial = null;
        try {
            Germplasm germplasm = new GermplasmPicker()
                    .getPrimaryGermplasm(stagingInventory, createGermplasmListFetchStrategy());
            geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
            if ("Finished".equalsIgnoreCase(germplasm.getLineType().getLineTypeRefId())) {
                geneticMaterial.setGeneration("INBRED");
                geneticMaterial.setLineage("|");
            } else { // Hybrid
                geneticMaterial.setGeneration("F1");
                geneticMaterial.setLineage(null);
            }
            addGeneticMaterial(geneticMaterial);
        } catch (Exception e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        }

        return geneticMaterial;
    }

    protected GermplasmListFetchStrategyCompetitor createGermplasmListFetchStrategy() {
        return new GermplasmListFetchStrategyCompetitor();
    }

    private Inventory lookUpMatchingArchivedMidasInventory(StagingInventory stagingInventory) throws
            InventoryImportProcessorException {
        Inventory inventory;
        try {
            inventory = new MidasInventoryDAO().getArchivedInventory(stagingInventory,
                    createGermplasmListFetchStrategy());
        } catch (Exception e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        }
        return inventory;
    }

    private GeneticMaterial lookUpMatchingGeneticMaterial(StagingInventory stagingInventory) {
        return new MidasInventoryDAO().getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(stagingInventory,
                createGermplasmListFetchStrategy());
    }
}
