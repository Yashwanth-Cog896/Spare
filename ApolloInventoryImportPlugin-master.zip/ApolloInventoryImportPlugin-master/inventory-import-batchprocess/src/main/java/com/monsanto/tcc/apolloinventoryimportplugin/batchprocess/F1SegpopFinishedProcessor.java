/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.FinishedGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategySegpop;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ParentageList;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProductNameProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.Util.StringUtils;

import java.util.List;

/**
 * Filename:    $RCSfile: F1SegpopFinishedProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:   $Date: 2008-06-12 04:50:23 $
 *
 * @author apatro
 * @version $Revision: 1.21 $
 * @noinspection UnusedDeclaration
 */
public class F1SegpopFinishedProcessor extends AbstractStagingInventoryProcessor {
  public static final String INVENTORY_CANNOT_BE_NULL_MSG = "InventoryContext cannot be null.";
  public static final String TWO_PARENTS_MUST_EXIST_MSG = "Two parents must exist.";
  private static final String HYBRID = MaterialTypeConstants.HYBRID_LINES;
  private static final String SEGPOP = MaterialTypeConstants.SEGPOP_LINES;
  private StagingParentageHelper stagingParentageHelper;
  private boolean f1SegpopIsMainRecord = false;

  public F1SegpopFinishedProcessor() {
    super();
    f1SegpopIsMainRecord = true;
  }

  public F1SegpopFinishedProcessor(MidasContext midasContext, StagingParentageHelper stagingParentageHelper) {
    super();
    this.midasContext = midasContext;
    this.stagingParentageHelper = stagingParentageHelper;
  }

  public MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException {
    if (null == inventoryContext) {
      throw new IllegalStateException(INVENTORY_CANNOT_BE_NULL_MSG);
    }

    StagingInventory stagingInventory = inventoryContext.getStagingInventory();

    if (stagingParentageHelper == null) {
      stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());
    }

    if (processMainRecord(inventoryContext)) {
      processSubRecords(stagingInventory, inventoryContext);
    }

    return midasContext;
  }

  private boolean processF1Segpop(StagingInventory stagingInventory, InventoryContext inventoryContext) {
    boolean parentageNotExists = true;

    GeneticMaterial geneticMaterial = fetchExistingMatchingGeneticMaterial(stagingInventory);
    if (geneticMaterial == null) {
      Germplasm germplasm = createMidasGermplasm(stagingInventory);
      stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
      addGermplasm(germplasm);
      geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
      addGeneticMaterial(geneticMaterial);
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        Inventory inventory = createMidasInventory(stagingInventory, geneticMaterial);
        addInventory(inventory);
      }
    } else if (parentageExists(geneticMaterial)) {
      parentageNotExists = false;
      inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
          geneticMaterial.getGeneticMaterialId());
    }

    stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

    if (parentageNotExists) {
      setImportStatus(stagingInventory, getImportedStatus());
    } else {
      setImportStatus(stagingInventory, getUnprocessedStatus());
    }

    return parentageNotExists;
  }

  private boolean processMainRecord(InventoryContext inventoryContext) {
    StagingInventory stagingInventory = inventoryContext.getStagingInventory();

    boolean processSubRecords = false;
    boolean archivedInventoryProcessed = false;

    if (f1SegpopIsMainRecord) {
      archivedInventoryProcessed = processArchivedInventory(stagingInventory);
    }

    if (!archivedInventoryProcessed) {
      processSubRecords = processF1Segpop(stagingInventory, inventoryContext);
    }

    return processSubRecords;
  }

  private boolean processArchivedInventory(StagingInventory stagingInventory) {
    boolean archivedInventoryFound = false;
    Inventory inventory = fetchExistingArchivedMidasInventory(stagingInventory);
    if (inventory != null) {
      archivedInventoryFound = true;
      unarchiveMidasInventory(inventory, stagingInventory);
      stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, inventory.getGeneticMaterial());
      addInventory(inventory);
    }
    return archivedInventoryFound;
  }

  private Inventory fetchExistingArchivedMidasInventory(StagingInventory stagingInventory) {
    return new MidasInventoryDAO().getArchivedInventory(stagingInventory,
        createGermplasmFetchStrategyForSegpop());
  }

  protected GermplasmListFetchStrategy createGermplasmFetchStrategyForSegpop() {
    return new GermplasmListFetchStrategySegpop();
  }

  private GeneticMaterial fetchExistingMatchingGeneticMaterial(StagingInventory stagingInventory) {
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String lineFunctionRefId = stagingInventory.getLineFunction();
    String pedigreeName = stagingInventory.getPedigreeName();
    String source = stagingInventory.getSource();
    String lineType = stagingInventory.getLineType();

    return createGeneticMaterialDAO(cropName, getLineFunctionCriteria(stagingInventory))
        .getGeneticMaterial(pedigreeName, source, lineType);
  }

  protected GeneticMaterialDAO createGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
    return new GeneticMaterialDAO(cropName, lineFunctionCriteria);
  }

  private void processSubRecords(StagingInventory stagingInventory, InventoryContext inventoryContext) throws
      InventoryImportProcessorException {
    StagingInventory[] parentInventories = stagingParentageHelper.getParentInventories(stagingInventory);

    if (parentInventories != null) {
      for (int i = 0; i < parentInventories.length; i++) {
        StagingInventory parentInventory = parentInventories[i];
        if (SEGPOP.equalsIgnoreCase(parentInventory.getLineType()) ||
            isLineTypeHybridAndProductNameNull(parentInventory)) {
          if (processSegpopHybridParent(parentInventory, inventoryContext)) {
            processSubRecords(parentInventory, inventoryContext);
          }
        } else { // Finished
          processFinishedParent(parentInventory, inventoryContext);
        }
      }
      processParentage(stagingInventory, parentInventories);
    } else {
      if (!stagingInventory.equals(inventoryContext.getStagingInventory())) {
        inventoryContext.addMessage(stagingInventory, TWO_PARENTS_MUST_EXIST_MSG);
      }
      throw new InventoryImportProcessorException(TWO_PARENTS_MUST_EXIST_MSG);
    }
  }

  private void processFinishedParent(StagingInventory parentInventory, InventoryContext inventoryContext)
      throws InventoryImportProcessorException {
    try {
      GeneticMaterial geneticMaterial = getDuplicateFinishedParentGenMat(parentInventory);
      if (geneticMaterial == null) {
        Germplasm germplasm = getExistingFinishedParentGermplasm(parentInventory);
        geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
        addGeneticMaterial(geneticMaterial);
        if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
          addInventory(createMidasInventory(parentInventory, geneticMaterial));
        }
      }
      stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);
      setImportStatus(parentInventory, getImportedStatus());
    } catch (Exception e) {
      inventoryContext.addMessage(parentInventory, e);
      throw new InventoryImportProcessorException(
          "Finished Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
    }
  }

  private Germplasm getExistingFinishedParentGermplasm(StagingInventory stagingInventory) {
    Germplasm germplasm;
    germplasm = stagingParentageHelper.getInventoryGermplasm(stagingInventory);
    if (germplasm == null) {
      String cropName = stagingInventory.getInventoryHeader().getCropName();
      String pedigreeName = stagingInventory.getPedigreeName();
      String lineCode = stagingInventory.getLineCode();
      String productName = stagingInventory.getProductName();

      ProductNameProductGermplasm productNameProductGermplasm = getProductNameProductGermplasm(cropName, lineCode,
          pedigreeName, productName);
      if(getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm) != null) {
        germplasm = getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm);
      } else {
        germplasm = createFinishedGermplasmDAO(cropName, getLineFunctionCriteria(stagingInventory))
            .getPrimaryGermplasm(lineCode);
      }
      if (germplasm != null) {
        stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
      }
    }
    return germplasm;
  }

  protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName,
                                                            LineFunctionCriteria lineFunctionCriteria) {
    return new FinishedGermplasmDAO(cropName, lineFunctionCriteria);
  }

  private GeneticMaterial getDuplicateFinishedParentGenMat(StagingInventory stagingInventory) {
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String source = stagingInventory.getSource();
    String lineCode = stagingInventory.getLineCode();
    LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(stagingInventory);
    GeneticMaterial geneticMaterial = null;

    geneticMaterial = getGeneticMaterialFromProductName(cropName, lineFunctionCriteria, stagingInventory);
    if(geneticMaterial == null) {
      if(MaterialTypeConstants.FINISHED_LINES.equals(stagingInventory.getLineType())) {
        geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
            .getPrimaryGeneticMaterial(lineCode, source);
      }
      if(HYBRID.equals(stagingInventory.getLineType())) {
        geneticMaterial = createHybridGeneticMaterialDAO(stagingInventory.getSource(), cropName)
            .getLowestGeneticMaterialMatchingPedigreeName(stagingInventory.getPedigreeName());
      }
    }

    return geneticMaterial;
  }

  private boolean processSegpopHybridParent(StagingInventory parentInventory, InventoryContext inventoryContext)
      throws InventoryImportProcessorException {
    boolean success;
    try {
      success = processF1Segpop(parentInventory, inventoryContext);
    } catch (Exception e) {
      inventoryContext.addMessage(parentInventory, e);
      String type = parentInventory.getLineType();
      throw new InventoryImportProcessorException(
          type + " Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
    }

    return success;
  }

  private void processParentage(StagingInventory stagingInventory, StagingInventory[] parentInventories) {
    GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

    GeneticMaterial parentGenMat;
    String parentalRole;
    for (int i = 0; i < parentInventories.length; i++) {
      StagingInventory parentInventory = parentInventories[i];
      parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
      parentalRole = stagingParentageHelper.getInventoryParentalRole(parentInventory);
      Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
      addParentage(parentage);
    }
  }

  private void setImportStatus(StagingInventory stagingInventory, ImportStatus status) {
    stagingInventory.setImportStatus(status);
  }

  private boolean parentageExists(GeneticMaterial geneticMaterial) {
    List parentageList = new ParentageList().getParentage(geneticMaterial);
    return (parentageList != null) && parentageList.size() > 0;
  }

  private boolean isLineTypeHybridAndProductNameNull(StagingInventory parentInventory) {
    return HYBRID.equalsIgnoreCase(parentInventory.getLineType()) &&
        StringUtils.isNullOrEmpty(parentInventory.getProductName());
  }
}