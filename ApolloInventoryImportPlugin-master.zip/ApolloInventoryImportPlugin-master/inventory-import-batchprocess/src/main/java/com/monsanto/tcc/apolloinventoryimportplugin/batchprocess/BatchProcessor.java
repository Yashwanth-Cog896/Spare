/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.KerberosPOSSecurity.KerberosContextUtil;
import com.monsanto.KerberosPOSSecurity.KerberosRunnable;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchRunSummaryInfo;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.systemekg.BatchSystemEKGLogger;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.posclients.ApprovedStagingInventoryActivityClient;
import com.monsanto.tcc.apolloinventoryimportplugin.common.posclients.ValidateStagingInventoryWithoutSavePOSClient;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.ietf.jgss.GSSException;

/**
 * Filename: $Id: BatchProcessor.java,v 1.43 2009-06-05 14:07:48 ssnall Exp $
 *
 * @author APATRO
 * @version $Revision: 1.43 $
 */
public class BatchProcessor {
    private boolean m_commit;
    private int m_processingBlockSize;
    private BatchRunHistoryHelper m_runHistoryHelper;
    private long m_recordsProcessed = 0;
    public static final int DEFAULT_FETCH_ALL_BLOCK_SIZE = 0;

    public BatchProcessor(boolean commit) {
        this(commit, DEFAULT_FETCH_ALL_BLOCK_SIZE);
    }

    public BatchProcessor(boolean commit, int processingBlockSize) {
        this.m_commit = commit;
        this.m_processingBlockSize =
                (processingBlockSize >= DEFAULT_FETCH_ALL_BLOCK_SIZE) ? processingBlockSize : DEFAULT_FETCH_ALL_BLOCK_SIZE;
        initBatchRunHistoryHelper();
    }

    private void initBatchRunHistoryHelper() {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();

        m_runHistoryHelper = createBatchRunHistoryHelper();

        if (m_commit) {
            session.getTransaction().commit();
        } else {
            session.getTransaction().rollback();
        }
    }

    protected BatchRunHistoryHelper createBatchRunHistoryHelper() {
        return new BatchRunHistoryHelper();
    }

    protected StagingInventory[] getStagingInventoryInApprovedStatus(int fetchSize) throws ActivityClientException,
            GSSException, IllegalAccessException, InstantiationException {
        ApprovedStagingInventoryActivityClient approvedStagingInventoryActivityClient = createApprovedStagingInventoryActivityClient();

        return approvedStagingInventoryActivityClient
                .getApprovedStagingInventories(fetchSize);
    }

    protected ApprovedStagingInventoryActivityClient createApprovedStagingInventoryActivityClient() {
        return new ApprovedStagingInventoryActivityClient();
    }

    protected void validateAndProcessInventory(StagingInventory[] approvedStagingInventory) {
        if (approvedStagingInventory == null) {
            return;
        }

        for (int i = 0; i < approvedStagingInventory.length; i++) {
            validateAndProcessInventory(approvedStagingInventory[i]);
        }
    }

    protected MidasContext validateAndProcessInventory(StagingInventory stagingInventory) {
        MidasContext midasContext = null;

        try {
            if (validateStagingInventory(stagingInventory)) {
                midasContext = processStagingInventoryIntoMidas(stagingInventory);
                m_recordsProcessed += 1;
            }
        } catch (Exception ex) {
            m_runHistoryHelper.setProcessExceptionMessage(stagingInventory, ex);
            ex.printStackTrace();
        } finally {
            // Try saving the RunDetails for this staging inventory
            saveRunDetails(stagingInventory);
        }

        return midasContext;
    }

    private void saveRunDetails(StagingInventory stagingInventory) {
        Transaction transaction = null;
        boolean encounteredException = true;
        try {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
            transaction = session.beginTransaction();
            getBatchRunHistoryHelper().saveRunDetails(stagingInventory);
            session.flush();
            if (m_commit) {
                transaction.commit();
            }
            getBatchRunHistoryHelper().removeRunDetails(stagingInventory);
            encounteredException = false;
        } catch (Exception ex) {
            if (!m_commit || encounteredException) {
                if (transaction != null) {
                    transaction.rollback();
                }
            }
            ex.printStackTrace();
        }
    }

    protected boolean validateStagingInventory(StagingInventory stagingInventory) throws ActivityClientException,
            GSSException, IllegalAccessException, InstantiationException {
        ValidateStagingInventoryWithoutSavePOSClient validateStagingInventoryActivityClient = createValidateStagingInventoryActivityClient();
        StagingInventory validatedStagingInventory;
        validatedStagingInventory = validateStagingInventoryActivityClient.validateStagingInventory(stagingInventory);

        ImportStatus validationStatus = validatedStagingInventory.getImportStatus();

        boolean valid = true;
        if ("Invalid".equalsIgnoreCase(validationStatus.getStatusCode())) {
            System.out.println("Validation failed for StagingInventory - " + stagingInventory.getId() + " - " +
                    validationStatus.getStatusCode());
            valid = false;
        } else {
            System.out.println("Processing StagingInventory - " + stagingInventory.getId() + " - into Midas");
        }

        getBatchRunHistoryHelper().setValidationInfo(validatedStagingInventory);

        //
        //TODO: Workaround for handling dates in XSD - Need to fix this within the serializer or XSD
        //TODO: This also seems to fix loading parentage records for now but this problem should be fixed when deserializing the POS response envelope
        //
        refreshStagingInventory(stagingInventory);

        return valid;
    }

    protected void refreshStagingInventory(StagingInventory stagingInventory) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        session.load(stagingInventory, stagingInventory.getId());
        if (m_commit) {
            session.getTransaction().commit();
        } else {
            session.getTransaction().rollback();
        }
    }

    protected ValidateStagingInventoryWithoutSavePOSClient createValidateStagingInventoryActivityClient() {
        return new ValidateStagingInventoryWithoutSavePOSClient();
    }

    protected ImportStatus getImportStatus(String statusCode) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        return (ImportStatus) session.createCriteria(ImportStatus.class)
                .add(Restrictions.eq("statusCode", statusCode)).uniqueResult();
    }

    protected MidasContext processStagingInventoryIntoMidas(StagingInventory stagingInventory) throws
            InventoryImportProcessorException, IllegalAccessException, InstantiationException {
        MidasContext midasContext = null;
        boolean encounteredException = true;
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        try {
            IIProcessor IIProcessor = createInventoryImportProcessor(stagingInventory);
            InventoryContext inventoryContext = new InventoryContext(stagingInventory, m_runHistoryHelper);
            midasContext = IIProcessor.processInventory(inventoryContext);
            midasContext.save(session);
            updateStagingInventory(stagingInventory);
            session.flush();
            if (m_commit) {
                session.getTransaction().commit();
            }
            encounteredException = false;
        } finally {
            if (!m_commit || encounteredException) {
                session.getTransaction().rollback();
            }
        }
        return midasContext;
    }

    protected IIProcessor createInventoryImportProcessor(StagingInventory stagingInventory)
            throws IllegalAccessException, InstantiationException {
        return IIProcessorFactory.createInventoryImportProcessor(stagingInventory);
    }

    protected void updateStagingInventory(StagingInventory processedStagingInventory) {
        if (processedStagingInventory != null) {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

            String statusCode = processedStagingInventory.getImportStatus().getStatusCode();
            if ("Imported".equalsIgnoreCase(statusCode) ||
                    "Unprocessed".equalsIgnoreCase(statusCode)) {
                session.update(processedStagingInventory);
                if (processedStagingInventory.getStagingParentage() != null) {
                    StagingParentage[] stagingParentage = processedStagingInventory.getSubRecords();
                    for (int i = 0; i < stagingParentage.length; i++) {
                        StagingInventory parentInventory = stagingParentage[i].getParentInventory();
                        String parentStatusCode = parentInventory.getImportStatus().getStatusCode();
                        if (!("Imported".equalsIgnoreCase(parentStatusCode) || "Unprocessed".equalsIgnoreCase(parentStatusCode))) {
                            parentInventory.setImportStatus(getImportStatus("Unprocessed"));
                        }
                        session.update(parentInventory);
                    }
                }
            }
        }
    }

    private void process() throws ActivityClientException, GSSException, InstantiationException, IllegalAccessException {
        StagingInventory[] approvedStagingInventory = getStagingInventoryInApprovedStatus(m_processingBlockSize);

        System.out.println("Number of Approved StagingInventory records found - " +
                ((approvedStagingInventory == null) ? 0 : approvedStagingInventory.length));

        process(approvedStagingInventory);
    }

    private void sendBatchRunSummaryInfoToSystemEKG(StagingInventory[] approvedStagingInventory, RunHistory runHistory) {
        BatchRunSummaryInfo batchRunSummaryInfo = createBatchSummaryInfo(approvedStagingInventory, runHistory);

        createSystemEKGLogger().log(batchRunSummaryInfo);
    }

    protected BatchRunSummaryInfo createBatchSummaryInfo(StagingInventory[] approvedStagingInventory,
                                                         RunHistory runHistory) {
        return new BatchRunSummaryInfo(approvedStagingInventory, runHistory);
    }

    protected BatchSystemEKGLogger createSystemEKGLogger() {
        return new BatchSystemEKGLogger();
    }

    protected void process(StagingInventory[] approvedStagingInventory) {
        initBatchRunHistory(approvedStagingInventory);

        validateAndProcessInventory(approvedStagingInventory);

        updateBatchRunHistory();

        sendBatchRunSummaryInfoToSystemEKG(approvedStagingInventory, m_runHistoryHelper.getRunHistory());
    }

    public static void AppMain(String[] args) throws ActivityClientException, GSSException, IllegalAccessException,
            InstantiationException {
        boolean commit = true;
        if (args[0].equalsIgnoreCase("rollback")) {
            commit = false;
        }

        int processingBlockSize = DEFAULT_FETCH_ALL_BLOCK_SIZE;
        if (null != args && args.length > 1) {
            try {
                processingBlockSize = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                processingBlockSize = DEFAULT_FETCH_ALL_BLOCK_SIZE;
            }
        }

        BatchProcessor batchProcessor = new BatchProcessor(commit, processingBlockSize);
        batchProcessor.process();
    }

    private void updateBatchRunHistory() {
        boolean encounteredException = true;
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
            transaction = session.beginTransaction();
            getBatchRunHistoryHelper().setRecordsProcessed(m_recordsProcessed);
            getBatchRunHistoryHelper().setRunStatus("Done");
            getBatchRunHistoryHelper().stampEndDate();
            getBatchRunHistoryHelper().saveRunHistory();
            session.flush();
            if (m_commit) {
                transaction.commit();
            }
            encounteredException = false;
        } finally {
            if (encounteredException || !m_commit) {
                if (transaction != null) {
                    transaction.rollback();
                }
            }
        }
    }

    private void initBatchRunHistory(StagingInventory[] approvedStagingInventory) {
        boolean encounteredException = true;
        Transaction transaction = null;
        try {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
            transaction = session.beginTransaction();
            if (null != approvedStagingInventory) getBatchRunHistoryHelper().addRecords(approvedStagingInventory);
            getBatchRunHistoryHelper().saveRunHistory();
            getBatchRunHistoryHelper().saveRunDetails();
            session.flush();
            if (m_commit) {
                transaction.commit();
            }
            encounteredException = false;
        } finally {
            if (encounteredException || !m_commit) {
                if (transaction != null) {
                    transaction.rollback();
                }
            }
        }
    }

    protected BatchRunHistoryHelper getBatchRunHistoryHelper() {
        return m_runHistoryHelper;
    }

    public static void KerberizedAppMain(String[] args) throws Exception {
        KerberosContextUtil kerberosContextUtil = new KerberosContextUtil();
        kerberosContextUtil.runAsKerbServerBeingClient(new KerbRunnable(args),
                " - kerb batch");
    }

    public static void main(String[] args) throws Exception {
        BatchProcessor.KerberizedAppMain(args);
    }

    static class KerbRunnable implements KerberosRunnable {
        private String[] args;

        public KerbRunnable(String[] args) {
            this.args = args;
        }

        public void runUnderKerberos() throws Exception {
            BatchProcessor.AppMain(args);
        }

        public void reportErrorFromRun(String message, Exception exception) throws Exception {
            throw exception;
        }
    }
}
