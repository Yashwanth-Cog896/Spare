/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ProcessName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunDetail;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.RunHistory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.*;

/**
 * Filename:    $RCSfile: BatchRunHistoryHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:	$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.10 $
 */
public class BatchRunHistoryHelper {
  private RunHistory runHistory;
  private Map runDetailsMap;

  public BatchRunHistoryHelper() {
    runDetailsMap = new HashMap();
    createAndInitRunHistory();
  }

  private void createAndInitRunHistory() {
    runHistory = createRunHistory();

    runHistory.setProcessName(getProcessName("Batch"));
    runHistory.setStartDate(new Timestamp(new Date().getTime()));
    runHistory.setRunStatus(getRunStatus("Running"));
    runHistory.setRecordsProcessed(new Long(0L));
  }

  protected RunHistory createRunHistory() {
    return new RunHistory();
  }

  public void setRunStatus(String statusCode) {
    runHistory.setRunStatus(getRunStatus(statusCode));
  }

  protected RunStatus getRunStatus(String statusCode) {
    Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    return (RunStatus) session.createCriteria(RunStatus.class, "rs")
        .add(Restrictions.eq("statusCode", statusCode).ignoreCase()).uniqueResult();
  }

  protected ProcessName getProcessName(String name) {
    Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    return (ProcessName) session.createCriteria(ProcessName.class, "pn")
        .add(Restrictions.eq("name", name).ignoreCase()).uniqueResult();
  }


  public long addRecords(StagingInventory[] stagingInventories) {
    long recordCount = 0;

    if (null != stagingInventories) {
      for (int i = 0; i < stagingInventories.length; i++) {
        addRecord(stagingInventories[i]);
        recordCount += addSubRecords(stagingInventories[i]);
      }
      recordCount += stagingInventories.length;
    }

    return recordCount;
  }

  private long addRecord(StagingInventory stagingInventory) {
    long recordCount = 0;
    if (!runDetailsMap.containsKey(getKey(stagingInventory))) {
      RunDetail runDetail = createRunDetail();
      runDetail.setRunHistory(runHistory);
      runDetail.setInventoryId(stagingInventory.getId());
      runDetailsMap.put(getKey(stagingInventory), runDetail);
      recordCount = 1;
    }
    return recordCount;
  }

  protected RunDetail createRunDetail() {
    return new RunDetail();
  }

  public long addSubRecords(StagingInventory stagingInventory) {
    Set stagingParentageSet = stagingInventory.getStagingParentage();
    if (stagingParentageSet == null || stagingParentageSet.isEmpty()) return 0L;

    int recordCount = 0;
    for (Iterator iterator = stagingParentageSet.iterator(); iterator.hasNext();) {
      StagingParentage sp = (StagingParentage) iterator.next();
      recordCount += addRecord(sp.getParentInventory());
    }
    return recordCount;
  }

  private String getKey(StagingInventory stagingInventory) {
    String key = null;
    if (stagingInventory.getId() != null) {
      key = stagingInventory.getId().toString();
    } else {
      key = stagingInventory.hashCode() + "";
    }

    return key;
  }

  protected final RunDetail getRunDetails(StagingInventory stagingInventory) {
    return (RunDetail) runDetailsMap.get(getKey(stagingInventory));
  }

  protected final RunHistory getRunHistory() {
    return runHistory;
  }

  protected final RunDetail[] getRunDetails() {
    return (runDetailsMap.isEmpty()) ? null : (RunDetail[]) runDetailsMap.values().toArray(new RunDetail[0]);
  }

  public void removeRunDetails(StagingInventory stagingInventory) {
    runDetailsMap.remove(getKey(stagingInventory));
    removeRunDetailsForParentageInventory(stagingInventory);
  }

  private void removeRunDetailsForParentageInventory(StagingInventory stagingInventory) {
    Set parentageSet = stagingInventory.getStagingParentage();
    if (parentageSet != null && parentageSet.size() > 0) {
      Iterator iterator = parentageSet.iterator();
      while (iterator.hasNext()) {
        removeRunDetails(((StagingParentage) iterator.next()).getParentInventory());
      }
    }
  }

  public void saveRunHistory() {
    Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

    session.saveOrUpdate(runHistory);
  }

  public void saveRunDetails() {
    RunDetail[] runDetails = getRunDetails();

    if (null == runDetails) return;

    for (int i = 0; i < runDetails.length; i++) {
      saveRunDetails(runDetails[i]);
    }
  }

  private void saveRunDetails(RunDetail runDetail) {
    if (null != runDetail) {
      Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
      session.saveOrUpdate(runDetail);
    }
  }

  public void setRecordsProcessed(long recordsProcessed) {
    runHistory.setRecordsProcessed(new Long(recordsProcessed));
  }

  public void setValidationInfo(StagingInventory validatedStagingInventory) {
    RunDetail runDetail = getRunDetails(validatedStagingInventory);
    if (null != runDetail) {
      runDetail.setValidationStatus(validatedStagingInventory.getImportStatus());
      runDetail.setValidationExceptionMsg(validatedStagingInventory.getValidationMessage());
      setValidationInforForParentageInventory(validatedStagingInventory);
    }
  }

  private void setValidationInforForParentageInventory(StagingInventory validatedStagingInventory) {
    Set parentageSet = validatedStagingInventory.getStagingParentage();
    if (parentageSet != null && parentageSet.size() > 0) {
      Iterator iterator = parentageSet.iterator();
      while (iterator.hasNext()) {
        setValidationInfo(((StagingParentage) iterator.next()).getParentInventory());
      }
    }
  }

  public void setProcessExceptionMessage(StagingInventory stagingInventory, String processMessage) {
    RunDetail runDetail = getRunDetails(stagingInventory);
    if (null != runDetail) {
      String message = runDetail.getProcessExceptionMsg();
      if (!StringUtils.isNullOrEmpty(message)) {
        message += "\n" + processMessage;
      } else {
        message = processMessage;
      }
      runDetail.setProcessExceptionMsg(message);
    }
  }

  public void setProcessExceptionMessage(StagingInventory stagingInventory, Exception e) {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    e.printStackTrace(printWriter);
    setProcessExceptionMessage(stagingInventory, stringWriter.toString());
  }

  public String getProcessExceptionMessage(StagingInventory stagingInventory) {
    RunDetail runDetail = getRunDetails(stagingInventory);
    String message = null;
    if (null != runDetail) {
      message = runDetail.getProcessExceptionMsg();
    }
    return message;
  }

  public void saveRunDetails(StagingInventory stagingInventory) {
    saveRunDetails(getRunDetails(stagingInventory));
    saveRunDetailsForParentageInventory(stagingInventory);
  }

  private void saveRunDetailsForParentageInventory(StagingInventory stagingInventory) {
    Set parentageSet = stagingInventory.getStagingParentage();
    if (parentageSet != null && parentageSet.size() > 0) {
      Iterator iterator = parentageSet.iterator();
      while (iterator.hasNext()) {
        saveRunDetails(((StagingParentage) iterator.next()).getParentInventory());
      }
    }
  }

  public void stampEndDate() {
    runHistory.setEndDate(new Timestamp(new Date().getTime()));
  }
}