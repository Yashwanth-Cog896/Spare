/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: InventoryContext.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $ On:	$Date:
 * 2007/05/21 16:15:58 $
 *
 * @author apatro
 * @version $Revision: 1.4 $
 */
public class InventoryContext {
  public static final String PARAMETERS_REQ_EXCEP_MSG = "StagingInventory and BatchRunHistoryHelper are required";

  private StagingInventory stagingInventory;
  private BatchRunHistoryHelper batchRunHistoryHelper;
  private int parentRecordsProcessed;

  public InventoryContext(StagingInventory stagingInventory, BatchRunHistoryHelper batchRunHistoryHelper) {
    if (stagingInventory == null || batchRunHistoryHelper == null) {
      throw new IllegalStateException(PARAMETERS_REQ_EXCEP_MSG);
    }

    this.stagingInventory = stagingInventory;
    this.batchRunHistoryHelper = batchRunHistoryHelper;
  }

  public StagingInventory getStagingInventory() {
    return stagingInventory;
  }

  public void addMessage(StagingInventory parentInventory, String message) {
    batchRunHistoryHelper.setProcessExceptionMessage(parentInventory, message);

    if (!stagingInventory.equals(parentInventory)) {
      addMessage(stagingInventory, "Parent Inventory[" + parentInventory.getId() + "]: " + message);
    }
  }

  public void addMessage(StagingInventory parentInventory, Exception exception) {
    batchRunHistoryHelper.setProcessExceptionMessage(parentInventory, exception);
  }

  public InventoryContext getInventoryContext(StagingInventory parentInventory) {
    InventoryContext inventoryContext;
    if (parentInventory != null && parentInventory.getId() == stagingInventory.getId()) {
      inventoryContext = this;
    } else {
      inventoryContext = new InventoryContext(parentInventory, batchRunHistoryHelper);
    }
    return inventoryContext;
  }

  public void setParentRecordsProcessed(int parentRecordsProcessed) {
    this.parentRecordsProcessed = parentRecordsProcessed;
  }

  public int getParentRecordsProcessed() {
    return parentRecordsProcessed;
  }
}