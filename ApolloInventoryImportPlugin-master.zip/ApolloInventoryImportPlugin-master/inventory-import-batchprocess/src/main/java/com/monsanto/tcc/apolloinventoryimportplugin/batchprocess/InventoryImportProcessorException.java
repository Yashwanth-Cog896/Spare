/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

/**
 * Filename: $Id: InventoryImportProcessorException.java,v 1.2 2007-02-01 20:23:24 apatro Exp $
 *
 * @author APATRO
 * @version $Revision: 1.2 $
 */
public class InventoryImportProcessorException extends Exception {
    public InventoryImportProcessorException(String message) {
        super(message);
    }

    public InventoryImportProcessorException(String message, Throwable cause) {
        super(message, cause);
    }
}
