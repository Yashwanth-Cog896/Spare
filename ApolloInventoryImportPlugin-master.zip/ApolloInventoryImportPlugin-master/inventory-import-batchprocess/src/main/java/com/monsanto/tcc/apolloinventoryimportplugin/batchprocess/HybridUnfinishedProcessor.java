/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategyCoded;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategyFinished;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.HybridGermplasmGeneticMaterialDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.ParentageList;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.inventorymaterial.hybridlines.GermplasmListFetchStrategyUnfinishedHybrid;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.parentage.PedigreeNameBuilder;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridUnfinishedProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:	$Date: 2008-06-12 04:50:23 $
 *
 * @author ddbrow5
 * @version $Revision: 1.38 $
 */
public class HybridUnfinishedProcessor extends AbstractStagingInventoryProcessor {
  public static final String INVENTORY_CANNOT_BE_NULL_MSG = "InventoryContext cannot be null.";
  public static final String SESSION_CANNOT_BE_NULL_MSG = "Session cannot be null.";
  public static final String TWO_PARENTS_MUST_EXIST_MSG = "Two parents must exist.";
  private static final int NUMBER_OF_PARENTS = 2;
  private StagingParentageHelper stagingParentageHelper;
  public static final String PARENT_GENMAT_NOT_FOUND = "Existing Genetic_Material not found!";
  public static final String PARENT_NOT_FOUND_IN_MIDAS = "Parent(s) not found in MIDAS";

  public MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException {
    if (null == inventoryContext) {
      throw new IllegalStateException(INVENTORY_CANNOT_BE_NULL_MSG);
    }

    StagingInventory stagingInventory = inventoryContext.getStagingInventory();
    stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());
    if (processMainRecord(stagingInventory, inventoryContext)) {
      processSubRecords(stagingInventory, inventoryContext);
    }
    setImportStatus(stagingInventory, getImportedStatus());

    return midasContext;
  }

  private boolean processMainRecord(StagingInventory stagingInventory, InventoryContext inventoryContext) {
    boolean success = true;

    Inventory inventory = fetchExistingArchivedMidasInventory(stagingInventory);

    GeneticMaterial geneticMaterial;
    if (inventory != null) {
      unarchiveMidasInventory(inventory, stagingInventory);
      geneticMaterial = inventory.getGeneticMaterial();
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        addInventory(inventory);
      }
    } else {
      geneticMaterial = fetchExistingMatchingGeneticMaterial(stagingInventory);
      if (geneticMaterial == null) {
        Germplasm germplasm = createMidasGermplasm(stagingInventory);
        addGermplasm(germplasm);
        stagingParentageHelper.addInventoryGermplasm(stagingInventory, germplasm);
        geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
        addGeneticMaterial(geneticMaterial);
      } else if (parentageExists(geneticMaterial)) {
        success = false;
        inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
            geneticMaterial.getGeneticMaterialId());
      }
      if (isUserSpecifiedSource(stagingInventory.getUserSpecifiedSource())) {
        inventory = createMidasInventory(stagingInventory, geneticMaterial);
        addInventory(inventory);
      }
    }

    stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, geneticMaterial);

    return success;
  }

  private boolean parentageExists(GeneticMaterial geneticMaterial) {
    List parentageList = new ParentageList().getParentage(geneticMaterial);
    return (parentageList != null) && parentageList.size() > 0;
  }

  private GeneticMaterial fetchExistingMatchingGeneticMaterial(StagingInventory stagingInventory) {
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String pedigreeName = stagingInventory.getPedigreeName();
    String lineType = stagingInventory.getLineType();
    String source = stagingInventory.getSource();
    return createGeneticMaterialDAO(cropName, getLineFunctionCriteria(stagingInventory))
        .getGeneticMaterial(pedigreeName, source, lineType);
  }

  private void processSubRecords(StagingInventory stagingInventory, InventoryContext inventoryContext) throws
      InventoryImportProcessorException {
    StagingInventory[] parentInventories = getParentInventoriesFromParentageHelper(stagingInventory);

    if (null == parentInventories || parentInventories.length != NUMBER_OF_PARENTS) {
      throw new InventoryImportProcessorException(TWO_PARENTS_MUST_EXIST_MSG);
    }

    GeneticMaterial subRecordGeneticMaterial;
    boolean parentsFound = true;
    for (int i = 0; i < parentInventories.length; i++) {
      subRecordGeneticMaterial = getMatchingGeneticMaterial(parentInventories[i]);

      if (subRecordGeneticMaterial != null) {
        stagingParentageHelper.addInventoryGeneticMaterial(parentInventories[i], subRecordGeneticMaterial);
        setImportStatus(parentInventories[i], getImportedStatus());
      } else {
        if (MaterialTypeConstants.FINISHED_LINES.equalsIgnoreCase(parentInventories[i].getLineType())) {
          addGeneticMaterialForFinished(parentInventories[i]);
          setImportStatus(parentInventories[i], getImportedStatus());
        } else if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(parentInventories[i].getLineType()) && isHybridFinished(parentInventories[i])) {
          addGeneticMaterialForHybrid(parentInventories[i]);
          setImportStatus(parentInventories[i], getImportedStatus());
        } else {
          inventoryContext.addMessage(parentInventories[i], PARENT_GENMAT_NOT_FOUND);
          parentsFound = false;
        }
      }
    }
    if (!parentsFound) {
      throw new InventoryImportProcessorException(PARENT_NOT_FOUND_IN_MIDAS);
    }
    processParentage(stagingInventory, parentInventories);
  }

  private void addGeneticMaterialForFinished(StagingInventory parentInventory) {
    setGenericNonProductSourceOnStagingInventoryIfNullOrEmpty(parentInventory);
    Germplasm germplasm = getExistingFinishedParentGermplasm(parentInventory);
    GeneticMaterial geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
    addGeneticMaterial(geneticMaterial);
    if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
      addInventory(createMidasInventory(parentInventory, geneticMaterial));
    }
    stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);
  }

  private void addGeneticMaterialForHybrid(StagingInventory parentInventory) {
    setGenericNonProductSourceOnStagingInventoryIfNullOrEmpty(parentInventory);
    Germplasm germplasm = getExistingHybridParentGermplasm(parentInventory);
    GeneticMaterial geneticMaterial = createMidasGeneticMaterial(parentInventory, germplasm);
    addGeneticMaterial(geneticMaterial);
    if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
      addInventory(createMidasInventory(parentInventory, geneticMaterial));
    }
    stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, geneticMaterial);
  }

  private Germplasm getExistingFinishedParentGermplasm(StagingInventory parentInventory) {
    Germplasm germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
    if (germplasm == null) {
      germplasm = createFinishedGermplasmDAO(parentInventory.getInventoryHeader().getCropName(),
          getLineFunctionCriteria(parentInventory)).getPrimaryGermplasm(parentInventory.getLineCode());
      if (germplasm != null) {
        stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
      }
    }
    return germplasm;
  }

  private Germplasm getExistingHybridParentGermplasm(StagingInventory parentInventory) {
    Germplasm germplasm = stagingParentageHelper.getInventoryGermplasm(parentInventory);
    if (germplasm == null) {
      germplasm = createHybridGermplasmDAO(parentInventory)
          .getPrimaryGermplasm_FinishedHybridOriginExist(parentInventory.getOrigin());
      if (germplasm != null) {
        stagingParentageHelper.addInventoryGermplasm(parentInventory, germplasm);
      }
    }
    return germplasm;
  }

  private StagingInventory[] getParentInventoriesFromParentageHelper(StagingInventory stagingInventory) {
    StagingInventory[] stagingInventories = new StagingInventory[0];
    if (null != stagingParentageHelper) {
      stagingInventories = stagingParentageHelper.getParentInventories(stagingInventory);
    }
    return stagingInventories;
  }

  private Inventory fetchExistingArchivedMidasInventory(StagingInventory stagingInventory) {
    return new MidasInventoryDAO().getArchivedInventory(stagingInventory,
            new GermplasmListFetchStrategyUnfinishedHybrid());
  }

  private GeneticMaterial getMatchingGeneticMaterial(StagingInventory stagingInventory) {
    GeneticMaterial geneticMaterial;
    String lineType = stagingInventory.getLineType();
    String cropName = stagingInventory.getInventoryHeader().getCropName();
    String origin = stagingInventory.getOrigin();
    String source = stagingInventory.getSource();
    String germplasmOwner = stagingInventory.getGermplasmOwner();
    String pedigreeName = stagingInventory.getPedigreeName();
    String lineFunctionRefId = stagingInventory.getLineFunction();
    LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(stagingInventory);

    if (MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType)) {
      geneticMaterial = getHybridGermplasmGeneticMaterialDAO(cropName, origin, lineFunctionRefId)
          .getLowestGeneticMaterialMatchingSourceForUnifishedHybrid(source, germplasmOwner);
    } else {
      if (MaterialTypeConstants.FINISHED_LINES.equalsIgnoreCase(lineType)) {
        geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
            .getPrimaryGeneticMaterial(pedigreeName, source);
      } else { // Coded or Segpop
        geneticMaterial = createGeneticMaterialDAO(cropName, lineFunctionCriteria)
            .getGeneticMaterial(pedigreeName, source, lineType);
      }
    }

    return geneticMaterial;
  }

  protected GeneticMaterialDAO createGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
    return new GeneticMaterialDAO(cropName, lineFunctionCriteria);
  }

  protected GermplasmListFetchStrategyCoded createGermplasmListFetchStrategyForCoded() {
    return new GermplasmListFetchStrategyCoded();
  }

  protected GermplasmListFetchStrategyFinished createGermplasmListFetchStrategyForFinished() {
    return new GermplasmListFetchStrategyFinished();
  }

  protected HybridGermplasmGeneticMaterialDAO getHybridGermplasmGeneticMaterialDAO(String cropName, String origin,
                                                                                   String lineFunctionRefId) {
    return new HybridGermplasmGeneticMaterialDAO(cropName, origin, lineFunctionRefId);
  }


  private void processParentage(StagingInventory stagingInventory,
                                StagingInventory[] parentInventories) {
    GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

    GeneticMaterial parentGenMat;
    String parentalRole;
    for (int i = 0; i < parentInventories.length; i++) {
      StagingInventory parentInventory = parentInventories[i];
      parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
      parentalRole = stagingParentageHelper.getInventoryParentalRole(parentInventory);
      Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
      addParentage(parentage);
    }
  }

  private void setImportStatus(StagingInventory stagingInventory, ImportStatus status) {
    stagingInventory.setImportStatus(status);
  }

  /**
   * @noinspection RefusedBequest
   */
  protected String getIsFinishedOrFinishedChild(String lineType, String origin) {
    return FALSE_STRING;
  }


  /**
   * @noinspection RefusedBequest
   */
  protected String buildPedigreeName(StagingInventory stagingInventory) {
    return new PedigreeNameBuilder().createPedigreeName(stagingInventory.getLineType().toUpperCase(),
        stagingInventory.getOrigin(),
        stagingInventory.getLineage(), stagingInventory.getLineCode(), stagingInventory.getProductName(),
        stagingInventory.getGermplasmOwner(), true);
  }

  private boolean isHybridFinished(StagingInventory stagingInventory) {
    List finishedHybridGermplasmList = createHybridGermplasmDAO(stagingInventory)
        .getFinishedGermplasms(stagingInventory.getOrigin());
    return finishedHybridGermplasmList != null && finishedHybridGermplasmList.size() > 0;
  }
}