/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename: $Id: IIProcessorFactory.java,v 1.2 2009-06-05 14:07:47 ssnall Exp $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public final class IIProcessorFactory {
    private static Map processorMap = new HashMap();

    public static void populateMap() {
        processorMap.put(MaterialTypeConstants.COMMERCIAL_PRODUCT.toUpperCase(), CommercialIIProcessor.class);
        processorMap.put(MaterialTypeConstants.COMPETITOR_PRODUCT.toUpperCase(), CompetitorIIProcessor.class);
        processorMap.put(MaterialTypeConstants.FINISHED_LINES.toUpperCase(), FinishedIIProcessor.class);
        processorMap.put(MaterialTypeConstants.SEGPOP_LINES.toUpperCase(), SegpopIIProcessor.class);
        processorMap.put(MaterialTypeConstants.CODED_LINES.toUpperCase(), CodedIIProcessor.class);
        processorMap.put(MaterialTypeConstants.HYBRID_UNFINISHED_LINES.toUpperCase(), HybridUnfinishedProcessor.class);
        processorMap.put(MaterialTypeConstants.HYBRID_FINISHED_LINES.toUpperCase(), HybridFinishedProcessor.class);
        processorMap.put(MaterialTypeConstants.ICB_MALE.toUpperCase(), ICBMaleIIProcessor.class);
        processorMap.put(MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES.toUpperCase(), F1SegpopUnfinishedProcessor.class);
        processorMap.put(MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES.toUpperCase(), F1SegpopFinishedProcessor.class);
        processorMap
                .put(MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_UNFINISHED_LINES.toUpperCase(),
                        F1SegpopUnfinishedProcessor.class);
        processorMap.put(MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_FINISHED_LINES.toUpperCase(),
                F1SegpopFinishedProcessor.class);
    }

    public static IIProcessor createInventoryImportProcessor(StagingInventory stagingInventory)
            throws IllegalAccessException, InstantiationException {
        if (processorMap.isEmpty()) {
            populateMap();
        }

        IIProcessor IIProcessor;

        String materialType = stagingInventory.getInventoryHeader().getImportType().getAbbreviation().toUpperCase();
        if (MaterialTypeConstants.HYBRID_LINES.toUpperCase().equals(materialType) ||
                MaterialTypeConstants.SEGPOP_LINES.toUpperCase().equals(materialType)) {
            IIProcessor = createProcessorBasedOnStagingInventoryMaterialType(stagingInventory);
        } else {
            IIProcessor = (IIProcessor) ((Class) processorMap.get(materialType)).newInstance();
        }

        return IIProcessor;
    }

    public static IIProcessor createF1SegpopInventoryImportProcessor(String segpopSubType,
                                                                     MidasContext midasContext,
                                                                     StagingParentageHelper stagingParentageHelper) throws
            InstantiationException {
        IIProcessor IIProcessor;
        if (MaterialTypeConstants.F1_SEGPOP_FINISHED_LINES.equalsIgnoreCase(segpopSubType)) {
            IIProcessor = new F1SegpopFinishedProcessor(midasContext, stagingParentageHelper);
        } else if (MaterialTypeConstants.F1_SEGPOP_UNFINISHED_LINES.equalsIgnoreCase(segpopSubType)) {
            IIProcessor = new F1SegpopUnfinishedProcessor(midasContext, stagingParentageHelper);
        } else if (MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_FINISHED_LINES.equalsIgnoreCase(segpopSubType)) {
            IIProcessor = new F1SegpopFinishedProcessor(midasContext, stagingParentageHelper);
        } else if (MaterialTypeConstants.CLINEFUNCTION_MSC0_SEGPOP_UNFINISHED_LINES.equalsIgnoreCase(segpopSubType)) {
            IIProcessor = new F1SegpopUnfinishedProcessor(midasContext, stagingParentageHelper);
        } else {
            throw new InstantiationException("Unknown Segpop subtype - " + segpopSubType);
        }
        return IIProcessor;
    }

    private static IIProcessor createProcessorBasedOnStagingInventoryMaterialType(
            StagingInventory stagingInventory) throws
            IllegalAccessException, InstantiationException {
        String subMaterialType = stagingInventory.getImportType().getAbbreviation().toUpperCase();
        return (IIProcessor) ((Class) processorMap.get(subMaterialType)).newInstance();
    }
}
