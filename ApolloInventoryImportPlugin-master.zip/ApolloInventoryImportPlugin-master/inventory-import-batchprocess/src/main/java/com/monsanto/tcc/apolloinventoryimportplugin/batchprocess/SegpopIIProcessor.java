/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gp.GermplasmPicker;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.List;

/**
 * Filename:    $RCSfile: SegpopIIProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:	$Date: 2009-06-05 14:07:48 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class SegpopIIProcessor extends AbstractNonProductNonHybridIIProcessor {
    public MidasContext processInventory(InventoryContext inventoryContext) throws
            InventoryImportProcessorException {

        StagingInventory stagingInventory = inventoryContext.getStagingInventory();

        stagingParentageHelper = new StagingParentageHelper(stagingInventory.getStagingParentage());

        if (processMainRecord(inventoryContext)) {
            processSubRecord(stagingInventory, inventoryContext);
        }

        return midasContext;
    }

    private void processParentage(StagingInventory stagingInventory, StagingInventory[] parentInventory) {
        GeneticMaterial childGenMat = stagingParentageHelper.getInventoryGeneticMaterial(stagingInventory);

        GeneticMaterial parentGenMat;
        String parentalRole;
        for (int i = 0; i < parentInventory.length; i++) {
            StagingInventory inventory = parentInventory[i];
            parentGenMat = stagingParentageHelper.getInventoryGeneticMaterial(inventory);
            parentalRole = stagingParentageHelper.getInventoryParentalRole(inventory);
            Parentage parentage = createMidasParentage(childGenMat, parentGenMat, getParentalRole(parentalRole));
            addParentage(parentage);
        }
    }

    private boolean processSubRecord(StagingInventory stagingInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        boolean success = true;

        StagingInventory[] parentInventories = stagingParentageHelper.getParentInventories(stagingInventory);
        if (parentInventories == null) return success;

        GeneticMaterial subRecordGeneticMaterial;

        for (int i = 0; i < parentInventories.length; i++) {
            StagingInventory parentInventory = parentInventories[i];

            if (stagingParentageHelper.isInventoryRecurringParent(parentInventory)) {
                subRecordGeneticMaterial = stagingParentageHelper.getInventoryGeneticMaterial(parentInventory);
                if (subRecordGeneticMaterial == null) {
                    processRecurringInventory(parentInventory, stagingParentageHelper, inventoryContext);
                }
            } else {
                if (isF1OrMsc0Segpop(parentInventory)) {
                    processF1orMsc0Segpop(parentInventory, inventoryContext);
                } else if (processNonRecurringInventory(parentInventory, inventoryContext)) {
                    success = processSubRecord(parentInventory, inventoryContext);
                }
            }
        }

        if (success) {
            processParentage(stagingInventory, parentInventories);
        }

        return success;
    }

    private boolean processNonRecurringInventory(StagingInventory parentInventory, InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        boolean success;
        try {
            GeneticMaterial subRecordGeneticMaterial;
            Germplasm subRecordGermplasm;
            success = true;
            subRecordGeneticMaterial = fetchDuplicateGeneticMaterial(parentInventory);

            if (subRecordGeneticMaterial == null) {
                subRecordGermplasm = createMidasGermplasm(parentInventory);
                subRecordGeneticMaterial = createMidasGeneticMaterial(parentInventory, subRecordGermplasm);
                addGermplasm(subRecordGermplasm);
                addGeneticMaterial(subRecordGeneticMaterial);
                if (isUserSpecifiedSource(parentInventory.getUserSpecifiedSource())) {
                    addInventory(createMidasInventory(parentInventory, subRecordGeneticMaterial));
                }
                stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, subRecordGeneticMaterial);
                parentInventory.setImportStatus(getImportedStatus());
            } else {
                stagingParentageHelper.addInventoryGeneticMaterial(parentInventory, subRecordGeneticMaterial);
                if (parentageExists(subRecordGeneticMaterial)) {
                    inventoryContext.addMessage(parentInventory, "Parentage already exists for identified genetic_material - " +
                            subRecordGeneticMaterial.getGeneticMaterialId());
                    success = false;
                    parentInventory.setImportStatus(getUnprocessedStatus());
                } else {
                    parentInventory.setImportStatus(getImportedStatus());
                }
            }
        } catch (Exception e) {
            inventoryContext.addMessage(parentInventory, e);
            throw new InventoryImportProcessorException(
                    "Parent Inventory[" + parentInventory.getId() + "]: " + e.getMessage());
        }

        return success;
    }

    // Same as FinishedIIProcessor.processMainRecord except that Germplasm is not created
    private void processRecurringInventory(StagingInventory recurringParentInventory,
                                           StagingParentageHelper stagingParentageHelper,
                                           InventoryContext inventoryContext)
            throws InventoryImportProcessorException {
        try {
            GeneticMaterial geneticMaterial;

            boolean userSpecifiedSource = isUserSpecifiedSource(recurringParentInventory.getUserSpecifiedSource());

            geneticMaterial = getDuplicateFinishedGeneticMaterial(recurringParentInventory);
            if (geneticMaterial == null) {
                Germplasm germplasm = stagingParentageHelper.getInventoryGermplasm(recurringParentInventory);
                if (germplasm == null) {
                    germplasm = getDuplicateFinishedGermplasm(recurringParentInventory);
                    stagingParentageHelper.addInventoryGermplasm(recurringParentInventory, germplasm);
                }
                geneticMaterial = createMidasGeneticMaterial(recurringParentInventory, germplasm);
                addGeneticMaterial(geneticMaterial);
                if (userSpecifiedSource) {
                    addInventory(createMidasInventory(recurringParentInventory, geneticMaterial));
                }
                recurringParentInventory.setImportStatus(getImportedStatus());
            } else {
                inventoryContext.addMessage(recurringParentInventory,
                        "Duplicate genetic_material already exists - " + geneticMaterial.getGeneticMaterialId());
                recurringParentInventory.setImportStatus(getUnprocessedStatus());
            }

            stagingParentageHelper.addInventoryGeneticMaterial(recurringParentInventory, geneticMaterial);
        } catch (Exception e) {
            inventoryContext.addMessage(recurringParentInventory, e);
            throw new InventoryImportProcessorException(
                    "Recurring Parent Inventory[" + recurringParentInventory.getId() + "]: " + e.getMessage());
        }
    }

    private Germplasm getDuplicateFinishedGermplasm(StagingInventory recurringParentInventory) {
        String cropName = recurringParentInventory.getInventoryHeader().getCropName();
        String pedigreeName = recurringParentInventory.getPedigreeName();
        String lineCode = recurringParentInventory.getLineCode();
        String productName = recurringParentInventory.getProductName();
        Germplasm germplasm;

        ProductNameProductGermplasm productNameProductGermplasm = getProductNameProductGermplasm(cropName, lineCode,
                pedigreeName, productName);
        if (getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm) != null) {
            germplasm = getGermplasmFromProductNameProductGermplasm(productNameProductGermplasm);
        } else {
            germplasm = createFinishedGermplasmDAO(cropName, getLineFunctionCriteria(recurringParentInventory))
                    .getPrimaryGermplasm(lineCode);
        }
        return germplasm;
    }

    protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName,
                                                              LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGermplasmDAO(cropName, lineFunctionCriteria);
    }

    protected HybridGermplasmDAO createHybridGermplasmDAO(String cropName,
                                                          LineFunctionCriteria lineFunctionCriteria) {
        return new HybridGermplasmDAO(cropName, lineFunctionCriteria);
    }

    private GeneticMaterial getDuplicateFinishedGeneticMaterial(StagingInventory recurringParentInventory) {
        String cropName = recurringParentInventory.getInventoryHeader().getCropName();
        String source = recurringParentInventory.getSource();
        String lineCode = recurringParentInventory.getLineCode();
        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(recurringParentInventory);
        GeneticMaterial geneticMaterial = null;

        geneticMaterial = getGeneticMaterialFromProductName(cropName, lineFunctionCriteria, recurringParentInventory);
        if (geneticMaterial == null) {
            if (MaterialTypeConstants.FINISHED_LINES.equals(recurringParentInventory.getLineType())) {
                geneticMaterial = createFinishedGeneticMaterialDAO(cropName, lineFunctionCriteria)
                        .getPrimaryGeneticMaterial(lineCode, source);
            }
            if (MaterialTypeConstants.HYBRID_LINES.equals(recurringParentInventory.getLineType())) {
                geneticMaterial = createHybridGeneticMaterialDAO(recurringParentInventory.getSource(), cropName)
                        .getLowestGeneticMaterialMatchingPedigreeName(recurringParentInventory.getPedigreeName());
            }
        }

        return geneticMaterial;
    }

    protected FinishedGeneticMaterialDAO createFinishedGeneticMaterialDAO(String cropName,
                                                                          LineFunctionCriteria lineFunctionCriteria) {
        return new FinishedGeneticMaterialDAO(cropName, lineFunctionCriteria);
    }

    private boolean processMainRecord(InventoryContext inventoryContext) throws InventoryImportProcessorException {
        boolean parentageExists = false;
        boolean inventoryExists = false;
        GeneticMaterial mainRecordGeneticMaterial;
        Germplasm mainRecordGermplasm;
        Inventory inventory;

        StagingInventory stagingInventory = inventoryContext.getStagingInventory();

        inventory = fetchExistingArchivedMidasInventory(stagingInventory);
        if (inventory != null) {
            unarchiveMidasInventory(inventory, stagingInventory);
            mainRecordGeneticMaterial = inventory.getGeneticMaterial();
        } else {
            mainRecordGeneticMaterial = fetchDuplicateGeneticMaterial(stagingInventory);

            if (mainRecordGeneticMaterial == null) {
                mainRecordGermplasm = getGermplasm(stagingInventory);
                mainRecordGeneticMaterial = createMidasGeneticMaterial(stagingInventory, mainRecordGermplasm);
                addGermplasm(mainRecordGermplasm);
                addGeneticMaterial(mainRecordGeneticMaterial);
            } else {
                if (parentageExists(mainRecordGeneticMaterial)) {
                    parentageExists = true;
                    inventoryContext.addMessage(stagingInventory, "Parentage already exists for identified genetic_material - " +
                            mainRecordGeneticMaterial.getGeneticMaterialId());
                }

                if (inventoryExists(mainRecordGeneticMaterial)) {
                    inventoryExists = true;
                    inventoryContext.addMessage(stagingInventory, "Inventory already exists for identified genetic_material - " +
                            mainRecordGeneticMaterial.getGeneticMaterialId());
                }
            }
            if (!inventoryExists) {
                inventory = createMidasInventory(stagingInventory, mainRecordGeneticMaterial);
            }
        }

        if (inventory != null) {
            addInventory(inventory);
        }
        stagingParentageHelper.addInventoryGeneticMaterial(stagingInventory, mainRecordGeneticMaterial);

        if (parentageExists && inventoryExists) {
            stagingInventory.setImportStatus(getUnprocessedStatus());
        } else {
            stagingInventory.setImportStatus(getImportedStatus());
        }

        return !parentageExists;
    }

    private Germplasm getGermplasm(StagingInventory stagingInventory) {
        Germplasm mainRecordGermplasm = getExistingGermplasm(stagingInventory);
        if (mainRecordGermplasm == null) {
            mainRecordGermplasm = createMidasGermplasm(stagingInventory);
        }
        return mainRecordGermplasm;
    }

    private Germplasm getExistingGermplasm(StagingInventory stagingInventory) {
        GermplasmPicker germplasmPicker = createGermplasmPicker();
        Germplasm primaryGermplasm = germplasmPicker.getPrimaryGermplasm(stagingInventory, new ExistingGermplasmsByVegetativeStructureFetchStratergy());
        return primaryGermplasm;
    }

    private GermplasmPicker createGermplasmPicker() {
        return new GermplasmPicker();
    }

    private GeneticMaterial fetchDuplicateGeneticMaterial(StagingInventory stagingInventory) {
        String cropName = stagingInventory.getInventoryHeader().getCropName();
        String pedigreeName = stagingInventory.getPedigreeName();
        String source = stagingInventory.getSource();
        String lineType = stagingInventory.getLineType();

        return createGeneticMaterialDAO(cropName, getLineFunctionCriteria(stagingInventory))
                .getGeneticMaterial(pedigreeName, source, lineType);
    }

    protected GeneticMaterialDAO createGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        return new GeneticMaterialDAO(cropName, lineFunctionCriteria);
    }

    protected GermplasmListFetchStrategySegpop createGermplasmListFetchStrategySegpop() {
        return new GermplasmListFetchStrategySegpop();
    }

    private boolean inventoryExists(GeneticMaterial mainRecordGeneticMaterial) {
        Inventory[] inventories = createMidasInventoryDAO().getActiveUnarchivedInventory(mainRecordGeneticMaterial);
        return inventories != null && inventories.length > 0;
    }

    protected com.monsanto.tcc.apolloinventoryimportplugin.appdao.inventory.InventoryDAO createMidasInventoryDAO() {
        return new com.monsanto.tcc.apolloinventoryimportplugin.appdao.inventory.InventoryDAO();
    }

    private Inventory fetchExistingArchivedMidasInventory(StagingInventory stagingInventory) throws
            InventoryImportProcessorException {
        Inventory inventory;
        try {
            inventory = new MidasInventoryDAO().getArchivedInventory(stagingInventory,
                    createGermplasmListFetchStrategySegpop());
        } catch (Exception e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        }
        return inventory;
    }

    private boolean parentageExists(GeneticMaterial geneticMaterial) {
        List parentageList = new ParentageList().getParentage(geneticMaterial);
        return (parentageList != null) && parentageList.size() > 0;
    }
}