/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.parentage.StagingInventoryParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;

/**
 * Filename:    $RCSfile: StagingParentageHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:	$Date: 2008-05-30 16:57:16 $
 *
 * @author apatro
 * @version $Revision: 1.16 $
 */
public class StagingParentageHelper {
  private Map<String, GeneticMaterial> inventoryGenMatMap;
  private Map<String, Germplasm> inventoryGermplasmMap;
  private StagingInventoryParentage stagingInventoryParentage;

  public StagingParentageHelper(Set stagingParentageSet) {
    inventoryGenMatMap = new HashMap<String, GeneticMaterial>();
    inventoryGermplasmMap = new HashMap<String, Germplasm>();

    if (stagingParentageSet != null) stagingInventoryParentage = new StagingInventoryParentage(stagingParentageSet);
  }

  public boolean isInventoryRecurringParent(StagingInventory stagingInventory) {
    String lineage = stagingInventory.getLineage();
    String generation = stagingInventory.getGeneration();
    return !LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(stagingInventory.getLineFunction()) &&
        (isLineagePipeAndGenerationInbred(lineage, generation) ||
            isF1HyrbidAndDoesF1ParentExistWithParentageAndIsInventoryNotAParentOfTheF1Parent(stagingInventory));
  }

  private boolean isF1HyrbidAndDoesF1ParentExistWithParentageAndIsInventoryNotAParentOfTheF1Parent(StagingInventory stagingInventory) {
    String generation = stagingInventory.getGeneration();
    String lineType = stagingInventory.getLineType();
    return isGenerationF1AndLineTypeHybrid(generation, lineType) &&
        doesF1RecordWithParentageExist() &&
        !isInventoryAParentOfF1Parent(stagingInventory);
  }

  private boolean doesF1RecordWithParentageExist() {
    StagingInventory f1RecordWithParentage = stagingInventoryParentage.getF1RecordWithParentage();
    return f1RecordWithParentage != null && f1RecordWithParentage.getStagingParentage() != null;
  }

  private boolean isInventoryAParentOfF1Parent(StagingInventory stagingInventory) {
    boolean isInventoryAParentOfF1Parent = false;
    StagingInventory f1RecordWithParentage = stagingInventoryParentage.getF1RecordWithParentage();
    if(f1RecordWithParentage != null && f1RecordWithParentage.getStagingParentage() != null) {
      Set parentsOfF1Record = f1RecordWithParentage.getStagingParentage();
      for(Iterator iter = parentsOfF1Record.iterator(); iter.hasNext();) {
        StagingParentage stagingParentage = (StagingParentage) iter.next();
        StagingInventory parentOfF1 = stagingParentage.getParentInventory();
        if(parentOfF1.getId().equals(stagingInventory.getId())) {
          isInventoryAParentOfF1Parent = true;
          break;
        }
      }
    }
    return isInventoryAParentOfF1Parent;
  }

  private boolean isLineagePipeAndGenerationInbred(String lineage, String generation) {
    return "|".equals(lineage) && "INBRED".equalsIgnoreCase(generation);
  }

  private boolean isGenerationF1AndLineTypeHybrid(String generation, String lineType) {
    return "F1".equalsIgnoreCase(generation) && MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(lineType);
  }

  private String getInventoryKey(StagingInventory stagingInventory) {
    String key;

    if ((isInventoryRecurringParent(stagingInventory))) {
      key = stagingInventory.getSource() + " " + stagingInventory.getLineCode() + " " +
          stagingInventory.getLineFunction();
    } else if ("Finished".equalsIgnoreCase(stagingInventory.getLineType())) {
      key = stagingInventory.getSource() + " " + stagingInventory.getLineage() + " " + stagingInventory.getLineCode() +
          " " + stagingInventory.getLineFunction();
    } else { //Segpop or Coded or Hybriud
      key = stagingInventory.getId().toString();
    }

    return key;
  }

  private String getInventoryKeyForGermplasm(StagingInventory stagingInventory) {
    String key;

    if ((isInventoryRecurringParent(stagingInventory))) {
      key = stagingInventory.getSource() + " " + stagingInventory.getLineCode() + " " +
          stagingInventory.getLineFunction();
    } else if ("Finished".equalsIgnoreCase(stagingInventory.getLineType())) {
      key = stagingInventory.getLineCode() + " " + stagingInventory.getLineFunction();
    } else { //Segpop or Coded or Hybrid
      key = stagingInventory.getId().toString();
    }

    return key;
  }

  public StagingInventory[] getParentInventories(StagingInventory stagingInventory) {
    return (stagingInventoryParentage != null) ? stagingInventoryParentage.getDirectParents(stagingInventory) : null;
  }

  public GeneticMaterial getInventoryGeneticMaterial(StagingInventory recurringInventory) {
    return (GeneticMaterial) inventoryGenMatMap.get(getInventoryKey(recurringInventory));
  }

  public void addInventoryGeneticMaterial(StagingInventory stagingInventory, GeneticMaterial geneticMaterial) {
    String key = getInventoryKey(stagingInventory);
    if (!inventoryGenMatMap.containsKey(key)) {
      inventoryGenMatMap.put(key, geneticMaterial);
    }
  }

  public String getInventoryParentalRole(StagingInventory stagingInventory) {
    return (stagingInventoryParentage != null) ? stagingInventoryParentage.getParentalRole(stagingInventory) : null;
  }

  public void addInventoryGermplasm(StagingInventory stagingInventory, Germplasm germplasm) {
    String inventoryKey = getInventoryKeyForGermplasm(stagingInventory);
    if (!inventoryGermplasmMap.containsKey(inventoryKey)) {
      inventoryGermplasmMap.put(inventoryKey, germplasm);
    }
  }

  public Germplasm getInventoryGermplasm(StagingInventory stagingInventory) {
    return (Germplasm) inventoryGermplasmMap.get(getInventoryKeyForGermplasm(stagingInventory));
  }
}