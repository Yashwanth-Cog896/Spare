/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

/**
 * Filename:    $RCSfile: InventoryProcessor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: apatro $    	 On:	$Date: 2007-05-21 16:15:58 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public interface InventoryProcessor {
  void processInventory(InventoryContext context) throws InventoryImportProcessorException;
}