/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.batchprocess;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.GermplasmListFetchStrategyForCommercial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.gp.GermplasmPicker;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.midasinventory.MidasInventoryDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.CommercialHybrid;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.PrimaryGeneticMaterialNotFoundException;
import com.monsanto.tcc.apolloinventoryimportplugin.batchprocess.commercial.PrimaryGermplasmNotFoundException;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.ParentalRoleConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.SourceStringConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.inventorymaterial.commercialproducts.CommercialStagingInventory;

/**
 * Filename: $Id: CommercialIIProcessor.java,v 1.2 2009-06-05 14:07:48 ssnall Exp $
 *
 * @author APATRO
 * @version $Revision: 1.2 $
 */
public class CommercialIIProcessor extends AbstractStagingInventoryProcessor {
    private static final String HYBRID_LINES = MaterialTypeConstants.HYBRID_LINES;
    private static final String FINISHED_LINES = MaterialTypeConstants.FINISHED_LINES;
    private static final String MALE_PARENTAL_ROLE = ParentalRoleConstants.MALE_PARENTAL_ROLE;
    private static final String FEMALE_PARENTAL_ROLE = ParentalRoleConstants.FEMALE_PARENTAL_ROLE;
    private static final String F1_GENERATION = "F1";
    private static final String PIPE_LINEAGE = "|";
    private static final String INBRED_GENERATION = "INBRED";

    public MidasContext processInventory(InventoryContext inventoryContext) throws InventoryImportProcessorException {
        // Check for matching archived inventory - if found activate it
        StagingInventory stagingInventory = inventoryContext.getStagingInventory();
        Inventory inventory = lookUpMatchingArchivedMidasInventory(stagingInventory);

        if (inventory != null) {
            unarchiveMidasInventory(inventory, stagingInventory);
        } else { // Create new inventory record along with GeneticMaterial & Parentage
            GeneticMaterial genMatAssociatedWithNewInventory = lookUpMatchingGeneticMaterial(stagingInventory);
            if (genMatAssociatedWithNewInventory == null) {
                genMatAssociatedWithNewInventory = createGeneticMaterial(stagingInventory);
                setAttributesBasedOnLineType(genMatAssociatedWithNewInventory, stagingInventory.getLineType());
                createParentageAndParentGeneticMaterialBasedOnLineType(stagingInventory, genMatAssociatedWithNewInventory);
            }
            inventory = createMidasInventory(stagingInventory, genMatAssociatedWithNewInventory);
        }
        addInventory(inventory);
        stagingInventory.setImportStatus(getImportedStatus());

        return midasContext;
    }

    private void createParentageAndParentGeneticMaterialBasedOnLineType(StagingInventory stagingInventory,
                                                                        GeneticMaterial genMatAssociatedWithNewInventory) throws
            InventoryImportProcessorException {
        if (HYBRID_LINES.equalsIgnoreCase(stagingInventory.getLineType())) {
            createParentageAlongWithParentGeneticMaterial(stagingInventory, genMatAssociatedWithNewInventory);
        }
    }

    private void createParentageAlongWithParentGeneticMaterial(StagingInventory stagingInventory,
                                                               GeneticMaterial geneticMaterial)
            throws InventoryImportProcessorException {
        try {
            createFemaleGeneticMaterialAndParentage(stagingInventory, geneticMaterial);
            createMaleGeneticMaterialAndParentage(stagingInventory, geneticMaterial);
        } catch (PrimaryGermplasmNotFoundException e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        } catch (PrimaryGeneticMaterialNotFoundException e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        }
    }

    private void createFemaleGeneticMaterialAndParentage(StagingInventory stagingInventory, GeneticMaterial geneticMaterial) throws
            PrimaryGeneticMaterialNotFoundException, PrimaryGermplasmNotFoundException {
        GeneticMaterial femaleParentGeneticMaterial = new CommercialHybrid(stagingInventory)
                .getGeneticMaterialForSourceOfFemaleParent();
        createGeneticMaterialAndParentage(stagingInventory, geneticMaterial, femaleParentGeneticMaterial, FEMALE_PARENTAL_ROLE);
    }

    private void createMaleGeneticMaterialAndParentage(StagingInventory stagingInventory, GeneticMaterial geneticMaterial) throws
            PrimaryGeneticMaterialNotFoundException, PrimaryGermplasmNotFoundException {
        GeneticMaterial maleParentGeneticMaterial = new CommercialHybrid(stagingInventory)
                .getGeneticMaterialForSourceOfMaleParent();
        createGeneticMaterialAndParentage(stagingInventory, geneticMaterial, maleParentGeneticMaterial, MALE_PARENTAL_ROLE);
    }

    private void createGeneticMaterialAndParentage(StagingInventory stagingInventory, GeneticMaterial geneticMaterial,
                                                   GeneticMaterial parentGeneticMaterial, String parentalRole) throws
            PrimaryGeneticMaterialNotFoundException, PrimaryGermplasmNotFoundException {
        if (parentGeneticMaterial != null) {
            addParentage(
                    createMidasParentage(geneticMaterial, parentGeneticMaterial, getParentalRole(parentalRole)));
        } else {
            GeneticMaterial newParentMaleGeneticMaterial = createParentGeneticMaterial(stagingInventory, parentalRole);
            addGeneticMaterial(newParentMaleGeneticMaterial);
            addParentage(
                    createMidasParentage(geneticMaterial, newParentMaleGeneticMaterial, getParentalRole(parentalRole)));
            createParentInventoryIfParentalSourceWasNotProvided(stagingInventory, newParentMaleGeneticMaterial);
        }
    }

    private void createParentInventoryIfParentalSourceWasNotProvided(StagingInventory stagingInventory,
                                                                     GeneticMaterial parentGeneticMaterial) {
        if (!SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE.equalsIgnoreCase(parentGeneticMaterial.getSourceStr())) {
            Inventory inventory = createMidasInventory(stagingInventory, parentGeneticMaterial);
            addInventory(inventory);
        }
    }

    private GeneticMaterial createParentGeneticMaterial(StagingInventory stagingInventory, String parentalRole)
            throws PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
        Germplasm parentGermplasm = getGermplasmOfParentOfPrimaryGeneticMaterial(stagingInventory, parentalRole);

        GeneticMaterial parentGeneticMaterial = createMidasGeneticMaterial(stagingInventory, parentGermplasm);
        // Override source, lineage, generation
        String source = new CommercialStagingInventory(stagingInventory).getParentSource(parentalRole);
        parentGeneticMaterial.setSourceStr(source);
        String lineTypeRefId = parentGermplasm.getLineType().getLineTypeRefId();
        setAttributesBasedOnLineType(parentGeneticMaterial, lineTypeRefId);
        return parentGeneticMaterial;
    }

    private void setAttributesBasedOnLineType(GeneticMaterial parentGeneticMaterial, String lineTypeRefId) {
        if (HYBRID_LINES.equalsIgnoreCase(lineTypeRefId)) {
            parentGeneticMaterial.setLineage(null);
            parentGeneticMaterial.setGeneration(F1_GENERATION);
        } else if (FINISHED_LINES.equalsIgnoreCase(lineTypeRefId)) {
            parentGeneticMaterial.setLineage(PIPE_LINEAGE);
            parentGeneticMaterial.setGeneration(INBRED_GENERATION);
        }
        setIsAutogenToTrueForManufacturingSource(parentGeneticMaterial);
    }

    private GeneticMaterial createGeneticMaterial(StagingInventory stagingInventory)
            throws InventoryImportProcessorException {
        GeneticMaterial geneticMaterial = null;
        try {
            Germplasm germplasm = new GermplasmPicker()
                    .getPrimaryGermplasm(stagingInventory, createGermplasmListFetchStrategy());
            geneticMaterial = createMidasGeneticMaterial(stagingInventory, germplasm);
            addGeneticMaterial(geneticMaterial);
        } catch (Exception e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        }
        return geneticMaterial;
    }

    private GermplasmListFetchStrategyForCommercial createGermplasmListFetchStrategy() {
        return new GermplasmListFetchStrategyForCommercial();
    }

    private GeneticMaterial lookUpMatchingGeneticMaterial(StagingInventory stagingInventory) {
        return new MidasInventoryDAO().getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(stagingInventory,
                createGermplasmListFetchStrategy());
    }

    private Inventory lookUpMatchingArchivedMidasInventory(StagingInventory stagingInventory) throws
            InventoryImportProcessorException {
        Inventory inventory = null;
        try {
            inventory = new MidasInventoryDAO().getArchivedInventory(stagingInventory, createGermplasmListFetchStrategy());
        } catch (Exception e) {
            throw new InventoryImportProcessorException(e.getMessage(), e);
        }
        return inventory;
    }

    private Germplasm getGermplasmOfParentOfPrimaryGeneticMaterial(StagingInventory stagingInventory,
                                                                   String parentalRole) throws
            PrimaryGermplasmNotFoundException, PrimaryGeneticMaterialNotFoundException {
        Germplasm parentGermplasm = null;
        if (MALE_PARENTAL_ROLE.equalsIgnoreCase(parentalRole)) {
            parentGermplasm = new CommercialHybrid(stagingInventory).getGermplasmOfMaleParentOfPrimaryGeneticMaterial();
        } else if (FEMALE_PARENTAL_ROLE.equalsIgnoreCase(parentalRole)) {
            parentGermplasm = new CommercialHybrid(stagingInventory).getGermplasmOfFemaleParentOfPrimaryGeneticMaterial();
        }
        return parentGermplasm;
    }

    private void setIsAutogenToTrueForManufacturingSource(GeneticMaterial geneticMaterial) {
        if (SourceStringConstants.INVENTORY_IMPORT_PRODUCT_SOURCE.equalsIgnoreCase(geneticMaterial.getSourceStr())) {
            geneticMaterial.setIsAutogen("T");
        }
    }
}
