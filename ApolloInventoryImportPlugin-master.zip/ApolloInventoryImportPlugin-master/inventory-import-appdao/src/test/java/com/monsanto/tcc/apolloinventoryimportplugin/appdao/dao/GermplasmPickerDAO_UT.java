/*
 GermplasmPickerDAO_UT was created on Feb 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmPickerDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: srkarna $    	 On:	$Date: 2008-03-17 21:55:23 $
 *
 * @author SRKARNA
 * @version $Revision: 1.5 $
 */
public class GermplasmPickerDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;
    private static final String CROP_NAME = "Corn";
    private static final String FINISHED_ORIGIN = "GP-PICK1/GP-PICK2";
    private static final String FINISHED_BR_PROG_REF_ID = "17";
    private Germplasm[] gpsWithEqualNumberOfGms = null;
    private Germplasm[] gpsWithDifferentNumberOfGms = null;
    private Germplasm[] gpsWithNoGms = null;

    public GermplasmPickerDAO_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);

        gpsWithEqualNumberOfGms = new Germplasm[3];
        gpsWithDifferentNumberOfGms = new Germplasm[5];
        gpsWithNoGms = new Germplasm[2];

        gpsWithEqualNumberOfGms[1] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC2",
                FINISHED_ORIGIN, "GP-PICK-LC2", FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[1], "GP-PICK-SOURCE21", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[1], "GP-PICK-SOURCE22", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[1], "GP-PICK-SOURCE23", "|", "INBRED");

        gpsWithEqualNumberOfGms[0] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC1",
                FINISHED_ORIGIN, "GP-PICK-LC1", FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[0], "GP-PICK-SOURCE11", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[0], "GP-PICK-SOURCE12", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[0], "GP-PICK-SOURCE13", "|", "INBRED");

        gpsWithEqualNumberOfGms[2] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC3",
                FINISHED_ORIGIN, "GP-PICK-LC3", FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[2], "GP-PICK-SOURCE31", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[2], "GP-PICK-SOURCE32", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithEqualNumberOfGms[2], "GP-PICK-SOURCE33", "|", "INBRED");

        gpsWithDifferentNumberOfGms[0] = gpsWithEqualNumberOfGms[0];
        gpsWithDifferentNumberOfGms[2] = gpsWithEqualNumberOfGms[2];
        gpsWithDifferentNumberOfGms[1] = gpsWithEqualNumberOfGms[1];

        gpsWithDifferentNumberOfGms[4] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC5",
                FINISHED_ORIGIN, "GP-PICK-LC5", FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[4], "GP-PICK-SOURCE51", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[4], "GP-PICK-SOURCE52", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[4], "GP-PICK-SOURCE53", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[4], "GP-PICK-SOURCE54", "|", "INBRED");

        gpsWithDifferentNumberOfGms[3] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC4",
                FINISHED_ORIGIN, "GP-PICK-LC4", FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[3], "GP-PICK-SOURCE41", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[3], "GP-PICK-SOURCE42", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[3], "GP-PICK-SOURCE43", "|", "INBRED");
        testHelper.createGeneticMaterial(gpsWithDifferentNumberOfGms[3], "GP-PICK-SOURCE44", "|", "INBRED");

        gpsWithNoGms[1] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC92",
                FINISHED_ORIGIN, "GP-PICK-LC92", FINISHED_BR_PROG_REF_ID, CROP_NAME);

        gpsWithNoGms[0] = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GP-PICK-LC91",
                FINISHED_ORIGIN, "GP-PICK-LC91", FINISHED_BR_PROG_REF_ID, CROP_NAME);
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetLowestGermplasmIdAssociatedWithHighestGeneticMaterials_DifferentGpsWithEqualNumberOfGms() throws
            Exception {
        GermplasmPickerDAO germplasmPickerDAO = new GermplasmPickerDAO(gpsWithEqualNumberOfGms);
        Germplasm germplasm = germplasmPickerDAO.getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();

        assertNotNull(germplasm);
        Long[] gpIds = new Long[]{gpsWithEqualNumberOfGms[0].getId(),
                gpsWithEqualNumberOfGms[1].getId(),
                gpsWithEqualNumberOfGms[2].getId()};
        Arrays.sort(gpIds);
        assertEquals(germplasm.getId(), gpIds[0]);
        assertTrue(germplasm.getId().compareTo(gpIds[1]) < 0);
        assertTrue(germplasm.getId().compareTo(gpIds[2]) < 0);
    }

    public void testGetLowestGermplasmIdAssociatedWithHighestGeneticMaterials_DifferentGpsWithDiffNumberOfGms() throws
            Exception {
        GermplasmPickerDAO germplasmPickerDAO = new GermplasmPickerDAO(gpsWithDifferentNumberOfGms);
        Germplasm germplasm = germplasmPickerDAO.getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();

        assertNotNull(germplasm);
        Long[] gpIds = new Long[]{
                gpsWithDifferentNumberOfGms[3].getId(),
                gpsWithDifferentNumberOfGms[4].getId()
        };
        Arrays.sort(gpIds);
        assertEquals(germplasm.getId(), gpIds[0]);
        assertTrue(germplasm.getId().compareTo(gpIds[1]) < 0);
    }

    public void testGetLowestGermplasmIdAssociatedWithHighestGeneticMaterials_DifferentGpsWithNoGms_ReturnNullGermplasm() throws
            Exception {
        GermplasmPickerDAO germplasmPickerDAO = new GermplasmPickerDAO(gpsWithNoGms);
        Germplasm germplasm = germplasmPickerDAO.getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();

        assertNull(germplasm);
    }

    public void testGermplasmsRequired() throws Exception {
        try {
            new GermplasmPickerDAO(null);
            fail("expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected path
        }

        try {
            new GermplasmPickerDAO(new Germplasm[0]);
            fail("expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // expected path
        }
    }

    public void testGetLowestGermplasmIdAssociatedWithHighestGeneticMaterials_MoreThan1000Germplasms() {
        Germplasm[] germplasms = get1000Germplasms();
        GermplasmPickerDAO germplasmPickerDAO = new GermplasmPickerDAO(germplasms);
        Germplasm germplasm = germplasmPickerDAO.getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();

        assertNotNull(germplasm);
    }

    private Germplasm[] get1000Germplasms() {
        List<Germplasm> germplasmList = new ArrayList<Germplasm>();
        germplasmList.addAll(Arrays.asList(gpsWithNoGms));
        for (int i = 0; i < 1000; i++) {
            Germplasm g = new Germplasm();
            g.setId(new Long(-i * 3));
            germplasmList.add(g);
        }
        return (Germplasm[]) germplasmList.toArray(new Germplasm[0]);
    }
}