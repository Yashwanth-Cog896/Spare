/*
 HybridGermplasmGeneticMaterialDAO_UT was created on May 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.BrProg;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridGermplasmGeneticMaterialDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    	 On:	$Date: 2008-10-03 16:18:31 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class HybridGermplasmGeneticMaterialDAO_UT extends TestIIContextConfigurer {
    private static final String MATCHING_ORIGIN = "HGGM+DAO++UT";
    private static final String MATCHING_SOURCE = "My Source";
    private static final String MATCHING_LINE_FUNCTION_S = "S";
    private static final String MATCHING_LINE_FUNCTION_F = "F";
    private static final String NO_MATCHING_SOURCE = "Some Source";
    private static final String PEDIGREE = "DAT";
    private static final String LINE_CODE = "UTL";
    private static final String LINE_TYPE = MaterialTypeConstants.HYBRID_LINES;
    private static final String CROP_NAME = "Corn";
    private static final String IS_DELETED_TRUE = "T";
    private static final String IS_DELETED_FALSE = "F";
    private static final String IS_FIN_OR_FIN_CHILD_FALSE = "F";
    private static final String IS_FIN_OR_FIN_CHILD_TRUE = "T";
    private TestHelper testHelper;
    private String brProgRefId;

    public HybridGermplasmGeneticMaterialDAO_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        testHelper = new TestHelper();
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
        BrProg brProg = testHelper.getActiveBrProg(CROP_NAME);
        brProgRefId = brProg.getBrProgRefId();
    }

    protected void tearDown() throws Exception {
        testHelper.purgeMidasObjects();
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        if (session != null && session.isOpen()) {
            Transaction transaction = session.getTransaction();
            if (transaction != null && transaction.isActive() && !transaction.wasRolledBack()) {
                transaction.rollback();
            }
        }
        super.tearDown();
    }

    public void testGetAllGeneticMaterialsMatchingSource() throws Exception {
        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefId,
                CROP_NAME, IS_DELETED_TRUE, IS_FIN_OR_FIN_CHILD_FALSE);
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");

        HybridGermplasmGeneticMaterialDAO dao = new HybridGermplasmGeneticMaterialDAO(CROP_NAME, MATCHING_ORIGIN);
        List geneticMaterials = dao.getAllGeneticMaterialsMatchingSourceAndLineFunction(MATCHING_SOURCE);

        assertNotNull(geneticMaterials);
        assertEquals(6, geneticMaterials.size());
    }

    public void testGetAllGeneticMaterials_NoMatchingSource() throws Exception {
        testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefId, CROP_NAME, IS_DELETED_TRUE,
                IS_FIN_OR_FIN_CHILD_FALSE);

        HybridGermplasmGeneticMaterialDAO dao = new HybridGermplasmGeneticMaterialDAO(CROP_NAME, MATCHING_ORIGIN);
        List geneticMaterials = dao.getAllGeneticMaterialsMatchingSourceAndLineFunction(NO_MATCHING_SOURCE);

        assertNotNull(geneticMaterials);
        assertEquals(0, geneticMaterials.size());
    }

    public void testGetLowestGeneticMaterialMatchingSourceForUnfinishedHybrid() throws Exception {
        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE + "a", brProgRefId,
                CROP_NAME, IS_DELETED_TRUE, IS_FIN_OR_FIN_CHILD_TRUE);
        GeneticMaterial expectedGeneticMaterial = testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");

        HybridGermplasmGeneticMaterialDAO dao = new HybridGermplasmGeneticMaterialDAO(CROP_NAME, MATCHING_ORIGIN);
        GeneticMaterial actualGeneticMaterial = dao
                .getLowestGeneticMaterialMatchingSourceForUnifishedHybrid(MATCHING_SOURCE, brProgRefId);

        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial, actualGeneticMaterial);
    }

    // todo: gets for germplams having line function also, is this correct?
    public void testGetUnfinishedActiveGeneticMaterialsMatchingSource() throws Exception {
        Germplasm[] germplasms = new Germplasm[6];

        germplasms[0] = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefId,
                CROP_NAME, IS_DELETED_TRUE, IS_FIN_OR_FIN_CHILD_FALSE);
        testHelper.createGeneticMaterial(germplasms[0], MATCHING_SOURCE, null, "|");

        germplasms[1] = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefId,
                CROP_NAME, IS_DELETED_FALSE, IS_FIN_OR_FIN_CHILD_FALSE);
        testHelper.createGeneticMaterial(germplasms[1], MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasms[1], MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasms[1], MATCHING_SOURCE, null, "|");

        germplasms[2] = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE + "a", brProgRefId,
                CROP_NAME, IS_DELETED_FALSE, IS_FIN_OR_FIN_CHILD_FALSE);
        testHelper.createGeneticMaterial(germplasms[2], MATCHING_SOURCE, null, "|");

        germplasms[3] = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE + "a", brProgRefId,
                CROP_NAME, IS_DELETED_FALSE, IS_FIN_OR_FIN_CHILD_TRUE);
        testHelper.createGeneticMaterial(germplasms[3], MATCHING_SOURCE, null, "|");

        germplasms[4] = testHelper.createGermplasm(LINE_TYPE, null, MATCHING_ORIGIN, MATCHING_ORIGIN, brProgRefId,
                CROP_NAME, IS_DELETED_FALSE, IS_FIN_OR_FIN_CHILD_TRUE, MATCHING_LINE_FUNCTION_S, null);
        testHelper.createGeneticMaterial(germplasms[4], MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasms[4], MATCHING_SOURCE, null, "|");

        germplasms[5] = testHelper.createGermplasm(LINE_TYPE, null, MATCHING_ORIGIN, MATCHING_ORIGIN, brProgRefId,
                CROP_NAME, IS_DELETED_FALSE, IS_FIN_OR_FIN_CHILD_TRUE, MATCHING_LINE_FUNCTION_F, null);

        HybridGermplasmGeneticMaterialDAO dao = new HybridGermplasmGeneticMaterialDAO(CROP_NAME, MATCHING_ORIGIN);
        List geneticMaterial = dao
                .getUnfinishedGeneticMaterialsMatchingSourceOrderdByIsFinishedOrFinishedChild(MATCHING_SOURCE);

        assertNotNull(geneticMaterial);
        assertEquals(7, geneticMaterial.size());
        assertEquals(IS_FIN_OR_FIN_CHILD_TRUE,
                ((GeneticMaterial) geneticMaterial.get(0)).getGermplasm().getIsFinishedOrFinishedChild());
        assertEquals(IS_FIN_OR_FIN_CHILD_TRUE,
                ((GeneticMaterial) geneticMaterial.get(1)).getGermplasm().getIsFinishedOrFinishedChild());
        assertEquals(IS_FIN_OR_FIN_CHILD_TRUE,
                ((GeneticMaterial) geneticMaterial.get(2)).getGermplasm().getIsFinishedOrFinishedChild());
        assertEquals(IS_FIN_OR_FIN_CHILD_FALSE,
                ((GeneticMaterial) geneticMaterial.get(3)).getGermplasm().getIsFinishedOrFinishedChild());
        assertEquals(IS_FIN_OR_FIN_CHILD_FALSE,
                ((GeneticMaterial) geneticMaterial.get(4)).getGermplasm().getIsFinishedOrFinishedChild());
        assertEquals(IS_FIN_OR_FIN_CHILD_FALSE,
                ((GeneticMaterial) geneticMaterial.get(5)).getGermplasm().getIsFinishedOrFinishedChild());
        assertEquals(IS_FIN_OR_FIN_CHILD_FALSE,
                ((GeneticMaterial) geneticMaterial.get(6)).getGermplasm().getIsFinishedOrFinishedChild());
    }

    public void testGetAllGeneticMaterialsMatchingSourceAndLineFunction() throws Exception {
        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefId,
                CROP_NAME, IS_DELETED_TRUE, IS_FIN_OR_FIN_CHILD_FALSE, MATCHING_LINE_FUNCTION_S, null);
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");
        testHelper.createGeneticMaterial(germplasm, MATCHING_SOURCE, null, "|");

        HybridGermplasmGeneticMaterialDAO dao = new HybridGermplasmGeneticMaterialDAO(CROP_NAME, MATCHING_ORIGIN,
                MATCHING_LINE_FUNCTION_S);
        List geneticMaterials = dao.getAllGeneticMaterialsMatchingSourceAndLineFunction(MATCHING_SOURCE);

        assertNotNull(geneticMaterials);
        assertEquals(2, geneticMaterials.size());
    }
}