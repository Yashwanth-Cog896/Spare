/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.Properties;

/**
 * Filename:    $RCSfile: MidasConnectionFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: AAGOSW $
 * On:	$Date: 2008-07-08 15:40:56 $
 *
 * @author skumar5
 * @version $Revision: 1.2 $
 */
@Deprecated
public class MidasConnectionFactory extends ConnectionFactory {
    private static final String MIDASDATAPOS_HIBERNATE_URI = "com/monsanto/tcc/apolloinventoryimportplugin/appdao/hibernate/hibernateMC.cfg.xml";

    private static final SessionFactory sessionFactoryForMidasDataPos;

    static {
        try {
            String env = EnvironmentHelper.getFunction();
            String decryptedSIPassword = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV",
                    "inventoryimport", "CipherValueSI.Base64", "KeyValueSI.hex");

            Configuration mcConfiguration = new Configuration().configure(MIDASDATAPOS_HIBERNATE_URI);
            Properties mcEnvProperties = mcConfiguration.getProperties();
            mcEnvProperties
                    .setProperty("hibernate.connection.url", mcEnvProperties.getProperty("connection.url." + env.trim()));
            mcEnvProperties.setProperty("hibernate.connection.password", decryptedSIPassword);
            mcEnvProperties.setProperty("show_sql", env.equalsIgnoreCase("win") ? "true" : "false");
            mcEnvProperties.setProperty("hibernate.show_sql", env.equalsIgnoreCase("win") ? "true" : "false");
            mcConfiguration.setProperties(mcEnvProperties);
            sessionFactoryForMidasDataPos = mcConfiguration.buildSessionFactory();
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactoryForMidasDataPos() {
        return sessionFactoryForMidasDataPos;
    }

    protected String getInstanceName() {
        String env = EnvironmentHelper.getFunction();
        Configuration mcConfiguration = new Configuration().configure(MIDASDATAPOS_HIBERNATE_URI);
        Properties mcEnvProperties = mcConfiguration.getProperties();
        String url = mcEnvProperties.getProperty("connection.url." + env.trim());
        return url.split(":")[url.split(":").length - 1].trim();
    }

    protected String getDatabaseUserName() {
        Configuration mcConfiguration = new Configuration().configure(MIDASDATAPOS_HIBERNATE_URI);
        Properties mcEnvProperties = mcConfiguration.getProperties();
        return mcEnvProperties.getProperty("connection.username");
    }

    protected String getDatabasePassword() {
        String decryptedMCPassword;
        try {
            decryptedMCPassword = EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "inventoryimport",
                    "CipherValueSI.Base64", "KeyValueSI.hex");
        } catch (EncryptorException ex) {
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
        return decryptedMCPassword;
    }
}