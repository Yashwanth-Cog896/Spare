package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.CompetitorProductNameDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.ProductGermPlasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.ProductNameDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 2:51:47 PM To change this template use File |
 * Settings | File Templates.
 */
public class CompetitorParentMatchingOriginStrategy_UT extends TestIIContextConfigurer {
    private List productGermplasmList;
    private List productNameList;

    public void testFetchParentProductGermplasms_NullProductGermplasmList()
            throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ");
        this.productGermplasmList = new ArrayList();
        List productGermplasms = strategy.fetchParentProductGermplasms("XYZ");
        assertEquals(0, productGermplasms.size());
    }

    public void testFetchParentProductGermplasms_HasZeroProductGermplasmList()
            throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ");
        List productNameProductGermplasms = strategy.fetchParentProductGermplasms("XYZ");
        assertEquals(0, productNameProductGermplasms.size());
    }

    public void testFetchParentProductGermplasms_HasOneMatchingProductGermplasmAndZeroMatchingProductName()
            throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ");
        ProductGermplasm productGermplasm1 = new ProductGermplasm();
        Product product1 = new Product();
        product1.setId(23L);
        Product product2 = new Product();
        product2.setId(25L);
        productGermplasm1.setProduct(product1);
        productGermplasmList = new ArrayList();
        productGermplasmList.add(productGermplasm1);
        ProductName productName1 = new ProductName();
        productName1.setProduct(product2);
        productNameList = new ArrayList();
        productNameList.add(productName1);
        List productNameProductGermplasm = strategy.fetchParentProductGermplasms("XYZ");
        assertEquals(0, productNameProductGermplasm.size());
    }

    public void testFetchParentProductGermplasms_HasOneMatchingProductGermplasmAndOneMatchingProductName()
            throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ");
        ProductGermplasm productGermplasm1 = new ProductGermplasm();
        Product product1 = new Product();
        product1.setId(23L);
        Product product2 = new Product();
        product2.setId(23L);
        productGermplasm1.setProduct(product1);
        productGermplasmList = new ArrayList();
        productGermplasmList.add(productGermplasm1);
        ProductName productName1 = new ProductName();
        productName1.setProduct(product2);
        productNameList = new ArrayList();
        productNameList.add(productName1);
        List productNameProductGermplasm = strategy.fetchParentProductGermplasms("XYZ");
        assertEquals(1, productNameProductGermplasm.size());
    }

    public void testFetchParentProductGermplasms_HasOneMatchingProductGermplasmAndTwoMatchingProductName()
            throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ");
        ProductGermplasm productGermplasm1 = new ProductGermplasm();
        Product product1 = new Product();
        product1.setId(23L);
        Product product2 = new Product();
        product2.setId(23L);
        productGermplasm1.setProduct(product1);
        productGermplasmList = new ArrayList();
        productGermplasmList.add(productGermplasm1);
        ProductName productName1 = new ProductName();
        productName1.setProduct(product1);
        ProductName productName2 = new ProductName();
        productName2.setProduct(product2);
        productNameList = new ArrayList();
        productNameList.add(productName1);
        productNameList.add(productName2);
        List productNameProductGermplasm = strategy.fetchParentProductGermplasms("XYZ");
        assertEquals(1, productNameProductGermplasm.size());
    }


    public void testFetchParentProductGermplasms_HasTwoMatchingProductGermplasmAndTwoMatchingProductName()
            throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ");
        ProductGermplasm productGermplasm1 = new ProductGermplasm();
        Product product1 = new Product();
        product1.setId(23L);
        Product product2 = new Product();
        product2.setId(23L);
        productGermplasm1.setProduct(product1);
        ProductGermplasm productGermplasm2 = new ProductGermplasm();
        productGermplasm2.setProduct(product2);
        productGermplasmList = new ArrayList();
        productGermplasmList.add(productGermplasm1);
        productGermplasmList.add(productGermplasm2);
        ProductName productName1 = new ProductName();
        productName1.setProduct(product1);
        ProductName productName2 = new ProductName();
        productName2.setProduct(product2);
        productNameList = new ArrayList();
        productNameList.add(productName1);
        List productNameProductGermplasm = strategy.fetchParentProductGermplasms("XYZ");
        assertEquals(2, productNameProductGermplasm.size());
    }

    public void testCheckIfParentsExists_Success() throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ") {
            public List fetchParentProductGermplasms(String originComponent) {
                return Collections.nCopies(2, 5);
            }
        };
        assertTrue(strategy.checkIfParentsExists("XYZ"));
    }

    public void testCheckIfParentsExists_Fail() throws Exception {
        CompetitorParentMatchingOriginStrategy strategy = new MockCompetitorParentMatchingOriginStrategy(
                "XYZ") {
            public List fetchParentProductGermplasms(String originComponent) {
                return new ArrayList();
            }
        };
        assertFalse(strategy.checkIfParentsExists("XYZ"));
    }

    private class MockCompetitorParentMatchingOriginStrategy extends
            CompetitorParentMatchingOriginStrategy {
        private MockCompetitorParentMatchingOriginStrategy(String cropName) {
            super(cropName);
        }

        protected ProductGermPlasmDAO createProductGermPlasmDAO() {
            return new MockProductGermPlasmDAO("XYZ");
        }

        protected ProductNameDAO createProductNameDAO() {
            return new MockProductNameDAO("XYZ");
        }
    }

    private class MockProductGermPlasmDAO extends ProductGermPlasmDAO {
        private MockProductGermPlasmDAO(String cropName) {
            super(cropName, null);
        }

        public List getProductGermplasmListMatchingOrigin(String origin) {
            return CompetitorParentMatchingOriginStrategy_UT.this.productGermplasmList;
        }
    }

    private class MockProductNameDAO extends CompetitorProductNameDAO {
        private MockProductNameDAO(String cropName) {
            super(cropName);
        }

        public List getProductListMatchingProducts(List list) {
            return CompetitorParentMatchingOriginStrategy_UT.this.productNameList;
        }
    }
}
