package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class SharedParentageBrProg_UT {
    SharedParentageBrProg testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new SharedParentageBrProg();
    }

    @Test
    public void testSettersAndGetters() throws Exception {
        BrProg brprog = new BrProg();
        brprog.setBrProgId(-98l);
        Parentage parentage = new Parentage();
        parentage.setParentageId(-76l);
        SharedParentageBrProgPk id = new SharedParentageBrProgPk(parentage, brprog);

        testObject.setId(id);

        assertEquals(id, testObject.getId());
    }
}
