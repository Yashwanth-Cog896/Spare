package com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty.select;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

public class GermplasmRoyaltyCriteriaFactory_UT {
    @Mock
    private Criteria mockCriteria;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void tesGermplasmRoyaltyCriteriaFactory() {
        when(mockCriteria.add(isA(Criterion.class))).thenReturn(mockCriteria);
        GermplasmRoyaltyCriteriaFactory.addActiveGermplasmRoyaltyCriteria("fakealias", mockCriteria);
        assertNotNull(mockCriteria);
    }
}
