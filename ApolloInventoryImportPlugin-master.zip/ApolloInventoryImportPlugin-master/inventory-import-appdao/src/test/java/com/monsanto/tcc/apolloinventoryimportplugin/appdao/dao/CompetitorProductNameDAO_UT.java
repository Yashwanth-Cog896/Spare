package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 3:49:22 PM To change this template use File |
 * Settings | File Templates.
 */
public class CompetitorProductNameDAO_UT extends TestIIContextConfigurer {
    private TestHelper testHelper;
    private Product testProduct1;
    private Product testProduct2;
    private Product testProduct3;

    protected void setUp() throws Exception {
        super.setUp();
        testHelper = new TestHelper();
    }

    protected void tearDown() throws Exception {
        testHelper.rollbackTransaction();
//        if (testHelper != null) {
//            testHelper.beginTransaction();
//            testHelper.purgeMidasObjects();
//            testHelper.purgeStagingObjects();
//            testHelper.endTransaction();
//        }
        super.tearDown();
    }

    public void testGetProductListMatchingProducts_ValidProductAndCrop_ReturnOneRecord() throws Exception {
        try {
            createProductNames();
        } catch (Exception e) {
            tearDown();
            throw e;
        }
        try {
            testHelper.beginTransaction();
            CompetitorProductNameDAO productNameDAO = new CompetitorProductNameDAO("Corn");
            List<Product> productList = new ArrayList<Product>();
            productList.add(testProduct1);
            List list = productNameDAO.getProductListMatchingProducts(productList);
            assertEquals(1, list.size());
        } finally {
            testHelper.rollbackTransaction();
        }
    }

    public void testGetProductListMatchingProducts_InValidProductValidCrop_ReturnNoRecord() throws Exception {
        try {
            createProductNames();
        } catch (Exception e) {
            tearDown();
            throw e;
        }
        try {
            testHelper.beginTransaction();
            List<Product> productList = new ArrayList<Product>();
            productList.add(testProduct3);
            ProductNameDAO productNameDAO = new CompetitorProductNameDAO("Corn");
            List list = productNameDAO.getProductListMatchingProducts(productList);
            assertEquals(0, list.size());
        } finally {
            testHelper.rollbackTransaction();
        }
    }

    public void testGetProductListMatchingProducts_ValidProductInValidCrop_ReturnNoRecord() throws Exception {
        try {
            createProductNames();
        } catch (Exception e) {
            tearDown();
        }
        try {
            testHelper.beginTransaction();
            List<Product> productList = new ArrayList<Product>();
            productList.add(testProduct2);
            CompetitorProductNameDAO productNameDAO = new CompetitorProductNameDAO("Corn");
            List list = productNameDAO.getProductListMatchingProducts(productList);
            assertEquals(0, list.size());
        } finally {
            testHelper.rollbackTransaction();
        }
    }

    private void createProductNames() throws Exception {
        testHelper.beginTransaction();
        String countryName = "United States of America";
        testProduct1 = testHelper.createProduct("Corn", "T");
        testProduct2 = testHelper.createProduct("Tomato", "T");
        testProduct3 = testHelper.createProduct("Corn", "T");
        testHelper.createProductName("PRODUCTABC1", "T", "MONSANTO", "MONSANTO", countryName, testProduct1);
        testHelper.createProductName("PRODUCTABC2", "T", "PAYMASTER", "MONSANTO", countryName, testProduct1);
        testHelper.createProductName("PRODUCTABC3", "T", "MYCOGEN", "DOW", countryName, testProduct1);
        testHelper.createProductName("PRODUCTABC4", "T", "MONSANTO", "MONSANTO", countryName, testProduct2);
        testHelper.createProductName("PRODUCTABC5", "T", "PAYMASTER", "MONSANTO", countryName, testProduct2);

        testHelper.endTransaction();
    }
}
