/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;

/**
 * Filename:    $RCSfile: ICBMaleGermplasmGeneticMaterialDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $ On:          $Date: 2008-06-03 15:27:48 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class ICBMaleGermplasmGeneticMaterialDAO_UT extends TestIIContextConfigurer {
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String OWNER = "17";
    private TestHelper testHelper;
    private Session session;
    private static final String CROP_NAME = "Corn";

    public void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
    }

    public void testGetPrimaryGermplasmForICBMale_NoLineFunction_OneGermplasmOneGeneticMaterial() throws Exception {
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        MockDAO dao = new MockDAO(CROP_NAME, null);
        Germplasm actualGermplasm = dao.getPrimaryGermplasmForICBMale(source, pedigree);
        assertNotNull(actualGermplasm);
        assertEquals(expectedGermplasm.getId(), actualGermplasm.getId());
    }

    public void testGetPrimaryGermplasmForICBMale_LineFunction_OneGermplasmOneGeneticMaterial() throws Exception {
        String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunction, null);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        MockDAO dao = new MockDAO(CROP_NAME, lineFunction);
        Germplasm actualGermplasm = dao.getPrimaryGermplasmForICBMale(source, pedigree);
        assertNotNull(actualGermplasm);
        assertEquals(expectedGermplasm.getId(), actualGermplasm.getId());
    }

    public void testGetPrimaryGermplasmForICBMale_NoLineFunction_MultipleGermplasms() throws Exception {
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);

        MockDAO dao = new MockDAO(CROP_NAME, null);
        Germplasm actualGermplasm = dao.getPrimaryGermplasmForICBMale(source, pedigree);
        assertNotNull(actualGermplasm);
        assertEquals(expectedGermplasm.getId(), actualGermplasm.getId());
    }

    public void testGetPrimaryGermplasmForICBMale_NoLineFunction_MultipleGermplasms_SourceSearchIsCaseInsensitive() throws
            Exception {
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());

        MockDAO dao = new MockDAO(CROP_NAME, null);
        Germplasm actualGermplasm = dao.getPrimaryGermplasmForICBMale(source.toLowerCase(), pedigree);
        assertNotNull(actualGermplasm);
        assertEquals(expectedGermplasm.getId(), actualGermplasm.getId());
    }

    public void testGetPrimaryGermplasmForICBMale_LineFunction_MultipleGermplasms() throws Exception {
        String lineFunctionOfExpectedGp = LineFunctionConstants.R_LINE_FUNCTION;
        String lineFunctionOfUnexpectedGp = LineFunctionConstants.B_LINE_FUNCTION;
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfExpectedGp,
                        null);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfUnexpectedGp,
                        null);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);

        MockDAO dao = new MockDAO(CROP_NAME, lineFunctionOfExpectedGp);
        Germplasm actualGermplasm = dao.getPrimaryGermplasmForICBMale(source, pedigree);
        assertNotNull(actualGermplasm);
        assertEquals(expectedGermplasm.getId(), actualGermplasm.getId());
    }

    public void testGetPrimaryGermplasmForICBMale_LineFunction_MultipleGermplasms_SourceSearchIsCaseInsensitive() throws
            Exception {
        String lineFunctionOfExpectedGp = LineFunctionConstants.R_LINE_FUNCTION;
        String lineFunctionOfUnexpectedGp = LineFunctionConstants.B_LINE_FUNCTION;
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfExpectedGp,
                        null);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfUnexpectedGp,
                        null);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());

        MockDAO dao = new MockDAO(CROP_NAME, lineFunctionOfExpectedGp);
        Germplasm actualGermplasm = dao.getPrimaryGermplasmForICBMale(source.toLowerCase(), pedigree);
        assertNotNull(actualGermplasm);
        assertEquals(expectedGermplasm.getId(), actualGermplasm.getId());
    }

    public void testGetPrimaryGeneticMaterial_NoLineFunction_OneGermplasmOneGeneticMaterial() throws Exception {
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        GeneticMaterial expectedGeneticMaterial = testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        ICBMaleGermplasmGeneticMaterialDAO dao = new ICBMaleGermplasmGeneticMaterialDAO(CROP_NAME, null);
        GeneticMaterial actualGeneticMaterial = dao.getPrimaryGeneticMaterial(source, pedigree);
        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), actualGeneticMaterial.getGeneticMaterialId());
        assertEquals(expectedGermplasm.getId(), actualGeneticMaterial.getGermplasm().getId());
    }

    public void testGetPrimaryGeneticMaterial_LineFunction_OneGermplasmOneGeneticMaterial() throws Exception {
        String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunction, null);
        GeneticMaterial expectedGeneticMaterial = testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        ICBMaleGermplasmGeneticMaterialDAO dao = new ICBMaleGermplasmGeneticMaterialDAO(CROP_NAME, lineFunction);
        GeneticMaterial actualGeneticMaterial = dao.getPrimaryGeneticMaterial(source, pedigree);
        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), actualGeneticMaterial.getGeneticMaterialId());
        assertEquals(expectedGermplasm.getId(), actualGeneticMaterial.getGermplasm().getId());
    }

    public void testGetPrimaryGeneticMaterial_NoLineFunction_MultipleGermplasms() throws Exception {
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        GeneticMaterial expectedGeneticMaterial = testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);

        ICBMaleGermplasmGeneticMaterialDAO dao = new ICBMaleGermplasmGeneticMaterialDAO(CROP_NAME, null);
        GeneticMaterial actualGeneticMaterial = dao.getPrimaryGeneticMaterial(source, pedigree);
        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), actualGeneticMaterial.getGeneticMaterialId());
        assertEquals(expectedGermplasm.getId(), actualGeneticMaterial.getGermplasm().getId());
    }

    public void testGetPrimaryGeneticMaterial_LineFunction_MultipleGermplasms() throws Exception {
        String lineFunctionOfExpectedGp = LineFunctionConstants.R_LINE_FUNCTION;
        String lineFunctionOfUnexpectedGp = LineFunctionConstants.B_LINE_FUNCTION;
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfExpectedGp,
                        null);
        GeneticMaterial expectedGeneticMaterial = testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source);

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfUnexpectedGp,
                        null);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source);

        ICBMaleGermplasmGeneticMaterialDAO dao = new ICBMaleGermplasmGeneticMaterialDAO(CROP_NAME,
                lineFunctionOfExpectedGp);
        GeneticMaterial actualGeneticMaterial = dao.getPrimaryGeneticMaterial(source, pedigree);
        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), actualGeneticMaterial.getGeneticMaterialId());
        assertEquals(expectedGermplasm.getId(), actualGeneticMaterial.getGermplasm().getId());
    }

    public void testGetPrimaryGeneticMaterial_NoLineFunction_MultipleGermplasms_SourceSearchIsCaseInsensitive() throws
            Exception {
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        GeneticMaterial expectedGeneticMaterial = testHelper
                .createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T");
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());

        ICBMaleGermplasmGeneticMaterialDAO dao = new ICBMaleGermplasmGeneticMaterialDAO(CROP_NAME, null);
        GeneticMaterial actualGeneticMaterial = dao.getPrimaryGeneticMaterial(source.toLowerCase(), pedigree);
        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), actualGeneticMaterial.getGeneticMaterialId());
        assertEquals(expectedGermplasm.getId(), actualGeneticMaterial.getGermplasm().getId());
    }

    public void testGetPrimaryGeneticMaterial_LineFunction_MultipleGermplasms_SourceSearchIsCaseInsensitive() throws
            Exception {
        String lineFunctionOfExpectedGp = LineFunctionConstants.R_LINE_FUNCTION;
        String lineFunctionOfUnexpectedGp = LineFunctionConstants.B_LINE_FUNCTION;
        String lineCode = "II-ICBMALE-LC";
        String origin = "II-ICBMALE-LC";
        String pedigree = "II-ICBMALE-LC";
        String source = lineCode + " SOURCE";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfExpectedGp,
                        null);
        GeneticMaterial expectedGeneticMaterial = testHelper
                .createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(expectedGermplasm, source.toUpperCase());

        Germplasm unexpectedGermplasm = testHelper
                .createGermplasm(FINISHED, lineCode, origin, pedigree, OWNER, CROP_NAME, "F", "T", lineFunctionOfUnexpectedGp,
                        null);
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());
        testHelper.createInbredGeneticMaterial(unexpectedGermplasm, source.toUpperCase());

        ICBMaleGermplasmGeneticMaterialDAO dao = new ICBMaleGermplasmGeneticMaterialDAO(CROP_NAME,
                lineFunctionOfExpectedGp);
        GeneticMaterial actualGeneticMaterial = dao.getPrimaryGeneticMaterial(source.toLowerCase(), pedigree);
        assertNotNull(actualGeneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), actualGeneticMaterial.getGeneticMaterialId());
        assertEquals(expectedGermplasm.getId(), actualGeneticMaterial.getGermplasm().getId());
    }

    public void testConstructor_CropNameNotPassedIn_ThrowsException() throws Exception {
        try {
            new ICBMaleGermplasmGeneticMaterialDAO(null);
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("cropName is required") > -1);
        }
    }

    public void testConstructor_LineFunctionPassedIn_CropNameNotPassedIn_ThrowsException() throws Exception {
        try {
            new ICBMaleGermplasmGeneticMaterialDAO(null, LineFunctionConstants.R_LINE_FUNCTION);
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("cropName is required") > -1);
        }
    }

    class MockDAO extends ICBMaleGermplasmGeneticMaterialDAO {
        public MockDAO(String cropName) {
            super(cropName);
        }

        public MockDAO(String cropName, String lineFunctionRefId) {
            super(cropName, lineFunctionRefId);
        }

        protected Germplasm getPrimaryGermplasmForICBMale(String source, String pedigree) {
            return super.getPrimaryGermplasmForICBMale(source, pedigree);
        }
    }
}