/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.BrProg;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: HybridGeneticMaterialDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: ddbrow5 $    	 On:	$Date: 2008-09-22 15:20:22 $
 *
 * @author ddbrow5
 * @version $Revision: 1.5 $
 * @noinspection RefusedBequest
 */
public class HybridGeneticMaterialDAO_UT extends TestIIContextConfigurer {
    private static final String HYBRID_LINE_TYPE = MaterialTypeConstants.HYBRID_LINES;
    private static final String CROP_NAME = "Corn";
    private static final String LINE_CODE = "GM9215";
    private static final String ORIGIN = "GM9215";
    private static final String SOURCE = "Source1";
    private static final String LINEAGE = "lineage";
    private static final String PEDIGREE_NAME = "GM9215";
    private static final String NOT_MATCHING_PEDIGREE_NAME = "DAT";
    private static final String GERMPLASM_OWNER = "06";
    private static final String INVENTORY_OWNER = "06";
    private static final String FEMALE_PARENT_SOURCE = "FS1";
    private static final String GP_FEMALE_PARENT = "9Q";
    private Session session;
    private GeneticMaterial expectedGeneticMaterial;

    public void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        TestHelper appdaoTestHelper = new TestHelper(session);

        BrProg activeCornProgram = appdaoTestHelper.getActiveBrProg(CROP_NAME);
        Germplasm gp = appdaoTestHelper.createGermplasm(HYBRID_LINE_TYPE, LINE_CODE, ORIGIN, PEDIGREE_NAME,
                activeCornProgram.getBrProgRefId(), CROP_NAME);
        expectedGeneticMaterial = appdaoTestHelper.createGeneticMaterial(gp, SOURCE, null, LINEAGE);
    }

    public void tearDown() throws Exception {
        if (session != null && session.isOpen()) {
            session.getTransaction().rollback();
        }
        super.tearDown();
    }

    public void testGetLowestGeneticMaterialMatchingPedigreeNameForSuccess() throws Exception {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory inventory = new StagingInventory();
        inventory.setSource(SOURCE);
        inventory.setGermplasmOwner(GERMPLASM_OWNER);
        inventory.setInventoryOwner(GERMPLASM_OWNER);
        inventory.setPedigreeName(PEDIGREE_NAME);
        inventory.setFemaleParentSource(FEMALE_PARENT_SOURCE);
        inventory.setGermplasmOwnerOfFemaleParent(GP_FEMALE_PARENT);
        inventory.setMaleParentSource(SOURCE);
        inventory.setGermplasmOwnerOfMaleParent(GERMPLASM_OWNER);
        inventory.setLineType(HYBRID_LINE_TYPE);
        inventory.setLineCode(LINE_CODE);
        inventory.setInventoryHeader(header);

        HybridGeneticMaterialDAO dao = new HybridGeneticMaterialDAO(inventory.getSource(), CROP_NAME);
        GeneticMaterial geneticMaterial = dao.getLowestGeneticMaterialMatchingPedigreeName(inventory.getPedigreeName());
        assertNotNull(geneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), geneticMaterial.getGeneticMaterialId());
    }

    public void testGetLowestGeneticMaterialMatchingPedigreeNameForFailure() throws Exception {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory inventory = new StagingInventory();
        inventory.setSource(SOURCE);
        inventory.setGermplasmOwner(GERMPLASM_OWNER);
        inventory.setInventoryOwner(INVENTORY_OWNER);
        inventory.setPedigreeName(NOT_MATCHING_PEDIGREE_NAME);
        inventory.setFemaleParentSource(FEMALE_PARENT_SOURCE);
        inventory.setGermplasmOwnerOfFemaleParent(GP_FEMALE_PARENT);
        inventory.setMaleParentSource(SOURCE);
        inventory.setGermplasmOwnerOfMaleParent(GERMPLASM_OWNER);
        inventory.setLineType(HYBRID_LINE_TYPE);
        inventory.setLineCode(LINE_CODE);
        inventory.setInventoryHeader(header);

        HybridGeneticMaterialDAO dao = new HybridGeneticMaterialDAO(inventory.getSource(), CROP_NAME);
        GeneticMaterial geneticMaterial = dao.getLowestGeneticMaterialMatchingPedigreeName(inventory.getPedigreeName());
        assertEquals(null, geneticMaterial);
    }

    public void testGetLowestGeneticMaterialMatchingGermplasm_Success() throws Exception {
        GermplasmDAO germplasmDAO = new GermplasmDAO(CROP_NAME);
        List germplasms = germplasmDAO.getAllGermplasmsMatchingPedigree(PEDIGREE_NAME);
        assertEquals(2, germplasms.size());

        Germplasm germplasm = null;
        for (Iterator iter = germplasms.iterator(); iter.hasNext();) {
            Germplasm iterGermplasm = (Germplasm) iter.next();
            if (germplasm == null || iterGermplasm.getId() > germplasm.getId()) {
                germplasm = iterGermplasm;
            }
        }
        HybridGeneticMaterialDAO dao = new HybridGeneticMaterialDAO(SOURCE, CROP_NAME);
        GeneticMaterial geneticMaterial = dao.getLowestGeneticMaterialMatchingGermplasm(germplasm);
        assertNotNull(geneticMaterial);
        assertEquals(expectedGeneticMaterial.getGeneticMaterialId(), geneticMaterial.getGeneticMaterialId());
    }
}
