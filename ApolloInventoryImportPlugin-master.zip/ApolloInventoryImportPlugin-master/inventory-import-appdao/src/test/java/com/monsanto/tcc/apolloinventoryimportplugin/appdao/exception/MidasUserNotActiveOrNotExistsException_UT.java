package com.monsanto.tcc.apolloinventoryimportplugin.appdao.exception;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

/**
 * Created by Dan Schnettgoecke on 6/18/12 at 10:08 AM.
 */

public class MidasUserNotActiveOrNotExistsException_UT {

    @Test
    public void exceptionMessageSetOnNewException() {
        String exceptionMessage = "sup dawg?";
        MidasUserNotActiveOrNotExistsException exception = new MidasUserNotActiveOrNotExistsException(exceptionMessage);
        assertThat(exception.getMessage(), equalTo(exceptionMessage));
    }
}