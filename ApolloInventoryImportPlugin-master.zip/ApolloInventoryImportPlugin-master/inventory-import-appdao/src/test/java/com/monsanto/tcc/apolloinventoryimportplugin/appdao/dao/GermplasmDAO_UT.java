/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;
/**
 *
 * Filename:    $RCSfile: GermplasmDAO_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ssnall $    	 On:	$Date: 2009-06-05 14:07:48 $
 * @version $Revision: 1.10 $
 * @author apatro
 */

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NonALineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

import java.util.List;

public class GermplasmDAO_UT extends TestIIContextConfigurer {
    private static String cornBrProgRefID = "17";
    private static final String CODED_LINECODE = "AXBXC";
    private Session session;
    private TestHelper testHelper;


    public GermplasmDAO_UT(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetGermplasmMatchingOriginOrLikeOrigin() throws Exception {

        testHelper
                .createGermplasm("Segpop", null, "PS*3/II", cornBrProgRefID + "_" + "S/P" + ":1.2.", cornBrProgRefID, "Corn");
        testHelper.createGermplasm("Segpop", null, "B/P11", cornBrProgRefID + "_" + "S/P" + ":1.2.", cornBrProgRefID,
                "Corn", "B");
        testHelper
                .createGermplasm("Segpop", null, "PS/II", cornBrProgRefID + "_" + "S/P" + ":1.2.", cornBrProgRefID, "Corn");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        Germplasm[] matchingGermplasms = dao
                .getAllGermplasmsMatchingOrigin("PS/II", "PS*%/II", new NullLineFunctionCriteria());

        assertNotNull(matchingGermplasms);
        assertEquals(2, matchingGermplasms.length);
    }

    public void testGetGermplasmMatchingOriginOrLikeOriginWithDifferentLineFunction() throws Exception {

        testHelper.createGermplasm("Segpop", null, "B/P11", cornBrProgRefID + "_" + "S/P" + ":1.2.", cornBrProgRefID,
                "Corn", "B");
        testHelper
                .createGermplasm("Segpop", null, "PS/II", cornBrProgRefID + "_" + "S/P" + ":1.2.", cornBrProgRefID, "Corn",
                        "B");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        Germplasm[] matchingGermplasms = dao
                .getAllGermplasmsMatchingOrigin("PS/II", "PS*%/II", new NullLineFunctionCriteria());

        assertNull(matchingGermplasms);
    }

    public void testGetAllGermplasmsMatchingPedigree() throws Exception {
        final String MATCHING_PEDIGREE = cornBrProgRefID + "_A/G:@.1.2.";

        testHelper.createGermplasm("Segpop", null, "A/G", MATCHING_PEDIGREE, cornBrProgRefID, "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmsMatchingPedigree(MATCHING_PEDIGREE);

        assertNotNull(matchingGermplasms);
        assertEquals(1, matchingGermplasms.size());
        assertEquals(MATCHING_PEDIGREE, ((Germplasm) matchingGermplasms.get(0)).getPedigreeName());
    }

    public void testGetAllGermplasmsMatchingPedigreeAndLineFunction() throws Exception {
        final String MATCHING_PEDIGREE = cornBrProgRefID + "_A/G:@.1.2.";

        testHelper.createGermplasm("Segpop", null, "A/G", MATCHING_PEDIGREE, cornBrProgRefID, "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmsMatchingPedigree(MATCHING_PEDIGREE,
                new NonALineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION));

        assertNotNull(matchingGermplasms);
        assertEquals(0, matchingGermplasms.size());
    }

    public void testGetAllGermplasmsMatchingLineCode_Failure() throws Exception {
        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmMatchingLineCode("AZZZZ");

        assertNotNull(matchingGermplasms);
        assertEquals(0, matchingGermplasms.size());
    }

    public void testGetAllGermplasmsMatchingLineCode() throws Exception {
        testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE, cornBrProgRefID,
                "Corn");
        testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE + ":1.2.",
                cornBrProgRefID, "Corn");
        testHelper.createGermplasm("Finished", CODED_LINECODE, "A/B", CODED_LINECODE, cornBrProgRefID, "Corn");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmMatchingLineCode(CODED_LINECODE);

        assertNotNull(matchingGermplasms);
        assertEquals(3, matchingGermplasms.size());
        assertEquals(CODED_LINECODE, ((Germplasm) matchingGermplasms.get(0)).getLineCode());
        assertEquals(CODED_LINECODE, ((Germplasm) matchingGermplasms.get(1)).getLineCode());
        assertEquals(CODED_LINECODE, ((Germplasm) matchingGermplasms.get(2)).getLineCode());
    }

    public void testGetCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction_ReturnsOneRecord() throws
            Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);

        GermplasmDAO dao = new GermplasmDAO(cropName);
        int matchingGermplasmCount = dao
                .getCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction(inventory);

        assertEquals(1, matchingGermplasmCount);
    }

    public void testGetCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction_ReturnsTwoRecords() throws
            Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);

        gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 2", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);

        GermplasmDAO dao = new GermplasmDAO(cropName);
        int matchingGermplasmCount = dao
                .getCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction(inventory);

        assertEquals(2, matchingGermplasmCount);
    }

    public void testGetCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction_ReturnsThreeRecords() throws
            Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;
        final String mismatchedLineFunction = LineFunctionConstants.B_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);

        gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 2", "F4", lineage);

        gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 3", "F4", lineage);

        Germplasm gpWillNotMatch = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName,
                        mismatchedLineFunction);
        testHelper.createGeneticMaterial(gpWillNotMatch, "Source 4", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);

        GermplasmDAO dao = new GermplasmDAO(cropName);
        int matchingGermplasmCount = dao
                .getCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction(inventory);

        assertEquals(3, matchingGermplasmCount);
    }

    public void testGetCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction_ReturnsZeroRecords() throws
            Exception {
        final String cropName = "Corn";
        final String gpOrigin = "A/G";
        final String siOrigin = "G/A";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + gpOrigin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, gpOrigin, pedigreeName, cornBrProgRefID, cropName,
                        lineFunction);
        testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(siOrigin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);

        GermplasmDAO dao = new GermplasmDAO(cropName);
        int matchingGermplasmCount = dao
                .getCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction(inventory);

        assertEquals(0, matchingGermplasmCount);
    }

    public void testGetCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction_ReturnsOneRecordsForIsDeletedIsT() throws
            Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "T",
                        "F", lineFunction, null);
        testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);

        GermplasmDAO dao = new GermplasmDAO(cropName);
        int matchingGermplasmCount = dao
                .getCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction(inventory);

        assertEquals(1, matchingGermplasmCount);
    }

    public void testSingleExistingGermplasmsByVegetativeStructureForBulbPicksGermplasmWithLineFunction() throws
            Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", lineFunction, null);
        Germplasm gp2 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", null, null);
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);
        GeneticMaterial geneticMaterial2 = testHelper.createGeneticMaterial(gp, "Source 2", "F4", lineage);
        GeneticMaterial geneticMaterial3 = testHelper.createGeneticMaterial(gp2, "Source 2", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);
        inventory.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory.setVegetativeStructure("Bulb");
        inventory.setGeneration("F4");

        testHelper.createInventory(geneticMaterial1, "F", "17", "T", "Seed");
        testHelper.createInventory(geneticMaterial2, "F", "17", "T", "Bulb");
        testHelper.createInventory(geneticMaterial3, "F", "17", "T", "Bulb");

        GermplasmDAO dao = new GermplasmDAO(cropName);
        List<Germplasm> germplasmsByVegetativeStructure = dao.getExistingGermplasmsByVegetativeStructure(inventory);

        assertEquals(1, germplasmsByVegetativeStructure.size());
        assertEquals(gp.getId(), germplasmsByVegetativeStructure.get(0).getId());

    }

    public void testSingleExistingGermplasmsByVegetativeStructureForBulbPicksGermplasmWithLineNoFunction() throws
            Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", lineFunction, null);
        Germplasm gp2 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", null, null);
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);
        GeneticMaterial geneticMaterial2 = testHelper.createGeneticMaterial(gp, "Source 2", "F4", lineage);
        GeneticMaterial geneticMaterial3 = testHelper.createGeneticMaterial(gp2, "Source 2", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory.setVegetativeStructure("Bulb");
        inventory.setGeneration("F4");

        testHelper.createInventory(geneticMaterial1, "F", "17", "T", "Seed");
        testHelper.createInventory(geneticMaterial2, "F", "17", "T", "Bulb");
        testHelper.createInventory(geneticMaterial3, "F", "17", "T", "Bulb");

        GermplasmDAO dao = new GermplasmDAO(cropName);
        List<Germplasm> germplasmsByVegetativeStructure = dao.getExistingGermplasmsByVegetativeStructure(inventory);

        assertEquals(1, germplasmsByVegetativeStructure.size());
        assertEquals(gp2.getId(), germplasmsByVegetativeStructure.get(0).getId());
    }

    public void testNoExistingGermplasmsByVegetativeStructureForBulbStagingInventoryWithLineFunction() throws Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp2 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", null, null);
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(gp2, "Source 1", "F4", lineage);
        GeneticMaterial geneticMaterial3 = testHelper.createGeneticMaterial(gp2, "Source 2", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setLineFunction(lineFunction);
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory.setVegetativeStructure("Bulb");
        inventory.setGeneration("F4");

        testHelper.createInventory(geneticMaterial1, "F", "17", "T", "Seed");
        testHelper.createInventory(geneticMaterial3, "F", "17", "T", "Bulb");

        GermplasmDAO dao = new GermplasmDAO(cropName);
        List<Germplasm> germplasmsByVegetativeStructure = dao.getExistingGermplasmsByVegetativeStructure(inventory);

        assertEquals(0, germplasmsByVegetativeStructure.size());
    }

    public void testGetMultipleExistingGermplasmsByVegetativeStructureForBulb() throws Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp1 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", lineFunction, null);
        Germplasm gp2 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName + "1", cornBrProgRefID,
                        cropName, "F", "F", lineFunction, null);
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(gp1, "Source 1", "F4", lineage);
        GeneticMaterial geneticMaterial2 = testHelper.createGeneticMaterial(gp2, "Source 2", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);
        inventory.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory.setVegetativeStructure("Bulb");
        inventory.setGeneration("F4");

        testHelper.createInventory(geneticMaterial1, "F", "17", "T", "Seed");
        testHelper.createInventory(geneticMaterial2, "F", "17", "T", "Bulb");

        GermplasmDAO dao = new GermplasmDAO(cropName);
        List<Germplasm> germplasmsByVegetativeStructure = dao.getExistingGermplasmsByVegetativeStructure(inventory);

        assertEquals(2, germplasmsByVegetativeStructure.size());
    }

    public void testNoExistingGermplasmsByVegetativeStructureForSeed() throws Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", lineFunction, null);
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);
        GeneticMaterial geneticMaterial2 = testHelper.createGeneticMaterial(gp, "Source 2", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);
        inventory.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory.setVegetativeStructure("Seed");
        inventory.setGeneration("F4");

        testHelper.createInventory(geneticMaterial1, "F", "17", "T", "Seed");
        testHelper.createInventory(geneticMaterial2, "F", "17", "T", "Bulb");

        GermplasmDAO dao = new GermplasmDAO(cropName);
        List<Germplasm> germplasmsByVegetativeStructure = dao.getExistingGermplasmsByVegetativeStructure(inventory);

        assertEquals(0, germplasmsByVegetativeStructure.size());
    }

    public void testExistingGermplasmsByVegetativeStructureForSeed() throws Exception {
        final String cropName = "Corn";
        final String origin = "A/G";
        final String lineage = "@.1.2.";
        final String pedigreeName = cornBrProgRefID + "_" + origin + ":" + lineage;
        final String lineFunction = LineFunctionConstants.R_LINE_FUNCTION;

        Germplasm gp = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigreeName, cornBrProgRefID, cropName, "F",
                        "F", lineFunction, null);
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(gp, "Source 1", "F4", lineage);

        StagingInventory inventory = new StagingInventory();
        inventory.setInventoryHeader(createStagingInventoryHeader(cropName));
        inventory.setGermplasmOwner(cornBrProgRefID);
        inventory.setOrigin(origin);
        inventory.setLineage(lineage);
        inventory.setLineFunction(lineFunction);
        inventory.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory.setVegetativeStructure("Seed");
        inventory.setGeneration("F4");

        testHelper.createInventory(geneticMaterial1, "F", "17", "T", "Bulb");

        GermplasmDAO dao = new GermplasmDAO(cropName);
        List<Germplasm> germplasmsByVegetativeStructure = dao.getExistingGermplasmsByVegetativeStructure(inventory);

        assertEquals(1, germplasmsByVegetativeStructure.size());
    }

    private StagingInventoryHeader createStagingInventoryHeader(String cropName) {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(cropName);
        return header;
    }


    public void testGetPrimaryGermplasmWhenGermplasmsAreNotAssociatedToAnyGeneticMaterials() throws Exception {
        Germplasm germplasm1 = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE, cornBrProgRefID,
                "Corn");
        Germplasm germplasm2 = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE + ":1.2.",
                cornBrProgRefID, "Corn");
        Germplasm germplasm3 = testHelper.createGermplasm("Finished", CODED_LINECODE, "A/B", CODED_LINECODE, cornBrProgRefID, "Corn");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmMatchingLineCode(CODED_LINECODE);
        Germplasm primaryGermplasm = dao.getPrimaryGermplasm(matchingGermplasms);
        assertNotNull(primaryGermplasm);
    }

    public void testGetPrimaryGermplasmWhenGermplasmsAreAssociatedToGeneticMaterials() throws Exception {
        Germplasm germplasm1 = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE, cornBrProgRefID,
                "Corn");
        testHelper.createGeneticMaterial(germplasm1, "TESTSRC", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm1, "TESTSRC2", "F1", "@.");
        Germplasm germplasm2 = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE + ":1.2.",
                cornBrProgRefID, "Corn");
        Germplasm germplasm3 = testHelper.createGermplasm("Finished", CODED_LINECODE, "A/B", CODED_LINECODE, cornBrProgRefID, "Corn");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmMatchingLineCode(CODED_LINECODE);
        Germplasm primaryGermplasm = dao.getPrimaryGermplasm(matchingGermplasms);
        assertEquals(germplasm1.getId(), primaryGermplasm.getId());
    }

    public void testGetPrimaryGermplasmWithLeastPrimaryKeyWhenMultipleGermplasmsAreAssociatedToTheSameNumberOfGeneticMaterials() throws Exception {
        Germplasm germplasm1 = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE, cornBrProgRefID,
                "Corn");
        testHelper.createGeneticMaterial(germplasm1, "TESTSRC", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm1, "TESTSRC2", "F1", "@.");
        Germplasm germplasm2 = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE + ":1.2.",
                cornBrProgRefID, "Corn");
        testHelper.createGeneticMaterial(germplasm2, "TESTSRC3", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm2, "TESTSRC4", "F1", "@.");

        Germplasm germplasm3 = testHelper.createGermplasm("Finished", CODED_LINECODE, "A/B", CODED_LINECODE, cornBrProgRefID, "Corn");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmMatchingLineCode(CODED_LINECODE);
        Germplasm primaryGermplasm = dao.getPrimaryGermplasm(matchingGermplasms);
        assertEquals(germplasm1.getId(), primaryGermplasm.getId());
    }

    public void testGetPrimaryGermplasmMultipleExecutions() throws Exception {
        Germplasm germplasm1a = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE, cornBrProgRefID,
                "Corn");
        testHelper.createGeneticMaterial(germplasm1a, "TESTSRC", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm1a, "TESTSRC2", "F1", "@.");

        Germplasm germplasm2a = testHelper.createGermplasm("Coded", CODED_LINECODE, "A/B", cornBrProgRefID + "_" + CODED_LINECODE + ":1.2.",
                cornBrProgRefID, "Corn");
        testHelper.createGeneticMaterial(germplasm2a, "TESTSRC3", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm2a, "TESTSRC4", "F1", "@.");

        Germplasm germplasm3a = testHelper.createGermplasm("Finished", CODED_LINECODE, "A/B", CODED_LINECODE, cornBrProgRefID, "Corn");

        GermplasmDAO dao = new GermplasmDAO("Corn");
        List matchingGermplasms = dao.getAllGermplasmMatchingLineCode(CODED_LINECODE);
        Germplasm primaryGermplasm = dao.getPrimaryGermplasm(matchingGermplasms);
        assertEquals(germplasm1a.getId(), primaryGermplasm.getId());

        Germplasm germplasm1b = testHelper.createGermplasm("Coded", CODED_LINECODE + "2", "A/B", cornBrProgRefID + "_" + CODED_LINECODE, cornBrProgRefID,
                "Corn");
        testHelper.createGeneticMaterial(germplasm1b, "TESTSRCW", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm1b, "TESTSRCX", "F1", "@.");

        Germplasm germplasm2b = testHelper.createGermplasm("Coded", CODED_LINECODE + "2", "A/B", cornBrProgRefID + "_" + CODED_LINECODE + ":1.2.",
                cornBrProgRefID, "Corn");
        testHelper.createGeneticMaterial(germplasm2b, "TESTSRCY", "F1", "@.");
        testHelper.createGeneticMaterial(germplasm2b, "TESTSRCZ", "F1", "@.");

        matchingGermplasms = dao.getAllGermplasmMatchingLineCode(CODED_LINECODE + "2");
        primaryGermplasm = dao.getPrimaryGermplasm(matchingGermplasms);

        assertEquals(germplasm1b.getId(), primaryGermplasm.getId());
    }
}
