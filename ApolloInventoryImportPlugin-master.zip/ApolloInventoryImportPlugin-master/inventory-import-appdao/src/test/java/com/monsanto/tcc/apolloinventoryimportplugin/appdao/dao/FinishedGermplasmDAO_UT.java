/*
 FinishedGermplasmDAO_UT was created on May 23, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NonALineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: FinishedGermplasmDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ssnall $ On:	$Date: 2009-06-05 14:07:48 $
 *
 * @author SRKARNA
 * @version $Revision: 1.6 $
 */
public class FinishedGermplasmDAO_UT extends TestIIContextConfigurer {
    private long[] germplasmId = new long[6];
    private long[] geneticMaterialId = new long[5];
    private static final String NOT_DELETED_LINECODE = "LINECODEXY";
    private static final String DELETED_LINECODE = "LINECODEYX";
    private static final String LINECODE_WITH_LINE_FUNCTION = "LINECODEZXY";
    private static final String LINECODE_WITH_NULL_LINE_FUNCTION = "LINECODEZAB";
    private static final String LINE_FUNCTION_REF_ID = "R";

    public FinishedGermplasmDAO_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        TestHelper testHelper = new TestHelper(session);

        Germplasm gp = testHelper
                .createGermplasm("Finished", NOT_DELETED_LINECODE, "A/B", NOT_DELETED_LINECODE, "17", "Corn", "F", "T");
        germplasmId[0] = gp.getId().longValue();

        gp = testHelper.createGermplasm("Finished", DELETED_LINECODE, "A/B", DELETED_LINECODE, "17", "Corn", "T", "T");
        germplasmId[1] = gp.getId().longValue();

        gp = testHelper.createGermplasm("Finished", LINECODE_WITH_LINE_FUNCTION, "A/B", LINECODE_WITH_LINE_FUNCTION, "17",
                "Corn", "F", "T", LINE_FUNCTION_REF_ID, null);
        germplasmId[2] = gp.getId().longValue();
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC 123456", "INBRED", "|");
        geneticMaterialId[0] = gm.getGeneticMaterialId().longValue();
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC 123897", "INBRED", "|");
        geneticMaterialId[1] = gm.getGeneticMaterialId().longValue();

        gp = testHelper.createGermplasm("Finished", LINECODE_WITH_NULL_LINE_FUNCTION, "A/B",
                LINECODE_WITH_NULL_LINE_FUNCTION, "17", "Corn", "F", "T");
        germplasmId[3] = gp.getId().longValue();
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC 6721378", "INBRED", "|");
        geneticMaterialId[2] = gm.getGeneticMaterialId().longValue();
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC 67219721", "INBRED", "|");
        geneticMaterialId[3] = gm.getGeneticMaterialId().longValue();

        gp = testHelper.createGermplasm("Finished", LINECODE_WITH_LINE_FUNCTION, "A/B", LINECODE_WITH_LINE_FUNCTION, "17",
                "Corn", "F", "T", LINE_FUNCTION_REF_ID, null);
        germplasmId[4] = gp.getId().longValue();
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC 672241245", "INBRED", "|");
        geneticMaterialId[3] = gm.getGeneticMaterialId().longValue();

        gp = testHelper.createGermplasm("Finished", LINECODE_WITH_NULL_LINE_FUNCTION, "A/B",
                LINECODE_WITH_NULL_LINE_FUNCTION, "17", "Corn", "F", "T");
        germplasmId[5] = gp.getId().longValue();
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC 672241245", "INBRED", "|");
        geneticMaterialId[4] = gm.getGeneticMaterialId().longValue();
    }

    public void tearDown() throws Exception {

        try {
            Transaction transaction = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession().getTransaction();
            if (null != transaction && transaction.isActive() && !transaction.wasCommitted() &&
                    !transaction.wasRolledBack()) {
                transaction.rollback();
            }
        } finally {
            super.tearDown();
        }
    }

    public void testGetPrimaryGermplasmSuccess() {
        Germplasm primaryGermplasm = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria())
                .getPrimaryGermplasm(LINECODE_WITH_NULL_LINE_FUNCTION, "INBRED");
        assertNotNull(primaryGermplasm);
        assertEquals(germplasmId[3], primaryGermplasm.getId().longValue());
    }

    public void testGetPrimaryGermplasmsSuccess() {
        Germplasm[] primaryGermplasms = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria())
                .getPrimaryGermplasms(LINECODE_WITH_NULL_LINE_FUNCTION);
        assertNotNull(primaryGermplasms);
        assertEquals(2, primaryGermplasms.length);
        assertEquals(germplasmId[3], primaryGermplasms[0].getId().longValue());
        assertEquals(germplasmId[5], primaryGermplasms[1].getId().longValue());
    }

    public void testGetPrimaryGermplasmWithLineFunctionSuccess() {
        Germplasm primaryGermplasm = new FinishedGermplasmDAO("Corn", new NonALineFunctionCriteria(LINE_FUNCTION_REF_ID))
                .getPrimaryGermplasm(LINECODE_WITH_LINE_FUNCTION, "INBRED");
        assertNotNull(primaryGermplasm);
        assertEquals(germplasmId[2], primaryGermplasm.getId().longValue());
    }

    public void testGetPrimaryGermplasmsWithLineFunctionSuccess() {
        Germplasm[] primaryGermplasms = new FinishedGermplasmDAO("Corn", new NonALineFunctionCriteria(LINE_FUNCTION_REF_ID))
                .getPrimaryGermplasms(LINECODE_WITH_LINE_FUNCTION);
        assertNotNull(primaryGermplasms);
        assertEquals(2, primaryGermplasms.length);
        assertEquals(germplasmId[2], primaryGermplasms[0].getId().longValue());
        assertEquals(germplasmId[4], primaryGermplasms[1].getId().longValue());
    }

    public void testGetPrimaryGermplasmNotExists() {
        Germplasm primaryGermplasm = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria())
                .getPrimaryGermplasm("ABCDEFGH", "");
        assertNull(primaryGermplasm);
    }

    public void testGetPrimaryGermplasmsNotExists() {
        Germplasm[] primaryGermplasms = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria())
                .getPrimaryGermplasms("ABCDEFGH");
        assertNull(primaryGermplasms);
    }

    public void testGetAllGermplasmsMatchingLineCode() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        List germplasms = dao.getAllGermplasmsExcludingLineFunction(NOT_DELETED_LINECODE);

        assertNotNull(germplasms);
        assertEquals(1, germplasms.size());
    }

    public void testGetAllGermplasmsMatchingLineCode_GetsDeletedAlso() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        List germplasms = dao.getAllGermplasmsExcludingLineFunction(DELETED_LINECODE);

        assertNotNull(germplasms);
        assertEquals(1, germplasms.size());
    }

    public void testGetAllGermplasmsMatchingLineCodeAndLineFunction_LineFunctionIsNotNull() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NonALineFunctionCriteria(LINE_FUNCTION_REF_ID));
        List germplasms = dao
                .getAllGermplasms(LINECODE_WITH_LINE_FUNCTION);

        assertNotNull(germplasms);
        assertEquals(2, germplasms.size());
    }


    public void testGetAllGermplasmsMatchingLineCodeAndLineFunction_LineFunctionIsNull() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        List germplasms = dao.getAllGermplasms(LINECODE_WITH_NULL_LINE_FUNCTION);

        assertNotNull(germplasms);
        assertEquals(2, germplasms.size());
    }


    public void testGetAllGermplasmsMatchingLineCodeAndLineFunction_LineFunctionEmptyString() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        List germplasms = dao.getAllGermplasms(LINECODE_WITH_NULL_LINE_FUNCTION);

        assertNotNull(germplasms);
        assertEquals(2, germplasms.size());
    }

    public void testGetAllGermplasmsMatchingLineCodeAndLineFunction_LineFunctionIsNull_Failure() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        List germplasms = dao.getAllGermplasms(LINECODE_WITH_LINE_FUNCTION);

        assertNotNull(germplasms);
        assertEquals(0, germplasms.size());
    }

    public void testConstrutorCropNameIsNullThrowsException() throws Exception {
        try {
            new FinishedGermplasmDAO(null, new NullLineFunctionCriteria());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGermplasmDAO.CROP_LINEFUNC_CRITERIA_REQ_MSG) >= 0);
        }
    }

    public void testConstrutorCropNameIsEmptyStringThrowsException() throws Exception {
        try {
            new FinishedGermplasmDAO("", new NullLineFunctionCriteria());
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGermplasmDAO.CROP_LINEFUNC_CRITERIA_REQ_MSG) >= 0);
        }
    }

    public void testGetAllGermplasmsMatchingLineCode_LineCodeIsNullThrowsException() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        try {
            dao.getAllGermplasmsExcludingLineFunction(null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGermplasmDAO.LINECODE_REQ_MSG) >= 0);
        }
    }

    public void testGetAllGermplasmsMatchingLineCode_LineCodeIsEmptyStringThrowsException() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        try {
            dao.getAllGermplasmsExcludingLineFunction("");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGermplasmDAO.LINECODE_REQ_MSG) >= 0);
        }
    }

    public void testGetAllGermplasmsMatchingLineCodeAndLineFunction_LineCodeIsNullThrowsException() throws Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        try {
            dao.getAllGermplasms(null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGermplasmDAO.LINECODE_REQ_MSG) >= 0);
        }
    }

    public void testGetAllGermplasmsMatchingLineCodeAndLineFunction_LineCodeIsEmptyStringThrowsException() throws
            Exception {
        FinishedGermplasmDAO dao = new FinishedGermplasmDAO("Corn", new NullLineFunctionCriteria());
        try {
            dao.getAllGermplasms("");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGermplasmDAO.LINECODE_REQ_MSG) >= 0);
        }
    }
}