package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 3:49:22 PM To change this template use File |
 * Settings | File Templates.
 */
public class CommercialProductNameDAO_UT extends TestIIContextConfigurer {
    private static final String CROP_NAME_CORN = "Corn";
    private static final String CROP_NAME_TOMATO = "Tomato";
    private static final String COUNTRY_NAME = "United States of America";
    private Session session;
    private TestHelper testHelper;
    private Product testProduct1;
    private Product testProduct2;
    private Product testProduct3;

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
        createProductNames();
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetProductListMatchingProducts_ValidProductAndCrop_ReturnTwoRecords() {
        CommercialProductNameDAO productNameDAO = new CommercialProductNameDAO(CROP_NAME_CORN);
        List<Product> productList = new ArrayList<Product>();
        productList.add(testProduct1);
        List list = productNameDAO.getProductListMatchingProducts(productList);
        assertEquals(2, list.size());
    }

    public void testGetProductListMatchingProducts_InValidProductValidCrop_ReturnNoRecord() throws Exception {
        List<Product> productList = new ArrayList<Product>();
        productList.add(testProduct3);
        ProductNameDAO productNameDAO = new CommercialProductNameDAO(CROP_NAME_CORN);
        List list = productNameDAO.getProductListMatchingProducts(productList);
        assertEquals(0, list.size());
    }

    public void testGetProductListMatchingProducts_ValidProductInValidCrop_ReturnNoRecord() throws Exception {
        List<Product> productList = new ArrayList<Product>();
        productList.add(testProduct2);
        CommercialProductNameDAO productNameDAO = new CommercialProductNameDAO(CROP_NAME_CORN);
        List list = productNameDAO.getProductListMatchingProducts(productList);
        assertEquals(0, list.size());
    }

    private void createProductNames() {
        testProduct1 = testHelper.createProduct(CROP_NAME_CORN, "T");
        testProduct2 = testHelper.createProduct(CROP_NAME_TOMATO, "T");
        testProduct3 = testHelper.createProduct(CROP_NAME_CORN, "T");
        testHelper.createProductName("PRODUCTABC1", "T", "MONSANTO", "MONSANTO", COUNTRY_NAME, testProduct1);
        testHelper.createProductName("PRODUCTABC2", "T", "PAYMASTER", "MONSANTO", COUNTRY_NAME, testProduct1);
        testHelper.createProductName("PRODUCTABC3", "T", "MYCOGEN", "DOW", COUNTRY_NAME, testProduct1);
        testHelper.createProductName("PRODUCTABC4", "T", "MONSANTO", "MONSANTO", COUNTRY_NAME, testProduct2);
        testHelper.createProductName("PRODUCTABC5", "T", "PAYMASTER", "MONSANTO", COUNTRY_NAME, testProduct2);
    }
}