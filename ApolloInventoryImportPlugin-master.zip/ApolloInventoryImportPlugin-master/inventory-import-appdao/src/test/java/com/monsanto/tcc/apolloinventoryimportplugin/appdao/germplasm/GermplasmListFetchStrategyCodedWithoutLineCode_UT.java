package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.google.common.collect.Lists;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.SimpleExpression;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.List;

import static org.hamcrest.Matchers.sameInstance;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by Dan Schnettgoecke on 6/18/12 at 11:13 AM.
 */

public class GermplasmListFetchStrategyCodedWithoutLineCode_UT {

    private GermplasmListFetchStrategyCodedWithoutLineCode germplasmListFetchStrategyCodedWithoutLineCode;
    @Mock
    private Session session;
    @Mock
    private Criteria criteria;
    @Mock
    private LineFunctionCriteria lineFunctionCriteria;


    @Before
    public void setup() {
        initMocks(this);
        germplasmListFetchStrategyCodedWithoutLineCode = new MockGermplasmListFetchStrategyCodedWithoutLineCode();
    }

    @Test
    public void doStuffForCodeCoverage() {
        List germplasms = Lists.newArrayList();
        StagingInventory stagingInventory = getTestStagingInventory();
        when(session.createCriteria(Germplasm.class, "gp")).thenReturn(criteria);
        when(criteria.add(any(SimpleExpression.class))).thenReturn(criteria);
        when(criteria.createAlias(anyString(), anyString())).thenReturn(criteria);
        when(criteria.list()).thenReturn(germplasms);

        List result = germplasmListFetchStrategyCodedWithoutLineCode.getGermplasms(stagingInventory);

        assertThat(result, sameInstance(germplasms));
    }

    private StagingInventory getTestStagingInventory() {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("butter");
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        stagingInventory.setOrigin("origin");
        return stagingInventory;
    }

    private class MockGermplasmListFetchStrategyCodedWithoutLineCode extends GermplasmListFetchStrategyCodedWithoutLineCode {
        @Override
        protected Session getCurrentSession() {
            return session;
        }

        @Override
        protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
            return lineFunctionCriteria;
        }
    }
}