/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.SimpleStagingInventoryByStatusCodesFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.StagingInventoryByStatusCodesFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

/**
 * Filename: $Id: SimpleStagingInventoryByStatusCodesFetchStrategy_UT.java,v 1.1 2008-02-21 20:34:02 srkarna Exp $
 *
 * @author APATRO
 * @version $Revision: 1.1 $
 */
public class SimpleStagingInventoryByStatusCodesFetchStrategy_UT extends TestIIContextConfigurer {

    MockStagingInventoryData testInventoryData;
    private Session session;

    public void setUp() throws Exception {
        testInventoryData = new MockStagingInventoryData();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
        session.getTransaction().rollback();
    }

    public void testGetStagingInventoryRecords_AtLeatsOne() {
        testInventoryData.createApprovedStagingInventory();

        StagingInventoryByStatusCodesFetchStrategy dao = new SimpleStagingInventoryByStatusCodesFetchStrategy();
        String[] statusCodes = new String[]{"Rejected"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length > 0);
    }

    public void testGetStagingInventoryRecords_LimitToAParticularSize() {
        testInventoryData.createApprovedStagingInventory();

        final int fetchSize = 5;
        StagingInventoryByStatusCodesFetchStrategy dao = new SimpleStagingInventoryByStatusCodesFetchStrategy(fetchSize);
        String[] statusCodes = new String[]{"Rejected"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length > 0);
        assertTrue(stagingInventory.length <= fetchSize);
    }

    public void testGetStagingInventoryRecords_None() {
        testInventoryData.createApprovedStagingInventory();

        StagingInventoryByStatusCodesFetchStrategy dao = new SimpleStagingInventoryByStatusCodesFetchStrategy();
        String[] statusCodes = new String[]{"Junk"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length == 0);
    }

    //Ignore - too many stagingInventory returned, plus validation error with older items.
//    public void testGetStagingInventoryRecords_withSubRecords() throws Exception {
//        testInventoryData.createApprovedStagingInventoryWithParentage();
//        testInventoryData.createPendingStagingInventoryWithParentage();
//        testInventoryData.createApprovedStagingInventory();
//        testInventoryData.createPendingStagingInventory();
//
//        String[] statusCodes = new String[]{"Approved", "Pending"};
//        StagingInventoryByStatusCodesFetchStrategy dao = new SimpleStagingInventoryByStatusCodesFetchStrategy();
//        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
//
//        int subRecordCount = 0;
//        Set spIdSet = new HashSet<Long>();
//        for (int i = 0; i < stagingInventory.length; i++) {
//            StagingInventory si = (StagingInventory) stagingInventory[i];
//            Set sps = si.getStagingParentage();
//            if (sps != null) {
//                subRecordCount += sps.size();
//                for (Object sp : sps) {
//                    spIdSet.add(((StagingParentage) sp).getId());
//                }
//            }
//        }
//
//        Query query = session.createQuery(
//                "select count(sp) from StagingParentage sp, StagingInventory si, ImportStatus ist where ist.statusCode in (:statusCodes) and si.importStatus = ist and sp.mainInventory = si");
//        query.setParameterList("statusCodes", statusCodes);
//        Long dbSubRecordCount = (Long) query.uniqueResult();
//
//        assertEquals(spIdSet.size(), subRecordCount);
//    }

}
