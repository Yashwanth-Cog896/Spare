package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Jul 7, 2010
 * Time: 4:58:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy_UT extends TestIIContextConfigurer {

    MockStagingInventoryData testInventoryData;
    private Session session;

    public void setUp() throws Exception {
        testInventoryData = new MockStagingInventoryData();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
        session.getTransaction().rollback();
    }

    public void testGetStagingInventoryRecords_AtLeatsOne() {
        testInventoryData.createApprovedStagingInventory();

        StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy dao = new StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy();
        String[] statusCodes = new String[]{"Rejected"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length > 0);
    }

    public void testGetStagingInventoryRecords_LimitToAParticularSize() {
        testInventoryData.createApprovedStagingInventory();

        final int fetchSize = 5;
        StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy dao = new StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy(fetchSize);
        String[] statusCodes = new String[]{"Rejected"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length > 0);
        assertTrue(stagingInventory.length <= fetchSize);
    }

    public void testGetStagingInventoryRecords_None() {
        testInventoryData.createApprovedStagingInventory();

        StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy dao = new StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy();
        String[] statusCodes = new String[]{"Junk"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length == 0);
    }

}