package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.verifyStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(HibernateUtil.class)
public class GermplasmListFetchStrategyFinishedWithoutLineCode_UT {

    @Mock
    private SessionFactory mockSessionFactory;

    @Mock
    private Session mockSession;

    @Mock
    private Criteria mockCriteria;

    GermplasmListFetchStrategyFinishedWithoutLineCode germplasmListFetchStrategyFinishedWithoutLineCode = new GermplasmListFetchStrategyFinishedWithoutLineCode();

    @Before
    public void setUp() {
        mockStatic(HibernateUtil.class);
        when(HibernateUtil.getSessionFactoryForMidasCentral()).thenReturn(mockSessionFactory);
        when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
        when(mockSession.createCriteria(isA(Class.class), anyString())).thenReturn(mockCriteria);
        when(mockCriteria.add(any(Criterion.class))).thenReturn(mockCriteria);
        when(mockCriteria.createAlias(anyString(), anyString())).thenReturn(mockCriteria);
    }

@Test
    public void verifyHibernateUtilGetCurrentSessionCalled() throws Exception {
        germplasmListFetchStrategyFinishedWithoutLineCode.getGermplasms(createStagingInventory());
        verifyStatic(times(1));
    }

    @Test
    public void verifyCriteriaCorrect() throws Exception {
        germplasmListFetchStrategyFinishedWithoutLineCode.getGermplasms(createStagingInventory());
        verify(mockSession, times(1)).createCriteria(com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm.class, "gp");
        verify(mockCriteria, times(4)).add(any(Criterion.class));
    }

    @Test
    public void verifyStagingInventoryDataInCriteria() throws Exception {
        StagingInventory stagingInventory = createStagingInventory();
        stagingInventory.setOrigin("xxx");
        germplasmListFetchStrategyFinishedWithoutLineCode.getGermplasms(stagingInventory);
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.eq("gp.origin", stagingInventory.getOrigin()))));
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))));
    }

    @Test
    public void VerifyLineFunctionNullCriteriaAdded() throws Exception {
        germplasmListFetchStrategyFinishedWithoutLineCode.getGermplasms(createStagingInventory());
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.isNull("gp.lineFunction"))));
    }

    @Test
    public void VerifyNonALineFunctionNullCriteriaAdded() throws Exception {
        StagingInventory stagingInventory = createStagingInventory();
        stagingInventory.setLineFunction("x");
        germplasmListFetchStrategyFinishedWithoutLineCode.getGermplasms(stagingInventory);
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.eq("lfunc.lineFunctionRefId", stagingInventory.getLineFunction()))));
    }

    @Test
    public void verifyNullDefaultLineStrategy() throws Exception {
        StagingInventory stagingInventory = createStagingInventory();
        stagingInventory.setLineFunction(null);
        LineFunctionCriteria lineFunctionCriteria = germplasmListFetchStrategyFinishedWithoutLineCode.getDefaultLineFunctionCriteria(stagingInventory);
        assertThat(lineFunctionCriteria, is(NullLineFunctionCriteria.class));
    }

    private StagingInventory createStagingInventory() {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("Corn");
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        return stagingInventory;
    }

    class MatchCriteria extends ArgumentMatcher<Criterion> {
        Object arg;

        public MatchCriteria(Object arg) {
            this.arg = arg;
        }

        @Override
        public boolean matches(Object criterion) {
            if (!(criterion instanceof Criterion)) {
                return false;
            }
            if (!criterion.toString().equals(arg.toString())) {
                return false;
            }
            return true;
        }
    }
}
