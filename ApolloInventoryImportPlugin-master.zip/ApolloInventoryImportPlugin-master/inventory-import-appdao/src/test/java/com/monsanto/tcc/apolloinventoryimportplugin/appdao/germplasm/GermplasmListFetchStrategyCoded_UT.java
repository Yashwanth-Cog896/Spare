package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.verifyStatic;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(HibernateUtil.class)
public class GermplasmListFetchStrategyCoded_UT {

    @Mock
    private SessionFactory mockSessionFactory;

    @Mock
    private Session mockSession;

    @Mock
    private Criteria mockCriteria;

    GermplasmListFetchStrategyCoded germplasmListFetchStrategyCoded = new GermplasmListFetchStrategyCoded();

    @Before
    public void setUp() {
        mockStatic(HibernateUtil.class);
        when(HibernateUtil.getSessionFactoryForMidasCentral()).thenReturn(mockSessionFactory);
        when(mockSessionFactory.getCurrentSession()).thenReturn(mockSession);
        when(mockSession.createCriteria(isA(Class.class), anyString())).thenReturn(mockCriteria);
        when(mockCriteria.add(any(Criterion.class))).thenReturn(mockCriteria);
        when(mockCriteria.createAlias(anyString(), anyString())).thenReturn(mockCriteria);
    }

    @Test
    public void verifyHibernateUtilGetCurrentSessionCalled() throws Exception {
        germplasmListFetchStrategyCoded.getGermplasms(createStagingInventory());
        verifyStatic(times(1));
    }

    @Test
    public void verifyCriteriaCorrect() throws Exception {
        germplasmListFetchStrategyCoded.getGermplasms(createStagingInventory());
        verify(mockSession, times(1)).createCriteria(Germplasm.class, "gp");
        verify(mockCriteria, times(7)).add(any(Criterion.class));
    }

    @Test
    public void verifyStagingInventoryDataInCriteria() throws Exception {
        germplasmListFetchStrategyCoded.getGermplasms(createStagingInventory());
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.eq("gp.lineCode", createStagingInventory().getLineCode()))));
    }

    @Test
    public void VerifyLineFunctionNullCriteriaAdded() throws Exception {
        germplasmListFetchStrategyCoded.getGermplasms(createStagingInventory());
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.isNull("gp.lineFunction"))));
    }

    @Test
    public void VerifyNonALineFunctionNullCriteriaAdded() throws Exception {
        StagingInventory stagingInventory = createStagingInventory();
        stagingInventory.setLineFunction("x");
        germplasmListFetchStrategyCoded.getGermplasms(stagingInventory);
        verify(mockCriteria, times(1)).add(argThat(new MatchCriteria(Restrictions.eq("lfunc.lineFunctionRefId", stagingInventory.getLineFunction()))));
    }

    @Test
    public void verifyNullDefaultLineStrategy() throws Exception {
        StagingInventory stagingInventory = createStagingInventory();
        stagingInventory.setLineFunction(null);
        LineFunctionCriteria lineFunctionCriteria = germplasmListFetchStrategyCoded.getDefaultLineFunctionCriteria(stagingInventory);
        assertThat(lineFunctionCriteria, is(NullLineFunctionCriteria.class));
    }

    private StagingInventory createStagingInventory() {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("Corn");
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        return stagingInventory;
    }

    class MatchCriteria extends ArgumentMatcher<Criterion> {
        Object arg;

        public MatchCriteria(Object arg) {
            this.arg = arg;
        }

        @Override
        public boolean matches(Object criterion) {
            if (!(criterion instanceof Criterion)) {
                return false;
            }
            if (!criterion.toString().equals(arg.toString())) {
                return false;
            }
            return true;
        }
    }
}


/*
public class GermplasmListFetchStrategyCoded extends AbstractGermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        LineFunctionCriteria lineFunctionCriteria = getDefaultLineFunctionCriteria(stagingInventory);
        return getExistingCodedGermplasmList(stagingInventory, lineFunctionCriteria);
    }

    protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
        return lineFunctionCriteria;
    }

    public List getExistingCodedGermplasmList(StagingInventory stagingInventory,
                                              LineFunctionCriteria lineFunctionCriteria) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = getGermplasmsCriteria(stagingInventory, session);
        addLineFunictionCriteria(lineFunctionCriteria, criteria);
        return criteria.list();
    }

    private void addLineFunictionCriteria(LineFunctionCriteria lineFunctionCriteria, Criteria criteria) {
        lineFunctionCriteria.addCriteria("gp", criteria);
    }


    @Override
    protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.lineCode", stagingInventory.getLineCode()))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", MaterialTypeConstants.CODED_LINES))
                .add(Restrictions.eq("lt.refActive", "T"))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))
                .add(Restrictions.eq("cr.refActive", "T"));
        return criteria;
    }
}
*/