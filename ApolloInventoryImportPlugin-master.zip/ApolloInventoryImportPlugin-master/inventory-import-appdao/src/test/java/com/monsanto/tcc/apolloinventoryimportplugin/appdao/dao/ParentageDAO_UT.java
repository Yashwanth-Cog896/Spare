package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ParentalRole;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Jan 19, 2010
 * Time: 3:31:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class ParentageDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;

    public void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testParentInventoriesExist() {
        String ownerProgram = "9Z";
        Germplasm germplasm = testHelper.createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, "test", "testPedgree", ownerProgram, "Tomato");
        GeneticMaterial childGeneticMaterial = testHelper.createGeneticMaterial(germplasm, "SRC", "F1", "");
        GeneticMaterial parentGeneticMaterial = testHelper.createGeneticMaterial(germplasm, "PSRC", "F1", "");
        ParentalRole parentalRole = new ParentageDAO().getParentalRole("F");

        Parentage parentage = testHelper.createParentage(childGeneticMaterial, parentGeneticMaterial, "F");
        session.save(parentage);


        ParentageDAO parentageDAO = new ParentageDAO();
        boolean exists = parentageDAO.isParentageExists(childGeneticMaterial, parentGeneticMaterial, parentalRole);
        assertTrue(exists);
//
//        Inventory inventory3 = testHelper.createInventory(geneticMaterial, "F", "TR");
//        Inventory inventory4 = testHelper.createInventory(geneticMaterial, "F", "TR");
//        parentInventoryDAO = new ParentInventoryDAO();
//        exists = parentInventoryDAO.isParentInventoryExists(inventory3, inventory4);
//        assertFalse(exists);
    }
}

