package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProcessName_UT {
    ProcessName processName;

    @Before
    public void setUp() throws Exception {
        processName = new ProcessName();
    }

    @Test
    public void testSettersAndGetters() throws Exception {
        Long id = -867l;
        String desc = "description";
        String name = "name";

        processName.setId(id);
        processName.setDescription(desc);
        processName.setName(name);

        assertEquals(id, processName.getId());
        assertEquals(desc, processName.getDescription());
        assertEquals(name, processName.getName());
    }
}
