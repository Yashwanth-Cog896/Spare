/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;

/**
 * Filename:    $RCSfile: NullLineFunctionCriteria_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $ On:	$Date: 2008-02-17 22:58:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NullLineFunctionCriteria_UT extends TestIIContextConfigurer {
    private Session session;

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testAddCriteriaAddLineFunctionIsNullRestriction() throws Exception {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp");

        LineFunctionCriteria lineFunctionCriteria = new NullLineFunctionCriteria();

        assertFalse(criteria.toString().toLowerCase().indexOf("gp.linefunction is null") >= 0);

        lineFunctionCriteria.addCriteria(criteria.getAlias(), criteria);

        assertTrue(criteria.toString().toLowerCase().indexOf("gp.linefunction is null") >= 0);
    }

    public void testAddStagingInventoryCriteriaAddLineFunctionIsNullRestriction() throws Exception {
        Criteria criteria = session.createCriteria(StagingInventory.class, "si");

        LineFunctionCriteria lineFunctionCriteria = new NullLineFunctionCriteria();

        assertFalse(criteria.toString().toLowerCase().indexOf("si.linefunction is null") >= 0);

        lineFunctionCriteria.addCriteria(criteria.getAlias(), criteria);

        assertTrue(criteria.toString().toLowerCase().indexOf("si.linefunction is null") >= 0);
    }
}