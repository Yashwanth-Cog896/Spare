package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class Germplasm_UT {
    Germplasm testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new Germplasm();
    }

    @Test
    public void testSettersAndGetters() throws Exception {
        String constructDisplay = "construct";
        Crop crop = new Crop();
        crop.setCropId(-3l);
        String cytoplasmDonor = "cytoplasmDonor";
        String deleted = "d";
        String eventDisplay = "event";
        String finishedOrFinishedChild = "finishedChild";
        Set germplasmEvent = new HashSet();
        Set germplasmRoyalties = new HashSet();
        String isTransgenic = "transgenic";
        String lineCode = "lineCode";
        LineFunction lineFunction = new LineFunction();
        LineType lineType = new LineType();
        String oldPedigree = "oldPedigree";
        String origin = "origin";
        BrProg ownerBrProg = new BrProg();
        String pedigreeName = "pedigree";
        String transgenic = "transgenic";

        testObject.setConstructDisplay(constructDisplay);
        testObject.setCrop(crop);
        testObject.setCytoplasmDonor(cytoplasmDonor);
        testObject.setDeleted(deleted);
        testObject.setEventDisplay(eventDisplay);
        testObject.setFinishedOrFinishedChild(finishedOrFinishedChild);
        testObject.setGermplasmEventConstruct(germplasmEvent);
        testObject.setGermplasmRoyalty(germplasmRoyalties);
        testObject.setIsTransgenic(isTransgenic);
        testObject.setLineCode(lineCode);
        testObject.setLineFunction(lineFunction);
        testObject.setLineType(lineType);
        testObject.setOldPedigree(oldPedigree);
        testObject.setOrigin(origin);
        testObject.setOwnerBrProg(ownerBrProg);
        testObject.setPedigreeName(pedigreeName);
        testObject.setTransgenic(transgenic);

        assertEquals(constructDisplay, testObject.getConstructDisplay());
        assertEquals(crop, testObject.getCrop());
        assertEquals(cytoplasmDonor, testObject.getCytoplasmDonor());
        assertEquals(deleted, testObject.getDeleted());
        assertEquals(eventDisplay, testObject.getEventDisplay());
        assertEquals(finishedOrFinishedChild, testObject.getFinishedOrFinishedChild());
        assertEquals(germplasmEvent, testObject.getGermplasmEventConstruct());
        assertEquals(germplasmRoyalties, testObject.getGermplasmRoyalty());
        assertEquals(isTransgenic, testObject.getIsTransgenic());
        assertEquals(lineCode, testObject.getLineCode());
        assertEquals(lineFunction, testObject.getLineFunction());
        assertEquals(lineType, testObject.getLineType());
        assertEquals(oldPedigree, testObject.getOldPedigree());
        assertEquals(origin, testObject.getOrigin());
        assertEquals(ownerBrProg, testObject.getOwnerBrProg());
        assertEquals(pedigreeName, testObject.getPedigreeName());
        assertEquals(transgenic, testObject.getTransgenic());
    }
}
