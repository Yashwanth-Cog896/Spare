/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import junit.framework.TestCase;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author vvkalu
 * @version $Revision$
 */
public class TestIIContextConfigurer extends TestCase {

    final static String[] contextURL = {"classpath:com/monsanto/tcc/apolloinventoryimportplugin/appdao/hibernate/contexts/application-context.xml",
            "classpath:com/monsanto/tcc/apolloinventoryimportplugin/appdao/hibernate/contexts/spring-properties-context.xml",
            "classpath:com/monsanto/tcc/apolloinventoryimportplugin/appdao/hibernate/contexts/hibernate-context.xml"};
    static ApplicationContext context;

    static {
        if (context == null)
            context = new ClassPathXmlApplicationContext(contextURL);
    }

    public TestIIContextConfigurer() {
        super();
    }

    public TestIIContextConfigurer(String name) {
        super(name);
    }
}