/*
 UnfinishedHybridGermplasmDTOList_UT was created on May 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: UnfinishedHybridGermplasmDTOList_UT.java,v $ Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-10 15:59:37 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class UnfinishedHybridGermplasmDTOList_UT extends TestIIContextConfigurer {
    public static final String MATCHING_ORIGIN = "XYZ+ABC";

    public UnfinishedHybridGermplasmDTOList_UT(String name) {
        super(name);
    }

    public void testCreateUnfinishedHybridGermplasmDTOListWithNoData() throws Exception {
        UnfinishedHybridGermplasmDTOList unfinishedHybridGermplasmDTOList = new UnfinishedHybridGermplasmDTOList(null);
        String arbitraryOrigin = null;
        String arbitraryGPOwner = null;
        String arbitraryIsDeletedFlag = null;

        assertNull(unfinishedHybridGermplasmDTOList.get(arbitraryOrigin, arbitraryGPOwner, arbitraryIsDeletedFlag));
        assertEquals(0, unfinishedHybridGermplasmDTOList.size());
        assertEquals(0, unfinishedHybridGermplasmDTOList.getOverallCountOfGermplasms());
    }

    public void testFindAMatchRecordInTheList() throws Exception {
        UnfinishedHybridGermplasmDTOList unfinishedHybridGermplasmDTOList = createUnfinishedHybridGermplasmDTOList();
        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO = unfinishedHybridGermplasmDTOList
                .get(MATCHING_ORIGIN, "17", UnfinishedHybridGermplasmDTO.ACTIVE_FLAG);

        assertNotNull(unfinishedHybridGermplasmDTO);
        assertEquals(1, unfinishedHybridGermplasmDTO.getCount());
    }

    public void testCounts() throws Exception {
        UnfinishedHybridGermplasmDTOList unfinishedHybridGermplasmDTOList = createUnfinishedHybridGermplasmDTOList();

        assertEquals(9, unfinishedHybridGermplasmDTOList.getOverallCountOfGermplasms());
        assertEquals(5, unfinishedHybridGermplasmDTOList.size());
    }

    private UnfinishedHybridGermplasmDTOList createUnfinishedHybridGermplasmDTOList() {
        List germplasmList = new ArrayList();

        germplasmList
                .add(createUnfinishedHybridGermplasmDTO(MATCHING_ORIGIN, "17", UnfinishedHybridGermplasmDTO.ACTIVE_FLAG, 1));
        germplasmList.add(
                createUnfinishedHybridGermplasmDTO(MATCHING_ORIGIN, "17", UnfinishedHybridGermplasmDTO.NOT_ACTIVE_FLAG, 3));
        germplasmList
                .add(createUnfinishedHybridGermplasmDTO(MATCHING_ORIGIN, "18", UnfinishedHybridGermplasmDTO.ACTIVE_FLAG, 1));
        germplasmList.add(
                createUnfinishedHybridGermplasmDTO(MATCHING_ORIGIN, "18", UnfinishedHybridGermplasmDTO.NOT_ACTIVE_FLAG, 3));
        germplasmList
                .add(createUnfinishedHybridGermplasmDTO(MATCHING_ORIGIN, "19", UnfinishedHybridGermplasmDTO.ACTIVE_FLAG, 1));

        return new UnfinishedHybridGermplasmDTOList(germplasmList);
    }

    private UnfinishedHybridGermplasmDTO createUnfinishedHybridGermplasmDTO(String origin, String germplasmOwner,
                                                                            String isDeleted, int isDeletedCount) {
        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO = new UnfinishedHybridGermplasmDTO();
        unfinishedHybridGermplasmDTO.setOrigin(origin);
        unfinishedHybridGermplasmDTO.setBrProgRefId(germplasmOwner);
        unfinishedHybridGermplasmDTO.setDeleted(isDeleted);
        unfinishedHybridGermplasmDTO.setCount(isDeletedCount);

        return unfinishedHybridGermplasmDTO;
    }

}