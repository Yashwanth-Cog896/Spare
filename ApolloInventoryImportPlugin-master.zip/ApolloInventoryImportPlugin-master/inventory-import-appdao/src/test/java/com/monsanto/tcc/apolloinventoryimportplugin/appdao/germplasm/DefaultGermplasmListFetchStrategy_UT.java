package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.google.common.collect.Lists;
import org.junit.Test;

import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Created by Dan Schnettgoecke on 6/18/12 at 10:02 AM.
 */

public class DefaultGermplasmListFetchStrategy_UT {

    @Test
    public void doStuffForCodeCoverage() {
        GermplasmListFetchStrategy germplasmListFetchStrategy = new DefaultGermplasmListFetchStrategy();
        assertTrue(germplasmListFetchStrategy.getGermplasms(null).equals(Lists.newArrayList()));
        assertTrue(germplasmListFetchStrategy.getGermplasmsWithActiveRoyalties(null).equals(Lists.newArrayList()));
        assertThat(germplasmListFetchStrategy.getGermplasmsListFetchCriteria(null), nullValue());
    }
}