package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.MeasurementUOM;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.UnitOfMeasure;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: 8/5/11
 * Time: 12:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class MeasurementUOMDao_UT extends TestIIContextConfigurer {

    Session session;


    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        if (session != null && session.isOpen()) {
            session.getTransaction().rollback();
        }
        super.tearDown();
    }

    @Test
    public void testSeedUnitOfMeasure() {
        UnitOfMeasure unitOfMeasure = (UnitOfMeasure) session.createCriteria(UnitOfMeasure.class).add(Restrictions.eq("name", "Pounds")).setMaxResults(1).uniqueResult();
        MeasurementUOMDao measurementUOMDao = new MeasurementUOMDao();
        MeasurementUOM englishMeasurementUOMByUomId = measurementUOMDao.getEnglishMeasurementUOMByUomId(unitOfMeasure.getUomId());
        assertTrue(englishMeasurementUOMByUomId.getPrecisionAllowed().equals("T"));
    }


}
