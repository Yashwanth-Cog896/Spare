/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.test;

import junit.framework.TestCase;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.KeysFolderNameResolver;

import java.util.Properties;

/**
 * Filename:    $RCSfile: KeysFolderNameResolver_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-09-10 16:01:18 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class KeysFolderNameResolver_UT extends TestCase {
  private static final String NON_QA_FOLDER_NAME = "inventoryimport";
  private static final String QA_FOLDER_NAME = "inventoryimport-qa";
  private static final String KEYS_FOLDER_PROPERTY_PREFIX = "keysfolder.";
  private Properties properties;

  protected void setUp() throws Exception {
    super.setUp();
    properties = new Properties();
    properties.setProperty(KEYS_FOLDER_PROPERTY_PREFIX + "win", NON_QA_FOLDER_NAME);
    properties.setProperty(KEYS_FOLDER_PROPERTY_PREFIX + "dev", NON_QA_FOLDER_NAME);
    properties.setProperty(KEYS_FOLDER_PROPERTY_PREFIX + "test", NON_QA_FOLDER_NAME);
    properties.setProperty(KEYS_FOLDER_PROPERTY_PREFIX + "QA", QA_FOLDER_NAME);
    properties.setProperty(KEYS_FOLDER_PROPERTY_PREFIX + "prod", NON_QA_FOLDER_NAME);
    properties.setProperty(KEYS_FOLDER_PROPERTY_PREFIX + "PostProd", NON_QA_FOLDER_NAME);
  }

  public void testGetKeyFolderForNull() throws Exception {
    try {
      new KeysFolderNameResolver().getKeyFolder(properties, null);
      fail("Expected Exception because lsi function is null");
    } catch(IllegalArgumentException e) {
      assertTrue(e.getMessage().indexOf("required") > -1);
    }
  }

  public void testGetKeyFolderForEmptyString() throws Exception {
    try {
      new KeysFolderNameResolver().getKeyFolder(properties, "");
      fail("Expected Exception because lsi function is \"\"");
    } catch(IllegalArgumentException e) {
      assertTrue(e.getMessage().indexOf("required") > -1);
    }
  }

  public void testGetKeyFolderForUnknown() throws Exception {
    try {
      new KeysFolderNameResolver().getKeyFolder(properties, "unknown");
      fail("Expected Exception because lsi function \"unknown\" is not defined");
    } catch(IllegalArgumentException e) {
      assertTrue(e.getMessage().indexOf("not defined") > -1);
    }
  }

  public void testGetKeyFolderForWin() throws Exception {
    assertEquals(NON_QA_FOLDER_NAME, new KeysFolderNameResolver().getKeyFolder(properties, "win"));
  }

  public void testGetKeyFolderForDev() throws Exception {
    assertEquals(NON_QA_FOLDER_NAME, new KeysFolderNameResolver().getKeyFolder(properties, "dev"));
  }

  public void testGetKeyFolderForTest() throws Exception {
    assertEquals(NON_QA_FOLDER_NAME, new KeysFolderNameResolver().getKeyFolder(properties, "test"));
  }

  public void testGetKeyFolderForQA() throws Exception {
    assertEquals(QA_FOLDER_NAME, new KeysFolderNameResolver().getKeyFolder(properties, "QA"));
  }

  public void testGetKeyFolderForProd() throws Exception {
    assertEquals(NON_QA_FOLDER_NAME, new KeysFolderNameResolver().getKeyFolder(properties, "prod"));
  }

  public void testGetKeyFolderForPostProd() throws Exception {
    assertEquals(NON_QA_FOLDER_NAME, new KeysFolderNameResolver().getKeyFolder(properties, "PostProd"));
  }

  public void testGetKeyFolderForPostProd_CaseInsensitive() throws Exception {
    try {
      new KeysFolderNameResolver().getKeyFolder(properties, "pOsTPRod");
      fail("Expected Exception because lsi function \"pOsTPRod\" is not defined");
    } catch(IllegalArgumentException e) {
      assertTrue(e.getMessage().indexOf("not defined") > -1);
    }
  }
}