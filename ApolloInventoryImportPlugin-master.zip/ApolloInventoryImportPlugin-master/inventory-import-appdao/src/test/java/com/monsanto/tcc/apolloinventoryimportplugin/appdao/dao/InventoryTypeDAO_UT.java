/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;
/**
 *
 * Filename:    $RCSfile: InventoryTypeDAO_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-02-18 04:26:05 $
 * @version $Revision: 1.1 $
 * @author apatro
 */

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.InventoryType;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;

public class InventoryTypeDAO_UT extends TestIIContextConfigurer {
    protected void setUp() throws Exception {
        super.setUp();

        HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession().beginTransaction();
    }

    protected void tearDown() throws Exception {
        HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession().getTransaction().rollback();

        super.tearDown();
    }

    public void testGetInventoryTypeThrowsExceptionWhenLineTypeMissing() {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = null;
        String cropName = "Corn";

        try {
            dao.getInventoryType(lineType, cropName);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(InventoryTypeDAO.LINE_TYPE_AND_CROP_NAME_REQUIRED_MSG) >= 0);
        }
    }

    public void testGetInventoryTypeThrowsExceptionWhenCropNameMissing() {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = "Segpop";
        String cropName = null;

        try {
            dao.getInventoryType(lineType, cropName);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(InventoryTypeDAO.LINE_TYPE_AND_CROP_NAME_REQUIRED_MSG) >= 0);
        }
    }

    public void testGetInventoryTypeThrowsExceptionWhenInvalidLineTypeSpecified() {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = "Junk";
        String cropName = "Corn";

        try {
            dao.getInventoryType(lineType, cropName);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(InventoryTypeDAO.INVALID_LINE_TYPE_MSG) >= 0);
        }
    }

    public void testGetInventoryTypeForLineType_Finished() throws Exception {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = "Finished";
        String cropName = "Corn";

        InventoryType inventotyType = dao.getInventoryType(lineType, cropName);
        assertNotNull(inventotyType);

        assertEquals("INBRED", inventotyType.getLineTypeRefId());
    }

    public void testGetInventoryTypeForLineType_Coded() throws Exception {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = "Coded";
        String cropName = "Corn";

        InventoryType inventotyType = dao.getInventoryType(lineType, cropName);
        assertNotNull(inventotyType);

        assertEquals("SEGPOP", inventotyType.getLineTypeRefId());
    }

    public void testGetInventoryTypeForLineType_Hybrid() throws Exception {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = "Hybrid";
        String cropName = "Corn";

        InventoryType inventotyType = dao.getInventoryType(lineType, cropName);
        assertNotNull(inventotyType);

        assertEquals("HYBRID", inventotyType.getLineTypeRefId());
    }

    public void testGetInventoryTypeForLineType_Segpop() throws Exception {
        InventoryTypeDAO dao = new InventoryTypeDAO();

        String lineType = "Segpop";
        String cropName = "Corn";

        InventoryType inventotyType = dao.getInventoryType(lineType, cropName);
        assertNotNull(inventotyType);

        assertEquals("SEGPOP", inventotyType.getLineTypeRefId());
    }
}