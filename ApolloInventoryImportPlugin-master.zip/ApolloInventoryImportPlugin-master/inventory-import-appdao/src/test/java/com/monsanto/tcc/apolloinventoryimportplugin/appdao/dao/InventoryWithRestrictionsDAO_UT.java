/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;


import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.test.MockStagingInventoryData;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;
import org.junit.Ignore;

import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: InventoryWithRestrictionsDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * AAGOSW $ On:	$Date: 2008-03-10 19:10:16 $
 *
 * @author SSPEYY
 * @version $Revision: 1.6 $
 */
public class InventoryWithRestrictionsDAO_UT extends TestIIContextConfigurer {
    private static final String USER_ID = "XYZ";
    private static final String USER_ID_FOR_PENDING_AUTHORITY = "Antwerp";
    private static final String MATERIAL_TYPE_FOR_NEW_AND_VALID = MaterialTypeConstants.COMMERCIAL_PRODUCT;
    private static final String MATERIAL_TYPE_FOR_PENDING = MaterialTypeConstants.SEGPOP_LINES;
    private static final String CROP_NAME = "Corn";
    private Session session;

    protected void setUp() throws Exception {
        super.setUp();
        MockStagingInventoryData mockStagingInventoryData = new MockStagingInventoryData();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        mockStagingInventoryData.createNewStagingInventoryForUser(USER_ID);
        mockStagingInventoryData.createValidStagingInventoryForUserImportType(USER_ID, MATERIAL_TYPE_FOR_NEW_AND_VALID);
        mockStagingInventoryData.createPendingStagingInventoryWithParentage();
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetInventoryDataForMoreThanOneStatus() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.IMPORTED, StagingInventoryStatusConstants.VALID};

        boolean newFlag = false;
        boolean validFlag = false;

        List data = new InventoryWithRestrictionsDAO(USER_ID, CROP_NAME, MATERIAL_TYPE_FOR_NEW_AND_VALID)
                .getStagingInventoryRecords(statusList);
        assertTrue(data.size() > 0);
        for (int i = 0; i < data.size(); i++) {
            StagingInventory stagingInventory = (StagingInventory) data.get(i);
            if (StagingInventoryStatusConstants.VALID.equals(stagingInventory.getImportStatus().getStatusCode()))
                validFlag = true;
            if (StagingInventoryStatusConstants.IMPORTED.equals(stagingInventory.getImportStatus().getStatusCode()))
                newFlag = true;
        }
        assertTrue(newFlag && validFlag);
    }

    public void testGetStagingInventoryMainRecords() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.VALID};

        List stagingInventoryList = new InventoryWithRestrictionsDAO(USER_ID, CROP_NAME, MATERIAL_TYPE_FOR_NEW_AND_VALID)
                .getStagingInventoryMainRecords(statusList, null);
        assertEquals(2, stagingInventoryList.size());
    }

    public void testGetStagingInventoryMainRecordsForAuthority() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.PENDING};

        List stagingInventoryList = new InventoryWithRestrictionsDAO(USER_ID_FOR_PENDING_AUTHORITY, CROP_NAME, MATERIAL_TYPE_FOR_PENDING)
                .getStagingInventoryMainRecordsForAuthority(statusList, null);
        assertEquals(1, stagingInventoryList.size());
        assertEquals(2, ((StagingInventory) stagingInventoryList.get(0)).getStagingParentage().size());
    }

    public void testGetStagingInventoryMainRecords_ReturnsZeroRecordsForNonMatchingCrop() throws Exception {
        final String cropName = "DummyCrop";
        String[] statusList = {StagingInventoryStatusConstants.PENDING};

        List stagingInventoryList = new InventoryWithRestrictionsDAO(USER_ID_FOR_PENDING_AUTHORITY, cropName, MATERIAL_TYPE_FOR_PENDING)
                .getStagingInventoryMainRecords(statusList, null);
        assertEquals(0, stagingInventoryList.size());
    }

    public void testCheckFileAlreadyImported() throws Exception {
        String fileName = "ValidStagingInventory.xls";
        assertTrue(
                new InventoryWithRestrictionsDAO(USER_ID, CROP_NAME, MATERIAL_TYPE_FOR_NEW_AND_VALID).checkFileAlreadyImported(fileName));
    }

    public void testCheckFileAlreadyImportedWithNullArgument() throws Exception {
        try {
            new InventoryWithRestrictionsDAO(USER_ID, CROP_NAME, MATERIAL_TYPE_FOR_NEW_AND_VALID).checkFileAlreadyImported(null);
            fail();
        } catch (IllegalArgumentException e) {
        }
    }

    public void testStagingInventoryGetMainRecordsCountForAuthority() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.PENDING};

        List list = new InventoryWithRestrictionsDAO(USER_ID_FOR_PENDING_AUTHORITY, CROP_NAME, MATERIAL_TYPE_FOR_PENDING)
                .getStagingInventoryMainRecordsCountForAuthority(statusList);
        int count = 0;
        for (Iterator iter = list.iterator(); iter.hasNext();) {
            Object[] row = (Object[]) iter.next();
            if (USER_ID_FOR_PENDING_AUTHORITY.equalsIgnoreCase((String) row[0])) {
                Long countObject = (Long) row[1];
                if (countObject != null)
                    count = countObject.intValue();
            }

        }
        assertEquals(1, count);
    }

    public void testStagingInventoryRecordsCountForAuthority() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.PENDING};

        List list = new InventoryWithRestrictionsDAO(USER_ID_FOR_PENDING_AUTHORITY, CROP_NAME, MATERIAL_TYPE_FOR_PENDING)
                .getStagingInventoryRecordsCountForAuthority(statusList);
        int count = 0;
        for (Iterator iter = list.iterator(); iter.hasNext();) {
            Object[] row = (Object[]) iter.next();
            if (USER_ID_FOR_PENDING_AUTHORITY.equalsIgnoreCase((String) row[0])) {
                Long countObject = (Long) row[1];
                if (countObject != null)
                    count = countObject.intValue();
            }

        }
        assertEquals(3, count);
    }

    public void testGetCountOfAllStagingInventoriesByStatusCode_OneStatusCode() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.PENDING};
        Integer totalCount = new InventoryWithRestrictionsDAO(USER_ID, CROP_NAME, MATERIAL_TYPE_FOR_PENDING)
                .getCountOfAllStagingInventoriesAndParentsByStatusCode(statusList);
        assertEquals(3, totalCount.intValue());
    }

    public void testGetCountOfAllStagingInventoriesByStatusCode_TwoStatusCodes() throws Exception {
        String[] statusList = {StagingInventoryStatusConstants.IMPORTED, StagingInventoryStatusConstants.VALID};
        Integer totalCount = new InventoryWithRestrictionsDAO(USER_ID, CROP_NAME, MATERIAL_TYPE_FOR_NEW_AND_VALID)
                .getCountOfAllStagingInventoriesAndParentsByStatusCode(statusList);
        assertEquals(6, totalCount.intValue());
    }
}