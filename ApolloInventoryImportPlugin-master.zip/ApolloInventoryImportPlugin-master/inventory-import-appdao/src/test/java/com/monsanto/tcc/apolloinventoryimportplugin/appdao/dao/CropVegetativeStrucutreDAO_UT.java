package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Crop;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.CropVegetativeStructure;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: ssnall Date: Mar 9, 2009 Time: 4:27:25 PM To change this template use File | Settings
 * | File Templates.
 */
public class CropVegetativeStrucutreDAO_UT extends TestIIContextConfigurer {

    private Session session;

    @Override
    protected void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
    }

    public void testVegitativeStructureValidatorReturnsTrueWithValidValue() {
        CropVegetativeStrucutreDAO cropVegetativeStrucutreDAO = new MockCropVegetativeStrucutreDAO();
        assertTrue(cropVegetativeStrucutreDAO.isVegetativeStructureValid("Seed", "Corn"));
    }

    public void testVegitativeStructureValidatorReturnsFalseWithInValidValue() {
        CropVegetativeStrucutreDAO cropVegetativeStrucutreDAO = new MockCropVegetativeStrucutreDAO();
        assertFalse(cropVegetativeStrucutreDAO.isVegetativeStructureValid("Bulb", "Corn"));
        assertFalse(cropVegetativeStrucutreDAO.isVegetativeStructureValid("Seed", "Junk"));
    }

    public void testGetVegetativeStructuresByCrop() {
        CropVegetativeStrucutreDAO cropVegetativeStrucutreDAO = new MockCropVegetativeStrucutreDAO();
        List<VegetativeStructure> vegetativeStructureList = cropVegetativeStrucutreDAO
                .getVegetativeStructuresByCrop(Collections.singletonList("Corn"));
        assertEquals(1, vegetativeStructureList.size());
        vegetativeStructureList = cropVegetativeStrucutreDAO
                .getVegetativeStructuresByCrop(Collections.singletonList("Onion"));
        assertEquals(2, vegetativeStructureList.size());
    }

    public void testReturnsTrueCropHasRootOrBulbVegetativeStructures() {
        Crop crop = getValidCrop();
        CropVegetativeStrucutreDAO cropVegetativeStrucutreDAO = new MockCropVegetativeStrucutreDAO();
        assertTrue(cropVegetativeStrucutreDAO.isCropHasBulbOrRootVegetativeStructure(crop.getCropName()));
    }

    public void testReturnsFalseWhenCropDoesNotHasRootOrBulbVegetativeStructures() {
        Crop crop = getInValidCrop();
        CropVegetativeStrucutreDAO cropVegetativeStrucutreDAO = new MockCropVegetativeStrucutreDAO();
        assertFalse(cropVegetativeStrucutreDAO.isCropHasBulbOrRootVegetativeStructure(crop.getCropName()));
    }


    public Crop getValidCrop() {
        ArrayList vegetativeStructures = new ArrayList();
        vegetativeStructures.add("Bulb");
        vegetativeStructures.add("Root");
        Criteria criteria = session.createCriteria(CropVegetativeStructure.class, "cv")
                .createAlias("cv.crop", "cp")
                .createAlias("cv.vegetativeStructure", "v")
                .add(Restrictions.in("v.name", vegetativeStructures))
                .add(Restrictions.eq("v.refActive", "T"))
                .setProjection(Projections.property("cv.crop"));

        List list = criteria.list();
        if (list != null && list.size() > 0) {
            return (Crop) list.get(0);
        }


        return null;
    }

    public Crop getInValidCrop() {
        ArrayList vegetativeStructures = new ArrayList();
        vegetativeStructures.add("Bulb");
        vegetativeStructures.add("Root");
        Criteria criteria = session.createCriteria(CropVegetativeStructure.class, "cv")
                .createAlias("cv.crop", "cp")
                .createAlias("cv.vegetativeStructure", "v")
                .add(Restrictions.not(Restrictions.in("v.name", vegetativeStructures)))
                .add(Restrictions.eq("v.refActive", "T"))
                .setProjection(Projections.property("cv.crop"));

        List list = criteria.list();
        if (list != null && list.size() > 0) {
            return (Crop) list.get(0);
        }


        return null;
    }


    @Override
    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
    }


    class MockCropVegetativeStrucutreDAO extends CropVegetativeStrucutreDAO {
        @Override
        protected org.hibernate.classic.Session getSession() {
            return (org.hibernate.classic.Session) session;
        }
    }
}