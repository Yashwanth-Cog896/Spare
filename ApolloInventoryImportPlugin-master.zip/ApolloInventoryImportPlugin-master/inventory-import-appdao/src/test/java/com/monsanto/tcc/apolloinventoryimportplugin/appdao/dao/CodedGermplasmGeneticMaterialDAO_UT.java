package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;
/**
 *
 * Filename:    $RCSfile: CodedGermplasmGeneticMaterialDAO_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    	 On:	$Date: 2008-10-03 20:30:10 $
 * @version $Revision: 1.8 $
 * @author apatro
 */

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.classic.Session;

import java.util.List;

public class CodedGermplasmGeneticMaterialDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;

    public CodedGermplasmGeneticMaterialDAO_UT(String string) {
        super(string);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetGeneticMaterial_SourceSearchIsCaseInsensitive() {
        final String cropName = "Corn";
        final String lineCode = "XYZ-AQW";
        final String origin = "XYZ/AQW";
        final String source = "SOME SOURCE XYZ";
        final String generation = "F6";
        final String lineage = "@.1.2.|3.4.";
        final String gpOwner = "17";
        final String lineType = "Coded";
        final String pedigreeName = "17_XYZ-AQW:3.4.";
        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(null, null);

        Germplasm germplasm = testHelper
                .createGermplasm(lineType, lineCode, origin, pedigreeName, gpOwner, cropName, "F", "F");
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        CodedGermplasmGeneticMaterialDAO dao = new CodedGermplasmGeneticMaterialDAO(cropName, origin, lineCode,
                lineFunctionCriteria);

        GeneticMaterial geneticMaterial = dao.getGeneticMaterial(source.toLowerCase(), lineage, generation);

        assertNotNull(geneticMaterial);
        assertEquals(cropName, geneticMaterial.getGermplasm().getCrop().getCropName());
        assertEquals(lineCode, geneticMaterial.getGermplasm().getLineCode());
        assertEquals(lineType.toUpperCase(), geneticMaterial.getGermplasm().getLineType().getLineTypeRefId());
        assertEquals(gpOwner, geneticMaterial.getGermplasm().getOwnerBrProg().getBrProgRefId());
        assertEquals(lineage, geneticMaterial.getLineage());
        assertEquals(generation, geneticMaterial.getGeneration());
        assertEquals(source.toUpperCase(), geneticMaterial.getSourceStr());
        assertEquals(pedigreeName, geneticMaterial.getGermplasm().getPedigreeName());
    }

    /**
     * @noinspection OverlyLongMethod
     */
    public void testGetGeneticMaterial_BasedOnGermplasm_SourceSearchIsCaseInsensitive() {
        final String cropName = "Corn";
        final String lineCode = "DAT-UTL";
        final String origin0 = "DAT/UTL0";
        final String origin1 = "DAT/UTL1";
        final String origin2 = "DAT/UTL2";
        final String source = "II-DAT-UTL-SRC";
        final String generation0 = "F5";
        final String generation1 = "F6";
        final String generation2 = "F7";
        final String lineage0 = "@.1.2.|3.";
        final String lineage1 = "@.1.2.|3.4.";
        final String lineage2 = "@.1.2.|3.4.5.";
        final String gpOwner = "17";
        final String lineType = "Coded";
        final String pedigreeName0 = "17_DAT-UTL:3.";
        final String pedigreeName1 = "17_DAT-UTL:3.4.";
        final String pedigreeName2 = "17_DAT-UTL:3.4.5.";

        Germplasm germplasm0 = testHelper
                .createGermplasm(lineType, lineCode, origin0, pedigreeName0, gpOwner, cropName, "F", "F");
        Germplasm germplasm1 = testHelper
                .createGermplasm(lineType, lineCode, origin1, pedigreeName1, gpOwner, cropName, "F", "F");
        Germplasm germplasm2 = testHelper
                .createGermplasm(lineType, lineCode, origin2, pedigreeName2, gpOwner, cropName, "F", "F");
        testHelper.createGeneticMaterial(germplasm0, source.toUpperCase(), generation0, lineage0);
        testHelper.createGeneticMaterial(germplasm1, source.toUpperCase(), generation1, lineage1);
        testHelper.createGeneticMaterial(germplasm2, source.toUpperCase(), generation2, lineage2);

        GermplasmDAO germplasmDAO = new GermplasmDAO(cropName);
        List gpList = germplasmDAO.getAllGermplasmMatchingLineCode(lineCode);
        assertNotNull(gpList);
        assertEquals(3, gpList.size());
        Germplasm gp0 = getGermplasmMatchingOrigin(gpList, origin0);
        Germplasm gp1 = getGermplasmMatchingOrigin(gpList, origin1);
        Germplasm gp2 = getGermplasmMatchingOrigin(gpList, origin2);

        CodedGermplasmGeneticMaterialDAO dao = new CodedGermplasmGeneticMaterialDAO(cropName, lineCode,
                getLineFunctionCriteria(null, null));
        GeneticMaterial geneticMaterial0 = dao.getGeneticMaterial(gp0, source.toLowerCase(), lineage0, generation0);
        GeneticMaterial geneticMaterial1 = dao.getGeneticMaterial(gp1, source.toLowerCase(), lineage1, generation1);
        GeneticMaterial geneticMaterial2 = dao.getGeneticMaterial(gp2, source.toLowerCase(), lineage2, generation2);

        assertEquals(germplasm0, geneticMaterial0.getGermplasm());
        assertEquals(germplasm1, geneticMaterial1.getGermplasm());
        assertEquals(germplasm2, geneticMaterial2.getGermplasm());
        assertEquals(source.toUpperCase(), geneticMaterial0.getSourceStr());
        assertEquals(source.toUpperCase(), geneticMaterial1.getSourceStr());
        assertEquals(source.toUpperCase(), geneticMaterial2.getSourceStr());
        assertEquals(generation0, geneticMaterial0.getGeneration());
        assertEquals(generation1, geneticMaterial1.getGeneration());
        assertEquals(generation2, geneticMaterial2.getGeneration());
        assertEquals(lineage0, geneticMaterial0.getLineage());
        assertEquals(lineage1, geneticMaterial1.getLineage());
        assertEquals(lineage2, geneticMaterial2.getLineage());
    }

    private Germplasm getGermplasmMatchingOrigin(List germplasmList, String origin) {
        Germplasm germplasm = null;
        for (int i = 0; i < germplasmList.size(); i++) {
            Germplasm gp = (Germplasm) germplasmList.get(i);
            if (gp.getOrigin().equals(origin)) {
                germplasm = gp;
                break;
            }
        }
        return germplasm;
    }

    private LineFunctionCriteria getLineFunctionCriteria(String lineFunction, String cytoplasmDonorPedigree) {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(lineFunction);
        inventory.setCytoplasmDonorPedigree(cytoplasmDonorPedigree);
        return new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();
    }
}