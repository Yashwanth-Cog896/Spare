/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.CompICBMale;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

/**
 * Filename:    $RCSfile: CompICBMaleDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ddbrow5 $ On:	$Date: 2007/07/18 21:01:32 $
 *
 * @author SSPEYY
 * @version $Revision: 1.6 $
 */
public class CompICBMaleDAO_UT extends TestIIContextConfigurer {
    private TestHelper testHelper;
    private Session session;

    public void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
    }

    public void testConstructorLineFunctionRefIdIsNullThrowsNoException() {
        try {
            new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null));
        } catch (Exception e) {
            e.printStackTrace();
            fail("Encountered unexpected Exception");
        }
    }

    public void testGetCompICBMaleForSuccess() throws Exception {
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale("SOME SRC1", "17_ASDA/ASDAS:1.2.3.");
        assertNotNull(compICBMales);
        assertEquals(2, compICBMales.length);
    }

    public void testGetCompICBMaleForSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        String sourceStr = "SOME SRC1".toUpperCase();
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale(sourceStr.toLowerCase(), "17_ASDA/ASDAS:1.2.3.");
        assertNotNull(compICBMales);
        assertEquals(2, compICBMales.length);
    }

    public void testGetCompICBMaleWithRefActiveTrueForSuccess() throws Exception {
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale("SOME SRC1", "17_ASDA/ASDAS:1.2.3.", true);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleWithRefActiveTrueForSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        String sourceStr = "SOME SRC1".toUpperCase();
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale(sourceStr.toLowerCase(), "17_ASDA/ASDAS:1.2.3.", true);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleWithRefActiveFalseForSuccess() throws Exception {
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale("SOME SRC1", "17_ASDA/ASDAS:1.2.3.", false);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleWithRefActiveFalseForSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        String sourceStr = "SOME SRC1".toUpperCase();
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale(sourceStr.toLowerCase(), "17_ASDA/ASDAS:1.2.3.", false);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleForSuccessWithLineFunction() throws Exception {
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale("SOME SRC1", "17_ASDA/ASDAS:1.2.3.");
        assertNotNull(compICBMales);
        assertEquals(2, compICBMales.length);
    }

    public void testGetCompICBMaleForSuccessWithLineFunction_SourceSearchIsCaseInsensitive() throws Exception {
        String sourceStr = "SOME SRC1".toLowerCase();
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null))
                .getCompICBMale(sourceStr.toUpperCase(), "17_ASDA/ASDAS:1.2.3.");
        assertNotNull(compICBMales);
        assertEquals(2, compICBMales.length);
    }

    public void testGetCompICBMaleWithRefActiveTrueForSuccessWithLineFunction() throws Exception {
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.R_LINE_FUNCTION, null);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", lineFunctionCriteria)
                .getCompICBMale("SOME SRC1", "17_ASDA/ASDAS:1.2.3.", true);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleWithRefActiveTrueForSuccessWithLineFunction_SourceSearchIsCaseInsensitive() throws
            Exception {
        String sourceStr = "SOME SRC1".toUpperCase();
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.R_LINE_FUNCTION, null);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", lineFunctionCriteria)
                .getCompICBMale(sourceStr.toLowerCase(), "17_ASDA/ASDAS:1.2.3.", true);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleWithRefActiveFalseForSuccessWithLineFunction() throws Exception {
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, "SOME SRC1", "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, false);

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.R_LINE_FUNCTION, null);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", lineFunctionCriteria)
                .getCompICBMale("SOME SRC1", "17_ASDA/ASDAS:1.2.3.", false);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleWithRefActiveFalseForSuccessWithLineFunction_SourceSearchIsCaseInsensitive() throws
            Exception {
        String sourceStr = "SOME SRC1".toUpperCase();
        Germplasm gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        GeneticMaterial gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn");
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, false);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        testHelper.createCompIcbMale(gm, true);

        gp = testHelper.createGermplasm("Segpop", null, "ASDA/ASDAS", "17_ASDA/ASDAS:1.2.3.", "17", "Corn",
                LineFunctionConstants.R_LINE_FUNCTION);
        gm = testHelper.createGeneticMaterial(gp, sourceStr, "F4", "1.2.3.");
        CompICBMale matchingCompIcbMale = testHelper.createCompIcbMale(gm, false);

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.R_LINE_FUNCTION, null);

        CompICBMale[] compICBMales = new CompICBMaleDAO("Corn", lineFunctionCriteria)
                .getCompICBMale(sourceStr.toLowerCase(), "17_ASDA/ASDAS:1.2.3.", false);
        assertNotNull(compICBMales);
        assertEquals(1, compICBMales.length);
        assertEquals(matchingCompIcbMale, compICBMales[0]);
    }

    public void testGetCompICBMaleReturningNull() throws Exception {
        assertNull(new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null)).getCompICBMale("II_SOURCE_NULL",
                "II_PEDIGREE_NULL"));
    }

    public void testGetCompICBMaleWithRefActiveFalseReturningNull() throws Exception {
        assertNull(new CompICBMaleDAO("Corn", getLineFunctionCriteria(null, null)).getCompICBMale("II_SOURCE",
                "II_PEDIGREE", false));
    }

    private LineFunctionCriteria getLineFunctionCriteria(String lineFunction, String cytoplasmDonorPedigree) {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(lineFunction);
        inventory.setCytoplasmDonorPedigree(cytoplasmDonorPedigree);
        return new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();
    }
}