package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class TempGeneticMaterial_UT {
    TempGeneticMaterial testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new TempGeneticMaterial();
    }

    @Test
    public void testSetId() throws Exception {
        Long id = -1l;
        Long gmId = -2l;
        Long inventoryId = -3l;

        testObject.setId(id);
        testObject.setGeneticMaterialId(gmId);
        testObject.setInventoryId(inventoryId);

        assertEquals(id, testObject.getId());
        assertEquals(gmId, testObject.getGeneticMaterialId());
        assertEquals(inventoryId, testObject.getInventoryId());
    }
}
