/*
 Beans_UT was created on May 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ClassUtils;

import java.beans.PropertyDescriptor;
import java.io.File;

public class Beans_UT {
    private static final String PROJECT_BASE_DIRECTORY = "inventory-import-appdao";
    private static final String COVER_PACKAGE = "com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity";
    private static final String COVER_BASE_PACKAGE = "com.monsanto.tcc.apolloinventoryimportplugin.appdao";

    @Test
    public void coverBeans() {
        String directoryToCover = getBeanDirectoryToCover();
        System.out.println("directoryToCover: " + directoryToCover);
        coverDirectory(new File(directoryToCover), "");
    }

    @Test
    public void coverBaseBeans() {
        String directoryToCover = getBaseDirectoryToCover();
        System.out.println("directoryToCover: " + directoryToCover);
        coverDirectory(new File(directoryToCover), "");
    }

    private String getBeanDirectoryToCover() {
        return getWorkingDirForTest() +
                File.separator +
                "src" +
                File.separator +
                "main" +
                File.separator +
                "java" +
                File.separator +
                COVER_PACKAGE.replace('.', File.separatorChar);
    }

    private String getBaseDirectoryToCover() {
        return getWorkingDirForTest() +
                File.separator +
                "src" +
                File.separator +
                "main" +
                File.separator +
                "java" +
                File.separator +
                COVER_BASE_PACKAGE.replace('.', File.separatorChar);
    }

    private void coverDirectory(File directory, String resourcePath) {
        File[] files = directory.listFiles();
        for (File file : files) {
            String fileName = file.getName();
            if (!file.isDirectory()) {
                coverFile(resourcePath, fileName);
            }
        }
    }

    private void coverFile(String resourcePath, String fileName) {
        if (isJavaFile(fileName)) {
            coverClass(resourcePath, fileName);
        }
    }

    private void coverClass(String resourcePath, String fileName) {
        try {
            Class clazz = getClass(resourcePath, fileName);
            if (!clazz.isInterface()) {
                coverNonInterface(clazz);
            }
        } catch (Exception e) {/* do nothing */}
    }

    private void coverNonInterface(Class clazz) {
        if (clazz.isEnum()) {
            clazz.getEnumConstants();
        } else {
            coverProperties(clazz);
        }
    }

    private void coverProperties(Class clazz) {
        PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(clazz);
        Object object = BeanUtils.instantiateClass(clazz);
        try {
            object.equals(object);
            object.equals(null);
            object.equals("");
            object.equals(BeanUtils.instantiateClass(clazz));
            object.hashCode();
        } catch (Exception e) {/* do nothing */}
        for (PropertyDescriptor descriptor : descriptors) {
            coverProperty(object, descriptor);
        }
    }

    private void coverProperty(Object object, PropertyDescriptor descriptor) {
        Object result = null;
        try {
            result = descriptor.getReadMethod().invoke(object);
        } catch (Exception e) {/* do nothing */}
        try {
            descriptor.getWriteMethod().invoke(object, result);
        } catch (Exception e) {/* do nothing */}
    }

    private Class getClass(String resourcePath, String fileName) throws ClassNotFoundException {
        String className = ClassUtils.convertResourcePathToClassName(resourcePath + fileName.replaceAll("\\.java", ""));
        return ClassUtils.forName(COVER_PACKAGE + "." + className);
    }

    private boolean isJavaFile(String fileName) {
        return !fileName.contains("svn") && fileName.contains(".java");
    }

    private String getWorkingDirForTest() {
        String currentDir = System.getProperty("user.dir");
        int projectBaseDirectoryIndex = currentDir.indexOf(PROJECT_BASE_DIRECTORY);
        if (projectBaseDirectoryIndex == -1) {
            if (currentDir.contains("target")) {
                return currentDir.substring(0, currentDir.indexOf("target") - 1);
            }

            if (currentDir.endsWith(File.separator)) {
                return currentDir.substring(0, currentDir.length() - 1);
            } else {
                return currentDir + File.separator + PROJECT_BASE_DIRECTORY;
            }
        }
        int index = projectBaseDirectoryIndex + PROJECT_BASE_DIRECTORY.length();
        if (currentDir.indexOf(File.separator, index) > 0) {
            index = currentDir.indexOf(File.separator, index);
        }
        return currentDir.substring(0, index);
    }
}