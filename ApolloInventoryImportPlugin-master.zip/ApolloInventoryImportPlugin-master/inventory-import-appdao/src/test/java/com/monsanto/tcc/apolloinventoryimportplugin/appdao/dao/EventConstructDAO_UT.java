/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * Filename:    $RCSfile: EventConstructDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ssnall $ On:          $Date: 2009-06-05 14:07:48 $
 *
 * @author ddbrow5
 * @version $Revision: 1.4 $
 */
@SuppressWarnings({"OverlyLongMethod"})
public class EventConstructDAO_UT extends TestIIContextConfigurer {
    private static final String CROP_NAME = "Corn";
    private static final String EVENT_NAME = "EVT-EventConstructDAO_UT";
    private static final String CONSTRUCT_NAME = "CONST-EventConstructDAO_UT";
    private static final String ACTIVE = "T";
    private static final String INACTIVE = "F";
    private Session session;
    private TestHelper testHelper;

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    protected void tearDown() throws Exception {
//    testHelper.purgeMidasObjects();
        if (session != null && session.isOpen()) {
            Transaction transaction = session.getTransaction();
            if (transaction != null && transaction.isActive() && !transaction.wasRolledBack()) {
                transaction.rollback();
            }
        }
        super.tearDown();
    }

    public void testGetEventConstruct_OneActiveEventConstructInDatabase_PassInOneEventNameArgument_ReturnOneMatchingEventConstruct() throws
            Exception {
        EventConstruct expectedEventConstruct = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});
        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstruct, actualEventConstructs[0]);
    }

    public void testGetEventConstruct_OneInactiveEventConstructInDatabase_PassInOneEventNameArgument_ReturnZeroEventConstruct() throws
            Exception {
        createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});
        assertNull(actualEventConstructs);
    }

    public void testGetEventConstruct_TwoActiveEventConstructsInDatabaseWithSameName_PassInOneEventNameArgument_ReturnOneEventConstructMatchingLowestEventConstructId() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 2;
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
        }

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[0], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_TwoActiveEventConstructsInDatabaseWithDifferentNames_PassInTwoEventNamesMatchingThoseInDatabase_ReturnTwoEventConstructMatchingThoseInDatabase() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 2;
        final String expectedEventName0 = EVENT_NAME;
        final String expectedEventName1 = EVENT_NAME + 1;

        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        expectedEventConstructs[0] = createEventConstruct(CROP_NAME, expectedEventName0, ACTIVE);
        expectedEventConstructs[1] = createEventConstruct(CROP_NAME, expectedEventName1, ACTIVE);

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{expectedEventName0, expectedEventName1});

        assertNotNull(actualEventConstructs);
        assertEquals(2, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[0], actualEventConstructs[0]);
        assertEventConstruct(expectedEventConstructs[1], actualEventConstructs[1]);
    }

    public void testGetEventConstruct_MultipleActiveEventConstructsInDatabaseWithSameName_PassInOneMatchingEventName_ReturnOneEventConstructMatchingLowestEventConstructId() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 10;
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
        }

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[0], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_MultipleActiveEventConstructsInDatabaseWithSameName_PassInTwoMatchingEventName_ReturnOneEventConstructMatchingLowestEventConstructId() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 10;
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
        }

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME, EVENT_NAME});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[0], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_MultipleActiveEventConstructsInDatabaseWithSameName_PassInAllMatchingEventName_ReturnOneEventConstructMatchingLowestEventConstructId() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 10;
        String[] eventNames = new String[numberOfEventConstructsInDatabase];
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
            eventNames[i] = EVENT_NAME;
        }

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME).getEventConstruct(eventNames);

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[0], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_MultipleActiveEventConstructsInDatabaseWithDifferentName_PassInOneMatchingEventName_ReturnOneMatchingEventConstruct() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 10;
        final int indexOfMatchingEventConstruct = 5;
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME + i, ACTIVE);
        }
        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME + indexOfMatchingEventConstruct});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[indexOfMatchingEventConstruct], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_MultipleActiveEventConstructsInDatabaseWithDifferentName_PassInTwoMatchingEventNames_ReturnTwoMatchingEventConstructs() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 10;
        final int indexOfMatchingEventConstruct0 = 5;
        final int indexOfMatchingEventConstruct1 = 7;
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME + i, ACTIVE);
        }
        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME).getEventConstruct(
                new String[]{EVENT_NAME + indexOfMatchingEventConstruct0, EVENT_NAME + indexOfMatchingEventConstruct1});

        assertNotNull(actualEventConstructs);
        assertEquals(2, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[indexOfMatchingEventConstruct0], actualEventConstructs[0]);
        assertEventConstruct(expectedEventConstructs[indexOfMatchingEventConstruct1], actualEventConstructs[1]);
    }

    public void testGetEventConstruct_MultipleActiveEventConstructsInDatabaseWithDifferentName_PassInAllMatchingEventNames_ReturnAllMatchingEventConstructs() throws
            Exception {
        final int numberOfEventConstructsInDatabase = 10;
        final String[] expectedEventNames = new String[numberOfEventConstructsInDatabase];
        EventConstruct[] expectedEventConstructs = new EventConstruct[numberOfEventConstructsInDatabase];
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            expectedEventConstructs[i] = createEventConstruct(CROP_NAME, EVENT_NAME + i, ACTIVE);
            expectedEventNames[i] = expectedEventConstructs[i].getEventName();
        }

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME).getEventConstruct(expectedEventNames);

        assertNotNull(actualEventConstructs);
        assertEquals(numberOfEventConstructsInDatabase, actualEventConstructs.length);
        for (int i = 0; i < numberOfEventConstructsInDatabase; i++) {
            assertEventConstruct(expectedEventConstructs[i], actualEventConstructs[i]);
        }
    }

    public void testGetEventConstruct_OneActiveOneInactiveEventConstructsInDatabaseWithSameName_PassInMatchingEventName_ReturnActiveEventConstruct() throws
            Exception {
        final int indexOfMatchingActiveEventConstruct = 1;
        EventConstruct[] expectedEventConstructs = new EventConstruct[2];
        expectedEventConstructs[0] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[1] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[indexOfMatchingActiveEventConstruct], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_OneActiveTwoInactiveEventConstructsInDatabaseWithSameName_PassInMatchingEventName_ReturnActiveEventConstruct() throws
            Exception {
        final int indexOfMatchingActiveEventConstruct = 2;
        EventConstruct[] expectedEventConstructs = new EventConstruct[3];
        expectedEventConstructs[0] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[1] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[2] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[indexOfMatchingActiveEventConstruct], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_MultipleActiveMultipleInactiveEventConstructsInDatabaseWithSameName_PassInMatchingEventName_ReturnActiveEventConstructMatchingLowestEventConstructId() throws
            Exception {
        final int indexOfMatchingExpectedEventConstruct = 6;
        EventConstruct[] expectedEventConstructs = new EventConstruct[10];
        expectedEventConstructs[0] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[1] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[2] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[3] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[4] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[5] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[6] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
        expectedEventConstructs[7] = createEventConstruct(CROP_NAME, EVENT_NAME, INACTIVE);
        expectedEventConstructs[8] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);
        expectedEventConstructs[9] = createEventConstruct(CROP_NAME, EVENT_NAME, ACTIVE);

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{EVENT_NAME});

        assertNotNull(actualEventConstructs);
        assertEquals(1, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs[indexOfMatchingExpectedEventConstruct], actualEventConstructs[0]);
    }

    public void testGetEventConstruct_MultipleActiveMultipleInactiveEventConstructsInDatabaseWithDifferentNames_PassInAllMatchingEventNames_ReturnAllActiveEventConstructsMatchingLowestEventConstructId() throws
            Exception {
        final String expectedEventName0 = EVENT_NAME;
        final String expectedEventName1 = EVENT_NAME + 1;
        final String expectedEventName2 = EVENT_NAME + 2;
        final int indexOfExpectedEventConstruct0 = 2;
        final int indexOfExpectedEventConstruct1 = 5;
        final int indexOfExpectedEventConstruct2 = 1;
        EventConstruct[] expectedEventConstructs0 = new EventConstruct[5];
        expectedEventConstructs0[0] = createEventConstruct(CROP_NAME, expectedEventName0, INACTIVE);
        expectedEventConstructs0[1] = createEventConstruct(CROP_NAME, expectedEventName0, INACTIVE);
        expectedEventConstructs0[2] = createEventConstruct(CROP_NAME, expectedEventName0, ACTIVE);
        expectedEventConstructs0[3] = createEventConstruct(CROP_NAME, expectedEventName0, INACTIVE);
        expectedEventConstructs0[4] = createEventConstruct(CROP_NAME, expectedEventName0, ACTIVE);

        EventConstruct[] expectedEventConstructs1 = new EventConstruct[10];
        expectedEventConstructs1[0] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[1] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[2] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[3] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[4] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[5] = createEventConstruct(CROP_NAME, expectedEventName1, ACTIVE);
        expectedEventConstructs1[6] = createEventConstruct(CROP_NAME, expectedEventName1, ACTIVE);
        expectedEventConstructs1[7] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[8] = createEventConstruct(CROP_NAME, expectedEventName1, ACTIVE);
        expectedEventConstructs1[9] = createEventConstruct(CROP_NAME, expectedEventName1, ACTIVE);

        EventConstruct[] expectedEventConstructs2 = new EventConstruct[7];
        expectedEventConstructs2[0] = createEventConstruct(CROP_NAME, expectedEventName2, INACTIVE);
        expectedEventConstructs2[1] = createEventConstruct(CROP_NAME, expectedEventName2, ACTIVE);
        expectedEventConstructs2[2] = createEventConstruct(CROP_NAME, expectedEventName2, INACTIVE);
        expectedEventConstructs2[3] = createEventConstruct(CROP_NAME, expectedEventName2, ACTIVE);
        expectedEventConstructs2[4] = createEventConstruct(CROP_NAME, expectedEventName2, INACTIVE);
        expectedEventConstructs2[5] = createEventConstruct(CROP_NAME, expectedEventName2, ACTIVE);
        expectedEventConstructs2[6] = createEventConstruct(CROP_NAME, expectedEventName2, ACTIVE);

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{expectedEventName0,
                        expectedEventName1, expectedEventName2});

        assertNotNull(actualEventConstructs);
        assertEquals(3, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs0[indexOfExpectedEventConstruct0], actualEventConstructs[0]);
        assertEventConstruct(expectedEventConstructs1[indexOfExpectedEventConstruct1], actualEventConstructs[1]);
        assertEventConstruct(expectedEventConstructs2[indexOfExpectedEventConstruct2], actualEventConstructs[2]);
    }

    public void testGetEventConstruct_MultipleActiveMultipleInactiveEventConstructsInDatabaseWithDifferentNames_PassInMatchingEventNameAndOneNullString_ReturnAllActiveEventConstructsMatchingLowestEventConstructId() throws
            Exception {
        final String expectedEventName0 = EVENT_NAME;
        final String expectedEventName1 = EVENT_NAME + 1;
        final int indexOfExpectedEventConstruct0 = 1;
        final int indexOfExpectedEventConstruct1 = 1;
        EventConstruct[] expectedEventConstructs0 = new EventConstruct[2];
        expectedEventConstructs0[0] = createEventConstruct(CROP_NAME, expectedEventName0, INACTIVE);
        expectedEventConstructs0[1] = createEventConstruct(CROP_NAME, expectedEventName0, ACTIVE);

        EventConstruct[] expectedEventConstructs1 = new EventConstruct[3];
        expectedEventConstructs1[0] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);
        expectedEventConstructs1[1] = createEventConstruct(CROP_NAME, expectedEventName1, ACTIVE);
        expectedEventConstructs1[2] = createEventConstruct(CROP_NAME, expectedEventName1, INACTIVE);

        EventConstruct[] actualEventConstructs = new EventConstructDAO(CROP_NAME)
                .getEventConstruct(new String[]{expectedEventName0,
                        null, expectedEventName1});

        assertNotNull(actualEventConstructs);
        assertEquals(2, actualEventConstructs.length);
        assertEventConstruct(expectedEventConstructs0[indexOfExpectedEventConstruct0], actualEventConstructs[0]);
        assertEventConstruct(expectedEventConstructs1[indexOfExpectedEventConstruct1], actualEventConstructs[1]);
    }

    public void testGetEventConstruct_OneEventArgument_NoMatchInDatabase() throws Exception {
        EventConstruct[] eventConstruct = new EventConstructDAO(CROP_NAME).getEventConstruct(new String[]{EVENT_NAME});

        assertNull(eventConstruct);
    }

    public void testGetEventConstruct_StringArrayArgument_NoMatchInDatabase() throws Exception {
        String[] eventNames = new String[]{EVENT_NAME, EVENT_NAME + 1, EVENT_NAME + 2};
        EventConstruct[] eventConstruct = new EventConstructDAO(CROP_NAME).getEventConstruct(eventNames);

        assertNull(eventConstruct);
    }

    public void testGetEventConstruct_StringArrayArgumentIsNull() throws Exception {
        try {
            new EventConstructDAO(CROP_NAME).getEventConstruct((String[]) null);
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("eventName is required") > -1);
        }
    }

    public void testGetEventConstruct_StringArrayArgumentIsEmptyArray() throws Exception {
        try {
            new EventConstructDAO(CROP_NAME).getEventConstruct(new String[]{});
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("eventName is required") > -1);
        }
    }

    public void testCropNameRequired_CropNameIsNull() throws Exception {
        try {
            new EventConstructDAO(null);
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("cropName is required") > -1);
        }
    }

    public void testCropNameRequired_CropNameIsEmptString() throws Exception {
        try {
            new EventConstructDAO("");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("cropName is required") > -1);
        }
    }


    private EventConstruct createEventConstruct(String cropName, String eventName, String refActive) {
        EventConstruct eventConstruct = testHelper.createEventConstruct(cropName, eventName, CONSTRUCT_NAME, refActive);
        return eventConstruct;
    }

    private void assertEventConstruct(EventConstruct expectedEventConstruct, EventConstruct actualEventConstruct) {
        assertEquals(expectedEventConstruct.getEventConstructId(), actualEventConstruct.getEventConstructId());
        assertEquals(expectedEventConstruct.getEventName(), actualEventConstruct.getEventName());
        assertEquals(expectedEventConstruct.getConstructName(), actualEventConstruct.getConstructName());

    }
}