/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.classic.Session;

import java.util.Date;

/**
 * Filename:    $RCSfile: FinishedGeneticMaterialDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: ssnall $ On:	$Date: 2009-06-05 14:07:48 $
 *
 * @author apatro
 * @version $Revision: 1.8 $
 */
public class FinishedGeneticMaterialDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;
    private LineFunctionCriteria nullLineFunctionCriteria = new LineFunctionCriteriaFactory(new StagingInventory())
            .getLineFunctionCriteria();

    public FinishedGeneticMaterialDAO_UT(String string) {
        super(string);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testConstructorThrowsExceptionWhenCropIsNull() {
        try {
            new FinishedGeneticMaterialDAO(null, nullLineFunctionCriteria);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGeneticMaterialDAO.CROP_LINEFUNCTION_REQ_MSG) >= 0);
        }
    }

    public void testConstructorThrowsNoExceptionWhenLineFunctionIsNull() {
        try {
            new FinishedGeneticMaterialDAO("Corn", null);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGeneticMaterialDAO.CROP_LINEFUNCTION_REQ_MSG) >= 0);
        }
    }

    public void testGetGeneticMaterialWithLineageOtherThanPipe() {
        String lineCode = "ABCSAD";
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial[] geneticMaterials = dao.getGeneticMaterialWithLineageOtherThanPipe(lineCode);

        assertNotNull(geneticMaterials);
        assertEquals(3, geneticMaterials.length);
    }

    public void testGetGeneticMaterialWithLineageOtherThanPipeNullLineFunction() {
        String lineCode = "ABCSAD";
        Germplasm gp1 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T", null, null);
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T", null, null);
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(null, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial[] geneticMaterials = dao.getGeneticMaterialWithLineageOtherThanPipe(lineCode);

        assertNotNull(geneticMaterials);
        assertEquals(3, geneticMaterials.length);
    }

    public void testGetGeneticMaterialWithLineageOtherThanPipeWithSLineFunction() {
        String lineCode = "ABCSAD";
        Germplasm gp1 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T", "S", null);
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T", "S", null);
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.S_LINE_FUNCTION, null);
        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial[] geneticMaterials = dao.getGeneticMaterialWithLineageOtherThanPipe(lineCode);

        assertNotNull(geneticMaterials);
        assertEquals(3, geneticMaterials.length);
    }

    public void testGetGeneticMaterialWithLineageOtherThanPipeReturnsNothing() {
        String lineCode = "ABCSADXXX";

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial[] geneticMaterials = dao.getGeneticMaterialWithLineageOtherThanPipe(lineCode);

        assertNull(geneticMaterials);
    }

    public void testGetGeneticMaterialWithLineageOtherThanPipeThrowsExceptionWhenLineCodeIsNull() {
        String lineCode = null;

        try {
            new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria)
                    .getGeneticMaterialWithLineageOtherThanPipe(lineCode);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGeneticMaterialDAO.LINECODE_REQ_MSG) >= 0);
        }
    }

    public void testgetPrimaryGeneticMaterial_LineCodeIsNull() {
        String lineCode = null;

        try {
            new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria)
                    .getPrimaryGeneticMaterial(lineCode, "XASDSASD", "");
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGeneticMaterialDAO.LINCODE_SRC_LINEAGE_ARE_REQ_MSG) >= 0);
        }
    }

    public void testgetPrimaryGeneticMaterial_SourceIsNull() {
        try {
            new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria).getPrimaryGeneticMaterial("ASDAS", null, "");
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(FinishedGeneticMaterialDAO.LINCODE_SRC_LINEAGE_ARE_REQ_MSG) >= 0);
        }
    }

    public void testgetPrimaryGeneticMaterialWithSingleMatch() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source, "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithSingleMatch_SourceSearchIsCaseInsensitive() {
        String lineCode = "ABCSAD";
        String source = new Date().toString().toUpperCase();
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source.toLowerCase(), "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithWithLineFunctionNotMatchingSource() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp1 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T", "B", null);
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source, "");
        assertNull(primaryGm);
    }

    public void testgetPrimaryGeneticMaterialWithWithLineFunctionMatchingSource() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp1 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T", "B", null);
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp1, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source, "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithWithLineFunctionMatchingSource_SourceSearchIsCaseInsensitive() {
        String lineCode = "ABCSAD";
        String source = new Date().toString().toUpperCase();
        Germplasm gp1 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T", "B", null);
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp1, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source.toLowerCase(), "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithMultipleMatch() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp1, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source, "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithMultipleMatch_SourceSearchIsCaseInsensitive() {
        String lineCode = "ABCSAD";
        String source = new Date().toString().toUpperCase();
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp1, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source.toLowerCase(), "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithMultipleMatchWithLineFunctionOnOne() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T", "B", null);
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source, "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialWithMultipleMatchWithLineFunctionOnOne_SourceSearchIsCaseInsensitive() {
        String lineCode = "ABCSAD";
        String source = new Date().toString().toUpperCase();
        Germplasm gp1 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T", "B", null);
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(lineCode, source.toLowerCase(), "F3");
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialByGermplasmWithSingleMatch() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        GeneticMaterial expectedPrimaryGm = testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", nullLineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(gp2);
        assertNotNull(primaryGm);
        assertEquals(expectedPrimaryGm.getGeneticMaterialId(), primaryGm.getGeneticMaterialId());
    }

    public void testgetPrimaryGeneticMaterialByGermplasmWithWithLineFunctionNotMatchingSource() {
        String lineCode = "ABCSAD";
        String source = new Date().toString();
        Germplasm gp1 = testHelper
                .createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "17", "Corn", "F", "T", "B", null);
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F4", "@.1.|2.");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp1, gp1.getId().toString(), "INBRED", "|");

        Germplasm gp2 = testHelper.createGermplasm("Finished", lineCode, "ABC/XYZ//Z", lineCode, "21", "Corn", "F", "T");
        testHelper.createGeneticMaterial(gp2, source, "F3", "@.1.|");
        testHelper.createGeneticMaterial(gp2, gp2.getId().toString(), "INBRED", "|");

        LineFunctionCriteria lineFunctionCriteria = getLineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION, null);

        FinishedGeneticMaterialDAO dao = new FinishedGeneticMaterialDAO("Corn", lineFunctionCriteria);

        GeneticMaterial primaryGm = dao.getPrimaryGeneticMaterial(gp2);
        assertNull(primaryGm);
    }

    private LineFunctionCriteria getLineFunctionCriteria(String lineFunction, String cytoplasmDonorPedigree) {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(lineFunction);
        inventory.setCytoplasmDonorPedigree(cytoplasmDonorPedigree);
        return new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();
    }
}