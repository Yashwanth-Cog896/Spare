package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class RunStatus_UT {
    RunStatus testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new RunStatus();
    }

    @Test
    public void testSetId() throws Exception {
        Long id = -789l;
        String desc = "description";
        String status = "status";

        testObject.setId(id);
        testObject.setDescription(desc);
        testObject.setStatusCode(status);

        assertEquals(id, testObject.getId());
        assertEquals(desc, testObject.getDescription());
        assertEquals(status, testObject.getStatusCode());
    }
}
