/*
 MidasInventoryDAO_UT was created on Mar 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.AbstractGermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.GermplasmListFetchStrategyFinished;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.GermplasmListFetchStrategySegpop;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MidasInventoryDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ssnall $    	 On:	$Date: 2009-06-05 14:08:08 $
 *
 * @author SRKARNA
 * @version $Revision: 1.6 $
 */
public class MidasInventoryDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private Germplasm germplasm1;
    private Germplasm germplasm2;
    private Germplasm germplasm3;
    private Germplasm germplasm4;
    private Germplasm germplasm5;

    public MidasInventoryDAO_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    private void init() {
        TestHelper testHelper = new TestHelper(session);

        germplasm1 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-1",
                "X/Y", "LC-1", "17", "Corn");
        GeneticMaterial geneticMaterialWithArchivedInventory11 = testHelper
                .createGeneticMaterial(germplasm1, "source-11", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17", "F");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "C3");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "F", "17");
        GeneticMaterial geneticMaterialWithArchivedInventory12 = testHelper
                .createGeneticMaterial(germplasm1, "source-12", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithArchivedInventory12, "F", "17");
        testHelper.createInventory(geneticMaterialWithArchivedInventory12, "F", "17");

        germplasm2 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-2",
                "X/Y", "LC-2", "17", "Corn");
        GeneticMaterial geneticMaterialWithNoArchivedInventory21 = testHelper
                .createGeneticMaterial(germplasm2, "source-21", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory21, "F", "17");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory21, "T", "C3");
        GeneticMaterial geneticMaterialWithNoArchivedInventory22 = testHelper
                .createGeneticMaterial(germplasm2, "source-22", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory22, "F", "17");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory22, "F", "17");

        germplasm3 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-3",
                "X/Y", "LC-3", "17", "Corn");
        GeneticMaterial geneticMaterial3 = testHelper.createGeneticMaterial(germplasm3, "source-31", "|", "INBRED");
        testHelper.createInventory(geneticMaterial3, "T", "C3");
        testHelper.createInventory(geneticMaterial3, "F", "C3");


        germplasm4 = testHelper.createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null,
                "X/Y", "17_X/Y:@.1.2.", "17", "Corn");
        GeneticMaterial geneticMaterial4 = testHelper.createGeneticMaterial(germplasm4, "source-41", "F4", "@.1.2.");
        testHelper.createInventory(geneticMaterial4, "T", "C3");

        germplasm5 = testHelper.createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null,
                "X/Y", "17_X/Y:@.1.2.", "17", "Corn");
        testHelper.createGeneticMaterial(germplasm5, "source-51", "F4", "@.1.2.");
        testHelper.createInventory(geneticMaterial4, "T", "C3", "F");

    }

    public void testGetArchivedInventory() throws Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-1", "source-11");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        Inventory inventory = midasInventoryDAO.getArchivedInventory(stagingInventory,
                new GermplasmListFetchStrategyFinished());

        assertNotNull(inventory);
    }

    public void testGetArchivedInventory_NoArchived_Returns_Null() throws Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-2", "source-21");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        Inventory inventory = midasInventoryDAO.getArchivedInventory(stagingInventory,
                new GermplasmListFetchStrategyFinished());

        assertNull(inventory);
    }

    public void testGetArchivedInventory_NoMatchingSource_Returns_Null() throws Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-1", "source-not-matching");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        Inventory inventory = midasInventoryDAO.getArchivedInventory(stagingInventory,
                new GermplasmListFetchStrategyFinished());

        assertNull(inventory);
    }

    public void testGetArchivedInventory_NoMatchingPedigree_Returns_Null() throws Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-Not-matching", "source-1");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        Inventory inventory = midasInventoryDAO.getArchivedInventory(stagingInventory,
                new GermplasmListFetchStrategyFinished());

        assertNull(inventory);
    }

    public void testGetArchivedInventory_NoInventory_Returns_Null() throws Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-3", "source-31");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        Inventory inventory = midasInventoryDAO.getArchivedInventory(stagingInventory,
                new GermplasmListFetchStrategyFinished());

        assertNull(inventory);
    }

    public void testGetGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner() throws Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("@.1.2.", "X/Y", "source-41");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        GeneticMaterial geneticMaterial = midasInventoryDAO
                .getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(stagingInventory,
                        new GermplasmListFetchStrategySegpop());

        assertNotNull(geneticMaterial);
    }

    public void testGetGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner_InActiveInventories_Returns_Null() throws
            Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("@.1.2.", "X/Y", "source-51");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        GeneticMaterial geneticMaterial = midasInventoryDAO
                .getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(stagingInventory,
                        new GermplasmListFetchStrategySegpop());

        assertNull(geneticMaterial);
    }

    public void testGetGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner_MatchingInvOwnerHasInventories_Returns_Null() throws
            Exception {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-2", "source-21");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        GeneticMaterial geneticMaterial = midasInventoryDAO
                .getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(stagingInventory,
                        new GermplasmListFetchStrategyFinished());

        assertNull(geneticMaterial);
    }

    public void testGetInventoryOwnedByGermplasmOwner() {

        TestHelper testHelper = new TestHelper(session);
        Germplasm germplasm1 = testHelper
                .createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-1", "X/Y", "LC-1", "17", "Corn");
        GeneticMaterial geneticMaterialWithArchivedInventory11 = testHelper
                .createGeneticMaterial(germplasm1, "source-11", "|", "INBRED");
        Inventory expectedInventory = testHelper.createInventory(geneticMaterialWithArchivedInventory11, "F", "17");
        Inventory archivedInventory = testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17");
        InventoryDAO inventoryDAO = new InventoryDAO();
        Inventory unarchivedInventoryOwnedByGermplasmOwner = inventoryDAO
                .getActiveUnarchivedInventoryOwnedByGermplasmOwner(geneticMaterialWithArchivedInventory11);
        assertEquals(expectedInventory.getInventoryId(), unarchivedInventoryOwnedByGermplasmOwner.getInventoryId());
    }

    public void testGetInventories() {
        TestHelper testHelper = new TestHelper(session);
        Germplasm germplasm1 = testHelper
                .createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-1", "X/Y", "LC-1", "17", "Corn");
        GeneticMaterial geneticMaterialWithArchivedInventory11 = testHelper
                .createGeneticMaterial(germplasm1, "source-11", "|", "INBRED");
        Inventory expectedInventory = testHelper.createInventory(geneticMaterialWithArchivedInventory11, "F", "17");
        Inventory archivedInventory = testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17");
        InventoryDAO inventoryDAO = new InventoryDAO();
        Inventory[] unarchivedInventoryOwnedByGermplasmOwner = inventoryDAO
                .getActiveUnarchivedInventory(geneticMaterialWithArchivedInventory11);
        assertEquals(expectedInventory.getInventoryId(), unarchivedInventoryOwnedByGermplasmOwner[0].getInventoryId());
    }

    public void testGetArchivedInventory_greaterThan1000Germplasms() {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-1", "source-11");

        MidasInventoryDAO midasInventoryDAO = new MidasInventoryDAO();
        Inventory inventory = midasInventoryDAO.getArchivedInventory(stagingInventory,
                new MockGermplasmFetchStrategy());

        assertNotNull(inventory);
    }

    private StagingInventory createStagingInventory(String lineCode, String source) {
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("Corn");
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        stagingInventory.setLineCode(lineCode);
        stagingInventory.setSource(source);
        stagingInventory.setInventoryOwner("17");
        return stagingInventory;
    }

    private StagingInventory createStagingInventory(String lineage, String origin, String source) {
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("Corn");
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        stagingInventory.setLineage(lineage);
        stagingInventory.setOrigin(origin);
        stagingInventory.setSource(source);
        stagingInventory.setInventoryOwner("17");
        return stagingInventory;
    }

    private class MockGermplasmFetchStrategy extends AbstractGermplasmListFetchStrategy {

        @Override
        protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        @Override
        protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public List getGermplasms(StagingInventory stagingInventory) {
            List<Germplasm> germplasmList = new ArrayList<Germplasm>();
            germplasmList.add(germplasm1);
            germplasmList.add(germplasm2);
            germplasmList.add(germplasm3);
            germplasmList.add(germplasm4);
            germplasmList.add(germplasm5);
            //add duplicate germplasm
            germplasmList.add(germplasm5);
            add1000Germplasms(germplasmList);
            return germplasmList;
        }

        private void add1000Germplasms(List<Germplasm> germplasmList) {
            for (int i = 0; i < 1000; i++) {
                germplasmList.add(getGermplasm(i));
            }
        }

        private Germplasm getGermplasm(int i) {
            Germplasm g = new Germplasm();
            g.setId(new Long(-i));
            return g;
        }
    }
}
