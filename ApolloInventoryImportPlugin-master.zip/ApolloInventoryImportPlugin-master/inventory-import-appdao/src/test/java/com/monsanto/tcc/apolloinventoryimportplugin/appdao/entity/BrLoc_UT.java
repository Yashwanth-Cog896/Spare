package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 12:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class BrLoc_UT {
    BrLoc testObject;

    @Before
    public void startup() {
        testObject = new BrLoc();
    }

    @Test
    public void testSettersAndGetters() throws Exception {
        String brLocId = "locId";
        BrProg brProd = new BrProg();
        brProd.setAcctId(-33L);
        String homeLoc = "homeLoc";
        String refActive = "T";
        String country = "us";

        testObject.setBrLocId(brLocId);
        testObject.setBrProg(brProd);
        testObject.setCountryId(country);
        testObject.setHomeLoc(homeLoc);
        testObject.setRefActive(refActive);

        assertEquals(brLocId, testObject.getBrLocId());
        assertEquals(brProd, testObject.getBrProg());
        assertEquals(homeLoc, testObject.getHomeLoc());
        assertEquals(country, testObject.getCountryId());
        assertEquals(refActive, testObject.getRefActive());
    }
}
