package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.Util.Exceptions.WrappingException;


public class MidasObjectIDBroker {

  public long nextID(PersistentStoreConnection conn) throws WrappingException {
    String sql = "select MIDAS.GET_NEXTID() as ID from dual";
    PersistentStoreResultSet resultSet = conn.executeQuery(sql);
    try {
      PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
      return singleResult.getLong("ID");
    } catch (EmptyResultSetException e) {
      throw new WrappingException(e);
    } finally {
      DatabaseResource.close(resultSet);
    }
  }
}
