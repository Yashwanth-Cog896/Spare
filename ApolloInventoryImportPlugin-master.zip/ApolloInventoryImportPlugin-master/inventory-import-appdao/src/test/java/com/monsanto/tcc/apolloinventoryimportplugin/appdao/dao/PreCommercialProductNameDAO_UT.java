package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 19, 2008 Time: 8:57:07 AM To change this template use File |
 * Settings | File Templates.
 */
public class PreCommercialProductNameDAO_UT extends TestIIContextConfigurer {
    private TestHelper testHelper;

    protected void setUp() throws Exception {
        super.setUp();
        testHelper = new TestHelper();
    }

    protected void tearDown() throws Exception {
        testHelper.rollbackTransaction();
//        if (testHelper != null) {
//            testHelper.beginTransaction();
//            testHelper.purgeMidasObjects();
//            testHelper.purgeStagingObjects();
//            testHelper.endTransaction();
//        }
        super.tearDown();
    }

    public void testGetProductListMatchingProductName_ValidProductNameAndCrop_ReturnOneRecord() throws Exception {
        try {
            createProductNames();
        } catch (Exception e) {
            tearDown();
            throw e;
        }
        try {
            testHelper.beginTransaction();
            ProductNameDAO productNameDAO = new PreCommercialProductNameDAO("Corn");
            String productName = testHelper.getPreCommercialProductName();
            List list = productNameDAO.getProductListMatchingProductName(productName);
            assertNotNull(list);
            assertTrue(list.size() > 0);
        } finally {
            testHelper.rollbackTransaction();
        }
    }

    public void testGetProductListMatchingProductName_InvalidProductNameandCrop_ReturnNoRecord() throws Exception {
        try {
            createProductNames();
        } catch (Exception e) {
            tearDown();
            throw e;
        }
        try {
            testHelper.beginTransaction();
            ProductNameDAO productNameDAO = new PreCommercialProductNameDAO("Tomato");
            List list = productNameDAO.getProductListMatchingProductName("PRODUCTABC2");
            assertEquals(0, list.size());
        } finally {
            testHelper.rollbackTransaction();
        }
    }

    private void createProductNames() throws Exception {
        testHelper.beginTransaction();
        String countryName = "United States of America";
        Product product1 = testHelper.createProduct("Corn", "T");
        Product product3 = testHelper.createProduct("Tomato", "T");
        testHelper.createProductName("PRODUCTABC1", "T", "MONSANTO", "MONSANTO", countryName, product1);
        testHelper.createProductName("PRODUCTABC1", "T", "PAYMASTER", countryName, product1);
        testHelper.createProductName("PRODUCTABC1", "T", "MONSANTO", "MONSANTO", countryName, product3);
        testHelper.createProductName("PRODUCTABC1", "T", "PAYMASTER", countryName, product3);
        testHelper.createProductName("PRODUCTABC3", "T", "MONSANTO", "MONSANTO", "CANADA", product1);
        testHelper.createProductName("PRODUCTABC3", "T", "PAYMASTER", "CANADA", product1);
        testHelper.endTransaction();
    }
}
