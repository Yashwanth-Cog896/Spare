package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Aug 12, 2008 Time: 2:23:18 PM To change this template use File |
 * Settings | File Templates.
 */
public class DuplicateMaterialDAO_UT extends TestIIContextConfigurer {

    private Session session;
    private TestHelper testHelper;

    public void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testCheckForArchivedMaterialWithParentage_returnsZero() throws Exception {
        String pedigreeName = "17_XYZ/WRT:1.2.3.";
        String source = "SRCDUPCHECK1";
        Germplasm germplasm = testHelper.createGermplasm("SEGPOP", "XYZ/WRT", null, pedigreeName, "17", "Corn");
        GeneticMaterial geneticMaterial = testHelper.createGeneticMaterial(germplasm, source, "F2", "1.2.");
        GeneticMaterial geneticMaterial1 = testHelper.createGeneticMaterial(germplasm, "DUMMY", "F1", "1.2.");
        testHelper.createInventory(geneticMaterial, "F", "17");
        testHelper.createParentage(geneticMaterial, geneticMaterial1, "M");
        DuplicateMaterialDAO duplicateMaterialDAO = new DuplicateMaterialDAO("Corn");
        assertTrue(duplicateMaterialDAO.getCountForForArchivedMaterialWithParentage(pedigreeName, source, "SEGPOP") == 0);
    }

    public void testCheckForArchivedMaterialWithParentage_returnsOne() throws Exception {

        String pedigreeName = "17_XYZ/WRT:1.2.3.";
        String source = "SRCDUPCHECK1";
        Germplasm germplasm = testHelper.createGermplasm("SEGPOP", "XYZ/WRT", null, pedigreeName, "17", "Corn");
        GeneticMaterial geneticMaterial = testHelper.createGeneticMaterial(germplasm, source, "F2", "1.2.");
        testHelper.createInventory(geneticMaterial, "F", "17");
        DuplicateMaterialDAO duplicateMaterialDAO = new DuplicateMaterialDAO("Corn");
        assertTrue(duplicateMaterialDAO.getCountForForArchivedMaterialWithParentage(pedigreeName, source, "SEGPOP") == 1);
    }
}
