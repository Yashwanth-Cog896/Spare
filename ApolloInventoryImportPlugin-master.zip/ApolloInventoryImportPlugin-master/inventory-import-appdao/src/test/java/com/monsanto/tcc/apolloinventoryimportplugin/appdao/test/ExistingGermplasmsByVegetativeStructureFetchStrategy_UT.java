package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.GermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.ExistingGermplasmsByVegetativeStructureFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 22, 2010
 * Time: 9:44:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class ExistingGermplasmsByVegetativeStructureFetchStrategy_UT {
    @Mock
    private GermplasmDAO mockGermplasmDAO;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void createExistingGermplasmsByVegetativeStructureFetchStrategy_getGermplams() {
        StagingInventory stagingInventory = new StagingInventory();
        ArrayList<Germplasm> germplasms = new ArrayList<Germplasm>();
        germplasms.add(new Germplasm());
        when(mockGermplasmDAO.getExistingGermplasmsByVegetativeStructure(stagingInventory)).thenReturn(germplasms);
        ExistingGermplasmsByVegetativeStructureFetchStrategy strategy = new MockExistingGermplasmsByVegetativeStructureFetchStrategy();
        List germplasmsList = strategy.getGermplasms(stagingInventory);
        assertEquals(1, germplasmsList.size());
    }

    @Test
    public void createExistingGermplasmsByVegetativeStructureFetchStrategy_getGermplasmsWithActiveRoyalties() {
        StagingInventory stagingInventory = new StagingInventory();
        ExistingGermplasmsByVegetativeStructureFetchStrategy strategy = new MockExistingGermplasmsByVegetativeStructureFetchStrategy();
        List germplasmsList = strategy.getGermplasmsWithActiveRoyalties(stagingInventory);
        assertEquals(0, germplasmsList.size());
    }


    class MockExistingGermplasmsByVegetativeStructureFetchStrategy extends ExistingGermplasmsByVegetativeStructureFetchStrategy {
        @Override
        protected GermplasmDAO getGermplasmDAO(StagingInventory stagingInventory) {
            return mockGermplasmDAO;
        }
    }

}
