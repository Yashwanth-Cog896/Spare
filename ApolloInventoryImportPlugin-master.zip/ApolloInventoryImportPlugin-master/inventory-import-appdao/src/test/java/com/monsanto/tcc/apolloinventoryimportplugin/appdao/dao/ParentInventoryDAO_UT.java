package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ParentInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.MidasSequence;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA. User: SSNALL Date: May 11, 2009 Time: 7:12:40 AM To change this template use File |
 * Settings | File Templates.
 */
public class ParentInventoryDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;


    public void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testParentInventoriesExist() {
        String ownerProgram = "9Z";
        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, "test", "testPedgree", ownerProgram, "Tomato");
        GeneticMaterial geneticMaterial = testHelper.createGeneticMaterial(germplasm, "SRC", "F1", "");
        Inventory inventory1 = testHelper.createInventory(geneticMaterial, "F", ownerProgram);
        Inventory inventory2 = testHelper.createInventory(geneticMaterial, "F", ownerProgram);
        ParentInventory parentInventory = new ParentInventory();
        parentInventory.setParentInventoryId(MidasSequence.getId());
        parentInventory.setInventory(inventory1);
        parentInventory.setParentInventory(inventory2);
        session.save(parentInventory);


        ParentInventoryDAO parentInventoryDAO = new ParentInventoryDAO();
        boolean exists = parentInventoryDAO.isParentInventoryExists(inventory1, inventory2);
        assertTrue(exists);

        Inventory inventory3 = testHelper.createInventory(geneticMaterial, "F", ownerProgram);
        Inventory inventory4 = testHelper.createInventory(geneticMaterial, "F", ownerProgram);
        parentInventoryDAO = new ParentInventoryDAO();
        exists = parentInventoryDAO.isParentInventoryExists(inventory3, inventory4);
        assertFalse(exists);


    }

}
