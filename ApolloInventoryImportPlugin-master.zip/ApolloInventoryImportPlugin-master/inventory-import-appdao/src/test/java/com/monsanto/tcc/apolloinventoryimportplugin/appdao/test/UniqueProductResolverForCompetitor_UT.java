package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.UniqueProductResolverForCompetitor;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA. User: aagosw Date: Oct 6, 2008 Time: 10:29:26 AM To change this template use File |
 * Settings | File Templates.
 */
public class UniqueProductResolverForCompetitor_UT extends TestIIContextConfigurer {
    private TestHelper testHelper;
    private Session session;
    private String CROP_NAME = "Corn";
    private String COMPETITOR_COMPANY = "CompetitorCompany";
    private String COMPETITOR_BRAND = "CompetitorBrand";
    private String COMPETITOR_COUNTRY = "CompetitorCountry";
    private static final String REF_ACTIVE_FALSE = "F";
    private static final String REF_ACTIVE_TRUE = "T";

    protected void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
    }

    protected void tearDown() {
        session.getTransaction().rollback();
    }

    public void testConstructor_CropIsNull_ThrowsIllegalArguementException() {
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setProductName("XX");
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        try {
            new UniqueProductResolverForCompetitor(stagingInventory);
            fail("Expected exception");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(UniqueProductResolverForCompetitor.REQUIRED_MSG) > -1);
        }
    }

    public void testConstructor_CropIsEmpty_ThrowsIllegalArguementException() {
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setProductName("XX");
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("");
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        try {
            new UniqueProductResolverForCompetitor(stagingInventory);
            fail("Expected exception");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(UniqueProductResolverForCompetitor.REQUIRED_MSG) > -1);
        }
    }

    public void testResolve_ProductNameIsNull__ThrowsIllegalArguementException() {
        StagingInventory stagingInventory = new StagingInventory();
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("YY");
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        try {
            new UniqueProductResolverForCompetitor(stagingInventory);
            fail("Expected exception");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(UniqueProductResolverForCompetitor.REQUIRED_MSG) > -1);
        }
    }

    public void testResolve_BrandNotSpecifiedOneProductNameRecordWithInactiveProduct_ReturnsNullAndMismatchErrorStatus() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_FALSE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            assertNull(resolver.resolve());

            assertTrue(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandNotSpecifiedOneProductNameRecordWithActiveProduct_ReturnsProductAndNoBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandSpecifiedOneProductNameRecordWithBrandMismatch_ReturnsSuccesAndNoBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            String brandName = "MISMATCH_BRAND";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(brandName);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandSpecifiedOneProductNameRecordWithBrandMatch_ReturnsSuccessAndBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(COMPETITOR_BRAND);


            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertTrue(resolver.isBrandNameMatched());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandSpecifiedMultipleProductNameRecordsWithMultipleBrandMatchAndProductMisMatch_ReturnsNullWithBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Product product1 = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product1, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(COMPETITOR_BRAND);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNull(foundProductName);
            assertFalse(resolver.isNoRecordExists());
            assertTrue(resolver.isBrandNameMatched());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }

    }

    public void testResolve_BrandSpecifiedMultipleProductNameRecordsWithMultipleBrandMatchAndProductMatch_ReturnsProductWithBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(COMPETITOR_BRAND);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertTrue(resolver.isBrandNameMatched());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandSpecifiedMultipleProductNameRecordsWithNoBrandMatchandNoUniqueProductId_ReturnsNullAndNoBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            String brandName = "MISMATCH_BRAND";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Product product1 = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product1, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(brandName);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNull(foundProductName);
            assertFalse(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandSpecifiedMultipleProductNameRecordsWithNoBrandMatchandUniqueProductId_ReturnsProductWithNoBrandNameMatch() {
        try {
            String pName = "COMPPRN1";
            String brandName = "MISMATCH_BRAND";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(brandName);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandSpecifiedMultipleProductNameRecordsWithOneBrandMatch_ReturnsProductWithBrandMatch() {
        try {
            String pName = "COMPPRN1";
            String brandName = "MISMATCH_BRAND";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Brand brand1 = testHelper.createBrand(company, brandName, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand1, country1, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);
            stagingInventory.setBrandName(COMPETITOR_BRAND);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertTrue(resolver.isBrandNameMatched());

        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandNotSpecifiedMultipleProductNameRecordsWithNoUniqueProductId_ReturnsNullAndNoBrandMatch() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Product product1 = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product1, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNull(foundProductName);
            assertFalse(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }

    public void testResolve_BrandNotSpecifiedMultipleProductNameRecordsWithUniqueProductId_ReturnsProductWithNoBrandMatch() {
        try {
            String pName = "COMPPRN1";
            Product product = testHelper.createProduct(CROP_NAME, REF_ACTIVE_TRUE);
            Company company = testHelper.createCompany(COMPETITOR_COMPANY, REF_ACTIVE_TRUE);
            Brand brand = testHelper.createBrand(company, COMPETITOR_BRAND, REF_ACTIVE_TRUE);
            Country country = testHelper.createCountry(COMPETITOR_COUNTRY, REF_ACTIVE_TRUE);
            Country country1 = testHelper.createCountry("ANOTHERCOUNTRY", REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country, product, pName, REF_ACTIVE_TRUE);
            testHelper.createProductName(brand, country1, product, pName, REF_ACTIVE_TRUE);

            StagingInventory stagingInventory = new StagingInventory();
            stagingInventory.setProductName(pName);
            StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
            stagingInventoryHeader.setCropName(CROP_NAME);
            stagingInventory.setInventoryHeader(stagingInventoryHeader);

            UniqueProductResolverForCompetitor resolver = new UniqueProductResolverForCompetitor(stagingInventory);
            ProductName foundProductName = resolver.resolve();

            assertNotNull(foundProductName);
            assertEquals(product.getId(), foundProductName.getProduct().getId());
            assertFalse(resolver.isNoRecordExists());
            assertFalse(resolver.isBrandNameMatched());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Did not expect exception");
        }
    }
}
