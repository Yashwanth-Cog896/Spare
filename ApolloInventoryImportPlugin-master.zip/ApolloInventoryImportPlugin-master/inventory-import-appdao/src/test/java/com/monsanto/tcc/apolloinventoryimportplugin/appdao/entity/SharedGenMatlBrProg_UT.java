package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class SharedGenMatlBrProg_UT {
    SharedGenMatlBrProg testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new SharedGenMatlBrProg();
    }

    @Test
    public void testSetterAndGetter() throws Exception {
        BrProg brprog = new BrProg();
        brprog.setBrProgId(-3L);
        GeneticMaterial gm = new GeneticMaterial();
        gm.setGeneticMaterialId(-4L);
        SharedGenMatlBrProgPk id = new SharedGenMatlBrProgPk(gm, brprog);

        testObject.setId(id);

        assertEquals(id, testObject.getId());
    }
}
