package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.XMLUtil.ParserException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;


public class IDUtil {

  public static long generateID(PersistentStoreConnection conn) throws WrappingException {
    return new MidasObjectIDBroker().nextID(conn);
  }

  public static long[] generateIDs(PersistentStoreConnection conn, int numIDs) throws WrappingException {
    long[] ids = new long[numIDs];
    for (int i = 0; i < numIDs; i++) {
      ids[i] = generateID(conn);
    }
    return ids;
  }

  public static long[] generateIDs(PersistentStoreConnection conn, int numIDs, long[] appendIDs) throws WrappingException {
    long[] ids = new long[numIDs + appendIDs.length];
    for (int i = 0; i < ids.length; i++) {
      ids[i] = (i < numIDs) ? generateID(conn) : appendIDs[i - numIDs];
    }
    return ids;
  }

  public static Document substituteID(Document doc, long id) throws IOException, ParserException {
    String docString = DOMUtil.getXMLString(doc);
    docString = docString.replaceAll("\\[id0\\]", Long.toString(id));
    doc = DOMUtil.newDocumentNS((new StringReader(docString)));
    return doc;
  }

  public static Document substituteIDs(Document doc, long[] ids) throws IOException, ParserException {
    String docString = DOMUtil.getXMLString(doc);
    for (int i = 0; i < ids.length; i++) {
      docString = docString.replaceAll("\\[id" + i + "\\]", Long.toString(ids[i]));
    }
    doc = DOMUtil.newDocumentNS((new StringReader(docString)));
    return doc;
  }

  public static Document substituteIDs(Document doc, String key, Object value) throws IOException, ParserException,
          EmptyResultSetException, WrappingException {
    String docString = DOMUtil.getXMLString(doc);
    docString = docString.replaceAll("\\[" + key + "\\]", value.toString());
    doc = DOMUtil.newDocumentNS((new StringReader(docString)));
    return doc;
  }

  public static Document createDocumentWithDynamicIDs(String fileName, String schemaName, long[] ids) throws IOException,
          ParserException, SAXException {
    Document doc = DOMUtil.newDocument(fileName);
    doc = IDUtil.substituteIDs(doc, ids);
//        if (!DOMUtil.isValidAccordingToSchema(doc, schemaName)) {
//            DOMUtil.outputXML(doc);
//            throw new SAXException("Document not valid.");
//        }
    return doc;
  }

}
