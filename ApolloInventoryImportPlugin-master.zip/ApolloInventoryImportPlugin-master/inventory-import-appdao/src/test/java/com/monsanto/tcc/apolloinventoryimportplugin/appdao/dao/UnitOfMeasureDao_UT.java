package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.UnitOfMeasure;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.junit.Test;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: 8/3/11
 * Time: 1:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class UnitOfMeasureDao_UT extends TestIIContextConfigurer {

    Session session;


    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        if (session != null && session.isOpen()) {
            session.getTransaction().rollback();
        }
        super.tearDown();
    }


    @Test
    public void testSeedUnitOfMeasure() {
        UnitOfMeasureDao unitOfMeasureDao = new UnitOfMeasureDao();
        List<UnitOfMeasure> seedUOMs = unitOfMeasureDao.getSeedUOMs();
        assertTrue(seedUOMs.size() >= 4);
    }

    @Test
    public void getUnitOfMeasureByName() {
        UnitOfMeasureDao unitOfMeasureDao = new UnitOfMeasureDao();
        UnitOfMeasure seed = unitOfMeasureDao.getUnitOfMeasureByName("Seed");
        assertTrue(seed != null);
    }

    @Test
    public void testIsUOMValidWithValidValue() {
        UnitOfMeasureDao unitOfMeasureDao = new UnitOfMeasureDao();
        assertTrue(unitOfMeasureDao.isValid("Seed"));
    }

    @Test
    public void testIsUOMValidWithinValidValue() {
        UnitOfMeasureDao unitOfMeasureDao = new UnitOfMeasureDao();
        assertFalse(unitOfMeasureDao.isValid("ABCDEF"));
    }


}
