package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 19, 2008 Time: 12:52:55 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProductGermPlasmDAO_UT extends TestIIContextConfigurer {
    private TestHelper testHelper;
    private Session session;


    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetProductGermplasmListForProducts_HasProductListWithNoAssociatedValidGermPlasm() throws
            Exception {
        String origin = "ABC/ADEA";
        String lineCode = "ABCSP";
        String cropName = "Corn";
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String cytoplasmDonorPedigree = "17_RES/SDF:@.1.>";
        List<Product> productList = new ArrayList<Product>();
        Product product1 = createProduct("Corn");
        Product product2 = createProduct("Corn");
        Product product3 = createProduct("Corn");
        productList.add(product1);
        productList.add(product2);
        productList.add(product3);
        Germplasm gp1 = createGermplasm(MaterialTypeConstants.SEGPOP_LINES, lineCode, origin, "17",
                cropName, "F", "F", "B", cytoplasmDonorPedigree);
        String onionOwnerProgram = "9Z";
        Germplasm gp2 = createGermplasm(lineType, lineCode, origin, onionOwnerProgram,
                "Tomato", "F", "F", "B", cytoplasmDonorPedigree);
        Germplasm gp3 = createGermplasm(MaterialTypeConstants.HYBRID_LINES, lineCode, origin, "17",
                cropName, "F", "T", "B", cytoplasmDonorPedigree);
        createProductGermplasm(product1, gp1);
        createProductGermplasm(product2, gp2);
        createProductGermplasm(product3, gp3);
        ProductGermPlasmDAO productGermPlasmDAO = new ProductGermPlasmDAO("Corn",
                new String[]{MaterialTypeConstants.FINISHED_LINES});
        List productGermplasmList = productGermPlasmDAO.getProductGermplasmListForProducts(productList);
        assertNotNull(productGermplasmList);
        assertEquals(0, productGermplasmList.size());
    }

    public void testGetProductGermplasmListForProducts_HasProductListWithOneAssociatedValidGermPlasm() throws
            Exception {
        String origin = "ABCZYX";
        String lineCode = "ABCSP";
        String cropName = "Corn";
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String cytoplasmDonorPedigree = "17_RES/SDF:@.1.>";
        List<Product> productList = new ArrayList<Product>();
        Product product1 = createProduct("Corn");
        productList.add(product1);
        Product product2 = createProduct("Corn");
        Product product3 = createProduct("Corn");
        productList.add(product1);
        productList.add(product2);
        productList.add(product3);
        Germplasm gp1 = createGermplasm(MaterialTypeConstants.FINISHED_LINES, lineCode, origin, "17",
                cropName, "F", "T", "B", cytoplasmDonorPedigree);
        String onionOwnerProgram = "9Z";
        Germplasm gp2 = createGermplasm(lineType, lineCode, origin, onionOwnerProgram,
                "Tomato", "F", "F", "B", cytoplasmDonorPedigree);
        Germplasm gp3 = createGermplasm(MaterialTypeConstants.HYBRID_LINES, lineCode, origin, "17",
                cropName, "F", "T", "B", cytoplasmDonorPedigree);
        createProductGermplasm(product1, gp1);
        createProductGermplasm(product2, gp2);
        createProductGermplasm(product3, gp3);
        ProductGermPlasmDAO productGermPlasmDAO = new ProductGermPlasmDAO("Corn",
                new String[]{MaterialTypeConstants.FINISHED_LINES});
        List germplasmList = productGermPlasmDAO.getProductGermplasmListForProducts(productList);
        assertNotNull(germplasmList);
        assertEquals(1, germplasmList.size());
    }

    public void testGetProductGermplasmListForProducts_HasProductListWithTwoAssociatedValidGermPlasm() throws
            Exception {
        String origin = "ABC/ADEA";
        String lineCode = "ABCSP";
        String cropName = "Corn";
        String lineType = MaterialTypeConstants.FINISHED_LINES;
        String cytoplasmDonorPedigree = "17_RES/SDF:@.1.>";
        List<Product> productList = new ArrayList<Product>();
        Product product1 = createProduct("Corn");
        Product product2 = createProduct("Corn");
        Product product3 = createProduct("Corn");
        productList.add(product1);
        productList.add(product2);
        productList.add(product3);
        Germplasm gp1 = createGermplasm(MaterialTypeConstants.FINISHED_LINES, lineCode, origin, "17",
                cropName, "F", "T", "B", cytoplasmDonorPedigree);
        String onionOwnerProgram = "9Z";
        Germplasm gp2 = createGermplasm(lineType, lineCode, origin, onionOwnerProgram,
                "Tomato", "F", "F", "B", cytoplasmDonorPedigree);
        Germplasm gp3 = createGermplasm(MaterialTypeConstants.FINISHED_LINES, lineCode, origin, "17",
                cropName, "F", "T", "B", cytoplasmDonorPedigree);
        createProductGermplasm(product1, gp1);
        createProductGermplasm(product2, gp2);
        createProductGermplasm(product3, gp3);
        ProductGermPlasmDAO productGermPlasmDAO = new ProductGermPlasmDAO("Corn",
                new String[]{MaterialTypeConstants.FINISHED_LINES});
        List germplasmList = productGermPlasmDAO.getProductGermplasmListForProducts(productList);
        assertNotNull(germplasmList);
        assertEquals(2, germplasmList.size());
    }

    public void testGetProductGermplasmListMatchingOrigin_HasNoMatchingOrigin() throws Exception {
        String origin = "TESTORIGIN3";
        String lineCode = "ABCSP";
        String cropName = "Corn";
        String cytoplasmDonorPedigree = "17_RES/SDF:@.1.>";
        Product product1 = createProduct("Corn");
        Germplasm gp1 = createGermplasm(MaterialTypeConstants.FINISHED_LINES, lineCode, "NOMATCHORIGIN", "17", cropName,
                "F", "T", "B", cytoplasmDonorPedigree);
        Germplasm gp2 = createGermplasm(MaterialTypeConstants.SEGPOP_LINES, lineCode, origin, "17", cropName, "F", "T",
                "B", cytoplasmDonorPedigree);
        createProductGermplasm(product1, gp1);
        createProductGermplasm(product1, gp2);
        ProductGermPlasmDAO productGermPlasmDAO =
                new ProductGermPlasmDAO("Corn",
                        new String[]{MaterialTypeConstants.FINISHED_LINES, MaterialTypeConstants.HYBRID_LINES});
        List germplasmList = productGermPlasmDAO.getProductGermplasmListMatchingOrigin(origin);
        assertNotNull(germplasmList);
        assertEquals(0, germplasmList.size());
    }

    public void testGetProductGermplasmListMatchingOrigin_HasOneMatchingOriginForHybridLine() throws Exception {
        String origin = "TESTORIGIN3";
        String lineCode = "ABCSP";
        String cropName = "Corn";
        String cytoplasmDonorPedigree = "17_RES/SDF:@.1.>";
        Product product1 = createProduct("Corn");
        Germplasm gp1 = createGermplasm(MaterialTypeConstants.FINISHED_LINES, lineCode, "NOMATCHORIGIN", "17", cropName,
                "F", "T", "B", cytoplasmDonorPedigree);
        Germplasm gp2 = createGermplasm(MaterialTypeConstants.HYBRID_LINES, lineCode, origin, "17", cropName, "F", "T",
                "B", cytoplasmDonorPedigree);
        createProductGermplasm(product1, gp1);
        createProductGermplasm(product1, gp2);
        ProductGermPlasmDAO productGermPlasmDAO =
                new ProductGermPlasmDAO("Corn",
                        new String[]{MaterialTypeConstants.FINISHED_LINES, MaterialTypeConstants.HYBRID_LINES});
        List germplasmList = productGermPlasmDAO.getProductGermplasmListMatchingOrigin(origin);
        assertNotNull(germplasmList);
        assertEquals(1, germplasmList.size());
    }

    public void testGetProductGermplasmListMatchingOrigin_HasTwoMatchingOriginsForHybridLineAndFinishedLine() throws
            Exception {
        String origin = "TESTORIGIN3";
        String lineCode = "ABCSP1";
        String cropName = "Corn";
        String cytoplasmDonorPedigree = "17_RES/SDF:@.1.>";
        Product product1 = createProduct("Corn");
        Germplasm gp1 = createGermplasm(MaterialTypeConstants.FINISHED_LINES, lineCode, origin, "17", cropName, "F", "T",
                "B", cytoplasmDonorPedigree);
        Germplasm gp2 = createGermplasm(MaterialTypeConstants.HYBRID_LINES, lineCode, origin, "17", cropName, "F", "T",
                "B", cytoplasmDonorPedigree);
        createProductGermplasm(product1, gp1);
        createProductGermplasm(product1, gp2);
        ProductGermPlasmDAO productGermPlasmDAO =
                new ProductGermPlasmDAO("Corn",
                        new String[]{MaterialTypeConstants.FINISHED_LINES, MaterialTypeConstants.HYBRID_LINES});
        List germplasmList = productGermPlasmDAO.getProductGermplasmListMatchingOrigin(origin);
        assertNotNull(germplasmList);
        assertEquals(2, germplasmList.size());
    }

    public void testGetProductGermplasmListForProducts_HasEmptyProductName() throws
            Exception {
        try {
            new ProductGermPlasmDAO("", null);
            fail("Expecting exception for empty string in constructor.");
        } catch (IllegalArgumentException e) {
        }
    }

    private Product createProduct(String cropName) throws Exception {
        return testHelper.createProduct(cropName, "T");
    }

    private Germplasm createGermplasm(String lineType, String lineCode, String origin,
                                      String ownerProgram, String cropName, String gpIsDeleted,
                                      String finishedOrFinishedChild, String lineFunction,
                                      String cytoplasmDonorPedigree) {
        return testHelper.createGermplasm(lineType, lineCode, origin, lineCode, ownerProgram,
                cropName, gpIsDeleted, finishedOrFinishedChild, lineFunction, cytoplasmDonorPedigree);
    }

    private void createProductGermplasm(Product product, Germplasm gp) {
        testHelper.createProductGermplasm(product, gp);
    }
}