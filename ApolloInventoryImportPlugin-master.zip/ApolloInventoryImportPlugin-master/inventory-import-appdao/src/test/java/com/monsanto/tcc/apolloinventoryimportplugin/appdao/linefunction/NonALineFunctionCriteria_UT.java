/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import org.hibernate.Criteria;
import org.hibernate.Session;

/**
 * Filename:    $RCSfile: NonALineFunctionCriteria_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $ On:	$Date: 2008-02-17 22:58:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NonALineFunctionCriteria_UT extends TestIIContextConfigurer {
    private Session session;

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testAddCriteriaAddsLineFunctionCriteria() throws Exception {
        String germplasmAlias = "gp";

        Criteria criteria = session.createCriteria(Germplasm.class, germplasmAlias);
        assertFalse(criteria.toString().indexOf(germplasmAlias + ".lineFunction") >= 0);
        assertFalse(criteria.toString().indexOf("lfunc.lineFunctionRefId=" + LineFunctionConstants.B_LINE_FUNCTION) >= 0);
        assertFalse(criteria.toString().indexOf("lfunc.refActive=T") >= 0);

        new NonALineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION).addCriteria(germplasmAlias, criteria);
        assertTrue(criteria.toString().indexOf(germplasmAlias + ".lineFunction") >= 0);
        assertTrue(criteria.toString().indexOf("lfunc.lineFunctionRefId=" + LineFunctionConstants.B_LINE_FUNCTION) >= 0);
        assertTrue(criteria.toString().indexOf("lfunc.refActive=T") >= 0);
    }

    public void testAddStagingInventoryCriteriaAddsLineFunctionCriteria() throws Exception {
        String stagingInventoryAlias = "si";

        Criteria criteria = session.createCriteria(Germplasm.class, stagingInventoryAlias);
        assertFalse(criteria.toString().indexOf(stagingInventoryAlias + ".lineFunction") >= 0);

        new NonALineFunctionCriteria(LineFunctionConstants.B_LINE_FUNCTION)
                .addStagingInventoryCriteria(stagingInventoryAlias, criteria);
        assertTrue(
                criteria.toString().indexOf(stagingInventoryAlias + ".lineFunction=" + LineFunctionConstants.B_LINE_FUNCTION) >=
                        0);
    }

    public void testLineFunctionIsA_ThrowsException() throws Exception {
        try {
            new NonALineFunctionCriteria(LineFunctionConstants.A_LINE_FUNCTION);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("cannot be \"A\"") >= 0);
        }
    }

    public void testLineFunctionValueIsRequired_LineFunctionValueIsNullThrowsException() throws Exception {
        try {
            new NonALineFunctionCriteria(null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("required") >= 0);
        }
    }

    public void testLineFunctionValueIsRequired_LineFunctionValueIsEmptyStringThrowsException() throws Exception {
        try {
            new NonALineFunctionCriteria("");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("required") >= 0);
        }
    }

    public void testLineFunctionValueIsRequired_LineFunctionValueIsWhiteSpaceStringThrowsException() throws Exception {
        try {
            new NonALineFunctionCriteria("  \t \t  ");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("required") >= 0);
        }
    }
}