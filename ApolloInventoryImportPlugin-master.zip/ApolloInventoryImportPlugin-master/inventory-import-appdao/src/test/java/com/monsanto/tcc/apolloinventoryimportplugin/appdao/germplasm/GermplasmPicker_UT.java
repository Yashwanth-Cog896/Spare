package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.google.common.collect.Lists;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.GermplasmPickerDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.List;

import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by Dan Schnettgoecke on 6/18/12 at 9:42 AM.
 */

public class GermplasmPicker_UT {

    private GermplasmPicker germplasmPicker;
    @Mock
    private GermplasmPickerDAO germplasmPickerDao;
    @Mock
    private GermplasmListFetchStrategy germplasmListFetchStrategy;

    @Before
    public void setup() {
        initMocks(this);
        germplasmPicker = new MockGermplasmPicker();
    }

    @Test
    public void zeroGermplasms() {
        when(germplasmListFetchStrategy.getGermplasms(null)).thenReturn(null);

        Germplasm germplasm = germplasmPicker.getPrimaryGermplasm(null, germplasmListFetchStrategy);

        assertThat(germplasm, nullValue());
    }

    @Test
    public void oneGermplasm() {
        Germplasm germplasm = new Germplasm();
        when(germplasmListFetchStrategy.getGermplasms(null)).thenReturn(Lists.newArrayList(germplasm));

        Germplasm result = germplasmPicker.getPrimaryGermplasm(null, germplasmListFetchStrategy);

        assertThat(result, sameInstance(germplasm));
    }

    @Test
    public void moreThanOneGermplasm() {
        Germplasm germplasm = new Germplasm();
        when(germplasmListFetchStrategy.getGermplasms(null)).thenReturn(Lists.newArrayList(new Germplasm(), new Germplasm()));
        when(germplasmPickerDao.getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials()).thenReturn(germplasm);

        Germplasm result = germplasmPicker.getPrimaryGermplasm(null, germplasmListFetchStrategy);

        assertThat(result, sameInstance(germplasm));
        verify(germplasmPickerDao).getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();
    }

    private class MockGermplasmPicker extends GermplasmPicker {
        @Override
        protected GermplasmPickerDAO createGermplasmPickerDAO(List germplasms) {
            return germplasmPickerDao;
        }
    }

}