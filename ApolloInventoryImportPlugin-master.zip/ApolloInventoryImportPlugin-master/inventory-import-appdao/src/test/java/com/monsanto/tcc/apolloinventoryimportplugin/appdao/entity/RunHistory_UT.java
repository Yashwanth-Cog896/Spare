package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class RunHistory_UT {
    RunHistory testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new RunHistory();
    }

    @Test
    public void testSetId() throws Exception {
        Long id = 98l;
        Timestamp endDate = new Timestamp(453455654l);
        ProcessName processName = new ProcessName();
        processName.setId(-45l);
        Long recordsProcessed = 7l;
        RunStatus runStatus = new RunStatus();
        runStatus.setId(-876l);
        Timestamp startDate = new Timestamp(43564678l);

        testObject.setId(id);
        testObject.setEndDate(endDate);
        testObject.setProcessName(processName);
        testObject.setRecordsProcessed(recordsProcessed);
        testObject.setRunStatus(runStatus);
        testObject.setStartDate(startDate);

        assertEquals(id, testObject.getId());
        assertEquals(endDate, testObject.getEndDate());
        assertEquals(processName, testObject.getProcessName());
        assertEquals(recordsProcessed, testObject.getRecordsProcessed());
        assertEquals(runStatus, testObject.getRunStatus());
        assertEquals(startDate, testObject.getStartDate());
    }
}
