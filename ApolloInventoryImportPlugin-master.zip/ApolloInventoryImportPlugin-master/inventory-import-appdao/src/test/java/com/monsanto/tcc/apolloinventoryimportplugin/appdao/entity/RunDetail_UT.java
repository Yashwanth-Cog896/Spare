package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 1:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class RunDetail_UT {
    RunDetail testObect;

    @Before
    public void setUp() throws Exception {
        testObect = new RunDetail();
    }

    @Test
    public void testSetId() throws Exception {
        Long id = -11l;
        Long inventoryId = -21l;
        String processMsg = "process";
        RunHistory runHistory = new RunHistory();
        runHistory.setId(-32l);
        String validationExceptionMsg = "exMsg";
        ImportStatus importStatus = new ImportStatus();
        importStatus.setId(-6l);

        testObect.setId(id);
        testObect.setInventoryId(inventoryId);
        testObect.setProcessExceptionMsg(processMsg);
        testObect.setRunHistory(runHistory);
        testObect.setValidationExceptionMsg(validationExceptionMsg);
        testObect.setValidationStatus(importStatus);

        assertEquals(id, testObect.getId());
        assertEquals(inventoryId, testObect.getInventoryId());
        assertEquals(processMsg, testObect.getProcessExceptionMsg());
        assertEquals(runHistory, testObect.getRunHistory());
        assertEquals(importStatus, testObect.getValidationStatus());
        assertEquals(validationExceptionMsg, testObect.getValidationExceptionMsg());
    }
}
