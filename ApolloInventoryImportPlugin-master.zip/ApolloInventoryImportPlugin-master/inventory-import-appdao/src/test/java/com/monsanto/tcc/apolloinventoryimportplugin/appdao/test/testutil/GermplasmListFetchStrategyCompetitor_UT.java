/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Company;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.GermplasmListFetchStrategyCompetitor;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyCompetitor_UT.java,v $ Label:       $Name: not supported by cvs2svn
 * $ Last Change: $Author: ddbrow5 $    	 On:	$Date: 2008-10-10 20:58:44 $
 *
 * @author SSPEYY
 * @version $Revision: 1.4 $
 */
public class GermplasmListFetchStrategyCompetitor_UT extends TestIIContextConfigurer {
    private static final String USA_COUNTRY_NAME = "United States of America";
    private static final String ANOTHER_COUNTRY_NAME = "Canada";
    private static final String LINE_CODE = "COM";
    private static final String CROP_NAME = "Corn";
    private static final String COMM_PRD_NAME = "PRDCOMM";
    private static final String COMP_PRD_NAME = "PRDCOMPETITOR";
    private static final String FINISHED = MaterialTypeConstants.FINISHED_LINES;
    private static final String INBRED = "INBRED";
    private static final String PIPE_STR = "|";
    private static final String OWNER_BR_PROG_REF_ID = "17";
    private static final String SOURCE_STR = "SOME SOURCE XXX";
    private static final String FALSE_STRING = "F";
    private static final String ORIGIN = "COMM/COMP";
    private static final String TRUE_STRING = "T";
    private TestHelper testHelper;
    private Session session;
    private String userId;
    private String templateName;

    public GermplasmListFetchStrategyCompetitor_UT(String name) {
        super(name);
        templateName = this.getClass().getName();
        userId = System.getProperty("user.name");
    }

    protected void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        testHelper = new TestHelper(session);
        session.beginTransaction();
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
    }

    public void testGetGermplasmListForCompetitorProductReturnsNoneWhenNoCompetitorProductWithProductNameExists() {
        String monsantobrandName = testHelper.getMonsantoBrandName();

        StagingInventoryHeader stagingInventoryHeader = testHelper
                .createStagingInventoryHeader(templateName, GermplasmListFetchStrategyCompetitor_UT.CROP_NAME, userId,
                        FINISHED);
        StagingInventory stagingInventory = testHelper.createStagingInventory(stagingInventoryHeader, FINISHED, ORIGIN,
                SOURCE_STR, null, null, null, null, OWNER_BR_PROG_REF_ID, OWNER_BR_PROG_REF_ID, FINISHED, userId, INBRED,
                PIPE_STR, LINE_CODE, null, null,
                null);
        stagingInventory.setProductName(COMM_PRD_NAME);
        Product product = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        createProductGermplasmWithProductName(MaterialTypeConstants.FINISHED_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMM_PRD_NAME, monsantobrandName,
                USA_COUNTRY_NAME, FALSE_STRING, null, null, product);
        createProductGermplasmWithProductName(MaterialTypeConstants.HYBRID_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMM_PRD_NAME, monsantobrandName,
                ANOTHER_COUNTRY_NAME, FALSE_STRING, null, null, product);

        try {
            GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
            List germplasmList = strategy.getGermplasms(stagingInventory);

            assertNotNull(germplasmList);
            assertEquals(0, germplasmList.size());
        } catch (Exception e) {
            e.printStackTrace();
            fail("did not expect exception");
        }
    }

    public void testGetGermplasmListForCompetitorProductReturnsOneCompetitorProductWithProductName() {
        String nonMonsantobrandName = testHelper.getNonMonsantoBrandName();

        StagingInventoryHeader stagingInventoryHeader = testHelper
                .createStagingInventoryHeader(templateName, GermplasmListFetchStrategyCompetitor_UT.CROP_NAME, userId,
                        FINISHED);
        StagingInventory stagingInventory = testHelper.createStagingInventory(stagingInventoryHeader, FINISHED, ORIGIN,
                SOURCE_STR, null, null, null, null, OWNER_BR_PROG_REF_ID, OWNER_BR_PROG_REF_ID, FINISHED, userId, INBRED,
                PIPE_STR, LINE_CODE, null, null,
                null);
        stagingInventory.setProductName(COMP_PRD_NAME);
        Product product = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        createProductGermplasmWithProductName(MaterialTypeConstants.FINISHED_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, nonMonsantobrandName,
                USA_COUNTRY_NAME, FALSE_STRING, null, null, product);
        createProductGermplasmWithProductName(MaterialTypeConstants.HYBRID_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, nonMonsantobrandName,
                ANOTHER_COUNTRY_NAME, FALSE_STRING, null, null, product);

        try {
            GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
            List germplasmList = strategy.getGermplasms(stagingInventory);

            assertNotNull(germplasmList);
            assertEquals(2, germplasmList.size());
        } catch (Exception e) {
            e.printStackTrace();
            fail("did not expect exception");
        }
    }

    public void testMultipleProductsWithSameProductNameAndDifferentBrandNamesReturnsGermplasmsMatchingStagingInventorysBrandName() {
        String stagingInventoryBrandName = "GermplasmListFetchStrategyCompetitor_UT-SI".toUpperCase();
        String monsantoBrandName = "GermplasmListFetchStrategyCompetitor_UT".toUpperCase();

        Company competitorCompany = testHelper.getCompetitorCompany();
        testHelper.createBrand(competitorCompany, stagingInventoryBrandName, "T");
        testHelper.createBrand(competitorCompany, monsantoBrandName, "T");

        StagingInventoryHeader stagingInventoryHeader = testHelper
                .createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
        StagingInventory stagingInventory = testHelper.createStagingInventory(stagingInventoryHeader, FINISHED, ORIGIN,
                SOURCE_STR, null, null, null, null, OWNER_BR_PROG_REF_ID, OWNER_BR_PROG_REF_ID, FINISHED, userId, INBRED,
                PIPE_STR, LINE_CODE, null, null, null);
        stagingInventory.setProductName(COMP_PRD_NAME);
        stagingInventory.setBrandName(stagingInventoryBrandName);
        Product product1 = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        Product product2 = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        createProductGermplasmWithProductName(MaterialTypeConstants.FINISHED_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, monsantoBrandName, USA_COUNTRY_NAME, FALSE_STRING, null, null, product1);
        ProductGermplasm productGermplasm = createProductGermplasmWithProductName(MaterialTypeConstants.FINISHED_LINES,
                LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, stagingInventoryBrandName, USA_COUNTRY_NAME, FALSE_STRING, null, null, product2);

        createProductGermplasmWithProductName(MaterialTypeConstants.HYBRID_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, monsantoBrandName, ANOTHER_COUNTRY_NAME, FALSE_STRING, null, null, product1);


        try {
            GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
            List germplasmList = strategy.getGermplasms(stagingInventory);

            assertNotNull(germplasmList);
            assertEquals(1, germplasmList.size());
            assertEquals(productGermplasm.getGermplasm().getId(), ((Germplasm) germplasmList.get(0)).getId());
        } catch (Exception e) {
            e.printStackTrace();
            fail("did not expect exception");
        }
    }

    public void testCompetitorProductExistsGermplasmDoesNotExist_ReturnsNull() {
        String stagingInventoryBrandName = "GermplasmListFetchStrategyCompetitor_UT-SI".toUpperCase();
        String monsantoBrandName = "GermplasmListFetchStrategyCompetitor_UT".toUpperCase();

        Company competitorCompany = testHelper.getCompetitorCompany();
        testHelper.createBrand(competitorCompany, stagingInventoryBrandName, "T");
        testHelper.createBrand(competitorCompany, monsantoBrandName, "T");

        StagingInventoryHeader stagingInventoryHeader = testHelper
                .createStagingInventoryHeader(templateName, CROP_NAME, userId, FINISHED);
        StagingInventory stagingInventory = testHelper.createStagingInventory(stagingInventoryHeader, FINISHED, ORIGIN,
                SOURCE_STR, null, null, null, null, OWNER_BR_PROG_REF_ID, OWNER_BR_PROG_REF_ID, FINISHED, userId, INBRED,
                PIPE_STR, LINE_CODE, null, null, null);
        stagingInventory.setProductName(COMP_PRD_NAME);
        stagingInventory.setBrandName(stagingInventoryBrandName);
        Product product = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        createProductName(COMP_PRD_NAME, stagingInventoryBrandName, USA_COUNTRY_NAME, product);

        try {
            GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
            List germplasmList = strategy.getGermplasms(stagingInventory);

            assertEquals(0, germplasmList.size());
        } catch (Exception e) {
            e.printStackTrace();
            fail("did not expect exception");
        }
    }

    public void testGetGermplasmListForCompetitorProductReturnsZeroForGermplasmIs_DeletedTrue() {
        String monsantobrandName = testHelper.getMonsantoBrandName();

        StagingInventoryHeader stagingInventoryHeader = testHelper
                .createStagingInventoryHeader(templateName, GermplasmListFetchStrategyCompetitor_UT.CROP_NAME, userId,
                        FINISHED);
        StagingInventory stagingInventory = testHelper.createStagingInventory(stagingInventoryHeader, FINISHED, ORIGIN,
                SOURCE_STR, null, null, null, null, OWNER_BR_PROG_REF_ID, OWNER_BR_PROG_REF_ID, FINISHED, userId, INBRED,
                PIPE_STR, LINE_CODE, null, null,
                null);
        stagingInventory.setProductName(COMP_PRD_NAME);
        Product product = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        createProductGermplasmWithProductName(MaterialTypeConstants.FINISHED_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, monsantobrandName,
                USA_COUNTRY_NAME, TRUE_STRING, null, null, product);

        try {
            GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
            List germplasmList = strategy.getGermplasms(stagingInventory);

            assertNotNull(germplasmList);
            assertEquals(0, germplasmList.size());
        } catch (Exception e) {
            e.printStackTrace();
            fail("did not expect exception");
        }
    }

    public void testGetGermplasmListForCompetitorProductReturnsZeroForGermplasmLineTypeIsSegpoop() {
        String monsantobrandName = testHelper.getMonsantoBrandName();
        StagingInventoryHeader stagingInventoryHeader = testHelper
                .createStagingInventoryHeader(templateName, GermplasmListFetchStrategyCompetitor_UT.CROP_NAME, userId,
                        FINISHED);
        StagingInventory stagingInventory = testHelper.createStagingInventory(stagingInventoryHeader, FINISHED, ORIGIN,
                SOURCE_STR, null, null, null, null, OWNER_BR_PROG_REF_ID, OWNER_BR_PROG_REF_ID, FINISHED, userId, INBRED,
                PIPE_STR, LINE_CODE, null, null,
                null);
        stagingInventory.setProductName(COMP_PRD_NAME);
        Product product = testHelper.createProduct(CROP_NAME, TRUE_STRING);
        createProductGermplasmWithProductName(MaterialTypeConstants.FINISHED_LINES, LINE_CODE, ORIGIN, CROP_NAME,
                COMP_PRD_NAME, monsantobrandName,
                USA_COUNTRY_NAME, TRUE_STRING, "A", null, product);

        try {
            GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
            List germplasmList = strategy.getGermplasms(stagingInventory);

            assertNotNull(germplasmList);
            assertEquals(0, germplasmList.size());
        } catch (Exception e) {
            e.printStackTrace();
            fail("did not expect exception");
        }
    }

    public void testGermplasmListFetchStrategyCompetitor_Returns_emptyListOfGermplasmRoyalties() {
        GermplasmListFetchStrategyCompetitor strategy = new GermplasmListFetchStrategyCompetitor();
        List germplasmList = strategy.getGermplasmsWithActiveRoyalties(null);
        assertEquals(0, germplasmList.size());
    }

    private ProductGermplasm createProductGermplasmWithProductName(String lineType, String lineCode, String origin,
                                                                   String cropName,
                                                                   String productNameString,
                                                                   String brandName, String countryName,
                                                                   String gpIsDeleted,
                                                                   String lineFunction, String cytoplasmDonorPedigree,
                                                                   Product product) {
        Germplasm gp = testHelper.createGermplasm(lineType, lineCode, origin, lineCode, OWNER_BR_PROG_REF_ID,
                cropName, gpIsDeleted, TRUE_STRING, lineFunction, cytoplasmDonorPedigree);
        ProductGermplasm productGermplasm = testHelper.createProductGermplasm(product, gp);
        createProductName(productNameString, brandName, countryName, product);
        return productGermplasm;
    }

    private void createProductName(String productNameString, String brandName, String countryName, Product product) {
        testHelper.createProductName(productNameString, TRUE_STRING, brandName, countryName, product);
    }

}