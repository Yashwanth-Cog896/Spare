package com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GermplasmRoyalty;
import org.junit.Test;

import java.sql.Date;
import java.sql.Timestamp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 22, 2010
 * Time: 9:28:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmRoyalty_UT {
    private static final Long GERMPLASM_ROYALTY_ID = new Long(200);
    private static final Long GERMPLASM_ID = new Long(-2000);
    private static final Long ROYALTY_CONTRACT_ID = new Long(3000);
    private static final Date INACTIVE_DT = new Date(System.currentTimeMillis());
    private static final Timestamp MODIFIED_DT = new Timestamp(System.currentTimeMillis());
    private static final String ROYALTY_IND = "T";

    @Test
    public void testGermplasmRoyalty_Setters() {
        GermplasmRoyalty germplasmRoyalty = new GermplasmRoyalty();
        assertNotNull(germplasmRoyalty);
        Germplasm germplasm = new Germplasm();
        germplasm.setId(GERMPLASM_ID);
        germplasmRoyalty.setGermplasm(germplasm);
        germplasmRoyalty.setGermplasmRoyaltyId(GERMPLASM_ROYALTY_ID);
        germplasmRoyalty.setRoyaltyContractId(ROYALTY_CONTRACT_ID);
        germplasmRoyalty.setInactiveDt(INACTIVE_DT);
        germplasmRoyalty.setModifiedDt(MODIFIED_DT);
        germplasmRoyalty.setRoyaltyInd(ROYALTY_IND);
        germplasmRoyalty.setExternalGermplasmName("A");

        assertEquals(GERMPLASM_ID, germplasmRoyalty.getGermplasm().getId());
        assertEquals(GERMPLASM_ROYALTY_ID, germplasmRoyalty.getGermplasmRoyaltyId());
        assertEquals(ROYALTY_CONTRACT_ID, germplasmRoyalty.getRoyaltyContractId());
        assertEquals(INACTIVE_DT, germplasmRoyalty.getInactiveDt());
        assertEquals(MODIFIED_DT, germplasmRoyalty.getModifiedDt());
        assertEquals(ROYALTY_IND, germplasmRoyalty.getRoyaltyInd());
        assertEquals("A", germplasmRoyalty.getExternalGermplasmName());
    }
}
