/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;


import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.dbdataservices.SQLUtil;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: TestTools.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $    	 On:	$Date: 2008-04-24 17:29:35 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.2 $
 * @noinspection MethodWithTooManyParameters,OverlyLongMethod
 */
public class TestTools {

  private static long midasCornCropID;
  private static long midasMonsantoBrandID;
  private static long midasUSACountryID;
  private static String activeCornBrProgRefID = "";
  private static long midasCompanyID;
  private static String brProgRefIdForGermplasmManager = "";

  public static void insertFakeParentage(PersistentStoreConnection conn, long parentageID, long geneticMaterialID,
                                         long parentGeneticMaterialID, String parentalRoleRefID) throws
      WrappingException {
    String sql =
        "INSERT INTO MIDAS.PARENTAGE (PARENTAGE_ID, GENETIC_MATERIAL_ID, PARENT_GENETIC_MATERIAL_ID, PARENTAL_ROLE_ID, IS_TESTER) " +
            "VALUES(" + parentageID + ", " + geneticMaterialID + ", " + parentGeneticMaterialID + ", " +
            "(select parental_role_id from midas.parental_role where parental_role_ref_id = '" + parentalRoleRefID +
            "'), 'F')";
    insertIntoDB(conn, sql);
  }

  public static void updateGermplasmIsDeletedToTrue(PersistentStoreConnection conn, long germplasmId) throws
      WrappingException {
    String sql = "update midas.germplasm set is_deleted = 'T' where germplasm_id = " + germplasmId;
    conn.executeUpdate(sql);
  }

  public static void updateGermplasmIsDeletedToFalse(PersistentStoreConnection conn, long germplasmId) throws
      WrappingException {
    String sql = "update midas.germplasm set is_deleted = 'F' where germplasm_id = " + germplasmId;
    conn.executeUpdate(sql);
  }
   public static void updateMidasProgram(PersistentStoreConnection conn, long brProgId) throws
      WrappingException {
    String sql = "update midas.br_prog set midas_program = 'T' where br_prog_id = " + brProgId;
    conn.executeUpdate(sql);
  }

  public static void insertFakeGeneticMaterial(PersistentStoreConnection conn, long geneticMaterialID, String source,
                                               String lineage, long germplasmID, String srcOperation) throws
      WrappingException {
    insertFakeGeneticMaterial(conn, geneticMaterialID, source, lineage, germplasmID, srcOperation, null);
  }

  public static void insertFakeGeneticMaterial(PersistentStoreConnection conn, long geneticMaterialID, String source,
                                               String lineage, long germplasmID, String srcOperation,
                                               String generation) throws WrappingException {
    String lineageClause = "null";
    if (lineage != null) {
      lineageClause = "'" + lineage + "'";
    }
    String srcOperationClause = "null";
    if (srcOperation != null) {
      srcOperationClause = "'" + srcOperation + "'";
    }
    String generationClause = "null";
    if (generation != null) {
      generationClause = "'" + generation + "'";
    }
    String sql =
        "INSERT INTO MIDAS.GENETIC_MATERIAL (GENETIC_MATERIAL_ID, SOURCE_STR, LINEAGE, GERMPLASM_ID, SRC_OPERATION, GENERATION) " +
            "VALUES (" + geneticMaterialID + ", '" + source + "', " + lineageClause + ", " + germplasmID + ", " +
            srcOperationClause + ", " + generationClause + ")";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeMidasProgram(PersistentStoreConnection conn, long programId, String name,
                                            String brProgRefId, long cropId) throws WrappingException {
    insertFakeMidasProgram(conn, programId, name, brProgRefId, cropId, true);
  }

  /**
   * @noinspection MethodWithTooManyParameters
   */
  public static void insertFakeMidasProgram(PersistentStoreConnection conn, long programId, String name,
                                            String brProgRefId, long cropId, boolean active) throws WrappingException {
    String sql = "INSERT INTO MIDAS.BR_PROG (BR_PROG_ID, NAME, BR_PROG_REF_ID, CROP_ID, MIDAS_PROGRAM, REF_ACTIVE) " +
        "VALUES( ?, ?, ?, ?, 'T', ?)";
    PersistentStoreStatement stmt = null;
    try {
      stmt = conn.prepareStatement(sql);
      stmt.setParam(1, programId);
      stmt.setParam(2, name);
      stmt.setParam(3, brProgRefId);
      stmt.setParam(4, cropId);
      stmt.setParam(5, active ? "T" : "F");
      stmt.executeInsert();
    } finally {
      DatabaseResource.close(stmt);
    }
  }

  public static void insertFakeCountry(PersistentStoreConnection conn, long countryID, String name,
                                       String abbreviation) throws WrappingException {
    String sql = "INSERT INTO MIDAS.COUNTRY (COUNTRY_ID, NAME, COUNTRY_ABBR) " + "VALUES (" + countryID + ", '" +
        name + "', '" + abbreviation + "')";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeLocation(PersistentStoreConnection conn, long locationID, String name, long programID,
                                        String locationRef, long countryID, long subCountryID, long subSubCountryID,
                                        boolean isHomeLocation) throws WrappingException {
    String homeLoc = "F";
    if (isHomeLocation) {
      homeLoc = "T";
    }
    String sql =
        "INSERT INTO MIDAS.BR_LOC (BR_LOC_ID, NAME, BR_PROG_ID, BR_LOC_REF_ID, COUNTRY_ID, SUB_COUNTRY_ID, SUB_SUB_COUNTRY_ID, HOME_LOC) " +
            "VALUES (" + locationID + ", '" + name + "', " + programID + ", '" + locationRef + "', " + countryID +
            ", " + subCountryID + ", " + subSubCountryID + ", '" + homeLoc + "')";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeProductName(PersistentStoreConnection conn, long productNameID, long productID,
                                           String name, long brandID, long countryID) throws WrappingException {
    insertFakeProductName(conn, productNameID, productID, name, brandID, countryID, true);
  }

  public static void insertFakeProductName(PersistentStoreConnection conn, long productNameID, long productID,
                                           String name, long brandID, long countryID, boolean active) throws
      WrappingException {
    String sql =
        "INSERT INTO MIDAS.PRODUCT_NAME (PRODUCT_NAME_ID, PRODUCT_ID, NAME, BRAND_ID, COUNTRY_ID, REF_ACTIVE) " +
            "VALUES (" + productNameID + ", " + productID + ", '" + name + "', " + brandID + ", " + countryID +
            ", " + ((active) ? "'T'" : "'F'") + ")";
    insertIntoDB(conn, sql);
  }


  public static void insertFakeBrand(PersistentStoreConnection conn, long brandID, String name,
                                     long companyId) throws WrappingException {
    insertFakeBrand(conn, brandID, name, true, companyId);
  }

  public static void insertFakeBrand(PersistentStoreConnection conn, long brandID, String name,
                                     boolean refActive, long companyId) throws WrappingException {
    String sql = "INSERT INTO MIDAS.BRAND (BRAND_ID, NAME, REF_ACTIVE, COMPANY_ID) " + "VALUES (" + brandID +
        ", '" + name + "', '" + (refActive ? "T" : "F") + "', " + String.valueOf(companyId) + ")";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeCompany(PersistentStoreConnection conn, long companyID, String name) throws
      WrappingException {
    insertFakeCompany(conn, companyID, name, true);
  }

  public static void insertFakeCompany(PersistentStoreConnection conn, long companyID, String name, boolean active) throws
      WrappingException {
    String sql = "INSERT INTO MIDAS.COMPANY (COMPANY_ID, NAME, REF_ACTIVE) " + "VALUES (" + companyID + ", '" +
        name + "', '" + (active ? "T" : "F") + "')";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeProduct(PersistentStoreConnection conn, long productID, long cropID) throws
      WrappingException {
    insertFakeProduct(conn, productID, cropID, true);
  }

  public static void insertFakeProduct(PersistentStoreConnection conn, long productID, long cropID,
                                       boolean refActive) throws WrappingException {
    String sql = "INSERT INTO MIDAS.PRODUCT (PRODUCT_ID, REF_ACTIVE, CROP_ID) " + "VALUES (" + productID + ", " +
        ((refActive) ? "'T'" : "'F'") + ", " + cropID + ")";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeProductGermplasm(PersistentStoreConnection conn, long productGermplasmID,
                                                long productID, long germplasmID) throws WrappingException {
    String sql = "INSERT INTO MIDAS.PRODUCT_GERMPLASM (PRODUCT_GERMPLASM_ID, PRODUCT_ID, GERMPLASM_ID) " +
        "VALUES (" + productGermplasmID + ", " + productID + ", " + germplasmID + ")";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeSubCountry(PersistentStoreConnection conn, long subCountryID, String name,
                                          long countryID) throws WrappingException {
    String sql = "INSERT INTO MIDAS.SUB_COUNTRY (SUB_COUNTRY_ID, NAME, COUNTRY_ID) " + "VALUES (" + subCountryID +
        ", '" + name + "', " + countryID + ")";
    insertIntoDB(conn, sql);
  }

  public static void insertFakeSubSubCountry(PersistentStoreConnection conn, long subSubCountryID, String name,
                                             long subCountryID) throws WrappingException {
    String sql = "INSERT INTO MIDAS.SUB_SUB_COUNTRY (SUB_SUB_COUNTRY_ID, NAME, SUB_COUNTRY_ID) " + "VALUES (" +
        subSubCountryID + ", '" + name + "', " + subCountryID + ")";
    insertIntoDB(conn, sql);
  }




  public static long getMidasCompanyId(PersistentStoreConnection conn, String name, boolean active) {
    if (midasCompanyID == 0) {
      PersistentStoreResultSet resultSet = null;
      try {
        String sql = "select company_id from midas.company where name = '" + name.toUpperCase() + "' and ref_active = '" + (active ? "T" : "F") + "'";
        resultSet = conn.executeQuery(sql);
        PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        midasCompanyID = singleResult.getLong("company_id");
      } catch (EmptyResultSetException e) {
        e.printStackTrace();
      } catch (WrappingException e) {
        e.printStackTrace();
      } finally {
        DatabaseResource.close(resultSet);
      }
    }
    return midasCompanyID;
  }

  public static long getMidasMonsantoBrandID(PersistentStoreConnection conn) {
    if (midasMonsantoBrandID == 0) {
      PersistentStoreResultSet resultSet = null;
      try {
        String sql = "select brand_id from midas.brand where upper(name) = 'MONSANTO' and ref_active = 'T' ";
        resultSet = conn.executeQuery(sql);
        PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        midasMonsantoBrandID = singleResult.getLong("brand_id");
      } catch (EmptyResultSetException e) {
        e.printStackTrace();
      } catch (WrappingException e) {
        e.printStackTrace();
      } finally {
        DatabaseResource.close(resultSet);
      }
    }
    return midasMonsantoBrandID;
  }

  public static long getMidasUSACountryID(PersistentStoreConnection conn) {
    if (midasUSACountryID == 0) {
      PersistentStoreResultSet resultSet = null;
      try {
        String sql = "select country_id from midas.country where upper(name) = 'UNITED STATES OF AMERICA' and ref_active = 'T' ";
        resultSet = conn.executeQuery(sql);
        PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        midasUSACountryID = singleResult.getLong("country_id");
      } catch (EmptyResultSetException e) {
        e.printStackTrace();
      } catch (WrappingException e) {
        e.printStackTrace();
      } finally {
        DatabaseResource.close(resultSet);
      }
    }
    return midasUSACountryID;
  }

  public static void updateRefActiveToFalse(PersistentStoreConnection conn, String table, long pk) throws
      WrappingException {
    String sql = "update midas." + table + " set ref_active = 'F' where " + table + "_id = " + pk;
    conn.executeUpdate(sql);
  }
public static void updateRefActiveToTrue(PersistentStoreConnection conn, String table, long pk) throws
      WrappingException {
    String sql = "update midas." + table + " set ref_active = 'T' where " + table + "_id = " + pk;
    conn.executeUpdate(sql);
  }
  public static void deleteFakeProduct(PersistentStoreConnection conn, long productID) throws WrappingException {
    String sql;
    sql = "DELETE FROM Midas.Product_Germplasm WHERE product_id = " + productID;
    conn.executeDelete(sql);
    sql = "DELETE FROM Midas.Product_Name WHERE product_id = " + productID;
    conn.executeDelete(sql);
    sql = "DELETE FROM Midas.Product WHERE product_id = " + productID;
    conn.executeDelete(sql);
  }
//
  public static void deleteFakeProductName(PersistentStoreConnection conn, long productNameID) throws WrappingException {
    String sql;
    sql = "DELETE FROM Midas.Product_Name WHERE product_name_id = " + productNameID;
    conn.executeDelete(sql);
  }




  public static void deleteFakeLocation(PersistentStoreConnection conn, long locationId) throws WrappingException {
    String sql = "DELETE FROM midas.br_loc WHERE br_loc_id = " + locationId;
    conn.executeDelete(sql);
  }

  public static void deleteFakeCountry(PersistentStoreConnection conn, long countryId) throws WrappingException {
    String sql = "DELETE FROM midas.country WHERE country_id = " + countryId;
    conn.executeDelete(sql);
  }

  public static void deleteFakeSubCountry(PersistentStoreConnection conn, long subCountryId) throws
      WrappingException {
    String sql = "DELETE FROM midas.sub_country WHERE sub_country_id = " + subCountryId;
    conn.executeDelete(sql);
  }

  public static void deleteFakeSubSubCountry(PersistentStoreConnection conn, long subSubCountryId) throws
      WrappingException {
    String sql = "DELETE FROM midas.sub_sub_country WHERE sub_sub_country_id = " + subSubCountryId;
    conn.executeDelete(sql);
  }

  public static void deleteFakeBrProg(PersistentStoreConnection conn, long brProgId) throws WrappingException {
    String sql = "DELETE FROM midas.br_prog WHERE br_prog_id = " + brProgId;
    conn.executeDelete(sql);
  }
  private static String dbbool(boolean boolVal) {
    return Boolean.toString(boolVal).substring(0, 1).toUpperCase();
  }
  public static void insertFakeInventory(PersistentStoreConnection conn, long inventoryId, String brProgRefId,
                                         long geneticMaterialId, boolean checkIndicator, String inventoryTypeName,
                                         boolean isActive, boolean isPreview, boolean toBeDestroyed, String barcode,
                                         char archivedMaterial, long cropId) throws Exception {
    String sql = "INSERT INTO MIDAS.INVENTORY (INVENTORY_ID, BR_PROG_ID, " +
        "GENETIC_MATERIAL_ID, CHECK_INDICATOR, INVENTORY_TYPE_ID, " +
        "IS_ACTIVE, IS_PREVIEW, TO_BE_DESTROYED, FATE_REASON_ID, BARCODE, ARCHIVED_MATERIAL) " +
        "VALUES (" + inventoryId + ", " +
        "(SELECT BR_PROG_ID FROM MIDAS.BR_PROG WHERE BR_PROG_REF_ID =  '" + brProgRefId + "' AND REF_ACTIVE = 'T' AND ROWNUM <= 1) " + ", "
        + geneticMaterialId + ", '" + dbbool(checkIndicator) + "', "
        + "(SELECT INVENTORY_TYPE_ID FROM MIDAS.INVENTORY_TYPE WHERE name =  '" + inventoryTypeName +
        "' AND CROP_ID = " + cropId + " AND REF_ACTIVE = 'T')" + ", '" +
        dbbool(isActive) + "', '" + dbbool(isPreview) + "', '" + dbbool(toBeDestroyed) + "', null " +
        ", '" + barcode + "','" + archivedMaterial + "')";
    insertIntoDB(conn, sql);
  }
  public static int deleteFakeInventoryType(PersistentStoreConnection conn, long inventoryTypeId) throws
      WrappingException {
    final String sql = "DELETE FROM midas.inventory_type WHERE inventory_type_id = ?";
    PersistentStoreStatement statement = null;
    int rowCount = 0;
    try {
      statement = conn.prepareStatement(sql);
      statement.setParam(1, inventoryTypeId);
      rowCount = statement.executeInsert();
    } finally {
      DatabaseResource.close(statement);
    }
    return rowCount;
  }

  public static void insertFakeProgramToRole(PersistentStoreConnection conn, long id, long progId,
                                             long midasRoleId) throws WrappingException {
    String sql = "insert into midas.program_to_role(PROGRAM_TO_ROLE_ID, BR_PROG_ID, MIDAS_ROLE_ID, REF_ACTIVE) " +
        " values (?, ?, ?, ?) ";
    PersistentStoreStatement stmt = null;
    try {
      stmt = conn.prepareStatement(sql);
      stmt.setParam(1, id);
      stmt.setParam(2, progId);
      stmt.setParam(3, midasRoleId);
      stmt.setParam(4, "T");
      stmt.executeInsert();
    } finally {
      DatabaseResource.close(stmt);
    }
  }
  public static long selectBrProgIdByRefId(PersistentStoreConnection conn, String brProgRefId) throws
      WrappingException,
      EmptyResultSetException {
    String sql = "select br_prog_id from midas.br_prog where upper(br_prog_ref_id) = ?";
    PersistentStoreStatement stmt = null;
    PersistentStoreResultSet rs = null;
    PersistentStoreResultSetSingleResult single;
    try {
      stmt = conn.prepareStatement(sql);
      stmt.setParam(1, brProgRefId.toUpperCase());
      rs = stmt.executeQuery();
      single = rs.getSingleResult();
      return single.getLong(1);
    } finally {
      DatabaseResource.close(rs);
      DatabaseResource.close(stmt);
    }
  }
  public static void deleteFakeInventory(PersistentStoreConnection conn, long id) throws WrappingException {
    String sql = "delete from midas.inventory where inventory_id = ?";
    PersistentStoreStatement stmt = null;
    try {
      stmt = conn.prepareStatement(sql);
      stmt.setParam(1, id);
      stmt.executeDelete();
    } finally {
      DatabaseResource.close(stmt);
    }
  }



  public static void insertFakeBrandPrefernece(PersistentStoreConnection conn, long brProgBrandPrefId, long brProgId, long brandId,
                                               long rank) throws WrappingException {
    String sql = "INSERT INTO MIDAS.BR_PROG_BRAND_PREF (BR_PROG_BRAND_PREF_ID, BR_PROG_ID, BRAND_ID,RANK) "
        + "VALUES (" + brProgBrandPrefId + ", " + brProgId + ", " + brandId + "," + rank + ")";
    insertIntoDB(conn, sql);
    }

  public static void deleteFakeBrandPreference(PersistentStoreConnection conn, long brandPrefId) throws
      WrappingException {
    String sql = "DELETE FROM midas.br_prog_brand_pref WHERE BR_PROG_BRAND_PREF_ID = " + brandPrefId;
    conn.executeDelete(sql);
    }

  public static void deleteFakeBrand(PersistentStoreConnection conn, long brandId) throws WrappingException {
    String sql = "DELETE FROM midas.brand WHERE BRAND_ID = " + brandId;
    conn.executeDelete(sql);
    }

  public static void deleteFakeCompany(PersistentStoreConnection conn, long companyId) throws WrappingException {
    String sql = "DELETE FROM midas.company WHERE COMPANY_ID = " + companyId;
    conn.executeDelete(sql);
    }

  public static void deleteFakeProductGermplasm(PersistentStoreConnection conn, long productGermplasmId)
      throws WrappingException {
    String sql = "DELETE FROM midas.product_germplasm WHERE product_germplasm_id = " + productGermplasmId;
    conn.executeDelete(sql);
    }

  public static void insertFakeCompICBMale(PersistentStoreConnection conn,long companyICBMaleId, long geneticMaterialId, long cornCropId,
                                           String refActive) throws WrappingException {
String sql =
        "INSERT INTO MIDAS.COMP_ICB_MALE (COMP_ICB_MALE_ID, GENETIC_MATERIAL_ID, CROP_ID, REF_ACTIVE) " + "VALUES(" +
            companyICBMaleId + ", " + geneticMaterialId + ", " + cornCropId + ", '" + refActive + "' )";
    insertIntoDB(conn, sql);
    }

  public static void deleteFakeCompICBMale(PersistentStoreConnection conn, long companyICBMaleId) throws
      WrappingException {
    String sql = "DELETE FROM midas.comp_icb_male WHERE comp_icb_male_id = " + companyICBMaleId;
    conn.executeDelete(sql);
    }
  public static long getMidasCornCropID(PersistentStoreConnection conn) {
        return getMidasCropID(conn, "Corn");
  }

  public static long getMidasCropID(PersistentStoreConnection conn, String cropName) {
    if (midasCornCropID == 0) {
    PersistentStoreResultSet resultSet = null;
    try {
        String sql = "select crop_id from midas.crop where lower(name) = '" + cropName.toLowerCase() + "'";
      resultSet = conn.executeQuery(sql);
      PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        midasCornCropID = singleResult.getLong("crop_id");
      } catch (EmptyResultSetException e) {
        e.printStackTrace();
      } catch (WrappingException e) {
        e.printStackTrace();
    } finally {
      DatabaseResource.close(resultSet);
    }
  }
    return midasCornCropID;
    }
  public static String getActiveCornBrProgRefID(PersistentStoreConnection conn) {
    if (activeCornBrProgRefID == "") {
    PersistentStoreResultSet resultSet = null;
    try {
        String sql = "select br.br_prog_ref_id br_prog_ref_id from midas.br_prog br, midas.crop cr where br.crop_id = cr.crop_id and " +
            " br.ref_active = 'T' and cr.ref_active = 'T' and cr.name = 'Corn' and length(br.br_prog_ref_id) = 2 " +
            " order by br_prog_id desc";

      resultSet = conn.executeQuery(sql);
      PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        activeCornBrProgRefID = singleResult.getString("br_prog_ref_id");
      } catch (EmptyResultSetException e) {
      e.printStackTrace();
      } catch (WrappingException e) {
        e.printStackTrace();
    } finally {
      DatabaseResource.close(resultSet);
    }
  }
    return activeCornBrProgRefID;
      }
  public static String selectBrProgRefIdOfACornGermplasmManager(PersistentStoreConnection conn) throws WrappingException,
      EmptyResultSetException {
    if (null == brProgRefIdForGermplasmManager || 0 == brProgRefIdForGermplasmManager.trim().length()) {
      String sql = "select bp.br_prog_ref_id br_prog_ref_id " +
          "from midas.program_to_role ptr, midas.midas_role mr, midas.br_prog bp, midas.crop c " +
          "where  ptr.br_prog_id = bp.br_prog_id and ptr.midas_role_id = mr.midas_role_id and bp.crop_id = c.crop_id " +
          "and ptr.ref_active = 'T' and bp.ref_active = 'T' and c.ref_active = 'T' " +
          "and mr.midas_role_ref_id = 'GM' and mr.midas_role_type_id = 'PR' " +
          "and    mr.ref_active = 'T' and mr.name = 'Germplasm Manager' and c.name = 'Corn'";
      PersistentStoreResultSet resultSet = null;
      try {
        resultSet = conn.executeQuery(sql);
        PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        brProgRefIdForGermplasmManager = singleResult.getString("br_prog_ref_id");
      } catch (EmptyResultSetException e) {
        e.printStackTrace();
      } catch (WrappingException e) {
        e.printStackTrace();
      } finally {
        DatabaseResource.close(resultSet);
      }
    }
    return brProgRefIdForGermplasmManager;
  }

  public static long selectMidasRole(PersistentStoreConnection conn, String name) throws WrappingException,
      EmptyResultSetException {
    String sql = "select midas_role_id from midas.midas_role where name = ?";
    PersistentStoreStatement stmt = null;
    PersistentStoreResultSet set = null;
    try {
      stmt = conn.prepareStatement(sql);
      stmt.setParam(1, name);
      set = stmt.executeQuery();
      return set.getSingleResult().getLong("midas_role_id");
    } finally {
      DatabaseResource.close(set);
      DatabaseResource.close(stmt);
    }
  }
  public static void deleteFakeParentage(PersistentStoreConnection conn, long id) throws WrappingException {
    String sql = "delete from midas.parentage where parentage_id = ?";
    PersistentStoreStatement stmt = null;
    try {
      stmt = conn.prepareStatement(sql);
      stmt.setParam(1, id);
      stmt.executeDelete();
    } finally {
      DatabaseResource.close(stmt);
    }
  }
  public static void deleteFakeGeneticMaterial(PersistentStoreConnection conn, long valid_genetic_mat_id) throws
      WrappingException {
    String sql = "delete from midas.GENETIC_MATERIAL where GENETIC_MATERIAL_ID = ?";
    PersistentStoreStatement stmt = conn.prepareStatement(sql);
    try {
      stmt.setParam(1, valid_genetic_mat_id);
      stmt.executeDelete();
    } finally {
      DatabaseResource.close(stmt);
    }
  }
  public static void deleteFakeGermplasm(PersistentStoreConnection conn, long germplasmID) throws WrappingException {
    String sql;
    sql = "DELETE FROM Midas.Genetic_Material WHERE germplasm_id = " + germplasmID;
    conn.executeDelete(sql);
    sql = "DELETE FROM Midas.Germplasm WHERE germplasm_id = " + germplasmID;
    conn.executeDelete(sql);
  }

  public static void deleteFakeProgramToRole(PersistentStoreConnection conn, long id) throws WrappingException {
    String sql = "delete from midas.program_to_role where program_to_role_id = ?";
    PersistentStoreStatement stmt = conn.prepareStatement(sql);
    try {
      stmt.setParam(1, id);
      stmt.executeDelete();
    } finally {
      DatabaseResource.close(stmt);
    }
  }

  public static void deleteFakeProgram(PersistentStoreConnection conn, long valid_prog_id) throws WrappingException {
    String sql = "delete from MIDAS.BR_PROG where BR_PROG_ID = ?";
    PersistentStoreStatement stmt = conn.prepareStatement(sql);
    try {
      stmt.setParam(1, valid_prog_id);
      stmt.executeDelete();
    } finally {
      DatabaseResource.close(stmt);
    }
  }

  public static void insertFakeGermplasm(PersistentStoreConnection conn, long germplasmID, String pedigree,
                                         String origin, String lineCode, String lineTypeRefID,
                                         String lineFunctionRefID, String ownerProgramRefID, long cropID,
                                         boolean isFinishedOrFinishedChild) throws WrappingException {
    insertFakeGermplasm(conn, germplasmID, pedigree, origin, lineCode, lineTypeRefID, lineFunctionRefID,
        ownerProgramRefID, cropID, isFinishedOrFinishedChild, null);
    }

  public static void insertFakeGermplasm(PersistentStoreConnection conn, long germplasmID, String pedigree,
                                         String origin, String lineCode, String lineTypeRefID,
                                         String lineFunctionRefID, String ownerProgramRefID, long cropID,
                                         String eventDisplay, boolean isFinished, boolean isTransgenic) throws
      WrappingException {
    insertFakeGermplasm(conn, germplasmID, pedigree, origin, lineCode, lineTypeRefID, lineFunctionRefID,
        ownerProgramRefID, cropID, eventDisplay, isFinished, isTransgenic, null);
    }

  public static void insertFakeGermplasm(PersistentStoreConnection conn, long germplasmID, String pedigree,
                                         String origin, String lineCode, String lineTypeRefID,
                                         String lineFunctionRefID, String ownerProgramRefID, long cropID,
                                         boolean isFinishedOrFinishedChild, java.util.Date codeYear) throws
      WrappingException {
    insertFakeGermplasm(conn, germplasmID, pedigree, origin, lineCode, lineTypeRefID, lineFunctionRefID,
        ownerProgramRefID, cropID, null, isFinishedOrFinishedChild, false, codeYear);
    }

  public static void insertFakeGermplasm(PersistentStoreConnection conn, long germplasmID, String pedigree,
                                         String origin, String lineCode, String lineTypeRefID,
                                         String lineFunctionRefID, String ownerProgramRefID, long cropID,
                                         String eventDisplay, boolean isFinished, boolean isTransgenic,
                                         java.util.Date codeYear) throws WrappingException {
    String lineCodeClause = "null";
    if (lineCode != null) {
      lineCodeClause = "'" + lineCode + "'";
    }
    String ownerProgramClause = "null";
    if (ownerProgramRefID != null) {
      ownerProgramClause = "(select br_prog_id from midas.br_prog where rownum = 1 and upper(br_prog_ref_id) = '" +
          ownerProgramRefID.toUpperCase() + "')";
  }
    String lineFunctionClause = "null";
    if (lineFunctionRefID != null) {
      lineFunctionClause = "(select line_function_id from midas.line_function where upper(line_function_ref_id) = '" +
          lineFunctionRefID.toUpperCase() + "')";
    }
    String eventDisplayClause = "null";
    if (eventDisplay != null) {
      eventDisplayClause = "'" + eventDisplay + "'";
  }
    String sql = "INSERT INTO MIDAS.GERMPLASM (GERMPLASM_ID, PEDIGREE_NAME, ORIGIN, LINE_CODE, LINE_TYPE_ID, " +
        "LINE_FUNCTION_ID, CROP_ID, OWNER_BR_PROG_ID, EVENT_DISPLAY, IS_FINISHED_OR_FINISHED_CHILD, IS_TRANSGENIC, CODE_YEAR) " +
        "VALUES (" + germplasmID + ", '" + pedigree + "', '" + origin + "', " + lineCodeClause + ", " +
        "(select line_type_id from midas.line_type where upper(line_type_ref_id) = '" + lineTypeRefID.toUpperCase() +
        "' and ref_active='T'), " + lineFunctionClause + ", " + cropID + ", " + ownerProgramClause + ", " +
        eventDisplayClause + ", " + ((isFinished) ? "'T'" : "'F'") + "," + ((isTransgenic) ? "'T'" : "'F'") + "," +
        ((codeYear != null) ? SQLUtil.buildToDateSQL(codeYear) : "NULL") + ")";
    insertIntoDB(conn, sql);
  }
  private static void insertIntoDB(PersistentStoreConnection conn, String sql) throws WrappingException {
    conn.executeInsert(sql);
  }

}

// End of class TestTools