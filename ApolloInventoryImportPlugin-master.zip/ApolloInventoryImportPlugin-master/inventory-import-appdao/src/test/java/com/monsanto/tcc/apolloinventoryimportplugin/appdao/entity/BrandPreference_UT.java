package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 12:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class BrandPreference_UT {
    BrandPreference testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new BrandPreference();
    }

    @Test
    public void testSetBrandPreferenceId() throws Exception {
        Brand brand = new Brand();
        brand.setBrandId(-6L);
        Long brandPrefId = -1L;
        BrProg brProg = new BrProg();
        brProg.setBrProgId(-2L);
        Long rank = -3L;

        testObject.setBrand(brand);
        testObject.setBrandPreferenceId(brandPrefId);
        testObject.setBrProg(brProg);
        testObject.setRank(rank);

        assertEquals(brand, testObject.getBrand());
        assertEquals(brandPrefId, testObject.getBrandPreferenceId());
        assertEquals(brProg, testObject.getBrProg());
        assertEquals(rank, testObject.getRank());
    }
}
