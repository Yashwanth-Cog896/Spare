/*
 UnfinishedHybridGermplasmDAO_UT was created on May 8, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.BrProg;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.MidasRole;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.UnfinishedHybridGermplasmDTOList;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: UnfinishedHybridGermplasmDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $      On:  $Date: 2008-09-19 19:51:12 $
 *
 * @author SRKARNA
 * @version $Revision: 1.4 $
 */
public class UnfinishedHybridGermplasmDAO_UT extends TestIIContextConfigurer {
    private static final String MATCHING_ORIGIN = "DAT+UTL++1+1";
    private static final String NO_MATCHING_ORIGIN = "SHOULD+NEVER++OCCUR";
    private static final String LINE_FUNCTION_REF_ID = "S";
    private static final String IS_DELETED_TRUE = "T";
    private static final String IS_DELETED_FALSE = "F";
    private static final String CROP_NAME = "Corn";
    private Session session;
    private String brProgRefIdWithGPManagerRole;

    protected void setUp() throws Exception {
        final String PEDIGREE = "DAT";
        final String LINE_CODE = "UTL";
        final String GERMPLASM_MANAGER_ROLE = "Germplasm Manager";
        final String LINE_TYPE = MaterialTypeConstants.HYBRID_LINES;
        final String FINISHED_OR_FIN_CHILD_FALSE = "F";
        final String REF_ACTIVE_TRUE = "T";

        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        TestHelper appdaoTestHelper = new TestHelper(session);

        MidasRole germplasmManagerRole = appdaoTestHelper.getMidasRole(GERMPLASM_MANAGER_ROLE);
        BrProg programWithGPManagerRole = appdaoTestHelper
                .selectBrProgRefIdOfACornGermplasmManager(REF_ACTIVE_TRUE, germplasmManagerRole,
                        CROP_NAME);
        brProgRefIdWithGPManagerRole = programWithGPManagerRole.getBrProgRefId();
        appdaoTestHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefIdWithGPManagerRole,
                CROP_NAME, IS_DELETED_TRUE, FINISHED_OR_FIN_CHILD_FALSE);
        appdaoTestHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefIdWithGPManagerRole,
                CROP_NAME, IS_DELETED_TRUE, FINISHED_OR_FIN_CHILD_FALSE);
        appdaoTestHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefIdWithGPManagerRole,
                CROP_NAME, IS_DELETED_FALSE, FINISHED_OR_FIN_CHILD_FALSE);
        appdaoTestHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefIdWithGPManagerRole,
                CROP_NAME, IS_DELETED_FALSE, FINISHED_OR_FIN_CHILD_FALSE);
        appdaoTestHelper.createGermplasm(LINE_TYPE, LINE_CODE, MATCHING_ORIGIN, PEDIGREE, brProgRefIdWithGPManagerRole,
                CROP_NAME, IS_DELETED_FALSE, FINISHED_OR_FIN_CHILD_FALSE, LINE_FUNCTION_REF_ID, null);
    }

    protected void tearDown() throws Exception {
        if (session != null && session.isOpen()) {
            session.getTransaction().rollback();
        }
        super.tearDown();
    }

    public void testCreateUnfinishedHybridGermplasmDAOPreconditionsWhenCropNameIsNull() throws Exception {
        try {
            new UnfinishedHybridGermplasmDAO(null, getLineFunctionCriteria(LINE_FUNCTION_REF_ID));
            fail("expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(UnfinishedHybridGermplasmDAO.CROP_LINEFUNCTION_REQ_MSG) >= 0);
        }
    }

    public void testCreateUnfinishedHybridGermplasmDAOPreconditionsWhenLineFunctionCriteriaIsNull() throws Exception {
        try {
            new UnfinishedHybridGermplasmDAO(CROP_NAME, null);
            fail("expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(UnfinishedHybridGermplasmDAO.CROP_LINEFUNCTION_REQ_MSG) >= 0);
        }
    }

//    public void testGetGermplasmsCountMatchingOriginGroupByOwnerAndIsDeleted() throws Exception {
//        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO;
//
//        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(null));
//        UnfinishedHybridGermplasmDTOList dtoList = dao
//                .getGermplasmsCountMatchingOriginGroupByOwnerAndIsDeleted(MATCHING_ORIGIN);
//
//        assertNotNull(dtoList);
//        assertEquals(2, dtoList.size());
//
//        unfinishedHybridGermplasmDTO = dtoList.get(MATCHING_ORIGIN, brProgRefIdWithGPManagerRole, IS_DELETED_FALSE);
//        assertNotNull(unfinishedHybridGermplasmDTO);
//        assertEquals(2, unfinishedHybridGermplasmDTO.getCount());
//
//        unfinishedHybridGermplasmDTO = dtoList.get(MATCHING_ORIGIN, brProgRefIdWithGPManagerRole, IS_DELETED_TRUE);
//        assertNotNull(unfinishedHybridGermplasmDTO);
//        assertEquals(2, unfinishedHybridGermplasmDTO.getCount());
//    }

    public void testGetGermplasmsCountNoMatchingOrigin() throws Exception {
        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(null));
        UnfinishedHybridGermplasmDTOList dtoList = dao
                .getGermplasmsCountMatchingOriginGroupByOwnerAndIsDeleted(NO_MATCHING_ORIGIN);

        assertEquals(0, dtoList.size());
    }

    public void testGetGermplasmsCountOriginRequired() throws Exception {
        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(null));

        try {
            dao.getGermplasmsCountMatchingOriginGroupByOwnerAndIsDeleted(null);
            fail("expecting IllegalArgumentException");
        } catch (Exception e) {
            assertTrue(e.getMessage().indexOf(UnfinishedHybridGermplasmDAO.ORIGIN_REQ_MSG) >= 0);
        }
    }

    public void testGetGermplasmsMatchingOrigin_OriginRequired() throws Exception {
        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(null));

        try {
            dao.getGermplasmsMatchingOrigin(null);
            fail("expecting IllegalArgumentException");
        } catch (Exception e) {
            assertTrue(e.getMessage().indexOf(UnfinishedHybridGermplasmDAO.ORIGIN_REQ_MSG) >= 0);
        }
    }

    public void testGetGermplasmsMatchingOriginWithNoLineFunction() throws Exception {
        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(null));

        List list = dao.getGermplasmsMatchingOrigin(MATCHING_ORIGIN);

        assertNotNull(list);
        assertEquals(4, list.size());
    }

    public void testGetGermplasmsMatchingOriginWithBlankLineFunction() throws Exception {
        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(""));

        List list = dao.getGermplasmsMatchingOrigin(MATCHING_ORIGIN);

        assertNotNull(list);
        assertEquals(4, list.size());
    }

    public void testGetGermplasmsMatchingOriginWithLineFunction() throws Exception {
        UnfinishedHybridGermplasmDAO dao = new UnfinishedHybridGermplasmDAO(CROP_NAME,
                getLineFunctionCriteria(LINE_FUNCTION_REF_ID));

        List list = dao.getGermplasmsMatchingOrigin(MATCHING_ORIGIN);

        assertNotNull(list);
        assertEquals(1, list.size());
    }

    private LineFunctionCriteria getLineFunctionCriteria(String lineFunctionRefId) {
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setLineFunction(lineFunctionRefId);
        return new LineFunctionCriteriaFactory(stagingInventory).getLineFunctionCriteria();
    }
}