package com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty.select;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 22, 2010
 * Time: 8:31:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class ActiveGermplasmRoyaltyCriteria_UT {
    @Mock
    private Criteria mockCriteria;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testActiveGermplasmRoyaltyCriteria() {
        when(mockCriteria.add(isA(Criterion.class))).thenReturn(mockCriteria);
        ActiveGermplasmRoyaltyCriteria criteria = new ActiveGermplasmRoyaltyCriteria();
        criteria.add("gp", mockCriteria);
        assertNotNull(criteria);
    }
}
