package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.FinishedGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 7:57:30 AM To change this template use File |
 * Settings | File Templates.
 */
public class FinishedParentMatchingLineCodeCheckingStrategy_UT extends TestIIContextConfigurer {

    private List germplasmList;

    public void testFetchExistingParentGermplasms_ZeroMatchingGermplasms() throws Exception {
        FinishedParentMatchingLineCodeCheckingStrategy strategy = new MockFinishedParentMatchingLineCodeCheckingStrategy(
                "XYZ");
        this.germplasmList = new ArrayList();
        List productGermplasms = strategy.fetchExistingParentGermplasms("XYZ");
        assertEquals(0, productGermplasms.size());
    }

    public void testFetchExistingParentGermplasms_TwoMatchingGermplasms() throws Exception {
        FinishedParentMatchingLineCodeCheckingStrategy strategy = new MockFinishedParentMatchingLineCodeCheckingStrategy(
                "XYZ");
        this.germplasmList = Collections.nCopies(2, 5);
        List productGermplasms = strategy.fetchExistingParentGermplasms("XYZ");
        assertEquals(2, productGermplasms.size());
    }

    public void testCheckIfParentsExists_Success() throws Exception {
        FinishedParentMatchingLineCodeCheckingStrategy strategy = new FinishedParentMatchingLineCodeCheckingStrategy(
                "XYZ") {
            public List fetchExistingParentGermplasms(String originComponent) {
                return Collections.nCopies(2, 5);
            }
        };
        assertTrue(strategy.checkIfParentsExists("XYZ"));
    }

    public void testCheckIfParentsExists_Fail() throws Exception {
        FinishedParentMatchingLineCodeCheckingStrategy strategy = new FinishedParentMatchingLineCodeCheckingStrategy(
                "XYZ") {
            public List fetchExistingParentGermplasms(String originComponent) {
                return new ArrayList();
            }
        };
        assertFalse(strategy.checkIfParentsExists("XYZ"));
    }

    private class MockFinishedParentMatchingLineCodeCheckingStrategy extends
            FinishedParentMatchingLineCodeCheckingStrategy {
        protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName) {
            return new MockFinishedGermplasmDAO("XYZ", new NullLineFunctionCriteria());
        }

        private MockFinishedParentMatchingLineCodeCheckingStrategy(String cropName) {
            super(cropName);

        }
    }

    private class MockFinishedGermplasmDAO extends FinishedGermplasmDAO {
        private MockFinishedGermplasmDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
            super(cropName, lineFunctionCriteria);
        }

        public List getAllGermplasmsExcludingLineFunction(String linecode) {
            return FinishedParentMatchingLineCodeCheckingStrategy_UT.this.germplasmList;
        }
    }
}
