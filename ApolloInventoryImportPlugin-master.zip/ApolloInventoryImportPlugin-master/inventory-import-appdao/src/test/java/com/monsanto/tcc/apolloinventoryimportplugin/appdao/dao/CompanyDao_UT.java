package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 20, 2010
 * Time: 5:05:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyDao_UT extends TestIIContextConfigurer {

    private Session session;

    @Override
    protected void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
    }

    @Override
    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
    }


    public void testWithValidCropName() {
        CompanyDao companyDao = new CompanyDao();
        assertTrue(companyDao.isValidCompany("MONSANTO"));
    }

    public void testWithCropNameAsNull() {
        CompanyDao companyDao = new CompanyDao();
        assertFalse(companyDao.isValidCompany(null));
    }


    public void testWithCropNameAsEmptyString() {
        CompanyDao companyDao = new CompanyDao();
        assertFalse(companyDao.isValidCompany(""));
    }


    public void testWithInvalidCropName() {
        CompanyDao companyDao = new CompanyDao();
        assertFalse(companyDao.isValidCompany("ZX!@@"));
    }
}

