package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;


import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 6:39:32 AM To change this template use File |
 * Settings | File Templates.
 */
public class ParentageFetchStrategyAssembler_UT extends TestIIContextConfigurer {

    public void testGetStrategiesForCheckingExistingParents_Success() throws Exception {
        ParentageFetchStrategyAssembler assembler = new ParentageFetchStrategyAssembler("Corn");
        ParentageFetchStrategy[] strategies = assembler.getStrategiesForCheckingExistingParents();
        assertNotNull(strategies);
        assertEquals(3, strategies.length);
    }
}
