/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

/**
 * Filename:    $RCSfile: DatabaseResource.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-17 21:54:26 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.1 $
 */
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreStatement;


public class DatabaseResource
{
    public static void close(PersistentStoreConnection connection)
    {
        if (connection != null)
        {
            forceClosed(connection);
        }
    }

    public static void close(PersistentStoreResultSet resultSet)
    {
        if (resultSet != null)
        {
            resultSet.close();
        }
    }

    public static void close(PersistentStoreStatement statement)
    {
        if (statement != null)
        {
            try
            {
                statement.close();
            }
            catch (WrappingException e)
            {
                Logger.log(new LoggableError(e));
            }
        }
    }

    private static void forceClosed(PersistentStoreConnection connection)
    {
        try
        {
            connection.close();
        }
        catch (WrappingException e)
        {
            Logger.log(new LoggableError(e));
        }
    }

} // End of class DatabaseResource