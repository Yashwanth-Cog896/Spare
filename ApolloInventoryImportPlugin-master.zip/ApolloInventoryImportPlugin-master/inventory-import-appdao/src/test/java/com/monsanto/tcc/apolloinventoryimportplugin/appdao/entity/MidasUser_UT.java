package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 12:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasUser_UT {
    MidasUser testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new MidasUser();
    }

    @Test
    public void testSetLoginId() throws Exception {
        String firstName = "first";
        String lastName = "last";
        String loginId = "login";
        Long midasUserId = -3L;
        String middleName = "middle";
        String refActive = "t";

        testObject.setFirstName(firstName);
        testObject.setLastName(lastName);
        testObject.setLoginId(loginId);
        testObject.setMidasUserId(midasUserId);
        testObject.setMiddleName(middleName);
        testObject.setRefActive(refActive);
    }
}
