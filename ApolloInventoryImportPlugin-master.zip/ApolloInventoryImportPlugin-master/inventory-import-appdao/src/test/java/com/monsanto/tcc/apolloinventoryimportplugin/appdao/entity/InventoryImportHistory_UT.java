package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: 5/25/11
 * Time: 12:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryImportHistory_UT {
    InventoryImportHistory testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new InventoryImportHistory();
    }

    @Test
    public void testSetterAndGetter() throws Exception {
        Date approvalDate = new Date(98324456l);
        Long userId = -4L;
        Long authorityUserId = -4L;
        Long inventoryImportHistoryId = -7l;
        Inventory inventory = new Inventory();
        inventory.setInventoryId(-5L);
        Long requestorUserId = -8l;
        Date requestDate = new Date(82473236l);
        Date unarchiveDate = new Date(4239854308l);
        Date validationDate = new Date(324023045905l);
        String transgenic = "F";
        String exposure = "F";
        String allergens = "F";
        String toxins = "F";
        String animal = "F";
        String mini = "F";
        String mfg = "F";
        String batch = "ASDF";
        String acronym = "JKL;";
        String materialNumber = "reh";

        testObject.setApprovalDate(approvalDate);
        testObject.setApproverUserId(userId);
        testObject.setAuthorityUserId(authorityUserId);
        testObject.setInventory(inventory);
        testObject.setInventoryImportHistoryId(inventoryImportHistoryId);
        testObject.setRequestDate(requestDate);
        testObject.setRequestorUserId(requestorUserId);
        testObject.setUnarchiveDate(unarchiveDate);
        testObject.setValidationDate(validationDate);
        testObject.setTransgenic(transgenic);
        testObject.setExposureHistoryKnown(exposure);
        testObject.setAllergensPresent(allergens);
        testObject.setToxinsPresent(toxins);
        testObject.setAnimalGenePresent(animal);
        testObject.setMiniChromosome(mini);
        testObject.setFromMfg(mfg);
        testObject.setMfgBatchNumber(batch);
        testObject.setMfgAcronymNumber(acronym);
        testObject.setMfgMaterialNumber(materialNumber);

        assertEquals(approvalDate, testObject.getApprovalDate());
        assertEquals(userId, testObject.getApproverUserId());
        assertEquals(authorityUserId, testObject.getAuthorityUserId());
        assertEquals(inventory, testObject.getInventory());
        assertEquals(inventoryImportHistoryId, testObject.getInventoryImportHistoryId());
        assertEquals(requestDate, testObject.getRequestDate());
        assertEquals(requestorUserId, testObject.getRequestorUserId());
        assertEquals(unarchiveDate, testObject.getUnarchiveDate());
        assertEquals(validationDate, testObject.getValidationDate());
        assertEquals(transgenic, testObject.getTransgenic());
        assertEquals(exposure, testObject.getExposureHistoryKnown());
        assertEquals(allergens, testObject.getAllergensPresent());
        assertEquals(toxins, testObject.getToxinsPresent());
        assertEquals(animal, testObject.getAnimalGenePresent());
        assertEquals(mini, testObject.getMiniChromosome());
        assertEquals(mfg, testObject.getFromMfg());
        assertEquals(batch, testObject.getMfgBatchNumber());
        assertEquals(acronym, testObject.getMfgAcronymNumber());
        assertEquals(materialNumber, testObject.getMfgMaterialNumber());
    }
}
