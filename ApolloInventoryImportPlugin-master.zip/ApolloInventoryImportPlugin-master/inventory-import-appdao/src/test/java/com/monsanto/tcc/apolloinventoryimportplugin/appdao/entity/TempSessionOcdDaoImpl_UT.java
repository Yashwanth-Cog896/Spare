package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.TempSessionOcdDaoImpl;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import org.hibernate.Session;

import java.util.HashSet;
import java.util.Set;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Created by IntelliJ IDEA.
 * User: rehigg
 * Date: Jan 27, 2011
 * Time: 11:09:40 AM
 */
public class TempSessionOcdDaoImpl_UT extends TestIIContextConfigurer {

    private Session session;

    public void testInsertNumberValues() throws Exception {
        session = mock(Session.class);
        int idCount = 10;
        Set<Long> ids = createIdSet(idCount);
        FacadeTempSessionOcdDaoImpl tempSessionOcdDao = new FacadeTempSessionOcdDaoImpl();

        tempSessionOcdDao.insertNumberValues(1L, ids);

        verify(session, times(1)).flush();
    }

    public void testInsertLargeNumberOfValues() {
        session = mock(Session.class);
        Set<Long> ids = createIdSet(1200);
        FacadeTempSessionOcdDaoImpl tempSessionOcdDao = new FacadeTempSessionOcdDaoImpl();

        tempSessionOcdDao.insertNumberValues(1L, ids);

        verify(session, times(2)).flush();
    }

    private Set<Long> createIdSet(int idCount) {
        Set<Long> ids = new HashSet<Long>();
        for (int i = 1; i <= idCount; i++) {
            ids.add((long) i);
        }
        return ids;
    }

    private class FacadeTempSessionOcdDaoImpl extends TempSessionOcdDaoImpl {
        @Override
        protected Session getSession() {
            return session;
        }
    }
}
