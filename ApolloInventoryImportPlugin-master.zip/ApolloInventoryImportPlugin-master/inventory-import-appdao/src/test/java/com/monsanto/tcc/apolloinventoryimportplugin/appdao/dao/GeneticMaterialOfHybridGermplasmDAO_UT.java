/*
 GeneticMaterialOfHybridGermplasmDAO_UT was created on Feb 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.ParentalRoleConstants;
import org.hibernate.Session;

import java.util.Arrays;

/**
 * Filename:    $RCSfile: GeneticMaterialOfHybridGermplasmDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-17 21:55:23 $
 *
 * @author SRKARNA
 * @version $Revision: 1.5 $
 */
public class GeneticMaterialOfHybridGermplasmDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;
    private Germplasm germplasmWithPrimaryGm;
    private Germplasm germplasmWithNoPrimaryGm;
    private GeneticMaterial[] gms = null;
    private Parentage[] parentage = null;

    public GeneticMaterialOfHybridGermplasmDAO_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);

        Germplasm parentFGermplasm = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GM-PICK1",
                "X1", "GM-PICK1", "17", "Corn");
        GeneticMaterial femaleParentGM = testHelper.createGeneticMaterial(parentFGermplasm, "female-parent", "|", "INBRED");

        Germplasm parentMGermplasm = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GM-PICK2",
                "X2", "GM-PICK2", "17", "Corn");
        GeneticMaterial maleParentGM = testHelper.createGeneticMaterial(parentMGermplasm, "male-parent", "|", "INBRED");

        germplasmWithPrimaryGm = testHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null,
                "GM-PICK1+GM-PICK2", "GM-PICK1+GM-PICK2", "17", "Corn");

        gms = new GeneticMaterial[5];
        parentage = new Parentage[4];

        gms[4] = testHelper.createGeneticMaterial(germplasmWithPrimaryGm, "GM-PICK-SOURCE15", "|", "INBRED");
        parentage[0] = testHelper.createParentage(gms[4], femaleParentGM, ParentalRoleConstants.FEMALE_PARENTAL_ROLE);
        parentage[1] = testHelper.createParentage(gms[4], maleParentGM, ParentalRoleConstants.MALE_PARENTAL_ROLE);
        gms[0] = testHelper.createGeneticMaterial(germplasmWithPrimaryGm, "GM-PICK-SOURCE11", "|", "INBRED");
        gms[3] = testHelper.createGeneticMaterial(germplasmWithPrimaryGm, "GM-PICK-SOURCE14", "|", "INBRED");
        testHelper.createParentage(gms[3], femaleParentGM, ParentalRoleConstants.FEMALE_PARENTAL_ROLE);
        gms[2] = testHelper.createGeneticMaterial(germplasmWithPrimaryGm, "GM-PICK-SOURCE13", "|", "INBRED");
        parentage[2] = testHelper.createParentage(gms[2], femaleParentGM, ParentalRoleConstants.FEMALE_PARENTAL_ROLE);
        parentage[3] = testHelper.createParentage(gms[2], maleParentGM, ParentalRoleConstants.MALE_PARENTAL_ROLE);
        gms[1] = testHelper.createGeneticMaterial(germplasmWithPrimaryGm, "GM-PICK-SOURCE12", "|", "INBRED");
        testHelper.createParentage(gms[1], maleParentGM, ParentalRoleConstants.MALE_PARENTAL_ROLE);

        germplasmWithNoPrimaryGm = testHelper.createGermplasm(MaterialTypeConstants.HYBRID_LINES, null,
                "GM-PICK11+GM-PICK12", "GM-PICK11+GM-PICK12", "17", "Corn");
        testHelper.createGeneticMaterial(germplasmWithNoPrimaryGm, "NO-PRIMARY-GM-11", "|", "INBRED");
        GeneticMaterial gm1 = testHelper.createGeneticMaterial(germplasmWithNoPrimaryGm, "NO-PRIMARY-GM-12", "|", "INBRED");
        testHelper.createParentage(gm1, femaleParentGM, ParentalRoleConstants.FEMALE_PARENTAL_ROLE);
        GeneticMaterial gm2 = testHelper.createGeneticMaterial(germplasmWithNoPrimaryGm, "NO-PRIMARY-GM-13", "|", "INBRED");
        testHelper.createParentage(gm2, maleParentGM, ParentalRoleConstants.MALE_PARENTAL_ROLE);
    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGeneticMaterialOfHybridGermplasmDAO_germplasm_required() throws Exception {
        try {
            new GeneticMaterialOfHybridGermplasmDAO(null);
            fail("expecting illegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.toString().indexOf(GeneticMaterialOfHybridGermplasmDAO.GERMPLASM_IS_REQUIRED) >= 0);
        }
    }

    public void testGeneticMaterialOfHybridGermplasmDAO_germplasm_must_be_hybrid() throws Exception {
        try {
            new GeneticMaterialOfHybridGermplasmDAO(new Germplasm());
            fail("expecting illegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.toString().indexOf(GeneticMaterialOfHybridGermplasmDAO.GERMPLAM_IS_NOT_HYBRID) >= 0);
        }
    }

    public void testGetPrimaryGeneticMaterial() throws Exception {
        GeneticMaterialOfHybridGermplasmDAO dao = new GeneticMaterialOfHybridGermplasmDAO(germplasmWithPrimaryGm);
        GeneticMaterial geneticMaterial = dao.getPrimaryGeneticMaterial();

        assertNotNull(geneticMaterial);
        Long[] gmIds = new Long[]{gms[2].getGeneticMaterialId(), gms[4].getGeneticMaterialId()};
        Arrays.sort(gmIds);
        assertEquals(geneticMaterial.getGeneticMaterialId(), gmIds[0]);
        assertTrue(geneticMaterial.getGeneticMaterialId().compareTo(gmIds[1]) < 0);
    }

    public void testGetPrimaryGeneticMaterial_None_Qualiied_Returns_Null() throws Exception {
        GeneticMaterialOfHybridGermplasmDAO dao = new GeneticMaterialOfHybridGermplasmDAO(germplasmWithNoPrimaryGm);
        GeneticMaterial geneticMaterial = dao.getPrimaryGeneticMaterial();

        assertNull(geneticMaterial);
    }

    public void testGetParentOfPrimaryGeneticMaterial_For_Female_Parent() throws Exception {
        String role = ParentalRoleConstants.FEMALE_PARENTAL_ROLE;
        GeneticMaterialOfHybridGermplasmDAO dao = new GeneticMaterialOfHybridGermplasmDAO(germplasmWithPrimaryGm);
        GeneticMaterial geneticMaterial = dao.getParentOfPrimaryGeneticMaterial(role);

        assertNotNull(geneticMaterial);
        assertTrue(contains(geneticMaterial, role, parentage));
    }

    public void testGetParentOfPrimaryGeneticMaterial_For_Male_Parent() throws Exception {
        String role = ParentalRoleConstants.MALE_PARENTAL_ROLE;
        GeneticMaterialOfHybridGermplasmDAO dao = new GeneticMaterialOfHybridGermplasmDAO(germplasmWithPrimaryGm);
        GeneticMaterial geneticMaterial = dao.getParentOfPrimaryGeneticMaterial(role);

        assertNotNull(geneticMaterial);
        assertTrue(contains(geneticMaterial, role, parentage));
    }

    public void testNo_Primary_Genetic_Material_Returns_Null_Parent() throws Exception {
        String role = ParentalRoleConstants.MALE_PARENTAL_ROLE;
        GeneticMaterialOfHybridGermplasmDAO dao = new GeneticMaterialOfHybridGermplasmDAO(germplasmWithNoPrimaryGm);
        GeneticMaterial geneticMaterial = dao.getParentOfPrimaryGeneticMaterial(role);

        assertNull(geneticMaterial);
    }

    private boolean contains(GeneticMaterial geneticMaterial, String role, Parentage[] parentage) {
        boolean exists = false;

        for (int i = 0; i < parentage.length; i++) {
            if (parentage[i].getParentalRole().getParentalRoleRefId().equals(role)) {
                GeneticMaterial parentGeneticMaterial = parentage[i].getParentGeneticMaterial();
                exists = (0 == geneticMaterial.getGeneticMaterialId().compareTo(parentGeneticMaterial.getGeneticMaterialId()));
            }
        }

        return exists;
    }
}