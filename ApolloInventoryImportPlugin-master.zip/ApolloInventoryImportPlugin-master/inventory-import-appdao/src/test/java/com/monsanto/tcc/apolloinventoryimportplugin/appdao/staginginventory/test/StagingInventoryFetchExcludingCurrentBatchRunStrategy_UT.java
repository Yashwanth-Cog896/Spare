/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.StagingInventoryFetchExcludingCurrentBatchRunStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

/**
 * Filename: $Id: StagingInventoryFetchExcludingCurrentBatchRunStrategy_UT.java,v 1.1 2008-02-21 20:34:02 srkarna Exp $
 *
 * @author APATRO
 * @version $Revision: 1.1 $
 */
public class StagingInventoryFetchExcludingCurrentBatchRunStrategy_UT extends TestIIContextConfigurer {

    MockStagingInventoryData testInventoryData;
    private Session session;

    public void setUp() throws Exception {
        testInventoryData = new MockStagingInventoryData();
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        session.beginTransaction();
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
        session.getTransaction().rollback();
    }

    public void testGetStagingInventoryRecords_AtLeatsOne() {
        testInventoryData.createApprovedStagingInventory();

        StagingInventoryFetchExcludingCurrentBatchRunStrategy dao = new StagingInventoryFetchExcludingCurrentBatchRunStrategy();
        String[] statusCodes = new String[]{"Rejected"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length > 0);
    }

    public void testGetStagingInventoryRecords_LimitToAParticularSize() {
        testInventoryData.createApprovedStagingInventory();

        final int fetchSize = 5;
        StagingInventoryFetchExcludingCurrentBatchRunStrategy dao = new StagingInventoryFetchExcludingCurrentBatchRunStrategy(fetchSize);
        String[] statusCodes = new String[]{"Rejected"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length > 0);
        assertTrue(stagingInventory.length <= fetchSize);
    }

    public void testGetStagingInventoryRecords_None() {
        testInventoryData.createApprovedStagingInventory();

        StagingInventoryFetchExcludingCurrentBatchRunStrategy dao = new StagingInventoryFetchExcludingCurrentBatchRunStrategy();
        String[] statusCodes = new String[]{"Junk"};
        StagingInventory[] stagingInventory = dao.getStagingInventoryRecords(statusCodes);
        assertNotNull(stagingInventory);
        assertTrue(stagingInventory.length == 0);
    }

}