/*
 TestHelper was created on Mar 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.*;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.source.parentalsource.ParentalSource;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import com.monsanto.tcc.apolloinventoryimportplugin.common.util.RoyaltyFlagEvaluator;
import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.*;

/**
 * Filename:    $RCSfile: TestHelper.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ssnall $ On:	$Date: 2008/01/17 22:15:00 $
 *
 * @author APATRO
 * @version $Revision: 1.25 $
 */
public class TestHelper {
    private Session midasSession;
    private Session stagingSession;
    private boolean externalSession;
    private boolean transactionActive;

    private static final String DEFAULT_NOT_NULL_VALUE = "-";

    private List midasObjects = new ArrayList();
    private List stagingObjects = new ArrayList();

    public TestHelper() {
        externalSession = false;
    }

    private void initSessions() {
        midasSession = HibernateUtil.getSessionFactoryForMidasCentral().openSession();
        stagingSession = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    }

    public TestHelper(Session session) {
        this.midasSession = session;
        this.stagingSession = session;
        externalSession = true;
    }

    public TestHelper(Session midasSession, Session stagingSession) {
        this.midasSession = midasSession;
        this.stagingSession = stagingSession;
        externalSession = true;
    }

    public void beginTransaction() {
        if (!externalSession && !transactionActive) {
            initSessions();
            midasSession.beginTransaction();
            stagingSession.beginTransaction();
            transactionActive = true;
        }
    }

    public void endTransaction(boolean commit) {
        if (!externalSession && transactionActive) {
            try {
                if (!commit) {
                    midasSession.getTransaction().rollback();
                    stagingSession.getTransaction().rollback();
                } else {
                    midasSession.getTransaction().commit();
                    stagingSession.getTransaction().commit();
                }
            } finally {
                transactionActive = false;
                midasSession.close();
                //noinspection EmptyCatchBlock
                try {
                    stagingSession.close();
                } catch (HibernateException e) {
                }
            }
        }
    }

    public void endTransaction() {
        endTransaction(true);
    }

    public void rollbackTransaction() {
        endTransaction(false);
    }

    public void setStagingSession(Session session) {
        stagingSession = session;
    }

    public void setMidasSession(Session session) {
        midasSession = session;
    }

    public void flushSession() {
        midasSession.flush();
        midasSession.clear();
    }

    public void purgeMidasObjects() {
        if (midasObjects != null && midasObjects.size() > 0) {
            Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            session.beginTransaction();
            for (int i = midasObjects.size() - 1; i >= 0; i--) {
                session.delete(midasObjects.get(i));
            }
            session.getTransaction().commit();
//            session.close();
        }
    }

    public void purgeStagingObjects() {
        if (stagingObjects != null && stagingObjects.size() > 0) {
            Session session = HibernateUtil.getSessionFactoryForStagingInventory().openSession();
            session.beginTransaction();
            for (int i = stagingObjects.size() - 1; i >= 0; i--) {
                session.delete(stagingObjects.get(i));
            }
            session.getTransaction().commit();
//            session.close();
        }
    }

    public void purgeProduct(String cropName, String productNameString, String brandName, String companyName) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().openSession();
        session.beginTransaction();

        Criteria criteria = session.createCriteria(ProductName.class, "pn")
                .add(Restrictions.eq("pn.name", productNameString))
                .createAlias("pn.brand", "br")
                .add(Restrictions.eq("br.name", brandName).ignoreCase())
                .createAlias("br.company", "c")
                .add(Restrictions.eq("c.name", companyName).ignoreCase());
        List list = criteria.list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ProductName productName = (ProductName) iterator.next();
                Product product = productName.getProduct();
                deleteProductGermplasm(session, productName, cropName);
                session.delete(productName);
                session.delete(product);
            }
        }
        session.getTransaction().commit();
//        session.close();
    }

    private void deleteProductGermplasm(Session session, ProductName productName, String cropName) {
        Criteria criteria = session.createCriteria(ProductGermplasm.class, "pg")
                .add(Restrictions.eq("pg.product", productName.getProduct()))
                .createAlias("pg.product", "pr")
                .createAlias("pr.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName));

        List list = criteria.list();
        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ProductGermplasm productGermplasm = (ProductGermplasm) iterator.next();
                session.delete(productGermplasm);
            }
        }
    }

    public void purgeGermplasm(String lineType, String lineCode, String origin, String pedigreeName,
                               String cropName) {
        boolean originalExternalSession = externalSession;
        externalSession = true;
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().openSession();
        session.beginTransaction();

        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.lineType", "lt")
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName));

        if (!StringUtils.isNullOrEmpty(lineCode)) {
            criteria.add(Restrictions.eq("gp.lineCode", lineCode));

        }
        List list = criteria.list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Germplasm germplasm = (Germplasm) iterator.next();
                deleteGeneticMaterial(session, germplasm);
                session.delete(germplasm);
            }
        }
        session.getTransaction().commit();
        session.close();
        externalSession = originalExternalSession;
    }

    private void checkTransaction() {
        if (!externalSession && !transactionActive) {
            throw new RuntimeException("No active transaction found. Use beginTransaction() first!");
        }
    }

    public Germplasm[] createInbreds(String[] pedigreeNames, String germplasmOwner, String cropName, String[] origins) {
        Germplasm[] germplasm = new Germplasm[pedigreeNames.length];

        for (int i = 0; i < pedigreeNames.length; i++) {
            String pedigreeName = pedigreeNames[i];
            String origin = origins[i];
            germplasm[i] = createInbred(pedigreeName, germplasmOwner, cropName, origin);
        }

        return germplasm;
    }

    public Germplasm createInbred(String lineCode, String germplasmOwner, String cropName, String origin) {
        Germplasm germplasm = createGermplasm("Finished", lineCode, origin, lineCode, germplasmOwner, cropName);
        createInbredGeneticMaterial(germplasm, "SOME SOURCE - " + lineCode);
        return germplasm;
    }

    // @noinspection MethodWithTooManyParameters

    public Germplasm createGermplasm(String lineType, String lineCode, String origin, String pedigreeName,
                                     String ownerProgram, String cropName) {
        String deleted = "F";
        String finishedOrFinishedChild = "T";

        return createGermplasm(lineType, lineCode, origin, pedigreeName, ownerProgram, cropName, deleted,
                finishedOrFinishedChild);
    }

    // @noinspection MethodWithTooManyParameters

    public Germplasm createGermplasm(String lineType, String lineCode, String origin, String pedigreeName,
                                     String ownerProgram, String cropName, String lineFunction) {
        String deleted = "F";
        String finishedOrFinishedChild = "T";

        return createGermplasm(lineType, lineCode, origin, pedigreeName, ownerProgram, cropName, deleted,
                finishedOrFinishedChild, lineFunction, null);
    }

    // @noinspection MethodWithTooManyParameters

    public Germplasm createGermplasm(String lineType, String lineCode, String origin, String pedigreeName,
                                     String ownerProgram,
                                     String cropName, String deleted,
                                     String finishedOrFinishedChild
    ) {
        return createGermplasm(lineType, lineCode, origin, pedigreeName, ownerProgram, cropName, deleted,
                finishedOrFinishedChild, null, null);
    }

    // @noinspection MethodWithTooManyParameters

    public Germplasm createGermplasm(String lineType, String lineCode, String origin, String pedigreeName,
                                     String ownerProgram,
                                     String cropName, String deleted,
                                     String finishedOrFinishedChild, String lineFunction,
                                     String cytoplasmDonorPedigree) {
        checkTransaction();

        Germplasm germplasm = new Germplasm();
        germplasm.setId(getId());
        germplasm.setIsDeleted(deleted);
        germplasm.setIsFinishedOrFinishedChild(finishedOrFinishedChild);
        germplasm.setIsTransgenic("F");
        germplasm.setLineCode(lineCode);
        germplasm.setLineType(getLineType(lineType));
        germplasm.setOrigin(origin);
        germplasm.setPedigreeName(pedigreeName);
        BrProg brProg = getBrProg(ownerProgram, cropName);
        germplasm.setOwnerBrProg(brProg);
        germplasm.setCrop(brProg.getCrop());
        if (!StringUtils.isNullOrEmpty(lineFunction)) {
            germplasm.setLineFunction(getLineFunction(lineFunction));
        }
        germplasm.setCytoplasmDonor(cytoplasmDonorPedigree);

        midasSession.save(germplasm);
//    midasSession.flush();
        midasObjects.add(germplasm);

        return germplasm;
    }

    private Long getId() {
        Query q = midasSession.createSQLQuery("select midas.get_nextid from dual");
        BigDecimal bd = (BigDecimal) q.list().get(0);
        return new Long(bd.longValue());
    }

    public LineFunction getLineFunction(String lineFunction) {
        checkTransaction();

        List list = midasSession.createCriteria(LineFunction.class)
                .add(Restrictions.eq("refActive", "T"))
                .add(Restrictions.eq("lineFunctionRefId", lineFunction.toUpperCase()))
                .list();

        return (list.size() > 0) ? (LineFunction) list.get(0) : null;
    }

    public LineType getLineType(String lineType) {
        checkTransaction();

        List list = midasSession.createCriteria(LineType.class)
                .add(Restrictions.eq("refActive", "T"))
                .add(Restrictions.eq("lineTypeRefId", lineType.toUpperCase()))
                .list();

        return (LineType) list.get(0);
    }

    public BrProg getBrProg(String ownerProgram, String cropName) {

        return getBrProg(ownerProgram, cropName, "T");

    }

    public BrProg getBrProg(String ownerProgram, String cropName, String refActive) {
        checkTransaction();
        List list = midasSession.createCriteria(BrProg.class)
                .createAlias("crop", "cr")
                .add(Restrictions.eq("refActive", refActive))
                .add(Restrictions.eq("brProgRefId", ownerProgram.toUpperCase()))
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .list();

        return (BrProg) list.get(0);
    }

    public void setRefActiveOnBrProg(BrProg brProg, String refActive) {
        checkTransaction();
        brProg.setRefActive(refActive);
        midasSession.saveOrUpdate(brProg);
    }

    public void deleteGermplasm(String lineType, String origin, String pedigreeName, String cropName) {
        checkTransaction();

        List list = midasSession.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.lineType", "lt")
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Germplasm germplasm = (Germplasm) iterator.next();
                deleteGeneticMaterial(germplasm);
                midasSession.delete(germplasm);
            }
            midasSession.flush();
        }
    }

    public void deleteGermplasm(String origin, String cropName) {
        checkTransaction();

        List list = midasSession.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.lineType", "lt")
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("gp.origin", origin))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Germplasm germplasm = (Germplasm) iterator.next();
                deleteGeneticMaterial(germplasm);
                midasSession.delete(germplasm);
            }
            midasSession.flush();
        }
    }

    // todo: added this call for the purpose of fitnesse
    // once we find a way of retaining germplasm object within the scope of
    // fitness test, we can discontinue this method call

    public void deleteGermplasm(Long id) {
        deleteGermplasm(midasSession, id);
    }

    public void deleteGermplasm(Session session, Long id) {
        checkTransaction();

        List list = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.id", id))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Germplasm germplasm = (Germplasm) iterator.next();
                deleteGeneticMaterial(session, germplasm);
                session.delete(germplasm);
            }
            session.flush();
        }
    }

    // todo: added this call for the purpose of fitnesse
    // once we find a way of retaining germplasm object within the scope of
    // fitness test, we can discontinue this method call

    public void deleteGeneticMaterials(Long germplasmId) {
        checkTransaction();

        List list = midasSession.createCriteria(GeneticMaterial.class)
                .createAlias("germplasm", "gp")
                .add(Restrictions.eq("gp.id", germplasmId))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                GeneticMaterial geneticMaterial = (GeneticMaterial) iterator.next();
                deleteInventory(geneticMaterial);
                midasSession.delete(geneticMaterial);
            }
            midasSession.flush();
        }
    }

    public void deleteGeneticMaterial(Germplasm germplasm) {
        deleteGeneticMaterial(midasSession, germplasm);
    }

    public void deleteGeneticMaterial(Session session, Germplasm germplasm) {
        checkTransaction();

        List list = session.createCriteria(GeneticMaterial.class)
                .add(Restrictions.eq("germplasm", germplasm))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                GeneticMaterial geneticMaterial = (GeneticMaterial) iterator.next();
                deleteInventory(session, geneticMaterial);
                deleteParentage(session, geneticMaterial);
                session.delete(geneticMaterial);
            }
            session.flush();
        }

    }

    public void deleteInventory(GeneticMaterial geneticMaterial) {
        deleteInventory(midasSession, geneticMaterial);
    }

    public void deleteInventory(Session session, GeneticMaterial geneticMaterial) {
        checkTransaction();

        List list = session.createCriteria(Inventory.class)
                .add(Restrictions.eq("geneticMaterial", geneticMaterial))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Inventory inventory = (Inventory) iterator.next();
                //deleteInventoryImportHistory(inventory);
                session.delete(inventory);
            }
            session.flush();
        }
    }

    public void deleteInventory(Long inventoryId) {
        checkTransaction();

        List list = stagingSession.createCriteria(Inventory.class)
                .add(Restrictions.eq("inventoryId", inventoryId))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Inventory inventory = (Inventory) iterator.next();
                stagingSession.delete(inventory);
            }
            stagingSession.flush();
        }
    }

    private void deleteParentage(Session session, GeneticMaterial geneticMaterial) {
        checkTransaction();

        List list = session.createCriteria(Parentage.class).
                add(Restrictions.eq("geneticMaterial", geneticMaterial))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Parentage parentage = (Parentage) iterator.next();
                deleteParentage(session, parentage.getParentGeneticMaterial());
                deleteInventory(session, parentage.getParentGeneticMaterial());
                if (parentage.getParentGeneticMaterial() != null) {
                    session.delete(parentage.getParentGeneticMaterial());
                    if (!geneticMaterial.getGermplasm().equals(parentage.getParentGeneticMaterial().getGermplasm())) {
                        session.delete(parentage.getParentGeneticMaterial().getGermplasm());
                    }
                }
                session.delete(parentage);
            }
            session.flush();
        }
    }

    public GeneticMaterial createInbredGeneticMaterial(Germplasm germplasm, String source) {
        return createGeneticMaterial(germplasm, source, "INBRED", "|");
    }

    public GeneticMaterial createGeneticMaterial(Germplasm germplasm, String source, String generation, String lineage) {
        checkTransaction();

        GeneticMaterial geneticMaterial = new GeneticMaterial();
        geneticMaterial.setGeneration(generation);
        geneticMaterial.setGeneticMaterialId(getId());
        geneticMaterial.setGermplasm(germplasm);
        geneticMaterial.setIsAutogen("F");
        geneticMaterial.setSourceStr(source);
        geneticMaterial.setLineage(lineage);

        midasSession.save(geneticMaterial);
        midasSession.flush();
        midasObjects.add(geneticMaterial);

        return geneticMaterial;
    }

    public Parentage createParentage(GeneticMaterial geneticMaterial, GeneticMaterial parentGeneticMaterial,
                                     String parentalRole) {
        Parentage parentage = new Parentage();
        parentage.setGeneticMaterial(geneticMaterial);
        parentage.setParentGeneticMaterial(parentGeneticMaterial);
        parentage.setTester("T");
        parentage.setParentageId(getId());
        parentage.setParentalRole(getParentalRole(parentalRole));

        midasSession.save(parentage);
        midasSession.flush();
        midasObjects.add(parentage);

        return parentage;
    }

    private ParentalRole getParentalRole(String s) {
        List list = midasSession.createCriteria(ParentalRole.class)
                .add(Restrictions.eq("parentalRoleRefId", s))
                .list();

        return (list != null && list.size() > 0) ? (ParentalRole) list.get(0) : null;
    }

    public Inventory createInventory(GeneticMaterial geneticMaterial, String archivedMaterial, String inventoryOwner) {
        return createInventory(geneticMaterial, archivedMaterial, inventoryOwner, "T");
    }

    public Inventory createInventory(GeneticMaterial geneticMaterial, String archivedMaterial, String inventoryOwner,
                                     String active) {
        return createInventory(geneticMaterial, archivedMaterial, inventoryOwner, active, null);
    }

    public Inventory createInventory(GeneticMaterial geneticMaterial, String archivedMaterial, String inventoryOwner,
                                     String active, String vegetativeStructure) {
        checkTransaction();

        Inventory inventory = new Inventory();
        inventory.setGeneticMaterial(geneticMaterial);
        inventory.setArchivedMaterial(archivedMaterial);
        inventory.setIsActive(active);
        inventory.setInventoryId(getId());
        inventory.setProgram(getBrProg(inventoryOwner, geneticMaterial.getGermplasm().getCrop().getCropName()));
        inventory.setCheckIndicator("F");
        inventory.setInventoryType(getInventoryType(geneticMaterial.getGermplasm().getLineType().getLineTypeRefId(),
                geneticMaterial.getGermplasm().getCrop().getCropName()));
        inventory.setVegetativeStructure(getVegetativeStructure(vegetativeStructure));

        midasSession.save(inventory);
        midasSession.flush();
        midasObjects.add(inventory);

        return inventory;
    }

    private VegetativeStructure getVegetativeStructure(String vegetativeStructure) {
        if (vegetativeStructure == null || vegetativeStructure.trim().length() == 0) {
            vegetativeStructure = "Seed";
        }
        return (VegetativeStructure) midasSession.createCriteria(VegetativeStructure.class)
                .add(Expression.eq("name", vegetativeStructure).ignoreCase())
                .add(Expression.eq("refActive", "T"))
                .uniqueResult();
    }

    public Inventory createInventory(Long geneticMaterialId, String archivedMaterial, String inventoryOwner) {
        checkTransaction();
        GeneticMaterial geneticMaterial = null;
        List list = midasSession.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.geneticMaterialId", geneticMaterialId))
                .list();
        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                geneticMaterial = (GeneticMaterial) iterator.next();
            }
        }
        Inventory inventory = new Inventory();
        inventory.setGeneticMaterial(geneticMaterial);
        inventory.setArchivedMaterial(archivedMaterial);
        inventory.setIsActive("T");
        inventory.setInventoryId(getId());
        inventory.setProgram(getBrProg(inventoryOwner, geneticMaterial.getGermplasm().getCrop().getCropName()));
        inventory.setCheckIndicator("F");
        inventory.setInventoryType(getInventoryType(geneticMaterial.getGermplasm().getLineType().getLineTypeRefId(),
                geneticMaterial.getGermplasm().getCrop().getCropName()));

        midasSession.save(inventory);
        midasSession.flush();
        midasObjects.add(inventory);

        return inventory;
    }

    private InventoryType getInventoryType(String lineType, String cropName) {
        String inventoryTypeLineType = convertLineTypeToInventoryTypeLineType(lineType);

        return (InventoryType) midasSession.createCriteria(InventoryType.class, "it")
                .createCriteria("it.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("it.lineTypeRefId", inventoryTypeLineType))
                .add(Restrictions.eq("it.name", getInventoryTypeName(inventoryTypeLineType)))
                .add(Restrictions.eq("it.refActive", "T"))
                .add(Restrictions.eq("it.active", "T"))
                .uniqueResult();
    }

    private String getInventoryTypeName(String inventoryTypeLineType) {
        char[] name = inventoryTypeLineType.toLowerCase().toCharArray();

        name[0] = new String(new char[]{name[0]}).toUpperCase().charAt(0);

        StringBuffer buffer = new StringBuffer();
        buffer.append("Active ").append(name);

        return buffer.toString();
    }

    private String convertLineTypeToInventoryTypeLineType(String lineType) {
        String inventoryTypeLineType = null;

        if (lineType.equalsIgnoreCase("Finished")) {
            inventoryTypeLineType = "INBRED";
        } else if (lineType.equalsIgnoreCase("Coded") || lineType.equalsIgnoreCase("Segpop")) {
            inventoryTypeLineType = "SEGPOP";
        } else if (lineType.equalsIgnoreCase("Hybrid")) {
            inventoryTypeLineType = "HYBRID";
        }

        return inventoryTypeLineType;
    }

    public StagingInventory createICBMaleStagingInventory(String cropName, String userId, String source,
                                                          String pedigreeName, String templateName,
                                                          boolean icbMaleYesNo) {
        checkTransaction();

        String importTypeAbbrev = MaterialTypeConstants.ICB_MALE;

        StagingInventoryHeader inventoryHeader = createStagingInventoryHeader(templateName, cropName, userId,
                importTypeAbbrev);

        StagingInventory stagingInventory = createStagingInventory(inventoryHeader, importTypeAbbrev, null, source,
                null,
                null, null, null, null, null, importTypeAbbrev, userId, null, null, null, null, null, null);
        stagingInventory.setPedigreeName(pedigreeName);
        stagingInventory.setIcbMale((icbMaleYesNo) ? "Y" : "N");

        stagingInventory.setCreationDate(new Date());
        stagingInventory.setApprovalProcessDate(new Date());
        stagingInventory.setApprovalRequestDate(new Date());
        stagingInventory.setAuthorityProcessed(userId);
        stagingInventory.setAuthorityRequested(userId);
        stagingInventory.setValidationDate(new Date());

        saveStagingInventory(stagingInventory);

        return stagingInventory;
    }

    public CompICBMale createCompIcbMale(GeneticMaterial geneticMaterial, boolean refActive) {
        checkTransaction();

        CompICBMale compICBMale = new CompICBMale();
        compICBMale.setCompICBMaleId(getId());
        compICBMale.setGeneticMaterial(geneticMaterial);
        compICBMale.setCrop(geneticMaterial.getGermplasm().getCrop());
        compICBMale.setRefActive((refActive) ? "T" : "F");

        midasSession.save(compICBMale);
        midasSession.flush();
        midasObjects.add(compICBMale);

        return compICBMale;
    }

    public StagingInventoryHeader createStagingInventoryHeader(String templateFileName, String cropName, String userId,
                                                               String importTypeAbbrev) {
        StagingInventoryHeader inventoryHeader = new StagingInventoryHeader();
        inventoryHeader.setCropName(cropName);
        inventoryHeader.setUserId(userId);
        inventoryHeader.setBatchDate(new Date());
        inventoryHeader.setTemplateName(templateFileName);
        ImportType importType = new ImportType();
        importType.setAbbreviation(importTypeAbbrev);
        inventoryHeader.setImportType(importType);


        return inventoryHeader;
    }

    // todo: added this call for the purpose of fitnesse
    // once we find a way of retaining germplasm object within the scope of
    // fitness test, we can discontinue this method call

    public void createStagingInventory(StagingInventoryHeader stagingInventoryHeader, StagingInventory stagingInventory) {
        checkTransaction();

        stagingSession.save(stagingInventoryHeader);
        stagingSession.save(stagingInventory);
        stagingObjects.add(stagingInventoryHeader);
        stagingObjects.add(stagingInventory);
        stagingSession.flush();
    }

    public StagingInventory createStagingInventory(StagingInventoryHeader inventoryHeader, String subImportType,
                                                   String origin, String source,
                                                   String femaleParentSource, String maleParentSource,
                                                   String femaleGpOwner, String maleGpOwner, String inventoryOwner,
                                                   String germplasmOwner, String lineType,
                                                   String userId, String generation, String lineage, String lineCode,
                                                   String lineFunctionRefId, String cytoplasmDonorSource,
                                                   String cytoplasmDonorPedigree) {
        return createStagingInventory(inventoryHeader, subImportType, origin, source, femaleParentSource, maleParentSource,
                femaleGpOwner, maleGpOwner, inventoryOwner, germplasmOwner, lineType, userId, generation, lineage, lineCode,
                lineFunctionRefId, cytoplasmDonorSource, cytoplasmDonorPedigree, null, null, null, null);
    }

    public StagingInventory createStagingInventory(StagingInventoryHeader inventoryHeader, String subImportType,
                                                   String origin, String source,
                                                   String femaleParentSource, String maleParentSource,
                                                   String femaleGpOwner, String maleGpOwner, String inventoryOwner,
                                                   String germplasmOwner, String lineType,
                                                   String userId, String generation, String lineage, String lineCode,
                                                   String lineFunctionRefId, String cytoplasmDonorSource,
                                                   String cytoplasmDonorPedigree, String royalty, String company, String externalGermplasmName) {
        return createStagingInventory(inventoryHeader, subImportType, origin, source, femaleParentSource, maleParentSource,
                femaleGpOwner, maleGpOwner, inventoryOwner, germplasmOwner, lineType, userId, generation, lineage, lineCode,
                lineFunctionRefId, cytoplasmDonorSource, cytoplasmDonorPedigree, null, royalty, company, lineCode);
    }

    // @noinspection MethodWithTooManyParameters

    public StagingInventory createStagingInventory(StagingInventoryHeader inventoryHeader, String subImportType,
                                                   String origin, String source,
                                                   String femaleParentSource, String maleParentSource,
                                                   String femaleGpOwner, String maleGpOwner, String inventoryOwner,
                                                   String germplasmOwner, String lineType,
                                                   String userId, String generation, String lineage, String lineCode,
                                                   String lineFunctionRefId, String cytoplasmDonorSource,
                                                   String cytoplasmDonorPedigree, String brandName, String royalty, String company, String externalGermplasmName) {
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setSource(source);
        stagingInventory.setFemaleParentSource(femaleParentSource);
        stagingInventory.setMaleParentSource(maleParentSource);
        stagingInventory.setGermplasmOwnerOfFemaleParent(femaleGpOwner);
        stagingInventory.setGermplasmOwnerOfMaleParent(maleGpOwner);
        stagingInventory.setInventoryOwner(inventoryOwner);
        stagingInventory.setGermplasmOwner(germplasmOwner);
        stagingInventory.setGeneration(generation);
        stagingInventory.setLineage(lineage);
        stagingInventory.setLineType(lineType);
        stagingInventory.setLineCode(lineCode);
        stagingInventory.setInventoryHeader(inventoryHeader);
        stagingInventory.setImportType(getImportType(subImportType));

        stagingInventory.setAuthorityProcessed(userId);
        stagingInventory.setAuthorityRequested(userId);

        stagingInventory.setUserSpecifiedSource("T");

        ImportStatus importStatus = new ImportStatus();
        importStatus.setStatusCode(StagingInventoryStatusConstants.NEW);
        stagingInventory.setImportStatus(importStatus);
        stagingInventory.setLineFunction(lineFunctionRefId);
        stagingInventory.setCytoplasmDonorSource(cytoplasmDonorSource);
        stagingInventory.setCytoplasmDonorPedigree(cytoplasmDonorPedigree);
        stagingInventory.setBrandName(brandName);
        return stagingInventory;
    }

    public ImportType getImportType(String abbrev) {
        checkTransaction();

        List list = stagingSession.createCriteria(ImportType.class)
                .add(Restrictions.eq("abbreviation", abbrev).ignoreCase())
                .list();

        return (ImportType) list.get(0);
    }

    public ImportStatus getImportStatus(String statusCode) {
        checkTransaction();

        List list = stagingSession.createCriteria(ImportStatus.class)
                .add(Restrictions.eq("statusCode", statusCode).ignoreCase())
                .list();

        return (ImportStatus) list.get(0);
    }

    private void saveStagingInventory(StagingInventory stagingInventory) {
        StagingInventoryHeader inventoryHeader = stagingInventory.getInventoryHeader();
        inventoryHeader.setImportType(getImportType(inventoryHeader.getImportType().getAbbreviation()));

        defaultRequiredColumns(stagingInventory);

        stagingSession.save(inventoryHeader);
        stagingSession.flush();
        stagingObjects.add(inventoryHeader);

        StagingParentage[] stagingParentage = stagingInventory.getSubRecords();
        if (stagingParentage != null) {
            for (int i = 0; i < stagingParentage.length; i++) {
                StagingParentage parentage = stagingParentage[i];
                StagingInventory parentInventory = parentage.getParentInventory();
                parentInventory.setImportType(getImportType(parentInventory.getImportType().getAbbreviation()));
                parentInventory.setImportStatus(getImportStatus(parentInventory.getImportStatus().getStatusCode()));
                stagingSession.save(parentInventory);
                stagingSession.flush();
                stagingObjects.add(parentInventory);
            }

            stagingInventory.setImportType(getImportType(stagingInventory.getImportType().getAbbreviation()));
            stagingInventory.setImportStatus(getImportStatus(stagingInventory.getImportStatus().getStatusCode()));
            stagingSession.save(stagingInventory);
            stagingSession.flush();
            stagingObjects.add(stagingInventory);

            Set parentalSourceSet = stagingInventory.getParentalSources();
            if (parentalSourceSet != null && parentalSourceSet.size() > 0) {
                Iterator iterator = parentalSourceSet.iterator();
                while (iterator.hasNext()) {
                    ParentalSource parentalSource = (ParentalSource) iterator.next();
                    stagingObjects.add(parentalSource);
                }
            }

            for (int i = 0; i < stagingParentage.length; i++) {
                StagingParentage parentage = stagingParentage[i];
                stagingObjects.add(parentage);
            }
        }
    }

    public Product createProduct(String cropName, String refActive) {
        checkTransaction();

        Product product = new Product();
        product.setId(getId());
        product.setRefActive(refActive);
        product.setCrop(getCrop(cropName));
        midasSession.save(product);
        midasSession.flush();
        midasObjects.add(product);

        return product;
    }

    public ProductName createProductName(String productNameString, String refActive, String brandName, String companyName,
                                         String countryName,
                                         Product product) {
        checkTransaction();

        ProductName productName = new ProductName();
        productName.setId(getId());
        productName.setProduct(product);
        productName.setRefActive(refActive);
        productName.setName(productNameString);
        productName.setBrand(getBrand(brandName, companyName));
        productName.setCountryId(getCountryId(countryName).toString());
        midasSession.save(productName);
        midasSession.flush();
        midasObjects.add(productName);

        return productName;
    }

    public Brand getBrand(String brandName, String companyName) {
        checkTransaction();

        List list = midasSession.createCriteria(Brand.class, "br")
                .add(Restrictions.or(Restrictions.eq("br.refActive", "T").ignoreCase(), Restrictions.eq("br.refActive", "y").ignoreCase()))
                .add(Restrictions.eq("br.name", brandName).ignoreCase())
                .createAlias("br.company", "cm")
                .add(Restrictions.eq("cm.refActive", "T"))
                .add(Restrictions.eq("cm.name", companyName).ignoreCase())
                .list();

        return (list != null && list.size() > 0) ? (Brand) list.get(0) : null;
    }

    public Company getCompetitorCompany() {
        checkTransaction();

        List list = midasSession.createCriteria(Company.class, "c")
                .add(Restrictions.eq("c.refActive", "T"))
                .add(Restrictions.ne("c.name", "MONSANTO").ignoreCase())
                .list();

        return (list != null && list.size() > 0) ? (Company) list.get(0) : null;
    }

    public Company getForCommercialCompany() {
        checkTransaction();

        List list = midasSession.createCriteria(Company.class, "c")
                .add(Restrictions.eq("c.refActive", "T"))
                .add(Restrictions.eq("c.name", "MONSANTO").ignoreCase())
                .list();

        return (list != null && list.size() > 0) ? (Company) list.get(0) : null;
    }

    public Crop getCrop(String cropName) {
        checkTransaction();

        List list = midasSession.createCriteria(Crop.class)
                .add(Restrictions.eq("refActive", "T"))
                .add(Restrictions.eq("cropName", cropName).ignoreCase())
                .list();

        return (Crop) list.get(0);
    }

    public ProductName createProductName(String productNameString, String refActive, String brandName, String countryName,
                                         Product product) {
        checkTransaction();

        ProductName productName = new ProductName();
        productName.setId(getId());
        productName.setProduct(product);
        productName.setRefActive(refActive);
        productName.setName(productNameString);
        productName.setBrand(getBrand(brandName));
        productName.setCountryId(getCountryId(countryName).toString());
        midasSession.save(productName);
        midasSession.flush();
        midasObjects.add(productName);

        return productName;
    }


    public ProductName createProductName(Brand brand, Country country, Product product, String name, String refActive) {
        checkTransaction();

        ProductName productName = new ProductName();
        productName.setId(getId());
        productName.setProduct(product);
        productName.setRefActive(refActive);
        productName.setName(name);
        productName.setBrand(brand);
        productName.setCountryId(country.getCountryId().toString());
        midasSession.save(productName);
        midasSession.flush();
        midasObjects.add(productName);

        return productName;
    }

    public Brand getBrand(String brandName) {
        checkTransaction();

        List list = midasSession.createCriteria(Brand.class)
                .add(Restrictions.or(Restrictions.eq("refActive", "T").ignoreCase(), Restrictions.eq("refActive", "y").ignoreCase()))
                .add(Restrictions.eq("name", brandName).ignoreCase())
                .list();

        return (list != null && list.size() > 0) ? (Brand) list.get(0) : null;
    }

    public Long getCountryId(String countryName) {
        checkTransaction();

        List list = midasSession.createCriteria(Country.class)
                .add(Restrictions.eq("refActive", "T"))
                .add(Restrictions.eq("name", countryName).ignoreCase())
                .list();

        return ((Country) list.get(0)).getCountryId();
    }

    public ProductGermplasm createProductGermplasm(Product product, Germplasm germplasm) {
        checkTransaction();

        ProductGermplasm productGermplasm = new ProductGermplasm();
        productGermplasm.setId(getId());
        productGermplasm.setProduct(product);
        productGermplasm.setGermplasm(germplasm);
        midasSession.save(productGermplasm);
        midasSession.flush();
        midasObjects.add(productGermplasm);

        return productGermplasm;
    }

    public ProductGermplasm createProductGermplasm(Long productId, Long germplasmId) {
        checkTransaction();

        Germplasm germplasm = (Germplasm) midasSession.get(Germplasm.class, germplasmId);
        Product product = (Product) midasSession.get(Product.class, productId);
        return createProductGermplasm(product, germplasm);

    }


    public StagingInventory getStagingInventoryWithParentage(String userId, String cropName, String templateName) {
        if (StringUtils.isNullOrEmpty(userId) || StringUtils.isNullOrEmpty(cropName) ||
                StringUtils.isNullOrEmpty(templateName)) {
            throw new IllegalArgumentException("expecting userId, cropName and templateName");
        }
        String queryString = "from StagingInventory si " +
                " where lower(si.inventoryHeader.userId) = :userId" +
                " and si.inventoryHeader.cropName = :cropName" +
                " and si.inventoryHeader.templateName = :templateName" +
                "  and not exists (from StagingParentage sp where parentInventory = si)";

        Query query = stagingSession.createQuery(queryString);
        query.setParameter("userId", userId.toLowerCase());
        query.setParameter("cropName", cropName);
        query.setParameter("templateName", templateName);
        StagingInventory inventory = (StagingInventory) query.uniqueResult();
        Set stagingParentage = inventory.getStagingParentage();
        if (stagingParentage != null) {
            Iterator iter = stagingParentage.iterator();
            while (iter.hasNext()) {
                StagingParentage parentage = (StagingParentage) iter.next();
                stagingObjects.add(parentage.getParentInventory());
                stagingObjects.add(parentage);
            }
        }
        stagingObjects.add(inventory);
        return inventory;
    }

    public Product getProductById(Long productId) {
        return (Product) midasSession.get(Product.class, productId);
    }

    public ImportStatus getImportStatusByStatusCode(String statusCode) {
        return (ImportStatus) stagingSession.createCriteria(ImportStatus.class)
                .add(Restrictions.eq("statusCode", statusCode)).uniqueResult();
    }

    public void preprocessMainRecordAndParentageForBatchProcessing(StagingInventory inventory, String statusCode,
                                                                   String authorityProcessed) {
        StagingInventory inventoryFromDb = getStagingInventoryWithParentage(inventory.getInventoryHeader().getUserId(),
                inventory.getInventoryHeader().getCropName(), inventory.getInventoryHeader().getTemplateName());
        setStatusTypeOnMainRecordAndParentage(inventoryFromDb, statusCode);
        setApprovedStatusOnMainRecordAndParentage(inventoryFromDb, authorityProcessed);
        stagingSession.update(inventoryFromDb);
    }

    private void setStatusTypeOnMainRecordAndParentage(StagingInventory mainInventory, String statusCode) {
        ImportStatus importStatus = getImportStatusByStatusCode(statusCode);
        mainInventory.setImportStatus(importStatus);
        Set parentageSet = mainInventory.getStagingParentage();
        if (parentageSet != null) {
            Iterator iter = parentageSet.iterator();
            while (iter.hasNext()) {
                StagingParentage parentage = (StagingParentage) iter.next();
                parentage.getParentInventory().setImportStatus(importStatus);
            }
        }
    }

    private void setApprovedStatusOnMainRecordAndParentage(StagingInventory mainInventory, String authorityId) {
        Date approvalDate = new Date();
        mainInventory.setAuthorityProcessed(authorityId);
        mainInventory.setAuthorityRequested(authorityId);
        mainInventory.setApprovalProcessDate(approvalDate);
        mainInventory.setValidationDate(approvalDate);
        mainInventory.setApprovalRequestDate(approvalDate);
        Set parentageSet = mainInventory.getStagingParentage();
        if (parentageSet != null) {
            Iterator iter = parentageSet.iterator();
            while (iter.hasNext()) {
                StagingParentage parentage = (StagingParentage) iter.next();
                parentage.getParentInventory().setAuthorityProcessed(authorityId);
                parentage.getParentInventory().setAuthorityRequested(authorityId);
                parentage.getParentInventory().setApprovalProcessDate(approvalDate);
                parentage.getParentInventory().setApprovalRequestDate(approvalDate);
                parentage.getParentInventory().setValidationDate(approvalDate);
            }
        }
    }

    public void setStatusCodeOnMainInventoryAndParentage(String statusCode, StagingInventory inventory) {
        StagingInventory inventoryFromDb = getStagingInventoryWithParentage(inventory.getInventoryHeader().getUserId(),
                inventory.getInventoryHeader().getCropName(), inventory.getInventoryHeader().getTemplateName());
        ImportStatus importStatus = getImportStatusByStatusCode(statusCode);
        inventoryFromDb.setImportStatus(importStatus);
        Set parentageSet = inventoryFromDb.getStagingParentage();
        if (parentageSet != null) {
            Iterator iter = parentageSet.iterator();
            while (iter.hasNext()) {
                StagingParentage parentage = (StagingParentage) iter.next();
                parentage.getParentInventory().setImportStatus(importStatus);
            }
        }
        stagingSession.update(inventoryFromDb);
    }

    public StagingInventory createCompetitorStagingInventory(String cropName, String importType, String productName,
                                                             String source, String inventoryOwner, String userId) {
        String templateName = createTemplateName(cropName, importType, productName, source, inventoryOwner, userId);

        StagingInventoryHeader header = createStagingInventoryHeader(templateName, cropName, userId, importType);
        header.setImportType(getImportType(importType));

        StagingInventory stagingInventory = createStagingInventory(header, importType, null, source, null, null, null, null,
                inventoryOwner, null, null, userId, null, null, null, null, null, null);
        stagingInventory.setImportStatus(getImportStatus(stagingInventory.getImportStatus().getStatusCode()));
        return stagingInventory;
    }

    private String createTemplateName(String cropName, String importType, String productName, String source,
                                      String inventoryOwner, String userId) {
        return "II_Import_Template_" + cropName + "_" + importType + "_" + productName + "_" + source + "_" +
                inventoryOwner + "_" + userId + ".xls";
    }

    public void deleteStagingInventoryHeader(String templateFileName, String cropName,
                                             String importType) {
        checkTransaction();

        List list = stagingSession.createCriteria(StagingInventoryHeader.class, "sih")
                .createAlias("sih.importType", "it")
                .add(Restrictions.eq("sih.templateName", templateFileName))
                .add(Restrictions.eq("sih.cropName", cropName))
//        .add(Restrictions.eq("sih.userId", userId))
                .add(Restrictions.eq("it.abbreviation", importType).ignoreCase())
                .list();

        deleteRunDetails(templateFileName, cropName, importType);

        if (list != null && list.size() > 0) {
            Iterator listIterator = list.iterator();
            while (listIterator.hasNext()) {
                StagingInventoryHeader inventoryHeader = (StagingInventoryHeader) listIterator.next();
                Set stagingInventorySet = inventoryHeader.getStagingInventory();
                if (stagingInventorySet != null && stagingInventorySet.size() > 0) {
                    // Delete StagingInventory with Parentage only
                    Iterator setIterator = stagingInventorySet.iterator();
                    while (setIterator.hasNext()) {
                        StagingInventory stagingInventory = (StagingInventory) setIterator.next();
                        Set stagingParentageSet = stagingInventory.getStagingParentage();
                        if (stagingParentageSet != null && stagingParentageSet.size() > 0) {
                            Iterator setIterator1 = stagingParentageSet.iterator();
                            while (setIterator1.hasNext()) {
                                StagingParentage stagingParentage = (StagingParentage) setIterator1.next();
                                stagingSession.delete(stagingParentage);
                            }
                            stagingSession.delete(stagingInventory);
                        }
                    }

                    // Delete all StagingInventory without Parentage
                    setIterator = stagingInventorySet.iterator();
                    while (setIterator.hasNext()) {
                        StagingInventory stagingInventory = (StagingInventory) setIterator.next();

                        Set parentalSourcesSet = stagingInventory.getParentalSources();
                        if (parentalSourcesSet != null && parentalSourcesSet.size() > 0) {
                            Iterator setIterator2 = parentalSourcesSet.iterator();
                            while (setIterator2.hasNext()) {
                                stagingSession.delete(setIterator2.next());
                            }
                        }

                        Set stagingParentageSet = stagingInventory.getStagingParentage();
                        if (stagingParentageSet == null || stagingParentageSet.size() == 0) {
                            stagingSession.delete(stagingInventory);
                        }
                    }
                }
                stagingSession.delete(inventoryHeader);
            }

            stagingSession.flush();
        }
    }

    private void deleteRunDetails(String templateFileName, String cropName, String importType) {

        Query query = stagingSession.createQuery("select rd " +
                "from RunDetail as rd, StagingInventory as si, StagingInventoryHeader as sih, " +
                "ImportType it " +
                "where rd.inventoryId = si.id " +
                "and si.inventoryHeader = sih " +
                "and sih.templateName = :templateFileName " +
                "and sih.cropName = :cropName " +
                "and sih.importType = it " +
                "and it.abbreviation = :importType");

        query.setParameter("templateFileName", templateFileName);
        query.setParameter("cropName", cropName);
        query.setParameter("importType", importType);

        System.out.println("query = " + query);

        List list = query.list();

        for (int i = 0; i < list.size(); i++) {
            RunDetail runDetail = (RunDetail) list.get(i);
            runDetail.setInventoryId(null);
            stagingSession.delete(runDetail);
        }
    }

    public void deleteBrProg(Long brProgId) {
        checkTransaction();

        List list = midasSession.createCriteria(BrProg.class, "br")
                .add(Restrictions.eq("br.brProgId", brProgId))
                .list();
        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                BrProg brProg = (BrProg) iterator.next();
                midasSession.delete(brProg);
            }
            midasSession.flush();
        }
    }

    public GermplasmEventConstruct createGermplasmEventConstruct(Long germplasmId, Long eventConstructId) {
        checkTransaction();

        GermplasmEventConstruct germplasmEventConstruct = new GermplasmEventConstruct();
        germplasmEventConstruct.setGermplasmEventConstructId(getId());

        Germplasm germplasm = (Germplasm) midasSession.load(Germplasm.class, germplasmId);
        germplasmEventConstruct.setGermplasm(germplasm);

        EventConstruct eventConstruct = (EventConstruct) midasSession.load(EventConstruct.class, eventConstructId);
        germplasmEventConstruct.setEventConstruct(eventConstruct);

        midasSession.save(germplasmEventConstruct);
        midasSession.flush();
        midasObjects.add(germplasmEventConstruct);

        return germplasmEventConstruct;
    }

    public GermplasmEventConstruct createGermplasmEventConstructAbsence(Long germplasmId, Long eventConstructId, Date absenceDate) {
        checkTransaction();

        GermplasmEventConstruct germplasmEventConstruct = new GermplasmEventConstruct();
        germplasmEventConstruct.setGermplasmEventConstructId(getId());

        Germplasm germplasm = (Germplasm) midasSession.load(Germplasm.class, germplasmId);
        germplasmEventConstruct.setGermplasm(germplasm);

        EventConstruct eventConstruct = (EventConstruct) midasSession.load(EventConstruct.class, eventConstructId);
        germplasmEventConstruct.setEventConstruct(eventConstruct);
        germplasmEventConstruct.setAbsenceDate(absenceDate);

        midasSession.save(germplasmEventConstruct);
        midasSession.flush();
        midasObjects.add(germplasmEventConstruct);

        return germplasmEventConstruct;
    }

    public Country createCountry(String name, String refActive) {
        checkTransaction();

        Country country = new Country();
        country.setCountryId(getId());
        country.setName(name);
        country.setRefActive(refActive);
        midasSession.save(country);
        midasSession.flush();
        midasObjects.add(country);

        return country;
    }

    public void deleteCompetitorStagingInventory(String cropName, String importType, String productName,
                                                 String source, String inventoryOwner, String userId) {
        String templateName = createTemplateName(cropName, importType, productName, source, inventoryOwner, userId);

        deleteStagingInventoryHeader(templateName, cropName, importType);
    }

    public void deleteProductGermplasm(Long productGermplasmId) {
        checkTransaction();

        List list = midasSession.createCriteria(ProductGermplasm.class, "pg")
                .add(Restrictions.eq("pg.id", productGermplasmId))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ProductGermplasm productGermplasm = (ProductGermplasm) iterator.next();
                midasSession.delete(productGermplasm);
            }
            midasSession.flush();
        }
    }

    public void purgeEventConstruct(String cropName, String eventName, String constructName, String refActive) {
        boolean originalExternalSession = externalSession;
        externalSession = true;
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().openSession();
        session.beginTransaction();

        Criteria criteria = session.createCriteria(EventConstruct.class, "e")
                .add(Restrictions.eq("e.eventName", eventName));

        if (!StringUtils.isNullOrEmpty(constructName)) {
            criteria.add(Restrictions.eq("e.constructName", constructName));
        }
        if (!StringUtils.isNullOrEmpty(refActive)) {
            criteria.add(Restrictions.eq("e.refActive", refActive));
        }
        if (!StringUtils.isNullOrEmpty(cropName)) {
            criteria.createAlias("e.crop", "c")
                    .add(Restrictions.eq("c.cropName", cropName));
        }
        List list = criteria.list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                EventConstruct eventConstruct = (EventConstruct) iterator.next();
                deleteGermplasmEventConstruct(session, eventConstruct);
                session.delete(eventConstruct);
            }
        }
        session.getTransaction().commit();
        session.close();
        externalSession = originalExternalSession;
    }

    public void deleteEventConstruct(Long eventConstructId) {
        checkTransaction();

        EventConstruct eventConstruct = (EventConstruct) midasSession.load(EventConstruct.class, eventConstructId);

        deleteGermplasmEventConstruct(eventConstruct);
        midasSession.delete(eventConstruct);
        midasSession.flush();

    }

    private void deleteGermplasmEventConstruct(EventConstruct eventConstruct) {
        deleteGermplasmEventConstruct(midasSession, eventConstruct);
    }

    private void deleteGermplasmEventConstruct(Session session, EventConstruct eventConstruct) {
        checkTransaction();

        List list = session.createCriteria(GermplasmEventConstruct.class, "gec")
                .add(Restrictions.eq("eventConstruct", eventConstruct))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                GermplasmEventConstruct germplasmEventConstruct = (GermplasmEventConstruct) iterator.next();
                deleteGermplasm(session, germplasmEventConstruct.getGermplasm().getId());
                session.delete(germplasmEventConstruct);
            }
            session.flush();
        }

    }

    public void deleteProduct(Long productId) {
        checkTransaction();

        Product product = getProductById(productId);
        List list = midasSession.createCriteria(ProductName.class, "pn")
                .createAlias("pn.product", "p")
                .add(Restrictions.eq("p.id", productId))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ProductName productName = (ProductName) iterator.next();
                midasSession.delete(productName);
                deleteBrandPreference(productName.getBrand());
                midasSession.delete(productName.getBrand());
                midasSession.delete(productName.getBrand().getCompany());
            }
            midasSession.delete(product);
            midasSession.flush();
        }
    }

    public void deleteBrandPreference(Brand brand) {
        checkTransaction();

        List list = midasSession.createCriteria(BrandPreference.class, "bp")
                .add(Restrictions.eq("brand", brand))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                BrandPreference brandPreference = (BrandPreference) iterator.next();
                midasSession.delete(brandPreference);
            }
            midasSession.flush();
        }

    }

    public EventConstruct createEventConstruct(String cropName, String eventName, String constructName,
                                               String refActive) {
        checkTransaction();

        EventConstruct eventConstruct = new EventConstruct();
        eventConstruct.setEventConstructId(getId());
        eventConstruct.setCrop(getCrop(cropName));
        eventConstruct.setEventName(eventName);
        eventConstruct.setConstructName(constructName);
        eventConstruct.setRefActive(refActive);
        eventConstruct.setBarCode("E000000" + getId());

        midasSession.save(eventConstruct);
//        midasSession.flush();
        midasObjects.add(eventConstruct);

        return eventConstruct;
    }


    public Company createCompany(String name, String refActive) {
        checkTransaction();

        Company company = new Company();
        company.setCompanyId(getId());
        company.setName(name);
        company.setRefActive(refActive);
        midasSession.save(company);
        midasSession.flush();
        midasObjects.add(company);

        return company;
    }

    public Brand createBrand(Company company, String brandName, String refActive) {
        checkTransaction();

        Brand brand = new Brand();
        brand.setBrandId(getId());
        brand.setCompany(company);
        brand.setName(brandName);
        brand.setRefActive(refActive);
        midasSession.save(brand);
        midasSession.flush();
        midasObjects.add(brand);

        return brand;
    }

    public BrandPreference createBrandPreference(Brand brand, String brandProgram, String cropName) {
        checkTransaction();

        BrandPreference brandPreference = new BrandPreference();
        brandPreference.setBrandPreferenceId(getId());
        brandPreference.setBrand(brand);
        brandPreference.setBrProg(getBrProg(brandProgram, cropName));
        brandPreference.setRank(new Long(1));
        midasSession.save(brandPreference);
        midasSession.flush();
        midasObjects.add(brandPreference);

        return brandPreference;
    }

    public MidasUser createMidasUser(String loginId, String refActive) {
        checkTransaction();

        MidasUser midasUser = new MidasUser();
        midasUser.setMidasUserId(getId());
        midasUser.setLoginId(loginId);
        midasUser.setRefActive(refActive);
        midasSession.save(midasUser);
        midasSession.flush();
        midasObjects.add(midasUser);

        return midasUser;
    }

    public UserCropRole createUserCropRole(Crop crop, MidasUser midasUser, MidasRole midasRole, String refActive) {
        checkTransaction();

        UserCropRole userCropRole = new UserCropRole();
        userCropRole.setId(getId());
        userCropRole.setCrop(crop);
        userCropRole.setMidasUser(midasUser);
        userCropRole.setRefActive(refActive);
        userCropRole.setRole(midasRole);
        midasSession.save(userCropRole);
        midasSession.flush();
        midasObjects.add(userCropRole);

        return userCropRole;
    }

    public Germplasm createGermplasmForInactiveBrProg(String lineType, String lineCode, String origin,
                                                      String pedigreeName,
                                                      String ownerProgram,
                                                      String cropName, String deleted,
                                                      String finishedOrFinishedChild, String lineFunction,
                                                      String cytoplasmDonorPedigree) {
        checkTransaction();

        Germplasm germplasm = new Germplasm();
        germplasm.setId(getId());
        germplasm.setIsDeleted(deleted);
        germplasm.setIsFinishedOrFinishedChild(finishedOrFinishedChild);
        germplasm.setIsTransgenic("F");
        germplasm.setLineCode(lineCode);
        germplasm.setLineType(getLineType(lineType));
        germplasm.setOrigin(origin);
        germplasm.setPedigreeName(pedigreeName);
        BrProg brProg = getInactiveBrProg(ownerProgram, cropName);
        germplasm.setOwnerBrProg(brProg);
        germplasm.setCrop(brProg.getCrop());
        if (!StringUtils.isNullOrEmpty(lineFunction)) {
            germplasm.setLineFunction(getLineFunction(lineFunction));
        }
        germplasm.setCytoplasmDonor(cytoplasmDonorPedigree);

        midasSession.save(germplasm);
        midasSession.flush();
        midasObjects.add(germplasm);

        return germplasm;
    }

    public BrProg getInactiveBrProg(String ownerProgram, String cropName) {
        checkTransaction();

        List list = midasSession.createCriteria(BrProg.class)
                .createAlias("crop", "cr")
                .add(Restrictions.eq("refActive", "F"))
                .add(Restrictions.eq("brProgRefId", ownerProgram.toUpperCase()))
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .list();

        return (BrProg) list.get(0);
    }

    public BrProg getActiveBrProg(String cropName) {
        checkTransaction();

        List list = midasSession.createCriteria(BrProg.class)
                .createAlias("crop", "cr")
                .add(Restrictions.eq("refActive", "T"))
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .list();

        return (BrProg) list.get(0);
    }

    public BrProg createBrProg(String brProgRefId, String refActive, String cropName) {
        checkTransaction();

        BrProg brProg = new BrProg();
        brProg.setBrProgId(getId());
        brProg.setAcctId(getId());
        brProg.setMidasProgram("F");
        brProg.setBrProgRefId(brProgRefId);
        brProg.setName(brProgRefId);
        brProg.setCrop(getCrop(cropName));
        brProg.setRefActive(refActive);

        midasSession.save(brProg);
        midasSession.flush();
        midasObjects.add(brProg);

        return brProg;
    }

    public MidasRole getMidasRole(String roleName) {
        checkTransaction();

        List list = midasSession.createCriteria(MidasRole.class)
                .add(Restrictions.eq("name", roleName))
                .list();

        return (MidasRole) list.get(0);
    }

    public MidasRole getMidasRole(String name, String midasRoleRefId, String midasRoleTypeId, String refActive) {
        checkTransaction();

        List list = midasSession.createCriteria(MidasRole.class)
                .add(Restrictions.eq("name", name))
                .add(Restrictions.eq("roleRefId", midasRoleRefId))
                .add(Restrictions.eq("roleTypeId", midasRoleTypeId))
                .add(Restrictions.eq("refActive", refActive))
                .list();

        return (MidasRole) list.get(0);
    }


    public MidasRole getInactiveMidasRole() {
        checkTransaction();

        List list = midasSession.createCriteria(MidasRole.class)
                .add(Restrictions.eq("refActive", "F"))
                .list();

        return (MidasRole) list.get(0);
    }

    public ProgramToRole createProgramToRole(BrProg brProg, MidasRole midasRole, String refActive) {
        checkTransaction();

        ProgramToRole programToRole = new ProgramToRole();
        programToRole.setId(getId());
        programToRole.setBrProg(brProg);
        programToRole.setMidasRole(midasRole);
        programToRole.setRefActive(refActive);

        midasSession.save(programToRole);
        midasSession.flush();
        midasObjects.add(programToRole);

        return programToRole;
    }

    public BrProg selectBrProgRefIdOfACornGermplasmManager(String programToRoleRefActive, MidasRole midasRole,
                                                           String cropName) {
        checkTransaction();

        List list = midasSession.createCriteria(ProgramToRole.class, "ptr")
                .add(Restrictions.eq("ptr.refActive", programToRoleRefActive))
                .add(Restrictions.eq("ptr.midasRole", midasRole))
                .createAlias("ptr.brProg", "br")
                .add(Restrictions.eq("br.refActive", "T"))
                .createAlias("br.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .list();

        if (list != null && list.size() > 0) {
            ProgramToRole programToRole = (ProgramToRole) list.get(0);
            return programToRole.getBrProg();
        }
        return null;
    }

    public CompICBMale createCompICBMale(String cropName, GeneticMaterial geneticMaterial, String refActive) {
        checkTransaction();

        CompICBMale compICBMale = new CompICBMale();
        compICBMale.setCompICBMaleId(getId());
        compICBMale.setCrop(getCrop(cropName));
        compICBMale.setGeneticMaterial(geneticMaterial);
        compICBMale.setRefActive(refActive);

        midasSession.save(compICBMale);
        midasSession.flush();
        midasObjects.add(compICBMale);

        return compICBMale;

    }

    public void deleteCountry(long countryId) {
        checkTransaction();

        List list = midasSession.createCriteria(Country.class, "cntry")
                .add(Restrictions.eq("cntry.id", countryId))
                .list();

        if (list != null && list.size() > 0) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                Country country = (Country) iterator.next();
                midasSession.delete(country);
            }
            midasSession.flush();
        }
    }

    public BrProg createBrProg(String brProgRefId, String refActive, String cropName, String isMidasProgramFlag) {
        checkTransaction();

        BrProg brProg = new BrProg();
        brProg.setBrProgId(getId());
        brProg.setAcctId(getId());
        brProg.setMidasProgram("F");
        brProg.setBrProgRefId(brProgRefId);
        brProg.setName(brProgRefId);
        brProg.setCrop(getCrop(cropName));
        brProg.setRefActive(refActive);
        brProg.setMidasProgram(isMidasProgramFlag);

        midasSession.save(brProg);
        midasSession.flush();
        midasObjects.add(brProg);

        return brProg;

    }

    public GermplasmRoyalty createGermplasmRoyalty(Timestamp modifiedActiveTimeStamp, java.sql.Date inActiveTimeStamp, String royaltyInd, Germplasm germplasm) {
        checkTransaction();
        GermplasmRoyalty germplasmRoyalty = new GermplasmRoyalty();
        germplasmRoyalty.setGermplasmRoyaltyId(getId());
        germplasmRoyalty.setRoyaltyContractId(getId());
        germplasmRoyalty.setRoyaltyInd(new RoyaltyFlagEvaluator(royaltyInd).getValue());
        germplasmRoyalty.setGermplasm(germplasm);
        germplasmRoyalty.setModifiedDt(modifiedActiveTimeStamp);
        germplasmRoyalty.setInactiveDt(inActiveTimeStamp);
        midasSession.save(germplasmRoyalty);
        midasSession.flush();
        midasObjects.add(germplasmRoyalty);
        return germplasmRoyalty;
    }

    public String getNonMonsantoBrandName() {
        String sql = "select b.name from midas.brand b inner join midas.company c on b.company_id = c.company_id where b.ref_active = 'T' and c.name <> 'MONSANTO' AND c.ref_active = 'T' ORDER BY B.NAME ";
        List results = midasSession.createSQLQuery(sql).list();
        return (String) results.get(0);
    }

    public String getMonsantoBrandName() {
        String sql = "select b.name from midas.brand b inner join midas.company c on b.company_id = c.company_id where b.ref_active = 'T' and c.name = 'MONSANTO' AND c.ref_active = 'T' ORDER BY B.NAME ";
        List results = midasSession.createSQLQuery(sql).list();
        return (String) results.get(0);
    }

    public String getNonMonsantoCompanyName() {
        String sql = "select c.name from midas.brand b inner join midas.company c on b.company_id = c.company_id where b.ref_active = 'T' and c.name <> 'MONSANTO' AND c.ref_active = 'T' ORDER BY B.NAME ";
        List results = midasSession.createSQLQuery(sql).list();
        return (String) results.get(0);
    }

    public String getMonsantoCompanyName() {
        String sql = "select c.name from midas.brand b inner join midas.company c on b.company_id = c.company_id where b.ref_active = 'T' and c.name = 'MONSANTO' AND c.ref_active = 'T' ORDER BY B.NAME ";
        List results = midasSession.createSQLQuery(sql).list();
        return (String) results.get(0);
    }

    public String getPreCommercialProductName() {
        StringBuffer sql = new StringBuffer("select pn.name ");
        sql.append(" from midas.product_name pn ");
        sql.append(" inner join midas.product p on pn.product_id = p.product_id ");
        sql.append(" inner join midas.crop c on p.crop_id = c.crop_id ");
        sql.append(" inner join midas.brand b on pn.brand_id = b.brand_id ");
        sql.append(" inner join midas.company co on b.company_id = co.company_id ");
        sql.append(" where 1=1 and pn.REF_ACTIVE='T' and p.REF_ACTIVE='T' and lower(c.NAME)='corn' and c.REF_ACTIVE='T' ");
        sql.append(" and lower(b.NAME)='monsanto' and (lower(b.REF_ACTIVE)='t' or lower(b.REF_ACTIVE)='t') and lower(co.NAME)='monsanto'");
        sql.append(" and co.ref_active = 'T'");
        List results = midasSession.createSQLQuery(sql.toString()).list();
        return (String) results.get(0);
    }

    protected void defaultRequiredColumns(StagingInventory stagingInventory) {
        stagingInventory.setTransgenic(StringUtils.isNullOrEmpty(stagingInventory.getTransgenic()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getTransgenic());
        stagingInventory.setExposureHistoryKnown(StringUtils.isNullOrEmpty(stagingInventory.getExposureHistoryKnown()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getExposureHistoryKnown());        stagingInventory.setAllergensPresent(StringUtils.isNullOrEmpty(stagingInventory.getAllergensPresent()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getAllergensPresent());
        stagingInventory.setToxinsPresent(StringUtils.isNullOrEmpty(stagingInventory.getToxinsPresent()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getToxinsPresent());
        stagingInventory.setAnimalGenePresent(StringUtils.isNullOrEmpty(stagingInventory.getAnimalGenePresent()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getAnimalGenePresent());
        stagingInventory.setMiniChromosome(StringUtils.isNullOrEmpty(stagingInventory.getMiniChromosome()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getMiniChromosome());
        stagingInventory.setFromMfg(StringUtils.isNullOrEmpty(stagingInventory.getFromMfg()) ? DEFAULT_NOT_NULL_VALUE : stagingInventory.getFromMfg());
    }
}