/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Expression;

import java.math.BigDecimal;
import java.util.List;

/**
 * Filename:    $RCSfile: HibernateUtil_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ssnall $ On:	$Date: 2007/04/03 22:32:38 $
 *
 * @author SSPEYY
 * @version $Revision: 1.3 $
 */
public class HibernateUtil_UT extends TestIIContextConfigurer {

    public void testVerifyNonNullHibernateFactoryOnUtils() throws Exception {

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        assertNotNull(session);
        Transaction tx = session.getTransaction();
        assertNotNull(tx);
        session.close();
    }

    public void testCreateSessionAndTransaction() throws Exception {

        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        assertNotNull(session);
        session.beginTransaction();
        Long value = getValidGeneticMaterialId(session);
        List gms = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Expression.eq("gm.geneticMaterialId", value))
                .list();
        assertTrue(gms.size() > 0);
    }

    public Long getValidGeneticMaterialId(Session session) {
        String sql = "select genetic_material_id from midas.GENETIC_MATERIAL where rownum <= 10";
        List results = session.createSQLQuery(sql).list();
        return ((BigDecimal) results.get(0)).longValue();
    }
}