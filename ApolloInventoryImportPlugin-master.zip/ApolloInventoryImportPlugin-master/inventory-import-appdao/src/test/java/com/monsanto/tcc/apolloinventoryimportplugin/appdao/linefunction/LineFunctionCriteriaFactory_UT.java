/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: LineFunctionCriteriaFactory_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $ On:	$Date: 2008-02-17 22:58:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class LineFunctionCriteriaFactory_UT extends TestIIContextConfigurer {
    public void testReturnNullLineFunctionCriteraWhenLineFunctionIsNull() throws Exception {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(null);

        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();

        assertNotNull(lineFunctionCriteria);
        assertTrue(lineFunctionCriteria.getClass().getName().indexOf("NullLineFunctionCriteria") >= 0);
    }

    public void testReturnNonALineFunctionCriteraWhenLineFunctionIsNotNullAndNotA() throws Exception {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(LineFunctionConstants.B_LINE_FUNCTION);

        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();

        assertNotNull(lineFunctionCriteria);
        assertTrue(lineFunctionCriteria.getClass().getName().indexOf("NonALineFunctionCriteria") >= 0);
    }

    public void testReturnALineFunctionCriteraWhenLineFunctionIsA() throws Exception {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(LineFunctionConstants.A_LINE_FUNCTION);
        inventory.setCytoplasmDonorPedigree("PED");

        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();

        assertNotNull(lineFunctionCriteria);
        assertTrue(lineFunctionCriteria.getClass().getName().indexOf(".ALineFunctionCriteria") >= 0);
    }

    public void testReturnALineFunctionCriteraWithoutCytoplasmDonorWhenLineFunctionIsAAndCytoplasmDonorIsBlank() throws
            Exception {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(LineFunctionConstants.A_LINE_FUNCTION);
        inventory.setCytoplasmDonorPedigree("");

        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();

        assertNotNull(lineFunctionCriteria);
        assertTrue(lineFunctionCriteria.getClass().getName().indexOf(".ALineFunctionCriteriaWithoutCytoplasmDonor") >= 0);
    }

    public void testReturnALineFunctionCriteraWithoutCytoplasmDonorWhenLineFunctionIsAAndCytoplasmDonorIsNull() throws
            Exception {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(LineFunctionConstants.A_LINE_FUNCTION);
        inventory.setCytoplasmDonorPedigree(null);

        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(inventory).getLineFunctionCriteria();

        assertNotNull(lineFunctionCriteria);
        assertTrue(lineFunctionCriteria.getClass().getName().indexOf(".ALineFunctionCriteriaWithoutCytoplasmDonor") >= 0);
    }

    public void testStagingInventoryIsNull_ThrowsException() throws Exception {
        try {
            new LineFunctionCriteriaFactory(null).getLineFunctionCriteria();
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf("required") >= 0);
        }
    }
}