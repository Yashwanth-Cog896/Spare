package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: May 1, 2010
 * Time: 5:55:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropVegetativeStructure_UT {
    private static final Long CROP_ID = new Long(10);
    private static final Long CROP_VEGETATIVE_STRUCTURE_ID = new Long(-2000);
    private static final Long DEVELOPMENT_ORDER = new Long(2);
    private static final String REF_ACTIVE = "T";
    private static final Long VEGETATIVE_STRUCTURE_ID = new Long(-200);

    @Test
    public void testCropVegetativeStructure() {
        CropVegetativeStructure cropVegetativeStructure = new CropVegetativeStructure();
        Crop crop = new Crop();
        crop.setCropId(CROP_ID);
        cropVegetativeStructure.setCrop(crop);
        cropVegetativeStructure.setCropVegetativeStructureId(CROP_VEGETATIVE_STRUCTURE_ID);
        cropVegetativeStructure.setDevelopmentOrder(DEVELOPMENT_ORDER);
        cropVegetativeStructure.setRefActive(REF_ACTIVE);
        VegetativeStructure structure = new VegetativeStructure();
        structure.setVegetativeStructureId(VEGETATIVE_STRUCTURE_ID);
        cropVegetativeStructure.setVegetativeStructure(structure);
        assertEquals(CROP_ID, cropVegetativeStructure.getCrop().getCropId());
        assertEquals(CROP_VEGETATIVE_STRUCTURE_ID, cropVegetativeStructure.getCropVegetativeStructureId());
        assertEquals(DEVELOPMENT_ORDER, cropVegetativeStructure.getDevelopmentOrder());
        assertEquals(VEGETATIVE_STRUCTURE_ID, cropVegetativeStructure.getVegetativeStructure().getVegetativeStructureId());
    }
}
