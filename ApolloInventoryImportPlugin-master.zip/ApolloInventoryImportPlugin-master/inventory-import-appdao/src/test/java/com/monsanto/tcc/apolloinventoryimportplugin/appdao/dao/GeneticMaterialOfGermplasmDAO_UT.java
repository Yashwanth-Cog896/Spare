/*
 GeneticMaterialOfGermplasmDAO_UT was created on Feb 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Session;

/**
 * Filename:    $RCSfile: GeneticMaterialOfGermplasmDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $    	 On:	$Date: 2008-04-17 17:05:29 $
 *
 * @author SRKARNA
 * @version $Revision: 1.5 $
 */
public class GeneticMaterialOfGermplasmDAO_UT extends TestIIContextConfigurer {
    private Session session;
    private TestHelper testHelper;
    private Germplasm germplasm;
    private static final String EXISTING_SOURCE = "gm-of-gp-source";
    private static final String NON_EXISTING_SOURCE = "non-exist-source";

    public GeneticMaterialOfGermplasmDAO_UT(String name) {
        super(name);
    }

    protected void setUp() throws Exception {
        super.setUp();
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);

        germplasm = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GM-PICK1",
                "X1", "GM-PICK1", "17", "Corn");
        testHelper.createGeneticMaterial(germplasm, EXISTING_SOURCE, "|", "INBRED");

        Germplasm germplasm2 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "GM-PICK2",
                "X1", "GM-PICK2", "17", "Corn");
        testHelper.createGeneticMaterial(germplasm2, EXISTING_SOURCE, "|", "INBRED");

    }

    protected void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testGetGeneticMaterial_For_Existing_Source() throws Exception {
        GeneticMaterialOfGermplasmDAO dao = new GeneticMaterialOfGermplasmDAO(germplasm);
        GeneticMaterial geneticMaterial = dao.getGeneticMaterial(EXISTING_SOURCE);

        assertNotNull(geneticMaterial);
    }

    public void testGetGeneticMaterial_For_NonExisting_Source_Null() throws Exception {
        GeneticMaterialOfGermplasmDAO dao = new GeneticMaterialOfGermplasmDAO(germplasm);
        GeneticMaterial geneticMaterial = dao.getGeneticMaterial(NON_EXISTING_SOURCE);

        assertNull(geneticMaterial);
    }
}