package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GermplasmEventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: REHIGG
 * Date: Aug 2, 2010
 * Time: 1:38:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmEventConstruct_UT extends TestIIContextConfigurer {

    private GermplasmEventConstruct testObject;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        testObject = new GermplasmEventConstruct();
    }

    public void testGettersAndSetters() {
        Date absenceDate = new Date();
        EventConstruct event = new EventConstruct();
        event.setEventConstructId(-3L);
        Germplasm germplasm = new Germplasm();
        germplasm.setId(-4L);

        testObject.setGermplasm(germplasm);
        testObject.setAbsenceDate(absenceDate);
        testObject.setEventConstruct(event);
        testObject.setGermplasmEventConstructId(-5L);

        assertEquals(new Long(-5), testObject.getGermplasmEventConstructId());
        assertEquals(event, testObject.getEventConstruct());
        assertEquals(germplasm, testObject.getGermplasm());
        assertEquals(absenceDate, testObject.getAbsenceDate());
    }
}
