/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridGermplasmDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ddbrow5 $ On:	$Date: 2008-07-10 18:49:48 $
 *
 * @author skumar5
 * @version $Revision: 1.14 $
 */
public class HybridGermplasmDAO_UT extends TestIIContextConfigurer {
    private static final String LINE_TYPE = MaterialTypeConstants.HYBRID_LINES;
    private static final String CROP_NAME = "Corn";
    private static final String OWNER = "17";
    private static final String F1_GENERATION = "F1";
    private static final String LINEAGE = null;
    private static final String IS_NOT_DELETED = "F";
    private static final String IS_FINISHED = "T";
    private static final String NULL_CYTO_DONOR_PEDIGREE = null;
    private static final String S_LINE_FUNCTION = "S";
    private static final String NULL_LINE_FUNCTION = null;
    private TestHelper testHelper;

    public HybridGermplasmDAO_UT(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    public void tearDown() throws Exception {
        rollbackTransaction();
        super.tearDown();
    }

    public void testGetOriginMatchingSourceAndPedigreeLFForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source2";

        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(S_LINE_FUNCTION));
        String actualOrigin = dao.getOriginMatchingSourceAndPedigree(LINE_TYPE, expectedOrigin, source);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingSourceAndOriginLFForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source2";

        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(S_LINE_FUNCTION));
        String actualOrigin = dao.getOriginMatchingSourceAndOrigin(LINE_TYPE, expectedOrigin, source);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingSourceAndLineCodeLFForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source2";

        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(S_LINE_FUNCTION));
        String actualOrigin = dao.getOriginMatchingSourceAndLineCode(LINE_TYPE, lineCode, source);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingSourceAndPedigreeNullLFForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC2";
        String source = "Source1";

        Germplasm germplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria());
        String actualOrigin = dao.getOriginMatchingSourceAndPedigree(LINE_TYPE, pedigree, source);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingSourceAndOriginNullLFForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC2";
        String source = "Source1";

        Germplasm germplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria());
        String actualOrigin = dao.getOriginMatchingSourceAndOrigin(LINE_TYPE, expectedOrigin, source);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingSourceAndLineCodeNullLFForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC2";
        String source = "Source1";

        Germplasm germplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria());
        String actualOrigin = dao.getOriginMatchingSourceAndLineCode(LINE_TYPE, lineCode, source);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingPedigreeForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source2";

        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(S_LINE_FUNCTION));
        String actualOrigin = dao.getOriginMatchingPedigree(LINE_TYPE, pedigree);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingOriginForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source2";

        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(S_LINE_FUNCTION));
        String actualOrigin = dao.getOriginMatchingOrigin(LINE_TYPE, expectedOrigin);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingLineCodeForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source2";

        Germplasm germplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(S_LINE_FUNCTION));
        String actualOrigin = dao.getOriginMatchingLineCode(LINE_TYPE, lineCode);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingPedigreeNullLineFunctionForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source1";

        Germplasm germplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria());
        String actualOrigin = dao.getOriginMatchingPedigree(LINE_TYPE, pedigree);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingOriginNullLineFunctionForSuccess() throws Exception {
        String expectedOrigin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";
        String source = "Source1";

        Germplasm germplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria());
        String actualOrigin = dao.getOriginMatchingOrigin(LINE_TYPE, expectedOrigin);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetOriginMatchingLineCodeNullLineFunctionForSuccess() throws Exception {
        String expectedOrigin = "IIXYZ+IIABC";
        String pedigree = "IIXYZ+IIABC";
        String lineCode = "LC1";
        String source = "Source2";

        Germplasm germplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, expectedOrigin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria());
        String actualOrigin = dao.getOriginMatchingLineCode(LINE_TYPE, lineCode);
        assertNotNull(actualOrigin);
        assertEquals(expectedOrigin, actualOrigin);
    }

    public void testGetGermplasmForSuccessNoLineFunction() throws Exception {
        String origin = "XYZ";
        String pedigree = "XYZ";
        String lineCode = "ABC";

        testHelper.createGermplasm(LINE_TYPE, lineCode, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);

        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setLineType(LINE_TYPE);
        stagingInventory.setLineFunction(NULL_LINE_FUNCTION);
        stagingInventory.setInventoryHeader(header);
        HybridGermplasmDAO dao = new HybridGermplasmDAO(header.getCropName(), getLineFunctionCriteria(stagingInventory));
        List list = dao.getFinishedGermplasms(stagingInventory.getOrigin());
        assertNotNull(list);
        assertEquals(1, list.size());
    }

    public void testGetFinishedGermplasmExcludingLineFunctionForSuccess() throws Exception {
        String origin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode0 = "LC2";
        String lineCode1 = "LC3";

        testHelper.createGermplasm(LINE_TYPE, lineCode0, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGermplasm(LINE_TYPE, lineCode1, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED,
                IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);

        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setLineType(LINE_TYPE);
        stagingInventory.setInventoryHeader(header);
        HybridGermplasmDAO dao = new HybridGermplasmDAO(header.getCropName(), getLineFunctionCriteria(stagingInventory));
        List list = dao.getFinishedGermplasmsExcludingLineFunction(stagingInventory.getOrigin());
        assertNotNull(list);
        assertEquals(2, list.size());
    }


    public void testGetGermplasmMatchingOriginAndNullLineFunctionSuccess() throws Exception {
        String origin = "XYZ";
        String pedigree = "XYZ";
        String lineCode = "ABC";

        testHelper.createGermplasm(LINE_TYPE, lineCode, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);

        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setLineType(LINE_TYPE);
        stagingInventory.setLineFunction(NULL_LINE_FUNCTION);
        stagingInventory.setInventoryHeader(header);
        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(stagingInventory));
        List list = dao.getAllGermplasms_FinishedOrUnfinished(stagingInventory.getOrigin());
        assertNotNull(list);
        assertEquals(1, list.size());
    }

    public void testGetGermplasmForSuccessWithLineFunction() throws Exception {
        String origin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC3";

        testHelper.createGermplasm(LINE_TYPE, lineCode, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED,
                S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);

        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setLineType(LINE_TYPE);
        stagingInventory.setLineFunction(S_LINE_FUNCTION);
        stagingInventory.setInventoryHeader(header);
        HybridGermplasmDAO dao = new HybridGermplasmDAO(header.getCropName(), getLineFunctionCriteria(stagingInventory));
        List list = dao.getFinishedGermplasms(stagingInventory.getOrigin());
        assertNotNull(list);
        assertEquals(1, list.size());
    }

    public void testGetGermplasmForSuccessWithLineFunctionS() throws Exception {
        String origin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC2";

        testHelper.createGermplasm(LINE_TYPE, lineCode, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED,
                S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);

        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setLineType(LINE_TYPE);
        stagingInventory.setLineFunction(S_LINE_FUNCTION);
        stagingInventory.setInventoryHeader(header);
        HybridGermplasmDAO dao = new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(stagingInventory));
        List list = dao.getAllGermplasms_FinishedOrUnfinished(stagingInventory.getOrigin());
        assertNotNull(list);
        assertEquals(1, list.size());
    }

    public void testGetPrimaryGermplasm_FinishedHybridOriginExist_ForSuccess() throws Exception {
        String origin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC2";
        String source = "Source1";

        Germplasm expectedGermplasm = testHelper
                .createGermplasm(LINE_TYPE, lineCode, origin, pedigree, OWNER, CROP_NAME, IS_NOT_DELETED, IS_FINISHED);
        testHelper.createGeneticMaterial(expectedGermplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        assertEquals(expectedGermplasm.getId(),
                new HybridGermplasmDAO(CROP_NAME, getNullLineFunctionCriteria())
                        .getPrimaryGermplasm_FinishedHybridOriginExist(origin).getId());
    }

    public void testGetPrimaryGermplasm_FinishedHybridOriginExist_ForSuccessWithLineFunctionS() throws Exception {
        String origin = "IIABC+IIDEF";
        String pedigree = "IIABC+IIDEF";
        String lineCode = "LC2";
        String source = "Source1";

        Germplasm expectedGermplasm = testHelper.createGermplasm(LINE_TYPE, lineCode, origin, pedigree, OWNER, CROP_NAME,
                IS_NOT_DELETED, IS_FINISHED, S_LINE_FUNCTION, NULL_CYTO_DONOR_PEDIGREE);
        testHelper.createGeneticMaterial(expectedGermplasm, source.toUpperCase(), F1_GENERATION, LINEAGE);

        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setOrigin(origin);
        stagingInventory.setLineType(LINE_TYPE);
        stagingInventory.setLineFunction(S_LINE_FUNCTION);
        stagingInventory.setInventoryHeader(header);
        assertEquals(expectedGermplasm.getId(),
                new HybridGermplasmDAO(CROP_NAME, getLineFunctionCriteria(stagingInventory))
                        .getPrimaryGermplasm_FinishedHybridOriginExist(origin)
                        .getId());
    }

    private LineFunctionCriteria getNullLineFunctionCriteria() {
        return getLineFunctionCriteria((String) null);
    }

    private LineFunctionCriteria getLineFunctionCriteria(String lineFunctionRefId) {
        StagingInventory inventory = new StagingInventory();
        inventory.setLineFunction(lineFunctionRefId);
        return getLineFunctionCriteria(inventory);
    }

    private LineFunctionCriteria getLineFunctionCriteria(StagingInventory stagingInventory) {
        return new LineFunctionCriteriaFactory(stagingInventory).getLineFunctionCriteria();
    }

    private void rollbackTransaction() {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        if (session != null && session.isOpen()) {
            Transaction transaction = session.getTransaction();
            if (transaction != null && !transaction.wasCommitted() && !transaction.wasRolledBack()) {
                transaction.rollback();
            }
        }
    }
}