/*
 MockStagingInventoryData was created on Feb 14, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory.test;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;
import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportType;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryStatusConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.parentage.StagingParentage;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.*;

/**
 * Filename: $Id: MockStagingInventoryData.java,v 1.2 2009-07-16 21:47:50 ssnall Exp $
 *
 * @author APATRO
 * @version $Revision: 1.2 $
 * @noinspection OverlyLongMethod
 */
public class MockStagingInventoryData {
    public static final String NEW_STAGING_INVENTORY_XLS = "NewStagingInventory.xls";
    public static final String VALID_STAGING_INVENTORY_XLS = "ValidStagingInventory.xls";
    public static final String VALID_STAGING_INVENTORY_XLS_FOR_CODED = "ValidStagingInventoryForCoded.xls";
    public static final String PENDING_STAGING_INVENTORY_XLS = "PendingStagingInventory.xls";
    public static final String APPROVED_STAGING_INVENTORY_XLS = "ApprovedStagingInventory.xls";
    public static final String APPRVD_SI_ONE_USR_MULTI_CRPS_XLS = "ApprovedSIOneUserMultipleCrops.xls";
    public static final String APPROVED_SI_PARENTAGE_XLS = "ApprovedSIWithParentage.xls";
    public static final String PENDING_SI_PARENTAGE_XLS = "PendingSIWithParentage.xls";
    public static final String REJECTED_STAGING_INVENTORY_XLS = "RejectedStagingInventory.xls";
    public static final String TO_BE_APPROVED_STAGING_INVENTORY_XLS = "ToBeApprovedStagingInventory.xls";
    public static final String NEW_STAGING_INVENTORY_MULT_PARENTS_XLS = "NewStagingInventoryMultipleParents.xls";

    public MockStagingInventoryData() {
        this(true);
    }

    public MockStagingInventoryData(boolean doClean) {
        if (doClean) {
            clean();
        }
    }

    private ImportStatus getStatus(String status, Session session) {
        return (ImportStatus) session.createCriteria(ImportStatus.class)
                .add(Restrictions.eq("statusCode", status)).uniqueResult();
    }

    private ImportType getImportType(String importType, Session session) {
        return (ImportType) session.createCriteria(ImportType.class)
                .add(Restrictions.eq("abbreviation", importType)).uniqueResult();
    }

    public void createApprovedStagingInventory() {
        createApprovedStagingInventoryForUser("APATRO");
    }

    public void createApprovedStagingInventoryForUser(String userId) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Commercial", session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName("ApprovedStagingInventory.xls");
        invHeader.setUserId(userId);
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Approved", session));
        inventory1.setImportType(importType);
        inventory1.setProductName("DKC-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Approved", session));
        inventory2.setImportType(importType);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Approved", session));
        inventory3.setImportType(importType);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        Set set = new HashSet();
        set.add(inventory1);
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);

        session.saveOrUpdate(invHeader);

        session.flush();
    }

    public void createApprovedStagingInventoryOneUserManyCrops() {
        createApprovedStagingInventoryOneUserManyCropsForUserImportType("ABC", "Commercial");
    }

    public void createApprovedStagingInventoryOneUserManyCropsForUserImportType(String userId, String importType) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importTypeObj = getImportType(importType, session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(APPRVD_SI_ONE_USR_MULTI_CRPS_XLS);
        invHeader.setUserId(userId);
        invHeader.setImportType(importTypeObj);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Approved", session));
        inventory1.setImportType(importTypeObj);
        inventory1.setProductName("DKC-XYZ");
        inventory1.setSource("ABC");
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Approved", session));
        inventory2.setImportType(importTypeObj);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventoryHeader invHeader2 = new StagingInventoryHeader();
        invHeader2.setBatchDate(new Date());
        invHeader2.setCropName("SoyBeans");
        invHeader2.setTemplateName(APPRVD_SI_ONE_USR_MULTI_CRPS_XLS);
        invHeader2.setUserId(userId);
        invHeader2.setImportType(importTypeObj);

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader2);
        inventory3.setImportStatus(getStatus("Approved", session));
        inventory3.setImportType(importTypeObj);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        Set set = new HashSet();
        set.add(inventory1);
        set.add(inventory2);
        invHeader.setStagingInventory(set);

        Set set2 = new HashSet();
        set2.add(inventory3);
        invHeader2.setStagingInventory(set2);

        session.save(invHeader);
        session.save(invHeader2);
    }

    public void deleteStagingInventory(String templateName, Session session) {
        Query query = null;

        query = session.createQuery(
                "select rd from RunDetail rd, StagingInventory si, StagingInventoryHeader ih where ih.templateName = :templateName and si.inventoryHeader = ih and rd.inventoryId = si.id");
        query.setParameter("templateName", templateName);
        List runDetailsList = query.list();
        if (runDetailsList != null) {
            for (int i = 0; i < runDetailsList.size(); i++) {
                session.delete(runDetailsList.get(i));
            }
        }

        session.flush();

        query = session.createQuery(
                "select distinct si from StagingParentage sp, StagingInventory si, StagingInventoryHeader ih where ih.templateName = :templateName and si.inventoryHeader = ih and sp.mainInventory = si");
        query.setParameter("templateName", templateName);
        List stagingInventoryList = query.list();
        if (stagingInventoryList != null) {
            for (int i = 0; i < stagingInventoryList.size(); i++) {
                StagingInventory si = (StagingInventory) stagingInventoryList.get(i);
                session.delete(si);
            }
        }
        session.flush();

        query = session.createQuery(
                "select si from StagingInventory si, StagingInventoryHeader ih where ih.templateName = :templateName and si.inventoryHeader = ih");
        query.setParameter("templateName", templateName);
        stagingInventoryList = query.list();
        if (stagingInventoryList != null) {
            for (int i = 0; i < stagingInventoryList.size(); i++) {
                StagingInventory si = (StagingInventory) stagingInventoryList.get(i);
                session.delete(si);
            }
        }
        session.flush();

        List invHdrList = session.createCriteria(StagingInventoryHeader.class)
                .setFetchMode("stagingInventory", FetchMode.JOIN)
                .add(Restrictions.eq("templateName", templateName)).list();

        for (int i = 0; i < invHdrList.size(); i++) {
            StagingInventoryHeader invHdr = (StagingInventoryHeader) invHdrList.get(i);
            session.delete(invHdr);
        }

        session.flush();
    }


    public void createNewStagingInventory() {
        createNewStagingInventoryForUser("XYZ");
    }

    public void createNewStagingInventoryForUser(String userId) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Commercial", session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(NEW_STAGING_INVENTORY_XLS);
        invHeader.setUserId(userId);
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Imported", session));
        inventory1.setImportType(importType);
        inventory1.setProductName("DKC-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Imported", session));
        inventory2.setImportType(importType);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Imported", session));
        inventory3.setImportType(importType);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        Set set = new HashSet();
        set.add(inventory1);
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);

        session.saveOrUpdate(invHeader);
        session.flush();
    }

    public Long[] createValidStagingInventory() {
        return createValidStagingInventoryForUserImportType("XYZ", "Commercial");
    }

    public Long[] createValidStagingInventoryForUserImportType(String userId, String importType) {
        Long[] ids = new Long[3];

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importTypeObj = getImportType(importType, session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(VALID_STAGING_INVENTORY_XLS);
        invHeader.setUserId(userId);
        invHeader.setImportType(importTypeObj);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Valid", session));
        inventory1.setImportType(importTypeObj);
        inventory1.setProductName("DKC-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Valid", session));
        inventory2.setImportType(importTypeObj);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Valid", session));
        inventory3.setImportType(importTypeObj);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingParentage parentage1 = new StagingParentage();
        parentage1.setChildInventory(inventory2);
        parentage1.setMainInventory(inventory2);
        parentage1.setParentInventory(inventory3);
        parentage1.setParentalRole("F");
        parentage1.setRecordLevel(new Long(1));

        Set setp = new HashSet();
        setp.add(parentage1);
        inventory2.setStagingParentage(setp);

        //Save Sub Inventory Records
        Set set = new HashSet();
        set.add(inventory3);
        invHeader.setStagingInventory(set);
        session.save(invHeader);

        // Save Main Inventory record
        set = new HashSet();
        set.add(inventory1);
        set.add(inventory2);
        invHeader.setStagingInventory(set);
        session.saveOrUpdate(invHeader);

        session.flush();

        ids[0] = inventory1.getId();
        ids[1] = inventory2.getId();
        ids[2] = inventory3.getId();

        return ids;
    }

    public Long[] createValidCodedStagingInventory() {
        return createValidCodedStagingInventoryForUser("XYZ");
    }

    public Long[] createValidCodedStagingInventoryForUser(String userId) {
        Long[] ids = new Long[3];

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importTypeObj = getImportType(MaterialTypeConstants.CODED_LINES, session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(VALID_STAGING_INVENTORY_XLS_FOR_CODED);
        invHeader.setUserId(userId);
        invHeader.setImportType(importTypeObj);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Valid", session));
        inventory1.setImportType(importTypeObj);
        inventory1.setGermplasmOwner("17");
        inventory1.setLineCode("II-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setLineType(MaterialTypeConstants.CODED_LINES);
        inventory1.setVegetativeStructure("Seed");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Valid", session));
        inventory2.setImportType(importTypeObj);
        inventory2.setGermplasmOwner("17");
        inventory2.setLineCode("II-XYZ");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setLineType(MaterialTypeConstants.CODED_LINES);
        inventory2.setVegetativeStructure("Seed");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Valid", session));
        inventory3.setImportType(importTypeObj);
        inventory3.setGermplasmOwner("17");
        inventory3.setLineCode("II-XYZ");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setLineType(MaterialTypeConstants.CODED_LINES);
        inventory3.setVegetativeStructure("Seed");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingParentage parentage1 = new StagingParentage();
        parentage1.setChildInventory(inventory1);
        parentage1.setMainInventory(inventory1);
        parentage1.setParentInventory(inventory2);
        parentage1.setParentalRole("F");
        parentage1.setRecordLevel(new Long(1));

        StagingParentage parentage2 = new StagingParentage();
        parentage2.setChildInventory(inventory2);
        parentage2.setMainInventory(inventory1);
        parentage2.setParentInventory(inventory3);
        parentage2.setParentalRole("F");
        parentage2.setRecordLevel(new Long(2));

        Set setp = new HashSet();
        setp.add(parentage1);
        setp.add(parentage2);
        inventory1.setStagingParentage(setp);

        //Save Sub Inventory Records
        Set set = new HashSet();
        set.add(inventory3);
        set.add(inventory2);
        invHeader.setStagingInventory(set);
        session.save(invHeader);

        // Save Main Inventory record
        set = new HashSet();
        set.add(inventory1);
        invHeader.setStagingInventory(set);
        session.saveOrUpdate(invHeader);

        session.flush();

        ids[0] = inventory1.getId();
        ids[1] = inventory2.getId();
        ids[2] = inventory3.getId();

        return ids;
    }

    public Long[] createPendingStagingInventory() {
        return createPendingStagingInventoryForUser("XYZ");
    }

    public Long[] createPendingStagingInventoryForUser(String userId) {
        Long[] ids = new Long[3];
        Date approvalProcessDate = getDateAddToToday(1, 2, 3);
        Date approvalRequestDate = getDateAddToToday(4, 5, 6);
        Date creationDate = getDateAddToToday(7, 8, 9);
        Date validationDate = getDateAddToToday(-10, -10, -20);

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Commercial", session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(PENDING_STAGING_INVENTORY_XLS);
        invHeader.setUserId(userId);
        invHeader.setImportType(importType);

        session.saveOrUpdate(invHeader);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Pending", session));
        inventory1.setImportType(importType);
        inventory1.setProductName("DK569IMI");
        inventory1.setSource("Pending-Status-Record-#1-For-Testing");
        inventory1.setInventoryOwner("17");
        inventory1.setRejectionReason("improper pedigree");
        inventory1.setApprovalProcessDate(approvalProcessDate);
        inventory1.setApprovalRequestDate(approvalRequestDate);
        inventory1.setCreationDate(creationDate);
        inventory1.setValidationDate(validationDate);
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");
        ids[0] = (Long) session.save(inventory1);

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Pending", session));
        inventory2.setImportType(importType);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setSource("Pending-Status-Record-#2-For-Testing");
        inventory2.setInventoryOwner("17");
        inventory2.setRejectionReason("improper pedigree");
        inventory2.setApprovalProcessDate(approvalProcessDate);
        inventory2.setApprovalRequestDate(approvalRequestDate);
        inventory2.setCreationDate(creationDate);
        inventory2.setValidationDate(validationDate);
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");
        ids[1] = (Long) session.save(inventory2);

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Pending", session));
        inventory3.setImportType(importType);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setSource("Pending-Status-Record-#3-For-Testing");
        inventory3.setInventoryOwner("17");
        inventory3.setRejectionReason("improper pedigree");
        inventory3.setApprovalProcessDate(approvalProcessDate);
        inventory3.setApprovalRequestDate(approvalRequestDate);
        inventory3.setCreationDate(creationDate);
        inventory3.setValidationDate(validationDate);
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");
        ids[2] = (Long) session.save(inventory3);

        return ids;
    }

    public StagingInventory[] createPendingStagingInventoryWithParentage() {
        StagingInventory[] stagingInventories = new StagingInventory[3];

        Date approvalProcessDate = getDateAddToToday(-5, 0, 0);
        Date approvalRequestDate = getDateAddToToday(5, 0, 0);
        Date creationDate = getDateAddToToday(0, 0, 0);
        Date validationDate = getDateAddToToday(20, 5, 10);

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Segpop", session);
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(PENDING_SI_PARENTAGE_XLS);
        invHeader.setUserId("XYZ");
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Pending", session));
        inventory1.setAuthorityRequested("Antwerp");
        inventory1.setImportType(importType);
        inventory1.setProductName("DK569IMI");
        inventory1.setSource("Pending-Status-Record-#1-For-Testing");
        inventory1.setApprovalProcessDate(approvalProcessDate);
        inventory1.setApprovalRequestDate(approvalRequestDate);
        inventory1.setCreationDate(creationDate);
        inventory1.setValidationDate(validationDate);
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Pending", session));
        inventory2.setAuthorityRequested("Antwerp");
        inventory2.setImportType(importType);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setApprovalProcessDate(approvalProcessDate);
        inventory2.setApprovalRequestDate(approvalRequestDate);
        inventory2.setCreationDate(creationDate);
        inventory2.setValidationDate(validationDate);
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Pending", session));
        inventory3.setAuthorityRequested("Antwerp");
        inventory3.setImportType(importType);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setApprovalProcessDate(approvalProcessDate);
        inventory3.setApprovalRequestDate(approvalRequestDate);
        inventory3.setCreationDate(creationDate);
        inventory3.setValidationDate(validationDate);
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingParentage parentage1 = new StagingParentage();
        parentage1.setChildInventory(inventory1);
        parentage1.setMainInventory(inventory1);
        parentage1.setParentInventory(inventory2);
        parentage1.setParentalRole("F");
        parentage1.setRecordLevel(new Long(1));

        StagingParentage parentage2 = new StagingParentage();
        parentage2.setChildInventory(inventory2);
        parentage2.setMainInventory(inventory1);
        parentage2.setParentInventory(inventory3);
        parentage2.setParentalRole("F");
        parentage2.setRecordLevel(new Long(2));

        Set setp = new HashSet();
        setp.add(parentage1);
        setp.add(parentage2);
        inventory1.setStagingParentage(setp);

        //Save Sub Inventory Records
        Set set = new HashSet();
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);
        session.save(invHeader);

        // Save Main Inventory record
        set = new HashSet();
        set.add(inventory1);
        invHeader.setStagingInventory(set);
        session.saveOrUpdate(invHeader);
        stagingInventories[0] = inventory1;
        stagingInventories[1] = inventory2;
        stagingInventories[2] = inventory3;
        return stagingInventories;
    }

    public void createApprovedStagingInventoryWithParentage() {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Segpop", session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(APPROVED_SI_PARENTAGE_XLS);
        invHeader.setUserId("APATRO");
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Approved", session));
        inventory1.setImportType(importType);
        inventory1.setProductName("DKC-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Approved", session));
        inventory2.setImportType(importType);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Approved", session));
        inventory3.setImportType(importType);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingParentage parentage1 = new StagingParentage();
        parentage1.setChildInventory(inventory1);
        parentage1.setMainInventory(inventory1);
        parentage1.setParentInventory(inventory2);
        parentage1.setParentalRole("F");
        parentage1.setRecordLevel(new Long(1));

        StagingParentage parentage2 = new StagingParentage();
        parentage2.setChildInventory(inventory2);
        parentage2.setMainInventory(inventory1);
        parentage2.setParentInventory(inventory3);
        parentage2.setParentalRole("F");
        parentage2.setRecordLevel(new Long(2));

        Set setp = new HashSet();
        setp.add(parentage1);
        setp.add(parentage2);
        inventory1.setStagingParentage(setp);

        //Save SubInventory records
        Set set = new HashSet();
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);
        session.save(invHeader);

        //Save Main Inventory
        set = new HashSet();
        set.add(inventory1);
        invHeader.setStagingInventory(set);
        session.saveOrUpdate(invHeader);
    }

    public void createToBeApprovedStagingInventoryForUser(String authorityRequested, String userId1, String userId2) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Commercial", session);
        ImportType importType2 = getImportType("Segpop", session);
        ImportStatus importStatus = getStatus(StagingInventoryStatusConstants.PENDING, session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(TO_BE_APPROVED_STAGING_INVENTORY_XLS);
        invHeader.setUserId(userId1);
        invHeader.setImportType(importType);

        StagingInventoryHeader invHeader2 = new StagingInventoryHeader();
        invHeader2.setBatchDate(new Date());
        invHeader2.setCropName("Tomato");
        invHeader2.setTemplateName(TO_BE_APPROVED_STAGING_INVENTORY_XLS);
        invHeader2.setUserId(userId2);
        invHeader2.setImportType(importType2);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(importStatus);
        inventory1.setImportType(importType);
        inventory1.setProductName("DKC-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setAuthorityRequested(authorityRequested);
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(importStatus);
        inventory2.setImportType(importType);
        inventory2.setProductName("DKC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setAuthorityRequested(authorityRequested);
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(importStatus);
        inventory3.setImportType(importType);
        inventory3.setProductName("DKC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setAuthorityRequested(authorityRequested);
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        Set set = new HashSet();
        set.add(inventory1);
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);

        StagingInventory inventory4 = new StagingInventory();
        inventory4.setInventoryHeader(invHeader2);
        inventory4.setImportStatus(importStatus);
        inventory4.setImportType(importType2);
        inventory4.setProductName("DAT-UTIL");
        inventory4.setSource("DAT");
        inventory4.setInventoryOwner("06");
        inventory4.setAuthorityRequested(authorityRequested);
        inventory4.setTransgenic("F");
        inventory4.setExposureHistoryKnown("F");
        inventory4.setAllergensPresent("F");
        inventory4.setToxinsPresent("F");
        inventory4.setAnimalGenePresent("F");
        inventory4.setMiniChromosome("F");
        inventory4.setFromMfg("F");

        StagingInventory inventory5 = new StagingInventory();
        inventory5.setInventoryHeader(invHeader2);
        inventory5.setImportStatus(importStatus);
        inventory5.setImportType(importType2);
        inventory5.setProductName("UTIL-DAT");
        inventory5.setSource("UTIL");
        inventory5.setInventoryOwner("06");
        inventory5.setAuthorityRequested(authorityRequested);
        inventory5.setTransgenic("F");
        inventory5.setExposureHistoryKnown("F");
        inventory5.setAllergensPresent("F");
        inventory5.setToxinsPresent("F");
        inventory5.setAnimalGenePresent("F");
        inventory5.setMiniChromosome("F");
        inventory5.setFromMfg("F");

        Set set2 = new HashSet();
        set2.add(inventory4);
        set2.add(inventory5);
        invHeader2.setStagingInventory(set2);

        session.saveOrUpdate(invHeader);
        session.saveOrUpdate(invHeader2);

        session.flush();
    }


    public void createRejectedStagingInventory() {
        createRejectedStagingInventoryForUser("XYZ");
    }

    public void createRejectedStagingInventoryForUser(String userId) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Commercial", session);

        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(REJECTED_STAGING_INVENTORY_XLS);
        invHeader.setUserId(userId);
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("Rejected", session));
        inventory1.setImportType(importType);
        inventory1.setProductName("ABC-XYZ");
        inventory1.setSource("XYZ");
        inventory1.setInventoryOwner("17");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("Rejected", session));
        inventory2.setImportType(importType);
        inventory2.setProductName("ABC-ABC");
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("Rejected", session));
        inventory3.setImportType(importType);
        inventory3.setProductName("ABC-123");
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingInventory inventory4 = new StagingInventory();
        inventory4.setInventoryHeader(invHeader);
        inventory4.setImportStatus(getStatus("Rejected", session));
        inventory4.setImportType(importType);
        inventory4.setProductName("ABC-PDQ");
        inventory4.setSource("PDQ");
        inventory4.setInventoryOwner("17");
        inventory4.setTransgenic("F");
        inventory4.setExposureHistoryKnown("F");
        inventory4.setAllergensPresent("F");
        inventory4.setToxinsPresent("F");
        inventory4.setAnimalGenePresent("F");
        inventory4.setMiniChromosome("F");
        inventory4.setFromMfg("F");

        StagingInventory inventory5 = new StagingInventory();
        inventory5.setInventoryHeader(invHeader);
        inventory5.setImportStatus(getStatus("Rejected", session));
        inventory5.setImportType(importType);
        inventory5.setProductName("ABC-PDQ");
        inventory5.setSource("PDQ");
        inventory5.setInventoryOwner("17");
        inventory5.setTransgenic("F");
        inventory5.setExposureHistoryKnown("F");
        inventory5.setAllergensPresent("F");
        inventory5.setToxinsPresent("F");
        inventory5.setAnimalGenePresent("F");
        inventory5.setMiniChromosome("F");
        inventory5.setFromMfg("F");

        Set set = new HashSet();
        set.add(inventory1);
        set.add(inventory2);
        set.add(inventory3);
        set.add(inventory4);
        set.add(inventory5);
        invHeader.setStagingInventory(set);

        session.save(invHeader);
    }

    public void clean() {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory()
                .openSession(); // This is okay as this should be done in a separate session
        session.beginTransaction();
        try {
            this.deleteStagingInventory(APPROVED_STAGING_INVENTORY_XLS, session);
        } catch (Exception e) {
        }
        try {
            this.deleteStagingInventory(PENDING_STAGING_INVENTORY_XLS, session);
        } catch (Exception e) {
        }
        try {
            this.deleteStagingInventory(APPROVED_SI_PARENTAGE_XLS, session);
        } catch (Exception e) {
        }
        try {
            this.deleteStagingInventory(PENDING_SI_PARENTAGE_XLS, session);
        } catch (Exception e) {
        }
        try {
            this.deleteStagingInventory(APPRVD_SI_ONE_USR_MULTI_CRPS_XLS, session);
        } catch (Exception e) {
        }
        try {
            this.deleteStagingInventory(TO_BE_APPROVED_STAGING_INVENTORY_XLS, session);
        } catch (Exception e) {
        }
        try {
            this.deleteStagingInventory(VALID_STAGING_INVENTORY_XLS, session);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            this.deleteStagingInventory(NEW_STAGING_INVENTORY_XLS, session);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            this.deleteStagingInventory(NEW_STAGING_INVENTORY_MULT_PARENTS_XLS, session);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            this.deleteStagingInventory(VALID_STAGING_INVENTORY_XLS_FOR_CODED, session);
        } catch (Exception e) {
            e.printStackTrace();
        }

        session.getTransaction().commit();
        session.close();
    }

    private Date getDateAddToToday(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.YEAR, year);
        calendar.add(Calendar.MONTH, month);
        calendar.add(Calendar.DATE, day);
        return calendar.getTime();
    }

    public StagingInventory[] createNewStagingInventoryWithParentage() {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType("Segpop", session);
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(PENDING_SI_PARENTAGE_XLS);
        invHeader.setUserId("XYZ");
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus("New", session));
        inventory1.setImportType(importType);
        inventory1.setSource("New-Status-Record-#1-For-Testing");
        inventory1.setCreationDate(new Date());
        inventory1.setInventoryOwner("17");
        inventory1.setGermplasmOwner("17");
        inventory1.setOrigin("A/B");
        inventory1.setLineage("@.1.");
        inventory1.setGeneration("F3");
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus("New", session));
        inventory2.setImportType(importType);
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setGermplasmOwner("17");
        inventory2.setCreationDate(new Date());
        inventory2.setOrigin("A/B");
        inventory2.setLineage("@.");
        inventory2.setGeneration("F2");
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("New", session));
        inventory3.setImportType(importType);
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setGermplasmOwner("17");
        inventory3.setCreationDate(new Date());
        inventory3.setOrigin("A/B");
        inventory3.setLineage(null);
        inventory3.setGeneration("F1");
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingParentage parentage1 = new StagingParentage();
        parentage1.setChildInventory(inventory1);
        parentage1.setMainInventory(inventory1);
        parentage1.setParentInventory(inventory2);
        parentage1.setParentalRole("F");
        parentage1.setRecordLevel(new Long(1));

        StagingParentage parentage2 = new StagingParentage();
        parentage2.setChildInventory(inventory2);
        parentage2.setMainInventory(inventory1);
        parentage2.setParentInventory(inventory3);
        parentage2.setParentalRole("F");
        parentage2.setRecordLevel(new Long(2));

        Set setp = new HashSet();
        setp.add(parentage1);
        setp.add(parentage2);
        inventory1.setStagingParentage(setp);

        //Save Sub Inventory Records
        Set set = new HashSet();
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);
        session.save(invHeader);

        // Save Main Inventory record
        set = new HashSet();
        set.add(inventory1);
        invHeader.setStagingInventory(set);
        session.saveOrUpdate(invHeader);
        return new StagingInventory[]{inventory1, inventory2, inventory3};
    }

    public StagingInventory[] createNewStagingInventoryWithMoreThanTwoParents() {
        return createNewStagingInventoryWithMoreThanTwoParentsByUser("XYZ");
    }

    public StagingInventory[] createNewStagingInventoryWithMoreThanTwoParentsByUser(String userId) {
        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        ImportType importType = getImportType(MaterialTypeConstants.SEGPOP_LINES, session);
        StagingInventoryHeader invHeader = new StagingInventoryHeader();
        invHeader.setBatchDate(new Date());
        invHeader.setCropName("Corn");
        invHeader.setTemplateName(NEW_STAGING_INVENTORY_MULT_PARENTS_XLS);
        invHeader.setUserId(userId);
        invHeader.setImportType(importType);

        StagingInventory inventory1 = new StagingInventory();
        inventory1.setInventoryHeader(invHeader);
        inventory1.setImportStatus(getStatus(StagingInventoryStatusConstants.NEW, session));
        inventory1.setImportType(getImportType(MaterialTypeConstants.SEGPOP_LINES, session));
        inventory1.setSource("New-Status-Record-With-Multiple-Parents-#1-For-Testing");
        inventory1.setCreationDate(new Date());
        inventory1.setInventoryOwner("17");
        inventory1.setGermplasmOwner("17");
        inventory1.setOrigin("A/B");
        inventory1.setGeneration("F1");
        inventory1.setLineType(MaterialTypeConstants.SEGPOP_LINES);
        inventory1.setTransgenic("F");
        inventory1.setExposureHistoryKnown("F");
        
        inventory1.setAllergensPresent("F");
        inventory1.setToxinsPresent("F");
        inventory1.setAnimalGenePresent("F");
        inventory1.setMiniChromosome("F");
        inventory1.setFromMfg("F");

        StagingInventory inventory2 = new StagingInventory();
        inventory2.setInventoryHeader(invHeader);
        inventory2.setImportStatus(getStatus(StagingInventoryStatusConstants.NEW, session));
        inventory2.setImportType(getImportType(MaterialTypeConstants.SEGPOP_LINES, session));
        inventory2.setSource("ABC");
        inventory2.setInventoryOwner("17");
        inventory2.setGermplasmOwner("17");
        inventory2.setCreationDate(new Date());
        inventory2.setLineCode("A");
        inventory2.setLineage("|");
        inventory2.setGeneration("INBRED");
        inventory2.setLineType(MaterialTypeConstants.FINISHED_LINES);
        inventory2.setTransgenic("F");
        inventory2.setExposureHistoryKnown("F");
        
        inventory2.setAllergensPresent("F");
        inventory2.setToxinsPresent("F");
        inventory2.setAnimalGenePresent("F");
        inventory2.setMiniChromosome("F");
        inventory2.setFromMfg("F");

        StagingInventory inventory3 = new StagingInventory();
        inventory3.setInventoryHeader(invHeader);
        inventory3.setImportStatus(getStatus("New", session));
        inventory3.setImportType(getImportType(MaterialTypeConstants.SEGPOP_LINES, session));
        inventory3.setSource("123");
        inventory3.setInventoryOwner("17");
        inventory3.setGermplasmOwner("17");
        inventory3.setCreationDate(new Date());
        inventory3.setLineCode("B");
        inventory3.setLineage("|");
        inventory3.setGeneration("INBRED");
        inventory3.setLineType(MaterialTypeConstants.FINISHED_LINES);
        inventory3.setTransgenic("F");
        inventory3.setExposureHistoryKnown("F");
        
        inventory3.setAllergensPresent("F");
        inventory3.setToxinsPresent("F");
        inventory3.setAnimalGenePresent("F");
        inventory3.setMiniChromosome("F");
        inventory3.setFromMfg("F");

        StagingParentage parentage1 = new StagingParentage();
        parentage1.setChildInventory(inventory1);
        parentage1.setMainInventory(inventory1);
        parentage1.setParentInventory(inventory2);
        parentage1.setParentalRole("F");
        parentage1.setRecordLevel(new Long(1));

        StagingParentage parentage2 = new StagingParentage();
        parentage2.setChildInventory(inventory1);
        parentage2.setMainInventory(inventory1);
        parentage2.setParentInventory(inventory3);
        parentage2.setParentalRole("F");
        parentage2.setRecordLevel(new Long(2));

        Set setp = new HashSet();
        setp.add(parentage1);
        setp.add(parentage2);
        inventory1.setStagingParentage(setp);

        //Save Sub Inventory Records
        Set set = new HashSet();
        set.add(inventory2);
        set.add(inventory3);
        invHeader.setStagingInventory(set);
        session.save(invHeader);

        // Save Main Inventory record
        set = new HashSet();
        set.add(inventory1);
        invHeader.setStagingInventory(set);
        session.saveOrUpdate(invHeader);
        return new StagingInventory[]{inventory1, inventory2, inventory3};
    }
}