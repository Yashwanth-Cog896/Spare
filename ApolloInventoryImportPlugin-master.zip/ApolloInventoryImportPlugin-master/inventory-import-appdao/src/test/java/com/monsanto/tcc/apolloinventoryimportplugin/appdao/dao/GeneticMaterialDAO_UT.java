/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.GermplasmListFetchStrategyFinished;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestHelper;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: GeneticMaterialDAO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: ddbrow5 $ On:	$Date: 2008-06-04 19:03:25 $
 *
 * @author skumar5
 * @version $Revision: 1.8 $
 * @noinspection RefusedBequest
 */
public class GeneticMaterialDAO_UT extends TestIIContextConfigurer {
    private static final String CROP_NAME = "Corn";
    private static final String FINISHED_ORIGIN = "II-A3910X/TJ2046ASDSA";
    private static final String FINISHED_LINE_CODE = "II-FINISHED-LCZZ";
    private static final String PEDIGREE_ALL_CAP = FINISHED_LINE_CODE;
    private static final String FINISHED_BR_PROG_REF_ID = "17";
    private static final String FINISHED_SOURCE = "II-FINISHED-SOURCE-ZXZ";
    private Session session;
    private TestHelper testHelper;

    private Germplasm germplasm1;
    private Germplasm germplasm2;
    private Germplasm germplasm3;
    private Germplasm germplasm4;
    private Germplasm germplasm5;

    public void setUp() throws Exception {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        session.beginTransaction();
        testHelper = new TestHelper(session);
    }

    public void tearDown() throws Exception {
        session.getTransaction().rollback();
        super.tearDown();
    }

    public void testConstructorThrowsExceptionWhenCropNameIsNull() {
        try {
            new GeneticMaterialDAO(null, new NullLineFunctionCriteria());
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(GeneticMaterialDAO.CROP_NAME_CRITERIA_REQ_MSG) >= 0);
        }
    }

    public void testConstructorThrowsExceptionWhenLineFunctionCriteriaIsNull() {
        try {
            LineFunctionCriteria lineFunctionCriteria = null;
            new GeneticMaterialDAO("Corn", lineFunctionCriteria);
            fail("Expecting IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().indexOf(GeneticMaterialDAO.CROP_NAME_CRITERIA_REQ_MSG) >= 0);
        }
    }

    public void testGetMatchingSourceAndPedigreeSuccess() throws Exception {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(header);
        stagingInventory.setSource(FINISHED_SOURCE);
        stagingInventory.setPedigreeName(PEDIGREE_ALL_CAP);

        Germplasm gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME);
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(gp, FINISHED_SOURCE, "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.R_LINE_FUNCTION);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE, "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.B_LINE_FUNCTION);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE, "|", "INBRED");

        List geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null)).getGeneticMaterial(
                stagingInventory.getPedigreeName(), stagingInventory.getSource());

        assertNotNull(geneticMaterial);
        assertEquals(1, geneticMaterial.size());
        assertEquals(matchingGm, geneticMaterial.get(0));
    }

    public void testGetMatchingSourceAndPedigreeSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(header);
        stagingInventory.setSource(FINISHED_SOURCE.toLowerCase());
        stagingInventory.setPedigreeName(PEDIGREE_ALL_CAP);

        Germplasm gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME);
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(gp, FINISHED_SOURCE.toUpperCase(), "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.R_LINE_FUNCTION);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE.toUpperCase(), "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.B_LINE_FUNCTION);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE.toUpperCase(), "|", "INBRED");

        List geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null)).getGeneticMaterial(
                stagingInventory.getPedigreeName(), stagingInventory.getSource());

        assertNotNull(geneticMaterial);
        assertEquals(1, geneticMaterial.size());
        assertEquals(matchingGm, geneticMaterial.get(0));
    }

    public void testGetMatchingSourceAndPedigreeSuccessWithLineFunction() throws Exception {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(header);
        stagingInventory.setSource(FINISHED_SOURCE);
        stagingInventory.setPedigreeName(PEDIGREE_ALL_CAP);
        stagingInventory.setLineFunction(LineFunctionConstants.R_LINE_FUNCTION);

        Germplasm gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE, "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.R_LINE_FUNCTION);
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(gp, FINISHED_SOURCE, "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.B_LINE_FUNCTION);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE, "|", "INBRED");

        List geneticMaterial = new GeneticMaterialDAO(CROP_NAME,
                getLineFunctionCriteria(LineFunctionConstants.R_LINE_FUNCTION, null)).getGeneticMaterial(
                stagingInventory.getPedigreeName(), stagingInventory.getSource());

        assertNotNull(geneticMaterial);
        assertEquals(1, geneticMaterial.size());
        assertEquals(matchingGm, geneticMaterial.get(0));
    }

    public void testGetMatchingSourceAndPedigreeSuccessWithLineFunction_SourceSearchIsCaseInsensitive() throws Exception {
        StagingInventoryHeader header = new StagingInventoryHeader();
        header.setCropName(CROP_NAME);
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(header);
        stagingInventory.setSource(FINISHED_SOURCE.toLowerCase());
        stagingInventory.setPedigreeName(PEDIGREE_ALL_CAP);
        stagingInventory.setLineFunction(LineFunctionConstants.R_LINE_FUNCTION);

        Germplasm gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE.toUpperCase(), "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.R_LINE_FUNCTION);
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(gp, FINISHED_SOURCE.toUpperCase(), "|", "INBRED");

        gp = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, FINISHED_LINE_CODE, FINISHED_ORIGIN,
                PEDIGREE_ALL_CAP, FINISHED_BR_PROG_REF_ID, CROP_NAME, LineFunctionConstants.B_LINE_FUNCTION);
        testHelper.createGeneticMaterial(gp, FINISHED_SOURCE.toUpperCase(), "|", "INBRED");

        List geneticMaterial = new GeneticMaterialDAO(CROP_NAME,
                getLineFunctionCriteria(LineFunctionConstants.R_LINE_FUNCTION, null)).getGeneticMaterial(
                stagingInventory.getPedigreeName(), stagingInventory.getSource());

        assertNotNull(geneticMaterial);
        assertEquals(1, geneticMaterial.size());
        assertEquals(matchingGm, geneticMaterial.get(0));
    }

    public void testGetGeneticMaterialWithoutLineTypeWithNullLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getGeneticMaterial(pedigree, source);
        assertNotNull(geneticMaterialList);
        assertEquals(matchingGm, geneticMaterialList.get(0));
    }

    public void testGetGeneticMaterialWithoutLineTypeWithNullLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getGeneticMaterial(pedigree, source.toLowerCase());
        assertNotNull(geneticMaterialList);
        assertEquals(matchingGm, geneticMaterialList.get(0));
    }

    public void testGetGeneticMaterialWithNullLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetGeneticMaterialWithNullLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getGeneticMaterial(pedigree, source.toLowerCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetFinishedGeneticMaterialWithNullLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "T", null,
                        null);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getFinishedGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetFinishedGeneticMaterialWithNullLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "T", null,
                        null);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getFinishedGeneticMaterial(pedigree, source.toLowerCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetUnfinishedGeneticMaterialWithNullLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "F", null,
                        null);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getUnfinishedGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetUnfinishedGeneticMaterialWithNullLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "F", null,
                        null);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getUnfinishedGeneticMaterial(pedigree, source.toLowerCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetGeneticMaterialWithBlankLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        String lineFunction = "";
        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetGeneticMaterialWithBlankLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        String lineFunction = "";
        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source.toLowerCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }


    public void testGetFinishedGeneticMaterialWithBlankLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "T", null,
                        null);

        Germplasm germplasm2 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "F", null,
                        null);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);
        testHelper.createGeneticMaterial(germplasm2, source, generation, lineage);

        String lineFunction = "";
        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getFinishedGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetFinishedGeneticMaterialWithBlankLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm finishedGermplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "T", null,
                        null);

        Germplasm unfinishedGermplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "F", null,
                        null);

        String source = "SOME SOUCE " + finishedGermplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper
                .createGeneticMaterial(finishedGermplasm, source.toUpperCase(), generation, lineage);
        testHelper.createGeneticMaterial(unfinishedGermplasm, source.toUpperCase(), generation, lineage);

        String lineFunction = "";
        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getFinishedGeneticMaterial(pedigree, source.toLowerCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetUnfinishedGeneticMaterialWithBlankLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "F", null,
                        null);

        Germplasm germplasm2 = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "T", null,
                        null);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);
        testHelper.createGeneticMaterial(germplasm2, source, generation, lineage);

        String lineFunction = "";
        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getUnfinishedGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetUnfinishedGeneticMaterialWithBlankLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm finishedGermplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "F", null,
                        null);

        Germplasm unfinishedGermplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "F", "T", null,
                        null);

        String source = "SOME SOUCE " + finishedGermplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper
                .createGeneticMaterial(finishedGermplasm, source.toUpperCase(), generation, lineage);
        testHelper.createGeneticMaterial(unfinishedGermplasm, source.toUpperCase(), generation, lineage);

        String lineFunction = "";
        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getUnfinishedGeneticMaterial(pedigree, source.toLowerCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    private LineFunctionCriteria getLineFunctionCriteria(String lineFunction, String cytoplasmDonorPedigree) {
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setLineFunction(lineFunction);
        stagingInventory.setCytoplasmDonorPedigree(cytoplasmDonorPedigree);
        return new LineFunctionCriteriaFactory(stagingInventory).getLineFunctionCriteria();
    }

    public void testGetGeneticMaterialWithoutLineTypeWithBlankLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        String lineFunction = "";
        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source);
        assertNotNull(geneticMaterialList);
        assertEquals(matchingGm, geneticMaterialList.get(0));
    }

    public void testGetGeneticMaterialWithoutLineTypeWithBlankLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toLowerCase(), generation, lineage);

        String lineFunction = "";
        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source.toUpperCase());
        assertNotNull(geneticMaterialList);
        assertEquals(matchingGm, geneticMaterialList.get(0));
    }

    public void testGetGeneticMaterialWithLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;
        String lineFunction = "B";

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, lineFunction);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source, MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetGeneticMaterialWithLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;
        String lineFunction = "B";

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, lineFunction);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toLowerCase(), generation, lineage);

        GeneticMaterial geneticMaterial = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source.toUpperCase(), MaterialTypeConstants.SEGPOP_LINES);
        assertNotNull(geneticMaterial);
        assertEquals(matchingGm, geneticMaterial);
    }

    public void testGetGeneticMaterialWithoutLineTypeWithLineFunctionSuccess() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;
        String lineFunction = "B";

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, lineFunction);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source, generation, lineage);

        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source);
        assertNotNull(geneticMaterialList);
        assertEquals(matchingGm, geneticMaterialList.get(0));
    }

    public void testGetGeneticMaterialWithoutLineTypeWithLineFunctionSuccess_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;
        String lineFunction = "B";

        Germplasm germplasm = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, lineFunction);

        String source = "SOME SOUCE " + germplasm.getId() + " " + pedigree;
        GeneticMaterial matchingGm = testHelper.createGeneticMaterial(germplasm, source.toUpperCase(), generation, lineage);

        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(lineFunction, null))
                .getGeneticMaterial(pedigree, source.toLowerCase());
        assertNotNull(geneticMaterialList);
        assertEquals(matchingGm, geneticMaterialList.get(0));
    }

    public void testGetGeneticMaterialMatchingPedigreeAndSourceNotLineFunction() throws Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasmNullLineFunction = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, null);

        Germplasm germplasmNotNullLineFunction = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "B");

        String source = "SOME SOUCE " + germplasmNullLineFunction.getId() + " " + pedigree;
        GeneticMaterial matchingGmNullLineFunction = testHelper
                .createGeneticMaterial(germplasmNullLineFunction, source, generation, lineage);
        GeneticMaterial matchingGmNotNullLineFunction = testHelper
                .createGeneticMaterial(germplasmNotNullLineFunction, source, generation, lineage);

        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getGeneticMaterialMatchingPedigreeAndSourceNotLineFunction(pedigree, source);
        assertNotNull(geneticMaterialList);
        assertEquals(2, geneticMaterialList.size());
        assertContainsGM(geneticMaterialList, matchingGmNullLineFunction);
        assertContainsGM(geneticMaterialList, matchingGmNotNullLineFunction);
    }

    public void testGetGeneticMaterialMatchingPedigreeAndSourceNotLineFunction_SourceSearchIsCaseInsensitive() throws
            Exception {
        String origin = "ABDEF/ASDSA";
        String gpOwner = "17";
        String generation = "F4";
        String lineage = "@.1.2.";
        String pedigree = gpOwner + "_" + origin + ":" + lineage;

        Germplasm germplasmNullLineFunction = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, null);

        Germplasm germplasmNotNullLineFunction = testHelper
                .createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null, origin, pedigree, gpOwner, CROP_NAME, "B");

        String source = "SOME SOUCE " + germplasmNullLineFunction.getId() + " " + pedigree;
        GeneticMaterial matchingGmNullLineFunction = testHelper
                .createGeneticMaterial(germplasmNullLineFunction, source.toUpperCase(), generation, lineage);
        GeneticMaterial matchingGmNotNullLineFunction = testHelper
                .createGeneticMaterial(germplasmNotNullLineFunction, source.toUpperCase(), generation, lineage);

        List geneticMaterialList = new GeneticMaterialDAO(CROP_NAME, getLineFunctionCriteria(null, null))
                .getGeneticMaterialMatchingPedigreeAndSourceNotLineFunction(pedigree, source.toLowerCase());
        assertNotNull(geneticMaterialList);
        assertEquals(2, geneticMaterialList.size());
        assertContainsGM(geneticMaterialList, matchingGmNullLineFunction);
        assertContainsGM(geneticMaterialList, matchingGmNotNullLineFunction);
    }

    private void assertContainsGM(List<GeneticMaterial> list, GeneticMaterial geneticMaterial) {
        boolean contains = false;
        for (GeneticMaterial geneticMaterialInList : list) {
            if (geneticMaterial.getGeneticMaterialId().equals((geneticMaterialInList).getGeneticMaterialId())) {
                contains = true;
                break;
            }
        }
        assertTrue(contains);
    }


    public void testGetGeneticMaterialWithMatchingSource() {
        init();
        StagingInventory stagingInventory = createStagingInventory("LC-2", "source-21");
        GeneticMaterial geneticMaterialWithMatchingSource = new GeneticMaterialDAO().getGeneticMaterialWithMatchingSource(stagingInventory, new GermplasmListFetchStrategyFinished());
        assertNotNull(geneticMaterialWithMatchingSource);
    }

    private StagingInventory createStagingInventory(String lineCode, String source) {
        StagingInventoryHeader stagingInventoryHeader = new StagingInventoryHeader();
        stagingInventoryHeader.setCropName("Corn");
        StagingInventory stagingInventory = new StagingInventory();
        stagingInventory.setInventoryHeader(stagingInventoryHeader);
        stagingInventory.setLineCode(lineCode);
        stagingInventory.setSource(source);
        stagingInventory.setInventoryOwner("17");
        return stagingInventory;
    }

    private void init() {
        TestHelper testHelper = new TestHelper(session);

        germplasm1 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-1",
                "X/Y", "LC-1", "17", "Corn");
        GeneticMaterial geneticMaterialWithArchivedInventory11 = testHelper
                .createGeneticMaterial(germplasm1, "source-11", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17", "F");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "17");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "T", "C3");
        testHelper.createInventory(geneticMaterialWithArchivedInventory11, "F", "17");
        GeneticMaterial geneticMaterialWithArchivedInventory12 = testHelper
                .createGeneticMaterial(germplasm1, "source-12", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithArchivedInventory12, "F", "17");
        testHelper.createInventory(geneticMaterialWithArchivedInventory12, "F", "17");

        germplasm2 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-2",
                "X/Y", "LC-2", "17", "Corn");
        GeneticMaterial geneticMaterialWithNoArchivedInventory21 = testHelper
                .createGeneticMaterial(germplasm2, "source-21", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory21, "F", "17");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory21, "T", "C3");
        GeneticMaterial geneticMaterialWithNoArchivedInventory22 = testHelper
                .createGeneticMaterial(germplasm2, "source-22", "|", "INBRED");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory22, "F", "17");
        testHelper.createInventory(geneticMaterialWithNoArchivedInventory22, "F", "17");

        germplasm3 = testHelper.createGermplasm(MaterialTypeConstants.FINISHED_LINES, "LC-3",
                "X/Y", "LC-3", "17", "Corn");
        GeneticMaterial geneticMaterial3 = testHelper.createGeneticMaterial(germplasm3, "source-31", "|", "INBRED");
        testHelper.createInventory(geneticMaterial3, "T", "C3");
        testHelper.createInventory(geneticMaterial3, "F", "C3");


        germplasm4 = testHelper.createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null,
                "X/Y", "17_X/Y:@.1.2.", "17", "Corn");
        GeneticMaterial geneticMaterial4 = testHelper.createGeneticMaterial(germplasm4, "source-41", "F4", "@.1.2.");
        testHelper.createInventory(geneticMaterial4, "T", "C3");

        germplasm5 = testHelper.createGermplasm(MaterialTypeConstants.SEGPOP_LINES, null,
                "X/Y", "17_X/Y:@.1.2.", "17", "Corn");
        testHelper.createGeneticMaterial(germplasm5, "source-51", "F4", "@.1.2.");
        testHelper.createInventory(geneticMaterial4, "T", "C3", "F");

    }

}