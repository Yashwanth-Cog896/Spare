/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dbdataservices.PersistentStoreOracleCachedType2;
import com.monsanto.Util.Exceptions.WrappingException;

import java.util.HashSet;

/**
 * Filename:    $RCSfile: ConnectionFactory.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $    	 On:	$Date: 2008-03-17 21:54:26 $
 *
 * @author skumar5
 * @version $Revision: 1.1 $
 */
public abstract class ConnectionFactory {
  private static HashSet registeredInstances = new HashSet();

  public PersistentStoreConnection getConnection() throws WrappingException {
    PersistentStoreConnection conn = null;
    String instanceName = getInstanceName();
    registerInstance(instanceName);
    try{
      conn = PersistentStore.instance(instanceName).connect();
    }
    catch(WrappingException connectException){
      // try re-registering and connecting again
      registeredInstances.clear();
      registerInstance(instanceName);
      conn = PersistentStore.instance(instanceName).connect();
    }

    return conn;
  }

  private void registerInstance(String instanceName) throws WrappingException {
    if (!registeredInstances.contains(instanceName)){
      PersistentStoreOracleCachedType2 instance = new PersistentStoreOracleCachedType2(
              getDatabaseUserName() ,
              getDatabasePassword() ,
              getInstanceName(),
              1, 100);
      PersistentStore.registerInstance(instanceName,instance);
      registeredInstances.add(instanceName);
    }

  }

  protected abstract String getInstanceName();
  protected abstract String getDatabaseUserName();
  protected abstract String getDatabasePassword();

}