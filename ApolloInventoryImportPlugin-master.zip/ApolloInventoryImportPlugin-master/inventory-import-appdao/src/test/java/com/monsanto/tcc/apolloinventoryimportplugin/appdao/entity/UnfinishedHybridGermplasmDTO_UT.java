/*
 UnfinishedHybridGermplasmDTO_UT was created on May 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.test.testutil.TestIIContextConfigurer;

/**
 * Filename:    $RCSfile: UnfinishedHybridGermplasmDTO_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $    	 On:	$Date: 2008-03-10 15:59:37 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class UnfinishedHybridGermplasmDTO_UT extends TestIIContextConfigurer {
    public UnfinishedHybridGermplasmDTO_UT(String name) {
        super(name);
    }

    public void testEqualsTrue() throws Exception {
        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO_1 = new UnfinishedHybridGermplasmDTO();
        unfinishedHybridGermplasmDTO_1.setOrigin("(W117/W64A:@.0001.0001.)+91DHA1");
        unfinishedHybridGermplasmDTO_1.setBrProgRefId("17");
        unfinishedHybridGermplasmDTO_1.setDeleted("F");
        unfinishedHybridGermplasmDTO_1.setCount(0);

        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO_2 = new UnfinishedHybridGermplasmDTO();
        unfinishedHybridGermplasmDTO_2.setOrigin("(W117/W64A:@.0001.0001.)+91DHA1");
        unfinishedHybridGermplasmDTO_2.setBrProgRefId("17");
        unfinishedHybridGermplasmDTO_2.setDeleted("F");
        unfinishedHybridGermplasmDTO_2.setCount(7);

        assertTrue(unfinishedHybridGermplasmDTO_1.equals(unfinishedHybridGermplasmDTO_2));
    }

    public void testEqualsFalse() throws Exception {
        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO_1 = new UnfinishedHybridGermplasmDTO();
        unfinishedHybridGermplasmDTO_1.setOrigin("(W117/W64A:@.0001.0001.)+91DHA1");
        unfinishedHybridGermplasmDTO_1.setBrProgRefId("17");
        unfinishedHybridGermplasmDTO_1.setDeleted("F");
        unfinishedHybridGermplasmDTO_1.setCount(0);

        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO_2 = new UnfinishedHybridGermplasmDTO();
        unfinishedHybridGermplasmDTO_2.setOrigin("(IIST0512/IIST0512A:0001%)+(IIST0512/IIST0512A:0001%0002.)");
        unfinishedHybridGermplasmDTO_2.setBrProgRefId("17");
        unfinishedHybridGermplasmDTO_2.setDeleted("F");
        unfinishedHybridGermplasmDTO_2.setCount(0);

        assertFalse(unfinishedHybridGermplasmDTO_1.equals(unfinishedHybridGermplasmDTO_2));
    }
}