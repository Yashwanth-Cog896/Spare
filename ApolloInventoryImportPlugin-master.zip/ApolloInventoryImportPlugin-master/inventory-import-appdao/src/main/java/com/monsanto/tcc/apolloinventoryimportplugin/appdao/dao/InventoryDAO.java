/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: InventoryWithRestrictionsDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:01 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class InventoryDAO {

    public Inventory[] getActiveUnarchivedInventory(GeneticMaterial geneticMaterial) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        List list = session.createCriteria(Inventory.class)
                .createAlias("program", "bp")
                .add(Restrictions.eq("geneticMaterial", geneticMaterial))
                .add(Restrictions.eq("archivedMaterial", "F"))
                .add(Restrictions.eq("bp.refActive", "T"))
                .list();

        Inventory[] inventories = null;
        if (list != null && list.size() > 0) {
            inventories = (Inventory[]) list.toArray(new Inventory[0]);
        }

        return inventories;
    }

    public Inventory getActiveUnarchivedInventoryOwnedByGermplasmOwner(GeneticMaterial geneticMaterial) {
        Inventory inventory = null;
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Query query = session.getNamedQuery("get.inventories.owned.by.germplasm.owner");
        query.setParameter("geneticMaterialId", geneticMaterial.getGeneticMaterialId());
        List inventories = query.list();
        if (inventories != null && inventories.size() > 0) {
            inventory = (Inventory) inventories.get(0);
        }
        return inventory;
    }

}