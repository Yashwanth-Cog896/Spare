package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 5:42:22 AM To change this template use File |
 * Settings | File Templates.
 */
public class ParentageFetchStrategyAssembler {

    private String cropName;

    public ParentageFetchStrategyAssembler(String cropName) {
        super();
        this.cropName = cropName;
    }

    public ParentageFetchStrategy[] getStrategiesForCheckingExistingParents() {
        return new ParentageFetchStrategy[]{
                new PreCommercialParentMatchingProductNameStrategy(cropName),
                new CompetitorParentMatchingOriginStrategy(cropName),
                new FinishedParentMatchingLineCodeCheckingStrategy(cropName)
        };
    }

    public ParentageFetchStrategy[] getStrategiesForFetchingParentProductGermplasm() {
        return new ParentageFetchStrategy[]{
                new PreCommercialParentMatchingProductNameStrategy(cropName),
                new CompetitorParentMatchingOriginStrategy(cropName)
        };
    }

}
