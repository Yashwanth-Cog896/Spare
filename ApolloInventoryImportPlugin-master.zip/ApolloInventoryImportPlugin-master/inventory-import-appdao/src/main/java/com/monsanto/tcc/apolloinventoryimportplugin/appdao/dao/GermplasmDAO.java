/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.math.BigDecimal;
import java.util.*;

/**
 * Filename:    $RCSfile: GermplasmDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date:
 * 2007/05/16 22:10:53 $
 *
 * @author apatro
 * @version $Revision: 1.5 $
 */
public class GermplasmDAO {
    public static final String CROP_NAME_REQ_MSG = "cropName is required.";
    public static final String PEDIGREE_REQ_MSG = "Pedigree is required.";
    public static final String ORIGIN_REQ_MSG = "Origin is required.";
    private static final String REF_ACTIVE_T = "T";
    public static final long REQUEST_ID = 1200L;

    private Session session = null;
    private String cropName = null;


    public GermplasmDAO() {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public GermplasmDAO(String cropName) {
        if (StringUtils.isNullOrEmpty(cropName)) {
            throw new IllegalArgumentException(CROP_NAME_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
    }

    //TODO: Change the return type to Germplasm[]

    public List getAllGermplasmsMatchingPedigree(String pedigree) {
        if (StringUtils.isNullOrEmpty(pedigree)) {
            throw new IllegalArgumentException(PEDIGREE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigree))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .add(Restrictions.eq("gp.isDeleted", "F"));


        return criteria.list();
    }

    public List getAllGermplasmsMatchingPedigree(String pedigree, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(pedigree)) {
            throw new IllegalArgumentException(PEDIGREE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigree))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .add(Restrictions.eq("gp.isDeleted", "F"));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return criteria.list();
    }

    //TODO: Change the return type to Germplasm[]

    public List getAllGermplasmMatchingLineCode(String lineCode) {
        return session.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .list();
    }

    public Germplasm[] getAllGermplasmsMatchingOrigin(String origin, String likeOrigin,
                                                      LineFunctionCriteria lineFunctionCriteria) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.crop", "cr");

        if (likeOrigin != null) {
            criteria.add(Restrictions.or(Restrictions.eq("origin", origin), Restrictions.like("origin", likeOrigin)));
        } else {
            criteria.add(Restrictions.eq("origin", origin));
        }
        criteria.add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria.list();

        Germplasm[] germplasms = null;
        if (list != null && list.size() > 0) {
            germplasms = (Germplasm[]) list.toArray(new Germplasm[0]);
        }

        return germplasms;
    }

    public Germplasm[] getAllGermplasmsMatchingOrigin(String[] origins) {
        List list = session.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.crop", "cr")
                .add(Restrictions.in("gp.origin", origins))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .list();

        Germplasm[] germplasms = null;
        if (list != null && list.size() > 0) {
            germplasms = (Germplasm[]) list.toArray(new Germplasm[0]);
        }

        return germplasms;
    }

    public int getCountOfAllSegpopGermplasmsMatchingOriginLineageLineTypeCropAndLineFunction(StagingInventory inventory) {
        int count = 0;
        if (null != inventory && !StringUtils.isNullOrEmpty(inventory.getOrigin())) {
            Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm");
            String lineage = inventory.getLineage();
            setLineageCriteria(lineage, criteria);
            criteria.createAlias("gm.germplasm", "gp")
                    .setProjection(Projections.projectionList().add(Projections.count("gm.geneticMaterialId"), "gmCount"))
                    .createAlias("gp.lineType", "lt")
                    .add(Expression.eq("lt.lineTypeRefId", MaterialTypeConstants.SEGPOP_LINES.toUpperCase()))
                    .add(Expression.eq("lt.refActive", "T"))
                    .add(Expression.eq("gp.origin", inventory.getOrigin()))
                    .createAlias("gp.crop", "cr")
                    .add(Expression.eq("cr.cropName", inventory.getInventoryHeader().getCropName()))
                    .add(Expression.eq("cr.refActive", "T"));

            addLineFunctionRestrictionToCriteria(inventory, criteria, "gp");

            Number result = (Number) criteria.uniqueResult();
            count = result.intValue();
        }
        return count;
    }

    private void setLineageCriteria(String lineage, Criteria criteria) {
        if (StringUtils.isNullOrEmpty(lineage)) {
            criteria.add(Expression.isNull("lineage"));
        } else {
            criteria.add(Expression.eq("lineage", lineage));
        }
    }

    private void addLineFunctionRestrictionToCriteria(StagingInventory stagingInventory, Criteria criteria,
                                                      String gpAlias) {
        LineFunctionCriteria lineFunctionCriteria1 = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
        lineFunctionCriteria1.addCriteria(gpAlias, criteria);
    }

    public List<Germplasm> getExistingGermplasmsByVegetativeStructure(StagingInventory inventory) {

        List<String> inValidVegetativeStructures = new ArrayList<String>();
        if ("Seed".equalsIgnoreCase(inventory.getVegetativeStructure())) {
            inValidVegetativeStructures.add("Seed");
        } else {
            inValidVegetativeStructures.add(" ");
        }

        Query query = null;

        String lineage = inventory.getLineage();
        if (lineage == null || lineage.trim().length() == 0) {
            if (lineFunctionDoesNotExists(inventory)) {
                query = session.getNamedQuery("get.existing.germplasms.by.null.lineage.origin.generation.and.vegetativestructure");
            } else {
                query = session.getNamedQuery("get.existing.germplasms.by.null.lineage.origin.generation.and.vegetativestructure.with.linefunction");
                query.setParameter("linefunction", inventory.getLineFunction());
            }

        } else {
            if (lineFunctionDoesNotExists(inventory)) {
                query = session.getNamedQuery("get.existing.germplasms.by.lineage.origin.generation.and.vegetativestructure");
            } else {
                query = session.getNamedQuery("get.existing.germplasms.by.lineage.origin.generation.and.vegetativestructure.with.linefunction");
                query.setParameter("linefunction", inventory.getLineFunction());
            }
            query.setParameter("lineage", lineage);
        }
        query.setParameter("generation", inventory.getGeneration());
        query.setParameter("lineTypeRefId", inventory.getLineType());
        query.setParameter("cropName", inventory.getInventoryHeader().getCropName());

        query.setParameterList("inValidVegetativeStructureCodes", inValidVegetativeStructures);
        query.setParameter("origin", inventory.getOrigin());
        return query.list();

    }

    private boolean lineFunctionDoesNotExists(StagingInventory inventory) {
        return inventory.getLineFunction() == null || inventory.getLineFunction().trim().length() == 0;
    }


    public Germplasm getPrimaryGermplasm(List activeGermplasmsList) {
        Set<Long> germplasmIdSet = new HashSet<Long>();
        for (Object germplasm : activeGermplasmsList) {
            germplasmIdSet.add(((Germplasm) germplasm).getId());
        }
        TempSessionOcdDao tempSessionOcdDao = new TempSessionOcdDaoImpl();
        tempSessionOcdDao.insertNumberValues(1200L, germplasmIdSet);
        Query query = session.getNamedQuery("germaplasmDao.getPrimaryGermplasmId");
        query.setParameter("req_id", REQUEST_ID);
        BigDecimal germplasmIdBigDecimalValue = (BigDecimal) (query.uniqueResult());
        Long germplasmId;
        if (germplasmIdBigDecimalValue == null) {
            ArrayList germplasmIds = new ArrayList(germplasmIdSet);
            Collections.<Long>sort(germplasmIds);
            germplasmId = (Long) germplasmIds.get(0);
        } else {
            germplasmId = new Long(germplasmIdBigDecimalValue.longValue());
        }

        session.createSQLQuery("delete from midas.temp_session_ocd where request_id = 1200").executeUpdate();

        Germplasm primaryGermplasm = (Germplasm) session.load(Germplasm.class, germplasmId);
        return primaryGermplasm;
    }
}