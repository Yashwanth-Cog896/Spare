/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.io.Serializable;

/**
 * Filename:    $RCSfile: SharedInventoryPk.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class SharedInventoryPk implements Serializable {
    private Inventory inventory;
    private BrProg brProg;

    public SharedInventoryPk() {
    }

    public SharedInventoryPk(Inventory inventory, BrProg brProg) {
        if (inventory == null || brProg == null) {
            throw new IllegalArgumentException("Inventory and BrProg required");
        }
        this.inventory = inventory;
        this.brProg = brProg;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public BrProg getBrProg() {
        return brProg;
    }

    public void setBrProg(BrProg brProg) {
        this.brProg = brProg;
    }

    public int hashCode() {
        return inventory.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj.getClass().equals(this.getClass()))) {
            return false;
        }
        final SharedInventoryPk sharedInventoryPk = (SharedInventoryPk) obj;
        if (!inventory.getInventoryId().equals(sharedInventoryPk.getInventory().getInventoryId())) {
            return false;
        }
        if (!brProg.getBrProgId().equals(sharedInventoryPk.getBrProg().getBrProgId())) {
            return false;
        }
        return true;
    }
}