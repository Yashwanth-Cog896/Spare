/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.util;

import com.monsanto.Util.StringUtils;

import java.util.Properties;

/**
 * Filename:    $RCSfile: KeysFolderNameResolver.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:          $Date: 2008-09-10 16:00:53 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class KeysFolderNameResolver {
  private static final String LSI_FUNCTION_REQ_MSG = "Value for lsi function is required";
  private static final String KEYFOLDER_PROPERTY_PREFIX = "keysfolder.";

  public String getKeyFolder(Properties properties, String lsiFunction) {
    if(StringUtils.isNullOrEmpty(lsiFunction)) {
      throw new IllegalArgumentException(LSI_FUNCTION_REQ_MSG);
    }

    String keyFolder = properties.getProperty(KEYFOLDER_PROPERTY_PREFIX + lsiFunction, null);
    if(StringUtils.isNullOrEmpty(keyFolder)) {
      throw new IllegalArgumentException("Key folder for lsi function '" + lsiFunction + "' is not defined.");
    }
    return keyFolder;
  }
}