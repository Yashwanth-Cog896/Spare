/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: LineFunction.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $ On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class LineFunction {
    private long lineFunctionId;
    private String lineFunctionRefId;
    private String refActive;

    public long getLineFunctionId() {
        return lineFunctionId;
    }

    public void setLineFunctionId(long lineFunctionId) {
        this.lineFunctionId = lineFunctionId;
    }

    public String getLineFunctionRefId() {
        return lineFunctionRefId;
    }

    public void setLineFunctionRefId(String lineFunctionRefId) {
        this.lineFunctionRefId = lineFunctionRefId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}