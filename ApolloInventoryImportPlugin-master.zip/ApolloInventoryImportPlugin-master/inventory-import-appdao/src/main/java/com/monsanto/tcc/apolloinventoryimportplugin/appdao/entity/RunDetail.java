/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.common.ImportStatus;

/**
 * Filename:    $RCSfile: RunDetail.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date:
 * 2007/03/08 22:43:53 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class RunDetail {
    private final static int PROCESS_EXCEPTION_MSG_SIZE = 2000;
    private final static int VALIDATION_EXCEPTION_MSG_SIZE = 2000;

    private Long id;
    private RunHistory runHistory;
    private Long inventoryId;
    private ImportStatus validationStatus;
    private String validationExceptionMsg;
    private String processExceptionMsg;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RunHistory getRunHistory() {
        return runHistory;
    }

    public void setRunHistory(RunHistory runHistory) {
        this.runHistory = runHistory;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public ImportStatus getValidationStatus() {
        return validationStatus;
    }

    public void setValidationStatus(ImportStatus validationStatus) {
        this.validationStatus = validationStatus;
    }

    public String getValidationExceptionMsg() {
        return validationExceptionMsg;
    }

    public void setValidationExceptionMsg(String validationExceptionMsg) {
        if (validationExceptionMsg != null) {
            if (validationExceptionMsg.length() > VALIDATION_EXCEPTION_MSG_SIZE) {
                this.validationExceptionMsg = validationExceptionMsg.substring(0, VALIDATION_EXCEPTION_MSG_SIZE);
            } else {
                this.validationExceptionMsg = validationExceptionMsg;
            }
        }
    }

    public String getProcessExceptionMsg() {
        return processExceptionMsg;
    }

    public void setProcessExceptionMsg(String processExceptionMsg) {
        if (processExceptionMsg != null) {
            if (processExceptionMsg.length() > PROCESS_EXCEPTION_MSG_SIZE) {
                this.processExceptionMsg = processExceptionMsg.substring(0, PROCESS_EXCEPTION_MSG_SIZE);
            } else {
                this.processExceptionMsg = processExceptionMsg;
            }
        }
    }
}