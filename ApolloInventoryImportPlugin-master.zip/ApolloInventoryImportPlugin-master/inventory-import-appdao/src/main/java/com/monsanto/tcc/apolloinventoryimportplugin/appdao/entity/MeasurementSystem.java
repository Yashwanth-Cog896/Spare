package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: 8/5/11
 * Time: 10:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class MeasurementSystem {

    public static final String ENGLISH = "English";
    public static final String METRIC = "Metric";

    private Long id;
    private String name;
    private String description;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
