/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.UniqueProductResolverForCompetitor;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyCompetitor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $     On:$Date: 2008-10-10 20:58:44 $
 *
 * @author SSPEYY
 * @version $Revision: 1.5 $
 */

public class GermplasmListFetchStrategyCompetitor implements GermplasmListFetchStrategy {

    public List getGermplasms(StagingInventory si) {
        ProductName productName = getUniqueProductResolverForCompetitor(si).resolve();
        return productName != null ? getGermplasmList(si, productName.getProduct()) : new ArrayList();
    }

    public List getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory) {
        return new ArrayList();
    }

    @Override
    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        ProductName productName = getUniqueProductResolverForCompetitor(stagingInventory).resolve();
        return productName != null ? getGermplasmsCriteria(stagingInventory, productName.getProduct(), session) : null;
    }

    private UniqueProductResolverForCompetitor getUniqueProductResolverForCompetitor(StagingInventory stagingInventory) {
        return new UniqueProductResolverForCompetitor(stagingInventory);
    }

    private List getGermplasmList(StagingInventory stagingInventory, Product product) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        List germplasmList = new ArrayList();
        if (product != null) {
            Criteria productGermplasmCriteria = getGermplasmsCriteria(stagingInventory, product, session);
            germplasmList = productGermplasmCriteria.list();
        }

        return germplasmList;
    }

    private Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Product product, Session session) {
        Criteria productGermplasmCriteria = session.createCriteria(ProductGermplasm.class, "pg")
                .createAlias("pg.germplasm", "gp")
                .setProjection(Projections.distinct(Projections.projectionList().add(Projections.property("pg.germplasm"))))
                .add(Restrictions.eq("pg.product", product))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", "T"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.or(Restrictions.eq("lt.name", "Hybrid").ignoreCase(),
                        Restrictions.eq("lt.name", "Finished").ignoreCase()))
                .add(Restrictions.eq("lt.refActive", "T"));
        addLineFunctionCriteria(stagingInventory, productGermplasmCriteria);
        return productGermplasmCriteria;
    }

    private void addLineFunctionCriteria(StagingInventory stagingInventory, Criteria productGermplasmCriteria) {
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory).getLineFunctionCriteria();
        lineFunctionCriteria.addCriteria("gp", productGermplasmCriteria);
    }
}