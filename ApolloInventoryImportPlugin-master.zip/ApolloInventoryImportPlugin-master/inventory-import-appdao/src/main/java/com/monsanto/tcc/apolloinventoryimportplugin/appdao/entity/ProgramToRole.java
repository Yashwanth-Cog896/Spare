/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: ProgramToRole.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class ProgramToRole {
    private Long id;
    private BrProg brProg;
    private MidasRole midasRole;
    private String refActive;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BrProg getBrProg() {
        return brProg;
    }

    public void setBrProg(BrProg brProg) {
        this.brProg = brProg;
    }

    public MidasRole getMidasRole() {
        return midasRole;
    }

    public void setMidasRole(MidasRole midasRole) {
        this.midasRole = midasRole;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}