/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: CodedGermplasmGeneticMaterialDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5
 * $     On:$Date: 2008-06-02 15:40:52 $
 *
 * @author apatro
 * @version $Revision: 1.2 $
 */
public class CodedGermplasmGeneticMaterialDAO {
    public static final String CROP_ORIGIN_LINECODE_REQ_MSG = "cropName, origin, lineCode and lineFunctionCriteria are required.";
    public static final String CROP_LINECODE_REQ_MSG = "cropName, lineCode and lineFunctionCriteria are required.";
    public static final String SOURCE_LINEAGE_GEN_REQ_MSG = "source, lineage and generation are required.";
    public static final String GPID_SOURCE_LINEAGE_GEN_REQ_MSG = "germplasmId, source, lineage and generation are required.";

    private static final String LINE_TYPE_REF_ID = MaterialTypeConstants.CODED_LINES.toUpperCase();

    private Session session;
    private String cropName;
    private String origin;
    private String lineCode;
    private LineFunctionCriteria lineFunctionCriteria;

    public CodedGermplasmGeneticMaterialDAO(String cropName, String lineCode, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || StringUtils.isNullOrEmpty(lineCode) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_LINECODE_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.lineCode = lineCode;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public CodedGermplasmGeneticMaterialDAO(String cropName, String origin, String lineCode,
                                            LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || StringUtils.isNullOrEmpty(origin)
                || StringUtils.isNullOrEmpty(lineCode) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_ORIGIN_LINECODE_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.origin = origin;
        this.lineCode = lineCode;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public GeneticMaterial getGeneticMaterial(String source, String lineage, String generation) {
        if (StringUtils.isNullOrEmpty(source) || StringUtils.isNullOrEmpty(lineage) ||
                StringUtils.isNullOrEmpty(generation)) {
            throw new IllegalArgumentException(SOURCE_LINEAGE_GEN_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("gm.germplasm", "gp")
                .createAlias("gp.lineType", "lt")
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("lt.lineTypeRefId", LINE_TYPE_REF_ID))
                .add(Restrictions.eq("lt.refActive", "T"))
                .add(Restrictions.eq("cr.refActive", "T"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("gm.lineage", lineage))
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .add(Restrictions.eq("gm.generation", generation));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return (GeneticMaterial) criteria.uniqueResult();
    }

    public GeneticMaterial getGeneticMaterial(Germplasm germplasm, String source, String lineage, String generation) {
        if (null == germplasm || StringUtils.isNullOrEmpty(source) || StringUtils.isNullOrEmpty(lineage) ||
                StringUtils.isNullOrEmpty(generation)) {
            throw new IllegalArgumentException(GPID_SOURCE_LINEAGE_GEN_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .setFetchMode("gm.germplasm", FetchMode.JOIN)
                .createAlias("gm.germplasm", "gp")
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("germplasm", germplasm))
                .add(Restrictions.eq("lt.lineTypeRefId", LINE_TYPE_REF_ID))
                .add(Restrictions.eq("lt.refActive", "T"))
                .add(Restrictions.eq("gm.lineage", lineage))
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .add(Restrictions.eq("gm.generation", generation));
        lineFunctionCriteria.addCriteria("gp", criteria);

        return (GeneticMaterial) criteria.uniqueResult();
    }
}