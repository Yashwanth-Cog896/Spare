package com.monsanto.tcc.apolloinventoryimportplugin.appdao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: aagosw Date: Oct 6, 2008 Time: 10:40:35 AM To change this template use File |
 * Settings | File Templates.
 */
public class UniqueProductResolverForCompetitor {
    private StagingInventory stagingInventory;
    public static final String REQUIRED_MSG = "Crop and ProductName is required";
    private String brandName;
    private boolean noRecordExists = false;
    private boolean brandNameMatched = false;
    public static final String COMPANY_MONSANTO = "MONSANTO";


    public UniqueProductResolverForCompetitor(StagingInventory stagingInventory) {
        if (StringUtils.isNullOrEmpty(stagingInventory.getInventoryHeader().getCropName()) ||
                StringUtils.isNullOrEmpty(stagingInventory.getProductName())) {
            throw new IllegalArgumentException(REQUIRED_MSG);
        }
        this.stagingInventory = stagingInventory;
        this.brandName = stagingInventory.getBrandName();
    }

    public ProductName resolve() {
        List<ProductName> productNameList = getProductNameList(stagingInventory);
        if (productNameList == null || productNameList.size() == 0) {
            noRecordExists = true;
            return null;
        }
        productNameList = subsetToMatchBrandName(productNameList);
        ProductName productName = checkIfMultipleProductNameRecordResolvesToOneProduct(productNameList);
        return productName;
    }

    private List<ProductName> subsetToMatchBrandName(List<ProductName> productNameList) {
        List<ProductName> productNameListMatchingBrandName = new ArrayList();
        if (!StringUtils.isNullOrEmpty(brandName)) {
            for (ProductName productName : productNameList) {
                if (productName.getBrand().getName().equalsIgnoreCase(brandName)) {
                    brandNameMatched = true;
                    productNameListMatchingBrandName.add(productName);
                }
            }
        }
        return productNameListMatchingBrandName.size() > 0 ? productNameListMatchingBrandName : productNameList;
    }

    private ProductName checkIfMultipleProductNameRecordResolvesToOneProduct(List<ProductName> productNameList) {
        ProductName productName = productNameList.get(0);
        for (ProductName name : productNameList) {
            if (!productName.equals(name) && !name.getProduct().getId().equals(productName.getProduct().getId())) {
                return null;
            }
        }
        return productName;
    }

    public boolean isNoRecordExists() {
        return noRecordExists;
    }

    public boolean isBrandNameMatched() {
        return brandNameMatched;
    }

    private List getProductNameList(StagingInventory stagingInventory) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        Criteria productNameCriteria = session.createCriteria(ProductName.class, "pn")
                .createAlias("pn.product", "p")
                .createAlias("pn.brand", "br")
                .createAlias("br.company", "cp")
                .add(Restrictions.eq("pn.name", stagingInventory.getProductName()).ignoreCase())
                .add(Restrictions.ne("cp.name", COMPANY_MONSANTO).ignoreCase())
//                .add(Restrictions.eq("br.refActive", "T"))
                .add(Restrictions.or(Restrictions.eq("br.refActive", "T").ignoreCase(), Restrictions.eq("br.refActive", "y").ignoreCase()))
                .add(Restrictions.eq("pn.refActive", "T"))
                .add(Restrictions.eq("p.refActive", "T"))
                .createAlias("p.crop", "cr")
                .add(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"));

        return productNameCriteria.list();
    }

}