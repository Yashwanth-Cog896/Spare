/*
 GeneticMaterialOfGermplasmDAO was created on Feb 29, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: GeneticMaterialOfGermplasmDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-04-17 17:05:29 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class GeneticMaterialOfGermplasmDAO {
    public static final String GERMPLASM_IS_REQUIRED = "germplasm is required.";
    private Session session = null;
    private Germplasm germplasm = null;

    public GeneticMaterialOfGermplasmDAO(Germplasm germplasm) {
        if (null == germplasm) {
            throw new IllegalArgumentException(GERMPLASM_IS_REQUIRED);
        }

        this.germplasm = germplasm;
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public GeneticMaterial getGeneticMaterial(String source) {
        GeneticMaterial geneticMaterial = (GeneticMaterial) session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.germplasm", germplasm))
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .uniqueResult();

        return geneticMaterial;

    }
}