/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.Collection;
import java.util.Set;

/**
 * Filename:    $RCSfile: GeneticMaterial.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date:
 * 2007/03/06 23:20:01 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class GeneticMaterial {
    private Long geneticMaterialId;
    private String sourceStr;
    private String generation;
    private String lineage;
    private Germplasm germplasm;
    private String isAutogen;
    private String srcLotNumber;
    private Collection<Inventory> inventories;

    private Set sharedGenMatlBrProg;

    public Long getGeneticMaterialId() {
        return geneticMaterialId;

    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public String getSourceStr() {
        return sourceStr;
    }

    public void setSourceStr(String sourceStr) {
        this.sourceStr = sourceStr;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public Germplasm getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }

    public Set getSharedGenMatlBrProg() {
        return sharedGenMatlBrProg;
    }

    public void setSharedGenMatlBrProg(Set sharedGenMatlBrProg) {
        this.sharedGenMatlBrProg = sharedGenMatlBrProg;
    }

    public String getIsAutogen() {
        return isAutogen;
    }

    public void setIsAutogen(String isAutogen) {
        this.isAutogen = isAutogen;
    }

    public String getSrcLotNumber() {
        return srcLotNumber;
    }

    public void setSrcLotNumber(String srcLotNumber) {
        this.srcLotNumber = srcLotNumber;
    }

    public Collection<Inventory> getInventories() {
        return inventories;
    }

    public void setInventories(Collection<Inventory> inventories) {
        this.inventories = inventories;
    }
}