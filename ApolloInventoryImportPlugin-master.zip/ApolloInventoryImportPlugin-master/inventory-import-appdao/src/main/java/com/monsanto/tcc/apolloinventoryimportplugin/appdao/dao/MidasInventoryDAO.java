/*
 MidasInventoryDAO was created on Mar 10, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.GermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.ListCriteriaUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Query;
import org.hibernate.Session;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: MidasInventoryDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2008-08-18 18:59:45 $
 *
 * @author SRKARNA
 * @version $Revision: 1.3 $
 */
public class MidasInventoryDAO {
    private Session session = null;
    private final ListCriteriaUtil listCriteriaUtil = new ListCriteriaUtil();
    private final static long COUNT_REQUEST_ID = 234l;
    private final static long QUERY_SAME_OWNER_INVENTORIES = 48956l;
    private final static long QUERY_DIFFERENT_OWNER_INVENTORIES = 89674l;

    public MidasInventoryDAO() {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public Inventory getArchivedInventory(StagingInventory stagingInventory,
                                          GermplasmListFetchStrategy germplasmListFetchStrategy) {
        Inventory inventory = null;

        List germplasmList = germplasmListFetchStrategy.getGermplasms(stagingInventory);
        if (isNotEmpty(germplasmList)) {
            Germplasm[] germplasms = (Germplasm[]) germplasmList.toArray(new Germplasm[0]);

            String source = stagingInventory.getSource();
            String inventoryOwner = stagingInventory.getInventoryOwner();

            inventory = getArchivedInventoryWithMatchingSourceAndSameInvOwnerQuery(germplasms,
                    source, inventoryOwner);
        }

        return inventory;
    }

    public GeneticMaterial getGeneticMaterialWhereAllInventoriesAreArchivedWithDifferentInventoryOwner(StagingInventory stagingInventory,
                                                                                                       GermplasmListFetchStrategy germplasmListFetchStrategy) {
        GeneticMaterial geneticMaterial = null;

        List germplasmList = germplasmListFetchStrategy.getGermplasms(stagingInventory);
        if (isNotEmpty(germplasmList)) {
            Germplasm[] germplasms = (Germplasm[]) germplasmList.toArray(new Germplasm[0]);

            String inventoryOwner = stagingInventory.getInventoryOwner();
            String source = stagingInventory.getSource();

            if (!hasNotArchivedInventoriesForMatchingSource(germplasms, source)
                    && !hasArchivedInventoriesForMatchingSourceAndInvOwner(germplasms, source, inventoryOwner)) {

                geneticMaterial = getGeneticMaterialForArchivedInventoryOnDifferentInventoryOwnerWithMatchingSource(germplasms, source, inventoryOwner);
            }
        }

        return geneticMaterial;
    }

    private GeneticMaterial getGeneticMaterialForArchivedInventoryOnDifferentInventoryOwnerWithMatchingSource(Germplasm[] germplasms, String source, String inventoryOwner) {
        GeneticMaterial geneticMaterial = null;
        Inventory inventory = getArchivedInventoryWithMatchingSourceAndDifferentInvOwnerQuery(germplasms, source, inventoryOwner);
        if (null != inventory) {
            geneticMaterial = inventory.getGeneticMaterial();
        }
        return geneticMaterial;
    }

    private boolean hasNotArchivedInventoriesForMatchingSource(Germplasm[] germplasms, String source) {
        return (getCountOfInventoriesNotArchivedMatchingSource(germplasms, source) > 0);
    }

    private boolean hasArchivedInventoriesForMatchingSourceAndInvOwner(Germplasm[] germplasms, String source, String inventoryOwner) {
        return (null != getArchivedInventoryWithMatchingSourceAndSameInvOwnerQuery(germplasms, source, inventoryOwner));
    }

    private boolean isNotEmpty(List rows) {
        return ((null != rows) && (rows.size() > 0));
    }

    private void setGermplasmTempTableCriteria(long id, Germplasm[] germplasms) {
        Set<Long> germplasmIdSet = new HashSet<Long>();
        for (Germplasm germplasm : germplasms) {
            germplasmIdSet.add(germplasm.getId());
        }
        TempSessionOcdDao tempSessionOcdDao = new TempSessionOcdDaoImpl();
        tempSessionOcdDao.insertNumberValues(id, germplasmIdSet);
    }

    private Inventory getArchivedInventoryWithMatchingSourceAndSameInvOwnerQuery(Germplasm[] germplasms,
                                                                                 String source,
                                                                                 String inventoryOwner) {
        String queryName = "getArchivedInventoriesWithMatchingsourceAndSameInvOwner";
        return runInventoryQuery(germplasms, source, inventoryOwner, QUERY_SAME_OWNER_INVENTORIES, queryName);

    }

    private Inventory getArchivedInventoryWithMatchingSourceAndDifferentInvOwnerQuery(Germplasm[] germplasms,
                                                                                      String source,
                                                                                      String inventoryOwner) {
        String queryName = "getArchivedInventoriesWithMatchingsourceAndDifferentInvOwner";
        return runInventoryQuery(germplasms, source, inventoryOwner, QUERY_DIFFERENT_OWNER_INVENTORIES, queryName);
    }

    private Inventory runInventoryQuery(Germplasm[] germplasms, String source, String inventoryOwner, long requestId, String queryName) {
        setGermplasmTempTableCriteria(requestId, germplasms);
        Query query = session.getNamedQuery(queryName);
        query.setParameter("brProgRefId", inventoryOwner);
        query.setParameter("source", source);
        query.setParameter("requestId", requestId);

        Inventory inventory = null;
        List rows = query.list();
        if (isNotEmpty(rows)) {
            inventory = (Inventory) rows.get(0);
        }

        return inventory;
    }

    private Integer getCountOfInventoriesNotArchivedMatchingSource(Germplasm[] germplasms, String source) {
        String queryName = "getCountOfInventoriesWithNotArchivedMatchingSource";
        setGermplasmTempTableCriteria(COUNT_REQUEST_ID, germplasms);
        Query query = session.getNamedQuery(queryName);
        query.setParameter("source", source);
        query.setParameter("requestId", COUNT_REQUEST_ID);
        Long count = (Long) query.uniqueResult();

        return count.intValue();
    }
}