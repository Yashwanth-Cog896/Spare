package com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty.select;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 15, 2010
 * Time: 3:02:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActiveGermplasmRoyaltyCriteria {
    public Criteria add(String alias, Criteria criteria) {
        return criteria.add(Restrictions.isNull(alias + ".inactiveDt"))
                .add(Restrictions.eq(alias + ".royaltyInd", "T"));
    }
}
