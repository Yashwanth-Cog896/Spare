/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.Set;

/**
 * Filename:    $RCSfile: Parentage.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class Parentage {
    private GeneticMaterial parentGeneticMaterial;
    private GeneticMaterial geneticMaterial;
    private ParentalRole parentalRole;
    private Long parentageId;
    private String tester;

    private Set sharedParentageBrProg;

    public String getTester() {
        return tester;
    }

    public void setTester(String tester) {
        this.tester = tester;
    }

    public Long getParentageId() {
        return parentageId;
    }

    public void setParentageId(Long parentageId) {
        this.parentageId = parentageId;
    }

    public ParentalRole getParentalRole() {
        return parentalRole;
    }

    public void setParentalRole(ParentalRole parentalRole) {
        this.parentalRole = parentalRole;
    }


    public GeneticMaterial getParentGeneticMaterial() {
        return parentGeneticMaterial;
    }

    public void setParentGeneticMaterial(GeneticMaterial parentGeneticMaterial) {
        this.parentGeneticMaterial = parentGeneticMaterial;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public Set getSharedParentageBrProg() {
        return sharedParentageBrProg;
    }

    public void setSharedParentageBrProg(Set sharedParentageBrProg) {
        this.sharedParentageBrProg = sharedParentageBrProg;
    }
}