package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 9, 2009
 * Time: 1:23:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropVegetativeStructure {

    private Long cropVegetativeStructureId;
    private Crop crop;
    private VegetativeStructure vegetativeStructure;
    private String refActive;
    private Long developmentOrder;

    public Long getCropVegetativeStructureId() {
        return cropVegetativeStructureId;
    }

    public void setCropVegetativeStructureId(Long cropVegetativeStructureId) {
        this.cropVegetativeStructureId = cropVegetativeStructureId;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public VegetativeStructure getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(VegetativeStructure vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public Long getDevelopmentOrder() {
        return developmentOrder;
    }

    public void setDevelopmentOrder(Long developmentOrder) {
        this.developmentOrder = developmentOrder;
    }
}
