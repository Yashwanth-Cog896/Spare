package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty.select.GermplasmRoyaltyCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 19, 2010
 * Time: 2:02:44 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractGermplasmListFetchStrategy implements GermplasmListFetchStrategy {

    public List<Germplasm> getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory) {
        Criteria criteria = getGermplasmsListFetchCriteria(stagingInventory);
        addRoyaltyCriteria(criteria);
        return criteria.list();
    }

    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = getGermplasmsCriteria(stagingInventory, session);
        addLineFunictionCriteria(stagingInventory, criteria);
        return criteria;
    }

    private void addLineFunictionCriteria(StagingInventory stagingInventory, Criteria criteria) {
        getDefaultLineFunctionCriteria(stagingInventory).addCriteria("gp", criteria);
    }

    private void addRoyaltyCriteria(Criteria criteria) {
        criteria.createAlias("gp.germplasmRoyalty", "gpr");

        GermplasmRoyaltyCriteriaFactory.addActiveGermplasmRoyaltyCriteria("gpr", criteria);
    }

    protected abstract Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session);

    protected abstract LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory);
}
