/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.UnfinishedHybridGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyUnfinishedHybrid.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: srkarna $     On:$Date: 2008-03-10 15:50:58 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.3 $
 */
public class GermplasmListFetchStrategyUnfinishedHybrid extends AbstractGermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        return createUnfinishedHybridGermplasmDAO(stagingInventory.getInventoryHeader().getCropName(),
                getDefaultLineFunctionCriteria(stagingInventory))
                .getGermplasmsMatchingOrigin(stagingInventory.getOrigin());
    }

    protected UnfinishedHybridGermplasmDAO createUnfinishedHybridGermplasmDAO(String cropName,
                                                                              LineFunctionCriteria lineFunctionCriteria) {
        return new UnfinishedHybridGermplasmDAO(cropName, lineFunctionCriteria);
    }

    @Override
    protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
        return createUnfinishedHybridGermplasmDAO(stagingInventory.getInventoryHeader().getCropName(),
                getDefaultLineFunctionCriteria(stagingInventory)).getGermplasmCriteria(stagingInventory.getOrigin());
    }

    @Override
    protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
        return new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
    }
}