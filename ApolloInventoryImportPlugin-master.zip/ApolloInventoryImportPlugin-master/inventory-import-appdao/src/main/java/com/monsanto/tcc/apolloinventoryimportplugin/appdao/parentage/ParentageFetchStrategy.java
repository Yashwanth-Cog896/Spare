package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductNameProductGermplasm;

import java.util.List;

public interface ParentageFetchStrategy {

    public boolean checkIfParentsExists(String originComponent);

    public List fetchParentProductGermplasms(String originComponent);

    public ProductNameProductGermplasm fetchProductNameProductGermplasm(String originComponent);


}
