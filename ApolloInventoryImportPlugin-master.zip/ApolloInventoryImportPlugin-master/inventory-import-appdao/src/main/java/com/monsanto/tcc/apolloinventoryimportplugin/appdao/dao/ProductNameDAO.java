package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 19, 2008 Time: 7:15:47 AM To change this template use File |
 * Settings | File Templates.
 */
public class ProductNameDAO {
    protected String cropName;
    protected Session session;

    public ProductNameDAO(String cropName) {
        if (StringUtils.isNullOrEmpty(cropName)) {
            {
                throw new IllegalArgumentException("cropName is required.");
            }
        }
        this.cropName = cropName;
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public List getProductListMatchingProductName(String productName) {
        return createCriteriaForProductListSearchByProductName(productName).list();
    }

    protected Criteria createCriteriaForProductListSearchByProductName(String productName) {
        Criteria criteria = session.createCriteria(ProductName.class, "pn")
                //.setProjection(Projections.distinct(Projections.property("pn.product")))
                .add(Restrictions.eq("pn.name", productName).ignoreCase())
                .add(Restrictions.eq("pn.refActive", "T"))
                .createAlias("pn.product", "pr")
                .add(Restrictions.eq("pr.refActive", "T"))
                .createAlias("pr.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"));
        addCriteriaForProductType("pn", criteria);
        return criteria;
    }

    public List getProductListMatchingProducts(List products) {
        return createCriteriaForProductListSearchByProduct(products).list();
    }

    protected Criteria createCriteriaForProductListSearchByProduct(List products) {
        Criteria criteria = session.createCriteria(ProductName.class, "pn")
                //.setProjection(Projections.distinct(Projections.id()))
                .createAlias("pn.product", "pr")
                .add(Restrictions.in("pn.product", products))
                .add(Restrictions.eq("pn.refActive", "T"))
                .add(Restrictions.eq("pr.refActive", "T"))
                .createAlias("pr.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"));
        addCriteriaForProductType("pn", criteria);
        return criteria;
    }

    protected void addCriteriaForProductType(String alias, Criteria criteria) {
    }

}