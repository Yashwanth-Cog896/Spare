/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.EventConstruct;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Filename:    $RCSfile: EventConstructDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $
 * On:$Date: 2008-05-06 20:26:31 $
 *
 * @author apatro
 * @version $Revision: 1.3 $
 */
public class EventConstructDAO {
    public static final String CROP_NAME_REQUIRED_MSG = "cropName is required";
    private static final String EVENT_NAME_REQUIRED_MSG = "eventName is required";
    private String cropName;

    public EventConstructDAO(String cropName) {
        if (StringUtils.isNullOrEmpty(cropName)) {
            throw new IllegalArgumentException(CROP_NAME_REQUIRED_MSG);
        }
        this.cropName = cropName;
    }

    public EventConstruct[] getEventConstruct(String[] eventNames) {
        if (eventNames == null || eventNames.length == 0) {
            throw new IllegalArgumentException(EVENT_NAME_REQUIRED_MSG);
        }

        String[] uniqueArrayOfEventNames = getUniqueArrayOfNonNullEventNames(eventNames);
        List<EventConstruct> eventConstructList = new ArrayList<EventConstruct>(uniqueArrayOfEventNames.length);
        for (int i = 0; i < uniqueArrayOfEventNames.length; i++) {
            getEventConstruct(eventConstructList, uniqueArrayOfEventNames[i]);
        }

        EventConstruct[] eventConstruct = null;
        if (eventConstructList.size() > 0) {
            eventConstruct = (EventConstruct[]) eventConstructList.toArray(new EventConstruct[eventConstructList.size()]);
        }

        return eventConstruct;
    }

    private void getEventConstruct(List<EventConstruct> eventConstructList, String eventName) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        List list = session.createCriteria(EventConstruct.class)
                .createAlias("crop", "cr")
                .add(Restrictions.eq("eventName", eventName))
                .add(Restrictions.eq("refActive", "T"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .addOrder(Order.asc("eventName"))
                .addOrder(Order.asc("eventConstructId"))
                .list();

        if (list != null && list.size() > 0) {
            eventConstructList.add((EventConstruct) list.get(0));
        }
    }

    private String[] getUniqueArrayOfNonNullEventNames(String[] originalEventNames) {
        Set<String> uniqueMapOfEventNames = new TreeSet<String>();
        for (int i = 0; i < originalEventNames.length; i++) {
            if (!StringUtils.isNullOrEmpty(originalEventNames[i])) {
                uniqueMapOfEventNames.add(originalEventNames[i]);
            }
        }
        return (String[]) uniqueMapOfEventNames.toArray(new String[uniqueMapOfEventNames.size()]);
    }
}