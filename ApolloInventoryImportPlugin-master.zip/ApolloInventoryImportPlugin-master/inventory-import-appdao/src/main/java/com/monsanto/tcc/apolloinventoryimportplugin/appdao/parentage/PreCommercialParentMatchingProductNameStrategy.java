package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;


import com.monsanto.tcc.apolloinventoryimportplugin.appdao.business.ProductGermplasmFinder;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.PreCommercialProductNameDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.ProductGermPlasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.ProductNameDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductNameProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.ArrayList;
import java.util.List;

public class PreCommercialParentMatchingProductNameStrategy implements ParentageFetchStrategy {
    private String cropName;
    private final ProductGermplasmFinder productGermplasmFinder = new ProductGermplasmFinder();

    public PreCommercialParentMatchingProductNameStrategy(
            String cropName) {
        super();
        this.cropName = cropName;
    }

    public boolean checkIfParentsExists(String originComponent) {
        List productGermplasmList = fetchParentProductGermplasms(originComponent);
        return !((null == productGermplasmList) || (0 == productGermplasmList.size()));
    }

    public ProductNameProductGermplasm fetchProductNameProductGermplasm(String originComponent) {
        return productGermplasmFinder.getPrimaryProductNameProductGermplasm(fetchParentProductGermplasms(originComponent));
    }

    public List fetchParentProductGermplasms(String originComponent) {
        ProductNameDAO productNameDAO = createProductNameDAO();
        List productNameList = productNameDAO.getProductListMatchingProductName(originComponent);
        if ((null == productNameList) || (0 == productNameList.size())) {
            return new ArrayList();
        }
        ProductGermPlasmDAO productGermPlasmDAO = createProductGermPlasmDAO();
        List<Product> productList = getProductListFromProductNameList(productNameList);
        List productGermplasmList = productGermPlasmDAO.getProductGermplasmListForProducts(productList);
        if (productGermplasmList == null || productGermplasmList.size() == 0) {
            return new ArrayList();
        }
        return productGermplasmFinder.getProductNameProductGermplasmList(productGermplasmList,
                productNameList);
    }

    protected List<Product> getProductListFromProductNameList(
            List productNameList) {
        List<Product> productList = new ArrayList<Product>();
        if (productNameList != null && productNameList.size() > 0) {
            for (Object aProductNameList : productNameList) {
                ProductName productName = (ProductName) aProductNameList;
                productList.add(productName.getProduct());
            }
        }
        return productList;
    }

    protected ProductGermPlasmDAO createProductGermPlasmDAO() {
        return new ProductGermPlasmDAO(cropName, getLineTypes());
    }

    protected String[] getLineTypes() {
        return new String[]{MaterialTypeConstants.FINISHED_LINES};
    }

    protected ProductNameDAO createProductNameDAO() {
        return new PreCommercialProductNameDAO(cropName);
    }
}
 


