/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm.GermplasmListFetchStrategy;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Restrictions;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Filename:    $RCSfile: GeneticMaterialDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:$Date:
 * 2007/07/18 05:42:16 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.4 $
 */
public class GeneticMaterialDAO {
    public static final String CROP_NAME_CRITERIA_REQ_MSG = "cropName and lineFunctionCriteria are required";

    private String cropName;
    private LineFunctionCriteria lineFunctionCriteria;

    private Session session;
    private static final String IS_FINISHED_T = "T";
    private static final String IS_FINISHED_F = "F";
    private static final String REF_ACTIVE_T = IS_FINISHED_T;
    private static final String IS_DELETED_F = IS_FINISHED_F;
    private final static long COUNT_REQUEST_ID = 2342;

    public GeneticMaterialDAO() {
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public GeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_NAME_CRITERIA_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        this.cropName = cropName;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public List getGeneticMaterialMatchingPedigreeAndSourceNotLineFunction(String pedigreeName, String source) {
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));

        return criteria.list();
    }

    public List getGeneticMaterial(String pedigreeName, String source) {
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return criteria.list();
    }

    public GeneticMaterial getGeneticMaterial(String pedigreeName, String source, String lineType) {

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Expression.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Expression.eq("gp.pedigreeName", pedigreeName))
                .add(Expression.eq("gp.isDeleted", IS_DELETED_F))
                .createAlias("gp.lineType", "lt")
                .add(Expression.eq("lt.name", lineType).ignoreCase())
                .add(Expression.eq("lt.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        criteria.createAlias("gp.crop", "cr")
                .add(Expression.eq("cr.cropName", cropName))
                .add(Expression.eq("cr.refActive", REF_ACTIVE_T));

        return (GeneticMaterial) criteria.uniqueResult();
    }

    public GeneticMaterial getFinishedGeneticMaterial(String pedigreeName, String source, String lineType) {

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Expression.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Expression.eq("gp.pedigreeName", pedigreeName))
                .add(Expression.eq("gp.isFinishedOrFinishedChild", IS_FINISHED_T))
                .add(Expression.eq("gp.isDeleted", IS_DELETED_F))
                .createAlias("gp.lineType", "lt")
                .add(Expression.eq("lt.name", lineType).ignoreCase())
                .add(Expression.eq("lt.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        criteria.createAlias("gp.crop", "cr")
                .add(Expression.eq("cr.cropName", cropName))
                .add(Expression.eq("cr.refActive", REF_ACTIVE_T));

        return (GeneticMaterial) criteria.uniqueResult();
    }

    public GeneticMaterial getUnfinishedGeneticMaterial(String pedigreeName, String source, String lineType) {

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Expression.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Expression.eq("gp.pedigreeName", pedigreeName))
                .add(Expression.eq("gp.isFinishedOrFinishedChild", IS_FINISHED_F))
                .add(Expression.eq("gp.isDeleted", IS_DELETED_F))
                .createAlias("gp.lineType", "lt")
                .add(Expression.eq("lt.name", lineType).ignoreCase())
                .add(Expression.eq("lt.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        criteria.createAlias("gp.crop", "cr")
                .add(Expression.eq("cr.cropName", cropName))
                .add(Expression.eq("cr.refActive", REF_ACTIVE_T));

        return (GeneticMaterial) criteria.uniqueResult();
    }


    public GeneticMaterial getGeneticMaterialWithMatchingSource(StagingInventory stagingInventory, GermplasmListFetchStrategy germplasmListFetchStrategy) {
        GeneticMaterial geneticMaterial = null;

        List germplasmList = germplasmListFetchStrategy.getGermplasms(stagingInventory);
        if (!CollectionUtils.isEmpty(germplasmList)) {
            Germplasm[] germplasms = (Germplasm[]) germplasmList.toArray(new Germplasm[0]);
            String queryName = "getGeneticMaterialWithMatchingSourceAndGermplasmOwner";
            setGermplasmTempTableCriteria(COUNT_REQUEST_ID, germplasms);
            Query query = session.getNamedQuery(queryName);
            query.setParameter("source", stagingInventory.getSource());
            query.setParameter("requestId", COUNT_REQUEST_ID);
            List geneticMaterialList = query.list();
            if (!CollectionUtils.isEmpty(geneticMaterialList)) {
                geneticMaterial = (GeneticMaterial) geneticMaterialList.get(0);
            }
        }

        return geneticMaterial;
    }

    private void setGermplasmTempTableCriteria(long id, Germplasm[] germplasms) {
        Set<Long> germplasmIdSet = new HashSet<Long>();
        for (Germplasm germplasm : germplasms) {
            germplasmIdSet.add(germplasm.getId());
        }
        TempSessionOcdDao tempSessionOcdDao = new TempSessionOcdDaoImpl();
        tempSessionOcdDao.insertNumberValues(id, germplasmIdSet);
    }

}