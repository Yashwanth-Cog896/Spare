package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.TempSessionOcd;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.TempSessionOcdId;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;

import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: rehigg
 * Date: Jan 27, 2011
 * Time: 11:02:12 AM
 */
public class TempSessionOcdDaoImpl implements TempSessionOcdDao {
    public static final int MAX_ITEMS_BEFORE_FLUSH = 1000;


    @Override
    public void insertNumberValues(Long requestId, Set<Long> ids) {
        Session session = getSession();
        Iterable<List<Long>> idBatches = Iterables.partition(ids, MAX_ITEMS_BEFORE_FLUSH);
        for (List<Long> idBatch : idBatches) {
            List<TempSessionOcd> tempSessionOcds = Lists.newArrayList();
            for (Long id : idBatch) {
                TempSessionOcd tempSessionOcd = new TempSessionOcd(new TempSessionOcdId(requestId, id, null, null, null, 1L));
                session.save(tempSessionOcd);
                tempSessionOcds.add(tempSessionOcd);
            }
            flushAndEvict(session, tempSessionOcds);
        }
    }

    private void flushAndEvict(Session session, List<TempSessionOcd> tempSessionOcds) {
        session.flush();
        for (TempSessionOcd tempSessionOcd : tempSessionOcds) {
            session.evict(tempSessionOcd);
        }
    }

    protected Session getSession() {
        return HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    }
}
