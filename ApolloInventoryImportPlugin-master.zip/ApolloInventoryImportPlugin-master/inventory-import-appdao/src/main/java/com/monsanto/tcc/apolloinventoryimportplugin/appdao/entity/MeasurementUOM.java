package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: 8/5/11
 * Time: 11:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class MeasurementUOM {

    private Long measurementUOMId;
    private Long measurementId;
    private Long uomId;
    private String precisionAllowed;
    private Date inActiveDate;
    private MeasurementSystem measurementSystem;

    public MeasurementSystem getMeasurementSystem() {
        return measurementSystem;
    }

    public void setMeasurementSystem(MeasurementSystem measurementSystem) {
        this.measurementSystem = measurementSystem;
    }


    public Long getMeasurementUOMId() {
        return measurementUOMId;
    }

    public void setMeasurementUOMId(Long measurementUOMId) {
        this.measurementUOMId = measurementUOMId;
    }

    public Long getMeasurementId() {
        return measurementId;
    }

    public void setMeasurementId(Long measurementId) {
        this.measurementId = measurementId;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }


    public String getPrecisionAllowed() {
        return precisionAllowed;
    }

    public void setPrecisionAllowed(String precisionAllowed) {
        this.precisionAllowed = precisionAllowed;
    }

    public Date getInActiveDate() {
        return inActiveDate;
    }

    public void setInActiveDate(Date inActiveDate) {
        this.inActiveDate = inActiveDate;
    }


}
