/*
 GermplasmPicker was created on Feb 22, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.GermplasmPickerDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmPicker.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-02-29 16:50:18 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class GermplasmPicker {
    public Germplasm getPrimaryGermplasm(StagingInventory stagingInventory, GermplasmListFetchStrategy germplasmListFetchStrategy) {
        Germplasm primaryGermplasm = null;

        List germplasms = germplasmListFetchStrategy.getGermplasms(stagingInventory);
        if (CollectionUtils.isEmpty(germplasms)) {
            primaryGermplasm = null;
        } else if (1 == germplasms.size()) {
            primaryGermplasm = (Germplasm) germplasms.get(0);
        } else {
            primaryGermplasm = createGermplasmPickerDAO(germplasms)
                    .getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();
        }

        return primaryGermplasm;
    }

    protected GermplasmPickerDAO createGermplasmPickerDAO(List germplasms) {
        return new GermplasmPickerDAO((Germplasm[]) germplasms.toArray(new Germplasm[0]));
    }
}