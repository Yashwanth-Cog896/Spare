/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: LineType.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class LineType {
    private Long lineTypeId;
    private String name;
    private String refActive;
    private String lineTypeRefId;
    private String pedEngRefId;

    public String getLineTypeRefId() {
        return lineTypeRefId;
    }

    public void setLineTypeRefId(String lineTypeRefId) {
        this.lineTypeRefId = lineTypeRefId;
    }

    public String getPedEngRefId() {
        return pedEngRefId;
    }

    public void setPedEngRefId(String pedEngRefId) {
        this.pedEngRefId = pedEngRefId;
    }

    public Long getLineTypeId() {
        return lineTypeId;
    }

    public void setLineTypeId(Long lineTypeId) {
        this.lineTypeId = lineTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}