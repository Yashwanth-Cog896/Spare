/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: UserRole.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class UserRole {

    public String getUserGlobalRoleId() {
        return userGlobalRoleId;
    }

    public void setUserGlobalRoleId(String userGlobalRoleId) {
        this.userGlobalRoleId = userGlobalRoleId;
    }

    public String getMidasUserId() {
        return midasUserId;
    }

    public void setMidasUserId(String midasUserId) {
        this.midasUserId = midasUserId;
    }

    public String getMidasRoleId() {
        return midasRoleId;
    }

    public void setMidasRoleId(String midasRoleId) {
        this.midasRoleId = midasRoleId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    private String userGlobalRoleId;
    private String midasUserId;
    private String midasRoleId;
    private String refActive;
}