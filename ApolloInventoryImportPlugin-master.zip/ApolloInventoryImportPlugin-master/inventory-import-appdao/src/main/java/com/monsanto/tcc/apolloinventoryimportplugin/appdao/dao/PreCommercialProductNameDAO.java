package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 21, 2008 Time: 9:52:15 AM To change this template use File |
 * Settings | File Templates.
 */
public class PreCommercialProductNameDAO extends ProductNameDAO {
    public PreCommercialProductNameDAO(String cropName) {
        super(cropName);
    }

    protected void addCriteriaForProductType(String alias, Criteria criteria) {
        criteria.createAlias(alias + ".brand", "br")
                .add(Restrictions.eq("br.name", "MONSANTO").ignoreCase())
                .add(Restrictions.or(Restrictions.eq("br.refActive", "T").ignoreCase(), Restrictions.eq("br.refActive", "y").ignoreCase()))
//        .add(Restrictions.eq("br.refActive", "T"))
                .createAlias("br.company", "cm")
                .add(Restrictions.eq("cm.name", "MONSANTO").ignoreCase())
                .add(Restrictions.eq("cm.refActive", "T"));
    }
}
