/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: ALineFunctionCriteriaWithoutCytoplasmDonor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class ALineFunctionCriteriaWithoutCytoplasmDonor implements LineFunctionCriteria {
    public void addCriteria(String alias, Criteria criteria) {
        criteria.createAlias(alias + ".lineFunction", "lfunc")
                .add(Restrictions.eq("lfunc.lineFunctionRefId", LineFunctionConstants.A_LINE_FUNCTION))
                .add(Restrictions.eq("lfunc.refActive", "T"));
    }

    public void addStagingInventoryCriteria(String alias, Criteria criteria) {
        criteria.add(Restrictions.eq(alias + ".lineFunction", LineFunctionConstants.A_LINE_FUNCTION));
    }
}