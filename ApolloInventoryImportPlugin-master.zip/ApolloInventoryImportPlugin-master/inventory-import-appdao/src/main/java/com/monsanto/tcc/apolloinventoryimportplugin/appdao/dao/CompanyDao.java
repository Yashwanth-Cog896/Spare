package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 20, 2010
 * Time: 4:58:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyDao {

    public boolean isValidCompany(String companyName) {
        boolean valid = false;
        if (companyName != null && !"".equals(companyName.trim())) {
            Session session = getSession();
            Query query = session.getNamedQuery("get.count.for.given.cropname");
            query.setParameter("companyName", companyName);
            Long cropVegetativeStructureCount = (Long) query.uniqueResult();
            if (cropVegetativeStructureCount.longValue() > 0) {
                valid = true;
            }
        }
        return valid;
    }

    protected org.hibernate.classic.Session getSession() {
        return HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

}
