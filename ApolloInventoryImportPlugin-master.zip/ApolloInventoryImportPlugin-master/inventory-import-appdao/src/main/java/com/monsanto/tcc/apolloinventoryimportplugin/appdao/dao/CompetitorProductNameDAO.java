package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 21, 2008 Time: 9:52:15 AM To change this template use File |
 * Settings | File Templates.
 */
public class CompetitorProductNameDAO extends ProductNameDAO {
    public CompetitorProductNameDAO(String cropName) {
        super(cropName);
    }

    protected void addCriteriaForProductType(String alias, Criteria criteria) {
        criteria.createAlias(alias + ".brand", "br")
                .add(Restrictions.or(Restrictions.eq("br.refActive", "T").ignoreCase(), Restrictions.eq("br.refActive", "y").ignoreCase()))
//        .add(Restrictions.eq("br.refActive", "T"))
                .createAlias("br.company", "cm")
                .add(Restrictions.ne("cm.name", "MONSANTO").ignoreCase())
                .add(Restrictions.eq("cm.refActive", "T"));
    }
}

