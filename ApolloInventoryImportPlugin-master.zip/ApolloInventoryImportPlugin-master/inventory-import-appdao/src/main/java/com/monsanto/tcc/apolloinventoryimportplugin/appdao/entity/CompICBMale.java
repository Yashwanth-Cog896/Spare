/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: CompICBMale.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class CompICBMale {
    private Long compICBMaleId;
    private GeneticMaterial geneticMaterial;
    private Crop crop;
    private String refActive;

    public Long getCompICBMaleId() {
        return compICBMaleId;
    }

    public void setCompICBMaleId(Long compICBMaleId) {
        this.compICBMaleId = compICBMaleId;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}