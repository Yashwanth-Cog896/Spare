/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: BrLoc.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class BrLoc {
    private String brLocId;
    private String countryId;
    private String homeLoc;
    private BrProg brProg;

    public BrProg getBrProg() {
        return brProg;
    }

    public void setBrProg(BrProg brProg) {
        this.brProg = brProg;
    }

    public String getBrLocId() {
        return brLocId;
    }

    public void setBrLocId(String brLocId) {
        this.brLocId = brLocId;
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getHomeLoc() {
        return homeLoc;
    }

    public void setHomeLoc(String homeLoc) {
        this.homeLoc = homeLoc;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    private String refActive;
}