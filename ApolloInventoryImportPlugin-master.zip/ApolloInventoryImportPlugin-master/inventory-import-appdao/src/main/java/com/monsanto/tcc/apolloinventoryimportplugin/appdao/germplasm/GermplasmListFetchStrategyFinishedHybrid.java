/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.HybridGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyFinishedHybrid.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * srkarna $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author skumar5
 * @version $Revision: 1.1 $
 */
public class GermplasmListFetchStrategyFinishedHybrid extends AbstractGermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        return createHybridGermplasmDAO(stagingInventory.getInventoryHeader().getCropName(),
                getDefaultLineFunctionCriteria(stagingInventory)).getFinishedGermplasms(stagingInventory.getOrigin());
    }

    protected HybridGermplasmDAO createHybridGermplasmDAO(String cropName,
                                                          LineFunctionCriteria lineFunctionCriteria) {
        return new HybridGermplasmDAO(cropName, lineFunctionCriteria);
    }

    @Override
    protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
        return createHybridGermplasmDAO(stagingInventory.getInventoryHeader().getCropName(), getDefaultLineFunctionCriteria(stagingInventory)).getFinishedGermplasmCriteria(stagingInventory.getOrigin());
    }

    @Override
    protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
        return new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
    }
}