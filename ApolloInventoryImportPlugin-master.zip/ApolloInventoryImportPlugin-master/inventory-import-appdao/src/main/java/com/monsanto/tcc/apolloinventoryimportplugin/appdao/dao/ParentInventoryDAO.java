package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: May 11, 2009
 * Time: 7:01:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class ParentInventoryDAO {


    public boolean isParentInventoryExists(Inventory childInventory, Inventory parentInventory) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        Query query = session.getNamedQuery("get.existing.parentInventory");
        query.setParameter("childInventory", childInventory);
        query.setParameter("parentInventory", parentInventory);

        List parentInventories = query.list();

        return (parentInventories != null && parentInventories.size() > 0);

    }

}
