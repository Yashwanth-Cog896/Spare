/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: LineFunctionCriteriaFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class LineFunctionCriteriaFactory {
    private StagingInventory inventory;

    public LineFunctionCriteriaFactory(StagingInventory inventory) {
        if (inventory == null) {
            throw new IllegalArgumentException("StagingInventory is required");
        }
        this.inventory = inventory;
    }

    public LineFunctionCriteria getLineFunctionCriteria() {
        if (StringUtils.isNullOrEmpty(inventory.getLineFunction())) {
            return new NullLineFunctionCriteria();
        }
        if (LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(inventory.getLineFunction().trim())) {
            if (StringUtils.isNullOrEmpty(inventory.getCytoplasmDonorPedigree())) {
                return new ALineFunctionCriteriaWithoutCytoplasmDonor();
            } else {
                return new ALineFunctionCriteria(inventory.getCytoplasmDonorPedigree());
            }
        }
        return new NonALineFunctionCriteria(inventory.getLineFunction());
    }
}