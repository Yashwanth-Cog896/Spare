package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 20, 2010
 * Time: 3:26:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class DefaultGermplasmListFetchStrategy implements GermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        return new ArrayList();
    }

    public List getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory) {
        return new ArrayList();
    }

    @Override
    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}