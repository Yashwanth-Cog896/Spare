package com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty.select;

import org.hibernate.Criteria;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 15, 2010
 * Time: 3:04:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmRoyaltyCriteriaFactory {

    public static Criteria addActiveGermplasmRoyaltyCriteria(String alias, Criteria criteria) {
        return new ActiveGermplasmRoyaltyCriteria().
                add(alias, criteria);
    }

}
