package com.monsanto.tcc.apolloinventoryimportplugin.appdao.business;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.GermplasmPickerDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductNameProductGermplasm;

import java.util.ArrayList;
import java.util.List;

public class ProductGermplasmFinder {

    public List<ProductNameProductGermplasm> getProductNameProductGermplasmList(
            List productGermplasmList, List productNameList) {
        List<ProductNameProductGermplasm> parentProductGermplasmWrapperList = new ArrayList<ProductNameProductGermplasm>();
        for (int i = 0; i < productGermplasmList.size(); i++) {
            ProductGermplasm productGermplasm = (ProductGermplasm) productGermplasmList
                    .get(i);
            for (int j = 0; j < productNameList.size(); j++) {
                ProductName productName = (ProductName) productNameList.get(j);
                if (productGermplasm.getProduct().getId().equals(
                        productName.getProduct().getId())) {
                    ProductNameProductGermplasm wrapper = new ProductNameProductGermplasm();
                    wrapper.setProductGermplasm(productGermplasm);
                    wrapper.setProductName(productName);
                    parentProductGermplasmWrapperList.add(wrapper);
                    break;
                }
            }
        }
        return parentProductGermplasmWrapperList;
    }

    public ProductNameProductGermplasm getPrimaryProductNameProductGermplasm(
            List productNameGermplasmList) {
        if (productNameGermplasmList == null || productNameGermplasmList.size() == 0) {
            return null;
        }
        if (productNameGermplasmList.size() == 1) {
            return (ProductNameProductGermplasm) productNameGermplasmList.get(0);
        }
        List<Germplasm> germplasms = getGermplasmListFromProductNameGermplasmList(productNameGermplasmList);
        GermplasmPickerDAO germplasmpicker = createGermplasmPickerDAO(germplasms);
        Germplasm germplasm = germplasmpicker
                .getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials();
        return getProductNameProductGermplasmFromProductNameGermplasmList(
                productNameGermplasmList, germplasm);

    }

    public List<Germplasm> getGermplasmListFromProductNameGermplasmList(
            List productNameGermplasmList) {
        List<Germplasm> germplasmList = new ArrayList<Germplasm>();
        if (productNameGermplasmList != null
                && productNameGermplasmList.size() > 0) {
            for (Object aProductNameGermplasmList : productNameGermplasmList) {
                ProductGermplasm productGermplasm = ((ProductNameProductGermplasm) aProductNameGermplasmList)
                        .getProductGermplasm();
                germplasmList.add(productGermplasm.getGermplasm());
            }
        }
        return germplasmList;
    }

    public ProductNameProductGermplasm getProductNameProductGermplasmFromProductNameGermplasmList(
            List productNameGermplasmList, Germplasm germplasm) {
        if (productNameGermplasmList != null) {
            for (Object aProductNameGermplasmList : productNameGermplasmList) {
                ProductNameProductGermplasm productNameGermplasm = (ProductNameProductGermplasm) aProductNameGermplasmList;
                if (productNameGermplasm.getProductGermplasm().getGermplasm().getId().equals(germplasm.getId())) {
                    return productNameGermplasm;
                }
            }
        }
        return null;
    }

    protected GermplasmPickerDAO createGermplasmPickerDAO(List<Germplasm> germplasms) {
        return new GermplasmPickerDAO((Germplasm[]) germplasms
                .toArray(new Germplasm[0]));
    }
}