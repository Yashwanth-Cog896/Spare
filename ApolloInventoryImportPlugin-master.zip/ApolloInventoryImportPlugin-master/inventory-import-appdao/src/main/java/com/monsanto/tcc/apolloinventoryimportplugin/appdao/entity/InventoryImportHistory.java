/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.Date;

/**
 * Filename:    $RCSfile: InventoryImportHistory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class InventoryImportHistory {
    private Long inventoryImportHistoryId;
    private Inventory inventory;
    private Long requestorUserId;
    private Long authorityUserId;
    private Long approverUserId;
    private Date requestDate;
    private Date validationDate;
    private Date approvalDate;
    private Date unarchiveDate;
    private String transgenic;
    private String exposureHistoryKnown;
    private String allergensPresent;
    private String toxinsPresent;
    private String animalGenePresent;
    private String miniChromosome;
    private String fromMfg;
    private String mfgBatchNumber;
    private String mfgAcronymNumber;
    private String mfgMaterialNumber;

    public Long getInventoryImportHistoryId() {
        return inventoryImportHistoryId;
    }

    public void setInventoryImportHistoryId(Long inventoryImportHistoryId) {
        this.inventoryImportHistoryId = inventoryImportHistoryId;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Long getRequestorUserId() {
        return requestorUserId;
    }

    public void setRequestorUserId(Long requestorUserId) {
        this.requestorUserId = requestorUserId;
    }

    public Long getAuthorityUserId() {
        return authorityUserId;
    }

    public void setAuthorityUserId(Long authorityUserId) {
        this.authorityUserId = authorityUserId;
    }

    public Long getApproverUserId() {
        return approverUserId;
    }

    public void setApproverUserId(Long approverUserId) {
        this.approverUserId = approverUserId;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getValidationDate() {
        return validationDate;
    }

    public void setValidationDate(Date validationDate) {
        this.validationDate = validationDate;
    }

    public Date getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(Date approvalDate) {
        this.approvalDate = approvalDate;
    }

    public Date getUnarchiveDate() {
        return unarchiveDate;
    }

    public void setUnarchiveDate(Date unarchiveDate) {
        this.unarchiveDate = unarchiveDate;
    }

    public String getTransgenic() {
        return transgenic;
    }

    public void setTransgenic(String transgenic) {
        this.transgenic = transgenic;
    }

    public String getExposureHistoryKnown() {
        return exposureHistoryKnown;
    }

    public void setExposureHistoryKnown(String exposureHistoryKnown) {
        this.exposureHistoryKnown = exposureHistoryKnown;
    }

    public String getAllergensPresent() {
        return allergensPresent;
    }

    public void setAllergensPresent(String allergensPresent) {
        this.allergensPresent = allergensPresent;
    }

    public String getToxinsPresent() {
        return toxinsPresent;
    }

    public void setToxinsPresent(String toxinsPresent) {
        this.toxinsPresent = toxinsPresent;
    }

    public String getAnimalGenePresent() {
        return animalGenePresent;
    }

    public void setAnimalGenePresent(String animalGenePresent) {
        this.animalGenePresent = animalGenePresent;
    }

    public String getMiniChromosome() {
        return miniChromosome;
    }

    public void setMiniChromosome(String miniChromosome) {
        this.miniChromosome = miniChromosome;
    }

    public String getFromMfg() {
        return fromMfg;
    }

    public void setFromMfg(String fromMfg) {
        this.fromMfg = fromMfg;
    }

    public String getMfgBatchNumber() {
        return mfgBatchNumber;
    }

    public void setMfgBatchNumber(String mfgBatchNumber) {
        this.mfgBatchNumber = mfgBatchNumber;
    }

    public String getMfgAcronymNumber() {
        return mfgAcronymNumber;
    }

    public void setMfgAcronymNumber(String mfgAcronymNumber) {
        this.mfgAcronymNumber = mfgAcronymNumber;
    }

    public String getMfgMaterialNumber() {
        return mfgMaterialNumber;
    }

    public void setMfgMaterialNumber(String mfgMaterialNumber) {
        this.mfgMaterialNumber = mfgMaterialNumber;
    }
}