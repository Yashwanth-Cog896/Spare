package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * User: rehigg
 * Date: Jan 27, 2011
 * Time: 10:54:34 AM
 */
public class TempSessionOcd {

    private TempSessionOcdId id;

    public TempSessionOcd() {
    }

    public TempSessionOcd(TempSessionOcdId x) {
        this.id = x;
    }

    public TempSessionOcdId getId() {
        return this.id;
    }

    public void setId(TempSessionOcdId x) {
        this.id = x;
    }
}
