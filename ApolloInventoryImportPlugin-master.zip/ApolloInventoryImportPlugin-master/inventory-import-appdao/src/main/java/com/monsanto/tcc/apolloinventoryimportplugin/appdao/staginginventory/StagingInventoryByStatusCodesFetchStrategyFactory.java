/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory;

import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.StagingInventoryFetchStrategyConstants;

/**
 * Filename:    $RCSfile: StagingInventoryByStatusCodesFetchStrategyFactory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: srkarna $     On:$Date: 2008-02-21 20:34:02 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class StagingInventoryByStatusCodesFetchStrategyFactory {
    private StagingInventoryByStatusCodesFetchStrategyFactory() {
    }

    public static StagingInventoryByStatusCodesFetchStrategy createStagingInventoryByStatusCodesFetchStrategy(
            String fetchStrategy, int fetchSize) {
        StagingInventoryByStatusCodesFetchStrategy stagingInventoryByStatusCodesFetchStrategy = null;

        if (StagingInventoryFetchStrategyConstants.INVENTORY_FETCH_STRATEGY_ECB.equalsIgnoreCase(fetchStrategy)) {
            stagingInventoryByStatusCodesFetchStrategy = new StagingInventoryFetchExcludingCurrentBatchRunStrategy(fetchSize);
        } else if (StagingInventoryFetchStrategyConstants.INVENTORY_FETCH_STRATEGY_ECBII.equalsIgnoreCase(fetchStrategy)) {
            stagingInventoryByStatusCodesFetchStrategy = new StagingInventoryFetchExcludingCurrentBatchRunAndInvalidInventoryStrategy(
                    fetchSize);
        } else if (StagingInventoryFetchStrategyConstants.INVENTORY_FETCH_STRATEGY_SIMPLE.equalsIgnoreCase(fetchStrategy)) {
            stagingInventoryByStatusCodesFetchStrategy = new SimpleStagingInventoryByStatusCodesFetchStrategy(fetchSize);
        } else { // default
            stagingInventoryByStatusCodesFetchStrategy = new SimpleStagingInventoryByStatusCodesFetchStrategy(fetchSize);
        }

        return stagingInventoryByStatusCodesFetchStrategy;
    }
}