/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.io.Serializable;

/**
 * Filename:    $RCSfile: SharedGenMatlBrProgPk.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class SharedGenMatlBrProgPk implements Serializable {
    private GeneticMaterial geneticMaterial;
    private BrProg brProg;

    public SharedGenMatlBrProgPk() {
    }

    public SharedGenMatlBrProgPk(GeneticMaterial geneticMaterial, BrProg brProg) {
        if (geneticMaterial == null || brProg == null) {
            throw new IllegalArgumentException("GeneticMaterial and BrProg required");
        }
        this.geneticMaterial = geneticMaterial;
        this.brProg = brProg;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public BrProg getBrProg() {
        return brProg;
    }

    public void setBrProg(BrProg brProg) {
        this.brProg = brProg;
    }

    public int hashCode() {
        return geneticMaterial.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj.getClass().equals(this.getClass()))) {
            return false;
        }
        final SharedGenMatlBrProgPk sharedGenMatlBrProgPk = (SharedGenMatlBrProgPk) obj;
        if (!geneticMaterial.getGeneticMaterialId()
                .equals(sharedGenMatlBrProgPk.getGeneticMaterial().getGeneticMaterialId())) {
            return false;
        }
        if (!brProg.getBrProgId().equals(sharedGenMatlBrProgPk.getBrProg().getBrProgId())) {
            return false;
        }
        return true;
    }
}