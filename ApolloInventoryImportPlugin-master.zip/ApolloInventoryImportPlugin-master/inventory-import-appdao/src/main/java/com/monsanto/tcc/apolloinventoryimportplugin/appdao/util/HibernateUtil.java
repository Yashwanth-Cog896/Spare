/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.util;

/**
 * Filename:    $RCSfile: HibernateUtil.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:08:08 $
 *
 * @author SSPEYY
 * @version $Revision: 1.5 $
 */

import org.hibernate.SessionFactory;

public class HibernateUtil {
    public static final String INVENTORY_IMPORT_HIBERNATE_URI = "com/monsanto/tcc/apolloinventoryimportplugin/appdao/hibernate/hibernateII.cfg.xml";

    private static SessionFactory sessionFactoryForInventoryImport;

    /*static {
        initializeSessionFactory();
    }

    public static void initializeSessionFactory() {
        if (sessionFactoryForInventoryImport != null) {
            return;
        }
        try {
            String env = EnvironmentHelper.getFunction();
            Configuration iiConfiguration = new Configuration().configure(INVENTORY_IMPORT_HIBERNATE_URI);
            Properties iiEnvProperties = iiConfiguration.getProperties();
            String decryptedSIPassword = getDecryptedPassword(iiEnvProperties, env);
            iiEnvProperties
                    .setProperty("hibernate.connection.url", iiEnvProperties.getProperty("connection.url." + env.trim()));
            iiEnvProperties.setProperty("hibernate.connection.password", decryptedSIPassword);
            iiEnvProperties.setProperty("show_sql", env.equalsIgnoreCase("win") ? "true" : "false");
            iiEnvProperties.setProperty("hibernate.show_sql", env.equalsIgnoreCase("win") ? "true" : "false");
            iiConfiguration.setProperties(iiEnvProperties);
            sessionFactoryForInventoryImport = iiConfiguration.buildSessionFactory();
        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }*/

//    public static void closeSessionFactory() {
//        if (sessionFactoryForInventoryImport != null) {
//            sessionFactoryForInventoryImport.close();
//            sessionFactoryForInventoryImport = null;
//        }
//    }

    public static SessionFactory getSessionFactoryForStagingInventory() {
        return sessionFactoryForInventoryImport;
    }

    public static SessionFactory getSessionFactoryForMidasCentral() {
        return sessionFactoryForInventoryImport;
    }

    public void setSessionFactoryForInventoryImport(SessionFactory sessionFactoryForInventoryImport) {
        this.sessionFactoryForInventoryImport = sessionFactoryForInventoryImport;
    }

    /* private static String getDecryptedPassword(Properties iiEnvProperties, String lsiFunction) throws EncryptorException {
        String keysFolder = new KeysFolderNameResolver().getKeyFolder(iiEnvProperties, lsiFunction);
        return EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV",
                keysFolder, "CipherValueSI.Base64", "KeyValueSI.hex");
    }*/
}