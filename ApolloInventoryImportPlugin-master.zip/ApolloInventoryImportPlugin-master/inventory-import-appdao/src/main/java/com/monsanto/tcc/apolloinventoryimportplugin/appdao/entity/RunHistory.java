/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.sql.Timestamp;

/**
 * Filename:    $RCSfile: RunHistory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class RunHistory {
    private Long id;
    private ProcessName processName;
    private Timestamp startDate;
    private Timestamp endDate;
    private RunStatus runStatus;
    private Long recordsProcessed;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ProcessName getProcessName() {
        return processName;
    }

    public void setProcessName(ProcessName processName) {
        this.processName = processName;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public RunStatus getRunStatus() {
        return runStatus;
    }

    public void setRunStatus(RunStatus runStatus) {
        this.runStatus = runStatus;
    }

    public Long getRecordsProcessed() {
        return recordsProcessed;
    }

    public void setRecordsProcessed(Long recordsProcessed) {
        this.recordsProcessed = recordsProcessed;
    }
}