package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.royalty.select.GermplasmRoyaltyCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.pedigree.PedigreeParser;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategySegpop.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: sspeyy
 * $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author DDBROW5
 * @version $Revision: 1.1 $
 */
public class GermplasmListFetchStrategySegpop implements GermplasmListFetchStrategy {

    public Criteria getGermplasmCountWithMatchOwnerCriteria(StagingInventory stagingInventory) {
        Criteria germplasmsCriteria = getGermplasmsListFetchCriteria(stagingInventory);
        if (germplasmsCriteria != null) {
            germplasmsCriteria.createAlias("gp.ownerBrProg", "prog")
                    .add(Restrictions.eq("prog.brProgRefId", stagingInventory.getGermplasmOwner()))
                    .setProjection(Projections.countDistinct("gp.id"));
        }
        return germplasmsCriteria;
    }

    public Criteria getGermplasmCountWithNoMatchOwnerCriteria(StagingInventory stagingInventory) {
        Criteria germplasmsCriteria = getGermplasmsListFetchCriteria(stagingInventory);
        if (germplasmsCriteria != null) {
            germplasmsCriteria.createAlias("gp.ownerBrProg", "prog")
                    .add(Restrictions.ne("prog.brProgRefId", stagingInventory.getGermplasmOwner()))
                    .setProjection(Projections.countDistinct("gp.id"));
        }
        return germplasmsCriteria;
    }

    public List getGermplasms(StagingInventory stagingInventory) {
        List germplasmList = new ArrayList();
        if (null != stagingInventory && null != stagingInventory.getOrigin()) {
            Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            Criteria criteria = getGermplasmCriteria(stagingInventory, session, stagingInventory.getOrigin(), stagingInventory.getLineage());
            addLineFunctionRestrictionToCriteria(stagingInventory, criteria, "gp");
            germplasmList = getGermplasms(criteria);
        }
        return germplasmList;
    }

    private List getGermplasms(Criteria criteria) {
        List germplasmList = new ArrayList();
        List geneticMaterialList;
        geneticMaterialList = criteria.list();

        if (geneticMaterialList != null && geneticMaterialList.size() > 0) {
            for (int i = 0; i < geneticMaterialList.size(); i++) {
                germplasmList.add(((GeneticMaterial) geneticMaterialList.get(i)).getGermplasm());
            }
        }
        return germplasmList;
    }

    private Criteria getGermplasmCriteria(StagingInventory stagingInventory, Session session, String origin, String lineage) {
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm");
        setLineageCriteria(lineage, criteria);
        criteria.createAlias("gm.germplasm", "gp")
                .createAlias("gp.lineType", "lt")
                .add(Expression.eq("lt.lineTypeRefId", "Segpop").ignoreCase())
                .add(Expression.eq("lt.refActive", "T"))
                .add(Expression.eq("gp.isDeleted", "F"))
                .add(Expression.eq("gp.origin", origin))
                .createAlias("gp.crop", "cr")
                .add(Expression.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))
                .add(Expression.eq("cr.refActive", "T"));
        return criteria;
    }

    public List getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory) {
        List germplasmList = new ArrayList();
        String origin = stagingInventory.getOrigin();
        String lineage = stagingInventory.getLineage();
        if (null != stagingInventory && origin == null && stagingInventory.getPedigreeName() != null) {
            PedigreeParser pedigreeParser = new PedigreeParser(stagingInventory.getPedigreeName());
            origin = pedigreeParser.getOriginOrLineCodeString();
            lineage = pedigreeParser.getLineageString();
        }
        if (null != stagingInventory && null != origin) {
            Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            Criteria criteria = getGermplasmCriteria(stagingInventory, session, origin, lineage);
            addLineFunctionRestrictionToCriteria(stagingInventory, criteria, "gp");
            addRoyaltyCriteria(criteria);
            germplasmList = getGermplasms(criteria);
        }
        return germplasmList;
    }

    @Override
    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory) {
        Criteria criteria = null;
        if (null != stagingInventory && null != stagingInventory.getOrigin()) {
            Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
            criteria = getGermplasmCriteria(stagingInventory, session, stagingInventory.getOrigin(), stagingInventory.getLineage());
            addLineFunctionRestrictionToCriteria(stagingInventory, criteria, "gp");
        }
        return criteria;

    }


    private void addRoyaltyCriteria(Criteria criteria) {
        criteria.createAlias("gp.germplasmRoyalty", "gpr");
        GermplasmRoyaltyCriteriaFactory.addActiveGermplasmRoyaltyCriteria("gpr", criteria);
    }


    private void setLineageCriteria(String lineage, Criteria criteria) {
        if (StringUtils.isNullOrEmpty(lineage)) {
            criteria.add(Expression.isNull("lineage"));
        } else {
            criteria.add(Expression.eq("lineage", lineage));
        }
    }

    public List getAllGermplasms(StagingInventory stagingInventory) {
        List germplasmList = new ArrayList();
        List geneticMaterialList;
        if (null != stagingInventory && null != stagingInventory.getOrigin()) {
            Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

            Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm");
            String lineage = stagingInventory.getLineage();
            setLineageCriteria(lineage, criteria);
            criteria.createAlias("gm.germplasm", "gp")
                    .createAlias("gp.lineType", "lt")
                    .add(Expression.eq("lt.lineTypeRefId", "Segpop").ignoreCase())
                    .add(Expression.eq("lt.refActive", "T"))
                    .add(Expression.eq("gp.origin", stagingInventory.getOrigin()))
                    .createAlias("gp.crop", "cr")
                    .add(Expression.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))
                    .add(Expression.eq("cr.refActive", "T"));

            addLineFunctionRestrictionToCriteria(stagingInventory, criteria, "gp");

            geneticMaterialList = criteria.list();

            if (geneticMaterialList != null && geneticMaterialList.size() > 0) {
                for (int i = 0; i < geneticMaterialList.size(); i++) {
                    germplasmList.add(((GeneticMaterial) geneticMaterialList.get(i)).getGermplasm());
                }
            }
        }
        return germplasmList;
    }

    private void addLineFunctionRestrictionToCriteria(StagingInventory stagingInventory, Criteria criteria,
                                                      String gpAlias) {
        LineFunctionCriteria lineFunctionCriteria1 = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
        lineFunctionCriteria1.addCriteria(gpAlias, criteria);
    }
}
