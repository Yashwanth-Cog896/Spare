package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Apr 27, 2009
 * Time: 2:19:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ParentInventory {

    private Long parentInventoryId;
    private Inventory inventory;
    private Inventory parentInventory;

    public Long getParentInventoryId() {
        return parentInventoryId;
    }

    public void setParentInventoryId(Long parentInventoryId) {
        this.parentInventoryId = parentInventoryId;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Inventory getParentInventory() {
        return parentInventory;
    }

    public void setParentInventory(Inventory parentInventory) {
        this.parentInventory = parentInventory;
    }
}