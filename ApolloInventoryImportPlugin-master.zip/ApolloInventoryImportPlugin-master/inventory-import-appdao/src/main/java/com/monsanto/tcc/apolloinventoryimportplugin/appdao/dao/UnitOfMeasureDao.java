package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.UnitOfMeasure;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Query;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class UnitOfMeasureDao {

    public static Collection<String> seedUOMs = Arrays.asList("SEED", "KILOGRAMS", "GRAMS", "POUNDS");

    public List<UnitOfMeasure> getSeedUOMs() {
        org.hibernate.Session session = getSession();
        Query query = session.getNamedQuery("get.all.inventory.unitOfMeasure");
        query.setParameterList("uomNames", seedUOMs);
        return query.list();
    }

    protected org.hibernate.classic.Session getSession() {
        return HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public boolean isValid(String seedQuantityUOM) {
        UnitOfMeasure unitOfMeasureByName = getUnitOfMeasureByName(seedQuantityUOM);
        return unitOfMeasureByName != null;

    }

    public UnitOfMeasure getUnitOfMeasureByName(String seedQuantityUOM) {
        if (!StringUtils.isNullOrEmpty(seedQuantityUOM)) {
            org.hibernate.Session session = getSession();
            Query query = session.getNamedQuery("get.unitOfMeasure.by.name");
            query.setParameter("uomName", seedQuantityUOM.toUpperCase());
            List<UnitOfMeasure> unitOfMeasures = (List<UnitOfMeasure>) query.list();
            if (!CollectionUtils.isEmpty(unitOfMeasures)) {
                return unitOfMeasures.get(0);
            }
        }
        return null;
    }
}
