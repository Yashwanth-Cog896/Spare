package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import java.util.Set;

/**
 * User: rehigg
 * Date: Jan 27, 2011
 * Time: 11:00:06 AM
 */
public interface TempSessionOcdDao {
    void insertNumberValues(Long requestId, Set<Long> ids);
}
