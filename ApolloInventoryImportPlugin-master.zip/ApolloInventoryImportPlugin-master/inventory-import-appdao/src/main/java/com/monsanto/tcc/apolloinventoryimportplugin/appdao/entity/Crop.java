/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: Crop.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class Crop {
    private Long cropId;
    private String cropName;
    private String refActive;
    private String genusSpecies;
    private String cropRefId;
    private String remCropId;
    private int rmMin;
    private int rmMax;
    private int rmIncrement;

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getGenusSpecies() {
        return genusSpecies;
    }

    public void setGenusSpecies(String genusSpecies) {
        this.genusSpecies = genusSpecies;
    }

    public String getCropRefId() {
        return cropRefId;
    }

    public void setCropRefId(String cropRefId) {
        this.cropRefId = cropRefId;
    }

    public int getRmMin() {
        return rmMin;
    }

    public void setRmMin(int rmMin) {
        this.rmMin = rmMin;
    }

    public int getRmMax() {
        return rmMax;
    }

    public void setRmMax(int rmMax) {
        this.rmMax = rmMax;
    }

    public int getRmIncrement() {
        return rmIncrement;
    }

    public void setRmIncrement(int rmIncrement) {
        this.rmIncrement = rmIncrement;
    }

    public String getRemCropId() {
        return remCropId;
    }

    public void setRemCropId(String remCropId) {
        this.remCropId = remCropId;
    }
}