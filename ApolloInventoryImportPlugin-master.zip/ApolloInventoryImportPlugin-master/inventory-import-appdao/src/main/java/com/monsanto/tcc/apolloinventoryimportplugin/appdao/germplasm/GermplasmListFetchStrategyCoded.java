/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyCoded.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5
 * $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class GermplasmListFetchStrategyCoded extends AbstractGermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        LineFunctionCriteria lineFunctionCriteria = getDefaultLineFunctionCriteria(stagingInventory);
        return getExistingCodedGermplasmList(stagingInventory, lineFunctionCriteria);
    }

    protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
        return lineFunctionCriteria;
    }

    public List getExistingCodedGermplasmList(StagingInventory stagingInventory,
                                              LineFunctionCriteria lineFunctionCriteria) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = getGermplasmsCriteria(stagingInventory, session);
        addLineFunictionCriteria(lineFunctionCriteria, criteria);
        return criteria.list();
    }

    private void addLineFunictionCriteria(LineFunctionCriteria lineFunctionCriteria, Criteria criteria) {
        lineFunctionCriteria.addCriteria("gp", criteria);
    }


    @Override
    protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.lineCode", stagingInventory.getLineCode()))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", MaterialTypeConstants.CODED_LINES))
                .add(Restrictions.eq("lt.refActive", "T"))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))
                .add(Restrictions.eq("cr.refActive", "T"));
        return criteria;
    }
}