package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.business.ProductGermplasmFinder;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.CompetitorProductNameDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.ProductGermPlasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.ProductNameDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductNameProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 28, 2008 Time: 12:22:12 PM To change this template use File |
 * Settings | File Templates.
 */
public class CompetitorParentMatchingOriginStrategy implements ParentageFetchStrategy {
    private String cropName;
    private final ProductGermplasmFinder productGermplasmFinder = new ProductGermplasmFinder();

    public CompetitorParentMatchingOriginStrategy(String cropName) {
        super();
        this.cropName = cropName;
    }

    public boolean checkIfParentsExists(String originComponent) {
        List productGermplasmList = fetchParentProductGermplasms(originComponent);
        return !((null == productGermplasmList) || (0 == productGermplasmList
                .size()));
    }

    public ProductNameProductGermplasm fetchProductNameProductGermplasm(String originComponent) {
        return productGermplasmFinder.getPrimaryProductNameProductGermplasm(fetchParentProductGermplasms(originComponent));
    }

    public List fetchParentProductGermplasms(String originComponent) {
        ProductGermPlasmDAO productGermPlasmDAO = createProductGermPlasmDAO();
        List productGermplasmList = productGermPlasmDAO
                .getProductGermplasmListMatchingOrigin(originComponent);
        if (productGermplasmList == null || productGermplasmList.size() == 0) {
            return new ArrayList();
        }
        List<Product> productList = getProductListFromProductGermplasmList(productGermplasmList);
        ProductNameDAO productNameDAO = createProductNameDAO();
        List productNameList = productNameDAO
                .getProductListMatchingProducts(productList);
        if (productNameList == null || productNameList.size() == 0) {
            return new ArrayList();
        }
        return productGermplasmFinder.getProductNameProductGermplasmList(productGermplasmList,
                productNameList);
    }

    protected ProductNameDAO createProductNameDAO() {
        return new CompetitorProductNameDAO(cropName);
    }

    protected List<Product> getProductListFromProductGermplasmList(
            List productGermplasmList) {
        List<Product> productList = new ArrayList<Product>();
        if (productGermplasmList != null && productGermplasmList.size() > 0) {
            for (Object aProductGermplasmList : productGermplasmList) {
                ProductGermplasm productGermplasm = (ProductGermplasm) aProductGermplasmList;
                productList.add(productGermplasm.getProduct());
            }
        }
        return productList;
    }

    protected ProductGermPlasmDAO createProductGermPlasmDAO() {
        return new ProductGermPlasmDAO(cropName, getLineTypes());
    }

    protected String[] getLineTypes() {
        return new String[]{MaterialTypeConstants.FINISHED_LINES,
                MaterialTypeConstants.HYBRID_LINES};
    }
}
