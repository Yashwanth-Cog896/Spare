/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: ICBMaleGermplasmGeneticMaterialDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * sspeyy $     On:$Date: 2008-06-03 15:27:12 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class ICBMaleGermplasmGeneticMaterialDAO {
    public static final String CROP_NAME_IS_REQUIRED_MSG = "cropName is required";
    public static final String LINE_FUNCTION_IS_REQUIRED_MSG = "lineFunctionRefId is required";

    private String cropName;
    private String lineFunctionRefId;

    public ICBMaleGermplasmGeneticMaterialDAO(String cropName) {
        if (StringUtils.isNullOrEmpty(cropName)) {
            throw new IllegalArgumentException(CROP_NAME_IS_REQUIRED_MSG);
        }
        this.cropName = cropName;
    }

    public ICBMaleGermplasmGeneticMaterialDAO(String cropName, String lineFunctionRefId) {
        this(cropName);
        this.lineFunctionRefId = lineFunctionRefId;
    }

    public GeneticMaterial getPrimaryGeneticMaterial(String source, String pedigree) {

        Germplasm primaryGermplasm = getPrimaryGermplasmForICBMale(source, pedigree);

        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        List list = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .add(Restrictions.eq("gm.germplasm", primaryGermplasm))
                .addOrder(Order.asc("gm.geneticMaterialId"))
                .list();

        GeneticMaterial geneticMaterial = null;
        if (null != list && list.size() > 0) {
            geneticMaterial = (GeneticMaterial) list.get(0);
        }

        return geneticMaterial;
    }

    protected Germplasm getPrimaryGermplasmForICBMale(String source, String pedigree) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("germplasm", "gp")
                .setProjection(Projections.projectionList().add(Projections.rowCount(), "gmByGpCount")
                        .add(Projections.groupProperty("gp.id")))
                .add(Restrictions.eq("gp.pedigreeName", pedigree))
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"));

        if (StringUtils.isNullOrEmpty(lineFunctionRefId)) {
            criteria.add(Restrictions.isNull("gp.lineFunction"));
        } else {
            criteria.createAlias("gp.lineFunction", "lf")
                    .add(Restrictions.eq("lf.lineFunctionRefId", lineFunctionRefId))
                    .add(Restrictions.eq("lf.refActive", "T"));
        }

        List list = criteria.list();

        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            Long germplasmId = (Long) obj[1];
            return (Germplasm) session.load(Germplasm.class, germplasmId);
        }

        return null;
    }

}