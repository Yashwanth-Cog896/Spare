/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename: $Id: SimpleStagingInventoryByStatusCodesFetchStrategy.java,v 1.1 2008-02-21 20:34:02 srkarna Exp $
 *
 * @author APATRO
 * @version $Revision: 1.1 $
 */
public class SimpleStagingInventoryByStatusCodesFetchStrategy implements StagingInventoryByStatusCodesFetchStrategy {
    private int fetchSize;

    public SimpleStagingInventoryByStatusCodesFetchStrategy() {
        this(0);
    }

    public SimpleStagingInventoryByStatusCodesFetchStrategy(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public StagingInventory[] getStagingInventoryRecords(String[] statusCodeList) {
        if (null == statusCodeList) {
            throw new IllegalArgumentException("statusCodeList is required");
        }

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        //TODO: This native SQL query SHOULD go into the mapping file!!
        StringBuffer sql = new StringBuffer();
        sql.append("select si.* from inventory_import_stage.STAGING_INVENTORY si ");
        sql.append("inner join INVENTORY_IMPORT_STAGE.STAGING_INVENTORY_HEADER sih on SIH.INVENTORY_HEADER_ID = si.inventory_header_id ");
        sql.append(
                "left outer join inventory_import_stage.STAGING_PARENTAGE sp on sp.PARENT_INVENTORY_ID = si.INVENTORY_ID, ");
        sql.append("inventory_import_stage.IMPORT_STATUS st ");
        sql.append("where si.IMPORT_STATUS_ID = st.IMPORT_STATUS_ID and st.STATUS_CODE in (:statusCodes) ");
        sql.append("and sp.PARENT_INVENTORY_ID is null ");
        sql.append("order by si.creation_date asc");

        SQLQuery query = session.createSQLQuery(limitQueryToFetchSize(sql.toString()));
        query.addEntity(StagingInventory.class);
        query.setParameterList("statusCodes", statusCodeList);

        List list = query.list();

        return (null != list) ? (StagingInventory[]) list.toArray(new StagingInventory[0]) : null;
    }

    private String limitQueryToFetchSize(String sql) {
        if (fetchSize > 0) {
            return "select * from (" + sql + ") where rownum <= " + fetchSize;
        }

        return sql;
    }
}
