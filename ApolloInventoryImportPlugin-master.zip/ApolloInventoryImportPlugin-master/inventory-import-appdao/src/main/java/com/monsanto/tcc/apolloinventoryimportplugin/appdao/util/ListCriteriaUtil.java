package com.monsanto.tcc.apolloinventoryimportplugin.appdao.util;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import java.util.List;

public class ListCriteriaUtil {

    // RESOLUTION: ORA-01795: If there are more than 1000 germplasms passed in this call will throw an ORA-01795
    // java.sql.SQLException: ORA-01795: maximum number of expressions in a list is 1000    
    public static Criterion addRestrictions(String propertyName, List list) {
        int size = list.size();
        int fromIndex = 0;
        int toIndex = (size > 999) ? 999 : size;
        List subList = list.subList(fromIndex, toIndex);
        Criterion lhs = Restrictions.in(propertyName, subList);
        toIndex = subList.size();
        size = size - toIndex;
        while (size > 0) {
            fromIndex = toIndex;
            toIndex += (size > 999) ? 999 : size;
            subList = list.subList(fromIndex, toIndex);
            Criterion rhs = Restrictions.in(propertyName, subList);
            lhs = Restrictions.or(lhs, rhs);
            size = size - subList.size();
        }//while
        return lhs;
    }
}