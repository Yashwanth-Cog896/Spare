/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;

/**
 * Filename:    $RCSfile: StagingInventoryByStatusCodesFetchStrategy.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-21 20:34:02 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public interface StagingInventoryByStatusCodesFetchStrategy {
    StagingInventory[] getStagingInventoryRecords(String[] statusCodeList);
}