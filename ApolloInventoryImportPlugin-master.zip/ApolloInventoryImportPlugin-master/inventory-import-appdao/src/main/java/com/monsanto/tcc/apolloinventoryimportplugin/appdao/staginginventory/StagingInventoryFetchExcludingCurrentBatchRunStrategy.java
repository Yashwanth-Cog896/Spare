/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.staginginventory;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import java.util.List;

/**
 * Filename:    $RCSfile: StagingInventoryFetchExcludingCurrentBatchRunStrategy.java,v $ Label:       $Name: not supported by cvs2svn $ Last
 * Change: $Author: srkarna $     On:$Date: 2008-02-21 20:34:02 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class StagingInventoryFetchExcludingCurrentBatchRunStrategy
        implements StagingInventoryByStatusCodesFetchStrategy {
    private int fetchSize;

    public StagingInventoryFetchExcludingCurrentBatchRunStrategy() {
        this(0);
    }

    public StagingInventoryFetchExcludingCurrentBatchRunStrategy(int fetchSize) {
        this.fetchSize = fetchSize;
    }

    public StagingInventory[] getStagingInventoryRecords(String[] statusCodeList) {
        if (null == statusCodeList) {
            throw new IllegalArgumentException("statusCodeList is required");
        }

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
        //TODO: This native SQL query SHOULD go into the mapping file!!
        String sql = "SELECT si.* "
                + "FROM "
                + "  inventory_import_stage.staging_inventory si "
                + "    INNER JOIN inventory_import_stage.staging_inventory_header sih "
                + "    ON si.inventory_header_id = sih.inventory_header_id "
                + "    LEFT OUTER JOIN inventory_import_stage.staging_parentage sp "
                + "    ON sp.parent_inventory_id =  si.inventory_id, "
                + "  inventory_import_stage.import_status st "
                + "WHERE si.import_status_id = st.import_status_id "
                + "AND st.status_code IN (:statusCodes) "
                + "AND sp.parent_inventory_id IS NULL "
                + "AND NOT EXISTS ( "
                + "  SELECT * "
                + "  FROM "
                + "    inventory_import_stage.run_history rh, "
                + "    inventory_import_stage.run_detail rd "
                + "  WHERE rh.end_date IS NULL "
                + "  AND rd.run_history_id = rh.run_history_id "
                + "  AND rd.inventory_id = si.inventory_id "
                + ") "
                + "ORDER BY si.creation_date ASC";

        SQLQuery query = session.createSQLQuery(limitQueryToFetchSize(sql));
        query.addEntity("si", StagingInventory.class);
        query.setParameterList("statusCodes", statusCodeList);

        List list = query.list();

        return (null != list) ? (StagingInventory[]) list.toArray(new StagingInventory[0]) : null;
    }

    private String limitQueryToFetchSize(String sql) {
        if (fetchSize > 0) {
            return "select * from (" + sql + ") where rownum <= " + fetchSize;
        }

        return sql;
    }
}