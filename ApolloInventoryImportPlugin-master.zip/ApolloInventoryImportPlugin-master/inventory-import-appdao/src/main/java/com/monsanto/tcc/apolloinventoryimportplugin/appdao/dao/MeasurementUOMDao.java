package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.MeasurementUOM;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Query;

public class MeasurementUOMDao {

    public MeasurementUOM getEnglishMeasurementUOMByUomId(Long uomId) {
        org.hibernate.Session session = getSession();
        Query query = session.getNamedQuery("get.english.measurmentuom.by.uomid");
        query.setParameter("uomId", uomId);
        return (MeasurementUOM) query.uniqueResult();
    }

    protected org.hibernate.classic.Session getSession() {
        return HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

}
