/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategy.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public interface GermplasmListFetchStrategy {

    public List getGermplasms(StagingInventory stagingInventory);

    public List getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory);

    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory);
}