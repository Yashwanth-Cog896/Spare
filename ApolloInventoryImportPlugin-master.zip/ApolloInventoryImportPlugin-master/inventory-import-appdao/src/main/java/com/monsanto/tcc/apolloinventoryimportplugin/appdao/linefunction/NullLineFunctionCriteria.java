/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: NullLineFunctionCriteria.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NullLineFunctionCriteria implements LineFunctionCriteria {
    public void addCriteria(String alias, Criteria criteria) {
        criteria.add(Restrictions.isNull(alias + ".lineFunction"));
    }

    public void addStagingInventoryCriteria(String alias, Criteria criteria) {
        criteria.add(Restrictions.isNull(alias + ".lineFunction"));
    }
}