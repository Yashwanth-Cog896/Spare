/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.exception;

/**
 * Filename:    $RCSfile: MidasUserNotActiveOrNotExistsException.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-03-13 20:55:38 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class MidasUserNotActiveOrNotExistsException extends Exception {
    public MidasUserNotActiveOrNotExistsException(String msg) {
        super(msg);
    }
}