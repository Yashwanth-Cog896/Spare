/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyFinished.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * apatro $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class GermplasmListFetchStrategyFinished extends AbstractGermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        return getExistingFinishedGermplasmList(stagingInventory, getDefaultLineFunctionCriteria(stagingInventory));
    }

    public List getExistingGermplasmList(StagingInventory stagingInventory) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();

        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.lineCode", stagingInventory.getLineCode()))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))
                .add(Restrictions.eq("cr.refActive", "T"));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return criteria.list();
    }

    private List getExistingFinishedGermplasmList(StagingInventory stagingInventory,
                                                  LineFunctionCriteria lineFunctionCriteria) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = getGermplasmsCriteria(stagingInventory, session);
        lineFunctionCriteria.addCriteria("gp", criteria);
        return criteria.list();
    }

    @Override
    protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
        return session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.lineCode", stagingInventory.getLineCode()))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", "Finished"))
                .add(Restrictions.eq("lt.refActive", "T"))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()))
                .add(Restrictions.eq("cr.refActive", "T"));
    }

    @Override
    protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
        return new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
    }
}