/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmListFetchStrategyFinishedWithoutLineCode.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change:
 * $Author: srkarna $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.1 $
 */
public class GermplasmListFetchStrategyFinishedWithoutLineCode extends AbstractGermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        return getExistingFinishedGermplasmList(stagingInventory, getDefaultLineFunctionCriteria(stagingInventory));
    }

    private List getExistingFinishedGermplasmList(StagingInventory stagingInventory,
                                                  LineFunctionCriteria lineFunctionCriteria) {
        Session session = this.getCurrentSession();
        Criteria criteria = getGermplasmsCriteria(stagingInventory, session);
        lineFunctionCriteria.addCriteria("gp", criteria);
        return criteria.list();
    }

    @Override
    protected Criteria getGermplasmsCriteria(StagingInventory stagingInventory, Session session) {
        return session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.origin", stagingInventory.getOrigin()))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", "Finished"))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", stagingInventory.getInventoryHeader().getCropName()));
    }

    @Override
    protected LineFunctionCriteria getDefaultLineFunctionCriteria(StagingInventory stagingInventory) {
        return new LineFunctionCriteriaFactory(stagingInventory)
                .getLineFunctionCriteria();
    }

    protected Session getCurrentSession() {
        return HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }
}