/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: SharedGenMatlBrProg.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class SharedGenMatlBrProg {
    private SharedGenMatlBrProgPk id;

    public SharedGenMatlBrProgPk getId() {
        return id;
    }

    public void setId(SharedGenMatlBrProgPk id) {
        this.id = id;
    }
}