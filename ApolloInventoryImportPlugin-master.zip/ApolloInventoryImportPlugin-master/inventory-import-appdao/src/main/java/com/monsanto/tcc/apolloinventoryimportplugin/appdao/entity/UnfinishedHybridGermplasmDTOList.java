/*
 UnfinishedHybridGermplasmDTOList was created on May 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: UnfinishedHybridGermplasmDTOList.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-03-10 15:59:37 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class UnfinishedHybridGermplasmDTOList {
    private List data = null;

    public UnfinishedHybridGermplasmDTOList(List data) {
        this.data = (null != data) ? data : new ArrayList();
    }

    public UnfinishedHybridGermplasmDTO get(String origin, String gpOwner, String isDeleted) {
        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO = null;

        UnfinishedHybridGermplasmDTO criteria = new UnfinishedHybridGermplasmDTO();
        criteria.setOrigin(origin);
        criteria.setBrProgRefId(gpOwner);
        criteria.setDeleted(isDeleted);

        int idx = data.indexOf(criteria);
        if (idx >= 0) {
            unfinishedHybridGermplasmDTO = (UnfinishedHybridGermplasmDTO) data.get(idx);
        }

        return unfinishedHybridGermplasmDTO;
    }

    public int getOverallCountOfGermplasms() {
        int cnt = 0;
        for (int i = 0; i < data.size(); i++) {
            UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO = (UnfinishedHybridGermplasmDTO) data.get(i);
            cnt += unfinishedHybridGermplasmDTO.getCount();
        }

        return cnt;
    }

    public int size() {
        return data.size();
    }
}