/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridGermplasmDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $ On:$Date:
 * 2007/05/15 20:15:00 $
 *
 * @author skumar5
 * @version $Revision: 1.16 $
 */
public class HybridGermplasmDAO {
    public static final String CROP_LINEFUNCTION_REQ_MSG = "cropName and lineFunctionCriteria are required.";
    public static final String ORIGIN_REQ_MSG = "Origin is required.";
    private static final String FINISHED = "T";
    private static final String LINE_TYPE = "Hybrid";
    private static final String REF_ACTIVE_T = "T";

    private Session session;
    private String cropName;
    private LineFunctionCriteria lineFunctionCriteria;

    public HybridGermplasmDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_LINEFUNCTION_REQ_MSG);
        }
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public List getFinishedGermplasms(String origin) {
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(ORIGIN_REQ_MSG);
        }

        List germplasmList;
        Criteria criteria = getFinishedGermplasmCriteria(origin);
        lineFunctionCriteria.addCriteria("gp", criteria);

        germplasmList = criteria.list();

        return germplasmList;
    }

    public Criteria getFinishedGermplasmCriteria(String origin) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", FINISHED))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));
        return criteria;
    }

    public List getFinishedGermplasmsExcludingLineFunction(String origin) {
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(ORIGIN_REQ_MSG);
        }

        List germplasmList;
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", FINISHED))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));
        germplasmList = criteria
                .list();

        return germplasmList;
    }

    public Germplasm getPrimaryGermplasm_FinishedHybridOriginExist(String origin) {
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("germplasm", "gp")
                .setProjection(Projections.projectionList().add(Projections.rowCount(), "gmByGpCount")
                        .add(Projections.groupProperty("gp.id")))
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", FINISHED))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", "Hybrid"))
                .add(Restrictions.eq("lt.refActive", "T"))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"));

        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"))
                .list();

        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            Long germplasmId = (Long) obj[1];
            return (Germplasm) session.load(Germplasm.class, germplasmId);
        }
        return null;
    }

    public List getAllGermplasms_FinishedOrUnfinished(String origin) {
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(ORIGIN_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .addOrder(Order.desc("gp.isFinishedOrFinishedChild"));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return criteria.list();
    }

    //TODO: Move this to a different dao. Does not belong here

    public String getOriginMatchingPedigree(String lineType, String pedigreeName) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "c")
                .add(Restrictions.eq("c.cropName", cropName))
                .add(Restrictions.eq("c.refActive", REF_ACTIVE_T))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        addDistinctProjection(criteria, "gp.origin");
        lineFunctionCriteria.addCriteria("gp", criteria);
        return (String) criteria.uniqueResult();
    }

    //TODO: Move this to a different dao. Does not belong here

    public String getOriginMatchingOrigin(String lineType, String origin) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "c")
                .add(Restrictions.eq("c.cropName", cropName))
                .add(Restrictions.eq("c.refActive", REF_ACTIVE_T))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        addDistinctProjection(criteria, "gp.origin");
        lineFunctionCriteria.addCriteria("gp", criteria);
        return (String) criteria.uniqueResult();
    }

    //TODO: Move this to a different dao. Does not belong here

    public String getOriginMatchingLineCode(String lineType, String lineCode) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "c")
                .add(Restrictions.eq("c.cropName", cropName))
                .add(Restrictions.eq("c.refActive", REF_ACTIVE_T))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        addDistinctProjection(criteria, "gp.origin");
        lineFunctionCriteria.addCriteria("gp", criteria);
        return (String) criteria.uniqueResult();
    }

    //TODO: Move this to a different dao. Does not belong here

    public String getOriginMatchingSourceAndPedigree(String lineType, String pedigreeName,
                                                     String source) {

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "c")
                .add(Restrictions.eq("c.cropName", cropName))
                .add(Restrictions.eq("c.refActive", REF_ACTIVE_T))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        addDistinctProjection(criteria, "gp.origin");
        lineFunctionCriteria.addCriteria("gp", criteria);
        return (String) criteria.uniqueResult();
    }

    //TODO: Move this to a different dao. Does not belong here

    public String getOriginMatchingSourceAndOrigin(String lineType, String origin, String source) {

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "c")
                .add(Restrictions.eq("c.cropName", cropName))
                .add(Restrictions.eq("c.refActive", REF_ACTIVE_T))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        addDistinctProjection(criteria, "gp.origin");
        lineFunctionCriteria.addCriteria("gp", criteria);
        return (String) criteria.uniqueResult();
    }

    //TODO: Move this to a different dao. Does not belong here

    public String getOriginMatchingSourceAndLineCode(String lineType, String lineCode, String source) {

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.crop", "c")
                .add(Restrictions.eq("c.cropName", cropName))
                .add(Restrictions.eq("c.refActive", REF_ACTIVE_T))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.lineTypeRefId", lineType).ignoreCase())
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        addDistinctProjection(criteria, "gp.origin");
        lineFunctionCriteria.addCriteria("gp", criteria);
        return (String) criteria.uniqueResult();
    }

    private void addDistinctProjection(Criteria criteria, String distinctField) {
        criteria.setProjection(Projections
                .distinct(Projections.projectionList()
                        .add(Projections.property(distinctField))));
    }
}