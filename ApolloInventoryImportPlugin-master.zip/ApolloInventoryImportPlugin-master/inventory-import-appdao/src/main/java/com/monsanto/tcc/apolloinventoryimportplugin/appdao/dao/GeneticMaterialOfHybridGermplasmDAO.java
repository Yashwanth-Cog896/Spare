/*
 GeneticMaterialOfHybridGermplasmDAO was created on Feb 27, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: GeneticMaterialOfHybridGermplasmDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-02-29 17:20:38 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class GeneticMaterialOfHybridGermplasmDAO {
    public static final String GERMPLASM_IS_REQUIRED = "germplasm is required.";
    public static final String GERMPLAM_IS_NOT_HYBRID = "provided germplam is not hybrid";
    private Session session = null;
    private Germplasm germplasm = null;

    public GeneticMaterialOfHybridGermplasmDAO(Germplasm germplasm) {
        if (null == germplasm) {
            throw new IllegalArgumentException(GERMPLASM_IS_REQUIRED);
        }
        if (!MaterialTypeConstants.HYBRID_LINES.equalsIgnoreCase(getLineType(germplasm))) {
            throw new IllegalArgumentException(GERMPLAM_IS_NOT_HYBRID);
        }

        this.germplasm = germplasm;
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    private String getLineType(Germplasm germplasm) {
        return ((null != germplasm.getLineType()) ? germplasm.getLineType().getLineTypeRefId() : null);
    }

    public GeneticMaterial getPrimaryGeneticMaterial() {
        GeneticMaterial geneticMaterial = null;

        String sql = "SELECT gm " +
                " FROM Parentage p1, Parentage p2, GeneticMaterial gm " +
                " WHERE p1.geneticMaterial = gm " +
                " AND p1.parentalRole.parentalRoleRefId = 'F' " +
                " AND p2.geneticMaterial = gm " +
                " AND p2.parentalRole.parentalRoleRefId = 'M' " +
                " AND gm.germplasm = :gp " +
                " ORDER BY gm.geneticMaterialId ASC ";

        Query query = session.createQuery(sql);
        query.setParameter("gp", germplasm);

        List geneticMaterialsList = query.list();
        if (isNotEmpty(geneticMaterialsList)) {
            geneticMaterial = (GeneticMaterial) geneticMaterialsList.get(0);
        }

        return geneticMaterial;
    }

    public GeneticMaterial getParentOfPrimaryGeneticMaterial(String parentalRole) {
        GeneticMaterial geneticMaterial = getPrimaryGeneticMaterial();

        GeneticMaterial parentGeneticMaterial = (GeneticMaterial) session.createCriteria(Parentage.class, "p")
                .add(Restrictions.eq("p.geneticMaterial", geneticMaterial))
                .createAlias("p.parentalRole", "role")
                .add(Restrictions.eq("role.parentalRoleRefId", parentalRole))
                .setProjection(Property.forName("p.parentGeneticMaterial"))
                .uniqueResult();

        return parentGeneticMaterial;
    }

    private boolean isNotEmpty(List rows) {
        return ((null != rows) && (rows.size() > 0));
    }
}