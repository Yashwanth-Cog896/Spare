package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Brand;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Product;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductName;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteriaFactory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GermplasmListFetchStrategyForCommercial implements GermplasmListFetchStrategy {
    private static final String HYBRID = "Hybrid";
    private static final String FINISHED = "Finished";
    private static final String COMPANY_MONSANTO = "MONSANTO";

    public List getGermplasms(StagingInventory si) {
        List germplasmListForProduct = getGermplasmListForCommercialProduct(si);
        return germplasmListMatchingOriginOrLineCode(germplasmListForProduct, si);
    }

    public List getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory) {
        return new ArrayList();  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public List getGermplasmListForCommercialProduct(StagingInventory si) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        List productList = getProductList(session, si);
        productList = getProducListMatchingBrandNameIfBrandNameNotNull(si, productList);
        return getGermplasmListFromProductGermplasmList(getProductGermplasmList(session, si, productList));
    }

    private List getGermplasmListFromProductGermplasmList(List productGermplasmList) {
        List<Germplasm> germplasmList = new ArrayList<Germplasm>();
        if (productGermplasmList != null && productGermplasmList.size() > 0) {
            for (int i = 0; i < productGermplasmList.size(); i++) {
                ProductGermplasm productGermplasm = (ProductGermplasm) productGermplasmList.get(i);
                germplasmList.add(productGermplasm.getGermplasm());
            }
        }
        return germplasmList;
    }

    private List getProductGermplasmList(Session session, StagingInventory si, List tempProductList) {

        List productGermplasmList = new ArrayList();
        if (tempProductList == null || tempProductList.size() == 0) {
            return productGermplasmList;
        }
        LineFunctionCriteria lineFunctionCriteria = new LineFunctionCriteriaFactory(si).getLineFunctionCriteria();
        Criteria criteria = session.createCriteria(ProductGermplasm.class, "pg")
                .createAlias("pg.germplasm", "gp")
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.or(Restrictions.eq("lt.name", HYBRID), Restrictions.eq("lt.name", FINISHED)))
                .add(Restrictions.eq("lt.refActive", "T"))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", "T"))
                .add(Restrictions.in("pg.product", tempProductList));
        lineFunctionCriteria.addCriteria("gp", criteria);
        productGermplasmList = criteria.list();
        return productGermplasmList;
    }

    private List getProductList(Session session, StagingInventory si) {
        Criteria criteria = session.createCriteria(ProductName.class, "pn")
                .setProjection(Projections.distinct(Projections.projectionList()
                        .add(Projections.property("pn.product"))
                        .add(Projections.property("pn.brand"))))
                .createAlias("pn.product", "pr")
                .createAlias("pn.brand", "br")
                .createAlias("br.company", "cp")
                .createAlias("pr.crop", "cr")
                .add(Restrictions.eq("pn.name", si.getProductName()).ignoreCase())
                .add(Restrictions.eq("cp.name", COMPANY_MONSANTO).ignoreCase())
                .add(Restrictions.eq("br.refActive", "T"))
                .add(Restrictions.eq("pn.refActive", "T"))
                .add(Restrictions.eq("pr.refActive", "T"))
                .add(Restrictions.eq("cr.cropName", si.getInventoryHeader().getCropName()).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"));
        return criteria.list();
    }

    private List germplasmListMatchingOriginOrLineCode(List<Germplasm> germplasmList, StagingInventory si) {
        List<Germplasm> gpList = new ArrayList<Germplasm>();
        for (Germplasm currentGermplasm : germplasmList) {
            addWhenOriginOrLineCodeMatch(gpList, currentGermplasm, si);
        }
        return gpList;
    }

    private void addWhenOriginOrLineCodeMatch(List<Germplasm> gpList, Germplasm currentGermplasm, StagingInventory si) {
        if (HYBRID.equalsIgnoreCase(si.getLineType())
                && currentGermplasm.getOrigin() != null
                && currentGermplasm.getOrigin().equals(si.getOrigin())) {
            gpList.add(currentGermplasm);
        } else if (FINISHED.equalsIgnoreCase(si.getLineType())
                && currentGermplasm.getLineCode() != null
                && currentGermplasm.getLineCode().equals(si.getLineCode())) {
            gpList.add(currentGermplasm);
        }
    }

    protected List getProducListMatchingBrandNameIfBrandNameNotNull(StagingInventory stagingInventory, List productBrandList) {
        List productListMatchingBrandName = null;
        if (productBrandList != null) {
            if (productBrandList.size() == 1) {
                productListMatchingBrandName = getProductObjectsFromProductBrandList(productBrandList);
            } else if (!isBrandNameProvided(stagingInventory.getBrandName())) {
                productListMatchingBrandName = getProductObjectsFromProductBrandList(productBrandList);
            } else {
                productListMatchingBrandName = getProductObjectsWhoseBrandNameMatches(productBrandList, stagingInventory.getBrandName());
            }
        }
        return productListMatchingBrandName;
    }

    protected List getProductObjectsWhoseBrandNameMatches(List productBrandList, String brandName) {
        List<Product> productList = new ArrayList<Product>();
        if (productBrandList != null && productBrandList.size() > 0) {
            for (Iterator iter = productBrandList.iterator(); iter.hasNext();) {
                Object[] productBrand = (Object[]) iter.next();
                if (getBrandNameOrEmptyString((Brand) productBrand[1]).equalsIgnoreCase(brandName)) {
                    productList.add((Product) productBrand[0]);
                }
            }
        }
        return productList.size() == 0 ? null : productList;
    }

    protected List getProductObjectsFromProductBrandList(List productBrandList) {
        List<Product> productList = new ArrayList<Product>();
        if (productBrandList != null && productBrandList.size() > 0) {
            for (Iterator iter = productBrandList.iterator(); iter.hasNext();) {
                Object[] productBrand = (Object[]) iter.next();
                productList.add((Product) productBrand[0]);
            }
        }
        return productList.size() == 0 ? null : productList;
    }

    private String getBrandNameOrEmptyString(Brand brand) {
        String brandName = "";
        if (brand != null && !StringUtils.isNullOrEmpty(brand.getName())) {
            brandName = brand.getName();
        }
        return brandName;
    }

    private boolean isBrandNameProvided(String brandName) {
        return !StringUtils.isNullOrEmpty(brandName);
    }
}