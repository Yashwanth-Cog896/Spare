package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;
import org.hibernate.Query;
import org.hibernate.Session;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 9, 2009
 * Time: 2:00:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropVegetativeStrucutreDAO {

    public boolean isVegetativeStructureValid(String vegetativeStrucutre, String cropName) {
        boolean valid = false;
        if (vegetativeStrucutre != null && !"".equals(vegetativeStrucutre.trim())) {
            Session session = getSession();
            Query query = session.getNamedQuery("get.count.for.given.crop.and.vegetativestructure");
            query.setParameter("vegetativeStrucutre", vegetativeStrucutre);
            query.setParameter("cropName", cropName);
            Long cropVegetativeStructureCount = (Long) query.uniqueResult();
            if (cropVegetativeStructureCount.longValue() > 0) {
                valid = true;
            }
        }
        return valid;
    }

    protected org.hibernate.classic.Session getSession() {
        return HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public List<VegetativeStructure> getVegetativeStructuresByCrop(List<String> cropNames) {
        Session session = getSession();
        Query query = session.getNamedQuery("get.vegetativestructures.for.given.crop");
        if (cropNames != null && cropNames.size() > 0) {
            query.setParameterList("cropnames", cropNames);
            return query.list();
        }
        return null;
    }


    public boolean isCropHasBulbOrRootVegetativeStructure(String cropName) {
        Session session = getSession();
        Query query = session.getNamedQuery("is.crop.has.bulb.or.root.vegetativestructure");
        query.setParameter("cropnames", cropName);
        Long cropVegetativeStructures = (Long) query.uniqueResult();
        return cropVegetativeStructures.longValue() > 0;
    }
}
