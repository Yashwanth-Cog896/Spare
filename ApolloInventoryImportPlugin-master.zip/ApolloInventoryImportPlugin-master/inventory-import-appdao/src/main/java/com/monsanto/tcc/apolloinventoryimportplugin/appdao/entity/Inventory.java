/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.tcc.apolloinventoryimportplugin.common.vegetativestructure.VegetativeStructure;

import java.util.Date;
import java.util.Set;

/**
 * Filename:    $RCSfile: Inventory.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date: 2009-06-05 14:07:48 $
 *
 * @author skumar5
 * @version $Revision: 1.2 $
 */
public class Inventory {
    private Long inventoryId;
    private BrProg program;
    private GeneticMaterial geneticMaterial;
    private InventoryType inventoryType;
    private String isActive;
    private String archivedMaterial;
    private String checkIndicator;
    private String asort1;
    private String asort2;
    private String asort3;
    private String asort4;
    private String asort5;
    private Double nsort1;
    private Double nsort2;
    private Double nsort3;
    private Double nsort4;
    private Double nsort5;
    private Date creationDate;

    private Set inventoryImportHistory;
    private Set sharedInventory;

    private String barCode;

    private VegetativeStructure vegetativeStructure;

    private Double quantity;
    private Long quantityUOMId;

    public Inventory() {
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public BrProg getProgram() {
        return program;
    }

    public void setProgram(BrProg program) {
        this.program = program;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public InventoryType getInventoryType() {
        return inventoryType;
    }

    public void setInventoryType(InventoryType inventoryType) {
        this.inventoryType = inventoryType;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String active) {
        isActive = active;
    }

    public String getArchivedMaterial() {
        return archivedMaterial;
    }

    public void setArchivedMaterial(String archivedMaterial) {
        this.archivedMaterial = archivedMaterial;
    }

    public String getCheckIndicator() {
        return checkIndicator;
    }

    public void setCheckIndicator(String checkIndicator) {
        this.checkIndicator = checkIndicator;
    }

    public String getAsort1() {
        return asort1;
    }

    public void setAsort1(String aSort1) {
        this.asort1 = aSort1;
    }

    public String getAsort2() {
        return asort2;
    }

    public void setAsort2(String aSort2) {
        this.asort2 = aSort2;
    }

    public String getAsort3() {
        return asort3;
    }

    public void setAsort3(String aSort3) {
        this.asort3 = aSort3;
    }

    public String getAsort4() {
        return asort4;
    }

    public void setAsort4(String aSort4) {
        this.asort4 = aSort4;
    }

    public String getAsort5() {
        return asort5;
    }

    public void setAsort5(String aSort5) {
        this.asort5 = aSort5;
    }

    public Double getNsort1() {
        return nsort1;
    }

    public void setNsort1(Double nSort1) {
        this.nsort1 = nSort1;
    }

    public Double getNsort2() {
        return nsort2;
    }

    public void setNsort2(Double nSort2) {
        this.nsort2 = nSort2;
    }

    public Double getNsort3() {
        return nsort3;
    }

    public void setNsort3(Double nSort3) {
        this.nsort3 = nSort3;
    }

    public Double getNsort4() {
        return nsort4;
    }

    public void setNsort4(Double nSort4) {
        this.nsort4 = nSort4;
    }

    public Double getNsort5() {
        return nsort5;
    }

    public void setNsort5(Double nSort5) {
        this.nsort5 = nSort5;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Set getInventoryImportHistory() {
        return inventoryImportHistory;
    }

    public void setInventoryImportHistory(Set inventoryImportHistory) {
        this.inventoryImportHistory = inventoryImportHistory;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public Set getSharedInventory() {
        return sharedInventory;
    }

    public void setSharedInventory(Set sharedInventory) {
        this.sharedInventory = sharedInventory;
    }

    public VegetativeStructure getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(VegetativeStructure vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Long getQuantityUOMId() {
        return quantityUOMId;
    }

    public void setQuantityUOMId(Long quantityUOMId) {
        this.quantityUOMId = quantityUOMId;
    }
}