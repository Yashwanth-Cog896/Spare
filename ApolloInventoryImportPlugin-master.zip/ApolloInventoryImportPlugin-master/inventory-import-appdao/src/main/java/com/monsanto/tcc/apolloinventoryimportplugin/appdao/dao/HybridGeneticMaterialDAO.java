/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridGeneticMaterialDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ddbrow5 $     On:$Date: 2008-04-14 17:56:09 $
 *
 * @author ddbrow5
 * @version $Revision: 1.2 $
 */
public class HybridGeneticMaterialDAO {
    public static final String CROP_NAME_REQ_MSG = "cropName is required.";
    public static final String SOURCE_REQ_MSG = "Source is required.";
    public static final String PEDIGREE_NAME_REQ_MSG = "Pedigree name is required.";
    private static final String LINE_TYPE = "Hybrid";
    private static final String REF_ACTIVE_T = "T";

    private Session session = null;
    private String cropName = null;
    private String source = null;

    public HybridGeneticMaterialDAO(String source, String cropName) {
        if (StringUtils.isNullOrEmpty(source)) {
            throw new IllegalArgumentException(SOURCE_REQ_MSG);
        }
        if (StringUtils.isNullOrEmpty(cropName)) {
            throw new IllegalArgumentException(CROP_NAME_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.source = source;
    }

    public GeneticMaterial getLowestGeneticMaterialMatchingPedigreeName(String pedigreeName) {
        if (StringUtils.isNullOrEmpty(pedigreeName)) {
            throw new IllegalArgumentException(PEDIGREE_NAME_REQ_MSG);
        }
        List list = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .setProjection(Projections.projectionList().add(Projections.count("gp.id"), "gmByGpCount")
                        .add(Projections.groupProperty("gp.id"))
                        .add(Projections.groupProperty("gp.isFinishedOrFinishedChild"))
                        .add(Projections.groupProperty("gp.isDeleted")))
                .addOrder(Order.desc("gp.isFinishedOrFinishedChild"))
                .addOrder(Order.asc("gp.isDeleted"))
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"))
                .list();

        Germplasm germplasm = null;
        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            Long germplasmId = (Long) obj[1];
            germplasm = (Germplasm) session.load(Germplasm.class, germplasmId);
        }
        return getLowestGeneticMaterialMatchingGermplasm(germplasm);
    }

    public GeneticMaterial getLowestGeneticMaterialMatchingGermplasm(Germplasm germplasm) {
        GeneticMaterial geneticMaterial = null;
        if (null != germplasm) {
            List list = session.createCriteria(GeneticMaterial.class, "gm")
                    .add(Restrictions.eq("gm.germplasm", germplasm))
                    .addOrder(Order.asc("gm.id"))
                    .list();
            if (null != list && list.size() > 0) {
                geneticMaterial = (GeneticMaterial) list.get(0);
            }
        }
        return geneticMaterial;
    }
}