/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: InventoryType.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SKUMAR5
 * @version $Revision: 1.1 $
 */
public class InventoryType {
    private String inventoryTypeId;
    private Crop crop;
    private String name;
    private String lineTypeRefId;
    private String active;
    private String refActive;

    public String getInventoryTypeId() {
        return inventoryTypeId;
    }

    public void setInventoryTypeId(String inventoryTypeId) {
        this.inventoryTypeId = inventoryTypeId;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLineTypeRefId() {
        return lineTypeRefId;
    }

    public void setLineTypeRefId(String lineTypeRefId) {
        this.lineTypeRefId = lineTypeRefId;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

}