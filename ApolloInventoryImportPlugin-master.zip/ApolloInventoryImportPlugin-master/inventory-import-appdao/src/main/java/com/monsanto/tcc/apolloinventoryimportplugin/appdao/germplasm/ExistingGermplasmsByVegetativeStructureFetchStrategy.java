package com.monsanto.tcc.apolloinventoryimportplugin.appdao.germplasm;


import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.GermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 12, 2009
 * Time: 3:46:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExistingGermplasmsByVegetativeStructureFetchStrategy implements GermplasmListFetchStrategy {
    public List getGermplasms(StagingInventory stagingInventory) {
        GermplasmDAO germplasmDAO = getGermplasmDAO(stagingInventory);
        return germplasmDAO.getExistingGermplasmsByVegetativeStructure(stagingInventory);
    }

    protected GermplasmDAO getGermplasmDAO(StagingInventory stagingInventory) {
        return new GermplasmDAO(stagingInventory.getInventoryHeader().getCropName());
    }

    public List getGermplasmsWithActiveRoyalties(StagingInventory stagingInventory) {
        return new ArrayList();
    }

    @Override
    public Criteria getGermplasmsListFetchCriteria(StagingInventory stagingInventory) {
        return null;
    }
}
