/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.Set;

/**
 * Filename:    $RCSfile: Germplasm.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $     On:$Date:
 * 2007/02/21 16:58:33 $
 *
 * @author SSPEYY
 * @version $Revision: 1.3 $
 */
public class Germplasm {

    private Long id;
    private String origin;
    private String lineCode;
    private Crop crop;
    private LineType lineType;
    private String isDeleted;
    private BrProg ownerBrProg;
    private String isFinishedOrFinishedChild;
    private String pedigreeName;
    private String isTransgenic;
    private String oldPedigree;
    private String eventDisplay;
    private String constructDisplay;
    private Set germplasmEventConstruct;
    private LineFunction lineFunction;
    private String cytoplasmDonor;
    private Set germplasmRoyalty;
    private String restriction;

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getIsTransgenic() {
        return isTransgenic;
    }

    public void setIsTransgenic(String transgenic) {
        isTransgenic = transgenic;
    }

    public String getDeleted() {
        return isDeleted;
    }

    public void setDeleted(String deleted) {
        isDeleted = deleted;
    }

    public String getFinishedOrFinishedChild() {
        return isFinishedOrFinishedChild;
    }

    public void setFinishedOrFinishedChild(String finishedOrFinishedChild) {
        isFinishedOrFinishedChild = finishedOrFinishedChild;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }


    public BrProg getOwnerBrProg() {
        return ownerBrProg;
    }

    public void setOwnerBrProg(BrProg ownerBrProg) {
        this.ownerBrProg = ownerBrProg;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getIsFinishedOrFinishedChild() {
        return isFinishedOrFinishedChild;
    }

    public void setIsFinishedOrFinishedChild(String isFinishedOrFinishedChild) {
        this.isFinishedOrFinishedChild = isFinishedOrFinishedChild;
    }


    public LineType getLineType() {
        return lineType;
    }

    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }

    public String getTransgenic() {
        return isTransgenic;
    }

    public void setTransgenic(String transgenic) {
        isTransgenic = transgenic;
    }

    public String getOldPedigree() {
        return oldPedigree;
    }

    public void setOldPedigree(String oldPedigree) {
        this.oldPedigree = oldPedigree;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public Set getGermplasmEventConstruct() {
        return germplasmEventConstruct;
    }

    public void setGermplasmEventConstruct(Set germplasmEventConstruct) {
        this.germplasmEventConstruct = germplasmEventConstruct;
    }

    public LineFunction getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(LineFunction lineFunction) {
        this.lineFunction = lineFunction;
    }

    public String getCytoplasmDonor() {
        return cytoplasmDonor;
    }

    public void setCytoplasmDonor(String cytoplasmDonor) {
        this.cytoplasmDonor = cytoplasmDonor;
    }

    public Set getGermplasmRoyalty() {
        return germplasmRoyalty;
    }

    public void setGermplasmRoyalty(Set germplasmRoyalty) {
        this.germplasmRoyalty = germplasmRoyalty;
    }

    public String getRestriction() {
        return restriction;
    }

    public void setRestriction(String restriction) {
        this.restriction = restriction;
    }
}