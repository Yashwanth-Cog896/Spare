/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: BrandPreference.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date:
 * 2006/12/18 16:51:55 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class BrandPreference {

    private Long brandPreferenceId;
    private Brand brand;
    private BrProg brProg;
    private Long rank;

    public Long getBrandPreferenceId() {
        return brandPreferenceId;
    }

    public void setBrandPreferenceId(Long brandPreferenceId) {
        this.brandPreferenceId = brandPreferenceId;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public BrProg getBrProg() {
        return brProg;
    }

    public void setBrProg(BrProg brProg) {
        this.brProg = brProg;
    }

    public Long getRank() {
        return rank;
    }

    public void setRank(Long rank) {
        this.rank = rank;
    }
}