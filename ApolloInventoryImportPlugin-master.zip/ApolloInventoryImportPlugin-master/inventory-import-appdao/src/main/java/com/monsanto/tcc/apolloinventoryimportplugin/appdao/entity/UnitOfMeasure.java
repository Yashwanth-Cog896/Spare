package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;


public class UnitOfMeasure {

    private Long uomId;
    private String name;
    private String refActive;
    private String uomRefId;

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getUomRefId() {
        return uomRefId;
    }

    public void setUomRefId(String uomRefId) {
        this.uomRefId = uomRefId;
    }
}
