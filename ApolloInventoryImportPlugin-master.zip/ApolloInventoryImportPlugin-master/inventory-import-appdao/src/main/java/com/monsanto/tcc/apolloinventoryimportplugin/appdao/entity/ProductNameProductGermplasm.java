package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Apr 1, 2008 Time: 12:29:59 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProductNameProductGermplasm {
    private ProductGermplasm productGermplasm;

    public ProductName getProductName() {
        return productName;
    }

    public void setProductName(ProductName productName) {
        this.productName = productName;
    }

    private ProductName productName;

    public ProductGermplasm getProductGermplasm() {
        return productGermplasm;
    }

    public void setProductGermplasm(ProductGermplasm productGermplasm) {
        this.productGermplasm = productGermplasm;
    }

}
