/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.util.Date;

/**
 * Filename:    $RCSfile: GermplasmEventConstruct.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class GermplasmEventConstruct {
    private Long germplasmEventConstructId;
    private EventConstruct eventConstruct;
    private Germplasm germplasm;
    private Date absenceDate;


    public Long getGermplasmEventConstructId() {
        return germplasmEventConstructId;
    }

    public void setGermplasmEventConstructId(Long germplasmEventConstructId) {
        this.germplasmEventConstructId = germplasmEventConstructId;
    }

    public EventConstruct getEventConstruct() {
        return eventConstruct;
    }

    public void setEventConstruct(EventConstruct eventConstruct) {
        this.eventConstruct = eventConstruct;
    }

    public Germplasm getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }

    public Date getAbsenceDate() {
        return absenceDate;
    }

    public void setAbsenceDate(Date absenceDate) {
        this.absenceDate = absenceDate;
    }
}