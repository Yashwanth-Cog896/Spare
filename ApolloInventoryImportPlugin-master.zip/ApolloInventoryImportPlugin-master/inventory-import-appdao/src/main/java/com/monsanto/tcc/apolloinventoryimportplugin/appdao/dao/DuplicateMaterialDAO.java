package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Inventory;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.*;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Aug 12, 2008 Time: 2:26:53 PM To change this template use File |
 * Settings | File Templates.
 */
public class DuplicateMaterialDAO {

    private String crop;

    public DuplicateMaterialDAO(String crop) {
        this.crop = crop;
    }

    public int getCountForForArchivedMaterialWithParentage(String pedigreeName, String source, String lineType) {

        Session session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();

        DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Parentage.class, "pa")
                .setProjection(Property.forName("pa.geneticMaterial"))
                .add(Property.forName("pa.geneticMaterial.id").eqProperty("gm.id"));

        Number count = (Number) session.createCriteria(Inventory.class, "in")
                .add(Restrictions.eq("in.archivedMaterial", "F"))
                .createAlias("in.geneticMaterial", "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.refActive", "T"))
                .add(Restrictions.eq("cr.cropName", crop).ignoreCase())
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.refActive", "T"))
                .add(Restrictions.eq("lt.lineTypeRefId", lineType))
                .add(Subqueries.notExists(detachedCriteria))
                .setProjection(Projections.count("in.inventoryId")).uniqueResult();

        return count.intValue();

    }
}

