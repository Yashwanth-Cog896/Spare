/*
 UnfinishedHybridGermplasmDAO was created on May 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.UnfinishedHybridGermplasmDTO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.UnfinishedHybridGermplasmDTOList;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import java.util.List;

/**
 * Filename:    $RCSfile: UnfinishedHybridGermplasmDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-03-10 15:59:37 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class UnfinishedHybridGermplasmDAO {
    public static final String CROP_NAME_REQ_MSG = "cropName is required.";
    public static final String CROP_LINEFUNCTION_REQ_MSG = "cropName and lineFunctionCriteria are required.";
    public static final String ORIGIN_REQ_MSG = "Origin is required.";
    private static final String UNFINISHED = "F";
    private static final String LINE_TYPE = "Hybrid";
    private static final String REF_ACTIVE_T = "T";

    private Session session = null;
    private String cropName = null;
    private LineFunctionCriteria lineFunctionCriteria;

    public UnfinishedHybridGermplasmDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_LINEFUNCTION_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public UnfinishedHybridGermplasmDTOList getGermplasmsCountMatchingOriginGroupByOwnerAndIsDeleted(String origin) {
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(ORIGIN_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .createAlias("gp.lineType", "lt")
                .createAlias("gp.crop", "cr")
                .createAlias("gp.ownerBrProg", "brp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", UNFINISHED))
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .add(Restrictions.eq("brp.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        List resultList = criteria
                .setProjection(Projections.projectionList()
                        .add(Projections.groupProperty("gp.origin").as("origin"))
                        .add(Projections.groupProperty("brp.brProgRefId").as("brProgRefId"))
                        .add(Projections.groupProperty("gp.isDeleted").as("isDeleted"))
                        .add(Projections.count("gp.isDeleted").as("count")))
                .setResultTransformer(Transformers.aliasToBean(UnfinishedHybridGermplasmDTO.class))
                .list();

        return new UnfinishedHybridGermplasmDTOList(resultList);
    }

    public List getGermplasmsMatchingOrigin(String origin) {
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(ORIGIN_REQ_MSG);
        }
        Criteria criteria = getGermplasmCriteria(origin);
        return criteria.list();
    }

    public Criteria getGermplasmCriteria(String origin) {
        Criteria criteria = session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", UNFINISHED))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));
        lineFunctionCriteria.addCriteria("gp", criteria);
        criteria.createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));
        return criteria;
    }
}