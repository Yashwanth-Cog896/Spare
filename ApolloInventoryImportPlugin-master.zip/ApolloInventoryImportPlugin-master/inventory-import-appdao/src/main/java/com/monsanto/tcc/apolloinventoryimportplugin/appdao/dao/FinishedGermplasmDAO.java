package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.List;

public class FinishedGermplasmDAO {
    public static final String CROP_LINEFUNC_CRITERIA_REQ_MSG = "cropName and lineFunctionCriteria are required.";
    public static final String LINECODE_REQ_MSG = "Line Code is required.";
    private static final String LINE_TYPE = "Finished";
    private static final String REF_ACTIVE_T = "T";
    private static final String IS_DELETED_F = "F";

    private Session session = null;
    private String cropName = null;
    private LineFunctionCriteria lineFunctionCriteria;

    public FinishedGermplasmDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_LINEFUNC_CRITERIA_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        this.cropName = cropName;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public Germplasm getPrimaryGermplasm(String lineCode, String generation) {
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("germplasm", "gp")
                .setProjection(Projections.projectionList().add(Projections.rowCount(), "gmByGpCount")
                        .add(Projections.groupProperty("gm.germplasm"))
                        .add(Projections.groupProperty("gp.id"))
                )
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", "T"));
        if (generation != null && !"INBRED".equals(generation)) {
            criteria.add(Restrictions.eq("gm.generation", generation));
        }

        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"))
                .list();

        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            return (Germplasm) obj[1];
        }

        return null;
    }

    public Germplasm getPrimaryGermplasmForParentExistValidation(String lineCode) {
        List list = getPrimaryGermplasmList(lineCode);
        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            return (Germplasm) obj[1];
        }
        return null;
    }

    public Germplasm[] getPrimaryGermplasms(String lineCode) {
        List list = getPrimaryGermplasmList(lineCode);
        if (null != list && list.size() > 0) {
            List germplasmList = new ArrayList();
            for (int i = 0; i < list.size(); i++) {
                Object[] obj = (Object[]) list.get(i);
                germplasmList.add(obj[1]);
            }
            return (Germplasm[]) germplasmList.toArray(new Germplasm[0]);
        }
        return null;
    }

    private List getPrimaryGermplasmList(String lineCode) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("gm.germplasm", "gp")
                .setProjection(Projections.projectionList().add(Projections.rowCount(), "gmByGpCount")
                        .add(Projections.groupProperty("gm.germplasm"))
                        .add(Projections.groupProperty("gp.id"))
                )
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", "T"));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return criteria
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", "T"))
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"))
                .list();
    }

    public List getAllGermplasmsExcludingLineFunction(String linecode) {
        if (StringUtils.isNullOrEmpty(linecode)) {
            throw new IllegalArgumentException(LINECODE_REQ_MSG);
        }

        Criteria criteria = getCriteriaForAllGermplasms(linecode)
                .addOrder(Order.asc("gp.isDeleted"));

        return criteria.list();
    }

    public List getAllGermplasms(String linecode) {
        if (StringUtils.isNullOrEmpty(linecode)) {
            throw new IllegalArgumentException(LINECODE_REQ_MSG);
        }

        Criteria criteria = getCriteriaForAllGermplasms(linecode)
                .add(Restrictions.eq("gp.isDeleted", IS_DELETED_F));

        lineFunctionCriteria.addCriteria("gp", criteria);

        return criteria.list();
    }

    private Criteria getCriteriaForAllGermplasms(String lineCode) {
        return session.createCriteria(Germplasm.class, "gp")
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T));
    }
}