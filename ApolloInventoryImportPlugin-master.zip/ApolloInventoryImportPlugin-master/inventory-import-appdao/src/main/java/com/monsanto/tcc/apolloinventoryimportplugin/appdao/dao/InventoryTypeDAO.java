/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.InventoryType;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: InventoryTypeDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-18 04:26:05 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class InventoryTypeDAO {
    public static final String LINE_TYPE_AND_CROP_NAME_REQUIRED_MSG = "lineType and cropName are required";
    public static final String INVALID_LINE_TYPE_MSG = "Invalid lineType ";

    public InventoryType getInventoryType(String lineType, String cropName) {
        if (StringUtils.isNullOrEmpty(lineType) || StringUtils.isNullOrEmpty(cropName)) {
            throw new IllegalArgumentException(LINE_TYPE_AND_CROP_NAME_REQUIRED_MSG);
        }

        String inventoryTypeLineType = convertLineTypeToInventoryTypeLineType(lineType);

        if (StringUtils.isNullOrEmpty(inventoryTypeLineType)) {
            throw new IllegalArgumentException(INVALID_LINE_TYPE_MSG + lineType);
        }

        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        InventoryType inventoryType = (InventoryType) session.createCriteria(InventoryType.class, "it")
                .createCriteria("it.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("it.lineTypeRefId", inventoryTypeLineType))
                .add(Restrictions.eq("it.name", getInventoryTypeName(inventoryTypeLineType)))
                .add(Restrictions.eq("it.refActive", "T"))
                .add(Restrictions.eq("it.active", "T"))
                .uniqueResult();

        return inventoryType;
    }

    private String getInventoryTypeName(String inventoryTypeLineType) {
        char[] name = inventoryTypeLineType.toLowerCase().toCharArray();

        name[0] = new String(new char[]{name[0]}).toUpperCase().charAt(0);

        StringBuffer buffer = new StringBuffer();
        buffer.append("Active ").append(name);

        return buffer.toString();
    }

    private String convertLineTypeToInventoryTypeLineType(String lineType) {
        String inventoryTypeLineType = null;

        if (lineType.equalsIgnoreCase("Finished")) {
            inventoryTypeLineType = "INBRED";
        } else if (lineType.equalsIgnoreCase("Coded") || lineType.equalsIgnoreCase("Segpop")) {
            inventoryTypeLineType = "SEGPOP";
        } else if (lineType.equalsIgnoreCase("Hybrid")) {
            inventoryTypeLineType = "HYBRID";
        }

        return inventoryTypeLineType;
    }
}