/*
 * Copyright � 2006, 2007, Monsanto.  All rights reserved.
 * This software was produced using Monsanto resources and is the sole property of Monsanto.
 * Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
 */
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.io.Serializable;

/**
 * Filename:    $RCSfile: SharedParentageBrProgPk.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author apatro
 * @version $Revision: 1.1 $
 */
public class SharedParentageBrProgPk implements Serializable {
    private Parentage parentage;
    private BrProg brProg;

    public SharedParentageBrProgPk() {
    }

    public SharedParentageBrProgPk(Parentage parentage, BrProg brProg) {
        if (parentage == null || brProg == null) {
            throw new IllegalArgumentException("Parentage and BrProg required");
        }
        this.parentage = parentage;
        this.brProg = brProg;
    }

    public Parentage getParentage() {
        return parentage;
    }

    public void setParentage(Parentage parentage) {
        this.parentage = parentage;
    }

    public BrProg getBrProg() {
        return brProg;
    }

    public void setBrProg(BrProg brProg) {
        this.brProg = brProg;
    }

    public int hashCode() {
        return parentage.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj.getClass().equals(this.getClass()))) {
            return false;
        }
        final SharedParentageBrProgPk sharedParentageBrProgPk = (SharedParentageBrProgPk) obj;
        if (!parentage.getParentageId().equals(sharedParentageBrProgPk.getParentage().getParentageId())) {
            return false;
        }
        if (!brProg.getBrProgId().equals(sharedParentageBrProgPk.getBrProg().getBrProgId())) {
            return false;
        }
        return true;
    }
}