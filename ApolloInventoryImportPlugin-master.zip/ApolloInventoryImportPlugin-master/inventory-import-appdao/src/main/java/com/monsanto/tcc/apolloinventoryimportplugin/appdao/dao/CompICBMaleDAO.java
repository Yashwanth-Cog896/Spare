/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.CompICBMale;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: CompICBMaleDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date:
 * 2007/07/11 21:25:52 $
 *
 * @author SSPEYY
 * @version $Revision: 1.2 $
 */
public class CompICBMaleDAO {
    public static final String CROP_LINEFUNC_REQUIRED_MSG = "cropName and lineFunctionCriteria is required";

    private String cropName;
    private LineFunctionCriteria lineFunctionCriteria;

    public CompICBMaleDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_LINEFUNC_REQUIRED_MSG);
        }
        this.cropName = cropName;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public CompICBMale[] getCompICBMale(String source, String pedigreeName, boolean refActive) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = session.createCriteria(CompICBMale.class, "icb")
                .createAlias("icb.geneticMaterial", "gm")
                .createAlias("gm.germplasm", "gp")
                .createAlias("gp.crop", "cr")
                .createAlias("gp.ownerBrProg", "br")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("br.refActive", "T"))
                .add(Restrictions.eq("cr.refActive", "T"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("icb.refActive", ((refActive) ? "T" : "F")));
        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria.list();

        return (list != null && list.size() > 0) ? (CompICBMale[]) list.toArray(new CompICBMale[list.size()]) : null;
    }


    public CompICBMale[] getCompICBMale(String source, String pedigreeName) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        Criteria criteria = session.createCriteria(CompICBMale.class, "icb")
                .createAlias("icb.geneticMaterial", "gm")
                .createAlias("gm.germplasm", "gp")
                .createAlias("gp.crop", "cr")
                .createAlias("gp.ownerBrProg", "br")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .add(Restrictions.eq("gp.pedigreeName", pedigreeName))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("br.refActive", "T"))
                .add(Restrictions.eq("cr.refActive", "T"))
                .add(Restrictions.eq("cr.cropName", cropName));
        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria.list();

        return (list != null && list.size() > 0) ? (CompICBMale[]) list.toArray(new CompICBMale[list.size()]) : null;
    }
}