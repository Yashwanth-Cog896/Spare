/*
 UnfinishedHybridGermplasmDTO was created on May 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import com.monsanto.Util.StringUtils;

/**
 * Filename:    $RCSfile: UnfinishedHybridGermplasmDTO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-03-10 15:59:37 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class UnfinishedHybridGermplasmDTO {
    public static final String ACTIVE_FLAG = "F";
    public static final String NOT_ACTIVE_FLAG = "T";

    private String origin;
    private String brProgRefId;
    private String isDeleted;
    private int count;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getBrProgRefId() {
        return brProgRefId;
    }

    public void setBrProgRefId(String brProgRefId) {
        this.brProgRefId = brProgRefId;
    }

    public String getDeleted() {
        return isDeleted;
    }

    public void setDeleted(String deleted) {
        isDeleted = deleted;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + (null == this.origin ? 0 : this.origin.hashCode());
        hash = 31 * hash + (null == this.brProgRefId ? 0 : this.brProgRefId.hashCode());
        hash = 31 * hash + (null == this.isDeleted ? 0 : this.isDeleted.hashCode());

        return hash;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }

        if (!(object instanceof UnfinishedHybridGermplasmDTO)) {
            return false;
        }

        UnfinishedHybridGermplasmDTO unfinishedHybridGermplasmDTO = (UnfinishedHybridGermplasmDTO) object;

        return StringUtils.areEqual(this.origin, unfinishedHybridGermplasmDTO.getOrigin()) &&
                StringUtils.areEqual(this.brProgRefId, unfinishedHybridGermplasmDTO.getBrProgRefId()) &&
                StringUtils.areEqual(this.isDeleted, unfinishedHybridGermplasmDTO.getDeleted());
    }
}