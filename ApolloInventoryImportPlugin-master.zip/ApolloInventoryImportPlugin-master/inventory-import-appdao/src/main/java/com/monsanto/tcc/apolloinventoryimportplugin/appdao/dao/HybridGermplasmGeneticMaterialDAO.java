/*
 HybridGermplasmGeneticMaterialDAO was created on May 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: HybridGermplasmGeneticMaterialDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * ddbrow5 $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class HybridGermplasmGeneticMaterialDAO {
    public static final String CROP_NAME_REQ_MSG = "cropName is required.";
    public static final String ORIGIN_REQ_MSG = "Origin is required.";
    public static final String SOURCE_REQ_MSG = "Source is required.";
    private static final String LINE_TYPE = "Hybrid";
    private static final String REF_ACTIVE_T = "T";
    private static final String FALSE_FLAG = "F";
    private static final String TRUE_FLAG = "F";

    private Session session = null;
    private String cropName = null;
    private String origin = null;
    private String lineFunctionRefId;

    public HybridGermplasmGeneticMaterialDAO(String cropName, String origin) {
        if (StringUtils.isNullOrEmpty(cropName) || StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException(CROP_NAME_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.origin = origin;
    }

    public HybridGermplasmGeneticMaterialDAO(String cropName, String origin, String lineFunctionRefId) {
        this(cropName, origin);
        this.lineFunctionRefId = lineFunctionRefId;
    }

    public List getAllGeneticMaterialsMatchingSource(String source) {
        if (StringUtils.isNullOrEmpty(source)) {
            throw new IllegalArgumentException(SOURCE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .addOrder(Order.desc("gp.isFinishedOrFinishedChild"))
                .addOrder(Order.asc("gp.isDeleted"));

        return criteria.list();
    }

    public List getAllGeneticMaterialsMatchingSourceAndLineFunction(String source) {
        if (StringUtils.isNullOrEmpty(source)) {
            throw new IllegalArgumentException(SOURCE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .addOrder(Order.desc("gp.isFinishedOrFinishedChild"))
                .addOrder(Order.asc("gp.isDeleted"));

        introduceLineFunctionClause(criteria);

        return criteria.list();
    }

    // todo: should this include line function?

    public List getUnfinishedGeneticMaterialsMatchingSourceOrderdByIsFinishedOrFinishedChild(String source) {
        if (StringUtils.isNullOrEmpty(source)) {
            throw new IllegalArgumentException(SOURCE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .add(Restrictions.eq("gp.isDeleted", FALSE_FLAG))
                .addOrder(Order.desc("gp.isFinishedOrFinishedChild"));

        return criteria.list();
    }

    public GeneticMaterial getLowestGeneticMaterialMatchingSourceForUnifishedHybrid(String source,
                                                                                    String germplasmOwner) {
        if (StringUtils.isNullOrEmpty(source)) {
            throw new IllegalArgumentException(SOURCE_REQ_MSG);
        }
        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase())
                .createAlias("gm.germplasm", "gp")
                .add(Restrictions.eq("gp.origin", origin))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        introduceLineFunctionClause(criteria);

        List list = criteria
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .setProjection(Projections.projectionList().add(Projections.count("gm.geneticMaterialId"), "gpByGmCount")
                        .add(Projections.groupProperty("gp.id"))
                        .add(Projections.min("gm.geneticMaterialId"))
                        .add(Projections.groupProperty("gp.isFinishedOrFinishedChild"))
                )
                .addOrder(Order.desc("gp.isFinishedOrFinishedChild"))
                .addOrder(Order.desc("gpByGmCount"))
                .addOrder(Order.asc("gp.id"))
                .list();

        GeneticMaterial geneticMaterial = null;
        if (null != list && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Object[] obj = (Object[]) list.get(i);
                Long geneticMaterialId = (Long) obj[2];
                String isFinisishedOrFinishedChild = (String) obj[3];
                geneticMaterial = (GeneticMaterial) session.load(GeneticMaterial.class, geneticMaterialId);
                if (isFinisishedOrFinishedChild.equalsIgnoreCase(TRUE_FLAG) ||
                        geneticMaterial.getGermplasm().getOwnerBrProg().getBrProgRefId().equalsIgnoreCase(germplasmOwner)) {
                    break;
                } else {
                    geneticMaterial = null;
                }
            }
        }

        return geneticMaterial;
    }

    private void introduceLineFunctionClause(Criteria criteria) {
        if (StringUtils.isNullOrEmpty(lineFunctionRefId)) {
            criteria.add(Restrictions.isNull("gp.lineFunction"));
        } else {
            criteria.createAlias("gp.lineFunction", "lf")
                    .add(Restrictions.eq("lf.lineFunctionRefId", lineFunctionRefId))
                    .add(Restrictions.eq("lf.refActive", REF_ACTIVE_T));
        }
    }
}
