package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 15, 2010
 * Time: 10:21:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmRoyalty {
    private Long germplasmRoyaltyId;
    private Long royaltyContractId;
    private Timestamp modifiedDt;
    private Date inactiveDt;
    private String royaltyInd;
    private Germplasm germplasm;
    private String externalGermplasmName;
    private String comments;

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getExternalGermplasmName() {
        return externalGermplasmName;
    }

    public void setExternalGermplasmName(String externalGermplasmName) {
        this.externalGermplasmName = externalGermplasmName;
    }

    public Long getGermplasmRoyaltyId() {
        return germplasmRoyaltyId;
    }

    public void setGermplasmRoyaltyId(Long germplasmRoyaltyId) {
        this.germplasmRoyaltyId = germplasmRoyaltyId;
    }

    public Long getRoyaltyContractId() {
        return royaltyContractId;
    }

    public void setRoyaltyContractId(Long royaltyContractId) {
        this.royaltyContractId = royaltyContractId;
    }

    public Timestamp getModifiedDt() {
        return modifiedDt;
    }

    public void setModifiedDt(Timestamp modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    public Date getInactiveDt() {
        return inactiveDt;
    }

    public void setInactiveDt(Date inactiveDt) {
        this.inactiveDt = inactiveDt;
    }

    public String getRoyaltyInd() {
        return royaltyInd;
    }

    public void setRoyaltyInd(String royaltyInd) {
        this.royaltyInd = royaltyInd;
    }

    public Germplasm getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }
}
