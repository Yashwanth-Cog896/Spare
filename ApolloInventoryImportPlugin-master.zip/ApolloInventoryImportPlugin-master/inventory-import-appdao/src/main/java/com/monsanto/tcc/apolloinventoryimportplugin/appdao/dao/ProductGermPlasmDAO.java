package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Mar 19, 2008 Time: 7:55:59 AM To change this template use File |
 * Settings | File Templates.
 */
public class ProductGermPlasmDAO {
    protected Session session;
    protected String cropName;
    protected String productType;
    protected String[] lineTypes;

    public ProductGermPlasmDAO(String cropName, String[] lineTypesArray) {
        if (StringUtils.isNullOrEmpty(cropName)) {
            {
                throw new IllegalArgumentException("cropName is required.");
            }
        }

        this.cropName = cropName;
        if (null == lineTypesArray) {
            this.lineTypes = new String[0];
        } else {
            this.lineTypes = Arrays.copyOf(lineTypesArray, lineTypesArray.length);
        }
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public List getProductGermplasmListForProducts(List productList) {
        if (productList == null || productList.size() == 0) {
            throw new IllegalArgumentException("productList is required.");
        }
        Criteria criteria = session.createCriteria(ProductGermplasm.class, "pg")
                .createAlias("pg.germplasm", "gp")
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", "T"))
                .add(Restrictions.in("pg.product", productList));
        if (lineTypes != null && lineTypes.length > 0) {
            criteria.createAlias("gp.lineType", "lt")
                    .add(Restrictions.eq("lt.refActive", "T"))
                    .add(Restrictions.in("lt.name", lineTypes));
        }
        return criteria.list();
    }

    public List getProductGermplasmListMatchingOrigin(String origin) {
        if (StringUtils.isNullOrEmpty(origin)) {
            throw new IllegalArgumentException("origin is required.");
        }
        Criteria criteria = session.createCriteria(ProductGermplasm.class, "pg")
                .createAlias("pg.germplasm", "gp")
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("gp.isFinishedOrFinishedChild", "T"))
                .add(Restrictions.eq("gp.origin", origin));

        if (lineTypes != null && lineTypes.length > 0) {
            criteria.createAlias("gp.lineType", "lt")
                    .add(Restrictions.eq("lt.refActive", "T"))
                    .add(Restrictions.in("lt.name", lineTypes));
        }
        return criteria.list();
    }
}
