/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.LineFunctionCriteria;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.MaterialTypeConstants;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: FinishedGeneticMaterialDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ssnall $
 * On:$Date: 2009-06-18 14:16:20 $
 *
 * @author apatro
 * @version $Revision: 1.6 $
 */
public class FinishedGeneticMaterialDAO {
    public static final String CROP_LINEFUNCTION_REQ_MSG = "cropName and lineFunctionCriteria are required.";
    public static final String LINECODE_REQ_MSG = "lineCode is required.";
    public static final String LINCODE_SRC_LINEAGE_ARE_REQ_MSG = "lineCode and source are required";
    private static final String GERMPLASM_IS_REQ_MSG = "Germplasm is required";

    private static final String LINE_TYPE = MaterialTypeConstants.FINISHED_LINES;
    private static final String REF_ACTIVE_T = "T";

    private Session session = null;
    private String cropName = null;
    private LineFunctionCriteria lineFunctionCriteria;

    public FinishedGeneticMaterialDAO(String cropName, LineFunctionCriteria lineFunctionCriteria) {
        if (StringUtils.isNullOrEmpty(cropName) || lineFunctionCriteria == null) {
            throw new IllegalArgumentException(CROP_LINEFUNCTION_REQ_MSG);
        }

        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        this.cropName = cropName;
        this.lineFunctionCriteria = lineFunctionCriteria;
    }

    public GeneticMaterial[] getGeneticMaterialWithLineageOtherThanPipe(String lineCode) {
        if (StringUtils.isNullOrEmpty(lineCode)) {
            throw new IllegalArgumentException(LINECODE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("gm.germplasm", "gp")
                .createAlias("gp.crop", "cr")
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .add(Restrictions.eq("cr.cropName", cropName))
                .add(Restrictions.eq("cr.refActive", "T"))
                .add(Restrictions.eq("lt.lineTypeRefId", LINE_TYPE).ignoreCase())
                .add(Restrictions.eq("lt.refActive", "T"))
                .add(Restrictions.ne("gm.lineage", "|"));

        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria.list();

        GeneticMaterial[] geneticMaterial = null;
        if (list != null && list.size() > 0) {
            geneticMaterial = (GeneticMaterial[]) list.toArray(new GeneticMaterial[list.size()]);
        }

        return geneticMaterial;
    }

    public GeneticMaterial getPrimaryGeneticMaterial(String lineCode, String source, String generation) {
        if (StringUtils.isNullOrEmpty(lineCode) || StringUtils.isNullOrEmpty(source)) {
            throw new IllegalArgumentException(LINCODE_SRC_LINEAGE_ARE_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("germplasm", "gp")
                .setProjection(Projections.projectionList().add(Projections.count("gm.geneticMaterialId"), "gmByGpCount")
                        .add(Projections.groupProperty("gp.id"))
                        .add(Projections.min("gm.geneticMaterialId"))
                )
                .add(Restrictions.eq("gp.lineCode", lineCode))
                .add(Restrictions.eq("gp.isDeleted", "F"))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T))
                .add(Restrictions.eq("gm.sourceStr", source).ignoreCase());
        if (generation != null && !"INBRED".equals(generation)) {
            criteria.add(Restrictions.eq("gm.generation", generation).ignoreCase());
        }

        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"))
                .list();

        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            Long minGeneticMaterialId = (Long) obj[2];
            return (GeneticMaterial) session.load(GeneticMaterial.class, minGeneticMaterialId);
        }

        return null;
    }

    public GeneticMaterial getPrimaryGeneticMaterial(Germplasm germplasm) {
        if (germplasm == null) {
            throw new IllegalArgumentException(GERMPLASM_IS_REQ_MSG);
        }

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("germplasm", "gp")
                .setProjection(Projections.projectionList().add(Projections.count("gm.geneticMaterialId"), "gmByGpCount")
                        .add(Projections.groupProperty("gp.id"))
                        .add(Projections.min("gm.geneticMaterialId"))
                )
                .add(Restrictions.eq("gp.id", germplasm.getId()))
                .createAlias("gp.lineType", "lt")
                .add(Restrictions.eq("lt.name", LINE_TYPE))
                .add(Restrictions.eq("lt.refActive", REF_ACTIVE_T));

        lineFunctionCriteria.addCriteria("gp", criteria);

        List list = criteria
                .createAlias("gp.crop", "cr")
                .add(Restrictions.eq("cr.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("cr.refActive", REF_ACTIVE_T))
                .addOrder(Order.desc("gmByGpCount"))
                .addOrder(Order.asc("gp.id"))
                .list();

        if (null != list && list.size() > 0) {
            Object[] obj = (Object[]) list.get(0);
            Long minGeneticMaterialId = (Long) obj[2];
            return (GeneticMaterial) session.load(GeneticMaterial.class, minGeneticMaterialId);
        }

        return null;
    }
}