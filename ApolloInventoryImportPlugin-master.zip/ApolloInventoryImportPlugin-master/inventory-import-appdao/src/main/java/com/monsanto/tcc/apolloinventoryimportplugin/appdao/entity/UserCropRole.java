/*
 UserCropRole was created on Jan 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: UserCropRole.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-02-19 05:23:21 $
 *
 * @author SRKARNA
 * @version $Revision: 1.2 $
 */
public class UserCropRole {
    private Long id;
    private MidasUser midasUser;
    private Crop crop;
    private MidasRole role;
    private String refActive;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MidasUser getMidasUser() {
        return midasUser;
    }

    public void setMidasUser(MidasUser midasUser) {
        this.midasUser = midasUser;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public MidasRole getRole() {
        return role;
    }

    public void setRole(MidasRole role) {
        this.role = role;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}