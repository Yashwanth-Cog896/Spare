/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity;

/**
 * Filename:    $RCSfile: BrProg.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-17 22:58:07 $
 *
 * @author skumar5
 * @version $Revision: 1.1 $
 */
public class BrProg {
    private Long brProgId;
    private String name;
    private String brProgRefId;
    private Crop crop;
    private String refActive;
    private String midasProgram;
    private Long mailStop;
    private Long acctId;

    public BrProg() {
    }

    public Long getBrProgId() {
        return brProgId;
    }

    public void setBrProgId(Long brProgId) {
        this.brProgId = brProgId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrProgRefId() {
        return brProgRefId;
    }

    public void setBrProgRefId(String brProgRefId) {
        this.brProgRefId = brProgRefId;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getMidasProgram() {
        return midasProgram;
    }

    public void setMidasProgram(String midasProgram) {
        this.midasProgram = midasProgram;
    }

    public Long getMailStop() {
        return mailStop;
    }

    public void setMailStop(Long mailStop) {
        this.mailStop = mailStop;
    }

    public Long getAcctId() {
        return acctId;
    }

    public void setAcctId(Long acctId) {
        this.acctId = acctId;
    }

}