package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Parentage;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ParentalRole;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.MidasSequence;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Expression;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Jan 19, 2010
 * Time: 3:15:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class ParentageDAO {

    public boolean isParentageExists(GeneticMaterial childGeneticMaterial, GeneticMaterial parentGeneticMaterial, ParentalRole parentalRole) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();

        Query query = session.getNamedQuery("get.existing.parentage");
        query.setParameter("childGeneticMaterial", childGeneticMaterial);
        query.setParameter("parentGeneticMaterial", parentGeneticMaterial);
        query.setParameter("parentalRole", parentalRole);

        List parentage = query.list();

        return (parentage != null && parentage.size() > 0);
    }

    public void saveParentage(Parentage parentage) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        parentage.setParentageId(MidasSequence.getId());
        session.save(parentage);
    }

    public ParentalRole getParentalRole(String parentalRole) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        return (ParentalRole) session.createCriteria(ParentalRole.class)
                .add(Expression.eq("parentalRoleRefId", parentalRole)).uniqueResult();

    }

    public List getParentage(GeneticMaterial geneticMaterial) {
        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        return session.createCriteria(Parentage.class)
                .add(Expression.eq("geneticMaterial", geneticMaterial)).list();

    }
}
