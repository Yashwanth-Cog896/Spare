/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.util;

import org.hibernate.Query;
import org.hibernate.Session;

import java.math.BigDecimal;

/**
 * Filename:    $RCSfile: MidasSequence.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $     On:$Date: 2008-02-16 04:31:30 $
 *
 * @author SSPEYY
 * @version $Revision: 1.1 $
 */
public class MidasSequence {
    public static Long getId() {

        Session session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
        StringBuffer sql = new StringBuffer(500);
        sql.append("select midas.get_nextid from dual");
        Query q = session.createSQLQuery(sql.toString());
        BigDecimal bd = (BigDecimal) q.list().get(0);
        return new Long(bd.longValue());
    }
}