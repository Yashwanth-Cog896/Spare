package com.monsanto.tcc.apolloinventoryimportplugin.appdao.parentage;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.business.ProductGermplasmFinder;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao.FinishedGermplasmDAO;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.ProductNameProductGermplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction.NullLineFunctionCriteria;

import java.util.List;

public class FinishedParentMatchingLineCodeCheckingStrategy implements ParentageFetchStrategy {

    private String cropName;
    private final ProductGermplasmFinder productGermplasmFinder = new ProductGermplasmFinder();

    public FinishedParentMatchingLineCodeCheckingStrategy(String cropName) {
        super();
        this.cropName = cropName;
    }

    public List fetchExistingParentGermplasms(String originComponent) {
        FinishedGermplasmDAO dao = createFinishedGermplasmDAO(cropName);
        return dao.getAllGermplasmsExcludingLineFunction(originComponent);
    }

    public boolean checkIfParentsExists(String originComponent) {
        List germplasmsList = fetchExistingParentGermplasms(originComponent);
        if ((null == germplasmsList) || (0 == germplasmsList.size())) {
            return false;
        }
        return true;
    }


    protected FinishedGermplasmDAO createFinishedGermplasmDAO(String cropName) {
        return new FinishedGermplasmDAO(cropName, new NullLineFunctionCriteria());

    }

    public List fetchParentProductGermplasms(String originComponent) {
        return null;
    }

    public ProductNameProductGermplasm fetchProductNameProductGermplasm(String originComponent) {
        return null;
    }

}