/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.header.StagingInventoryHeader;
import com.monsanto.tcc.apolloinventoryimportplugin.common.staging.inventory.StagingInventory;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Filename:    $RCSfile: InventoryWithRestrictionsDAO.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddbrow5 $     On:$Date: 2008-03-25 14:15:07 $
 *
 * @author SSPEYY
 * @version $Revision: 1.5 $
 */
public class InventoryWithRestrictionsDAO {
    private String userId;
    private String cropName;
    private String materialType;
    private Session session;

    public InventoryWithRestrictionsDAO(String userId, String cropName, String materialType) {
        if (StringUtils.isNullOrEmpty(userId) || StringUtils.isNullOrEmpty(cropName) || StringUtils.isNullOrEmpty(materialType)) {
            throw new IllegalArgumentException("userId, cropName, materialType are required.");
        }

        this.userId = userId;
        this.cropName = cropName;
        this.materialType = materialType;
        session = HibernateUtil.getSessionFactoryForStagingInventory().getCurrentSession();
    }

    public List getStagingInventoryRecords(String[] statusCodeList) {
        if (null == statusCodeList) {
            throw new IllegalArgumentException("expecting at least one status code");
        }

        return session.createCriteria(StagingInventory.class, "si")
                .setFetchMode("si.importStatus", FetchMode.JOIN)
                .createCriteria("si.importType", "it")
                .add(Restrictions.eq("it.abbreviation", materialType))
                .createCriteria("si.importStatus", "is")
                .add(Restrictions.in("is.statusCode", statusCodeList))
                .createCriteria("si.inventoryHeader", "ih")
                .add(Restrictions.eq("ih.userId", userId).ignoreCase())
                .add(Restrictions.eq("ih.cropName", cropName)).list();
    }

    public List getStagingInventoryMainRecords(String[] statusCodeList, String orderByClause) {
        if (null == statusCodeList) {
            throw new IllegalArgumentException("expecting at least one status code");
        }

        String queryString = session.getNamedQuery("main.records.for.requestor.by.croptypestatus").getQueryString();
        queryString = getOrderByQueryString(queryString, orderByClause);

        Query query = session.createQuery(queryString);
        query.setParameter("materialType", materialType);
        query.setParameter("userId", userId);
        query.setParameter("cropName", cropName);
        query.setParameterList("statusCodes", statusCodeList);

        return query.list();
    }

    public List getStagingInventoryMainRecordsForAuthority(String[] statusCodeList, String orderByClause) {
        if (null == statusCodeList) {
            throw new IllegalArgumentException("expecting at least one status code");
        }

        String queryString = session.getNamedQuery("main.records.for.authority.by.croptypestatus").getQueryString();
        queryString = getOrderByQueryString(queryString, orderByClause);

        Query query = session.createQuery(queryString);
        query.setParameter("materialType", materialType);
        query.setParameter("authorityId", userId);
        query.setParameter("cropName", cropName);
        query.setParameterList("statusCodes", statusCodeList);

        return query.list();
    }

    public Integer getCountOfAllStagingInventoriesAndParentsByStatusCode(String[] statusCodes) {
        if (null == statusCodes) {
            throw new IllegalArgumentException("expecting at least one status code");
        }
        Criteria criteria = session.createCriteria(StagingInventory.class, "si")
                .createAlias("si.inventoryHeader", "ih")
                .add(Restrictions.eq("ih.userId", userId).ignoreCase())
                .add(Restrictions.eq("ih.cropName", cropName))
                .createAlias("ih.importType", "itype")
                .add(Restrictions.eq("itype.abbreviation", materialType))
                .createAlias("si.importStatus", "istat")
                .add(Restrictions.in("istat.statusCode", statusCodes))
                .setProjection(Projections.projectionList().add(Projections.count("si.id"), "siCount"));

        return ((Number) criteria.uniqueResult()).intValue();
    }

    private String getOrderByQueryString(String queryString, String orderByClause) {
        orderByClause = ((null == orderByClause) ? "creationDate" : orderByClause);
        queryString += " order by " + orderByClause;
        return queryString;
    }

    public boolean checkFileAlreadyImported(String fileName) {
        if (null == fileName || "".equals(fileName.trim())) {
            throw new IllegalArgumentException("File name missing");
        }
        return session.createCriteria(StagingInventoryHeader.class, "sh")
                .add(Restrictions.eq("sh.userId", userId).ignoreCase())
                .add(Restrictions.eq("sh.cropName", cropName).ignoreCase())
                .add(Restrictions.eq("sh.templateName", fileName).ignoreCase())
                .createCriteria("sh.importType", "it")
                .add(Restrictions.eq("it.abbreviation", materialType).ignoreCase())
                .list().size() > 0;
    }

    public List getStagingInventoryMainRecordsCountForAuthority(String[] statusCodeList) {
        String queryString = "select authorityRequested ,count(authorityRequested) from StagingInventory si  where si.inventoryHeader.importType.abbreviation = :materialType" +
                " and si.importStatus.statusCode in (:statusCodes)" +
                " and si.inventoryHeader.cropName = :cropName" +
                "  and not exists (from StagingParentage sp where parentInventory = si) group by authorityRequested";
        Query query = session.createQuery(queryString);
        query.setParameter("materialType", materialType);
        query.setParameter("cropName", cropName);
        query.setParameterList("statusCodes", statusCodeList);
        return query.list();
    }

    public List getStagingInventoryRecordsCountForAuthority(String[] statusCodeList) {
        String queryString = "select authorityRequested ,count(authorityRequested) from StagingInventory si  where si.inventoryHeader.importType.abbreviation = :materialType" +
                " and si.importStatus.statusCode in (:statusCodes)" +
                " and si.inventoryHeader.cropName = :cropName group by authorityRequested";
        Query query = session.createQuery(queryString);
        query.setParameter("materialType", materialType);
        query.setParameter("cropName", cropName);
        query.setParameterList("statusCodes", statusCodeList);
        return query.list();
    }
}