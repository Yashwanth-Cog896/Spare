
/*
 GermplasmPickerDAO was created on Feb 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.dao;

import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.GeneticMaterial;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.entity.Germplasm;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.HibernateUtil;
import com.monsanto.tcc.apolloinventoryimportplugin.appdao.util.ListCriteriaUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import java.util.Arrays;
import java.util.List;

/**
 * Filename:    $RCSfile: GermplasmPickerDAO.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: srkarna $     On:$Date: 2008-02-24 07:34:23 $
 *
 * @author SRKARNA
 * @version $Revision: 1.1 $
 */
public class GermplasmPickerDAO {
    public static final String GERMPLASMS_IS_REQUIRED = "germplasms is required.";
    private Session session = null;
    private Germplasm[] germplasms;

    public GermplasmPickerDAO(Germplasm[] germplasmsArray) {
        if (isEmpty(germplasmsArray)) {
            throw new IllegalArgumentException(GERMPLASMS_IS_REQUIRED);
        }

        if (null == germplasmsArray) {
            this.germplasms = new Germplasm[0];
        } else {
            this.germplasms = Arrays.copyOf(germplasmsArray, germplasmsArray.length);
        }
        session = HibernateUtil.getSessionFactoryForMidasCentral().getCurrentSession();
    }

    public Germplasm getGermplasmWithLowestIdAssociatedWithHighestGeneticMaterials() {
        Germplasm germplasm = null;

        Criteria criteria = session.createCriteria(GeneticMaterial.class, "gm")
                .createAlias("germplasm", "gp")
                .setProjection(Projections.projectionList()
                        .add(Projections.groupProperty("gp.id"))
                        .add(Projections.rowCount(), "gmCount")
                )
                .addOrder(Order.desc("gmCount"))
                .addOrder(Order.asc("gp.id"));
        setGermplasmCriteria(germplasms, criteria);

        List rows = criteria.list();
        if (isNotEmpty(rows)) {
            Object[] firstRow = (Object[]) rows.get(0);
            germplasm = (Germplasm) session.get(Germplasm.class, (Long) firstRow[0]);
        }

        return germplasm;
    }

    private boolean isNotEmpty(List rows) {
        return ((null != rows) && (rows.size() > 0));
    }

    private boolean isEmpty(Germplasm[] germplasms) {
        return ((null == germplasms) || (germplasms.length < 1));
    }

    private void setGermplasmCriteria(Germplasm[] germplasms, Criteria criteria) {
        if (germplasms.length > 999) {
            criteria.add(ListCriteriaUtil.addRestrictions("gm.germplasm", Arrays.asList(germplasms)));
        } else {
            criteria.add(Restrictions.in("gm.germplasm", germplasms));
        }
    }
}
