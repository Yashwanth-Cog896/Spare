/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.apolloinventoryimportplugin.appdao.linefunction;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.apolloinventoryimportplugin.common.constants.LineFunctionConstants;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    $RCSfile: NonALineFunctionCriteria.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: srkarna $
 * On:$Date: 2008-02-17 22:58:07 $
 *
 * @author ddbrow5
 * @version $Revision: 1.1 $
 */
public class NonALineFunctionCriteria implements LineFunctionCriteria {
    private String lineFunction;
    private static final String LINE_FUNCTION_REQ_MSG = "Line function value is required";
    private static final String LINE_FUNCTION_CANNOT_BE_A_MSG = "Line function value cannot be \"A\"";

    public NonALineFunctionCriteria(String lineFunction) {
        if (StringUtils.isNullOrEmpty(lineFunction)) {
            throw new IllegalArgumentException(LINE_FUNCTION_REQ_MSG);
        }
        if (LineFunctionConstants.A_LINE_FUNCTION.equalsIgnoreCase(lineFunction.trim())) {
            throw new IllegalArgumentException(LINE_FUNCTION_CANNOT_BE_A_MSG);
        }
        this.lineFunction = lineFunction.trim();
    }

    public void addCriteria(String alias, Criteria criteria) {
        criteria.createAlias(alias + ".lineFunction", "lfunc")
                .add(Restrictions.eq("lfunc.lineFunctionRefId", lineFunction))
                .add(Restrictions.eq("lfunc.refActive", "T"));
    }

    public void addStagingInventoryCriteria(String alias, Criteria criteria) {
        criteria.add(Restrictions.eq(alias + ".lineFunction", lineFunction));
    }
}