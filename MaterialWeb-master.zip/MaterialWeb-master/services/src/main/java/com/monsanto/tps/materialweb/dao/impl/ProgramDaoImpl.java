package com.monsanto.tps.materialweb.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.aop.cache.MethodCache;
import com.monsanto.tps.materialweb.dao.ProgramDao;
import com.monsanto.tps.materialweb.entity.ProgramEntity;
import com.monsanto.tps.materialweb.entity.ProgramToRoleEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

public class ProgramDaoImpl implements ProgramDao {
    @Resource
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    @MethodCache
    public Collection<ProgramEntity> getActiveGermplasmManagersProgramsForCrop(Long cropId) {
        List<ProgramToRoleEntity> list = getSession().createCriteria(ProgramToRoleEntity.class, "ptr")
                .createAlias("ptr.program", "bp")
                .createAlias("ptr.role", "mr")
                .createAlias("bp.crop", "cr")
                .add(Restrictions.eq("ptr.refActive", "T"))
                .add(Restrictions.eq("bp.refActive", "T"))
                .add(Restrictions.eq("cr.id", cropId))
                .add(Restrictions.eq("cr.refActive", "T"))
                .add(Restrictions.eq("mr.roleRefId", "GM"))
                .add(Restrictions.eq("mr.roleTypeId", "PR"))
                .add(Restrictions.eq("mr.refActive", "T"))
                .list();

        List<ProgramEntity> programs = Lists.newArrayList();
        for (ProgramToRoleEntity progRole : list) {
            programs.add(progRole.getProgram());
        }
        return programs;
    }

}
