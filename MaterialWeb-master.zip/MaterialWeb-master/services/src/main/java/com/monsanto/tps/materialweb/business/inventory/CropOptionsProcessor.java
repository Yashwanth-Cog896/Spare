package com.monsanto.tps.materialweb.business.inventory;

public interface CropOptionsProcessor {

    com.monsanto.tps.materialweb.model.CropOptions getDetailsForCrop(Long cropId);

}
