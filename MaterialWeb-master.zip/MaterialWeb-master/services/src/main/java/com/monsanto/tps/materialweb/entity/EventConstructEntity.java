package com.monsanto.tps.materialweb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "EVENT_CONSTRUCT", schema = "MIDAS")
public class EventConstructEntity implements Serializable {
    @Id
    @Column(name = "EVENT_CONSTRUCT_ID", nullable = false)
    private Long eventConstructId;
    @Column(name = "EVENT_NAME")
    private String eventName;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @Column(name = "CONSTRUCT_NAME")
    private String constructName;
    @Column(name = "BARCODE")
    private String barcode;

    public Long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(Long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getConstructName() {
        return constructName;
    }

    public void setConstructName(String constructName) {
        this.constructName = constructName;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
}
