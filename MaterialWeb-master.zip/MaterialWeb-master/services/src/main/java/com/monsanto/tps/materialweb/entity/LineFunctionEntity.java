package com.monsanto.tps.materialweb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "LINE_FUNCTION", schema = "MIDAS")
public class LineFunctionEntity implements Serializable {
    @Id
    @Column(name = "LINE_FUNCTION_ID", nullable = false)
    private Long lineFunctionId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @Column(name = "LINE_FUNCTION_REF_ID")
    private String lineFunctionRefId;

    public Long getLineFunctionId() {
        return lineFunctionId;
    }

    public void setLineFunctionId(Long lineFunctionId) {
        this.lineFunctionId = lineFunctionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getLineFunctionRefId() {
        return lineFunctionRefId;
    }

    public void setLineFunctionRefId(String lineFunctionRefId) {
        this.lineFunctionRefId = lineFunctionRefId;
    }
}
