package com.monsanto.tps.materialweb.service.impl;

import com.google.common.base.Preconditions;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;

import javax.annotation.Resource;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 9/12/13
 * Time: 3:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class AbstractUserInfoService {
    @Resource
    protected UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    protected String getUserLoginId() {
        EnhancedUserDetails userDetails = userDetailsProvider.getUserDetails();
        Preconditions.checkArgument(null != userDetails, "User can't be null");
        return userDetails.getUsername();
    }
}
