package com.monsanto.tps.materialweb.entity;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;

@Entity
@Immutable
@Table(name = "CROP_VEGETATIVE_STRUCTURE")
public class CropToVegetativeStructureEntity {

    @Column(name = "CROP_VEGETATIVE_STRUCTURE_ID", nullable = false)
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private CropEntity crop;

    @ManyToOne(optional = false)
    @JoinColumn(name = "VEGETATIVE_STRUCTURE_ID", nullable = false)
    private VegetativeStructureEntity vegetativeStructure;

    @Column(name = "REF_ACTIVE", nullable = false)
    private String refActive;

    @Column(name = "DEVELOPMENT_ORDER", nullable = false)
    private Integer order;

    public Long getId() {
        return id;
    }

    void setId(final Long id) {
        this.id = id;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

    public VegetativeStructureEntity getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(VegetativeStructureEntity vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }
}