package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.Util.fileutil.FileUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.io.IOException;

public class AbstractJDBCDao {
    private static final Log logger = LogFactory.getLog(AbstractJDBCDao.class);

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
    }

    protected String readSql(String query) {
        try {
            return FileUtil.readFileToString(Thread.currentThread().getContextClassLoader().getResourceAsStream(query));
        } catch (IOException e) {
            logger.error("Problem reading sql file: " + query, e);
            throw new RuntimeException(e);
        }
    }

    public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
        return namedParameterJdbcTemplate;
    }
}
