package com.monsanto.tps.materialweb.interceptor;

import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import com.monsanto.tps.ws.cxf.interceptor.ReferenceIdProvider;
import com.monsanto.tps.ws.cxf.interceptor.SuppressStacktraceOutFaultInterceptor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.springframework.beans.factory.annotation.Required;

import java.util.ResourceBundle;

public class SuppressStackTraceRest extends SuppressStacktraceOutFaultInterceptor {
        private static final Log log = LogFactory.getLog(SuppressStackTraceRest.class);
        private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;
        private ReferenceIdProvider referenceIdProvider;

        @Override
        public void handleMessage(Message message) throws Fault {
             Fault fault = (Fault) message.getContent(Exception.class);
             Throwable throwable = fault.getCause();
              try{
                   super.handleMessage(message); }
              catch(Exception e) {
                   suppressStackMessageRest(message, throwable);
             }
        }
        private void suppressStackMessageRest(Message message, Throwable throwable) {
             Exchange exchange = message.getExchange();
             String endPt=exchange.get("org.apache.cxf.service.object.last").toString();
             String endpointName=endPt.substring(0,endPt.indexOf("@")).split("\\.")[6];
             String fullServiceMethodName = exchange.get("org.apache.cxf.resource.operation.name").toString();
             String serviceMethodName = fullServiceMethodName.substring(fullServiceMethodName.indexOf("#")+1);
             String errorMessage = String.format(ERROR_MESSAGE, String.format("%s.%s", endpointName, serviceMethodName),
                             userDetailsProvider.getUserDetails().getUsername(), referenceIdProvider.getReferenceId());
             log.error(String.format(errorMessage), throwable);
             Fault newFault = new Fault(errorMessage, (ResourceBundle) null);
             message.setContent(Exception.class, newFault);
             if(newFault.getMessage().startsWith("Server side exception")) {
              message.getExchange().put(Message.PROPOGATE_EXCEPTION, "false");
             }
        }
         @Required
        public void setUserDetailsProvider(UserDetailsProvider<EnhancedUserDetails> userDetailsProvider) {
             this.userDetailsProvider = userDetailsProvider;
        }

         @Required
        public void setReferenceIdProvider(ReferenceIdProvider referenceIdProvider) {
             this.referenceIdProvider = referenceIdProvider;
        }
}
