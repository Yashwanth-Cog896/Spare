/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.materialweb.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "CROP", schema = "MIDAS")
public class CropEntity implements Serializable {
    @Id
    @Column(name = "CROP_ID", nullable = false)
    private Long cropId;
    @Column(name = "NAME")
    private String cropName;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @Column(name = "GENUS_SPECIES")
    private String genusSpecies;
    @Column(name = "CROP_REF_ID")
    private String cropRefId;
    @Column(name = "REM_CROP_ID")
    private String remCropId;
    @Column(name = "RM_MIN")
    private int rmMin;
    @Column(name = "RM_MAX")
    private int rmMax;
    @Column(name = "RM_INCREMENT")
    private int rmIncrement;

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getGenusSpecies() {
        return genusSpecies;
    }

    public void setGenusSpecies(String genusSpecies) {
        this.genusSpecies = genusSpecies;
    }

    public String getCropRefId() {
        return cropRefId;
    }

    public void setCropRefId(String cropRefId) {
        this.cropRefId = cropRefId;
    }

    public int getRmMin() {
        return rmMin;
    }

    public void setRmMin(int rmMin) {
        this.rmMin = rmMin;
    }

    public int getRmMax() {
        return rmMax;
    }

    public void setRmMax(int rmMax) {
        this.rmMax = rmMax;
    }

    public int getRmIncrement() {
        return rmIncrement;
    }

    public void setRmIncrement(int rmIncrement) {
        this.rmIncrement = rmIncrement;
    }

    public String getRemCropId() {
        return remCropId;
    }

    public void setRemCropId(String remCropId) {
        this.remCropId = remCropId;
    }
}