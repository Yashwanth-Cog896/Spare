package com.monsanto.tps.materialweb.entity.util;

public class TempTableSessionIdProvider {
    private int sessionId = 0;
    private static final int MIN_SESSION_ID = 1;
    private static final int MAX_SESSION_ID = 10000;

    public synchronized int getNextSessionId() {
        sessionId++;
        if (MAX_SESSION_ID < sessionId) {
            sessionId = MIN_SESSION_ID;
        }
        return sessionId;
    }
}
