package com.monsanto.tps.materialweb.business.inventory.impl;

import com.google.common.collect.Lists;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lineadvancement.model.SourceCreationRequest;
import com.monsanto.tcc.lineadvancement.model.SourceCreationResponse;
import com.monsanto.tcc.lineadvancement.service.InventoryCreationService;
import com.monsanto.tps.materialweb.business.inventory.CreationProcessor;
import com.monsanto.tps.materialweb.model.CreationRequest;
import com.monsanto.tps.materialweb.model.CreationResponse;
import com.monsanto.tps.materialweb.model.CreationResults;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;

public class CreationProcessorImpl implements CreationProcessor {
    @Resource
    private InventoryCreationService remoteInventoryCreationService;

    public final static String UNKNOWN = "U";
    public final static String TRUE = "T";
    public final static String FALSE = "F";
    public final static String DEFAULT = "-";

    @Override
    @Transactional(readOnly = false)
    public CreationResults createNewSources(Collection<CreationRequest> requests, String loginId) {
        Collection<SourceCreationRequest> serviceRequests = transformRequests(requests, loginId);
        Collection<SourceCreationResponse> serviceResults = remoteInventoryCreationService.createNewSourceForExistingGermplasm(serviceRequests);
        CreationResults result = transformResults(serviceResults);
        return result;
    }

    private Collection<SourceCreationRequest> transformRequests(Collection<CreationRequest> requests, String loginId) {
        Collection<SourceCreationRequest> serviceRequests = Lists.newArrayList();
        for (CreationRequest request : requests) {
            SourceCreationRequest creationRequest = new SourceCreationRequest();
            creationRequest.setApproverLoginId(loginId);
            creationRequest.setGermplasmId(request.getGermplasmId());
            creationRequest.setInventoryOwnerBrProgRefId(request.getInventoryOwnerProgram());
            creationRequest.setRequesterLoginID(loginId);
            creationRequest.setSeedQuantity(request.getSeedQuantity());
            creationRequest.setUomName(request.getSeedQuantityUOM());
            creationRequest.setSourceName(request.getSourceName());
            creationRequest.setVegetativeStructureName(request.getVegetativeStructure());
            creationRequest.setValidateOnly(request.getValidateOnly());
            creationRequest.setAllergensPresent(transformForTrueFalseUnknown(request.getAllergensPresent()));
            creationRequest.setAnimalGenePresent(transformForTrueFalseUnknown(request.getAnimalGenePresent()));
            creationRequest.setExposureHistoryKnown(transformForTrueFalseUnknown(request.getExposureHistoryKnown()));
            creationRequest.setFromManufacturing(request.getFromManufacturing());
            creationRequest.setManufacturingAcronymNumber(request.getManufacturingAcronymNumber());
            creationRequest.setManufacturingBatchNumber(request.getManufacturingBatchNumber());
            creationRequest.setManufacturingMaterialNumber(request.getManufacturingMaterialNumber());
            creationRequest.setMiniChromosome(transformForTrueFalseUnknown(request.getMiniChromosome()));
            creationRequest.setToxinsPresent(transformForTrueFalseUnknown(request.getToxinsPresent()));
            serviceRequests.add(creationRequest);
        }
        return serviceRequests;
    }

    private CreationResults transformResults(Collection<SourceCreationResponse> serviceResults) {
        CreationResults result = new CreationResults();
        result.setRequestSuccess(true);
        for (SourceCreationResponse response : serviceResults) {
            CreationResponse detail = new CreationResponse();
            detail.setGermplasmId(response.getGermplasmId());
            detail.setInventoryBID(response.getInventoryBID());
            detail.setMessages(response.getMessages());
            detail.setSourceString(response.getSourceString());
            detail.setSuccess(response.isSuccessful());
            if (!response.isSuccessful()) {
                result.setRequestSuccess(false);
                result.setResponseMessage("Resolve problems and resubmit.");
            }
            result.addResponses(detail);
        }
        return result;
    }

    private String transformForTrueFalseUnknown(String inputValue) {
        if (StringUtils.isNullOrEmpty(inputValue)) {
            return DEFAULT;
        } else if ("UNKNOWN".equalsIgnoreCase(inputValue) || "U".equalsIgnoreCase(inputValue)) {
            return UNKNOWN;
        } else if ("TRUE".equalsIgnoreCase(inputValue) || "T".equalsIgnoreCase(inputValue)) {
            return TRUE;
        } else if ("FALSE".equalsIgnoreCase(inputValue) || "F".equalsIgnoreCase(inputValue)) {
            return FALSE;
        } else {
            return DEFAULT;
        }
    }
}
