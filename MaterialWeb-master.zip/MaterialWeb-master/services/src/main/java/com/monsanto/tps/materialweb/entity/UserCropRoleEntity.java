package com.monsanto.tps.materialweb.entity;

import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "USER_CROP_ROLE", schema = "MIDAS")
public class UserCropRoleEntity implements Serializable {
    @Id
    @Column(name = "USER_CROP_ROLE_ID", nullable = false)
    private Long id;

    @Column(name = "REF_ACTIVE")
    private String refActive;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "MIDAS_USER_ID", nullable = false)
    private MidasUserEntity midasUser;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private CropEntity crop;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "MIDAS_ROLE_ID", nullable = false)
    private MidasRoleEntity midasRole;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public MidasUserEntity getMidasUser() {
        return midasUser;
    }

    public void setMidasUser(MidasUserEntity midasUser) {
        this.midasUser = midasUser;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

    public MidasRoleEntity getMidasRole() {
        return midasRole;
    }

    public void setMidasRole(MidasRoleEntity midasRole) {
        this.midasRole = midasRole;
    }
}
