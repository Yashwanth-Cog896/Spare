package com.monsanto.tps.materialweb.service.adapter;

import com.monsanto.tps.regulatory.traitquality.isolation.CropTO;
import com.monsanto.tps.regulatory.traitquality.isolation.policy.TraitQualityPolicyService;

import javax.annotation.Resource;
import java.util.Collection;

public class TraitQualityPolicyServiceAdapter {
    @Resource
    private TraitQualityPolicyService traitQualityPolicyService;

    public Collection<CropTO> getTraitQualityPolicyCrops() throws Exception {
        return traitQualityPolicyService.getPolicyCrops();
    }
}
