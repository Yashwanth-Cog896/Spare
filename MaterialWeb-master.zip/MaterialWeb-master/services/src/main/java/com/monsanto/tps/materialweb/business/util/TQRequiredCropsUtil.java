package com.monsanto.tps.materialweb.business.util;

import com.monsanto.tps.materialweb.service.adapter.TraitQualityPolicyServiceAdapter;
import com.monsanto.tps.regulatory.traitquality.isolation.CropTO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collection;

public class TQRequiredCropsUtil {
    private static final Log logger = LogFactory.getLog(TQRequiredCropsUtil.class);
    private static final long cacheDataTimeInMilliseconds = 43200000l; //12 hours
    private static long lastUpdateTimeInMilliseconds = 0;

    @Resource
    private TraitQualityPolicyServiceAdapter traitQualityPolicyServiceAdapter;

    private Collection<CropTO> tqRequiredCrops;

    public boolean isCropTQRequiredByCropId(Long cropId) {
        checkTQRequiredCropsLoad();
        if (!CollectionUtils.isEmpty(tqRequiredCrops)) {
            for (CropTO requiredCrop : tqRequiredCrops) {
                if (requiredCrop.getId().equals(cropId)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isCropTQRequiredByCropName(String cropName) {
        checkTQRequiredCropsLoad();
        if (!CollectionUtils.isEmpty(tqRequiredCrops)) {
            for (CropTO requiredCrop : tqRequiredCrops) {
                if (requiredCrop.getName().equalsIgnoreCase(cropName)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void checkTQRequiredCropsLoad() {
        long refreshTime = lastUpdateTimeInMilliseconds + cacheDataTimeInMilliseconds;
        if (CollectionUtils.isEmpty(tqRequiredCrops) || System.currentTimeMillis() > refreshTime) {
            getTQRequiredCrops();
        }
    }

    private void getTQRequiredCrops() {
        try {
            tqRequiredCrops = traitQualityPolicyServiceAdapter.getTraitQualityPolicyCrops();
            lastUpdateTimeInMilliseconds = System.currentTimeMillis();
        } catch (Exception e) {
            logger.error("Failed trying to get TQ required crops.", e);
        }
    }
}
