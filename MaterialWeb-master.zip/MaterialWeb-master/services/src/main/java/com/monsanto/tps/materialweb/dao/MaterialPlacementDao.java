package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.model.MaterialPlacementInformation;

import java.util.List;

public interface MaterialPlacementDao {
    List<MaterialPlacementInformation> getPlacementInfo(List<String> barcodes);
}
