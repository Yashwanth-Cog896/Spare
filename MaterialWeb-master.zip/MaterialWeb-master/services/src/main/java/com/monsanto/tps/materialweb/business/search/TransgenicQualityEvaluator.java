package com.monsanto.tps.materialweb.business.search;

import com.monsanto.tps.materialweb.model.MaterialInformation;

import java.util.Collection;

public interface TransgenicQualityEvaluator {
    void updateTransgenticColumns(Collection<MaterialInformation> searchResults);
}
