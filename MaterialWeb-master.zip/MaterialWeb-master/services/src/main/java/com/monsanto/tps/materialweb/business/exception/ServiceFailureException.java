package com.monsanto.tps.materialweb.business.exception;

public class ServiceFailureException extends Exception {
    public ServiceFailureException(String message) {
        super(message);
    }

    public ServiceFailureException(String message, Throwable cause) {
        super(message, cause);
    }
}
