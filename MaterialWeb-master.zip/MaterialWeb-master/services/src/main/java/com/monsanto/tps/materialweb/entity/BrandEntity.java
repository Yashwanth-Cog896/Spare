package com.monsanto.tps.materialweb.entity;

import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "BRAND", schema = "MIDAS")
public class BrandEntity implements Serializable {
    @Id
    @Column(name = "BRAND_ID", nullable = false)
    private Long brandId;
    @Column(name = "NAME")
    private String brandName;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "COMPANY_ID", nullable = false)
    private CompanyEntity company;

    public Long getBrandId() {
        return brandId;
    }

    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public CompanyEntity getCompany() {
        return company;
    }

    public void setCompany(CompanyEntity company) {
        this.company = company;
    }
}
