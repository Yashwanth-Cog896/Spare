package com.monsanto.tps.materialweb.entity;

import java.io.Serializable;

public class TempSessionOcdEntity implements Serializable {

    private TempSessionOcdId id;
    public static final String SESSION_ID = "SESSION_ID";

    public TempSessionOcdEntity() {
    }

    public TempSessionOcdEntity(TempSessionOcdId x) {
        this.id = x;
    }

    public TempSessionOcdId getId() {
        return this.id;
    }

    public void setId(TempSessionOcdId x) {
        this.id = x;
    }
}
