package com.monsanto.tps.materialweb.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.materialweb.UserDetailsHelper;
import com.monsanto.tps.materialweb.dao.MaterialPlacementDao;
import com.monsanto.tps.materialweb.model.MaterialPlacementInformation;
import com.monsanto.tps.materialweb.service.MaterialPlacementService;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

public class MaterialPlacementServiceImpl implements MaterialPlacementService {
    public static final String ROLE_BREEDER = "ROLE_BREEDER";
    public static final String ROLE_INVENTORY_PROCESSOR = "ROLE_INVENTORY PROCESSOR";
    public static final String INVENTORY_COUNT = "inventory count";
    public static final String PLACEMENT_INFO_COUNT = "placement info count";

    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;
    private MaterialPlacementDao materialPlacementDao;

    @Resource(name = "dataPointHolder")
    DataPointHolder dataPointHolder;

    public MaterialPlacementServiceImpl(MaterialPlacementDao materialPlacementDao, UserDetailsProvider<EnhancedUserDetails> userDetailsProvider) {
        this.materialPlacementDao = materialPlacementDao;
        this.userDetailsProvider = userDetailsProvider;
    }

    @Override
    @Transactional(readOnly = true)
    @PerformanceMetric(task = "show placement info", comment = "")
    public MaterialPlacementInformation[] placement(String barcodes) {
        List<String> barcodeList = Lists.newArrayList(StringUtils.tokenizeToStringArray(barcodes, ","));
        List<MaterialPlacementInformation> materialPlacementInformationList = materialPlacementDao.getPlacementInfo(barcodeList);
        scrubData(materialPlacementInformationList);
        logMetrics(barcodeList, materialPlacementInformationList);
        return materialPlacementInformationList.toArray(new MaterialPlacementInformation[materialPlacementInformationList.size()]);
    }

    private void logMetrics(List<String> barcodeList, List<MaterialPlacementInformation> materialPlacementInformationList) {
        dataPointHolder.add(INVENTORY_COUNT, barcodeList.size());
        dataPointHolder.add(PLACEMENT_INFO_COUNT, materialPlacementInformationList.size());
    }

    private void scrubData(List<MaterialPlacementInformation> materialPlacementInformationList) {
        if (!UserDetailsHelper.hasRole((Collection<GrantedAuthority>) userDetailsProvider.getUserDetails().getAuthorities(), ROLE_BREEDER, ROLE_INVENTORY_PROCESSOR)) {
            for (MaterialPlacementInformation materialPlacementInformation : materialPlacementInformationList) {
                materialPlacementInformation.setPedigree(null);
                materialPlacementInformation.setSource(null);
            }
        }
    }
}
