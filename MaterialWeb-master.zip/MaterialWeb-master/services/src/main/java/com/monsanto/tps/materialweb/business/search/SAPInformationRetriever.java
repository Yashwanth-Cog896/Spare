package com.monsanto.tps.materialweb.business.search;

import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;

import java.util.Collection;

public interface SAPInformationRetriever {

    public Collection<PipelineBatchInformationDTO> retrieveInfo(MaterialSearchCriteria criteria) throws ServiceFailureException;
}
