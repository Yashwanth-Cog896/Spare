package com.monsanto.tps.materialweb.entity;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;

@Entity
@Immutable
@Table(name = "UOM")
public class UnitOfMeasureEntity {
    @Column(name = "UOM_ID", nullable = false)
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
    private Long uomId;

    @Column(name = "NAME", nullable = false, length = 50)
    private String name;

    @Column(name = "UOM_REF_ID", nullable = false)
    private String referenceId;

    @Column(name = "REF_ACTIVE", nullable = false)
    private String referenceActive;

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceCode) {
        this.referenceId = referenceCode;
    }

    public String getReferenceActive() {
        return referenceActive;
    }

    public void setReferenceActive(String referenceActive) {
        this.referenceActive = referenceActive;
    }
}
