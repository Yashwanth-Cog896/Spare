package com.monsanto.tps.materialweb.service.impl;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.inventory.CreationProcessor;
import com.monsanto.tps.materialweb.business.search.MaterialSearchProcessor;
import com.monsanto.tps.materialweb.model.CreationRequest;
import com.monsanto.tps.materialweb.model.CreationResults;
import com.monsanto.tps.materialweb.model.SearchCriteriaModel;
import com.monsanto.tps.materialweb.model.SearchMaterialResults;
import com.monsanto.tps.materialweb.service.MaterialService;
import org.apache.commons.lang.StringUtils;

import javax.annotation.Resource;
import java.util.Collection;


public class MaterialServiceImpl extends AbstractUserInfoService implements MaterialService {

    public static final String NULL_TEXT_VALUE = "NULL";
    @Resource
    private MaterialSearchProcessor materialSearchProcessor;
    @Resource
    private CreationProcessor creationProcessor;

    @Override
    public SearchMaterialResults searchMaterial(SearchCriteriaModel model) {
        Long cropId = Long.parseLong(model.getCropId());
        Collection<String> searchValues1 = parseStringToCollection(model.getSearchValue1());
        Collection<String> searchValues2 = parseStringToCollection(model.getSearchValue2());
        return materialSearchProcessor.processMaterialSearch(cropId, model.getSearchType1(), searchValues1, model.getSearchType2(), searchValues2);
    }

    @Override
    public CreationResults createMaterial(Collection<CreationRequest> requests) {
        return creationProcessor.createNewSources(requests, getUserLoginId());
    }

    protected Collection<String> parseStringToCollection(String valueString) {
        if (StringUtils.isEmpty(valueString)) {
            return Lists.newArrayList();
        } else {
            return Lists.newArrayList(Splitter.on(CharMatcher.anyOf(" \n\t")).trimResults().omitEmptyStrings().split(valueString));
        }
    }

}
