package com.monsanto.tps.materialweb.business.model;

import com.google.common.collect.Sets;

import java.util.Set;

public class CommercialName {
    private Set<String> commercialNames = Sets.newLinkedHashSet();
    private Set<String> brandNames = Sets.newLinkedHashSet();

    public CommercialName() {
    }

    public CommercialName(String commercialName, String brandName) {
        commercialNames.add(commercialName);
        brandNames.add(brandName);
    }

    public String getCommercialName() {
        return stringify(commercialNames);
    }

    public void setCommercialName(String commercialName) {
            commercialNames.add(commercialName);
    }

    public String getBrandName() {
        return stringify(brandNames);
    }

    public void setBrandName(String brandName) {
            brandNames.add(brandName);
    }

    private String stringify(Set<String> names) {
        StringBuffer result = new StringBuffer();
        for (String name : names) {
            if(result.length() > 0) {
                result.append(", ");
            }
            result.append(name);
        }
        return result.toString();
    }
}