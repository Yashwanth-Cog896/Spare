package com.monsanto.tps.materialweb.entity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public class TempSessionOcdId implements Serializable {
    private Long requestId;
    private Long number1;
    private Long number2;
    private String text1;
    private String text2;
    private Long sortOrder;

    public TempSessionOcdId() {
    }

    public TempSessionOcdId(Long id, Long sort) {
        this.requestId = id;
        this.sortOrder = sort;
    }

    public TempSessionOcdId(Long id, Long num1,
                            Long num2, String t1, String t2, Long sort) {
        this.requestId = id;
        this.number1 = num1;
        this.number2 = num2;
        this.text1 = t1;
        this.text2 = t2;
        this.sortOrder = sort;
    }

    public Long getRequestId() {
        return this.requestId;
    }

    public void setRequestId(Long id) {
        this.requestId = id;
    }

    public Long getNumber1() {
        return number1;
    }

    public void setNumber1(Long num) {
        this.number1 = num;
    }

    public Long getNumber2() {
        return number2;
    }

    public void setNumber2(Long num) {
        this.number2 = num;
    }

    public String getText1() {
        return this.text1;
    }

    public void setText1(String s) {
        this.text1 = s;
    }

    public String getText2() {
        return this.text2;
    }

    public void setText2(String s) {
        this.text2 = s;
    }

    public Long getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Long sort) {
        this.sortOrder = sort;
    }

    private List<?> identityValues() {
        return Arrays.asList(requestId, number1, number2, text1, text2, sortOrder);
    }

    @Override
    public boolean equals(Object object) {
        return (object == this) || ((object instanceof TempSessionOcdId) && equalsImpl((TempSessionOcdId) object));
    }

    private boolean equalsImpl(TempSessionOcdId tempSessionOcdId) {
        return identityValues().equals(tempSessionOcdId.identityValues());
    }

    @Override
    public int hashCode() {
        return identityValues().hashCode();
    }
}
