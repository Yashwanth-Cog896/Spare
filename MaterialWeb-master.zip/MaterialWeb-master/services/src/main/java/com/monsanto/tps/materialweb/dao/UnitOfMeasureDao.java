package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.entity.UnitOfMeasureEntity;

import java.util.Collection;

public interface UnitOfMeasureDao {
    Collection<UnitOfMeasureEntity> getInventoryUnitOfMeasures();
}
