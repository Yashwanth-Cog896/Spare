package com.monsanto.tps.materialweb.dao;

import java.util.Set;

public interface TempSessionOcdDao {
    void insertNumberValues(Long requestId, Set<Long> ids);
}
