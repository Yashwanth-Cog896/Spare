package com.monsanto.tps.materialweb.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.inventory.CropOptionsProcessor;
import com.monsanto.tps.materialweb.dao.MidasRefDataDao;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.model.Crop;
import com.monsanto.tps.materialweb.model.CropOptions;
import com.monsanto.tps.materialweb.service.ReferenceDataService;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;


public class ReferenceDataServiceImpl extends AbstractUserInfoService implements ReferenceDataService {

    @Resource
    private MidasRefDataDao midasRefDataDao;
    @Resource
    private CropOptionsProcessor cropOptionsProcessor;

    @Override
    @Transactional(readOnly = true)
    public List<Crop> getUserCropNames() {
        //Get userId from WAM and get crops for that user.
        String userId = getUserLoginId();
        CropEntity[] cropEntities = midasRefDataDao.getInventoryImportUserCrops(userId);
        return buildCropList(cropEntities);
    }

    @Override
    @Transactional(readOnly = true)
    public CropOptions getCropReferenceData(Long cropId) {
        return cropOptionsProcessor.getDetailsForCrop(cropId);
    }

    private List<Crop> buildCropList(CropEntity[] cropEntities) {
        List<Crop> crops = Lists.newArrayList();
        if (cropEntities != null && cropEntities.length > 0) {
            for (CropEntity entity : cropEntities) {
                crops.add(new Crop(entity.getCropId(), entity.getCropName()));
            }
        }
        Collections.sort(crops);
        return crops;
    }
}
