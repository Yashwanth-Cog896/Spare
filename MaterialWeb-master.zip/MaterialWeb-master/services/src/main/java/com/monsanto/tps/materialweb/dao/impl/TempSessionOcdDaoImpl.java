package com.monsanto.tps.materialweb.dao.impl;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.dao.TempSessionOcdDao;
import com.monsanto.tps.materialweb.entity.TempSessionOcdEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdId;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

public class TempSessionOcdDaoImpl implements TempSessionOcdDao {
    public static final int MAX_ITEMS_BEFORE_FLUSH = 1000;

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public void insertNumberValues(Long requestId, Set<Long> ids) {
        Session session = getSession();
        Iterable<List<Long>> idBatches = Iterables.partition(ids, MAX_ITEMS_BEFORE_FLUSH);
        for (List<Long> idBatch : idBatches) {
            List<TempSessionOcdEntity> tempSessionOcds = Lists.newArrayList();
            for (Long id : idBatch) {
                TempSessionOcdEntity tempSessionOcd = new TempSessionOcdEntity(new TempSessionOcdId(requestId, id, null, null, null, 1L));
                session.save(tempSessionOcd);
                tempSessionOcds.add(tempSessionOcd);
            }
            flushAndEvict(session, tempSessionOcds);
        }
    }

    private void flushAndEvict(Session session, List<TempSessionOcdEntity> tempSessionOcds) {
        session.flush();
        for (TempSessionOcdEntity tempSessionOcd : tempSessionOcds) {
            session.evict(tempSessionOcd);
        }
    }

    protected Session getSession() {
        return sessionFactory.getCurrentSession();
    }

}
