package com.monsanto.tps.materialweb;

import com.monsanto.tps.security.authorization.SecurityRoleTransformer;

import java.util.Set;

public class DefaultSecurityRoleTransformer implements SecurityRoleTransformer {
    @Override
    public Set<String> transformSecurityRoles(Set<String> grantedAuthorities) {
        return grantedAuthorities;
    }
}
