package com.monsanto.tps.materialweb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "MIDAS_ROLE", schema = "MIDAS")
public class MidasRoleEntity implements Serializable {
    @Id
    @Column(name = "MIDAS_ROLE_ID", nullable = false)
    private Long roleId;
    @Column(name = "MIDAS_ROLE_REF_ID")
    private String roleRefId;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @Column(name = "NAME")
    private String name;
    @Column(name = "MIDAS_ROLE_TYPE_ID")
    private String roleTypeId;

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public String getRoleRefId() {
        return roleRefId;
    }

    public void setRoleRefId(String roleRefId) {
        this.roleRefId = roleRefId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoleTypeId() {
        return roleTypeId;
    }

    public void setRoleTypeId(String roleTypeId) {
        this.roleTypeId = roleTypeId;
    }
}
