package com.monsanto.tps.materialweb;

import com.google.common.collect.Sets;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Set;

public class UserDetailsHelper {

    public static boolean hasRole(Collection<GrantedAuthority> authorities, String... roles) {
        Set<String> stringAuthorities = asStringSet(authorities);
        for(String role : roles) {
            if(stringAuthorities.contains(role)) {
                return true;
            }
        }
        return false;
    }

    private static Set<String> asStringSet(Collection<GrantedAuthority> authorities) {
        Set<String> stringAuthorities = Sets.newHashSet();
        for(GrantedAuthority authority : authorities) {
            stringAuthorities.add(authority.getAuthority());
        }
        return stringAuthorities;
    }
}
