package com.monsanto.tps.materialweb.business.model;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.tps.materialweb.entity.CropEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.Map;

public class MaterialSearchCriteria {

    private CropEntity cropEntity;
    private Map<SearchType, Collection<String>> criteria = Maps.newHashMap();
    private static final String NULL_VALUE = "null";

    public MaterialSearchCriteria() {
    }

    public MaterialSearchCriteria(CropEntity crop, String searchType1, Collection<String> searchValues1, String searchType2, Collection<String> searchValues2) {
        this.cropEntity = crop;
        addSearchValue(SearchType.fromString(searchType1), searchValues1);
        addSearchValue(SearchType.fromString(searchType2), searchValues2);
    }

    public void addSearchValue(SearchType searchType, Collection<String> searchValues) {
        if (!SearchType.NONE.equals(searchType) && hasValidValue(searchValues)) {
            Collection<String> valueList = Lists.newArrayList();
            for (String value : searchValues) {
                if (value != null && !NULL_VALUE.equalsIgnoreCase(value))
                    valueList.add(value.trim());
            }
            criteria.put(searchType, valueList);
        }
    }

    private boolean hasValidValue(Collection<String> searchValue) {
        // check collection is not empty and first value is not null
        boolean validValue = false;
        if (!CollectionUtils.isEmpty(searchValue)) {
            String value = searchValue.iterator().next();
            if (!value.isEmpty() && !NULL_VALUE.equalsIgnoreCase(value)) {
                validValue = true;
            }
        }
        return validValue;
    }

    public CropEntity getCropEntity() {
        return cropEntity;
    }

    public void setCropEntity(CropEntity cropEntity) {
        this.cropEntity = cropEntity;
    }

    public Long getCropId() {
        return cropEntity.getCropId();
    }

    public Map<SearchType, Collection<String>> getCriteria() {
        return criteria;
    }

    public String buildSearchCriteriaString() {
        StringBuffer queryString = new StringBuffer();
        if (cropEntity != null) {
            queryString.append("Crop=");
            queryString.append(cropEntity.getCropName());
        }
        for (Map.Entry<SearchType, Collection<String>> entry : getCriteria().entrySet()) {
            appendSearchTypeString(entry.getKey(), entry.getValue(), queryString);
        }
        return queryString.toString();
    }

    private void appendSearchTypeString(SearchType searchType, Collection<String> searchValues, StringBuffer queryString) {
        queryString.append(", ");
        queryString.append(searchType.description());
        queryString.append("=");
        queryString.append(StringUtils.collectionToCommaDelimitedString(searchValues));
    }
}
