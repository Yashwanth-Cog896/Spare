package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.tps.materialweb.dao.MidasRefDataDao;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.entity.UserCropRoleEntity;
import org.hibernate.FetchMode;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import javax.annotation.Resource;
import java.util.List;

import static org.hibernate.criterion.Restrictions.eq;

public class MidasRefDataDaoImpl implements MidasRefDataDao {

    @Resource
    private SessionFactory sessionFactory;
    public static final String CROP_PATH = "ucr.crop";
    public static final String TRUE = "T";
    public static final String[] INVENTORY_IMPORT_ROLES = {"IIA", "IIR"};

    @Override
    public CropEntity[] getInventoryImportUserCrops(String userId) {
        List cropList = sessionFactory.getCurrentSession().createCriteria(UserCropRoleEntity.class, "ucr")
                .setFetchMode(CROP_PATH, FetchMode.JOIN)
                .add(Restrictions.eq("ucr.refActive", TRUE))
                .createCriteria("ucr.midasRole", "r")
                .add(Restrictions.eq("r.refActive", TRUE))
                .add(Restrictions.in("r.roleRefId", INVENTORY_IMPORT_ROLES))
                .createCriteria("ucr.midasUser", "u")
                .add(Restrictions.eq("u.refActive", TRUE))
                .add(Restrictions.eq("u.loginId", userId.toLowerCase()).ignoreCase())
                .createCriteria(CROP_PATH, "c")
                .add(Restrictions.eq("c.refActive", TRUE))
                .setProjection(Projections.distinct(
                        Projections.projectionList()
                                .add(Projections.property(CROP_PATH), "crop")
                )
                )
                .list();

        return (CropEntity[]) cropList.toArray(new CropEntity[0]);
    }

    @Override
    public CropEntity getCropByCropId(Long cropId) {
        CropEntity cropEntity = (CropEntity) sessionFactory.getCurrentSession()
                .createCriteria(CropEntity.class)
                .add(eq("cropId", cropId)).uniqueResult();
        return cropEntity;
    }
}
