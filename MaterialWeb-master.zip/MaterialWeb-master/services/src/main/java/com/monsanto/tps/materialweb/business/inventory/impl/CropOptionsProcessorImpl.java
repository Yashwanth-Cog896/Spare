package com.monsanto.tps.materialweb.business.inventory.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.inventory.CropOptionsProcessor;
import com.monsanto.tps.materialweb.business.util.TQRequiredCropsUtil;
import com.monsanto.tps.materialweb.dao.ProgramDao;
import com.monsanto.tps.materialweb.dao.UnitOfMeasureDao;
import com.monsanto.tps.materialweb.dao.VegetativeStructureDao;
import com.monsanto.tps.materialweb.entity.ProgramEntity;
import com.monsanto.tps.materialweb.entity.UnitOfMeasureEntity;
import com.monsanto.tps.materialweb.entity.VegetativeStructureEntity;
import com.monsanto.tps.materialweb.model.CropOptions;

import javax.annotation.Resource;
import java.util.Collection;

public class CropOptionsProcessorImpl implements CropOptionsProcessor {
    @Resource
    private ProgramDao programDao;
    @Resource
    private VegetativeStructureDao vegetativeStructureDao;
    @Resource
    private UnitOfMeasureDao unitOfMeasureDao;
    @Resource
    private TQRequiredCropsUtil tqRequiredCropsUtil;

    @Override
    public CropOptions getDetailsForCrop(Long cropId) {
        CropOptions options = new CropOptions();
        options.setAvailablePrograms(getActivePrograms(cropId));
        options.setVegetativeStructures(getVegetativeStructures(cropId));
        options.setSeedQuantityUoms(getInventoryUOMs());
        options.setTQRequiredCrop(checkTQRequiredCrop(cropId));
        return options;
    }

    Collection<String> getInventoryUOMs() {
        Collection<String> uoms = Lists.newArrayList();
        Collection<UnitOfMeasureEntity> uomEntities = unitOfMeasureDao.getInventoryUnitOfMeasures();
        for (UnitOfMeasureEntity uom : uomEntities) {
            uoms.add(uom.getName());
        }
        return uoms;
    }

    Collection<String> getVegetativeStructures(Long cropId) {
        Collection<String> vegStructures = Lists.newArrayList();
        Collection<VegetativeStructureEntity> structureEntities = vegetativeStructureDao.getVegetativeStructures(cropId);
        for (VegetativeStructureEntity structure : structureEntities) {
            vegStructures.add(structure.getReferenceCode());
        }
        return vegStructures;
    }

    Collection<String> getActivePrograms(Long cropId) {
        Collection<String> activePrograms = Lists.newArrayList();
        Collection<ProgramEntity> programs = programDao.getActiveGermplasmManagersProgramsForCrop(cropId);
        for (ProgramEntity program : programs) {
            activePrograms.add(program.getReferenceCode());
        }
        return activePrograms;
    }

    private Boolean checkTQRequiredCrop(Long cropId) {
        return tqRequiredCropsUtil.isCropTQRequiredByCropId(cropId);
    }
}