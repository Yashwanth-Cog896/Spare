package com.monsanto.tps.materialweb.entity;

import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "PRODUCT", schema = "MIDAS")
public class ProductEntity implements Serializable {
    @Id
    @Column(name = "PRODUCT_ID", nullable = false)
    private Long productId;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private CropEntity crop;

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }
}
