package com.monsanto.tps.materialweb.business.model;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonValue;

import java.net.URLDecoder;

public enum SearchType {
    BATCH("Manufacturing Batch", 1),
    MATERIAL("Manufacturing Material Number", 2),
    ACRONYM("Manufacturing Acronym", 3),
    LINECODE("Line Code", 4),
    ORIGIN("Origin", 5),
    PRECOMMERCIAL("Precommercial Name", 6),
    COMMERCIAL("Commercial Name", 7),
    MANUFACTURING_NAME("Manufacturing Name", 8),
    PRODUCT_ID("Product Id", 9),
    NONE("null", 10),
    CROP_NAME("Crop Name", 11);

    private String description;
    private int value;

    SearchType(String desc, int value) {
        this.description = desc;
        this.value = value;
    }

    @JsonValue
    public String description() {
        return description;
    }

    public int value() {
        return value;
    }

    @JsonCreator
    public static SearchType fromString(@JsonProperty("searchType") String desc) {
        if (desc != null) {
            String decodedDesc = URLDecoder.decode(desc.trim());
            for (SearchType type : SearchType.values()) {
                if (type.description.equalsIgnoreCase(decodedDesc) || type.toString().equalsIgnoreCase(decodedDesc)) {
                    return type;
                }
            }
        }
        return SearchType.NONE;
    }
}
