package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.tps.aop.cache.MethodCache;
import com.monsanto.tps.materialweb.dao.GermplasmDao;
import com.monsanto.tps.materialweb.entity.GermplasmEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

public class GermplasmDaoImpl implements GermplasmDao {

    private static final String GET_GERMPLASMS_BY_GERMPLASM_ID = "GetGermplasmsByGermplasmId";

    @Resource
    private SessionFactory sessionFactory;

    @Override
    @MethodCache
    public GermplasmEntity getGermplasm(Long germplasmId) {
        GermplasmEntity entity = (GermplasmEntity) getSession().createCriteria(GermplasmEntity.class, "g")
                .add(Restrictions.eq("germplasmId", germplasmId))
                .uniqueResult();
        return entity;
    }

    @Override
    public Collection<GermplasmEntity> getGermplasmsByTempSessionId(Long tempSessionId) {
        List<GermplasmEntity> gemplasmList = sessionFactory.getCurrentSession()
                .getNamedQuery(GET_GERMPLASMS_BY_GERMPLASM_ID)
                .setParameter(TempSessionOcdEntity.SESSION_ID, tempSessionId)
                .list();
        return gemplasmList;
    }

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }
}
