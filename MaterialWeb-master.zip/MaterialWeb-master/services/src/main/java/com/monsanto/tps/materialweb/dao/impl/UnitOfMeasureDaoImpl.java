package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.tps.aop.cache.MethodCache;
import com.monsanto.tps.materialweb.dao.UnitOfMeasureDao;
import com.monsanto.tps.materialweb.entity.UnitOfMeasureEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class UnitOfMeasureDaoImpl implements UnitOfMeasureDao {
    @Resource
    private SessionFactory sessionFactory;
    public static Collection<String> seedUOMs = Arrays.asList("SEED", "KILOGRAMS", "GRAMS", "POUNDS");

    @Override
    @MethodCache
    public Collection<UnitOfMeasureEntity> getInventoryUnitOfMeasures() {
        List<UnitOfMeasureEntity> unitOfMeasureEntities = getSession().createCriteria(UnitOfMeasureEntity.class, "uom")
                .add(Restrictions.in("uom.name", seedUOMs))
                .list();
        return unitOfMeasureEntities;
    }

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }
}
