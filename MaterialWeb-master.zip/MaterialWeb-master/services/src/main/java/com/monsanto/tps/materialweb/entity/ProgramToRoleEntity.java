package com.monsanto.tps.materialweb.entity;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;

@Entity
@Immutable
@Table(name = "PROGRAM_TO_ROLE")
public class ProgramToRoleEntity {

    @Column(name = "PROGRAM_TO_ROLE_ID", nullable = false)
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "BR_PROG_ID", nullable = false)
    private ProgramEntity program;

    @ManyToOne(optional = false)
    @JoinColumn(name = "MIDAS_ROLE_ID", nullable = false)
    private MidasRoleEntity role;

    @Column(name = "REF_ACTIVE", nullable = false)
    private String refActive;

    public Long getId() {
        return id;
    }

    void setId(final Long id) {
        this.id = id;
    }

    public ProgramEntity getProgram() {
        return program;
    }

    public void setProgram(ProgramEntity program) {
        this.program = program;
    }

    public MidasRoleEntity getRole() {
        return role;
    }

    public void setRole(MidasRoleEntity role) {
        this.role = role;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}