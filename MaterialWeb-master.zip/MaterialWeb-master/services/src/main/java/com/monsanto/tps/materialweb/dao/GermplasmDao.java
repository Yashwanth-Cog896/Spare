package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.entity.GermplasmEntity;

import java.util.Collection;

public interface GermplasmDao {

    GermplasmEntity getGermplasm(Long germplasmId);

    Collection<GermplasmEntity> getGermplasmsByTempSessionId(Long tempSessionId);
}
