package com.monsanto.tps.materialweb.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "GERMPLASM", schema = "MIDAS")
public class GermplasmEntity implements Serializable {
    @Id
    @Column(name = "GERMPLASM_ID", nullable = false)
    private Long germplasmId;
    @Column(name = "ORIGIN")
    private String origin;
    @Column(name = "LINE_CODE")
    private String lineCode;
    @Column(name = "PEDIGREE_NAME")
    private String pedigreeName;
    @Column(name = "IS_TRANSGENIC")
    private String isTransgenic;
    @Column(name = "CYTOPLASM_DONOR")
    private String cytoplasmDonor;
    @Column(name = "EVENT_DISPLAY")
    private String eventDisplay;
    @Column(name = "CONSTRUCT_DISPLAY")
    private String constructDisplay;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private CropEntity crop;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "LINE_FUNCTION_ID", nullable = true)
    private LineFunctionEntity lineFunction;
    @Column(name = "IS_DELETED")
    private String isDeleted;
    @OneToMany(mappedBy = "germplasm", fetch = FetchType.LAZY)
    private Collection<GermplasmEventConstructEntity> germplasmEventConstruct;

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getTransgenic() {
        return isTransgenic;
    }

    public void setTransgenic(String transgenic) {
        isTransgenic = transgenic;
    }

    public String getCytoplasmDonor() {
        return cytoplasmDonor;
    }

    public void setCytoplasmDonor(String cytoplasmDonor) {
        this.cytoplasmDonor = cytoplasmDonor;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public void setCrop(CropEntity crop) {
        this.crop = crop;
    }

    public LineFunctionEntity getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(LineFunctionEntity lineFunction) {
        this.lineFunction = lineFunction;
    }

    public String getDeleted() {
        return isDeleted;
    }

    public void setDeleted(String deleted) {
        isDeleted = deleted;
    }

    public Collection<GermplasmEventConstructEntity> getGermplasmEventConstruct() {
        return germplasmEventConstruct;
    }

    public void setGermplasmEventConstruct(Collection<GermplasmEventConstructEntity> germplasmEventConstruct) {
        this.germplasmEventConstruct = germplasmEventConstruct;
    }
}
