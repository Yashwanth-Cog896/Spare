package com.monsanto.tps.materialweb.service.adapter;


import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.regulatory.traitquality.sap.BatchInformationService;
import com.monsanto.tps.regulatory.traitquality.sap.SearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

public class BatchInformationServiceAdapter {

    @Resource(name = "batchInformationService")
    private BatchInformationService batchInformationService;
    private static final Log logger = LogFactory.getLog(BatchInformationService.class);

    public Collection<PipelineBatchInformationDTO> findByCriteria(SearchCriteria criteria) throws ServiceFailureException {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("Calling TQ service with criteria: " + criteria.toString());
        List<PipelineBatchInformationDTO> results = null;
        try {
            results = batchInformationService.findByCriteria(criteria);
        } catch (Exception e) {
            logger.error("Problem calling TQ Batch Info Service with " + criteria.toString(), e);
            stopWatch.stop();
            throw new ServiceFailureException("Problem calling TQ Batch Info Service ", e);
        }
        stopWatch.stop();
        logger.info(stopWatch.prettyPrint());
        return results;
    }
}
