package com.monsanto.tps.materialweb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "COMPANY", schema = "MIDAS")
public class CompanyEntity implements Serializable {
    @Id
    @Column(name = "COMPANY_ID", nullable = false)
    private Long companyId;
    @Column(name = "NAME")
    private String companyName;
    @Column(name = "REF_ACTIVE")
    private String refActive;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}
