package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.entity.CropEntity;

public interface MidasRefDataDao {

    public CropEntity[] getInventoryImportUserCrops(String userId);

    public CropEntity getCropByCropId(Long cropId);
}
