package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.entity.VegetativeStructureEntity;

import java.util.Collection;

public interface VegetativeStructureDao {
    Collection<VegetativeStructureEntity> getVegetativeStructures(Long cropId);
}
