package com.monsanto.tps.materialweb.business.search.impl;

import com.monsanto.tps.materialweb.business.search.TransgenicQualityEvaluator;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.apache.commons.lang.StringUtils;

import java.util.Collection;

public class TransgenicQualityEvaluatorImpl implements TransgenicQualityEvaluator {
    public static final String MINI_CHROMOSONE_RESTRICTION = "restrictedminic";
    public static final String ANIMAL_GENE_RESTRICITION = "restrictedanimg";

    @Override
    public void updateTransgenticColumns(Collection<MaterialInformation> searchResults) {
        for (MaterialInformation material : searchResults) {
            if (StringUtils.isEmpty(material.getMaterialNumber())) {
                material.clearTQDependentColumns();
            }
            if (!StringUtils.isEmpty(material.getBatchNumber())) {
                material.setExposureHistoryBoolean(true);
            }
            if (!StringUtils.isEmpty(material.getEvent()) || !StringUtils.isEmpty(material.getRestriction())) {
                material.setTransgenicBoolean(true);
            }
            if (!StringUtils.isEmpty(material.getRestriction())) {
                if (material.getRestriction().toLowerCase().contains(ANIMAL_GENE_RESTRICITION)) {
                    material.setAnimalGeneBoolean(true);
                }
                if (material.getRestriction().toLowerCase().contains(MINI_CHROMOSONE_RESTRICTION)) {
                    material.setMiniChromosomeBoolean(true);
                }
            }
        }
    }
}