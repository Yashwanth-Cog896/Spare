package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.tps.materialweb.dao.ProductNameDao;
import com.monsanto.tps.materialweb.entity.ProductNameEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdEntity;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import javax.annotation.Resource;
import java.util.List;

public class ProductNameDaoImpl implements ProductNameDao {

    public static final String MONSANTO_NAME = "monsanto";
    private static final String GET_COMMERCIAL_PRODUCT_NAMES_BY_PRODUCT_ID = "GetCommercialProductNamesByProductId";

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<ProductNameEntity> lookupCommercialProductName(String productName) {
        List<ProductNameEntity> productNameList = sessionFactory.getCurrentSession().createCriteria(ProductNameEntity.class, "pn")
                .add(Restrictions.eq("pn.refActive", "T"))
                .createCriteria("pn.product", "p")
                .add(Restrictions.eq("p.refActive", "T"))
                .createCriteria("pn.brand", "b")
                .add(Restrictions.eq("b.refActive", "T"))
                .add(Restrictions.ne("b.brandName", MONSANTO_NAME).ignoreCase())
                .createCriteria("b.company", "c")
                .add(Restrictions.eq("c.companyName", MONSANTO_NAME).ignoreCase())
                .add(Restrictions.eq("pn.productName", productName.toLowerCase()).ignoreCase())
                .list();
        return productNameList;
    }

    @Override
    public List<ProductNameEntity> lookupCommercialProductNameLike(String productName) {
        List<ProductNameEntity> productNameList = sessionFactory.getCurrentSession().createCriteria(ProductNameEntity.class, "pn")
                .add(Restrictions.eq("pn.refActive", "T"))
                .createCriteria("pn.product", "p")
                .add(Restrictions.eq("p.refActive", "T"))
                .createCriteria("pn.brand", "b")
                .add(Restrictions.eq("b.refActive", "T"))
                .add(Restrictions.ne("b.brandName", MONSANTO_NAME).ignoreCase())
                .createCriteria("b.company", "c")
                .add(Restrictions.eq("c.companyName", MONSANTO_NAME).ignoreCase())
                .add(Restrictions.like("pn.productName", productName.toLowerCase(), MatchMode.START).ignoreCase())
                .list();
        return productNameList;
    }

    @Override
    public List<ProductNameEntity> getCommercialProductNameByProductIds(List<Long> productIds) {
        List<ProductNameEntity> productNameList = sessionFactory.getCurrentSession().createCriteria(ProductNameEntity.class, "pn")
                .add(Restrictions.eq("pn.refActive", "T"))
                .createCriteria("pn.product", "p")
                .add(Restrictions.eq("p.refActive", "T"))
                .createCriteria("pn.brand", "b")
                .add(Restrictions.eq("b.refActive", "T"))
                .add(Restrictions.ne("b.brandName", MONSANTO_NAME).ignoreCase())
                .createCriteria("b.company", "c")
                .add(Restrictions.eq("c.companyName", MONSANTO_NAME).ignoreCase())
                .add(Restrictions.in("p.productId", productIds))
                .list();
        return productNameList;
    }

    @Override
    public List<ProductNameEntity> getCommercialProductNameByProductWithTempId(Long tempSessionId) {
        List<ProductNameEntity> productNameList = sessionFactory.getCurrentSession()
                .getNamedQuery(GET_COMMERCIAL_PRODUCT_NAMES_BY_PRODUCT_ID)
                .setParameter(TempSessionOcdEntity.SESSION_ID, tempSessionId)
                .list();
        return productNameList;
    }
}
