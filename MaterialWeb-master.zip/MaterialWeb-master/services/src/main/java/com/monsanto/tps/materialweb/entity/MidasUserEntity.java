package com.monsanto.tps.materialweb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "MIDAS_USER", schema = "MIDAS")
public class MidasUserEntity implements Serializable {
    @Id
    @Column(name = "MIDAS_USER_ID", nullable = false)
    private Long midasUserId;
    @Column(name = "LOGIN_ID")
    private String loginId;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Column(name = "MIDDLE_NAME")
    private String middleName;
    @Column(name = "LAST_NAME")
    private String lastName;

    public Long getMidasUserId() {
        return midasUserId;
    }

    public void setMidasUserId(Long midasUserId) {
        this.midasUserId = midasUserId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
