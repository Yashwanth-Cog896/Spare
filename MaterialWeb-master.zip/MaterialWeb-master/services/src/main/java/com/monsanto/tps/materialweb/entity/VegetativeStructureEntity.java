package com.monsanto.tps.materialweb.entity;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;

@Entity
@Immutable
@Table(name = "VEGETATIVE_STRUCTURE")
public class VegetativeStructureEntity {
    @Column(name = "VEGETATIVE_STRUCTURE_ID", nullable = false)
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
    private Long id;

    @Column(name = "NAME", nullable = false, length = 50)
    private String name;

    @Column(name = "REF_CD", nullable = false)
    private String referenceCode;

    @Column(name = "REF_ACTIVE", nullable = false)
    private String referenceActive;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReferenceCode() {
        return referenceCode;
    }

    public void setReferenceCode(String referenceCode) {
        this.referenceCode = referenceCode;
    }

    public String getReferenceActive() {
        return referenceActive;
    }

    public void setReferenceActive(String referenceActive) {
        this.referenceActive = referenceActive;
    }
}
