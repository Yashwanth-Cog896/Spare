package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.entity.ProgramEntity;

import java.util.Collection;

public interface ProgramDao {
    Collection<ProgramEntity> getActiveGermplasmManagersProgramsForCrop(Long cropId);
}
