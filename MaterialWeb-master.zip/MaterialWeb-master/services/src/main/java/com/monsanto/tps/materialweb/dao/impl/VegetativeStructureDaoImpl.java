package com.monsanto.tps.materialweb.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.aop.cache.MethodCache;
import com.monsanto.tps.materialweb.dao.VegetativeStructureDao;
import com.monsanto.tps.materialweb.entity.CropToVegetativeStructureEntity;
import com.monsanto.tps.materialweb.entity.VegetativeStructureEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

public class VegetativeStructureDaoImpl implements VegetativeStructureDao {

    @Resource
    private SessionFactory sessionFactory;

    @Override
    @MethodCache
    public Collection<VegetativeStructureEntity> getVegetativeStructures(Long cropId) {
        List<CropToVegetativeStructureEntity> list = getSession().createCriteria(CropToVegetativeStructureEntity.class, "cvs")
                .add(Restrictions.eq("crop.id", cropId))
                .list();
        List<VegetativeStructureEntity> structures = Lists.newArrayList();
        for (CropToVegetativeStructureEntity cropStructure : list) {
            structures.add(cropStructure.getVegetativeStructure());
        }
        return structures;
    }

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }
}
