package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.search.ExtendedBatchDetailConverter;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import com.monsanto.tps.regulatory.traitquality.sap.batch.ManufacturingDetails;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import com.monsanto.tps.regulatory.traitquality.sap.batch.ProductDetails;
import com.monsanto.tps.regulatory.traitquality.sap.batch.TechnologyDetails;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.List;

public class ExtendedBatchDetailConverterImpl implements ExtendedBatchDetailConverter {

    @Override
    public Collection<MaterialInformation> covertExtendedBatchDetails(Collection<PipelineBatchInformationDTO> details, Long cropId) {
        List<MaterialInformation> materialList = Lists.newArrayList();
        if (!CollectionUtils.isEmpty(details)) {
            for (PipelineBatchInformationDTO detail : details) {
                MaterialInformation material = new MaterialInformation();
                material.setBatchNumber(detail.getBatchNumber());
                material.setMaterialNumber(detail.getMaterialNumber());
                ManufacturingDetails sapDetails = detail.getManufacturingDetails();
                if (sapDetails != null) {
                    material.setAcronym(sapDetails.getAcronym());
                    material.setSapBrandName(sapDetails.getBrandName());
                    material.setSapCreatedDate(sapDetails.getCreationDate());
                    material.setSapMaterialDescription(sapDetails.getMaterialDescription());
                    material.setSapTraitVersion(sapDetails.getTraitVersion());
                    material.setManufacturingName(sapDetails.getManufacturingName());
                }
                TechnologyDetails gpDetails = detail.getTechnologyDetails();
                if (gpDetails != null) {
                    material.setPedigree(gpDetails.getCytoplasmDonor());
                    material.setLineCode(gpDetails.getLineCode());
                    material.setLineFunction(gpDetails.getLineFunction());
                    material.setOrigin(gpDetails.getOrigin());
                    material.setLineType(gpDetails.getLineType());
                    material.setGermplasmOwner(gpDetails.getOwner());
                    material.setPreferredGermplasm(gpDetails.getPreferredGermplasm());
                    material.setPreferredName(gpDetails.getPreferredName());
                    material.setEvent(eventNamesToString(gpDetails.getEventNames()));
                    material.setRestriction(gpDetails.getRestriction());
                    material.setId(gpDetails.getGermplasmId());
                    material.setTraitVersion(gpDetails.getLexiconTraitVersion());
                }
                ProductDetails prodDetails = detail.getProductDetails();
                if (prodDetails != null) {
                    material.setMidasCommercialBrandName(prodDetails.getBrandName());
                    material.setLexiconPreCommercialName(prodDetails.getPrecommercialName());
                    material.setMidasCommercialName(prodDetails.getProductName());
                }
                material.setCropId(cropId);
                materialList.add(material);
            }
        }
        return materialList;
    }

    private String eventNamesToString(List<String> eventNames) {
        return StringUtils.collectionToCommaDelimitedString(eventNames);
    }

}
