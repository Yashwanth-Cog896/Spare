package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.tps.materialweb.dao.EventConstructDao;
import com.monsanto.tps.materialweb.entity.GermplasmEventConstructEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdEntity;
import org.hibernate.SessionFactory;

import javax.annotation.Resource;
import java.util.List;

public class EventConstructDaoImpl implements EventConstructDao {

    private static final String GET_EVENT_CONSTRUCTS_BY_GERMPLASM_ID = "GetEventConstructsByGermplasmId";

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<GermplasmEventConstructEntity> getEventsForGermplasmIdWithTempSessionId(Long tempSessionId) {
        List<GermplasmEventConstructEntity> gemplasmEventConstructList = sessionFactory.getCurrentSession()
                .getNamedQuery(GET_EVENT_CONSTRUCTS_BY_GERMPLASM_ID)
                .setParameter(TempSessionOcdEntity.SESSION_ID, tempSessionId)
                .list();
        return gemplasmEventConstructList;
    }
}
