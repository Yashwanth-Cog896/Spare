package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.tps.materialweb.dao.MaterialPlacementDao;
import com.monsanto.tps.materialweb.model.MaterialPlacementInformation;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class MaterialPlacementDaoImpl extends AbstractJDBCDao implements MaterialPlacementDao {
    private static final String PLACEMENT_INFO_QUERY = "com/monsanto/tps/materialweb/sql/PlacementInfoQuery.sql";

    @Override
    public List<MaterialPlacementInformation> getPlacementInfo(List<String> barcodes) {
        SqlParameterSource parameterSource = new MapSqlParameterSource("barcodes", barcodes);
        return getNamedParameterJdbcTemplate().query(readSql(PLACEMENT_INFO_QUERY), parameterSource, new MaterialPlacementInfoRowMapper());
    }

    private class MaterialPlacementInfoRowMapper implements RowMapper<MaterialPlacementInformation> {

        @Override
        public MaterialPlacementInformation mapRow(ResultSet rs, int rowNum) throws SQLException {
            MaterialPlacementInformation retVal = new MaterialPlacementInformation();
            retVal.setInventoryBarcode(rs.getString("inventory_barcode"));
            retVal.setPedigree(rs.getString("pedigree"));
            retVal.setSource(rs.getString("source"));
            retVal.setSeason(rs.getString("season"));
            retVal.setSetName(rs.getString("set_name"));
            retVal.setSetType(getSetType(rs));
            retVal.setRepNumber(getInteger(rs, "rep_number"));
            retVal.setLocationName(rs.getString("location_name"));
            retVal.setLocationRefId(rs.getString("location_ref_id"));
            retVal.setFieldName(rs.getString("field_name"));
            retVal.setTrackId(rs.getString("track_id"));
            retVal.setFieldType(rs.getString("field_type"));
            retVal.setEntryNumber(getInteger(rs, "entry_number"));
            retVal.setPlotBarcode(rs.getString("plot_barcode"));
            retVal.setPlotNumber(getInteger(rs, "plot_number"));
            retVal.setAbsRange(getInteger(rs, "abs_range"));
            retVal.setAbsColumn(getInteger(rs, "abs_column"));
            return retVal;
        }

        private String getSetType(ResultSet rs) throws SQLException {
            String setType = rs.getString("set_type");
            String icb = rs.getString("icb");
            return "T".equals(icb) ? "ICB" : setType;
        }

        private Integer getInteger(ResultSet rs, String columnLabel) throws SQLException {
            int val = rs.getInt(columnLabel);
            return rs.wasNull() ? null : val;
        }
    }
}
