package com.monsanto.tps.materialweb.business.inventory;

import com.monsanto.tps.materialweb.model.CreationRequest;
import com.monsanto.tps.materialweb.model.CreationResults;

import java.util.Collection;

public interface CreationProcessor {

    CreationResults createNewSources(Collection<CreationRequest> requests, String loginId);
}
