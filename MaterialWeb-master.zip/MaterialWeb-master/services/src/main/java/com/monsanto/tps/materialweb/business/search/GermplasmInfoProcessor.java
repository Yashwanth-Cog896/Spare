package com.monsanto.tps.materialweb.business.search;

import com.monsanto.tps.materialweb.model.MaterialInformation;

import java.util.Collection;

public interface GermplasmInfoProcessor {

    void addGermplasmInfoToResults(Collection<MaterialInformation> searchResults);
}
