package com.monsanto.tps.materialweb.entity;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.util.Set;

@Entity
@Immutable
@Table(name = "BR_PROG")
public class ProgramEntity {

    @Column(name = "BR_PROG_ID", nullable = false)
    @Id
    @GeneratedValue(generator = "idGenerator")
    @GenericGenerator(name = "idGenerator", strategy = "com.monsanto.tps.primarykey.midas.MidasKeyGenerator")
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "CROP_ID", nullable = false)
    private CropEntity crop;

    @Column(name = "NAME", nullable = false, length = 50)
    private String name;

    @Column(name = "BR_PROG_REF_ID", nullable = false)
    private String referenceCode;

    @OneToMany(mappedBy = "program")
    private Set<ProgramToRoleEntity> programToRoleEntities;

    @Column(name = "REF_ACTIVE", nullable = false)
    private String refActive;

    public Long getId() {
        return id;
    }

    public CropEntity getCrop() {
        return crop;
    }

    public String getName() {
        return name;
    }

    public void setCrop(final CropEntity crop) {
        this.crop = crop;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getReferenceCode() {
        return referenceCode;
    }

    public void setReferenceCode(String referenceCode) {
        this.referenceCode = referenceCode;
    }

    void setId(final Long id) {
        this.id = id;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refACtive) {
        this.refActive = refACtive;
    }
}