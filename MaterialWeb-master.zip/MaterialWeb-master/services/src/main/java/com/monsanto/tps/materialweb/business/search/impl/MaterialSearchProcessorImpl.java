package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.materialweb.business.search.*;
import com.monsanto.tps.materialweb.dao.MidasRefDataDao;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import com.monsanto.tps.materialweb.model.MaterialInformationComparator;
import com.monsanto.tps.materialweb.model.SearchMaterialResults;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class MaterialSearchProcessorImpl implements MaterialSearchProcessor {
    public static final String NULL_TEXT_VALUE = "NULL";
    private static final Log logger = LogFactory.getLog(MaterialSearchProcessorImpl.class);

    @Resource
    private MidasRefDataDao midasRefDataDao;
    @Resource
    private SAPInformationRetriever sapInformationRetriever;
    @Resource
    private ExtendedBatchDetailConverter extendedBatchDetailConverter;
    @Resource
    private TransgenicQualityEvaluator transgenicQualityEvaluator;
    @Resource
    private GermplasmInfoProcessor germplasmInfoProcessor;
    private final static int INVENTORY_SIZE_LIMIT = 1050;
    private final static String INVENTORY_RESULT_SIZE_WARNING = "Returning first 1000 of %d material results.  Please refine criteria to limit the search results.";

    @Transactional
    @Override
    @PerformanceMetric(task = "Process Search Materials", comment = "call TQ service and transform data")
    public SearchMaterialResults processMaterialSearch(Long cropId, String searchType1, Collection<String> searchValue1, String searchType2, Collection<String> searchValue2) {
        CropEntity cropEntity = getCropEntity(cropId);
        MaterialSearchCriteria criteria = new MaterialSearchCriteria(cropEntity, searchType1, searchValue1, searchType2, searchValue2);
        String criteriaString = criteria.buildSearchCriteriaString();
        try {
            Collection<MaterialInformation> materials = performSearchNew(criteria);
            Collection<MaterialInformation> filteredMaterials = filterFinishedAndCodedLines(materials);
            transgenicQualityEvaluator.updateTransgenticColumns(filteredMaterials);
            return buildSearchMaterialResults(filteredMaterials, criteriaString);
        } catch (Exception e) {
            SearchMaterialResults results = new SearchMaterialResults();
            logger.warn("Error during search; criteria=" + criteriaString + " ", e);
            results.setWarning("Problem with search " + e.toString());
            results.setMaterialInformation(Lists.<MaterialInformation>newArrayList());
            results.setQueryString(criteriaString);
            results.setSearchResultCount(0);
            return results;
        }
    }

    protected Collection<MaterialInformation> performSearchNew(MaterialSearchCriteria criteria) throws ServiceFailureException {
        Collection<PipelineBatchInformationDTO> batchDetailList = sapInformationRetriever.retrieveInfo(criteria);
        Collection<MaterialInformation> materials = extendedBatchDetailConverter.covertExtendedBatchDetails(batchDetailList, criteria.getCropId());
        return materials;
    }

    private SearchMaterialResults buildSearchMaterialResults(Collection<MaterialInformation> materials, String criteriaString) {
        SearchMaterialResults results = new SearchMaterialResults();
        Collection<MaterialInformation> uniqueMaterials = getUniqueListForDisplay(materials);
        germplasmInfoProcessor.addGermplasmInfoToResults(uniqueMaterials);
        results.setQueryString(criteriaString);
        if (uniqueMaterials.size() > INVENTORY_SIZE_LIMIT) {
            results.setWarning(String.format(INVENTORY_RESULT_SIZE_WARNING, uniqueMaterials.size()));
            Collection<MaterialInformation> materialInformation = ((List) uniqueMaterials).subList(0, 1000);
            results.setMaterialInformation(materialInformation);
            results.setSearchResultCount(materialInformation.size());
        } else {
            results.setMaterialInformation(uniqueMaterials);
            results.setSearchResultCount(uniqueMaterials.size());
        }
        return results;
    }

    private CropEntity getCropEntity(Long cropId) {
        return midasRefDataDao.getCropByCropId(cropId);
    }

    private Collection<MaterialInformation> getUniqueListForDisplay(Collection<MaterialInformation> materials) {
        //reduce the result set by unique columns that are being displayed  (the UI does not care about IDs (germplasmId or productId)
        Set uniqueInventories = Sets.newTreeSet(new MaterialInformationComparator());
        uniqueInventories.addAll(materials);
        return Lists.newArrayList(uniqueInventories);
    }

    public Collection<MaterialInformation> filterFinishedAndCodedLines(Collection<MaterialInformation> searchResults) {
        Collection<MaterialInformation> results;
        if (hasFinishedLineType(searchResults)) {
            results = removeCodedLineTypes(searchResults);
        } else {
            results = searchResults;
        }
        return results;
    }

    private Collection<MaterialInformation> removeCodedLineTypes(Collection<MaterialInformation> searchResults) {
        Collection<MaterialInformation> updatedResults = Lists.newArrayList();
        for (MaterialInformation ii : searchResults) {
            if (!ii.getLineType().equalsIgnoreCase("coded")) {
                updatedResults.add(ii);
            }
        }
        return updatedResults;
    }

    private boolean hasFinishedLineType(Collection<MaterialInformation> searchResults) {
        for (MaterialInformation ii : searchResults) {
            String lineType = ii.getLineType();
            if (lineType != null && lineType.equalsIgnoreCase("finished")) {
                return true;
            }
        }
        return false;
    }
}
