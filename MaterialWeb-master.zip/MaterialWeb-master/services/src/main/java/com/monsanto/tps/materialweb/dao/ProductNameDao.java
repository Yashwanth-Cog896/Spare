package com.monsanto.tps.materialweb.dao;


import com.monsanto.tps.materialweb.entity.ProductNameEntity;

import java.util.List;

public interface ProductNameDao {
    List<ProductNameEntity> lookupCommercialProductName(String productName);

    List<ProductNameEntity> lookupCommercialProductNameLike(String productName);

    List<ProductNameEntity> getCommercialProductNameByProductIds(List<Long> productIds);

    List<ProductNameEntity> getCommercialProductNameByProductWithTempId(Long tempSessionId);
}
