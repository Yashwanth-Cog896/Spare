package com.monsanto.tps.materialweb.entity;

import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "PRODUCT_NAME", schema = "MIDAS")
public class ProductNameEntity implements Serializable {
    @Id
    @Column(name = "PRODUCT_NAME_ID", nullable = false)
    private Long productNameId;
    @Column(name = "NAME")
    private String productName;
    @Column(name = "REF_ACTIVE")
    private String refActive;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "BRAND_ID", nullable = false)
    private BrandEntity brand;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private ProductEntity product;

    public Long getProductNameId() {
        return productNameId;
    }

    public void setProductNameId(Long productNameId) {
        this.productNameId = productNameId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public BrandEntity getBrand() {
        return brand;
    }

    public void setBrand(BrandEntity brand) {
        this.brand = brand;
    }

    public ProductEntity getProduct() {
        return product;
    }

    public void setProduct(ProductEntity product) {
        this.product = product;
    }
}
