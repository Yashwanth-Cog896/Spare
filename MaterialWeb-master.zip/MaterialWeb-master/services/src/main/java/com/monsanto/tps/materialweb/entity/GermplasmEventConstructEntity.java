package com.monsanto.tps.materialweb.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

import static javax.persistence.FetchType.LAZY;

@Entity
@Table(name = "GERMPLASM_EVENT_CONSTRUCT", schema = "MIDAS")
public class GermplasmEventConstructEntity implements Serializable {
    @Id
    @Column(name = "GERMPLASM_EVENT_CONSTRUCT_ID", nullable = false)
    private Long germplasmEventConstructId;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "EVENT_CONSTRUCT_ID", nullable = false)
    private EventConstructEntity event;
    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "GERMPLASM_ID", nullable = false)
    private GermplasmEntity germplasm;
    @Column(name = "EVENT_CONSTRUCT_ABSENCE_DATE")
    private Date absenceDate;

    public Long getGermplasmEventConstructId() {
        return germplasmEventConstructId;
    }

    public void setGermplasmEventConstructId(Long germplasmEventConstructId) {
        this.germplasmEventConstructId = germplasmEventConstructId;
    }

    public EventConstructEntity getEvent() {
        return event;
    }

    public void setEvent(EventConstructEntity event) {
        this.event = event;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public Date getAbsenceDate() {
        return absenceDate;
    }

    public void setAbsenceDate(Date absenceDate) {
        this.absenceDate = absenceDate;
    }
}
