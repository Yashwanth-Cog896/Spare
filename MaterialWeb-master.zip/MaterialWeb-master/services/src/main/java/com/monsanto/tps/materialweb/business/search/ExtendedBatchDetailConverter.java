package com.monsanto.tps.materialweb.business.search;

import com.monsanto.tps.materialweb.model.MaterialInformation;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;

import java.util.Collection;

public interface ExtendedBatchDetailConverter {
    public Collection<MaterialInformation> covertExtendedBatchDetails(Collection<PipelineBatchInformationDTO> details, Long cropId);
}
