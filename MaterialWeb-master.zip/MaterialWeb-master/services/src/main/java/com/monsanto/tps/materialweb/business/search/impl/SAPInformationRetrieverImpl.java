package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.materialweb.business.model.SearchType;
import com.monsanto.tps.materialweb.business.search.SAPInformationRetriever;
import com.monsanto.tps.materialweb.service.adapter.BatchInformationServiceAdapter;
import com.monsanto.tps.regulatory.traitquality.sap.Attribute;
import com.monsanto.tps.regulatory.traitquality.sap.AttributeFilter;
import com.monsanto.tps.regulatory.traitquality.sap.SearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class SAPInformationRetrieverImpl implements SAPInformationRetriever {
    @Resource
    private BatchInformationServiceAdapter batchInformationServiceAdapter;

    @Override
    public Collection<PipelineBatchInformationDTO> retrieveInfo(MaterialSearchCriteria criteria) throws ServiceFailureException {
        SearchCriteria searchCriteria = createSearchCriteria(criteria);
        return batchInformationServiceAdapter.findByCriteria(searchCriteria);
    }

    private SearchCriteria createSearchCriteria(MaterialSearchCriteria criteria) {
        SearchCriteria searchCriteria = new SearchCriteria();
        AttributeFilter cropFilter = new AttributeFilter(getSearchCriteriaAttribute(SearchType.CROP_NAME), criteria.getCropEntity().getCropName(), false);
        List<AttributeFilter> simpleFilters = Lists.newArrayList(cropFilter);
        for (Map.Entry<SearchType, Collection<String>> entry : criteria.getCriteria().entrySet()) {
            if (!CollectionUtils.isEmpty(entry.getValue())) {
                simpleFilters.add(buildSimpleSearchCriteria(entry.getKey(), entry.getValue()));
            }
        }
        searchCriteria.setSimpleAttributeFilters(simpleFilters);
        return searchCriteria;
    }

    private AttributeFilter buildSimpleSearchCriteria(SearchType searchType, Collection<String> values) {
        AttributeFilter filter = new AttributeFilter();
        filter.setAttribute(getSearchCriteriaAttribute(searchType));
        if (values.size() > 1) {
            filter.setValueList(getTrimmedValues(values));
        } else {
            String value = values.iterator().next();
            filter.setValue(trimValue(value));
            filter.setWildcard(valueHasWildCard(value));
        }
        return filter;
    }

    private List<String> getTrimmedValues(Collection<String> values) {
        List<String> trimmedValues = Lists.newArrayList();
        for (String s : values) {
            trimmedValues.add(trimValue(s));
        }
        return trimmedValues;
    }

    private Attribute getSearchCriteriaAttribute(SearchType searchType) {
        Attribute attribute = null;
        switch (searchType) {
            case ACRONYM: {
                attribute = Attribute.MANUFACTURING_ACRONYM;
                break;
            }
            case LINECODE: {
                attribute = Attribute.LINE_CODE;
                break;
            }
            case ORIGIN: {
                attribute = Attribute.ORIGIN;
                break;
            }
            case PRECOMMERCIAL: {
                attribute = Attribute.PRECOMMERCIAL_NAME;
                break;
            }
            case BATCH: {
                attribute = Attribute.BATCH_NUMBER;
                break;
            }
            case MATERIAL: {
                attribute = Attribute.MATERIAL_NUMBER;
                break;
            }
            case COMMERCIAL: {
                attribute = Attribute.COMMERCIAL_NAME;
                break;
            }
            case MANUFACTURING_NAME: {
                attribute = Attribute.MANUFACTURING_NAME;
                break;
            }
            case CROP_NAME: {
                attribute = Attribute.CROP_NAME;
                break;
            }
        }
        return attribute;
    }

    private boolean valueHasWildCard(String value) {
        if (value != null) {
            return (value.trim().endsWith("*"));
        } else {
            return false;
        }
    }

    private String trimValue(String value) {
        String trimValue = value;
        if (null != value) {
            value.trim();
            if (valueHasWildCard(value)) {
                trimValue = value.substring(0, value.length() - 1);
            }
        }
        return trimValue;
    }
}
