package com.monsanto.tps.materialweb.dao;

import com.monsanto.tps.materialweb.entity.GermplasmEventConstructEntity;

import java.util.List;

public interface EventConstructDao {
    public List<GermplasmEventConstructEntity> getEventsForGermplasmIdWithTempSessionId(Long tempSessionId);
}
