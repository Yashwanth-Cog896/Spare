package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.monsanto.tps.materialweb.business.search.GermplasmInfoProcessor;
import com.monsanto.tps.materialweb.dao.GermplasmDao;
import com.monsanto.tps.materialweb.dao.TempSessionOcdDao;
import com.monsanto.tps.materialweb.entity.GermplasmEntity;
import com.monsanto.tps.materialweb.entity.GermplasmEventConstructEntity;
import com.monsanto.tps.materialweb.entity.LineFunctionEntity;
import com.monsanto.tps.materialweb.entity.util.TempTableSessionIdProvider;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class GermplasmInfoProcessorImpl implements GermplasmInfoProcessor {

    @Resource
    private TempTableSessionIdProvider tempTableSessionIdProvider;
    @Resource
    private TempSessionOcdDao tempSessionOcdDao;
    @Resource
    private GermplasmDao germplasmDao;

    public void addGermplasmInfoToResults(Collection<MaterialInformation> searchResults) {
        Set<Long> germplasmIds = getGermplasmIdSet(searchResults);
        if (germplasmIds.size() > 0) {
            Map<Long, GermplasmInfo> germplasmInfoMap = buildGermplasmInfoMapByGermplasmId(germplasmIds);
            for (MaterialInformation material : searchResults) {
                GermplasmInfo info = germplasmInfoMap.get(material.getId());
                if (info != null) {
                    material.setEvent(info.getEventName());
                    material.setPedigree(info.getPedigree());
                }
            }
        }
    }

    private Set<Long> getGermplasmIdSet(Collection<MaterialInformation> searchResults) {
        Set<Long> germplasmIds = Sets.newHashSet();
        for (MaterialInformation material : searchResults) {
            germplasmIds.add(material.getId());
        }
        return germplasmIds;
    }

    private Map<Long, GermplasmInfo> buildGermplasmInfoMapByGermplasmId(Set<Long> germplasmIds) {
        Integer germplasmIdsTempSessionId = tempTableSessionIdProvider.getNextSessionId();
        tempSessionOcdDao.insertNumberValues(germplasmIdsTempSessionId.longValue(), germplasmIds);
        Map<Long, GermplasmInfo> germplasmInfoMap = Maps.newHashMap();
        Collection<GermplasmEntity> germplasmEntities = germplasmDao.getGermplasmsByTempSessionId(germplasmIdsTempSessionId.longValue());

        for (GermplasmEntity entity : germplasmEntities) {
            Long germplasmId = entity.getGermplasmId();
            String pedigree = checkForPedigree(entity);
            String eventString = checkEvents(entity);
            germplasmInfoMap.put(germplasmId, new GermplasmInfo(eventString, pedigree));
        }
        return germplasmInfoMap;
    }

    private String checkEvents(GermplasmEntity entity) {
        StringBuffer eventString = new StringBuffer();
        Collection<GermplasmEventConstructEntity> germplasmEventConstructs = entity.getGermplasmEventConstruct();
        if (!CollectionUtils.isEmpty(germplasmEventConstructs)) {
            for (GermplasmEventConstructEntity eventConstruct : germplasmEventConstructs) {
                if (eventString.length() > 0) {
                    eventString.append(", ");
                }
                eventString.append(eventConstruct.getEvent().getEventName());
            }
        }
        return eventString.toString();
    }

    private String checkForPedigree(GermplasmEntity germplasm) {
        LineFunctionEntity lineFunction = germplasm.getLineFunction();
        String pedigree = germplasm.getPedigreeName();
        if (lineFunction != null) {
            if (lineFunction.getName().equalsIgnoreCase("A") || lineFunction.getName().equalsIgnoreCase("C")) {
                pedigree = germplasm.getCytoplasmDonor();
            }
        }
        return pedigree;
    }

    private class GermplasmInfo {
        private String eventName;
        private String pedigree;

        private GermplasmInfo(String eventName, String pedigree) {
            this.eventName = eventName;
            this.pedigree = pedigree;
        }

        public String getEventName() {
            return eventName;
        }

        public String getPedigree() {
            return pedigree;
        }
    }
}
