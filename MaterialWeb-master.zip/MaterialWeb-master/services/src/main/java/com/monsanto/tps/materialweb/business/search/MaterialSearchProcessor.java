package com.monsanto.tps.materialweb.business.search;

import com.monsanto.tps.materialweb.model.SearchMaterialResults;

import java.util.Collection;

public interface MaterialSearchProcessor {

    public SearchMaterialResults processMaterialSearch(Long cropId, String searchType1, Collection<String> searchValue1, String searchType2, Collection<String> searchValue2);
}
