package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 10/11/12
 * Time: 9:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasUserEntity_UT {
    private MidasUserEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new MidasUserEntity();
    }

    @Test
    public void testGetMidasUserId() throws Exception {
        testObject.setFirstName("A");
        testObject.setLastName("B");
        testObject.setLoginId("C");
        testObject.setMidasUserId(-9l);
        testObject.setMiddleName("D");
        testObject.setRefActive("E");

        assertThat(testObject.getFirstName(), equalTo("A"));
        assertThat(testObject.getLastName(), equalTo("B"));
        assertThat(testObject.getLoginId(), equalTo("C"));
        assertThat(testObject.getMidasUserId(), equalTo(-9l));
        assertThat(testObject.getMiddleName(), equalTo("D"));
        assertThat(testObject.getRefActive(), equalTo("E"));
    }
}
