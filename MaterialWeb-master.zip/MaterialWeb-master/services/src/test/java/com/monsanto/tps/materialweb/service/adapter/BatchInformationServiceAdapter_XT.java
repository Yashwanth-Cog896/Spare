package com.monsanto.tps.materialweb.service.adapter;

import com.google.common.collect.Lists;
import com.monsanto.tps.regulatory.traitquality.sap.Attribute;
import com.monsanto.tps.regulatory.traitquality.sap.AttributeFilter;
import com.monsanto.tps.regulatory.traitquality.sap.SearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static org.hamcrest.Matchers.greaterThan;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/business-context.xml",
        "classpath:/com/monsanto/tps/ws/service/ws-service-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/services-client-context.xml"
})
@Transactional
public class BatchInformationServiceAdapter_XT {
    @Resource
    private BatchInformationServiceAdapter batchInformationServiceAdapter;
    private static StopWatch stopWatch;

    @BeforeClass
    public static void startTest() throws Exception {
        stopWatch = new StopWatch();
    }

    @AfterClass
    public static void endTest() {
        System.out.println(stopWatch.prettyPrint());
    }


    @Test
    public void testCallService_findByCriteria() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.LINE_CODE, "01INL1EZRAB");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_NAME, "Corn");
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 1 - Corn, Line Code = 01INL1EZRAB");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 1 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria2() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.ORIGIN, "01INL1EZRAB");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        AttributeFilter attribute3 = new AttributeFilter(Attribute.MANUFACTURING_NAME, "HCL503BT1");  //Corn

        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2, attribute3);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 2 - Corn, Origin = 01INL1EZRAB, Manufacturing Name = HCL503BT1");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 2 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria3() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.BATCH_NUMBER, "VERSION001");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        AttributeFilter attribute3 = new AttributeFilter(Attribute.MANUFACTURING_ACRONYM, "HCL503BT1");
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2, attribute3);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 3 - Corn, Batch Number = VERSION001, Acronymn = HCL503BT1");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 3 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria4() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.PRECOMMERCIAL_NAME, "01INL1EZRAB");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        AttributeFilter attribute3 = new AttributeFilter(Attribute.MATERIAL_NUMBER, "000000000010045612");
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2, attribute3);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 4 - Corn, PreCommercial Name = 01INL1EZRAB, Material Number = 000000000010045612");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 4 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria5() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.PRECOMMERCIAL_NAME, "DEBE886-JLH-T1A1");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 5 - Corn precommercial name = DEBE886-JLH-T1A1");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 5 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria6() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.COMMERCIAL_NAME, "TREBBIABT");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 6 - Corn, commercial name = TREBBIABT");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 6 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria7_largerReturn() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
        AttributeFilter attribute1 = new AttributeFilter(Attribute.COMMERCIAL_NAME, "DK818");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 7 - large result set - Corn, Commercial name = DK818");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 7 - result set = " + results.size());
    }

    @Test
    public void testCallService_findByCriteria8() throws Exception {
        SearchCriteria searchCriteria = new SearchCriteria();
        //Corn, batch 1762STOCK
//        AttributeFilter attribute1 = new AttributeFilter(Attribute.BATCH_NUMBER, "781h*");
        AttributeFilter attribute1 = new AttributeFilter(Attribute.BATCH_NUMBER, "DK*");
        AttributeFilter attribute2 = new AttributeFilter(Attribute.CROP_ID, "65601536");  //Corn
        List<AttributeFilter> simpleAttributes = Lists.newArrayList(attribute1, attribute2);
        searchCriteria.setSimpleAttributeFilters(simpleAttributes);

        stopWatch.start("criteria 8 - Corn, ");
        Collection<PipelineBatchInformationDTO> results = batchInformationServiceAdapter.findByCriteria(searchCriteria);
        stopWatch.stop();

        assertNotNull(results);
        assertThat(results.size(), greaterThan(0));
        System.out.println("Criteria 8 - result set = " + results.size());
    }
}
