package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.search.GermplasmInfoProcessor;
import com.monsanto.tps.materialweb.dao.GermplasmDao;
import com.monsanto.tps.materialweb.dao.TempSessionOcdDao;
import com.monsanto.tps.materialweb.entity.EventConstructEntity;
import com.monsanto.tps.materialweb.entity.GermplasmEntity;
import com.monsanto.tps.materialweb.entity.GermplasmEventConstructEntity;
import com.monsanto.tps.materialweb.entity.LineFunctionEntity;
import com.monsanto.tps.materialweb.entity.util.TempTableSessionIdProvider;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class GermplasmInfoProcessorImpl_UT {

    @InjectMocks
    private GermplasmInfoProcessor testObject = new GermplasmInfoProcessorImpl();
    @Mock
    private TempTableSessionIdProvider tempTableSessionIdProvider;
    @Mock
    private TempSessionOcdDao tempSessionOcdDao;
    @Mock
    private GermplasmDao germplasmDao;
    private Integer tempSessionId = -555;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        when(tempTableSessionIdProvider.getNextSessionId()).thenReturn(tempSessionId);
    }

    @Test
    public void testAddEventsToResults() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setId(-1l);
        Collection<MaterialInformation> dummyResults = Lists.newArrayList(item1);
        GermplasmEventConstructEntity constructEntity = new GermplasmEventConstructEntity();
        EventConstructEntity event1 = new EventConstructEntity();
        event1.setEventName("evnt1");
        constructEntity.setEvent(event1);
        GermplasmEntity germplasm1 = new GermplasmEntity();
        germplasm1.setGermplasmId(-1l);
        germplasm1.setPedigreeName("A");
        germplasm1.setCytoplasmDonor("B");
        constructEntity.setGermplasm(germplasm1);
        List<GermplasmEventConstructEntity> eventResults = Lists.newArrayList(constructEntity);
        germplasm1.setGermplasmEventConstruct(eventResults);
        Collection<GermplasmEntity> germplasmResults = Lists.newArrayList(germplasm1);
        when(germplasmDao.getGermplasmsByTempSessionId(tempSessionId.longValue())).thenReturn(germplasmResults);

        testObject.addGermplasmInfoToResults(dummyResults);

        assertThat(dummyResults.iterator().next().getEvent(), is("evnt1"));
        assertThat(dummyResults.iterator().next().getPedigree(), is("A"));
        verify(tempTableSessionIdProvider).getNextSessionId();
        ArgumentCaptor<Set> germplasmIdSet = ArgumentCaptor.forClass(Set.class);
        verify(tempSessionOcdDao).insertNumberValues(eq(tempSessionId.longValue()), (Set<Long>) germplasmIdSet.capture());
    }

    @Test
    public void testPedigreeForSterileLine() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setId(-1l);
        Collection<MaterialInformation> dummyResults = Lists.newArrayList(item1);
        GermplasmEventConstructEntity constructEntity = new GermplasmEventConstructEntity();
        EventConstructEntity event1 = new EventConstructEntity();
        event1.setEventName("evnt1");
        constructEntity.setEvent(event1);
        GermplasmEntity germplasm1 = new GermplasmEntity();
        germplasm1.setGermplasmId(-1l);
        germplasm1.setPedigreeName("A");
        germplasm1.setCytoplasmDonor("B");
        LineFunctionEntity lf = new LineFunctionEntity();
        lf.setName("A");
        germplasm1.setLineFunction(lf);
        constructEntity.setGermplasm(germplasm1);
        List<GermplasmEventConstructEntity> eventResults = Lists.newArrayList(constructEntity);
        germplasm1.setGermplasmEventConstruct(eventResults);
        Collection<GermplasmEntity> germplasmResults = Lists.newArrayList(germplasm1);
        when(germplasmDao.getGermplasmsByTempSessionId(tempSessionId.longValue())).thenReturn(germplasmResults);

        testObject.addGermplasmInfoToResults(dummyResults);

        assertThat(dummyResults.iterator().next().getEvent(), is("evnt1"));
        assertThat(dummyResults.iterator().next().getPedigree(), is("B"));
        verify(tempTableSessionIdProvider).getNextSessionId();
        ArgumentCaptor<Set> germplasmIdSet = ArgumentCaptor.forClass(Set.class);
        verify(tempSessionOcdDao).insertNumberValues(eq(tempSessionId.longValue()), (Set<Long>) germplasmIdSet.capture());
    }

    @Test
    public void testAddEventsToResults_multipleEvents() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setId(-1l);
        Collection<MaterialInformation> dummyResults = Lists.newArrayList(item1);
        GermplasmEventConstructEntity constructEntity = new GermplasmEventConstructEntity();
        EventConstructEntity event1 = new EventConstructEntity();
        event1.setEventName("evnt1");
        constructEntity.setEvent(event1);
        GermplasmEntity germplasm1 = new GermplasmEntity();
        germplasm1.setGermplasmId(-1l);
        constructEntity.setGermplasm(germplasm1);
        GermplasmEventConstructEntity constructEntity2 = new GermplasmEventConstructEntity();
        EventConstructEntity event2 = new EventConstructEntity();
        event2.setEventName("e2");
        constructEntity2.setEvent(event2);
        constructEntity2.setGermplasm(germplasm1);
        List<GermplasmEventConstructEntity> eventResults = Lists.newArrayList(constructEntity, constructEntity2);
        germplasm1.setGermplasmEventConstruct(eventResults);
        Collection<GermplasmEntity> germplasmResults = Lists.newArrayList(germplasm1);
        when(germplasmDao.getGermplasmsByTempSessionId(tempSessionId.longValue())).thenReturn(germplasmResults);

        testObject.addGermplasmInfoToResults(dummyResults);

        assertThat(dummyResults.iterator().next().getEvent(), is("evnt1, e2"));
        verify(tempTableSessionIdProvider).getNextSessionId();
        ArgumentCaptor<Set> germplasmIdSet = ArgumentCaptor.forClass(Set.class);
        verify(tempSessionOcdDao).insertNumberValues(eq(tempSessionId.longValue()), (Set<Long>) germplasmIdSet.capture());
    }
}
