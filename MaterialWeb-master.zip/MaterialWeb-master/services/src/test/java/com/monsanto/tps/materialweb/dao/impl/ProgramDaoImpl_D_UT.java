package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.pipeline.breeding.test.TestTools;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.ProgramDao;
import com.monsanto.tps.materialweb.entity.ProgramEntity;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.Collection;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@Transactional
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
public class ProgramDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "programDao")
    private ProgramDao programDao;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    public PersistentStoreConnection connection;
    private Long cropId;

    @Before
    public void setUp() throws Exception {
        connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
        cropId = TestTools.getCornCropId();
    }

    @Test
    public void testGetValidCornPrograms() throws Exception {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("Calling get active programs: ");
        Collection<ProgramEntity> results = programDao.getActiveGermplasmManagersProgramsForCrop(cropId);

        stopWatch.stop();
        System.out.println(stopWatch.prettyPrint());
        assertThat(CollectionUtils.isEmpty(results), is(false));
    }

}
