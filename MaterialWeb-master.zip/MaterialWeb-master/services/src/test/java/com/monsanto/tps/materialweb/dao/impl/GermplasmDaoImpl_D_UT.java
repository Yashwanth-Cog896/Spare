package com.monsanto.tps.materialweb.dao.impl;

import com.google.common.collect.Sets;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.TempSessionOcdDao;
import com.monsanto.tps.materialweb.entity.GermplasmEntity;
import com.monsanto.tps.materialweb.entity.util.TempTableSessionIdProvider;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.Collection;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
@Transactional
public class GermplasmDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "germplasmDao")
    private GermplasmDaoImpl germplasmDao;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    @Resource
    private TempSessionOcdDao tempSessionOcdDao;
    @Resource
    private TempTableSessionIdProvider tempTableSessionIdProvider;

    public PersistentStoreConnection connection;
    public static final long germplasmId = -26l;

    @Before
    public void setUp() throws Exception {
          connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
//        connection.beginTransaction();
//        Long cropId = TestTools.getCornCropId();
//        TestTools.insertFakeGermplasm(connection, germplasmId, "X+Z", "X+Z", "", "SEGPOP", null, "17", cropId );
    }

    @Test
    public void testGetGermplasm() throws Exception {
        Long existingGermplasmId = findExistingGermplasmId();

        GermplasmEntity result = germplasmDao.getGermplasm(existingGermplasmId);

        assertNotNull(result);
        assertThat(result.getGermplasmId(), is(existingGermplasmId));
    }

    @Ignore("can't get the insert tests working")
    @Test
    public void testGetGermplasms() throws WrappingException, EmptyResultSetException {
        Long existingGermplasmId = findExistingGermplasmId();
        Integer germplasmIdsTempSessionId = tempTableSessionIdProvider.getNextSessionId();
        tempSessionOcdDao.insertNumberValues(germplasmIdsTempSessionId.longValue(), Sets.newHashSet(existingGermplasmId));

        Collection<GermplasmEntity> germplasms = germplasmDao.getGermplasmsByTempSessionId(germplasmIdsTempSessionId.longValue());

        assertNotNull(germplasms);
        assertThat(germplasms.size(), is(1));
        assertThat(germplasms.iterator().next().getGermplasmId(), is(existingGermplasmId));
    }

    private Long findExistingGermplasmId() throws WrappingException, EmptyResultSetException {
        StringBuffer sql = new StringBuffer("select g.germplasm_id from MIDAS.GERMPLASM g ");
        sql.append("inner join MIDAS.BR_PROG prog on G.OWNER_BR_PROG_ID = PROG.BR_PROG_ID ");
        sql.append("inner join MIDAS.LINE_TYPE lt on G.LINE_TYPE_ID = LT.LINE_TYPE_ID ");
        sql.append("where PROG.BR_PROG_REF_ID = '17' and LT.NAME = 'Hybrid' and g.IS_DELETED = 'F' and rownum = 1 ");

        PersistentStoreResultSet resultSet = connection.executeQuery(sql.toString());
        PersistentStoreResultSetSingleResult singleResult = resultSet.getSingleResult();
        Long germplasmId = singleResult.getLong("germplasm_id");
        return germplasmId;
    }
}
