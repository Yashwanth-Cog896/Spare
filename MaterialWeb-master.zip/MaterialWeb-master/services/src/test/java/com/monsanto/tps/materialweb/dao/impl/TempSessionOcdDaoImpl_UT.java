package com.monsanto.tps.materialweb.dao.impl;

import org.hibernate.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.HashSet;
import java.util.Set;

import static org.mockito.Mockito.*;

public class TempSessionOcdDaoImpl_UT {
    @Mock
    private Session session;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testInsertNumberValues() throws Exception {
        session = mock(Session.class);
        int idCount = 10;
        Set<Long> ids = createIdSet(idCount);
        FacadeTempSessionOcdDaoImpl tempSessionOcdDao = new FacadeTempSessionOcdDaoImpl();

        tempSessionOcdDao.insertNumberValues(1L, ids);

        verify(session, times(1)).flush();
    }

    @Test
    public void testInsertLargeNumberOfValues() {
        session = mock(Session.class);
        Set<Long> ids = createIdSet(1200);
        FacadeTempSessionOcdDaoImpl tempSessionOcdDao = new FacadeTempSessionOcdDaoImpl();

        tempSessionOcdDao.insertNumberValues(1L, ids);

        verify(session, times(2)).flush();
    }

    private Set<Long> createIdSet(int idCount) {
        Set<Long> ids = new HashSet<Long>();
        for (int i = 1; i <= idCount; i++) {
            ids.add((long) i);
        }
        return ids;
    }

    private class FacadeTempSessionOcdDaoImpl extends TempSessionOcdDaoImpl {
        @Override
        protected Session getSession() {
            return session;
        }
    }
}
