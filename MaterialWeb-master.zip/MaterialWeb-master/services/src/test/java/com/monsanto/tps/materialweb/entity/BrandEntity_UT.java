package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class BrandEntity_UT {
    private BrandEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new BrandEntity();
    }

    @Test
    public void testGetterAndSetters() throws Exception {
        testObject.setBrandId(-4l);
        testObject.setBrandName("b");
        CompanyEntity company = new CompanyEntity();
        company.setCompanyId(-7l);
        testObject.setCompany(company);
        testObject.setRefActive("F");

        assertThat(testObject.getBrandId(), equalTo(-4l));
        assertThat(testObject.getBrandName(), equalTo("b"));
        assertThat(testObject.getRefActive(), equalTo("F"));
        assertThat(testObject.getCompany(), equalTo(company));
    }
}
