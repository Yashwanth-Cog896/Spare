package com.monsanto.tps.materialweb.test.utility;

import com.google.common.collect.Lists;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.pipeline.breeding.test.TestTools;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.materialweb.business.model.SearchType;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.List;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@Transactional
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
public class SearchMaterialDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    @Resource(name = "searchMaterialDao")
    private SearchMaterialDaoImpl searchMaterialDao;
    private long cropId;
    private String lineCode = "01CWI6";
    public PersistentStoreConnection connection;

    @Before
    public void setUp() throws Exception {
        connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
        cropId = TestTools.getCornCropId();
        //Note inserting this record does not appear to be enough by itself... but this linecode is currently working
        TestTools.insertFakeGermplasm(connection, -234l, "D", "E", lineCode, "HYBRID", "A", "8E", cropId);
        searchMaterialDao.setWriteSql(true);
    }

    //    @Ignore
    @Test
    public void testSearchMaterial() throws Exception {
        MaterialSearchCriteria criteria = new MaterialSearchCriteria();
        CropEntity crop = new CropEntity();
        crop.setCropId(cropId);
        criteria.setCropEntity(crop);
        criteria.addSearchValue(SearchType.fromString("Line Code"), Lists.newArrayList(lineCode));

        List<MaterialInformation> results = searchMaterialDao.searchMaterial(criteria);

        assertNotNull(results);
        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    @Test
    public void testSearchMaterial_allEqualsCriteria() throws Exception {
        MaterialSearchCriteria criteria = new MaterialSearchCriteria();
        CropEntity crop = new CropEntity();
        crop.setCropId(cropId);
        criteria.setCropEntity(crop);
        criteria.addSearchValue(SearchType.BATCH, Lists.newArrayList("a"));
        criteria.addSearchValue(SearchType.LINECODE, Lists.newArrayList("b"));
        criteria.addSearchValue(SearchType.ACRONYM, Lists.newArrayList("c"));
        criteria.addSearchValue(SearchType.ORIGIN, Lists.newArrayList("d"));
        criteria.addSearchValue(SearchType.PRECOMMERCIAL, Lists.newArrayList("e"));
        criteria.addSearchValue(SearchType.MATERIAL, Lists.newArrayList("f"));
        criteria.addSearchValue(SearchType.MANUFACTURING_NAME, Lists.newArrayList("G"));

        List<MaterialInformation> results = searchMaterialDao.searchMaterial(criteria);

        assertNotNull(results);
        assertThat(results.size(), equalTo(0));
    }

    @Test
    public void testSearchMaterial_allWildCardCriteria() throws Exception {
        MaterialSearchCriteria criteria = new MaterialSearchCriteria();
        CropEntity crop = new CropEntity();
        crop.setCropId(cropId);
        criteria.setCropEntity(crop);
        criteria.addSearchValue(SearchType.BATCH, Lists.newArrayList("a*"));
        criteria.addSearchValue(SearchType.LINECODE, Lists.newArrayList("b*"));
        criteria.addSearchValue(SearchType.ACRONYM, Lists.newArrayList("c*"));
        criteria.addSearchValue(SearchType.ORIGIN, Lists.newArrayList("d*"));
        criteria.addSearchValue(SearchType.PRECOMMERCIAL, Lists.newArrayList("e*"));
        criteria.addSearchValue(SearchType.MATERIAL, Lists.newArrayList("f*"));
        criteria.addSearchValue(SearchType.MANUFACTURING_NAME, Lists.newArrayList("G*"));

        List<MaterialInformation> results = searchMaterialDao.searchMaterial(criteria);

        assertNotNull(results);
        assertThat(results.size(), equalTo(0));
    }

    //    @Ignore
    @Test
    public void testSearch() {
        MaterialSearchCriteria criteria = new MaterialSearchCriteria();
        CropEntity crop = new CropEntity();
        crop.setCropId(65601536l);
        criteria.setCropEntity(crop);
        criteria.addSearchValue(SearchType.BATCH, Lists.newArrayList("null"));
        criteria.addSearchValue(SearchType.LINECODE, Lists.newArrayList("01CWI6"));

        List<MaterialInformation> results = searchMaterialDao.searchMaterial(criteria);

        assertNotNull(results);
        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    //    @Ignore
    @Test
    public void testSearch_byProductId() {
        MaterialSearchCriteria criteria = new MaterialSearchCriteria();
        CropEntity crop = new CropEntity();
        crop.setCropId(65601536l);
        criteria.setCropEntity(crop);
        criteria.addSearchValue(SearchType.PRODUCT_ID, Lists.newArrayList("123"));

        List<MaterialInformation> results = searchMaterialDao.searchMaterial(criteria);

        assertNotNull(results);
        assertThat(results.size(), greaterThanOrEqualTo(0));
    }
}
