package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 10/17/12
 * Time: 9:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyEntity_UT {
    private CompanyEntity testObject;

    @Before
    public void setup() {
        testObject = new CompanyEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setCompanyId(-3l);
        testObject.setCompanyName("A");
        testObject.setRefActive("T");

        assertThat(testObject.getCompanyId(), equalTo(-3l));
        assertThat(testObject.getCompanyName(), equalTo("A"));
        assertThat(testObject.getRefActive(), equalTo("T"));
    }
}
