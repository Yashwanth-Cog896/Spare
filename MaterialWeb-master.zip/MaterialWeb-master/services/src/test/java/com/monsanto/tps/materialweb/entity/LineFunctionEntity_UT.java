package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class LineFunctionEntity_UT {
    private LineFunctionEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new LineFunctionEntity();
    }

    @Test
    public void testSettersAndGetters() throws Exception {
        testObject.setLineFunctionId(-3l);
        testObject.setLineFunctionRefId("A");
        testObject.setName("B");
        testObject.setRefActive("F");

        assertThat(testObject.getLineFunctionId(), is(-3l));
        assertThat(testObject.getLineFunctionRefId(), is("A"));
        assertThat(testObject.getName(), is("B"));
        assertThat(testObject.getRefActive(), is("F"));
    }
}
