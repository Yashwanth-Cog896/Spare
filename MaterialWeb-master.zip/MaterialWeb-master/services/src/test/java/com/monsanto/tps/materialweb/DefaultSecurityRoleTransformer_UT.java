package com.monsanto.tps.materialweb;

import com.google.common.collect.Sets;
import com.monsanto.tps.security.authorization.SecurityRoleTransformer;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static junit.framework.Assert.assertEquals;

public class DefaultSecurityRoleTransformer_UT {

    @Test
    public void testTransformSecurityRoles() {
        SecurityRoleTransformer securityRoleTransformer = new DefaultSecurityRoleTransformer();
        HashSet<String> input = Sets.newHashSet("S1", "S2");
        Set<String> output = securityRoleTransformer.transformSecurityRoles(input);
        assertEquals(input, output);
    }
}
