package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;


public class CropEntity_UT {

    private CropEntity testObject;

    @Before
    public void setup() {
        testObject = new CropEntity();
    }

    @Test
    public void testGetCropId() throws Exception {
        testObject.setCropId(-1l);
        testObject.setCropName("Corn");
        testObject.setCropRefId("ABC");
        testObject.setGenusSpecies("Gen");
        testObject.setRefActive("CDE");
        testObject.setRemCropId("GHI");
        testObject.setRmIncrement(3);
        testObject.setRmMax(4);
        testObject.setRmMin(5);

        assertThat(testObject.getCropId(), equalTo(new Long(-1L)));
        assertThat(testObject.getCropName(), equalTo("Corn"));
        assertThat(testObject.getCropRefId(), equalTo("ABC"));
        assertThat(testObject.getGenusSpecies(), equalTo("Gen"));
        assertThat(testObject.getRefActive(), equalTo("CDE"));
        assertThat(testObject.getRemCropId(), equalTo("GHI"));
        assertThat(testObject.getRmIncrement(), equalTo(3));
        assertThat(testObject.getRmMax(), equalTo(4));
        assertThat(testObject.getRmMin(), equalTo(5));
    }
}
