package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.pipeline.breeding.test.TestTools;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.MidasRefDataDao;
import com.monsanto.tps.materialweb.entity.CropEntity;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@Transactional
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
public class MidasRefDataDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "midasRefDataDao")
    private MidasRefDataDao midasRefDataDao;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    public PersistentStoreConnection connection;

    @Before
    public void setUp() throws Exception {
        connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
        TestTools.insertFakeMidasUser(connection, -435, "REHTEST", "T", "RH", "", "TEST");
    }

    @Test
    public void testGetInventoryImportUserCrops() throws Exception {
        CropEntity[] results = midasRefDataDao.getInventoryImportUserCrops("REHTEST");

        assertNotNull(results);
    }

    @Test
    public void testSession() {
        Long cropId = TestTools.getCornCropId();

        CropEntity cropEntity = midasRefDataDao.getCropByCropId(cropId);

        assertNotNull(cropEntity);
    }

}
