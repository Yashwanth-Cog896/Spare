package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.UnitOfMeasureDao;
import com.monsanto.tps.materialweb.entity.UnitOfMeasureEntity;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.Collection;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@Transactional
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
public class UnitOfMeasureDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "unitOfMeasureDao")
    private UnitOfMeasureDao unitOfMeasureDao;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    public PersistentStoreConnection connection;

    @Before
    public void setUp() throws Exception {
       connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
    }

    @Test
    public void testGetVegetativeStructures() throws Exception {
        Collection<UnitOfMeasureEntity> results = unitOfMeasureDao.getInventoryUnitOfMeasures();

        assertNotNull(results);
        //This is reference data so it should be there.
        boolean hasSeedValue = false;
        for (UnitOfMeasureEntity item : results) {
            if (item.getName().equalsIgnoreCase("SEED")) {
                hasSeedValue = true;
            }
        }
        assertThat(hasSeedValue, is(true));
    }
}
