package com.monsanto.tps.materialweb.entity;

import org.junit.Test;

import static junit.framework.Assert.*;

public class TempSessionOcdId_UT {

    @Test
    public void tempSessionOcdIdEmptyConstructorTest() {
        TempSessionOcdId testObject = new TempSessionOcdId();
        assertNull(testObject.getRequestId());
        assertNull(testObject.getNumber1());
        assertNull(testObject.getNumber2());
        assertNull(testObject.getText1());
        assertNull(testObject.getText2());
        assertNull(testObject.getSortOrder());
    }

    @Test
    public void tempSessionOcdTestSetters() {
        TempSessionOcdId testObject = new TempSessionOcdId();
        testObject.setNumber1(-1L);
        testObject.setNumber2(-2L);
        testObject.setRequestId(-3L);
        testObject.setSortOrder(-4L);
        testObject.setText1("test1");
        testObject.setText2("test2");

        assertEquals(new Long(-1), testObject.getNumber1());
        assertEquals(new Long(-2), testObject.getNumber2());
        assertEquals(new Long(-3), testObject.getRequestId());
        assertEquals(new Long(-4), testObject.getSortOrder());
        assertEquals("test1", testObject.getText1());
        assertEquals("test2", testObject.getText2());
    }

    @Test
    public void tempSessionFullConstrutorTest() {
        TempSessionOcdId testObject = new TempSessionOcdId(-11L, -12L, -13L, "testText1", "testText2", -14L);

        assertEquals(new Long(-12), testObject.getNumber1());
        assertEquals(new Long(-13), testObject.getNumber2());
        assertEquals(new Long(-11), testObject.getRequestId());
        assertEquals(new Long(-14), testObject.getSortOrder());
        assertEquals("testText1", testObject.getText1());
        assertEquals("testText2", testObject.getText2());
    }

    @Test
    public void tempSessionPartialConstrutorTest() {
        TempSessionOcdId testObject = new TempSessionOcdId(-21L, -22L);

        assertEquals(new Long(-21), testObject.getRequestId());
        assertEquals(new Long(-22), testObject.getSortOrder());
        assertNull(testObject.getNumber1());
        assertNull(testObject.getNumber2());
        assertNull(testObject.getText1());
        assertNull(testObject.getText2());
    }

    @Test
    public void tempSessionEqualsTest() {
        TempSessionOcdId testObject1 = new TempSessionOcdId(-11L, -12L, -13L, "testText1", "testText2", -14L);
        TempSessionOcdId testObject2 = new TempSessionOcdId(-11L, -12L, -13L, "testText1", "testText2", -14L);

        assertTrue(testObject1.equals(testObject2));
        assertFalse(testObject1.equals(null));
        assertFalse(testObject1.equals(new Object()));
        testObject2 = new TempSessionOcdId(-111111L, -12L, -13L, "testText1", "testText2", -14L);
        assertFalse(testObject1.equals(testObject2));
        testObject2 = new TempSessionOcdId(-11L, -121111L, -13L, "testText1", "testText2", -14L);
        assertFalse(testObject1.equals(testObject2));
        testObject2 = new TempSessionOcdId(-11L, -12L, -131111L, "testText1", "testText2", -14L);
        assertFalse(testObject1.equals(testObject2));
        testObject2 = new TempSessionOcdId(-11L, -12L, -13L, "testText11X", "testText2", -14L);
        assertFalse(testObject1.equals(testObject2));
        testObject2 = new TempSessionOcdId(-11L, -12L, -13L, "testText1", "testText21X", -14L);
        assertFalse(testObject1.equals(testObject2));
        testObject2 = new TempSessionOcdId(-11L, -12L, -13L, "testText1", "testText2", -14111L);
        assertFalse(testObject1.equals(testObject2));
    }

    @Test
    public void tempSessionHashCodeTest() {
        TempSessionOcdId testObject1 = new TempSessionOcdId(-11L, -12L, -13L, "testText1", "testText2", -14L);

        assertNotNull(testObject1.hashCode());
    }
}
