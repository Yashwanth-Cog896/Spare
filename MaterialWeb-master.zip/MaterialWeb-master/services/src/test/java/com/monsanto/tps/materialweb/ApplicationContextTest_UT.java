package com.monsanto.tps.materialweb;

import com.monsanto.tps.materialweb.service.MaterialPlacementService;
import com.monsanto.tps.security.authorization.ActiveDirectoryAuthorityProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import static junit.framework.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/application-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"

})
public class ApplicationContextTest_UT {
    @Resource(name = "activeDirectoryAuthorityProvider")
    private ActiveDirectoryAuthorityProvider activeDirectoryAuthorityProvider;
    @Resource(name = "materialPlacementService")
    private MaterialPlacementService materialPlacementService;

    @Test
    public void testAppContextInstantiation() {
        assertNotNull(activeDirectoryAuthorityProvider);
        assertNotNull(materialPlacementService);
    }
}