package com.monsanto.tps.materialweb.business.exception;


import org.junit.Test;

import static junit.framework.Assert.assertNotNull;

public class ServiceFailureException_UT {

    @Test
    public void constructor() {
        ServiceFailureException testObject = new ServiceFailureException("fail");

        assertNotNull(testObject);
    }

    @Test
    public void constructor_withException() {
        ServiceFailureException testObject = new ServiceFailureException("fail", new IllegalAccessException("problem"));

        assertNotNull(testObject);
    }
}
