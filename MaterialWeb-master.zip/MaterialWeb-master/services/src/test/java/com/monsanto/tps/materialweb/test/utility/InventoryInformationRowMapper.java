package com.monsanto.tps.materialweb.test.utility;

import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class InventoryInformationRowMapper implements RowMapper<MaterialInformation> {

    public static final String ORIGIN_COL = "Origin";
    public final String LINECODE_COL = "Line_Code";
    public final String LINETYPE_COL = "Line_Type";
    public final String LINEFUNCTION_COL = "Line_Function";
    public final String DONOR_COL = "Cytoplasm_Donor";
    public final String OWNER_COL = "Owner_Program";
    public final String SOURCE_COL = "Cytoplasm_Source";
    public final String BATCH_COL = "Batch_Number";
    public final String MATERIAL_NUM_COL = "Material_Number";
    public final String MATERIAL_ACRONYM_COL = "Material_Acronym";
    public final String MATERIAL_DESC_COL = "Material_Desc";
    public final String TRAIT_VERSION_COL = "Trait_Version";
    public final String CROP_NAME_COL = "Crop_Name";
    public final String CROP_ID_COL = "cropId";
    public final String PRODUCT_ID_COL = "productId";
    public final String GERMPLASM_ID_COL = "germplasmId";
    public final String VARIETY_NAME_COL = "Variety_Name";
    public final String RESTRICTION_COL = "restriction";
    public final String SAP_BRAND_NAME_COL = "SAP_Brand_Name";
    public final String SAP_MATERIAL_DESC = "SAP_Material_Desc";
    public final String PREFERRED_GERMPLASM_COL = "Preferred_Germplasm";
    public final String PREFERRED_NAME_COL = "Preferred_Name";
    public final String SAP_TRAIT_VERSION_COL = "SAP_Trait_Version";
    public final String SAP_CREATED_DATE_COL = "SAP_Created_Date";
    public final String LEX_PRE_COMMERICAL_NAME_COL = "LEX_PRE_COMMERCIAL_NAME";
    public final String MIDAS_COMMERICAL_NAME_COL = "MIDAS_Commercial_Name";
    public final String MIDAS_COMMERICAL_BRAND_NAME_COL = "MIDAS_Commercial_Brand_Name";
    public final String MANUFACTURING_NAME = "Manufacturing_Name";

    @Override
    public MaterialInformation mapRow(ResultSet rs, int rowNum) throws SQLException {
        MaterialInformation value = new MaterialInformation();
        value.setOrigin(rs.getString(ORIGIN_COL));
        value.setLineCode(rs.getString(LINECODE_COL));
        value.setLineType(rs.getString(LINETYPE_COL));
        value.setLineFunction(rs.getString(LINEFUNCTION_COL));
        value.setGermplasmOwner(rs.getString(OWNER_COL));
        value.setBatchNumber(rs.getString(BATCH_COL));
        value.setMaterialNumber(rs.getString(MATERIAL_NUM_COL));
        value.setAcronym(rs.getString(MATERIAL_ACRONYM_COL));
        value.setTraitVersion(rs.getString(TRAIT_VERSION_COL));
        value.setCropName(rs.getString(CROP_NAME_COL));
        value.setCropId(rs.getLong(CROP_ID_COL));
//        value.setProductId(rs.getLong(PRODUCT_ID_COL));
        value.setId(rs.getLong(GERMPLASM_ID_COL));
        value.setVarietyName(rs.getString(VARIETY_NAME_COL));
        value.setRestriction(rs.getString(RESTRICTION_COL));
        value.setPedigree(rs.getString(DONOR_COL));
        value.setSapBrandName(rs.getString(SAP_BRAND_NAME_COL));
        value.setSapMaterialDescription(rs.getString(SAP_MATERIAL_DESC));
        value.setPreferredGermplasm(rs.getString(PREFERRED_GERMPLASM_COL));
        value.setPreferredName(rs.getString(PREFERRED_NAME_COL));
        value.setSapTraitVersion(rs.getString(SAP_TRAIT_VERSION_COL));
        value.setSapCreatedDate(rs.getDate(SAP_CREATED_DATE_COL));
        value.setLexiconPreCommercialName(rs.getString(LEX_PRE_COMMERICAL_NAME_COL));
        value.setMidasCommercialName(rs.getString(MIDAS_COMMERICAL_NAME_COL));
        value.setMidasCommercialBrandName(rs.getString(MIDAS_COMMERICAL_BRAND_NAME_COL));
        value.setManufacturingName(rs.getString(MANUFACTURING_NAME));
        return value;
    }
}