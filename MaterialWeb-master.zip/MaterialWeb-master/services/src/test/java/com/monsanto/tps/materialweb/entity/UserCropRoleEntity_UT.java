package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 10/11/12
 * Time: 9:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserCropRoleEntity_UT {
    private UserCropRoleEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new UserCropRoleEntity();
    }

    @Test
    public void testGetId() throws Exception {
        CropEntity crop = new CropEntity();
        crop.setCropId(-6l);
        testObject.setCrop(crop);
        testObject.setId(-7l);
        MidasRoleEntity role = new MidasRoleEntity();
        role.setRoleId(-8l);
        testObject.setMidasRole(role);
        MidasUserEntity user = new MidasUserEntity();
        user.setMidasUserId(-4l);
        testObject.setMidasUser(user);
        testObject.setRefActive("A");

        assertThat(testObject.getCrop(), equalTo(crop));
        assertThat(testObject.getId(), equalTo(-7l));
        assertThat(testObject.getMidasRole(), equalTo(role));
        assertThat(testObject.getMidasUser(), equalTo(user));
        assertThat(testObject.getRefActive(), equalTo("A"));
    }
}
