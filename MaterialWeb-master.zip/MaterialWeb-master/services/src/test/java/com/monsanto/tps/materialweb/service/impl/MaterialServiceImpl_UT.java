package com.monsanto.tps.materialweb.service.impl;

import com.google.common.base.CharMatcher;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.monsanto.tps.architecture.security.common.user.IDMUserAttributes;
import com.monsanto.tps.materialweb.business.inventory.CreationProcessor;
import com.monsanto.tps.materialweb.business.search.MaterialSearchProcessor;
import com.monsanto.tps.materialweb.model.CreationRequest;
import com.monsanto.tps.materialweb.model.SearchCriteriaModel;
import com.monsanto.tps.materialweb.service.MaterialService;
import com.monsanto.tps.security.userdetails.EnhancedUser;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MaterialServiceImpl_UT {
    @InjectMocks
    private MaterialService testObject = new MaterialServiceImpl();
    @Mock
    private MaterialSearchProcessor materialSearchProcessor;
    @Mock
    private CreationProcessor creationProcessor;
    @Mock
    protected UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSearchMaterialPost() throws Exception {

        SearchCriteriaModel model = new SearchCriteriaModel("22", "x", "y", "z", "w");
        testObject.searchMaterial(model);

        verify(materialSearchProcessor).processMaterialSearch(22l, "x", Lists.newArrayList("y"), "z", Lists.newArrayList("w"));
    }

    @Test
    public void testCreateSourcesPost() throws Exception {
        Collection<CreationRequest> request = Lists.newArrayList();
        String userId = "rehigg";
        IDMUserAttributes attributes = new IDMUserAttributes(userId);
        Collection<? extends GrantedAuthority> authority = Lists.newArrayList();
        EnhancedUserDetails userDetails = new EnhancedUser(userId, "password", true, true, true, true, authority, attributes);
        when(userDetailsProvider.getUserDetails()).thenReturn(userDetails);

        testObject.createMaterial(request);

        verify(creationProcessor).createNewSources(request, userId);
    }

    @Test
    public void testSplitter() {
        String s = "a,b,,c d\ne\tf";

        Collection<String> result = Lists.newArrayList(Splitter.on(CharMatcher.anyOf(", \n\t")).trimResults().omitEmptyStrings().split(s));

        assertThat(result.size(), is(6));
    }

    @Test
    public void testSplitterMethod() {
        String s = "a b  c d\ne\tf";

        Collection<String> result = ((MaterialServiceImpl) testObject).parseStringToCollection(s);

        assertThat(result.size(), is(6));
    }

    @Test
    public void testSplitterMethod_emptyString() {

        Collection<String> result = ((MaterialServiceImpl) testObject).parseStringToCollection("");

        assertThat(result.size(), is(0));
    }
}
