package com.monsanto.tps.materialweb.business.model;

import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class SearchType_UT {

    @Test
    public void testFromStringForValidDescriptionStrings() throws Exception {

        assertThat(SearchType.fromString(SearchType.NONE.description()), equalTo(SearchType.NONE));
        assertThat(SearchType.fromString(SearchType.PRECOMMERCIAL.description()), equalTo(SearchType.PRECOMMERCIAL));
        assertThat(SearchType.fromString(SearchType.LINECODE.description()), equalTo(SearchType.LINECODE));
        assertThat(SearchType.fromString(SearchType.BATCH.description()), equalTo(SearchType.BATCH));
        assertThat(SearchType.fromString(SearchType.ORIGIN.description()), equalTo(SearchType.ORIGIN));
        assertThat(SearchType.fromString(SearchType.ACRONYM.description()), equalTo(SearchType.ACRONYM));
        assertThat(SearchType.fromString(SearchType.COMMERCIAL.description()), equalTo(SearchType.COMMERCIAL));
        assertThat(SearchType.fromString(SearchType.MANUFACTURING_NAME.description()), equalTo(SearchType.MANUFACTURING_NAME));
    }

    @Test
    public void testFromStringForValidStrings() throws Exception {
        assertThat(SearchType.fromString("NONE"), equalTo(SearchType.NONE));
        assertThat(SearchType.fromString("PRECOMMERCIAL"), equalTo(SearchType.PRECOMMERCIAL));
        assertThat(SearchType.fromString("LINECODE"), equalTo(SearchType.LINECODE));
        assertThat(SearchType.fromString("BATCH"), equalTo(SearchType.BATCH));
        assertThat(SearchType.fromString("ORIGIN"), equalTo(SearchType.ORIGIN));
        assertThat(SearchType.fromString("ACRONYM"), equalTo(SearchType.ACRONYM));
        assertThat(SearchType.fromString("COMMERCIAL"), equalTo(SearchType.COMMERCIAL));
        assertThat(SearchType.fromString("MANUFACTURING_NAME"), equalTo(SearchType.MANUFACTURING_NAME));
    }

    @Test
    public void testFromStringForValidStrings_caseInsentive() throws Exception {

        assertThat(SearchType.fromString("none"), equalTo(SearchType.NONE));
        assertThat(SearchType.fromString("precommercial"), equalTo(SearchType.PRECOMMERCIAL));
        assertThat(SearchType.fromString("linecode"), equalTo(SearchType.LINECODE));
        assertThat(SearchType.fromString("batch"), equalTo(SearchType.BATCH));
        assertThat(SearchType.fromString("origin"), equalTo(SearchType.ORIGIN));
        assertThat(SearchType.fromString("acronym"), equalTo(SearchType.ACRONYM));
        assertThat(SearchType.fromString("commercial"), equalTo(SearchType.COMMERCIAL));
        assertThat(SearchType.fromString("manufacturing name"), equalTo(SearchType.MANUFACTURING_NAME));
    }

    @Test
    public void testFromStringForValidStrings_null() throws Exception {
        assertThat(SearchType.NONE, equalTo(SearchType.fromString("null")));
    }

    @Test
    public void testFromStringForNull() {
        assertThat(SearchType.fromString("abc"), equalTo(SearchType.NONE));
    }

    @Test
    public void testValue() {
        assertThat(SearchType.COMMERCIAL.value(), equalTo(7));
    }

    @Test
    public void testHTMLEncodedDescription() {
        assertThat(SearchType.BATCH, equalTo(SearchType.fromString("Manufacturing%20Batch")));
        assertThat(SearchType.BATCH, equalTo(SearchType.fromString("Manufacturing Batch")));
    }
}
