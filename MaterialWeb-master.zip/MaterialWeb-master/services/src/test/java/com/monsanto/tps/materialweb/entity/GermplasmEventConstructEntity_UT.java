package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 10/18/12
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmEventConstructEntity_UT {
    private GermplasmEventConstructEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new GermplasmEventConstructEntity();
    }

    @Test
    public void testGetGermplasmEventConstructId() throws Exception {
        EventConstructEntity event = new EventConstructEntity();
        event.setEventConstructId(-1l);
        testObject.setEvent(event);
        GermplasmEntity germplasm = new GermplasmEntity();
        germplasm.setGermplasmId(-2l);
        testObject.setGermplasm(germplasm);
        testObject.setGermplasmEventConstructId(-3l);
        Date date = new Date();
        testObject.setAbsenceDate(date);

        assertThat(testObject.getEvent(), equalTo(event));
        assertThat(testObject.getGermplasm(), equalTo(germplasm));
        assertThat(testObject.getGermplasmEventConstructId(), equalTo(-3l));
        assertThat(testObject.getAbsenceDate(), equalTo(date));
    }
}
