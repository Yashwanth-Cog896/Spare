package com.monsanto.tps.materialweb;

import org.eclipse.jetty.security.HashLoginService;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;
import org.junit.Test;

// Before launching the webapp using this test:
// 1. Use a JRE that doesn't have the servlet-api.jar in its lib/ext folder. Jetty versions >= 6 require servlet api >= 2.5 and we have 2.4 in our JREs
// 2. At a minimum use the following system properites:
//    -Dlsi.function=win
//    -DMONCRYPTJV=C:\MONCRYPTJV
//    -Xmx768m
//    -XX:PermSize=256M
// 3. If you want logging directed to a file (like when deployed to WebLogic), use these properties with appropriate values:
//    -Dserver.logs=c:/webapps/logs
//    -Dlog4j.configuration=file:///C:/projects/experimentCuration/trunk/experiment-curation-service/target/classes/log4j.xml

// To maintain this test:
// 1. When introducing any new JNDI resources(datasources, JMS connection factories, queues etc.) to the project also add them to jetty-env.xml
// 2. When updating localurlmap.properties in src/main/resources also update the same file under src/test/resources

public class JettyServer_XT {
    @Test
    public void startServer() throws Exception {
        setSystemPropertiesForJettyJNDI();

        Server server = new Server(7001);

        WebAppContext context = new WebAppContext();
        HashLoginService dummyLoginService = new HashLoginService("TEST-SECURITY-REALM");
        context.getSecurityHandler().setLoginService(dummyLoginService);
        context.setConfigurationClasses(getConfigurationClasses());
        context.setResourceBase("services/target/material-web-services");
        context.setContextPath("/material-services");

        context.setParentLoaderPriority(true);

        server.setHandler(context);

        server.start();
        System.out.println("Jetty server started...");
        server.join();
    }

    private void setSystemPropertiesForJettyJNDI() {
        System.setProperty("java.naming.factory.url.pkgs", "org.eclipse.jetty.jndi");
        System.setProperty("java.naming.factory.initial", "org.eclipse.jetty.jndi.InitialContextFactory");
    }

    private String[] getConfigurationClasses() {
        return new String[]{
                "org.eclipse.jetty.webapp.WebInfConfiguration",
                "org.eclipse.jetty.webapp.WebXmlConfiguration",
                "org.eclipse.jetty.webapp.MetaInfConfiguration",
                "org.eclipse.jetty.webapp.FragmentConfiguration",
                "org.eclipse.jetty.plus.webapp.EnvConfiguration",
                "org.eclipse.jetty.webapp.JettyWebXmlConfiguration",
                "org.eclipse.jetty.webapp.TagLibConfiguration"
        };
    }

}