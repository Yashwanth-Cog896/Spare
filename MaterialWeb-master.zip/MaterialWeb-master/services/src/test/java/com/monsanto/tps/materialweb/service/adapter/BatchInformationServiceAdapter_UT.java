package com.monsanto.tps.materialweb.service.adapter;

import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.regulatory.traitquality.sap.BatchInformationService;
import com.monsanto.tps.regulatory.traitquality.sap.BatchSearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.SearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isNotNull;
import static org.mockito.Mockito.ignoreStubs;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class BatchInformationServiceAdapter_UT {
    @InjectMocks
    private BatchInformationServiceAdapter testObject = new BatchInformationServiceAdapter();
    @Mock
    private BatchInformationService batchInformationService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testFindByCriteria() throws Exception {
        SearchCriteria criteria = new SearchCriteria();

        Collection<PipelineBatchInformationDTO> results = testObject.findByCriteria(criteria);

        verify(batchInformationService).findByCriteria(criteria);
    }

    @Test
    public void testFindByCriteria_throwExcpetion() {
        SearchCriteria criteria = new SearchCriteria();
        IllegalArgumentException ex = new IllegalArgumentException("bad");
        when(batchInformationService.findByCriteria(Matchers.<SearchCriteria>any())).thenThrow(ex);

        try {
            Collection<PipelineBatchInformationDTO> results = testObject.findByCriteria(criteria);
            fail("Should throw exception");
        } catch (ServiceFailureException e) {
            assertThat(e instanceof ServiceFailureException, is(true));
        }

    }
}
