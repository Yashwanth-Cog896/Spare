package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.search.TransgenicQualityEvaluator;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.junit.Test;

import java.util.Collection;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class TransgenicQualityEvaluatorImpl_UT {
    private TransgenicQualityEvaluator testObject = new TransgenicQualityEvaluatorImpl();

    @Test
    public void testTransgenicColumns() {
        MaterialInformation item1 = new MaterialInformation();
        item1.setMaterialNumber("2");
        Collection<MaterialInformation> searchResults = Lists.newArrayList(item1);

        assertThat(item1.getTransgenic(), is("F"));
        assertThat(item1.getAnimalGene(), is("F"));
        assertThat(item1.getMiniChromosome(), is("F"));
        item1.setEvent("ABC");
        item1.setRestriction("restrictedAnimG, restrictedMiniC");

        testObject.updateTransgenticColumns(searchResults);

        assertThat(item1.getTransgenic(), is("T"));
        assertThat(item1.getAnimalGene(), is("T"));
        assertThat(item1.getMiniChromosome(), is("T"));
    }

    @Test
    public void testTransgenicAndRestrictionColumns() {
        MaterialInformation item1 = new MaterialInformation();
        item1.setMaterialNumber("2");
        Collection<MaterialInformation> searchResults = Lists.newArrayList(item1);

        assertThat(item1.getTransgenic(), is("F"));
        assertThat(item1.getAnimalGene(), is("F"));
        assertThat(item1.getMiniChromosome(), is("F"));
        item1.setRestriction("restrictedAnimG");

        testObject.updateTransgenticColumns(searchResults);

        assertThat(item1.getTransgenic(), is("T"));
        assertThat(item1.getAnimalGene(), is("T"));
        assertThat(item1.getMiniChromosome(), is("F"));
    }

    @Test
    public void testTransgenicColumns_noEventsOrRestrictions() {
        MaterialInformation item1 = new MaterialInformation();
        item1.setMaterialNumber("3");
        Collection<MaterialInformation> searchResults = Lists.newArrayList(item1);

        testObject.updateTransgenticColumns(searchResults);

        assertThat(item1.getTransgenic(), is("F"));
        assertThat(item1.getAnimalGene(), is("F"));
        assertThat(item1.getMiniChromosome(), is("F"));
    }

    @Test
    public void testTransgenicDependentColumns_noMaterial() {
        MaterialInformation item1 = new MaterialInformation();
        Collection<MaterialInformation> searchResults = Lists.newArrayList(item1);

        testObject.updateTransgenticColumns(searchResults);

        assertThat(item1.getFromManufacturing(), is(""));
        assertThat(item1.getExposureHistory(), is(""));
        assertThat(item1.getToxinsPresent(), is(""));
        assertThat(item1.getAllergens(), is(""));
        assertThat(item1.getTransgenic(), is("F"));
        assertThat(item1.getAnimalGene(), is("F"));
        assertThat(item1.getMiniChromosome(), is("F"));
    }
}
