package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 10/18/12
 * Time: 1:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class EventConstructEntity_UT {
    private EventConstructEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new EventConstructEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setBarcode("A");
        testObject.setConstructName("B");
        testObject.setEventConstructId(-1l);
        testObject.setEventName("C");
        testObject.setRefActive("D");

        assertThat(testObject.getBarcode(), equalTo("A"));
        assertThat(testObject.getConstructName(), equalTo("B"));
        assertThat(testObject.getEventConstructId(), equalTo(-1l));
        assertThat(testObject.getEventName(), equalTo("C"));
        assertThat(testObject.getRefActive(), equalTo("D"));
    }
}
