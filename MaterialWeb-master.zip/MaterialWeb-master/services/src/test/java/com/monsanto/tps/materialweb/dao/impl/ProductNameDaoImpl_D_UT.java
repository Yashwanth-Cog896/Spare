package com.monsanto.tps.materialweb.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.ProductNameDao;
import com.monsanto.tps.materialweb.dao.TempSessionOcdDao;
import com.monsanto.tps.materialweb.entity.ProductNameEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdId;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.List;

import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@Transactional
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
public class ProductNameDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    @Resource(name = "productNameDao")
    private ProductNameDao productNameDao;
    @Resource(name = "tempSessionOcdDao")
    private TempSessionOcdDao tempSessionOcdDaoDao;

    public PersistentStoreConnection connection;

    @Before
    public void setUp() throws Exception {
      connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
    }

    @Test
    public void testLookupCommercialProductName() throws Exception {
        Long companyId = getCompany_monsanto(connection);
        Long brandId = getBrand_DEKALB(connection, companyId);
        String productName = getProductName_DEKALB(connection, brandId);

        List<ProductNameEntity> results = productNameDao.lookupCommercialProductName(productName);

        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    @Test
    public void testLookupCommercialProductNameWildCard() throws Exception {
        Long companyId = getCompany_monsanto(connection);
        Long brandId = getBrand_DEKALB(connection, companyId);
        String productName = getProductName_DEKALB(connection, brandId);

        List<ProductNameEntity> results = productNameDao.lookupCommercialProductNameLike(productName);

        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    @Test
    public void testGetCommericalProductNameByProductId() throws WrappingException, EmptyResultSetException {
        Long companyId = getCompany_monsanto(connection);
        Long brandId = getBrand_DEKALB(connection, companyId);
        Long productId = getProductId_DEKALB(connection, brandId);

        List<ProductNameEntity> results = productNameDao.getCommercialProductNameByProductIds(Lists.newArrayList(productId));

        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    @Test
    public void testGetCommericalProductNamesByTempSessionId() throws WrappingException, EmptyResultSetException {
        sessionFactory.getCurrentSession().beginTransaction();  //NOTE Temp has to be in an active transaction to work
        Long companyId = getCompany_monsanto(connection);
        Long brandId = getBrand_DEKALB(connection, companyId);
        Long productId = getProductId_DEKALB(connection, brandId);
        Integer requestId = 181;
        TempSessionOcdEntity tempSessionOcd = new TempSessionOcdEntity(new TempSessionOcdId(requestId.longValue(), productId, null, null, null, 1L));
        sessionFactory.getCurrentSession().save(tempSessionOcd);
        sessionFactory.getCurrentSession().flush();
        sessionFactory.getCurrentSession().evict(tempSessionOcd);

        List<ProductNameEntity> results = productNameDao.getCommercialProductNameByProductWithTempId(requestId.longValue());

        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    private Long getCompany_monsanto(PersistentStoreConnection connection) throws WrappingException, EmptyResultSetException {
        PersistentStoreResultSet result = connection.executeQuery("select company_id from midas.company where name = 'MONSANTO'");
        return result.getSingleResult().getLong("company_id");
    }

    private Long getBrand_DEKALB(PersistentStoreConnection connection, Long companyId) throws WrappingException, EmptyResultSetException {
        PersistentStoreResultSet result = connection.executeQuery("select brand_id from midas.brand where name = 'DEKALB' and company_id = " + companyId.toString());
        return result.getSingleResult().getLong("brand_id");
    }

    private String getProductName_DEKALB(PersistentStoreConnection connection, Long brandId) throws WrappingException, EmptyResultSetException {
        PersistentStoreResultSet result = connection.executeQuery("select name from MIDAS.PRODUCT_NAME where brand_id = " + brandId.toString() + "and rownum = 1 and name like ('D%')");
        return result.getSingleResult().getString("name");
    }

    private Long getProductId_DEKALB(PersistentStoreConnection connection, Long brandId) throws WrappingException, EmptyResultSetException {
        PersistentStoreResultSet result = connection.executeQuery("select product_id from MIDAS.PRODUCT_NAME where brand_id = " + brandId.toString() + "and rownum = 1 and name like ('D%') and ref_active = 'T'");
        return result.getSingleResult().getLong("product_id");
    }
}
