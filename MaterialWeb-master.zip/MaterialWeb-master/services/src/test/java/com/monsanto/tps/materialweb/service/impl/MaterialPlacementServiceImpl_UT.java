package com.monsanto.tps.materialweb.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.materialweb.dao.MaterialPlacementDao;
import com.monsanto.tps.materialweb.model.MaterialPlacementInformation;
import com.monsanto.tps.materialweb.service.MaterialPlacementService;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;

import java.util.Collection;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MaterialPlacementServiceImpl_UT {

    @Mock
    private MaterialPlacementDao materialPlacementDao;
    @Mock
    private EnhancedUserDetails enhancedUserDetails;
    @Mock
    private UserDetailsProvider userDetailsProvider;
    @Mock
    private DataPointHolder dataPointHolder;
    @InjectMocks
    private MaterialPlacementService materialPlacementService = new MaterialPlacementServiceImpl(materialPlacementDao, userDetailsProvider);

    @Before
    public void setup() {
        when(userDetailsProvider.getUserDetails()).thenReturn(enhancedUserDetails);
    }

    @Test
    public void testPlacementWithRole() {
        when(enhancedUserDetails.getAuthorities()).thenReturn((Collection) Lists.<GrantedAuthority>newArrayList(new GrantedAuthorityImpl(MaterialPlacementServiceImpl.ROLE_BREEDER)));

        MaterialPlacementInformation resp = new MaterialPlacementInformation();
        resp.setInventoryBarcode("IB1");
        resp.setPedigree("P1");
        resp.setSource("S1");
        Mockito.when(materialPlacementDao.getPlacementInfo(Lists.newArrayList("1", "2"))).thenReturn(Lists.newArrayList(resp));

        MaterialPlacementInformation[] placementInformation = materialPlacementService.placement("1,2");

        assertEquals(1, placementInformation.length);
        assertEquals("IB1", placementInformation[0].getInventoryBarcode());
        assertEquals("P1", placementInformation[0].getPedigree());
        assertEquals("S1", placementInformation[0].getSource());
        Mockito.verify(dataPointHolder).add(MaterialPlacementServiceImpl.INVENTORY_COUNT, 2.0);
        Mockito.verify(dataPointHolder).add(MaterialPlacementServiceImpl.PLACEMENT_INFO_COUNT, 1.0);
    }

    @Test
    public void testPlacementWithoutRole() {
        when(enhancedUserDetails.getAuthorities()).thenReturn((Collection) Lists.<GrantedAuthority>newArrayList());

        MaterialPlacementInformation resp = new MaterialPlacementInformation();
        resp.setInventoryBarcode("IB1");
        resp.setPedigree("P1");
        resp.setSource("S1");
        Mockito.when(materialPlacementDao.getPlacementInfo(Lists.newArrayList("1", "2"))).thenReturn(Lists.newArrayList(resp));

        MaterialPlacementInformation[] placementInformation = materialPlacementService.placement("1,2");

        assertEquals(1, placementInformation.length);
        assertEquals("IB1", placementInformation[0].getInventoryBarcode());
        assertNull(placementInformation[0].getPedigree());
        assertNull(placementInformation[0].getSource());
    }
}
