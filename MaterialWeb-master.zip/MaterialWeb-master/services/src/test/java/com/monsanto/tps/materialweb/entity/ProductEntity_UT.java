package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class ProductEntity_UT {
    private ProductEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new ProductEntity();
    }

    @Test
    public void testGetProductId() throws Exception {
        testObject.setProductId(-5l);
        testObject.setRefActive("F");
        CropEntity crop = new CropEntity();
        crop.setCropId(-8l);
        testObject.setCrop(crop);

        assertThat(testObject.getProductId(), equalTo(-5l));
        assertThat(testObject.getRefActive(), equalTo("F"));
        assertThat(testObject.getCrop(), equalTo(crop));
    }
}
