package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;


public class ProductNameEntity_UT {
    private ProductNameEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new ProductNameEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setProductNameId(-9l);
        testObject.setProductName("r");
        testObject.setRefActive("F");
        BrandEntity brand = new BrandEntity();
        brand.setBrandId(-2l);
        testObject.setBrand(brand);
        ProductEntity product = new ProductEntity();
        product.setProductId(-1l);
        testObject.setProduct(product);

        assertThat(testObject.getProductNameId(), equalTo(-9l));
        assertThat(testObject.getProductName(), equalTo("r"));
        assertThat(testObject.getRefActive(), equalTo("F"));
        assertThat(testObject.getProduct(), equalTo(product));
        assertThat(testObject.getBrand(), equalTo(brand));
    }
}
