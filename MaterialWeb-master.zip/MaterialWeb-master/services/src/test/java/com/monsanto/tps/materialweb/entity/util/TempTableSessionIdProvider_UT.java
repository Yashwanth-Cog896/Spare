package com.monsanto.tps.materialweb.entity.util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TempTableSessionIdProvider_UT {
    @Test
    public void testGetNextSessionId_WrapsAroundAtMaxSize() throws Exception {
        TempTableSessionIdProvider tempTableSessionIdProvider = new TempTableSessionIdProvider();
        for (int i = 1; i < 10000; i++) {
            assertEquals(i, tempTableSessionIdProvider.getNextSessionId());
        }
        assertEquals(10000, tempTableSessionIdProvider.getNextSessionId());
        assertEquals(1, tempTableSessionIdProvider.getNextSessionId());
    }
}
