package com.monsanto.tps.materialweb;

import com.google.common.collect.Lists;
import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

public class UserDetailsHelper_UT {

    @Test
    public void testHasRole() {
        GrantedAuthority grantedAuthority1 = new GrantedAuthorityImpl("R1");
        GrantedAuthority grantedAuthority2 = new GrantedAuthorityImpl("R2");
        assertTrue(UserDetailsHelper.hasRole(Lists.newArrayList(grantedAuthority1, grantedAuthority2), "R1"));
    }

    @Test
    public void testHasAnySingleRole() {
        GrantedAuthority grantedAuthority1 = new GrantedAuthorityImpl("R1");
        GrantedAuthority grantedAuthority2 = new GrantedAuthorityImpl("R2");
        assertTrue(UserDetailsHelper.hasRole(Lists.newArrayList(grantedAuthority1, grantedAuthority2), "R1", "R3"));
    }

    @Test
    public void testDoesNotHaveRole() {
        GrantedAuthority grantedAuthority1 = new GrantedAuthorityImpl("R1");
        GrantedAuthority grantedAuthority2 = new GrantedAuthorityImpl("R2");
        assertFalse(UserDetailsHelper.hasRole(Lists.newArrayList(grantedAuthority1, grantedAuthority2), "R3"));
    }
}
