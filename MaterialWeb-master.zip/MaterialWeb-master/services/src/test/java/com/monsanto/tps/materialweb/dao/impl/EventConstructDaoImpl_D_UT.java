package com.monsanto.tps.materialweb.dao.impl;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.TempSessionOcdDao;
import com.monsanto.tps.materialweb.entity.GermplasmEventConstructEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdEntity;
import com.monsanto.tps.materialweb.entity.TempSessionOcdId;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.List;

import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.junit.Assert.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/spring-properties-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-dao-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml"
})
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
@Transactional
public class EventConstructDaoImpl_D_UT {
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "dataSource")
    private DataSource dataSource;
    @Resource(name = "eventConstructDao")
    private EventConstructDaoImpl eventConstructDao;
    @Resource(name = "tempSessionOcdDao")
    private TempSessionOcdDao tempSessionOcdDaoDao;

    public PersistentStoreConnection connection;

    @Before
    public void setUp() throws Exception {
        connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
    }

    @Test
    public void testGetEventConstructsByGermplasmId() throws WrappingException, EmptyResultSetException {
        sessionFactory.getCurrentSession().beginTransaction();  //NOTE Temp has to be in an active transaction to work
        Long germplasmId = getGermplasmIds_WithEvents(connection);
        Integer requestId = 191;
        TempSessionOcdEntity tempSessionOcd = new TempSessionOcdEntity(new TempSessionOcdId(requestId.longValue(), germplasmId, null, null, null, 1L));
        sessionFactory.getCurrentSession().save(tempSessionOcd);
        sessionFactory.getCurrentSession().flush();
        sessionFactory.getCurrentSession().evict(tempSessionOcd);

        List<GermplasmEventConstructEntity> results = eventConstructDao.getEventsForGermplasmIdWithTempSessionId(requestId.longValue());

        assertThat(results.size(), greaterThanOrEqualTo(1));
    }

    private Long getGermplasmIds_WithEvents(PersistentStoreConnection connection) throws WrappingException, EmptyResultSetException {
        PersistentStoreResultSet result = connection.executeQuery("select germplasm_id from MIDAS.GERMPLASM_EVENT_CONSTRUCT where EVENT_CONSTRUCT_ABSENCE_DATE IS NULL ");
        return result.getSingleResult().getLong("germplasm_Id");
    }

}
