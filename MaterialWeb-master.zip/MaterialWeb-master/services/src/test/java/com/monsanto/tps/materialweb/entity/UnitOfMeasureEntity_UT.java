package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class UnitOfMeasureEntity_UT {
    private UnitOfMeasureEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new UnitOfMeasureEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setUomId(-22l);
        testObject.setName("uom stuff");
        testObject.setReferenceId("r4");
        testObject.setReferenceActive("F");

        assertThat(testObject.getUomId(), equalTo(-22l));
        assertThat(testObject.getName(), equalTo("uom stuff"));
        assertThat(testObject.getReferenceId(), equalTo("r4"));
        assertThat(testObject.getReferenceActive(), equalTo("F"));
    }
}
