package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class VegetativeStructureEntity_UT {
    private VegetativeStructureEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new VegetativeStructureEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setId(-23l);
        testObject.setName("veg stuff");
        testObject.setReferenceCode("r5");
        testObject.setReferenceActive("F");

        assertThat(testObject.getId(), equalTo(-23l));
        assertThat(testObject.getName(), equalTo("veg stuff"));
        assertThat(testObject.getReferenceCode(), equalTo("r5"));
        assertThat(testObject.getReferenceActive(), equalTo("F"));
    }
}
