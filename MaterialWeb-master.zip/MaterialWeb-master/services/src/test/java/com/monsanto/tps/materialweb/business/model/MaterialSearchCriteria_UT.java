package com.monsanto.tps.materialweb.business.model;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.entity.CropEntity;
import org.junit.Test;

import java.util.Collection;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class MaterialSearchCriteria_UT {

    @Test
    public void testSettersAndGetters() throws Exception {
        MaterialSearchCriteria testObject = new MaterialSearchCriteria();

        CropEntity crop = new CropEntity();
        crop.setCropId(-5l);
        testObject.setCropEntity(crop);
        testObject.addSearchValue(SearchType.ACRONYM, Lists.newArrayList("b"));
        testObject.addSearchValue(SearchType.BATCH, Lists.newArrayList("c"));

        assertThat(testObject.getCropId(), equalTo(-5l));
        assertThat(testObject.getCropEntity(), equalTo(crop));
        Collection<String> valueB = Lists.newArrayList("b");
        Collection<String> valueC = Lists.newArrayList("c");
        assertThat((Map<SearchType, Collection<String>>) testObject.getCriteria(), hasEntry(SearchType.ACRONYM, valueB));
        assertThat((Map<SearchType, Collection<String>>) testObject.getCriteria(), hasEntry(SearchType.BATCH, valueC));
    }

    @Test
    public void testConstructor() {
        CropEntity crop = new CropEntity();
        crop.setCropId(-3l);
        MaterialSearchCriteria testObject = new MaterialSearchCriteria(crop, SearchType.LINECODE.toString(), Lists.newArrayList("d"), SearchType.MATERIAL.toString(), Lists.newArrayList("x"));

        assertThat(testObject.getCropId(), equalTo(-3l));
        Collection<String> valueD = Lists.newArrayList("d");
        Collection<String> valueX = Lists.newArrayList("x");
        assertThat((Map<SearchType, Collection<String>>) testObject.getCriteria(), hasEntry(SearchType.LINECODE, valueD));
        assertThat((Map<SearchType, Collection<String>>) testObject.getCriteria(), hasEntry(SearchType.MATERIAL, valueX));
    }

    @Test
    public void testBuildCriteriaString() {
        CropEntity crop = new CropEntity();
        crop.setCropId(-4l);
        MaterialSearchCriteria testObject = new MaterialSearchCriteria(crop, SearchType.BATCH.toString(), Lists.newArrayList("efg"), SearchType.ACRONYM.toString(), Lists.newArrayList("yz"));

        String criteria = testObject.buildSearchCriteriaString();

        assertThat(criteria, containsString("efg"));
        assertThat(criteria, containsString("yz"));
        assertThat(criteria, containsString(SearchType.BATCH.description()));
        assertThat(criteria, containsString(SearchType.ACRONYM.description()));
    }

    @Test
    public void testBuildCriteriaString_skipEmptyParameters() {
        CropEntity crop = new CropEntity();
        crop.setCropId(-5l);
        crop.setCropName("jkl");
        MaterialSearchCriteria testObject = new MaterialSearchCriteria(crop, SearchType.BATCH.toString(), Lists.newArrayList(""), SearchType.ACRONYM.toString(), Lists.newArrayList("null"));

        String criteria = testObject.buildSearchCriteriaString();

        assertThat(criteria, containsString("jkl"));
        assertThat(criteria, not(containsString(SearchType.BATCH.description())));
        assertThat(criteria, not(containsString(SearchType.ACRONYM.description())));
        assertThat(testObject.getCriteria().size(), is(0));
    }
}
