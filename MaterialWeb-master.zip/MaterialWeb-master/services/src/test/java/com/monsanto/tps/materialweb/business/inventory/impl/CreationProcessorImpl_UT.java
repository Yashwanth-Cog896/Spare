package com.monsanto.tps.materialweb.business.inventory.impl;

import com.google.common.collect.Lists;
import com.monsanto.tcc.lineadvancement.model.SourceCreationRequest;
import com.monsanto.tcc.lineadvancement.model.SourceCreationResponse;
import com.monsanto.tcc.lineadvancement.service.InventoryCreationService;
import com.monsanto.tps.materialweb.business.inventory.CreationProcessor;
import com.monsanto.tps.materialweb.model.CreationRequest;
import com.monsanto.tps.materialweb.model.CreationResults;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CreationProcessorImpl_UT {
    @InjectMocks
    private CreationProcessor testObject;
    @Mock
    private InventoryCreationService remoteInventoryCreationService;

    @Before
    public void setUp() throws Exception {
        testObject = new CreationProcessorImpl();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCreateNewSources() throws Exception {
        Collection<CreationRequest> requests = Lists.newArrayList();
        Collection<SourceCreationResponse> responses = Lists.newArrayList();
        SourceCreationResponse response1 = new SourceCreationResponse();
        response1.setGermplasmId(-3l);
        response1.setSuccessful(true);
        responses.add(response1);
        SourceCreationResponse response2 = new SourceCreationResponse();
        response2.setGermplasmId(-5l);
        response2.setSuccessful(true);
        responses.add(response2);
        when(remoteInventoryCreationService.createNewSourceForExistingGermplasm((Collection<SourceCreationRequest>) any())).thenReturn(responses);
        CreationRequest request1 = new CreationRequest();
        request1.setGermplasmId(-4l);
        request1.setInventoryOwnerProgram("2b");
        request1.setSeedQuantity(5d);
        request1.setSeedQuantityUOM("seed");
        request1.setSourceName("abc");
        request1.setValidateOnly(false);
        request1.setVegetativeStructure("seed");
        requests.add(request1);

        CreationResults results = testObject.createNewSources(requests, "rehigg");

        assertThat(results, notNullValue());
        verify(remoteInventoryCreationService).createNewSourceForExistingGermplasm((Collection<SourceCreationRequest>) any());
        assertThat(results.getResponseMessage().isEmpty(), is(true));
        assertThat(results.isRequestSuccess(), is(true));
        assertThat(results.getResponses().size(), is(2));
    }

    @Test
    public void testCreateNewSources_responseWithError() throws Exception {
        Collection<CreationRequest> requests = Lists.newArrayList();
        Collection<SourceCreationResponse> responses = Lists.newArrayList();
        SourceCreationResponse response1 = new SourceCreationResponse();
        response1.setGermplasmId(-3l);
        response1.setSuccessful(true);
        responses.add(response1);
        SourceCreationResponse response2 = new SourceCreationResponse();
        response2.setGermplasmId(-5l);
        response2.setSuccessful(false);
        responses.add(response2);
        when(remoteInventoryCreationService.createNewSourceForExistingGermplasm((Collection<SourceCreationRequest>) any())).thenReturn(responses);
        CreationRequest request1 = new CreationRequest();
        request1.setGermplasmId(-4l);
        request1.setInventoryOwnerProgram("2b");
        request1.setSeedQuantity(5d);
        request1.setSeedQuantityUOM("seed");
        request1.setSourceName("abc");
        request1.setValidateOnly(false);
        request1.setVegetativeStructure("seed");
        requests.add(request1);

        CreationResults results = testObject.createNewSources(requests, "rehigg");

        assertThat(results, notNullValue());
        verify(remoteInventoryCreationService).createNewSourceForExistingGermplasm((Collection<SourceCreationRequest>) any());
        assertThat(results.isRequestSuccess(), is(false));
        assertThat(results.getResponses().size(), is(2));
        assertThat(results.getResponseMessage(), is("Resolve problems and resubmit."));
    }

    @Test
    public void testValuesOnRequest() {
        CreationRequest request1 = new CreationRequest();
        request1.setAllergensPresent("A");
        request1.setAnimalGenePresent("True");
        request1.setExposureHistoryKnown("False");
        request1.setFromManufacturing("D");
        request1.setGermplasmId(-5l);
        request1.setInventoryOwnerProgram("E");
        request1.setManufacturingAcronymNumber("F");
        request1.setManufacturingBatchNumber("G");
        request1.setManufacturingMaterialNumber("H");
        request1.setMiniChromosome("I");
        request1.setSeedQuantity(-2d);
        request1.setSeedQuantityUOM("J");
        request1.setSourceName("K");
        request1.setToxinsPresent("L");
        request1.setValidateOnly(false);
        request1.setVegetativeStructure("M");
        Collection<CreationRequest> requests = Lists.newArrayList(request1);
        Collection<SourceCreationResponse> responses = Lists.newArrayList();
        SourceCreationResponse response1 = new SourceCreationResponse();
//        response1.setGermplasmId(-3l);
//        response1.setSuccessful(true);
//        responses.add(response1);
        SourceCreationResponse response2 = new SourceCreationResponse();
//        response2.setGermplasmId(-5l);
//        response2.setSuccessful(false);
        responses.add(response2);
//        Collection<SourceCreationRequest> sourceRequest = ;
        ArgumentCaptor<Collection> sourceRequests = ArgumentCaptor.forClass(Collection.class);
        when(remoteInventoryCreationService.createNewSourceForExistingGermplasm((Collection<SourceCreationRequest>) sourceRequests.capture())).thenReturn(responses);

        CreationResults results = testObject.createNewSources(requests, "rehigg");

        assertThat(results, notNullValue());
        Collection<SourceCreationRequest> sourceRequestList = sourceRequests.getValue();
        SourceCreationRequest sourceRequest1 = sourceRequestList.iterator().next();
        assertThat(sourceRequest1.getAllergensPresent(), is(CreationProcessorImpl.DEFAULT));
        assertThat(sourceRequest1.getAnimalGenePresent(), is(CreationProcessorImpl.TRUE));
        assertThat(sourceRequest1.getApproverLoginId(), is("rehigg"));
        assertThat(sourceRequest1.getExposureHistoryKnown(), is(CreationProcessorImpl.FALSE));
        assertThat(sourceRequest1.getFromManufacturing(), is(request1.getFromManufacturing()));
        assertThat(sourceRequest1.getInventoryOwnerBrProgRefId(), is(request1.getInventoryOwnerProgram()));
        assertThat(sourceRequest1.getGermplasmId(), is(request1.getGermplasmId()));
        assertThat(sourceRequest1.getManufacturingAcronymNumber(), is(request1.getManufacturingAcronymNumber()));
        assertThat(sourceRequest1.getManufacturingBatchNumber(), is(request1.getManufacturingBatchNumber()));
        assertThat(sourceRequest1.getManufacturingMaterialNumber(), is(request1.getManufacturingMaterialNumber()));
        assertThat(sourceRequest1.getMiniChromosome(), is("-"));
        assertThat(sourceRequest1.getRequesterLoginID(), is("rehigg"));
        assertThat(sourceRequest1.getSeedQuantity(), is(request1.getSeedQuantity()));
        assertThat(sourceRequest1.getSourceName(), is(request1.getSourceName()));
        assertThat(sourceRequest1.getToxinsPresent(), is("-"));
        assertThat(sourceRequest1.getUomName(), is(request1.getSeedQuantityUOM()));
        assertThat(sourceRequest1.getVegetativeStructureName(), is(request1.getVegetativeStructure()));

    }
}
