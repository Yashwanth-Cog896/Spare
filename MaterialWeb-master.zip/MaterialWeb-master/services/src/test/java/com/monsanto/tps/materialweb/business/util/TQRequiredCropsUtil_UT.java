package com.monsanto.tps.materialweb.business.util;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.service.adapter.TraitQualityPolicyServiceAdapter;
import com.monsanto.tps.regulatory.traitquality.isolation.CropTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;


public class TQRequiredCropsUtil_UT {
    @Mock
    private TraitQualityPolicyServiceAdapter traitQualityPolicyServiceAdapter;
    @InjectMocks
    private TQRequiredCropsUtil tqRequiredCropsUtil;
    private Collection<CropTO> mockTQCrops;

    @Before
    public void setUp() throws Exception {
        tqRequiredCropsUtil = new TQRequiredCropsUtil();
        MockitoAnnotations.initMocks(this);
        CropTO crop1 = new CropTO(-3l, "Corn");
        CropTO crop2 = new CropTO(-5l, "Wheat");
        mockTQCrops = Lists.newArrayList(crop1, crop2);
    }

    @Test
    public void testLoading() throws Exception {
        when(traitQualityPolicyServiceAdapter.getTraitQualityPolicyCrops()).thenReturn(mockTQCrops);

        Boolean result = tqRequiredCropsUtil.isCropTQRequiredByCropId(-2l);
        Boolean result2 = tqRequiredCropsUtil.isCropTQRequiredByCropId(-2l);

        assertThat(result, is(false));
        verify(traitQualityPolicyServiceAdapter, times(1)).getTraitQualityPolicyCrops();
    }

    @Test
    public void testReTry() throws Exception {
        Boolean result = tqRequiredCropsUtil.isCropTQRequiredByCropId(-2l);
        when(traitQualityPolicyServiceAdapter.getTraitQualityPolicyCrops()).thenReturn(mockTQCrops);
        Boolean result2 = tqRequiredCropsUtil.isCropTQRequiredByCropId(-2l);

        assertThat(result, is(false));
        verify(traitQualityPolicyServiceAdapter, times(2)).getTraitQualityPolicyCrops();
    }

    @Test
    public void testIsCropTQRequiredByCropId() throws Exception {
        when(traitQualityPolicyServiceAdapter.getTraitQualityPolicyCrops()).thenReturn(mockTQCrops);

        Boolean result = tqRequiredCropsUtil.isCropTQRequiredByCropId(-3l);

        assertThat(result, is(true));
    }

    @Test
    public void testIsCropTQRequiredByCropName() throws Exception {
        when(traitQualityPolicyServiceAdapter.getTraitQualityPolicyCrops()).thenReturn(mockTQCrops);

        Boolean result = tqRequiredCropsUtil.isCropTQRequiredByCropName("corn");

        assertThat(result, is(true));
    }
}
