package com.monsanto.tps.materialweb.entity;

import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class GermplasmEntity_UT {
    private GermplasmEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new GermplasmEntity();
    }

    @Test
    public void testGetGermplasmId() throws Exception {
        testObject.setGermplasmId(-2l);
        testObject.setEventDisplay("A");
        testObject.setCytoplasmDonor("B");
        CropEntity crop = new CropEntity();
        crop.setCropId(-5l);
        testObject.setCrop(crop);
        testObject.setConstructDisplay("C");
        testObject.setLineCode("D");
        testObject.setOrigin("E");
        testObject.setPedigreeName("F");
        testObject.setTransgenic("G");
        LineFunctionEntity lf = new LineFunctionEntity();
        lf.setLineFunctionId(-5l);
        testObject.setLineFunction(lf);
        testObject.setDeleted("T");
        GermplasmEventConstructEntity gec = new GermplasmEventConstructEntity();
        gec.setGermplasmEventConstructId(-8l);
        testObject.setGermplasmEventConstruct(Lists.newArrayList(gec));

        assertThat(testObject.getGermplasmId(), equalTo(-2l));
        assertThat(testObject.getEventDisplay(), is("A"));
        assertThat(testObject.getCytoplasmDonor(), is("B"));
        assertThat(testObject.getCrop(), is(crop));
        assertThat(testObject.getConstructDisplay(), is("C"));
        assertThat(testObject.getLineCode(), is("D"));
        assertThat(testObject.getOrigin(), is("E"));
        assertThat(testObject.getPedigreeName(), is("F"));
        assertThat(testObject.getTransgenic(), is("G"));
        assertThat(testObject.getLineFunction(), is(lf));
        assertThat(testObject.getDeleted(), is("T"));
        assertThat(testObject.getGermplasmEventConstruct(), contains(gec));
    }
}
