package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class CropToVegetativeStructureEntity_UT {
    private CropToVegetativeStructureEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new CropToVegetativeStructureEntity();
    }

    @Test
    public void testGetAndSetters() throws Exception {
        CropEntity crop = new CropEntity();
        testObject.setCrop(crop);
        testObject.setId(-3l);
        testObject.setOrder(0);
        testObject.setRefActive("A");
        VegetativeStructureEntity structure = new VegetativeStructureEntity();
        testObject.setVegetativeStructure(structure);

        assertThat(testObject.getId(), is(-3l));
        assertThat(testObject.getOrder(), is(0));
        assertThat(testObject.getRefActive(), is("A"));
        assertThat(testObject.getCrop(), is(crop));
        assertThat(testObject.getVegetativeStructure(), is(structure));
    }
}
