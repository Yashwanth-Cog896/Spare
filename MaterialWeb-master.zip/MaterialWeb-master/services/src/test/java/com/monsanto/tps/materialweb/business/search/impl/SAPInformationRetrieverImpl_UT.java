package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.materialweb.business.model.SearchType;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.service.adapter.BatchInformationServiceAdapter;
import com.monsanto.tps.regulatory.traitquality.sap.Attribute;
import com.monsanto.tps.regulatory.traitquality.sap.AttributeFilter;
import com.monsanto.tps.regulatory.traitquality.sap.SearchCriteria;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class SAPInformationRetrieverImpl_UT {
    @InjectMocks
    private SAPInformationRetrieverImpl testObject;

    @Mock
    private BatchInformationServiceAdapter batchInformationServiceAdapter;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRetrieveInfo_Acronym_Batch() throws Exception {
        CropEntity crop = new CropEntity();
        crop.setCropName("Corn");
        MaterialSearchCriteria criteria = new MaterialSearchCriteria(crop, SearchType.ACRONYM.name(), Lists.newArrayList("A"), SearchType.BATCH.name(), Lists.newArrayList("B"));
        PipelineBatchInformationDTO result1 = new PipelineBatchInformationDTO();
        result1.setBatchNumber("-1");
        List<PipelineBatchInformationDTO> testResult = Lists.newArrayList(result1);
        ArgumentCaptor<SearchCriteria> batchCriteria = ArgumentCaptor.forClass(SearchCriteria.class);
        when(batchInformationServiceAdapter.findByCriteria(batchCriteria.capture())).thenReturn(testResult);

        Collection<PipelineBatchInformationDTO> results = testObject.retrieveInfo(criteria);

        assertThat(results.size(), is(1));
        final List<AttributeFilter> simpleAttributeFilters = batchCriteria.getValue().getSimpleAttributeFilters();
        assertThat(simpleAttributeFilters.size(), is(3));
        boolean foundAcroymn = false;
        boolean foundBatch = false;
        boolean foundCrop = false;
        for (AttributeFilter filter : simpleAttributeFilters) {
            if (filter.getAttribute() == Attribute.BATCH_NUMBER) {
                assertThat(filter.getValue(), is("B"));
                assertThat(filter.getWildcard(), is(false));
                foundBatch = true;
            } else if (filter.getAttribute() == Attribute.CROP_NAME) {
                assertThat(filter.getValue(), is("Corn"));
                assertThat(filter.getWildcard(), is(false));
                foundCrop = true;
            } else if (filter.getAttribute() == Attribute.MANUFACTURING_ACRONYM) {
                assertThat(filter.getValue(), is("A"));
                assertThat(filter.getWildcard(), is(false));
                foundAcroymn = true;
            }
        }
        assertThat(foundBatch, is(true));
        assertThat(foundCrop, is(true));
        assertThat(foundAcroymn, is(true));
    }

    @Test
    public void testRetrieveInfo_LineCode_Origin_WildCard() throws Exception {
        CropEntity crop = new CropEntity();
        crop.setCropName("Corn");
        MaterialSearchCriteria criteria = new MaterialSearchCriteria(crop, SearchType.LINECODE.name(), Lists.newArrayList("C*"), SearchType.ORIGIN.name(), Lists.newArrayList("D"));
        PipelineBatchInformationDTO result1 = new PipelineBatchInformationDTO();
        result1.setBatchNumber("-1");
        List<PipelineBatchInformationDTO> testResult = Lists.newArrayList(result1);
        ArgumentCaptor<SearchCriteria> batchCriteria = ArgumentCaptor.forClass(SearchCriteria.class);
        when(batchInformationServiceAdapter.findByCriteria(batchCriteria.capture())).thenReturn(testResult);

        Collection<PipelineBatchInformationDTO> results = testObject.retrieveInfo(criteria);

        assertThat(results.size(), is(1));
        final List<AttributeFilter> simpleAttributeFilters = batchCriteria.getValue().getSimpleAttributeFilters();
        assertThat(simpleAttributeFilters.size(), is(3));
        boolean foundLineCode = false;
        boolean foundOrigin = false;
        boolean foundCrop = false;
        for (AttributeFilter filter : simpleAttributeFilters) {
            if (filter.getAttribute() == Attribute.ORIGIN) {
                assertThat(filter.getValue(), is("D"));
                assertThat(filter.getWildcard(), is(false));
                foundOrigin = true;
            } else if (filter.getAttribute() == Attribute.CROP_NAME) {
                assertThat(filter.getValue(), is("Corn"));
                assertThat(filter.getWildcard(), is(false));
                foundCrop = true;
            } else if (filter.getAttribute() == Attribute.LINE_CODE) {
                assertThat(filter.getValue(), is("C"));
                assertThat(filter.getWildcard(), is(true));
                foundLineCode = true;
            }
        }
        assertThat(foundOrigin, is(true));
        assertThat(foundCrop, is(true));
        assertThat(foundLineCode, is(true));
    }

    @Test
    public void testRetrieveInfo_PreComm_Material() throws Exception {
        CropEntity crop = new CropEntity();
        crop.setCropName("Corn");
        MaterialSearchCriteria criteria = new MaterialSearchCriteria(crop, SearchType.MATERIAL.name(), Lists.newArrayList("E"), SearchType.PRECOMMERCIAL.name(), Lists.newArrayList("F"));
        PipelineBatchInformationDTO result1 = new PipelineBatchInformationDTO();
        result1.setBatchNumber("-1");
        List<PipelineBatchInformationDTO> testResult = Lists.newArrayList(result1);
        ArgumentCaptor<SearchCriteria> batchCriteria = ArgumentCaptor.forClass(SearchCriteria.class);
        when(batchInformationServiceAdapter.findByCriteria(batchCriteria.capture())).thenReturn(testResult);

        Collection<PipelineBatchInformationDTO> results = testObject.retrieveInfo(criteria);

        assertThat(results.size(), is(1));
        final List<AttributeFilter> simpleAttributeFilters = batchCriteria.getValue().getSimpleAttributeFilters();
        assertThat(simpleAttributeFilters.size(), is(3));
        boolean foundLineCode = false;
        boolean foundOrigin = false;
        boolean foundCrop = false;
        for (AttributeFilter filter : simpleAttributeFilters) {
            if (filter.getAttribute() == Attribute.MATERIAL_NUMBER) {
                assertThat(filter.getValue(), is("E"));
                assertThat(filter.getWildcard(), is(false));
                foundOrigin = true;
            } else if (filter.getAttribute() == Attribute.CROP_NAME) {
                assertThat(filter.getValue(), is("Corn"));
                assertThat(filter.getWildcard(), is(false));
                foundCrop = true;
            } else if (filter.getAttribute() == Attribute.PRECOMMERCIAL_NAME) {
                assertThat(filter.getValue(), is("F"));
                assertThat(filter.getWildcard(), is(false));
                foundLineCode = true;
            }
        }
        assertThat(foundOrigin, is(true));
        assertThat(foundCrop, is(true));
        assertThat(foundLineCode, is(true));
    }

    @Test
    public void testRetrieveInfo_Comm_Manufacturing() throws Exception {
        CropEntity crop = new CropEntity();
        crop.setCropName("Corn");
        MaterialSearchCriteria criteria = new MaterialSearchCriteria(crop, SearchType.COMMERCIAL.name(), Lists.newArrayList("G"), SearchType.MANUFACTURING_NAME.name(), Lists.newArrayList("H"));
        PipelineBatchInformationDTO result1 = new PipelineBatchInformationDTO();
        result1.setBatchNumber("-1");
        List<PipelineBatchInformationDTO> testResult = Lists.newArrayList(result1);
        ArgumentCaptor<SearchCriteria> batchCriteria = ArgumentCaptor.forClass(SearchCriteria.class);
        when(batchInformationServiceAdapter.findByCriteria(batchCriteria.capture())).thenReturn(testResult);

        Collection<PipelineBatchInformationDTO> results = testObject.retrieveInfo(criteria);

        assertThat(results.size(), is(1));
        final List<AttributeFilter> simpleAttributeFilters = batchCriteria.getValue().getSimpleAttributeFilters();
        assertThat(simpleAttributeFilters.size(), is(3));
        boolean foundLineCode = false;
        boolean foundOrigin = false;
        boolean foundCrop = false;
        for (AttributeFilter filter : simpleAttributeFilters) {
            if (filter.getAttribute() == Attribute.COMMERCIAL_NAME) {
                assertThat(filter.getValue(), is("G"));
                assertThat(filter.getWildcard(), is(false));
                foundOrigin = true;
            } else if (filter.getAttribute() == Attribute.CROP_NAME) {
                assertThat(filter.getValue(), is("Corn"));
                assertThat(filter.getWildcard(), is(false));
                foundCrop = true;
            } else if (filter.getAttribute() == Attribute.MANUFACTURING_NAME) {
                assertThat(filter.getValue(), is("H"));
                assertThat(filter.getWildcard(), is(false));
                foundLineCode = true;
            }
        }
        assertThat(foundOrigin, is(true));
        assertThat(foundCrop, is(true));
        assertThat(foundLineCode, is(true));
    }

    @Test
    public void testServiceException() throws ServiceFailureException {
        CropEntity crop = new CropEntity();
        crop.setCropName("Corn");
        MaterialSearchCriteria criteria = new MaterialSearchCriteria(crop, SearchType.COMMERCIAL.name(), Lists.newArrayList("G"), SearchType.MANUFACTURING_NAME.name(), Lists.newArrayList("H"));
        final ServiceFailureException badness = new ServiceFailureException("badness");
        when(batchInformationServiceAdapter.findByCriteria((SearchCriteria) any())).thenThrow(badness);

        try {
            testObject.retrieveInfo(criteria);
            fail("Should throw exception");
        } catch (ServiceFailureException e) {
            assertThat(e, is(badness));
        }
    }
}
