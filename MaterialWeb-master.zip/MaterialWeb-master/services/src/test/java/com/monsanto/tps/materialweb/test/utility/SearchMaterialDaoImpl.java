package com.monsanto.tps.materialweb.test.utility;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.materialweb.business.model.SearchType;
import com.monsanto.tps.materialweb.dao.impl.AbstractJDBCDao;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/*NOTE this is the OLD GMI Query Class.  It was replaced by using the TQ Service, however I have moved it to the TEST package
    because of it's potential usefulness in writing AT tests...  */
public class SearchMaterialDaoImpl extends AbstractJDBCDao {
    private static final Log logger = LogFactory.getLog(SearchMaterialDaoImpl.class);
    private boolean writeSql = false;
    public static final String SEARCH_MATERIAL_QUERY = "com/monsanto/tps/materialweb/sql/SearchMaterialQuery.sql";
    private static final String NULL_VALUE = "NULL";
    public static final String ACRONYM_COL = "inner_query.SAP_MATERIAL_ACRONYM_NM";
    public static final String LINECODE_COL = "G.LINE_CODE";
    public static final String ORIGIN_COL = "G.ORIGIN";
    public static final String PRECOMMERCIAL_COL = "inner_query.pre_commercial_name";
    public static final String BATCH_COL = "inner_query.SAP_BATCH_NBR";
    public static final String MATERIAL_COL = "inner_query.SAP_MATERIAL_NBR";
    public static final String PRODUCT_ID_COL = "MPG.PRODUCT_ID";
    public static final String VARIETY_COL = "inner_query.VARIETY_NAME";
    public static final String MANUFACTURING_NAME = "inner_query.product_name";
    public static final String AND = " and ";

    public List<MaterialInformation> searchMaterial(MaterialSearchCriteria criteria) {
        StringBuffer sqlBuffer = new StringBuffer(readSql(SEARCH_MATERIAL_QUERY));
        SqlParameterSource parameterSource = new MapSqlParameterSource("cropId", criteria.getCropId());
        appendQueryCriteria(sqlBuffer, criteria);
        sqlBuffer.append(buildOrderClause());
        logSql(sqlBuffer);
        return getNamedParameterJdbcTemplate().query(sqlBuffer.toString(), parameterSource, new InventoryInformationRowMapper());
    }

    private void logSql(StringBuffer sqlBuffer) {
        logger.info("Search Materials query " + sqlBuffer.toString());
        if (writeSql) {
            System.out.println(sqlBuffer.toString());
        }
    }

    protected void appendQueryCriteria(StringBuffer sqlBuffer, MaterialSearchCriteria criteria) {
        int validParamters = 0;
        for (Map.Entry<SearchType, Collection<String>> entry : criteria.getCriteria().entrySet()) {
            //Only handle the first entry
            String value = entry.getValue().iterator().next();
            if (StringUtils.isEmpty(value) || NULL_VALUE.equalsIgnoreCase(value)) {
                //skip
            } else {
                //Make value sql safe
                value = value.replaceAll("['\"]", "");
                boolean isWildCard = false;
                if (value.endsWith("*")) {
                    value = value.substring(0, value.length() - 1);
                    isWildCard = true;
                }
                sqlBuffer.append(getEqualsCriteria(entry.getKey(), value, isWildCard));
                validParamters++;
            }
        }
        if (validParamters == 0) {
            throw new IllegalArgumentException("Must have at least one valid criteria");
        }
    }

    private String buildOrderClause() {
        return " Order By inner_query.pre_commercial_name, G.ORIGIN, G.LINE_CODE, inner_query.SAP_MATERIAL_NBR, MPG.IS_PREFERRED DESC, G.GERMPLASM_ID DESC";
    }

    private String getEqualsCriteria(SearchType searchType, String searchValue, boolean isWildCard) {
        StringBuffer clause = new StringBuffer();
        switch (searchType) {
            case ACRONYM: {
                if (searchValue.length() > 18) {
                    //Only use the first 18 characters
                    searchValue = searchValue.substring(0, 18);
                }
                clause.append(AND);
                clause.append("(");
                clause.append(buildColumnEqualsClause(ACRONYM_COL, searchValue, isWildCard));
                clause.append(" or ");    //Or Variety_Name
                clause.append(buildColumnEqualsClause(VARIETY_COL, searchValue, isWildCard));
                clause.append(")");
                break;
            }
            case LINECODE: {
                clause.append(AND);
                clause.append(buildColumnEqualsClause(LINECODE_COL, searchValue, isWildCard));
                break;
            }
            case ORIGIN: {
                clause.append(AND);
                clause.append(buildColumnEqualsClause(ORIGIN_COL, searchValue, isWildCard));
                break;
            }
            case PRECOMMERCIAL: {
                clause.append(AND);
                clause.append(buildColumnEqualsClause(PRECOMMERCIAL_COL, searchValue, isWildCard));
                break;
            }
            case BATCH: {
                clause.append(AND);
                clause.append(buildColumnEqualsClause(BATCH_COL, searchValue, isWildCard));
                break;
            }
            case MATERIAL: {
                clause.append(AND);
                clause.append(buildColumnEqualsClause(MATERIAL_COL, searchValue, isWildCard));
                break;
            }
            case COMMERCIAL: {
                break;
            }
            case PRODUCT_ID: {
                clause.append(AND);
                clause.append(buildProductIdClause(searchValue));
                break;
            }
            case MANUFACTURING_NAME: {
                clause.append(AND);
                clause.append(buildColumnEqualsClause(MANUFACTURING_NAME, searchValue, isWildCard));
                break;
            }
            default: {
                throw new IllegalArgumentException("Unknown search type " + searchType.toString());
            }
        }
        return clause.toString();
    }

    private String buildColumnEqualsClause(String columnName, String searchValue, boolean isWildCard) {
        if (isWildCard) {
            return columnName + " LIKE '" + searchValue + "%'";
        } else {
            return columnName + " = '" + searchValue + "'";
        }
    }

    private String buildColumnEqualsClauseCaseInsensitive(String columnName, String searchValue, boolean isWildCard) {
        if (isWildCard) {
            return columnName + " LIKE '" + searchValue + "%'";
        } else {
            return columnName + " = '" + searchValue + "'";
        }
    }

    private String buildProductIdClause(String tempSessionId) {
        StringBuffer sb = new StringBuffer(PRODUCT_ID_COL + " in (");
        sb.append("SELECT NUMBER_1 FROM MIDAS.TEMP_SESSION_OCD WHERE REQUEST_ID = ");
        sb.append(tempSessionId);
        sb.append(")");
        return sb.toString();
    }

    public void setWriteSql(boolean writeSql) {
        this.writeSql = writeSql;
    }
}
