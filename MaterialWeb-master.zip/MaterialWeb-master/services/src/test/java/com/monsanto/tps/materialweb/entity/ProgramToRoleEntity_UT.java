package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class ProgramToRoleEntity_UT {
    private ProgramToRoleEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new ProgramToRoleEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setId(-19l);
        ProgramEntity program = new ProgramEntity();
        program.setName("A");
        program.setId(-1l);
        testObject.setProgram(program);
        MidasRoleEntity role = new MidasRoleEntity();
        role.setRoleId(-2L);
        testObject.setRole(role);

        assertThat(testObject.getId(), equalTo(-19l));
        assertThat(testObject.getProgram(), equalTo(program));
        assertThat(testObject.getRole(), equalTo(role));
    }
}
