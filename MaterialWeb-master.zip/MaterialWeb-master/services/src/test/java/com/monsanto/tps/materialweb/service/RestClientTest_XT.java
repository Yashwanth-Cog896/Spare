package com.monsanto.tps.materialweb.service;

import com.monsanto.tps.materialweb.business.model.SearchType;
import com.monsanto.tps.materialweb.model.Crop;
import com.monsanto.tps.materialweb.model.SearchCriteriaModel;
import com.monsanto.tps.materialweb.model.SearchMaterialResults;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/rest-client-context.xml"
})
public class RestClientTest_XT {

    @Resource(name = "referenceDataServiceClient")
    private ReferenceDataService referenceDataService;

    @Resource(name = "materialServiceClient")
    private MaterialService materialService;

    @Test
    public void getUserCrops() {
        List<Crop> crops = referenceDataService.getUserCropNames();

        assertNotNull(crops);
    }

    //    @Ignore
    @Test
    public void getMaterials() {
        SearchCriteriaModel search = new SearchCriteriaModel("65601536", String.valueOf(SearchType.LINECODE), "01INL1EZRAB", null, null);
        SearchMaterialResults results = materialService.searchMaterial(search);

        assertNotNull(results);
    }
}
