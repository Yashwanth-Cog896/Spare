package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.exception.ServiceFailureException;
import com.monsanto.tps.materialweb.business.model.MaterialSearchCriteria;
import com.monsanto.tps.materialweb.business.model.SearchType;
import com.monsanto.tps.materialweb.business.search.*;
import com.monsanto.tps.materialweb.dao.MidasRefDataDao;
import com.monsanto.tps.materialweb.dao.ProductNameDao;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.entity.ProductEntity;
import com.monsanto.tps.materialweb.entity.ProductNameEntity;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import com.monsanto.tps.materialweb.model.SearchMaterialResults;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MaterialSearchProcessorImpl_UT {
    @InjectMocks
    private MaterialSearchProcessor testObject = new MaterialSearchProcessorImpl();
    @Mock
    private MidasRefDataDao midasRefDataDao;
    @Mock
    private ProductNameDao productNameDao;
    @Mock
    private TransgenicQualityEvaluator transgenicQualityEvaluator;
    @Mock
    private SAPInformationRetriever sapInformationRetriever;
    @Mock
    private ExtendedBatchDetailConverter extendedBatchDetailConverter;
    @Mock
    private GermplasmInfoProcessor germplasmInfoProcessor;
    private Collection<PipelineBatchInformationDTO> pipelineInfo;
    private final static long CROPID = -1l;
    private CropEntity cropEntity;

    @Before
    public void setup() throws ServiceFailureException {
        MockitoAnnotations.initMocks(this);
        pipelineInfo = Lists.newArrayList();
        when(sapInformationRetriever.retrieveInfo((MaterialSearchCriteria) any())).thenReturn(pipelineInfo);
        cropEntity = new CropEntity();
        cropEntity.setCropId(CROPID);
    }

    @Test
    public void testProcessMaterialSearchNew() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setBatchNumber("0001");
        MaterialInformation item2 = new MaterialInformation();
        item2.setBatchNumber("0002");
        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
        when(extendedBatchDetailConverter.covertExtendedBatchDetails(pipelineInfo, CROPID)).thenReturn(materialList);
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.PRECOMMERCIAL.toString(), Lists.newArrayList("axy"), SearchType.LINECODE.toString(), Lists.newArrayList("bzd"));

        assertThat(results.getSearchResultCount(), equalTo(2));
        assertThat(results.getQueryString(), containsString(SearchType.PRECOMMERCIAL.description()));
        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
        assertThat(results.getQueryString(), containsString("axy"));
        assertThat(results.getQueryString(), containsString("bzd"));
        assertThat((List<MaterialInformation>) results.getMaterialInformation(), equalTo(materialList));
        verify(sapInformationRetriever).retrieveInfo((MaterialSearchCriteria) any());
        verify(extendedBatchDetailConverter).covertExtendedBatchDetails(pipelineInfo, CROPID);
        verify(transgenicQualityEvaluator).updateTransgenticColumns(materialList);
        verify(germplasmInfoProcessor).addGermplasmInfoToResults(materialList);
    }

//    @Test
//    public void testProcessMaterialSearch() throws Exception {
//        MaterialInformation item1 = new MaterialInformation();
//        item1.setBatchNumber("0001");
//        MaterialInformation item2 = new MaterialInformation();
//        item2.setBatchNumber("0002");
//        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
//        when(searchMaterialDao.searchMaterial((MaterialSearchCriteria) any())).thenReturn(materialList);
//        CropEntity cropEntity = new CropEntity();
//        when(midasRefDataDao.getCropByCropId(-1l)).thenReturn(cropEntity);
//
//        SearchMaterialResults results = testObject.processMaterialSearch(-1l, SearchType.PRECOMMERCIAL.toString(), "axy", SearchType.LINECODE.toString(), "bzd");
//
//        assertThat(results.getSearchResultCount(), equalTo(2));
//        assertThat(results.getQueryString(), containsString(SearchType.PRECOMMERCIAL.description()));
//        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
//        assertThat(results.getQueryString(), containsString("axy"));
//        assertThat(results.getQueryString(), containsString("bzd"));
//        assertThat((List<MaterialInformation>) results.getMaterialInformation(), equalTo(materialList));
//        verify(informationColumnAppender).appendDataToResults(materialList);
//        verify(transgenicQualityEvaluator).updateTransgenticColumns(materialList);
//    }

    @Test
    public void testProcessMaterialSearch_Commercial() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setBatchNumber("0001");
        MaterialInformation item2 = new MaterialInformation();
        item2.setBatchNumber("0002");
        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
        when(extendedBatchDetailConverter.covertExtendedBatchDetails(pipelineInfo, CROPID)).thenReturn(materialList);
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);
        ProductNameEntity productName1 = new ProductNameEntity();
        productName1.setProductName("axy");
        ProductEntity product1 = new ProductEntity();
        product1.setProductId(45l);
        productName1.setProduct(product1);
        List<ProductNameEntity> products = Lists.newArrayList(productName1);
        when(productNameDao.lookupCommercialProductName("abc")).thenReturn(products);

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.COMMERCIAL.toString(), Lists.newArrayList("axy"), SearchType.LINECODE.toString(), Lists.newArrayList("bzd"));

        assertThat(results.getSearchResultCount(), equalTo(2));
        assertThat(results.getQueryString(), containsString(SearchType.COMMERCIAL.description()));
        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
        assertThat(results.getQueryString(), containsString("axy"));
        assertThat(results.getQueryString(), containsString("bzd"));
        assertThat((List<MaterialInformation>) results.getMaterialInformation(), equalTo(materialList));
        verify(sapInformationRetriever).retrieveInfo((MaterialSearchCriteria) any());
        verify(extendedBatchDetailConverter).covertExtendedBatchDetails(pipelineInfo, CROPID);
        verify(transgenicQualityEvaluator).updateTransgenticColumns(materialList);
        verify(germplasmInfoProcessor).addGermplasmInfoToResults(materialList);
    }

    @Test
    public void testProcessMaterialSearch_CommercialWildCard() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setBatchNumber("0001");
        MaterialInformation item2 = new MaterialInformation();
        item2.setBatchNumber("0002");
        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
        when(extendedBatchDetailConverter.covertExtendedBatchDetails(pipelineInfo, CROPID)).thenReturn(materialList);
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);
        ProductNameEntity productName1 = new ProductNameEntity();
        productName1.setProductName("axy");
        ProductEntity product1 = new ProductEntity();
        product1.setProductId(45l);
        productName1.setProduct(product1);
        List<ProductNameEntity> products = Lists.newArrayList(productName1);
        when(productNameDao.lookupCommercialProductNameLike("axy*")).thenReturn(products);

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.COMMERCIAL.toString(), Lists.newArrayList("axy*"), SearchType.LINECODE.toString(), Lists.newArrayList("bzd"));

        assertThat(results.getSearchResultCount(), equalTo(2));
        assertThat(results.getQueryString(), containsString(SearchType.COMMERCIAL.description()));
        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
        assertThat(results.getQueryString(), containsString("axy"));
        assertThat(results.getQueryString(), containsString("bzd"));
        assertThat((List<MaterialInformation>) results.getMaterialInformation(), equalTo(materialList));
        verify(sapInformationRetriever).retrieveInfo((MaterialSearchCriteria) any());
        verify(extendedBatchDetailConverter).covertExtendedBatchDetails(pipelineInfo, CROPID);
        verify(transgenicQualityEvaluator).updateTransgenticColumns(materialList);
        verify(germplasmInfoProcessor).addGermplasmInfoToResults(materialList);
    }

    @Test
    public void testInvalidSearch() throws ServiceFailureException {
        CropEntity cropEntity = new CropEntity();
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);
        when(sapInformationRetriever.retrieveInfo((MaterialSearchCriteria) any())).thenThrow(new ServiceFailureException("service problem"));

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.PRECOMMERCIAL.toString(), Lists.newArrayList(""), SearchType.LINECODE.toString(), Lists.newArrayList(""));

        assertThat(results.getSearchResultCount(), equalTo(0));
        assertThat(results.getWarning(), containsString("service problem"));
        assertThat(results.getMaterialInformation().size(), equalTo(0));
    }

    @Test
    public void testLimitSearch() {
        when(extendedBatchDetailConverter.covertExtendedBatchDetails(pipelineInfo, CROPID)).thenReturn(getInventoryList(6080));
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.PRECOMMERCIAL.toString(), Lists.newArrayList("axy"), SearchType.LINECODE.toString(), Lists.newArrayList("bzd"));

        assertThat(results.getSearchResultCount(), equalTo(1000));
        assertThat(results.getQueryString(), containsString(SearchType.PRECOMMERCIAL.description()));
        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
        assertThat(results.getQueryString(), containsString("axy"));
        assertThat(results.getQueryString(), containsString("bzd"));
        assertThat(results.getMaterialInformation().size(), equalTo(1000));
        assertThat(results.getWarning(), containsString("6082"));
        assertThat(results.getWarning(), containsString("Please refine criteria to limit the search results"));
    }

    @Test
    public void testFilterWithCoded() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setBatchNumber("0001");
        item1.setLineType("Coded");
        MaterialInformation item2 = new MaterialInformation();
        item2.setBatchNumber("0002");
        item2.setLineType("Coded");
        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
        when(extendedBatchDetailConverter.covertExtendedBatchDetails(pipelineInfo, CROPID)).thenReturn(materialList);
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.PRECOMMERCIAL.toString(), Lists.newArrayList("axy"), SearchType.LINECODE.toString(), Lists.newArrayList("bzd"));

        assertThat(results.getSearchResultCount(), equalTo(2));
        assertThat(results.getQueryString(), containsString(SearchType.PRECOMMERCIAL.description()));
        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
        assertThat(results.getQueryString(), containsString("axy"));
        assertThat(results.getQueryString(), containsString("bzd"));
        assertThat(results.getMaterialInformation().contains(item1), is(true));
        assertThat(results.getMaterialInformation().contains(item2), is(true));
    }

    @Test
    public void testFilterWithFinishedAndCoded() throws Exception {
        MaterialInformation item1 = new MaterialInformation();
        item1.setBatchNumber("0001");
        item1.setLineType("Finished");
        MaterialInformation item2 = new MaterialInformation();
        item2.setBatchNumber("0002");
        item2.setLineType("Coded");
        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
        when(extendedBatchDetailConverter.covertExtendedBatchDetails(pipelineInfo, CROPID)).thenReturn(materialList);
        when(midasRefDataDao.getCropByCropId(CROPID)).thenReturn(cropEntity);

        SearchMaterialResults results = testObject.processMaterialSearch(CROPID, SearchType.PRECOMMERCIAL.toString(), Lists.newArrayList("axy"), SearchType.LINECODE.toString(), Lists.newArrayList("bzd"));

        assertThat(results.getSearchResultCount(), equalTo(1));
        assertThat(results.getQueryString(), containsString(SearchType.PRECOMMERCIAL.description()));
        assertThat(results.getQueryString(), containsString(SearchType.LINECODE.description()));
        assertThat(results.getQueryString(), containsString("axy"));
        assertThat(results.getQueryString(), containsString("bzd"));
        assertThat(results.getMaterialInformation().contains(item1), is(true));
        assertThat(results.getMaterialInformation().contains(item2), is(false));
    }

    private List<MaterialInformation> getInventoryList(int limit) {
        MaterialInformation item1 = new MaterialInformation();
        item1.setBatchNumber("0001");
        MaterialInformation item2 = new MaterialInformation();
        item2.setBatchNumber("0002");
        List<MaterialInformation> materialList = Lists.newArrayList(item1, item2);
        for (int i = 0; i < limit; i++) {
            item2 = new MaterialInformation();
            item2.setBatchNumber(String.valueOf(i));
            materialList.add(item2);
        }
        return materialList;
    }
}
