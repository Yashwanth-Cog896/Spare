package com.monsanto.tps.materialweb.service.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.inventory.CropOptionsProcessor;
import com.monsanto.tps.materialweb.dao.MidasRefDataDao;
import com.monsanto.tps.materialweb.entity.CropEntity;
import com.monsanto.tps.materialweb.model.Crop;
import com.monsanto.tps.materialweb.model.CropOptions;
import com.monsanto.tps.security.userdetails.EnhancedUserDetails;
import com.monsanto.tps.security.userdetails.UserDetailsProvider;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ReferenceDataServiceImpl_UT {
    @InjectMocks
    private ReferenceDataServiceImpl testObject = new ReferenceDataServiceImpl();
    @Mock
    private MidasRefDataDao midasRefDataDao;
    @Mock
    private UserDetailsProvider<EnhancedUserDetails> userDetailsProvider;
    @Mock
    private CropOptionsProcessor cropOptionsProcessor;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetCropNames() throws Exception {
        EnhancedUserDetails mockUser = mock(EnhancedUserDetails.class);
        when(mockUser.getUsername()).thenReturn("xyz");
        when(userDetailsProvider.getUserDetails()).thenReturn(mockUser);
        CropEntity crop1 = new CropEntity();
        crop1.setCropName("A");
        CropEntity crop2 = new CropEntity();
        crop2.setCropName("B");
        CropEntity[] entities = new CropEntity[]{crop1, crop2};
        when(midasRefDataDao.getInventoryImportUserCrops("xyz")).thenReturn(entities);

        List<Crop> results = testObject.getUserCropNames();

        assertThat(results.size(), equalTo(2));
        assertThat(results.get(0).getName(), is("A"));
        assertThat(results.get(1).getName(), is("B"));
    }

    @Test
    public void testGetCropNamesSort() throws Exception {
        EnhancedUserDetails mockUser = mock(EnhancedUserDetails.class);
        when(mockUser.getUsername()).thenReturn("xyz");
        when(userDetailsProvider.getUserDetails()).thenReturn(mockUser);
        CropEntity crop1 = new CropEntity();
        crop1.setCropName("Z");
        CropEntity crop2 = new CropEntity();
        crop2.setCropName("B");
        CropEntity[] entities = new CropEntity[]{crop1, crop2};
        when(midasRefDataDao.getInventoryImportUserCrops("xyz")).thenReturn(entities);

        List<Crop> results = testObject.getUserCropNames();

        assertThat(results.size(), equalTo(2));
        assertThat(results.get(0).getName(), is("B"));
        assertThat(results.get(1).getName(), is("Z"));
    }

//    @Test
//    public void testSetUserDetailsProvider() throws Exception {
//        testObject.setUserDetailsProvider(userDetailsProvider);
//
//        assertThat(testObject.getUserDetailsProvider(), equalTo(userDetailsProvider));
//    }

    @Test
    public void testGetCropReference() {
        CropOptions dummyOptions = new CropOptions();
        dummyOptions.setAvailablePrograms(Lists.newArrayList("2a", "3b"));
        when(cropOptionsProcessor.getDetailsForCrop(-5l)).thenReturn(dummyOptions);

        CropOptions results = testObject.getCropReferenceData(-5l);

        assertThat(results, equalTo(dummyOptions));
    }
}
