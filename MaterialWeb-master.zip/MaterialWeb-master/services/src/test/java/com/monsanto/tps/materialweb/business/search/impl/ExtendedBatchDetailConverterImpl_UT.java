package com.monsanto.tps.materialweb.business.search.impl;

import com.google.common.collect.Lists;
import com.monsanto.tps.materialweb.business.search.ExtendedBatchDetailConverter;
import com.monsanto.tps.materialweb.model.MaterialInformation;
import com.monsanto.tps.regulatory.traitquality.sap.batch.ManufacturingDetails;
import com.monsanto.tps.regulatory.traitquality.sap.batch.PipelineBatchInformationDTO;
import com.monsanto.tps.regulatory.traitquality.sap.batch.ProductDetails;
import com.monsanto.tps.regulatory.traitquality.sap.batch.TechnologyDetails;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ExtendedBatchDetailConverterImpl_UT {

    private ExtendedBatchDetailConverter testObject = new ExtendedBatchDetailConverterImpl();

    @Test
    public void testCovertExtendedBatchDetails() throws Exception {
        PipelineBatchInformationDTO detail1 = new PipelineBatchInformationDTO();
        detail1.setBatchNumber("AB1");
        detail1.setMaterialNumber("MAT2");
        ManufacturingDetails sapDetails = new ManufacturingDetails();
        sapDetails.setAcronym("C3");
        sapDetails.setBrandName("D");
        sapDetails.setCreationDate(new Date());
        sapDetails.setMaterialDescription("E");
        sapDetails.setTraitVersion("F");
        sapDetails.setManufacturingName("AB");
        detail1.setManufacturingDetails(sapDetails);
        TechnologyDetails gpDetails = new TechnologyDetails();
        gpDetails.setCytoplasmDonor("G");
        gpDetails.setLineCode("H");
        gpDetails.setLineFunction("I");
        gpDetails.setOrigin("J");
        gpDetails.setLineType("K");
        gpDetails.setOwner("L");
        gpDetails.setPreferredGermplasm("M");
        gpDetails.setPreferredName("N");
        gpDetails.setGermplasmId(-9l);
        gpDetails.setRestriction("R");
        gpDetails.setLexiconTraitVersion("S");
        List<String> events = Lists.newArrayList("mn", "op", "rs");
        gpDetails.setEventNames(events);
        detail1.setTechnologyDetails(gpDetails);
        ProductDetails productDetails = new ProductDetails();
        productDetails.setBrandName("O");
        productDetails.setPrecommercialName("P");
        productDetails.setProductName("Q");
        detail1.setProductDetails(productDetails);
        List<PipelineBatchInformationDTO> details = Lists.newArrayList(detail1);

        Collection<MaterialInformation> materialInformationList = testObject.covertExtendedBatchDetails(details, -1l);

        assertThat(materialInformationList.size(), is(1));
        MaterialInformation line1 = materialInformationList.iterator().next();
        assertThat(line1.getBatchNumber(), is(detail1.getBatchNumber()));
        assertThat(line1.getMaterialNumber(), is(detail1.getMaterialNumber()));
        assertThat(line1.getAcronym(), is(sapDetails.getAcronym()));
        assertThat(line1.getSapBrandName(), is(sapDetails.getBrandName()));
        assertThat(line1.getSapTraitVersion(), is(sapDetails.getTraitVersion()));
        assertThat(line1.getSapCreatedDate(), is(sapDetails.getCreationDate()));
        assertThat(line1.getSapMaterialDescription(), is(sapDetails.getMaterialDescription()));
        assertThat(line1.getPedigree(), is(gpDetails.getCytoplasmDonor()));
        assertThat(line1.getLineCode(), is(gpDetails.getLineCode()));
        assertThat(line1.getLineFunction(), is(gpDetails.getLineFunction()));
        assertThat(line1.getLineType(), is(gpDetails.getLineType()));
        assertThat(line1.getGermplasmOwner(), is(gpDetails.getOwner()));
        assertThat(line1.getOrigin(), is(gpDetails.getOrigin()));
        assertThat(line1.getPreferredGermplasm(), is(gpDetails.getPreferredGermplasm()));
        assertThat(line1.getPreferredName(), is("NO"));
        assertThat(line1.getEvent(), is("mn,op,rs"));
        assertThat(line1.getMidasCommercialBrandName(), is(productDetails.getBrandName()));
        assertThat(line1.getMidasCommercialName(), is(productDetails.getProductName()));
        assertThat(line1.getLexiconPreCommercialName(), is(productDetails.getPrecommercialName()));
        assertThat(line1.getId(), is(-9l));
        assertThat(line1.getRestriction(), is("R"));
        assertThat(line1.getTraitVersion(), is("S"));
        assertThat(line1.getManufacturingName(), is(sapDetails.getManufacturingName()));
        assertThat(line1.getCropId(), is(-1l));
    }

    @Test
    public void testConvertExtendedBatchDetails_null() {

        Collection<MaterialInformation> result = testObject.covertExtendedBatchDetails(null, null);

        assertThat(CollectionUtils.isEmpty(result), is(true));
    }

    @Test
    public void testCovertExtendedBatchDetails_NullProperties() throws Exception {
        PipelineBatchInformationDTO detail1 = new PipelineBatchInformationDTO();
        detail1.setBatchNumber("ABC2");
        detail1.setMaterialNumber("MAT3");

        List<PipelineBatchInformationDTO> details = Lists.newArrayList(detail1);

        Collection<MaterialInformation> materialInformationList = testObject.covertExtendedBatchDetails(details, -2l);

        assertThat(materialInformationList.size(), is(1));
        MaterialInformation line1 = materialInformationList.iterator().next();
        assertThat(line1.getBatchNumber(), is(detail1.getBatchNumber()));
        assertThat(line1.getMaterialNumber(), is(detail1.getMaterialNumber()));
        assertThat(line1.getCropId(), is(-2l));
    }
}
