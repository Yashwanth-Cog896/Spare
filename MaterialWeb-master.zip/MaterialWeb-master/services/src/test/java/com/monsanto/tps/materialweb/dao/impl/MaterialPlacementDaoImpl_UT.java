package com.monsanto.tps.materialweb.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.pipeline.breeding.test.TestTools;
import com.monsanto.tcc.pipeline.database.PersistentStoreTransactionalDBConnection;
import com.monsanto.tps.materialweb.dao.MaterialPlacementDao;
import com.monsanto.tps.materialweb.model.MaterialPlacementInformation;
import org.hibernate.SessionFactory;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.util.List;

import static junit.framework.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:/com/monsanto/tps/materialweb/contexts/database-context.xml",
        "classpath:/com/monsanto/tps/materialweb/test-database-context.xml",
        "classpath:/com/monsanto/tps/materialweb/contexts/hibernate-context.xml"
})
@Transactional
@TransactionConfiguration(transactionManager = "hibernateTransactionManager", defaultRollback = true)
public class MaterialPlacementDaoImpl_UT {
    @Resource(name = "dataSource")
    private DataSource dataSource;
    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;
    @Resource(name = "materialPlacementDao")
    private MaterialPlacementDao materialPlacementDao;
    @Ignore
    @Test
    public void testGetPlacementInfo() throws Exception {
        insertTestData();
        List<MaterialPlacementInformation> materialPlacementInformationList = materialPlacementDao.getPlacementInfo(Lists.newArrayList("I1", "I2", "I3"));
        assertEquals(3, materialPlacementInformationList.size());
    }

    private void insertTestData() throws Exception {
        PersistentStoreConnection connection = new PersistentStoreTransactionalDBConnection(sessionFactory.getCurrentSession().connection());
        TestTools.insertFakeSeason(connection, -150, "1500:01", true);

        TestTools.insertFakeBrProg(connection, -2512, "OR1", "OR", 65601536);
        TestTools.insertFakeBrProg(connection, -2521, "GR1", "GR", 65601536);
        TestTools.insertFakeBrPlan(connection, -567, -2512, -150, 2);
        TestTools.insertFakeInventoryType(connection, -158, 65601536L, "TST", true, true);

        TestTools.insertFakeGeneticMaterial(connection, -200, "CN2003102", "|", 328071, "");
        TestTools.insertFakeGeneticMaterial(connection, -201, "CN2003102", "@", 328071, "");
        TestTools.insertFakeGeneticMaterial(connection, -202, "CN2003102", "@.@.", 328071, "");

        TestTools.insertFakeInventory(connection, -160, -2512, -200, true, -158, true, true, false, "I1");
        TestTools.insertFakeInventory(connection, -161, -2512, -201, true, -158, true, true, false, "I2");
        TestTools.insertFakeInventory(connection, -162, -2512, -202, true, -158, true, true, false, "I3");

        TestTools.insertFakeLocation(connection, -178, "Location 1", -2512, "LOC", TestTools.getMidasUSACountryID(connection),
                TestTools.getMidasMissouriSubCountryID(connection), TestTools.getMidasGasconadeMissouriSubSubCountryID(connection),
                false);
        TestTools.insertFakeField(connection, -179, "F1", -150, -178, 2);

        TestTools.insertFakeTestSet(connection, -1, -567, 2, "Set5");
        TestTools.insertFakeTestSetEntry(connection, -333, 3, 1, -1);
        TestTools.insertFakeBrRep(connection, -180, -179, -2521, -2512, -2521, 2, -1, false);

        TestTools.insertFakePlot(connection, -221, 2, 1, -160, "P1", -180, -333, -179);
        insertBufferPlot(connection, -222, 2, 2, -161, "P2", -179);
        insertAssociatedBufferPlot(connection, -223, 2, 3, -161, "P2", -179, -180);

    }

    public static void insertBufferPlot(PersistentStoreConnection conn, long plotId, int objType, int relativeLocSeqNum,
                                        long inventoryID, String barcodeID, long fieldId) throws WrappingException {
        String sql = "INSERT INTO MIDAS.PLOT (PLOT_ID, OBJ_TYPE, RELATIVE_LOC_SEQ_NUMBER, INVENTORY_ID, BARCODE, BR_FIELD_ID) " +
                "VALUES (" + plotId + ", " + objType + ", " + relativeLocSeqNum + ", " + inventoryID +
                ", '" + barcodeID + "', " + fieldId + ")";
        conn.executeInsert(sql);
    }

    public static void insertAssociatedBufferPlot(PersistentStoreConnection conn, long plotId, int objType, int relativeLocSeqNum,
                                                  long inventoryID, String barcodeID, long fieldId, long repId) throws WrappingException {
        String sql = "INSERT INTO MIDAS.PLOT (PLOT_ID, OBJ_TYPE, RELATIVE_LOC_SEQ_NUMBER, INVENTORY_ID, BARCODE, BR_FIELD_ID, REP_ID) " +
                "VALUES (" + plotId + ", " + objType + ", " + relativeLocSeqNum + ", " + inventoryID +
                ", '" + barcodeID + "', " + fieldId + ", " + repId + ")";
        conn.executeInsert(sql);
    }
}
