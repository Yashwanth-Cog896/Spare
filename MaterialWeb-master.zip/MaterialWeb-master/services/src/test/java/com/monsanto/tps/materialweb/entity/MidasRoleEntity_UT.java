package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class MidasRoleEntity_UT {
    private MidasRoleEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new MidasRoleEntity();
    }

    @Test
    public void testGetRoleId() throws Exception {
        testObject.setName("A");
        testObject.setRefActive("B");
        testObject.setRoleId(-3l);
        testObject.setRoleRefId("C");
        testObject.setRoleTypeId("D");

        assertThat(testObject.getName(), equalTo(testObject.getName()));
        assertThat(testObject.getRefActive(), equalTo(testObject.getRefActive()));
        assertThat(testObject.getRoleId(), equalTo(testObject.getRoleId()));
        assertThat(testObject.getRoleRefId(), equalTo(testObject.getRoleRefId()));
        assertThat(testObject.getRoleTypeId(), equalTo(testObject.getRoleTypeId()));
    }
}
