package com.monsanto.tps.materialweb.service.adapter;

import com.google.common.collect.Lists;
import com.monsanto.tps.regulatory.traitquality.isolation.CropTO;
import com.monsanto.tps.regulatory.traitquality.isolation.policy.TraitQualityPolicyService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertThat;

public class TraitQualityPolicyServiceAdapter_UT {
    @InjectMocks
    private TraitQualityPolicyServiceAdapter testObject = new TraitQualityPolicyServiceAdapter();
    @Mock
    private TraitQualityPolicyService traitQualityPolicyService;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetTraitQualityPolicyCrops() throws Exception {
        List<CropTO> cropNames = Lists.newArrayList();
        Mockito.when(traitQualityPolicyService.getPolicyCrops()).thenReturn(cropNames);

        Collection<CropTO> results = testObject.getTraitQualityPolicyCrops();

        assertThat(cropNames, org.hamcrest.Matchers.equalTo(results));
        Mockito.verify(traitQualityPolicyService).getPolicyCrops();
    }
}
