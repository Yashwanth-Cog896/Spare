package com.monsanto.tps.materialweb.business.inventory.impl;

import com.google.common.collect.Lists;
import com.monsanto.tcc.lineadvancement.service.InventoryCreationService;
import com.monsanto.tps.materialweb.business.inventory.CropOptionsProcessor;
import com.monsanto.tps.materialweb.business.util.TQRequiredCropsUtil;
import com.monsanto.tps.materialweb.dao.ProgramDao;
import com.monsanto.tps.materialweb.dao.UnitOfMeasureDao;
import com.monsanto.tps.materialweb.dao.VegetativeStructureDao;
import com.monsanto.tps.materialweb.entity.ProgramEntity;
import com.monsanto.tps.materialweb.entity.UnitOfMeasureEntity;
import com.monsanto.tps.materialweb.entity.VegetativeStructureEntity;
import com.monsanto.tps.materialweb.model.CropOptions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collection;

import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class CropOptionsProcessorImpl_UT {
    @InjectMocks
    private CropOptionsProcessor testObject;
    @Mock
    private InventoryCreationService remoteInventoryCreationService;
    @Mock
    private ProgramDao programDao;
    @Mock
    private VegetativeStructureDao vegetativeStructureDao;
    @Mock
    private UnitOfMeasureDao unitOfMeasureDao;
    @Mock
    private TQRequiredCropsUtil tqRequiredCropsUtil;

    @Before
    public void setUp() throws Exception {
        testObject = new CropOptionsProcessorImpl();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetDetailsForCrop() throws Exception {
        Long id = -6l;
        Collection<ProgramEntity> programs = Lists.newArrayList();
        ProgramEntity program1 = new ProgramEntity();
        program1.setReferenceCode("5K");
        programs.add(program1);
        ProgramEntity program2 = new ProgramEntity();
        program2.setReferenceCode("1a");
        programs.add(program2);
        when(programDao.getActiveGermplasmManagersProgramsForCrop(id)).thenReturn(programs);
        Collection<UnitOfMeasureEntity> uoms = Lists.newArrayList();
        UnitOfMeasureEntity uom1 = new UnitOfMeasureEntity();
        uom1.setName("seed");
        uoms.add(uom1);
        when(unitOfMeasureDao.getInventoryUnitOfMeasures()).thenReturn(uoms);
        Collection<VegetativeStructureEntity> structures = Lists.newArrayList();
        VegetativeStructureEntity structure1 = new VegetativeStructureEntity();
        structure1.setReferenceCode("seed");
        structures.add(structure1);
        when(vegetativeStructureDao.getVegetativeStructures(id)).thenReturn(structures);
        when(tqRequiredCropsUtil.isCropTQRequiredByCropId(id)).thenReturn(true);

        CropOptions results = testObject.getDetailsForCrop(id);

        assertThat(results.getAvailablePrograms(), hasItem("1a"));
        assertThat(results.getAvailablePrograms(), hasItem("5K"));
        assertThat(results.getVegetativeStructures(), hasItem("seed"));
        assertThat(results.getSeedQuantityUoms(), hasItem("seed"));
        assertThat(results.getTQRequiredCrop(), is(true));
    }
}
