package com.monsanto.tps.materialweb.entity;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class ProgramEntity_UT {
    private ProgramEntity testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new ProgramEntity();
    }

    @Test
    public void testGettersAndSetters() throws Exception {
        testObject.setId(-19l);
        testObject.setName("pgm stuff");
        testObject.setReferenceCode("r3");
        CropEntity crop = new CropEntity();
        crop.setCropId(-4l);
        testObject.setCrop(crop);

        assertThat(testObject.getId(), equalTo(-19l));
        assertThat(testObject.getName(), equalTo("pgm stuff"));
        assertThat(testObject.getReferenceCode(), equalTo("r3"));
        assertThat(testObject.getCrop(), equalTo(crop));
    }
}
