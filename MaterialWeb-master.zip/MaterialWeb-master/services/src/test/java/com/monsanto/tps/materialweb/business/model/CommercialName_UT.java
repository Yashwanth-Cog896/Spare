package com.monsanto.tps.materialweb.business.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

public class CommercialName_UT {
    private CommercialName testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new CommercialName();
    }

    @Test
    public void testGetCommercialName() throws Exception {
        testObject.setBrandName("XYX");
        testObject.setCommercialName("NEW");

        assertThat(testObject.getCommercialName(), equalTo("NEW"));
        assertThat(testObject.getBrandName(), equalTo("XYX"));
    }

    @Test
    public void testSetAppending() {
        testObject = new CommercialName("A", "B");
        testObject.setBrandName("XYX");
        testObject.setCommercialName("NEW");

        assertThat(testObject.getCommercialName(), equalTo("A, NEW"));
        assertThat(testObject.getBrandName(), equalTo("B, XYX"));
    }

    @Test
    public void testSetAppending_withDuplicates() {
        testObject = new CommercialName("A", "B");
        testObject.setBrandName("XYX");
        testObject.setBrandName("XYX");
        testObject.setCommercialName("NEW");
        testObject.setCommercialName("NEW");

        assertThat(testObject.getCommercialName(), equalTo("A, NEW"));
        assertThat(testObject.getBrandName(), equalTo("B, XYX"));
    }

    @Test
    public void testConstructor() {
        testObject = new CommercialName("A", "B");

        assertThat(testObject.getCommercialName(), equalTo("A"));
        assertThat(testObject.getBrandName(), equalTo("B"));
    }

    @Test
    public void testConstructor_withDuplicates() {
        testObject = new CommercialName("A", "B");
        testObject.setCommercialName("A");
        testObject.setBrandName("B");

        assertThat(testObject.getCommercialName(), equalTo("A"));
        assertThat(testObject.getBrandName(), equalTo("B"));
    }
}
