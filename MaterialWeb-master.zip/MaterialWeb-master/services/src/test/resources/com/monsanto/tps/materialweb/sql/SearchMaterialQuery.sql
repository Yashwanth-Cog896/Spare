select DISTINCT G.ORIGIN as Origin
    , G.LINE_CODE as Line_Code
    , LT.NAME as Line_Type
    , LF.NAME as Line_Function
    , G.CYTOPLASM_DONOR as Cytoplasm_Donor
    , BP.BR_PROG_REF_ID as Owner_Program
    , '' as Cytoplasm_Source
    , inner_query.product_name as Manufacturing_Name
    , inner_query.SAP_BATCH_NBR as Batch_Number
    , inner_query.SAP_MATERIAL_NBR as Material_Number
    , inner_query.SAP_MATERIAL_ACRONYM_NM as Material_Acronym
    , inner_query.SAP_MATERIAL_DESC as Material_Desc
    , inner_query.SAP_TRAIT_VERSION as SAP_Trait_Version
    , CROP.NAME as Crop_Name
    , CROP.CROP_ID as cropId
    , MPG.PRODUCT_ID as productId
    , G.GERMPLASM_ID as germplasmId
    , inner_query.VARIETY_NAME as Variety_Name
    , G.RESTRICTION as restriction
    , inner_query.SAP_MATERIAL_BRAND_NM as SAP_Brand_Name
    , inner_query.SAP_MATERIAL_DESC as SAP_Material_Desc
    , inner_query.PRODUCT_NAME as Product_Name
    , inner_query.preferred_name as Preferred_Name
    , inner_query.trait_version as Trait_Version
    , MPG.IS_PREFERRED as Preferred_Germplasm
    , inner_query.SAP_CREATED_DATE as SAP_Created_Date
    , inner_query.pre_commercial_name as LEX_PRE_COMMERCIAL_NAME
    , COMMERCIAL_NAME.NAME as MIDAS_Commercial_Name
    , COMMERCIAL_NAME.BRAND_NAME as MIDAS_Commercial_Brand_Name
from MIDAS.GERMPLASM g
left outer join MIDAS.PRODUCT_GERMPLASM mpg on MPG.GERMPLASM_ID = G.GERMPLASM_ID
left outer join (
  select MSB.SAP_MATERIAL_NBR, MSB.SAP_BATCH_NBR, MSB.SAP_MATERIAL_ACRONYM_NM, mp.product_id,
  lp.product_name, MSB.SAP_MATERIAL_DESC,
  MSB.TRAIT_VERSION SAP_TRAIT_VERSION, MSB.VARIETY_NAME, MSB.crop_sub_class_id, MSB.SAP_MATERIAL_BRAND_NM, MSB.SAP_MATERIAL_TRAIT_DESC
  , lp.preferred_name, lp.trait_version, MSB.SAP_CREATED_DATE, lp.pre_commercial_name
  from COMPLI_PROC.MANUFACTURE_SEED_BATCH MSB
    , ( select PCP.PRODUCT_PUBKEY , replace(PS.COMMERCIAL_NAME, ' ', '') product_name
          , ps.preferred_name_flag preferred_name, '' trait_version, PCP.PRE_COML_NAME pre_commercial_name
          from lexicon.product_stage ps
             , lexicon.pre_coml_product pcp
          where PS.LOGICAL_DELETE = 'n'
            and PCP.LOGICAL_DELETE = 'n'
            and ps.product_id = pcp.product_id
          union
          select PCP.PRODUCT_PUBKEY , PCP.PRE_COML_NAME, '', '', PCP.PRE_COML_NAME
          from lexicon.pre_coml_product pcp
          where PCP.LOGICAL_DELETE = 'n'
          union
            select PCP.PRODUCT_PUBKEY , R.MANUFACTURING_NAME, '', x.trait_version, PCP.PRE_COML_NAME
            from lexicon.product_relationship_xref x
               , lexicon.pre_coml_product pcp
               , lexicon.product_relationship r
            where X.PRODUCT_ID = pcp.product_id
              and R.LOGICAL_DELETE = 'n'
              and X.PRODUCT_RELATIONSHIP_ID = R.PRODUCT_RELATIONSHIP_ID
              and pcp.logical_delete = 'n'
        ) lp
    , FBS_COMMON.PRODUCT_XREF X
    , MIDAS.PRODUCT mp
  where MSB.SAP_MATERIAL_ACRONYM_NM(+) = lp.product_name
  and x.LEXICON_PRODUCT_PUBKEY = lp.product_pubkey
  and x.MIDAS_PRODUCT_ID = mp.product_id
) inner_query on inner_query.product_id = mpg.product_id and (inner_query.crop_sub_class_id = G.CROP_ID OR inner_query.crop_sub_class_id IS NULL)
inner join MIDAS.LINE_TYPE lt on G.LINE_TYPE_ID = LT.LINE_TYPE_ID
left outer join MIDAS.LINE_FUNCTION lf on G.LINE_FUNCTION_ID = LF.LINE_FUNCTION_ID
inner join MIDAS.BR_PROG bp on G.OWNER_BR_PROG_ID = BP.BR_PROG_ID
inner join MIDAS.CROP CROP on G.CROP_ID = CROP.CROP_ID
left outer join (select P.PRODUCT_ID, PN.NAME, B.NAME as BRAND_NAME from midas.product p
    inner join MIDAS.PRODUCT_NAME pn on P.PRODUCT_ID = PN.PRODUCT_ID
    inner join midas.brand b on pn.brand_id = b.brand_id
    inner join MIDAS.COMPANY c on B.COMPANY_ID = C.COMPANY_ID
    where C.NAME = 'MONSANTO' and B.NAME <> 'MONSANTO' and P.REF_ACTIVE = 'T') COMMERCIAL_NAME on COMMERCIAL_NAME.product_id = MPG.PRODUCT_ID
where CROP.CROP_ID = :cropId
and G.IS_DELETED = 'F'