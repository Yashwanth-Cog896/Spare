package com.monsanto.tps.materialweb.model;

import com.google.common.collect.Lists;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.Collection;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreationResults {
    @JsonProperty
    private boolean requestSuccess;
    @JsonProperty
    private String responseMessage = "";
    @JsonProperty
    private Collection<CreationResponse> responses = Lists.newArrayList();

    public boolean isRequestSuccess() {
        return requestSuccess;
    }

    public void setRequestSuccess(boolean requestSuccess) {
        this.requestSuccess = requestSuccess;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Collection<CreationResponse> getResponses() {
        return responses;
    }

    public void addResponses(CreationResponse response) {
        this.responses.add(response);
    }

    public void clearResponses() {
        this.responses = Lists.newArrayList();
    }
}
