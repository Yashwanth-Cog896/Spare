package com.monsanto.tps.materialweb.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaterialPlacementInformation {

    @JsonProperty
    private String inventoryBarcode;

    @JsonProperty
    private String pedigree;

    @JsonProperty
    private String source;

    @JsonProperty
    private String season;

    @JsonProperty
    private String setName;

    @JsonProperty
    private String setType;

    @JsonProperty
    private Integer repNumber;

    @JsonProperty
    private String locationName;

    @JsonProperty
    private String locationRefId;

    @JsonProperty
    private String fieldName;

    @JsonProperty
    private String trackId;

    @JsonProperty
    private String fieldType;

    @JsonProperty
    private Integer entryNumber;

    @JsonProperty
    private String plotBarcode;

    @JsonProperty
    private Integer plotNumber;

    @JsonProperty
    private Integer absRange;

    @JsonProperty
    private Integer absColumn;

    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public String getSetName() {
        return setName;
    }

    public void setSetName(String setName) {
        this.setName = setName;
    }

    public String getSetType() {
        return setType;
    }

    public void setSetType(String setType) {
        this.setType = setType;
    }

    public Integer getRepNumber() {
        return repNumber;
    }

    public void setRepNumber(Integer repNumber) {
        this.repNumber = repNumber;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getLocationRefId() {
        return locationRefId;
    }

    public void setLocationRefId(String locationRefId) {
        this.locationRefId = locationRefId;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getTrackId() {
        return trackId;
    }

    public void setTrackId(String trackId) {
        this.trackId = trackId;
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    public Integer getEntryNumber() {
        return entryNumber;
    }

    public void setEntryNumber(Integer entryNumber) {
        this.entryNumber = entryNumber;
    }

    public String getPlotBarcode() {
        return plotBarcode;
    }

    public void setPlotBarcode(String plotBarcode) {
        this.plotBarcode = plotBarcode;
    }

    public Integer getPlotNumber() {
        return plotNumber;
    }

    public void setPlotNumber(Integer plotNumber) {
        this.plotNumber = plotNumber;
    }

    public Integer getAbsRange() {
        return absRange;
    }

    public void setAbsRange(Integer absRange) {
        this.absRange = absRange;
    }

    public Integer getAbsColumn() {
        return absColumn;
    }

    public void setAbsColumn(Integer absColumn) {
        this.absColumn = absColumn;
    }
}
