package com.monsanto.tps.materialweb.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchCriteriaModel {
    @JsonProperty
    private String cropId;
    @JsonProperty
    private String searchType1;
    @JsonProperty
    private String searchValue1;
    @JsonProperty
    private String searchType2;
    @JsonProperty
    private String searchValue2;

    public SearchCriteriaModel() {
    }

    public SearchCriteriaModel(String cropId, String searchType1, String searchValue1, String searchType2, String searchValue2) {
        this.cropId = cropId;
        this.searchType1 = searchType1;
        this.searchValue1 = searchValue1;
        this.searchType2 = searchType2;
        this.searchValue2 = searchValue2;
    }

    public String getCropId() {
        return cropId;
    }

    public void setCropId(String cropId) {
        this.cropId = cropId;
    }

    public String getSearchType1() {
        return searchType1;
    }

    public void setSearchType1(String searchType1) {
        this.searchType1 = searchType1;
    }

    public String getSearchValue1() {
        return searchValue1;
    }

    public void setSearchValue1(String searchValue1) {
        this.searchValue1 = searchValue1;
    }

    public String getSearchType2() {
        return searchType2;
    }

    public void setSearchType2(String searchType2) {
        this.searchType2 = searchType2;
    }

    public String getSearchValue2() {
        return searchValue2;
    }

    public void setSearchValue2(String searchValue2) {
        this.searchValue2 = searchValue2;
    }
}
