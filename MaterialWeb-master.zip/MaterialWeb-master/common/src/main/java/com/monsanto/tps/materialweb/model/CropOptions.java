package com.monsanto.tps.materialweb.model;

import java.util.Collection;

public class CropOptions {
    private Collection<String> availablePrograms;
    private Collection<String> vegetativeStructures;
    private Collection<String> seedQuantityUoms;
    private Boolean isTQRequiredCrop = false;

    public Collection<String> getAvailablePrograms() {
        return availablePrograms;
    }

    public void setAvailablePrograms(Collection<String> availablePrograms) {
        this.availablePrograms = availablePrograms;
    }

    public Collection<String> getVegetativeStructures() {
        return vegetativeStructures;
    }

    public void setVegetativeStructures(Collection<String> vegetativeStructures) {
        this.vegetativeStructures = vegetativeStructures;
    }

    public Collection<String> getSeedQuantityUoms() {
        return seedQuantityUoms;
    }

    public void setSeedQuantityUoms(Collection<String> seedQuantityUoms) {
        this.seedQuantityUoms = seedQuantityUoms;
    }

    public Boolean getTQRequiredCrop() {
        return isTQRequiredCrop;
    }

    public void setTQRequiredCrop(Boolean TQRequiredCrop) {
        isTQRequiredCrop = TQRequiredCrop;
    }
}
