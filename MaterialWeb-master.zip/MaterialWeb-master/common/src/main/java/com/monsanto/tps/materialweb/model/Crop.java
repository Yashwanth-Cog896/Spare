package com.monsanto.tps.materialweb.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * Created by IntelliJ IDEA.
 * User: RRGUDI
 * Date: 5/14/12
 * Time: 1:09 PM
 * To change this template use File | Settings | File Templates.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Crop implements Comparable<Crop> {

    @JsonProperty
    private Long id;
    @JsonProperty
    private String name;

    public Crop() {
    }

    public Crop(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Crop o) {
        return name.compareTo(o.getName());
    }
}
