package com.monsanto.tps.materialweb.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreationRequest {
    @JsonProperty
    private boolean validateOnly;
    @JsonProperty
    private String vegetativeStructure;
    @JsonProperty
    private String sourceName;
    @JsonProperty
    private String seedQuantityUOM;
    @JsonProperty
    private Double seedQuantity;
    @JsonProperty
    private String inventoryOwnerProgram;
    @JsonProperty
    private Long germplasmId;
    @JsonProperty
    private String exposureHistoryKnown;
    @JsonProperty
    private String toxinsPresent;
    @JsonProperty
    private String allergensPresent;
    @JsonProperty
    private String animalGenePresent;
    @JsonProperty
    private String miniChromosome;
    @JsonProperty
    private String fromManufacturing;
    @JsonProperty
    private String manufacturingBatchNumber;
    @JsonProperty
    private String manufacturingAcronymNumber;
    @JsonProperty
    private String manufacturingMaterialNumber;

    public boolean isValidateOnly() {
        return validateOnly;
    }

    public void setValidateOnly(boolean validateOnly) {
        this.validateOnly = validateOnly;
    }

    public String getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(String vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getSeedQuantityUOM() {
        return seedQuantityUOM;
    }

    public void setSeedQuantityUOM(String seedQuantityUOM) {
        this.seedQuantityUOM = seedQuantityUOM;
    }

    public Double getSeedQuantity() {
        return seedQuantity;
    }

    public void setSeedQuantity(Double seedQuantity) {
        this.seedQuantity = seedQuantity;
    }

    public String getInventoryOwnerProgram() {
        return inventoryOwnerProgram;
    }

    public void setInventoryOwnerProgram(String inventoryOwnerProgram) {
        this.inventoryOwnerProgram = inventoryOwnerProgram;
    }

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public boolean getValidateOnly() {
        return validateOnly;
    }

    public String getExposureHistoryKnown() {
        return exposureHistoryKnown;
    }

    public void setExposureHistoryKnown(String exposureHistoryKnown) {
        this.exposureHistoryKnown = exposureHistoryKnown;
    }

    public String getToxinsPresent() {
        return toxinsPresent;
    }

    public void setToxinsPresent(String toxinsPresent) {
        this.toxinsPresent = toxinsPresent;
    }

    public String getAllergensPresent() {
        return allergensPresent;
    }

    public void setAllergensPresent(String allergensPresent) {
        this.allergensPresent = allergensPresent;
    }

    public String getAnimalGenePresent() {
        return animalGenePresent;
    }

    public void setAnimalGenePresent(String animalGenePresent) {
        this.animalGenePresent = animalGenePresent;
    }

    public String getMiniChromosome() {
        return miniChromosome;
    }

    public void setMiniChromosome(String miniChromosome) {
        this.miniChromosome = miniChromosome;
    }

    public String getFromManufacturing() {
        return fromManufacturing;
    }

    public void setFromManufacturing(String fromManufacturing) {
        this.fromManufacturing = fromManufacturing;
    }

    public String getManufacturingBatchNumber() {
        return manufacturingBatchNumber;
    }

    public void setManufacturingBatchNumber(String manufacturingBatchNumber) {
        this.manufacturingBatchNumber = manufacturingBatchNumber;
    }

    public String getManufacturingAcronymNumber() {
        return manufacturingAcronymNumber;
    }

    public void setManufacturingAcronymNumber(String manufacturingAcronymNumber) {
        this.manufacturingAcronymNumber = manufacturingAcronymNumber;
    }

    public String getManufacturingMaterialNumber() {
        return manufacturingMaterialNumber;
    }

    public void setManufacturingMaterialNumber(String manufacturingMaterialNumber) {
        this.manufacturingMaterialNumber = manufacturingMaterialNumber;
    }
}
