package com.monsanto.tps.materialweb.service;

import com.monsanto.tps.materialweb.model.Crop;
import com.monsanto.tps.materialweb.model.CropOptions;

import javax.ws.rs.*;
import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

public interface ReferenceDataService {

    @GET
    @Path("/crops/user")
    @Produces(APPLICATION_JSON)
    @Consumes({APPLICATION_JSON})
    public List<Crop> getUserCropNames();

    @GET
    @Path("/crop/referencedata")
    @Produces(APPLICATION_JSON)
    @Consumes({APPLICATION_JSON})
    public CropOptions getCropReferenceData(@QueryParam("cropId") Long cropId);

}
