package com.monsanto.tps.materialweb.model;


import org.apache.commons.lang.StringUtils;

import java.util.Comparator;

public class MaterialInformationComparator implements Comparator<MaterialInformation> {
    @Override
    public int compare(MaterialInformation info1, MaterialInformation info2) {
        if (info1 == null && info2 != null) {
            return -1;
        } else if (info1 != null && info2 == null) {
            return 1;
        } else if (info1 == null && info2 == null) {
            return 0;
        } else {
            return compareInfoDetails(info1, info2);
        }
    }

    /**
     * return " Order By PRECOMMERCIAL_NAME.NAME, G.ORIGIN, G.LINE_CODE, inner_query.SAP_MATERIAL_NBR, MPG.IS_PREFERRED DESC, G.GERMPLASM_ID DESC";
     */
    private int compareInfoDetails(MaterialInformation info1, MaterialInformation info2) {
        int result = compareStringSpaceLast(info1.getLexiconPreCommercialName(), info2.getLexiconPreCommercialName());
        if (result == 0) {
            result = compareStringSpaceLast(info1.getOrigin(), info2.getOrigin());
        }
        if (result == 0) {
            result = compareString(info1.getLineCode(), info2.getLineCode());
        }
        if (result == 0) {
            result = compareStringSpaceLast(info1.getMaterialNumber(), info2.getMaterialNumber());
        }
        if (result == 0) {
            result = compareStringSpaceLast(info1.getPreferredGermplasm(), info2.getPreferredGermplasm());
        }
        if (result == 0) {
            result = compareString(info1.getBatchNumber(), info2.getBatchNumber());
        }
        if (result == 0) {
            result = compareString(info1.getAcronym(), info2.getAcronym());
        }
        if (result == 0) {
            result = compareString(info1.getMidasCommercialBrandName(), info2.getMidasCommercialBrandName());
        }
        if (result == 0) {
            result = compareString(info1.getMidasCommercialName(), info2.getMidasCommercialName());
        }
        if (result == 0) {
            result = compareString(info1.getLineType(), info2.getLineType());
        }
        if (result == 0) {
            result = compareString(info1.getLineFunction(), info2.getLineFunction());
        }
        if (result == 0) {
            result = compareString(info1.getGermplasmOwner(), info2.getGermplasmOwner());
        }
        if (result == 0) {
            result = compareString(info1.getSapMaterialDescription(), info2.getSapMaterialDescription());
        }
        if (result == 0) {
            result = compareString(info1.getTraitVersion(), info2.getTraitVersion());
        }
        if (result == 0) {
            result = compareString(info1.getSapBrandName(), info2.getSapBrandName());
        }
        if (result == 0) {
            result = compareString(info1.getPreferredGermplasm(), info2.getPreferredGermplasm());
        }
        if (result == 0) {
            result = compareString(info1.getPreferredName(), info2.getPreferredName());
        }
        if (result == 0) {
            result = compareString(info1.getSapTraitVersion(), info2.getSapTraitVersion());
        }
        if (result == 0) {
            result = compareString(info1.getPedigree(), info2.getPedigree());
        }
        if (result == 0) {
            result = compareString(info1.getEvent(), info2.getEvent());
        }
        if (result == 0) {
            result = compareString(info1.getRestriction(), info2.getRestriction());
        }
        return result;
    }

    private int compareStringSpaceLast(String str1, String str2) {
        if (str1 == null && str2 != null) {
            return -1;
        } else if (str1 != null && str2 == null) {
            return 1;
        } else if (str1 == null && str2 == null) {
            return 0;
        } else if (StringUtils.isEmpty(str1) && !StringUtils.isEmpty(str2)) {
            return 1;
        } else if (!StringUtils.isEmpty(str1) && StringUtils.isEmpty(str2)) {
            return -1;
        } else {
            return str1.compareTo(str2);
        }
    }

    private int compareString(String str1, String str2) {
        if (str1 == null && str2 != null) {
            return -1;
        } else if (str1 != null && str2 == null) {
            return 1;
        } else if (str1 == null && str2 == null) {
            return 0;
        } else {
            return str1.compareTo(str2);
        }
    }
}
