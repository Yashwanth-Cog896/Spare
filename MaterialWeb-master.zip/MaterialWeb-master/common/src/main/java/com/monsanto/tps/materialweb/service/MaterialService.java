package com.monsanto.tps.materialweb.service;

import com.monsanto.tps.materialweb.model.CreationRequest;
import com.monsanto.tps.materialweb.model.CreationResults;
import com.monsanto.tps.materialweb.model.SearchCriteriaModel;
import com.monsanto.tps.materialweb.model.SearchMaterialResults;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.util.Collection;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/materials")
public interface MaterialService {

    @POST
    @Produces(APPLICATION_JSON)
    @Consumes({APPLICATION_JSON})
    public SearchMaterialResults searchMaterial(SearchCriteriaModel model);

    @POST
    @Path("/create")
    @Produces(APPLICATION_JSON)
    @Consumes(APPLICATION_JSON)
    public CreationResults createMaterial(Collection<CreationRequest> requests);

}
