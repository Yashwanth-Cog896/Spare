package com.monsanto.tps.materialweb.model;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MaterialInformation {

    @JsonProperty
    private Long id;    //using the germplasmId as the unique id
    @JsonProperty
    private String batchNumber;
    @JsonProperty
    private String materialNumber;
    @JsonProperty
    private String origin;
    @JsonProperty
    private String lineCode;
    @JsonProperty
    private String event;
    @JsonProperty
    private String lineType;
    @JsonProperty
    private String lineFunction;
    @JsonProperty
    private String germplasmOwner;
    @JsonProperty
    private String pedigree;
    @JsonProperty
    private String cropName;
    @JsonProperty
    private String acronym;
    @JsonProperty
    private String traitVersion;
    @JsonProperty
    private long cropId;
    @JsonProperty
    private String varietyName;
    @JsonProperty
    private String restriction;
    @JsonProperty
    private String transgenic = "F";
    @JsonProperty
    private String toxinsPresent = "F";
    @JsonProperty
    private String allergens = "F";
    @JsonProperty
    private String animalGene = "F";
    @JsonProperty
    private String exposureHistory = "F";
    @JsonProperty
    private String miniChromosome = "F";
    @JsonProperty
    private String fromManufacturing = "T";
    @JsonProperty
    private String sapBrandName;
    @JsonProperty
    private String sapMaterialDescription;
    @JsonProperty
    private String preferredGermplasm;
    @JsonProperty
    private String preferredName;
    @JsonProperty
    private String sapTraitVersion;
    @JsonProperty
    private Date sapCreatedDate;
    @JsonProperty
    private String lexiconPreCommercialName;
    @JsonProperty
    private String midasCommercialName;
    @JsonProperty
    private String midasCommercialBrandName;
    @JsonProperty
    private String manufacturingName;

    //Input properties
    @JsonProperty
    private String source;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public String getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(String materialNumber) {
        this.materialNumber = materialNumber;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public String getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(String lineFunction) {
        this.lineFunction = lineFunction;
    }

    public String getGermplasmOwner() {
        return germplasmOwner;
    }

    public void setGermplasmOwner(String germplasmOwner) {
        this.germplasmOwner = germplasmOwner;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public String getTraitVersion() {
        return traitVersion;
    }

    public void setTraitVersion(String traitVersion) {
        this.traitVersion = traitVersion;
    }

    public long getCropId() {
        return cropId;
    }

    public void setCropId(long cropId) {
        this.cropId = cropId;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public String getRestriction() {
        return restriction;
    }

    public void setRestriction(String restriction) {
        this.restriction = restriction;
    }

    public String getTransgenic() {
        return transgenic;
    }

    public void setTransgenicBoolean(boolean transgenic) {
        this.transgenic = convertBoolean(transgenic);
    }

    public void setTransgenic(String transgenic) {
        this.transgenic = transgenic;
    }

    public String getToxinsPresent() {
        return toxinsPresent;
    }

    public void setToxinsPresentBoolean(boolean toxinsPresent) {
        this.toxinsPresent = convertBoolean(toxinsPresent);
    }

    public void setToxinsPresent(String toxinsPresent) {
        this.toxinsPresent = toxinsPresent;
    }

    public String getAllergens() {
        return allergens;
    }

    public void setAllergensBoolean(boolean allergens) {
        this.allergens = convertBoolean(allergens);
    }

    public void setAllergens(String allergens) {
        this.allergens = allergens;
    }

    public String getAnimalGene() {
        return animalGene;
    }

    public void setAnimalGeneBoolean(boolean animalGene) {
        this.animalGene = convertBoolean(animalGene);
    }

    public void setAnimalGene(String animalGene) {
        this.animalGene = animalGene;
    }

    public String getExposureHistory() {
        return exposureHistory;
    }

    public void setExposureHistoryBoolean(boolean exposureHistory) {
        this.exposureHistory = convertBoolean(exposureHistory);
    }

    public void setExposureHistory(String exposureHistory) {
        this.exposureHistory = exposureHistory;
    }

    public String getMiniChromosome() {
        return miniChromosome;
    }

    public void setMiniChromosomeBoolean(boolean miniChromosome) {
        this.miniChromosome = convertBoolean(miniChromosome);
    }

    public void setMiniChromosome(String miniChromosome) {
        this.miniChromosome = miniChromosome;
    }

    public String getFromManufacturing() {
        return fromManufacturing;
    }

    public void setFromManufacturingBoolean(boolean fromManufacturing) {
        this.fromManufacturing = convertBoolean(fromManufacturing);
    }

    public void setFromManufacturing(String fromManufacturing) {
        this.fromManufacturing = fromManufacturing;
    }

    private String convertBoolean(boolean value) {
        if (value) {
            return "T";
        }
        return "F";
    }

    private String convertFlag(String originalValue) {
        if ("N".equalsIgnoreCase(originalValue)) {
            return "NO";
        } else if ("Y".equalsIgnoreCase(originalValue)) {
            return "YES";
        }
        return originalValue;
    }

    public String getSapBrandName() {
        return sapBrandName;
    }

    public void setSapBrandName(String sapBrandName) {
        this.sapBrandName = sapBrandName;
    }

    public String getSapMaterialDescription() {
        return sapMaterialDescription;
    }

    public void setSapMaterialDescription(String sapMaterialDescription) {
        this.sapMaterialDescription = sapMaterialDescription;
    }

    public void clearTQDependentColumns() {
        this.allergens = "";
        this.exposureHistory = "";
        this.fromManufacturing = "";
        this.toxinsPresent = "";
    }

    public String getPreferredGermplasm() {
        return preferredGermplasm;
    }

    public void setPreferredGermplasm(String preferredGermplasm) {
        this.preferredGermplasm = convertFlag(preferredGermplasm);
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = convertFlag(preferredName);
    }

    public String getSapTraitVersion() {
        return sapTraitVersion;
    }

    public void setSapTraitVersion(String sapTraitVersion) {
        this.sapTraitVersion = sapTraitVersion;
    }

    public Date getSapCreatedDate() {
        return sapCreatedDate;
    }

    public void setSapCreatedDate(Date sapCreatedDate) {
        this.sapCreatedDate = sapCreatedDate;
    }

    public String getLexiconPreCommercialName() {
        return lexiconPreCommercialName;
    }

    public void setLexiconPreCommercialName(String lexiconPreCommercialName) {
        this.lexiconPreCommercialName = lexiconPreCommercialName;
    }

    public String getMidasCommercialName() {
        return midasCommercialName;
    }

    public void setMidasCommercialName(String midasCommercialName) {
        this.midasCommercialName = midasCommercialName;
    }

    public String getMidasCommercialBrandName() {
        return midasCommercialBrandName;
    }

    public void setMidasCommercialBrandName(String midasCommercialBrandName) {
        this.midasCommercialBrandName = midasCommercialBrandName;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public void setManufacturingName(String manufacturingName) {
        this.manufacturingName = manufacturingName;
    }

    @Override
    /** Make unique by properties that are displayed */
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }

        MaterialInformation material = (MaterialInformation) obj;

        if (!StringUtils.equals(material.getOrigin(), this.getOrigin()) ||
                !StringUtils.equals(material.getLineCode(), this.getLineCode()) ||
                !StringUtils.equals(material.getBatchNumber(), this.getBatchNumber()) ||
                !StringUtils.equals(material.getMaterialNumber(), this.getMaterialNumber()) ||
                !StringUtils.equals(material.getAcronym(), this.getAcronym()) ||
                !StringUtils.equals(material.getLineType(), this.getLineType()) ||
                !StringUtils.equals(material.getLineFunction(), this.getLineFunction()) ||
                !StringUtils.equals(material.getGermplasmOwner(), this.getGermplasmOwner()) ||
                !StringUtils.equals(material.getSapMaterialDescription(), this.getSapMaterialDescription()) ||
                !StringUtils.equals(material.getTraitVersion(), this.getTraitVersion()) ||
                !StringUtils.equals(material.getSapBrandName(), this.getSapBrandName()) ||
                !StringUtils.equals(material.getPreferredGermplasm(), this.getPreferredGermplasm()) ||
                !StringUtils.equals(material.getPreferredName(), this.getPreferredName()) ||
                !StringUtils.equals(material.getSapTraitVersion(), this.getSapTraitVersion()) ||
                !StringUtils.equals(material.getPedigree(), this.getPedigree()) ||
                !StringUtils.equals(material.getEvent(), this.getEvent()) ||
                !StringUtils.equals(material.getLexiconPreCommercialName(), this.getLexiconPreCommercialName()) ||
                !StringUtils.equals(material.getMidasCommercialName(), this.getMidasCommercialName()) ||
                !StringUtils.equals(material.getMidasCommercialBrandName(), this.getMidasCommercialBrandName()) ||
                !StringUtils.equals(material.getManufacturingName(), this.getManufacturingName())
                ) {
            return false;
        } else {
            return true;
        }
    }

    @Override
    /** Make unique by properties that are displayed */
    public int hashCode() {
        int hashCode = 43;
        hashCode += getHashCode(getOrigin());
        hashCode += getHashCode(getLineCode());
        hashCode += getHashCode(getBatchNumber());
        hashCode += getHashCode(getMaterialNumber());
        hashCode += getHashCode(getAcronym());
        hashCode += getHashCode(getLineType());
        hashCode += getHashCode(getLineFunction());
        hashCode += getHashCode(getGermplasmOwner());
        hashCode += getHashCode(getSapMaterialDescription());
        hashCode += getHashCode(getTraitVersion());
        hashCode += getHashCode(getSapBrandName());
        hashCode += getHashCode(getPreferredGermplasm());
        hashCode += getHashCode(getSapTraitVersion());
        hashCode += getHashCode(getPreferredName());
        hashCode += getHashCode(getPedigree());
        hashCode += getHashCode(getEvent());
        hashCode += getHashCode(getLexiconPreCommercialName());
        hashCode += getHashCode(getMidasCommercialName());
        hashCode += getHashCode(getMidasCommercialBrandName());
        hashCode += getHashCode(getManufacturingName());
        return hashCode;
    }

    private int getHashCode(Object obj) {
        if (obj != null) {
            return obj.hashCode();
        } else {
            return 0;
        }
    }
}
