package com.monsanto.tps.materialweb.service;

import com.monsanto.tps.materialweb.model.MaterialPlacementInformation;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path("/place")
public interface MaterialPlacementService {

    @GET
    @Path("/inventories")
    @Produces(APPLICATION_JSON)
    public MaterialPlacementInformation[] placement(@QueryParam("barcodes") String barcodes);
}
