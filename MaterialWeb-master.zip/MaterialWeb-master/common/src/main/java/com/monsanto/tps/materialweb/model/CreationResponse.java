package com.monsanto.tps.materialweb.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.Collection;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CreationResponse {
    @JsonProperty
    private Long germplasmId;
    @JsonProperty
    private String inventoryBID;
    @JsonProperty
    private Collection<String> messages;
    @JsonProperty
    private String sourceString;
    @JsonProperty
    private boolean success;

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getInventoryBID() {
        return inventoryBID;
    }

    public void setInventoryBID(String inventoryBID) {
        this.inventoryBID = inventoryBID;
    }

    public Collection<String> getMessages() {
        return messages;
    }

    public void setMessages(Collection<String> messages) {
        this.messages = messages;
    }

    public String getSourceString() {
        return sourceString;
    }

    public void setSourceString(String sourceString) {
        this.sourceString = sourceString;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
