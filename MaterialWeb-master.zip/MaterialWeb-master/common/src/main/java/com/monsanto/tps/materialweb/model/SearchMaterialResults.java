package com.monsanto.tps.materialweb.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import java.util.Collection;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchMaterialResults {

    @JsonProperty
    private Integer searchResultCount;
    @JsonProperty
    private Collection<MaterialInformation> materialInformation;
    @JsonProperty
    private String queryString;
    @JsonProperty
    private String warning;

    public Integer getSearchResultCount() {
        return searchResultCount;
    }

    public void setSearchResultCount(Integer searchResultCount) {
        this.searchResultCount = searchResultCount;
    }

    public Collection<MaterialInformation> getMaterialInformation() {
        return materialInformation;
    }

    public void setMaterialInformation(Collection<MaterialInformation> materialInformation) {
        this.materialInformation = materialInformation;
    }

    public String getQueryString() {
        return queryString;
    }

    public void setQueryString(String queryString) {
        this.queryString = queryString;
    }

    public String getWarning() {
        return warning;
    }

    public void setWarning(String warning) {
        this.warning = warning;
    }
}
