package com.monsanto.tps.materialweb.model;

import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class CreationResponse_UT {
    private CreationResponse testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new CreationResponse();
    }

    @Test
    public void testGettersAndSetters() {
        testObject.setGermplasmId(-1l);
        testObject.setInventoryBID("I4");
        Collection<String> msgs = Lists.newArrayList();
        msgs.add("hello");
        testObject.setMessages(msgs);
        testObject.setSourceString("b");
        testObject.setSuccess(true);

        assertThat(testObject.getGermplasmId(), is(-1l));
        assertThat(testObject.getInventoryBID(), is("I4"));
        assertThat(testObject.getMessages(), contains("hello"));
        assertThat(testObject.getSourceString(), is("b"));
        assertThat(testObject.isSuccess(), is(true));
    }
}
