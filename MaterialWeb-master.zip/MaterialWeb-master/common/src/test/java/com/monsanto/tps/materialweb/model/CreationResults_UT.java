package com.monsanto.tps.materialweb.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;


public class CreationResults_UT {
    private CreationResults testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new CreationResults();
    }

    @Test
    public void testGettersAndSetters() {
        testObject.setResponseMessage("A");
        testObject.setRequestSuccess(false);
        CreationResponse response = new CreationResponse();
        testObject.addResponses(response);

        assertThat(testObject.getResponseMessage(), is("A"));
        assertThat(testObject.isRequestSuccess(), is(false));
        assertThat(testObject.getResponses(), contains(response));
    }
}
