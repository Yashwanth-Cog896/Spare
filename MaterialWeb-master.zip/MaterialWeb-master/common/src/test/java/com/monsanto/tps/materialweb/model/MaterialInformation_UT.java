package com.monsanto.tps.materialweb.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

public class MaterialInformation_UT {
    private MaterialInformation testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new MaterialInformation();
    }

    @Test
    public void testGettersAndSetters() {
        testObject.setRestriction("A");
        testObject.setAcronym("B");
        testObject.setAllergens("C");
        testObject.setAnimalGene("D");
        testObject.setBatchNumber("E");
        testObject.setCropId(-1l);
        testObject.setCropName("F");
        testObject.setEvent("G");
        testObject.setExposureHistory("H");
        testObject.setFromManufacturing("I");
        testObject.setGermplasmOwner("J");
        testObject.setId(-2l);
        testObject.setLexiconPreCommercialName("K");
        testObject.setLineCode("L");
        testObject.setLineFunction("M");
        testObject.setLineType("N");
        testObject.setManufacturingName("O");
        testObject.setMaterialNumber("P");
        testObject.setMidasCommercialBrandName("Q");
        testObject.setMidasCommercialName("R");
        testObject.setMiniChromosome("S");
        testObject.setOrigin("T");
        testObject.setVarietyName("U");

        assertThat(testObject.getRestriction(), is("A"));
        assertThat(testObject.getAcronym(), is("B"));
        assertThat(testObject.getAllergens(), is("C"));
        assertThat(testObject.getAnimalGene(), is("D"));
        assertThat(testObject.getBatchNumber(), is("E"));
        assertThat(testObject.getCropId(), is(-1l));
        assertThat(testObject.getCropName(), is("F"));
        assertThat(testObject.getEvent(), is("G"));
        assertThat(testObject.getExposureHistory(), is("H"));
        assertThat(testObject.getFromManufacturing(), is("I"));
        assertThat(testObject.getGermplasmOwner(), is("J"));
        assertThat(testObject.getId(), is(-2l));
        assertThat(testObject.getLexiconPreCommercialName(), is("K"));
        assertThat(testObject.getLineCode(), is("L"));
        assertThat(testObject.getLineFunction(), is("M"));
        assertThat(testObject.getLineType(), is("N"));
        assertThat(testObject.getManufacturingName(), is("O"));
        assertThat(testObject.getMaterialNumber(), is("P"));
        assertThat(testObject.getMidasCommercialBrandName(), is("Q"));
        assertThat(testObject.getMidasCommercialName(), is("R"));
        assertThat(testObject.getMiniChromosome(), is("S"));
        assertThat(testObject.getOrigin(), is("T"));
        assertThat(testObject.getVarietyName(), is("U"));
    }

    @Test
    public void testBooleanSetters() {
        testObject.setAnimalGeneBoolean(true);
        testObject.setAllergensBoolean(true);
        testObject.setExposureHistoryBoolean(true);
        testObject.setFromManufacturingBoolean(true);
        testObject.setMiniChromosomeBoolean(true);
        testObject.setToxinsPresentBoolean(false);
    }

    @Test
    public void testTQSetters() {
        testObject.setTransgenic("A");
        testObject.setToxinsPresent("B");

    }

    @Test
    public void testHashCode() {
        testObject.setId(-4l);
        testObject.setLineCode("E");

        assertThat(testObject.hashCode(), greaterThan(1));
    }

    @Test
    public void testEquals() {
        testObject.setId(-4l);
        testObject.setLineCode("F");

        assertFalse(testObject.equals(null));
    }

    @Test
    public void testPreferredName() {
        testObject.setId(-4l);
        testObject.setLineCode("F");
        testObject.setPreferredName("Y");

        assertThat(testObject.getPreferredName(), is("YES"));
    }
}
