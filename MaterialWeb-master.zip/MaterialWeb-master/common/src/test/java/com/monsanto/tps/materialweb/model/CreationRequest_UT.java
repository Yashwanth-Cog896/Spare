package com.monsanto.tps.materialweb.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class CreationRequest_UT {
    private CreationRequest testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new CreationRequest();
    }

    @Test
    public void testGettersAndSetters() {
        testObject.setGermplasmId(-1l);
        testObject.setSeedQuantity(-2d);
        testObject.setSourceName("A");
        testObject.setVegetativeStructure("B");
        testObject.setInventoryOwnerProgram("C");
        testObject.setSeedQuantityUOM("D");
        testObject.setValidateOnly(true);

        assertThat(testObject.getGermplasmId(), is(-1l));
        assertThat(testObject.getSeedQuantity(), is(-2d));
        assertThat(testObject.getSourceName(), is("A"));
        assertThat(testObject.getVegetativeStructure(), is("B"));
        assertThat(testObject.getInventoryOwnerProgram(), is("C"));
        assertThat(testObject.getSeedQuantityUOM(), is("D"));
        assertThat(testObject.getValidateOnly(), is(true));
    }

    @Test
    public void testTQGettersAndSetters() {
        testObject.setAllergensPresent("A");
        testObject.setAnimalGenePresent("B");
        testObject.setExposureHistoryKnown("C");
        testObject.setFromManufacturing("D");
        testObject.setManufacturingAcronymNumber("E");
        testObject.setManufacturingBatchNumber("F");
        testObject.setManufacturingMaterialNumber("G");
        testObject.setMiniChromosome("H");
        testObject.setToxinsPresent("I");

        assertThat(testObject.getAllergensPresent(), is("A"));
        assertThat(testObject.getAnimalGenePresent(), is("B"));
        assertThat(testObject.getExposureHistoryKnown(), is("C"));
        assertThat(testObject.getFromManufacturing(), is("D"));
        assertThat(testObject.getManufacturingAcronymNumber(), is("E"));
        assertThat(testObject.getManufacturingBatchNumber(), is("F"));
        assertThat(testObject.getManufacturingMaterialNumber(), is("G"));
        assertThat(testObject.getMiniChromosome(), is("H"));
        assertThat(testObject.getToxinsPresent(), is("I"));
    }
}
