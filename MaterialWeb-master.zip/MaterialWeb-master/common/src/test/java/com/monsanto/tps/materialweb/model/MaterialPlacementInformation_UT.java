package com.monsanto.tps.materialweb.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 4/30/13
 * Time: 3:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialPlacementInformation_UT {
    private MaterialPlacementInformation testObject;

    @Before
    public void setUp() throws Exception {
        testObject = new MaterialPlacementInformation();
    }

    @Test
    public void testGettersAndSetters() {
        testObject.setAbsColumn(1);
        testObject.setAbsRange(2);
        testObject.setEntryNumber(3);
        testObject.setFieldName("A");
        testObject.setFieldType("B");
        testObject.setInventoryBarcode("C");
        testObject.setLocationName("D");
        testObject.setLocationRefId("E");
        testObject.setPedigree("F");
        testObject.setPlotBarcode("G");
        testObject.setPlotNumber(4);
        testObject.setRepNumber(5);
        testObject.setSeason("I");
        testObject.setSetName("J");
        testObject.setSetType("H");
        testObject.setSource("K");
        testObject.setTrackId("L");

        assertThat(testObject.getAbsColumn(), is(1));
        assertThat(testObject.getAbsRange(), is(2));
        assertThat(testObject.getEntryNumber(), is(3));
        assertThat(testObject.getFieldName(), is("A"));
        assertThat(testObject.getFieldType(), is("B"));
        assertThat(testObject.getInventoryBarcode(), is("C"));
        assertThat(testObject.getLocationName(), is("D"));
        assertThat(testObject.getLocationRefId(), is("E"));
        assertThat(testObject.getPedigree(), is("F"));
        assertThat(testObject.getPlotBarcode(), is("G"));
        assertThat(testObject.getPlotNumber(), is(4));
        assertThat(testObject.getRepNumber(), is(5));
        assertThat(testObject.getSeason(), is("I"));
        assertThat(testObject.getSetName(), is("J"));
        assertThat(testObject.getSetType(), is("H"));
        assertThat(testObject.getSource(), is("K"));
        assertThat(testObject.getTrackId(), is("L"));
    }
}
