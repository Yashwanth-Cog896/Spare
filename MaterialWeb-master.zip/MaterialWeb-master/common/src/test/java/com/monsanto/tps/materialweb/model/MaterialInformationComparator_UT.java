package com.monsanto.tps.materialweb.model;

import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class MaterialInformationComparator_UT {
    private MaterialInformationComparator testObject = new MaterialInformationComparator();

    @Test
    public void testCompare_equals() throws Exception {
        MaterialInformation info1 = new MaterialInformation();
        info1.setRestriction("A");
        MaterialInformation info2 = new MaterialInformation();
        info2.setRestriction("A");

        int result = testObject.compare(info1, info2);

        assertThat(result, is(0));
    }

    @Test
    public void testCompare_notEquals() throws Exception {
        MaterialInformation info1 = new MaterialInformation();
        info1.setRestriction("A");
        MaterialInformation info2 = new MaterialInformation();
        info2.setRestriction("B");

        int result = testObject.compare(info1, info2);

        assertThat(result, is(-1));
    }

    @Test
    public void testCompare_secondNull() throws Exception {
        MaterialInformation info1 = new MaterialInformation();
        info1.setRestriction("A");
        MaterialInformation info2 = new MaterialInformation();
        info2.setRestriction("B");

        int result = testObject.compare(info1, null);

        assertThat(result, is(1));
    }

    @Test
    public void testCompare_bothNulls() throws Exception {
        MaterialInformation info1 = new MaterialInformation();
        info1.setRestriction("A");
        MaterialInformation info2 = new MaterialInformation();
        info2.setRestriction("B");

        int result = testObject.compare(null, null);

        assertThat(result, is(0));
    }

    @Test
    public void testCompare_firstNull() throws Exception {
        MaterialInformation info1 = new MaterialInformation();
        info1.setRestriction("A");
        MaterialInformation info2 = new MaterialInformation();
        info2.setRestriction("B");

        int result = testObject.compare(null, info2);

        assertThat(result, is(-1));
    }
}
