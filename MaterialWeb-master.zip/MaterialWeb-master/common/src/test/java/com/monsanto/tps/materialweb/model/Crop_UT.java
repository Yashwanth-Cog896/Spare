package com.monsanto.tps.materialweb.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class Crop_UT {
    private Crop testObject;

    @Before
    public void setup() {
        testObject = new Crop();
    }

    @Test
    public void testGettersAndSetters() {
        testObject.setId(-1l);
        testObject.setName("ABC");

        assertThat(testObject.getId(), is(-1L));
        assertThat(testObject.getName(), is("ABC"));
    }
}
