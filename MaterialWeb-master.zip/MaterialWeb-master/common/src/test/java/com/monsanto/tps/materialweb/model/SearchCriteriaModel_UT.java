package com.monsanto.tps.materialweb.model;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

/**
 * Created with IntelliJ IDEA.
 * User: REHIGG
 * Date: 4/30/13
 * Time: 3:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class SearchCriteriaModel_UT {
    private SearchCriteriaModel testObject;

    @Test
    public void constructor() throws Exception {
        testObject = new SearchCriteriaModel("1", "A", "B", "C", "D");

        assertThat(testObject.getCropId(), is("1"));
        assertThat(testObject.getSearchType1(), is("A"));
        assertThat(testObject.getSearchValue1(), is("B"));
        assertThat(testObject.getSearchType2(), is("C"));
        assertThat(testObject.getSearchValue2(), is("D"));
    }

    @Test
    public void settersAndGetters() throws Exception {
        testObject = new SearchCriteriaModel();
        testObject.setCropId("2");
        testObject.setSearchType1("E");
        testObject.setSearchType2("F");
        testObject.setSearchValue1("G");
        testObject.setSearchValue2("H");

        assertThat(testObject.getCropId(), is("2"));
        assertThat(testObject.getSearchType1(), is("E"));
        assertThat(testObject.getSearchValue1(), is("G"));
        assertThat(testObject.getSearchType2(), is("F"));
        assertThat(testObject.getSearchValue2(), is("H"));
    }
}
