package com.monsanto.tps.materialweb.model;

import com.google.common.collect.Lists;
import org.junit.Test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

public class CropOptions_UT {
    private CropOptions testObject = new CropOptions();

    @Test
    public void testGettersAndSetters() {
        testObject.setAvailablePrograms(Lists.newArrayList("1z", "2x"));
        testObject.setVegetativeStructures(Lists.newArrayList("seed"));
        testObject.setSeedQuantityUoms(Lists.newArrayList("seed", "lb"));
        testObject.setTQRequiredCrop(true);

        assertThat(testObject.getSeedQuantityUoms(), hasItem("seed"));
        assertThat(testObject.getVegetativeStructures(), contains("seed"));
        assertThat(testObject.getAvailablePrograms(), hasItem("2x"));
        assertThat(testObject.getTQRequiredCrop(), is(true));
    }
}
