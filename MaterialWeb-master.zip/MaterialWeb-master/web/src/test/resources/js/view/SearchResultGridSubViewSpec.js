define(["jquery", "underscore", "view/ExportGridSubView", "view/SearchResultGridSubView",
    "model/SearchResultModel", "model/ExportModel", "common/error/MessageView",
    "view/grid/InventoryToolGridColumns",
    "view/grid/InventoryToolExportColumns",
    "model/GMIScreenPersistModel",
    "backbone",
    "lib/twitter/bootstrap/bootstrap-popover"],
    function ($, _, ExportGridSubView, SearchResultGridSubView, SearchResultModel, ExportModel, MessageView, GridColumns, ExportColumns, ScreenPersistModel, backbone) {
        describe("Search Result Grid Tool view", function () {
            var view,
                mockElement,
                mockSearchResultModel,
                mockSearchGridColumns,
                mockExportGridColumns,
                mockEventBus,
                mockExportModel,
                mockScreenPersistModel,
                mockOnSort,
                mockOnSubscribe,
                mockRow1,
                rootDiv;

            beforeEach(function () {
                mockElement = jasmine.createSpy();
                mockSearchResultModel = jasmine.createSpyObj("SearchResultModel", ["queryString", "materialInformation", "searchResultCount", "refreshGrid", "on", "get", "warning"]);
                mockExportModel = jasmine.createSpyObj("ExportModel", ["render", "pushRow"]);
                mockSearchGridColumns = new GridColumns();
                mockExportGridColumns = new ExportColumns();
                mockEventBus = jasmine.createSpyObj("backbone.Events", ["trigger"]);
                mockScreenPersistModel = new ScreenPersistModel();
                mockRow1 = jasmine.createSpyObj("MaterialInfo", ["batchNumber", "source"]);
                mockOnSort = {
                    subscribe:function (value, args) {
                    }
                };
                mockOnSubscribe = {
                    subscribe:function (value, args) {
                    }
                };
                rootDiv = $('<div id="mainView"><div id="searchResultGrid"></div><div id="contentView">' +
                    '<div id="importView"></div><a class="popover-search" rel="popover"></a></div></div>').appendTo($("body"));

                $('.popover-search').popover = jasmine.createSpy();

                view = new SearchResultGridSubView({el:mockElement,
                    model:mockSearchResultModel,
                    exportModel:mockExportModel,
                    searchGridColumns:mockSearchGridColumns,
                    exportGridColumns:mockExportGridColumns,
                    eventBus:mockEventBus,
                    screenPersistModel:mockScreenPersistModel
                });
            });

            afterEach(function () {
                rootDiv.remove();
            });

            it("SearchResultGridSubView render, with existing grid", function () {
                mockSearchResultModel.queryString.andReturn('AB');
                mockSearchResultModel.searchResultCount.andReturn('5');
                mockSearchResultModel.materialInformation.andReturn(['x', 'y']);
                var mockGrid = jasmine.createSpyObj("slick.Grid", ["setData", "updateRowCount", "render", "setSelectionModel", "registerPlugin", "setSelectedRows", "getSelectedRows", "getData", "onSort", "onSelectedRowsChanged", "destroy"]);
                mockGrid.onSelectedRowsChanged = (mockOnSubscribe);
                mockGrid.onSort = (mockOnSort);
                view.resultsGrid = mockGrid;

                view.render();

//                expect(mockGrid.setData).toHaveBeenCalled();
//                expect(mockGrid.updateRowCount).toHaveBeenCalled();
//                expect(mockGrid.render).toHaveBeenCalled();
//                expect(mockGrid.setSelectionModel).toHaveBeenCalled();
//                expect(mockGrid.registerPlugin).toHaveBeenCalled();
//                expect(mockGrid.setSelectedRows).toHaveBeenCalled();
            });

            it("SearchResultGridSubView refreshGrid", function () {
                var mockGrid = jasmine.createSpyObj("slick.Grid", ["destroy"]);
                view.resultsGrid = mockGrid;

                view.refreshGrid();

                expect(mockGrid.destroy).toHaveBeenCalled();
            });

            it("SearchResultGridSubView addSelectedMaterial, with selected data", function () {
                mockSearchResultModel.queryString.andReturn('AB');
                mockSearchResultModel.searchResultCount.andReturn('5');
                mockSearchResultModel.materialInformation.andReturn(['x', 'y']);
                var mockGrid = jasmine.createSpyObj("slick.Grid", ["render", "getSelectedRows", "getData", "setSelectedRows"]);
                mockGrid.getSelectedRows.andReturn(["0"]);
                mockGrid.getData.andReturn([mockRow1]);
                view.resultsGrid = mockGrid;
                view.dataView = {getItemByIdx: function(){}};
                spyOn(view.dataView, "getItemByIdx").andReturn({});

                view.addSelectedMaterial();

                expect(mockExportModel.pushRow).toHaveBeenCalled();
                expect(mockGrid.getSelectedRows).toHaveBeenCalled();
                //expect(mockGrid.getData).toHaveBeenCalled();
                expect(mockGrid.setSelectedRows).toHaveBeenCalled();
                expect(mockEventBus.trigger).toHaveBeenCalled();
            });

            it("SearchResultGridSubView change grid columns", function () {
                var mockGrid = jasmine.createSpyObj("slick.Grid", ["destroy"]);
                view.resultsGrid = mockGrid;

                view.refreshGrid();

                expect(mockGrid.destroy).toHaveBeenCalled();
            });
        });
    });
