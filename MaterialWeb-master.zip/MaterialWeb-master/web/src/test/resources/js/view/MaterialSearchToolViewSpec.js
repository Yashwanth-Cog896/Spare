define(["jquery", "underscore", "view/MaterialSearchToolView", "view/SearchResultGridSubView",
    "model/SearchResultModel", "model/CropsCollection", "validation/validateSearch", "common/error/MessageView", "common/util"],
    function ($, _, MaterialSearchToolView, SearchResultGridSubView, SearchResultModel, CropsCollection, Validator, MessageView, util) {
        describe("Material Search Tool View", function () {
            var view,
                mockElement,
                mockSearchResultGridSubView,
                mockSearchCriteriaSubView,
                mockExportGridSubView,
                mockEventBus;

            beforeEach(function () {
                mockElement = jasmine.createSpy();
                mockSearchResultGridSubView = jasmine.createSpyObj("SearchResultGridSubView", ["render", "setElement"]);
                mockSearchCriteriaSubView = jasmine.createSpyObj("SearchCriteriaSubView", ["render", "setElement"]);
                mockExportGridSubView = jasmine.createSpyObj("ExportGridSubView", ["render", "setElement"]);
                mockEventBus = jasmine.createSpyObj("backbone.Events", ["trigger", "on"]);

                view = new MaterialSearchToolView({el:mockElement,
                    searchResultGridSubView:mockSearchResultGridSubView,
                    searchCriteriaSubView:mockSearchCriteriaSubView,
                    exportGridSubView:mockExportGridSubView,
                    eventBus:mockEventBus
                });
            });

            it("MaterialSearchToolView render", function () {
                view.searchResultGridSubView.setElement.andReturn(mockSearchResultGridSubView);
                view.searchCriteriaSubView.setElement.andReturn(mockSearchCriteriaSubView);
                view.exportGridSubView.setElement.andReturn(mockExportGridSubView);

                view.render();

                expect(view.searchResultGridSubView.render).toHaveBeenCalledWith();
                expect(view.searchCriteriaSubView.render).toHaveBeenCalledWith();
                expect(view.exportGridSubView.render).toHaveBeenCalledWith();
            });
        });
    });
