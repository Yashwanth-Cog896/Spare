define(["jquery", "underscore", "view/SearchCriteriaSubView", "view/SearchResultGridSubView",
    "model/SearchResultModel", "model/CropsCollection", "validation/validateSearch", "common/error/MessageView", "common/util",
    "common/select/SelectUtils"
],
    function ($, _, SearchCriteriaSubView, SearchResultGridSubView, SearchResultModel, CropsCollection, Validator, MessageView, util, SelectUtils) {
        describe("Search Criteria Sub View", function () {
            var view,
                mockElement,
                mockSearchResultGridSubView,
                mockSearchResultModel,
                mockSelectUtil,
                mockEventBus,
                mockUtil,
                mockCropsCollection;

            beforeEach(function () {
                mockElement = jasmine.createSpy();
                mockSearchResultModel = jasmine.createSpyObj("SearchResultModel", ["load"]);
                mockCropsCollection = jasmine.createSpyObj("CropsCollection", ["fetch", "models"]);
                mockSelectUtil = jasmine.createSpyObj("SelectUtils", ["populateSelect"]);
                mockEventBus = jasmine.createSpyObj("backbone.Events", ["trigger", "on"]);

                view = new SearchCriteriaSubView({el:mockElement,
                    searchResultModel:mockSearchResultModel,
                    cropsCollection:mockCropsCollection,
                    eventBus:mockEventBus
                });

                mockUtil = jasmine.createSpyObj(view.util, ["urlParams"]);
                view.selectUtil = mockSelectUtil;
            });

            it("MaterialSearchToolView render with empty crops collection", function () {
                mockCropsCollection.models = [];
                view.util = {
                    urlParams:function () {
                        return {};
                    }
                };

                view.render();

                expect(mockCropsCollection.fetch).toHaveBeenCalled();
            });
            it("Search Criteria Sub render with existing crops collection", function () {
                mockCropsCollection.models = [1, 2, 3];
                view.render();

                expect(mockCropsCollection.fetch).not.toHaveBeenCalled();
            });
            it("Search Criteria Sub search material valid criteria", function () {
                spyOn(view.validator, "verifySearchCriteria").andReturn(true);

                view.searchMaterial();

                expect(mockSearchResultModel.load).toHaveBeenCalled();
            });
            it("Search Criteria Sub search material invalid criteria", function () {
                spyOn(view.validator, "verifySearchCriteria").andReturn(false);

                view.searchMaterial();

                expect(mockSearchResultModel.load).not.toHaveBeenCalled();
            });
            //Example of valid url parameters '/material-web/index.html?cropId=65667072&acronym=290345ys'  multiple parameters separated by spaces
            it("Search Criteria Sub load with valid parameters", function () {
                view.util = {
                    urlParams:function () {
                        return {cropId:2, acronym:'abc'};
                    }
                };
                mockCropsCollection.models = [];
//                spyOn(view.util, "urlParams");
                spyOn(view, "fetchUserCrops").andCallThrough();
                spyOn(view.validator, "verifySearchCriteria").andReturn(true);

                view.render();

                expect(view.fetchUserCrops).toHaveBeenCalledWith(2);
                expect(mockCropsCollection.fetch).toHaveBeenCalled();
            });
            //Example of valid url parameters '/material-web/index.html?cropId=65667072&acronym=290345ys'  multiple parameters separated by spaces
            it("Search Criteria Sub perform search if given cropId", function () {
                mockCropsCollection.models = [1, 2, 3];
                spyOn(view, "searchMaterial");
                view.selectUtil = mockSelectUtil;

                view.displayCrops("2");

                expect(mockSelectUtil.populateSelect).toHaveBeenCalled();
            });
            //Example of valid url parameters '/material-web/index.html?cropId=65667072&acronym=290345ys'  multiple parameters separated by spaces
            it("Search Criteria Sub does NOT perform search if no cropId parameter", function () {
                mockCropsCollection.models = [1, 2, 3];
                spyOn(view, "searchMaterial");
                view.selectUtil = mockSelectUtil;

                view.displayCrops();

                expect(view.selectUtil.populateSelect).toHaveBeenCalled();
            });
        });
    });
