define(["common/error/MessageView"],
    function (MessageView) {
        describe("MessageView", function () {
            var mockJGrowl,
                messageView;

            beforeEach(function () {
                mockJGrowl = jasmine.createSpy();
                messageView = new MessageView({
                    jGrowl:mockJGrowl
                });
            });

            function expectMessage(message, header, theme, sticky) {
                expect(mockJGrowl).toHaveBeenCalledWith(message, {
                    header:header,
                    theme:theme,
                    sticky:sticky
                });
            }

            function expectErrorMessage(message, header) {
                expectMessage(message, header, "error", true);
            }

            it("error displays message and header", function () {
                var message = "msg";
                var header = "header";
                messageView.error(message, header);

                expectErrorMessage(message, header);
            });

            it("produces an error callback for an ajax call", function () {
                var header = "header";
                var message = "message";
                messageView.errorCallback(header)(null, null, message);

                expectErrorMessage(message, header);
            });

            it("invokes additional callbacks on error", function () {
                var message = "message";
                var callback = jasmine.createSpy();
                messageView.errorCallback("", callback)(null, null, message);

                expect(callback).toHaveBeenCalledWith(null, null, message);
            });

            it("info message is non-sticky", function () {
                var header = "header";
                var message = "hello";
                messageView.info(message, header);

                expectMessage(message, header, "info", false);
            });
        });
    });
