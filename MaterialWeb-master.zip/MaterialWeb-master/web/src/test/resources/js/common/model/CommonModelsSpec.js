define(["jquery", "underscore", "common/model/CommonModels", "common/ticker/ModalProgress"],
    function ($, _, CommonModels, Progress) {
        describe("Common Models", function () {
            var selectModel;
            beforeEach(function () {
                selectModel = new CommonModels.SelectModel();
            });
            afterEach(function () {
//                selectModel.reset();
            });

            it("Common Model is Initially empty", function () {
                expect(_.isUndefined(selectModel.value())).toBe(true);
                expect(_.isUndefined(selectModel.description())).toBe(true);
            });
            it("Common Model assign values", function () {
                selectModel.set('id', 21);
                selectModel.set('name', 'desc1');

                expect(selectModel.value()).toBe(21);
                expect(selectModel.description()).toBe('desc1');
            });
        });
    });
