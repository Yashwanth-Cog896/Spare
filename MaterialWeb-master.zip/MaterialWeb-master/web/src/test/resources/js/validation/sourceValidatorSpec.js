define(["jquery", "underscore", "validation/sourceValidator"],
    function ($, _, SourceValidator) {
        describe("Source Validator", function () {

            it("Validate succeeds with average source", function () {
                var result = new SourceValidator('25Jun2013 abcd3ef');
                expect(result.valid).toBe(true);
            });

            it("Validate fails with ( in source", function () {
                var result = new SourceValidator('25Jun2013 (abcd3ef)');
                expect(result.valid).toBe(false);
            });

            it("Validate fails with ? in source", function () {
                var result = new SourceValidator('25Jun2013 ? abcd3ef');
                expect(result.valid).toBe(false);
            });

            it("Validate fails with * in source", function () {
                var result = new SourceValidator('25Jun2013 * abcd3ef');
                expect(result.valid).toBe(false);
            });

            it("Validate fails with ' in source", function () {
                var result = new SourceValidator('25Jun2013 \' abcd3ef');
                expect(result.valid).toBe(false);
            });

            it("Validate fails with ; in source", function () {
                var result = new SourceValidator('25Jun2013 ; abcd3ef');
                expect(result.valid).toBe(false);
            });

            it("Validate fails with ` in source", function () {
                var result = new SourceValidator('25Jun2013 ` abcd3ef');
                expect(result.valid).toBe(false);
            });

            //NOTE Ran into a 'quirk' with Dan's testing; a " copied from a Word document does not pass
            it("Validate passes with ~!@#$%^&_+[]{}:?,./<> in source", function () {
                var result = new SourceValidator('~!@#$%^&_+[]{}:?,./<>');
                expect(result.valid).toBe(false);
            });

        });
    });