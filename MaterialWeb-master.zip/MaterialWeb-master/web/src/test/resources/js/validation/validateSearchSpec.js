define(["jquery", "underscore", "validation/validateSearch", "common/error/MessageView"],
    function ($, _, ValidateSearch, MessageView) {
        describe("Validate Search", function () {
            var validator;
            var mockMessageView;
            beforeEach(function () {
                mockMessageView = jasmine.createSpyObj("MessageView", ["info"]);

                validator = new ValidateSearch({
                    messageView:mockMessageView
                });
            });

            it("Validate fails with no values 2", function () {
                expect(validator.verifySearchCriteria("", "", "")).toBe(false);
                expect(mockMessageView.info).toHaveBeenCalled();
            });
            it("Validate fails with no values 1", function () {
                expect(validator.verifySearchCriteria("", "", "")).toBe(false);
                expect(mockMessageView.info).toHaveBeenCalled();
            });
            it("Validate fails with crop and no values", function () {
                expect(validator.verifySearchCriteria("d", "", "")).toBe(false);
                expect(mockMessageView.info).toHaveBeenCalled();
            });
            it("Validate fails with no crop and value one", function () {
                expect(validator.verifySearchCriteria("", "a", "")).toBe(false);
                expect(mockMessageView.info).toHaveBeenCalled();
            });
            it("Validate fails with no crop and value two", function () {
                expect(validator.verifySearchCriteria("", "", "b")).toBe(false);
                expect(mockMessageView.info).toHaveBeenCalled();
            });
            it("Validate fails with no crop and two values", function () {
                expect(validator.verifySearchCriteria("", "a", "b")).toBe(false);
                expect(mockMessageView.info).toHaveBeenCalled();
            });
            it("Validate passes with crop and value one", function () {
                expect(validator.verifySearchCriteria("b", "d", "")).toBe(true);
                expect(mockMessageView.info).not.toHaveBeenCalled();
            });
            it("Validate passes with crop and value two", function () {
                expect(validator.verifySearchCriteria("a", "", "c")).toBe(true);
                expect(mockMessageView.info).not.toHaveBeenCalled();
            });
            it("Validate passes with crop and two values", function () {
                expect(validator.verifySearchCriteria("x", "a", "b")).toBe(true);
                expect(mockMessageView.info).not.toHaveBeenCalled();
            });
        });
    });