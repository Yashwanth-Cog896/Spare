define(["jquery", "underscore", "model/SearchCriteriaModel", "common/ticker/ModalProgress"],
    function ($, _, SearchCriteriaModel, Progress) {
        describe("Search Criteria Model", function () {
            var searchCriteriaModel;
            beforeEach(function () {
                searchCriteriaModel = new SearchCriteriaModel();
            });

            it("Search Criteria check initially settings", function () {
                expect(searchCriteriaModel.get('cropId')).toBe(0);
                expect(searchCriteriaModel.get('searchType1')).toBe(null);
                expect(searchCriteriaModel.get('searchType2')).toBe(null);
                expect(searchCriteriaModel.get('searchValue1')).toBe(null);
                expect(searchCriteriaModel.get('searchValue2')).toBe(null);
            });
            it("Search Criteria set values", function () {
                searchCriteriaModel.set('cropId', 5);
                searchCriteriaModel.set('searchType1', "t1");
                searchCriteriaModel.set('searchType2', "t2");
                searchCriteriaModel.set('searchValue1', "v1");
                searchCriteriaModel.set('searchValue2', "v2");

                expect(searchCriteriaModel.get('cropId')).toBe(5);
                expect(searchCriteriaModel.get('searchType1')).toBe("t1");
                expect(searchCriteriaModel.get('searchType2')).toBe("t2");
                expect(searchCriteriaModel.get('searchValue1')).toBe("v1");
                expect(searchCriteriaModel.get('searchValue2')).toBe("v2");
            });
        });
    });
