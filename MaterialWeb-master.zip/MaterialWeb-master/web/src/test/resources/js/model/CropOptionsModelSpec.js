define(["jquery", "underscore", "model/CropOptionsModel", "common/ticker/ModalProgress"],
    function ($, _, CropOptionsModel, Progress) {
        describe("Crop Options Model", function () {
            var cropOptionsModel;
            beforeEach(function () {
                cropOptionsModel = new CropOptionsModel();
            });
            it("Crop Options set cropId", function () {
                cropOptionsModel.cropId = 65601536;

                expect(cropOptionsModel.cropId).toBe(65601536);
            });
            it("Crops url string is valid", function () {

                expect(cropOptionsModel.url()).toContain("/material-services/services/rest/crop/referencedata?cropId=");
            });
            it("Crops test load", function () {
                spyOn(cropOptionsModel, 'fetch');
                spyOn(Progress, 'show');

                cropOptionsModel.load();

                expect(cropOptionsModel.fetch).toHaveBeenCalled();
                expect(Progress.show).toHaveBeenCalledWith("Loading Crop Reference Data");
            });
        });
    });
