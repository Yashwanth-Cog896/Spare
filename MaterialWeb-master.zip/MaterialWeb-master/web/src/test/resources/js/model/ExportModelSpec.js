define(["jquery", "underscore", "model/ExportModel"],
    function ($, _, ExportModel) {
        describe("Export Model", function () {
            var exportModel;
            beforeEach(function () {
                exportModel = new ExportModel();
            });
            afterEach(function () {
                exportModel.reset();
            });

            it("Export Model array is Initially empty", function () {
                expect(_.isEmpty(exportModel.allSavedMaterialInformation())).toBe(true);
            });
            it("Export Model push row", function () {
                var tst1 = "1st item";
                var tst2 = "2nd item";
                exportModel.pushRow(tst1);
                expect(exportModel.allSavedMaterialInformation()[0]).toBe(tst1);
            });
            it("Export Model push multiple rows", function () {
                var tst1 = "1st item";
                var tst2 = "2nd item";
                exportModel.pushRow(tst1);
                exportModel.pushRow(tst2);
                expect(exportModel.allSavedMaterialInformation()).toContain(tst1);
                expect(exportModel.allSavedMaterialInformation()).toContain(tst2);
                expect(exportModel.allSavedMaterialInformation().length).toBe(2);
            });
            it("Export Model pop multiple row1", function () {
                var tst1 = "1st item";
                var tst2 = "2nd item";
                var tst3 = "3rd item";
                exportModel.pushRow(tst1);
                exportModel.pushRow(tst2);
                exportModel.pushRow(tst3);
                exportModel.popRow(tst2);
                expect(exportModel.allSavedMaterialInformation()).toContain(tst1);
                expect(exportModel.allSavedMaterialInformation()).toContain(tst3);
                expect(exportModel.allSavedMaterialInformation().length).toBe(2);
            });
            it("Export Model reset empties array", function () {
                var tst1 = "1st item";
                var tst2 = "2nd item";
                exportModel.pushRow(tst1);
                exportModel.pushRow(tst2);
                exportModel.reset();
                expect(_.isEmpty(exportModel.allSavedMaterialInformation())).toBe(true);
            });
        });
    });
