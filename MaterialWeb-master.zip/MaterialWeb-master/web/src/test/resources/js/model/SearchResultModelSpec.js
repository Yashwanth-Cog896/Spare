define(["jquery", "underscore", "model/SearchResultModel", "common/ticker/ModalProgress"],
    function ($, _, SearchResultModel, Progress) {
        describe("Search Result Model", function () {
            var searchResultModel;
            beforeEach(function () {
                searchResultModel = new SearchResultModel();
            });
            afterEach(function () {
                searchResultModel.reset();
            });

            it("Search Result Count is Initially zero", function () {
                expect(searchResultModel.searchResultCount()).toBe(0);
            });
            it("Search Result materialInformation is accessable", function () {
                searchResultModel.set('materialInformation', "item1");

                expect(searchResultModel.materialInformation()).toBe("item1");
            });
            it("Search Result materialInformation is accessable", function () {
                searchResultModel.set('queryString', "string2");

                expect(searchResultModel.queryString()).toBe("string2");
            });
            it("Search Result searchResultCount is accessable", function () {
                searchResultModel.set('searchResultCount', "3");

                expect(searchResultModel.searchResultCount()).toBe("3");
            });
            it("Search Result reset clears data", function () {
                searchResultModel.set('materialInformation', "item1");
                searchResultModel.set('queryString', "string2");
                searchResultModel.set('searchResultCount', "4");
                searchResultModel.reset();

                expect(searchResultModel.searchResultCount()).toBe(0);
                expect(_.isEmpty(searchResultModel.materialInformation()));
                expect(searchResultModel.queryString()).toBe("");
            });
            it("Search Result test load", function () {
                spyOn(searchResultModel, 'save');
                spyOn(Progress, 'show');

                searchResultModel.load("c2", "sType1", "sValue1", "sType2", "sValue2", "load msg");

                expect(searchResultModel.save).toHaveBeenCalled();
                expect(Progress.show).toHaveBeenCalledWith("load msg");
            });
        });
    });
