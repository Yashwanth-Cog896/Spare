define(["jquery", "underscore", "model/CropsCollection", "common/ticker/ModalProgress"],
    function ($, _, CropsCollection, Progress) {
        describe("Crops Model", function () {
            var cropsCollection;
            beforeEach(function () {
                cropsCollection = new CropsCollection();
            });
            afterEach(function () {
                cropsCollection.reset();
            });
            it("Crops model is initally empty", function () {
                expect(_.isEmpty(cropsCollection.models)).toBe(true);
            });
            it("Crops url string is valid", function () {

                expect(cropsCollection.url()).toContain("/material-services/services/rest/crops/user");
            });
            it("Crops test load", function () {
                spyOn(cropsCollection, 'fetch');
                spyOn(Progress, 'show');

                cropsCollection.load();

                expect(cropsCollection.fetch).toHaveBeenCalled();
                expect(Progress.show).toHaveBeenCalledWith("Loading Crops");
            });
        });
    });
