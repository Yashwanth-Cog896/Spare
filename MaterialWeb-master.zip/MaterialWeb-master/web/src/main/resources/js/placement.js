define(["underscore", "jquery", "backbone", "lib/slick-grid/slick-grid", "lib/slick-grid/slick-core",
    "lib/slick-grid/slick-dataview",
    "lib/slick-grid/slick-rowselectionmodel",
    "lib/slick-grid/slick-checkboxselectcolumn",
    "tps/slick-grid/sort/gridSort",
    "export-util"],
    function (_, $, backbone, slick, core, view, rsm, csc, gridSort, exportUtil) {
        var options = {
            enableCellNavigation : true,
            editable : false,
            enableColumnReorder : false
        };
        var cols = [
            {id : "inventoryBarcode", name : "Barcode", field : "inventoryBarcode"},
            {id : "pedigree", name : "Pedigree", field : "pedigree"},
            {id : "source", name : "Source", field : "source"},
            {id : "season", name : "Season", field : "season"},
            {id : "setName", name : "Set", field : "setName"},
            {id : "setType", name : "Set Type", field : "setType"},
            {id : "repNumber", name : "Rep#", field : "repNumber", type : "Number"},
            {id : "locationName", name : "City", field : "locationName"},
            {id : "locationRefId", name : "Loc", field : "locationRefId"},
            {id : "fieldName", name : "Field", field : "fieldName"},
            {id : "trackId", name : "Track", field : "trackId"},
            {id : "fieldType", name : "Field Type", field : "fieldType"},
            {id : "entryNumber", name : "Entry#", field : "entryNumber", type : "Number"},
            {id : "plotBarcode", name : "Plot Barcode", field : "plotBarcode"},
            {id : "plotNumber", name : "Plot#", field : "plotNumber", type : "Number"},
            {id : "absRange", name : "Abs Range", field : "absRange", type : "Number"},
            {id : "absColumn", name : "Abs Column", field : "absColumn", type : "Number"}
        ];
        var columnDefaults = {
            sortable : true,
            type : "String"
        };

        var allColumns = _.map(cols, function(col) {
            return $.extend({}, columnDefaults, col);
        });

        var nonSecureColumns = _.filter(allColumns, function(col) {
            return col.id !== "pedigree" && col.id !== "source";
        });

        var hasSecureData = function (data) {
            return _.any(data, function(row) {
                return row.pedigree || row.source;
            });
        };

        var setupExport = function (gridCols, data) {
            $('#exportPlacementInfoGridBtn').click(function(event) {
                event.preventDefault();
                exportUtil.exportToExcel({"fileName" : "MaterialPlacementInfo", "sheetName" : "Plots", "backbone" : false, "columns" : gridCols, "rows": data});
            });
        };

        var render = function(data, barcodes) {
            if(_.isEmpty(data)) {
                $("#placementInfoGrid").html('<p class="muted"><i class="icon-info-sign"></i> No placement info found for ' + barcodes + '</p>');
                $('#exportPlacementInfoGridBtn').unbind('click');
                return;
            }

            var secureData = hasSecureData(data);
            var gridCols = secureData ? allColumns : nonSecureColumns;
            var grid = new slick.Grid("#placementInfoGrid", data, gridCols, options);
            grid.onSort.subscribe(function(event, options) {
                gridSort.sort(event, options);
                if(!options.sortAsc) {
                    grid.getData().reverse();
                }
                grid.invalidate();
                grid.render();
            });
            grid.render();
            setupExport(gridCols, data);
        };

        var search = function(barcodes) {
            $.getJSON(
                    "/material-services/services/rest/place/inventories?" + "barcodes=" + barcodes,
                    function(data) {
                        render(data, barcodes);
                    }
            );
        };

        return {
            search: search
        };
    });