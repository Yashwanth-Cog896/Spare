/*Material Search Tool View */
define(["underscore", "jquery", "backbone", "common/error/MessageView", "lib/twitter/bootstrap/bootstrap-collapse",
    "lib/backbone-modelbinding/ModelBinder", "common/model/CommonModels",
    "common/select/SelectUtils", "common/ticker/ModalProgress", "model/CropsCollection",
    "validation/validateSearch",
    "tps/security",
    "common/util"],
    function (_, $, backbone, MessageView, bootstrapCollapse, ModelBinder, commonModels, SelectUtils, Progress, CropsCollection, Validator, security, Utils) {
        var SearchCriteriaSubView;

        SearchCriteriaSubView = backbone.View.extend({
            initialize:function () {
                var self = this;
                self.el = self.options.el;
                self.html = self.options.html;
                self.eventBus = self.options.eventBus;
                self.searchResultModel = self.options.searchResultModel;
                self.cropsCollection = self.options.cropsCollection;  // for testing spec
                self.validator = self.options.validator;  // for testing spec
                self.util = Utils;
                self.selectUtil = SelectUtils;
                if (_.isUndefined(self.cropsCollection)) {
                    self.cropsCollection = new CropsCollection();
                }
                if (_.isUndefined(self.validator)) {
                    self.validator = new Validator();
                }
                $('#collapseCriteria').collapse('show');
            },
            reInitScreen:function () {
                var self = this;
                $('#materialSearchBtn').click(_.bind(self.searchMaterial, self));
                $('#clearSearchCriteriaBtn').click(_.bind(self.clearSearchCriteria, self));
                $(".popover-search").popover({trigger:"hover",
                        delay:{ show:100, hide:500 },
                        placement:"right",
                        html:"true",
                        animation:"true",
                        title:"Search Terms",
                        content:"<ul><li>Wildcard - Enter a search term followed by an asterick *. Only 1 wildcard per search field</li><li>Multiple Terms - Enter or copy and paste multiple terms into the text box</li><li>Make sure each term appears on a separate line.</li><li>Terms are case sensitive</li> </ul>"}
                );
            },
            render:function () {
                var self = this,
                    cropId = '';
                self.reInitScreen();
                if (_.isEmpty(self.cropsCollection.models)) {
                    cropId = self.checkUrlParameters();
                    self.fetchUserCrops(cropId);
                } else {
                    self.loadFromSearchResultModel();
                }
                return self;
            },
            loadFromSearchResultModel:function () {
                var self = this, value1, value2;
                self.displayCrops(self.searchResultModel.cropId);
                self.setSelector($('#type1Selector'), self.searchResultModel.searchType1);
                value1 = (self.searchResultModel.searchValue1 === "null") ? "" : self.searchResultModel.searchValue1;
                $('#field01').val(value1);
                self.setSelector($('#type2Selector'), self.searchResultModel.searchType2);
                value2 = (self.searchResultModel.searchValue2 === "null") ? "" : self.searchResultModel.searchValue2;
                $('#field02').val(value2);
            },
            fetchUserCrops:function (cropId) {
                var self = this;
                self.cropsCollection.fetch({
                    success:function (cropsCollection) {
                        if (_.isEmpty(cropsCollection.models)) {
                            var accessMessage = "Your current user profile is incomplete. Please contact TPS Application Support to complete your user setup." +
                                "<br>e-Mail: <b>SUPPORT, TECHNOLOGY PIPELINE [AG/1000]</b> <br>Phone: <b>1.888.711.7717, option 3</b>";
                            new MessageView().error(accessMessage);
                        } else {
                            self.displayCrops(cropId);
                        }
                    },
                    error:function () {
                        new MessageView().error("Error while loading Crops.");
                    }
                });
            },
            displayCrops:function (cropId) {
                var self = this;
                if (self.cropsCollection.length > 1) {
                    self.renderCrops();
                } else {
                    self.renderSingleCrop();
                }
                if (_.isEmpty(cropId) === false) {
                    self.setSelector($('#cropSelector'), cropId);
                }
            },
            renderSingleCrop:function () {
                var self = this;
                self.selectUtil.populateSelect($('#searchCriteriaSubView'), "[name='crop']", self.cropsCollection.models, {noSelectOne:true, disabled:false, emptyOption:false});
            },
            renderCrops:function () {
                var self = this;
                self.selectUtil.populateSelect($('#searchCriteriaSubView'), "[name='crop']", self.cropsCollection.models, {noSelectOne:true, disabled:false, emptyOption:true});
            },
            reload:function () {
                this.search("Searching");
            },
            searchMaterial:function () {
                var self = this,
                    cropName = $('#cropSelector option:selected').text(),
                    searchValue1 = $('#field01').val(),
                    searchValue2 = $('#field02').val();
                if (self.validator.verifySearchCriteria(cropName, searchValue1, searchValue2)) {
                    this.search("Searching for Inventory");
                }
            },
            clearSearchCriteria:function () {
                var self = this;
                $('#field01').val('');
                $('#field02').val('');
            },
            search:function (message) {
                var self = this;
                var cropId = $('#cropSelector option:selected').val(),
                    searchType1 = $('#type1Selector option:selected').val(),
                    searchType2 = $('#type2Selector option:selected').val(),
                    searchValue1 = _.isEmpty($('#field01').val()) ? "null" : $('#field01').val(),
                    searchValue2 = _.isEmpty($('#field02').val()) ? "null" : $('#field02').val();
                self.searchResultModel.load(cropId, searchType1, searchValue1, searchType2, searchValue2, message);
                self.showSearchResults();
                return true;
            },
            showSearchResults:function () {
                var self = this;
                self.eventBus.trigger('showSearchResults');
            },
            setSelector:function (selector, selectorValue) {
                selector.val(selectorValue);
                selector.trigger("liszt:updated");
            },
            checkUrlParameters:function () {
                var self = this,
                    cropId = self.util.urlParams().cropId,
                    batch = self.util.urlParams().batch,
                    materialnum = self.util.urlParams().materialnum,
                    acronym = self.util.urlParams().acronym,
                    linecode = self.util.urlParams().linecode,
                    origin = self.util.urlParams().origin,
                    precommercial = self.util.urlParams().precommercial,
                    commercial = self.util.urlParams().commercial,
                    manufacturing = self.util.urlParams().manufacturing;

                if (batch) {
                    self.setSelector($('#type1Selector'), 'Manufacturing Batch');
                    $('#field01').val(batch);
                } else if (materialnum) {
                    self.setSelector($('#type1Selector'), 'Manufacturing Material Number');
                    $('#field01').val(materialnum);
                } else if (acronym) {
                    self.setSelector($('#type1Selector'), 'Manufacturing Acronym');
                    $('#field01').val(acronym);
                }
                if (linecode) {
                    self.setSelector($('#type2Selector'), 'Line Code');
                    $('#field02').val(linecode);
                } else if (origin) {
                    self.setSelector($('#type2Selector'), 'Origin');
                    $('#field02').val(origin);
                } else if (precommercial) {
                    self.setSelector($('#type2Selector'), 'Precommercial Name');
                    $('#field02').val(precommercial);
                } else if (commercial) {
                    self.setSelector($('#type2Selector'), 'Commercial Name');
                    $('#field02').val(commercial);
                } else if (manufacturing) {
                    self.setSelector($('#type2Selector'), 'Manufacturing Name');
                    $('#field02').val(manufacturing);
                }
                return cropId;
            }
        });
        return SearchCriteriaSubView;
    });
