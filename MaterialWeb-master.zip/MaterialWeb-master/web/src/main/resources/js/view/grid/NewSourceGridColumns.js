define(["underscore", "jquery", "backbone",
    "common/grid/GridDataFormatter",
    "lib/slick-grid/slick-editors",
    "validation/sourceValidator",
    "common/grid/SelectEditor2",
    "export-util",
    "common/error/MessageView",
    "lib/slick-grid/slick-grid",
    "lib/slick-grid/slick-core",
    "lib/slick-grid/slick-dataview",
    "lib/slick-grid/slick-rowselectionmodel",
    "lib/slick-grid/slick-checkboxselectcolumn",
    "version!jquery-plugins/eventdrag[2.0]"],
    function (_, $, backbone, GridDataFormatter, editor, SourceValidator, SelectEditor2, exportUtil, messageView) {
        var cols = [
                {id:"germplasmPedigree", minWidth:200, name:"Germplasm Pedigree", field:"pedigree", sortable:true, editable:false, cssClass:'resultsText', headerCssClass:'resultsHeader'},
//                {id:"lineCode", minWidth:200, name:"Line Code", field:"lineCode", sortable:true, editable:false},
                {id:"germplasmOwner", minWidth:100, name:"Germplasm Owner", field:"germplasmOwner", sortable:true, editable:false},
                {id:"source", minWidth:120, name:"Source *", field:"source", sortable:true, validator:SourceValidator, editable:true},
                {id:"invProgram", minWidth:90, name:"Inv Program *", field:"program", sortable:true, editable:true, valueList:function (model) {
                    return model.get('validPrograms');
                }, editor:function (options) {
                    return new SelectEditor2(options);
                }},
                {id:"vegStructure", minWidth:100, name:"Veg Struct *", field:"vegStructure", sortable:true, editable:true, valueList:function (model) {
                    return model.get('validVegStructures');
                }, editor:function (options) {
                    return new SelectEditor2(options);
                }},
                {id:"tqExposure", minWidth:90, name:"Exposure History", field:"tqExposure", sortable:true, valueList:["T", "F", "U"], editable:true, editor:function (options) {
                    return new SelectEditor2(options);
                }},
                {id:"tqAllergen", minWidth:90, name:"Allergen Present", field:"tqAllergen", sortable:true, valueList:["T", "F", "U"], editable:true, editor:function (options) {
                    return new SelectEditor2(options);
                }},
                {id:"tqToxin", minWidth:90, name:"Toxin Present", field:"tqToxin", sortable:true, valueList:["T", "F", "U"], editable:true, editor:function (options) {
                    return new SelectEditor2(options);
                }},
                {id:"seedQuantity", minWidth:75, name:"Seed Quantity", field:"seedQuantity", sortable:true, editable:true, format:'0', type:'number'},
                {id:"seedQuantityUOM", minWidth:100, name:"Quantity UOM", field:"seedQuantityUOM", sortable:true, editable:true, valueList:function (model) {
                    return model.get('validUoms');
                }, editor:function (options) {
                    return new SelectEditor2(options);
                }},
                {id:"id", minWidth:50, name:"Remove", formatter:function (rowIndex, columnIndex, value, column, model) {
                    function formatButton(buttonText) {
                        return "<button type='button' class='btn collection-grid-button' id='deleteRowBtn' data-job-id='" + model.cid +
                            "'>" + "Remove" + "</button>";
//                            "'>" + "<i class='icon-trash'></i>" + "</button>";
                    }

                    return formatButton("Remove");
                }, sortable:false, editor:false}
            ],
            resultsCols = [
                {id:"germplasmPedigree", width:220, name:"Germplasm Pedigree", field:"pedigree", sortable:true, editable:false},
//                {id:"lineCode", width:220, name:"Line Code", field:"lineCode", sortable:true, editable:false},
                {id:"germplasmOwner", minWidth:100, name:"Germplasm Owner", field:"germplasmOwner", sortable:true, editable:false},
                {id:"source", width:120, name:"Source", field:"source", sortable:true, editable:false},
                {id:"invProgram", minWidth:90, name:"Inventory Owner", field:"program"},
                {id:"success", width:100, name:"Success", field:"success", sortable:true, editable:false},
                {id:"inventoryBID", width:220, name:"Inventory BID", field:"inventoryBID", sortable:true, editable:false},
                {id:"messages", width:220, name:"Messages", field:"messages", sortable:true, editable:false}
            ],
            exportCols = [
                {id:"germplasmPedigree", width:220, name:"Germplasm Pedigree", field:"pedigree"},
                {id:"source", width:120, name:"Source", field:"source"},
                {id:"invProgram", minWidth:90, name:"Inventory Owner", field:"program"},
                {id:"success", width:100, name:"Success", field:"success"},
                {id:"inventoryBID", width:220, name:"Inventory BID", field:"inventoryBID"},
                {id:"messages", width:220, name:"Messages", field:"messages"}
            ],
            confirmCols = [
                {id:"germplasmPedigree", width:220, name:"Germplasm Pedigree", field:"pedigree", sortable:true, editable:false},
                {id:"germplasmOwner", minWidth:100, name:"Germplasm Owner", field:"germplasmOwner", sortable:true, editable:false},
                {id:"source", width:120, name:"Source", field:"source", sortable:true, editable:false},
                {id:"invProgram", minWidth:90, name:"Inventory Owner", field:"program"},
                {id:"tqExposure", width:90, name:"Exposure History", field:"tqExposure", sortable:true, editable:false},
                {id:"tqAllergen", width:90, name:"Allergen Present", field:"tqAllergen", sortable:true, editable:false},
                {id:"tqToxin", width:90, name:"Toxin Present", field:"tqToxin", sortable:true, editable:false},
                {id:"tqMiniChromosome", width:90, name:"Mini Chromosome Present", field:"tqMiniChromosome", sortable:true, editable:false},
                {id:"tqAnimalGene", width:90, name:"Animal Gene Present", field:"tqAnimalGene", sortable:true, editable:false}
            ],
            confirmMessageCol = [
                {id:"tqMessages", width:320, name:"Messages", field:"tqMessages", sortable:true, editable:false}
            ]
        options = {
            selection:"none",
            autoResize:true,
            toolbar:true
        };

        function NewSourceGridColumns(options) {
            var self = this;
            _.extend(self, options);
        }

        var prototype = NewSourceGridColumns.prototype;

        prototype.getOptions = function () {
            return options;
        };
        prototype.getColumns = function () {
            var columns = [];
            return columns.concat(cols);
        };
        prototype.getResultsColumns = function () {
            var columns = [];
            return columns.concat(resultsCols);
        };
        prototype.getConfirmColumns = function () {
            var columns = [];
            return columns.concat(confirmCols);
        };
        prototype.getConfirmMessageColumns = function () {
            var columns = [];
            return columns.concat(confirmMessageCol, confirmCols);
        };

        prototype.exportResults = function (data) {
            if (_.isEmpty(data)) {
                messageView.info("No results to export.");
            } else {
                exportUtil.exportToExcel({"fileName":"NewSourceCreation_Results", "sheetName":"New Source Results", "backbone":true, "columns":exportCols, "rows":data.models});
            }
        };
        return NewSourceGridColumns;

    });

