/*Material Search Tool View */
define(["underscore", "jquery", "backbone", "common/error/MessageView", "lib/twitter/bootstrap/bootstrap-collapse",
    "lib/backbone-modelbinding/ModelBinder", "common/model/CommonModels",
    "common/ticker/ModalProgress",
    "validation/validateSearch",
    "tps/security"
],
    function (_, $, backbone, MessageView, bootstrapCollapse, ModelBinder, commonModels, Progress, Validator, security) {
        var MaterialSearchToolView;

        MaterialSearchToolView = backbone.View.extend({
            initialize:function () {
                var self = this;
                security.localUserSettings.enableInWinEnvironment();
                self.el = self.options.el;
                self.html = self.options.html;
                self.searchResultGridSubView = self.options.searchResultGridSubView;
                self.eventBus = self.options.eventBus;
                self.searchCriteriaSubView = self.options.searchCriteriaSubView;
                self.exportGridSubView = self.options.exportGridSubView;
                self.initEvents();
            },
            initEvents:function () {
                var self = this;
                self.eventBus.on('showSearchResults', _.bind(self.onShowSearchResults, self));
                self.eventBus.on('showImportList', _.bind(self.onShowImportList, self));
            },
            render:function () {
                var self = this;
                self.$el.html(self.html);
                self.assign(self.searchCriteriaSubView, 'searchCriteriaView');
                self.assign(self.searchResultGridSubView, 'resultsTab');
                self.assign(self.exportGridSubView, 'importTab');
                return self;
            },
            assign:function (view, section) {
                view.setElement($(section)).render();
            },
            onShowSearchResults:function () {
                var self = this;
                self.searchResultGridSubView.showResults();
                self.searchResultGridSubView.render();
            },
            onShowImportList:function () {
                var self = this;
                self.exportGridSubView.showImportList();
                self.exportGridSubView.render();
            },
            resetData:function () {
                var self = this;
                self.searchResultGridSubView.reInitEvents();
                self.searchResultGridSubView.resetOptions();
                self.searchResultGridSubView.refreshGrid();
                self.exportGridSubView.reInitEvents();
                self.exportGridSubView.refreshGrid();
            }
        });
        return MaterialSearchToolView;
    });
