define(["underscore", "jquery", "backbone", "common/error/MessageView", "lib/twitter/bootstrap/bootstrap-collapse",
    "lib/backbone-modelbinding/ModelBinder", "common/model/CommonModels",
    "common/select/SelectUtils", "common/ticker/ModalProgress", "model/CropsCollection",
    "validation/validateSearch",
    "tps/security",
    "common/util",
    "tps/collection-grid/CollectionGrid",
    "require",
    "model/CropOptionsModel",
    "model/NewSourceModel",
    "jquery-plugins/select2",
    "bootbox"],
    function (_, $, backbone, MessageView, bootstrapCollapse, ModelBinder, commonModels, SelectUtils, Progress, CropsCollection, Validator, security, Utils, CollectionGrid, require, CropOptionsModel, NewSourceModel, select2, bootbox) {
        var CreateSourceView;

        CreateSourceView = backbone.View.extend({
            events:{
//                'click #materialSearchBtn':'searchMaterial',
//                'click #clearSearchCriteriaBtn':'clearSearchCriteria'
            },
            initialize:function () {
                var self = this;
                self.el = self.options.el;
                self.html = self.options.html;
                self.eventBus = self.options.eventBus;
                self.newSourceModel = self.options.newSourceModel;
                self.newSourceGridColumns = self.options.newSourceGridColumns;
                self.newSourcesCollection = self.options.newSourcesCollection;
                self.createResultsModel = self.options.createResultsModel;
                self.cropOptionsMap = new backbone.Model();
                self.eventBus.on('cropOptionsLoaded', _.bind(self.loadNewSourcesWithCropOptions, self));
                self.eventBus.on('displayNewSourceResults', _.bind(self.displayResults, self));
                self.resultsCollection = new backbone.Collection();
            },
            reinitEvents:function () {
                var self = this;
                $('#createSourcesBtn').click(_.bind(self.confirmCreate, self));
                $('#confirmCreateBtn').click(_.bind(self.createNewSources, self));
                $('#backToSearchBtn').click(_.bind(self.backToSearch, self));
                $('#backToSearchHref').click(_.bind(self.backToSearch, self));
                $('#autoPopulateBtn').click(_.bind(self.showAutoPopulate, self));
                $('#applyAutoPopulateBtn').click(_.bind(self.applyAutoPopulate, self));
                $('#exportResultsBtn').click(_.bind(self.exportResults, self));
                $("#autoPopulateBtn").popover({trigger:"hover",
                        delay:{ show:100, hide:500 },
                        placement:"right",
                        html:"true",
                        animation:"true",
                        title:"Autopopulate",
                        content:"Autopopulate allows you to fill all rows with default values for Inventory Program, Vegetative Structure and/or Seed Quantity UOM."}
                );
            },
            initializeGridButtons:function () {
                var self = this;
                $("#createSourceGrid").on("mouseup", "button.collection-grid-button", self, function (event) {
                    var id = $(event.target).attr("data-job-id"),
                        self = event.data;
                    self.deleteNewSource(id);
                });
            },
            render:function () {
                var self = this;
                self.el.html(self.html);
                self.reinitEvents();
                self.buildDummyNewSource();
                self.getCropDefaults();
                self.buildNewSourceTable();
                return self;
            },
            buildDummyNewSource:function () {
                var self = this;
                if (_.isEmpty(self.newSourcesCollection.toArray())) {
                    var testItem = new NewSourceModel(),
                        item = {
                            pedigree:"test",
                            id:-3,
                            cropId:65601536
                        };
                    testItem.setRow(item);
                    self.newSourcesCollection.push(testItem);
                }
            },
            getCropDefaults:function () {
                var self = this;
                _.each(self.newSourcesCollection.models, function (obj) {
                    var cropId = obj.get('cropId'),
                        cropOptionModel = self.cropOptionsMap.get(cropId);
                    if (_.isUndefined(cropOptionModel)) {
                        cropOptionModel = new CropOptionsModel();
                        cropOptionModel.eventBus = self.eventBus;
                        cropOptionModel.set("cropId", cropId);
                        cropOptionModel.load();
                        self.cropOptionsMap.set(cropId, cropOptionModel);
                    } else {
                        self.loadNewSourcesWithCropOptions();
                    }
                });
            },
            loadNewSourcesWithCropOptions:function () {
                var self = this;
                _.each(self.newSourcesCollection.models, function (obj) {
                    var cropId = obj.get('cropId'),
                        cropOptionModel = self.cropOptionsMap.get(cropId);
                    if (_.isObject(cropOptionModel)) {
                        obj.setRowOptions(cropOptionModel);
                    }
                });
            },
            buildNewSourceTable:function () {
                var self = this;
                var $grid = $('#createSourceGrid').
                    css({
                        height:'300px',
                        width:'98%',
                        position:"relative",
                        left:0,
                        top:0,
                        bottom:0,
                        right:0,
                        overflow:'scroll',
                        font:'8px'
                    });
                var dependencies = {
                    collection:self.newSourcesCollection,
                    columns:self.newSourceGridColumns.getColumns(),
                    $el:$grid
                };
                //noinspection JSUnusedLocalSymbols
                self.newSourcesGrid = new CollectionGrid(dependencies, self.newSourceGridColumns.getOptions());
                self.initializeGridButtons();
            },
            deleteNewSource:function (id) {
                var self = this;
                $.each(self.newSourcesCollection.toArray(), function () {
                    if (this.cid === id) {
                        self.newSourcesCollection.remove(this);
                    }
                });
            },
            createNewSources:function () {
                var self = this,
                    itemsToSend = self.newSourcesCollection.toArray();
                $('#confirmCreateModal').modal('hide');
                self.resultsCollection = new backbone.Collection();
                _.each(self.newSourcesCollection.models, function (obj) {
                    self.resultsCollection.push(obj);
                });
                if (!_.isEmpty(itemsToSend)) {
                    self.createResultsModel.createSources(itemsToSend, "Creating Sources");
                } else {
                    bootbox.alert("No sources to Send");
                }
            },
            clearResults:function () {
                var self = this;
                self.newSourcesCollection.reset();
                if (!_.isUndefined(self.confirmGrid)) {
                    self.confirmGrid.destroy();
                    $('#confirmCreateGrid').replaceAll('<br/>');
                    self.confirmGrid = undefined;
                }
                if (!_.isUndefined(self.resultsGrid)) {
                    self.resultsGrid.destroy();
                    $('#newSourceResultsGrid').replaceAll('<br/>');
                    self.resultsGrid = undefined;
                }
            },
            backToSearch:function () {
                var self = this;
                self.clearResults();
                self.eventBus.trigger('searchScreen');
            },
            displayResults:function () {
                var self = this;
                self.buildResultsGrid();
                self.setResultsMessage();
                $('#resultsModal').modal('show');
            },
            setResultsMessage:function () {
                var self = this,
                    success = true;
                $.each(self.resultsCollection.toArray(), function () {
                    if (!this.get('success')) {
                        success = false;
                    }
                });
                if (success) {
                    $('#resultsMessage').html("The following inventories <strong>have been created</strong> in Midas from the records listed below:");
                } else {
                    $('#resultsMessage').html("Inventories have <strong>NOT</strong> been created due to the error(s) listed below:");
                }
            },
            buildResultsGrid:function () {
                var self = this;
                if (_.isUndefined(self.resultsGrid)) {
                    var $resultsGrid = $('#newSourceResultsGrid').
                        css({
                            height:'300px',
                            width:'98%',
                            position:"relative",
                            left:0,
                            top:0,
                            bottom:0,
                            right:0,
                            overflow:'scroll'
                        });
                    var dependencies = {
                        collection:self.resultsCollection,
                        columns:self.newSourceGridColumns.getResultsColumns(),
                        $el:$resultsGrid
                    };
                    //noinspection JSUnusedLocalSymbols
                    self.resultsGrid = new CollectionGrid(dependencies, self.newSourceGridColumns.getOptions());
                }
            },
            exportResults:function () {
                var self = this;
                self.newSourceGridColumns.exportResults(self.resultsCollection);
            },
            showAutoPopulate:function () {
                var self = this,
                    obj = _.first(self.newSourcesCollection.models);
                var cropId = obj.get('cropId'),
                    cropOptionModel = self.cropOptionsMap.get(cropId);
                $("#invProgram").select2({
                    closeOnSelect:true,
                    minimumInputLength:0,
                    data:self.buildSelect2Array(cropOptionModel.get('availablePrograms'))
                });
                $("#vegStructure").select2({
                    closeOnSelect:true,
                    minimumInputLength:0,
                    data:self.buildSelect2Array(cropOptionModel.get('vegetativeStructures'))
                });
                $("#quantityUOM").select2({
                    closeOnSelect:true,
                    minimumInputLength:0,
                    data:self.buildSelect2Array(cropOptionModel.get('seedQuantityUoms'))
                });
                $('#autoPopulateModal').modal('show');
            },
            buildSelect2Array:function (items) {
                var self = this,
                    array = [];
                $.each(items, function () {
                    array.push({id:this, text:this});
                });
                return array;
            },
            applyAutoPopulate:function () {
                var self = this,
                    program = $("#invProgram").select2('val'),
                    vegStructure = $("#vegStructure").select2('val'),
                    uom = $("#quantityUOM").select2('val');
                if (_.isString(program)) {
                    self.setCollectionValues('inventoryProgram', program);
                    self.setCollectionValues('program', program);
                }
                if (_.isString(vegStructure)) {
                    self.setCollectionValues('vegStructure', vegStructure);
                }
                if (_.isString(uom)) {
                    self.setCollectionValues('seedQuantityUOM', uom);
                }
                $('#autoPopulateModal').modal('hide');
                self.render();
            },
            setCollectionValues:function (propertyName, value) {
                var self = this;
                _.each(self.newSourcesCollection.models, function (obj) {
                    obj.set(propertyName, value);
                });
            },
            confirmCreate:function () {
                var self = this,
                    itemsToSend = self.newSourcesCollection.models,
                    showTQCategory1Warning = false,
                    foundError = false;
                _.each(itemsToSend, function (obj) {
                    obj.set('tqMessages', '');     //Note this depends upon this occuring first, it will clear exising messages.
                    if (obj.get('isTQRequired')) {
                        var isCat1Msg = self.checkForCategory1(obj);
                        if (isCat1Msg !== '') {
                            showTQCategory1Warning = true;
                            obj.set('tqMessages', 'Inventory will be assigned Category 1. ' + isCat1Msg);
                        }
                    }
                });
                foundError = self.checkForRequiredFields(itemsToSend);
                if (showTQCategory1Warning) {
                    $('#confirmWarningText').fadeIn();
                    foundError = true;
                } else {
                    $('#confirmWarningText').fadeOut();
                }
                self.buildConfirmGrid(foundError);
                $('#confirmCreateModal').modal('show');
            },
            checkForRequiredFields:function (items) {
                var self,
                    errorFound = false,
                    sourceNames = [];
                _.each(items, function (obj) {
                    var msg = obj.get('tqMessages');
                    if (_.isUndefined(obj.get('program')) || obj.get('program') === '') {
                        errorFound = true;
                        msg = msg + 'Inventory Program required. ';
                        obj.set('tqMessages', msg);
                    }
                    if (_.isUndefined(obj.get('source')) || obj.get('source') === '') {
                        errorFound = true;
                        msg = msg + 'Source name required. ';
                        obj.set('tqMessages', msg);
                    }
                    if ($.inArray(obj.get('source'), sourceNames) >= 0) {
                        errorFound = true;
                        msg = msg + 'Source name is already used. ';
                        obj.set('tqMessages', msg);
                    } else {
                        sourceNames.push(obj.get('source'));
                    }
                });
                return errorFound;
            },
            checkForCategory1:function (rowData) {
                var self = this,
                    tqMessage = rowData.get('tqMessages'),
                    tqExposure = rowData.get('tqExposure'),
                    tqToxin = rowData.get('tqToxin'),
                    tqAllergen = rowData.get('tqAllergen'),
                    tqAnimalGene = rowData.get('tqAnimalGene'),
                    tqMiniChromosome = rowData.get('tqMiniChromosome');
                if (tqAllergen === 'T') {
                    tqMessage = tqMessage + 'Allergens are present. ';
                } else if (tqAllergen === 'U') {
                    tqMessage = tqMessage + 'Allergens are unknown. ';
                } else if (_.isUndefined(tqAllergen) || tqAllergen === '') {
                    tqMessage = tqMessage + 'Allergen Present answer required. ';
                }
                if (tqToxin === 'T') {
                    tqMessage = tqMessage + 'Toxins are present. ';
                } else if (tqToxin === 'U') {
                    tqMessage = tqMessage + 'Toxins are unknown. ';
                } else if (_.isUndefined(tqToxin) || tqToxin === '') {
                    tqMessage = tqMessage + 'Toxin Present answer required. ';
                }
                if (tqAnimalGene === 'T') {
                    tqMessage = tqMessage + 'Animal Genes are present. ';
                } else if (tqAnimalGene === 'U') {
                    tqMessage = tqMessage + 'Animal Genes are unknown. ';
                }
                if (tqMiniChromosome === 'T') {
                    tqMessage = tqMessage + 'Mini Chromosome are present. ';
                } else if (tqMiniChromosome === 'U') {
                    tqMessage = tqMessage + 'Mini Chromosome are unknown. ';
                }
                if (tqExposure === 'F') {
                    tqMessage = tqMessage + 'Exposure is false. ';
                } else if (tqExposure === 'U') {
                    tqMessage = tqMessage + 'Exposure is unknown. ';
                } else if (_.isUndefined(tqExposure) || tqExposure === '') {
                    tqMessage = tqMessage + 'Exposure History answer required. ';
                }
                if (_.isUndefined(tqMessage)) {
                    tqMessage = '';
                }
                return tqMessage;
            },
            buildConfirmGrid:function (showTQCategory1Warning) {
                var self = this;
                if (_.isUndefined(self.confirmGrid)) {
                    var $confirmGrid = $('#confirmCreateGrid').
                        css({
                            height:'180px',
                            width:'98%',
                            position:"relative",
                            left:0,
                            top:0,
                            bottom:0,
                            right:0,
                            overflow:'scroll'
                        });
                    var columns = self.newSourceGridColumns.getConfirmColumns();
                    if (showTQCategory1Warning) {
                        columns = self.newSourceGridColumns.getConfirmMessageColumns();
                    }
                    var dependencies = {
                        collection:self.newSourcesCollection,
                        columns:columns,
                        $el:$confirmGrid
                    };
                    //noinspection JSUnusedLocalSymbols
                    self.confirmGrid = new CollectionGrid(dependencies, self.newSourceGridColumns.getOptions());
                }
            }
        });
        return CreateSourceView;
    });
