define(["underscore", "jquery", "backbone", "lib/slick-grid/slick-grid",
    "tps/appcontext/requiredDependency",
    "jquery-plugins/select2",
    "model/NewSourceModel",
    "lib/slick-grid/slick-core",
    "lib/slick-grid/slick-dataview",
    "lib/slick-grid/slick-rowselectionmodel",
    "lib/slick-grid/slick-checkboxselectcolumn",
    "version!jquery-plugins/eventdrag[2.0]"],
    function (_, $, backbone, slick, requiredDependency, select2, NewSourceModel) {
        var ExportGridSubView,
            exportGrid,
            exportSelector = new slick.CheckboxSelectColumn(),
            exportOptions = {
                enableCellNavigation:true,
                enableTextSelectionOnCells:true,
                enableColumnReorder:false,
                editable:true
            };
        ExportGridSubView = backbone.View.extend({
            initialize:function () {
                var self = this;
                self.el = self.options.el;
                self.model = self.options.model;
                self.eventBus = self.options.eventBus;
                self.model.on("refreshGrid", self.refreshGrid, self);
                self.model.on("renderGrid", self.render, self);
                self.gridColumns = self.options.searchGridColumns;
                self.exportColumns = self.options.exportGridColumns;
                self.screenPersistModel = self.options.screenPersistModel;
                self.newSourcesCollection = self.options.newSourcesCollection;
            },
            reInitEvents:function () {
                var self = this;
                $('#exportDeleteBtn').click(_.bind(self.deleteExportItem, self));
                $('#commercialExport').click(_.bind(self.commercialExport, self));
                $('#competitorExport').click(_.bind(self.competitorExport, self));
                $('#finishedExport').click(_.bind(self.finishedExport, self));
                $('#hybridExport').click(_.bind(self.hybridExport, self));
                $('#resultsViewOptions').change(_.bind(self.refreshGrid, self));
                $('#createNewSourcesBtn').click(_.bind(self.gotoNewSourcesPage, self));
            },
            refreshGrid:function () {
                var self = this;
                self.resetGrid();
                self.render();
            },
            resetGrid:function () {
                var self = this;
                if (self.exportGrid) {
                    self.exportGrid.destroy();
                }
                self.exportGrid = null;
            },
            isShowTQColumnsSelected:function () {
                var self = this;
                var selectedOptions = $('#resultsViewOptions').val();
                return _.contains(selectedOptions, 'showTQCols');
            },
            render:function () {
                var self = this,
                    data = _.isEmpty(self.model.allSavedMaterialInformation()) ? [] : self.model.allSavedMaterialInformation(),
                    size = _.isEmpty(data) ? 0 : _.size(data),
                    header = '(' + size + ')';
                $('#exportResultHeader').text(header);
                self.showImportList();
                self.resetGrid();
                var dataWrapper = new slick.Data.DataView();
                self.dataView = dataWrapper;
                for (var i = 0; i < data.length; i++) {  // data.id is not unique (or maybe the query is wrong?)
                    data[i].gridRowId = i;
                }
                dataWrapper.setItems(data, "gridRowId");

                self.exportGrid = new slick.Grid("#exportGrid", dataWrapper, self.gridColumns.getColumnsWithInput(self.isShowTQColumnsSelected(), exportSelector), exportOptions);
                self.setupValidation();
                self.exportGrid.updateRowCount();
                self.exportGrid.resizeCanvas();
                self.exportGrid.render();
                self.exportGrid.setSelectionModel(new slick.RowSelectionModel({selectActiveRow:false}));
                self.exportGrid.registerPlugin(exportSelector);
                self.exportGrid.setSelectedRows([]);

                dataWrapper.syncGridSelection(self.exportGrid, true);
                dataWrapper.onRowCountChanged.subscribe(function (e, args) {
                    self.exportGrid.updateRowCount();
                    self.exportGrid.render();
                });
                dataWrapper.onRowsChanged.subscribe(function (e, args) {
                    self.exportGrid.invalidateRows(args.rows);
                    self.exportGrid.render();
                });

                self.checkBoxChecked();
                self.exportGrid.onSelectedRowsChanged.subscribe(function (e, args) {
                    self.checkBoxChecked();
                });
                self.exportGrid.onSort.subscribe(function(e, args) {
                    var sortFunc = function (dataRow1, dataRow2) {
                        var field = args.sortCol.field,
                            sign = args.sortAsc ? 1 : -1,
                            value1 = dataRow1[field],
                            value2 = dataRow2[field],
                            result = (value1 === value2 ? 0 : (value1 > value2 ? 1 : -1)) * sign;
                        if (result !== 0) {
                            return result;
                        }
                        return 0;
                    };
                    dataWrapper.sort(sortFunc, true);
                });
            },
            checkBoxChecked:function () {
                var self = this,
                    selectedRows = self.exportGrid.getSelectedRows();
                if (_.isUndefined(selectedRows) || $.isEmptyObject(selectedRows)) {
                    $('#exportDeleteBtn').attr('disabled', 'disabled');
                    $('#commercialExport').attr('disabled', 'disabled');
                    $('#competitorExport').attr('disabled', 'disabled');
                    $('#finishedExport').attr('disabled', 'disabled');
                    $('#hybridExport').attr('disabled', 'disabled');
                    $('#materialExportBtn').attr('disabled', 'disabled');
                    $('#createNewSourcesBtn').attr('disabled', 'disabled');
                } else {
                    $('#exportDeleteBtn').removeAttr('disabled');
                    $('#commercialExport').removeAttr('disabled');
                    $('#competitorExport').removeAttr('disabled');
                    $('#finishedExport').removeAttr('disabled');
                    $('#hybridExport').removeAttr('disabled');
                    $('#materialExportBtn').removeAttr('disabled');
                    $('#createNewSourcesBtn').removeAttr('disabled');
                }
            },
            deleteExportItem:function () {
                var self = this,
                    selected = self.exportGrid.getSelectedRows();
                $.each(selected, function () {
                    var selectedRow = self.dataView.getItemByIdx(this);
                    self.model.popRow(selectedRow);
                });
                self.exportGrid.setSelectedRows([]);
                self.render();
            },
            gotoNewSourcesPage:function () {
                var self = this,
                    selected = self.exportGrid.getSelectedRows();
                $.each(selected, function () {
                    var selectedRow = self.dataView.getItemByIdx(this),
                        newSourceModel = new NewSourceModel();
                    self.model.popRow(selectedRow);
                    newSourceModel.setRow(selectedRow);
                    self.newSourcesCollection.push(newSourceModel);
                });
                self.eventBus.trigger('createSources');

            },
            getExportData:function () {
                var self = this,
                    selected = self.exportGrid.getSelectedRows(),
                    exportInformation = [];
                $.each(selected, function () {
                    var selectedRow = self.dataView.getItemByIdx(this);
                    exportInformation.push(selectedRow);
                });
                return exportInformation;
            },
            commercialExport:function () {
                var self = this;
                self.exportColumns.commercialExport(self.getExportData());
            },
            competitorExport:function () {
                var self = this;
                self.exportColumns.competitorExport(self.getExportData());
            },
            finishedExport:function () {
                var self = this;
                self.exportColumns.finishedExport(self.getExportData());
            },
            hybridExport:function () {
                var self = this;
                self.exportColumns.hybridExport(self.getExportData());
            },
            setupValidation:function () {
                var self = this;
                self.exportGrid.onValidationError.subscribe(function (e, args) {
                    var validationResult = args.validationResults;
                    var activeCellNode = args.cellNode;
                    var errorMessage = validationResult.msg;
                    var cellNode = $(activeCellNode);
                    var popOver = cellNode.data('popover');
                    if (popOver) {
                        popOver.options.content = errorMessage;
                    } else {
                        cellNode.popover({animation:true, trigger:'manual', content:errorMessage, title:'Invalid'});
                    }
                    cellNode.popover('show');
                    _.delay(function () {
                        cellNode.popover('hide');
                    }, 3000);
                });
            },
            showImportList:function () {
                var self = this;
                if (_.isEmpty(self.model.allSavedMaterialInformation()) === false) {
                    $('#importView').show();
                    $('#noImports').hide();
                    $('#collapseImports').collapse('show');
                }
            }
        });

        return ExportGridSubView;
    });