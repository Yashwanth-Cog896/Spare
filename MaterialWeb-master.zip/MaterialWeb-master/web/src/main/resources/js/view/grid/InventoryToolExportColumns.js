define(["underscore", "jquery", "backbone",
    "common/grid/GridDataFormatter",
    "export-util",
    "common/error/MessageView",
    "lib/slick-grid/slick-grid",
    "lib/slick-grid/slick-core",
    "lib/slick-grid/slick-dataview",
    "lib/slick-grid/slick-rowselectionmodel",
    "lib/slick-grid/slick-checkboxselectcolumn",
    "version!jquery-plugins/eventdrag[2.0]"],
    function (_, $, backbone, GridDataFormatter, exportUtil, MessageView) {
        var commercialCols = [
                {id:"midasCommercialName", name:"Product Name", field:"midasCommercialName", width:"150"},
                {id:"origin", name:"Origin or Line Code", field:"origin", width:"150"},
                {id:"lineType", name:"Line Type", field:"lineType", width:"100"},
                {id:"source", name:"Source", field:"source", width:"200"},
                {id:"inventoryOwner", name:"Inventory Owner", field:""},
                {id:"vegetativeStructure", name:"Vegetative Structure", field:"vegetativeStructure"},
                {id:"lineFunction", name:"Line Function", field:"lineFunction", width:"150"},
                {id:"pedigree", name:"Cytoplasm Donor Pedigree", field:"pedigree", width:"100"},
                {id:"midasCommercialBrandName", name:"Brand Name", field:"midasCommercialBrandName", width:"100"},
                {id:"transgenic", name:"Transgenic?", field:"transgenic", width:"100"},
                {id:"batchNumber", name:"Manufacturing Batch #?", field:"batchNumber", width:"150"},
                {id:"materialNumber", name:"Manufacturing Material #?", field:"materialNumber", width:"150"},
                {id:"royalty", name:"Royalty", field:"", width:"75"},
                {id:"company", name:"Company", field:"", width:"100"},
                {id:"externalGermplasm", name:"External Germplasm Name", field:"", width:"100"},
                {id:"seedQuantity", name:"Seed Quantity", field:"", width:"100"},
                {id:"seedQuantityUOM", name:"Seed Quantity_UOM", field:"", width:"100"},
                {id:"asrt1", name:"ASRT1", field:"", width:"50"},
                {id:"asrt2", name:"ASRT2", field:"", width:"50"},
                {id:"asrt3", name:"ASRT3", field:"", width:"50"},
                {id:"asrt4", name:"ASRT4", field:"", width:"50"},
                {id:"asrt5", name:"ASRT5", field:"", width:"50"},
                {id:"srt1", name:"#SRT1", field:"", width:"50"},
                {id:"srt1", name:"#SRT2", field:"", width:"50"},
                {id:"srt3", name:"#SRT3", field:"", width:"50"},
                {id:"srt4", name:"#SRT4", field:"", width:"50"},
                {id:"srt5", name:"#SRT5", field:"", width:"50"},
                {id:"srcLot", name:"SRC Lot#", field:"", width:"50"},
                {id:"comments", name:"Comments", field:"", width:"50"},
                {id:"femaleSource", name:"Source of Female Parent", field:"", width:"100"},
                {id:"maleSource", name:"Source of Male Parent", field:"", width:"100"}
            ],
            competitorCols = [
                {id:"midasCommercialName", name:"Product Name", field:"midasCommercialName", width:"100"},
                {id:"source", name:"Source", field:"source", width:"200"},
                {id:"inventoryOwner", name:"Inventory Owner", field:"", width:"100"},
                {id:"vegetativeStructure", name:"Vegetative Structure", field:"vegetativeStructure", width:"100"},
                {id:"transgenic", name:"Transgenic?", field:"transgenic", width:"100"},
                {id:"exposureHistory", name:"Is Exposure History Known?", field:"exposureHistory", width:"100"},
                {id:"lineFunction", name:"Line Function", field:"lineFunction", width:"150"},
                {id:"pedigree", name:"Cytoplasm Donor Pedigree", field:"pedigree", width:"150"},
                {id:"midasCommercialBrandName", name:"Brand Name", field:"midasCommercialBrandName", width:"150"},
                {id:"seedQuantity", name:"Seed Quantity", field:"", width:"100"},
                {id:"seedQuantityUOM", name:"Seed Quantity_UOM", field:"", width:"100"},
                {id:"asrt1", name:"ASRT1", field:"", width:"50"},
                {id:"asrt2", name:"ASRT2", field:"", width:"50"},
                {id:"asrt3", name:"ASRT3", field:"", width:"50"},
                {id:"asrt4", name:"ASRT4", field:"", width:"50"},
                {id:"asrt5", name:"ASRT5", field:"", width:"50"},
                {id:"srt1", name:"#SRT1", field:"", width:"50"},
                {id:"srt1", name:"#SRT2", field:"", width:"50"},
                {id:"srt3", name:"#SRT3", field:"", width:"50"},
                {id:"srt4", name:"#SRT4", field:"", width:"50"},
                {id:"srt5", name:"#SRT5", field:"", width:"50"},
                {id:"srcLot", name:"SRC Lot#", field:"", width:"50"},
                {id:"comments", name:"Comments", field:"", width:"50"}
            ],
            finishedCols = [
                {id:"germplasmOwner", name:"Germplasm Owner", field:"germplasmOwner", width:"100"},
                {id:"lineCode", name:"Line Code", field:"lineCode", width:"150"},
                {id:"source", name:"Source", field:"source", width:"200"},
                {id:"inventoryOwner", name:"Inventory Owner", field:"", width:"100"},
                {id:"vegetativeStructure", name:"Vegetative Structure", field:"vegetativeStructure", width:"100"},
                {id:"transgenic", name:"Transgenic?", field:"transgenic", width:"100"},
                {id:"exposureHistory", name:"Is Exposure History Known?", field:"exposureHistory", width:"100"},
                {id:"origin", name:"Origin", field:"origin", width:"150"},
                {id:"lineage", name:"Lineage", field:"", width:"100"},
                {id:"generation", name:"Generation", field:"", width:"100"},
                {id:"lineFunction", name:"Line Function", field:"lineFunction", width:"150"},
                {id:"pedigree", name:"Cytoplasm Donor Pedigree", field:"pedigree", width:"150"},
                {id:"source", name:"Cytoplasm Donor Source", field:"", width:"150"},
                {id:"codedLineCode", name:"Coded Line Code", field:"", width:"150"},
                {id:"allergens", name:"Are Allergens Present?", field:"allergens", width:"100"},
                {id:"toxinsPresent", name:"Are Toxins Present?", field:"toxinsPresent", width:"100"},
                {id:"animalGene", name:"Contains Animal Gene?", field:"animalGene", width:"100"},
                {id:"miniChromosome", name:"Contains Mini Chromosome?", field:"miniChromosome", width:"100"},
                {id:"fromManufacturing", name:"From Manufacturing?", field:"fromManufacturing", width:"100"},
                {id:"batchNumber", name:"Manufacturing Batch #?", field:"batchNumber", width:"150"},
                {id:"acronym", name:"Manufacturing Acronym #?", field:"acronym", width:"150"},
                {id:"materialNumber", name:"Manufacturing Material #?", field:"materialNumber", width:"150"},
                {id:"royalty", name:"Royalty", field:"", width:"100"},
                {id:"company", name:"Company", field:"", width:"100"},
                {id:"externalGermplasmName", name:"External Germplasm Name", field:"", width:"150"},
                {id:"oldPedigree", name:"Old Pedigree", field:"", width:"100"},
                {id:"seedQuantity", name:"Seed Quantity", field:"", width:"100"},
                {id:"seedQuantityUOM", name:"Seed Quantity_UOM", field:"", width:"100"},
                {id:"asrt1", name:"ASRT1", field:"", width:"50"},
                {id:"asrt2", name:"ASRT2", field:"", width:"50"},
                {id:"asrt3", name:"ASRT3", field:"", width:"50"},
                {id:"asrt4", name:"ASRT4", field:"", width:"50"},
                {id:"asrt5", name:"ASRT5", field:"", width:"50"},
                {id:"srt1", name:"#SRT1", field:"", width:"50"},
                {id:"srt1", name:"#SRT2", field:"", width:"50"},
                {id:"srt3", name:"#SRT3", field:"", width:"50"},
                {id:"srt4", name:"#SRT4", field:"", width:"50"},
                {id:"srt5", name:"#SRT5", field:"", width:"50"},
                {id:"srcLot", name:"SRC Lot#", field:"", width:"50"},
                {id:"event", name:"Event", field:"event", width:"50"},
                {id:"comments", name:"Comments", field:"", width:"50"},
                {id:"buildParentage", name:"Build Parentage", field:"buildParentage", width:"100"},
                {id:"parentalSources", name:"Parental Sources", field:"parentalSources", width:"100"}
            ],
            hybridCols = [
                {id:"germplasmOwner", name:"Germplasm Owner", field:"germplasmOwner", width:"100"},
                {id:"origin", name:"Origin", field:"origin", width:"150"},
                {id:"source", name:"Source", field:"source", width:"200"},
                {id:"inventoryOwner", name:"Inventory Owner", field:"", width:"100"},
                {id:"vegetativeStructure", name:"Vegetative Structure", field:"vegetativeStructure", width:"100"},
                {id:"transgenic", name:"Transgenic?", field:"transgenic", width:"100"},
                {id:"exposureHistory", name:"Is Exposure History Known?", field:"exposureHistory", width:"100"},
                {id:"allergens", name:"Are Allergens Present?", field:"allergens", width:"100"},
                {id:"toxinsPresent", name:"Are Toxins Present?", field:"toxinsPresent", width:"100"},
                {id:"animalGene", name:"Contains Animal Gene?", field:"animalGene", width:"100"},
                {id:"miniChromosome", name:"Contains Mini Chromosome?", field:"miniChromosome", width:"100"},
                {id:"fromManufacturing", name:"From Manufacturing?", field:"fromManufacturing", width:"100"},
                {id:"batchNumber", name:"Manufacturing Batch #?", field:"batchNumber", width:"150"},
                {id:"acronym", name:"Manufacturing Acronym #?", field:"acronym", width:"150"},
                {id:"materialNumber", name:"Manufacturing Material #?", field:"materialNumber", width:"150"},
                {id:"lineFunction", name:"Line Function", field:"lineFunction", width:"150"},
                {id:"royalty", name:"Royalty", field:"", width:"50"},
                {id:"company", name:"Company", field:"", width:"100"},
                {id:"externalGermplasmName", name:"External Germplasm Name", field:"", width:"100"},
                {id:"oldPedigree", name:"Old Pedigree", field:"", width:"100"},
                {id:"seedQuantity", name:"Seed Quantity", field:"", width:"100"},
                {id:"seedQuantityUOM", name:"Seed Quantity_UOM", field:"", width:"100"},
                {id:"asrt1", name:"ASRT1", field:"", width:"50"},
                {id:"asrt2", name:"ASRT2", field:"", width:"50"},
                {id:"asrt3", name:"ASRT3", field:"", width:"50"},
                {id:"asrt4", name:"ASRT4", field:"", width:"50"},
                {id:"asrt5", name:"ASRT5", field:"", width:"50"},
                {id:"srt1", name:"#SRT1", field:"", width:"50"},
                {id:"srt1", name:"#SRT2", field:"", width:"50"},
                {id:"srt3", name:"#SRT3", field:"", width:"50"},
                {id:"srt4", name:"#SRT4", field:"", width:"50"},
                {id:"srt5", name:"#SRT5", field:"", width:"50"},
                {id:"srcLot", name:"SRC Lot#", field:"", width:"50"},
                {id:"event", name:"Event", field:"event", width:"50"},
                {id:"comments", name:"Comments", field:"", width:"50"},
                {id:"femaleSource", name:"Source of Female Parent", field:"", width:"100"},
                {id:"gpOwnerFemaleParent", name:"GP Owner of Female Parent", field:"", width:"100"},
                {id:"maleSource", name:"Source of Male Parent", field:"", width:"100"},
                {id:"gpOwnerMaleParent", name:"GP Owner of Male Parent", field:"", width:"100"}
            ],
            messageView = new MessageView();

        function InventoryToolExportColumns(options) {
            var self = this;
            _.extend(self, options);
        }

        var prototype = InventoryToolExportColumns.prototype;

        prototype.hybridExport = function (data) {
            var self = this;
            self.exportItems(hybridCols, "Hybrid", data);
        };

        prototype.commercialExport = function (data) {
            var self = this;
            self.exportItems(commercialCols, "Commercial", data);
        };

        prototype.competitorExport = function (data) {
            var self = this;
            self.exportItems(competitorCols, "Competitor", data);
        };

        prototype.finishedExport = function (data) {
            var self = this;
            self.exportItems(finishedCols, "Finished", data);
        };

        prototype.exportItems = function (gridCols, spreadSheetName, data) {
            if (_.isEmpty(data)) {
                messageView.info("Select a Saved Batch/Material to export.");
            } else {
                exportUtil.exportToExcel({"fileName":"InventoryImportTool_" + spreadSheetName, "sheetName":spreadSheetName, "backbone":false, "columns":gridCols, "rows":data});
            }
        };

        return InventoryToolExportColumns;

    });

