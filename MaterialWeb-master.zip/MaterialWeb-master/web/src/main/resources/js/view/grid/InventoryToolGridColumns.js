define(["underscore", "jquery", "backbone",
    "common/grid/GridDataFormatter",
    "lib/slick-grid/slick-editors",
    "validation/sourceValidator",
    "lib/slick-grid/slick-grid",
    "lib/slick-grid/slick-core",
    "lib/slick-grid/slick-dataview",
    "lib/slick-grid/slick-rowselectionmodel",
    "lib/slick-grid/slick-checkboxselectcolumn",
    "version!jquery-plugins/eventdrag[2.0]"],
    function (_, $, backbone, GridDataFormatter, editor, SourceValidator) {
        var cols = [
                {id:"lexiconPreCommercialName", name:"PreCommercial Name", field:"lexiconPreCommercialName", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"midasCommercialName", name:"Product Name", field:"midasCommercialName", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"midasCommercialBrandName", name:"Brand Name", field:"midasCommercialBrandName", type:"String", width:75, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"origin", name:"Origin", field:"origin", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"lineCode", name:"Line Code", field:"lineCode", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"lineType", name:"Line Type", field:"lineType", type:"String", width:75, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"lineFunction", name:"Line Function", field:"lineFunction", type:"String", width:75, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"event", name:"Event", field:"event", type:"String", width:75, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"germplasmOwner", name:"Owner", field:"germplasmOwner", type:"String", width:75, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"pedigree", name:"Cytoplasm Donor Pedigree", field:"pedigree", type:"String", width:75, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"batchNumber", name:"SAP Batch", field:"batchNumber", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"materialNumber", name:"SAP Material", field:"materialNumber", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"acronym", name:"SAP Material Acronym", field:"acronym", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"sapMaterialDescription", name:"SAP Material Description", field:"sapMaterialDescription", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"traitVersion", name:"Trait Version", field:"traitVersion", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"sapTraitVersion", name:"SAP Trait Version", field:"sapTraitVersion", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"sapBrandName", name:"SAP Brand Name", field:"sapBrandName", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"preferredName", name:"Preferred Name", field:"preferredName", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"preferredGermplasm", name:"Preferred Germplasm", field:"preferredGermplasm", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"sapCreatedDate", name:"SAP Creation Date", field:"sapCreatedDate", type:"String", width:150, formatter:GridDataFormatter.getDateFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"manufacturingName", name:"Manufacturing Name", field:"manufacturingName", type:"String", width:150, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true}
            ],
            tqCols = [
                {id:"transgenic", name:"Transgenic?", field:"transgenic", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true},
                {id:"exposureHistory", name:"Exposure History?", field:"exposureHistory", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"fromManufacturing", name:"From Manufacturing?", field:"fromManufacturing", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"containsAnimalGene", name:"Contains Animal Gene?", field:"animalGene", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"containsMiniChromosome", name:"Contains Mini Chromosome?", field:"miniChromosome", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"containsAllergens", name:"Contains Allergens?", field:"allergens", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true},
                {id:"toxinsPresent", name:"Contains Toxins?", field:"toxinsPresent", type:"String", width:100, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, selectable:true}
            ],
            inputCols = [
                {id:"source", name:"Source", field:"source", type:"String", width:200, formatter:GridDataFormatter.getFormatter, cssClass:'cellText', headerCssClass:'cellHeader', sortable:true, resizable:true, editor:editor.Editors.Text, validator:SourceValidator}
            ];

        function InventoryToolGridColumns(options) {
            var self = this;
            _.extend(self, options);
        }

        var prototype = InventoryToolGridColumns.prototype;

        prototype.getColumns = function (isShowTQColumnsChecked, checkboxSelector) {
            var self = this,
                columns = [];
            columns.push(checkboxSelector.getColumnDefinition());
            if (isShowTQColumnsChecked) {
                return columns.concat(cols, tqCols);
            }
            return columns.concat(cols);
        };
        prototype.getColumnsWithInput = function (isShowTQColumnsChecked, checkboxSelector) {
            var self = this,
                columns = [];
            columns.push(checkboxSelector.getColumnDefinition());
            if (isShowTQColumnsChecked) {
                return columns.concat(inputCols, cols, tqCols);
            }
            return columns.concat(inputCols, cols);
        };

        return InventoryToolGridColumns;

    });

