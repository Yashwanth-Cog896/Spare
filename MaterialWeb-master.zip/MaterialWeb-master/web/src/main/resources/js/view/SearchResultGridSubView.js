define(["underscore", "jquery", "backbone", "lib/slick-grid/slick-grid",
    "moment",
    "jquery-plugins/select2",
    "lib/slick-grid/slick-core",
    "lib/slick-grid/slick-dataview",
    "lib/slick-grid/slick-rowselectionmodel",
    "lib/slick-grid/slick-checkboxselectcolumn",
    'lib/twitter/bootstrap/bootstrap-modal',
    "version!jquery-plugins/eventdrag[2.0]"],
    function (_, $, backbone, slick, moment, select2) {
        var SearchResultGridSubView,
            checkboxSelector = new slick.CheckboxSelectColumn(),
            options = {
                enableCellNavigation:true,
                enableColumnReorder:false,
                enableTextSelectionOnCells:true,
                headerRowHeight:50
            };
        SearchResultGridSubView = backbone.View.extend({
            initialize:function () {
                var self = this;
                self.el = self.options.el;
                self.model = self.options.model;
                self.exportModel = self.options.exportModel;
                self.eventBus = self.options.eventBus;
                self.model.on("refreshGrid", self.refreshGrid, self);
                self.gridColumns = self.options.searchGridColumns;
                self.screenPersistModel = self.options.screenPersistModel;
            },
            reInitEvents:function () {
                var self = this;
                $('#addToExportBtn').click(_.bind(self.addSelectedMaterial, self));
                $('#resultsViewOptions').change(_.bind(self.refreshGrid, self));
                $('#clearSearchResultsBtn').click(_.bind(self.resetGrid, self));
            },
            resetOptions:function () {
                var self = this,
                    settings = [];
                if (self.screenPersistModel.searchShowTQOption === true) {
                    settings.push('showTQCols');
                }
                if (self.screenPersistModel.searchShowPreferredGermplasmOption === true) {
                    settings.push('showOnlyPrefGP');
                }
                $('#resultsViewOptions').select2('val', settings);
            },
            refreshGrid:function () {
                var self = this;
                self.resetGrid();
                self.render();
                self.screenPersistModel.searchShowTQOption = self.isShowTQColumnsSelected();
                self.screenPersistModel.searchShowPreferredGermplasmOption = self.isShowOnlyPreferredGermplasmSelected();
            },
            resetGrid:function () {
                var self = this;
                if (self.resultsGrid) {
                    self.resultsGrid.destroy();
                }
                self.resultsGrid = null;
                $('#searchResultCriteria').hide();
                $('#searchResultWarning').hide();
            },
            isShowTQColumnsSelected:function () {
                var self = this;
                var selectedOptions = $('#resultsViewOptions').val();
                return _.contains(selectedOptions, 'showTQCols');
            },
            isShowOnlyPreferredGermplasmSelected:function () {
                var self = this;
                var selectedOptions = $('#resultsViewOptions').val();
                return _.contains(selectedOptions, 'showOnlyPrefGP');
            },
            checkBoxChecked:function () {
                var self = this,
                    selectedRows = self.resultsGrid.getSelectedRows();
                if (_.isUndefined(selectedRows) || $.isEmptyObject(selectedRows)) {
                    $('#addToExportBtn').attr('disabled', 'disabled');
                } else {
                    $('#addToExportBtn').removeAttr('disabled');
                }
            },
            render:function () {
                var self = this,
                    data,
                    criteria = _.isEmpty(self.model.queryString()) ? '' : 'Search Criteria: ' + self.model.queryString(),
                    size = _.isUndefined(self.model.searchResultCount()) ? 0 : self.model.searchResultCount(),
                    header = '(' + size + ')';
                $("#resultsViewOptions").select2();
                $('#searchResultCriteria').text(criteria);
                $('#searchResultCriteria').show();
                $('#searchResultHeader').text(header);
                if (_.isUndefined(self.model.warning()) || _.isNull(self.model.warning())) {
                    $('#searchResultWarning').hide();
                } else {
                    $('#searchResultWarning').text(self.model.warning());
                    $('#searchResultWarning').show();
                }
                data = self.filterMaterialData();
                self.showResults();
                var dataWrapper = new slick.Data.DataView();
                self.dataView = dataWrapper;
                for (var i = 0; i < data.length; i++) {  // data.id is not unique (or maybe the query is wrong?)
                    data[i].gridRowId = i;
                }
                dataWrapper.setItems(data, "gridRowId");

                self.resultsGrid = new slick.Grid('#searchResultGrid', dataWrapper, self.gridColumns.getColumns(self.isShowTQColumnsSelected(), checkboxSelector), options);
                self.resultsGrid.updateRowCount();
                self.resultsGrid.render();
                self.resultsGrid.setSelectionModel(new slick.RowSelectionModel({selectActiveRow:false}));
                self.resultsGrid.registerPlugin(checkboxSelector);
                self.resultsGrid.setSelectedRows([]);

                dataWrapper.syncGridSelection(self.resultsGrid, true);
                dataWrapper.onRowCountChanged.subscribe(function (e, args) {
                    self.resultsGrid.updateRowCount();
                    self.resultsGrid.render();
                });
                dataWrapper.onRowsChanged.subscribe(function (e, args) {
                    self.resultsGrid.invalidateRows(args.rows);
                    self.resultsGrid.render();
                });

                self.checkBoxChecked();
                self.resultsGrid.onSelectedRowsChanged.subscribe(function (e, args) {
                    self.checkBoxChecked();
                });
                self.resultsGrid.onSort.subscribe(function(e, args) {
                    var sortFunc = function (dataRow1, dataRow2) {
                        var field = args.sortCol.field,
                            sign = args.sortAsc ? 1 : -1,
                            value1 = dataRow1[field],
                            value2 = dataRow2[field],
                            result = (value1 === value2 ? 0 : (value1 > value2 ? 1 : -1)) * sign;
                        if (result !== 0) {
                            return result;
                        }
                        return 0;
                    };
                    dataWrapper.sort(sortFunc, true);
                });
            },
            addSelectedMaterial:function () {
                var self = this,
                    selected = self.resultsGrid.getSelectedRows();
                $.each(selected, function () {
                    var selectedRow = $.extend({}, self.dataView.getItemByIdx(this));
                    selectedRow.source = self.generateSource(selectedRow.batchNumber);
                    self.exportModel.pushRow(selectedRow);
                });
                self.eventBus.trigger("showImportList");
                self.resultsGrid.setSelectedRows([]);
            },
            generateSource:function (batchNumber) {
                var source,
                    dateString;
                dateString = moment(new Date()).format("YYMMMDD");
                source = dateString + ' ' + $.trim(batchNumber);
                return source;
            },
            filterMaterialData:function () {
                var self = this;
                $('#filterFeedback').text("");
                var data = _.isEmpty(self.model.get('materialInformation')) ? [] : self.model.get('materialInformation');
                if (self.isShowOnlyPreferredGermplasmSelected()) {
                    $('#filterFeedback').text("Filtered by: Preferred Germplasm = 'T'");
                    return _.filter(data, function (row) {
                        return row.preferredGermplasm === 'T';
                    });
                }
                return data;
            },
            showResults:function () {
                var self = this;
                if (_.isEmpty(self.model.queryString()) === false) {
                    $('#searchResults').show();
                    $('#noResults').hide();
                    $('#collapseResults').collapse('show');
                }
            }
        });

        return SearchResultGridSubView;
    });