(function () {
    require(["jquery",
        "underscore",
        "common/ticker/ModalProgress",
        "common/error/MessageView",
        "jquery-plugins/chosen",
        "page-init",
        "MaterialSearchContext",
        "tps/navigation/documentReady"
    ],
        function ($, _, Progress, MessageView, chosen, pageInit, AppContext, documentReady) {

            var message = "Loading...",
                router;
            Progress.show(message);

            function addStyleSheet(name) {
                $('<link ' +
                    'rel="stylesheet" ' +
                    'type="text/css" ' +
                    'href="resources/css/' + name + '.css" ' +
                    'media="screen" ' +
                    '></link>')
                    .appendTo($("head"));
            }

            function init() {
                var self = this;
                window.onerror = function () {
                    new MessageView().error("Script error on window. Contact Administrator.");
                };
                $.ajaxSetup({ cache:false });
                $(".chzn-select").chosen();
                $(".collapse").collapse({toggle:false});

                Progress.hide(message);
            }

            function startup() {
                var self = this;
                self.appContext = new AppContext();
                self.appContext.initialize();
                $('#gmi-version').html('<div style="text-align: right"><h6>v&nbsp;${pom.version}&nbsp</h6></div>');
            }

            pageInit.init(init);
            documentReady(startup);
        });
}());