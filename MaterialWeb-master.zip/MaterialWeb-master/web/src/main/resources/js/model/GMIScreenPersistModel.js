define(["underscore", "jquery", "backbone"], function (_, $, backbone) {
    return backbone.Model.extend({
        defaults:{
            searchShowPreferredGermplasmOption:null,
            searchShowTQOption:null
        }
    });
});
