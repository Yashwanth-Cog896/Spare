define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress", "common/error/MessageView", "common/model/CommonModels", "model/NewSourceModel"],
    function (_, $, backbone, Progress, MessageView, commonModels, NewSourceModel) {
        var NewSourcesCollection;
        NewSourcesCollection = backbone.Collection.extend({
            model:NewSourceModel
        });
        return NewSourcesCollection;
    });