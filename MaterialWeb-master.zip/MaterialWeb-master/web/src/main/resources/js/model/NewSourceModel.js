define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress", "model/SearchResultModel"],
    function (_, $, backbone, Progress, SearchResultModel) {
        var row = new SearchResultModel();
        var NewSourceModel = backbone.Model.extend({
            defaults:{
                germplasmId:"",
                pedigree:"",
                lineCode:"",
                cropId:"",
                source:"",
                inventoryProgram:"",
                vegetativeStructure:"",
                tqExposure:"-",
                tqAllergen:"-",
                tqToxin:"-",
                seedQuantity:"0",
                seedQuantityUom:"",
                tqAnimalGene:"-",
                tqMiniChromosome:"-",
                fromManufacturing:"-",
                manufacturingBatchNumber:"",
                manufacturingAcronymNumber:"",
                manufacturingMaterialNumber:""
            },
            setRow:function (selectedRow) {
                var self = this;
                self.row = selectedRow;
                self.set('germplasmId', selectedRow.id);
                self.set('lineCode', selectedRow.lineCode);
                self.set('pedigree', selectedRow.pedigree);
                self.set('cropId', selectedRow.cropId);
                self.set('source', selectedRow.source);
                self.set('tqExposure', selectedRow.exposureHistory);
                self.set('tqAllergen', selectedRow.allergens);
                self.set('tqToxin', selectedRow.toxinsPresent);
                self.set('tqAnimalGene', selectedRow.animalGene);
                self.set('tqMiniChromosome', selectedRow.miniChromosome);
                self.set('fromManufacturing', selectedRow.fromManufacturing);
                self.set('manufacturingBatchNumber', selectedRow.batchNumber);
                self.set('manufacturingAcronymNumber', selectedRow.acronym);
                self.set('manufacturingMaterialNumber', selectedRow.materialNumber);
                self.set('germplasmOwner', selectedRow.germplasmOwner);
            },
            setRowOptions:function (cropOptions) {
                var self = this,
                    validVegStructures = cropOptions.get('vegetativeStructures'),
                    validUoms = cropOptions.get('seedQuantityUoms');
                self.set('validPrograms', cropOptions.get('availablePrograms'));
                self.set('validUoms', validUoms);
                self.set('validVegStructures', validVegStructures);
                self.set('isTQRequired', cropOptions.get('tqrequiredCrop'));
                if (_.size(validVegStructures) === 1) {
                    self.set('vegStructure', _.first(validVegStructures));
                }
                if (_.size(validUoms) === 1) {
                    self.set('seedQuantityUOM', _.first(validUoms));
                }
            },
            row:function () {
                var self = this;
                return self.row;
            }
        });
        return NewSourceModel;
    });