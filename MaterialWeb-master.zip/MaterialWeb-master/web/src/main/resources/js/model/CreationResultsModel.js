define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress", "common/error/MessageView", "model/CreateRequestModel"],
    function (_, $, backbone, Progress, MessageView, CreateRequestModel) {
        var requests = new backbone.Collection();
        var CreationResultsModel = backbone.Model.extend({
            defaults:{
                requestSuccess:"",
                responseMessage:"",
                responses:[]
            },
//            initialize:function () {
//                var self = this;
//                self.eventBus = self.options.eventBus;
//            },
            requestSuccess:function () {
                return this.get('requestSuccess');
            },
            responseMessage:function () {
                return this.get('responseMessage');
            },
            responses:function () {
                return this.get('responses');
            },
            setRequest:function (newSource) {
                var self = this,
                    request = new CreateRequestModel();
                request.set('vegetativeStructure', newSource.get('vegStructure'));
                request.set('sourceName', newSource.get('source'));
                request.set('seedQuantityUOM', newSource.get('seedQuantityUOM'));
                request.set('seedQuantity', newSource.get('seedQuantity'));
                request.set('inventoryOwnerProgram', newSource.get('program'));
                request.set('germplasmId', newSource.get('germplasmId'));
                request.set('exposureHistoryKnown', newSource.get('tqExposure'));
                request.set('toxinsPresent', newSource.get('tqToxin'));
                request.set('allergensPresent', newSource.get('tqAllergen'));
                request.set('animalGenePresent', newSource.get('tqAnimalGene'));
                request.set('miniChromosome', newSource.get('tqMiniChromosome'));
                request.set('fromManufacturing', newSource.get('fromManufacturing'));
                request.set('manufacturingBatchNumber', newSource.get('manufacturingBatchNumber'));
                request.set('manufacturingAcronymNumber', newSource.get('manufacturingAcronymNumber'));
                request.set('manufacturingMaterialNumber', newSource.get('manufacturingMaterialNumber'));
                request.set('germplasmOwner', newSource.get('germplasmOwner'));
                self.requests.push(request);
            },
            save:function (options) {
                var self = this,
                    dataString;
                dataString = JSON.stringify(self.requests); //.toJSON();

                $.ajax({
                    url:"/material-services/services/rest/materials/create",
                    type:'POST',
                    data:dataString,
                    contentType:"application/json",
                    success:options.success,
                    error:function (jqXHR, textStatus, errorThrown) {
                        options.error(null, jqXHR);
                    }
                }, self);
            },
            createSources:function (newSources, message) {
                var self = this;
                Progress.show(message);
                self.reset();
                _.each(newSources, function (obj) {
                    self.setRequest(obj);
                });
                self.save({
                    success:function (model, response, options) {
                        self.set('requestSuccess', model.requestSuccess);
                        self.set('responseMessage', model.responseMessage);
                        self.set('responses', model.responses);
                        self.processResponses(model, response, newSources);
                        self.trigger("refreshGrid", self);
                        Progress.hide(message);
                    },
                    error:function (model, error) {
                        self.reset();
                        Progress.hide(message);
                        new MessageView().error("Error while Creating Sources.  " + error);
                    }
                });
            },
            processResponses:function (model, response, newSources) {
                var self = this;
                _.each(model.responses, function (obj) {
                    var newSource = self.findNewSourceByGermplasmId(obj.germplasmId, obj.sourceString, newSources);
                    if (_.isObject(newSource)) {
                        newSource.set('inventoryBID', obj.inventoryBID);
                        newSource.set('messages', obj.messages);
                        newSource.set('success', obj.success);
                    }
                });
                self.get('eventBus').trigger('displayNewSourceResults');
            },
            findNewSourceByGermplasmId:function (germplasmId, sourceName, newSources) {
                var self = this,
                    result = null;
                _.each(newSources, function (obj) {
                    if (obj.get('germplasmId') === germplasmId && obj.get('source') === sourceName) {
                        result = obj;
                    }
                });
                return result;
            },
            reset:function () {
                var self = this;
                self.requests = new backbone.Collection();
                self.set('requestSuccess', null);
                self.set('responseMessage', '');
                self.set('responses', []);
            }
        });
        return CreationResultsModel;
    });