define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress"],
    function (_, $, backbone, Progress) {
        var allSavedMaterialInformation = [],
            ExportModel = backbone.Model.extend({
                allSavedMaterialInformation:function () {
                    return allSavedMaterialInformation;
                },
                reset:function () {
                    allSavedMaterialInformation = [];
                    this.trigger("reset", this);
                },
                pushRow:function (inventoryRow) {
                    allSavedMaterialInformation.push(inventoryRow);
                },
                popRow:function (inventoryRow) {
                    allSavedMaterialInformation = _.without(allSavedMaterialInformation, inventoryRow);
                }
            });
        return ExportModel;
    });