define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress", "common/error/MessageView", "common/model/CommonModels"],
    function (_, $, backbone, Progress, MessageView, commonModels) {
        var CropsCollection;
        CropsCollection = backbone.Collection.extend({
            model:commonModels.SelectModel,
            url : function () {
                return '/material-services/services/rest/crops/user';
            },
            load : function () {
                var self = this,
                    message = "Loading Crops";
                Progress.show(message);
                self.fetch({
                    success : function () {
                        Progress.hide(message);
                    },
                    error : function () {
                        Progress.hide(message);
                        new MessageView().error("Error while loading Crops");
                    }
                });
                return this;
            }
        });
        return CropsCollection;
    });