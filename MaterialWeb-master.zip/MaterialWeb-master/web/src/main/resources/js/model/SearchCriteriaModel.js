define(["underscore", "jquery", "backbone"], function(_, $, backbone) {
    return backbone.Model.extend({
        defaults : {
            cropId : 0,
            searchType1 : null,
            searchValue1 : null,
            searchType2 : null,
            searchValue2 : null
        }
    });
});
