define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress", "common/error/MessageView", "common/model/CommonModels"],
    function (_, $, backbone, Progress, MessageView, commonModels) {
        var CropOptionsModel;
        var eventBus;
        CropOptionsModel = backbone.Model.extend({
            model:commonModels.SelectModel,
            defaults:{
                cropId:0
            },
            cropId:function () {
                return this.get('cropId');
            },
            availablePrograms:function () {
                return this.get('availablePrograms');
            },
            vegetativeStructures:function () {
                return this.get('vegetativeStructures');
            },
            seedQuantityUoms:function () {
                return this.get('seedQuantityUoms');
            },
            isTQRequired:function () {
                return this.get('isTQRequiredCrop');
            },
            url:function () {
                var self = this;
                return '/material-services/services/rest/crop/referencedata?cropId=' + self.cropId();
            },
            load:function () {
                var self = this,
                    message = "Loading Crop Reference Data";
                Progress.show(message);
                self.fetch({
                    success:function () {
                        if (_.isObject(self.eventBus)) {
                            self.eventBus.trigger('cropOptionsLoaded');
                        }
                        Progress.hide(message);
                    },
                    error:function () {
                        Progress.hide(message);
                        new MessageView().error("Error while loading Crop Reference Data");
                    }
                });
                return this;
            }
        });
        return CropOptionsModel;
    });