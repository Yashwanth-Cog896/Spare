define(["underscore", "jquery", "backbone"], function (_, $, backbone) {
    return backbone.Model.extend({
        defaults:{
            validateOnly:false,
            vegetativeStructure:null,
            sourceName:null,
            seedQuantityUOM:null,
            seedQuantity:null,
            inventoryOwnerProgram:null,
            germplasmId:null,
            exposureHistoryKnown:null,
            toxinsPresent:null,
            allergensPresent:null,
            animalGenePresent:null,
            miniChromosome:null,
            fromManufacturing:null,
            manufacturingBatchNumber:null,
            manufacturingAcronymNumber:null,
            manufacturingMaterialNumber:null
        },
        setValidateOnly:function (value) {
            var self = this;
            self.set('validateOnly', self.parseBoolean(value));
        },
        parseBoolean:function (string) {
            switch (String(string).toLowerCase()) {
                case "true":
                case "1":
                case "yes":
                case "y":
                case "T":
                case "t":
                    return true;
                case "false":
                case "0":
                case "no":
                case "n":
                case "F":
                case "f":
                    return false;
                default:
                    //you could throw an error, but 'undefined' seems a more logical reply
                    return undefined;
            }
        }
    });
});
