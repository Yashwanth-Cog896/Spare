define(["underscore", "jquery", "backbone", "common/ticker/ModalProgress", "common/error/MessageView", "model/SearchCriteriaModel"],
    function (_, $, backbone, Progress, MessageView, SearchCriteriaModel) {
        var criteria = new SearchCriteriaModel();
        var SearchResultModel = backbone.Model.extend({
            defaults:{
                searchResultCount:0
            },
            warning:function () {
                return this.get('warning');
            },
            searchResultCount:function () {
                return this.get('searchResultCount');
            },
            materialInformation:function () {
                return this.get('materialInformation');
            },
            queryString:function () {
                return this.get('queryString');
            },
            setSearchCriteria:function () {
                var self = this;
                criteria.set('cropId', self.cropId);
                criteria.set('searchType1', self.searchType1);
                criteria.set('searchValue1', self.searchValue1);
                criteria.set('searchType2', self.searchType2);
                criteria.set('searchValue2', self.searchValue2);
                return criteria;
            },
            save:function (options) {
                var self = this,
                    dataString;
                self.setSearchCriteria();
                dataString = JSON.stringify(criteria);

                $.ajax({
                    url:"/material-services/services/rest/materials",
                    type:'POST',
                    data:dataString,
                    contentType:"application/json",
                    success:options.success,
                    error:function (jqXHR, textStatus, errorThrown) {
                        options.error(null, jqXHR);
                    }
                }, self);
            },
            load:function (cropId, searchType1, searchValue1, searchType2, searchValue2, message) {
                var self = this;
                self.cropId = cropId;
                self.searchType1 = searchType1;
                self.searchValue1 = searchValue1;
                self.searchType2 = searchType2;
                self.searchValue2 = searchValue2;
                Progress.show(message);
                self.save({
                    success:function (model, response, options) {
                        self.set('materialInformation', model.materialInformation);
                        self.set('queryString', model.queryString);
                        self.set('searchResultCount', model.searchResultCount);
                        self.set('warning', model.warning);
                        self.trigger("refreshGrid", self);
                        Progress.hide(message);
                        if (model.searchResultCount > 0) {
                            $('#collapseCriteria').collapse();
                        }
                    },
                    error:function (model, error) {
                        self.reset();
                        Progress.hide(message);
                        new MessageView().error("Error while loading Search Results.  " + error);
                    }
                });
            },
            reset:function () {
                var self = this;
                self.set('materialInformation', []);
                self.set('queryString', '');
                self.set('searchResultCount', 0);
                self.set('warning', null);
            }
        });
        return SearchResultModel;
    });