define(["underscore", "jquery", "backbone"],
    function (_, $, backbone) {
        var SomeView = backbone.View.extend({
            render:function () {
                this.modelBinder.bind(this.model, this.el);
            }
        });
    }
);