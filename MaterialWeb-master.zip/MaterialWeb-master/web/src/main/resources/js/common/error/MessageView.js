define([
    "underscore",
    "jquery-plugins/jgrowl"
], function (_, jGrowl) {
    function MessageView(options) {
        var self = this;
        _.extend(self, options);
    }

    var prototype = MessageView.prototype;

    prototype.jGrowl = jGrowl;

    prototype.message = function (message, options) {
        var self = this;
        self.jGrowl(message, options);
    };

    prototype.info = function (message, header) {
        var self = this;
        self.message(message, {
            header:header || "Information",
            theme:"info",
            sticky:false
        });
    };

    prototype.error = function (message, header) {
        var self = this;
        self.message(message, {
            header:header || "Error",
            theme:"error",
            sticky:true
        });
    };

    prototype.errorCallback = function (header) {
        var self = this;
        var callbacks = _.toArray(arguments).slice(1);
        return function () {
            var args = arguments;
            self.error(args[2], header);
            _.each(callbacks, function (callback) {
                callback.apply(null, args);
            });
        };
    };

    return MessageView;
});