define(["underscore", "jquery", "jqueryui"], function (_, $, jqueryui) {
    var prototype, namespace = {}, modalProgress;

    function ModalProgress(options) {
        $.extend(this, options);
    }

    prototype = ModalProgress.prototype;

    prototype.html = '<div id="tickerDialog"><p></p><img style="position: absolute; left: 50%; top: 50%; margin-left: -8px; margin-top: -8px;" alt="progress" src="images/ajax-loader.gif"></div>';

    prototype.init = function () {
        var self = this;

        if (!self._inited) {
            self.div = $(self.html);
            self.div.dialog({
                autoOpen:false,
                hide:"fade",
                minHeight:false,
                modal:true,
                resizable:false,
                show:"fade",
                zIndex:2147483647
            });
            $(".ui-dialog-titlebar", $("#tickerDialog").parent()).hide();
            self._inited = true;
        }

        self._activities = [];
        self._closeTimerId = null;
        self._openTimerId = null;
        self._currentActivity = null;
    };


    prototype.show = function (text) {
        var self = this;
        self._activities.push(text);
        self._displayProgress();
    };


    prototype.hide = function (text) {
        var self = this;

        $.each(self._activities, function (i, activity) {
            if (self._activities[i] === text) {
                delete self._activities[i];
                return false;
            }
        });

        self._displayProgress();
    };
    prototype.hideAll = function () {
        var self = this;

        $.each(self._activities, function (i, activity) {
            delete self._activities[i];
        });

        self._displayProgress();
    };

    prototype._displayProgress = function () {
        var self = this, requiredActivity;

        // Determine the activity that is required to be shown. There may not be
        // one.
        requiredActivity = null;
        $.each(self._activities, function (i, obj) {
            if (obj) {
                requiredActivity = i;
                return false;
            }
        });

        // If we have an activity to be shown and it isn't the current one, display
        // it. Otherwise clear it.
        if (requiredActivity !== null) {
            if (requiredActivity !== self._currentActivity) {
                $("p", self.div).text(self._activities[requiredActivity]);
                self._currentActivity = requiredActivity;

                // If we have not queued up a dialog to show the activity and it
                // really isn't there then do so now.
                if (!self._openTimerId && !self.div.dialog("isOpen")) {
                    self._openTimerId = setTimeout(function () {
                        self.div.dialog("open");
                        self._openTimerId = null;
                        $("body").addClass("hideOverflow");
                    }, 750);
                }

                // We know we're going to be showing a dialog so ensure
                // that there's no pending closure of it.
                if (self._closeTimerId) {
                    clearTimeout(self._closeTimerId);
                    self._closeTimerId = null;
                }

            }
        } else {
            // We want to close the dialog so queue an event to do this i.e. delay
            // and allow anything else in the current thread after us to queue up
            // another message.
            self._closeTimerId = setTimeout(function () {
                self.div.dialog("close");
                self._closeTimerId = null;
                $("body").removeClass("hideOverflow");
            }, 0);

            // If there's anything destined to open then kill it off as it
            // is no longer required. This is typical when the response for
            // a request comes in before the time we want until the message
            // is shown.
            if (self._openTimerId) {
                clearTimeout(self._openTimerId);
                self._openTimerId = null;
            }

            // Do some clean up.
            self._currentActivity = null;
        }
    };

    modalProgress = new ModalProgress({});
    modalProgress.init();

    namespace.show = function (message) {
        modalProgress.show(message);
    };

    namespace.hide = function (message) {
        modalProgress.hide(message);
    };
    namespace.hideAll = function () {
        modalProgress.hideAll();
    };

    //For testing only
    namespace.instance = modalProgress;

    return namespace;
});