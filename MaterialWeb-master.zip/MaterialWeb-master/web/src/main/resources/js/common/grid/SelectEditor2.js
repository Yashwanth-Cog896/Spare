define(function (require) {
    var _ = require("underscore");
    var $ = require("jquery");
    var EditorBase = require("./EditorBase2");
    require("jquery-plugins/select2");

    var blankOption = '<option value=""></option>';

    var super_ = EditorBase.prototype;

    /**
     * @ignore collection_grid.editors.SelectEditor
     *
     * An editor that uses an HTML select element.  This is installed by default if the column is editable and has
     * implemented getValueList().
     *
     * A demo is available at http://research-portal-d.monsanto.com/docs/demos.html
     * @param {Object} options - provided by slickgrid.
     * @constructor
     */
    function SelectEditor(options) {
        var self = this;
        super_.constructor.apply(self, arguments);

        function createOptionHtml(value) {
            return '<option value="' + value + '">' + value + '</option>';
        }

        var $el = self.$el = $("<select class='select-editor'></select>");
        var parent = options.container;
        $el.appendTo(parent);
//        $(parent).find("div.select2-container").css({
//            width: options.column.width,
//            left: -4,
//            top: -4,
//            height: 22
//        });
        $el.html(blankOption + _.map(options.column.valueList(options.item), createOptionHtml).join(''));
        $el.select2({
            minimumResultsForSearch:10
        });
        $(parent).find("div.select2-container").css({
            width:options.column.width,
            left:-4,
            top:-4,
            height:22
        });
//        $el.html(blankOption + _.map(options.column.valueList(options.item), createOptionHtml).join(''));
        $el.select2("open");
        $el.change(function () {
            self.applyValue(options.item, $el.val());
        });
    }

    var prototype = _.extend(SelectEditor.prototype, super_);

    prototype.loadValue = function () {
        var self = this;
        super_.loadValue.apply(self, arguments);
        self.$el.select2("val", self.$el.val());
    };

    prototype.applyValue = function (item, value) {
        var self = this;
        // empty string is null
        super_.applyValue.call(self, item, value || null);
    };

    return SelectEditor;
});