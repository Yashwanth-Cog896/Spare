define(["underscore", "jquery", "backbone"], function (_, $, backbone) {

    var namespace = {};

    function loadOptions(collectionModel, opts) {
        var options = opts || {};
        var selected = options.selected;
        var html = (options.noSelectOne) ? ((options.emptyOption) ? '<option value=""></option>' : '') : '<option value="">Select One</option>';

        _.each(collectionModel, function (item) {
            var option = '<option ';
            if (selected && (item.description() === selected)) {
                option += 'selected="selected" ';
            }
            option += 'value="' + item.value() + '">' + item.description() + '</option>';
            html += option;
        });
        if (options.el) {
            options.el.html(html);
        }
        return html;
    }

    function setHtmlAndUpdate(el, selector, html, options) {
        var box = el.find(selector);
        box.empty().html(html);
        if (options.disabled) {
            box.attr("disabled", "disabled");
        }
        box.trigger("liszt:updated");
    }

    function populateSelect(el, selector, items, options) {
        var html = loadOptions(items, options);
        setHtmlAndUpdate(el, selector, html, options);
    }

    function fetchAndUpdate(el, collectionModel, selector, options) {
        setHtmlAndUpdate(el, selector, '<option value="">Loading...</option>', options);
        collectionModel.fetch({
            success:function (model) {
                populateSelect(el, selector, model.models, options);
            }
        });
    }


    namespace.loadOptions = loadOptions;
    namespace.fetchAndUpdate = fetchAndUpdate;
    namespace.populateSelect = populateSelect;
    namespace.setHtmlAndUpdate = setHtmlAndUpdate;

    return namespace;
});