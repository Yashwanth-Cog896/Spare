define(function (require) {
    var _ = require("underscore");
    var slick = require("version!lib/slick-grid/slick-grid[2.1]");

    /**
     * @class collection_grid.editors.EditorBase
     *
     * Base class for editors.
     *
     * @param options
     * @constructor
     */
    function EditorBase(options) {
        var self = this;
        self.options = options;
    }

    var prototype = EditorBase.prototype;

    prototype.destroy = function () {
        var self = this;
        self.$el.remove();
    };

    prototype.focus = function () {
        var self = this;
        self.$el.focus();
    };

    prototype.getValue = prototype.serializeValue = function () {
        var self = this;
        return self.$el.val();
    };

    prototype.setValue = function (value) {
        var self = this;
        self.$el.val(value);
    };

    /**
     * Load the value into the UI from the given item.
     *
     * @param {Object} item
     */
    prototype.loadValue = function (item) {
        var self = this;
        var column = self.options.column;
        var stringValue = column.getFormattedValue(column.getValue(item));
        self.defaultValue = stringValue;
        self.$el.val(stringValue);
    };

    /**
     * Sets the item's value.  For most editors this is just a raw string value.
     *
     * @param {Object} item
     * @param {*} value
     */
    prototype.applyValue = function (item, value) {
        var self = this;
        var column = self.options.column;
        if (column.editable) {
            column.setValue(item, value);
        }
    };

    prototype.isValueChanged = function () {
        var self = this;
        return self.getValue() !== self.defaultValue;
    };

    prototype.validate = function () {
        var self = this;
        var validator = self.options.column.validator;

        function validateWithValidator() {
            var results = _.isFunction(validator) && validator(self.getValue());
            return results && results.valid === false && results;
        }

        return validateWithValidator() || {valid:true, msg:null};
    };

    prototype.setEditorToCloseOnLostFocus = function () {
        var self = this;
        self.$el.blur(function () {
            slick.GlobalEditorLock.commitCurrentEdit();
        });
    };

    return EditorBase;
});