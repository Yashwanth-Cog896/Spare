define(["underscore", "jquery", "backbone"], function (_, $, backbone) {
    var namespace = {};
    var SelectModel = backbone.Model.extend({
        value:function () {
            return this.get('id');
        },
        description:function () {
            return this.get('name');
        }
    });

    namespace.SelectModel = SelectModel;

    return namespace;
});