/**
 * Defines type-based display formatting of data for use with both Backbone models and basic array models
 */
define(["underscore", "jquery", "backbone", "tps/model-utils", "moment"],
    function (_, $, backbone, modelUtils, moment) {
        var namespace = {}, columnFormatter, getFormatter, columnDateFormatter, getDateFormatter;

        function getValue(item, field) {
            return modelUtils.getValue(item, field);
        }

        /**
         * Formatter functions for use with SlickGrid display formatting
         */
            // Generic Formatter function
        columnFormatter = function (row, cell, value, col, data) {
            return getValue(data, col.field);
        };

        columnDateFormatter = function (row, cell, value, col, data) {
            var myDate = getValue(data, col.field);
            if (_.isUndefined(myDate) || _.isNull(myDate)) {
                return "";
            } else {
                return moment(myDate).format("DD-MMM-YYYY");
            }
        };

        // Expose these functions in the Formatters namespace
        namespace = {
            getFormatter : columnFormatter,
            getDateFormatter : columnDateFormatter
        };

        return namespace;
    });


