define(["jquery", "tps/navigation"],
        function ($, navMenu) {

            var init = function(func) {
                navMenu.installHeader();
                navMenu.installFooter();
                func();
            };

            return {
                init : init
            };
        }
);