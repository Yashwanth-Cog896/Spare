define(function () {
    return {
        fullName: "Jane Doe",
        firstName: "Jane",
        lastName: "Doe",
        phoneNumber: "+1-314-5551212",
        emailAddress: "jane/doe@monsanto.com",
        manager: "cn=JSSMITH,ou=PRIMARY,ou=USERS,ou=INT,o=MONSANTO",
        cube: "ZZ1234",
        division: "Technology Pipeline Solutions",
        authorities: [
            {
                authority: "ROLE_FOO_BAR"
            }
        ],
        password: "password",
        username: "JADOE",
        accountNonExpired: true,
        accountNonLocked: true,
        credentialsNonExpired: true,
        enabled: true
    };
});
