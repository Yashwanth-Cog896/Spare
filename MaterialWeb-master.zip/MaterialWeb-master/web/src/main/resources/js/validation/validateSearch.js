define(["underscore", "jquery", "backbone", "common/error/MessageView"],
    function (_, $, backbone, MessageView) {

//        var namespace = {};
        function ValidateSearch(options) {
            var self = this;
            _.extend(self, options);
        }

        var prototype = ValidateSearch.prototype;

        prototype.messageView = new MessageView();

        prototype.verifySearchCriteria = function verifySearchCriteria(cropName, searchValue1, searchValue2) {
            var self = this;
            var response = true;
            if (_.isEmpty(cropName) || (_.isEmpty(searchValue1) && _.isEmpty(searchValue2))) {
                response = false;
                self.messageView.info('<b>Select a Crop and enter at least one search criteria value</b>');
            }
            return response;
        };
//        };

//        namespace.verifySearchCriteria = verifySearchCriteria;
//        return namespace;
        return ValidateSearch;
    });
