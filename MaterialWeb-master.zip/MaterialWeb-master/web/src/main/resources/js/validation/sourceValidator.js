define(["underscore", "jquery", "backbone"],
    function (_, $, backbone) {
        function SourceValidator(value) {
            var regEx = /[^\- @{}_.!%#\/+>\[\]\\<,~&:A-Za-z0-9$\^"]+/;
            if (regEx.test(value)) {
                return {valid:false, msg:"Enter valid Source. Invalid characters include '(*)'|;?"};
            }
            return {valid:true, msg:null};
        }

        return SourceValidator;
    }

)
;
