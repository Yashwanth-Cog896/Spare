define(["jquery",
    "underscore",
    "backbone",
    "tps/appcontext/requiredDependency"],
    function ($, _, Backbone, requiredDependency) {
        var MaterialSearchRouter;

        MaterialSearchRouter = Backbone.Router.extend({
            materialSearchView:requiredDependency,
            createSourceView:requiredDependency,
            eventBus:requiredDependency,
            routes:{
                '':'baseScreen',
                'search':'showSearch',
                'newSources':'newSources'
            },
            initialize:function (options) {
                var self = this;
                _.extend(self, options);
                self.eventBus.on('createSources', _.bind(self.gotoNewSource, self));
                self.eventBus.on('searchScreen', _.bind(self.gotoSearch, self));
//                self.model = options.model;
                self.routesHit = 0;
                Backbone.history.on('route', function () {
                    this.routsHit++;
                }, this);
                Backbone.history.start();
            },
            baseScreen:function () {
                var self = this;
                self.showSearch();
            },
            showSearch:function () {
                var self = this;
//                window.alert('showSearch');
                self.createSourceView.clearResults();
                self.materialSearchView.render();
                self.materialSearchView.resetData();
            },
            newSources:function () {
                var self = this;
//                window.alert('newSources');
                self.createSourceView.render();
            },
            gotoSearch:function () {
                var self = this;
                self.navigate('search', {trigger:true});
            },
            gotoNewSource:function () {
                var self = this;
                self.navigate('newSources', {trigger:true});
            },
            back:function () {
                var self = this;
                if (self.routesHit > 0) {
                    window.history.back();
                } else {
                    self.baseScreen();
                }
            }
            //to invoke the new sources screen - MaterialSearchRouter.navigate('newSources', {trigger: true});
        });
        return MaterialSearchRouter;
    }
);