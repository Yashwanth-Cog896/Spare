define(function (require) {
    var $ = require("jquery");
    var _ = require("underscore");
    var backbone = require("backbone");
    var MaterialSearchRouter = require("MaterialSearchRouter");
    var mainHtml = require("text!./../../index.html");
    //Search
    var ExportModel = require("model/ExportModel");
    var ExportGridSubView = require("view/ExportGridSubView");
    var SearchResultModel = require("model/SearchResultModel");
    var GMIScreenPersistModel = require("model/GMIScreenPersistModel");
    var SearchResultGridSubView = require("view/SearchResultGridSubView");
    var MaterialSearchToolView = require("view/MaterialSearchToolView");
    var SearchGridColumns = require("view/grid/InventoryToolGridColumns");
    var ExportGridColumns = require("view/grid/InventoryToolExportColumns");
    var CropsCollection = require("model/CropsCollection");
    var SearchCriteriaSubView = require("view/SearchCriteriaSubView");
    var materialSearchHtml = require("text!./view/template/materialSearch.html");
    //Create Sources
    var NewSourceModel = require("model/NewSourceModel");
    var CreationResultsModel = require("model/CreationResultsModel");
    var NewSourceGridColumns = require("view/grid/NewSourceGridColumns");
    var NewSourcesCollection = require("model/NewSourcesCollection");
    var CreateSourceView = require("view/CreateSourceView");
    var createSourceHtml = require("text!./view/template/createsource.html");

    /**
     * MaterialSearchContext is analagous to a Spring xml configuration file.  We wire up all dependencies for the
     * application here.
     */
    function MaterialSearchContext(options) {
        var self = this;
        _.extend(self, options);
    }

    var prototype = MaterialSearchContext.prototype;

    prototype.initialize = function () {
        var self = this;
        self.eventBus = _.extend({}, backbone.Events);

        self.mainDiv = $("#gmi-content");
        //MODELS
        //         -- Search
        self.exportModel = new ExportModel();
        self.screenPersistModel = new GMIScreenPersistModel();
        self.searchResultModel = new SearchResultModel();
        self.searchGridColumns = new SearchGridColumns();
        self.exportGridColumns = new ExportGridColumns();
        //          -- Create Sources
        self.newSourceGridColumns = new NewSourceGridColumns();
        self.newSourceModel = new NewSourceModel();
        self.newSourcesCollection = new NewSourcesCollection();
        self.createResultsModel = new CreationResultsModel({eventBus:self.eventBus});
        //html templates
        self.searchHtml = _.template(materialSearchHtml, {title:'Germplasm and Material Import - Search'});
        self.newSourceHtml = _.template(createSourceHtml, {title:'Germplasm and Material Import - Create Sources'});
        //SUB VIEWS
        //           -- Search
        self.exportGridSubView = new ExportGridSubView({el:$("#importView"), model:self.exportModel, eventBus:self.eventBus,
            searchGridColumns:self.searchGridColumns, exportGridColumns:self.exportGridColumns, screenPersistModel:self.screenPersistModel,
            newSourcesCollection:self.newSourcesCollection});
        self.searchResultGridSubView = new SearchResultGridSubView({el:$("#searchResults"), model:self.searchResultModel,
            exportModel:self.exportModel, searchGridColumns:self.searchGridColumns, eventBus:self.eventBus, screenPersistModel:self.screenPersistModel});
        self.searchCriteriaSubView = new SearchCriteriaSubView({el:$("#searchCriteriaView"), eventBus:self.eventBus,
            searchResultModel:self.searchResultModel});
        //            -- New Sources
        self.createSourceView = new CreateSourceView({el:self.mainDiv, html:self.newSourceHtml, eventBus:self.eventBus,
            newSourceModel:self.newSourceModel, newSourceGridColumns:self.newSourceGridColumns,
            newSourcesCollection:self.newSourcesCollection, createResultsModel:self.createResultsModel});

        //MAIN views
        self.materialSearchToolView = new MaterialSearchToolView({el:self.mainDiv, html:self.searchHtml,
            searchResultGridSubView:self.searchResultGridSubView, eventBus:self.eventBus,
            searchCriteriaSubView:self.searchCriteriaSubView, exportGridSubView:self.exportGridSubView });

        function initializeAll() {
            _.each(self, function (bean) {
                if (typeof bean.initializeBean === "function") {
                    bean.initializeBean();
                }
            });
        }

        self.router = new MaterialSearchRouter({materialSearchView:self.materialSearchToolView,
            createSourceView:self.createSourceView, eventBus:self.eventBus});
        initializeAll();

        return true;
    };
    return MaterialSearchContext;
});