(function () {
    require(["jquery", "page-init", "placement", "common/util"],
        function ($, pageInit, placement, util) {

            function init() {
                $('#placementSearch').submit(function() {
                    placement.search($('#placementSearchText').val());
                    return false;
                });

                var barcodes = util.urlParams().barcodes;
                if(barcodes) {
                    placement.search(barcodes);
                }
            }
            pageInit.init(init);
        });
}());