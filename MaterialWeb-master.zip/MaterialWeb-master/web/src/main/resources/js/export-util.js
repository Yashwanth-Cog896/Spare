define(["jquery",
    "tps/excel-export/ExportFile"],
    function ($, ExportFile) {

        var exportUrl;

        var doExport = function (parameters) {
            var exportFile = new ExportFile({url: exportUrl, name: parameters.fileName});
            exportFile.addSheet({
                backbone: parameters.backbone,
                name: parameters.sheetName,
                rows: parameters.rows,
                columns: parameters.columns
            });
            exportFile.submit();
        };

        var lookupUrlAndExport = function (parameters) {
            var urlLookupKey = ExportFile.URL_LOOKUP_KEY;
            $.getJSON(
                    "/material-services/services/rest/ServiceLocator/lookup?service=" + urlLookupKey,
                    function(urlMap) {
                        exportUrl = urlMap[urlLookupKey];
                        doExport(parameters);
                    }
            );
        };

        var exportToExcel = function (parameters) {
            if (exportUrl) {
                doExport(parameters);
            } else {
                lookupUrlAndExport(parameters);
            }
        };

        return {
            exportToExcel: exportToExcel
        };

    });