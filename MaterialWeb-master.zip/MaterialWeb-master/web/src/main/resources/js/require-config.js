(function () {
    var bootstrap = window.bootstrap; // keep jslint happy
    bootstrap.configurePackages({
        "jquery-plugins/jgrowl":"1.2.6",
        "jquery-plugins/eventdrag":"2.0",
        "jquery-plugins/chosen":"0.9.8",
        "jquery-plugins/mousewheel":"3.0.6",
        "jquery-plugins/jquery-address":"1.5",
        "lib/slick-grid":"2.1",
        "tps/slick-grid":"1.1.3",
        "tps/collection-grid":"1.0.8",
        "tps/excel-export":"1.0.0",
        "lib/backbone-modelbinding":"1.0.2",
        "tps/model-utils":"1.0.0",
        "tps/appcontext":"1.0.1",
        "jquery-plugins/select2":"3.4.3",
        "scripts/moment":"1.7.0"
    });
    bootstrap.configureDependencies({
        backbone:"scripts.backbone:backbone:1.0.0",
        bootbox:"scripts.bootbox:bootbox:3.2.0"
    });
    require.config(bootstrap.requireJsConfiguration);

    bootstrap.addCss("pkg/lib/twitter/bootstrap", "bootstrap-responsive", "2.0.4");
}());