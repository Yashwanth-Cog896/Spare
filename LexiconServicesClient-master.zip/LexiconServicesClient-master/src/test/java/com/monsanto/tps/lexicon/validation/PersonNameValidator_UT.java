/*
 PersonNameValidator_UT was created on Jul 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import com.monsanto.tps.lexicon.person.service.People;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * @author GGSHIV - Jul 30, 2008 11:44:16 AM
 */
public class PersonNameValidator_UT
   extends TestCase
{
   public void testValidate_NullFirstAndLastName_Invalid() {
      try {
         new PersonNameValidator(null, null).validate();
      }
      catch (IllegalArgumentException e) {
         assertEquals(People.INVALID_PERSON_NAME, e.getMessage());
      }
   }

   public void testValidate_EmptyFirstAndLastName_Invalid() {
      try {
         new PersonNameValidator("", "").validate();
      }
      catch (IllegalArgumentException e) {
         assertEquals(People.INVALID_PERSON_NAME, e.getMessage());
      }
   }

   public void testValidate_NullLastName_Valid() {
      new PersonNameValidator("GMS", null).validate();
   }

   public void testValidate_NullFirstName_Valid() {
      new PersonNameValidator(null, "GMS").validate();
   }

   public void testValidate_EmptyLastName_Valid() {
      new PersonNameValidator("GMS", "").validate();
   }

   public void testValidate_EmptyFirstName_Valid() {
      new PersonNameValidator("", "GMS").validate();
   }

   public void testValidate_FirstAndLastNamesContainNumbers_Invalid() {
      try {
         new PersonNameValidator("GMS1", "GMS2").validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.\nLast Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_LastNameContainsNumber_Invalid() {
      try {
         new PersonNameValidator("GMS", "GMS1").validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Last Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_FirstNameContainsNumber_Invalid() {
      try {
         new PersonNameValidator("GMS1", "GMS").validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_FirstAndLastNameAreOnlyWildcards_Invalid() {
      try {
         new PersonNameValidator("*", "*").validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.\nLast Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_LastNameIsOnlyWildcard_Invalid() {
      try {
         new PersonNameValidator("GMS", "*").validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Last Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_FirstNameIsOnlyWildcard_Invalid() {
      try {
         new PersonNameValidator("*", "GMS").validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithValidNames_DoesNotThrowsInvalidFieldMessage() {
      new PersonNameValidator("GMS*", "G*MS").validate();
   }

}

