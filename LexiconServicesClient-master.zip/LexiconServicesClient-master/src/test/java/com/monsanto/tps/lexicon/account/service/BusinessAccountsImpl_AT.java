package com.monsanto.tps.lexicon.account.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator.LINE_SEPARATOR;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * nbwald - May 27, 2008 3:56:00 PM
 */
public class BusinessAccountsImpl_AT
   extends TestCase
{
   private BusinessAccounts client;

   protected void setUp()
      throws Exception
   {
      client = new BusinessAccountsImpl(new KerberosStandaloneCredential());
   }

   public void testFindByIds_NoIds_FindsNoResults() {
      long[] businessAccountIds = new long[0];
      BusinessAccount[] found = client.findByIds(businessAccountIds);

      assertNotNull(found);
      assertEquals(0, found.length);
   }

   public void testFindByIds_ValidIds_FindsResults() {
      long[] businessAccountIds = new long[]{235937};

      BusinessAccount[] found = client.findByIds(businessAccountIds);

      assertNotNull(found);
      assertEquals(1, found.length);
      BusinessAccount businessAccount = found[0];
      assertEquals("235937", businessAccount.getAccountID());
      AddressRecord[] addressRecords = businessAccount.getAddressRecords();
      assertNotNull(addressRecords);
      assertTrue(addressRecords.length > 0);
      AddressRecord addressRecord = addressRecords[0];
      Address address = addressRecord.getAddress();
      assertEquals("UNITED STATES", address.getCountry());
   }

   public void testFindByCriteria_CompanyName() {
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setCompanyName("MONSANTO");

      BusinessAccount[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);

      for (BusinessAccount businessAccount : found) {
         assertEquals("MONSANTO", businessAccount.getCompanyName());
      }
   }

   public void testFindByCriteria_CompanyName_MayContainsSpecialCharacters_DashAndAmpersand() {
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setCompanyName("CEN-TEX SEED & DELINTING INC");

      BusinessAccount[] businessAccounts = client.findByCriteria(criteria);

      assertNotNull(businessAccounts);
      assertTrue(businessAccounts.length > 0);

      for (BusinessAccount businessAccount : businessAccounts) {
         assertEquals("CEN-TEX SEED & DELINTING INC", businessAccount.getCompanyName());
      }
   }

   public void testFindByCriteria_WithOnlyWildcardAsCompanyName_ThrowsIllegalArgumentException() {
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setCompanyName("*");
      try {
         client.findByCriteria(criteria);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Company name must contain a non-wildcard character.", e.getMessage());
      }
   }

   public void testFindByCriteria_CompanyName_WildCard() {
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setCompanyName("Mon*to");

      BusinessAccount[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);

      for (BusinessAccount businessAccount : found) {
         assertTrue(businessAccount.getCompanyName().startsWith("MON") || businessAccount.getCompanyName().startsWith("mon"));
         assertTrue(businessAccount.getCompanyName().endsWith("TO") || businessAccount.getCompanyName().endsWith("to"));
      }
   }

   public void testFindByCriteria_CompanyName_StartsWithWildCard() {
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setCompanyName("*Monsan*");

      BusinessAccount[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);

      for (BusinessAccount businessAccount : found) {
         assertTrue(businessAccount.getCompanyName().contains("MONSAN") || businessAccount.getCompanyName().contains("monsan"));
      }
   }

   public void testFindByCriteria_Location_USA_Country_Subcountry() {
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("NC");
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setCompanyName("AVERY*");
      criteria.setLocation(location);

      BusinessAccount[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);

      for (BusinessAccount businessAccount : found) {
         assertTrue(businessAccount.getCompanyName().startsWith("AVERY"));
         AddressRecord[] addressRecords = businessAccount.getAddressRecords();
         assertNotNull(addressRecords);
         assertTrue(addressRecords.length > 0);
         for (AddressRecord addressRecord : addressRecords) {
            Address address = addressRecord.getAddress();
            assertNotNull(address);
            assertEquals("UNITED STATES", address.getCountry());
            assertEquals("NC", address.getState());
         }
      }
   }

   public void testFindByCriteria_InvalidLocationNames_ThrowsIllegalArgumentException() {
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("In123");
      location.setSubcountryCode("Kar456");
      location.setSubsubcountryName("Man789");
      location.setCity("Ban0");
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setLocation(location);
      try {
         client.findByCriteria(criteria);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(
            "Country Name must be only alphabetic characters." + LINE_SEPARATOR +
               "Subcountry Name must be only alphabetic characters." + LINE_SEPARATOR +
               "Subsubcountry Name must be only alphabetic characters." + LINE_SEPARATOR +
               "City Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindByCriteria_WildCardSubSubCountryAndCity() {
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("NC");
      location.setSubsubcountryName("*MECKLEN*");
      location.setCity("*CHARLOT*");
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setLocation(location);

      BusinessAccount[] found = client.findByCriteria(criteria);
      assertNotNull(found);
      assertTrue(found.length>0);

   }

   public void testFindByCriteria_WithMaxResults() {
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setLocation(location);
      int maxResults=100;
      criteria.setMaxResults(maxResults);
      BusinessAccount[] found = client.findByCriteria(criteria);
      assertNotNull(found);
      assertTrue(found.length==100);

   }

   public void testFindByCriteria_ThrowsResultCountCannotExceedMaxResultsAllowedException()
   {
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
      criteria.setLocation(location);
      int resultCount = 1001;
      criteria.setMaxResults(resultCount);
      try {
         client.findByCriteria(criteria);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Cannot exceed maximum allowed results of 1000.", e.getMessage());
      }
   }

//TODO: Implement when IRD adds ex-USA subcountry and subsubcountries
//   public void testFindByCriteria_Location_Country_Subcountry() {
//      SearchableLocation location = new SearchableLocation();
//      location.setCountryName("INDIA");
//      location.setSubcountryName("KARNATAKA");
//      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
//      criteria.setLocation(location);
//
//      BusinessAccount[] found = client.findByCriteria(criteria);
//
//      assertNotNull(found);
//      assertTrue(found.length > 0);
//
//      for (BusinessAccount businessAccount : found) {
//         AddressRecord[] addressRecords = businessAccount.getAddressRecords();
//         assertNotNull(addressRecords);
//         assertTrue(addressRecords.length > 0);
//         for (AddressRecord addressRecord : addressRecords) {
//            Address address = addressRecord.getAddress();
//            assertNotNull(address);
//            assertEquals("INDIA", address.getCountry());
//            assertEquals("KARNATAKA", address.getState());
//         }
//      }
//   }
//
//   public void testFindByCriteria_Location_Country_Subsubcountry() {
//      SearchableLocation location = new SearchableLocation();
//      location.setCountryName("INDIA");
//      location.setSubcountryName("KARNATAKA");
//      location.setSubsubcountryName("BANGALORE");
//      BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
//      criteria.setLocation(location);
//
//      BusinessAccount[] found = client.findByCriteria(criteria);
//
//      assertNotNull(found);
//      assertTrue(found.length > 0);
//
//      for (BusinessAccount businessAccount : found) {
//         AddressRecord[] addressRecords = businessAccount.getAddressRecords();
//         assertNotNull(addressRecords);
//         assertTrue(addressRecords.length > 0);
//         for (AddressRecord addressRecord : addressRecords) {
//            Address address = addressRecord.getAddress();
//            assertNotNull(address);
//            assertEquals("INDIA", address.getCountry());
//            assertEquals("KARNATAKA", address.getState());
//            assertEquals("BANGALORE", address.getCounty());
//         }
//      }
//   }
}