package com.monsanto.tps.lexicon.account.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.account.BusinessAccount;
import junit.framework.TestCase;

import java.util.Calendar;

/**
 * rrchak1 - Aug 12, 2008 11:50:44 AM
 */
public class BusinessAccountsImpl_PT
   extends TestCase
{

   private BusinessAccounts client;

   protected void setUp()
      throws Exception
   {
      client = new BusinessAccountsImpl(new KerberosStandaloneCredential());
   }

   public void testFindByIds_MultipleValidIds_FindsResults() {
      long[] businessAccountIds = new long[]{
      100126,  10031,   100462,  1005116, 1008122, 1009364, 100943,  1012163, 1014698, 1014812,
      1014867, 101639,  1016730, 1017282, 1017810, 1019274, 1020785, 1021780, 102547,  1025966,
      102766,  10277,   1028873, 1033050, 1035657, 1035972, 1039599, 1040256, 10405,   1041354,
      1041750, 1043185, 10469,   10477,   1047969, 10497,   1052463, 105247,  1052593, 105407,
      1054537, 1055236, 1055784, 1055937, 1057292, 106064,  1060941, 106344,  1063457, 106348,
      106350,  10641,   1064221, 1064228, 106428,  1065001, 1065717, 1068237, 106857,  1068770,
      1072246, 1073604, 1074315, 1075121, 107576,  107672,  1076893, 1080422, 1081684, 1082044,
      1082570, 108403,  1084775, 1085894, 1086171, 1087247, 108839,  1090370, 109184,  1092065,
      1094431, 1094905, 1096199, 1098801, 1098875, 1099018, 1100126, 1102936, 1104552, 1105370,
      1106614, 1106702, 1110219, 111053,  1111009, 1113580, 1114045, 111523,  111539,  1116008
      };
      long beginTime= Calendar.getInstance().getTimeInMillis();
      BusinessAccount[] found = client.findByIds(businessAccountIds);
      long endTime = Calendar.getInstance().getTimeInMillis();
      //System.out.println("timetaken:"+(endTime-beginTime));
      assertNotNull(found);
      assertTrue(endTime-beginTime<30000);      
   }


}
