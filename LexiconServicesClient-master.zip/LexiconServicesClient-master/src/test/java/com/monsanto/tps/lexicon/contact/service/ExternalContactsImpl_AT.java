package com.monsanto.tps.lexicon.contact.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.account.service.BusinessAccounts;
import com.monsanto.tps.lexicon.account.service.BusinessAccountsImpl;
import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator.LINE_SEPARATOR;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;
import org.ietf.jgss.GSSException;

/**
 * nbwald - May 27, 2008 4:46:27 PM
 */
public class ExternalContactsImpl_AT
   extends TestCase
{
   private ExternalContacts client;

   protected void setUp()
      throws Exception
   {
      client = new ExternalContactsImpl(new KerberosStandaloneCredential());
   }

   public void testFindByExternalContactIds_NoIds_FindsNoResults() {
      long[] externalContactIds = new long[0];
      ExternalContact[] found = client.findByExternalContactIds(externalContactIds);

      assertNotNull(found);
      assertEquals(0, found.length);
   }

   public void testFindByExternalContactIds_ValidIds_FindsResults() {
      long[] externalContactIds = new long[]{1963470};

      ExternalContact[] found = client.findByExternalContactIds(externalContactIds);

      assertNotNull(found);
      assertEquals(1, found.length);
      ExternalContact externalContact = found[0];
      assertEquals("1963470", externalContact.getContactID());
      assertEquals(1, externalContact.getAddressRecords().length);
   }

   public void testFindByExternalContactIds_DoesNotFindNonactiveExternalContacts() {
      long[] externalContactIds = new long[]{4165967};
      ExternalContact[] found = client.findByExternalContactIds(externalContactIds);

      assertNotNull(found);
      assertEquals(0, found.length);
   }

   public void testFindByBusinessAccountIds_NoIds_FindsNoResults() {
      long[] businessAccountIds = new long[0];
      ExternalContact[] found = client.findByBusinessAccountIds(businessAccountIds);

      assertNotNull(found);
      assertEquals(0, found.length);
   }

   public void testFindByBusinessAccountIds_ValidIds_FindsResults() {
      long[] businessAccountIds = new long[]{13176, 14716};
      ExternalContact[] found = client.findByBusinessAccountIds(businessAccountIds);

      assertNotNull(found);
      assertTrue(found.length > 0);
   }


   public void testFindByCriteria_WithOnlyWildcardAsCompanyName_ThrowsIllegalArgumentException() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setCompanyName("*");
      try {
         client.findByCriteria(criteria);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Company name must contain a non-wildcard character.", e.getMessage());
      }
   }

   public void testFindByCriteria_CompanyName() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setCompanyName("LINKS FERTILIZER AND LIME SERVICE");

      ExternalContact[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);
      for (ExternalContact externalContact : found) {
         assertEquals("LINKS FERTILIZER AND LIME SERVICE", externalContact.getCompanyName());
      }
   }

   public void testFindByCriteria_CompanyName_Wildcard() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setCompanyName("LINKS FERTILIZER*E");

      ExternalContact[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);
      for (ExternalContact externalContact : found) {
         assertTrue(externalContact.getCompanyName().startsWith("LINKS FERTILIZER"));
         assertTrue(externalContact.getCompanyName().endsWith("E"));
      }
   }

   public void testFindByCriteria_CompanyName_Wildcard_Contains() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setCompanyName("*NKS FERTILIZE*");

      ExternalContact[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);
      for (ExternalContact externalContact : found) {
         assertTrue(externalContact.getCompanyName().contains("LINKS FERTILIZER"));
         assertTrue(externalContact.getCompanyName().endsWith("E"));
      }
   }

   public void testFindByCriteria_CompanyName_HasSpecialCharacters_DashAndAmpersand() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setCompanyName("CEN-TEX SEED & DELINTING INC");

      ExternalContact[] externalContacts = client.findByCriteria(criteria);

      assertNotNull(externalContacts);
      assertTrue(externalContacts.length > 0);
      for (ExternalContact externalContact : externalContacts) {
         assertEquals("CEN-TEX SEED & DELINTING INC", externalContact.getCompanyName());
      }
   }

   public void testFindByCriteria_InvalidFirstAndLastName_ThrowsIllegalArgumentException() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setFirstName("*Mike123*");
      criteria.setLastName("*g32*");
      try {
         client.findByCriteria(criteria);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.\nLast Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindByCriteria_WildcardedFirstAndLastName() {
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setFirstName("*Mike*");
      criteria.setLastName("*ge*");

      ExternalContact[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length > 0);
      for (ExternalContact externalContact : found) {
         assertTrue(externalContact.getFirstName(), StringUtils.toUpperCaseNull(externalContact.getFirstName()).contains("MIKE"));
         assertTrue(externalContact.getLastName(), StringUtils.toUpperCaseNull(externalContact.getLastName()).contains("G"));
      }
   }

   public void testFindByCriteria_WildcardedFirstAndLastName_WithMaxResults() {
      int maxResults = 100;
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setFirstName("*Mike*");
      criteria.setLastName("*ge*");      
      criteria.setMaxResults(maxResults);
      ExternalContact[] found = client.findByCriteria(criteria);

      assertNotNull(found);
      assertTrue(found.length == 100);
   }

   public void testFindByCriteria_InvalidLocationNames_ThrowsIllegalArgumentException() {
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("In123");
      location.setSubcountryCode("Kar456");
      location.setSubsubcountryName("Man789");
      location.setCity("Ban0");
      ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
      criteria.setLocation(location);
      try {
         client.findByCriteria(criteria);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(
            "Country Name must be only alphabetic characters." + LINE_SEPARATOR +
               "Subcountry Name must be only alphabetic characters." + LINE_SEPARATOR +
               "Subsubcountry Name must be only alphabetic characters." + LINE_SEPARATOR +
               "City Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindByCriteria_BusinessAccountLocationCriteria()
      throws Exception
   {
      final int targetBusinessAccountId = 36573;

      ExternalContact externalContactInTargetBusinessAccount = findExternalContactInBusinessAccount(targetBusinessAccountId);
      BusinessAccount targetBusinessAccount = findBusinessAccount(targetBusinessAccountId);

      assertEquals(0, externalContactInTargetBusinessAccount.getAddressRecords().length);

      AddressRecord[] targetBusinessAccountsAddresses = targetBusinessAccount.getAddressRecords();
      assertEquals(2, targetBusinessAccountsAddresses.length);
      Address targetBusinessAccountsAddress = targetBusinessAccountsAddresses[0].getAddress();
      assertEquals("UNITED STATES", targetBusinessAccountsAddress.getCountry());
      assertEquals("NC", targetBusinessAccountsAddress.getState());
      assertEquals("MECKLENBURG", targetBusinessAccountsAddress.getCounty());
      assertEquals("CHARLOTTE", targetBusinessAccountsAddress.getCity());


      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("NC");
      location.setSubsubcountryName("MECKLENBURG");
      location.setCity("CHARLOTTE");
      ExternalContactSearchCriteria wrappedCriteria = new ExternalContactSearchCriteria();
      wrappedCriteria.setLocation(location);
      wrappedCriteria.setCompanyName(externalContactInTargetBusinessAccount.getCompanyName());
      wrappedCriteria.setFirstName(externalContactInTargetBusinessAccount.getFirstName());
      wrappedCriteria.setLastName(externalContactInTargetBusinessAccount.getLastName());

      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      criteria.setExternalContactSearchCriteria(wrappedCriteria);

      ExternalContact[] externalContacts = client.findByCriteria(criteria);
      assertEquals(1, externalContacts.length);
   }

   public void testExecute_ReturnsExternalContactsWhenSearchingWithWildCardedSearchCriteria()
      throws Exception
   {
      ExternalContactByBusinessGeographySearchCriteria searchCriteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria externalContactSearchCriteria = new ExternalContactSearchCriteria();
      SearchableLocation searchableLocation = new SearchableLocation();
      searchableLocation.setCountryName("united states");
      searchableLocation.setSubcountryCode("PA");
      externalContactSearchCriteria.setLocation(searchableLocation);
      externalContactSearchCriteria.setLastName("d*");
      externalContactSearchCriteria.setFirstName("a*");
      searchCriteria.setExternalContactSearchCriteria(externalContactSearchCriteria);
      ExternalContact[] externalContacts = client.findByCriteria(searchCriteria);
      assertNotNull(externalContacts);
   }

   public void testExecute_ReturnsExternalContactsWhenMaxResultsSpecified()
      throws Exception
   {
      int maxResults=100;
      ExternalContactByBusinessGeographySearchCriteria searchCriteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria externalContactSearchCriteria = new ExternalContactSearchCriteria();
      SearchableLocation searchableLocation = new SearchableLocation();
      searchableLocation.setCountryName("united states");
      searchableLocation.setSubcountryCode("PA");
      externalContactSearchCriteria.setLocation(searchableLocation);
      externalContactSearchCriteria.setLastName("*m*");
      externalContactSearchCriteria.setFirstName("*g*");
      externalContactSearchCriteria.setMaxResults(maxResults);
      searchCriteria.setExternalContactSearchCriteria(externalContactSearchCriteria);
      ExternalContact[] externalContacts = client.findByCriteria(searchCriteria);
      assertNotNull(externalContacts);
   }

   private ExternalContact findExternalContactInBusinessAccount(int targetBusinessAccountId)
      throws GSSException
   {
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] externalContactsResult = externalContacts.findByBusinessAccountIds(new long[]{targetBusinessAccountId});
      assertEquals(1, externalContactsResult.length);
      return externalContactsResult[0];
   }

   private BusinessAccount findBusinessAccount(int targetBusinessAccountId)
      throws GSSException
   {
      BusinessAccounts businessAccounts = new BusinessAccountsImpl(new KerberosStandaloneCredential());
      BusinessAccount[] businessAccountsResult = businessAccounts.findByIds(new long[]{targetBusinessAccountId});
      assertEquals(1, businessAccountsResult.length);
      return businessAccountsResult[0];
   }
}
