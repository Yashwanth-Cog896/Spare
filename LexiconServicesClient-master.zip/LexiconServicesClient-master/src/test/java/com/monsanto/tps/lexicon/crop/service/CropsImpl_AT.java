/*
 Crops_AT was created on Jun 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.crop.BayerCode;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.ScientificName;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

import java.util.Collection;
import java.util.List;

/**
 * @author GGSHIV - Jun 30, 2008 5:22:38 PM
 */
public class CropsImpl_AT extends TestCase {

   private Crops client;

   protected void setUp() throws Exception {
      client = new CropsImpl(new KerberosStandaloneCredential());
   }

   public void testFindAll_ReturnsTheSameNumberOfCropsAsSearchingByFullyWildcardedCropName() {
      Crop[] allCrops = client.findAll();
      for (Crop crop : allCrops) {
         assertCropHasValues(crop);
      }
      Crop[] cropsFoundByOnlyWildcard = client.findByName("*");
      assertEquals(allCrops.length, cropsFoundByOnlyWildcard.length);
   }

   public void testFindByBayerCodes_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByBayerCodes(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByBayerCodes_WithInvalidInput_ThrowsIllegalArgumentException() {
      try {
         client.findByBayerCodes(new String[]{"GMS"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByBayerCodes_WithDummyBayerCode_ReturnsNoCrops() {
      Crop[] crops = client.findByBayerCodes(new String[]{"ZZZZZ"});
      assertEmpty(crops);
   }

   public void testFindByBayerCodes_WithSingleBayerCode_ReturnsCorrespondingCrop() {
      Crop[] crops = client.findByBayerCodes(new String[]{"ALLCE"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            assertEquals("ALLCE", bayerCode.getCode());
         }
      }
   }

   public void testFindByBayerCode_WithSingleCode_ReturnsCorrespondingCropWithAllScientificNames() {
      Crop[] crops = client.findByBayerCodes(new String[]{"SINAL"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            assertEquals("SINAL", bayerCode.getCode());
            assertEquals(3, bayerCode.getScientificNames().size());
         }
         assertCropHasValues(crop);
      }
   }

   public void testFindByBayerCodes_WithMultipleBayerCodes_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByBayerCodes(new String[]{"ALLCE", "ALLFI"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            assertTrue("ALLCE".equals(bayerCode.getCode()) || "ALLFI".equals(bayerCode.getCode()));
         }
      }
   }

   public void testFindByAbbreviations_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByAbbreviations(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByAbbreviations_WithInvalidAbbreviation_ThrowsIllegalArgumentException() {
      try {
         client.findByAbbreviations(new String[]{"GMS"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByAbbreviations_WithDummyInput_ReturnsNoCrops() {
      Crop[] crops = client.findByAbbreviations(new String[]{"ZQ"});
      assertEmpty(crops);
   }

   public void testFindByAbbreviations_WithValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByAbbreviations(new String[]{"ZM"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         assertEquals("ZM", crop.getAbbreviation());
      }
   }

   public void testFindByAbbreviationsAndScientificName_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByAbbreviationsAndScientificName(null, null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByAbbreviationsAndScientificName_WithInvalidAbbreviation_ThrowsIllegalArgumentException() {
      try {
         client.findByAbbreviationsAndScientificName(new String[]{"GMS"}, null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByAbbreviationsAndScientificName_WithDummyInput_ReturnsNoCrops() {
      Crop[] crops = client.findByAbbreviationsAndScientificName(new String[]{"ZZ"}, "ZZZZZ");
      assertEmpty(crops);
   }

   public void testFindByAbbreviationsAndScientificName_WithValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByAbbreviationsAndScientificName(new String[]{"ZM"}, "z*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         assertEquals("ZM", crop.getAbbreviation());
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               assertTrue(scientificName.getName().startsWith("Z") || scientificName.getName().startsWith("z"));
            }
         }
      }
   }

   public void testFindByName_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByName(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByName_WithInvalidName_ThrowsIllegalArgumentException() {
      try {
         client.findByName("123NAME");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByName_WithDummyInput_ReturnsNoCrops() {
      Crop[] crops = client.findByName("NROC");
      assertEmpty(crops);
   }

   public void testFindByName_WithWildcard_ReturnsAllMatchingCrops() {
      Crop[] crops = client.findByName("Mu*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
      }
   }

   public void testFindByName_WithOnlyWildcard_ReturnsAllCrops() {
      Crop[] crops = client.findByName("*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
      }
   }

   public void testFindByName_WithOnlyNumbers_ReturnsNoCrops() {
      try {
         client.findByName("1234");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByName_WithValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByName("CORN");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         assertEquals("CORN", crop.getName());
      }
   }

   public void testFindByExactName_ReturnsExactlyOneCrop() {
      Crop[] crops = client.findByName("EUCALYPTUS");

      assertNotEmpty(crops);
      assertEquals(1, crops.length);
      for (Crop crop : crops) {
         assertEquals("EUCALYPTUS", crop.getName());
         List<BayerCode> bayerCodes = crop.getBayerCodes();
         assertNotEmpty(bayerCodes);
         assertEquals(3, bayerCodes.size());

         for (BayerCode bayerCode : bayerCodes) {
            List<ScientificName> scientificNames = bayerCode.getScientificNames();
            assertNotEmpty(scientificNames);
            assertEquals(scientificNames.size(), bayerCode.getCode().equals("EUCSS") ? 2 : 1);
         }
      }
   }


    public void testFindBySinglePubKey_ReturnsExactlyOneCrop() {
     /* Crop[] crops = client.findByPublicKeys(new String[]{"5315"});
      assertNotEmpty(crops);
      assertEquals(1, crops.length);

      for (Crop crop : crops) {
         assertEquals("5315", crop.getPublicKey());
         List<BayerCode> bayerCodes = crop.getBayerCodes();
         assertNotEmpty(bayerCodes);
         assertEquals(2, bayerCodes.size());

         for (BayerCode bayerCode : bayerCodes) {
            List<ScientificName> scientificNames = bayerCode.getScientificNames();
            assertNotEmpty(scientificNames);
            assertEquals(scientificNames.size(), bayerCode.getCode().equals("SINAL") ? 3 : 1);
         }
      }*/
   }

   public void testFindByScientificName_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByScientificName(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByScientificName_WithEmptyInput_ThrowsIllegalArgumentException() {
      try {
         client.findByScientificName("");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByScientificName_WithInvalidName_ThrowsIllegalArgumentException() {
      try {
         client.findByScientificName("1234name");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByScientificName_WithDummyInput_ReturnsNoCrops() {
      Crop[] crops = client.findByScientificName("PAMPA");
      assertEmpty(crops);
   }

   public void testFindByScientificName_WithOnlyNumbers_ReturnsNoCrops() {
      try {
         client.findByScientificName("1234");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByScientificName_WithValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByScientificName("Zea*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               assertTrue(scientificName.getName().startsWith("Zea") || scientificName.getName().startsWith("zea"));
            }
         }
      }
   }

   public void testFindByScientificName_WithWildcardValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByScientificName("Brassica al*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            List<ScientificName> scientificNames = bayerCode.getScientificNames();
            assertEquals(1, scientificNames.size());
            for (ScientificName scientificName : scientificNames) {
               assertTrue(scientificName.getName().startsWith("Brassica al") || scientificName.getName().startsWith("brassica al"));
            }
         }
      }
   }

   public void testFindByScientificName_Withwildcard_ReturnsAllCrops() {
      Crop[] crops = client.findByScientificName("*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
      }
   }

   public void testFindByNameScientificName_WithInvalidAbbreviation_ThrowsIllegalArgumentException() {
      try {
         client.findByNameAndScientificName("CORN", null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByNameAndScientificName_WithDummyInput_ReturnsNoCrops() {
      Crop[] crops = client.findByNameAndScientificName("PAMPA", "GFH");
      assertEmpty(crops);
   }

   public void testFindByNameAndScientificName_WithWildcardInput_ReturnsAllCrops() {
      Crop[] crops = client.findByNameAndScientificName("*", "*");
      assertNotEmpty(crops);
   }

   public void testFindNameByNameAndScientificName_WithValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByNameAndScientificName("CORN", "z*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         assertEquals("CORN", crop.getName());
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               assertTrue(scientificName.getName().startsWith("Z") || scientificName.getName().startsWith("z"));
            }
         }
      }
   }

   public void testFindByNameAndScientificName_WithWildcardValidInput_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByNameAndScientificName("Mus*", "Brassica*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         assertTrue(crop.getName().startsWith("MUS") || crop.getName().startsWith("mus"));
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            List<ScientificName> scientificNames = bayerCode.getScientificNames();
            assertEquals(2, scientificNames.size());
            for (ScientificName scientificName : scientificNames) {
               assertTrue(scientificName.getName().startsWith("Brassica") || scientificName.getName().startsWith("brassica"));
            }
         }
      }
   }

   public void testFindByPublicKeys_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByPublicKeys(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByPublicKeys_WithInvalidInput_ThrowsIllegalArgumentException() {
      try {
         client.findByPublicKeys(new String[]{"GMS"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }


    public void testFindByPublicKeys_WithDummyPublicKey_ReturnsNoCrops() {
     /* Crop[] crops = client.findByPublicKeys(new String[]{"000"});
      assertEmpty(crops);*/
   }


    public void testFindByPublicKeys_WithSinglePublicKey_ReturnsCorrespondingCrop() {
    /*  Crop[] crops = client.findByPublicKeys(new String[]{"1415"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertEquals("1415", crop.getPublicKey());
         assertCropHasValues(crop);
      }*/
   }


    public void testFindByPublicKeys_WithMultiplePublicKeys_ReturnsCorrespondingCrops() {
     /* Crop[] crops = client.findByPublicKeys(new String[]{"1415", "2415"});
      assertNotEmpty(crops);
      assertEquals(2, crops.length);
      for (Crop crop : crops) {
         assertTrue("1415".equals(crop.getPublicKey()) || "2415".equals(crop.getPublicKey()));
         assertCropHasValues(crop);
      }*/
   }

   public void testFindByBayerCodePubKeys_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByBayerCodePublicKeys(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByBayerCodePubKeys_WithInvalidInput_ThrowsIllegalArgumentException() {
      try {
         client.findByBayerCodePublicKeys(new String[]{"GMS"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByBayerCodePubKeys_WithDummyPublicKey_ReturnsNoCrops() {
      Crop[] crops = client.findByBayerCodePublicKeys(new String[]{"000"});
      assertEmpty(crops);
   }

   public void testFindByBayerCodePubKeys_WithSinglePublicKey_ReturnsCorrespondingCrop() {
      Crop[] crops = client.findByBayerCodePublicKeys(new String[]{"9518"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            assertEquals("9518", bayerCode.getPublicKey());
         }
         assertCropHasValues(crop);
      }
   }

   public void testFindByBayerCodePubKeys_WithSinglePublicKey_ReturnsCorrespondingCropWithAllScientificNames() {
      Crop[] crops = client.findByBayerCodePublicKeys(new String[]{"2718"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            assertEquals("2718", bayerCode.getPublicKey());
            assertEquals(4, bayerCode.getScientificNames().size());
         }
         assertCropHasValues(crop);
      }
   }

   public void testFindByBayerCodePubKeys_WithMultiplePublicKeys_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByBayerCodePublicKeys(new String[]{"1118", "1418"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            assertTrue("1118".equals(bayerCode.getPublicKey()) || "1418".equals(bayerCode.getPublicKey()));
         }
         assertCropHasValues(crop);
      }
   }

   public void testFindByScientificPubKeysPubKeys_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByGenusSpeciePublicKeys(null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByScientificPubKeysPubKeys_WithInvalidInput_ThrowsIllegalArgumentException() {
      try {
         client.findByGenusSpeciePublicKeys(new String[]{"GMS"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByScientificPubKeysPubKeys_WithDummyPublicKey_ReturnsNoCrops() {
      Crop[] crops = client.findByGenusSpeciePublicKeys(new String[]{"000"});
      assertEmpty(crops);
   }

   public void testFindByScientificPubKeysPubKeys_WithSinglePublicKey_ReturnsCorrespondingCrop() {
      Crop[] crops = client.findByGenusSpeciePublicKeys(new String[]{"1901"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               assertEquals("1901", scientificName.getPublicKey());
            }
         }
         assertCropHasValues(crop);
      }
   }

   public void testFindByScientificPubKeysPubKeys_WithMultiplePublicKeys_ReturnsCorrespondingCrops() {
      Crop[] crops = client.findByGenusSpeciePublicKeys(new String[]{"1901", "2501"});
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               assertTrue("2501".equals(scientificName.getPublicKey()) || "1901".equals(scientificName.getPublicKey()));
            }
         }
         assertCropHasValues(crop);
      }
   }

   public void testFindByPubkeys_WithNull_ThrowsIllegalArgumentException() {
      try {
         client.findByPubkeysAndScientificName(null, null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByPubkeysAndScientificName_WithInvalidAbbreviation_ThrowsIllegalArgumentException() {
      try {
         client.findByPubkeysAndScientificName(new String[]{"1015"}, null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindByPubkeysAndScientificName_WithDummyInput_ReturnsNoCrops() {
    /*  Crop[] crops = client.findByPubkeysAndScientificName(new String[]{"0000"}, "ZXY");
      assertEmpty(crops);*/
   }

   public void testFindByPubkeysAndScientificName_WithNullInput_ReturnsCorrespondingCrops() {
      try {
         client.findByPubkeysAndScientificName(null, null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

    public void testFindByPubkeysAndScientificName_WithWildcardValidInput_ReturnsCorrespondingCrops() {
      /*Crop[] crops = client.findByPubkeysAndScientificName(new String[]{"5315"}, "Brassica*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            List<ScientificName> scientificNames = bayerCode.getScientificNames();
            assertEquals(2, scientificNames.size());
            for (ScientificName scientificName : scientificNames) {
               assertTrue(scientificName.getName().startsWith("Brassica") || scientificName.getName().startsWith("brassica"));
            }
         }
      }*/
   }


    public void testFindByPubkeysAndScientificName_WithValidInput_ReturnsCorrespondingCrops() {
     /* Crop[] crops = client.findByPubkeysAndScientificName(new String[]{"1015"}, "Zea*");
      assertNotEmpty(crops);
      for (Crop crop : crops) {
         assertCropHasValues(crop);
         assertEquals("1015", crop.getPublicKey());
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               assertTrue(scientificName.getName().startsWith("Zea") || scientificName.getName().startsWith("zea"));
            }
         }
      }*/
   }

   private void assertCropHasValues(Crop crop) {
      assertNotNull(crop.getName());
      assertNotNull(crop.getPublicKey());

      for (BayerCode bayerCode : crop.getBayerCodes()) {
         assertNotNull(bayerCode.getCode());
         assertNotNull(bayerCode.getPublicKey());

         for (ScientificName scientificName : bayerCode.getScientificNames()) {
            assertNotNull(scientificName.getName());
            assertNotNull(scientificName.getPublicKey());
         }
      }

   }

   private void assertNotEmpty(Crop[] crops) {
      assertNotNull(crops);
      assertTrue(crops.length > 0);
   }

   private void assertEmpty(Crop[] crops) {
      assertNotNull(crops);
      assertEquals(0, crops.length);
   }

   private void assertNotEmpty(Collection<?> crops) {
      assertNotNull(crops);
      assertFalse(crops.isEmpty());
   }

}
