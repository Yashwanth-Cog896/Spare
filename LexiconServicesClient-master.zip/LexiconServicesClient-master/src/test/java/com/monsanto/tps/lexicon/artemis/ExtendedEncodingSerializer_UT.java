package com.monsanto.tps.lexicon.artemis;

import com.monsanto.tps.lexicon.uom.UnitOfMeasure;
import junit.framework.TestCase;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * nbwald - Jul 14, 2008 5:52:20 PM
 */
public class ExtendedEncodingSerializer_UT
   extends TestCase
{
   public void testFromCompressedStream_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.fromCompressedStream(null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testFromDocument_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.fromDocument(null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testFromInputStream_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.fromInputStream(null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testFromXML_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.fromXML(null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testToDocument_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.toDocument(null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testToXML_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.toXML(null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testWriteToCompressedStream_ThrowsUnsupportedOperationException()
      throws Exception
   {
      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();
      try {
         serializer.writeToCompressedStream(null, null);
         fail();
      }
      catch(UnsupportedOperationException e) { }
   }

   public void testWriteToAndFromStream_HandlesUTF16Characters()
      throws Exception
   {
      UnitOfMeasure uom = new UnitOfMeasure();
      uom.setSymbol(new String(new byte[] {-2, -1, 0, -75, 0, 103}, "utf-16"));

      assertEquals("�g", uom.getSymbol());

      ExtendedEncodingSerializer serializer = new ExtendedEncodingSerializer();

      ByteArrayOutputStream os = new ByteArrayOutputStream();
      serializer.writeToStream(uom, os);

      UnitOfMeasure deserializedUom = (UnitOfMeasure) serializer.fromStream(new ByteArrayInputStream(os.toByteArray()));
      assertEquals("�g", deserializedUom.getSymbol());

      byte[] expectedBytes = uom.getSymbol().getBytes("utf-16");
      byte[] actualBytes = deserializedUom.getSymbol().getBytes("utf-16");
      assertEquals(expectedBytes.length, actualBytes.length);
      for (int i = 0; i < expectedBytes.length; i++) {
         assertEquals(expectedBytes[i], actualBytes[i]);
      }
      assertEquals(uom.getSymbol(), deserializedUom.getSymbol());
   }
}
