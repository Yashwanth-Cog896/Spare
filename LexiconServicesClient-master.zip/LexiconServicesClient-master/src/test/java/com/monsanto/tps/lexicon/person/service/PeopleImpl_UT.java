package com.monsanto.tps.lexicon.person.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tps.lexicon.person.MinimalPersonRecord;
import com.monsanto.tps.lexicon.person.Person;
import com.monsanto.tps.lexicon.person.PersonRecord;
import static com.monsanto.tps.lexicon.person.service.People.INVALID_PERSON_NAME;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import junit.framework.TestCase;
import org.ietf.jgss.GSSCredential;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

/**
 * nbwald - Apr 30, 2008 10:27:32 AM
 */
public class PeopleImpl_UT extends TestCase {

   private static final int NATHAN_PARTY_ID = 809486;
   private static final int ARUN_PARTY_ID = 654300;

   private static final String ACTIVE_NETWORK_ID = "ATHANGA";
   private static final String INACTIVE_NETWORK_ID = "MAIACO";

   private static final long ACTIVE_PARTY_ID = 654300;
   private static final long INACTIVE_PARTY_ID = 22033;

   private PeopleImpl client;
   private PeopleDataService peopleDataService;

   protected void setUp() throws Exception {
      client = new PeopleImpl(new KerberosStandaloneCredential());
      peopleDataService = mock(PeopleDataService.class);
      client.setPeopleDataService(peopleDataService);
   }

   public void testFindPeopleByNetworkIds_ReturnsZeroResultsIfCannotFindPerson() {
      ResponseEnvelope envelope = new ResponseEnvelope();
      envelope.add(new ArrayList<PersonRecord>());

      when(peopleDataService.call(isA(String.class), isA(CompositeObject.class))).thenReturn(envelope);
      PersonRecord[] personRecords = client.findPeopleByNetworkIds(new String[]{"QQQQQQ"});

      assertNotNull(personRecords);
      assertEquals(0, personRecords.length);
   }

   public void testFindPeopleByNetworkIdsWithNullInput_ThrowsIllegalArgumentException() {
      try {
         client.findPeopleByNetworkIds(null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("People Network Id is Missing, Please provide valid information.", e.getMessage());
      }
   }

   public void testFindPeopleByNetworkIdsWithEmptyInput_ThrowsIllegalArgumentException() {
      try {
         client.findPeopleByNetworkIds(new String[0]);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("People Network Id is Missing, Please provide valid information.", e.getMessage());
      }
   }

   public void testFindPeopleByNetworkIdsWithSymbol_ThrowsIllegalArgumentException() {
      try {
         client.findPeopleByNetworkIds(new String[]{"PNAGAPP+"});
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("People Network Id must be AlphaNumeric characters.", e.getMessage());
      }
   }

   public void testFindPeopleByNetworkIdsBeginningWithNumber_ThrowsIllegalArgumentException() {
      try {
         client.findPeopleByNetworkIds(new String[]{"123PNAGAPP"});
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("People Network Id must be AlphaNumeric characters.", e.getMessage());
      }
   }

   public void testFindPeopleByNetworkIdsWithOnlyNumbers_ThrowsIllegalArgumentException() {
      try {
         client.findPeopleByNetworkIds(new String[]{"3344"});
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("People Network Id must be AlphaNumeric characters.", e.getMessage());
      }
   }

   public void testFindPeopleByNameWithBothNull_ThrowsIllegalArgumentException() {
      try {
         client.findMinimalPersonRecordsByWildcardableFirstAndLastName(null, null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals(INVALID_PERSON_NAME, e.getMessage());
      }
   }

   public void testFindPeopleByNameBothNumbers_ThrowsIllegalArgumentException() {
      try {
         client.findMinimalPersonRecordsByWildcardableFirstAndLastName("1234", "5678");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.\nLast Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindPeopleByNameFirstNameAsNumber_ThrowsIllegalArgumentException() {
      try {
         client.findMinimalPersonRecordsByWildcardableFirstAndLastName("1234", "");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("First Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindPeopleByNameLastNameAsNumber_ThrowsIllegalArgumentException() {
      try {
         client.findMinimalPersonRecordsByWildcardableFirstAndLastName("", "1234");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Last Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindMinimalPersonRecordsByWildcardableFirstAndLastName_FirstNameContainsOnlyOneCharacter_OK() {
      MinimalPersonRecord personRecord = new MinimalPersonRecord();
      ResponseEnvelope envelope = new ResponseEnvelope();
      envelope.add(Arrays.asList(personRecord));

      when(peopleDataService.call(isA(String.class), isA(CompositeObject.class))).thenReturn(envelope);
      MinimalPersonRecord[] personRecords = client.findMinimalPersonRecordsByWildcardableFirstAndLastName("A", "");

      assertNotNull(personRecords);
      assertEquals(1, personRecords.length);
   }

   /*public void testFindMinimalPersonRecordsByWildcardableFirstAndLastName_LastNameContainsOnlyOneCharacter_OK() {
      client.findMinimalPersonRecordsByWildcardableFirstAndLastName("", "A");
   }

   public void testFindPeopleByNetworkIds_CanFindPeople() {
      PersonRecord[] personRecords = client.findPeopleByNetworkIds(new String[]{"NBWALD"});

      assertNotNull(personRecords);
      assertEquals(1, personRecords.length);
      assertHasPersonWithFirstAndLastName(personRecords, "NATHAN", "WALDMAN");
   }

   public void testFindPeopleByNetworkIds_CanFindMultiplePeople() {
      PersonRecord[] personRecords = client.findPeopleByNetworkIds(new String[]{"NBWALD", "ATHANGA"});

      assertNotNull(personRecords);
      assertEquals(2, personRecords.length);
      assertHasPersonWithFirstAndLastName(personRecords, "NATHAN", "WALDMAN");
      assertHasPersonWithFirstAndLastName(personRecords,  "ARUN","THANGAMANI");
   }

   public void testFindPeopleByPartyIds_ReturnsZeroResultsIfCannotFindPerson() {
      PersonRecord[] personRecords = client.findPeopleByPartyIds(new long[]{-1});

      assertNotNull(personRecords);
      assertEquals(0, personRecords.length);
   }*/

   public void testFindPeopleByPartyIds() {
      PersonRecord arunRecord = new PersonRecord();
      Person arun = new Person();
      arun.setFirstName("ARUN");
      arun.setLastName("THANGAMANI");
      arunRecord.setPerson(arun);

      ResponseEnvelope envelope = new ResponseEnvelope();
      envelope.add(Arrays.asList(arunRecord));
      when(peopleDataService.call(isA(String.class), isA(CompositeObject.class))).thenReturn(envelope);

      PersonRecord[] personRecords = client.findPeopleByPartyIds(new long[]{NATHAN_PARTY_ID, ARUN_PARTY_ID});

      assertNotNull(personRecords);
      assertEquals(1, personRecords.length);
      assertHasPersonWithFirstAndLastName(personRecords, "ARUN", "THANGAMANI");
   }

   /*public void testFindMinimalPersonRecordsByNetworkIds_ReturnsZeroResultsIfCannotFindPerson() {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByNetworkIds(new String[]{"QQQQQQ"});

      assertNotNull(minimalPersonRecords);
      assertEquals(0, minimalPersonRecords.length);
   }

   public void testFindMinimalPersonRecordsByNetworkIds_SearchesCaseInsensitively_ReturnsInUppercase()
      throws Exception
   {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByNetworkIds(new String[]{"nbWaLd"});

      assertNotNull(minimalPersonRecords);
      assertEquals(1, minimalPersonRecords.length);

      MinimalPersonRecord minimalPersonRecord = minimalPersonRecords[0];
      assertEquals("NBWALD", minimalPersonRecord.getNetworkId());
   } */

   public void testFindMinimalPersonRecordsByNetworkIds_CanFindMultiplePeople() {
      MinimalPersonRecord arunRecord = new MinimalPersonRecord();
      arunRecord.setFirstName("ARUN");
      arunRecord.setLastName("THANGAMANI");

      MinimalPersonRecord nateRecord = new MinimalPersonRecord();
      nateRecord.setFirstName("NATHAN");
      nateRecord.setLastName("WALDMAN");

      ResponseEnvelope envelope = new ResponseEnvelope();
      envelope.add(Arrays.asList(arunRecord, nateRecord));
      when(peopleDataService.call(isA(String.class), isA(CompositeObject.class))).thenReturn(envelope);

      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByNetworkIds(new String[]{"NBWALD", "ATHANGA"});

      assertNotNull(minimalPersonRecords);
      assertEquals(2, minimalPersonRecords.length);

      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "NATHAN", "WALDMAN");
      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "ARUN", "THANGAMANI");
   }

   public void testFindMinimalPersonRecordsByPartyIds_ReturnsZeroResultsIfCannotFindPerson() {
      ResponseEnvelope envelope = new ResponseEnvelope();
      envelope.add(new ArrayList<MinimalPersonRecord>());

      when(peopleDataService.call(isA(String.class), isA(CompositeObject.class))).thenReturn(envelope);
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByPartyIds(new long[]{-1});

      assertNotNull(minimalPersonRecords);
      assertEquals(0, minimalPersonRecords.length);
   }

   /*public void testFindMinimalPersonRecordsByPartyIds_CanFindMultiplePeople() {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByPartyIds(new long[]{NATHAN_PARTY_ID, ARUN_PARTY_ID});

      assertNotNull(minimalPersonRecords);
      assertEquals(2, minimalPersonRecords.length);

      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "NATHAN", "WALDMAN");
      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "ARUN", "THANGAMANI");
   }

   public void testFindMinimalPersonRecordsByWildcardableFirstAndLastName() {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByWildcardableFirstAndLastName("NATHAN", "WALDMAN");

      assertNotNull(minimalPersonRecords);
      assertEquals(1, minimalPersonRecords.length);

      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "NATHAN", "WALDMAN");
   }

   public void testFindMinimalPersonRecordsByWildcardableFirstAndLastName_FirstAndLastNameAreWildcarded() {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByWildcardableFirstAndLastName("NA*HAN", "WALDM*N");

      assertNotNull(minimalPersonRecords);
      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "NATHAN", "WALDMAN");
   }

   public void testFindMinimalPersonRecordsByWildcardableFirstAndLastName_FirstNameIsNull_OnlySearchesByLastName() {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByWildcardableFirstAndLastName(null, "WALDMAN");

      assertNotNull(minimalPersonRecords);
      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "NATHAN", "WALDMAN");
   }

   public void testFindMinimalPersonRecordsByWildcardableFirstAndLastName_LastNameIsNull_OnlySearchesByFirstName() {
      MinimalPersonRecord[] minimalPersonRecords = client.findMinimalPersonRecordsByWildcardableFirstAndLastName("NATHAN", null);

      assertNotNull(minimalPersonRecords);
      assertHasMinimalPersonRecordWithFirstAndLastName(minimalPersonRecords, "NATHAN", "WALDMAN");
   }*/

   public void testDAOAcceptsSystemSecurityProxy_FakeSystemSecurityProxyDoesNotWork() {
      try {
         People client = new PeopleImpl(new MockSystemSecurityProxy());
         client.findMinimalPersonRecordsByNetworkIds(new String[]{"A"});
         client.findMinimalPersonRecordsByPartyIds(new long[]{-1});
         client.findMinimalPersonRecordsByWildcardableFirstAndLastName("FIRSTNAME", "LASTNAME");
         client.findPeopleByNetworkIds(new String[]{"A"});
         client.findPeopleByPartyIds(new long[]{-1});
         fail("Expected exception from fake system security proxy");
      }
      catch (Exception e) {
         assertNotNull(e.getMessage());
      }
   }

   /*public void testFindPeopleByNetworkIds_ByDefaultFindsOnlyActive()
      throws Exception
   {
      PersonRecord[] personRecords = client.findPeopleByNetworkIds(new String[]{ACTIVE_NETWORK_ID, INACTIVE_NETWORK_ID});

      assertEquals(1, personRecords.length);
      assertEquals(ACTIVE_NETWORK_ID, personRecords[0].getPerson().getUserID());
   }

   public void testFindPeopleByNetworkIds_OnlyActiveFalse()
      throws Exception
   {
      PersonRecord[] personRecords = client.findPeopleByNetworkIds(new String[]{ACTIVE_NETWORK_ID, INACTIVE_NETWORK_ID}, false);

      assertEquals(2, personRecords.length);
   }

   public void testFindPeopleByPartyIds_ByDefaultFindsOnlyActive()
      throws Exception
   {
      PersonRecord[] personRecords = client.findPeopleByPartyIds(new long[]{ACTIVE_PARTY_ID, INACTIVE_PARTY_ID});

      assertEquals(1, personRecords.length);
      assertEquals(ACTIVE_PARTY_ID, personRecords[0].getUniqueID());
   }

   public void testFindPeopleByPartyIds_OnlyActiveFalse()
      throws Exception
   {
      PersonRecord[] personRecords = client.findPeopleByPartyIds(new long[]{ACTIVE_PARTY_ID, INACTIVE_PARTY_ID}, false);

      assertEquals(2, personRecords.length);
   }*/

   private void assertHasPersonWithFirstAndLastName(PersonRecord[] personRecords, String firstName, String lastName) {
      for (PersonRecord personRecord : personRecords) {
         Person person = personRecord.getPerson();
         if (person.getFirstName().equals(firstName) && person.getLastName().equals(lastName)) {
            return;
         }
      }
      fail("Could not find person " + firstName + " " + lastName);
   }

   private void assertHasMinimalPersonRecordWithFirstAndLastName(MinimalPersonRecord[] minimalPersonRecords, String firstName, String lastName) {
      for (MinimalPersonRecord minimalPersonRecord : minimalPersonRecords) {
         if (firstName.equals(minimalPersonRecord.getFirstName()) && lastName.equals(minimalPersonRecord.getLastName())) {
            return;
         }
      }
      fail("Could not find person " + firstName + " " + lastName);
   }

   private class MockSystemSecurityProxy
           implements SystemSecurityProxy {
      public String getUserID() {
         return "FakeUserIDFrom" + getClass().getSimpleName();
      }

      public String getFullName() {
         return "FakeFullNameFrom" + getClass().getSimpleName();
      }

      public int getFailedLogonAttempts() {
         return 0;
      }

      public Date getLastLogon() {
         return new Date();
      }

      public GSSCredential getDelegCredential() {
         return null;
      }
   }
}
