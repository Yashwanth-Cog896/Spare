/*
 CompanyNameAndLocationValidator_UT was created on Jul 29, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import com.monsanto.tps.lexicon.contact.SearchableLocation;
import static com.monsanto.tps.lexicon.validation.CompanyNameAndLocationValidator.MANDATORY_COUNTRY_NAME;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * @author ggshiv - Jul 29, 2008 4:33:56 PM
 */
public class CompanyNameAndLocationValidator_UT
   extends TestCase
{
   public void testValidate_EmptyCompanyName_ThrowsIllegalArgumentException() {
      try {
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("", new SearchableLocation());
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Company Name is Missing, Please provide valid information.", e.getMessage());
      }
   }

   public void testValidate_OnlyWildcardCompanyName_ThrowsIllegalArgumentException() {
      try {
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("**", new SearchableLocation());
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Company name must contain a non-wildcard character.", e.getMessage());
      }
   }

   public void testValidate_WildcardedCompanyName_IsOK() {
      CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("a*", new SearchableLocation());
      validator.validate();
   }

   public void testValidate_WithSpecialCharactersInCompanyName_IsValid() {
      CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("@!#", null);
      validator.validate();
   }

   public void testValidate_WithInvalidCountryName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setCountryName("In*7");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Country Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithOnlySubcountryName_VerifiesCourntyNamePresence_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setSubcountryCode("Karnataka");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(MANDATORY_COUNTRY_NAME, e.getMessage());
      }
   }

   public void testValidate_WithInvalidSubcountryName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setCountryName("In*");
         location.setSubcountryCode("In*7");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Subcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithInvalidSubsubcountryName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setSubsubcountryName("In*7");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Subsubcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithInvalidCityName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setCity("In*7");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("City Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithOnlyWildcardAsCountryName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setCountryName("*");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Country Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithOnlyWildcardAsSubcountryName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setCountryName("In*");
         location.setSubcountryCode("*");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Subcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithOnlyWildcardAsSubsubcountryName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setSubsubcountryName("*");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("Subsubcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testValidate_WithOnlyWildcardAsCityName_ThrowsIllegalArgumentException() {
      try {
         SearchableLocation location = new SearchableLocation();
         location.setCity("*");
         CompanyNameAndLocationValidator validator = new CompanyNameAndLocationValidator("GMS", location);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("City Name must be only alphabetic characters.", e.getMessage());
      }
   }
}
