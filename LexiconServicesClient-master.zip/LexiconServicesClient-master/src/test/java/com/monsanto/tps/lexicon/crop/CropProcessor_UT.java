package com.monsanto.tps.lexicon.crop;

import com.monsanto.tps.lexicon.crop.processor.CropsProcessor;
import com.monsanto.tps.lexiconservices.crop.domain.*;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/27/13
 * Time: 12:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropProcessor_UT extends TestCase {
    
    private String scientificName = "*";
    private List<String> pubkeys = new ArrayList<String>() ;
    private  List<Crop> crops = new ArrayList<Crop>();
    
    public void testHappyPath() {
        CropsProcessor cropsProcessor = new CropsProcessor();
        pubkeys.add("1015");
        CropRetrievalByPubKeysAndScientificNameRequest request = new CropRetrievalByPubKeysAndScientificNameRequest(pubkeys, scientificName, CropPublicKeyTypeEnum.CROP);
        try {
             crops = cropsProcessor.findCropsByPublicKeysAndScientificName(request);
        } catch (Exception e) {

        }
        assertEquals(1,crops.size());
    }

    public void testInvalidRequest() {
        CropsProcessor cropsProcessor = new CropsProcessor();
        CropRetrievalByPubKeysAndScientificNameRequest request = new CropRetrievalByPubKeysAndScientificNameRequest(pubkeys, scientificName, CropPublicKeyTypeEnum.CROP);
        try {
            crops =  cropsProcessor.findCropsByPublicKeysAndScientificName(request);
        } catch (Exception e) {

        }
        assertEquals(0,crops.size());
    }
}
