/*
 Countries_AT was created on Jun 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.geography.country.Country;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * @author GGSHIV - Jun 2, 2008 3:05:27 PM
 */
public class CountriesImpl_AT extends TestCase {
   private Countries client;

   protected void setUp() throws Exception {
      client = new CountriesImpl(new KerberosStandaloneCredential());
   }

   public void testFindCountries_WhenNameIsNull_ThrowsIllegalArgumentException() {
      try {
         client.findCountries((String) null);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenNameIsEmpty_ThrowsIllegalArgumentException() {
      try {
         client.findCountries("");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WithNumberInput_ThrowsIllegalArgumentException() {
      try {
         client.findCountries("1234");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WithInvalidInput_ThrowsIllegalArgumentException() {
      try {
         client.findCountries("INDIA1234");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }


   public void testFindCountries_WhenISOCodeIsNull_ThrowsIllegalArgumentException() {
      try {
         client.findCountries(new String[]{null});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenISOCodeIsEmpty_ThrowsIllegalArgumentException() {
      try {
         client.findCountries(new String[0]);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenISOCodeIsOneChar_ThrowsIllegalArgumentException() {
      try {
         client.findCountries(new String[]{"I"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenISOCodeIsAlphaNum_ThrowsIllegalArgumentException() {
      try {
         client.findCountries(new String[]{"IN12"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenISOCodeIsThreeChar_ThrowsIllegalArgumentException() {
      try {
         client.findCountries(new String[]{"IND"});
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenISOCodeIsNumber_ThrowsIllegalArgumentException() {
      try {
         client.findCountries("12");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_WhenISOCodeIsl_WithInvalidInput_ThrowsIllegalArgumentException() {
      try {
         String[] codes = {"INUS", "I"};
         client.findCountries(codes);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindCountries_ExactCountryName_ReturnsCorrespondingCountry() {
      Country[] countries = client.findCountries("INDIA");
      assertCountryIndia(countries);
   }

   public void testFindCountries_WithWildCard_CountryName_ReturnsMatchingCounries() {
      Country[] countries = client.findCountries("IN*A");
      assertNotNull(countries);
      assertTrue(countries.length > 0);
      for (Country country : countries) {
         assertTrue(country.getName().startsWith("In"));
         assertTrue(country.getName().endsWith("a"));
      }
   }

   public void testFindAllCountries_ReturnsTheSameNumberOfCountriesAsSearchingByFullyWildcardedFindCountries() {
      Country[] allCountries = client.findAllCountries();
      Country[] wildcardOnlyFoundCountries = client.findCountries("*");

      assertEquals(wildcardOnlyFoundCountries.length, allCountries.length);
   }

   public void testFindCountries_WithDummyCountryISOCode_ReturnsNoCountries() {
      Country[] countries = client.findCountries(new String[]{"ZZ"});
      assertNotNull(countries);
      assertEquals(0, countries.length);
   }

   public void testFindCountries_CountryISOCode_ReturnsCorrespondingCountry() {
      Country[] countries = client.findCountries(new String[]{"IN"});
      assertCountryIndia(countries);
   }

   public void testFindCountries_MultipleCountryISOCodes_ReturnsCorrespondingCountries() {
      Country[] countries = client.findCountries(new String[]{"IN", "US"});
      assertNotNull(countries);
      assertEquals(2, countries.length);
   }

   private void assertCountryIndia(Country[] countries) {
      assertNotNull(countries);
      assertEquals(1, countries.length);
      for (Country country : countries) {
         assertEquals("India", country.getName());
         assertEquals("IN", country.getCountryISOcode());
         assertEquals("IND", country.getAbbreviation());
         assertEquals("State", country.getSubCountryDescription());
         assertEquals("District", country.getSubSubCountryDescription());
      }
   }
}
