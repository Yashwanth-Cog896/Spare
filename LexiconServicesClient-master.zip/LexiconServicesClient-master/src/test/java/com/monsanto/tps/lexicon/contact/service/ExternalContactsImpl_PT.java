package com.monsanto.tps.lexicon.contact.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import junit.framework.TestCase;

import java.util.Calendar;

/**
 * rrchak1 - Aug 12, 2008 11:47:27 AM
 */
public class ExternalContactsImpl_PT
   extends TestCase
{
   private ExternalContacts client;

   protected void setUp()
      throws Exception
   {
      client = new ExternalContactsImpl(new KerberosStandaloneCredential());
   }

   public void testFindByExternalContactIds_MultipleValidIds_FindsResults() {
      long[] externalContactIds = new long[]{
         3772494,1954942,3876417,3876109,1936376,1935974,1960945,1962542,1954572,3772519,
         1954970,3877592,1936812,1936547,3983274,3873286,1935979,3898192,4153261,1962546,
         3505253,3780863,3772531,3876521,1936552,1936382,3873291,1960024,1960857,1961297,
         2409832,3978339,3987785,1936804,1937798,1938702,3879071,1936020,1936023,1962544,
         1962566,4247980,3876522,2502596,3876229,3994995,2746336,2745979,1962559,3585780,
         3772538,3981414,3585795,1935976,3978403,3875702,3520461,1961141,1962564,1962867,
         1937442,3877591,3876412,3978307,3123820,3879069,3876130,3885845,2901070,1962592,
         1962608,1954959,3876414,3987784,1973132,3878999,3887783,3876189,3978405,3780430
      };
      long beginTime= Calendar.getInstance().getTimeInMillis();
      ExternalContact[] found = client.findByExternalContactIds(externalContactIds);
      long endTime = Calendar.getInstance().getTimeInMillis();
      //System.out.println("timetaken:"+(endTime-beginTime));      
      assertNotNull(found);
      assertTrue(beginTime-endTime < 30000);
   }

   public void testFindJarrodSmith()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("*Jarrod*");
      realCriteria.setLastName("*Smith*");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindJarrodSmith_WithoutLeadingStar()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("Jarrod*");
      realCriteria.setLastName("Smith*");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindJarrodSmith_WithoutAnyStars()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("Jarrod");
      realCriteria.setLastName("Smith");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindAlmaPrice()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("ND");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("*alma*");
      realCriteria.setLastName("*price*");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindAlmaPrice_WithoutLeadingStar()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("ND");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("alma*");
      realCriteria.setLastName("price*");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindAlmaPrice_WithoutAnyStars()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("ND");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("alma");
      realCriteria.setLastName("price");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindJS()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("*j*");
      realCriteria.setLastName("*s*");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindJS_WithoutLeadingStar()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("j*");
      realCriteria.setLastName("s*");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }

   public void testFindJS_WithoutAnyStars()
      throws Exception
   {
      long start = System.currentTimeMillis();
      SearchableLocation location = new SearchableLocation();
      location.setCountryName("UNITED STATES");
      location.setSubcountryCode("MO");
      ExternalContactByBusinessGeographySearchCriteria criteria = new ExternalContactByBusinessGeographySearchCriteria();
      ExternalContactSearchCriteria realCriteria = new ExternalContactSearchCriteria();
      criteria.setExternalContactSearchCriteria(realCriteria);
      realCriteria.setLocation(location);
      realCriteria.setMaxResults(100);
      realCriteria.setFirstName("j");
      realCriteria.setLastName("s");
      ExternalContacts externalContacts = new ExternalContactsImpl(new KerberosStandaloneCredential());
      ExternalContact[] results = externalContacts.findByCriteria(criteria);
      System.out.println("Total time: " + (System.currentTimeMillis() - start) + " ms");
      for (ExternalContact result : results) {
         System.out.println("result = " + result);
      }
   }
}