package com.monsanto.tps.lexicon.traitstack.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.traitstack.TraitStackRequest;
import com.monsanto.tps.lexicon.traitstack.TraitStackVO;
import junit.framework.TestCase;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Filename:    TraitStacksImpl_AT.java
 * Last Change: rrchak1 On:	Jul 18, 2008
 *
 * @author: rrchak1
 */
public class TraitStacksImpl_AT
   extends TestCase
{

   private TraitStacks client;

   protected void setUp()
      throws Exception
   {
      client = new TraitStacksImpl(new KerberosStandaloneCredential());
   }

   public void testFindByTraitStackPubKey_WithValidPubKey()
      throws Exception
   {
      TraitStackRequest traitStackRequest = new TraitStackRequest();
      traitStackRequest.setPubKeys(new String[]{"1023"});
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(traitStackRequest);
      assertTrue(containsStackWithPubkey(Arrays.asList(traitStackVOs), "1023"));
   }

   public void testFindByTraitStackPubKeyAndCropName_WithValidPubKeyAndCropName()
      throws Exception
   {
      TraitStackRequest traitStackRequest = new TraitStackRequest();
      traitStackRequest.setPubKeys(new String[]{"5123"});
      traitStackRequest.setCropNames(new String[]{"SOYBEANS"});
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(traitStackRequest);
      assertTrue(containsStackWithPubkeyAndCropName(Arrays.asList(traitStackVOs), "5123", "SOYBEANS"));
   }

   public void testFindByTraitStackPubKeyAndReportingName_WithValidPubKeyAndReportingName()
      throws Exception
   {
      TraitStackRequest traitStackRequest = new TraitStackRequest();
      traitStackRequest.setPubKeys(new String[]{"208823"});
      traitStackRequest.setStackAttribute(new String[]{"AGT/ACB/LL/VIP*"});
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(traitStackRequest);
      assertTrue(containsStackWithPubkeyAndReportingName(Arrays.asList(traitStackVOs), "208823", "VIPTERA3110"));
   }

   public void testFindByCropNames_WithValidCropNames()
      throws Exception
   {
      TraitStackRequest traitStackRequest = new TraitStackRequest();
      traitStackRequest.setCropNames(new String[]{"SOYBEANS", "CORN"});
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(traitStackRequest);
      assertFalse(containsStackWithCropName(Arrays.asList(traitStackVOs), "SUNFLOWER"));
   }

   public void testFindByWildcardableStackAttribute_WithValidStackAttribute()
      throws Exception
   {
      TraitStackRequest traitStackRequest = new TraitStackRequest();
      traitStackRequest.setStackAttribute(new String[]{"bt"});
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(traitStackRequest);
      assertTrue(allTraitStacksContainsWildcardStackAttribute(Arrays.asList(traitStackVOs), "bt"));
   }

   public void testFindByPubKey_WithInvalidPubKey()
      throws Exception
   {
      TraitStackRequest traitStackRequest = new TraitStackRequest();
      traitStackRequest.setPubKeys(new String[]{"11111"});
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(traitStackRequest);
      assertTrue(traitStackVOs.length == 0);
   }

   public void testFindBySearchCriteria_EmptyRequest_FindsAllTraits()
      throws Exception
   {
      TraitStackVO[] traitStackVOs = client.findBySearchCriteria(new TraitStackRequest());

      assertTrue(traitStackVOs.length > 0);
   }

   public void testFindBySearchCriteria_PrecommercialOnly()
      throws Exception
   {
      TraitStackRequest request = new TraitStackRequest();
      request.setPrecommercialOnly(true);

      TraitStackVO[] traitStacks = client.findBySearchCriteria(request);
      
      assertTrue(traitStacks.length > 0);
   }

   private boolean containsStackWithPubkey(Collection<TraitStackVO> stacks, String pubkey) {
      for (TraitStackVO stack : stacks) {
         if (pubkey.equals(stack.getTraitStackPubkey())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsStackWithPubkeyAndCropName(List<TraitStackVO> traitStackVOs, String pubkey, String cropName) {
      for (TraitStackVO stack : traitStackVOs) {
         if (pubkey.equals(stack.getTraitStackPubkey()) && cropName.equals(stack.getTraitStackCropName())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsStackWithPubkeyAndReportingName(List<TraitStackVO> traitStackVOs, String pubkey, String reportingName) {
      for (TraitStackVO stack : traitStackVOs) {
         if (pubkey.equals(stack.getTraitStackPubkey()) && reportingName.equals(stack.getTraitStackReportingName())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsStackWithCropName(List<TraitStackVO> traitStackVOs, String cropName) {
      for (TraitStackVO stack : traitStackVOs) {
         if (cropName.equals(stack.getTraitStackCropName())) {
            return true;
         }
      }
      return false;
   }

   private boolean allTraitStacksContainsWildcardStackAttribute(List<TraitStackVO> traitStackVOs, String wildcardStackAttribute) {
      for (TraitStackVO stack : traitStackVOs) {
         if (!(stack.getTraitStackAbbr().contains(wildcardStackAttribute.toUpperCase())
            || stack.getTraitStackReportingName().contains(wildcardStackAttribute.toUpperCase())
            || stack.getTraitStackManfTraitCode().contains(wildcardStackAttribute.toUpperCase()))) {
            return false;
         }
      }
      return true;
   }

}
