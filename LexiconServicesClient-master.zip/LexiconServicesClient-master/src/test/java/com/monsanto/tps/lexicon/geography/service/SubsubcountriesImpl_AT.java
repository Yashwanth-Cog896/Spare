/*
 Subsubcountries_AT was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.tps.lexicon.geography.service.SubsubcountriesImpl.FIELDS_REQUIRED;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator.LINE_SEPARATOR;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * @author GGSHIV - Jun 10, 2008 7:17:54 PM
 */
public class SubsubcountriesImpl_AT extends TestCase {
   private Subsubcountries client;

   protected void setUp()
           throws Exception {
      client = new SubsubcountriesImpl(new KerberosStandaloneCredential());
   }

   public void testFindSubsubcountriesByName_WithNullcountryISOCode_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = null;
         String subcountryName = "Ka*";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code is Missing, Please provide valid information.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithAllNulls_ThrowsIllegalArgumentException() {
      try {
         client.findSubsubcountriesByName(null, null, null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals(FIELDS_REQUIRED, e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithAllEmptyValues_ThrowsIllegalArgumentException() {
      try {
         client.findSubsubcountriesByName("", "", "");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {

         assertEquals("Country ISO Code is Missing, Please provide valid information." + LINE_SEPARATOR +
                 "Subcountry Name is Missing, Please provide valid information." + LINE_SEPARATOR +
                 "Subsubcountry Name is Missing, Please provide valid information.", e.getMessage());
      }
   }


   public void testFindSubsubcountriesByName_WithNullsubcountryName_ThrowsIllegalArgumentException() {

      String countryISOCode = "IN";
      String subcountryName = null;
      String subsubcountryName = "Be*";
      Subsubcountry[] subsubcountries = client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);

      assertTrue(subsubcountries.length > 0);

   }

   public void testFindSubsubcountriesByName_WithNullsubsubcountryName_ThrowsIllegalArgumentException() {
      String countryISOCode = "IN";
      String subcountryName = "Ka*";
      String subsubcountryName = null;
      Subsubcountry[] subsubcountries = client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);

      assertTrue(subsubcountries.length > 0);
      for (Subsubcountry subsubcountry : subsubcountries) {
         assertSubsubcountry(subsubcountry);
      }
   }

   public void testFindSubsubcountriesByName_WithEmptycountryISOCode_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = " ";
         String subcountryName = "Ka*";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code is Missing, Please provide valid information.", e.getMessage());

      }
   }

   //  TODo :
   public void testFindSubsubcountriesByName_WithEmptyNullsubcountryName_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "IN";
         String subcountryName = " ";
         String subsubcountryName = "Be*";
         Subsubcountry[] subsubcountries = client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Subcountry Name is Missing, Please provide valid information.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithEmptysubsubcountryName_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "IN";
         String subcountryName = "Ka*";
         String subsubcountryName = " ";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Subsubcountry Name is Missing, Please provide valid information.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithOneCharAsISOCode_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "I";
         String subcountryName = "Ka*";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must be Exactly two alphabetic characters.", e.getMessage());

      }
   }

   public void testFindSubsubcountriesByName_WithThreeCharAsISOCode_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "IND";
         String subcountryName = "Ka*";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must be Exactly two alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_SubCountryNameWithNumber_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "IN";
         String subcountryName = "Ka123";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Subcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_ISOCodeWithNumber_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "34";
         String subcountryName = "Ka*";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must be Exactly two alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_SubcountryNameWithNumber_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "34";
         String subcountryName = "KA34";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must be Exactly two alphabetic characters." + LINE_SEPARATOR + "Subcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithNumberAsSubsubcountryName_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "34";
         String subcountryName = "KA34";
         String subsubcountryName = "1234";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must be Exactly two alphabetic characters." + LINE_SEPARATOR +
                 "Subcountry Name must be only alphabetic characters." + LINE_SEPARATOR +
                 "Subsubcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName() throws Exception {
      String countryISOCode = "IN";
      String subcountryName = "Ka*";
      String subsubcountryName = "Be*";
      Subsubcountry[] subsubcountries = client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);

      assertTrue(subsubcountries.length > 0);
      for (Subsubcountry subsubcountry : subsubcountries) {
         assertSubsubcountry(subsubcountry);
      }
   }

   public void testFindSubsubcountriesByName_WithInvalidcountryISOCode_ThrowsIllegalArgumentException()
           throws Exception {
      try {
         String countryISOCode = "INDIA";
         String subcountryName = "Ka*";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must be Exactly two alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithInvalidsubcountryName_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "IN";
         String subcountryName = "Karnataka1234";
         String subsubcountryName = "Be*";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Subcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindSubsubcountriesByName_WithInvalidsubsubcountryName_ThrowsIllegalArgumentException() {
      try {
         String countryISOCode = "IN";
         String subcountryName = "Ka*";
         String subsubcountryName = "Bellary1234";
         client.findSubsubcountriesByName(countryISOCode, subcountryName, subsubcountryName);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {
         assertEquals("Subsubcountry Name must be only alphabetic characters.", e.getMessage());
      }
   }

   public void testFindAllSubsubcountries_ReturnsTheSameResultsAsFindSubsubcountriesByFullyWildcardedName() {
      String countryISOCode = "IN";
      String subcountryName = "Ka*";
      Subsubcountry[] fullyWildcardedSubsubcountries = client.findSubsubcountriesByName(countryISOCode, subcountryName, "*");
      Subsubcountry[] allSubsubcountries = client.findAllSubsubcountries(countryISOCode, subcountryName);

      assertEquals(fullyWildcardedSubsubcountries.length, allSubsubcountries.length);
   }

   public void testFindSubsubcountriesBySubcountriesAbbreviation() {
      String countryISOCode = "IN";
      String[] subcountryAbbr = {"KA"};
      String subsubcountryName = "Be*";
      Subsubcountry[] subsubcountries = client.findSubsubcountriesBySubcountriesAbbreviation(countryISOCode, subcountryAbbr, subsubcountryName);

      assertTrue(subsubcountries.length > 0);
      for (Subsubcountry subsubcountry : subsubcountries) {
         assertSubsubcountry(subsubcountry);
      }
   }

   private void assertSubsubcountry(Subsubcountry subsubcountry) {
      assertEquals("KA", subsubcountry.getAbbreviation());
      assertEquals("IN", subsubcountry.getCountryISOCode());
      assertEquals("District", subsubcountry.getDescription());
   }
}
