package com.monsanto.tps.lexicon.person.service;

import com.monsanto.tps.lexicon.person.NetworkID;
import com.monsanto.tps.lexicon.person.PartyID;
import junit.framework.TestCase;

/**
 * nbwald - May 5, 2008 11:52:49 AM
 */
public class PeopleRecordQueryIdBuilder_UT
   extends TestCase
{
   public void testBuildFromNetworkIds()
      throws Exception
   {
      String[] networkIdStrings = new String[] { "ABCDEF", "GHIJKL" };
      PeopleRecordQueryIdBuilder builder = new PeopleRecordQueryIdBuilder();
      NetworkID[] networkIDs = builder.buildByNetworkIds(networkIdStrings);

      assertEquals(2, networkIDs.length);
      assertEquals(networkIdStrings[0], networkIDs[0].getNetworkId());
      assertEquals(networkIdStrings[1], networkIDs[1].getNetworkId());
   }
   
   public void testBuildFromPartyIds()
      throws Exception
   {
      long[] partyIdValues = new long[] { 1, 2 };
      PeopleRecordQueryIdBuilder builder = new PeopleRecordQueryIdBuilder();
      PartyID[] partyIDs = builder.buildByPartyIds(partyIdValues);

      assertEquals(2, partyIDs.length);
      assertEquals("1", partyIDs[0].getPartyId());
      assertEquals("2", partyIDs[1].getPartyId());
   }
}
