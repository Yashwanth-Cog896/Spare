package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * nbwald - Jun 8, 2008 4:27:34 PM
 */
public class SubcountriesImpl_AT extends TestCase {

   private Subcountries client;

   protected void setUp() throws Exception {
      client = new SubcountriesImpl(new KerberosStandaloneCredential());
   }

   public void testFindSubcountriesByName_WhenSubcountriesNameisNull_ThrowsIllegalArgumentException() throws Exception {
      try {
         String countryISOCode = "US";
         String subcountryName = null;
         client.findSubcountriesByName(countryISOCode, subcountryName);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindSubcountriesByName_WhenSubcountriesNameisInvalid_ThrowsIllegalArgumentException() throws Exception {
      try {
         String countryISOCode = "US";
         String subcountryName = "Misson1234";
         client.findSubcountriesByName(countryISOCode, subcountryName);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }


   public void testFindSubcountriesByName() throws Exception {
      String countryISOCode = "US";
      String subcountryName = "Missouri";
      Subcountry[] subcountries = client.findSubcountriesByName(countryISOCode, subcountryName);

      assertEquals(1, subcountries.length);
      Subcountry missouri = subcountries[0];
      assertEquals("Missouri", missouri.getName());
      assertEquals("MO", missouri.getAbbreviation());
      assertEquals("US", missouri.getCountryISOCode());
      assertEquals("State", missouri.getDescription());
   }

   public void testFindSubcountriesByName_SubCountryNameIsCaseInsensitive() throws Exception {
      String countryISOCode = "US";
      String subcountryName = "MiSSoUri";
      Subcountry[] subcountries = client.findSubcountriesByName(countryISOCode, subcountryName);

      assertEquals(1, subcountries.length);
      Subcountry missouri = subcountries[0];
      assertEquals("Missouri", missouri.getName());
      assertEquals("MO", missouri.getAbbreviation());
      assertEquals("US", missouri.getCountryISOCode());
      assertEquals("State", missouri.getDescription());
   }

   public void testFindSubcountriesByName_SubCountryNameIsWildcardable() throws Exception {
      String countryISOCode = "US";
      String subcountryName = "Miss*ri";
      Subcountry[] subcountries = client.findSubcountriesByName(countryISOCode, subcountryName);

      assertEquals(1, subcountries.length);
      Subcountry missouri = subcountries[0];
      assertEquals("Missouri", missouri.getName());
      assertEquals("MO", missouri.getAbbreviation());
      assertEquals("US", missouri.getCountryISOCode());
      assertEquals("State", missouri.getDescription());
   }

   public void testFindAllSubcountries_FindsAllSubcountriesByFullyWildcardedName() throws Exception {
      Subcountry[] allSubcountries = client.findAllSubcountries("US");
      Subcountry[] fullyWilcardedSubcoutries = client.findSubcountriesByName("US", "*");

      assertEquals(fullyWilcardedSubcoutries.length, allSubcountries.length);
   }

   public void testFindSubcountriesByAbbreviation_WhenSubcountriesAbbreviationisNull_ThrowsIllegalArgumentException() throws Exception {
      try {
         String countryISOCode = "IN";
         String[] subcountryAbbr = {null};
         client.findSubcountriesByAbbreviation(countryISOCode, subcountryAbbr);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindSubcountriesByAbbreviation_WhenSubcountriesAbbreviationisInvalid_ThrowsIllegalArgumentException() throws Exception {
      try {
         String countryISOCode = "IN";
         String[] subcountryAbbr = {"KARNATAKA"};
         client.findSubcountriesByAbbreviation(countryISOCode, subcountryAbbr);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
      }
   }

   public void testFindSubcountriesByAbbreviation() throws Exception {
      String countryISOCode = "IN";
      String[] subcountryAbbr = {"KA"};
      Subcountry[] subcountries = client.findSubcountriesByAbbreviation(countryISOCode, subcountryAbbr);

      assertEquals(1, subcountries.length);
      Subcountry karnataka = subcountries[0];
      assertKarnataka(karnataka);
   }

   public void testFindSubcountriesByMultipleAbbreviation() throws Exception {
      String countryISOCode = "IN";
      String[] subcountryAbbr = {"KA", "MH"};
      Subcountry[] subcountries = client.findSubcountriesByAbbreviation(countryISOCode, subcountryAbbr);
      assertEquals(2, subcountries.length);
      assertKarnataka(subcountries[0]);
   }

   private void assertKarnataka(Subcountry karnataka) {
      assertEquals("Karnataka", karnataka.getName());
      assertEquals("KA", karnataka.getAbbreviation());
      assertEquals("IN", karnataka.getCountryISOCode());
      assertEquals("State", karnataka.getDescription());
   }
}
