/*
 LexiconServicesClientRequestValidator_UT was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator.EMPTY_FIELDS;
import static com.monsanto.tps.lexicon.validation.PropertyReader.*;
import junit.framework.TestCase;

/**
 * @author GGSHIV - Jul 1, 2008 6:31:55 PM
 */
public class LexiconServicesClientRequestValidator_UT
   extends TestCase
{
   public static final String IMPROPER_VALIDATION = "Expected validation to throw an IllegalArgumentException";
   private static final String VALID_FIELD = "Name";
   private static final String[] VALID_FIELDS = {VALID_FIELD, "Age"};
   private static final String[] VALID_VALUES = {"ABC", "26"};
   private LexiconServicesClientRequestValidator validator;

   protected void setUp()
      throws Exception
   {
      validator = new LexiconServicesClientRequestValidator(LexiconServicesClientRequestValidator.class);
   }

   public void testValidateField_WithNonExistingProperties_ThrowsMissingFieldMessage() {
      try {
         new LexiconServicesClientRequestValidator(LexiconArtemisService.class);
         fail(IMPROPER_VALIDATION);
      }
      catch (RuntimeException e) {
      }
   }

   public void testValidateField_WithNull_ThrowsMissingFieldMessage() {
      String s = null;
      try {
         validator.validateField(s, s);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(getMissingFieldProperty(), e.getMessage());
      }
   }

   public void testValidateField_WithNullValue_ThrowsMissingFieldMessage() {
      String s = null;
      try {
         validator.validateField(VALID_FIELD, s);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(VALID_FIELD + getMissingFieldProperty(), e.getMessage());
      }
   }

   public void testValidateField_WithNonExistingField_ThrowsMissingFieldFormatMessage() {
      try {
         validator.validateField("ABC", "");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("ABC" + getMissingFormatProperty(), e.getMessage());
      }
   }

   public void testValidateField_VerifiesFieldNameExistanceInErrorMessagesAndFieldFormatMessagesProperites() {
      validator.validateField(VALID_FIELD, "GMS");
   }

   public void testValidateField_NameWithNumber_ThrowsValidationMessage() {
      try {
         validator.validateField(VALID_FIELD, "123");
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(getMessageProperty(VALID_FIELD), e.getMessage());
      }
   }

   public void testValidateField_WithInvalidNames_ThrowsValidationMessage() {
      String[] names = {"GMS", "G123", "James"};
      try {
         validator.validateField(VALID_FIELD, names);
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(getMessageProperty(VALID_FIELD), e.getMessage());
      }
   }

   public void testValidateFields_WithEmptyField_ThrowsMissingFieldMessage() {
      try {
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(EMPTY_FIELDS, e.getMessage());
      }
   }

   public void testValidateFields_WithNullField_ThrowsMissingFieldMessage() {
      String[] s = null;
      try {
         validator.addField(null, s);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(getMissingFieldProperty(), e.getMessage());
      }
   }

   public void testValidateFields_WithNullValue_ThrowsMissingFieldMessage() {
      String[] s = null;
      try {
         validator.addField(VALID_FIELD, s);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(VALID_FIELD + getMissingFieldProperty(), e.getMessage());
      }
   }

   public void testValidateFields_WithNonExistingField_ThrowsMissingFieldMessage() {
      String[] s = {"Name", "ABC"};
      try {
         validator.addField("ABC", s);
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals("ABC" + getMissingFormatProperty(), e.getMessage());
      }
   }

   public void testValidateFields_WithEmptyValues_ThrowsMissingFieldMessage() {
      try {
         validator.addField("", "");
         validator.addField("", "");
         validator.validate();
         fail(IMPROPER_VALIDATION);
      }
      catch (IllegalArgumentException e) {
         assertEquals(getMissingFieldProperty(), e.getMessage());
      }
   }

   public void testValidateFields_WithValidValues() {
      validator.addField(VALID_FIELDS[0], VALID_VALUES[0]);
      validator.addField(VALID_FIELDS[1], VALID_VALUES[1]);
      validator.validate();
   }
}
