package com.monsanto.tps.lexicon.uom.service;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tps.lexicon.uom.UnitOfMeasure;
import static com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator_UT.IMPROPER_VALIDATION;
import junit.framework.TestCase;

/**
 * Filename:    UnitOfMeasures_AT.java
 * Last Change: rrchak1 On:	Jun 16, 2008
 *
 * @author: rrchak1
 */
public class UnitsOfMeasureImpl_AT
   extends TestCase {

   private UnitsOfMeasure client;

   protected void setUp() throws Exception {
      client = new UnitsOfMeasureImpl(new KerberosStandaloneCredential());
   }

   public void testFindAll_ReturnsTheSameNumberOfUOMsAsSearchingByFullyWildcardedUOMName() {
      UnitOfMeasure[] allUOMs = client.findAll();
      assertUnitsOfMeasureHaveValues(allUOMs);
      UnitOfMeasure[] uomFoundByOnlyWildcard = client.findByName("*");
      assertEquals(allUOMs.length, uomFoundByOnlyWildcard.length);
   }

   public void testFindByCountryISOCode_WithNullInput() throws Exception {
      try {
         client.findByCountryISOCode(null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCountryISOCode_WithEmptyInput() throws Exception {
      try {
         client.findByCountryISOCode("");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCountryISOCode_WithDummyCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCountryISOCode("ZZ");
      assertEmpty(unitsOfMeasure);
   }

   public void testFindByCountryISOCode_WithValidCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCountryISOCode("IN");
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindByCountryISOcodeAndDimension_WithNullInput() throws Exception {
      try {
         client.findByCountryISOcodeAndDimension(null, null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCountryISOcodeAndDimension_WithEmptyInput() throws Exception {
      try {
         client.findByCountryISOcodeAndDimension("", "");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCountryISOcodeAndDimension_WithDummyCode() throws Exception {
      try {
         client.findByCountryISOcodeAndDimension("ZZ", null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCountryISOcodeAndDimension_WithValidCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCountryISOcodeAndDimension("IN", "LENGTH");
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindByCountryISOcodeAndDimension_WithWildcardDimensionCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCountryISOcodeAndDimension("IN", "LE*");
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindByCodes_WithNullInput() throws Exception {
      try {
         client.findByCodes(null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCodes_WithEmptyInput() throws Exception {
      try {
         client.findByCodes(new String[0]);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindByCodes_WithDummyCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCodes(new String[]{"ZZZ"});
      assertEmpty(unitsOfMeasure);
   }

   public void testFindByCodes_WithValidCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCodes(new String[]{"M"});
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindByCodes_WithMultipleCodes() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCodes(new String[]{"M", "L"});
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindUOMByCodes_WithValidCode_ThatReturnsNonUTF8Values() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByCodes(new String[]{"MC"});
      assertNotEmpty(unitsOfMeasure);
      UnitOfMeasure microGram = unitsOfMeasure[0];
      assertEquals("MC", microGram.getCode());
      assertEquals("Mass", microGram.getDimension());
      assertEquals("Microgram", microGram.getName());
      assertEquals("Metric", microGram.getUnitType());
      assertEquals('g', microGram.getSymbol().charAt(1));
      assertEquals('�', microGram.getSymbol().charAt(0));    
   }

   public void testFindUOMbyWildcardDimesion_WithNullInput() throws Exception {
      try {
         client.findByWildcardableDimension(null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindUOMbyWildcardDimesion_WithEmptyInput() throws Exception {
      try {
         client.findByWildcardableDimension("");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindUOMbyWildcardDimesion_WithDummyCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByWildcardableDimension("ZZ");
      assertEmpty(unitsOfMeasure);
   }

   public void testFindUOMbyWildcardDimesion_WithValidCode() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findByWildcardableDimension("LE*");
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindBySymbolsAndDimension_WithNullInput() throws Exception {
      try {
         client.findBySymbolsAndDimension(null, null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindBySymbolsAndDimension_WithEmptyInput() throws Exception {
      try {
         client.findBySymbolsAndDimension(new String[]{""}, "");
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindBySymbolsAndDimension_WithDummySymbol() throws Exception {
      try {
         client.findBySymbolsAndDimension(new String[]{"ZZZZ"}, null);
         fail(IMPROPER_VALIDATION);
      } catch (IllegalArgumentException e) {}
   }

   public void testFindBySymbolsAndDimension_WithValidInput() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findBySymbolsAndDimension(new String[]{"M"}, "LENGTH");
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindBySymbolsAndDimension_WithWildcardDimension() throws Exception {
      UnitOfMeasure[] unitsOfMeasure = client.findBySymbolsAndDimension(new String[]{"M"}, "LE*");
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindUOMByName_UnitOfMeasureIsWildcardable() throws Exception {
      String uomName = "*oun*";
      UnitOfMeasure[] unitsOfMeasure = client.findByName(uomName);
      assertUnitsOfMeasureHaveValues(unitsOfMeasure);
   }

   public void testFindUOMByName_WithOracleWildCardInSearchCriteria() throws Exception {
      String uomName = "*%*";
      UnitOfMeasure[] unitsOfMeasure = client.findByName(uomName);

      assertNotEmpty(unitsOfMeasure);
      for (UnitOfMeasure unitOfMeasure : unitsOfMeasure) {
         assertTrue(unitOfMeasure.getCode().contains("%"));
      }
   }

   private void assertUnitsOfMeasureHaveValues(UnitOfMeasure[] unitsOfMeasure) {
      assertNotEmpty(unitsOfMeasure);
      for (UnitOfMeasure unitOfMeasure : unitsOfMeasure) {
         assertNotNull(unitOfMeasure.getDimension());
         assertNotNull(unitOfMeasure.getSymbol());
         assertNotNull(unitOfMeasure.getCode());
      }
   }

   private void assertEmpty(UnitOfMeasure[] unitsOfMeasure) {
      assertNotNull(unitsOfMeasure);
      assertEquals(0, unitsOfMeasure.length);
   }

   private void assertNotEmpty(UnitOfMeasure[] unitsOfMeasure) {
      assertNotNull(unitsOfMeasure);
      assertTrue(unitsOfMeasure.length > 0);
   }
}
