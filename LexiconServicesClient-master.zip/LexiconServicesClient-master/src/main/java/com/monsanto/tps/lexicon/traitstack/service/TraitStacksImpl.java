package com.monsanto.tps.lexicon.traitstack.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.traitstack.TraitStackRequest;
import com.monsanto.tps.lexicon.traitstack.TraitStackVO;

import java.util.Collection;

/**
 * Filename:    TraitStacksImpl.java
 * Last Change: rrchak1 On:	Jul 18, 2008
 *
 * @author: rrchak1
 */
public class TraitStacksImpl extends LexiconArtemisService
        implements TraitStacks
{
    private String TRAIT_STACK_SEARCH_SERVICE = "TraitStackSearch";

    public TraitStacksImpl(SystemSecurityProxy systemSecurityProxy) {
        super(systemSecurityProxy);
    }

    public TraitStackVO[] findBySearchCriteria(TraitStackRequest traitStackRequest) {
        return find (traitStackRequest, TRAIT_STACK_SEARCH_SERVICE);
    }

    private TraitStackVO[] find(TraitStackRequest traitStackRequest, String traitStackSearchService) {
        Collection<TraitStackVO> traitStackVOs = invokeService(traitStackRequest, traitStackSearchService, TraitStackVO.class);
        return traitStackVOs.toArray(new TraitStackVO[traitStackVOs.size()]);
    }
}
