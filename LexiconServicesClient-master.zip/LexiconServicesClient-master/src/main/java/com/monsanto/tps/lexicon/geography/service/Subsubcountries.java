package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

/**
 * nbwald - Jul 1, 2008 2:11:07 PM
 */
public interface Subsubcountries
{
   Subsubcountry[] findAllSubsubcountries(String countryISOCode, String subcountryName);

   Subsubcountry[] findSubsubcountriesByName(String countryISOCode, String subcountryName, String subsubcountryName);

   Subsubcountry[] findSubsubcountriesBySubcountriesAbbreviation(String countryISOCode, String[] subcountryAbbr, String subsubcountryName);
}
