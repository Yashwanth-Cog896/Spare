/*
 LexiconArtemisServiceXmlSerializerProvider was created on May 13, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.artemis;

import com.monsanto.services.client.common.envelope.EnvelopeXmlSerializerBuilderMappingRegister;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * @author GGSHIV - May 13, 2008 2:54:08 PM
 */
public class LexiconArtemisServiceXmlSerializerProvider
   implements XmlSerializerProvider
{
   public static final String NAMESPACE = "urn:monsanto.com:Lex_LexiconArtemisServices";

   public XmlSerializer getXmlSerializer() {
      XmlSerializerBuilder builder = createSerializerBuilder();
      registerEnvelopeMappings(builder);
      return builder.createSerializer();
   }

   private XmlSerializerBuilder createSerializerBuilder() {
      // TODO need to figure out a better, more accurate way to do this.
      XmlSerializerBuilder builder = new XmlSerializerBuilder();
      builder.setClassLoader(getClass().getClassLoader());
      return builder;
   }

   private void registerEnvelopeMappings(XmlSerializerBuilder builder) {
      EnvelopeXmlSerializerBuilderMappingRegister register = new EnvelopeXmlSerializerBuilderMappingRegister();
      register.registerMappings(builder, NAMESPACE);
   }

//   private class ExtendedEncodingXmlSerializerBuilder
//      extends XmlSerializerBuilder
//   {
//      public XmlSerializer createSerializer() {
//         XmlSerializer serializer = super.createSerializer();
//         return new ExtendedEncodingSerializer(serializer);
//      }
//   }
//
//   private class ExtendedEncodingSerializer
//      implements XmlSerializer
//   {
//      private final XmlSerializer delegate;
//
//      public ExtendedEncodingSerializer(XmlSerializer delegate) {
//         this.delegate = delegate;
//      }
//
//      public Object fromCompressedStream(InputStream inputStream)
//         throws DeserializationException
//      {
//         return delegate.fromCompressedStream(inputStream);
//      }
//
//      public Object fromDocument(Document document)
//         throws DeserializationException
//      {
//         return delegate.fromDocument(document);
//      }
//
//      public Object fromInputStream(InputStream inputStream)
//         throws DeserializationException
//      {
//         return delegate.fromInputStream(inputStream);
//      }
//
//      public Object fromStream(InputStream inputStream) {
//         try {
//            return delegate.fromXML(getString(inputStream));
//         }
//         catch (DeserializationException e) {
//            throw new RuntimeException(e);
//         }
//      }
//
//      private String getString(InputStream inputStream) {
//         try {
//            InputStreamReader isReader = new InputStreamReader(inputStream, "UTF-8");
//            BufferedReader reader = new BufferedReader(isReader);
//            StringBuilder stringBuilder = new StringBuilder();
//            String line = reader.readLine();
//            while(line != null) {
//               stringBuilder.append(line).append("\n");
//               line = reader.readLine();
//            }
//            return stringBuilder.toString();
//         }
//         catch (IOException e) {
//            throw new RuntimeException(e);
//         }
//      }
//
//      public Object fromXML(String xml)
//         throws DeserializationException
//      {
//         return delegate.fromXML(xml);
//      }
//
//      public Document toDocument(Object object)
//         throws SerializationException
//      {
//         return delegate.toDocument(object);
//      }
//
//      public String toXML(Object object) {
//         return delegate.toXML(object);
//      }
//
//      public void writeToCompressedStream(Object request, OutputStream outputStream)
//         throws SerializationException
//      {
//         delegate.writeToCompressedStream(request, outputStream);
//      }
//
//      public void writeToStream(Object request, OutputStream outputStream) {
//         delegate.writeToStream(request, outputStream);
//      }
//   }
}