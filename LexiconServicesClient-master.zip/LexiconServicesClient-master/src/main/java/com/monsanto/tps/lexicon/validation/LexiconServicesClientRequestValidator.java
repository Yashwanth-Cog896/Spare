/*
 LexiconServicesClientRequestValidator was created on Jun 27, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import com.monsanto.Util.StringUtils;
import static com.monsanto.tps.lexicon.validation.PropertyReader.getFormatProperty;
import static com.monsanto.tps.lexicon.validation.PropertyReader.getMessageProperty;
import static com.monsanto.tps.lexicon.validation.PropertyReader.getMissingFieldProperty;
import static com.monsanto.tps.lexicon.validation.PropertyReader.getMissingFormatProperty;
import static com.monsanto.tps.lexicon.validation.PropertyReader.loadProperties;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author GGSHIV - Jun 27, 2008 2:13:15 PM
 */
public class LexiconServicesClientRequestValidator {

   public static final String LINE_SEPARATOR = StringUtils.getLineSeparator();
   public static final String EMPTY_FIELDS = "No fields to validate.";
   private Map<String, String[]> fieldMap;

   public LexiconServicesClientRequestValidator(Class<?> clientClass) {
      loadProperties(clientClass);
   }

   public LexiconServicesClientRequestValidator() {
      loadProperties(getClass());
   }

   public void addField(String fieldName, String value) {
      addField(fieldName, new String[]{value});
   }

   public void addField(String fieldName, String[] values) {
      if (fieldMap == null) {
         fieldMap = new LinkedHashMap<String, String[]>();
      }
      fieldMap.put(fieldName, values);
   }

   public void validate() {
      StringBuilder sb = getStringBuilder();
      for (String field : fieldMap.keySet()) {
         validateFieldMapValue(sb, field);
      }
      clearFieldsMap(sb);
   }

   private void validateFieldMapValue(StringBuilder sb, String field) {
      try {
         validateField(field, fieldMap.get(field));
      } catch (IllegalArgumentException iae) {
         sb.append(iae.getMessage()).append(LINE_SEPARATOR);
      }
   }

   private void clearFieldsMap(StringBuilder sb) {
      fieldMap = null;
      if (sb.length() > 0) {
         throwMessage(sb.toString().substring(0, sb.length() - LINE_SEPARATOR.length()));
      }
   }

   private StringBuilder getStringBuilder() {
      if (fieldMap == null) {
         throwMessage(EMPTY_FIELDS);
      }
      return new StringBuilder();
   }

   public void validateField(String fieldName, String value) {
      verifyParamsNotNull(fieldName, value);
      if (!value.matches(getFormatProperty(fieldName))) {
         throwMessage(getMessageProperty(fieldName));
      }
   }

   public void validateField(String fieldName, String[] values) {
      VerifyFieldNameNotNull(fieldName);
      try {
         verifyValuesNotNull(values);
      } catch (IllegalArgumentException e) {
         throwMessage(getFieldAlias(fieldName) + e.getMessage());
      }
      for (String value : values) {
         validateField(fieldName, value);
      }
   }

   private void verifyParamsNotNull(String fieldName, String value) {
      VerifyFieldNameNotNull(fieldName);
      verifyFieldHasPropertyMessages(fieldName);
      verifyValueNotNull(fieldName, value);
   }

   private void verifyFieldHasPropertyMessages(String fieldName) {
      if (null == getFormatProperty(fieldName) || null == getMessageProperty(fieldName)) {
         throwMessage(getFieldAlias(fieldName) + getMissingFormatProperty());
      }
   }

   private void verifyValueNotNull(String fieldName, String value) {
      if (StringUtils.isNullOrEmpty(value)) {
         throwMessage(getFieldAlias(fieldName) + getMissingFieldProperty());
      }
   }

   private void VerifyFieldNameNotNull(String fieldName) {
      if (StringUtils.isNullOrEmpty(fieldName)) {
         throwMessage(getMissingFieldProperty());
      }
   }

   private String getFieldAlias(String fieldName) {
      return fieldName.replace('.', ' ');
   }

   private void verifyValuesNotNull(Object[] values) {
      if (null == values || values.length == 0) {
         throwMessage(getMissingFieldProperty());
      }
   }

   private void throwMessage(String message) {
      throw new IllegalArgumentException(message);
   }
}
