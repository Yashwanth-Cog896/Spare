/*
 Subsubcountries was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.geography.subsubcountry.SubsubcountriesByAbbreviationRequest;
import com.monsanto.tps.lexicon.geography.subsubcountry.SubsubcountriesByNameRequest;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;

import java.util.Collection;


/**
 * @author GGSHIV - Jun 10, 2008 7:17:37 PM
 */
public class SubsubcountriesImpl extends LexiconArtemisService implements Subsubcountries {

   private static final String FIND_SUBSUBCOUNTRIES_BY_NAME = "FindSubsubcountriesByName";
   private static final String FIND_SUBSUBCOUNTRIES_BY_ABBREVIATION = "FindSubsubcountriesByAbbreviation";

   private static final String ISO_CODE = "Country.ISO.Code";
   private static final String SUB_COUNTRY_NAME = "Subcountry.Name";
   private static final String SUB_COUNTRY_ABBREVATION = "Subcountry.Abbrevation";
   private static final String SUBSUB_COUNTRY_NAME = "Subsubcountry.Name";
protected static final String FIELDS_REQUIRED = "Subcountry name or Subsubcountryname required";
   private final LexiconServicesClientRequestValidator validator;

   public SubsubcountriesImpl(SystemSecurityProxy systemSecurityProxy) {
      super(systemSecurityProxy);
      this.validator = new LexiconServicesClientRequestValidator(getClass());
   }

   public Subsubcountry[] findAllSubsubcountries(String countryISOCode, String subcountryName) {
      return findSubsubcountriesByName(countryISOCode, subcountryName, "*");
   }

   public Subsubcountry[] findSubsubcountriesByName(String countryISOCode, String subcountryName, String subsubcountryName) {
      validateFields(countryISOCode, subcountryName, subsubcountryName);
      SubsubcountriesByNameRequest request = new SubsubcountriesByNameRequest();
      request.setCountryISOCode(countryISOCode);
      request.setWildcardableSubcountryName(subcountryName);
      request.setWildcardableName(subsubcountryName);
      return find(request, FIND_SUBSUBCOUNTRIES_BY_NAME);
   }

   public Subsubcountry[] findSubsubcountriesBySubcountriesAbbreviation(String countryISOCode, String[] subcountryAbbr, String subsubcountryName) {
      validateFields(countryISOCode, subcountryAbbr, subsubcountryName);
      SubsubcountriesByAbbreviationRequest request = new SubsubcountriesByAbbreviationRequest();
      request.setCountryISOCode(countryISOCode);
      request.setSubcountriesAbbreviation(subcountryAbbr);
      request.setWildcardableName(subsubcountryName);
      return find(request, FIND_SUBSUBCOUNTRIES_BY_ABBREVIATION);
   }

   private void validateFields(String countryISOCode, String subcountryName, String subsubcountryName) {
      if (subcountryName == null && subsubcountryName == null) {
         throw new IllegalArgumentException(FIELDS_REQUIRED);
      }
      validator.addField(ISO_CODE, countryISOCode);
      if (subcountryName != null) {
         validator.addField(SUB_COUNTRY_NAME, subcountryName);
      }
      verifySubsubcountryNameExists(subsubcountryName);
      validator.validate();
   }

   private void verifySubsubcountryNameExists(String subsubcountryName) {
      if (subsubcountryName != null) {
         validator.addField(SUBSUB_COUNTRY_NAME, subsubcountryName);
      }
   }

   private void validateFields(String countryISOCode, String[] subcountryAbbr, String subsubcountryName) {
      if ((subcountryAbbr == null || subcountryAbbr.length == 0) && (subsubcountryName != null)) {
         throw new IllegalArgumentException(FIELDS_REQUIRED);
      }
      validator.addField(ISO_CODE, countryISOCode);
      if (subcountryAbbr != null) {
         validator.addField(SUB_COUNTRY_ABBREVATION, subcountryAbbr);
      }
      verifySubsubcountryNameExists(subsubcountryName);
      validator.validate();
   }

   private Subsubcountry[] find(Object payLoad, String operationName) {
      Collection<Subsubcountry> subcountries = invokeService(payLoad, operationName, Subsubcountry.class);
      return subcountries.toArray(new Subsubcountry[subcountries.size()]);
   }

}
