package com.monsanto.tps.lexicon.person.service;

import com.monsanto.tps.lexicon.person.MinimalPersonRecord;
import com.monsanto.tps.lexicon.person.PersonRecord;

/**
 * nbwald - Jul 1, 2008 2:13:20 PM
 */
public interface People {

   String INVALID_PERSON_NAME = "Invalid Person Name";

   PersonRecord[] findPeopleByNetworkIds(String[] networkIds);

   PersonRecord[] findPeopleByNetworkIds(String[] networkIds, boolean onlyActive);

   PersonRecord[] findPeopleByPartyIds(long[] partyIds);

   PersonRecord[] findPeopleByPartyIds(long[] partyIds, boolean onlyActive);

   MinimalPersonRecord[] findMinimalPersonRecordsByNetworkIds(String[] networkIds);

   MinimalPersonRecord[] findMinimalPersonRecordsByPartyIds(long[] partyIds);

   MinimalPersonRecord[] findMinimalPersonRecordsByWildcardableFirstAndLastName(String firstName, String lastName);
}
