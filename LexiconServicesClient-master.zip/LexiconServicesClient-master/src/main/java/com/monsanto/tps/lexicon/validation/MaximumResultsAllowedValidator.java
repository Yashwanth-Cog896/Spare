package com.monsanto.tps.lexicon.validation;

/**
 * rrchak1 - Aug 13, 2008 4:44:03 PM
 */
public class MaximumResultsAllowedValidator
{
   private int maxResults;
   private static final int maxResultsAllowed = 1000;
   private static final String INVALID_RESULTS_COUNT = "Cannot exceed maximum allowed results of 1000.";

   public MaximumResultsAllowedValidator(int maxResults) {
      this.maxResults = maxResults;
   }

   public void validate()
      throws IllegalArgumentException
   {
      if (maxResults > maxResultsAllowed) {
         throw new IllegalArgumentException(INVALID_RESULTS_COUNT);
      }

   }
}
