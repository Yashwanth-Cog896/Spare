/*
 PropertyReader was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import java.io.IOException;
import java.util.Properties;

/**
 * @author GGSHIV - Jul 1, 2008 2:00:52 PM
 */
public class PropertyReader {

   private static final Properties FORMAT_PROPS = new Properties();
   private static final Properties MESSAGE_PROPS = new Properties();
   private static final String MISSING_FIELD = "MissingField";
   private static final String MISSING_FIELD_FORMAT = "MissingFormat";
   private static final String FORMAT_PROPERTIES = "FieldFormat.properties";
   private static final String MESSAGE_PROPERTIES = "ErrorMessages.properties";

   public static String getFormatProperty(String field) {
      return FORMAT_PROPS.getProperty(field);
   }

   public static String getMessageProperty(String field) {
      return MESSAGE_PROPS.getProperty(field);
   }

   public static String getMissingFieldProperty() {
      return null == MESSAGE_PROPS.getProperty(MISSING_FIELD) ? " is Missing, Please provide valid information." : MESSAGE_PROPS.getProperty(MISSING_FIELD);
   }

   public static String getMissingFormatProperty() {
      return null == MESSAGE_PROPS.getProperty(MISSING_FIELD_FORMAT) ? " : Missing field Format/Message to validate." : MESSAGE_PROPS.getProperty(MISSING_FIELD_FORMAT);
   }

   public static void loadProperties(Class<?> clientClass) {
      try {
         FORMAT_PROPS.load(clientClass.getResourceAsStream(FORMAT_PROPERTIES));
         MESSAGE_PROPS.load(clientClass.getResourceAsStream(MESSAGE_PROPERTIES));
      } catch (IOException e) {
         throw new RuntimeException(e);
      }
   }

}
