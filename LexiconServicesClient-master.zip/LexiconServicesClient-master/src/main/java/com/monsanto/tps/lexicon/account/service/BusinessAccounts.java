package com.monsanto.tps.lexicon.account.service;

import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;

/**
 * nbwald - Jul 1, 2008 2:00:15 PM
 */
public interface BusinessAccounts
{
   BusinessAccount[] findByIds(long[] businessAccountIds);

   BusinessAccount[] findByCriteria(BusinessAccountSearchCriteria criteria);
}
