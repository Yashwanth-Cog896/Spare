package com.monsanto.tps.lexicon.artemis;

import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.services.client.common.activity.ActivityClient;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.securityinterfaces.SystemSecurityProxy;

/**
 * nbwald - May 5, 2008 11:16:43 AM
 */
public class ArtemisTwoServiceInvoker
{
   private final SystemSecurityProxy systemSecurityProxy;
   private String serviceName;
   private String operationName;
   private XmlSerializer xmlSerializer;

   public ArtemisTwoServiceInvoker(SystemSecurityProxy systemSecurityProxy, String serviceName, String operationName, XmlSerializer xmlSerializer) {
      this.systemSecurityProxy = systemSecurityProxy;
      this.serviceName = serviceName;
      this.operationName = operationName;
      this.xmlSerializer = xmlSerializer;
   }

   public ResponseEnvelope call(Object payload) {
      try {
         ActivityClient client = new ActivityClient(systemSecurityProxy);
         return client.perform(buildRequestEnvelope(payload), serviceName, xmlSerializer);
      }
      catch (ActivityClientException e) {
         throw new RuntimeException(e);
      }
   }

   private RequestEnvelope buildRequestEnvelope(Object payload) {
      RequestOperation operation = new RequestOperation(operationName);
      return new RequestEnvelope(operation, payload);
   }
}
