package com.monsanto.tps.lexicon.contact.service;

import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * nbwald - Jul 1, 2008 2:02:16 PM
 */
public interface ExternalContacts
{
   ExternalContact[] findByExternalContactIds(long[] externalContactIds);

   ExternalContact[] findByBusinessAccountIds(long[] businessAccountIds);

   ExternalContact[] findByCriteria(ExternalContactSearchCriteria criteria);

   ExternalContact[] findByCriteria(ExternalContactByBusinessGeographySearchCriteria criteria);
}
