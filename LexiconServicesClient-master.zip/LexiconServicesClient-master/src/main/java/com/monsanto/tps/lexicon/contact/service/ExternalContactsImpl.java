package com.monsanto.tps.lexicon.contact.service;

import com.monsanto.Util.StringUtils;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import com.monsanto.tps.lexicon.validation.CompanyNameAndLocationValidator;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;
import com.monsanto.tps.lexicon.validation.MaximumResultsAllowedValidator;
import com.monsanto.tps.lexicon.validation.PersonNameValidator;

import java.util.Collection;

/**
 * @author GGSHIV - May 27, 2008 4:48:29 PM
 */
public class ExternalContactsImpl
   extends LexiconArtemisService
   implements ExternalContacts
{
   private static final String FIND_BY_BUSINESS_ACCOUNT_IDS_OPERATION = "FindExternalContactsByBusinessAccountIds";
   private static final String FIND_BY_EXTERNAL_CONTACT_IDS_OPERATION = "FindExternalContactsByExternalContactIds";
   private static final String FIND_BY_CRITERIA_OPERATION = "FindExternalContactsBySearchCriteria";
   private static final String FIND_BY_BUSINESS_GEOGRAPHY_CRITERIA_OPERATION = "FindExternalContactsByBusinessGeoSearchCriteria";
   private static final String CONTACT_TYPE = "Contact.Type";
   private static final boolean ALLOW_NULLS = true;

   public ExternalContactsImpl(SystemSecurityProxy systemSecurityProxy) {
      super(systemSecurityProxy);
   }

   public ExternalContact[] findByExternalContactIds(long[] externalContactIds) {
      validateMaxresultsAllowed(externalContactIds.length);
      return find(externalContactIds, FIND_BY_EXTERNAL_CONTACT_IDS_OPERATION);
   }

   public ExternalContact[] findByBusinessAccountIds(long[] businessAccountIds) {
      validateMaxresultsAllowed(businessAccountIds.length);
      return find(businessAccountIds, FIND_BY_BUSINESS_ACCOUNT_IDS_OPERATION);
   }

   public ExternalContact[] findByCriteria(ExternalContactSearchCriteria criteria) {
      validateSearchCriteria(criteria);
      return find(criteria, FIND_BY_CRITERIA_OPERATION);
   }

   public ExternalContact[] findByCriteria(ExternalContactByBusinessGeographySearchCriteria criteria) {
      validateMaxresultsAllowed(criteria.getExternalContactSearchCriteria().getMaxResults());
      return find(criteria, FIND_BY_BUSINESS_GEOGRAPHY_CRITERIA_OPERATION);
   }

   private ExternalContact[] find(Object payload, String operationName) {
      Collection<ExternalContact> externalContacts = invokeService(payload, operationName, ExternalContact.class);
      return externalContacts.toArray(new ExternalContact[externalContacts.size()]);
   }

   private void validateSearchCriteria(ExternalContactSearchCriteria criteria) {
      validateContactType(criteria.getContactType());
      new CompanyNameAndLocationValidator(criteria.getCompanyName(), criteria.getLocation()).validate();
      validateMaxresultsAllowed(criteria.getMaxResults());
      if (!StringUtils.isNullOrEmpty(criteria.getFirstName()) || !StringUtils.isNullOrEmpty(criteria.getLastName())) {
         new PersonNameValidator(criteria.getFirstName(), criteria.getLastName()).validate();
      }
   }

   private void validateMaxresultsAllowed(int value) {
      new MaximumResultsAllowedValidator(value).validate();
   }

   private void validateContactType(String contactType) {
      if (contactType != null) {
         new LexiconServicesClientRequestValidator(getClass()).validateField(CONTACT_TYPE, contactType);
      }
   }
}
