package com.monsanto.tps.lexicon.uom.service;


import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.uom.CountryISOCodeAndDimensionRequest;
import com.monsanto.tps.lexicon.uom.UOMSymbolsAndDimensionRequest;
import com.monsanto.tps.lexicon.uom.UnitOfMeasure;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;

import java.util.Collection;

/**
 * Filename:    UnitOfMeasures.java
 * Last Change: rrchak1 On:	Jun 16, 2008
 *
 * @author: rrchak1
 */
public class UnitsOfMeasureImpl extends LexiconArtemisService implements UnitsOfMeasure {

   private static final String FIND_BY_NAME = "FindUOMByName";
   private static final String FIND_BY_CODES = "FindUOMByCodes";
   private static final String FIND_BY_COUNTRY_ISO_CODE = "FindUOMbyCountryISOcode";
   private static final String FIND_BY_COUNTRY_ISO_CODE_AND_DIMENSION = "FindUOMbyCountryISOcodeAndDimension";
   private static final String FIND_BY_WILDCARD_DIMENSION = "FindUOMbyWildcardableDimension";
   private static final String FIND_BY_SYMBOLS_AND_DIMENSION = "FindUOMBySymbolsAndDimension";
   private static final String NAME = "UOM.Name";
   private static final String COUNTRY_ISO_CODE = "Country.ISO.Code";
   private static final String CODE = "UOM.Code";
   private static final String SYMBOL = "UOM.Symbol";
   private static final String DIMENSION = "UOM.Dimension";
   private final LexiconServicesClientRequestValidator validator;

   public UnitsOfMeasureImpl(SystemSecurityProxy systemSecurityProxy) {
      super(systemSecurityProxy);
      validator = new LexiconServicesClientRequestValidator(getClass());
   }

   public UnitOfMeasure[] findAll() {
      return findByName("*");
   }

   public UnitOfMeasure[] findByName(String uomName) {
      validator.validateField(NAME, uomName);
      return find(uomName, FIND_BY_NAME);
   }

   public UnitOfMeasure[] findByCountryISOCode(String countryISOCode) {
      validator.validateField(COUNTRY_ISO_CODE, countryISOCode);
      return find(countryISOCode, FIND_BY_COUNTRY_ISO_CODE);
   }

   public UnitOfMeasure[] findByCodes(String[] uomCodes) {
      validator.validateField(CODE, uomCodes);
      return find(uomCodes, FIND_BY_CODES);
   }

   public UnitOfMeasure[] findByCountryISOcodeAndDimension(String countryISOCode, String wildcardableDimension) {
      validator.addField(COUNTRY_ISO_CODE, countryISOCode);
      validator.addField(DIMENSION, wildcardableDimension);
      validator.validate();
      CountryISOCodeAndDimensionRequest request = new CountryISOCodeAndDimensionRequest(countryISOCode, wildcardableDimension);
      return find(request, FIND_BY_COUNTRY_ISO_CODE_AND_DIMENSION);
   }

   public UnitOfMeasure[] findByWildcardableDimension(String wildcardableDimension) {
      validator.validateField(DIMENSION, wildcardableDimension);
      return find(wildcardableDimension, FIND_BY_WILDCARD_DIMENSION);
   }

   public UnitOfMeasure[] findBySymbolsAndDimension(String[] symbols, String wildcardableDimension) {
      validator.addField(SYMBOL, symbols);
      validator.addField(DIMENSION, wildcardableDimension);
      validator.validate();
      UOMSymbolsAndDimensionRequest request = new UOMSymbolsAndDimensionRequest(symbols, wildcardableDimension);
      return find(request, FIND_BY_SYMBOLS_AND_DIMENSION);
   }

   private UnitOfMeasure[] find(Object request, String operationName) {
      Collection<UnitOfMeasure> unitOfMeasures = invokeService(request, operationName, UnitOfMeasure.class);
      return unitOfMeasures.toArray(new UnitOfMeasure[unitOfMeasures.size()]);
   }
}
