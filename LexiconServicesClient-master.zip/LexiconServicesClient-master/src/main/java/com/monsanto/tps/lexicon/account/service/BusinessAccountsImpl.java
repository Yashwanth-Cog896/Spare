package com.monsanto.tps.lexicon.account.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.validation.CompanyNameAndLocationValidator;
import com.monsanto.tps.lexicon.validation.MaximumResultsAllowedValidator;

import java.util.Collection;

/**
 * @author GGSHIV - May 27, 2008 3:57:37 PM
 */
public class BusinessAccountsImpl extends LexiconArtemisService implements BusinessAccounts {

   private static final String FIND_BY_IDS_OPERATION = "FindBusinessAccountsByIds";
   private static final String FIND_BY_CRITERIA_OPERATION = "FindBusinessAccountsBySearchCriteria";

   public BusinessAccountsImpl(SystemSecurityProxy systemSecurityProxy) {
      super(systemSecurityProxy);
   }

   public BusinessAccount[] findByIds(long[] businessAccountIds) {
      validateMaxResultsAllowed(businessAccountIds.length);
      return find(businessAccountIds, FIND_BY_IDS_OPERATION);
   }

   public BusinessAccount[] findByCriteria(BusinessAccountSearchCriteria criteria) {
      new CompanyNameAndLocationValidator(criteria.getCompanyName(), criteria.getLocation()).validate();
      validateMaxResultsAllowed(criteria.getMaxResults());
      return find(criteria, FIND_BY_CRITERIA_OPERATION);
   }

   private void validateMaxResultsAllowed(int value) {
      new MaximumResultsAllowedValidator(value).validate();
   }

   private BusinessAccount[] find(Object payload, String operationName) {
      Collection<BusinessAccount> businessAccounts = invokeService(payload, operationName, BusinessAccount.class);
      return businessAccounts.toArray(new BusinessAccount[businessAccounts.size()]);
   }
}
