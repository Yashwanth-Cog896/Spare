package com.monsanto.tps.lexicon.person.service;

import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tps.lexicon.artemis.ArtemisTwoServiceInvoker;
import com.monsanto.tps.lexicon.person.serializer.PeopleDataXmlSerializationFactory;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.securityinterfaces.SystemSecurityProxy;

/**
 * nbwald - May 5, 2008 11:27:23 AM
 */
public class PeopleDataService
{
   private static final String LEX_PEOPLE_DATA_SERVICES = "Lex_PeopleDataServices";
   private final SystemSecurityProxy systemSecurityProxy;

   public PeopleDataService(SystemSecurityProxy systemSecurityProxy) {
      this.systemSecurityProxy = systemSecurityProxy;
   }

   public ResponseEnvelope call(String operation, Object payload) {
      XmlSerializer xmlSerializer = new PeopleDataXmlSerializationFactory().createSerializer();
      ArtemisTwoServiceInvoker serviceInvoker = new ArtemisTwoServiceInvoker(systemSecurityProxy, LEX_PEOPLE_DATA_SERVICES, operation, xmlSerializer);
      return serviceInvoker.call(payload);
   }
}
