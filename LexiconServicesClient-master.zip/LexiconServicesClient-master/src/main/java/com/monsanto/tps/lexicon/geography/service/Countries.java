package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.tps.lexicon.geography.country.Country;

/**
 * nbwald - Jul 1, 2008 2:07:30 PM
 */
public interface Countries
{
   Country[] findAllCountries();

   Country[] findCountries(String countryName);

   Country[] findCountries(String[] countryISOCodes);
}
