/*
 Countries was created on Jun 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.geography.country.Country;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;

import java.util.Collection;

/**
 * @author GGSHIV - Jun 2, 2008 12:39:00 PM
 */
public class CountriesImpl
        extends LexiconArtemisService
        implements Countries {

   private static final String FIND_BY_ISO_CODE_OPERATION = "FindCountriesByISOCodes";
   private static final String FIND_BY_NAME_OPERATION = "FindCountriesByName";
   private static final String NAME = "Country.Name";
   private static final String ISO_CODE = "Country.ISO.Code";

   private final LexiconServicesClientRequestValidator validator;

   public CountriesImpl(SystemSecurityProxy systemSecurityProxy) {
      super(systemSecurityProxy);
      this.validator = new LexiconServicesClientRequestValidator(getClass());
   }

   public Country[] findAllCountries() {
      return findCountries("*");
   }

   public Country[] findCountries(String countryName) {

      validator.validateField(NAME, countryName);
      return find(countryName, FIND_BY_NAME_OPERATION);
   }

   public Country[] findCountries(String[] countryISOCodes) {
      validator.validateField(ISO_CODE, countryISOCodes);
      return find(countryISOCodes, FIND_BY_ISO_CODE_OPERATION);
   }

   private Country[] find(Object payload, String operationName) {
      Collection<Country> countries = invokeService(payload, operationName, Country.class);
      return countries.toArray(new Country[countries.size()]);
   }
}
