package com.monsanto.tps.lexicon.crop.service;

import com.monsanto.tps.lexicon.crop.Crop;

/**
 * @author GGSHIV - Jul 2, 2008 12:59:17 PM
 */
public interface Crops {

   Crop[] findAll();

   Crop[] findByPublicKeys(String[] publicKeys);

   Crop[] findByBayerCodes(String[] bayerCodes);

   Crop[] findByAbbreviations(String[] abbreviations);

   Crop[] findByAbbreviationsAndScientificName(String[] abbreviations, String scientificName);

   Crop[] findByBayerCodePublicKeys(String[] bayerCodepubKeys);

   Crop[] findByName(String name);

   Crop[] findByScientificName(String scientificName);

   Crop[] findByPubkeysAndScientificName(String[] pubKeys, String scientificName);

   Crop[] findByNameAndScientificName(String name, String scientificName);

   Crop[] findByGenusSpeciePublicKeys(String[] scientificPubKeys);
}
