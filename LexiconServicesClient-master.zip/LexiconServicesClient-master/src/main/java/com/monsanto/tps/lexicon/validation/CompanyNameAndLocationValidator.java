/*
 CompanyNameAndLocationValidator was created on Jul 29, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import com.monsanto.tps.lexicon.contact.SearchableLocation;

/**
 * @author ggshiv - Jul 29, 2008 4:35:00 PM
 */
public class CompanyNameAndLocationValidator extends LexiconServicesClientRequestValidator {

   private static final String COMPANY_NAME = "Company.Name";
   private static final String COUNTRY_NAME = "Country.Name";
   private static final String CITY = "City.Name";
   private static final String SUB_COUNTRY_NAME = "Subcountry.Name";
   private static final String SUBSUB_COUNTRY_NAME = "Subsubcountry.Name";
   protected static final String MANDATORY_COUNTRY_NAME = "Country name, mandatory if Subcountry (state) is specified.";
   private final String companyName;
   private final SearchableLocation location;
   private boolean fieldExists = false;

   public CompanyNameAndLocationValidator(String companyName, SearchableLocation location) {
      this.companyName = companyName;
      this.location = location;
   }

   public void validate() {
      verifyCompanyNameExists();
      verifyLocationExists();
      if (fieldExists) {
         super.validate();
      }
   }

   private void verifyLocationExists() {
      if (location != null) {
         fieldExists = true;
         validateCountryName(location.getCountryName(), location.getSubcountryCode());
         validateSubcountryName(location.getSubcountryCode());
         validateSubsubcountryName(location.getSubsubcountryName());
         validateCityName(location.getCity());
      }
   }

   private void validateCityName(String city) {
      if (city != null) {
         addField(CITY, city);
      }
   }

   private void validateSubsubcountryName(String subsubcountryName) {
      if (subsubcountryName != null) {
         addField(SUBSUB_COUNTRY_NAME, subsubcountryName);
      }
   }

   private void validateSubcountryName(String subcountryName) {
      if (subcountryName != null) {
         addField(SUB_COUNTRY_NAME, subcountryName);
      }
   }

   private void validateCountryName(String countryName, String subcountryName) {
      checkCountryNamePresenceWithSubcountryName(countryName, subcountryName);
      if (countryName != null) {
         addField(COUNTRY_NAME, countryName);
      }
   }

   private void checkCountryNamePresenceWithSubcountryName(String countryName, String subcountryName) {
      if (subcountryName != null && countryName == null) {
         throw new IllegalArgumentException(MANDATORY_COUNTRY_NAME);
      }
   }

   private void verifyCompanyNameExists() {
      if (companyName != null) {
         fieldExists = true;
         addField(COMPANY_NAME, companyName);
      }
   }
}
