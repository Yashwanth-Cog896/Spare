package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.geography.subcountry.SubcountriesByAbbreviationRequest;
import com.monsanto.tps.lexicon.geography.subcountry.SubcountriesByNameRequest;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;

import java.util.Collection;

/**
 * nbwald - Jun 8, 2008 4:28:04 PM
 */
public class SubcountriesImpl extends LexiconArtemisService implements Subcountries {

   private static final String FIND_SUBCOUNTRIES_BY_NAME = "FindSubcountriesByName";
   private static final String FIND_SUBCOUNTRIES_BY_ABBREVIATION = "FindSubcountriesByAbbreviation";

   private static final String ISO_CODE = "Country.ISO.Code";
   private static final String SUB_COUNTRY_NAME = "Subcountry.Name";
   private static final String SUB_COUNTRY_ABBREVATION = "Subcountry.Abbrevation";

   private final LexiconServicesClientRequestValidator validator;

   public SubcountriesImpl(SystemSecurityProxy systemSecurityProxy) {
      super(systemSecurityProxy);
      this.validator = new LexiconServicesClientRequestValidator(getClass());
   }

   public Subcountry[] findAllSubcountries(String countryISOCode) {
      validator.validateField(ISO_CODE, countryISOCode);
      return findSubcountriesByName(countryISOCode, "*");
   }

   public Subcountry[] findSubcountriesByName(String countryISOCode, String subcountryName) {
      validator.addField(ISO_CODE, countryISOCode);
      validator.addField(SUB_COUNTRY_NAME, subcountryName);
      validator.validate();
      SubcountriesByNameRequest request = new SubcountriesByNameRequest();
      request.setCountryISOCode(countryISOCode);
      request.setWildcardableSubcountryName(subcountryName);
      return find(request, FIND_SUBCOUNTRIES_BY_NAME);
   }

   public Subcountry[] findSubcountriesByAbbreviation(String countryISOCode, String[] subcountriesAbbreviation) {
      validator.addField(ISO_CODE, countryISOCode);
      validator.addField(SUB_COUNTRY_ABBREVATION, subcountriesAbbreviation);
      validator.validate();
      SubcountriesByAbbreviationRequest request = new SubcountriesByAbbreviationRequest();
      request.setCountryISOCode(countryISOCode);
      request.setSubcountriesAbbreviation(subcountriesAbbreviation);
      return find(request, FIND_SUBCOUNTRIES_BY_ABBREVIATION);
   }

   private Subcountry[] find(Object request, String operationName) {
      Collection<Subcountry> subcountries = invokeService(request, operationName, Subcountry.class);
      return subcountries.toArray(new Subcountry[subcountries.size()]);
   }
}
