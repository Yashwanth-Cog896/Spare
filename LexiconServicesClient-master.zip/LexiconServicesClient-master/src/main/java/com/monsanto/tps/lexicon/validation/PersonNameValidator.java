/*
 PersonNameValidator was created on Jul 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.validation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexicon.person.service.People;

/**
 * @author GGSHIV - Jul 30, 2008 11:50:50 AM
 */
public class PersonNameValidator
{
   private final String firstName;
   private final String lastName;

   public PersonNameValidator(String firstName, String lastName) {
      this.firstName = firstName;
      this.lastName = lastName;
   }

   public void validate() {
      Errors errors = new Errors();
      errors.checkIfBothNull(firstName, lastName);
      errors.checkForValidValues(firstName, "First Name");
      errors.checkForValidValues(lastName, "Last Name");
      errors.alert();
   }

   private class Errors
   {
      private StringBuilder messages = new StringBuilder();

      public void checkForNull(String fieldValue, String fieldName) {
         if (fieldValue == null) {
            add(fieldName + " is Missing, Please provide valid information.");
         }
      }

      public void checkForValidValues(String name, String fieldName) {
         if (nameHasInvalidValue(name)) {
            add(fieldName + " must be only alphabetic characters.");
         }
      }

      private boolean nameHasInvalidValue(String name) {
         return !StringUtils.isNullOrEmpty(name) && ("*".equals(name) || !name.matches("[a-zA-Z*]+"));
      }

      private void add(String message) {
         if (hasErrors()) {
            messages.append("\n");
         }
         messages.append(message);
      }

      private boolean hasErrors() {
         return messages.length() > 0;
      }

      public void alert() {
         if (hasErrors()) {
            throw new IllegalArgumentException(messages.toString());
         }
      }

      public void checkIfBothNull(String firstName, String lastName) {
         if(StringUtils.isNullOrEmpty(firstName) && StringUtils.isNullOrEmpty(lastName)) {
            add(People.INVALID_PERSON_NAME);
         }
      }
   }
}