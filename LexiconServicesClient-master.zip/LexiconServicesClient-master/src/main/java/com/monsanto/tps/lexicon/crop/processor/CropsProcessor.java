package com.monsanto.tps.lexicon.crop.processor;

import com.monsanto.tps.lexicon.crop.BayerCode;
import com.monsanto.tps.lexicon.crop.ScientificName;
import com.monsanto.tps.lexiconservices.crop.domain.Crop;
import com.monsanto.tps.lexiconservices.crop.domain.CropRetrievalByPubKeysAndScientificNameRequest;
import com.monsanto.tps.lexiconservices.crop.service.CropRetrievalByPubKeyAndScientificNameService;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: PGANG
 * Date: 12/19/13
 * Time: 5:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropsProcessor {

  private static ClassPathXmlApplicationContext applicationContext;

  private static final String[] CONTEXT_FILES = new String[]{
    "/context/application-context.xml"
  };

  static {
    applicationContext = new ClassPathXmlApplicationContext(CONTEXT_FILES, false);
    applicationContext.refresh();
  }

  public List<com.monsanto.tps.lexicon.crop.Crop> findCropsByPublicKeysAndScientificName(CropRetrievalByPubKeysAndScientificNameRequest request) throws Exception {
    CropRetrievalByPubKeyAndScientificNameService cropRetrievalByPubKeyAndScientificNameService = getCropRetrievalByPubKeyAndScientificNameServiceBean();
    List<Crop> crops = cropRetrievalByPubKeyAndScientificNameService.findByPublicKeysAndScientificName(request);
    if (crops!= null && !crops.isEmpty()) {
      return mapCropToClient(crops);
    } else {
      return new ArrayList<com.monsanto.tps.lexicon.crop.Crop>();
    }
  }

  private List<com.monsanto.tps.lexicon.crop.Crop> mapCropToClient(List<Crop> crops) {
    List<com.monsanto.tps.lexicon.crop.Crop> clientCrops = new ArrayList<com.monsanto.tps.lexicon.crop.Crop>();
    if (crops!= null && !crops.isEmpty()) {
      for (Crop crop : crops) {
        com.monsanto.tps.lexicon.crop.Crop clientCrop = new com.monsanto.tps.lexicon.crop.Crop();
        clientCrop.setAbbreviation(crop.getAbbreviation());
        clientCrop.setBayerCodes(mapBayerCodeToClient(crop.getBayerCodes()));
        clientCrop.setPublicKey(crop.getPublicKey());
        clientCrop.setShippingStatement(crop.getShippingStatement());
        clientCrop.setName(crop.getName());
        clientCrops.add(clientCrop);
      }
    }
    return clientCrops;
  }

  private List<BayerCode> mapBayerCodeToClient(List<com.monsanto.tps.lexiconservices.crop.domain.BayerCode> bayerCodes) {
    List<BayerCode> clientBayerCodes = new ArrayList<BayerCode>();
    if (bayerCodes!=null && !bayerCodes.isEmpty()) {
      for (com.monsanto.tps.lexiconservices.crop.domain.BayerCode bayerCode : bayerCodes) {
        BayerCode clientBayerCode = new BayerCode();
        clientBayerCode.setCode(bayerCode.getCode());
        clientBayerCode.setPublicKey(bayerCode.getPublicKey());
        clientBayerCode.setScientificNames(mapScientificNameToClient(bayerCode.getScientificNames()));
        clientBayerCodes.add(clientBayerCode);
      }
    }
    return clientBayerCodes;
  }

  private List<ScientificName> mapScientificNameToClient(List<com.monsanto.tps.lexiconservices.crop.domain.ScientificName> scientificNames) {
    List<ScientificName> clientScientificNames = new ArrayList<ScientificName>();
    if (scientificNames!=null && !scientificNames.isEmpty()) {
      for (com.monsanto.tps.lexiconservices.crop.domain.ScientificName scientificName : scientificNames) {
        ScientificName clientScientificName = new ScientificName(scientificName.getName(), scientificName.getPublicKey());
        clientScientificNames.add(clientScientificName);
      }
    }
    return clientScientificNames;
  }

 private CropRetrievalByPubKeyAndScientificNameService getCropRetrievalByPubKeyAndScientificNameServiceBean() throws Exception {
    return (CropRetrievalByPubKeyAndScientificNameService) applicationContext.getBean("cropRetrievalByPubKeyAndScientificNameService");
  }

  }
