package com.monsanto.tps.lexicon.uom.service;

import com.monsanto.tps.lexicon.uom.UnitOfMeasure;

/**
 * nbwald - Jul 1, 2008 2:14:02 PM
 */
public interface UnitsOfMeasure {

   UnitOfMeasure[] findAll();

   UnitOfMeasure[] findByName(String uomName);

   UnitOfMeasure[] findByCountryISOCode(String countryISOCode);

   UnitOfMeasure[] findByCodes(String[] uomCodes);

   UnitOfMeasure[] findByCountryISOcodeAndDimension(String countryISOCode, String wildcardableDimension);

   UnitOfMeasure[] findByWildcardableDimension(String wildcardableDimension);

   UnitOfMeasure[] findBySymbolsAndDimension(String[] symbols, String wildcardableDimension);
}
