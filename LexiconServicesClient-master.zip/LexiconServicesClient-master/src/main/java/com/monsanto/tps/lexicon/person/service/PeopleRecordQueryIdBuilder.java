package com.monsanto.tps.lexicon.person.service;

import com.monsanto.tps.lexicon.person.NetworkID;
import com.monsanto.tps.lexicon.person.PartyID;

/**
 * nbwald - May 5, 2008 11:54:41 AM
 */
public class PeopleRecordQueryIdBuilder
{
   public NetworkID[] buildByNetworkIds(String[] networkIdStrings) {
      NetworkID[] networkIds = new NetworkID[networkIdStrings.length];
      for (int i = 0; i < networkIdStrings.length; i++) {
         networkIds[i] = new NetworkID(networkIdStrings[i]);
      }
      return networkIds;
   }

   public PartyID[] buildByPartyIds(long[] partyIdValues) {
      PartyID[] partyIDs = new PartyID[partyIdValues.length];
      for (int i = 0; i < partyIdValues.length; i++) {
         partyIDs[i] = new PartyID(String.valueOf(partyIdValues[i]));
      }
      return partyIDs;
   }
}
