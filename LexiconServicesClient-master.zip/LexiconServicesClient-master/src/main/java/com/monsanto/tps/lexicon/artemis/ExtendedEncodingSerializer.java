package com.monsanto.tps.lexicon.artemis;

import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.thoughtworks.xstream.XStream;
import org.apache.commons.lang.CharEncoding;
import org.w3c.dom.Document;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

/**
 * nbwald - Jul 17, 2008 2:37:51 PM
*/
public class ExtendedEncodingSerializer
   implements XmlSerializer
{
   private static final String ENCODING = CharEncoding.UTF_16;

   public void writeToStream(Object request, OutputStream outputStream) {
      XStream xStream = new XStream();
      try {
         xStream.toXML(request, new OutputStreamWriter(outputStream, ENCODING));
      }
      catch (UnsupportedEncodingException e) {
         throw new RuntimeException(e);
      }
   }

   public Object fromStream(InputStream inputStream) {
      XStream xStream = new XStream();
      try {
         return xStream.fromXML(new InputStreamReader(inputStream, ENCODING));
      }
      catch (UnsupportedEncodingException e) {
         throw new RuntimeException(e);
      }
   }

   public Object fromCompressedStream(InputStream inputStream)
      throws DeserializationException
   {
      throw new UnsupportedOperationException();
   }

   public Object fromDocument(Document document)
      throws DeserializationException
   {
      throw new UnsupportedOperationException();
   }

   public Object fromInputStream(InputStream inputStream)
      throws DeserializationException
   {
      throw new UnsupportedOperationException();
   }

   public Object fromXML(String xml)
      throws DeserializationException
   {
      throw new UnsupportedOperationException();
   }

   public Document toDocument(Object object)
      throws SerializationException
   {
      throw new UnsupportedOperationException();
   }

   public String toXML(Object object) {
      throw new UnsupportedOperationException();
   }

   public void writeToCompressedStream(Object request, OutputStream outputStream)
      throws SerializationException
   {
      throw new UnsupportedOperationException();
   }
}
