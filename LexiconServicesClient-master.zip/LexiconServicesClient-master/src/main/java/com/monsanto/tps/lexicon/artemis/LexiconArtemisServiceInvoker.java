/*
 LexiconArtemisServiceInvoker was created on May 13, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.artemis;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tcc.constellation.serviceconnection.CachingServiceUrlResolver;
import com.monsanto.tcc.constellation.serviceconnection.DefaultXmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.KerberosXmlServiceRequest;
import com.monsanto.tcc.constellation.serviceconnection.ServiceConnection;
import com.monsanto.tcc.constellation.serviceconnection.ServiceUrlResolver;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnection;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceRequest;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * @author GGSHIV - May 13, 2008 2:51:53 PM
 */
public class LexiconArtemisServiceInvoker
{
   private static final String SERVICE_NAME = "Lex_LexiconArtemisServices";
   private final SystemSecurityProxy systemSecurityProxy;
   private final String operationName;
   private final XmlSerializerProvider serializerProvider;
   private final ServiceUrlResolver urlResolver;

   public LexiconArtemisServiceInvoker(SystemSecurityProxy systemSecurityProxy, String operationName) {
      this.systemSecurityProxy = systemSecurityProxy;
      this.operationName = operationName;
      this.serializerProvider = new LexiconArtemisServiceXmlSerializerProvider();
      this.urlResolver = new CachingServiceUrlResolver();
   }

   public ResponseEnvelope call() {
      return call(null);
   }

   public ResponseEnvelope call(Object payload) {
      RequestEnvelope requestEnvelope = getRequestEnvelope(payload);
      XmlServiceConnectionInterpreter connectionInterpreter = getConnectionInterpreter();
      XmlServiceRequest serviceRequest = getServiceRequest();
      ServiceConnection conn = new XmlServiceConnection(SERVICE_NAME, urlResolver, connectionInterpreter, serviceRequest);
      return (ResponseEnvelope) conn.call(requestEnvelope);
   }

   private RequestEnvelope getRequestEnvelope(Object payload) {
      RequestOperation operation = new RequestOperation(operationName);
      return new RequestEnvelope(operation, payload);
   }

   private XmlServiceConnectionInterpreter getConnectionInterpreter() {
      XmlSerializer serializer = serializerProvider.getXmlSerializer();
      return new DefaultXmlServiceConnectionInterpreter(serializer);
   }

   private XmlServiceRequest getServiceRequest() {
      ClientSecurityProxy clientSecurityProxy = new KerberosSPNEGOClient(new OSBasedGSSManagerFactory());
      return new KerberosXmlServiceRequest(clientSecurityProxy, systemSecurityProxy);
   }
}