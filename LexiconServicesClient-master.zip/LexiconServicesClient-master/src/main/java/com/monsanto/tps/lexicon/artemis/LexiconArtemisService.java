/*
 LexiconArtemisService was created on Jun 9, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.artemis;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;

import java.util.Collection;

/**
 * @author GGSHIV - Jun 9, 2008 2:44:09 PM
 */
public class LexiconArtemisService {

   private final SystemSecurityProxy systemSecurityProxy;

   public LexiconArtemisService(SystemSecurityProxy systemSecurityProxy) {
      this.systemSecurityProxy = systemSecurityProxy;
   }

   public <T> Collection<T> invokeService(Object payLoad, String operationName, Class<T> responseClass) {
      LexiconArtemisServiceInvoker serviceInvoker = new LexiconArtemisServiceInvoker(systemSecurityProxy, operationName);
      ResponseEnvelope responseEnvelope = serviceInvoker.call(payLoad);
      return responseEnvelope.get(responseClass);
   }
}
