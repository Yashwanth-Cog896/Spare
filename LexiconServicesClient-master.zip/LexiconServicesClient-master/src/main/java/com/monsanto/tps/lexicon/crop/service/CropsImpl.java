/*
 CropsImpl was created on Jun 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.tps.lexicon.artemis.LexiconArtemisService;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.CropAbbreviationAndScientificNameRequest;
import com.monsanto.tps.lexicon.crop.CropNameAndScientificNameRequest;
import com.monsanto.tps.lexicon.crop.processor.CropsProcessor;
import com.monsanto.tps.lexicon.crop.CropPubKeysAndScientificNameRequest;
import com.monsanto.tps.lexicon.crop.CropPublicKeyType;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;
import com.monsanto.tps.lexiconservices.crop.domain.CropPublicKeyTypeEnum;
import com.monsanto.tps.lexiconservices.crop.domain.CropRetrievalByPubKeysAndScientificNameRequest;

import java.util.*;

import static com.monsanto.tps.lexicon.crop.CropPublicKeyType.SCIENTIFIC;

/**
 * @author GGSHIV - Jun 30, 2008 5:23:05 PM
 */
public class CropsImpl extends LexiconArtemisService implements Crops {

  private static final String WILDCARD = "*";
  private static final String FIND_BY_BAYER_CODES_OPERATION = "FindCropsByBayerCodes";
  private static final String FIND_BY_ABBREVIATION_SCIENTIFIC_NAME_OPERATION = "FindCropsByAbbreviationsAndScientificName";
  private static final String FIND_BY_NAME_AND_SCIENTIFIC_NAME_OPERATION = "FindCropsByNameAndScientificName";
  private static final String FIND_BY_PUBKEYS_SCIENTIFIC_NAME_OPERATION = "FindCropsByPubKeysAndScientificName";
  private static final String PUBLIC_KEY = "Crop.Public.Key";
  private static final String BAYER_CODE_PUBLIC_KEY = "Crop.Bayer.Code.Public.Key";
  private static final String SCIENTIFIC_PUBLIC_KEY = "Crop.Genus.Species.Public.Key";
  private static final String BAYER_CODE = "Crop.Bayer.Code";
  private static final String SCIENTIFIC_NAME = "Crop.Scientific.Name";
  private static final String CROP_NAME = "Crop.Name";
  private static final String ABBREVIATION = "Crop.Abbreviation";

  private final LexiconServicesClientRequestValidator validator;

  public CropsImpl(SystemSecurityProxy systemSecurityProxy) {
    super(systemSecurityProxy);
    validator = new LexiconServicesClientRequestValidator(getClass());
  }

  public Crop[] findAll() {
    return findByName(WILDCARD);
  }

  public Crop[] findByPublicKeys(String[] publicKeys) {
    return findByPubkeysAndScientificName(publicKeys, WILDCARD);
  }

  public Crop[] findByBayerCodes(String[] bayerCodes) {
    validator.validateField(BAYER_CODE, bayerCodes);
    return find(bayerCodes, FIND_BY_BAYER_CODES_OPERATION);
  }

  public Crop[] findByBayerCodePublicKeys(String[] bayerCodepubKeys) {
    validator.validateField(BAYER_CODE_PUBLIC_KEY, bayerCodepubKeys);
    return findByPubKeys(bayerCodepubKeys, WILDCARD, CropPublicKeyType.BAYER_CODE);
  }

  public Crop[] findByName(String name) {
    return findByNameAndScientificName(name, WILDCARD);
  }

  public Crop[] findByScientificName(String scientificName) {
    return findByNameAndScientificName(WILDCARD, scientificName);
  }

  public Crop[] findByGenusSpeciePublicKeys(String[] scientificpubKeys) {
    validator.validateField(SCIENTIFIC_PUBLIC_KEY, scientificpubKeys);
    return findByPubKeys(scientificpubKeys, WILDCARD, SCIENTIFIC);
  }

  public Crop[] findByAbbreviations(String[] abbreviations) {
    return findByAbbreviationsAndScientificName(abbreviations, WILDCARD);
  }

  public Crop[] findByAbbreviationsAndScientificName(String[] abbreviations, String scientificName) {
    validator.addField(ABBREVIATION, abbreviations);
    validator.addField(SCIENTIFIC_NAME, scientificName);
    validator.validate();
    CropAbbreviationAndScientificNameRequest request = new CropAbbreviationAndScientificNameRequest(abbreviations, scientificName);
    return find(request, FIND_BY_ABBREVIATION_SCIENTIFIC_NAME_OPERATION);
  }

  public Crop[] findByPubkeysAndScientificName(String[] pubkeys, String scientificName) {
    validator.addField(PUBLIC_KEY, pubkeys);
    validator.addField(SCIENTIFIC_NAME, scientificName);
    validator.validate();

    CropRetrievalByPubKeysAndScientificNameRequest request = new CropRetrievalByPubKeysAndScientificNameRequest(Arrays.asList(pubkeys), scientificName, CropPublicKeyTypeEnum.CROP);
    CropsProcessor cropsProcessor = new CropsProcessor();
    Collection<Crop> crops = null;
    try {
      crops = cropsProcessor.findCropsByPublicKeysAndScientificName(request);
    } catch (Exception e) {

    }
    return crops.toArray(new Crop[crops.size()]);
  }

  public Crop[] findByNameAndScientificName(String name, String scientificName) {
    validator.addField(CROP_NAME, name);
    validator.addField(SCIENTIFIC_NAME, scientificName);
    validator.validate();
    return find(new CropNameAndScientificNameRequest(name, scientificName), FIND_BY_NAME_AND_SCIENTIFIC_NAME_OPERATION);
  }

  private Crop[] findByPubKeys(String[] bayerCodepubKeys, String scientificName, CropPublicKeyType publicKeyType) {
    CropPubKeysAndScientificNameRequest request = new CropPubKeysAndScientificNameRequest(bayerCodepubKeys, scientificName, publicKeyType);
    return find(request, FIND_BY_PUBKEYS_SCIENTIFIC_NAME_OPERATION);
  }

  private Crop[] find(Object payload, String operationName) {
    Collection<Crop> crops = invokeService(payload, operationName, Crop.class);
    return crops.toArray(new Crop[crops.size()]);
  }

}
