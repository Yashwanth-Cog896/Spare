package com.monsanto.tps.lexicon.traitstack.service;

import com.monsanto.tps.lexicon.traitstack.TraitStackRequest;
import com.monsanto.tps.lexicon.traitstack.TraitStackVO;

/**
 * Filename:    TraitStacks.java
 * Last Change: rrchak1 On:	Jul 18, 2008
 *
 * @author: rrchak1
 */
public interface TraitStacks {

    TraitStackVO[] findBySearchCriteria(TraitStackRequest traitStackRequest);
}
