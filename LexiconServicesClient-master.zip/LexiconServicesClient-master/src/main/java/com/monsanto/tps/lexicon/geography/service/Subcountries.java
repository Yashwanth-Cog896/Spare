package com.monsanto.tps.lexicon.geography.service;

import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

/**
 * nbwald - Jul 1, 2008 2:10:00 PM
 */
public interface Subcountries
{
   Subcountry[] findAllSubcountries(String countryISOCode);

   Subcountry[] findSubcountriesByName(String countryISOCode, String subcountryName);

   Subcountry[] findSubcountriesByAbbreviation(String countryISOCode, String[] subcountriesAbbreviation);
}
