package com.monsanto.tps.lexicon.person.service;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tps.lexicon.person.MinimalPeopleRecordNameQuery;
import com.monsanto.tps.lexicon.person.MinimalPersonRecord;
import com.monsanto.tps.lexicon.person.PeopleRecordQuery;
import com.monsanto.tps.lexicon.person.PersonRecord;
import com.monsanto.tps.lexicon.validation.LexiconServicesClientRequestValidator;
import com.monsanto.tps.lexicon.validation.PersonNameValidator;

import java.util.Collection;

/**
 * nbwald - Apr 30, 2008 10:29:59 AM
 */
public class PeopleImpl implements People {

   private static final String FETCH_MINIMAL_PEOPLE_RECORDS_OPERATION = "FetchMinimalPeopleRecords";
   private static final String FETCH_PEOPLE_RECORDS_OPERATION = "FetchPeopleRecords";
   private final PeopleRecordQueryIdBuilder idBuilder = new PeopleRecordQueryIdBuilder();

   private PeopleDataService peopleDataService;

   private static final String NETWORK_ID = "People.Network.Id";
   private final LexiconServicesClientRequestValidator validator;

   public PeopleImpl(SystemSecurityProxy systemSecurityProxy) {
      this.validator = new LexiconServicesClientRequestValidator(getClass());
      this.peopleDataService = new PeopleDataService(systemSecurityProxy);
   }

   public PersonRecord[] findPeopleByNetworkIds(String[] networkIds) {
      return findPeopleByNetworkIds(networkIds, true);
   }

   public PersonRecord[] findPeopleByNetworkIds(String[] networkIds, boolean onlyActive) {
      validator.validateField(NETWORK_ID, networkIds);
      CompositeObject compositeObject = buildNetworkIdQuery(networkIds, onlyActive);
      return fetchPeopleRecords(compositeObject);
   }

   public PersonRecord[] findPeopleByPartyIds(long[] partyIds) {
      return findPeopleByPartyIds(partyIds, true);
   }

   public PersonRecord[] findPeopleByPartyIds(long[] partyIds, boolean onlyActive) {
      CompositeObject compositeObject = buildPartyIdQuery(partyIds, onlyActive);
      return fetchPeopleRecords(compositeObject);
   }

   public MinimalPersonRecord[] findMinimalPersonRecordsByNetworkIds(String[] networkIds) {
      validator.validateField(NETWORK_ID, networkIds);
      CompositeObject compositeObject = buildNetworkIdQuery(networkIds, true);
      return fetchMinimalPeopleRecords(compositeObject);
   }

   public MinimalPersonRecord[] findMinimalPersonRecordsByPartyIds(long[] partyIds) {
      CompositeObject compositeObject = buildPartyIdQuery(partyIds, true);
      return fetchMinimalPeopleRecords(compositeObject);
   }

   public MinimalPersonRecord[] findMinimalPersonRecordsByWildcardableFirstAndLastName(String firstName, String lastName) {
      validateFields(firstName, lastName);
      CompositeObject compositeObject = buildWildcardableNameQuery(firstName, lastName);
      return fetchMinimalPeopleRecords(compositeObject);
   }

   private void validateFields(String firstName, String lastName) {
      new PersonNameValidator(firstName, lastName).validate();
   }

   private MinimalPersonRecord[] fetchMinimalPeopleRecords(CompositeObject compositeObject) {
      ResponseEnvelope responseEnvelope = peopleDataService.call(FETCH_MINIMAL_PEOPLE_RECORDS_OPERATION, compositeObject);
      Collection<MinimalPersonRecord> minimalPersonRecords = (Collection<MinimalPersonRecord>) responseEnvelope.getFirst(Collection.class);
      return minimalPersonRecords.toArray(new MinimalPersonRecord[minimalPersonRecords.size()]);
   }

   private PersonRecord[] fetchPeopleRecords(CompositeObject compositeObject) {
      ResponseEnvelope responseEnvelope = peopleDataService.call(FETCH_PEOPLE_RECORDS_OPERATION, compositeObject);
      Collection<PersonRecord> personRecordCollection = (Collection<PersonRecord>) responseEnvelope.getFirst(Collection.class);
      return personRecordCollection.toArray(new PersonRecord[personRecordCollection.size()]);
   }

   private CompositeObject buildNetworkIdQuery(String[] networkIds, boolean onlyActive) {
      CompositeObject compositeObject = new CompositeObject();
      compositeObject.add(new PeopleRecordQuery(idBuilder.buildByNetworkIds(networkIds), onlyActive));
      return compositeObject;
   }

   private CompositeObject buildPartyIdQuery(long[] partyIds, boolean onlyActive) {
      CompositeObject compositeObject = new CompositeObject();
      compositeObject.add(new PeopleRecordQuery(idBuilder.buildByPartyIds(partyIds), onlyActive));
      return compositeObject;
   }

   private CompositeObject buildWildcardableNameQuery(String firstName, String lastName) {
      CompositeObject compositeObject = new CompositeObject();
      compositeObject.add(new MinimalPeopleRecordNameQuery(firstName, lastName));
      return compositeObject;
   }

    public void setPeopleDataService(PeopleDataService peopleDataService) {
        this.peopleDataService = peopleDataService;
    }
}
