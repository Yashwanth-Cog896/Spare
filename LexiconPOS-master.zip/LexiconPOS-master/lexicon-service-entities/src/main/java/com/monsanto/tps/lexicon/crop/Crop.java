/*
 Crop was created on Jul 8, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop;

import java.util.List;

/**
 * @author GGSHIV - Jul 8, 2008 11:01:40 AM
 */
public class Crop {

   private String publicKey;
   private String name;
   private String abbreviation;
   private String shippingStatement;
   private List<BayerCode> bayerCodes;

   public String getPublicKey() {
      return publicKey;
   }

   public void setPublicKey(String publicKey) {
      this.publicKey = publicKey;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

   public String getShippingStatement() {
      return shippingStatement;
   }

   public void setShippingStatement(String shippingStatement) {
      this.shippingStatement = shippingStatement;
   }

   public List<BayerCode> getBayerCodes() {
      return bayerCodes;
   }

   public void setBayerCodes(List<BayerCode> bayerCodes) {
      this.bayerCodes = bayerCodes;
   }
}
