/*
 MinimalPeopleRecordNameQuery was created on May 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.person;

/**
 * GGSHIV - May 1, 2008 2:43:59 PM
 */
public class MinimalPeopleRecordNameQuery {

   private String firstName;

   private String lastName;

   public MinimalPeopleRecordNameQuery(String firstName, String lastName) {
      this.firstName = firstName;
      this.lastName = lastName;
   }

   public String getLastName() {
      return lastName;
   }

   public String getFirstName() {
      return firstName;
   }
}
