package com.monsanto.tps.lexicon.crop;

/**
 * @author GGSHIV - Jul 4, 2008 11:42:04 AM
 */
public enum CropPublicKeyType {

   CROP ("C.CROP_PUBKEY"), BAYER_CODE("BC.BAYER_CODE_PUBKEY"), SCIENTIFIC ("BCGS.BAYER_CODE_GENUS_SP_PUBKEY");

   private String type;

   CropPublicKeyType(String type) {
      this.type = type;
   }

   public String getType() {
      return type;
   }
}
