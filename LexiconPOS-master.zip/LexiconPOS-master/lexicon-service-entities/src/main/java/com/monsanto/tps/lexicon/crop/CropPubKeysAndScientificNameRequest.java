/*
 CropPubKeysAndScientificNameRequest was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop;

/**
 * @author PNAGAPP - Jul 1, 2008 11:15:34 AM
 */
public class CropPubKeysAndScientificNameRequest {

   private final String[] publickeys;
   private final String scientificName;
   private final CropPublicKeyType publicKeyType;

   public CropPubKeysAndScientificNameRequest(String[] publickeys, String scientificName, CropPublicKeyType publicKeyType) {
      this.publickeys = publickeys;
      this.scientificName = scientificName;
      this.publicKeyType = publicKeyType;
   }

   public String[] getPublickeys() {
      return publickeys;
   }

   public String getScientificName() {
      return scientificName;
   }

   public CropPublicKeyType getPublicKeyType() {
      return publicKeyType;
   }
}
