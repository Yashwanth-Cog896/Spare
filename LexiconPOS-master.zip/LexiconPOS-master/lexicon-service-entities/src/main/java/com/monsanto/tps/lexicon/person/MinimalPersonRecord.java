package com.monsanto.tps.lexicon.person;

/**
 * nbwald - Apr 28, 2008 5:49:54 PM
 */
public class MinimalPersonRecord
{
   //private long uniqueId;
   private String  uniqueId;
   private String firstName;
   private String middleName;
   private String lastName;
   private String organizationDescription;
   private String networkId;

   public String getFirstName() {
      return firstName;
   }

   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }

   public String getMiddleName() {
      return middleName;
   }

   public void setMiddleName(String middleName) {
      this.middleName = middleName;
   }

   public String getLastName() {
      return lastName;
   }

   public void setLastName(String lastName) {
      this.lastName = lastName;
   }

   public String getNetworkId() {
      return networkId;
   }

   public void setNetworkId(String networkId) {
      this.networkId = networkId;
   }

   public String getOrganizationDescription() {
      return organizationDescription;
   }

   public void setOrganizationDescription(String organizationDescription) {
      this.organizationDescription = organizationDescription;
   }

   /*public long getUniqueId() {
      return uniqueId;
   }

   public void setUniqueId(long uniqueId) {
      this.uniqueId = uniqueId;
   }*/
   public String  getUniqueId() {
      return uniqueId;
   }

   public void setUniqueId(String  uniqueId) {
      this.uniqueId = uniqueId;
   }

}
