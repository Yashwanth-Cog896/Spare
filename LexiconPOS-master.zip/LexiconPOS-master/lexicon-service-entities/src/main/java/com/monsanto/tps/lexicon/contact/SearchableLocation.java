package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - May 19, 2008 5:31:49 PM
 */
public class SearchableLocation
{
   private String countryName;
   private String subcountryCode;
   private String subsubcountryName;
   private String city;

   public String getCountryName() {
      return countryName;
   }

   public void setCountryName(String countryName) {
      this.countryName = countryName;
   }

   public String getSubcountryCode() {
      return subcountryCode;
   }

   public void setSubcountryCode(String subcountryCode) {
      this.subcountryCode = subcountryCode;
   }

   public String getSubsubcountryName() {
      return subsubcountryName;
   }

   public void setSubsubcountryName(String subsubcountryName) {
      this.subsubcountryName = subsubcountryName;
   }

   public String getCity() {
      return city;
   }

   public void setCity(String city) {
      this.city = city;
   }
}
