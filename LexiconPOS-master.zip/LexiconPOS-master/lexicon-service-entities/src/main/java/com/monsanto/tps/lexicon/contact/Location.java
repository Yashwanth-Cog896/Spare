package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - Apr 28, 2008 5:34:24 PM
 */
public class Location
{
   private String mailZone;
   private String siteName;
   private String siteIndex;

   public String getMailZone() {
      return mailZone;
   }

   public void setMailZone(String mailZone) {
      this.mailZone = mailZone;
   }

   public String getSiteIndex() {
      return siteIndex;
   }

   public void setSiteIndex(String siteIndex) {
      this.siteIndex = siteIndex;
   }

   public String getSiteName() {
      return siteName;
   }

   public void setSiteName(String siteName) {
      this.siteName = siteName;
   }
}
