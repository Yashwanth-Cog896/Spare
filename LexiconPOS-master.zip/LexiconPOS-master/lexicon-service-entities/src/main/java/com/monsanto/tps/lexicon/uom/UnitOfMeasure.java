package com.monsanto.tps.lexicon.uom;

/**
 * Filename:    UnitsOfMeasure.java
 * Last Change: rrchak1 On:	Jun 16, 2008
 *
 * @author: rrchak1
 */
public class UnitOfMeasure {

    private String name;
    private String code;
    private String symbol;
    private String dimension;
    private String unitType;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public String getUnitType() {
        return unitType;
    }

    public void setUnitType(String unitType) {
        this.unitType = unitType;
    }
}
