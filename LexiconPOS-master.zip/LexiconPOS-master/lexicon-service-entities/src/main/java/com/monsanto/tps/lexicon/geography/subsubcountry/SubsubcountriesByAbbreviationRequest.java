/*
 SubsubcountriesByAbbreviationRequest was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.subsubcountry;

/**
 * @author GGSHIV - Jun 10, 2008 2:23:58 PM
 */
public class SubsubcountriesByAbbreviationRequest {

   private String countryISOCode;
   private String[] subcountriesAbbreviation;
   private String wildcardableName;

   public String getCountryISOCode() {
      return countryISOCode;
   }

   public void setCountryISOCode(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public String[] getSubcountriesAbbreviation() {
      return subcountriesAbbreviation;
   }

   public void setSubcountriesAbbreviation(String[] subcountriesAbbreviation) {
      this.subcountriesAbbreviation = subcountriesAbbreviation;
   }

   public String getWildcardableName() {
      return wildcardableName;
   }

   public void setWildcardableName(String wildcardableName) {
      this.wildcardableName = wildcardableName;
   }
}
