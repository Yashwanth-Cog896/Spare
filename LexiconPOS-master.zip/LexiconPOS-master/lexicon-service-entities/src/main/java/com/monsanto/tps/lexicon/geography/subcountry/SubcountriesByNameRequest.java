package com.monsanto.tps.lexicon.geography.subcountry;

/**
 * nbwald - Jun 8, 2008 1:09:35 PM
 */
public class SubcountriesByNameRequest
{
   private String countryISOCode;
   private String wildcardableSubcountryName;

   public String getCountryISOCode() {
      return countryISOCode;
   }

   public void setCountryISOCode(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public String getWildcardableSubcountryName() {
      return wildcardableSubcountryName;
   }

   public void setWildcardableSubcountryName(String wildcardableSubcountryName) {
      this.wildcardableSubcountryName = wildcardableSubcountryName;
   }
}
