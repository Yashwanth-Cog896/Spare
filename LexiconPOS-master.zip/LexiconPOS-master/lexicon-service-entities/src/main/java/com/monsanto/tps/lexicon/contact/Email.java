package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - Apr 28, 2008 5:36:51 PM
 */
public class Email
{
   private String emailAddress;

   public String getEmailAddress() {
      return emailAddress;
   }

   public void setEmailAddress(String emailAddress) {
      this.emailAddress = emailAddress;
   }
}
