/*
 SubcountriesByAbbreviationRequest was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.subcountry;

/**
 * @author GGSHIV - Jun 10, 2008 12:20:40 PM
 */
public class SubcountriesByAbbreviationRequest {

   private String countryISOCode;
   private String[] subcountriesAbbreviation;

   public void setCountryISOCode(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public String getCountryISOCode() {
      return countryISOCode;
   }

   public void setSubcountriesAbbreviation(String[] subcountriesAbbreviation) {
      this.subcountriesAbbreviation = subcountriesAbbreviation;
   }

   public String[] getSubcountriesAbbreviation() {
      return subcountriesAbbreviation;
   }
}
