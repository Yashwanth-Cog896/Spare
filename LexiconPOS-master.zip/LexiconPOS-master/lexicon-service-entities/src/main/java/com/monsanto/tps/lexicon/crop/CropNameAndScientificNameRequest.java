/*
 CropNameAndScientificNameRequest was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop;

/**
 * @author PNAGAPP - Jul 1, 2008 4:32:47 PM
 */
public class CropNameAndScientificNameRequest {

   private final String name;
   private final String scientificName;

   public CropNameAndScientificNameRequest(String name, String scientificName) {
      this.name = name;
      this.scientificName = scientificName;
   }

   public String getName() {
      return name;
   }

   public String getScientificName() {
      return scientificName;
   }

}
