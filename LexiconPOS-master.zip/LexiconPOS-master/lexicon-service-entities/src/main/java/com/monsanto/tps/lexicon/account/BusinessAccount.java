/*
 BusinessAccount was created on May 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.account;

import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.PhoneNumber;

/**
 * @author ggshiv - May 12, 2008 4:10:57 PM
 */
public class BusinessAccount {

   private String accountID;
   private String companyName;
   private PhoneNumber phone;
   private AddressRecord[] addressRecords;

   public String getAccountID() {
      return accountID;
   }

   public void setAccountID(String accountID) {
      this.accountID = accountID;
   }

   public AddressRecord[] getAddressRecords() {
      return addressRecords;
   }

   public void setAddressRecords(AddressRecord[] addressRecords) {
      this.addressRecords = addressRecords;
   }

   public String getCompanyName() {
      return companyName;
   }

   public void setCompanyName(String companyName) {
      this.companyName = companyName;
   }

   public PhoneNumber getPhone() {
      return phone;
   }

   public void setPhone(PhoneNumber phone) {
      this.phone = phone;
   }
}