package com.monsanto.tps.lexicon.person;

/**
 * Filename:    ExternalContactByBusinessGeographySearchCriteria.java
 * Last Change: rrchak1 On:	Jul 23, 2008
 *
 * @author: rrchak1
 */
public class ExternalContactByBusinessGeographySearchCriteria {

    private ExternalContactSearchCriteria externalContactSearchCriteria;


    public ExternalContactSearchCriteria getExternalContactSearchCriteria() {
        return externalContactSearchCriteria;
    }

    public void setExternalContactSearchCriteria(ExternalContactSearchCriteria externalContactSearchCriteria) {
        this.externalContactSearchCriteria = externalContactSearchCriteria;
    }
}
