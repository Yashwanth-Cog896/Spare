package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - Apr 28, 2008 5:37:57 PM
 */
public class Organization
{
   private String orgID;
   private String orgDesc;
   private String divisionID;
   private String divisionDesc;
   private String mailCode;
   private String fullCostCenter;
   private String unitID;
   private String unitDesc;

   public String getDivisionDesc() {
      return divisionDesc;
   }

   public void setDivisionDesc(String divisionDesc) {
      this.divisionDesc = divisionDesc;
   }

   public String getDivisionID() {
      return divisionID;
   }

   public void setDivisionID(String divisionID) {
      this.divisionID = divisionID;
   }

   public String getFullCostCenter() {
      return fullCostCenter;
   }

   public void setFullCostCenter(String fullCostCenter) {
      this.fullCostCenter = fullCostCenter;
   }

   public String getMailCode() {
      return mailCode;
   }

   public void setMailCode(String mailCode) {
      this.mailCode = mailCode;
   }

   public String getOrgDesc() {
      return orgDesc;
   }

   public void setOrgDesc(String orgDesc) {
      this.orgDesc = orgDesc;
   }

   public String getOrgID() {
      return orgID;
   }

   public void setOrgID(String orgID) {
      this.orgID = orgID;
   }

   public String getUnitDesc() {
      return unitDesc;
   }

   public void setUnitDesc(String unitDesc) {
      this.unitDesc = unitDesc;
   }

   public String getUnitID() {
      return unitID;
   }

   public void setUnitID(String unitID) {
      this.unitID = unitID;
   }
}
