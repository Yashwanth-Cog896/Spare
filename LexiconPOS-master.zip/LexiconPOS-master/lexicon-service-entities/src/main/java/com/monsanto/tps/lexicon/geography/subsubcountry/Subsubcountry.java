/*
 Subsubcountry was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.subsubcountry;

/**
 * @author GGSHIV - Jun 10, 2008 2:14:37 PM
 */
public class Subsubcountry {

   private String name;
   private String countryISOCode;
   private String abbreviation;
   private String description;

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

   public String getCountryISOCode() {
      return countryISOCode;
   }

   public void setCountryISOCode(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }
}
