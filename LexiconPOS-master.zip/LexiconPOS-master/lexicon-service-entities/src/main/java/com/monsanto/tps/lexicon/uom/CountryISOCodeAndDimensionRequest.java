/*
 CountryISOCodeAndDimensionRequest was created on Jun 17, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.uom;

/**
 * @author GGSHIV - Jun 17, 2008 1:09:35 PM
 */
public class CountryISOCodeAndDimensionRequest {

   private String countryISOCode;
   private String wildcardableDimension;

   public CountryISOCodeAndDimensionRequest(String countryISOCode, String wildcardableDimension) {
      this.countryISOCode = countryISOCode;
      this.wildcardableDimension = wildcardableDimension;
   }

   public String getCountryISOCode() {
      return countryISOCode;
   }

   public void setCountryISOCode(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public String getWildcardableDimension() {
      return wildcardableDimension;
   }

   public void setWildcardableDimension(String wildcardableDimension) {
      this.wildcardableDimension = wildcardableDimension;
   }
}