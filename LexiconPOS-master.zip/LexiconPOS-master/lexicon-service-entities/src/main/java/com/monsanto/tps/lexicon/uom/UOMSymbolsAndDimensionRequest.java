/*
 UOMSymbolsAndDimensionRequest was created on Jun 23, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.uom;

/**
 * @author GGSHIV - Jun 23, 2008 3:50:55 PM
 */
public class UOMSymbolsAndDimensionRequest {

   private String[] symbols;
   private String wildcardableDimension;

   public UOMSymbolsAndDimensionRequest(String[] symbols, String wildcardableDimension) {
      this.symbols = symbols;
      this.wildcardableDimension = wildcardableDimension;
   }

   public void setSymbols(String[] symbols) {
      this.symbols = symbols;
   }

   public void setWildcardableDimension(String wildcardableDimension) {
      this.wildcardableDimension = wildcardableDimension;
   }

   public String[] getSymbols() {
      return symbols;
   }

   public String getWildcardableDimension() {
      return wildcardableDimension;
   }
}
