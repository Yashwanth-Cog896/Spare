package com.monsanto.tps.lexicon.person;

/**
 * nbwald - Apr 28, 2008 5:39:57 PM
 */
public class Person
{
   private String firstName;
   private String middleName;
   private String lastName;
   private String userID;
   private String employeeStatus;
   private String title;

   public String getEmployeeStatus() {
      return employeeStatus;
   }

   public void setEmployeeStatus(String employeeStatus) {
      this.employeeStatus = employeeStatus;
   }

   public String getFirstName() {
      return firstName;
   }

   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }

   public String getLastName() {
      return lastName;
   }

   public void setLastName(String lastName) {
      this.lastName = lastName;
   }

   public String getMiddleName() {
      return middleName;
   }

   public void setMiddleName(String middleName) {
      this.middleName = middleName;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public String getUserID() {
      return userID;
   }

   public void setUserID(String userID) {
      this.userID = userID;
   }
}
