/*
 ExternalContact was created on May 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.person;

import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.Email;
import com.monsanto.tps.lexicon.contact.PhoneNumber;

/**
 * @author ggshiv - May 12, 2008 4:18:57 PM
 */
public class ExternalContact {

   private String contactID;
   private String firstName;
   private String middleName;
   private String lastName;
   private String businessAccountID;
   private String companyName;
   private AddressRecord[] addressRecords;
   private PhoneNumber phone;
   private PhoneNumber cell;
   private PhoneNumber fax;
   private PhoneNumber pager;
   private String jobTitle;
   private Email email;
   private String[] contactTypes;

   public String getContactID() {
      return contactID;
   }

   public void setContactID(String contactID) {
      this.contactID = contactID;
   }

   public String getFirstName() {
      return firstName;
   }

   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }

   public String getMiddleName() {
      return middleName;
   }

   public void setMiddleName(String middleName) {
      this.middleName = middleName;
   }

   public String getLastName() {
      return lastName;
   }

   public void setLastName(String lastName) {
      this.lastName = lastName;
   }

   public String getBusinessAccountID() {
      return businessAccountID;
   }

   public void setBusinessAccountID(String businessAccountID) {
      this.businessAccountID = businessAccountID;
   }

   public AddressRecord[] getAddressRecords() {
      return addressRecords;
   }

   public void setAddressRecords(AddressRecord[] addressRecords) {
      this.addressRecords = addressRecords;
   }

   public String getCompanyName() {
      return companyName;
   }

   public void setCompanyName(String companyName) {
      this.companyName = companyName;
   }

   public PhoneNumber getCell() {
      return cell;
   }

   public void setCell(PhoneNumber cell) {
      this.cell = cell;
   }

   public Email getEmail() {
      return email;
   }

   public void setEmail(Email email) {
      this.email = email;
   }

   public PhoneNumber getFax() {
      return fax;
   }

   public void setFax(PhoneNumber fax) {
      this.fax = fax;
   }

   public String getJobTitle() {
      return jobTitle;
   }

   public void setJobTitle(String jobTitle) {
      this.jobTitle = jobTitle;
   }

   public PhoneNumber getPager() {
      return pager;
   }

   public void setPager(PhoneNumber pager) {
      this.pager = pager;
   }

   public PhoneNumber getPhone() {
      return phone;
   }

   public void setPhone(PhoneNumber phone) {
      this.phone = phone;
   }

   public String[] getContactTypes() {
      return contactTypes;
   }

   public void setContactTypes(String[] contactTypes) {
      this.contactTypes = contactTypes;
   }
}