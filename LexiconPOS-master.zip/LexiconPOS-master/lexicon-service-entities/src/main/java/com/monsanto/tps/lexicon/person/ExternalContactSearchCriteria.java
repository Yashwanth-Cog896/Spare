package com.monsanto.tps.lexicon.person;

import com.monsanto.tps.lexicon.contact.SearchableLocation;

/**
 * nbwald - May 15, 2008 2:43:48 PM
 */
public class ExternalContactSearchCriteria
{
   private SearchableLocation location;
   private String contactType;
   private String companyName;
   private String firstName;
   private String lastName;
   private int maxResults;

   public SearchableLocation getLocation() {
      return location;
   }

   public void setLocation(SearchableLocation location) {
      this.location = location;
   }

   public String getContactType() {
      return contactType;
   }

   public void setContactType(String contactType) {
      this.contactType = contactType;
   }

   public String getCompanyName() {
      return companyName;
   }

   public void setCompanyName(String companyName) {
      this.companyName = companyName;
   }

   public String getFirstName() {
      return firstName;
   }

   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }

   public String getLastName() {
      return lastName;
   }

   public void setLastName(String lastName) {
      this.lastName = lastName;
   }

   public void setMaxResults(int maxResults) {
      this.maxResults=maxResults;
   }

   public int getMaxResults() {
      return maxResults;
   }
}
