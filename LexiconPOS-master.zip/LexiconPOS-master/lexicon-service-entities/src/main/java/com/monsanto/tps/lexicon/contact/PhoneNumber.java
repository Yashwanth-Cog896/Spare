package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - Apr 28, 2008 5:35:49 PM
 */
public class PhoneNumber
{
   private String number;

   public String getNumber() {
      return number;
   }

   public void setNumber(String number) {
      this.number = number;
   }
}
