package com.monsanto.tps.lexicon.account;

import com.monsanto.tps.lexicon.contact.SearchableLocation;

/**
 * nbwald - May 15, 2008 11:17:13 AM
 */
public class BusinessAccountSearchCriteria
{
   private SearchableLocation location;
   private String companyName;
   private int maxResults;

   public SearchableLocation getLocation() {
      return location;
   }

   public void setLocation(SearchableLocation location) {
      this.location = location;
   }

   public String getCompanyName() {
      return companyName;
   }

   public void setCompanyName(String companyName) {
      this.companyName = companyName;
   }

   public void setMaxResults(int maxResults) {
      this.maxResults=maxResults;
   }

   public int getMaxResults() {
      return maxResults;
   }
}
