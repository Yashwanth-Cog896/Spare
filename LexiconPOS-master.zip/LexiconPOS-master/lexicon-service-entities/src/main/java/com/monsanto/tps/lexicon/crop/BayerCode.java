/*
 BayerCode was created on Jul 8, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop;

import java.util.List;

/**
 * @author GGSHIV - Jul 8, 2008 11:10:52 AM
 */
public class BayerCode {

   String code;
   String publicKey;
   List<ScientificName> scientificNames;

   public BayerCode(String code, String publicKey, List<ScientificName> scientificNames) {
      this.code = code;
      this.publicKey = publicKey;
      this.scientificNames = scientificNames;
   }
   public BayerCode(){
       
   }

   public String getCode() {
      return code;
   }

   public String getPublicKey() {
      return publicKey;
   }

   public List<ScientificName> getScientificNames() {
      return scientificNames;
   }

    public void setCode(String code) {
        this.code = code;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    public void setScientificNames(List<ScientificName> scientificNames) {
        this.scientificNames = scientificNames;
    }
}
