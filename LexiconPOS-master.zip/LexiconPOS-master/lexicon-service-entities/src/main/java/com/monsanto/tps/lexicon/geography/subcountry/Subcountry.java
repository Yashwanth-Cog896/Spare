package com.monsanto.tps.lexicon.geography.subcountry;

/**
 * nbwald - Jun 8, 2008 12:56:54 PM
 */
public class Subcountry
{
   private String name;
   private String countryISOCode;
   private String abbreviation;
   private String description;

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

   public String getCountryISOCode() {
      return countryISOCode;
   }

   public void setCountryISOCode(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }
}
