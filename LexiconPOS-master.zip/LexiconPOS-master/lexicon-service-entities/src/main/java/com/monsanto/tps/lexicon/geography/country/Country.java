/*
 Country was created on May 29, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.geography.country;

/**
 * @author GGSHIV - May 30, 2008 9:53:06 AM
 */
public class Country {

   private String name;
   private String countryISOcode;
   private String subCountryDescription;
   private String subSubCountryDescription;
   private String abbreviation;

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

   public String getCountryISOcode() {
      return countryISOcode;
   }

   public void setCountryISOcode(String countryISOcode) {
      this.countryISOcode = countryISOcode;
   }

   public String getSubCountryDescription() {
      return subCountryDescription;
   }

   public void setSubCountryDescription(String subCountryDescription) {
      this.subCountryDescription = subCountryDescription;
   }

   public String getSubSubCountryDescription() {
      return subSubCountryDescription;
   }

   public void setSubSubCountryDescription(String subSubCountryDescription) {
      this.subSubCountryDescription = subSubCountryDescription;
   }

}