package com.monsanto.tps.lexicon.traitstack;

/**
 * Filename:    TraitStackRequest.java
 * Last Change: rrchak1 On:	Jul 15, 2008
 *
 * @author: rrchak1
 */
public class TraitStackRequest
{
   private String[] pubKeys;
   private String[] cropNames;
   private String[] stackAttribute;
   private boolean precommercialOnly;

   public String[] getPubKeys() {
      return pubKeys;
   }

   public void setPubKeys(String[] pubKeys) {
      this.pubKeys = pubKeys;
   }

   public void setCropNames(String[] cropNames) {
      this.cropNames = cropNames;
   }

   public String[] getCropNames() {
      return cropNames;
   }

   public void setStackAttribute(String[] stackAttribute) {
      this.stackAttribute = stackAttribute;
   }

   public String[] getStackAttribute() {
      return stackAttribute;
   }

   public boolean isPrecommercialOnly() {
      return precommercialOnly;
   }

   public void setPrecommercialOnly(boolean precommercialOnly) {
      this.precommercialOnly = precommercialOnly;
   }
}
