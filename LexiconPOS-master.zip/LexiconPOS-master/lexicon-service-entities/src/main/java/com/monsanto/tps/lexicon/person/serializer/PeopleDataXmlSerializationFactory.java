package com.monsanto.tps.lexicon.person.serializer;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tps.lexicon.person.MinimalPeopleRecordNameQuery;
import com.monsanto.tps.lexicon.person.MinimalPersonRecord;
import com.monsanto.tps.lexicon.person.NetworkID;
import com.monsanto.tps.lexicon.person.PartyID;
import com.monsanto.tps.lexicon.person.PeopleRecordQuery;
import com.monsanto.tps.lexicon.person.PersonRecord;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: May 2, 2008
 * Time: 3:43:04 PM
 */
public class PeopleDataXmlSerializationFactory implements XmlSerializerProvider {
    private final String NAMESPACE = "http://www.monsanto.com/lexicon/peopledata";

    public XmlSerializer createSerializer() {
        XmlSerializerBuilder builder = new XmlSerializerBuilder();
        builder.setClassLoader(PeopleDataXmlSerializationFactory.class.getClassLoader());
        builder.registerMapping(NAMESPACE, "request", RequestEnvelope.class);
        builder.registerMapping(NAMESPACE, "response", ResponseEnvelope.class);
        builder.registerMapping(NAMESPACE, "networkid", NetworkID.class);
        builder.registerMapping(NAMESPACE, "partyid", PartyID.class);
        builder.registerMapping(NAMESPACE, "minimalpeoplerecordnamequery", MinimalPeopleRecordNameQuery.class);
        builder.registerMapping(NAMESPACE, "peoplerecordquery", PeopleRecordQuery.class);
        builder.registerMapping(NAMESPACE, "minimalpersonrecord", MinimalPersonRecord.class);
        builder.registerMapping(NAMESPACE, "personrecord", PersonRecord.class);
        builder.addImplicitCollection(CompositeObject.class, "objects");
        return builder.createSerializer();
    }

    public XmlSerializer getXmlSerializer() {
        return createSerializer();
    }
}
