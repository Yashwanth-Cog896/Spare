package com.monsanto.tps.lexicon.traitstack;

/**
 * Filename:    TraitStackVO.java
 * Last Change: rrchak1 On:	Jul 16, 2008
 *
 * @author: rrchak1
 */
public class TraitStackVO
{
   private long traitStackId;
   private String traitStackPubkey;
   private String traitStackAbbr;
   private String traitStackDesc;
   private String traitStackReportingName;
   private String traitStackTDName;
   private String traitStackCropName;
   private String traitStackManfTraitCode;
   private boolean precommercial;

   public void setTraitStackId(long traitStackId) {
      this.traitStackId = traitStackId;
   }

   public long getTraitStackId() {
      return traitStackId;
   }

   public void setTraitStackPubKey(String traitStackPubkey) {
      this.traitStackPubkey = traitStackPubkey;
   }

   public String getTraitStackPubkey() {
      return traitStackPubkey;
   }

   public void setTraitStackAbbr(String traitStackAbbr) {
      this.traitStackAbbr = traitStackAbbr;
   }

   public String getTraitStackAbbr() {
      return traitStackAbbr;
   }

   public void setTraitStackDesc(String traitStackDesc) {
      this.traitStackDesc = traitStackDesc;
   }

   public String getTraitStackDesc() {
      return traitStackDesc;
   }

   public void setTraitStackReportingName(String traitStackReportingName) {
      this.traitStackReportingName = traitStackReportingName;
   }

   public String getTraitStackReportingName() {
      return traitStackReportingName;
   }

   public void setTraitStackTDName(String traitStackTDName) {
      this.traitStackTDName = traitStackTDName;
   }

   public String getTraitStackTDName() {
      return traitStackTDName;
   }

   public String getTraitStackCropName() {
      return traitStackCropName;
   }

   public void setTraitStackCropName(String traitStackCropName) {
      this.traitStackCropName = traitStackCropName;
   }

   public String getTraitStackManfTraitCode() {
      return traitStackManfTraitCode;
   }

   public void setTraitStackManfTraitCode(String traitStackManfTraitCode) {
      this.traitStackManfTraitCode = traitStackManfTraitCode;
   }

   public boolean isPrecommercial() {
      return precommercial;
   }

   public void setPrecommercial(boolean precommercial) {
      this.precommercial = precommercial;
   }
}
