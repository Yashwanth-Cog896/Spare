package com.monsanto.tps.lexicon.person;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: Apr 30, 2008
 * Time: 1:57:33 PM
 */
public class PeopleRecordQuery {
   private NetworkID[] networkIds;
   private PartyID[] partyIds;
   private boolean activeOnly;

   public  PeopleRecordQuery(NetworkID[] networkIds) {
      this(networkIds, false);
   }

   public PeopleRecordQuery(NetworkID[] networkIds, boolean activeOnly) {
      this.networkIds = networkIds;
      this.activeOnly = activeOnly;
   }

   public PeopleRecordQuery(PartyID[] partyIds) {
      this(partyIds, false);
   }

   public PeopleRecordQuery(PartyID[] partyIds, boolean activeOnly) {
      this.partyIds = partyIds;
      this.activeOnly = activeOnly;
   }

   public NetworkID[] getNetworkIds() {
      return networkIds;
   }

   public PartyID[] getPartyIds() {
      return partyIds;
   }

   public boolean activeOnly() {
      return activeOnly;
   }
}
