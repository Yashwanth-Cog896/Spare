package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - May 12, 2008 6:26:40 PM
 */
public class AddressRecord
{
   private String addressId;
   private String addressType; // enum?
   private Address address;

   public String getAddressId() {
      return addressId;
   }

   public void setAddressId(String addressId) {
      this.addressId = addressId;
   }

   public String getAddressType() {
      return addressType;
   }

   public void setAddressType(String addressType) {
      this.addressType = addressType;
   }

   public Address getAddress() {
      return address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }
}
