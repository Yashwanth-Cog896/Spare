package com.monsanto.tps.lexicon.contact;

/**
 * nbwald - Apr 28, 2008 5:30:30 PM
 */
public class Address
{
   private String line1;
   private String line2;
   private String line3;
   private String city;
   private String county;
   private String state;
   private String country;
   private String postalCode;

   public String getCity() {
      return city;
   }

   public void setCity(String city) {
      this.city = city;
   }

   public String getCountry() {
      return country;
   }

   public void setCountry(String country) {
      this.country = country;
   }

   public String getCounty() {
      return county;
   }

   public void setCounty(String county) {
      this.county = county;
   }

   public String getLine1() {
      return line1;
   }

   public void setLine1(String line1) {
      this.line1 = line1;
   }

   public String getLine2() {
      return line2;
   }

   public void setLine2(String line2) {
      this.line2 = line2;
   }

   public String getLine3() {
      return line3;
   }

   public void setLine3(String line3) {
      this.line3 = line3;
   }

   public String getPostalCode() {
      return postalCode;
   }

   public void setPostalCode(String postalCode) {
      this.postalCode = postalCode;
   }

   public String getState() {
      return state;
   }

   public void setState(String state) {
      this.state = state;
   }
}