/*
 PartyID was created on May 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.person;

/**
 * @author GGSHIV  $
 * @version $Revision: 1.1 $
 * @since May 2, 2008 12:35:31 PM
 */
public class PartyID {

   private String partyId;

   public PartyID(String partyId) {
      this.partyId = partyId;
   }

   public String getPartyId() {
      return partyId;
   }
}

/*
* Revision Log
* $Log: not supported by cvs2svn $
*/
