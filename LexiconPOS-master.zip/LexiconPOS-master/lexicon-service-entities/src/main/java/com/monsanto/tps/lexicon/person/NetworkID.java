/*
 NetworkID was created on May 2, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.person;

/**
 * @author GGSHIV  $
 * @version $Revision: 1.1 $
 * @since May 2, 2008 12:33:34 PM
 */
public class NetworkID {

   private String networkId;

   public NetworkID(String networkId) {
      this.networkId = networkId;
   }

   public String getNetworkId() {
      return networkId;
   }
}

/*
* Revision Log
* $Log:
*/
