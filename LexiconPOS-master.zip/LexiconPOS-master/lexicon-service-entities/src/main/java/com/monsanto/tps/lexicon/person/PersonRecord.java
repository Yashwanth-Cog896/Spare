package com.monsanto.tps.lexicon.person;

import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.Email;
import com.monsanto.tps.lexicon.contact.Location;
import com.monsanto.tps.lexicon.contact.Organization;
import com.monsanto.tps.lexicon.contact.PhoneNumber;


/**
 * nbwald - Apr 28, 2008 5:40:37 PM
 */
public class PersonRecord
{
   //private long uniqueID;
   private String uniqueID;
   private Person person;
   private Organization organization;
   private PhoneNumber phoneNumber;
   private PhoneNumber cellNumber;
   private PhoneNumber pager;
   private PhoneNumber fax;
   private Email email;
   private Location location;
   private Address address;

   public Address getAddress() {
      return address;
   }

   public void setAddress(Address address) {
      this.address = address;
   }

   public PhoneNumber getCellNumber() {
      return cellNumber;
   }

   public void setCellNumber(PhoneNumber cellNumber) {
      this.cellNumber = cellNumber;
   }

   public Email getEmail() {
      return email;
   }

   public void setEmail(Email email) {
      this.email = email;
   }

   public PhoneNumber getFax() {
      return fax;
   }

   public void setFax(PhoneNumber fax) {
      this.fax = fax;
   }

   public Location getLocation() {
      return location;
   }

   public void setLocation(Location location) {
      this.location = location;
   }

   public Organization getOrganization() {
      return organization;
   }

   public void setOrganization(Organization organization) {
      this.organization = organization;
   }

   public PhoneNumber getPager() {
      return pager;
   }

   public void setPager(PhoneNumber pager) {
      this.pager = pager;
   }

   public Person getPerson() {
      return person;
   }

   public void setPerson(Person person) {
      this.person = person;
   }

   public PhoneNumber getPhoneNumber() {
      return phoneNumber;
   }

   public void setPhoneNumber(PhoneNumber phoneNumber) {
      this.phoneNumber = phoneNumber;
   }

  /* public long getUniqueID() {
      return uniqueID;
   }

   public void setUniqueID(long uniqueID) {
      this.uniqueID = uniqueID;
   }*/
   public String  getUniqueID() {
      return uniqueID;
   }

   public void setUniqueID(String  uniqueID) {
      this.uniqueID = uniqueID;
   }

}
