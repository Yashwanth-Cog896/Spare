/*
 CropAbbreviationAndScientificNameRequest was created on Jun 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop;

/**
 * @author GGSHIV - Jun 30, 2008 3:01:28 PM
 */
public class CropAbbreviationAndScientificNameRequest {

   private final String[] abbreviations;
   private final String scientificName;

   public CropAbbreviationAndScientificNameRequest(String[] abbreviations, String scientificName) {
      this.abbreviations = abbreviations;
      this.scientificName = scientificName;
   }

   public String[] getAbbreviations() {
      return abbreviations;
   }

   public String getScientificName() {
      return scientificName;
   }

}
