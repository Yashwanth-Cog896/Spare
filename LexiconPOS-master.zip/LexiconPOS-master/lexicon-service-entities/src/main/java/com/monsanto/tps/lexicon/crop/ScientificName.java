/*
 ScientificName was created on Jun 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexicon.crop;

/**
 * @author PNAGAPP - Jun 26, 2008 1:20:03 PM
 */
public class ScientificName {

   private String name;
   private String publicKey;

   public ScientificName(String name, String publicKey) {
      this.name = name;
      this.publicKey = publicKey;
   }

   public String getName() {
      return name;
   }

   public String getPublicKey() {
      return publicKey;
   }
}
