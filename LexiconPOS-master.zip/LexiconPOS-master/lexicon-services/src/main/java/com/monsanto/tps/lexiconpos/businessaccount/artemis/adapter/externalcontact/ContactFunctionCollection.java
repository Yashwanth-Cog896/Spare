package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;


import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactFunction;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactFunctionId;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * nbwald - Aug 1, 2008 2:22:37 PM
 */
public class ContactFunctionCollection
{
   private final Collection<ContactFunction> contactFunctions;

   public ContactFunctionCollection(Collection<ContactFunction> contactFunctions) {
      this.contactFunctions = contactFunctions;
   }

   public String[] getContactTypes() {
      return contactFunctions == null ? new String[0] : getContactTypesFromNonNullContactFunction();
   }

   private String[] getContactTypesFromNonNullContactFunction() {
      List<String> contactTypes = new ArrayList<String>();
      for (ContactFunction contactFunction : contactFunctions) {
         ContactFunctionId contactFunctionId = contactFunction.getId();
         if(contactFunctionId != null) {
            contactTypes.add(contactFunctionId.getFunctionTypeCode());
         }
      }
      return contactTypes.toArray(new String[contactTypes.size()]);
   }
}
