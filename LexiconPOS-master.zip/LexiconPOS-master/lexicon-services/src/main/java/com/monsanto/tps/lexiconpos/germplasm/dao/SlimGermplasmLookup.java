/*
 SlimGermplasmLookup was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.germplasm.OriginRecipricator;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmQueryItem;
import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasmSet;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Jan 29, 2007 4:04:38 PM
 */
public class SlimGermplasmLookup {
   private GermplasmQueryItem queryItem;
   private SlimGermplasmLookupQuerySet querySet;

   public SlimGermplasmLookup(GermplasmQueryItem queryItem, SlimGermplasmLookupQuerySet querySet) {
      this.queryItem = queryItem;
      this.querySet = querySet;
   }

   public SlimGermplasmQueryResults findGermplasms()
      throws WrappingException
   {
      SlimGermplasmSet germplasms = new SlimGermplasmSet();
      germplasms.addAll(findByOrigin());
      germplasms.addAll(findByOriginReciprocal());
      germplasms.addAll(findByLineCode());
      germplasms.addAll(findByPedigree());
      int numGermplasmFromGermplasmCriteria = germplasms.count();
      germplasms.addAll(findByProductPubkey());
      return new SlimGermplasmQueryResults(germplasms.getArray(), numGermplasmFromGermplasmCriteria);
   }

   private SlimGermplasm[] findByOrigin()
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(queryItem.getOrigin()) ? new SlimGermplasm[0] :
         querySet.findByOriginAndCropName(queryItem.getOrigin(), queryItem.getCropName());
   }

   private SlimGermplasm[] findByOriginReciprocal()
      throws WrappingException
   {
      String reciprocal = getReciprocal();
      return StringUtils.isNullOrEmpty(reciprocal) ? new SlimGermplasm[0] :
         querySet.findByOriginAndCropName(reciprocal, queryItem.getCropName());
   }

   private SlimGermplasm[] findByLineCode()
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(queryItem.getLineCode()) ? new SlimGermplasm[0] :
         querySet.findByLineCodeAndCropName(queryItem.getLineCode(), queryItem.getCropName());
   }

   private SlimGermplasm[] findByPedigree()
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(queryItem.getPedigree()) ? new SlimGermplasm[0] :
         querySet.findByPedigreeAndCropName(queryItem.getPedigree(), queryItem.getCropName());
   }

   private SlimGermplasm[] findByProductPubkey()
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(queryItem.getProductPubkey()) ? new SlimGermplasm[0] :
         querySet.findByProductPubkeyAndCropName(queryItem.getProductPubkey(), queryItem.getCropName());
   }

   private String getReciprocal() {
      OriginRecipricator reciprocator = new OriginRecipricator(queryItem.getOrigin());
      return reciprocator.getReciprical();
   }

}