/*
 BFCReleaseSiteSQL was created on Oct 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.site;

/**
 * nbwald Oct 9, 2006 4:36:56 PM
 */
public interface BFCReleaseSiteSQL {
   String SELECT_RELEASE_SITE = "ReleaseSite.Lookup";
   String ALIAS_ACRES = "Acres";
}