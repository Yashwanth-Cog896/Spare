package com.monsanto.tps.lexiconpos.event.deregulated.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatus;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatusImpl;
import com.monsanto.tps.lexiconpos.event.deregulated.DeregulatedEventValidationCondition;
import com.monsanto.tps.lexiconpos.event.deregulated.model.StackApprovalVerificationRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 20, 2006
 * Time: 3:38:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class AgencyApprovalVerification
{
   private final StackApprovalVerificationRequest stackApprovalVerificationRequest;

   public AgencyApprovalVerification(StackApprovalVerificationRequest stackApprovalVerificationRequest) {
      this.stackApprovalVerificationRequest = stackApprovalVerificationRequest;
   }

   public boolean isDeregulated()
      throws WrappingException
   {
      return isStackedStackDeregulated() && areIndividualStacksDeregulated();
   }

   private boolean isStackedStackDeregulated()
      throws WrappingException
   {
      ValidationStatus validationStatus = getStackedStackApprovalValidationStatus();
      return !validationStatus.hasSeverity(ValidationConditionSeverity.ERROR);
   }

   private boolean areIndividualStacksDeregulated()
      throws WrappingException
   {
      ValidationStatus[] validationStatuses = getIndividualStackApprovalValidationStatuses();
      for (int i = 0; i < validationStatuses.length; i ++) {
         if (validationStatuses[i].hasSeverity(ValidationConditionSeverity.ERROR)) {
            return false;
         }
      }
      return true;
   }

   public ValidationStatus getStackedStackApprovalValidationStatus()
      throws WrappingException
   {
      ValidationStatus[] statuses = getStackedStackApprovalValidationStatuses();
      return getSingleStackedStackValidationStatus(statuses);
   }

   public ValidationStatus[] getIndividualStackApprovalValidationStatuses()
      throws WrappingException
   {
      List list = new ArrayList();
      String[] individualStacks = stackApprovalVerificationRequest.getIndividualStacks();
      for (int i = 0; i < individualStacks.length; i++) {
         ValidationStatus status = getValidationStatus(individualStacks[i]);
         list.add(status);
      }
      return (ValidationStatus[])list.toArray(new ValidationStatus[list.size()]);
   }

   private ValidationStatus[] getStackedStackApprovalValidationStatuses()
      throws WrappingException
   {
      List list = new ArrayList();
      String[] stackedStacks = stackApprovalVerificationRequest.getStackedStacks();
      for (int i = 0; i < stackedStacks.length; i++) {
         ValidationStatus status = getValidationStatus(stackedStacks[i]);
         list.add(status);
      }
      return (ValidationStatus[])list.toArray(new ValidationStatus[list.size()]);
   }

   private ValidationStatus getSingleStackedStackValidationStatus(ValidationStatus[] statuses) {
      ValidationStatus status = new ValidationStatusImpl();
      if (isAtleastOneStackDeregulated(statuses)) {
         return status;
      }
      else {
         status.addCondition(getIsNotDeregulatedCondition(), ValidationConditionSeverity.ERROR);
      }
      return status;
   }

   private boolean isAtleastOneStackDeregulated(ValidationStatus[] statuses) {
      for (int i = 0; i < statuses.length; i ++) {
         if (!statuses[i].hasSeverity(ValidationConditionSeverity.ERROR)) {
            return true;
         }
      }
      return false;
   }

   private ValidationStatus getValidationStatus(String stackAbbr)
      throws WrappingException
   {
      AgencyValidationStatus process =
         new AgencyValidationStatus(stackAbbr,
            stackApprovalVerificationRequest.getCropName(),
            stackApprovalVerificationRequest.getCountryPubkey());
      return process.getValidationStatus();
   }

   private DeregulatedEventValidationCondition getIsNotDeregulatedCondition() {
      return new DeregulatedEventValidationCondition(DeregulatedEventValidationCondition.EVENT_NOT_DEREGULATED_CODE);
   }
}
