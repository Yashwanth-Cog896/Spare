package com.monsanto.tps.lexiconpos.db.tempsession.dao.midas;

import com.monsanto.tps.lexiconpos.db.tempsession.domain.midas.TempSessionOcd;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.Collection;

/**
 * RLCASW - Feb 28, 2010 3:13:44 PM
 */
public class TempSessionOcdDaoImpl
   implements TempSessionOcdDao
{
   private final SessionFactory sessionFactory;

   TempSessionOcdDaoImpl(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   @Override
   public void insertText1Values(Long requestId, Collection<String> ids) {
      Session session = sessionFactory.getCurrentSession();
      long sortOrder = 0L;

      for (String id : ids) {
         TempSessionOcd tempSessionOcd = new TempSessionOcd();
         tempSessionOcd.setRequestId(requestId);
         tempSessionOcd.setSortOrder(sortOrder);
         tempSessionOcd.setText1(id);
         tempSessionOcd.setNumber1(0L);
         session.saveOrUpdate(tempSessionOcd);
         sortOrder++;
      }
      session.flush();
   }

   @Override
   public void insertNumber1Values(Long requestId, Collection<Long> ids) {
      Session session = sessionFactory.getCurrentSession();
      long sortOrder = 0L;

      for (Long id : ids) {
         TempSessionOcd tempSessionOcd = new TempSessionOcd();
         tempSessionOcd.setRequestId(requestId);
         tempSessionOcd.setSortOrder(sortOrder);
         tempSessionOcd.setNumber1(id);
         tempSessionOcd.setText1(" ");
         session.saveOrUpdate(tempSessionOcd);
         sortOrder++;
      }
      session.flush();
   }
}
