/*
 StubCountryQuerySet was created on Jun 12, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.query;

import com.monsanto.tps.lexicon.geography.country.Country;

import java.util.Arrays;
import java.util.List;

/**
 * @author GGSHIV - Jun 12, 2008 6:11:59 PM
 */
public class StubCountryQuerySet implements CountryQuerySet {
   public List<Country> findCountriesByISOCodes(String[] countryISOCode) {
      return getList();
   }

   public List<Country> findCountriesByName(String countryName) {
      return getList();
   }

   private List<Country> getList() {
      return Arrays.asList(new Country(), new Country());
   }
}
