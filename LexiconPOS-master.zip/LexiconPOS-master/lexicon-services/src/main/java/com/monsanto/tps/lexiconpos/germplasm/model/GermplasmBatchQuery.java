/*
 BatchQuery was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.model;

/**
 * nbwald Jan 30, 2007 6:10:34 PM
 */
public interface GermplasmBatchQuery {
   int getMaxItems();
   GermplasmQueryItem[] getQueryItems();
}