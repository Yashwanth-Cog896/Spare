/*
 AbstractArtemisServiceAction was created on Nov 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.artemis.action;

import com.monsanto.tcc.artemis.workflow.actions.ProcessAction;
import com.monsanto.tcc.artemis.workflow.process.ProcessContext;
import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;

/**
 * nbwald Nov 6, 2007 1:54:42 PM
 */
public abstract class AbstractArtemisServiceAction
   implements ProcessAction
{
   public void execute(ProcessContext processContext)
      throws Exception
   {
      process((ServiceProcessContext) processContext);
      processContext.fireTransition();
   }

   public abstract void process(ServiceProcessContext context) throws Exception;
}