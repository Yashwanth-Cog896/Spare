package com.monsanto.tps.lexiconpos.db.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.product.common.domain.yieldmart.YieldMartProduct;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 5, 2005
 * Time: 11:18:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class YieldMartProductPSRowImpl
   implements YieldMartProduct
{
   private final int mirageSeedProductID;
   private final long midasProductID;
   private final long midasGeneticMaterialID;
   private final String productName;

   public YieldMartProductPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      mirageSeedProductID = row.getInt(getAlias(YieldMartSQL.ALIAS_SEED_PRODUCT_ID));
      midasGeneticMaterialID = row.getLong(getAlias(YieldMartSQL.ALIAS_GEN_MAT_ID));
      midasProductID = row.getLong(getAlias(YieldMartSQL.ALIAS_MIDAS_PROD_ID));
      productName = row.getString(getAlias(YieldMartSQL.ALIAS_MIRAGE_NAME));
   }

   public int getMirageSeedProductID() {
      return mirageSeedProductID;
   }
   public long getMidasProductID() {
      return midasProductID;
   }
   public long getMidasGeneticMaterialID() {
      return midasGeneticMaterialID;
   }
   public String getProductName() {
      return productName;
   }

   private String getAlias(String aliasPropName)
      throws WrappingException
   {
      return new SQLPropFile(YieldMartSQL.class).getAlias(aliasPropName);
   }
}
