package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.SubCountry;
import com.monsanto.tps.lexiconpos.geography.SubSubCountry;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 2:53:02 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconGeographyLookup
{
    public LexiconCountry[] getCountriesByName(
        String wildcardableName,
        PersistentStoreConnection lexConn)
        throws WrappingException;
    
    public LexiconCountry[] getCountriesByUNCode(
        String unCode)
        throws WrappingException;

    public LexiconCountry[] getCountryByPubKey(
        String pubKey,
        PersistentStoreConnection lexConn)
        throws WrappingException;

    public SubCountry[] getSubCountriesByName(
        long countryID,
        String wildcardableName,
        PersistentStoreConnection midasConn)
        throws WrappingException;
    
    public SubCountry[] getSubCountriesByAbbr(
        long countryID,
        String subCountryAbbr,
        PersistentStoreConnection midasConn)
        throws WrappingException;

    public SubSubCountry[] getSubSubCountriesByName(
        long subCountryID,
        String wildcardableName,
        PersistentStoreConnection midasConn)
        throws WrappingException;
}
