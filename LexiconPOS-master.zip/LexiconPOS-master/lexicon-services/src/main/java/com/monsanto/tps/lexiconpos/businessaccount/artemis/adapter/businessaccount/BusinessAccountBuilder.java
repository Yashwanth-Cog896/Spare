package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctAddr;
import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctPhone;
import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.contact.AddressRecord;

import java.util.Set;

/**
 * Filename: BusinessAccountBuilder.java
 * Last Change: rrchak1 On:	Aug 6, 2008
 *
 * @author: rrchak1
 */
public class BusinessAccountBuilder {
    private final int BUSINESS_PHONE_TYPE = 1;

    public BusinessAccount build(Acct acct) {
        BusinessAccount businessAccount = new BusinessAccount();
        setAllFields(acct, businessAccount);
        return businessAccount;
    }

    private void setAllFields(Acct acct, BusinessAccount businessAccount) {
      setSimpleFields(acct, businessAccount);
      setCollectionFields(acct, businessAccount);
      setPhoneNumberFields(acct.getAcctPhones(),businessAccount);
    }

    private void setPhoneNumberFields(Set<AcctPhone> acctPhones, BusinessAccount businessAccount) {
        PhoneNumberBuilder builder = new PhoneNumberBuilder();
        businessAccount.setPhone(builder.build(getBusinessPhone(acctPhones)));
    }

    private AcctPhone getBusinessPhone(Set<AcctPhone> acctPhones) {
        if(acctPhones!=null && !acctPhones.isEmpty()){
            for (AcctPhone acctPhone : acctPhones) {
                if(BUSINESS_PHONE_TYPE ==acctPhone.getAcctPhoneType().getAcctPhoneTypeId()){
                    return acctPhone;
                }
            }

        }
        return null;
    }

    private void setCollectionFields(Acct acct, BusinessAccount businessAccount) {
        businessAccount.setAddressRecords(extractAddressRecords(acct.getAcctAddrs()));
    }

    private AddressRecord[] extractAddressRecords(Set<AcctAddr> acctAddrs) {
        AcctAddrCollection collection = new AcctAddrCollection(acctAddrs);
        return collection.getAddressRecords();

    }

    private void setSimpleFields(Acct acct, BusinessAccount businessAccount) {
        businessAccount.setAccountID(String.valueOf(acct.getAcctId()));
        businessAccount.setCompanyName(acct.getName1());
    }
}
