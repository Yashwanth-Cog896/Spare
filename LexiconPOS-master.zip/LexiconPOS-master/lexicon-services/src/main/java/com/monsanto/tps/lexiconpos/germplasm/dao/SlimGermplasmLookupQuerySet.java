/*
 SlimGermplasmLookupQuerySet was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 29, 2007 4:08:33 PM
 */
public interface SlimGermplasmLookupQuerySet {

   SlimGermplasm[] findByOriginAndCropName(String origin, String cropName)
      throws WrappingException;

   SlimGermplasm[] findByLineCodeAndCropName(String lineCode, String cropName)
      throws WrappingException;

   SlimGermplasm[] findByProductPubkeyAndCropName(String productPubkey, String cropName)
      throws WrappingException;

   SlimGermplasm[] findByPedigreeAndCropName(String lineCode, String cropName)
       throws WrappingException;
}