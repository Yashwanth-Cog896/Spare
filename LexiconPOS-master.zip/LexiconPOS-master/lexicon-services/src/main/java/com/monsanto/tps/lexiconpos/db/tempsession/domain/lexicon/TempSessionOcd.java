package com.monsanto.tps.lexiconpos.db.tempsession.domain.lexicon;

import java.io.Serializable;

/**
 * RLCASW - Feb 28, 2010 10:59:55 AM
 */
public class TempSessionOcd
   implements Serializable
{
   private Long requestId;
   private String text1;
   private Long sortOrder;
   private Long number1;
   public static final int THIRTY_ONE = 31;
   public static final int ZERO = 0;

   public Long getRequestId() {
      return requestId;
   }

   public void setRequestId(Long requestId) {
      this.requestId = requestId;
   }

   public String getText1() {
      return text1;
   }

   public void setText1(String text1) {
      this.text1 = text1;
   }

   public Long getNumber1() {
      return number1;
   }

   public void setNumber1(Long number1) {
      this.number1 = number1;
   }

   public Long getSortOrder() {
      return sortOrder;
   }

   public void setSortOrder(Long sortOrder) {
      this.sortOrder = sortOrder;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (!(o instanceof TempSessionOcd)) {
         return false;
      }

      TempSessionOcd that = (TempSessionOcd) o;

      return tempSessionOcdEquals(that);
   }

   private boolean tempSessionOcdEquals(TempSessionOcd that) {
      if (requestId != null ? !requestId.equals(that.requestId) : that.requestId != null) {
         return false;
      }
      if (sortOrder != null ? !sortOrder.equals(that.sortOrder) : that.sortOrder != null) {
         return false;
      }
      if (text1 != null ? !text1.equals(that.text1) : that.text1 != null) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result = requestId != null ? requestId.hashCode() : ZERO;
      result = THIRTY_ONE * result + (text1 != null ? text1.hashCode() : ZERO);
      result = THIRTY_ONE * result + (sortOrder != null ? sortOrder.hashCode() : ZERO);
      return result;
   }
}