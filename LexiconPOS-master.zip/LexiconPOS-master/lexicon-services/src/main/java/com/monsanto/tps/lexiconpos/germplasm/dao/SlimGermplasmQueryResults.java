package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;

/**
 * nbwald - Feb 24, 2009 3:39:45 PM
 */
public class SlimGermplasmQueryResults
{
   private SlimGermplasm[] slimGermplasms;
   private int numGermplasmFromGermplasmCriteria;

   public SlimGermplasmQueryResults(SlimGermplasm[] slimGermplasms, int numGermplasmFromGermplasmCriteria) {
      this.slimGermplasms = slimGermplasms;
      this.numGermplasmFromGermplasmCriteria = numGermplasmFromGermplasmCriteria;
   }

   public SlimGermplasm[] getGermplasms() {
      return slimGermplasms;
   }

   public int numGermplasmFromGermplasmCriteria() {
      return numGermplasmFromGermplasmCriteria;
   }
}
