/*
 FindCropsByPublicKeysAction was created on Jun 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet;
import com.monsanto.tps.lexicon.crop.Crop;

import java.util.List;

/**
 * @author GGSHIV - Jun 26, 2008 4:10:58 PM
 */
public class FindCropsByBayerCodesAction extends AbstractArtemisServiceAction {

   private final CropQuerySet cropQuerySet;

   public FindCropsByBayerCodesAction(CropQuerySet cropQuerySet) {
      this.cropQuerySet = cropQuerySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      String[] bayerCodes = (String[]) context.getRequestPayload();
      List<Crop> crops = cropQuerySet.findByBayerCodes(bayerCodes);
      new MultipleResultResponse(crops).saveResponse(context);
   }
}