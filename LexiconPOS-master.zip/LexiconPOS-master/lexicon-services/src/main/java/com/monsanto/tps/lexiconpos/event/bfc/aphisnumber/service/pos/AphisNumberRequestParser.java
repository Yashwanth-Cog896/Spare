package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 12:32:41 PM
 */
public class AphisNumberRequestParser
   implements AphisNumberSchemaConstants
{
   private final Document requestDoc;

   public AphisNumberRequestParser(Document requestDoc)
   {
      this.requestDoc = requestDoc;
   }

   public AphisNumberRequestModel parse()
   {
      Element docElement = requestDoc.getDocumentElement();
      String transCode = getTransCode(docElement);
      return new AphisNumberRequestModel(transCode);
   }

   private String getTransCode(Element docElement)
   {
      String name = DOMUtil.getChildValue(docElement, REQUESTED_TRANSCODE);
      return name.toUpperCase();
   }
}
