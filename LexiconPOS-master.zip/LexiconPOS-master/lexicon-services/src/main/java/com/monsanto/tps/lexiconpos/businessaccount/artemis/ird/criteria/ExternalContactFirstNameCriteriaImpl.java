package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    ExternalContactFirstNameCriteriaImpl.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class ExternalContactFirstNameCriteriaImpl
    implements QueryCriteria
{
    private String firstName;

    public ExternalContactFirstNameCriteriaImpl(String firstName) {
        this.firstName = firstName;
    }

    public Criterion getCriterion() {
        return Restrictions.like(BusinessAccountSchemaConstants.CONTACT_NAME1, convertWildCards(firstName.toUpperCase()));
    }

    public boolean hasCriteria() {
        return StringUtils.isNotEmpty(firstName);
    }
    
    private String convertWildCards(String attribute) {
        return new StdWildcardableCriteria(attribute).oracleVersion();
    }
}
