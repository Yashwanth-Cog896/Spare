/*
 GermplasmsByCropNameAndOriginQuery was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

import java.util.List;

/**
 * nbwald Jan 29, 2007 12:32:05 PM
 */
public class SlimGermplasmsByCropNameAndOriginQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String origin;
   private final String cropName;

   public SlimGermplasmsByCropNameAndOriginQuery(String origin, String cropName) {
      this.origin = origin;
      this.cropName = cropName;
   }

   public SlimGermplasm[] getGermplasms()
      throws WrappingException
   {
      List slimGermplasms = getList();
      return (SlimGermplasm[]) slimGermplasms.toArray(new SlimGermplasm[slimGermplasms.size()]);
   }

   public SlimGermplasm[] getGermplasms(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      List slimGermplasms = getList(midasConn);
      return (SlimGermplasm[]) slimGermplasms.toArray(new SlimGermplasm[slimGermplasms.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new SlimGermplasmPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_SLIM_GPS_BY_CROP_AND_ORIGIN);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { origin, cropName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

}