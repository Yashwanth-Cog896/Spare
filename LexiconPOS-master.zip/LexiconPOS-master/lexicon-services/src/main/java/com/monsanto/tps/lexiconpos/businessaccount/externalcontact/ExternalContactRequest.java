package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 3:26:42 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ExternalContactRequest
{
   String getContactType();
   String getLastName();
   String getFirstName();
   String getCompany();
}
