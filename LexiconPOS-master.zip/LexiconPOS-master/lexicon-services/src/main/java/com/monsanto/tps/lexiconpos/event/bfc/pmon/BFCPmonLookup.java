package com.monsanto.tps.lexiconpos.event.bfc.pmon;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Sep 27, 2006
 * Time: 9:56:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class BFCPmonLookup
   implements BFCPmonLookupSQL
{
   private final SQLPropFile sqlPropFile = new SQLPropFile(BFCPmonLookupSQL.class);

   public String[] getPmons(String monsantoId, PersistentStoreConnection bfcConnection)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(SELECT_PMON_BY_MONSANTO_ID);
      PersistentStoreStatement stmt = bfcConnection.prepareStatement(sql);
      try {
         stmt.setParam(1, monsantoId);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         return buildPmons(iter);
      }
      finally {
         stmt.close();
      }
   }

   private String[] buildPmons(PersistentStoreResultSetFwdIterator iter)
      throws WrappingException
   {
      Set pmons = new HashSet();
      while(iter.next()) {
         String pmon = iter.getString(sqlPropFile.getAlias(ALIAS_PMON));
         pmons.add(pmon.toUpperCase());
      }
      return (String[])pmons.toArray(new String[pmons.size()]);
   }
}
