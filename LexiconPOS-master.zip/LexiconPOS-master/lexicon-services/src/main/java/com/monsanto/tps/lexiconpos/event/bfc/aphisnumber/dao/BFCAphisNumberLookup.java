package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.dao;

import com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos.AphisNumberDatum;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Mar 7, 2006
 * Time: 2:26:50 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BFCAphisNumberLookup
{
   AphisNumberDatum[] getAphisNumberData(
      String transCode,
      PersistentStoreConnection bfcConn)
      throws WrappingException;
}
