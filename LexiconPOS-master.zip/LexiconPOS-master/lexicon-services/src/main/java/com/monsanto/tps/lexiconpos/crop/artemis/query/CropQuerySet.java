package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.CropPublicKeyType;

import java.util.List;

/**
 * @Author: PNAGAPP - Jun 25, 2008 4:03:54 PM
 */
public interface CropQuerySet {

   SQLPropFile CROP_SQL_PROPERTY_FILE = new SQLPropFile(CropSQL.class);

   List<Crop> findByBayerCodes(String[] bayerCodes) throws Exception;

   List<Crop> findByAbbreviationsAndScientificName(String[] cropAbbreviations, String scientificName) throws Exception;

   List<Crop> findByPublicKeysAndScientificName(String[] publicKeys, String scientificName, CropPublicKeyType publicKeyType) throws Exception;

   List<Crop> findByNameAndScientificName(String cropName, String scientificName) throws Exception;
}
