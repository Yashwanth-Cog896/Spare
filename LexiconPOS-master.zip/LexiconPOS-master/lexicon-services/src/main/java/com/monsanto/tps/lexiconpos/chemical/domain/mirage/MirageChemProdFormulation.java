package com.monsanto.tps.lexiconpos.chemical.domain.mirage;

import com.monsanto.tps.lexiconpos.chemical.service.pos.ChemicalMaterialSchemaConstants;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 22, 2005
 * Time: 12:18:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageChemProdFormulation
    extends MirageChemProdImpl
{
    public String getMaterialClassification() {
        return ChemicalMaterialSchemaConstants.FORMULATION_ELEM_NAME;
    }
}
