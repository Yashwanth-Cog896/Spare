package com.monsanto.tps.lexiconpos.db;

import com.monsanto.tcc.lexiconcommon.db.factories.PersistentStoreConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactory;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactory;
import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactory;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 14, 2004
 * Time: 1:17:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class TPSPersistentStoreConnection
   extends MultiSystemPlusLexAuditorPSConnection
{
   public static final String MIDAS_CONN = "Midas";
   public static final String MIRAGE_CONN = "Mirage";
//   public static final String YLDMAR_CONN = "YieldMart";
//   public static final String FBS_COMMON_CONN = "FBSCommon";
//   public static final String VIRGO_CONN = "Virgo";
   public static final String BFC_CONN = "BFC";

   protected Map getFactoryMap() {
      HashMap map = new HashMap(4);
      map.put(MIDAS_CONN, getMidasConnectionFactory());
      map.put(MIRAGE_CONN, getMirageConnectionFactory());
//      map.put(YLDMAR_CONN, new YieldMartConnectionFactory());
//      map.put(FBS_COMMON_CONN, new FBSCommonConnectionFactory());
//      map.put(VIRGO_CONN, new VirgoConnectionFactory());
      map.put(BFC_CONN, getBFCConnectionFactory());
      map.put(LEX_CONN, getLexiconConnectionFactory());
      return map;
   }
   protected PersistentStoreConnectionFactory getLexiconConnectionFactory() {
      return new LexiconConnectionFactory();
   }
   protected PersistentStoreConnectionFactory getMidasConnectionFactory() {
      return new MidasConnectionFactory();
   }
   protected PersistentStoreConnectionFactory getMirageConnectionFactory() {
      return new MirageConnectionFactory();
   }
   protected PersistentStoreConnectionFactory getBFCConnectionFactory() {
      return new BFCConnectionFactory();
   }

   public PersistentStoreConnection getMidasConnection() throws WrappingException {
      return getConnection(MIDAS_CONN);
   }

   public PersistentStoreConnection getMirageConnection() throws WrappingException {
      return getConnection(MIRAGE_CONN);
   }

   public PersistentStoreConnection getYieldMartConnection() throws WrappingException {
      return getConnection(MIDAS_CONN);
   }

   public PersistentStoreConnection getFBSCommonConnection() throws WrappingException {
      return getConnection(MIDAS_CONN);
   }

   public PersistentStoreConnection getVirgoConnection() throws WrappingException {
      return getConnection(MIRAGE_CONN);
   }

   public PersistentStoreConnection getBFCConnection() throws WrappingException {
      return getConnection(BFC_CONN);
   }
}
