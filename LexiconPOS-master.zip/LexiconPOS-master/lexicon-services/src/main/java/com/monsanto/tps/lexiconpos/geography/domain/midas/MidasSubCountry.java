package com.monsanto.tps.lexiconpos.geography.domain.midas;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 30, 2006
 * Time: 3:24:18 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasSubCountry {
   String getSubCountryKey();
   String getSubCountryName();
   String getSubCountryAbbr();
   String getCountryKey();
}
