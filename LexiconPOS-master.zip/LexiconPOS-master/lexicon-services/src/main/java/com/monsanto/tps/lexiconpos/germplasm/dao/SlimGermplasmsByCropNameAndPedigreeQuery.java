/*
 GermplasmsByCropNameAndLineCodeQuery was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;

import java.util.List;

/**
 * nbwald Jan 29, 2007 2:38:20 PM
 */
public class SlimGermplasmsByCropNameAndPedigreeQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String pedigree;
   private final String cropName;

   public SlimGermplasmsByCropNameAndPedigreeQuery(String pedigree, String cropName) {
      this.pedigree = pedigree;
      this.cropName = cropName;
   }

   public SlimGermplasm[] getGermplasms()
      throws WrappingException
   {
      List germplasms = getList();
      return (SlimGermplasm[]) germplasms.toArray(new SlimGermplasm[germplasms.size()]);
   }

   public SlimGermplasm[] getGermplasms(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      List germplasms = getList(midasConn);
      return (SlimGermplasm[]) germplasms.toArray(new SlimGermplasm[germplasms.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new SlimGermplasmPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_SLIM_GPS_BY_CROP_AND_PEDIGREE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] {pedigree, cropName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

}