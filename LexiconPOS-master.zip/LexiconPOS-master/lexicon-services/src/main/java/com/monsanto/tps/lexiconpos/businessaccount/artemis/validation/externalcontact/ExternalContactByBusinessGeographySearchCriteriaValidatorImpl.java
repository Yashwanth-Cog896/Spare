package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tcc.lexiconcommon.validation.validator.SingleResultValidator;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.FieldIsNotWildcardableRule;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.FieldIsNotFullyWildcardedRule;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    ExternalContactByBusinessGeographySearchCriteriaValidator.java
 * Last Change: rrchak1 On:	Jul 29, 2008
 *
 * @author: rrchak1
 */
public class ExternalContactByBusinessGeographySearchCriteriaValidatorImpl implements ExternalContactByBusinessGeographySearchCriteriaValidator {
    public void validate(ExternalContactByBusinessGeographySearchCriteria searchCriteria) {
        SingleResultValidator<String> validator = new SingleResultValidator<String>(getRules(searchCriteria), null);
        String violation = validator.validate();
        if(violation != null) {
           throw new IllegalArgumentException(violation);
        }
    }


   private List<? extends Rule<String>> getRules(ExternalContactByBusinessGeographySearchCriteria businessGeographySearchCriteria) {
       ExternalContactSearchCriteria criteria = businessGeographySearchCriteria.getExternalContactSearchCriteria();
      List<Rule<String>> rules = new ArrayList<Rule<String>>();
      rules.add(new ExternalContactByBusinessLocationRequiredFieldsRule(criteria));
      rules.add(new FieldIsNotWildcardableRule("Contact type", criteria.getContactType()));
      rules.add(new FieldIsNotFullyWildcardedRule("Company", criteria.getCompanyName()));
      rules.add(new FieldIsNotFullyWildcardedRule("Last name", criteria.getLastName()));
      rules.add(new FieldIsNotFullyWildcardedRule("First name", criteria.getFirstName()));
      addLocationSpecificRules(rules, criteria.getLocation());
      return rules;
   }

   private void addLocationSpecificRules(List<Rule<String>> rules, SearchableLocation searchableLocation) {
       if(searchableLocation != null){
           rules.add(new FieldIsNotWildcardableRule("Country", searchableLocation.getCountryName()));
           rules.add(new FieldIsNotWildcardableRule("Sub-country", searchableLocation.getSubcountryCode()));
           rules.add(new FieldIsNotFullyWildcardedRule("Sub-sub-country", searchableLocation.getSubsubcountryName()));
           rules.add(new FieldIsNotFullyWildcardedRule("City", searchableLocation.getCity()));
       }
   }
}
