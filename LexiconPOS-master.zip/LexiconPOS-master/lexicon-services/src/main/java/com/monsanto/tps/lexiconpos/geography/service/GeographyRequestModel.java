package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 10:57:46 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GeographyRequestModel
{
    String getCountryName();
    String getCountryAbbr();
    String getCountryPubkey();
    String getSubCountryName();
    String getSubCountryAbbr();
    String getSubCountryPubkey();
    String getSubSubCountryName();
}
