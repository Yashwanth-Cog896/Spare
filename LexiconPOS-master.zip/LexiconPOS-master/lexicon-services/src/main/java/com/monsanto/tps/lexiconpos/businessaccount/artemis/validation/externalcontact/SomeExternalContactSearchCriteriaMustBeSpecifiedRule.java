package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * nbwald - Jun 8, 2008 11:55:30 AM
 */
public class SomeExternalContactSearchCriteriaMustBeSpecifiedRule
   implements Rule<String>
{
   private final ExternalContactSearchCriteria criteria;

   public SomeExternalContactSearchCriteriaMustBeSpecifiedRule(ExternalContactSearchCriteria criteria) {
      this.criteria = criteria;
   }

   public boolean violated() {
      return criteria.getCompanyName() == null
         && criteria.getContactType() == null
         && criteria.getFirstName() == null
         && criteria.getLastName() == null
         && noLocationCriteriaSpecified();
   }

   private boolean noLocationCriteriaSpecified() {
      SearchableLocation location = criteria.getLocation();
      return location == null ||
         (location.getCity() == null
            && location.getSubsubcountryName() == null
            && location.getSubcountryCode() == null
            && location.getCountryName() == null);
   }

   public String getViolation() {
      return "Must specify some criteria.";
   }
}
