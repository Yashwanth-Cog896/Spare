/*
 ReleaseSiteLookup was created on Oct 9, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.ReleaseSite;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Oct 9, 2006 4:06:40 PM
 */
public class ReleaseSiteLookup
   extends AbstractPersistentStoreSingleResultQuery
{
   private final long permitID;
   private final long siteID;
   private final long personID;
   private final long releaseSiteID;

   public ReleaseSiteLookup(long permitID, long siteID, long personID, long releaseSiteID) {
      this.permitID = permitID;
      this.siteID = siteID;
      this.personID = personID;
      this.releaseSiteID = releaseSiteID;
   }

   public ReleaseSite getReleaseSite(PersistentStoreConnection bfcConn)
      throws WrappingException
   {
      return (ReleaseSite)execute(bfcConn);
   }

   protected String getSQL()
      throws WrappingException
   {
      return getSQLPropFile().getSQL(BFCReleaseSiteSQL.SELECT_RELEASE_SITE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(permitID), new Long(siteID), new Long(personID), new Long(releaseSiteID) };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new ReleaseSitePSRowImpl(row);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(BFCReleaseSiteSQL.class);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new BFCConnectionFactoryProperties();
   }
}