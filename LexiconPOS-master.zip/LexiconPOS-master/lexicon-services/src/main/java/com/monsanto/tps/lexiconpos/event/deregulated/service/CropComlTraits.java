package com.monsanto.tps.lexiconpos.event.deregulated.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait.ComlTraitNotFoundException;
import com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait.CropComlTraitByEventQuery;
import com.monsanto.tps.lexiconpos.event.deregulated.model.CropComlTrait;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 10, 2006
 * Time: 11:26:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class CropComlTraits
{
   private String cropName;
   private final List cropComlTraits = new ArrayList();

   public CropComlTraits(String[] events)
      throws WrappingException, ComlTraitNotFoundException
   {
      init(events);
   }

   public void validateSameCrop()
      throws WrappingException, CropMismatchException
   {
      Set crops = new HashSet();
      for (Iterator iter = cropComlTraits.iterator(); iter.hasNext();) {
         crops.add(((CropComlTrait)iter.next()).getCropName());
      }
      if (crops.size() > 1) {
         throw new CropMismatchException();
      }
   }

   public String getCropName() {
      return cropName;
   }

   public String[] getComlTraitNames() {
      List comlTraitNames = new ArrayList();
      for (Iterator iter = cropComlTraits.iterator(); iter.hasNext();) {
         comlTraitNames.add(((CropComlTrait)iter.next()).getComlTraitName());
      }
      return (String[]) comlTraitNames.toArray(new String[comlTraitNames.size()]);
   }

   protected void init(String[] events)
      throws WrappingException, ComlTraitNotFoundException
   {
      for (int i = 0; i < events.length; i ++) {
         CropComlTraitByEventQuery query = new CropComlTraitByEventQuery(events[i]);
         CropComlTrait cropComlTrait = query.getCropComlTrait();
         setCropName(cropComlTrait);
         cropComlTraits.add(cropComlTrait);
      }
   }

   private void setCropName(CropComlTrait cropComlTrait) {
      if (cropComlTrait != null) {
         cropName = cropComlTrait.getCropName();
      }
   }

    public List getCropComlTraits() {
        return cropComlTraits;
    }
}
