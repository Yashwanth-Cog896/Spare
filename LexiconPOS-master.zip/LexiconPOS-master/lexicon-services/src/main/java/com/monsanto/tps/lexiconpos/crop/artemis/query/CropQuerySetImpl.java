/*
 CropQuerySetImpl was created on Jun 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.CropPublicKeyType;

import java.util.List;

/**
 * @author PNAGAPP - Jun 25, 2008 4:14:49 PM
 */
public class CropQuerySetImpl implements CropQuerySet {

   public List<Crop> findByBayerCodes(String[] bayerCodes) throws Exception {
      return getDesegregatedCrops(new CropsByBayerCodesQuery(bayerCodes).find());
   }

   public List<Crop> findByAbbreviationsAndScientificName(String[] cropAbbreviations, String scientificName) throws Exception {
      return getDesegregatedCrops(new CropsByAbbreviationsAndScientificNameQuery(cropAbbreviations, new StdWildcardableCriteria(scientificName)).find());
   }

   public List<Crop> findByPublicKeysAndScientificName(String[] publicKeys, String scientificName, CropPublicKeyType publicKeyType) throws Exception {
      return getDesegregatedCrops(new CropsByPubkeysAndScientificNameQuery(publicKeys, new StdWildcardableCriteria(scientificName), publicKeyType).find());
   }

   public List<Crop> findByNameAndScientificName(String cropName, String scientificName) throws Exception {
      return getDesegregatedCrops(new CropsByNameAndScientificNameQuery(new StdWildcardableCriteria(cropName), new StdWildcardableCriteria(scientificName)).find());
   }

   private List<Crop> getDesegregatedCrops(List<SegregateCrop> segregateCrops) {
      return new CropDesegregator(segregateCrops).desegregate();
   }

}
