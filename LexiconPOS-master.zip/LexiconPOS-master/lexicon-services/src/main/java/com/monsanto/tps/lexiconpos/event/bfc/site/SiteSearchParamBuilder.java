package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSiteSearchRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: Oct 11, 2010
 * Time: 2:14:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class SiteSearchParamBuilder {

    private final BFCSiteSearchRequest siteSearchRequest;

    public SiteSearchParamBuilder(BFCSiteSearchRequest siteSearchRequest) {
       this.siteSearchRequest = siteSearchRequest;
    }
    public Object[] getParams()
       throws WrappingException
    {
       ArrayList params = new ArrayList();
       params.addAll(setFarmNameParams());
       params.addAll(setAddressParams());
       params.addAll(setCityParams());
       params.addAll(setIslandTownshipParams());
       params.addAll(setSubSubCountryParams());
       params.addAll(setSubCountryParams());
       params.addAll(setCountryParams());
       params.addAll(setPostalCodeParams());
       return params.toArray(new String[params.size()]);
    }

    private List setFarmNameParams() {
       return getParams(siteSearchRequest.getFarmNames());
    }

    private List setAddressParams() {
       return getParams(siteSearchRequest.getFullAddresses());
    }

    private List setCityParams() {
       return getParams(siteSearchRequest.getCityNames());
    }

    private List setIslandTownshipParams() {
       return getParams(siteSearchRequest.getIslandTownshipNames());
    }

    private List setSubSubCountryParams() throws WrappingException {
       return getParams(siteSearchRequest.getSubSubCountryNames());
    }

    private List setSubCountryParams() throws WrappingException {
       return getParams(siteSearchRequest.getSubCountryAbbrs());
    }

    private List setCountryParams() {
       return getParams(siteSearchRequest.getCountryAbbrs());
    }

    private List setPostalCodeParams()  {
       return getParams(siteSearchRequest.getPostalCodes());
    }

    private List getParams(String[] values) {
       ArrayList params = new ArrayList();
       for (int i = 0; values != null && i < values.length; i ++) {
          params.add(getToUpperWildcardableValue(values[i]));
       }
       return params;
    }

    private String getToUpperWildcardableValue(String value) {
       StdWildcardableCriteria criteria = new StdWildcardableCriteria(StringUtils.toUpperCaseNull(value));
       return criteria.oracleVersion();
    }    
}
