/*
 ComplianceSiteLookup was created on Sep 28, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.ComplianceSite;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Sep 28, 2006 9:33:20 AM
 */
public class ComplianceSiteLookup
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String monsantoID;
   private final long siteID;

   public ComplianceSiteLookup(String monsantoID, long siteID) {
      this.monsantoID = monsantoID;
      this.siteID = siteID;
   }

   public ComplianceSite getComplianceSite(PersistentStoreConnection bfcConnection)
      throws WrappingException
   {
      return (ComplianceSite) execute(bfcConnection);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { monsantoID, new Long(siteID) };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new ComplianceSitePSRowImpl(row);
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(BFCComplianceSiteSQL.class).getSQL(BFCComplianceSiteSQL.SELECT_COMPLIANCESITE);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new BFCConnectionFactoryProperties();
   }
}