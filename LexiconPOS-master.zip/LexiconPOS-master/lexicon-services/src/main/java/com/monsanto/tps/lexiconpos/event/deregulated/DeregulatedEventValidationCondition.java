package com.monsanto.tps.lexiconpos.event.deregulated;

import com.monsanto.tcc.lexiconcommon.validation.StringTableBasedValidationCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 20, 2006
 * Time: 3:56:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeregulatedEventValidationCondition
   extends StringTableBasedValidationCondition
{
   public static final ValidationConditionCode EVENT_NOT_DEREGULATED_CODE = new ValidationConditionCode("EventNotDeregulated");

   public DeregulatedEventValidationCondition(ValidationConditionCode code) {
      super(new DeregulatedEventStringTable(), code);
   }
}
