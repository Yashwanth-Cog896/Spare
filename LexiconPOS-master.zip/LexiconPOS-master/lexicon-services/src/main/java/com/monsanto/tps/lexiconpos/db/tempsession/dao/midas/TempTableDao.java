package com.monsanto.tps.lexiconpos.db.tempsession.dao.midas;

import java.util.Collection;


public interface TempTableDao {
    long insertIdsIntoTempTable(Long requestId,Collection<Long> numbers);
}
