package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmSingleQuery;
import com.monsanto.tps.lexiconpos.product.common.domain.collections.GermplasmCollection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 24, 2007
 * Time: 8:41:13 AM
 */
public class GermplasmByOriginLineCodeProductPubkeyLookup
{
   private final GermplasmByOriginLineCodePedigreeProductPubkeyQuerySet querySet;

   public GermplasmByOriginLineCodeProductPubkeyLookup(GermplasmByOriginLineCodePedigreeProductPubkeyQuerySet querySet) {
      this.querySet = querySet;
   }

   public GermplasmQueryResults getMatchingGermplasm(GermplasmSingleQuery request)
      throws WrappingException
   {
      GermplasmCollection germplasms = new GermplasmCollection(new Germplasm[0]);

      germplasms.addGermplasms(queryByLineCode(request.getLineCode(), request.getCropName()));
      germplasms.addGermplasms(queryByOrigin(request.getOrigin(), request.getCropName()));
      germplasms.addGermplasms(queryByOriginReciprocals(request.getOriginReciprocal(), request.getCropName()));
      germplasms.addGermplasms(queryByPedigree(request.getPedigree(),request.getCropName()));
      int countFromGermplasmCriteria = germplasms.numGermplasm();
      germplasms.addGermplasms(productPubkeyGermplasms(request.getProductPubkey(), request.getCropName()));

      return new GermplasmQueryResults(germplasms, countFromGermplasmCriteria);
   }

   private Germplasm[] queryByPedigree(String pedigree, String cropName)
      throws WrappingException
   {
       return StringUtils.isNullOrEmpty(pedigree) ?
         new Germplasm[0] : querySet.getGermplasmsByCropNameAndPedigree(pedigree, cropName);
   }

   private Germplasm[] queryByLineCode(String lineCode, String cropName)
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(lineCode) ?
         new Germplasm[0] : querySet.getGermplasmsByCropNameAndLineCode(lineCode, cropName);
   }

   private Germplasm[] queryByOrigin(String origin, String cropName)
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(origin) ?
         new Germplasm[0] : querySet.getGermplasmsByCropNameAndOrigin(origin, cropName);
   }

   private Germplasm[] queryByOriginReciprocals(String originReciprocal, String cropName)
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(originReciprocal) ?
         new Germplasm[0] : querySet.getGermplasmsByCropNameAndOrigin(originReciprocal, cropName);
   }

   private Germplasm[] productPubkeyGermplasms(String productPubkey, String cropName)
      throws WrappingException
   {
      return StringUtils.isNullOrEmpty(productPubkey) ?
         new Germplasm[0] : querySet.getGermplasmsByCropNameAndLexProdPubkey(productPubkey, cropName);
   }
}