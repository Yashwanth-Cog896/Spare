package com.monsanto.tps.lexiconpos.db.factories.virgo;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 9, 2005
 * Time: 12:44:45 PM
 */
public class VirgoConnectionFactory
   extends BasicConnectionFactory
{
   public VirgoConnectionFactory() {
      super(new VirgoConnectionFactoryProperties());
   }
}