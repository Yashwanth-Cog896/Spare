/*
 QueryGermplasmRenderer was created on Jan 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.tps.lexiconpos.germplasm.model.ProductGermplasmWithSources;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * nbwald Jan 19, 2007 1:55:49 PM
 */
public class QueryGermplasmRenderer {
   private final Element parent;
   private final ProductGermplasmWithSources productGermplasmWithSources;

   public QueryGermplasmRenderer(Element parent, ProductGermplasmWithSources productGermplasmWithSources) {
      this.parent = parent;
      this.productGermplasmWithSources = productGermplasmWithSources;
   }

   public void render() {
      Element germplasmElem = renderGermplasmElem();
      renderGermplasmID(germplasmElem);
      renderGermplasmFields(germplasmElem);
   }

   private void renderGermplasmFields(Element germplasmElem) {
      renderCrop(germplasmElem);
      renderOrigin(germplasmElem);
      renderLineCode(germplasmElem);
      renderLineType(germplasmElem);
      renderOwnerProgRefID(germplasmElem);
      renderSources(germplasmElem);
      renderPedigree(germplasmElem);
      renderEvents(germplasmElem);
      renderRelativeMaturity(germplasmElem);
      renderProductPubkey(germplasmElem);
      renderIsPreferred(germplasmElem);
      renderIsFinished(germplasmElem);
   }

   private void renderIsFinished(Element germplasmElem) {
      renderField(germplasmElem, GermplasmDocTags.IS_FINISHED_ELEM_NAME, Boolean.toString(productGermplasmWithSources.isFinished()));
   }

   private void renderIsPreferred(Element germplasmElem) {
      if(productGermplasmWithSources.getLexProdPubkey()!=null){
          renderField(germplasmElem, GermplasmDocTags.IS_PREFERRED_ELEM_NAME, Boolean.toString(productGermplasmWithSources.isPreferred()));
      }
   }
   private void renderProductPubkey(Element germplasmElem) {
      renderOptionalField(germplasmElem, GermplasmDocTags.PRODUCT_PUBKEY_ELEM_NAME, productGermplasmWithSources.getLexProdPubkey());
   }

   private void renderRelativeMaturity(Element germplasmElem) {
      String relativeMaturity = productGermplasmWithSources.getRelativeMaturity() == null ? null : productGermplasmWithSources.getRelativeMaturity().toString();
      renderOptionalField(germplasmElem, GermplasmDocTags.REL_MAT_ELEM_NAME, relativeMaturity);
   }

   private void renderEvents(Element germplasmElem) {
      renderOptionalField(germplasmElem, GermplasmDocTags.EVENTS_ELEM_NAME, productGermplasmWithSources.getEventDisplay());
   }

   private void renderPedigree(Element germplasmElem) {
      renderOptionalField(germplasmElem, GermplasmDocTags.PEDIGREE_ELEM_NAME, productGermplasmWithSources.getPedigree());
   }

   private void renderSources(Element germplasmElem) {
      Element sourcesElem = DOMUtil.addChildElementWithNS(GermplasmDocTags.NS_URI, germplasmElem, GermplasmDocTags.SOURCES_ELEM_NAME);
      renderSourceList(sourcesElem, productGermplasmWithSources.getSources());
   }

   private void renderSourceList(Element sourcesElem, String[] sources) {
      for (int i = 0; i < sources.length; i++) {
         renderSource(sourcesElem, sources[i]);
      }
   }

   private void renderSource(Element sourcesElem, String source) {
      DOMUtil.addChildElementWithNS(GermplasmDocTags.NS_URI, sourcesElem, GermplasmDocTags.SOURCE_ELEM_NAME, source);
   }

   private void renderOwnerProgRefID(Element germplasmElem) {
      renderField(germplasmElem, GermplasmDocTags.OWNER_PROG_ELEM_NAME, productGermplasmWithSources.getOwnerProgRefID());
   }

   private void renderLineType(Element germplasmElem) {
      renderField(germplasmElem, GermplasmDocTags.LINE_TYPE_ELEM_NAME, productGermplasmWithSources.getLineType());
   }

   private void renderLineCode(Element germplasmElem) {
      renderOptionalField(germplasmElem, GermplasmDocTags.LINE_CODE_ELEM_NAME, productGermplasmWithSources.getLineCode());
   }

   private void renderOrigin(Element germplasmElem) {
      renderOptionalField(germplasmElem, GermplasmDocTags.ORIGIN_ELEM_NAME, productGermplasmWithSources.getOrigin());
   }

   private void renderCrop(Element germplasmElem) {
      renderField(germplasmElem, GermplasmDocTags.CROP_NAME_ELEM_NAME, productGermplasmWithSources.getCropName());
   }

   private Element renderGermplasmElem() {
      return DOMUtil.addChildElementWithNS(GermplasmDocTags.NS_URI, parent, GermplasmDocTags.GERMPLASM_ELEM_NAME);
   }

   private void renderGermplasmID(Element germplasmElem) {
      DOMUtil.setAttribute(germplasmElem, GermplasmDocTags.GP_ID_ATTRIB_NAME, Long.toString(productGermplasmWithSources.getMidasGermplasmID()));
   }

   private void renderField(Element germplasmElem, String fieldElemName, String fieldValue) {
      DOMUtil.addChildElementWithNS(GermplasmDocTags.NS_URI, germplasmElem, fieldElemName, fieldValue);
   }

   private void renderOptionalField(Element germplasmElem, String fieldElemName, String fieldValue) {
      if(!StringUtils.isNullOrEmpty(fieldValue)) {
         renderField(germplasmElem, fieldElemName, fieldValue);
      }
   }

}