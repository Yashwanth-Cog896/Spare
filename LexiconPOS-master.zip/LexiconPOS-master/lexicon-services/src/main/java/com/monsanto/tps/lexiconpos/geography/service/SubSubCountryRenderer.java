package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.tps.lexiconpos.geography.SubSubCountry;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 13, 2006
 * Time: 10:47:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class SubSubCountryRenderer
    implements GeographicEntityRenderer,
               GeographySchemaConstants
{
    public void render(
        Element element,
        GeographicEntity entity)
    {
        SubSubCountry subSubCountry = getGetSubSubCountry(entity);
        createSubSubCountryElement(element, subSubCountry);
    }

    private SubSubCountry getGetSubSubCountry(GeographicEntity entity) {
        return (SubSubCountry)entity;
    }

    private Element createSubSubCountryElement(
        Element element,
        SubSubCountry subSubCountry)
    {
        Element subCountryElement = DOMUtil.addChildElementWithNS(NAMESPACE, element, SUBSUBCOUNTRY_ELEM_NAME);
        subCountryElement.setAttribute(PUBKEY_ELEM_NAME, Long.toString(subSubCountry.getID()));
        DOMUtil.addChildElementWithNS(NAMESPACE, subCountryElement, NAME_ELEM_NAME, subSubCountry.getName());
        return subCountryElement;
    }
}
