package com.monsanto.tps.lexiconpos.chemical.service.pos;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 23, 2005
 * Time: 12:14:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialClassificationType
{
    public static final MaterialClassificationType COML_PROD = 
        new MaterialClassificationType(ChemicalMaterialSchemaConstants.COML_PROD_ELEM_NAME);
    
    public static final MaterialClassificationType FORMULATION =
        new MaterialClassificationType(ChemicalMaterialSchemaConstants.FORMULATION_ELEM_NAME);
    
    public static final MaterialClassificationType ACTIVE_INGRED = 
        new MaterialClassificationType(ChemicalMaterialSchemaConstants.ACT_INGRED_ELEM_NAME);

    public static MaterialClassificationType fromString(String name)
        throws InvalidMaterialClassificationTypeException
    {
        if (ChemicalMaterialSchemaConstants.COML_PROD_ELEM_NAME.equals(name)) {
            return COML_PROD;
        }
        else if (ChemicalMaterialSchemaConstants.FORMULATION_ELEM_NAME.equals(name)) {
            return FORMULATION;
        }
        else if (ChemicalMaterialSchemaConstants.ACT_INGRED_ELEM_NAME.equals(name)) {
            return ACTIVE_INGRED;
        }
        else {
            throw new InvalidMaterialClassificationTypeException(name);
        }
    }

    private final String name;

    private MaterialClassificationType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
