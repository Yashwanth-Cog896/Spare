package com.monsanto.tps.lexiconpos.crop;

import com.monsanto.tps.lexiconpos.tps.crop.domain.LexiconCrop;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 11, 2006
 * Time: 4:39:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropResponseRenderer
{
   private final LexiconCrop[] crops;

   public CropResponseRenderer(LexiconCrop[] crops) {
      this.crops = crops;
   }

   public Document renderDocument() {
      Document doc = DOMUtil.newDocument();
      Element root = createRootNode(doc);
      Element listNode = DOMUtil.addChildElementWithNS(CropSchemaConsts.NS_URI, root, CropSchemaConsts.CROPS_ELEM);
      createCropNodes(listNode);
      return doc;
   }

   private void createCropNodes(Element listNode) {
      for (int i = 0; i < crops.length; i++) {
         createCropNode(listNode, crops[i]);
      }
   }

   private void createCropNode(Element listNode, LexiconCrop crop) {
      Element element = DOMUtil.addChildElementWithNS(
         CropSchemaConsts.NS_URI, listNode, CropSchemaConsts.CROP_ELEM, crop.getName());
      DOMUtil.setAttribute(element, CropSchemaConsts.PUBKEY_ATTR, crop.getPubkey());
   }

   private Element createRootNode(Document doc) {
      Element root = DOMUtil.addChildElementWithNS(CropSchemaConsts.NS_URI, doc, CropSchemaConsts.ROOT_RESPOSNE_ELEM);
      root.setAttribute("xmlns", CropSchemaConsts.NS_URI);
      root.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
      return root;
   }
}
