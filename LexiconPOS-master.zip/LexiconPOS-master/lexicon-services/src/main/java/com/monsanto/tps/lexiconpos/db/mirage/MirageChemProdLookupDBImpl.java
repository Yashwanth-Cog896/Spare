package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageActiveIngredient;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageChemProd;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageChemProdFormulation;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageComlChemProd;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 11:32:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageChemProdLookupDBImpl
   implements MirageChemProdLookup,
   MirageSQL
{
   public MirageChemProd[] getCommercialProdcts(
      String wildcardedName,
      PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      WildcardableCriteria criteria = new StdWildcardableCriteria(wildcardedName);
      String sql = getSQLPropFile().getSQL(SELECT_CHEM_PROD_BY_WC_NAME);

      PersistentStoreStatement stmt = mirageConn.prepareStatement(sql);
      try {
         stmt.setParam(1, criteria.oracleVersion());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();

         MirageComlChemProd product;
         String[] activeIngreds;
         ArrayList list = new ArrayList();
         while (iter.next()) {
            product = createCommercialProduct(iter);
            activeIngreds = getActiveIngredientNames(product, mirageConn);
            product.setActiveIngredients(activeIngreds);
            list.add(product);
         }
         return (MirageChemProd[])list.toArray(new MirageChemProd[list.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public MirageChemProd[] getFormulations(
      String wildcardedName,
      PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      WildcardableCriteria criteria = new StdWildcardableCriteria(wildcardedName);
      String sql = getSQLPropFile().getSQL(SELECT_FORMULATION_BY_WC_NAME);
      PersistentStoreStatement stmt = mirageConn.prepareStatement(sql);
      try {
         stmt.setParam(1, criteria.oracleVersion());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();

         MirageChemProdFormulation product;
         String[] activeIngreds;
         ArrayList list = new ArrayList();
         while (iter.next()) {
            product = createFormualtion(iter);
            activeIngreds = getActiveIngredientNames(product, mirageConn);
            product.setActiveIngredients(activeIngreds);
            list.add(product);
         }
         return (MirageChemProd[])list.toArray(new MirageChemProd[list.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public MirageChemProd[] getActiveIngredients(
      String wildcardedName,
      PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      WildcardableCriteria criteria = new StdWildcardableCriteria(wildcardedName);
      String sql = getSQLPropFile().getSQL(SELECT_ACT_INGRED_BY_WC_NAME);
      PersistentStoreStatement stmt = mirageConn.prepareStatement(sql);
      try {
         stmt.setParam(1, criteria.oracleVersion());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();

         MirageChemProd product;
         ArrayList list = new ArrayList();
         while (iter.next()) {
            product = createActiveIngredient(iter);
            list.add(product);
         }
         return (MirageChemProd[])list.toArray(new MirageChemProd[list.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public String[] getActiveIngredientNames(
      MirageChemProd product,
      PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_ACT_INGREDS_BY_CP);
      PersistentStoreStatement stmt = mirageConn.prepareStatement(sql);
      try {
         stmt.setParam(1, product.getProductID());
         stmt.setParam(2, product.getProductName());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();

         ArrayList list = new ArrayList();
         while (iter.next()) {
            list.add(iter.getString(getSQLPropFile().getAlias(ALIAS_ACTIVE_INGRED_NAME)));
         }
         return (String[])list.toArray(new String[list.size()]);
      }
      finally {
         stmt.close();
      }
   }

   private MirageComlChemProd createCommercialProduct(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      MirageComlChemProd product = new MirageComlChemProd();
      product.setProductID(row.getLong(getSQLPropFile().getAlias(ALIAS_CHEM_PROD_ID)));
      product.setProductName(row.getString(getSQLPropFile().getAlias(ALIAS_TRADE_NAME)));
      product.setFullName(row.getString(getSQLPropFile().getAlias(ALIAS_FULL_TRADE_NAME)));
      product.setEnabled("Y".equals(row.getString(getSQLPropFile().getAlias(ALIAS_ENABLED))));
      product.setFormulatedAmount(row.getLong(getSQLPropFile().getAlias(ALIAS_FORMULATED_AMOUNT)));
      product.setFormulatedAmountName(row.getString(getSQLPropFile().getAlias(ALIAS_FORMULATED_AMOUNT_NAME)));
      product.setFormulationDesignation(row.getString(getSQLPropFile().getAlias(ALIAS_FORM_DS)));
      return product;
   }

   private MirageChemProdFormulation createFormualtion(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      MirageChemProdFormulation product = new MirageChemProdFormulation();
      product.setProductID(row.getLong(getSQLPropFile().getAlias(ALIAS_CHEM_PROD_ID)));
      product.setProductName(row.getString(getSQLPropFile().getAlias(ALIAS_TRADE_NAME)));
      product.setFullName(row.getString(getSQLPropFile().getAlias(ALIAS_FULL_TRADE_NAME)));
      product.setEnabled("Y".equals(row.getString(getSQLPropFile().getAlias(ALIAS_ENABLED))));
      product.setFormulatedAmount(row.getLong(getSQLPropFile().getAlias(ALIAS_FORMULATED_AMOUNT)));
      product.setFormulatedAmountName(row.getString(getSQLPropFile().getAlias(ALIAS_FORMULATED_AMOUNT_NAME)));
      product.setFormulationDesignation(row.getString(getSQLPropFile().getAlias(ALIAS_FORM_DS)));
      return product;
   }

   private MirageActiveIngredient createActiveIngredient(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      MirageActiveIngredient product = new MirageActiveIngredient();
      product.setProductID(row.getLong(getSQLPropFile().getAlias(ALIAS_ACTIVE_INGRED_CODE)));
      product.setProductName(row.getString(getSQLPropFile().getAlias(ALIAS_ACTIVE_INGRED_NAME)));
      product.setFullName(row.getString(getSQLPropFile().getAlias(ALIAS_ACTIVE_INGRED_FULLNAE)));
      product.setEnabled("Y".equals(row.getString(getSQLPropFile().getAlias(ALIAS_ENABLED))));
      return product;
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MirageSQL.class);
   }
}
