package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSite;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSiteSearchRequest;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 20, 2006
 * Time: 3:32:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class BFCSiteSearchQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final SiteSearchQueryBuilder queryBuilder;
   private final BFCSiteSearchRequest siteSearchRequest;

   public BFCSiteSearchQuery(BFCSiteSearchRequest siteSearchRequest) throws WrappingException {
      this.siteSearchRequest = siteSearchRequest;
      queryBuilder = new SiteSearchQueryBuilder(siteSearchRequest);
   }

   public BFCSite[] getBFCSites() throws WrappingException {
      List list = getList();
      return (BFCSite[]) list.toArray(new BFCSite[list.size()]);
   }

   protected List getList()
      throws WrappingException
   {
      return (siteSearchRequest.hasCriteria()) ? super.getList() : new ArrayList();
   }

   protected String getSQL() throws WrappingException {
      return queryBuilder.getSQL();
   }

   protected Object[] getBindVariables() throws WrappingException {
      return queryBuilder.getBindVariables();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new BFCSitePSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new BFCConnectionFactoryProperties();
   }
}
