package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 24, 2007
 * Time: 1:22:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactController
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return BusinessAccountSchemaConstants.SCHEMA_SRC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      ExternalContactRequest request = getExternalContactRequest(inputDocument);
      ExternalContact[] externalContacts = getExternalContacts(request);
      return renderResponse(externalContacts);
   }

   private ExternalContactRequest getExternalContactRequest(Document inputDocument) {
      return new ExternalContactRequestDOMImpl(inputDocument);
   }

   private ExternalContact[] getExternalContacts(ExternalContactRequest request)
      throws WrappingException
   {
      ExternalContactHandler process = new ExternalContactHandler(request);
      return process.getExternalContacts();
   }

   private Document renderResponse(ExternalContact[] externalContacts) {
      ExternalContactResponseDocumentRenderer renderer = new ExternalContactResponseDocumentRenderer(externalContacts);
      return renderer.render();
   }
}
