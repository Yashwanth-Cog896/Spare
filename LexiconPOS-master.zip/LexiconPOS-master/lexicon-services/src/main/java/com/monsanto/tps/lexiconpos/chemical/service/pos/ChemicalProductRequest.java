package com.monsanto.tps.lexiconpos.chemical.service.pos;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 11:54:59 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChemicalProductRequest
{
    private final String productName;
    private final MaterialClassificationType classification;

    public ChemicalProductRequest(
        String productName,
        MaterialClassificationType classification)
    {
        this.productName = productName;
        this.classification = classification;
    }

    public String getProductName() {
        return productName;
    }
    public MaterialClassificationType getClassification() {
        return classification;
    }
}
