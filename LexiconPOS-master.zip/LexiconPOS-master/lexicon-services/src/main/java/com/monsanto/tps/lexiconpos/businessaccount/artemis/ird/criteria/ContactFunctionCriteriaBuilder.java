package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import org.hibernate.Criteria;

/**
 * Filename: ContactFunctionCriteriBuilder.java
 * Last Change: rrchak1 On: Jul 30, 2008
 * 
 * @author: rrchak1
 */
public class ContactFunctionCriteriaBuilder
{
   public void addCriteria(Criteria contactFunctionCriteria, String contactType) {
      QueryCriteria queryCriteria = new ContactFunctionContactTypeCriteriaImpl(contactType);
      if(queryCriteria.hasCriteria()) {
         contactFunctionCriteria.add(queryCriteria.getCriterion());
      }
   }
}
