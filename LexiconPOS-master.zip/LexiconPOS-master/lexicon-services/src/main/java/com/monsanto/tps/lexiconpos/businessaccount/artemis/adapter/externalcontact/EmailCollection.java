package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactEmail;
import com.monsanto.tps.lexicon.contact.Email;

import java.util.Collection;

/**
 * nbwald - Aug 1, 2008 2:32:06 PM
 */
public class EmailCollection
{
   private final Collection<ContactEmail> contactEmails;

   public EmailCollection(Collection<ContactEmail> contactEmails) {
      this.contactEmails = contactEmails;
   }

   public Email getEmail() {
      Email email = new Email();
      if (contactEmails != null && !contactEmails.isEmpty()) {
         email.setEmailAddress(contactEmails.iterator().next().getEmail());
      }
      return email;
   }
}
