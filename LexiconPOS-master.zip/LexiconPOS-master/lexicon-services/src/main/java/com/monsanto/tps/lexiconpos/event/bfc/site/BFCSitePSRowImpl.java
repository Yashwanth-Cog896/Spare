package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSite;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 20, 2006
 * Time: 3:46:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class BFCSitePSRowImpl
   implements BFCSite
{
   private final long siteKey;
   private final String farmName;
   private final String fullAddress;
   private final String city;
   private final String islandTownship;
   private final String subSubCountry;
   private final String subCountry;
   private final String country;
   private final String postalCode;

   public BFCSitePSRowImpl(PersistentStoreResultSetRow row) throws WrappingException {
      siteKey = row.getLong(getAlias(BFCSiteSQL.ALIAS_SITE_KEY));
      farmName = row.getString(getAlias(BFCSiteSQL.ALIAS_FARM_NAME));
      fullAddress = row.getString(getAlias(BFCSiteSQL.ALIAS_FULL_ADDRESS));
      city = row.getString(getAlias(BFCSiteSQL.ALIAS_CITY));
      islandTownship = row.getString(getAlias(BFCSiteSQL.ALIAS_ISLAND_TOWNSHIP));
      subSubCountry = row.getString(getAlias(BFCSiteSQL.ALIAS_SUB_SUB_COUNTRY));
      subCountry = row.getString(getAlias(BFCSiteSQL.ALIAS_SUB_COUNTRY));
      country = row.getString(getAlias(BFCSiteSQL.ALIAS_COUNTRY));
      postalCode = row.getString(getAlias(BFCSiteSQL.ALIAS_POSTAL_CODE));
   }

   public long getSiteKey() {
      return siteKey;
   }

   public String getFarmName() {
      return farmName;
   }

   public String getFullAddress() {
      return fullAddress;
   }

   public String getCity() {
      return city;
   }

   public String getIslandTownship() {
      return islandTownship;
   }

   public String getSubSubCountryName() {
      return subSubCountry;
   }

   public String getSubCountryAbbr() {
      return subCountry;
   }

   public String getCountryAbbr() {
      return country;
   }

   public String getPostalCode() {
      return postalCode;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return getSQLPropFile().getAlias(propName);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(BFCSiteSQL.class);
   }
}
