/*
 GermplasmsByProductPubkeysQueryRequestParser was created on Jun 4, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconcommon.service.germplasm.GermplasmsByProductPubkeysQueryDocTags;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Jun 4, 2007 5:37:22 PM
 */
public class GermplasmsByProductPubkeysQueryRequestParser
{
   public String[] getProductPubkeys(Document request) {
      // nstub revisit with xpath parser
      Node[] productPubkeyNodes = DOMUtil.getChildren(request.getDocumentElement(), GermplasmsByProductPubkeysQueryDocTags.PRODUCT_PUBKEY_ELEM_NAME);
      List<String> productPubkeys = new ArrayList<String>();
      for (Node productPubkeyNode : productPubkeyNodes) {
         productPubkeys.add( DOMUtil.getTextValue(productPubkeyNode) );
      }
      return (String[]) productPubkeys.toArray(new String[productPubkeys.size()]);
   }
}