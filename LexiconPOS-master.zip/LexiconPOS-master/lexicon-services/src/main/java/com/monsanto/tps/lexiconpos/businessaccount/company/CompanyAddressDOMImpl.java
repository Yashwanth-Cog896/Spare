package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.tps.lexiconpos.businessaccount.AddressDOMImpl;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 2, 2007
 * Time: 2:34:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyAddressDOMImpl
   extends AddressDOMImpl
{
   public CompanyAddressDOMImpl(Element row) {
      super(row);
   }

   public String getAddressId() {
      return getFieldNodeValue(ACCT_ADDRID_ATTR_NAME);
   }
   public String getPhoneNumber() {
      return getFieldNodeValue(PHONE_NUMBER_ATTR_NAME);
   }
}
