/*
 GermplasmLookupQuerySetStdImpl was created on Jan 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.dao.fbscommon.FBSCommonProductXrefByMidasProductIdQuery;
import com.monsanto.tps.lexiconpos.product.common.domain.fbscommon.FBSCommonProductXref;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.GeneticMaterial;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.MidasProductGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 22, 2007 3:13:27 PM
 */
public class ProductGermplasmWithSourcesQuerySetStdImpl
   implements ProductGermplasmWithSourcesQuerySet
{
   public MidasProductGermplasm getProductGermplasm(long midasGermplasmID)
      throws WrappingException
   {
      MidasProductGermplasmByGermplasmIDQuery query = new MidasProductGermplasmByGermplasmIDQuery(midasGermplasmID);
      return query.getProductGermplasm();
   }

   public GeneticMaterial[] getGeneticMaterial(long midasGermplasmID)
      throws WrappingException
   {
      GeneticMaterialsByGermplasmIDQuery query = new GeneticMaterialsByGermplasmIDQuery(midasGermplasmID);
      return query.getGeneticMaterial();
   }

   public String getProductPubkey(long midasProductID)
      throws WrappingException
   {
      FBSCommonProductXrefByMidasProductIdQuery query = new FBSCommonProductXrefByMidasProductIdQuery(midasProductID);
      FBSCommonProductXref productXref = query.getXref();
      return productXref == null ? null : productXref.getLexiconProductPubkey();
   }

   public Germplasm getGermplasm(long germplasmID)
      throws WrappingException
   {
      GermplasmByIDQuery query = new GermplasmByIDQuery(germplasmID);
      return query.getGermplasm();
   }

}