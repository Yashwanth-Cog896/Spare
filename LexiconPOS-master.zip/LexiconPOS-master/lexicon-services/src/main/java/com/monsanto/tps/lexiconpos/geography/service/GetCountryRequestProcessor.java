package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconGeographyLookup;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconGeographyLookupDBImpl;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 5:21:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetCountryRequestProcessor
    implements GeographyRequestProcessor
{
    private LexiconGeographyLookup lookup;

    public GeographicEntity[] getMatchingGeography(
        GeographyRequestModel requestModel,
        TPSPersistentStoreConnection conn)
        throws WrappingException
    {

        LexiconCountry[] countries;

        if (!StringUtils.isNullOrEmpty(requestModel.getCountryName()))
        {
            countries = getCountriesByName(requestModel, conn);
        }
        else if (!StringUtils.isNullOrEmpty(requestModel.getCountryAbbr()))
        {
            countries = getCountriesByAbbr(requestModel);
        }
        else
        {
            countries = getCountryByPubkey(requestModel, conn);
        }
        return countries;
    }

    private LexiconCountry[] getCountriesByName(
        GeographyRequestModel requestModel,
        TPSPersistentStoreConnection conn)
        throws WrappingException
    {
        return getGeographyLookup().getCountriesByName(
            requestModel.getCountryName(), conn.getLexiconConnection());
    }

    private LexiconCountry[] getCountriesByAbbr(
        GeographyRequestModel requestModel)
        throws WrappingException
    {
        return getGeographyLookup().getCountriesByUNCode(
            requestModel.getCountryAbbr());
    }

    private LexiconCountry[] getCountryByPubkey(
        GeographyRequestModel requestModel,
        TPSPersistentStoreConnection conn)
        throws WrappingException
    {
        return getGeographyLookup().getCountryByPubKey(
            requestModel.getCountryPubkey(), conn.getLexiconConnection());
    }

    protected LexiconGeographyLookup getGeographyLookup()
    {
        if (lookup == null) {
            lookup = new LexiconGeographyLookupDBImpl();
        }
        return lookup;
    }
}
