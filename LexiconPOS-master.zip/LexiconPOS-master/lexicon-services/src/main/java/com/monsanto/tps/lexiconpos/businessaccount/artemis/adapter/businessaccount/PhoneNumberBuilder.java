package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctPhone;
import com.monsanto.tps.lexicon.contact.PhoneNumber;

/**
 * nbwald - Aug 1, 2008 12:27:52 PM
 */
public class PhoneNumberBuilder
{
   public PhoneNumber build(AcctPhone accountPhone) {
      PhoneNumber phoneNumber = new PhoneNumber();
      phoneNumber.setNumber(getPhoneNumber(accountPhone));
      return phoneNumber;
   }

   private String getPhoneNumber(AcctPhone acctPhone) {
      return acctPhone == null ? null : acctPhone.getPhoneNumber();
   }
}