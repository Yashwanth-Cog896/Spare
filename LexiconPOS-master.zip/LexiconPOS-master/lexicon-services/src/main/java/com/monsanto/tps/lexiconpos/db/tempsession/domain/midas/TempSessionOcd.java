package com.monsanto.tps.lexiconpos.db.tempsession.domain.midas;

import java.io.Serializable;

/**
 * RLCASW - Feb 28, 2010 10:59:55 AM
 */
public class TempSessionOcd
   implements Serializable
{
   private Long requestId;
   private String text1;
   private Long sortOrder;
   private Long number1;

   public Long getRequestId() {
      return requestId;
   }

   public void setRequestId(Long requestId) {
      this.requestId = requestId;
   }

   public String getText1() {
      return text1;
   }

   public void setText1(String text1) {
      this.text1 = text1;
   }

   public Long getSortOrder() {
      return sortOrder;
   }

   public void setSortOrder(Long sortOrder) {
      this.sortOrder = sortOrder;
   }

   public Long getNumber1() {
      return number1;
   }

   public void setNumber1(Long number1) {
      this.number1 = number1;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      TempSessionOcd that = (TempSessionOcd) o;

      if (number1 != null ? !number1.equals(that.number1) : that.number1 != null) {
         return false;
      }
      if (requestId != null ? !requestId.equals(that.requestId) : that.requestId != null) {
         return false;
      }
      if (sortOrder != null ? !sortOrder.equals(that.sortOrder) : that.sortOrder != null) {
         return false;
      }
      if (text1 != null ? !text1.equals(that.text1) : that.text1 != null) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result = requestId != null ? requestId.hashCode() : 0;
      result = 31 * result + (text1 != null ? text1.hashCode() : 0);
      result = 31 * result + (sortOrder != null ? sortOrder.hashCode() : 0);
      result = 31 * result + (number1 != null ? number1.hashCode() : 0);
      return result;
   }
}
