package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 30, 2006
 * Time: 9:21:23 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasGeographicRegionQuery
{
   public MidasGeographicRegion[] getMidasGeographicRegions()
      throws WrappingException;
}
