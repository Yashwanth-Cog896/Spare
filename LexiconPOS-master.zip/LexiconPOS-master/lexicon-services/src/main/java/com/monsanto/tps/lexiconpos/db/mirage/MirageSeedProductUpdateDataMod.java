package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 7, 2007
 * Time: 8:50:33 PM
 */
public class MirageSeedProductUpdateDataMod
{
   private final int seedProductID;
   private final String productName;
   private final int companyID;
   private final String bayerCode;
   private final String countryCode;
   private final int traitCharacteristicsID;
   private final String enabled;

   public MirageSeedProductUpdateDataMod(
      int seedProductID, String productName, int companyID,
      String bayerCode, String countryCode, int traitCharacteristicsID, boolean isEnabled)
   {
      this.seedProductID = seedProductID;
      this.productName = productName;
      this.companyID = companyID;
      this.bayerCode = bayerCode;
      this.countryCode = countryCode;
      this.traitCharacteristicsID = traitCharacteristicsID;
      this.enabled = isEnabled ? "Y" : "N";
   }

   public int performUpdate(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return new MirageAuditedAction(){
         @Override
         protected int performAction(PersistentStoreStatement statement)
            throws WrappingException
         {
            return statement.executeUpdate();
         }

         @Override
         protected String getSQL()
            throws WrappingException
         {
            SQLPropFile propFile = new SQLPropFile(MirageSeedProductWriterSQL.class);
            return propFile.getSQL(MirageSeedProductWriterSQL.UPDATE_PRODUCT);
         }

         @Override
         protected Object[] getBindVariables(int auditId) {
            return new Object[] {companyID, productName, bayerCode, countryCode, getTraitCharacteristicCode(),
            enabled, enabled, auditId, seedProductID};
         }

         private String getTraitCharacteristicCode() {
            return traitCharacteristicsID == 0 ? "" : String.valueOf(traitCharacteristicsID);
         }

         @Override
         protected int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
            throws WrappingException
         {
            return mirageAuditor.auditUpdateSeedProduct(mirageConn);
         }
      }.execute(mirageConn);
   }
}
