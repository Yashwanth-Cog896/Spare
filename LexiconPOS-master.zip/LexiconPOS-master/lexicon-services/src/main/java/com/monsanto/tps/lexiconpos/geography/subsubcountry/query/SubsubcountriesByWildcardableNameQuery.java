/*
 SubsubcountriesByWildcardableNameQuery was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subsubcountry.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

import java.util.List;

/**
 * @author GGSHIV - Jun 10, 2008 3:05:14 PM
 */
public class SubsubcountriesByWildcardableNameQuery extends AbstractPersistentStoreMultiRowQuery {

   private final String lexiconCountryPubkey;
   private final WildcardableCriteria subcountryName;
   private final WildcardableCriteria subsubcountryName;

   public SubsubcountriesByWildcardableNameQuery(String lexiconCountryPubkey, WildcardableCriteria subcountryName,
                                                 WildcardableCriteria subsubcountryName) {
      this.lexiconCountryPubkey = lexiconCountryPubkey;
      this.subcountryName = subcountryName;
      this.subsubcountryName = subsubcountryName;
   }

   public Subsubcountry[] find() {
      try {
         List<Subsubcountry> subcountries = getList();
         return subcountries.toArray(new Subsubcountry[subcountries.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      Subsubcountry subcountry = new Subsubcountry();
      subcountry.setName( row.getString("SubsubCountryName") );
      subcountry.setAbbreviation( row.getString("SubCountryAbbr") );
      return subcountry;
   }

   protected String getSQL() throws WrappingException {
      return
        "   SELECT SSC.name AS \"SubsubCountryName\", SC.sub_country_abbr AS \"SubCountryAbbr\"" +
        "     FROM FBS_Common.Country_Xref CX," +
        "          Midas.Country C," +
        "          Midas.Sub_Country SC," +
        "          Midas.Sub_Sub_Country SSC" +
        "    WHERE CX.lexicon_country_pubkey = ?" +
        "      AND CX.midas_country_id = C.country_id" +
        "      AND C.country_id = SC.country_id" +
        "      AND SC.sub_country_id = SSC.sub_country_id" + getCriteria() +
        " ORDER BY SSC.name";
   }

   protected Object[] getBindVariables() throws WrappingException {
      if (subcountryName.getCriteria() != null && subsubcountryName.getCriteria() != null) {
         return new Object[]{lexiconCountryPubkey, subcountryName.oracleVersion(), subsubcountryName.oracleVersion()};
      }
      return null == subsubcountryName.getCriteria() ? new Object[]{lexiconCountryPubkey, subcountryName.oracleVersion()}
              : new Object[]{lexiconCountryPubkey, subsubcountryName.oracleVersion()};
   }

   private String getCriteria() {
      if (subcountryName.getCriteria() == null) {
         return subsubCountryNameCriteria();
      }
      if (subsubcountryName.getCriteria() == null) {
         return subCountryNameCriteria();
      }
      return subCountryNameCriteria() + subsubCountryNameCriteria();
   }

   private String subCountryNameCriteria() {
      return " AND UPPER(SC.name) LIKE UPPER(?)";
   }

   private String subsubCountryNameCriteria() {
      return " AND UPPER(SSC.name) LIKE UPPER(?)";
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}