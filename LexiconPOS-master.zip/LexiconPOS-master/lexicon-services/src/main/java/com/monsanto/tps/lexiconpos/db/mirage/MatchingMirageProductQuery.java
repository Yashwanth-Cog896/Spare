package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.product.common.domain.mirage.MirageProduct;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 20, 2006
 * Time: 8:08:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class MatchingMirageProductQuery
{
   private final String productName;
   private final String bayerCode;
   private final int companyID;
   private final String countryCode;

   public MatchingMirageProductQuery(String productName, String bayerCode, int companyID, String countryCode) {
      this.productName = productName;
      this.bayerCode = padBayerCode(bayerCode);
      this.companyID = companyID;
      this.countryCode = countryCode;
   }

   public MirageProduct execute(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(MirageSQL.SELECT_PROD_BY_MODEL);
      PersistentStoreStatement stmt = mirageConn.prepareStatement(sql);
      try {
         stmt.setParam(1, productName);
         stmt.setParam(2, bayerCode);
         stmt.setParam(3, companyID);
         stmt.setParam(4, countryCode);

         PersistentStoreResultSetFwdIterator iterator = stmt.executeQuery().getForwardIterator();
         return (iterator.next()) ? new MirageProductDTOBuilder(iterator) : null;
      }
      finally {
         stmt.close();
      }
   }

   private String padBayerCode(String bayerCode) {
      if (bayerCode != null) {
         bayerCode = bayerCode.trim();
         if (bayerCode.length() == 5) {
            bayerCode = bayerCode + ' ';
         }
      }
      return bayerCode;
   }

   protected SQLPropFile getSQLPropFile() {
       return new SQLPropFile(MirageSQL.class);
   }
}
