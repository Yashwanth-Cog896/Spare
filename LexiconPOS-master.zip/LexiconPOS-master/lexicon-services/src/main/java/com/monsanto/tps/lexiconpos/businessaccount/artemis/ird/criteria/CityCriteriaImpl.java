package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    CityCriteriaImpl.java
 * Last Change: rrchak1 On: Jul 30, 2008
 *
 * @author: rrchak1
 */
public class CityCriteriaImpl implements QueryCriteria {
    private final String city;

    public CityCriteriaImpl(String city) {
        this.city = city;
    }

    public Criterion getCriterion() {
        return Restrictions.like(BusinessAccountSchemaConstants.CITY, convertWildCards(city)).ignoreCase();
    }

    public boolean hasCriteria() {
        return StringUtils.isNotEmpty(city);
    }

    private String convertWildCards(String attribute) {
        return new StdWildcardableCriteria(attribute).oracleVersion();
    }
}
