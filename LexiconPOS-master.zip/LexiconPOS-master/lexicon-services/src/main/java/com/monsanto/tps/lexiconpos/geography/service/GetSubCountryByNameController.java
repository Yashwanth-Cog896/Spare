package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 12, 2006
 * Time: 11:23:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubCountryByNameController
    extends GetGeographicEntitiesController
{
    protected GeographyRequestParser getGeographyRequestParser() {
        return new GetSubCountryByNameRequestParser();
    }

    protected GeographyRequestProcessor getGeographyRequestProcessor() {
        return new GetSubCountryByNameRequestProcessor();
    }

    protected GeographicEntityRenderer getEntityRenderer() {
        return new SubCountryRenderer();
    }

    protected String getResponseDocumentElementName() {
        return GeographySchemaConstants.GET_SUB_COUNTRY_RESPONSE_ELEM_NAME;
    }
}
