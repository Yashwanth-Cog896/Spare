package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.businessaccount;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.contact.SearchableLocation;

/**
 * nbwald - Jun 4, 2008 3:46:35 PM
 */
public class SomeBusinessAccountSearchCriteriaMustBeSpecifiedRule
   implements Rule<String>
{
   private final BusinessAccountSearchCriteria criteria;

   public SomeBusinessAccountSearchCriteriaMustBeSpecifiedRule(BusinessAccountSearchCriteria criteria) {
      this.criteria = criteria;
   }

   public boolean violated() {
      return criteria.getCompanyName() == null
         && noLocationCriteria(criteria.getLocation());
   }

   private boolean noLocationCriteria(SearchableLocation location) {
      return location == null ||
         (location.getCity() == null
         && location.getCountryName() == null
         && location.getSubcountryCode() == null
         && location.getSubsubcountryName() == null);
   }

   public String getViolation() {
      return "Must specify some criteria.";
   }
}
