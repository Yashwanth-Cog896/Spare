package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.tps.lexiconpos.geography.dao.LexiconGeographyLookup;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconGeographyLookupDBImpl;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 12, 2006
 * Time: 11:25:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubSubCountryByNameRequestProcessor 
    implements GeographyRequestProcessor
{
    public GeographicEntity[] getMatchingGeography(
        GeographyRequestModel requestModel,
        TPSPersistentStoreConnection conn)
        throws WrappingException
    {
        return getGeographyLookup().getSubSubCountriesByName(
            new Long(requestModel.getSubCountryPubkey()).longValue(),
            requestModel.getSubSubCountryName(), conn.getMidasConnection());
    }

    protected LexiconGeographyLookup getGeographyLookup() {
        return new LexiconGeographyLookupDBImpl();
    }
}
