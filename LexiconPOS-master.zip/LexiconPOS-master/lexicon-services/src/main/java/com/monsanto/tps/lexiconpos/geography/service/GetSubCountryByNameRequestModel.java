package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 6:43:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubCountryByNameRequestModel
    implements GeographyRequestModel
{
    private final String countryPubkey;
    private final String subCountryName;
    private final String subCountryAbbr;

    public GetSubCountryByNameRequestModel(
        String countryPubkey,
        String subCountryName,
        String subCountryAbbr)
    {
        this.countryPubkey = countryPubkey;
        this.subCountryName = subCountryName;
        this.subCountryAbbr = subCountryAbbr;
    }

    public String getCountryPubkey() {
        return countryPubkey;
    }
    public String getSubCountryName() {
        return subCountryName;
    }
    public String getSubCountryAbbr() {
        return subCountryAbbr;
    }

    public String getCountryName() {
        return null;
    }
    public String getCountryAbbr() {
        return null;
    }
    public String getSubCountryPubkey() {
        return null;
    }
    public String getSubSubCountryName() {
        return null;
    }
}
