/*
 SegregateCropBuilder was created on Jun 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.BAYER_CODE_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.BAYER_CODE_PUBKEY_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.CROP_ABBREVIATION_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.CROP_NAME_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.CROP_PUBKEY_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.SCIENTIFIC_NAME_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.SCIENTIFIC_PUBKEY_ALIAS;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.SHIPPING_STATEMENT_ALIAS;
import static com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet.CROP_SQL_PROPERTY_FILE;
import com.monsanto.tps.lexicon.crop.ScientificName;

/**
 * @author GGSHIV - Jun 26, 2008 6:59:22 PM
 */
public class SegregateCropBuilder {

   public SegregateCrop build(PersistentStoreResultSetRow row) throws WrappingException {
      SegregateCrop crop = new SegregateCrop();
      crop.setPublicKey(row.getString(getAlias(CROP_PUBKEY_ALIAS)));
      crop.setName(row.getString(getAlias(CROP_NAME_ALIAS)));
      crop.setAbbreviation(row.getString(getAlias(CROP_ABBREVIATION_ALIAS)));
      crop.setShippingStatement(row.getString(getAlias(SHIPPING_STATEMENT_ALIAS)));
      crop.setBayerCode(getBayerCode(row));
      return crop;
   }

   private SegregateBayerCode getBayerCode(PersistentStoreResultSetRow row) throws WrappingException {
      return new SegregateBayerCode(row.getString(getAlias(BAYER_CODE_ALIAS)), row.getString(getAlias(BAYER_CODE_PUBKEY_ALIAS)), getScientificName(row));
   }

   private ScientificName getScientificName(PersistentStoreResultSetRow row) throws WrappingException {
      return new ScientificName(row.getString(getAlias(SCIENTIFIC_NAME_ALIAS)), row.getString(getAlias(SCIENTIFIC_PUBKEY_ALIAS)));
   }

   protected String getAlias(String aliasName) throws WrappingException {
      return CROP_SQL_PROPERTY_FILE.getAlias(aliasName);
   }
}
