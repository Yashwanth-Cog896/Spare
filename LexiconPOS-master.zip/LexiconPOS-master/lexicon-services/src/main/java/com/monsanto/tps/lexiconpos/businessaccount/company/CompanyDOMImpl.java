package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.tps.lexiconpos.businessaccount.Address;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 11:24:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyDOMImpl
   implements Company, BusinessAccountSchemaConstants
{
   private final Element row;

   public CompanyDOMImpl(Element row) {
      this.row = row;
   }

   public String getAcctId() {
      return getFieldNodeValue(ACCT_ID_ATTR_NAME);
   }
   public String getCompanyName() {
      return getFieldNodeValue(NAME_1_ATTR_NAME);
   }
   public Address[] getAddresses() {
      return new Address[] {new CompanyAddressDOMImpl(row)};
   }

   protected String getFieldNodeValue(String attributeName)
   {
      try {
         String path = getFieldNameAttributePath() + attributeName + "']/text()";
         Node node = XPathAPI.selectSingleNode(row, path);
         return (node == null) ? null : node.getNodeValue();
      } catch (TransformerException e) {
         throw new RuntimeException(e);
      }
   }
   private String getFieldNameAttributePath() {
      return new StringBuffer(FIELD_ELEM_NAME)
            .append("[@")
            .append(NAME_ATTR_NAME)
            .append("='").toString();
   }
}
