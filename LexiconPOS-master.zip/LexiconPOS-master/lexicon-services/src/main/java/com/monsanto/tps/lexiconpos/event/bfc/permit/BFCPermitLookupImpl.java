package com.monsanto.tps.lexiconpos.event.bfc.permit;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tps.lexiconpos.permit.Permit;
import com.monsanto.tps.lexiconpos.permit.PermitRequest;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.BFCPerson;
import com.monsanto.tps.lexiconpos.event.bfc.person.BFCPersonByFullNameQuery;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 17, 2006
 * Time: 3:53:44 PM
 */
public class BFCPermitLookupImpl implements BFCPermitLookup, BFCPermitSQL
{
   private final SQLPropFile sqlPropFile = new SQLPropFile(BFCPermitSQL.class);

   public Permit getPermit(PersistentStoreConnection conn, PermitRequest request)
      throws WrappingException
   {
      String sql = getSQL(request);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, getId(request));
         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return buildPermit(rs, conn);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         stmt.close();
      }
   }

   private String getId(PermitRequest request) {
      return (request.isRequestByMonsantoId()) ? request.getMonsantoId() : request.getAgencyId();
   }

   private String getSQL(PermitRequest request) throws WrappingException {
      return getBaseSQL(request.isRequestByMonsantoId()) + getStatusCriteria(request.getStatuses()) + getApplicationCriteria(request.getApplicationTypes());
   }

   private String getBaseSQL(boolean hasMonsantoId) throws WrappingException {
      return hasMonsantoId ? getSQL(SELECT_BY_MONSANTO_ID) : getSQL(SELECT_BY_AGENCY_ID);
   }

   private String getApplicationCriteria(String[] applicationTypes) throws WrappingException {
      return (applicationTypes != null && applicationTypes.length > 0) ? buildApplicationTypeSQL(applicationTypes) : "";
   }

   private String getStatusCriteria(String[] statuses) throws WrappingException {
      return (statuses != null && statuses.length > 0) ? buildStatusSQL(statuses) : "";
   }

   private String buildApplicationTypeSQL(String[] applicationTypes) throws WrappingException {
      return " AND " + getSQL(APPLICATION_TYPE_CRITERIA) + " " + SqlUtilities.makeInListOfStrings(applicationTypes).toUpperCase();
   }

   private String buildStatusSQL(String[] statuses) throws WrappingException {
      return " AND " + getSQL(STATUS_CRITERIA) + " " + SqlUtilities.makeInListOfStrings(statuses).toUpperCase();
   }

   private String getSQL(String propertyName) throws WrappingException {
      return sqlPropFile.getSQL(propertyName);
   }

   private Permit buildPermit(PersistentStoreResultSetSingleResult rs, PersistentStoreConnection conn)
      throws WrappingException
   {
      return new PermitDTO(  rs.getLong(PERMIT_ID_ALIAS),
                                 rs.getString(MONSANTO_ID_ALIAS),
                                 rs.getString(AGENCY_ID_ALIAS),
                                 rs.getString(APPLICATION_TYPE_ALIAS),
                                 rs.getString(SUBMISSION_TYPE_ALIAS),
                                 rs.getString(STATUS_ALIAS),
                                 rs.getString(CROP_NAME_ALIAS),
                                 rs.getString(CROP_CODE_ALIAS),
                                 rs.getDate(EFFECTIVE_DATE_ALIAS),
                                 rs.getDate(EXPIRATION_DATE_ALIAS),
                                 bool(rs.getString(BFCPermitSQL.HAS_EUP_ALIAS)),
                                 rs.getString(BFCPermitSQL.EUP_DOCUMENT_NAME_ALIAS),
                                 getPermitRequester(rs, conn));
   }

   private BFCPerson getPermitRequester(PersistentStoreResultSetSingleResult rs, PersistentStoreConnection conn)
      throws WrappingException
   {
      String fullName = rs.getString(REQUESTED_BY);
      BFCPersonByFullNameQuery query = new BFCPersonByFullNameQuery(fullName);
      return query.getPerson(conn);
   }

   private boolean bool(String s) {
      return Boolean.valueOf(s).booleanValue();
   }
}
