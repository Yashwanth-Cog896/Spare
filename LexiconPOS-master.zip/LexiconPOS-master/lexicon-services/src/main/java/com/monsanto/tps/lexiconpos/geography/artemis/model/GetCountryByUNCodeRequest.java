/*
 GetCountriesActionRequest was created on Nov 5, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.geography.artemis.model;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.services.domain.common.filter.extractor.FilterValueExtractor;

/**
 * nbwald Nov 5, 2007 12:19:38 PM
 */
public class GetCountryByUNCodeRequest
{
   private static final String UN_CODE_OPERAND = "UNCode";
   
   private int unCode;

   public GetCountryByUNCodeRequest(ServiceProcessContext context) {
      this.unCode = getUNCodeValueFromRequest(context);
   }

   public int getUNCode() {
      return unCode;
   }

   private int getUNCodeValueFromRequest(ServiceProcessContext context) {
      CompositeObject requestPayload = (CompositeObject)context.getRequestPayload();
      Filter filter = (Filter)requestPayload.getFirst(Filter.class);
      FilterValueExtractor filterValues = new FilterValueExtractor(filter);
      String unCodeValue = filterValues.getValue(UN_CODE_OPERAND);
      return Integer.valueOf(unCodeValue);
   }
}