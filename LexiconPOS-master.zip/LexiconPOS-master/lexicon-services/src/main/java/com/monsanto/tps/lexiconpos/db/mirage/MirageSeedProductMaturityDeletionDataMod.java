package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 16, 2006
 * Time: 11:19:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageSeedProductMaturityDeletionDataMod
   extends AbstractPersistentStoreDelete
{
   private final int seedProductID;

   public MirageSeedProductMaturityDeletionDataMod(int seedProductID) {
      this.seedProductID = seedProductID;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MirageSeedProductWriterSQL.class);
      return propFile.getSQL(MirageSeedProductWriterSQL.DELETE_MATRUITY);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { Integer.valueOf(seedProductID)};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }
}
