package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.domain.midas.GeneticMaterial;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.MidasProductGermplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.ProductGermplasmWithSources;
import com.monsanto.tps.lexiconpos.germplasm.model.ProductGermplasmWithSourcesImpl;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 19, 2007
 * Time: 3:49:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductGermplasmWithSourcesFactory
{
   private final Germplasm[] germplasms;
   private final ProductGermplasmWithSourcesQuerySet productGermplasmWithSourcesQuerySet;

   public ProductGermplasmWithSourcesFactory(Germplasm[] germplasms, ProductGermplasmWithSourcesQuerySet productProductGermplasmWithSourcesQuerySet) {
      this.productGermplasmWithSourcesQuerySet = productProductGermplasmWithSourcesQuerySet;
      this.germplasms = germplasms;
   }

   public ProductGermplasmWithSources[] buildProductGermplasmWithSources()
      throws WrappingException
   {
      ProductGermplasmWithSources[] queryGermplasms = new ProductGermplasmWithSources[germplasms.length];
      for (int i = 0; i < germplasms.length; i++) {
         queryGermplasms[i] = buildSingleProductGermplasmWithSources(germplasms[i]);
      }
      return queryGermplasms;
   }

   private ProductGermplasmWithSources buildSingleProductGermplasmWithSources(Germplasm germplasm)
      throws WrappingException
   {
      MidasProductGermplasm productGermplasm = productGermplasmWithSourcesQuerySet.getProductGermplasm(germplasm.getMidasGermplasmID());
      GeneticMaterial[] geneticMaterial = productGermplasmWithSourcesQuerySet.getGeneticMaterial(germplasm.getMidasGermplasmID());
      String productPubkey = getProductPubkey(productGermplasm);
      return new ProductGermplasmWithSourcesImpl(germplasm, productGermplasm, geneticMaterial, productPubkey);
   }

   private String getProductPubkey(MidasProductGermplasm productGermplasm)
      throws WrappingException
   {
      if(productGermplasm != null) {
         return productGermplasmWithSourcesQuerySet.getProductPubkey(productGermplasm.getMidasProductID());
      }
      else {
         return null;
      }
   }
}
