package com.monsanto.tps.lexiconpos.artemis.response;

import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tcc.artemis.metric.MetricAuditor;
import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;

import java.util.Arrays;
import java.util.List;

/**
 * nbwald - Jul 7, 2008 2:28:21 PM
 */
public class MultipleResultResponse
{
   private final List<?> responseObjects;

   public MultipleResultResponse(Object[] responseObjects) {
      this(Arrays.asList(responseObjects)); 
   }

   public MultipleResultResponse(List<?> responseObjects) {
      this.responseObjects = responseObjects;
   }

   public void saveResponse(ServiceProcessContext context) {
      saveResponseObjectsInResponseEnvelope(context);
      saveNumberOfResultsMetric(context);
   }

   private void saveResponseObjectsInResponseEnvelope(ServiceProcessContext context) {
      ResponseEnvelope responseEnvelope = context.getResponseEnvelope();
      responseEnvelope.addAll(responseObjects);
   }

   private void saveNumberOfResultsMetric(ServiceProcessContext context) {
      MetricAuditor metricAuditor = context.getMetricAuditor();
      metricAuditor.capture("Number of Results", responseObjects.size());
   }
}
