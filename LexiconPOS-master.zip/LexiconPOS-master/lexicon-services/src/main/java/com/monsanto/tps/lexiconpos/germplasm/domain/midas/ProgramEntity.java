package com.monsanto.tps.lexiconpos.germplasm.domain.midas;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Mar 1, 2011
 * Time: 11:41:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProgramEntity {
    private long id;
    private String refId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }
}
