package com.monsanto.tps.lexiconpos.businessaccount.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact.ContactCollection;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.contract.IdentifiersRequest;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service.IrdExternalContactService;

/**
 * nbwald - May 14, 2008 3:41:15 PM
 */
public class FindExternalContactsByExternalContactIdsAction
   extends AbstractArtemisServiceAction
{
    private IrdExternalContactService service;

    public FindExternalContactsByExternalContactIdsAction(IrdExternalContactService irdExternalContactService) {
      this.service = irdExternalContactService;
   }

   public void process(ServiceProcessContext context)
      throws Exception
   {
      IdentifiersRequest request = new IdentifiersRequest(context);
      Contact[] irdContacts = service.findByIds(request.getIds());
      ContactCollection contactCollection = new ContactCollection(irdContacts);
      new MultipleResultResponse(contactCollection.getExternalContacts()).saveResponse(context);
   }
}
