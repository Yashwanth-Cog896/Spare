package com.monsanto.tps.lexiconpos.geography.zipcode;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 10:04:50 AM
 */
public class ZipCodeValidationRequestModel
{
	private final String zipCode;

	public ZipCodeValidationRequestModel(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getZipCode() {
		return zipCode;
	}

}
