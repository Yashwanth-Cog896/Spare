/*
 GermplasmQueryResultsBuilder was created on Jan 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tps.lexiconpos.germplasm.model.ProductGermplasmWithSources;
import org.w3c.dom.Document;

/**
 * nbwald Jan 19, 2007 3:47:52 PM
 */
public class GermplasmQueryResultsBuilder
{
   private final ProductGermplasmWithSources[] queryGermplasms;
   private final int matchedGP;
   private final int matchedGPFromGPCriteria;

   public GermplasmQueryResultsBuilder(ProductGermplasmWithSources[] queryGermplasms, int matchedGP, int matchedGPFromGPCriteria) {
      this.queryGermplasms = queryGermplasms;
      this.matchedGP = matchedGP;
      this.matchedGPFromGPCriteria = matchedGPFromGPCriteria;
   }

   public Document build() {
      Document responseDoc = createDocument();
      renderResponse(responseDoc);
      return responseDoc;
   }

   private void renderResponse(Document responseDoc) {
      GermplasmQueryResultsRenderer renderer = new GermplasmQueryResultsRenderer(responseDoc.getDocumentElement(), queryGermplasms, matchedGP, matchedGPFromGPCriteria);
      renderer.render();
   }

   private Document createDocument() {
      return DocumentCreator.createDocument(GermplasmQueryDocTags.NS_URI, GermplasmQueryDocTags.QUERY_RESULTS_ELEM_NAME);
   }
}