package com.monsanto.tps.lexiconpos.germplasm.domain.midas;

import com.monsanto.tps.lexiconpos.crop.domain.midas.MidasCropEntity;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.ProductGermplasmEntity;
import com.monsanto.tps.lexiconpos.royalty.domain.midas.GermplasmRoyalty;

import java.util.List;

/**
 * RLCASW - Feb 28, 2010 9:14:02 AM
 */
public class Germplasm
{
   private Long id;
   private boolean deleted;
   private String eventDisplay;
   private boolean finished;
   private String origin;
   private String linecode;
   private String pedigree;
   private boolean transgenic;

   private LineType lineType;
   private MidasCropEntity crop;
   private ProgramEntity ownerProgram;
   private List<ProductGermplasmEntity> productGermplasms;
   private List<GermplasmRoyalty> germplasmRoyalties;
    
   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public boolean isDeleted() {
      return deleted;
   }

   public void setDeleted(boolean deleted) {
      this.deleted = deleted;
   }

   public LineType getLineType() {
      return lineType;
   }

   public void setLineType(LineType lineType) {
      this.lineType = lineType;
   }


   public List<GermplasmRoyalty> getGermplasmRoyalties() {
      return germplasmRoyalties;
   }

   public void setGermplasmRoyalties(List<GermplasmRoyalty> germplasmRoyalties) {
      this.germplasmRoyalties = germplasmRoyalties;
   }

    public List<ProductGermplasmEntity> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(List<ProductGermplasmEntity> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public MidasCropEntity getCrop() {
        return crop;
    }

    public void setCrop(MidasCropEntity crop) {
        this.crop = crop;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public String getLinecode() {
        return linecode;
    }

    public void setLinecode(String linecode) {
        this.linecode = linecode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public boolean isTransgenic() {
        return transgenic;
    }

    public void setTransgenic(boolean transgenic) {
        this.transgenic = transgenic;
    }

    public ProgramEntity getOwnerProgram() {
        return ownerProgram;
    }

    public void setOwnerProgram(ProgramEntity ownerProgram) {
        this.ownerProgram = ownerProgram;
    }
}
