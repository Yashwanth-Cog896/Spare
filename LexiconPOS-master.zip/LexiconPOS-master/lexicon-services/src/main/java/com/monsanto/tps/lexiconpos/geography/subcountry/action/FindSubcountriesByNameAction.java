package com.monsanto.tps.lexiconpos.geography.subcountry.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.subcountry.query.SubcountryQuerySet;
import com.monsanto.tps.lexiconpos.geography.subcountry.query.SubcountryQuerySetImpl;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexicon.geography.subcountry.SubcountriesByNameRequest;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

/**
 * nbwald - Jun 8, 2008 12:45:33 PM
 */
public class FindSubcountriesByNameAction extends AbstractArtemisServiceAction {

   private final SubcountryQuerySet querySet;

   public FindSubcountriesByNameAction() {
      this(new SubcountryQuerySetImpl());
   }

   public FindSubcountriesByNameAction(SubcountryQuerySet querySet) {
      this.querySet = querySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      SubcountriesByNameRequest request = (SubcountriesByNameRequest) context.getRequestPayload();
      LexiconCountry lexiconCountry = getLexiconCountry(request);
      Subcountry[] subcountries = getSubcountries(request, lexiconCountry);
      new MultipleResultResponse(subcountries).saveResponse(context);
   }

   private LexiconCountry getLexiconCountry(SubcountriesByNameRequest request) {
      return querySet.findCountryByISOCode(request.getCountryISOCode());
   }

   private Subcountry[] getSubcountries(SubcountriesByNameRequest request, LexiconCountry lexiconCountry) {
      Subcountry[] subcountries = new Subcountry[0];
      if(lexiconCountry != null) {
         subcountries = querySet.findSubcountriesByWildcardableSubcountryName(lexiconCountry.getPublicKey(), request.getWildcardableSubcountryName());
         setCountryInformation(lexiconCountry, subcountries);
      }
      return subcountries;
   }

   private void setCountryInformation(LexiconCountry lexiconCountry, Subcountry[] subcountries) {
      for (Subcountry subcountry : subcountries) {
         subcountry.setCountryISOCode(lexiconCountry.getISOCode());
         subcountry.setDescription(lexiconCountry.getSubCountryDescription());
      }
   }
}
