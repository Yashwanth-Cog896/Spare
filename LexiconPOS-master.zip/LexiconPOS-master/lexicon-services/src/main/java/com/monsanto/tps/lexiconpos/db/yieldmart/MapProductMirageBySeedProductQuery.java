package com.monsanto.tps.lexiconpos.db.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.product.common.domain.yieldmart.YieldMartProduct;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 3, 2005
 * Time: 12:38:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class MapProductMirageBySeedProductQuery extends AbstractPersistentStoreSingleResultQuery {
    private final int mirageSeedProductID;

    public MapProductMirageBySeedProductQuery(int mirageSeedProductID) {
        this.mirageSeedProductID = mirageSeedProductID;
    }

    public YieldMartProduct getProductMapping()
            throws WrappingException {
        return (YieldMartProduct) execute();
    }

    public YieldMartProduct getProductMapping(PersistentStoreConnection yieldMartConn)
            throws WrappingException {
        return (YieldMartProduct) execute(yieldMartConn);
    }

    protected Object createObjectFromRow(PersistentStoreResultSetRow row)
            throws WrappingException {
        return new YieldMartProductPSRowImpl(row);
    }

    protected String getSQL()
            throws WrappingException {
        return new SQLPropFile(YieldMartSQL.class).getSQL(YieldMartSQL.SELECT_BY_SEED_PRODUCT_ID);
    }

    protected Object[] getBindVariables()
            throws WrappingException {
        return new Object[]{Integer.valueOf(mirageSeedProductID)};
    }

    protected ConnectionFactoryProperties getConnectionFactoryProperties() {
        return new YieldMartConnectionFactoryProperties();
    }

    public int getMirageSeedProductID() {
        return mirageSeedProductID;
    }
}
