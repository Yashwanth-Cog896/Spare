package com.monsanto.tps.lexiconpos.db;

import com.monsanto.tcc.lexiconcommon.db.factories.PersistentStoreConnectionFactory;
import com.monsanto.tps.lexiconpos.util.log.LogWriter;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jun 7, 2006
 * Time: 2:48:56 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class MultiSystemPersistentStoreConnection
{
   protected abstract Map getFactoryMap();

   private boolean transactionStarted = false;
   private Map factoryMap;
   private Map connectionMap;

   protected MultiSystemPersistentStoreConnection() {
      factoryMap = getFactoryMap();
      connectionMap = getConnectionMap(factoryMap);
   }

   private Map getConnectionMap(Map factoryMap) {
      HashMap hashMap = new HashMap();
      for (Iterator iter = factoryMap.keySet().iterator(); iter.hasNext();) {
         hashMap.put(iter.next(), null);
      }
      return hashMap;
   }

   public PersistentStoreConnection getConnection(Object key)
      throws WrappingException
   {
      PersistentStoreConnection connection = getConnectionFromMap(key);
      if (connection == null) {
         connection = getConnectionFromFactory(key);
         startTransactionOnNewConnection(connection);
         putConnectionInMap(key, connection);
      }
      return connection;
   }

   protected PersistentStoreConnection getConnectionFromMap(Object key) {
      return (PersistentStoreConnection)connectionMap.get(key);
   }

   protected PersistentStoreConnection getConnectionFromFactory(Object key)
      throws WrappingException
   {
      PersistentStoreConnectionFactory factory = getFactoryFromMap(key);
      if (factory == null) {
         throw new WrappingException(new Exception("Can't find connection factory based on key:" + key.toString()));
      }
      return factory.getConnection();
   }

   protected PersistentStoreConnectionFactory getFactoryFromMap(Object key) {
      return (PersistentStoreConnectionFactory)factoryMap.get(key);
   }

   private void startTransactionOnNewConnection(PersistentStoreConnection connection)
      throws WrappingException
   {
      if (transactionStarted) {
         connection.beginTransaction();
      }
   }

   private void putConnectionInMap(Object key, PersistentStoreConnection connection) {
      connectionMap.put(key, connection);
   }

   public void close() {
      transactionStarted = false;
      for (Iterator iter = connectionMap.values().iterator(); iter.hasNext();) {
         closeConnection((PersistentStoreConnection)iter.next());
      }
      connectionMap = getConnectionMap(factoryMap);
   }

   protected void closeConnection(PersistentStoreConnection conn) {
      try {
         if (conn != null) {
            conn.close();
         }
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(LogWriter.getCategory(this), e);
      }
   }

   public void beginTransaction()
      throws WrappingException
   {
      transactionStarted = true;
      for (Iterator iter = connectionMap.values().iterator(); iter.hasNext();) {
         beginTransaction((PersistentStoreConnection)iter.next());
      }
   }

   private void beginTransaction(PersistentStoreConnection conn)
      throws WrappingException
   {
      if (conn != null) {
         conn.beginTransaction();
      }
   }

   public void endTransaction()
      throws WrappingException
   {
      transactionStarted = false;
      try {
         for (Iterator iter = connectionMap.values().iterator(); iter.hasNext();) {
            endTransaction((PersistentStoreConnection)iter.next());
         }
      }
      catch (WrappingException e) {
         rollbackTransaction();
         throw e;
      }
   }

   private void endTransaction(PersistentStoreConnection conn)
      throws WrappingException
   {
      if (conn != null) {
         conn.endTransaction();
      }
   }

   public void rollbackTransaction() {
      transactionStarted = false;
      for (Iterator iter = connectionMap.values().iterator(); iter.hasNext();) {
         rollbackTransaction((PersistentStoreConnection)iter.next());
      }
   }

   private void rollbackTransaction(PersistentStoreConnection conn) {
      try {
         if (conn != null) {
            conn.rollbackTransaction();
         }
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(LogWriter.getCategory(this), e);
      }
   }
}
