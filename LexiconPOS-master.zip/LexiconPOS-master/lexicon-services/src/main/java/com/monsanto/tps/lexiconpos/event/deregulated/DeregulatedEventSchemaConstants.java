package com.monsanto.tps.lexiconpos.event.deregulated;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 19, 2006
 * Time: 2:12:24 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DeregulatedEventSchemaConstants
{
   String NAMESPACE = "http://www.monsanto.com/lexicon/Event";
   String SCHEMA_LOC = "xsd/lexicon/Event.xsd";

   String EVENTS_ELEM_NAME = "Events";
   String EVENT_ELEM_NAME = "Event";
   String COUNTRY_PUBKEY_ELEM_NAME = "CountryPubkey";
   String SUB_COUNTRY_PUBKEY_ELEM_NAME = "SubCountryPubkey";

   String DEREG_EVENT_RESP_ELEM_NAME = "DeregulatedEventServiceResponse";
   String DEREGULATED_ELEM_NAME = "Deregulated";
   String ERROR_ELEM_NAME = "Error";
}
