package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.tps.lexiconpos.util.strings.GeographyStringTable;
import com.monsanto.Util.StringUtils;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 7:14:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubSubCountryByNameRequestParser
    extends GeographyRequestParser
{
    public static String getInvalidRequestError() {
        return new GeographyStringTable().getString(GeographyStringTable.INVALID_SUBSUBCOUNTRY_NAME_REQUEST);
    }

    protected GeographyRequestModel parse(Element root)
        throws InvalidGeographyRequestException
    {
        String subCountryPubkey = getSubCountryPubkey(root);
        String subSubCountryName = getSubSubCountryName(root);
        subSubCountryName = validateSubSubCountryName(subSubCountryName);
        return new GetSubSubCountryByNameRequestModel(subCountryPubkey, subSubCountryName);
    }

    private String validateSubSubCountryName(String subSubCountryName)
        throws InvalidGeographyRequestException
    {
        if (StringUtils.isNullOrEmpty(subSubCountryName)) {
            throw new InvalidGeographyRequestException(getInvalidRequestError());
        }
        else {
            return subSubCountryName.toUpperCase();
        }
    }
}
