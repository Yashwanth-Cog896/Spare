package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.businessaccount.externalcontact.ExternalContact;
import com.monsanto.tps.lexiconpos.businessaccount.externalcontact.ExternalContactDOMImpl;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.transform.TransformerException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 23, 2007
 * Time: 10:57:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class IRDExternalContactServiceResponse
{
   private final Document doc;

   public IRDExternalContactServiceResponse(Document doc) {
      this.doc = doc;
   }

   public ExternalContact[] getExternalContacts() {
      Element root = getRootElement();
      List externalContacts = new ArrayList();
      NodeList rowElements = getRowElements(root);
      for (int i = 0; i < rowElements.getLength(); i++) {
         Element rowElement = (Element)rowElements.item(i);
         externalContacts.add(getExternalContact(rowElement));
      }
      return (ExternalContact[])externalContacts.toArray(new ExternalContact[externalContacts.size()]);
   }

   public boolean isErrorResponse() {
      return !StringUtils.isNullOrEmpty(getErrorMsg());
   }

   public String getErrorMsg() {
      Element root = getRootElement();
      try {
         Node errorNode = XPathAPI.selectSingleNode(root,
            BusinessAccountSchemaConstants.RESPONSE_ELEM_NAME + "/" + BusinessAccountSchemaConstants.ERROR_ELEM_NAME);
         return errorNode == null ? null :
            DOMUtil.getChildValue(errorNode, BusinessAccountSchemaConstants.MSG_ELEM_NAME);
      }
      catch (TransformerException e) {
         return e.getMessage();
      }
   }

   private ExternalContact getExternalContact(Element parent) {
      return new ExternalContactDOMImpl(parent);
   }
   private NodeList getRowElements(Element parent) {
      return parent.getElementsByTagName(BusinessAccountSchemaConstants.ROW_ELEM_NAME);
   }
   private Element getRootElement() {
      return doc.getDocumentElement();
   }
}
