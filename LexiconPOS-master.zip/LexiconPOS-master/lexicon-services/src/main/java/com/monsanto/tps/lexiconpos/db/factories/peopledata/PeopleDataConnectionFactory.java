package com.monsanto.tps.lexiconpos.db.factories.peopledata;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 2, 2006
 * Time: 3:37:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class PeopleDataConnectionFactory
   extends BasicConnectionFactory
{
   public PeopleDataConnectionFactory() {
      super(new PeopleDataConnectionFactoryProperties());
   }
}

