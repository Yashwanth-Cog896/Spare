package com.monsanto.tps.lexiconpos.geography.zipcode;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 10:02:14 AM
 */
public class ZipCodeValidationRequestParser
	implements ZipCodeValidationSchemaConstants
{
	public ZipCodeValidationRequestModel parse(Document requestDoc) {
		Element docElement = requestDoc.getDocumentElement();
		String zipCode = getZipCode(docElement);
		return new ZipCodeValidationRequestModel(zipCode);
	}

	private String getZipCode(Element docElement) {
		return DOMUtil.getChildValue(docElement, REQUEST_ZIP_CODE_ELEM_NAME);
	}
}
