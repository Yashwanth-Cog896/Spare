package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactPhone;

import java.util.Collection;

/**
 * nbwald - Jul 31, 2008 3:53:04 PM
 */
public enum ContactPhoneType
{
   BUSINESS (1),
   FAX (2),
   PAGER (6),
   CELL (7);

   private final long contactPhoneTypeId;
   private ContactPhoneType(long contactPhoneTypeId) {
      this.contactPhoneTypeId = contactPhoneTypeId;
   }

   public ContactPhone findIn(Collection<ContactPhone> contactPhones) {
      return contactPhones == null ? null : findInNonNullContactPhones(contactPhones);
   }

   private ContactPhone findInNonNullContactPhones(Collection<ContactPhone> contactPhones) {
      for (ContactPhone contactPhone : contactPhones) {
         if(this.isTheTypeOf(contactPhone)) {
            return contactPhone;
         }
      }
      return null;
   }

   private boolean isTheTypeOf(ContactPhone contactPhone) {
      return contactPhone.getContactPhoneTypeId() == contactPhoneTypeId;
   }
}
