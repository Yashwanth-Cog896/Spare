/*
 PermitProtocolLookup was created on Oct 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.protocol;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.PermitProtocol;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Oct 6, 2006 11:50:58 AM
 */
public class PermitProtocolLookup
   extends AbstractPersistentStoreSingleResultQuery
{
   private final long permitID;
   private final long siteID;
   private final long personID;
   private final long releaseSiteID;

   public PermitProtocolLookup(long permitID, long siteID, long personID, long releaseSiteID) {
      this.permitID = permitID;
      this.siteID = siteID;
      this.personID = personID;
      this.releaseSiteID = releaseSiteID;
   }

   public PermitProtocol getPermitProtocol(PersistentStoreConnection bfcConn) throws WrappingException {
      return (PermitProtocol) execute(bfcConn);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new PermitProtocolPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(BFCPermitProtocolSQL.class).getSQL(BFCPermitProtocolSQL.SELECT_PERMITPROTOCOL);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(permitID), new Long(siteID), new Long(personID), new Long(releaseSiteID)};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new BFCConnectionFactoryProperties();
   }
}