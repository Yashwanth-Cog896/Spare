package com.monsanto.tps.lexiconpos.chemical.service.pos;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.db.mirage.MirageChemProdLookup;
import com.monsanto.tps.lexiconpos.db.mirage.MirageChemProdLookupDBImpl;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageChemProd;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 22, 2005
 * Time: 2:29:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetChemicalMaterialRequestProcessor
{
    private MirageChemProdLookup lookup;
    
    public MirageChemProd[] processRequest(
        ChemicalProductRequest requestModel,
        TPSPersistentStoreConnection conn)
        throws WrappingException
    {
        MirageChemProd[] products = null;
        String wildcardedName = requestModel.getProductName();
        PersistentStoreConnection mirageConn = conn.getMirageConnection();
        MaterialClassificationType classification = requestModel.getClassification();
        if (classification == null) {
            products = getAllChemicalProducts(wildcardedName, mirageConn);
        }
        else if (MaterialClassificationType.COML_PROD.equals(classification)) {
            products = getCommercialProdcts(wildcardedName, mirageConn);
        }
        else if (MaterialClassificationType.FORMULATION.equals(classification)) {
            products = getFormulations(wildcardedName, mirageConn);
        }
        else if (MaterialClassificationType.ACTIVE_INGRED.equals(classification)) {
            products = getActiveIngredients(wildcardedName, mirageConn);
        }
        return products;
    }

    private MirageChemProd[] getAllChemicalProducts(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException
    {
        MirageChemProd[] comlProducts = getCommercialProdcts(wildcardedName, mirageConn);
        MirageChemProd[] formulations = getFormulations(wildcardedName, mirageConn);
        MirageChemProd[] activeIngreds = getActiveIngredients(wildcardedName, mirageConn);
        return mergeArrays(comlProducts, formulations, activeIngreds);
    }

    private MirageChemProd[] mergeArrays(
        MirageChemProd[] comlProducts,
        MirageChemProd[] formulations,
        MirageChemProd[] activeIngreds)
    {
        int size = comlProducts.length + formulations.length + activeIngreds.length;
        ArrayList productList = new ArrayList(size);
        productList.addAll(Arrays.asList(comlProducts));
        productList.addAll(Arrays.asList(formulations));
        productList.addAll(Arrays.asList(activeIngreds));
        return (MirageChemProd[])productList.toArray(new MirageChemProd[size]);
    }

    private MirageChemProd[] getCommercialProdcts(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException
    {
        MirageChemProdLookup mirageChemProdLookup = getMirageLookup();
        return mirageChemProdLookup.getCommercialProdcts(wildcardedName, mirageConn);

    }

    private MirageChemProd[] getFormulations(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException
    {
        MirageChemProdLookup mirageChemProdLookup = getMirageLookup();
        return mirageChemProdLookup.getFormulations(wildcardedName, mirageConn);

    }

    private MirageChemProd[] getActiveIngredients(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException
    {
        MirageChemProdLookup lookup = getMirageLookup();
        return lookup.getActiveIngredients(wildcardedName, mirageConn);
    }

    protected MirageChemProdLookup getMirageLookup() {
        if (lookup == null) {
            lookup = new MirageChemProdLookupDBImpl();
        }
        return lookup;
    }
}
