package com.monsanto.tps.lexiconpos.crop;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 11, 2006
 * Time: 4:23:23 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CropSchemaConsts
{
   String NS_URI = "http://www.monsanto.com/lexicon/entity";
   String SCHEMA_LOC = "xsd/lexicon/Crop.xsd";

   String ROOT_REQUEST_ELEM = "CropRequest";
   String ROOT_RESPOSNE_ELEM = "CropResponse";
   String CROPS_ELEM = "Crops";
   String CROP_ELEM = "Crop";

   String PUBKEY_ATTR = "PublicKey";
}
