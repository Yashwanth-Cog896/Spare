package com.monsanto.tps.lexiconpos.chemical.domain.mirage;

import com.monsanto.tps.lexiconpos.chemical.service.pos.ChemicalMaterialSchemaConstants;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 22, 2005
 * Time: 10:02:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageActiveIngredient
    extends MirageChemProdImpl
{
    public String getMaterialClassification() {
        return ChemicalMaterialSchemaConstants.ACT_INGRED_ELEM_NAME;
    }

    public String[] getActiveIngredients() {
        return null;
    }
    public void setActiveIngredients(String[] activeIngredients) {}


    public long getFormulatedAmount() {
       return 0;
    }
    public void setFormulatedAmount(long amount) {}

    public String getFormulatedAmountName() {
       return null;
    }
    public void setFormulatedAmountName(String name) {}

    public String getFormulationDesignation() {
       return null;
    }
    public void setFormulationDesignation(String x) {}
}
