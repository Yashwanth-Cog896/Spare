package com.monsanto.tps.lexiconpos.businessaccount.artemis.contract;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;

/**
 * @author: rrchak1
 */
public class ExternalContactByBusinessGeographySearchCriteriaRequest
{
   private final ServiceProcessContext context;

   public ExternalContactByBusinessGeographySearchCriteriaRequest(ServiceProcessContext context) {
      this.context = context;
   }

   public ExternalContactByBusinessGeographySearchCriteria getSearchCriteria() {
      return (ExternalContactByBusinessGeographySearchCriteria) context.getRequestPayload();
   }
}
