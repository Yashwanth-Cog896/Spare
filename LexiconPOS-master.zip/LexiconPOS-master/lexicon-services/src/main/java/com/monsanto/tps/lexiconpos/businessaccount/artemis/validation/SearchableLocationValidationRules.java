package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.contact.SearchableLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jun 8, 2008 12:17:22 PM
 */
public class SearchableLocationValidationRules
{
   public List<? extends Rule<String>> getSearchableLocationRules(SearchableLocation searchableLocation) {
      List<Rule<String>> rules = new ArrayList<Rule<String>>();
      if(searchableLocation != null) {
         rules.add(new MustSpecifyCountryAndSubcountryIfSearchingByLocationRule(searchableLocation));
         rules.add(new FieldIsNotWildcardableRule("Country", searchableLocation.getCountryName()));
         rules.add(new FieldIsNotWildcardableRule("Sub-country", searchableLocation.getSubcountryCode()));
         rules.add(new FieldIsNotFullyWildcardedRule("Sub-sub-country", searchableLocation.getSubsubcountryName()));
         rules.add(new FieldIsNotFullyWildcardedRule("City", searchableLocation.getCity()));
      }
      return rules;
   }
}
