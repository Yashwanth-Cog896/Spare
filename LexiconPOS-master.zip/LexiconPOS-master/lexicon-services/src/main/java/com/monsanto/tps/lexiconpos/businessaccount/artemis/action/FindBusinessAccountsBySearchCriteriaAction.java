package com.monsanto.tps.lexiconpos.businessaccount.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount.AccountCollection;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.contract.BusinessAccountSearchCriteriaRequest;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service.IrdBusinessAccountService;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.businessaccount.BusinessAccountSearchCriteriaValidator;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;

/**
 * nbwald - May 14, 2008 5:14:01 PM
 */
public class FindBusinessAccountsBySearchCriteriaAction
   extends AbstractArtemisServiceAction
{
   private IrdBusinessAccountService service;
   private BusinessAccountSearchCriteriaValidator validator;

   public FindBusinessAccountsBySearchCriteriaAction(IrdBusinessAccountService service, BusinessAccountSearchCriteriaValidator validator) {
      this.service = service;
      this.validator = validator;
   }

   public void process(ServiceProcessContext context)
      throws Exception
   {
      BusinessAccountSearchCriteriaRequest request = new BusinessAccountSearchCriteriaRequest(context);
      BusinessAccountSearchCriteria searchCriteria = request.getSearchCriteria();
      validator.validate(searchCriteria);
      Acct[] irdAccts = service.findBySearchCriteria(searchCriteria);
      AccountCollection accountCollection = new AccountCollection(irdAccts);
      new MultipleResultResponse(accountCollection.getBusinessAccounts()).saveResponse(context);
   }
}
