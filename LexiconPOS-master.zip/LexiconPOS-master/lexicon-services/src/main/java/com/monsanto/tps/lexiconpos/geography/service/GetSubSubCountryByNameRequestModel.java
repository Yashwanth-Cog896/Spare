package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 6:43:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubSubCountryByNameRequestModel
    implements GeographyRequestModel
{
    private final String subCountryPubkey;
    private final String subSubCountryName;

    public GetSubSubCountryByNameRequestModel(
        String subCountryPubkey,
        String subSubCountryName)
    {
        this.subCountryPubkey = subCountryPubkey;
        this.subSubCountryName = subSubCountryName;
    }

    public String getSubCountryPubkey() {
        return subCountryPubkey;
    }
    public String getSubSubCountryName() {
        return subSubCountryName;
    }

    public String getCountryName() {
        return null;
    }
    public String getCountryAbbr() {
        return null;
    }
    public String getCountryPubkey() {
        return null;
    }
    public String getSubCountryName()  {
        return null;
    }
    public String getSubCountryAbbr() {
        return null;
    }
}
