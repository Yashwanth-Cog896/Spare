package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSiteSearchRequest;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: Oct 11, 2010
 * Time: 2:13:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class SiteSearchSQLBuilder {

    private final BFCSiteSearchRequest siteSearchRequest;

    public SiteSearchSQLBuilder(BFCSiteSearchRequest siteSearchRequest) {
        this.siteSearchRequest = siteSearchRequest;
    }

    public String buildSql()
            throws WrappingException {
        String sql = addSelectFromStrut() + " WHERE " +
                addStatusCondition() + addFarmNameCondition() + addAddressCondition() +
                addCityCondition() + addIslandTownshipCondition() + addSubSubCountryCondition() +
                addSubCountryCondition() + addCountryCondition() + addPostalCodeCondition();
        return trimSql(sql);
    }

    private String addSelectFromStrut() throws WrappingException {
        return getSQLPropFile().getSQL(BFCSiteSQL.SITE_SELECT_FROM_STRUT);
    }

    private String addStatusCondition() throws WrappingException {
        return getSQLPropFile().getSQL(BFCSiteSQL.SITE_STATUS_CONDITION) + " AND ";
    }

    private String addFarmNameCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getFarmNames(), BFCSiteSQL.SITE_FARM_NAME_CONDITION);
    }

    private String addAddressCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getFullAddresses(), BFCSiteSQL.SITE_ADDRESS_CONDITION);
    }

    private String addCityCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getCityNames(), BFCSiteSQL.SITE_CITY_CONDITION);
    }

    private String addIslandTownshipCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getIslandTownshipNames(), BFCSiteSQL.SITE_ISLAND_TOWNSHIP_CONDITION);
    }

    private String addSubSubCountryCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getSubSubCountryNames(), BFCSiteSQL.SITE_SUB_SUB_COUNTRY_CONDITION);
    }

    private String addSubCountryCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getSubCountryAbbrs(), BFCSiteSQL.SITE_SUB_COUNTRY_CONDITION);
    }

    private String addCountryCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getCountryAbbrs(), BFCSiteSQL.SITE_COUNTRY_CONDITION);
    }

    private String addPostalCodeCondition() throws WrappingException {
        return addCondition(siteSearchRequest.getPostalCodes(), BFCSiteSQL.SITE_POSTAL_CODE_CONDITION);
    }

    private String addCondition(String[] values, String sqlCondition)
            throws WrappingException {
        StringBuffer buffer = new StringBuffer();
        if (values != null && values.length > 0) {
            buffer.append("(");
            for (int i = 0; i < values.length; i++) {
                if (i != 0) {
                    buffer.append(" OR ");
                }
                buffer.append(getSQLPropFile().getSQL(sqlCondition));
            }
            buffer.append(") AND ");
        }
        return buffer.toString();
    }

    private String trimSql(String sqlStr) {
        sqlStr = sqlStr.trim();
        if (sqlStr.endsWith("AND")) {
            return sqlStr.substring(0, sqlStr.length() - 3);
        }
        return sqlStr.trim();
    }

    private SQLPropFile getSQLPropFile() {
        return new SQLPropFile(BFCSiteSQL.class);
    }

}
