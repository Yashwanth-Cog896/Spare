package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:46:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessAccountController
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return BusinessAccountSchemaConstants.SCHEMA_SRC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      CompanyRequest request = getCompanyRequest(inputDocument);
      Company[] companies = getCompanies(request);
      return renderResponse(companies);
   }

   private CompanyRequest getCompanyRequest(Document inputDocument) {
      return new CompanyRequestDOMImpl(inputDocument);
   }

   private Company[] getCompanies(CompanyRequest request)
      throws WrappingException
   {
      BusinessAccountHandler process = new BusinessAccountHandler();
      return process.getCompanies(request);
   }

   private Document renderResponse(Company[] companies) {
      CompanyResponseDocumentRenderer renderer = new CompanyResponseDocumentRenderer(companies);
      return renderer.render();
   }
}