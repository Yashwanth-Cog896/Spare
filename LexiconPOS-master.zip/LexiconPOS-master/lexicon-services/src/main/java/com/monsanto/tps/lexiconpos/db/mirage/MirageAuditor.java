package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 15, 2004
 * Time: 10:24:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageAuditor
{
   public static final String AUDIT_USER = "LexiconPOS";

   public static final String INSERT_SP_EVENT = "CREATE SEED PRODUCT";
   public static final String UPDATE_SP_EVENT = "UPDATE SEED PRODUCT";
   public static final String INSERT_MAT_EVENT = "CREATE SEED PRODUCT MATURITY";
   public static final String UPDATE_MAT_EVENT = "UPDATE SEED PRODUCT MATURITY";
   public static final String DELETE_MAT_EVENT = "DELETE SEED PRODUCT MATURITY";

   public int auditCreateSeedProduct(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return audit(mirageConn, INSERT_SP_EVENT);
   }

   public int auditUpdateSeedProduct(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return audit(mirageConn, UPDATE_SP_EVENT);
   }

   public int auditCreateProductMaturity(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return audit(mirageConn, INSERT_MAT_EVENT);
   }

   public int auditUpdateProductMaturity(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return audit(mirageConn, UPDATE_MAT_EVENT);
   }

   public int auditDeleteProductMaturity(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return audit(mirageConn, DELETE_MAT_EVENT);
   }

   private int audit(PersistentStoreConnection mirageConn, String auditEvent)
      throws WrappingException
   {
      int auditID = getAuditID(mirageConn);
      String sql = getSQLPropFile().getSQL(MirageSQL.INSERT_AUDIT);
      PersistentStoreStatement statement = mirageConn.prepareStatement(sql);
      try {
         statement.setParam(1, auditID);
         statement.setParam(2, new Date());
         statement.setParam(3, AUDIT_USER);
         statement.setParam(4, AUDIT_USER);
         statement.setParam(5, auditEvent);
         statement.setParam(6, auditEvent);
         statement.setParam(7, auditEvent);
         statement.executeInsert();
      }
      finally {
         statement.close();
      }
      return auditID;
   }

   private int getAuditID(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return new MirageObjectIDBroker().nextID(mirageConn);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MirageSQL.class);
   }
}
