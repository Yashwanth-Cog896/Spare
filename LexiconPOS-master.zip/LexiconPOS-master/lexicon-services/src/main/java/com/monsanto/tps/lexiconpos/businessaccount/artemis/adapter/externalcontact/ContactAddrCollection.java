package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactAddr;
import com.monsanto.tps.lexicon.contact.AddressRecord;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * nbwald - Aug 1, 2008 2:16:55 PM
 */
public class ContactAddrCollection
{
   private final Collection<ContactAddr> contactAddrs;

   public ContactAddrCollection(Collection<ContactAddr> contactAddrs) {
      this.contactAddrs = contactAddrs;
   }

   public AddressRecord[] getAddressRecords() {
      return contactAddrs == null ? new AddressRecord[0] : getAddressRecordsFromNonNullContactAddrs();
   }

   private AddressRecord[] getAddressRecordsFromNonNullContactAddrs() {
      List<AddressRecord> addressRecords = new ArrayList<AddressRecord>();
      for (ContactAddr contactAddr : contactAddrs) {
         AddressRecordBuilder builder = new AddressRecordBuilder();
         addressRecords.add(builder.build(contactAddr));
      }
      return addressRecords.toArray(new AddressRecord[addressRecords.size()]);
   }
}
