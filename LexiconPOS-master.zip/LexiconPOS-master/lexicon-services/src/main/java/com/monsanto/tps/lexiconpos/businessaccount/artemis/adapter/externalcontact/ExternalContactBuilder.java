package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactAddr;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactEmail;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactFunction;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactPhone;
import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.Email;
import com.monsanto.tps.lexicon.person.ExternalContact;

import java.util.Set;

/**
 * nbwald - Jul 30, 2008 3:36:43 PM
 */
public class ExternalContactBuilder
{
   public ExternalContact build(Contact contact) {
      ExternalContact externalContact = new ExternalContact();
      setAllFields(contact, externalContact);
      return externalContact;
   }

   private void setAllFields(Contact contact, ExternalContact externalContact) {
      setSimpleFields(contact, externalContact);
      setCollectionFields(contact, externalContact);
      setAccountFields(externalContact, contact.getAcct());
      setPhoneNumberFields(externalContact, contact.getContactPhones());
   }

   private void setSimpleFields(Contact contact, ExternalContact externalContact) {
      externalContact.setContactID(String.valueOf(contact.getContactId()));
      externalContact.setFirstName(contact.getName1());
      externalContact.setMiddleName(contact.getName2());
      externalContact.setLastName(contact.getName3());
      externalContact.setJobTitle(contact.getJobTitle());
   }

   private void setCollectionFields(Contact contact, ExternalContact externalContact) {
      externalContact.setEmail(extractEmail(contact.getContactEmails()));
      externalContact.setContactTypes(extractContactTypes(contact.getContactFunctions()));
      externalContact.setAddressRecords(extractAddressRecords(contact.getContactAddrs()));
   }

   private void setPhoneNumberFields(ExternalContact externalContact, Set<ContactPhone> contactPhones) {
      PhoneNumberBuilder builder = new PhoneNumberBuilder();
      externalContact.setPhone(builder.build(ContactPhoneType.BUSINESS.findIn(contactPhones)));
      externalContact.setCell(builder.build(ContactPhoneType.CELL.findIn(contactPhones)));
      externalContact.setFax(builder.build(ContactPhoneType.FAX.findIn(contactPhones)));
      externalContact.setPager(builder.build(ContactPhoneType.PAGER.findIn(contactPhones)));
   }

   private AddressRecord[] extractAddressRecords(Set<ContactAddr> contactAddrs) {
      ContactAddrCollection collection = new ContactAddrCollection(contactAddrs);
      return collection.getAddressRecords();
   }

   private String[] extractContactTypes(Set<ContactFunction> contactFunctions) {
      ContactFunctionCollection collection = new ContactFunctionCollection(contactFunctions);
      return collection.getContactTypes();
   }

   private Email extractEmail(Set<ContactEmail> contactEmails) {
      EmailCollection collection = new EmailCollection(contactEmails);
      return collection.getEmail();
   }

   private void setAccountFields(ExternalContact externalContact, Acct account) {
      if(account != null) {
         externalContact.setBusinessAccountID(String.valueOf(account.getAcctId()));
         externalContact.setCompanyName(account.getName1());
      }
   }
}
