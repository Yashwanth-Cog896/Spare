package com.monsanto.tps.lexiconpos.db.factories.bfc;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryPropertiesLexiconImpl;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 12, 2006
 * Time: 3:20:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class BFCConnectionFactoryProperties
   extends ConnectionFactoryPropertiesLexiconImpl
{
   public static final String INSTANCE_NAME = "BFC";
   private static final String PROP_FILENAME = "BFC_DB.properties";

   public String getInstanceName() {
      return INSTANCE_NAME;
   }
   public Properties loadProperties() throws IOException {
      return PropertyManager.getInstance().getNonCachedProperties(getClass(), PROP_FILENAME);
   }
}
