package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;

/**
 * Filename:    ExternalContactByBusinessGeographySearchCriteriaValidator.java
 * Last Change: rrchak1 On:	Jul 29, 2008
 *
 * @author: rrchak1
 */
public interface ExternalContactByBusinessGeographySearchCriteriaValidator {
    public void validate(ExternalContactByBusinessGeographySearchCriteria searchCriteria);
}
