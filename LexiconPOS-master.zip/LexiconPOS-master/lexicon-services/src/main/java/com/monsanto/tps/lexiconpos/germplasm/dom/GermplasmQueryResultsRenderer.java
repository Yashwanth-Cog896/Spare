/*
 GermplasmQueryResultsRenderer was created on Jan 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.tps.lexiconpos.germplasm.model.ProductGermplasmWithSources;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * nbwald Jan 19, 2007 3:12:31 PM
 */
public class GermplasmQueryResultsRenderer
{
   private final Element parent;
   private final ProductGermplasmWithSources[] queryGermplasms;
   private final int matchedGP;
   private final int matchedGPFromGPCriteria;

   public GermplasmQueryResultsRenderer(Element parent, ProductGermplasmWithSources[] queryGermplasms, int matchedGP, int matchedGPFromGPCriteria) {
      this.parent = parent;
      this.queryGermplasms = queryGermplasms;
      this.matchedGP = matchedGP;
      this.matchedGPFromGPCriteria = matchedGPFromGPCriteria;
   }

   public void render() {
      renderResultCounts();
      renderResultItem();
   }

   private void renderResultCounts() {
      DOMUtil.setAttribute(parent, GermplasmDocTags.ITEMS_MATCHED_ATTR_NAME, matchedGP);
      DOMUtil.setAttribute(parent, GermplasmDocTags.ITEMS_RETURNED_ATTR_NAME, queryGermplasms.length);
   }

   private void renderResultItem() {
      Element resultElem = DOMUtil.addChildElementWithNS(GermplasmQueryDocTags.NS_URI, parent, GermplasmQueryDocTags.QUERY_ITEM_RESULT_ELEM_NAME);
      DOMUtil.setAttribute(resultElem, GermplasmQueryDocTags.ITEM_ID_ATTR_NAME, 0);
      DOMUtil.setAttribute(resultElem, GermplasmDocTags.ITEM_MATCHED_FROM_GP_CRITERIA_ATTR_NAME, matchedGPFromGPCriteria);
      renderGermplasms(resultElem);
   }

   private void renderGermplasms(Element resultElem) {
      Element germplasmsElem = DOMUtil.addChildElementWithNS(GermplasmQueryDocTags.NS_URI, resultElem, GermplasmDocTags.GERMPLASM_LIST_ELEM_NAME);
      renderEachGermplasm(germplasmsElem);
   }

   private void renderEachGermplasm(Element germplasmsElem) {
      for (ProductGermplasmWithSources productGermplasmWithSources : queryGermplasms) {
         QueryGermplasmRenderer renderer = new QueryGermplasmRenderer(germplasmsElem, productGermplasmWithSources);
         renderer.render();
      }
   }
}