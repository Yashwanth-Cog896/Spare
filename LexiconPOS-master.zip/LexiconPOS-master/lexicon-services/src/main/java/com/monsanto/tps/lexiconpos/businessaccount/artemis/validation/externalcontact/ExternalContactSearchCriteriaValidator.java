package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * nbwald - Jun 8, 2008 12:11:51 PM
 */
public interface ExternalContactSearchCriteriaValidator
{
   void validate(ExternalContactSearchCriteria criteria);
}
