/*
 ComplianceSitePSRowImpl was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.ComplianceSite;

import java.util.Date;

/**
 * nbwald Oct 12, 2006 2:43:42 PM
 */
public class ComplianceSitePSRowImpl
   implements ComplianceSite
{
   private final String addressType;
   private final boolean active;
   private final boolean cancelled;
   private final boolean dropped;
   private final Date packetSent;
   private final Long releaseSiteId;
   private final long effectiveSiteId;
   private final long complianceSiteId;

   public ComplianceSitePSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      active = getActive(row.getLong(getAlias(BFCComplianceSiteSQL.ALIAS_SITE_STATUS)));
      dropped = getDropped(row.getLong(getAlias(BFCComplianceSiteSQL.ALIAS_DROPPED)));
      cancelled = getCancelled(row.getLong(getAlias(BFCComplianceSiteSQL.ALIAS_CANCELLED)));
      addressType = row.getString(getAlias(BFCComplianceSiteSQL.ALIAS_ADDRESS_TYPE));
      packetSent = row.getDate(getAlias(BFCComplianceSiteSQL.ALIAS_PACKET_SENT));
      releaseSiteId = row.getLONG(getAlias(BFCComplianceSiteSQL.ALIAS_RELEASESITE_ID));
      complianceSiteId = row.getLong(getAlias(BFCComplianceSiteSQL.ALIAS_COMPLIANCE_SITE_ID));
      effectiveSiteId = row.getLong(getAlias(BFCComplianceSiteSQL.ALIAS_EFFECTIVE_SITE_ID));
   }

   public String getAddressType() {
      return addressType;
   }

   public boolean isActive() {
      return active;
   }

   public boolean isCancelled() {
      return cancelled;
   }

   public boolean isDropped() {
      return dropped;
   }

   public Date getPacketSent() {
      return packetSent;
   }

   public Long getReleaseSiteId() {
      return releaseSiteId;
   }

   public long getEffectiveSiteId() {
      return effectiveSiteId;
   }

   public long getComplianceSiteId() {
      return complianceSiteId;
   }


   private boolean getDropped(long dropped) {
      return toBool(dropped);
   }

   private boolean getCancelled(long cancelled) {
      return toBool(cancelled);
   }

   private boolean getActive(long inactive) {
      return !toBool(inactive);
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return getSQLPropFile().getAlias(propName);
   }

   private boolean toBool(long bfcBoolean) {
      return bfcBoolean == -1;
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(BFCComplianceSiteSQL.class);
   }
}