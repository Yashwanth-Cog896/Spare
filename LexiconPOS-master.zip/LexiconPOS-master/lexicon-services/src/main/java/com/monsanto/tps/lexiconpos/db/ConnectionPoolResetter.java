package com.monsanto.tps.lexiconpos.db;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;

/**
 * <p>Title: ConnectionPoolResetter</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author JLEVRAE
 * @version $Id
 */
public class ConnectionPoolResetter
   extends HttpServlet
{
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
   {
      this.doPost(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
   {
      Writer out = response.getWriter();
      try {
         releaseConnections();
         out.write("Reset Successful");
      }
      catch (Exception e) {
         out.write(e.getMessage());
      }
      finally {
         out.flush();
         out.close();
      }
   }

   public void releaseConnections()
      throws WrappingException
   {
      PersistentStore.dropAllInstances();
   }
}
