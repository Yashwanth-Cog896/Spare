/*
 SubsubcountryQuerySetImpl was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subsubcountry.query;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconCountryByISOCodeQuery;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

/**
 * @author GGSHIV - Jun 10, 2008 3:44:04 PM
 */
public class SubsubcountryQuerySetImpl implements SubsubcountryQuerySet {

   public LexiconCountry findCountryByISOCode(String countryISOCode) {
      LexiconCountryByISOCodeQuery query = new LexiconCountryByISOCodeQuery(countryISOCode);
      return query.find();
   }

   public Subsubcountry[] findSubsubcountriesByWildcardableName(String countryPubkey, String wildcardableSubcountryName, String wildcardableSubsubcountryName) {
      StdWildcardableCriteria subcountryName = new StdWildcardableCriteria(wildcardableSubcountryName);
      StdWildcardableCriteria subsubcountryName = new StdWildcardableCriteria(wildcardableSubsubcountryName);
      SubsubcountriesByWildcardableNameQuery query = new SubsubcountriesByWildcardableNameQuery(countryPubkey, subcountryName, subsubcountryName);
      return query.find();
   }

   public Subsubcountry[] findSubsubcountriesByAbbreviation(String countryPubkey, String[] subcountriesAbbreviation, String wildcardableSubsubcountryName) {
      StdWildcardableCriteria subsubcountryName = new StdWildcardableCriteria(wildcardableSubsubcountryName);
      SubsubcountriesByAbbreviationQuery query = new SubsubcountriesByAbbreviationQuery(countryPubkey, subcountriesAbbreviation, subsubcountryName);
      return query.find();
   }
}