package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.tps.lexiconpos.businessaccount.externalcontact.ExternalContactRequest;
import com.monsanto.tps.lexiconpos.util.service.IRDServiceInvoker;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 23, 2007
 * Time: 10:15:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class IRDExternalContactService
{
   public IRDExternalContactServiceResponse getServiceResult(ExternalContactRequest contactRequest)
      throws WrappingException
   {
      final Document requestDoc = renderRequest(contactRequest);
      Document responseDoc = invokeService(requestDoc);
      return parseResponse(responseDoc);
   }

   protected Document renderRequest(ExternalContactRequest contactRequest) {
      IRDExternalContactServiceReqDocRenderer renderer = new IRDExternalContactServiceReqDocRenderer(contactRequest);
      return renderer.renderRequest();
   }

   protected Document invokeService(final Document requestDoc) throws WrappingException {
      return new IRDServiceInvoker().call(requestDoc);
   }

   private IRDExternalContactServiceResponse parseResponse(Document responseDoc) {
      return new IRDExternalContactServiceResponse(responseDoc);
   }
}
