/*
 GermplasmBatchQueryResultsRenderer was created on Jan 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import org.w3c.dom.Element;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmBatchQueryResults;
import com.monsanto.tps.lexiconpos.germplasm.model.QueryItemResult;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * nbwald Jan 31, 2007 11:20:19 AM
 */
public class GermplasmBatchQueryResultsRenderer {
   private final Element queryResultsElem;
   private final GermplasmBatchQueryResults results;

   public GermplasmBatchQueryResultsRenderer(Element queryResultsElem, GermplasmBatchQueryResults results) {
      this.queryResultsElem = queryResultsElem;
      this.results = results;
   }

   public void render() {
      renderItemsMatched();
      renderItemsReturned();
      renderQueryItemResults();
   }

   private void renderItemsMatched() {
      DOMUtil.setAttribute(queryResultsElem, GermplasmDocTags.ITEMS_MATCHED_ATTR_NAME, results.getItemsMatched());
   }

   private void renderItemsReturned() {
      DOMUtil.setAttribute(queryResultsElem, GermplasmDocTags.ITEMS_RETURNED_ATTR_NAME, results.getItemsReturned());
   }

   private void renderQueryItemResults() {
      QueryItemResult[] queryItemResults = results.getQueryItemResults();
      for (QueryItemResult queryItemResult : queryItemResults) {
         renderQueryItemResult(queryResultsElem, queryItemResult);
      }
   }

   private void renderQueryItemResult(Element queryResultsElem, QueryItemResult queryItemResult) {
      QueryItemResultRenderer renderer = new QueryItemResultRenderer(queryResultsElem, queryItemResult);
      renderer.render();
   }
}