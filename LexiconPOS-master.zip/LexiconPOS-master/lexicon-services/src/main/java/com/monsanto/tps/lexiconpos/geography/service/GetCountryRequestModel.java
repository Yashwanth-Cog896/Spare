package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 5:32:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetCountryRequestModel
    implements GeographyRequestModel
{
    private final String countryName;
    private final String countryAbbr;
    private final String pubKey;

    public GetCountryRequestModel(
        String countryName,
        String countryAbbr,
        String pubKey)
    {
        this.countryName = (!StringUtils.isNullOrEmpty(countryName)) ? countryName.toUpperCase() : null;
        this.countryAbbr = (!StringUtils.isNullOrEmpty(countryAbbr)) ? countryAbbr.toUpperCase() : null;
        this.pubKey = (!StringUtils.isNullOrEmpty(pubKey)) ? pubKey.toUpperCase() : null;
    }

    public String getCountryName() {
        return countryName;
    }
    public String getCountryAbbr() {
        return countryAbbr;
    }

    public String getCountryPubkey() {
        return pubKey;
    }
    public String getSubCountryName() {
        return null;
    }
    public String getSubCountryAbbr() {
        return null;
    }
    public String getSubCountryPubkey() {
        return null;
    }
    public String getSubSubCountryName() {
        return null;
    }
}
