package com.monsanto.tps.lexiconpos.event.bfc.person;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.BFCPerson;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 12, 2006
 * Time: 11:03:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class BFCPersonPSRowImpl
   implements BFCPerson
{
   private final long personId;
   private final String userId;

   public BFCPersonPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      personId = row.getLong(getAlias(BFCPersonSQL.ALIAS_PERSON_ID));
      userId = row.getString(getAlias(BFCPersonSQL.ALIAS_USER_ID));
   }

   public long getPersonId() {
      return personId;
   }
   public String getUserId() {
      return userId;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return getSQLPropFile().getAlias(propName);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(BFCPersonSQL.class);
   }
}
