package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 13, 2004
 * Time: 10:55:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasObjectIDBroker
   extends AbstractPersistentStoreSingleResultQuery
{
   public long nextID()
      throws WrappingException
   {
      return ((Long)execute()).longValue();
   }

   public long nextID(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      return ((Long)execute(midasConn)).longValue();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getLONG(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT MIDAS.GET_NEXTID() FROM DUAL";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[0];
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
