package com.monsanto.tps.lexiconpos.geography.zipcode;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.agshare.AgshareConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 2, 2006
 * Time: 4:41:03 PM
 */
public class ZipCodeQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String zipCode;

   public ZipCodeQuery(String zipCode) {
      this.zipCode = zipCode;
   }

   public boolean doesZipCodeExist()
      throws WrappingException
   {
      return !StringUtils.isNullOrEmpty((String)super.execute());
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(AgshareSQL.ALIAS_ZIP_CODE);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(AgshareSQL.class).getSQL(AgshareSQL.SELECT_ZIP_CODE_BY_ZIP_CODE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { zipCode };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new AgshareConnectionFactoryProperties();
   }
}
