package com.monsanto.tps.lexiconpos.db.factories.peopledata;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryPropertiesLexiconImpl;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Feb 2, 2006
 * Time: 3:30:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class PeopleDataConnectionFactoryProperties
   extends ConnectionFactoryPropertiesLexiconImpl
{
   public static final String INSTANCE_NAME = "PeopleData";
   private static final String PROP_FILENAME = "PeopleDataDB.properties";

   public String getInstanceName() {
      return INSTANCE_NAME;
   }
   public Properties loadProperties() throws IOException {
      return PropertyManager.getInstance().getNonCachedProperties(getClass(), PROP_FILENAME);
   }
}
