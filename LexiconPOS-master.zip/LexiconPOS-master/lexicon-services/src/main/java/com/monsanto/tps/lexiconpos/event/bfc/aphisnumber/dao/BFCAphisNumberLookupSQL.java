package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.dao;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 6, 2006
 * Time: 4:44:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BFCAphisNumberLookupSQL
{
    String SELECT_APHIS_NUM_DATA_BY_TRANSCODE = "AphisNumData.SelectByTransCode";
    String ALIAS_TRANSCODE = "TransCode";
    String ALIAS_APHIS_NUM = "AphisNum";
    String ALIAS_EFF_DATE = "EffectiveDate";
    String ALIAS_EXPR_DATE = "ExpirationDate";
}
