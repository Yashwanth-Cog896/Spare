package com.monsanto.tps.lexiconpos.crop.dao.lexicon;

import com.monsanto.tps.lexiconpos.crop.domain.lexicon.Crop;

/**
 * rrchak1 - Feb 13, 2009 1:40:11 PM
 */
public interface CropDao
{
   Crop findByName(String cropName);

   Crop findByPubkey(String cropPubkey);

   Crop[] findAll();

   Crop findByCropID(Long cropID);
}
