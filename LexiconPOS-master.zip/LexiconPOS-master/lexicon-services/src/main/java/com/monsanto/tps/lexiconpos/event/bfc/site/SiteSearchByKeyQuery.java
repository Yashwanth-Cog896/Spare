package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSite;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 25, 2006
 * Time: 11:28:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class SiteSearchByKeyQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private long siteKey;
   public SiteSearchByKeyQuery(long siteKey) {
      this.siteKey = siteKey;
   }

   public BFCSite getSite() throws WrappingException {
      return (BFCSitePSRowImpl) execute();
   }

   protected String getSQL() throws WrappingException {
      StringBuffer sql = new StringBuffer();
      sql.append(getSQLPropFile().getSQL(BFCSiteSQL.SITE_SELECT_FROM_STRUT));
      sql.append(" WHERE ");
      sql.append(getSQLPropFile().getSQL(BFCSiteSQL.SITE_STATUS_CONDITION));
      sql.append(" AND ");
      sql.append(getSQLPropFile().getSQL(BFCSiteSQL.SITE_KEY_CONDITION));
      return sql.toString();
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(siteKey) };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new BFCSitePSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new BFCConnectionFactoryProperties();
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(BFCSiteSQL.class);
   }
}
