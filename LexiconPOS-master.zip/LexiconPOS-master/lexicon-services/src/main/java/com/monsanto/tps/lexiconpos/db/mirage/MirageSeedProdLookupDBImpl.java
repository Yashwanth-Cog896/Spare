package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tps.lexiconpos.product.common.domain.mirage.MirageProduct;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 1, 2005
 * Time: 5:44:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageSeedProdLookupDBImpl
   implements MirageSeedProdLookup
{
   public MirageProduct getSeedProduct(String productName, String bayerCode, int companyID, String countryCode,
      PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      MatchingMirageProductQuery query = new MatchingMirageProductQuery(productName, bayerCode, companyID, countryCode);
      return query.execute(mirageConn);
   }

   public MirageProduct getSeedProduct(int seedProductID, PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      MirageProductByIDQuery query = new MirageProductByIDQuery(seedProductID);
      return query.getSeedProduct(mirageConn);
   }
}
