/*
 GermplasmBatchQueryResultsImpl was created on Jan 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.model;

import java.util.List;
import java.util.ArrayList;

/**
 * nbwald Jan 31, 2007 11:47:05 AM
 */
public class GermplasmBatchQueryResultsImpl
   implements GermplasmBatchQueryResults
{
   private int itemsMatched = 0;
   private int itemsReturned = 0;
   private List queryItemResults = new ArrayList();

   public int getItemsMatched() {
      return itemsMatched;
   }

   public int getItemsReturned() {
      return itemsReturned;
   }

   public QueryItemResult[] getQueryItemResults() {
      return (QueryItemResult[]) queryItemResults.toArray(new QueryItemResult[queryItemResults.size()]);
   }

   public void addResult(QueryItemResult result) {
      itemsReturned += result.getRichGermplasms().length;
      queryItemResults.add(result);
   }

   public void addToMatchedGermplasmCount(int matchedGermplasmInBatch) {
      itemsMatched += matchedGermplasmInBatch;
   }
}