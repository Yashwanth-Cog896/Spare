package com.monsanto.tps.lexiconpos.db.yieldmart;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jul 7, 2005
 * Time: 4:39:48 PM
 * To change this template use File | Settings | File Templates.
 */
public interface YieldMartSQLPropFile
{
/*
    String GP_REC_EXISTS = "Germplasm.RecordExists";
    String INSERT_GP = "Germplasm.Insert";
    String UPDATE_GP = "Germplasm.Update";
    String GM_REC_EXISTS = "GeneticMaterial.RecordExists";
    String INSERT_GM = "GeneticMaterial.Insert";
    String PROD_REC_EXISTS = "Product.RecordExists";
    String INSERT_PROD = "Product.Insert";
    String UPDATE_PROD = "Product.Update";
    String PROD_GP_REC_EXISTS = "ProductGermplasm.RecordExists";
    String INSERT_PROD_GP = "ProductGermplasm.Insert";
    String PROD_NAME_REC_EXISTS = "ProductName.RecordExists";
    String INSERT_PROD_NAME = "ProductName.Insert";
    String UPDATE_PROD_NAME = "ProductName.Update";
*/
    String MAP_PROD_MIRAGE_REC_EXISTS = "MapProductMirage.RecordExists";
    String INSERT_MAP_PROD_MIRAGE = "MapProductMirage.Insert";
    String UPDATE_MAP_PROD_MIRAGE = "MapProductMirage.Update";
    String UPDATE_MPM_PROD_ID = "MapProductMirage.UpdateProductId";

    String SELECT_BY_SEED_PRODUCT_ID = "MapProductMirage.SelectBySeedProductId";

    String SEED_PRODUCT_ID_ALIAS = "SeedProductId";
    String GEN_MAT_ID_ALIAS = "GeneticMaterialId";
    String PROD_ID_ALIAS = "ProductId";
    String MIRAGE_NAME_ALIAS = "MirageName";
}
