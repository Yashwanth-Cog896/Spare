package com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 4, 2006
 * Time: 2:31:24 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EventCropComlTraitSQL
{
   String ALIAS_CROP_NAME = "CropName";
   String ALIAS_COML_TRAIT_NAME = "ComlTraitName";
   String CROP_COML_TRAIT_BY_EVENT = "CropComlTrait.ByEvent";
}
