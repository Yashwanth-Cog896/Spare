/*
 GermplasmBatchQueryDOMImpl was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmBatchQuery;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmQueryItem;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * nbwald Jan 30, 2007 6:12:39 PM
 */
public class GermplasmBatchQueryDOMImpl
   implements GermplasmBatchQuery
{
   private final int maxItems;
   private final GermplasmQueryItem[] queryItems;
   public static final int DEFAULT_MAX_ITEMS = 1000;

   public GermplasmBatchQueryDOMImpl(Element queryElem) {
      this.maxItems = parseMaxItems(queryElem);
      this.queryItems = parseQueryItems(queryElem);
   }

   public int getMaxItems() {
      return maxItems;
   }

   public GermplasmQueryItem[] getQueryItems() {
      return queryItems;
   }

   private int parseMaxItems(Element queryElem) {
      String sMaxItems = DOMUtil.getAttribute(queryElem, GermplasmQueryDocTags.MAX_ITEMS_ATTR_NAME);
      return sMaxItems == null ? DEFAULT_MAX_ITEMS : Integer.parseInt(sMaxItems);
   }

   private GermplasmQueryItem[] parseQueryItems(Element queryElem) {
      String cropName = parseCropName(queryElem);
      Node[] queryItemElems = DOMUtil.getChildren(queryElem, GermplasmQueryDocTags.QUERY_ITEM_ELEM_NAME);
      GermplasmQueryItem[] items = new GermplasmQueryItem[queryItemElems.length];
      for (int i = 0; i < queryItemElems.length; i++) {
         items[i] = parseQueryItem((Element) queryItemElems[i], cropName);
      }
      return items;
   }

   private String parseCropName(Element queryElem) {
      return DOMUtil.getChildValue(queryElem, GermplasmDocTags.CROP_NAME_ELEM_NAME);
   }

   private GermplasmQueryItem parseQueryItem(Element queryItemElem, String cropName) {
      return new GermplasmQueryItemDOMImpl(queryItemElem, cropName);
   }

}