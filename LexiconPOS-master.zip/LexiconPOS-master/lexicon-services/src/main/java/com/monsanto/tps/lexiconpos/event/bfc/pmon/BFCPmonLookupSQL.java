package com.monsanto.tps.lexiconpos.event.bfc.pmon;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Sep 27, 2006
 * Time: 12:07:28 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BFCPmonLookupSQL
{
   String ALIAS_PMON = "Pmon";
   String SELECT_PMON_BY_MONSANTO_ID = "SelectPmonByMonsantoId";
}
