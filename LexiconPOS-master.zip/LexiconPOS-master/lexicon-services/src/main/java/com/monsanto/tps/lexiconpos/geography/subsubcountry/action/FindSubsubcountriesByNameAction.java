/*
 FindSubsubcountriesByNameAction was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subsubcountry.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.subsubcountry.query.SubsubcountryQuerySet;
import com.monsanto.tps.lexiconpos.geography.subsubcountry.query.SubsubcountryQuerySetImpl;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexicon.geography.subsubcountry.SubsubcountriesByNameRequest;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

/**
 * @author GGSHIV - Jun 10, 2008 2:38:26 PM
 */
public class FindSubsubcountriesByNameAction extends AbstractArtemisServiceAction {

   private final SubsubcountryQuerySet querySet;

   public FindSubsubcountriesByNameAction(SubsubcountryQuerySet querySet) {
      this.querySet = querySet;
   }

   public FindSubsubcountriesByNameAction() {
      this(new SubsubcountryQuerySetImpl());

   }

   public void process(ServiceProcessContext context) throws Exception {
      SubsubcountriesByNameRequest request = (SubsubcountriesByNameRequest) context.getRequestPayload();
      LexiconCountry lexiconCountry = getLexiconCountry(request);
      Subsubcountry[] subsubcountries = getSubsubcountries(request, lexiconCountry);
      setCountryInformation(lexiconCountry, subsubcountries);
      new MultipleResultResponse(subsubcountries).saveResponse(context);
   }

   private LexiconCountry getLexiconCountry(SubsubcountriesByNameRequest request) {
      return querySet.findCountryByISOCode(request.getCountryISOCode());
   }

   private Subsubcountry[] getSubsubcountries(SubsubcountriesByNameRequest request, LexiconCountry lexiconCountry) {
      return lexiconCountry == null ? new Subsubcountry[0]
              : querySet.findSubsubcountriesByWildcardableName(lexiconCountry.getPublicKey(), request.getWildcardableSubcountryName(), request.getWildcardableName());
   }

   private void setCountryInformation(LexiconCountry lexiconCountry, Subsubcountry[] subsubcountries) {
      for (Subsubcountry subsubcountry : subsubcountries) {
         subsubcountry.setCountryISOCode(lexiconCountry.getISOCode());
         subsubcountry.setDescription(lexiconCountry.getSubSubCountryDescription());
      }
   }
}
