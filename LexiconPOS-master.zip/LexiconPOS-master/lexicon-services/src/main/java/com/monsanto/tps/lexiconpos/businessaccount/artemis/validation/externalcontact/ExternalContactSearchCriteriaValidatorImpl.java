package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tcc.lexiconcommon.validation.validator.SingleResultValidator;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.FieldIsNotFullyWildcardedRule;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.FieldIsNotWildcardableRule;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.SearchableLocationValidationRules;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jun 8, 2008 11:46:13 AM
 */
public class ExternalContactSearchCriteriaValidatorImpl
   implements ExternalContactSearchCriteriaValidator
{
   public void validate(ExternalContactSearchCriteria criteria) {
      SingleResultValidator<String> validator = new SingleResultValidator<String>(getRules(criteria), null);
      String violation = validator.validate();
      if(violation != null) {
         throw new IllegalArgumentException(violation);
      }
   }

   private List<? extends Rule<String>> getRules(ExternalContactSearchCriteria criteria) {
      List<Rule<String>> rules = new ArrayList<Rule<String>>();
      rules.add(new SomeExternalContactSearchCriteriaMustBeSpecifiedRule(criteria));
      rules.add(new FieldIsNotWildcardableRule("Contact type", criteria.getContactType()));
      rules.add(new FieldIsNotFullyWildcardedRule("Company", criteria.getCompanyName()));
      rules.add(new FieldIsNotFullyWildcardedRule("Last name", criteria.getLastName()));
      rules.add(new FieldIsNotFullyWildcardedRule("First name", criteria.getFirstName()));
      addLocationSpecificRules(rules, criteria.getLocation());
      return rules;
   }

   private void addLocationSpecificRules(List<Rule<String>> rules, SearchableLocation location) {
      rules.addAll(new SearchableLocationValidationRules().getSearchableLocationRules(location));
   }
}
