/*
 FBSCommonProductXrefByLexProdPubkeyQuery was created on Nov 6, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.db.fbscommon;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.fbs.FBSCommonConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.product.common.dao.fbscommon.FBSCommonProductXrefPSRowImpl;
import com.monsanto.tps.lexiconpos.product.common.dao.fbscommon.FBSCommonSQL;
import com.monsanto.tps.lexiconpos.product.common.domain.fbscommon.FBSCommonProductXref;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Nov 6, 2006 4:08:53 PM
 */
public class FBSCommonProductXrefByLexProdPubkeyQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private String lexProdPubkey;

   public FBSCommonProductXrefByLexProdPubkeyQuery(String lexProdPubkey) {
      this.lexProdPubkey = lexProdPubkey;
   }

   public FBSCommonProductXref getXref()
      throws WrappingException
   {
      return (FBSCommonProductXref) execute();
   }

   public FBSCommonProductXref getXref(PersistentStoreConnection conn)
      throws WrappingException
   {
      return (FBSCommonProductXref) execute(conn);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new FBSCommonProductXrefPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(FBSCommonSQL.class).getSQL(FBSCommonSQL.PROD_XREF_QUERY_PROP);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { lexProdPubkey };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new FBSCommonConnectionFactoryProperties();
   }

}