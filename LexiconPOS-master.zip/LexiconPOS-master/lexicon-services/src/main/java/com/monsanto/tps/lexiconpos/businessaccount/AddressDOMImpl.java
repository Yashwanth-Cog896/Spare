package com.monsanto.tps.lexiconpos.businessaccount;

import com.monsanto.Util.StringUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 14, 2007
 * Time: 4:08:58 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AddressDOMImpl
   implements Address, BusinessAccountSchemaConstants
{
   private final Element row;
    
   public AddressDOMImpl(Element row) {
      this.row = row;
   }

   public abstract String getPhoneNumber();
   public abstract String getAddressId();

   public String getAddress1() {
      return getFieldNodeValue(ADDR_LINE_1_ATTR_NAME);
   }
   public String getAddress2() {
      return getFieldNodeValue(ADDR_LINE_2_ATTR_NAME);
   }
   public String getAddress3() {
      return getFieldNodeValue(ADDR_LINE_3_ATTR_NAME);
   }
   public String getCity() {
      return getFieldNodeValue(CITY_ATTR_NAME);
   }
   public String getCounty() {
      return getFieldNodeValue(COUNTY_ATTR_NAME);
   }
   public String getState() {
      return getFieldNodeValue(STATE_CODE_ATTR_NAME);
   }
   public String getCountry() {
      return getFieldNodeValue(COUNTRY_ATTR_NAME);
   }
   public String getPostalCode() {
      return StringUtils.isNullOrEmpty(getFieldNodeValue(ZIP4_ATTR_NAME)) ? getZip(ZIP_ATTR_NAME) :
         getZip(ZIP_ATTR_NAME) + "-" + getZip(ZIP4_ATTR_NAME);
   }
   private String getZip(String locator) {
      return StringUtils.isNullOrEmpty(getFieldNodeValue(locator)) ? "" : getFieldNodeValue(locator);
   }

   protected String getFieldNodeValue(String attributeName) {
      try {
         String path = getFieldNameAttributePath() + attributeName + "']/text()";
         Node node = XPathAPI.selectSingleNode(row, path);
         return (node == null) ? null : node.getNodeValue();
      }
      catch (TransformerException e) {
         throw new RuntimeException(e);
      }
   }
   private String getFieldNameAttributePath() {
      return new StringBuffer(FIELD_ELEM_NAME)
         .append("[@")
         .append(NAME_ATTR_NAME)
         .append("='").toString();
   }
}