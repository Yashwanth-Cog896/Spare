/*
 ProductGermplasmByGermplasmIDQuery was created on Jan 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.germplasm.model.MidasProductGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Jan 22, 2007 11:36:42 AM
 */
public class MidasProductGermplasmByGermplasmIDQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final long germplasmID;

   public MidasProductGermplasmByGermplasmIDQuery(long germplasmID) {
      this.germplasmID = germplasmID;
   }

   public MidasProductGermplasm getProductGermplasm()
      throws WrappingException
   {
      return (MidasProductGermplasm) execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new MidasProductGermplasmPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_PROD_GP_BY_GP_ID);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(germplasmID) };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}