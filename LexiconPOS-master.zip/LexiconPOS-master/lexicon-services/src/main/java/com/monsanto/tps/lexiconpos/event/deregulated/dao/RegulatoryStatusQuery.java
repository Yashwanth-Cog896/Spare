package com.monsanto.tps.lexiconpos.event.deregulated.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 11, 2006
 * Time: 9:54:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class RegulatoryStatusQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   public String[] getValidDeregulatedStatuses() throws WrappingException {
      List list = getList();
      return (String[])list.toArray(new String[list.size()]);
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(RegulatoryStatusSQL.class).getSQL(RegulatoryStatusSQL.SELECT_DEREGULATED_STATUSES);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[0];
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
