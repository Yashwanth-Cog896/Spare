package com.monsanto.tps.lexiconpos.event.bfc.notificationdetail;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Sep 28, 2006
 * Time: 3:07:42 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BFCNotificationDetailLookupSQL
{
   String ALIAS_DETAILS = "Details";

   String SELECT_PERMIT_CONST_TRANS_DETAILS_BY_MONSANTO_ID = "SelectEventDetails";
}
