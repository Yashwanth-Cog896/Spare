/*
 GermplasmBatchQueryResults was created on Jan 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.model;

/**
 * nbwald Jan 31, 2007 11:13:57 AM
 */
public interface GermplasmBatchQueryResults {
   int getItemsMatched();
   int getItemsReturned();
   QueryItemResult[] getQueryItemResults();
}