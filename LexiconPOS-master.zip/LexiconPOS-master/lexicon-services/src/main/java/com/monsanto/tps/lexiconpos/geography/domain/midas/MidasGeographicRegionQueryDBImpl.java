package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.site.model.MidasGeographicRegionRequest;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 23, 2006
 * Time: 3:51:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGeographicRegionQueryDBImpl
   extends AbstractPersistentStoreMultiRowQuery
   implements MidasGeographicRegionQuery
{
   private final String[] countryPubkeys;
   private final long[] subCountryIds;
   private final long[] subSubCountryIds;
   private final String[] subSubCountryNames;

   private final MidasGeographicRegionRequest request;
   public MidasGeographicRegionQueryDBImpl(MidasGeographicRegionRequest request) {
      this.request = request;
      this.countryPubkeys = request.getCountryKeys();
      this.subCountryIds = request.getSubCountryKeys();
      this.subSubCountryIds = request.getSubSubCountryKeys();
      this.subSubCountryNames = request.getSubSubCountryNames();
   }

   public MidasGeographicRegion[] getMidasGeographicRegions()
      throws WrappingException
   {
      List midasGeographicRegions = getList();
      return (MidasGeographicRegion[])midasGeographicRegions.toArray(new MidasGeographicRegion[midasGeographicRegions.size()]);
   }

   protected List getList()
      throws WrappingException
   {
      return (request.hasCriteria())? super.getList() : new ArrayList();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new MidasGeographicRegionPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      MidasGeographicRegionSQLBuilder sqlBuilder =
         new MidasGeographicRegionSQLBuilder(countryPubkeys, subCountryIds, subSubCountryIds, subSubCountryNames);
      return sqlBuilder.getSQL();
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[0];
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
