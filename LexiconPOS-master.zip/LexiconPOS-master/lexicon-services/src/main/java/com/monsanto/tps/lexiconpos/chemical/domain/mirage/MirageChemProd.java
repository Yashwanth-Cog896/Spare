package com.monsanto.tps.lexiconpos.chemical.domain.mirage;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 10:24:47 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageChemProd
{
    String getMaterialClassification();
    long getProductID();
    String getProductName();
    String getFullName();
    long getFormulatedAmount();
    String getFormulatedAmountName();
    String getFormulationDesignation();
    String[] getActiveIngredients();
    boolean isEnabled();
}
