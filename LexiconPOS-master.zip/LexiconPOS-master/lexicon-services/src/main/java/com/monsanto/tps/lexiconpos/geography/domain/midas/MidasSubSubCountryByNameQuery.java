package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 30, 2006
 * Time: 4:23:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasSubSubCountryByNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String subSubCountryName;
   private final String subCountryKey;

   public MidasSubSubCountryByNameQuery(String subSubCountryName, String subCountryKey)
   {
      this.subSubCountryName = subSubCountryName;
      this.subCountryKey = subCountryKey;
   }

   public MidasSubSubCountry getSubSubCountry() throws WrappingException {
      return (MidasSubSubCountry) execute();
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MidasGeographicRegionQuerySQL.class).getSQL(
         MidasGeographicRegionQuerySQL.SELECT_SUB_SUB_COUNTRY_BY_NAME);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { StringUtils.toUpperCaseNull(subSubCountryName), subCountryKey };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new MidasSubSubCountryPSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
