package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 28, 2006
 * Time: 2:31:29 PM
 */
public class MirageSeedProductMaturityCreationDataMod
{
   private final int seedProductID;
   private final String maturityRating;

   public MirageSeedProductMaturityCreationDataMod(int seedProductID, String maturityRating) {
      this.seedProductID = seedProductID;
      this.maturityRating = maturityRating;
   }

   public int performInsert(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return new MirageAuditedAction()
      {
         @Override
         protected int performAction(PersistentStoreStatement statement)
            throws WrappingException
         {
            return statement.executeInsert();
         }

         @Override
         protected String getSQL()
            throws WrappingException
         {
            SQLPropFile propFile = new SQLPropFile(MirageSeedProductWriterSQL.class);
            return propFile.getSQL(MirageSeedProductWriterSQL.INSERT_MATURITY);
         }

         @Override
         protected Object[] getBindVariables(int auditId) {
            return new Object[] { seedProductID, maturityRating, auditId };
         }

         @Override
         protected int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
            throws WrappingException
         {
            return mirageAuditor.auditCreateProductMaturity(mirageConn);
         }
      }.execute(mirageConn);
   }
}
