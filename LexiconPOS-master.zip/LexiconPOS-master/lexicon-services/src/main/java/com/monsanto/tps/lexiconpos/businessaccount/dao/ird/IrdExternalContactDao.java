package com.monsanto.tps.lexiconpos.businessaccount.dao.ird;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * Filename:    IrdExternalContactDao.java
 * Last Change: rrchak1 On:	Jul 23, 2008
 *
 * @author: rrchak1
 */
public interface IrdExternalContactDao {

    public Contact[] findByBusinessGeographySearchCriteria(ExternalContactByBusinessGeographySearchCriteria externalContactByBusinessGeographySearchCriteria);

    public Contact[] findByIds(long[] contactIds);

    public Contact[] findBySearchCriteria(ExternalContactSearchCriteria externalContactSearchCriteria);

    public Contact[] findByBusinessAcctIds(long[] accountIds);
}
