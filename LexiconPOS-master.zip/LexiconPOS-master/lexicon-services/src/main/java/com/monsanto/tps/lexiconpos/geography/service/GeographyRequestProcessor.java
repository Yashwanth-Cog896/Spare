package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 1:46:08 PM
 * To change this template use File | Settings | File Templates.
 */
public interface GeographyRequestProcessor
{
    public GeographicEntity[] getMatchingGeography(
        GeographyRequestModel requestModel,
        TPSPersistentStoreConnection conn)
        throws WrappingException;
}
