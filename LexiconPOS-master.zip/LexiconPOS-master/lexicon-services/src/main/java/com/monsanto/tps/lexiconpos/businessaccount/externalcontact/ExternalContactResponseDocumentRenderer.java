package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 4:08:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactResponseDocumentRenderer
   implements BusinessAccountSchemaConstants
{
   private ExternalContact[] externalContacts;

   public ExternalContactResponseDocumentRenderer(ExternalContact[] externalContacts)
   {
      this.externalContacts = externalContacts;
   }

   public Document render()
   {
      Document doc = DOMUtil.newDocument();
      Element root = createRootElement(doc);
      Element externalContactsElem = renderExternalContactsElem(root);
      renderExternalContacts(externalContactsElem);
      return doc;
   }

   private Element createRootElement(Document doc)
   {
      Element root = DOMUtil.addChildElementWithNS(NAMESPACE, doc, EXTERNAL_CONTACT_RESP_ELEM_NAME);
      root.setAttribute("xmlns", NAMESPACE);
      root.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
      return root;
   }

   private Element renderExternalContactsElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, EXTERNAL_CONTACTS_ELEM_NAME);      
   }

   private void renderExternalContacts(Element parent)
   {
      ExternalContactRenderer renderer;
      for (int i = 0; i < externalContacts.length; i++) {
         renderer = new ExternalContactRenderer(externalContacts[i]);
         renderer.render(parent);
      }
   }
}
