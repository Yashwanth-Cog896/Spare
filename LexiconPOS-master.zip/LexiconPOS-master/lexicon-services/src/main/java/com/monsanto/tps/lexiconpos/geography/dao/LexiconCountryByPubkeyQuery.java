package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 30, 2006
 * Time: 12:59:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconCountryByPubkeyQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String pubkey;

   public LexiconCountryByPubkeyQuery(String pubkey) {
      this.pubkey = pubkey;
   }

   public LexiconCountry getLexiconCountry()
      throws WrappingException
   {
      return (LexiconCountry)execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new LexiconCountryPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(LexiconSQL.class).getSQL(LexiconSQL.SELECT_COUNTRY_BY_PUBKEY);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { pubkey };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
