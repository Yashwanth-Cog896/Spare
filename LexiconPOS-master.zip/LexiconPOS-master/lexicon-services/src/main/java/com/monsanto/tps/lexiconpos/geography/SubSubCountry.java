package com.monsanto.tps.lexiconpos.geography;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 13, 2006
 * Time: 10:46:35 AM
 * To change this template use File | Settings | File Templates.
 */
public interface SubSubCountry
   extends GeographicEntity
{
   long getID();
   String getName();
}
