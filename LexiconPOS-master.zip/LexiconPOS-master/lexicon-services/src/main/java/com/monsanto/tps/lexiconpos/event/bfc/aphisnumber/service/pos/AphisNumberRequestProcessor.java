package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

import com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.dao.BFCAphisNumberLookup;
import com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.dao.BFCAphisNumberLookupDBImpl;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 1:33:18 PM
 */
public class AphisNumberRequestProcessor
{
   public AphisNumberDatum[] getAphisNubmerData(
      AphisNumberRequestModel requestModel, TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      String transCode = requestModel.getRequestedTransCode();
      BFCAphisNumberLookup lookup = getAphisNumberLookup();
      return lookup.getAphisNumberData(transCode, conn.getBFCConnection());
   }

   protected BFCAphisNumberLookup getAphisNumberLookup() {
      return new BFCAphisNumberLookupDBImpl();
   }
}
