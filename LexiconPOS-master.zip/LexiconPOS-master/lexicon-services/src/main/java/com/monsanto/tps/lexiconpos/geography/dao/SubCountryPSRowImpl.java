package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.SubCountry;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 8:14:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubCountryPSRowImpl
   implements SubCountry, LexiconSQL
{
   private final long id;
   private final String name;
   private final String abbr;
   private LexiconCountry country;

   public SubCountryPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      id = row.getLong(getSQLPropFile().getAlias(ALIAS_SUBCOUNTRY_ID));
      name = row.getString(getSQLPropFile().getAlias(ALIAS_SUBCOUNTRY_NAME));
      abbr = row.getString(getSQLPropFile().getAlias(ALIAS_SUBCOUNTRY_ABBR));
   }

   public long getID() {
      return id;
   }
   public String getName() {
      return name;
   }
   public String getAbbr() {
      return abbr;
   }
   public LexiconCountry getCountry() {
      return country;
   }
   public void setCountry(LexiconCountry country) {
      this.country = country;
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(LexiconSQL.class);
   }
}