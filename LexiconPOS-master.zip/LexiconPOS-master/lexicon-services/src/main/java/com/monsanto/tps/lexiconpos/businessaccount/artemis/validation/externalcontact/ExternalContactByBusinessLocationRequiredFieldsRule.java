package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * nbwald - Jun 8, 2008 11:55:30 AM
 */
public class ExternalContactByBusinessLocationRequiredFieldsRule
   implements Rule<String>
{
   private final ExternalContactSearchCriteria criteria;

   public ExternalContactByBusinessLocationRequiredFieldsRule(ExternalContactSearchCriteria criteria) {
      this.criteria = criteria;
   }

   public boolean violated() {
      return criteria.getFirstName() == null
         || criteria.getLastName() == null
         || noLocationCriteriaSpecified();
   }

   public String getViolation() {
      return "Must specify First Name, Last Name, Country and SubCountry criteria.";
   }

   private boolean noLocationCriteriaSpecified() {
      SearchableLocation location = criteria.getLocation();
      return location == null ||
         location.getSubcountryCode() == null
            || location.getCountryName() == null;
   }
}