package com.monsanto.tps.lexiconpos.chemical.service.pos;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 17, 2005
 * Time: 1:32:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ChemicalMaterialSchemaConstants
{
    String NAMESPACE = "http://www.monsanto.com/lexicon/ChemicalMaterial";
    String SCHEMA_LOC = "xsd/lexicon/ChemicalMaterial.xsd";

    String REQUEST_ELEM_NAME = "Request";
    String PROD_NAME_ELEM_NAME = "ProductName";
    String MAT_CLASS_ELEM_NAME = "MaterialClassification";

    String RESPONSE_ELEM_NAME = "Response";
    String CHEM_PROD_ELEM_NAME = "ChemicalMaterial";
    String MAT_KEY_ELEM_NAME = "MaterialKey";
    String MAT_NAME_ELEM_NAME = "MaterialName";
    String FORMULATED_AMOUNT_ELEM_NAME = "FormulatedAmount";
    String FORMULATED_AMOUNT_UNIT_ELEM_NAME = "FormulatedAmountUnit";
    String FORM_DS_ELEM_NAME = "FormulationDesignation";

    String COML_PROD_ELEM_NAME = "CommercialProduct";
    String FORMULATION_ELEM_NAME = "Formulation";
    String ACT_INGRED_ELEM_NAME = "ActiveIngredient";
}
