/*
 CropDesegregator was created on Jul 8, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.tps.lexicon.crop.BayerCode;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.ScientificName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author GGSHIV - Jul 8, 2008 11:51:13 AM
 */
public class CropDesegregator {

   private final Map<String, Crop> cropMap = new LinkedHashMap<String, Crop>();
   private final Map<String, BayerCode> bayercodeMap = new HashMap<String, BayerCode>();
   private final Map<String, List<ScientificName>> scientificNameMap = new HashMap<String, List<ScientificName>>();
   private final List<SegregateCrop> segregateCrops;

   public CropDesegregator(List<SegregateCrop> segregateCrops) {
      this.segregateCrops = segregateCrops;
   }

   public List<Crop> desegregate() {
      for (SegregateCrop segregateCrop : segregateCrops) {
         desegregateScientificName(segregateCrop);
         desegregateBayerCode(segregateCrop);
         desegregateCrop(segregateCrop);
      }
      return new ArrayList<Crop>(cropMap.values());
   }

   private void desegregateCrop(SegregateCrop segregateCrop) {
      Crop crop = cropMap.containsKey(segregateCrop.getPublicKey()) ? updateCrop(segregateCrop) : createCrop(segregateCrop);
      cropMap.put(segregateCrop.getPublicKey(), crop);
   }

   private void desegregateBayerCode(SegregateCrop segregateCrop) {
      String bayerPubKey = segregateCrop.getBayerCode().getPublicKey();
      if (!bayercodeMap.containsKey(bayerPubKey)) {
         bayercodeMap.put(bayerPubKey, new BayerCode(segregateCrop.getBayerCode().getCode(), bayerPubKey, scientificNameMap.get(bayerPubKey)));
      }
   }

   private void desegregateScientificName(SegregateCrop segregateCrop) {
      String bayerPubKey = segregateCrop.getBayerCode().getPublicKey();
      List<ScientificName> scientificNames = scientificNameMap.containsKey(bayerPubKey) ? scientificNameMap.get(bayerPubKey) : new ArrayList<ScientificName>();
      scientificNames.add(segregateCrop.getBayerCode().getScientificName());
      scientificNameMap.put(bayerPubKey, scientificNames);
   }

   private Crop createCrop(SegregateCrop segregateCrop) {
      Crop crop = new Crop();
      crop.setName(segregateCrop.getName());
      crop.setPublicKey(segregateCrop.getPublicKey());
      crop.setShippingStatement(segregateCrop.getShippingStatement());
      crop.setAbbreviation(segregateCrop.getAbbreviation());

      List<BayerCode> bayerCodes = new ArrayList<BayerCode>();
      bayerCodes.add(bayercodeMap.get(segregateCrop.getBayerCode().getPublicKey()));
      crop.setBayerCodes(bayerCodes);
      return crop;
   }

   private Crop updateCrop(SegregateCrop segregateCrop) {
      Crop crop = cropMap.get(segregateCrop.getPublicKey());
      updateBayerCode(segregateCrop, crop);
      return crop;
   }

   private void updateBayerCode(SegregateCrop segregateCrop, Crop crop) {
      for (BayerCode bayerCode : crop.getBayerCodes()) {
         if (segregateCrop.getBayerCode().getPublicKey().equals(bayerCode.getPublicKey())) {
            return;
         }
      }
      crop.getBayerCodes().add(bayercodeMap.get(segregateCrop.getBayerCode().getPublicKey()));
   }
}
