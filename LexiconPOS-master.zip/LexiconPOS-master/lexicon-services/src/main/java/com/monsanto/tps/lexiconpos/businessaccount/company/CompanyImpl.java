package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.tps.lexiconpos.businessaccount.Address;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 13, 2007
 * Time: 1:47:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyImpl
   implements Company
{
   private final Company company;
   private final List addresses = new ArrayList();

   public CompanyImpl(Company company) {
      this.company = company;
      initAddresses();
   }

   private void initAddresses()
   {
      Address[] addressArr = company.getAddresses();
      addAddresses(addressArr);
   }

   public String getAcctId() {
      return company.getAcctId();
   }
   public String getCompanyName() {
      return company.getCompanyName();
   }
   public Address[] getAddresses() {
      return (Address[]) addresses.toArray(new Address[addresses.size()]);
   }
   public void addAddress(Address address) {
      addresses.add(address);
   }
   public void addAddresses(Address[] addressArr) {
      for (int i = 0; i < addressArr.length; i++) {
         Address address = addressArr[i];
         addAddress(address);
      }
   }
}
