package com.monsanto.tps.lexiconpos.germplasm;

import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Mar 24, 2006
 * Time: 4:47:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class OriginRecipricator
{
   private final String origin;

   public OriginRecipricator(String origin)
   {
      this.origin = origin;
   }

   public String getReciprical()
   {
      String reciprical = null;
      if (!StringUtils.isNullOrEmpty(origin)) {
         reciprical = getReciprical("++");
         if (null == reciprical) {
            reciprical = getReciprical("+");
         }
      }
      return reciprical;
   }

   private String getReciprical(String token)
   {
      int index = origin.indexOf(token);
      return (index == -1) ? null :
         origin.substring(index + token.length()) +
            token + origin.substring(0, index);
   }
}
