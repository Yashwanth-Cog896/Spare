package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.tps.lexiconpos.util.strings.GeographyStringTable;
import com.monsanto.Util.StringUtils;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 5:24:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetCountryRequestParser
    extends GeographyRequestParser
{
    public static String getInvalidRequestError() {
        return new GeographyStringTable().getString(GeographyStringTable.INVALID_COUNTRY_NAME_REQUEST);
    }

    protected GeographyRequestModel parse(Element root)
        throws InvalidGeographyRequestException
    {
        GeographyRequestModel model =
            new GetCountryRequestModel(
                getCountryName(root), getCountryAbbr(root),getCountryPubkey(root));

        validateRequest(model);
        return model;
    }

    private void validateRequest(GeographyRequestModel model)
        throws InvalidGeographyRequestException
    {
        if (StringUtils.isNullOrEmpty(model.getCountryName()) &&
            StringUtils.isNullOrEmpty(model.getCountryAbbr()) &&
            StringUtils.isNullOrEmpty(model.getCountryPubkey()))
        {
            throw new InvalidGeographyRequestException(getInvalidRequestError());
        }
    }
}
