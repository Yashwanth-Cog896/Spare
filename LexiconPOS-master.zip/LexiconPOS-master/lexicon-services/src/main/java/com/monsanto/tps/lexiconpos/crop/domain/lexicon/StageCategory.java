package com.monsanto.tps.lexiconpos.crop.domain.lexicon;

/**
 * vvkalu - Jun 21, 2010 10:59:50 AM
 */
public class StageCategory
{
   private int stageCategoryId;
   private String stageCategoryName;

   public int getStageCategoryId() {
      return stageCategoryId;
   }

   public void setStageCategoryId(int stageCategoryId) {
      this.stageCategoryId = stageCategoryId;
   }

   public String getStageCategoryName() {
      return stageCategoryName;
   }

   public void setStageCategoryName(String stageCategoryName) {
      this.stageCategoryName = stageCategoryName;
   }
}
