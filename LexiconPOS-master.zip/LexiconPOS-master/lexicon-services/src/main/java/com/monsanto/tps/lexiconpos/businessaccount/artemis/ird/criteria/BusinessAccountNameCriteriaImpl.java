package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdSpecialCharacterCriteria;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.db.hibernate.EscapingLikeExpression;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.db.constants.LexiconConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Last Change: rrchak1 On:	Jul 30, 2008 
 * @author: rrchak1
 */
public class BusinessAccountNameCriteriaImpl implements QueryCriteria {

    private final String accountName;

    public BusinessAccountNameCriteriaImpl(String accountName) {
        this.accountName = accountName;
    }

    public Criterion getCriterion() {
       if(new StdSpecialCharacterCriteria(accountName).hasSpecialCharacters()){
          return new EscapingLikeExpression
             (BusinessAccountSchemaConstants.ACCT_NAME1,
                convertWildCards(
                applyEscapeChar(String.valueOf(LexiconConstants.EscapeChar))
                  ),
                LexiconConstants.EscapeChar,
                true);
       }else{
          return Restrictions.like(BusinessAccountSchemaConstants.ACCT_NAME1, convertWildCards(accountName)).ignoreCase();
       }
    }

   private String applyEscapeChar(String escapeChar) {
      return new StdSpecialCharacterCriteria(accountName,escapeChar).oracleVersion();
   }

   public boolean hasCriteria() {
        return StringUtils.isNotEmpty(accountName);
    }

    private String convertWildCards(String attribute) {
        return new StdWildcardableCriteria(attribute).oracleVersion();
    }
}
