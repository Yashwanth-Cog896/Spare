package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - Jun 4, 2008 2:40:11 PM
 */
public class FieldIsNotWildcardableRule
   implements Rule<String>
{
   private final String fieldName;
   private final String fieldValue;

   public FieldIsNotWildcardableRule(String fieldName, String fieldValue) {
      this.fieldName = fieldName;
      this.fieldValue = fieldValue;
   }

   public boolean violated() {
      WildcardableCriteria fieldCriteria = new StdWildcardableCriteria(fieldValue);
      return fieldCriteria.hasWildcard();
   }

   public String getViolation() {
      return fieldName + " is not wildcardable.";
   }
}
