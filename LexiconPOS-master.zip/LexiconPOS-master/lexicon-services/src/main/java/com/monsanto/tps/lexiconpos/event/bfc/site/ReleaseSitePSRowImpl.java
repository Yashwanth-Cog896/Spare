/*
 ReleaseSitePSRowImpl was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.ReleaseSite;

/**
 * nbwald Oct 12, 2006 2:29:34 PM
 */
public class ReleaseSitePSRowImpl
   implements ReleaseSite
{
   private final String acres;

   public ReleaseSitePSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      acres = row.getString(getAlias(BFCReleaseSiteSQL.ALIAS_ACRES));
   }

   public String getAcres() {
      return acres;
   }


   private String getAlias(String propName)
      throws WrappingException
   {
      SQLPropFile releaseSiteSQL = new SQLPropFile(BFCReleaseSiteSQL.class);
      return releaseSiteSQL.getAlias(propName);
   }
}