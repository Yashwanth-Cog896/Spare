package com.monsanto.tps.lexiconpos.event.deregulated.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.geography.domain.midas.MidasGetSubCountriesByCountryPubkeyQuery;
import com.monsanto.tps.lexiconpos.traitstack.dao.stateregistration.GetStateRegistrationStatusQuery;
import com.monsanto.tps.lexiconpos.traitstack.dao.stateregistration.GetStateRegistrationStatusQueryImpl;
import com.monsanto.tps.lexiconpos.geography.domain.midas.MidasSubCountry;
import com.monsanto.tps.lexiconpos.event.deregulated.model.StateRegistrationStatus;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Nov 7, 2006
 * Time: 11:01:11 AM
 * To change this template use File | Settings | File Templates.
 */
public class StateRegistrationVerification
{
   private final String stackAbbr;
   private final String cropName;
   private final String countryPubkey;
   private final String[] subCountryKeys;

   public StateRegistrationVerification(String stackAbbr, String cropName, String countryPubkey, String[] subCountryKeys) {
      this.stackAbbr = stackAbbr;
      this.cropName = cropName;
      this.countryPubkey = countryPubkey;
      this.subCountryKeys = subCountryKeys;
   }

   public boolean isDeregulatedAtStateLevel() throws WrappingException
   {
      if (!stateRegistrationsExistForGivenStackAndCountry()) {
         return true;
      }
      StateRegistrationStatus[] statuses = getStateRegistrationsForRequestedSubCountryKeys();
      if (missingRegistrationStatuses(statuses)) {
         return false;
      }
      Date today = getCurrentDate();
      return (areAllRegistrationsValid(statuses, today) && areAllNotificationsValid(statuses, today));
   }

   private boolean stateRegistrationsExistForGivenStackAndCountry() throws WrappingException
   {
      StateRegistrationStatus[] statuses = getStateRegistrationStatuses(getAllSubCountryKeys());
      return statuses.length != 0;
   }

   private StateRegistrationStatus[] getStateRegistrationsForRequestedSubCountryKeys() throws WrappingException
   {
      if (subCountryKeys.length == 0) {
         return getStateRegistrationStatuses(getAllSubCountryKeys());
      }
      return getStateRegistrationStatuses(subCountryKeys);
   }

   protected StateRegistrationStatus[] getStateRegistrationStatuses(String[] subCountryKeys) throws WrappingException
   {
      GetStateRegistrationStatusQuery query = new GetStateRegistrationStatusQueryImpl(stackAbbr, cropName, subCountryKeys);
      return query.getStateRegistrationStatuses();
   }

   private boolean missingRegistrationStatuses(StateRegistrationStatus[] statuses) {
      return statuses.length < subCountryKeys.length;
   }

   private boolean areAllRegistrationsValid(StateRegistrationStatus[] statuses, Date today) {
      for (int i = 0; i < statuses.length; i ++ ) {
         if (statuses[i].isRegistration() && !isTodayWithinRegistrationDateRange(today, statuses[i]))
         {
            return false;
         }
      }
      return true;
   }

   private boolean areAllNotificationsValid(StateRegistrationStatus[] statuses, Date today) {
      for (int i = 0; i < statuses.length; i ++ ) {
         if (isNotification(statuses[i]) && !isTodayAfterNotificationDate(today, statuses[i]))
         {
            return false;
         }
      }
      return true;
   }

   private boolean isTodayWithinRegistrationDateRange(Date today, StateRegistrationStatus stateRegistrationStatus) {
      return today.after(stateRegistrationStatus.getApprovalDate()) && today.before(stateRegistrationStatus.getExpirationDate());
   }

   private boolean isTodayAfterNotificationDate(Date today, StateRegistrationStatus stateRegistrationStatus) {
      return today.after(stateRegistrationStatus.getApprovalDate());
   }

   private boolean isNotification(StateRegistrationStatus status) {
      return !status.isRegistration();
   }

   protected Date getCurrentDate() {
      return Calendar.getInstance().getTime();
   }

   protected String[] getAllSubCountryKeys() throws WrappingException {
      List list = new ArrayList();
      MidasSubCountry[] subCountries = lookupSubCountries();
      for (int i = 0; i < subCountries.length; i++) {
         list.add(subCountries[i].getSubCountryKey());
      }
      return (String[]) list.toArray(new String[list.size()]);
   }

   private MidasSubCountry[] lookupSubCountries() throws WrappingException {
      MidasGetSubCountriesByCountryPubkeyQuery query = new MidasGetSubCountriesByCountryPubkeyQuery(countryPubkey);
      return query.getSubCountriesByCountryPubkey();
   }

    public String getStackAbbr() {
        return stackAbbr;
    }

    public String getCropName() {
        return cropName;
    }

    public String getCountryPubkey() {
        return countryPubkey;
    }

    public String[] getSubCountryKeys() {
        return subCountryKeys;
    }
}
