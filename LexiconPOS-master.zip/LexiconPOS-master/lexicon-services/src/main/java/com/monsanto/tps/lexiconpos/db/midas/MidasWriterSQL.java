package com.monsanto.tps.lexiconpos.db.midas;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jul 6, 2006
 * Time: 10:29:35 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasWriterSQL
{
   String INSERT_PRODUCT = "Product.Insert";
   String UPDATE_PRODUCT_REF_ACTIVE = "Product.UpdateRefActive";
   String UPDATE_DENOM_BY_PUBKEY = "Product.UpdateDenominationByPubkey";

   String INSERT_PRODUCT_NAME = "ProductName.Insert";
   String REUSE_PRODUCT_NAME = "ProductName.Reuse";
   String UPDATE_PRODUCT_NAME = "ProductName.Update";
   String DELETE_PRODUCT_NAME = "ProductName.Delete";

   String UPDATE_PRODUCTS_BRANDED_NAMES = "ProductName.Update.ByBrand";
   String DELETE_PRODUCTS_BRANDED_NAMES = "ProductName.Delete.ByBrand";

   String INSERT_PRODUCT_GERMPLASM = "ProductGermplasm.Insert";
   String INSERT_GERMPLASM = "Germplasm.Insert";
   String INSERT_GENETIC_MATERIAL = "GeneticMaterial.Insert";
   String REPOINT_GENETIC_MATERIAL = "GeneticMaterial.Repoint";
}
