package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.tps.lexiconpos.geography.SubCountry;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 7:31:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubCountryRenderer
    implements GeographicEntityRenderer,
               GeographySchemaConstants
{
    public void render(
        Element element,
        GeographicEntity entity)
    {
        SubCountry subCountry = getGetSubCountry(entity);
        createSubCountryElement(element, subCountry);
//        renderCountryElement(subCountryElement, subCountry);
    }

    private SubCountry getGetSubCountry(GeographicEntity entity) {
        return (SubCountry)entity;
    }

    private Element createSubCountryElement(
        Element element,
        SubCountry subCountry)
    {
        Element subCountryElement = DOMUtil.addChildElementWithNS(NAMESPACE, element, SUBCOUNTRY_ELEM_NAME);
        subCountryElement.setAttribute(PUBKEY_ELEM_NAME, Long.toString(subCountry.getID()));
        DOMUtil.addChildElementWithNS(NAMESPACE, subCountryElement, NAME_ELEM_NAME, subCountry.getName());
        DOMUtil.addChildElementWithNS(NAMESPACE, subCountryElement, ABBR_ELEM_NAME, subCountry.getAbbr());
        return subCountryElement;
    }
/*
    private void renderCountryElement(
        Element subCountryElement,
        SubCountry subCountry)
    {
        CountryRenderer renderer = new CountryRenderer();
        renderer.render(subCountryElement, subCountry.getCountry());
    }
*/
}
