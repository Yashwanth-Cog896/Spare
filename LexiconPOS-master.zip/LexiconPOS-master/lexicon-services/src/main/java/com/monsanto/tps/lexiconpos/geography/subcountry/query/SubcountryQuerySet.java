package com.monsanto.tps.lexiconpos.geography.subcountry.query;

import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

/**
 * nbwald - Jun 8, 2008 3:39:26 PM
 */
public interface SubcountryQuerySet {

   LexiconCountry findCountryByISOCode(String countryISOCode);

   Subcountry[] findSubcountriesByWildcardableSubcountryName(String countryPubkey, String wildcardableSubcountryName);

   Subcountry[] findSubcountriesByAbbreviation(String countryPubkey, String[] subcountriesAbbreviation);
}
