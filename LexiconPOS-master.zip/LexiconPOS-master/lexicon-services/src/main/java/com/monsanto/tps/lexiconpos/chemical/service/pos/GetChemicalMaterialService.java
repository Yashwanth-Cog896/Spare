package com.monsanto.tps.lexiconpos.chemical.service.pos;

import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageChemProd;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 17, 2005
 * Time: 1:31:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetChemicalMaterialService
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return ChemicalMaterialSchemaConstants.SCHEMA_LOC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      TPSPersistentStoreConnection conn = getConnection();
      try {
         ChemicalProductRequest requestModel = getRequestModel(inputDocument);
         MirageChemProd[] products = processRequest(requestModel, conn);
         return renderContent(products);
      }
      finally {
         closeConnection(conn);
      }
   }

   private ChemicalProductRequest getRequestModel(Document requestDoc)
      throws InvalidMaterialClassificationTypeException
   {
      ChemicalProductRequestParser parser = new ChemicalProductRequestParser(requestDoc);
      return parser.parse();
   }

   private MirageChemProd[] processRequest(ChemicalProductRequest requestModel, TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      GetChemicalMaterialRequestProcessor processor = getRequestProcessor();
      return processor.processRequest(requestModel, conn);
   }

   protected GetChemicalMaterialRequestProcessor getRequestProcessor() {
      return new GetChemicalMaterialRequestProcessor();
   }

   private Document renderContent(MirageChemProd[] products) {
      ChemicalMaterialRenderer renderer = new ChemicalMaterialRenderer(products);
      Document response = ChemicalMaterialRenderer.createDocument();
      renderer.renderProducts(response.getDocumentElement());
      return response;
   }

   protected TPSPersistentStoreConnection getConnection() {
      return new TPSPersistentStoreConnection();
   }

   protected void closeConnection(TPSPersistentStoreConnection conn) {
      conn.close();
   }
}
