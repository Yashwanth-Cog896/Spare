package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctAddr;
import com.monsanto.tps.lexiconpos.geography.domain.ird.Fips;
import com.monsanto.tps.lexiconpos.geography.domain.ird.Geo;
import com.monsanto.tps.lexiconpos.geography.domain.ird.ZipCode;
import com.monsanto.tps.lexicon.contact.Address;

/**
 * nbwald - Jul 31, 2008 6:20:31 PM
 */
public class AddressBuilder
{
   public Address build(AcctAddr acctAddr) {
      Address address = new Address();
      setAddressFields(acctAddr, address);
      setLocationFields(acctAddr, address);
      return address;
   }

   private void setAddressFields(AcctAddr acctAddr, Address address) {
      address.setLine1(acctAddr.getAddrLine1());
      address.setLine2(acctAddr.getAddrLine2());
      address.setLine3(acctAddr.getAddrLine3());
      address.setPostalCode(extractPostalCode(acctAddr));
   }

   private String extractPostalCode(AcctAddr acctAddr) {
      ZipCode zipCode = acctAddr.getZipCode();
      return zipCode == null ? null : zipCode.getZipCode() + extendedZipCode(acctAddr);
   }

   private String extendedZipCode(AcctAddr acctAddr) {
      String extendedZipCode = acctAddr.getZipCode4();
      return StringUtils.isNullOrEmpty(extendedZipCode) ? "" : "-" + extendedZipCode;
   }

   private void setLocationFields(AcctAddr acctAddr, Address address) {
      address.setCity(acctAddr.getCity());
      address.setState(acctAddr.getStateCode());
      address.setCounty(getCounty(acctAddr.getZipCode()));
      address.setCountry(getCountry(acctAddr.getGeo()));
   }

   private String getCounty(ZipCode zipCode) {
      if(zipCode != null) {
         Fips fips = zipCode.getFips();
         if(fips != null) {
            return fips.getCountyDescr();
         }
      }
      return null;
   }

   private String getCountry(Geo geo) {
      return geo == null ? null : geo.getDescr();
   }
}