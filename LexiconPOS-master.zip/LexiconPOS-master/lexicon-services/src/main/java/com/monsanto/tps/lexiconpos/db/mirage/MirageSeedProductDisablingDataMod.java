package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 7, 2007
 * Time: 9:10:18 PM
 */
public class MirageSeedProductDisablingDataMod
{
   private final int seedProductID;
   private final MirageAuditedAction action = new MirageAuditedAction()
   {
      @Override
      protected int performAction(PersistentStoreStatement statement)
         throws WrappingException
      {
         return statement.executeUpdate();
      }

      @Override
      protected String getSQL()
         throws WrappingException
      {
         SQLPropFile propFile = new SQLPropFile(MirageSeedProductWriterSQL.class);
         return propFile.getSQL(MirageSeedProductWriterSQL.DISABLE_PRODUCT);
      }

      @Override
      protected Object[] getBindVariables(int auditId) {
         return new Object[]{auditId, seedProductID};
      }

      @Override
      protected int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
         throws WrappingException
      {
         return mirageAuditor.auditUpdateSeedProduct(mirageConn);
      }
   };

   public MirageSeedProductDisablingDataMod(int seedProductID) {
      this.seedProductID = seedProductID;
   }

   public int performUpdate()
      throws WrappingException
   {
      return action.execute();
   }

   public int performUpdate(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return action.execute(mirageConn);
   }
}
