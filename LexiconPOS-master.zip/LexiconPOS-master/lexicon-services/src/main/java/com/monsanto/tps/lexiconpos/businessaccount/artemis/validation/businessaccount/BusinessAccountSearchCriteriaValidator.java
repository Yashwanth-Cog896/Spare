package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.businessaccount;

import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;

/**
 * nbwald - Jun 4, 2008 3:16:09 PM
 */
public interface BusinessAccountSearchCriteriaValidator
{
   void validate(BusinessAccountSearchCriteria criteria);
}
