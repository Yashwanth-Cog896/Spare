package com.monsanto.tps.lexiconpos.event.bfc.permit;

import com.monsanto.tps.lexiconpos.permit.Permit;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.BFCPerson;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 17, 2006
 * Time: 4:02:31 PM
 */
public class PermitDTO
   implements Permit
{
   private long permitId;
   private String monsantoId;
   private String agencyId;
   private String applicationType;
   private String submissionType;
   private String status;
   private String cropName;
   private String cropCode;
   private Date effectiveDate;
   private Date expirationDate;
   private boolean eupAvailability;
   private String EUPDocumentName;
   private BFCPerson requester;

   public PermitDTO(
      long permitId,
      String monsantoId,
      String agencyId,
      String applicationType,
      String submissionType,
      String status,
      String cropName,
      String cropCode,
      Date effectiveDate,
      Date expirationDate,
      boolean eupAvailability,
      String eupDocumentName,
      BFCPerson requester)
   {
      this.permitId = permitId;
      this.monsantoId = monsantoId;
      this.agencyId = agencyId;
      this.applicationType = applicationType;
      this.submissionType = submissionType;
      this.status = status;
      this.cropName = cropName;
      this.cropCode = cropCode;
      this.effectiveDate = effectiveDate;
      this.expirationDate = expirationDate;
      this.eupAvailability = eupAvailability;
      this.EUPDocumentName = eupDocumentName;
      this.requester = requester;
   }

   public long getPermitId() {
      return permitId;
   }

   public void setPermitId(long permitId) {
      this.permitId = permitId;
   }

   public String getMonsantoId() {
      return monsantoId;
   }

   public String getAgencyId() {
      return agencyId;
   }

   public String getApplicationType() {
      return applicationType;
   }

   public String getSubmissionType() {
      return submissionType;
   }

   public String getStatus() {
      return status;
   }

   public String getCropName() {
      return cropName;
   }

   public String getCropCode() {
      return cropCode;
   }

   public Date getEffectiveDate() {
      return effectiveDate;
   }

   public Date getExpirationDate() {
      return expirationDate;
   }

   public boolean hasEUP() {
      return eupAvailability;
   }

   public String getEUPDocumentName() {
      return EUPDocumentName;
   }

   public BFCPerson getRequester() {
      return requester;
   }
}
