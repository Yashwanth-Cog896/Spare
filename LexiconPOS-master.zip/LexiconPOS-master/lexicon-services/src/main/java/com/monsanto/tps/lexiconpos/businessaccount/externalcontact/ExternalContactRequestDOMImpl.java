package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 3:27:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactRequestDOMImpl
   implements ExternalContactRequest
{
   private final Document doc;

   public ExternalContactRequestDOMImpl(Document doc) {
      this.doc = doc;
   }

   public String getContactType() {
      return DOMUtil.getChildValue(getRequestElement(), BusinessAccountSchemaConstants.CONTACT_TYPE_ELEM_NAME);
   }

   public String getLastName() {
      return DOMUtil.getChildValue(getRequestElement(), BusinessAccountSchemaConstants.LAST_NAME_ELEM_NAME);
   }

   public String getFirstName() {
      return DOMUtil.getChildValue(getRequestElement(), BusinessAccountSchemaConstants.FIRST_NAME_ELEM_NAME);
   }

   public String getCompany() {
      return DOMUtil.getChildValue(getRequestElement(), BusinessAccountSchemaConstants.COMPANY_ELEM_NAME);
   }

   private Element getRequestElement() {
      return doc.getDocumentElement();
   }
}
