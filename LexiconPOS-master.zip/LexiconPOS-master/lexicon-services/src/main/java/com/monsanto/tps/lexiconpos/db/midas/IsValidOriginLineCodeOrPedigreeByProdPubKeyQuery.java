package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;

import java.util.List;

/**
 * vvkalu - Jun 8, 2010 11:30:13 AM
 */
public class IsValidOriginLineCodeOrPedigreeByProdPubKeyQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private static final int VALID_CONDITION = 0;
   private final String pedigree;
   private final String prodPubKey;
   private final String origin;
   private final String lineCode;

   public IsValidOriginLineCodeOrPedigreeByProdPubKeyQuery(String lineCode, String origin, String pedigree,String prodPubKey) {
      this.lineCode = lineCode;
      this.origin = origin;
      this.pedigree = pedigree;
      this.prodPubKey = prodPubKey;
   }

   public boolean isValidOriginOrLineCode(PersistentStoreConnection conn)
      throws WrappingException
   {
      List germplasmIds = this.getList(conn);
      return germplasmIds.size() > VALID_CONDITION;
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString("GermplasmID");
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      if(originPopulated()){
         return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.IS_VALID_ORIGIN_BY_PUBKEY);
      }
      else if( lineCodePopulated()){
         return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.IS_VALID_LINECODE_BY_PUBKEY);
      }
      else {
         return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.IS_VALID_PEDIGREE_BY_PUBKEY);
      }
   }

   private boolean lineCodePopulated() {
      return !StringUtils.isNullOrEmpty(lineCode);
   }

   private boolean originPopulated() {
      return !StringUtils.isNullOrEmpty(origin);
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      if(originPopulated()){
         return new Object[]{prodPubKey, origin};
      }
      else if(lineCodePopulated()){
         return  new Object[]{prodPubKey, lineCode};
      }
      else {
         return new Object[]{prodPubKey, pedigree};
      }
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
