package com.monsanto.tps.lexiconpos.event.deregulated.model;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 19, 2006
 * Time: 2:18:50 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DeregulatedEventRequest
{
   String[] getEvents();
   String getCountryPubkey();
   String getSubCountryPubkey();
}
