package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.MidasProduct;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 11, 2006
 * Time: 11:18:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductPSRowImpl
   implements MidasProduct
{
   private final long productID;
   private final long cropID;
   private final String denomination;
   private final boolean productActive;

   public MidasProductPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      productID = row.getLong(getAlias(MidasSQL.ALIAS_PROD_ID));
      cropID = row.getLong(getAlias(MidasSQL.ALIAS_CROP_ID));
      denomination = row.getString(getAlias(MidasSQL.ALIAS_DENOM));
      productActive = "T".equals(row.getString(getAlias(MidasSQL.ALIAS_PROD_ACTIVE)));
   }

   public long getProductID() {
      return productID;
   }
   public long getCropID() {
      return cropID;
   }
   public String getDenomination() {
      return denomination;
   }
   public boolean isProductActive() {
      return productActive;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getAlias(propName);
   }
}
