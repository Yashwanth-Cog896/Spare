package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.germplasm.dao.GermplasmPSRowImpl;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 15, 2006
 * Time: 10:19:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductGermplasmByPubkeyQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String productPubkey;

   public ProductGermplasmByPubkeyQuery(String productPubkey) {
      this.productPubkey = productPubkey;
   }

   public Germplasm[] getGermplasms()
      throws WrappingException
   {
      List list = getList();
      return (Germplasm[])list.toArray(new Germplasm[list.size()]);
   }

   public Germplasm[] getGermplasms(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      List list = getList(midasConn);
      return (Germplasm[])list.toArray(new Germplasm[list.size()]);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_GERMPLASMS_BY_PROD_PUBKEY);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { productPubkey };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new GermplasmPSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}

