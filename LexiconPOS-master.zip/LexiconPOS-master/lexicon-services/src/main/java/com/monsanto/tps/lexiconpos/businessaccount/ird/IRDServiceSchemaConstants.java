package com.monsanto.tps.lexiconpos.businessaccount.ird;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Feb 7, 2007
 * Time: 11:56:13 AM
 */
public interface IRDServiceSchemaConstants
{
   String IRDSERVICE_REQ_ELEM_NAME = "IRDSERVICE_REQ";
   String REQUEST_ELEM_NAME = "REQUEST";
   String KEY_ATTR_NAME = "KEY";
   String ID_ATTR_NAME = "ID";
   String FIELD_ELEM_NAME = "FIELD";
   String NAME_ATTR_NAME = "NAME";

   String IRDSERVICE_RESP_ELEM_NAME = "IRDSERVICE_RESP";
   String RESPONSE_ELEM_NAME = "RESPONSE";
   String MSG_ELEM_NAME = "MSG";
   String ROW_ELEM_NAME = "ROW";
   String ERROR_ELEM_NAME = "ERROR";
}
