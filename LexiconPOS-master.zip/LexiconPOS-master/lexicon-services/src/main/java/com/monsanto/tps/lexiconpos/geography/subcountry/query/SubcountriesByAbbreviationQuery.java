/*
 SubcountriesByAbbreviationQuery was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subcountry.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.StringsCriteriaBuilder;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

import java.util.List;

/**
 * @author GGSHIV - Jun 10, 2008 12:39:25 PM
 */
public class SubcountriesByAbbreviationQuery extends AbstractPersistentStoreMultiRowQuery {

   private final String lexiconCountryPubkey;
   private final String[] subcountriesAbbreviation;

   public SubcountriesByAbbreviationQuery(String lexiconCountryPubkey, String[] subcountriesAbbreviation) {
      this.lexiconCountryPubkey = lexiconCountryPubkey;
      this.subcountriesAbbreviation = subcountriesAbbreviation;
   }

   public Subcountry[] find() {
      try {
         List<Subcountry> subcountries = getList();
         return subcountries.toArray(new Subcountry[subcountries.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      Subcountry subcountry = new Subcountry();
      subcountry.setName( row.getString("SubCountryName") );
      subcountry.setAbbreviation( row.getString("SubCountryAbbr") );
      return subcountry;
   }

   protected String getSQL() throws WrappingException {
      return
         "   SELECT SC.name AS \"SubCountryName\", SC.sub_country_abbr AS \"SubCountryAbbr\"" +
         "     FROM FBS_Common.Country_Xref CX," +
         "          Midas.Country C," +
         "          Midas.Sub_Country SC" +
         "    WHERE CX.lexicon_country_pubkey = ?" +
         "      AND CX.midas_country_id = C.country_id" +
         "      AND C.country_id = SC.country_id" +
         "      AND UPPER(SC.sub_country_abbr) IN (" + new StringsCriteriaBuilder().build(subcountriesAbbreviation) + ")" +
         " ORDER BY SC.name";
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { lexiconCountryPubkey };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
