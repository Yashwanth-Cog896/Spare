package com.monsanto.tps.lexiconpos.germplasm.domain.midas;

/**
 * RLCASW - Feb 28, 2010 9:30:49 AM
 */
public class LineType
{
   public static final String HYBRID = "HYBRID";

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getRefId() {
      return refId;
   }

   public void setRefId(String refId) {
      this.refId = refId;
   }

   private Long id;
   private String refId;
}
