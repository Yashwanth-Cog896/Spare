package com.monsanto.tps.lexiconpos.db.audit.helpers;

import com.monsanto.Util.StringUtils;
import com.monsanto.appstatscommon.DataPoint;
import com.monsanto.tps.lexiconpos.db.audit.dao.lexicon.AuditStagingDao;
import com.monsanto.tps.lexiconpos.db.audit.domain.lexicon.AuditStaging;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.springframework.aop.AopUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import java.lang.reflect.Method;

/**
 * rrchak1 - Aug 25, 2008 10:06:54 AM
 */
public class AuditStagingAspect
   implements ApplicationContextAware
{
   private AuditStagingDao auditStagingDao;
   private ApplicationContext applicationContext;
   private DataPointHolder dataPointHolder;
   private UserProfile userProfile;

   public Object advice(ProceedingJoinPoint joinPoint)
      throws Throwable
   {
      Method method = AopUtils.getMethod(joinPoint);
      AuditStage auditStage = method.getAnnotation(AuditStage.class);
      String processName = auditStage.processName();
      String auditComment = getAuditComment(auditStage);
      String auditRequestor = getAuditRequestor(auditStage);
      AuditStaging auditStaging = auditStagingDao.create(userProfile.getUserName(), processName, auditComment, auditRequestor);
      Object result;
      try {
         result = joinPoint.proceed();
      }
      finally {
         auditStagingDao.delete(auditStaging);
      }
      return result;
   }

   private String getAuditComment(AuditStage auditStage) {
      String auditComment = auditStage.auditComment();
      if (StringUtils.isNullOrEmpty(auditComment)) {
         auditComment = getDataPoint(AuditStagingDataPointEnum.AUDITCOMMENT);
      }
      return auditComment;
   }

   private String getAuditRequestor(AuditStage auditStage) {
      String auditRequestor = auditStage.auditRequestor();
      if (StringUtils.isNullOrEmpty(auditRequestor)) {
         auditRequestor = getDataPoint(AuditStagingDataPointEnum.AUDITREQUESTOR);
      }
      return auditRequestor;
   }

   private String getDataPoint(AuditStagingDataPointEnum auditStagingDataPointEnum) {
      for (DataPoint dataPoint : dataPointHolder.getDataPoints()) {
         if (auditStagingDataPointEnum.name().equalsIgnoreCase(dataPoint.getName())) {
            return dataPoint.getStringValue();
         }
      }
      return null;
   }

   public void setAuditStagingDao(AuditStagingDao auditStagingDao) {
      this.auditStagingDao = auditStagingDao;
   }

   public void setApplicationContext(ApplicationContext applicationContext)
      throws BeansException
   {
      this.applicationContext = applicationContext;
   }

   public void setDataPointHolder(DataPointHolder dataPointHolder) {
      this.dataPointHolder = dataPointHolder;
   }

   public void setUserProfile(UserProfile userProfile) {
      this.userProfile = userProfile;
   }
}
