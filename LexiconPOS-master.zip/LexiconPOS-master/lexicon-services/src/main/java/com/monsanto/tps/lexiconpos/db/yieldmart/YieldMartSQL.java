package com.monsanto.tps.lexiconpos.db.yieldmart;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 3, 2005
 * Time: 1:00:48 PM
 * To change this template use File | Settings | File Templates.
 */
public interface YieldMartSQL
{
    String SELECT_BY_SEED_PRODUCT_ID = "MapProductMirage.SelectBySeedProductId";

    String ALIAS_SEED_PRODUCT_ID = "SeedProductID";
    String ALIAS_MIDAS_PROD_ID = "MidasProductID";
    String ALIAS_GEN_MAT_ID = "GeneticMaterialID";
    String ALIAS_MIRAGE_NAME = "ProductName";
}
