package com.monsanto.tps.lexiconpos.chemical.service.pos;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageChemProd;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 10:26:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChemicalMaterialRenderer
    implements ChemicalMaterialSchemaConstants
{
    private final MirageChemProd[] chemProducts;

    public ChemicalMaterialRenderer(MirageChemProd[] chemProducts) {
        this.chemProducts = chemProducts;
    }

    public void renderProducts(Element parent)
    {
        for (int i = 0; i < chemProducts.length; i++) {
            renderProduct(parent, chemProducts[i]);
        }
    }

    private void renderProduct(
        Element parent,
        MirageChemProd chemProduct)
    {
        Element productElement = DOMUtil.addChildElementWithNS(NAMESPACE, parent, chemProduct.getMaterialClassification());
        renderProductKey(productElement, chemProduct.getProductID());
        renderTradeName(productElement, chemProduct.getProductName());

        if (!ChemicalMaterialSchemaConstants.ACT_INGRED_ELEM_NAME.equals(chemProduct.getMaterialClassification())) {
            renderFormuatedAmount(productElement, chemProduct.getFormulatedAmount());
            renderFormulatedAmountName(productElement, chemProduct.getFormulatedAmountName());
            renderFormulationDesignation(productElement, chemProduct.getFormulationDesignation());
            renderActiveIngredients(productElement, chemProduct.getActiveIngredients());
        }
        renderMaterialClassification(productElement, chemProduct.getMaterialClassification());
    }

   private void renderProductKey(Element productElement, long productID) {
       DOMUtil.addChildElementWithNS(NAMESPACE, productElement, MAT_KEY_ELEM_NAME, Long.toString(productID));
   }

   private void renderTradeName(Element productElement, String tradeName) {
       DOMUtil.addChildElementWithNS(NAMESPACE,
           productElement, MAT_NAME_ELEM_NAME, tradeName);
   }

   private void renderMaterialClassification(Element productElement, String materialClassification) {
       DOMUtil.addChildElementWithNS(NAMESPACE,
          productElement, MAT_CLASS_ELEM_NAME, materialClassification);
   }

   private void renderFormuatedAmount(Element productElement, long formulatedAmount) {
       DOMUtil.addChildElementWithNS(NAMESPACE,
           productElement, FORMULATED_AMOUNT_ELEM_NAME, Long.toString(formulatedAmount));
   }

   private void renderFormulatedAmountName(Element productElement, String formulatedAmountName) {
       DOMUtil.addChildElementWithNS(NAMESPACE,
          productElement, FORMULATED_AMOUNT_UNIT_ELEM_NAME, formulatedAmountName);
   }

  private void renderFormulationDesignation(Element productElement, String formulationDesignation) {
     DOMUtil.addChildElementWithNS(NAMESPACE,
        productElement, FORM_DS_ELEM_NAME, formulationDesignation);
  }

   private void renderActiveIngredients(
       Element productElement,
       String[] activeIngredients)
   {
       if (activeIngredients != null) {
           StringBuffer buffer = new StringBuffer();
           for (int i = 0; i < activeIngredients.length; i++) {
               if (i > 0) {
                   buffer.append(",");
               }
               buffer.append(activeIngredients[i]);
           }
           DOMUtil.addChildElementWithNS(NAMESPACE, productElement, ACT_INGRED_ELEM_NAME, buffer.toString());
       }
   }

  public static Document createDocument() {
      return new DocumentCreator().createDocument(NAMESPACE, RESPONSE_ELEM_NAME);
  }
}
