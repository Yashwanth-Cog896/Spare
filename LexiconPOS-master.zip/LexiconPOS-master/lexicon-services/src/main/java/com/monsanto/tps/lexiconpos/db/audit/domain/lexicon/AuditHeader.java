package com.monsanto.tps.lexiconpos.db.audit.domain.lexicon;

import java.util.Collection;
import java.util.Date;

/**
 * nbwald - Aug 20, 2008 5:17:02 PM
 */
public class AuditHeader
{
   private long auditHeaderId;

   public long getAuditHeaderId() {
      return auditHeaderId;
   }

   public void setAuditHeaderId(long auditHeaderId) {
      this.auditHeaderId = auditHeaderId;
   }

   private String auditOperationType;

   public String getAuditOperationType() {
      return auditOperationType;
   }

   public void setAuditOperationType(String auditOperationType) {
      this.auditOperationType = auditOperationType;
   }

   private String tableName;

   public String getTableName() {
      return tableName;
   }

   public void setTableName(String tableName) {
      this.tableName = tableName;
   }

   private Date entryDate;

   public Date getEntryDate() {
      return entryDate;
   }

   public void setEntryDate(Date entryDate) {
      this.entryDate = entryDate;
   }

   private long primaryKeyField1;

   public long getPrimaryKeyField1() {
      return primaryKeyField1;
   }

   public void setPrimaryKeyField1(long primaryKeyField1) {
      this.primaryKeyField1 = primaryKeyField1;
   }

   private String processName;

   public String getProcessName() {
      return processName;
   }

   public void setProcessName(String processName) {
      this.processName = processName;
   }

   private String auditComment;

   public String getAuditComment() {
      return auditComment;
   }

   public void setAuditComment(String auditComment) {
      this.auditComment = auditComment;
   }

   private String auditRequestor;

   public String getAuditRequestor() {
      return auditRequestor;
   }

   public void setAuditRequestor(String auditRequestor) {
      this.auditRequestor = auditRequestor;
   }

   private String userLoginId;

   public String getUserLoginId() {
      return userLoginId;
   }

   public void setUserLoginId(String userLoginId) {
      this.userLoginId = userLoginId;
   }

   private Collection<AuditDetail> auditDetails;

   public Collection<AuditDetail> getAuditDetails() {
      return auditDetails;
   }

   public void setAuditDetails(Collection<AuditDetail> auditDetails) {
      this.auditDetails = auditDetails;
   }
}
