package com.monsanto.tps.lexiconpos.event.deregulated.service;

import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.tps.lexiconpos.event.deregulated.DeregulatedEventSchemaConstants;
import com.monsanto.tps.lexiconpos.event.deregulated.dom.DeregulatedEventRequestDOMImpl;
import com.monsanto.tps.lexiconpos.event.deregulated.dom.DeregulatedEventResponseDocumentRenderer;
import com.monsanto.tps.lexiconpos.event.deregulated.model.DeregulatedEventRequest;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 19, 2006
 * Time: 12:57:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeregulatedEventController
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return DeregulatedEventSchemaConstants.SCHEMA_LOC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      DeregulatedEventRequest request = getRequestModel(inputDocument);
      boolean isDeregulated = getResponse(request);
      return renderResponse(isDeregulated);
   }

   private DeregulatedEventRequest getRequestModel(Document inputDocument) {
      return new DeregulatedEventRequestDOMImpl(inputDocument);
   }

   private boolean getResponse(DeregulatedEventRequest request)
      throws WrappingException, CropMismatchException
   {
      DeregulatedEvent process = new DeregulatedEvent();
      return process.execute(request);
   }

   private Document renderResponse(boolean isDeregulated) {
      DeregulatedEventResponseDocumentRenderer renderer = new DeregulatedEventResponseDocumentRenderer(isDeregulated);
      return renderer.renderDocument();
   }
}
