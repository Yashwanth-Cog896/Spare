package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.businessaccount;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tcc.lexiconcommon.validation.validator.SingleResultValidator;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.FieldIsNotFullyWildcardedRule;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.SearchableLocationValidationRules;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.contact.SearchableLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jun 3, 2008 4:24:25 PM
 */
public class BusinessAccountSearchCriteriaValidatorImpl
   implements BusinessAccountSearchCriteriaValidator
{
   public void validate(BusinessAccountSearchCriteria criteria) {
      SingleResultValidator<String> validator = new SingleResultValidator<String>(getRules(criteria), null);
      String violation = validator.validate();
      if(violation != null) {
         throw new IllegalArgumentException(violation);
      }
   }

   private List<? extends Rule<String>> getRules(BusinessAccountSearchCriteria criteria) {
      List<Rule<String>> rules = new ArrayList<Rule<String>>();
      rules.add(new SomeBusinessAccountSearchCriteriaMustBeSpecifiedRule(criteria));
      rules.add(new FieldIsNotFullyWildcardedRule("Company", criteria.getCompanyName()));
      addLocationSpecificRules(rules, criteria.getLocation());
      return rules;
   }

   private void addLocationSpecificRules(List<Rule<String>> rules, SearchableLocation location) {
      rules.addAll(new SearchableLocationValidationRules().getSearchableLocationRules(location));
   }
}
