package com.monsanto.tps.lexiconpos.businessaccount;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 12, 2007
 * Time: 2:39:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddressRenderer
   implements BusinessAccountSchemaConstants
{
   private final Address address;

   public AddressRenderer(Address address) {
      this.address = address;
   }

   public void render(Element parent) {
      if (!StringUtils.isNullOrEmpty(address.getCity())) {
         Element addressElem = addAddressElem(parent);
         addAddrId(addressElem);
         addAddr1Elem(addressElem);
         addAddr2Elem(addressElem);
         addAddr3Elem(addressElem);
         addCityElem(addressElem);
         addCountyElem(addressElem);
         addStateElem(addressElem);
         addPostalCodeElem(addressElem);
         addCountryElem(addressElem);
         addPhoneNumberElem(addressElem);
      }
   }

   private Element addAddressElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDRESS_ELEM_NAME);
   }
   private void addAddrId(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDRESS_ID_ATTR_NAME, address.getAddressId());
   }
   private void addAddr1Elem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDR_LINE_1_ELEM_NAME, address.getAddress1());
   }
   private void addAddr2Elem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDR_LINE_2_ELEM_NAME, address.getAddress2());
   }
   private void addAddr3Elem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDR_LINE_3_ELEM_NAME, address.getAddress3());
   }
   private void addCityElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, CITY_ELEM_NAME, address.getCity());
   }
   private void addCountyElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, COUNTY_ELEM_NAME, address.getCounty());
   }
   private void addStateElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, STATE_ELEM_NAME, address.getState());
   }
   private void addPostalCodeElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, POSTAL_CODE_ELEM_NAME, address.getPostalCode());
   }
   private void addCountryElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, COUNTRY_ELEM_NAME, address.getCountry());
   }
   private void addPhoneNumberElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, PHONE_NUMBER_ELEM_NAME, address.getPhoneNumber());
   }
}
