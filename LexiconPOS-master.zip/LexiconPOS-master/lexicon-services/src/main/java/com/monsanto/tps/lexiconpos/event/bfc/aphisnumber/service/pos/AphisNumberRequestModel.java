package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 12:32:53 PM
 */
public class AphisNumberRequestModel
{
    private final String transCode;

    public AphisNumberRequestModel(String transCode) {
        this.transCode = transCode;
	}

	public String getRequestedTransCode() {
		return transCode;
	}
}
