package com.monsanto.tps.lexiconpos.businessaccount.company;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:21:11 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CompanyRequest
{
   String getCompanyName();
   String getAccountType();
}
