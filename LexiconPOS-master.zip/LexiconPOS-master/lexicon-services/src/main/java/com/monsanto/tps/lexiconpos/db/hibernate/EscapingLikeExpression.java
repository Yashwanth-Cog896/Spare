package com.monsanto.tps.lexiconpos.db.hibernate;

import org.hibernate.criterion.LikeExpression;

/**
 * rrchak1 - Mar 5, 2009 11:18:10 AM
 */
public class EscapingLikeExpression
    extends LikeExpression
{
   public EscapingLikeExpression(String property, String value, char escapeChar, boolean ignoreCase) {
      super(property,value,escapeChar,ignoreCase);
   }   
}
