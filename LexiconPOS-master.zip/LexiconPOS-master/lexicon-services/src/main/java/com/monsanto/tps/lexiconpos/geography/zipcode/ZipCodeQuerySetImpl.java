package com.monsanto.tps.lexiconpos.geography.zipcode;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Feb 7, 2007
 * Time: 4:59:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class ZipCodeQuerySetImpl
   implements ZipCodeQuerySet
{
   public boolean doesZipCodeExist(String zipCode)
      throws WrappingException
   {
      return new ZipCodeQuery(zipCode).doesZipCodeExist();
   }
}
