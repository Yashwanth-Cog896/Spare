/*
 BFCPersonByFullNameQuery was created on Oct 23, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.person;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.BFCPerson;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Oct 23, 2006 10:43:57 AM
 */
public class BFCPersonByFullNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String fullName;
   
   public BFCPersonByFullNameQuery(String fullName) {
      this.fullName = fullName;
   }

   public BFCPerson getPerson(PersistentStoreConnection bfcConnection) throws WrappingException {
      return (BFCPerson) execute(bfcConnection);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new BFCPersonPSRowImpl(row);
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(BFCPersonSQL.class).getSQL(BFCPersonSQL.SELECT_PERSON_BY_FULLNAME);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { fullName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new BFCConnectionFactoryProperties();
   }

}