/*
 AuditedTransaction was created on Jan 16, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.db.audit.transaction;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.monitor.TransactionMonitor;
import com.monsanto.tcc.lexiconcommon.db.monitor.TransactionMonitorManager;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUser;

/**
 * nbwald Jan 16, 2008 3:32:18 PM
 */
public abstract class AuditedTransaction
{
   private final LexSecureUser lexSecureUser;
   private final String processName;

   public AuditedTransaction(LexSecureUser lexSecureUser, String processName) {
      this.lexSecureUser = lexSecureUser;
      this.processName = processName;
   }

   public abstract void transact()
      throws WrappingException;

   public void execute()
      throws WrappingException
   {
      TransactionMonitor monitor = TransactionMonitorManager.getInstance().beginTransactionMonitor();
      try {
         setLexiconAuditor(monitor);
         transact();
         monitor.commitTransactions();
      }
      finally {
         monitor.deactivate();
      }
   }

   private void setLexiconAuditor(TransactionMonitor monitor)
      throws WrappingException
   {
      LexiconAuditor auditor = new LexiconAuditor(lexSecureUser.getLoginName(), processName, "", "");
      monitor.setInstanceAuditor(LexiconConnectionFactoryProperties.INSTANCE_NAME, auditor);
   }
}
