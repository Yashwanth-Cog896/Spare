package com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.event.deregulated.model.CropComlTrait;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 4, 2006
 * Time: 11:09:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class CropComlTraitByEventQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String event;

   public CropComlTraitByEventQuery(String event) {
      this.event = event;
   }

   public CropComlTrait getCropComlTrait()
      throws WrappingException, ComlTraitNotFoundException
   {
      Object cropComlTrait = execute();
      if (cropComlTrait == null) {
         throw new ComlTraitNotFoundException(event);
      }
      return (CropComlTrait)cropComlTrait;
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(EventCropComlTraitSQL.class).getSQL(EventCropComlTraitSQL.CROP_COML_TRAIT_BY_EVENT);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { StringUtils.toUpperCaseNull(event) };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new CropComlTraitPSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
