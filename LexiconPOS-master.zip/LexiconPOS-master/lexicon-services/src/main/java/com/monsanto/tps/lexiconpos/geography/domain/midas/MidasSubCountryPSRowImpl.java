package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 30, 2006
 * Time: 3:23:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasSubCountryPSRowImpl
   implements MidasSubCountry
{
   private String subCountryKey;
   private String subCountryName;
   private String subCountryAbbr;
   private String countryKey;

   public MidasSubCountryPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      subCountryKey = row.getString(getAlias(MidasGeographicRegionQuerySQL.SUB_COUNTRY_ID_ALIAS));
      subCountryName = row.getString(getAlias(MidasGeographicRegionQuerySQL.SUB_COUNTRY_NAME_ALIAS));
      subCountryAbbr = row.getString(getAlias(MidasGeographicRegionQuerySQL.SUB_COUNTRY_ABBR_ALIAS));
      countryKey = row.getString(getAlias(MidasGeographicRegionQuerySQL.COUNTRY_ID_ALIAS));
   }

   public String getSubCountryKey() {
      return subCountryKey;
   }

   public String getSubCountryName() {
      return subCountryName;
   }

   public String getSubCountryAbbr() {
      return subCountryAbbr;
   }

   public String getCountryKey() {
      return countryKey;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return getSQLPropFile().getAlias(propName);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MidasGeographicRegionQuerySQL.class);
   }
}
