package com.monsanto.tps.lexiconpos.event.bfc.permit;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tps.lexiconpos.permit.Permit;
import com.monsanto.tps.lexiconpos.permit.PermitRequest;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 17, 2006
 * Time: 3:53:25 PM
 */
public interface BFCPermitLookup
{
   public Permit getPermit(
      PersistentStoreConnection conn,
      PermitRequest request)
      throws WrappingException;
}
