package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctAddr;
import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctAddrType;
import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.AddressRecord;

/**
 * nbwald - Jul 31, 2008 6:04:09 PM
 */
public class AddressRecordBuilder
{
   public AddressRecord build(AcctAddr acctAddr) {
      AddressRecord addressRecord = new AddressRecord();
      addressRecord.setAddressId(String.valueOf(acctAddr.getAcctAddrId()));
      addressRecord.setAddressType(extractAddressTypeDescription(acctAddr));
      addressRecord.setAddress(buildAddress(acctAddr));
      return addressRecord;
   }

   private Address buildAddress(AcctAddr acctAddr) {
      AddressBuilder builder = new AddressBuilder();
      return builder.build(acctAddr);
   }

   private String extractAddressTypeDescription(AcctAddr contactAddr) {
      AcctAddrType addressType = contactAddr.getAcctAddrType();
      return addressType == null ? null : addressType.getDescr();
   }
}