package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 30, 2006
 * Time: 1:25:21 PM
 */
public class LexiconCountryByUNCodeQuery
    extends AbstractPersistentStoreSingleResultQuery
{
   private final String UNCode;

   public LexiconCountryByUNCodeQuery(String unCode) {
      this.UNCode = unCode;
   }

   public LexiconCountry getLexiconCountry()
      throws WrappingException
   {
      return (LexiconCountry)execute();
   }

   public LexiconCountry getLexiconCountry(PersistentStoreConnection lexConn)
      throws WrappingException
   {
      return (LexiconCountry)execute(lexConn);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new LexiconCountryPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(LexiconSQL.class).getSQL(LexiconSQL.SELECT_COUNTRY_BY_ABBR);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { UNCode };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
