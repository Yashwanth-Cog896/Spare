package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.product.common.domain.mirage.MirageProduct;
import com.monsanto.tps.lexiconpos.product.common.domain.mirage.MirageProductDTO;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 5, 2005
 * Time: 10:54:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageProductDTOBuilder
   implements MirageProduct
{
   private final MirageProductDTO product;

   public MirageProductDTOBuilder(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      product = new MirageProductDTO();
      product.setSeedProductID(row.getInt(getSQLPropFile().getAlias(MirageSQL.ALIAS_PROD_ID)));
      product.setCompanyID(row.getInt(getSQLPropFile().getAlias(MirageSQL.ALIAS_COMPANY_ID)));
      product.setCompanyName(row.getString(getSQLPropFile().getAlias(MirageSQL.ALIAS_COMPANY_NAME)));
      product.setProductName(row.getString(getSQLPropFile().getAlias(MirageSQL.ALIAS_PROD_NAME)));
      product.setBayerCode(row.getString(getSQLPropFile().getAlias(MirageSQL.ALIAS_BAYER_CODE)));
      product.setCountryCode(row.getString(getSQLPropFile().getAlias(MirageSQL.ALIAS_COUNTRY_CODE)));
      product.setTraitCharacteristicsID(row.getInt(getSQLPropFile().getAlias(MirageSQL.ALIAS_TRAIT_CHAR_CODE)));
      product.setMaturityRating(row.getString(getSQLPropFile().getAlias(MirageSQL.ALIAS_MAT_RATE)));
      product.setProductEnabled("Y".equals(row.getString(getSQLPropFile().getAlias(MirageSQL.ALIAS_ENABLED))));
      product.setDisabledDate(row.getDate(getSQLPropFile().getAlias(MirageSQL.ALIAS_DISABLED_DATE)));
   }

   public int getSeedProductID() {
      return product.getSeedProductID();
   }
   public String getProductName() {
      return product.getProductName();
   }
   public String getBayerCode() {
      return product.getBayerCode();
   }
   public int getCompanyID() {
      return product.getCompanyID();
   }
   public String getCompanyName() {
      return product.getCompanyName();
   }
   public String getCountryCode() {
      return product.getCountryCode();
   }
   public int getTraitCharacteristicsID() {
      return product.getTraitCharacteristicsID();
   }
   public String getMaturityRating() {
      return product.getMaturityRating();
   }
   public boolean isProductEnabled() {
      return product.isProductEnabled();
   }
   public Date getDisabledDate() {
      return product.getDisabledDate();
   }

   protected SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MirageSQL.class);
   }
}
