/*
 SegregateCrop was created on Jun 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

/**
 * @author PNAGAPP - Jun 25, 2008 1:15:02 PM
 */
public class SegregateCrop {

   private String publicKey;
   private String name;
   private String abbreviation;
   private String shippingStatement;
   private SegregateBayerCode bayerCode;

   public String getPublicKey() {
      return publicKey;
   }

   public void setPublicKey(String publicKey) {
      this.publicKey = publicKey;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

   public String getShippingStatement() {
      return shippingStatement;
   }

   public void setShippingStatement(String shippingStatement) {
      this.shippingStatement = shippingStatement;
   }

   public SegregateBayerCode getBayerCode() {
      return bayerCode;
   }

   public void setBayerCode(SegregateBayerCode bayerCode) {
      this.bayerCode = bayerCode;
   }
}
