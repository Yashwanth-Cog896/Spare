package com.monsanto.tps.lexiconpos.db.tempsession.dao.lexicon;


import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.monsanto.tps.lexiconpos.db.tempsession.domain.lexicon.TempSessionOcd;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.InterruptibleBatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.AbstractInterruptibleBatchPreparedStatementSetter;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * RLCASW - Feb 28, 2010 3:13:44 PM
 */
public class TempSessionOcdDaoImpl
        implements TempSessionOcdDao {
    private static final String DEFAULT_STRING = "I";
    private static final long DEFAULT_NUMBER = 0L;
    private JdbcTemplate jdbcTemplate;
    private static final String TEMP_SESSION_INSERT =
            "insert into lexicon.temp_session_ocd tso (request_id, number_1, number_2, text_1, text_2, sort_order) " +
                    "values(?, ?, ?, ?, ?, ?)";
    private static final Long DEFAULT_SORT_ORDER = 0L;

    @Override
    @Transactional
    public void insertText1Values(final Long requestId, final Collection<String> ids) {
        final ArrayList<String> idsList = Lists.newArrayList(ids);
        final Long[] currentSortOrder = {DEFAULT_SORT_ORDER};
        jdbcTemplate.batchUpdate(TEMP_SESSION_INSERT, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setLong(1, requestId);
                ps.setLong(2, DEFAULT_NUMBER);
                ps.setObject(3, null);
                ps.setString(4, idsList.get(i));
                ps.setObject(5, null);
                ps.setLong(6, currentSortOrder[0]++);
            }

            @Override
            public int getBatchSize() {
                return idsList.size();
            }
        });
    }

    @Override
    @Transactional
    public void insertNumber1Values(final long requestId, Collection<Long> values) {
        final ArrayList<Long> longValueList = Lists.newArrayList(values);
        final Long[] currentSortOrder = {DEFAULT_SORT_ORDER};
        jdbcTemplate.batchUpdate(TEMP_SESSION_INSERT, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setLong(1, requestId);
                ps.setLong(2, longValueList.get(i));
                ps.setObject(3, null);
                ps.setString(4, DEFAULT_STRING);
                ps.setObject(5, null);
                ps.setLong(6, currentSortOrder[0]++);
            }

            @Override
            public int getBatchSize() {
                return longValueList.size();
            }
        });
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}