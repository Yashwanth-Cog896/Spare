/*
 IsGermplasmAttachedToProductQuery was created on Jul 25, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 25, 2007 9:56:16 AM
 */
public class IsGermplasmAttachedToProductQuery
   extends AbstractPersistentStoreEntityExistsQuery
{
   private final long germplasmID;

   public IsGermplasmAttachedToProductQuery(long germplasmID) {
      this.germplasmID = germplasmID;
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.IS_GERMPLASM_ATTACHED_TO_PRODUCT);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { germplasmID };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}