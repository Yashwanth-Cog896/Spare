package com.monsanto.tps.lexiconpos.event.deregulated.dao;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 29, 2006
 * Time: 1:56:22 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RegulatoryAgency {
   long getAgencyID();
   String getAgencyName();
}
