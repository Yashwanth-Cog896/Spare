package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.domain.collections.GermplasmCollection;

/**
 * nbwald - Feb 20, 2009 10:39:06 AM
 */
public class GermplasmQueryResults
{
   private GermplasmCollection germplasms;
   private int countFromGermplasmCriteria;

   public GermplasmQueryResults(GermplasmCollection germplasms, int countFromGermplasmCriteria) {
      this.germplasms = germplasms;
      this.countFromGermplasmCriteria = countFromGermplasmCriteria;
   }

   public GermplasmCollection getCollection() {
      return germplasms;
   }

   public int getCountFromGermplasmCriteria() {
      return countFromGermplasmCriteria;
   }
}
