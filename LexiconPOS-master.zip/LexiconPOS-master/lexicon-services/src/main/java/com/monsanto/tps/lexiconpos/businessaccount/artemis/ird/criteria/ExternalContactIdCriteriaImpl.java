package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    ExternalContactIdCriteriaImpl.java
 * Last Change: rrchak1 On:	Aug 7, 2008
 *
 * @author: rrchak1
 */
public class ExternalContactIdCriteriaImpl
   implements QueryCriteria
{
   private long[] contactIds;

   public ExternalContactIdCriteriaImpl(long[] contactIds) {
      this.contactIds = contactIds;
   }

   public Criterion getCriterion() {
      return Restrictions.in(BusinessAccountSchemaConstants.CONTACT_ID, ArrayUtils.toObject(contactIds));
   }

   public boolean hasCriteria() {
      return !ArrayUtils.isEmpty(contactIds);
   }
}
