package com.monsanto.tps.lexiconpos.event.deregulated;

import com.monsanto.tcc.lexiconcommon.string.StringTable;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 20, 2006
 * Time: 3:58:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeregulatedEventStringTable
   extends StringTable
{
   protected String getFilename() throws IOException {
      return "DeregulatedEventStringTable.properties";
   }
}
