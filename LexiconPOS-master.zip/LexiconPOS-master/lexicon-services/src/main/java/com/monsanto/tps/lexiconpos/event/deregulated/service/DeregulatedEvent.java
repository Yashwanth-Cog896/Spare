package com.monsanto.tps.lexiconpos.event.deregulated.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait.ComlTraitNotFoundException;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconCountryByPubkeyQuery;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.event.deregulated.model.DeregulatedEventRequest;
import com.monsanto.tps.lexiconpos.event.deregulated.model.StackApprovalVerificationRequest;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 19, 2006
 * Time: 4:10:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeregulatedEvent {

    public boolean execute(DeregulatedEventRequest deregEventRequest) throws WrappingException, CropMismatchException {
        try {
            if (!isUSAOrCanada(deregEventRequest.getCountryPubkey())) {
                return false;
            }
            CropComlTraits cropComlTraits = new CropComlTraits(deregEventRequest.getEvents());
            cropComlTraits.validateSameCrop();
            return areStacksDeregulated(cropComlTraits, deregEventRequest);
        }
        catch (ComlTraitNotFoundException e) {
            return false;
        }
    }

    private boolean isUSAOrCanada(String countryPubkey) throws WrappingException {
        LexiconCountryByPubkeyQuery query = new LexiconCountryByPubkeyQuery(countryPubkey);
        LexiconCountry country = query.getLexiconCountry();
        if (country != null) {
            return "USA".equalsIgnoreCase(country.getUNCodeStr()) || "CAN".equalsIgnoreCase(country.getUNCodeStr()) ||
                    "TESTCTRY".equalsIgnoreCase(country.getName());
        }
        return false;
    }

    private boolean areStacksDeregulated(CropComlTraits cropComlTraits, DeregulatedEventRequest deregEventRequest)
            throws WrappingException {
        String cropName = cropComlTraits.getCropName();
        String[] comlTraitNames = cropComlTraits.getComlTraitNames();
        StackApprovalVerificationRequest request = new StackApprovalVerificationRequest(cropName, comlTraitNames, deregEventRequest.getCountryPubkey(), deregEventRequest.getSubCountryPubkey());
        return getAgencyApproval(request) && getStateApproval(request);
    }

    private boolean getAgencyApproval(StackApprovalVerificationRequest request) throws WrappingException {
        AgencyApprovalVerification process = new AgencyApprovalVerification(request);
        return process.isDeregulated();
    }

    private boolean getStateApproval(StackApprovalVerificationRequest request) throws WrappingException {
        String[] stackAbbrs = getAllStacks(request);
        for (int i = 0; i < stackAbbrs.length; i++) {
            StateRegistrationVerification process = new StateRegistrationVerification(stackAbbrs[i], request.getCropName(), request.getCountryPubkey(), request.getSubCountryKeys());
            if (!process.isDeregulatedAtStateLevel()) {
                return false;
            }
        }
        return true;
    }

    private String[] getAllStacks(StackApprovalVerificationRequest request) {
        Set allStacks = new HashSet();
        addStackstoSet(request.getIndividualStacks(), allStacks);
        addStackstoSet(request.getStackedStacks(), allStacks);
        return (String[]) allStacks.toArray(new String[allStacks.size()]);
    }

    private void addStackstoSet(String[] stacks, Set allStacks) {
        for (int i = 0; i < stacks.length; i++) {
            allStacks.add(stacks[i]);
        }
    }
}
