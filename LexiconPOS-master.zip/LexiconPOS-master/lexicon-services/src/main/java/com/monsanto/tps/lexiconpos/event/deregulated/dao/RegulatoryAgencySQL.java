package com.monsanto.tps.lexiconpos.event.deregulated.dao;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 29, 2006
 * Time: 1:58:20 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RegulatoryAgencySQL
{
   String ALIAS_REGULATORY_AGENCY_ID = "RegulatoryAgencyID";
   String ALIAS_REGULATORY_AGENCY_NAME = "RegulatoryAgencyName";
   String REGULATORY_AGENCIES_BY_COUNTRY_PUBKEY_SQL = "RegulatoryAgency.SelectByCountryPubkey";

}
