package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Last Change: rrchak1 On:	Aug 7, 2008
 *
 * @author: rrchak1
 */
public class BusinessAccountIdCriteriaImpl
        implements QueryCriteria {
    private final long[] businessAccountIds;

    public BusinessAccountIdCriteriaImpl(long[] businessAccountIds) {
        this.businessAccountIds = businessAccountIds;
    }

    public Criterion getCriterion() {
        Criterion criterion = null;
        int numGroups = (businessAccountIds.length / 1000) + 1;
        for (int i = 0; i < numGroups; i++) {
            int start = i * 1000;
            int end = (start + 1000 < businessAccountIds.length) ? start + 1000 : businessAccountIds.length;
            long[] group = ArrayUtils.subarray(businessAccountIds, start, end);

            Criterion inRestriction = Restrictions.in(BusinessAccountSchemaConstants.ACCT_ID, ArrayUtils.toObject(group));
            if (criterion == null) {
                criterion = inRestriction;
            } else {
                criterion = Restrictions.or(criterion, inRestriction);
            }
        }

        return criterion;
    }

    public boolean hasCriteria() {
        return !ArrayUtils.isEmpty(businessAccountIds);
    }
}
