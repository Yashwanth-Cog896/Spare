/*
 GermplasmLookupQuerySet was created on Jan 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.domain.midas.GeneticMaterial;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.MidasProductGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 22, 2007 3:09:46 PM
 */
public interface ProductGermplasmWithSourcesQuerySet
{
   Germplasm getGermplasm(long germplasmID)
      throws WrappingException;

   MidasProductGermplasm getProductGermplasm(long midasGermplasmID)
      throws WrappingException;

   GeneticMaterial[] getGeneticMaterial(long midasGermplasmID)
      throws WrappingException;

   String getProductPubkey(long midasProductID)
      throws WrappingException;
}