/*
 GetCountryAction was created on Nov 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.geography.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.artemis.dao.CountryDAO;
import com.monsanto.tps.lexiconpos.geography.artemis.dao.CountryDAOImpl;
import com.monsanto.tps.lexiconpos.geography.artemis.model.GetCountryByUNCodeRequest;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.geography.Country;

/**
 * nbwald Nov 1, 2007 2:03:33 PM
 */
public class GetCountryByUNCodeAction
   extends AbstractArtemisServiceAction
{
   private final CountryDAO countryDAO;

   public GetCountryByUNCodeAction() {
      this(new CountryDAOImpl());
   }

   public GetCountryByUNCodeAction(CountryDAO countryDAO) {
      this.countryDAO = countryDAO;
   }

   public void process(ServiceProcessContext context) {
      GetCountryByUNCodeRequest request = new GetCountryByUNCodeRequest(context);
      LexiconCountry lexiconCountry = countryDAO.findCountryByUNCode(request.getUNCode());
      saveResponse(context, lexiconCountry);
   }

   private void saveResponse(ServiceProcessContext context, LexiconCountry lexiconCountry) {
      if(lexiconCountry != null) {
         Country country = createCountry(lexiconCountry);
         ResponseEnvelope responseEnvelope = context.getResponseEnvelope();
         responseEnvelope.add(country);
      }
   }

   private Country createCountry(LexiconCountry lexiconCountry) {
      return new Country(
         lexiconCountry.getPublicKey(),
         lexiconCountry.getName(),
         lexiconCountry.getUNCodeStr(),
         lexiconCountry.getUNCode(),
         lexiconCountry.getISOCode());
   }
}