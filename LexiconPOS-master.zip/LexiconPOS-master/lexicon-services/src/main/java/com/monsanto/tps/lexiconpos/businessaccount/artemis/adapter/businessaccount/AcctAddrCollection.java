package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.AcctAddr;
import com.monsanto.tps.lexicon.contact.AddressRecord;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Filename: AcctAddrCollection.java
 * Last Change: rrchak1 On: Aug 6, 2008
 *
 * @author: rrchak1
 */
public class AcctAddrCollection {

   private final Collection<AcctAddr> accountAddrs;

   public AcctAddrCollection(Collection<AcctAddr> acctAddrs) {
      this.accountAddrs = acctAddrs;
   }

   public AddressRecord[] getAddressRecords() {
      return accountAddrs == null ? new AddressRecord[0] : getAddressRecordsFromNonNullAcctAddrs();
   }

   private AddressRecord[] getAddressRecordsFromNonNullAcctAddrs() {
      List<AddressRecord> addressRecords = new ArrayList<AddressRecord>();
      for (AcctAddr acctAddr : accountAddrs) {
         AddressRecordBuilder builder = new AddressRecordBuilder();
         addressRecords.add(builder.build(acctAddr));
      }
      return addressRecords.toArray(new AddressRecord[addressRecords.size()]);
   }
}
