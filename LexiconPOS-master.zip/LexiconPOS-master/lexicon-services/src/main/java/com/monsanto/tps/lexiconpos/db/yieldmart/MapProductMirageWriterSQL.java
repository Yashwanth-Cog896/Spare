package com.monsanto.tps.lexiconpos.db.yieldmart;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 29, 2006
 * Time: 9:54:00 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MapProductMirageWriterSQL {
   String INSERT_MAP_PRODUCT_MIRAGE = "MapProdMirage.Insert";
   String UPDATE_MAP_PRODUCT_MIRAGE_PRODUCT = "MapProdMirage.UpdateProduct";
}
