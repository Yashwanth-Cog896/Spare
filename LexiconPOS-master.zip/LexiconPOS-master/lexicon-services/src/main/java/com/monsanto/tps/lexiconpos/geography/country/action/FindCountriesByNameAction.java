/*
 FindCountriesByNameAction was created on Jun 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.country.contract.CountryNameRequest;
import com.monsanto.tps.lexiconpos.geography.country.query.CountryQuerySet;
import com.monsanto.tps.lexiconpos.geography.country.query.CountryQuerySetImpl;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexicon.geography.country.Country;

import java.util.List;

/**
 * @author GGSHIV - Jun 4, 2008 10:07:05 AM
 */
public class FindCountriesByNameAction extends AbstractArtemisServiceAction {

   private final CountryQuerySet countryQuerySet;

   public FindCountriesByNameAction() {
      this(new CountryQuerySetImpl());
   }

   public FindCountriesByNameAction(CountryQuerySet countryQuerySet) {
      this.countryQuerySet = countryQuerySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      CountryNameRequest request = new CountryNameRequest(context);
      List<Country> countries = countryQuerySet.findCountriesByName(request.getName());
      new MultipleResultResponse(countries).saveResponse(context);
   }
}
