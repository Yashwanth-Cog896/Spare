package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.businessaccount.Address;
import com.monsanto.tps.lexiconpos.businessaccount.AddressRenderer;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 4:11:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyRenderer
   implements BusinessAccountSchemaConstants
{
   private final Company company;

   public CompanyRenderer(Company company)
   {
      this.company = company;
   }

   public void render(Element parent)
   {
      Element companyElem = addCompanyElem(parent);
      renderCompanyInfo(companyElem);
   }
   private Element addCompanyElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, COMPANY_ELEM_NAME);
   }
   private void renderCompanyInfo(Element parent) {
      addAcctIdElem(parent);
      addCompanyNameElem(parent);
      addAddressInfo(parent);
   }
   private void addAcctIdElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, ACCOUNT_ID_ELEM_NAME, company.getAcctId());
   }
   private void addCompanyNameElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, COMPANY_NAME_ELEM_NAME, company.getCompanyName());
   }
   private void addAddressInfo(Element parent) {
      Element addressesElem = addAddressesElem(parent);
      addAddressElems(addressesElem);
   }
   private Element addAddressesElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDRESSES_ELEM_NAME);
   }

   private void addAddressElems(Element parent) {
      Address[] addresses = company.getAddresses();
      for (int i = 0; i < addresses.length; i++) {
         AddressRenderer addressRenderer = new AddressRenderer(addresses[i]);
         addressRenderer.render(parent);
      }
   }
}
