package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 1:50:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class CountryRenderer
    implements GeographicEntityRenderer,
               GeographySchemaConstants
{
    public void render(
        Element element,
        GeographicEntity entity)
    {
        LexiconCountry country = getCountry(entity);
        Element countryElement = DOMUtil.addChildElementWithNS(NAMESPACE, element, COUNTRY_ELEM_NAME);
        countryElement.setAttribute(PUBKEY_ELEM_NAME, country.getPublicKey());
        DOMUtil.addChildElementWithNS(NAMESPACE, countryElement, NAME_ELEM_NAME, country.getName());
        DOMUtil.addChildElementWithNS(NAMESPACE, countryElement, UN_CODE_ELEM_NAME, country.getUNCodeStr());
        DOMUtil.addChildElementWithNS(NAMESPACE, countryElement, ISO_CODE_ELEM_NAME, country.getISOCode());
        DOMUtil.addChildElementWithNS(NAMESPACE, countryElement, UN_NUMERIC_CODE_ELEM_NAME, country.getUNCode());
    }

    private LexiconCountry getCountry(GeographicEntity entity) {
        return (LexiconCountry)entity;
    }
}
