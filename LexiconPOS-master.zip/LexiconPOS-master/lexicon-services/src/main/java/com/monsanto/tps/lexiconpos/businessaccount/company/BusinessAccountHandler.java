package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.tps.lexiconpos.businessaccount.Address;
import com.monsanto.tps.lexiconpos.businessaccount.ird.IRDCompanyService;
import com.monsanto.tps.lexiconpos.businessaccount.ird.IRDCompanyServiceResponse;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 13, 2007
 * Time: 1:37:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessAccountHandler
{
   public Company[] getCompanies(CompanyRequest request)
      throws WrappingException
   {
      IRDCompanyServiceResponse response = getServiceResponse(request);
      return consolidateAddresses(response.getCompanies());
   }

   protected IRDCompanyServiceResponse getServiceResponse(CompanyRequest request)
      throws WrappingException
   {
      IRDCompanyService service = new IRDCompanyService();
      IRDCompanyServiceResponse response = service.getServiceResult(request);
      if (response.isErrorResponse()) {
         throw new WrappingException(new Exception(response.getErrorMsg()));
      }
      return response;
   }

   private Company[] consolidateAddresses(Company[] companies)
   {
      Map<String, Company> addressConsolidator = new HashMap<String, Company>();
      for (Company company : companies) {
         consolidateAddress(company, addressConsolidator);
      }
      Collection<Company> modifiedCompanies = addressConsolidator.values();
      return modifiedCompanies.toArray(new Company[modifiedCompanies.size()]);
   }

   private void consolidateAddress(Company company, Map<String, Company> addressConsolidator)
   {
      if (contains(addressConsolidator, company)) {
         Address[] newAddressSet = company.getAddresses();
         Company existingCompany = addressConsolidator.get(company.getAcctId());
         Company updatedCompany = getUpdatedCompany(existingCompany, newAddressSet);
         addressConsolidator.put(updatedCompany.getAcctId(), updatedCompany);
      } else {
         addressConsolidator.put(company.getAcctId(), company);
      }
   }

   private boolean contains(Map<String, Company> addressConsolidator, Company company) {
      return addressConsolidator.containsKey(company.getAcctId());
   }

   private Company getUpdatedCompany(Company company, Address[] addresses) {
      CompanyImpl companyImpl = new CompanyImpl(company);
      companyImpl.addAddresses(addresses);
      return companyImpl;
   }
}
