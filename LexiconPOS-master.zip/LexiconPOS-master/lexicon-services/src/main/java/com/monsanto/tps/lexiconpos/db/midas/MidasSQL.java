package com.monsanto.tps.lexiconpos.db.midas;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 10, 2005
 * Time: 2:36:22 PM
 */
public interface MidasSQL
{
   String ALIAS_PROD_NAME = "ProductName.Name";
   String ALIAS_PROD_NAME_ID = "ProductName.ID";
   String ALIAS_PROD_ID = "Product.ID";
   String ALIAS_CROP_ID = "Crop.ID";
   String ALIAS_CROP_NAME = "Crop.Name";
   String ALIAS_BRAND_ID = "Brand.ID";
   String ALIAS_BRAND_NAME = "Brand.Name";
   String ALIAS_COUNTRY_ID = "Country.ID";
   String ALIAS_NAME_ACTIVE = "ProductName.Active";
   String ALIAS_PREFERRED_NAME = "ProductName.PreferredName";
   String ALIAS_PROD_ACTIVE = "Product.Active";
   String ALIAS_DENOM = "Product.Denomination";
   String ALIAS_LEX_PROD_PK = "LexProdPubkey";
   String ALIAS_REL_MAT = "Trait.RelativeMaturity";
   String ALIAS_PRODUCT_GERMPLASM_ID = "productGermplasmId";
   String ALIAS_PRODUCT_GERMPLASM_IS_PREFFERED = "ProductGermplasm.isPreferred";
   String ALIAS_GP_ID = "GP.ID";
   String ALIAS_GP_ORIGIN = "GP.Origin";
   String ALIAS_GP_LINE_CODE = "GP.LineCode";
   String ALIAS_GP_PEDIGREE = "GP.Pedigree";
   String ALIAS_GP_EVENT_DISPLAY = "GP.EventDisplay";
   String ALIAS_GP_IS_TRANSGEN = "GP.IsTransgenic";
   String ALIAS_GP_IS_DELETED = "GP.IsDeleted";
   String ALIAS_GP_FIN_FLAG = "GP.IsFinished";
   String ALIAS_OWNER_PROG_REF = "GP.OwnerProgRefID";

   String ALIAS_LT_LINE_TYPE = "LT.LineType";

   String ALIAS_GM_ID = "GM.ID";
   String ALIAS_GM_LINEAGE = "GM.Lineage";
   String ALIAS_GM_SOURCE = "GM.Source";
   String ALIAS_GM_GENERATION = "GM.Generation";

   String SELECT_DISTINCT_MON_NAMES_BY_PROD_ID = "ProductName.DistinctMonsantoCount";
   String SELECT_PROD_BY_PROD_ID = "Product.SelectByProdId";
   String SELECT_PROD_BY_LEXICON_PROD_PUBKEY = "Product.SelectByLexiconProdPubkey";
   String SELECT_PROD_NAME_BY_MODEL = "ProductName.SelectByModel";
   String SELECT_PROD_NAME_BY_PRODID_BRAND_COUNTRY = "ProductName.SelectByProdIDBrandCountry";
   String SELECT_PROD_NAME_BY_NAME_ID = "ProductName.SelectByNameId";
   String SELECT_PROD_NAMES_BY_PROD_ID = "ProductName.SelectByProdId";
   String SELECT_PROD_NAMES_BY_NAME_BRAND_COUNTRY = "ProductName.SelectByNameBrandCountry";
   String SELECT_GLOBAL_PC_NAMES = "ProductName.SelectGlobalPCNames";
   String SELECT_PROD_NAME_BY_PC_NAME = "ProductName.SelectByPCName";
   String SELECT_GENETIC_MATERIAL_BY_PROD_ID = "GeneticMaterial.SelectByProdId";
   String SELECT_GENETIC_MATERIAL_BY_GP_ID = "GeneticMaterial.SelectByGPId";
   String SELECT_MIRAGE_GM_BY_PROD_ID = "GeneticMaterial.SelectMirageGMByProdId";
   String SELECT_GERMPLASMS_BY_PROD_ID = "Germplasm.SelectByProdId";
   String SELECT_PRODUCT_GERMPLASMS_BY_PROD_ID = "ProductGermplasm.SelectByProdId";
   String SELECT_GERMPLASMS_BY_GP_ID = "Germplasm.SelectByGermplasmID";
   String SELECT_GERMPLASMS_BY_PROD_PUBKEY = "Germplasm.SelectByProdPubkey";

   String SELECT_GERMPLASMS_BY_CROP_AND_WC_ORIGIN = "Germplasm.SelectByCropNameAndWildcardableOrigin";
   String SELECT_GERMPLASMS_BY_CROP_AND_WC_PEDIGREE = "Germplasm.SelectByCropNameAndWildcardablePedigree";
   String SELECT_GERMPLASMS_BY_CROP_AND_WC_LINECODE = "Germplasm.SelectByCropNameAndWildcardableLineCode";
   String SELECT_GERMPLASMS_BY_CROP_AND_PROD_PUBKEY = "Germplasm.SelectByCropNameAndProdPubkey";

   String SELECT_SLIM_GPS_BY_CROP_AND_ORIGIN = "SlimGermplasm.SelectByCropNameAndOrigin";
   String SELECT_SLIM_GPS_BY_CROP_AND_LINECODE = "SlimGermplasm.SelectByCropNameAndLineCode";
   String SELECT_SLIM_GPS_BY_CROP_AND_PEDIGREE = "SlimGermplasm.SelectByCropNameAndPedigree";
   String SELECT_SLIM_GPS_BY_CROP_AND_PROD_PUBKEY = "SlimGermplasm.SelectByCropNameAndProdPubkey";

   String SELECT_PROD_GP_BY_GP_ID = "ProductGermplasm.SelectPGByGermplasmID";
   String SELECT_PROD_GP_BY_P_ID = "ProductGermplasm.SelectPGByProductID";

   String IS_GERMPLASM_ATTACHED_TO_PRODUCT = "Germplasm.IsAttachedToProduct";
   String IS_VALID_ORIGIN_BY_PUBKEY = "Germplasm.IsValidOriginByPubkey";
   String IS_VALID_LINECODE_BY_PUBKEY = "Germplasm.IsValidLineCodeByPubkey";
   String IS_VALID_PEDIGREE_BY_PUBKEY = "Germplasm.IsValidPedigreeByPubkey";

   String SELECT_COUNTRY_NAME_BY_PRODUCT_NAME = "CountryName.SelectByProductName";
}
