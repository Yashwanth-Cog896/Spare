package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 13, 2006
 * Time: 10:22:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateMidasProductDataMod
   extends AbstractPersistentStoreInsert
{
   private final long productID;
   private final long cropID;
   private final String denomination;

   public CreateMidasProductDataMod(long productID, long cropID, String denomination) {
      this.productID = productID;
      this.cropID = cropID;
      this.denomination = denomination;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MidasWriterSQL.class);
      return propFile.getSQL(MidasWriterSQL.INSERT_PRODUCT);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(productID), new Long(cropID), denomination, "T" };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
