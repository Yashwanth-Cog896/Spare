package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.Address;
import com.monsanto.tps.lexiconpos.businessaccount.AddressRenderer;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 4:23:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactRenderer
   implements BusinessAccountSchemaConstants
{
   private final ExternalContact contact;

   public ExternalContactRenderer(ExternalContact contact) {
      this.contact = contact;
   }

   public void render(Element parent) {
      Element externalContactElem = addExternalContactElem(parent);
      addContactIdElem(externalContactElem);
      addCompanyInfo(externalContactElem);
      addContactInfo(externalContactElem);
   }

   private Element addExternalContactElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, EXTERNAL_CONTACT_ELEM_NAME);
   }
   private void addContactIdElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, CONTACT_ID_ELEM_NAME, contact.getContactId());
   }

   private void addCompanyInfo(Element parent) {
      addAcctIdElem(parent);
      addCompanyNameElem(parent);
      addAddressInfo(parent);
   }
   private void addAcctIdElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, ACCOUNT_ID_ELEM_NAME, contact.getAcctId());
   }
   private void addCompanyNameElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, COMPANY_ELEM_NAME, contact.getCompanyName());
   }
   private void addAddressInfo(Element parent) {
      Element addressesElem = addAddressesElem(parent);
      addAddressElems(addressesElem);
   }

   private void addContactInfo(Element externalContactElem) {
      addLastNameElem(externalContactElem);
      addFirstNameElem(externalContactElem);
      addMiddleNameElem(externalContactElem);
      addJobTitleElem(externalContactElem);
      addEmailElem(externalContactElem);
      addFaxNumberElem(externalContactElem);
      addCellNumberElem(externalContactElem);
      addPagerNumberElem(externalContactElem);
   }

   private Element addAddressesElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, ADDRESSES_ELEM_NAME);
   }
   private void addAddressElems(Element parent) {
      Address[] addresses = contact.getAddresses();
      for (int i = 0; i < addresses.length; i++) {
         AddressRenderer addressRenderer = new AddressRenderer(addresses[i]);
         addressRenderer.render(parent);
      }
   }
   private void addLastNameElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, LAST_NAME_ELEM_NAME, contact.getLastName());
   }

   private void addFirstNameElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, FIRST_NAME_ELEM_NAME, contact.getFirstName());
   }

   private void addMiddleNameElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, MIDDLE_NAME_ELEM_NAME, contact.getMiddleName());
   }

   private void addJobTitleElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, JOB_TITLE_ELEM_NAME, contact.getTitle());
   }

   private void addEmailElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, EMAIL_ELEM_NAME, contact.getEmailAddress());
   }

   private void addFaxNumberElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, FAX_NUMBER_ELEM_NAME, contact.getFaxNumber());
   }

   private void addCellNumberElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, CELL_NUMBER_ELEM_NAME, contact.getCellNumber());
   }

   private void addPagerNumberElem(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, PAGER_NUMBER_ELEM_NAME, contact.getPagerNumber());
   }
}
