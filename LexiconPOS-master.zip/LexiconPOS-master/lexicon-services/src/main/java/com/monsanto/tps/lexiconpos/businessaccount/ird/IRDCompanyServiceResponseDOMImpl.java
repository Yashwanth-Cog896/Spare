package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.businessaccount.company.Company;
import com.monsanto.tps.lexiconpos.businessaccount.company.CompanyDOMImpl;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:25:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class IRDCompanyServiceResponseDOMImpl implements IRDCompanyServiceResponse {
   private final Document doc;

   public IRDCompanyServiceResponseDOMImpl(Document doc) {
      this.doc = doc;
   }

   public Company[] getCompanies()
   {
      Element rowElement;
      Element root = getRootElement();
      List companies = new ArrayList();
      NodeList rowElements = getRowElements(root);
      for (int i = 0; i < rowElements.getLength(); i++) {
         rowElement = (Element) rowElements.item(i);
         companies.add(getCompany(rowElement));
      }
      return (Company[]) companies.toArray(new Company[companies.size()]);
   }

   public boolean isErrorResponse()
   {
      return !StringUtils.isNullOrEmpty(getErrorMsg());
   }

   public String getErrorMsg() {
      Element root = getRootElement();
      try {
         Node errorNode = XPathAPI.selectSingleNode(root, BusinessAccountSchemaConstants.RESPONSE_ELEM_NAME + "/" + BusinessAccountSchemaConstants.ERROR_ELEM_NAME);
         return errorNode == null ? null : DOMUtil.getChildValue(errorNode, BusinessAccountSchemaConstants.MSG_ELEM_NAME);
      } catch (TransformerException e) {
         return e.getMessage();
      }
   }

   private Company getCompany(Element parent)
   {
      return new CompanyDOMImpl(parent);
   }

   private NodeList getRowElements(Element parent) {
      return parent.getElementsByTagName(BusinessAccountSchemaConstants.ROW_ELEM_NAME);
   }

   private Element getRootElement() {
      return doc.getDocumentElement();
   }
}
