package com.monsanto.tps.lexiconpos.db;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 28, 2006
 * Time: 5:30:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class TPSPersistentStoreConnectionFactory
{
   private final TPSPersistentStoreConnection delagatedConnection;

   public TPSPersistentStoreConnectionFactory() {
      this.delagatedConnection = null;
   }

   public TPSPersistentStoreConnectionFactory( TPSPersistentStoreConnection inDelagatedConnection) {
      
      this.delagatedConnection = new DelegateTPSPersistentStoreConnection(inDelagatedConnection);

     
   }

   public TPSPersistentStoreConnection getConnection() {
      return (delagatedConnection == null) ? new TPSPersistentStoreConnection() : delagatedConnection;
   }

}
