/*
 CountryQuerySetImpl was created on Jun 11, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.query;

import com.monsanto.tps.lexicon.geography.country.Country;

import java.util.List;

/**
 * @author GGSHIV - Jun 11, 2008 3:33:00 PM
 */
public class CountryQuerySetImpl implements CountryQuerySet {

   public List<Country> findCountriesByISOCodes(String[] countryISOCodes) {
      return new CountriesByISOCodesQuery(countryISOCodes).findCountries();
   }

   public List<Country> findCountriesByName(String countryName) {
      return new CountriesByNameQuery(countryName).findCountries();
   }
}
