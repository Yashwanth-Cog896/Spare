package com.monsanto.tps.lexiconpos.event.deregulated.model;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 4, 2006
 * Time: 11:30:02 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CropComlTrait
{
   String getCropName();
   String getComlTraitName();
}
