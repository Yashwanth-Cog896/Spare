/*
 CropsByPubkeysAndScientificNameQuery was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.StringsCriteriaBuilder;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.SELECT_BY_SCIENTIFIC_NAME;
import static com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet.CROP_SQL_PROPERTY_FILE;
import com.monsanto.tps.lexicon.crop.CropPublicKeyType;
import static com.monsanto.tps.lexicon.crop.CropPublicKeyType.CROP;

import java.util.List;

/**
 * @author PNAGAPP - Jul 1, 2008 11:42:09 AM
 */
public class CropsByPubkeysAndScientificNameQuery extends AbstractPersistentStoreMultiRowQuery {

   private final String[] pubkeys;
   private final WildcardableCriteria scientificName;
   private final CropPublicKeyType pubKeyType;

   public CropsByPubkeysAndScientificNameQuery(String[] pubkeys, WildcardableCriteria scientificName, CropPublicKeyType pubKeyType) {
      this.pubkeys = pubkeys;
      this.scientificName = scientificName;
      this.pubKeyType = null == pubKeyType ? CROP : pubKeyType;
   }

   public List<SegregateCrop> find() throws WrappingException {
      return getList();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new SegregateCropBuilder().build(row);
   }

   protected String getSQL() throws WrappingException {
      return CROP_SQL_PROPERTY_FILE.getSQL(SELECT_BY_SCIENTIFIC_NAME) + " AND UPPER(" + pubKeyType.getType() + ") IN ("
              + new StringsCriteriaBuilder().build(pubkeys) + ") ORDER BY " + pubKeyType.getType();
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]{scientificName.oracleVersion()};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }

}

