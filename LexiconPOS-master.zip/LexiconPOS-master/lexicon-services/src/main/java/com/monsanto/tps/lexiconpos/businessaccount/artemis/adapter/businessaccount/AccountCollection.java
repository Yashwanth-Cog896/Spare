package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexicon.account.BusinessAccount;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jul 30, 2008 3:28:25 PM
 */
public class AccountCollection {
    private final Acct[] accounts;

    public AccountCollection(Acct[] accounts) {
        this.accounts = accounts;
    }

    public BusinessAccount[] getBusinessAccounts() {
        return accounts == null ? new BusinessAccount[0] : getBusinessAccountsFromNonNullAccounts();
    }

    private BusinessAccount[] getBusinessAccountsFromNonNullAccounts() {
        List<BusinessAccount> businessAccounts = new ArrayList<BusinessAccount>();
        for (Acct acct : accounts) {
            BusinessAccountBuilder builder = new BusinessAccountBuilder();
            businessAccounts.add(builder.build(acct));
        }
        return businessAccounts.toArray(new BusinessAccount[businessAccounts.size()]);
    }
}