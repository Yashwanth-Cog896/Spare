package com.monsanto.tps.lexiconpos.db.tempsession.dao.lexicon;

import java.util.Collection;

/**
 * RLCASW - Feb 28, 2010 3:12:23 PM
 */
public interface TempSessionOcdDao
{
   void insertText1Values(Long requestId, Collection<String> ids);

   void insertNumber1Values(long requestId, Collection<Long> values);
}