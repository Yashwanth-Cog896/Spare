package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.GeneticMaterial;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 25, 2006
 * Time: 7:22:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class GeneticMaterialPSRowImpl
   implements GeneticMaterial
{
   private final long geneticMaterialID;
   private final String materialSource;
   private final String lineage;
   private final String generation;
   private final long germplasmID;

   public GeneticMaterialPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.geneticMaterialID = row.getLong(getAlias(MidasSQL.ALIAS_GM_ID));
      this.germplasmID = row.getLong(getAlias(MidasSQL.ALIAS_GP_ID));
      this.materialSource = row.getString(getAlias(MidasSQL.ALIAS_GM_SOURCE));
      this.generation = row.getString(getAlias(MidasSQL.ALIAS_GM_GENERATION));
      this.lineage = row.getString(getAlias(MidasSQL.ALIAS_GM_LINEAGE));
   }

   public long getGeneticMaterialID() {
      return geneticMaterialID;
   }
   public String getMaterialSource() {
      return materialSource;
   }
   public String getLineage() {
      return lineage;
   }
   public String getGeneration() {
      return generation;
   }
   public long getGermplasmID() {
      return germplasmID;
   }

   private String getAlias(String ident)
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getAlias(ident);
   }

}
