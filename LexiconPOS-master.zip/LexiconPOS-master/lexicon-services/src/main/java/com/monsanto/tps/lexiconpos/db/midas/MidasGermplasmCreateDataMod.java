package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 29, 2006
 * Time: 3:37:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGermplasmCreateDataMod
   extends AbstractPersistentStoreInsert
{
   private final long germplasmID;
   private final String origin;
   private final String lineCode;
   private final String pedigreeName;
   private final String lineTypeRefID;
   private final String cropName;
   private final String ownerProgramRefID;
   private final String eventDisplay;
   private final boolean isTransgenic;
   private final boolean isFinished;

   public MidasGermplasmCreateDataMod(long germplasmID, String origin, String lineCode, String pedigreeName,
      String lineTypeRefID, String cropName, String ownerProgramRefID,
      String eventDisplay, boolean transgenic, boolean finished)
   {
      this.germplasmID = germplasmID;
      this.origin = origin;
      this.lineCode = lineCode;
      this.pedigreeName = pedigreeName;
      this.lineTypeRefID = lineTypeRefID;
      this.cropName = cropName;
      this.ownerProgramRefID = ownerProgramRefID;
      this.eventDisplay = eventDisplay;
      isTransgenic = transgenic;
      isFinished = finished;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MidasWriterSQL.class);
      return propFile.getSQL(MidasWriterSQL.INSERT_GERMPLASM);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(germplasmID), origin, lineCode, pedigreeName, 
         lineTypeRefID, cropName, ownerProgramRefID, eventDisplay,
         isTransgenic ? "T" : "F",
         isFinished ? "T" : "F"
      };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
