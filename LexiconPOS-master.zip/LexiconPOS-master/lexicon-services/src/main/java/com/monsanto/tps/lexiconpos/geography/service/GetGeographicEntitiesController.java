package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 5:15:03 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class GetGeographicEntitiesController
   extends LexiconPOSController
{
   protected abstract GeographyRequestParser getGeographyRequestParser();
   protected abstract GeographyRequestProcessor getGeographyRequestProcessor();
   protected abstract GeographicEntityRenderer getEntityRenderer();
   protected abstract String getResponseDocumentElementName();

   protected String getXMLSchemaRelativeToServletContext() {
      return GeographySchemaConstants.SCHEMA_LOC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      TPSPersistentStoreConnection conn = getConnection();
      try {
         GeographyRequestModel requestModel = getRequestModel(inputDocument);
         GeographicEntity[] entities = processModel(requestModel, conn);
         return renderResponse(entities);
      }
      finally {
         closeConnection(conn);
      }
   }

   protected GeographyRequestModel getRequestModel(Document inputDocument)
      throws InvalidGeographyRequestException
   {
      GeographyRequestParser parser = getGeographyRequestParser();
      return parser.parse(inputDocument);
   }

   protected GeographicEntity[] processModel(GeographyRequestModel requestModel, TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      GeographyRequestProcessor processor = getGeographyRequestProcessor();
      return processor.getMatchingGeography(requestModel, conn);
   }

   private Document renderResponse(GeographicEntity[] entities) {
      Document response = createResponseDocument();
      Element root = response.getDocumentElement();

      GeographicEntityRenderer renderer = getEntityRenderer();
      for (GeographicEntity entity : entities) {
         renderer.render(root, entity);
      }
      return response;
   }

   private Document createResponseDocument() {
      return new DocumentCreator().createDocument(
         GeographySchemaConstants.NAMESPACE, getResponseDocumentElementName());
   }

   protected TPSPersistentStoreConnection getConnection() {
      return new TPSPersistentStoreConnection();
   }

   protected void closeConnection(TPSPersistentStoreConnection conn) {
      conn.close();
   }
}
