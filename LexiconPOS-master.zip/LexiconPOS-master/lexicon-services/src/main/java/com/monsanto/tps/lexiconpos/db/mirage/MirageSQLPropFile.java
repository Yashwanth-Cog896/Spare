package com.monsanto.tps.lexiconpos.db.mirage;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 13, 2005
 * Time: 9:40:10 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageSQLPropFile
{
    String INSERT_SEED_PRODUCT = "SeedProduct.Insert";
    String UPDATE_SEED_PRODUCT = "SeedProduct.Update";
    String UPDATE_EQUIV_PRODUCT = "SeedProduct.UpdateEquiv";
    String UPDATE_ENABLED_PRODUCT = "SeedProduct.UpdateEnabled";
    String UPDATE_PRODUCT_NAME = "SeedProduct.UpdateName";

    String INSERT_MATURITY = "ProductMaturity.Insert";
    String UPDATE_MATURITY = "ProductMaturity.Update";
    String DELETE_MATURITY = "ProductMaturity.Delete";

    String INSERT_AUDIT = "Audit.Insert";

    String SELECT_PROD_BY_MODEL = "SeedProduct.SelectByModel";
    String SELECT_PROD_BY_PROD_ID = "SeedProduct.SelectByProdId";
    String SELECT_PROD_BY_CRITERIA = "SeedProduct.SelectByCriteria";
    String SELECT_PRE_COML_BY_LINKED_ID = "SeedProduct.SelectPreComlByLinkedId";
    String SELECT_PRE_COML_EQUIV = "SeedProduct.SelectPreComlEquiv";
    String PRODUCT_ID_USE = "SeedProduct.InUse";

    String PROD_ID_ALAIS = "ProductId";
    String PROD_NAME_ALIAS = "ProductName";
    String COMPANY_ID_ALIAS = "CompanyId";
    String COMPANY_NAME_ALIAS = "CompanyName";
    String BAYER_CODE_ALIAS = "BayerCode";
    String COUNTRY_CODE_ALIAS = "CountryCode";
    String TRAIT_CHAR_CODE_ALIAS = "TraitCode";
    String ENABLED_ALIAS = "Enabled";
    String DISABLED_DATE_ALIAS = "DisabledDate";
    String MAT_RATE_ALAIS = "MaturityRating";
    String EQUIV_ID_ALAIS = "EquivalentId";
    String LINKED_ID_ALIAS = "LinkedId";
    String PRE_COML_PROD_ID = "PreComlProductId";
}
