package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:53:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyResponseDocumentRenderer
   implements BusinessAccountSchemaConstants
{
   private final Company[] companies;


   public CompanyResponseDocumentRenderer(Company[] companies)
   {
      this.companies = companies;
   }

   public Document render()
   {
      Document doc = DOMUtil.newDocument();
      Element root = createRootElement(doc);
      Element companiesElem = renderCompaniesElem(root);
      renderCompanies(companiesElem);
      return doc;
   }

   private Element createRootElement(Document doc)
   {
      Element root = DOMUtil.addChildElementWithNS(NAMESPACE, doc, BUSINESS_ACCT_RESP_ELEM_NAME);
      root.setAttribute("xmlns", NAMESPACE);
      root.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
      return root;
   }

   private Element renderCompaniesElem(Element parent) {
      return DOMUtil.addChildElementWithNS(NAMESPACE, parent, COMPANIES_ELEM_NAME);
   }

   private void renderCompanies(Element parent)
   {
      CompanyRenderer renderer;
      for (int i = 0; i < companies.length; i++) {
         renderer = new CompanyRenderer(companies[i]);
         renderer.render(parent);
      }
   }

}
