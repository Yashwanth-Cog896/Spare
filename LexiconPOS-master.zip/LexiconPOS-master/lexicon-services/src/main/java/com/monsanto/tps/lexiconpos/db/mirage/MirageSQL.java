package com.monsanto.tps.lexiconpos.db.mirage;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 2, 2005
 * Time: 10:02:14 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageSQL
{
   String ALIAS_PROD_ID = "ProductID";
   String ALIAS_PROD_NAME = "ProductName";
   String ALIAS_COMPANY_ID = "CompanyID";
   String ALIAS_BAYER_CODE = "BayerCode";
   String ALIAS_COMPANY_NAME = "CompanyName";
   String ALIAS_COUNTRY_CODE = "CountryCode";
   String ALIAS_TRAIT_CHAR_CODE = "TraitCode";
   String ALIAS_ENABLED = "Enabled";
   String ALIAS_DISABLED_DATE = "DisabledDate";
   String ALIAS_MAT_RATE = "Maturity";

   String SELECT_PROD_BY_MODEL = "SeedProduct.SelectByModel";
   String SELECT_PROD_BY_PROD_ID = "SeedProduct.SelectByProdId";

   String INSERT_AUDIT = "Audit.Insert";

   String ALIAS_CHEM_PROD_ID = "ProductID";
   String ALIAS_TRADE_NAME = "TradeName";
   String ALIAS_FULL_TRADE_NAME = "FullTradeName";
   String ALIAS_ACTIVE_INGRED_CODE = "ActiveIngredCode";
   String ALIAS_ACTIVE_INGRED_NAME = "ActiveIngredName";
   String ALIAS_ACTIVE_INGRED_FULLNAE = "ActiveIngredFullName";
   String ALIAS_FORMULATED_AMOUNT = "FormulatedAmount";
   String ALIAS_FORMULATED_AMOUNT_NAME = "FormulatedAmountName";
   String ALIAS_FORM_DS = "FormulationDesignation";

   String SELECT_CHEM_PROD_BY_WC_NAME = "ChemicalProduct.Commercial.SelectByWCName";
   String SELECT_FORMULATION_BY_WC_NAME = "ChemicalProduct.Formulation.SelectByWCName";
   String SELECT_ACT_INGRED_BY_WC_NAME = "ChemicalProduct.ActiveIngred.SelectByWCName";
   String SELECT_ACT_INGREDS_BY_CP = "ChemicalProduct.ActiveIngred.SelectByCP";
}
