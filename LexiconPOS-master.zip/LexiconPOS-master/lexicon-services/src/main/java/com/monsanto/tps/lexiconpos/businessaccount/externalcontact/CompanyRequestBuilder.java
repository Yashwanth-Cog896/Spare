package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.company.CompanyRequest;
import com.monsanto.tps.lexiconpos.businessaccount.company.CompanyRequestImpl;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 15, 2007
 * Time: 12:19:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyRequestBuilder
{
   public CompanyRequest[] getUniqueCompanyRequests(ExternalContact[] externalContacts, String accountType) {
      String[] uniqueCompanyNames = getUniqueCompanyNames(externalContacts);
      return createCompanyRequests(uniqueCompanyNames, accountType);
   }

   private String[] getUniqueCompanyNames(ExternalContact[] externalContacts) {
      Set companyNames = new HashSet();
      for (int i = 0; i < externalContacts.length; i++) {
         companyNames.add(externalContacts[i].getCompanyName());
      }
      return (String[]) companyNames.toArray(new String[companyNames.size()]);
   }

   private CompanyRequest[] createCompanyRequests(String[] uniqueCompanyNames, String accountType) {
      CompanyRequest[] companyRequests = new CompanyRequest[uniqueCompanyNames.length];
      for (int i = 0; i < uniqueCompanyNames.length; i++) {
         companyRequests[i] = new CompanyRequestImpl(uniqueCompanyNames[i], accountType);
      }
      return companyRequests;
   }
}
