package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.AddressDOMImpl;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 2, 2007
 * Time: 2:34:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactAddressDOMImpl
   extends AddressDOMImpl
{
   public ExternalContactAddressDOMImpl(Element row) {
      super(row);
   }

   public String getPhoneNumber() {
      return getFieldNodeValue(BUS_NUMBER_ATTR_NAME);
   }

   public String getAddressId() {
      return getFieldNodeValue(CONTACT_ADDRID_ATTR_NAME);
   }
}
