package com.monsanto.tps.lexiconpos.db.factories.virgo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactoryProperties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 9, 2006
 * Time: 3:30:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class VirgoConnectionFactoryProperties
   implements ConnectionFactoryProperties
{
   private MirageConnectionFactoryProperties mirageProps = new MirageConnectionFactoryProperties();

   public String getInstanceName() {
      return mirageProps.getInstanceName();
   }

   public String getUserName()
      throws WrappingException
   {
      return mirageProps.getUserName();
   }

   public String getPassword()
      throws WrappingException
   {
      return mirageProps.getPassword();
   }

   public String getDataSource()
      throws WrappingException
   {
      return mirageProps.getDataSource();
   }

   public String getSequenceName()
      throws WrappingException
   {
      return mirageProps.getSequenceName();
   }

   public int getMinPoolSize()
      throws WrappingException
   {
      return mirageProps.getMinPoolSize();
   }

   public int getMaxPoolSize()
      throws WrappingException
   {
      return mirageProps.getMaxPoolSize();
   }

   public String getJndiName()
      throws WrappingException
   {
      return mirageProps.getJndiName();
   }

    @Override
    public String getConnectionString() throws WrappingException {
        return mirageProps.getConnectionString();
    }
}
