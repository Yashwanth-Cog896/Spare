/*
 FindCropsByAbbreviationsAndScientificNameAction was created on Jun 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.CropAbbreviationAndScientificNameRequest;

import java.util.List;

/**
 * @author GGSHIV - Jun 30, 2008 1:26:36 PM
 */
public class FindCropsByAbbreviationsAndScientificNameAction extends AbstractArtemisServiceAction {

   private final CropQuerySet cropQuerySet;

   public FindCropsByAbbreviationsAndScientificNameAction(CropQuerySet cropQuerySet) {
      this.cropQuerySet = cropQuerySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      CropAbbreviationAndScientificNameRequest request = (CropAbbreviationAndScientificNameRequest) context.getRequestPayload();
      List<Crop> crops = cropQuerySet.findByAbbreviationsAndScientificName(request.getAbbreviations(), request.getScientificName());
      new MultipleResultResponse(crops).saveResponse(context);
   }
}
