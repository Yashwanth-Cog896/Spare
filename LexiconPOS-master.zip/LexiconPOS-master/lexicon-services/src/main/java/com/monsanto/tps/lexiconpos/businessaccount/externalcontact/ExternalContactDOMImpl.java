package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.Address;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import javax.xml.transform.TransformerException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 3:48:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactDOMImpl
   implements ExternalContact, BusinessAccountSchemaConstants
{
   private final Element row;
   public ExternalContactDOMImpl(Element row) {
      this.row = row;
   }

   public String getContactId() {
      return getFieldNodeValue(CONTACT_ID_ATTR_NAME);
   }
   public String getAcctId() {
      return getFieldNodeValue(ACCT_ID_ATTR_NAME);
   }
   public String getCompanyName() {
      return getFieldNodeValue(NAME_1_ATTR_NAME);
   }
   public String getLastName() {
      return getFieldNodeValue(LAST_NAME_ATTR_NAME);
   }
   public String getFirstName() {
      return getFieldNodeValue(FIRST_NAME_ATTR_NAME);
   }
   public String getMiddleName() {
      return getFieldNodeValue(MIDDLE_NAME_ATTR_NAME);
   }
   public String getTitle() {
      return getFieldNodeValue(JOB_TITLE_ATTR_NAME);
   }
   public String getPhoneNumber() {
      return getFieldNodeValue(BUS_NUMBER_ATTR_NAME);
   }
   public String getAltPhoneNumber() {
      return null;
   }
   public String getFaxNumber() {
      return getFieldNodeValue(FAX_NUMBER_ATTR_NAME);
   }
   public String getCellNumber() {
      return getFieldNodeValue(CELL_NUMBER_ATTR_NAME);
   }
   public String getPagerNumber() {
      return getFieldNodeValue(PAGER_NUMBER_ATTR_NAME);
   }
   public String getEmailAddress() {
      return getFieldNodeValue(EMAIL_ATTR_NAME);
   }
   public String getActiveStatus() {
      return null;
   }
   public Address[] getAddresses() {
      return new Address[] {new ExternalContactAddressDOMImpl(row)};
   }

   protected String getFieldNodeValue(String attributeName) {
      try {
         String path = getFieldNameAttributePath() + attributeName + "']/text()";
         Node node = XPathAPI.selectSingleNode(row, path);
         return (node == null) ? null : node.getNodeValue();
      }
      catch (TransformerException e) {
         throw new RuntimeException(e);
      }
   }
   private String getFieldNameAttributePath() {
      return new StringBuffer(FIELD_ELEM_NAME)
         .append("[@")
         .append(NAME_ATTR_NAME)
         .append("='").toString();
   }
}
