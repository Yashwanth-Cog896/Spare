package com.monsanto.tps.lexiconpos.db.fbscommon;

import com.monsanto.tps.lexiconpos.product.common.domain.fbscommon.FBSCommonProductNameXref;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 24, 2007
 * Time: 11:27:38 AM
 * To change this template use File | Settings | File Templates.
 */
public interface FBSCommonProductNameXrefByProductAliasPubkeyQuery
{
   FBSCommonProductNameXref getXref()
      throws WrappingException;
}
