package com.monsanto.tps.lexiconpos.db.yieldmart;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.product.common.domain.yieldmart.YieldMartProduct;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 5, 2005
 * Time: 11:17:29 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MapProductMirageLookup
{
    public YieldMartProduct getProductMapping(
        int mirageSeedProductID,
        PersistentStoreConnection yieldMartConn)
        throws WrappingException;
}
