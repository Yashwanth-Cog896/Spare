package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.tps.lexiconpos.tps.linetype.LineTypeRef;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jul 13, 2006
 * Time: 5:03:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmPSRowImpl
   implements Germplasm
{
   private long midasGermplasmID;
   private String origin;
   private String lineCode;
   private String pedigree;
   private String lineType;
   private String cropName;
   private String ownerProgRefID;
   private String eventDisplay;
   private boolean transgenic;
   private boolean finishedFlag;
   private boolean deleted;

   public GermplasmPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.midasGermplasmID = row.getLong(getAlias(MidasSQL.ALIAS_GP_ID));
      this.origin = row.getString(getAlias(MidasSQL.ALIAS_GP_ORIGIN));
      this.lineCode = row.getString(getAlias(MidasSQL.ALIAS_GP_LINE_CODE));
      this.pedigree = row.getString(getAlias(MidasSQL.ALIAS_GP_PEDIGREE));
      this.lineType = row.getString(getAlias(MidasSQL.ALIAS_LT_LINE_TYPE));
      this.cropName = row.getString(getAlias(MidasSQL.ALIAS_CROP_NAME));
      this.ownerProgRefID = row.getString(getAlias(MidasSQL.ALIAS_OWNER_PROG_REF));
      this.eventDisplay = row.getString(getAlias(MidasSQL.ALIAS_GP_EVENT_DISPLAY));
      this.transgenic = ("T".equalsIgnoreCase(row.getString(getAlias(MidasSQL.ALIAS_GP_IS_TRANSGEN))));
      this.finishedFlag = ("T".equalsIgnoreCase(row.getString(getAlias(MidasSQL.ALIAS_GP_FIN_FLAG))));
      this.deleted = ("T".equalsIgnoreCase(row.getString(getAlias(MidasSQL.ALIAS_GP_IS_DELETED))));
   }

   public long getMidasGermplasmID() {
      return midasGermplasmID;
   }
   public String getOrigin() {
      return origin;
   }
   public String getLineCode() {
      return lineCode;
   }
   public String getPedigree() {
      return pedigree;
   }
   public String getLineType() {
      return lineType;
   }
   public String getCropName() {
      return cropName;
   }
   public String getOwnerProgRefID() {
      return ownerProgRefID;
   }
   public String getEventDisplay() {
      return eventDisplay;
   }
   public boolean isTransgenic() {
      return transgenic;
   }
   public boolean isDeleted() {
      return deleted;
   }

   public boolean isFinished() {
      return (LineTypeRef.HYBRID.equals(lineType)) ?
              finishedFlag : LineTypeRef.FINISHED.equals(lineType);
   }

   private String getAlias(String ident)
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getAlias(ident);
   }
}
