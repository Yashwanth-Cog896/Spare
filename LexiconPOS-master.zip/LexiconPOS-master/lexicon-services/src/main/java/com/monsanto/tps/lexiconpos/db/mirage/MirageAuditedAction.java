package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.factories.PersistentStoreConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.monitor.MonitoredConnectionFactory;
import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactoryProperties;

/**
 * nbwald - Aug 14, 2009 7:14:37 PM
*/
public abstract class MirageAuditedAction
{
   public int execute()
      throws WrappingException
   {
      PersistentStoreConnection conn = getConnection();
      try {
         return execute(conn);
      }
      finally {
         conn.close();
      }
   }

   public int execute(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      MirageAuditor mirageAuditor = new MirageAuditor();
      int auditId = createAuditRecord(mirageAuditor, mirageConn);
      return performAction(auditId, mirageConn);
   }

   private PersistentStoreConnection getConnection()
      throws WrappingException
   {
      PersistentStoreConnectionFactory factory = new MonitoredConnectionFactory(new MirageConnectionFactoryProperties());
      return factory.getConnection();
   }

   private int performAction(int auditId, PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      String sql = getSQL();
      PersistentStoreStatement statement = mirageConn.prepareStatement(sql);
      try {
         setBindVariables(statement, auditId);
         return performAction(statement);
      }
      finally {
         statement.close();
      }
   }

   private void setBindVariables(PersistentStoreStatement stmt, int auditId)
      throws WrappingException
   {
      Object[] params = getBindVariables(auditId);
      for (int i = 0; i < params.length; i++) {
         stmt.setParam(i + 1, params[i]);
      }
   }

   protected abstract int performAction(PersistentStoreStatement statement)
      throws WrappingException;

   protected abstract String getSQL()
   throws WrappingException;

   protected abstract Object[] getBindVariables(int auditId);

   protected abstract int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
      throws WrappingException;
}
