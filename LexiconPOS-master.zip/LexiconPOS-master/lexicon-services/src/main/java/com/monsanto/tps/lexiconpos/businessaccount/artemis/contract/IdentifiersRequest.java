package com.monsanto.tps.lexiconpos.businessaccount.artemis.contract;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;

/**
 * nbwald - May 14, 2008 3:03:22 PM
 */
public class IdentifiersRequest
{
   private final long[] ids;

   public IdentifiersRequest(ServiceProcessContext context) {
      ids = (long[]) context.getRequestPayload();
   }

   public long[] getIds() {
      return ids;
   }
}
