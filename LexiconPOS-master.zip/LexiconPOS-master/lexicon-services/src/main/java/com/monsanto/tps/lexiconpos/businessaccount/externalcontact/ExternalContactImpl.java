package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.Address;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 13, 2007
 * Time: 2:33:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactImpl
   implements ExternalContact
{
   private final ExternalContact contact;
   private List addresses = new ArrayList();

   public ExternalContactImpl(ExternalContact contact) {
      this.contact = contact;
      initAddresses();
   }

   private void initAddresses()
   {
      Address[] addressArr = contact.getAddresses();
      addAddresses(addressArr);
   }

   public void addAddress(Address address) {
      addresses.add(address);
   }
   public void addAddresses(Address[] addressArr) {
      for (int i = 0; i < addressArr.length; i++) {
         Address address = addressArr[i];
         addAddress(address);
      }
   }

   public String getContactId() {
      return contact.getContactId();
   }
   public String getAcctId() {
      return contact.getAcctId();
   }
   public String getCompanyName() {
      return contact.getCompanyName();
   }

   public Address[] getAddresses() {
      return (Address[]) addresses.toArray(new Address[addresses.size()]);
   }

   public String getLastName() {
      return contact.getLastName();
   }
   public String getFirstName() {
      return contact.getFirstName();
   }
   public String getMiddleName() {
      return contact.getMiddleName();
   }
   public String getTitle() {
      return contact.getTitle();
   }
   public String getAltPhoneNumber() {
      return contact.getAltPhoneNumber();
   }
   public String getFaxNumber() {
      return contact.getFaxNumber();
   }
   public String getCellNumber() {
      return contact.getCellNumber();
   }
   public String getPagerNumber() {
      return contact.getPagerNumber();
   }
   public String getEmailAddress() {
      return contact.getEmailAddress();
   }
   public String getActiveStatus() {
      return contact.getActiveStatus();
   }
}
