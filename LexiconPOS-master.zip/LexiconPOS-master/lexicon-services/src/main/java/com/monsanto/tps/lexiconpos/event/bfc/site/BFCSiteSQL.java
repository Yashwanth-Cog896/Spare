package com.monsanto.tps.lexiconpos.event.bfc.site;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 20, 2006
 * Time: 3:47:35 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BFCSiteSQL
{
   String ALIAS_SITE_KEY = "SiteKey";
   String ALIAS_FARM_NAME = "FarmName";
   String ALIAS_FULL_ADDRESS  = "FullAddress";
   String ALIAS_CITY = "City";
   String ALIAS_ISLAND_TOWNSHIP = "IslandTownship";
   String ALIAS_SUB_SUB_COUNTRY = "SubSubCountry";
   String ALIAS_SUB_COUNTRY = "SubCountry";
   String ALIAS_COUNTRY = "Country";
   String ALIAS_POSTAL_CODE = "PostalCode";

   String SITE_SELECT_FROM_STRUT = "Site.SelectFromStrut";
   String SITE_STATUS_CONDITION = "Site.StatusCondition";
   String SITE_FARM_NAME_CONDITION = "Site.FarmNameCondition";
   String SITE_ADDRESS_CONDITION = "Site.AddressCondition";
   String SITE_CITY_CONDITION = "Site.CityCondition";
   String SITE_ISLAND_TOWNSHIP_CONDITION = "Site.IslandTownshipCondition";
   String SITE_SUB_SUB_COUNTRY_CONDITION = "Site.SubSubCountryCondition";
   String SITE_SUB_COUNTRY_CONDITION = "Site.SubCountryCondition";
   String SITE_COUNTRY_CONDITION = "Site.CountryCondition";
   String SITE_POSTAL_CODE_CONDITION = "Site.PostalCodeCondition";
   String SITE_KEY_CONDITION = "Site.KeyCondition";
}
