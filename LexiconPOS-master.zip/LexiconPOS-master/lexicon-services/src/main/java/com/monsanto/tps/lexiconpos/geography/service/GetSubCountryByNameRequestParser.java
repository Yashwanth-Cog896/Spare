package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.tps.lexiconpos.util.strings.GeographyStringTable;
import com.monsanto.Util.StringUtils;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 7:14:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubCountryByNameRequestParser
    extends GeographyRequestParser
{
    public static String getInvalidRequestError() {
        return new GeographyStringTable().getString(GeographyStringTable.INVALID_SUBCOUNTRY_NAME_REQUEST);
    }

    public static String getInvalidRequestError2() {
        return new GeographyStringTable().getString(GeographyStringTable.INVALID_SUBCOUNTRY_NAME_REQUEST2);
    }

    protected GeographyRequestModel parse(Element root)
        throws InvalidGeographyRequestException
    {
        String countryPubkey = getCountryPubkey(root);
        String subCountryName = getSubCountryName(root);
        String subCountryAbbr = getSubCountryAbbr(root);

        GetSubCountryByNameRequestModel requestModel =
            new GetSubCountryByNameRequestModel(countryPubkey, subCountryName, subCountryAbbr);

        validateSubCountryName(requestModel);
        return requestModel;
    }

    private void validateSubCountryName(GetSubCountryByNameRequestModel requestModel)
        throws InvalidGeographyRequestException
    {
        if (StringUtils.isNullOrEmpty(requestModel.getSubCountryName()) &&
            StringUtils.isNullOrEmpty(requestModel.getSubCountryAbbr()))
        {
            throw new InvalidGeographyRequestException(getInvalidRequestError());
        }
        else if (StringUtils.isNullOrEmpty(requestModel.getCountryPubkey())) {
            throw new InvalidGeographyRequestException(getInvalidRequestError2());
        }
    }
}
