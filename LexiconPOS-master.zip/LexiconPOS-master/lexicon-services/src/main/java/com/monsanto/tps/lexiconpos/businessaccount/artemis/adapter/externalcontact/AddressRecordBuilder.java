package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactAddr;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactAddrType;
import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.AddressRecord;

/**
 * nbwald - Jul 31, 2008 6:04:09 PM
 */
public class AddressRecordBuilder
{
   public AddressRecord build(ContactAddr contactAddr) {
      AddressRecord addressRecord = new AddressRecord();
      addressRecord.setAddressId(String.valueOf(contactAddr.getContactAddrId()));
      addressRecord.setAddressType(extractAddressTypeDescription(contactAddr));
      addressRecord.setAddress(buildAddress(contactAddr));
      return addressRecord;
   }

   private Address buildAddress(ContactAddr contactAddr) {
      AddressBuilder builder = new AddressBuilder();
      return builder.build(contactAddr);
   }

   private String extractAddressTypeDescription(ContactAddr contactAddr) {
      ContactAddrType addressType = contactAddr.getContactAddrType();
      return addressType == null ? null : addressType.getDescr();
   }
}
