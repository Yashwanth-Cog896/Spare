package com.monsanto.tps.lexiconpos.businessaccount;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 12, 2007
 * Time: 10:55:20 AM
 * To change this template use File | Settings | File Templates.
 */
public interface Address
{
   String getAddressId();
   String getAddress1();
   String getAddress2();
   String getAddress3();
   String getCity();
   String getCounty();
   String getState();
   String getCountry();
   String getPostalCode();
   String getPhoneNumber();
}
