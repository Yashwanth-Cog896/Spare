package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    ContactFunctionContactTypeCriteriaImpl.java
 * Last Change: rrchak1 On: Jul 30, 2008
 * 
 * @author: rrchak1
 */
public class ContactFunctionContactTypeCriteriaImpl
   implements QueryCriteria
{
   private final String contactType;

   public ContactFunctionContactTypeCriteriaImpl(String contactType) {
      this.contactType = contactType;
   }

   public Criterion getCriterion() {
      return Restrictions.eq("id.functionTypeCode", contactType);
   }

   public boolean hasCriteria() {
      return StringUtils.isNotEmpty(contactType);
   }
}
