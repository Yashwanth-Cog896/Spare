/*
 BFCPersonSQL was created on Oct 19, 2006 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.person;

/**
 * nbwald Oct 19, 2006 2:05:38 PM
 */
public interface BFCPersonSQL {
   String SELECT_SRR = "Person.SRR.Lookup";
   String ALIAS_USER_ID = "UserId";
   String ALIAS_PERSON_ID = "PersonId";
   String SELECT_PERSON_BY_FULLNAME = "Person.PermitRequester.Lookup";
}