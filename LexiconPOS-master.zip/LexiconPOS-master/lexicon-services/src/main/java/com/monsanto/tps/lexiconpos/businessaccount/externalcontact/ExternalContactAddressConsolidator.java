package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.company.Company;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 15, 2007
 * Time: 12:24:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactAddressConsolidator
{
   private final ExternalContact[] externalContacts;
   private final Company[] companies;

   public ExternalContactAddressConsolidator(ExternalContact[] externalContacts, Company[] companies)
   {
      this.externalContacts = externalContacts;
      this.companies = companies;
   }

   public ExternalContact[] getContactsWithConsolidatedAddresses() {
      List updatedContacts = new ArrayList();
      for (int i = 0; i < externalContacts.length; i++) {
         ExternalContact updatedContact = getUpdatedExternalContact(externalContacts[i]);
         updatedContacts.add(updatedContact);
      }
      return (ExternalContact[]) updatedContacts.toArray(new ExternalContact[updatedContacts.size()]);
   }

   private ExternalContact getUpdatedExternalContact(ExternalContact externalContact) {
      ExternalContactImpl updatedContact = new ExternalContactImpl(externalContact);
      for (int i = 0; i < companies.length; i++) {
         Company company = companies[i];
         if (isSameAcctId(externalContact, company)) {
            updatedContact.addAddresses(company.getAddresses());
         }
      }
      return updatedContact;
   }

   private boolean isSameAcctId(ExternalContact externalContact, Company company) {
      return company.getAcctId().equals(externalContact.getAcctId());
   }
}
