package com.monsanto.tps.lexiconpos.db.constants;

/**
 * rrchak1 - Aug 21, 2008 5:51:58 PM
 */
public interface LexiconSchemaConstants
{
   String MANUFACTURING_NAME = "manufacturingName";
   String LOGICAL_DELETE = "logicalDelete";
   String PRE_COML_NAME = "preComlName";
   String PRODUCT_PUBKEY = "productPubkey";
   String PRE_COML_PRODUCT = "preComlProduct";
   String CROP = "crop";
   String PRODUCT_RELATIONSHIP = "productRelationship";
   String CROP_PUBKEY = "cropPubkey";
   String LOGICAL_DELETE_NO = "N";
   String PRODUCTION_STATUS_NAME = "productionStatusName";
   String PRODUCT_RELATIONSHIP_XREF_ID = "productRelationshipXrefId";
}
