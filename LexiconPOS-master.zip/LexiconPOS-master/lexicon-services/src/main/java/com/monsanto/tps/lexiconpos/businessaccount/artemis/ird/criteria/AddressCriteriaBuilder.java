package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexicon.contact.SearchableLocation;
import org.hibernate.criterion.Criterion;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author: rrchak1
 */
public class AddressCriteriaBuilder {

    public List<Criterion> getCriterion(SearchableLocation searchableLocation) {
        List<QueryCriteria> addressCriteriaList = buildCriteria(searchableLocation);
        return getCriterion(addressCriteriaList);
    }

    private List<Criterion> getCriterion(List<QueryCriteria> addressCriteriaList) {
        List<Criterion> criterion = new ArrayList<Criterion>();
        for (QueryCriteria queryCriteria : addressCriteriaList) {
            if (queryCriteria.hasCriteria()) {
                criterion.add(queryCriteria.getCriterion());
            }
        }
        return criterion;
    }

    private List<QueryCriteria> buildCriteria(SearchableLocation searchableLocation) {
        return Arrays.asList(
                new SubCountryCriteriaImpl(searchableLocation.getSubcountryCode()),
                new CityCriteriaImpl(searchableLocation.getCity())
        );
    }

    public void addCriteria(Criteria accountAddressCriteria, SearchableLocation searchableLocation) {
        List<Criterion> accountAddressCriterion = getCriterion(searchableLocation);
        for (Criterion c : accountAddressCriterion) {
            accountAddressCriteria.add(c);
        }
    }
}
