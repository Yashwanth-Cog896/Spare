/*
 FindSubcountriesByAbbreviationAction was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subcountry.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.subcountry.query.SubcountryQuerySet;
import com.monsanto.tps.lexiconpos.geography.subcountry.query.SubcountryQuerySetImpl;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexicon.geography.subcountry.SubcountriesByAbbreviationRequest;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

/**
 * @author GGSHIV - Jun 10, 2008 12:16:40 PM
 */
public class FindSubcountriesByAbbreviationAction extends AbstractArtemisServiceAction {

   private final SubcountryQuerySet querySet;

   public FindSubcountriesByAbbreviationAction() {
      this(new SubcountryQuerySetImpl());
   }

   public FindSubcountriesByAbbreviationAction(SubcountryQuerySet querySet) {
      this.querySet = querySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      SubcountriesByAbbreviationRequest request = (SubcountriesByAbbreviationRequest) context.getRequestPayload();
      LexiconCountry lexiconCountry = getLexiconCountry(request);
      Subcountry[] subcountries = getSubcountries(request, lexiconCountry);
      new MultipleResultResponse(subcountries).saveResponse(context);
   }

   private LexiconCountry getLexiconCountry(SubcountriesByAbbreviationRequest request) {
      return querySet.findCountryByISOCode(request.getCountryISOCode());
   }

   private Subcountry[] getSubcountries(SubcountriesByAbbreviationRequest request, LexiconCountry lexiconCountry) {
      Subcountry[] subcountries = new Subcountry[0];
      if(lexiconCountry != null) {
         subcountries = querySet.findSubcountriesByAbbreviation(lexiconCountry.getPublicKey(), request.getSubcountriesAbbreviation());
         setCountryInformation(lexiconCountry, subcountries);
      }
      return subcountries;
   }

   private void setCountryInformation(LexiconCountry lexiconCountry, Subcountry[] subcountries) {
      for (Subcountry subcountry : subcountries) {
         subcountry.setCountryISOCode(lexiconCountry.getISOCode());
         subcountry.setDescription(lexiconCountry.getSubCountryDescription());
      }
   }
}
