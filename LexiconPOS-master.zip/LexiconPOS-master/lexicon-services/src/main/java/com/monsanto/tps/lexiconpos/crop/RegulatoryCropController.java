package com.monsanto.tps.lexiconpos.crop;

import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.tps.lexiconpos.tps.crop.dao.RegulatoryCropQuery;
import com.monsanto.tps.lexiconpos.tps.crop.domain.LexiconCrop;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 11, 2006
 * Time: 4:25:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegulatoryCropController
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return CropSchemaConsts.SCHEMA_LOC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      LexiconCrop[] crops = getCrops();
      return createResponseDoc(crops);
   }

   private LexiconCrop[] getCrops()
      throws WrappingException
   {
      RegulatoryCropQuery query = new RegulatoryCropQuery();
      return query.getCrops();
   }

   private Document createResponseDoc(LexiconCrop[] crops) {
      CropResponseRenderer renderer = new CropResponseRenderer(crops);
      return renderer.renderDocument();
   }
}
