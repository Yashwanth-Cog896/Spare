/*
 CountryBuilder was created on Jun 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.query;

import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexicon.geography.country.Country;

/**
 * @author GGSHIV - Jun 4, 2008 3:34:50 PM
 */
public class CountryBuilder {
   public Country build(LexiconCountry lexiconCountry) {
      Country country = new Country();
      country.setCountryISOcode(lexiconCountry.getISOCode());
      country.setAbbreviation(lexiconCountry.getUNCodeStr());
      country.setName(lexiconCountry.getName());
      country.setSubCountryDescription(lexiconCountry.getSubCountryDescription());
      country.setSubSubCountryDescription(lexiconCountry.getSubSubCountryDescription());
      return country;
   }
}
