package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.tps.lexiconpos.businessaccount.Address;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 11:20:48 AM
 * To change this template use File | Settings | File Templates.
 */
public interface Company {
   String getAcctId();
   String getCompanyName();
   Address[] getAddresses();
}
