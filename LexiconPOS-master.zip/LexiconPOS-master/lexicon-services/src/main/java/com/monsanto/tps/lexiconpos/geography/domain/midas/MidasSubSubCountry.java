package com.monsanto.tps.lexiconpos.geography.domain.midas;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 30, 2006
 * Time: 3:50:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasSubSubCountry
{
   String getSubSubCountryKey();
   String getSubSubCountryName();
   String getSubCountryKey();
}
