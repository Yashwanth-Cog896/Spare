/*
 QueryItemDOMImpl was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmQueryItem;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * nbwald Jan 30, 2007 6:00:00 PM
 */
public class GermplasmQueryItemDOMImpl
   implements GermplasmQueryItem
{
   private final Element queryItemElem;
   private final String cropName;

   public GermplasmQueryItemDOMImpl(Element queryItemElem, String cropName) {
      this.queryItemElem = queryItemElem;
      this.cropName = cropName;
   }

   public int getItemID() {
      String sItemID = DOMUtil.getAttribute(queryItemElem, GermplasmQueryDocTags.ITEM_ID_ATTR_NAME);
      return Integer.parseInt(sItemID);
   }

   public String getCropName() {
      return cropName;
   }

   public String getOrigin() {
      return DOMUtil.getChildValue(queryItemElem, GermplasmDocTags.ORIGIN_ELEM_NAME);
   }

   public String getLineCode() {
      return DOMUtil.getChildValue(queryItemElem, GermplasmDocTags.LINE_CODE_ELEM_NAME);
   }

   public String getProductPubkey() {
      return DOMUtil.getChildValue(queryItemElem, GermplasmDocTags.PRODUCT_PUBKEY_ELEM_NAME);
   }

   @Override
   public String getPedigree() {
      return DOMUtil.getChildValue(queryItemElem, GermplasmDocTags.PEDIGREE_ELEM_NAME);
   }
}