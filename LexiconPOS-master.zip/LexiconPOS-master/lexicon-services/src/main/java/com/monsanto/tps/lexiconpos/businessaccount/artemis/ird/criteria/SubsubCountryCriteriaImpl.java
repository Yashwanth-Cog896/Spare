package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    SubsubCountryCriteriaImpl.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class SubsubCountryCriteriaImpl implements QueryCriteria {
    private String subSubCountryName;

    public SubsubCountryCriteriaImpl(String subSubCountryName) {
        this.subSubCountryName = subSubCountryName;
    }

    public Criterion getCriterion() {
        return Restrictions.like(BusinessAccountSchemaConstants.COUNTY_DESCR, convertWildCards(subSubCountryName)).ignoreCase();
    }

    public boolean hasCriteria() {
        return StringUtils.isNotEmpty(subSubCountryName);
    }

    private String convertWildCards(String attribute) {
        return new StdWildcardableCriteria(attribute).oracleVersion();
    }

}
