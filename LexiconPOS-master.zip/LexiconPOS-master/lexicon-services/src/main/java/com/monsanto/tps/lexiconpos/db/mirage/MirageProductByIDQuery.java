package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.product.common.domain.mirage.MirageProduct;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 20, 2006
 * Time: 9:25:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageProductByIDQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final int seedProductID;

   public MirageProductByIDQuery(int seedProductID) {
      this.seedProductID = seedProductID;
   }

   public MirageProduct getSeedProduct()
      throws WrappingException
   {
      return (MirageProduct)execute();
   }

   public MirageProduct getSeedProduct(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return (MirageProduct)execute(mirageConn);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new MirageProductDTOBuilder(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return getSQLPropFile().getSQL(MirageSQL.SELECT_PROD_BY_PROD_ID);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { Integer.valueOf(seedProductID) };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MirageSQL.class);
   }
}
