package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * Filename:    StubExternalContactService.java
 * Last Change: rrchak1 On:	Jul 29, 2008
 *
 * @author: rrchak1
 */
public class StubExternalContactService
    implements IrdExternalContactService
{

    public Contact[] findByBusinessGeographySearchCriteria(ExternalContactByBusinessGeographySearchCriteria externalContactByBusinessGeographySearchCriteria) {
        return new Contact[]{
                new Contact(),
                new Contact()
        };
    }

    public Contact[] findByIds(long[] ids) {
        return new Contact[]{
                new Contact(),
                new Contact()
        };
    }

   public Contact[] findByBusinessAccountIds(long[] ids) {
      return new Contact[]{
              new Contact(),
              new Contact()
      };
   }

   public Contact[] findBySearchCriteria(ExternalContactSearchCriteria externalContactSearchCriteria) {
        return new Contact[]{
                new Contact(),
                new Contact()
        };
    }
}
