/*
 FindSubsubcountriesByAbbreviationAction was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subsubcountry.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.subsubcountry.query.SubsubcountryQuerySet;
import com.monsanto.tps.lexiconpos.geography.subsubcountry.query.SubsubcountryQuerySetImpl;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexicon.geography.subsubcountry.SubsubcountriesByAbbreviationRequest;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

/**
 * @author GGSHIV - Jun 10, 2008 2:38:34 PM
 */
public class FindSubsubcountriesByAbbreviationAction extends AbstractArtemisServiceAction {

   private final SubsubcountryQuerySet querySet;

   public FindSubsubcountriesByAbbreviationAction(SubsubcountryQuerySet querySet) {
      this.querySet = querySet;
   }

   public FindSubsubcountriesByAbbreviationAction() {
      this(new SubsubcountryQuerySetImpl());

   }

   public void process(ServiceProcessContext context) throws Exception {
      SubsubcountriesByAbbreviationRequest request = (SubsubcountriesByAbbreviationRequest) context.getRequestPayload();
      LexiconCountry lexiconCountry = getLexiconCountry(request);
      Subsubcountry[] subsubcountries = getSubsubcountries(request, lexiconCountry);
      setCountryInformation(lexiconCountry, subsubcountries);
      new MultipleResultResponse(subsubcountries).saveResponse(context);
   }

   private LexiconCountry getLexiconCountry(SubsubcountriesByAbbreviationRequest request) {
      return querySet.findCountryByISOCode(request.getCountryISOCode());
   }

   private Subsubcountry[] getSubsubcountries(SubsubcountriesByAbbreviationRequest request, LexiconCountry lexiconCountry) {
      return lexiconCountry == null ? new Subsubcountry[0]
              : querySet.findSubsubcountriesByAbbreviation(lexiconCountry.getPublicKey(), request.getSubcountriesAbbreviation(), request.getWildcardableName());
   }

   private void setCountryInformation(LexiconCountry lexiconCountry, Subsubcountry[] subsubcountries) {
      for (Subsubcountry subsubcountry : subsubcountries) {
         subsubcountry.setCountryISOCode(lexiconCountry.getISOCode());
         subsubcountry.setDescription(lexiconCountry.getSubSubCountryDescription());
      }
   }
}
