/*
 GermplasmsByCropNameAndWildcardableLineCodeQuery was created on Jan 18, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.germplasm.validation.GPQueryWildcardableCriteria;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;

import java.util.List;

/**
 * nbwald Jan 18, 2007 3:21:08 PM
 */
public class GermplasmsByCropNameAndWildcardableLineCodeQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String oracleWCLineCode;
   private final String midasCropName;

   public GermplasmsByCropNameAndWildcardableLineCodeQuery(String wildcardableLineCode, String midasCropName) {
      GPQueryWildcardableCriteria lineCode = new GPQueryWildcardableCriteria(wildcardableLineCode);
      this.oracleWCLineCode = lineCode.oracleVersion();
      this.midasCropName = midasCropName;
   }

   public Germplasm[] getGermplasms()
      throws WrappingException
   {
      List germplasms = this.getList();
      return (Germplasm[]) germplasms.toArray(new Germplasm[germplasms.size()]);
   }

   public Germplasm[] getGermplasms(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      List germplasms = this.getList(midasConn);
      return (Germplasm[]) germplasms.toArray(new Germplasm[germplasms.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new GermplasmPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_GERMPLASMS_BY_CROP_AND_WC_LINECODE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { oracleWCLineCode, midasCropName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}