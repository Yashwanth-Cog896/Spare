package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 30, 2006
 * Time: 3:56:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasSubSubCountryPSRowImpl
   implements MidasSubSubCountry
{
   private final String subSubCountryKey;
   private final String subSubCountryName;
   private final String subCountryKey;

   public MidasSubSubCountryPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      subSubCountryKey = row.getString(getAlias(MidasGeographicRegionQuerySQL.SUB_SUB_COUNTRY_ID_ALIAS));
      subSubCountryName = row.getString(getAlias(MidasGeographicRegionQuerySQL.SUB_SUB_COUNTRY_NAME_ALIAS));
      subCountryKey = row.getString(getAlias(MidasGeographicRegionQuerySQL.SUB_COUNTRY_ID_ALIAS));
   }

   public String getSubSubCountryKey() {
      return subSubCountryKey;
   }

   public String getSubSubCountryName() {
      return subSubCountryName;
   }

   public String getSubCountryKey() {
      return subCountryKey;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return getSQLPropFile().getAlias(propName);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MidasGeographicRegionQuerySQL.class);
   }
}
