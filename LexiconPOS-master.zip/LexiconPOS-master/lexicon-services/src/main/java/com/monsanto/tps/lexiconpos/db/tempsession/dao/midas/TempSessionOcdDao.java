package com.monsanto.tps.lexiconpos.db.tempsession.dao.midas;

import java.util.Collection;

/**
 * RLCASW - Feb 28, 2010 3:12:23 PM
 */
public interface TempSessionOcdDao
{
   public void insertText1Values(Long requestId, Collection<String> ids);

   public void insertNumber1Values(Long requestId, Collection<Long> ids);
}
