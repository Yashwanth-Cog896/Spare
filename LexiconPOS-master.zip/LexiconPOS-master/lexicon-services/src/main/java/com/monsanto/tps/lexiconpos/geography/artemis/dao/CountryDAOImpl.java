/*
 CountryDAOImpl was created on Nov 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.geography.artemis.dao;

import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.artemis.query.CountryByUNCodeQuery;

/**
 * nbwald Nov 2, 2007 4:53:17 PM
 */
public class CountryDAOImpl
        implements CountryDAO {

   public LexiconCountry findCountryByUNCode(int unCode) {
      CountryByUNCodeQuery query = new CountryByUNCodeQuery(unCode);
      return query.findCountry();
   }
}