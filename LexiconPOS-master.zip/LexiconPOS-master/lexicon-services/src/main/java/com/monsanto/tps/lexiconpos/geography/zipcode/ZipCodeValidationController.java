package com.monsanto.tps.lexiconpos.geography.zipcode;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 12:42:14 PM
 */
public class ZipCodeValidationController
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return ZipCodeValidationSchemaConstants.SCHEMA_LOC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      ZipCodeValidationRequestModel requestModel = getRequestModel(inputDocument);
      String validatedZipCode = processModel(requestModel);
      return renderResponse(validatedZipCode);
   }

   private ZipCodeValidationRequestModel getRequestModel(Document inputDocument) {
      ZipCodeValidationRequestParser parser = new ZipCodeValidationRequestParser();
      return parser.parse(inputDocument);
   }

   private String processModel(ZipCodeValidationRequestModel requestModel)
      throws WrappingException
   {
      ZipCodeValidationRequestProcessor processor = new ZipCodeValidationRequestProcessor();
      return processor.getValidZipCode(requestModel);
   }

   private Document renderResponse(String zipCode) {
      Document response = createResponseDocument();
      ZipCodeValidationRenderer renderer = new ZipCodeValidationRenderer(zipCode);
      renderer.render(response.getDocumentElement());
      return response;
   }

   private Document createResponseDocument() {
      return new DocumentCreator().createDocument(
         ZipCodeValidationSchemaConstants.NAMESPACE, ZipCodeValidationSchemaConstants.RESPONSE_ELEM_NAME);
   }
}
