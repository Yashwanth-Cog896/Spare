/*
 FindCropsByPubKeysAndScientificNameAction was created on Jun 26, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.CropPubKeysAndScientificNameRequest;

import java.util.List;

/**
 * @author PNAGAPP - Jun 26, 2008 4:36:48 PM
 */
public class FindCropsByPubKeysAndScientificNameAction extends AbstractArtemisServiceAction {
 private final CropQuerySet cropQuerySet;

   public FindCropsByPubKeysAndScientificNameAction(CropQuerySet cropQuerySet) {
      this.cropQuerySet = cropQuerySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      CropPubKeysAndScientificNameRequest request = (CropPubKeysAndScientificNameRequest) context.getRequestPayload();
      List<Crop> crops = cropQuerySet.findByPublicKeysAndScientificName(request.getPublickeys(), request.getScientificName(), request.getPublicKeyType());
      new MultipleResultResponse(crops).saveResponse(context);
   }
}
