package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexicon.contact.SearchableLocation;
import org.hibernate.criterion.Criterion;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    FipsCriteriaBuilder.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class FipsCriteriaBuilder {

    public List<Criterion> getCriterion(SearchableLocation searchableLocation) {
        List<QueryCriteria> addressCriteriaList = buildCriteria(searchableLocation);
        return getCriterion(addressCriteriaList);
    }

    private List<Criterion> getCriterion(List<QueryCriteria> fipsCriteriaList) {
        List<Criterion> criterion = new ArrayList<Criterion>();
        for (QueryCriteria queryCriteria : fipsCriteriaList) {
            if (queryCriteria.hasCriteria()) {
                criterion.add(queryCriteria.getCriterion());
            }
        }
        return criterion;
    }

    private List<QueryCriteria> buildCriteria(SearchableLocation searchableLocation) {
        QueryCriteria fipsCriteria = new SubsubCountryCriteriaImpl(searchableLocation.getSubsubcountryName());
        return Arrays.asList(fipsCriteria);
    }

    public void addCriteria(Criteria fipsCriteria, SearchableLocation searchableLocation) {
        List<Criterion> accountAddressCriterion = getCriterion(searchableLocation);
        for (Criterion c : accountAddressCriterion) {
            fipsCriteria.add(c);
        }
    }
}