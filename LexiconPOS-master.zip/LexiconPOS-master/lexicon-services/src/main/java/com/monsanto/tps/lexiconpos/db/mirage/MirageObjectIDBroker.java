package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Sep 1, 2006
 * Time: 11:39:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageObjectIDBroker
{
   public int nextID(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      PersistentStore store = PersistentStore.instance(MirageConnectionFactoryProperties.INSTANCE_NAME);
      return store.nextObjectID();
   }
}
