package com.monsanto.tps.lexiconpos.db.lexicon;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 24, 2005
 * Time: 10:36:20 AM
 */
public interface LexiconSQLPropFile
{
	String SELECT_BY_PROD_STAGE_PUBKEY = "ProductStage.SelectByPubkey";
	String SELECT_BY_PROD_NAME_PUBKEY = "ProductName.SelectByPubkey";

	String SELECT_PROD_NAMES_BY_PROD_PUBKEY = "ProductName.SelectByProdPubkey";
	String SELECT_PROD_STAGES_BY_PROD_PUBKEY = "ProductStage.SelectByProdPubkey";

	String SELECT_PROD_NAME_PUBKEYS_BY_PROD_ID = "Product.Competitive.SelectNamePubkeys";
	String SELECT_PROD_STAGE_PUBKEYS_BY_PROD_ID = "Product.Monsanto.SelectNamePubkeys";

   String DELETE_PROD_REL_XREF = "ProdRelXref.Delete";
   String LOGICAL_DELETE_MON_PROD = "Product.Monsanto.LogicalDelete";
	String LOGICAL_DELETE_COMP_PROD = "Product.Competitive.LogicalDelete";
	String LOGICAL_DELETE_STAGE = "ProductStage.LogicalDelete";
	String LOGICAL_DELETE_NAME = "ProductName.LogicalDelete";

	String UPDATE_PROD_STAGE_PROD_ID = "ProductStage.UpdateProductId";
	String UPDATE_PROD_NAME_PROD_ID = "ProductName.UpdatedProductId";

	String UPDATE_PROD_STAGE = "ProductStage.Update";
	String UPDATE_PROD_NAME_FROM_EXISTING_PROD_NAME = "ProductName.Update.UseExistingProd";

    String TOUCH_MON_PROD = "Product.Monsanto.Touch";
    String TOUCH_COMP_PROD = "Product.Competitive.Touch";

	String ALIAS_PROD_STAGE_ID = "ProductStage.Id";
	String ALIAS_PROD_ID = "Product.Id";
	String ALIAS_COUNTRY_ID = "Country.Id";
	String ALIAS_BRAND_ID = "Brand.Id";
	String ALIAS_STAGE_ID = "Stage.Id";
    String ALIAS_COML_MAT =  "CommercialMaturity";
	String ALIAS_ACTIVE = "Active";
	String ALIAS_COML_TRAIT_STACK_ID =  "ComlTraitStack.Id";
	String ALIAS_DELETE = "LogicalDelete";

	String ALIAS_PROD_NAME_ID = "ProductName.Id";
	String ALIAS_PROD_NAME_NAME = "ProductName.Name";
	String ALIAS_PROD_NAME_VER_DATA_SRC = "ProductName.VerifiedDataSource";
	String ALIAS_PROD_NAME_DATA_SRC_YR = "ProductName.DataSourceYear";
    String ALIAS_PROD_NAME_COMMENTS = "ProductName.Comments";

	String ALIAS_PROD_STAGE_COML_NAME = "ProductStage.CommercialName";
	String ALIAS_PROD_STAGE_TEST_NAME = "ProductStage.TestName";
	String ALIAS_PROD_STAGE_OECD_NAME = "ProductStage.OECDReqdName";

	String ALIAS_PROD_NAME_PUBKEY = "ProductName.Pubkey";
	String ALIAS_PROD_STAGE_PUBKEY = "ProductStage.Pubkey";
}
