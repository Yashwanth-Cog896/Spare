package com.monsanto.tps.lexiconpos.geography.domain.midas;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 24, 2006
 * Time: 12:10:32 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasGeographicRegionQuerySQL
{
   String GEOGRAPHIC_REGIONS_BY_IDS = "GeographicRegionsByIds";

   String COUNTRY_PUBKEY_COLUMN  = "CountryPubkeyColumn";
   String SUB_COUNTRY_ID_COLUMN = "SubCountryIdColumn";
   String SUB_SUB_COUNTRY_ID_COLUMN = "SubSubCountryIdColumn";
   String SUB_SUB_COUNTRY_NAME_CRITERIA = "SubSubCountryNameCriteria";

   String COUNTRY_PUBKEY_ALIAS = "CountryPubkey";
   String COUNTRY_ID_ALIAS = "CountryId";
   String SUB_COUNTRY_ID_ALIAS = "SubCountryId";
   String SUB_COUNTRY_NAME_ALIAS = "SubCountryName";
   String SUB_SUB_COUNTRY_ID_ALIAS = "SubSubCountryId";
   String SUB_COUNTRY_ABBR_ALIAS = "SubCountryAbbr";
   String SUB_SUB_COUNTRY_NAME_ALIAS = "SubSubCountryName";

   String SELECT_SUB_COUNTRY_BY_ABBR = "SubCountry.SelectByAbbr";
   String SELECT_SUB_SUB_COUNTRY_BY_NAME = "SubSubCountry.SelectByName";

   String SELECT_SUB_COUNTRY_BY_COUNTRY_PUBKEY = "SubCountry.SelectByCountryPubkey";   
}
