/*
 CountryDAO was created on Nov 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.geography.artemis.dao;

import com.monsanto.tps.lexiconpos.geography.LexiconCountry;

/**
 * nbwald Nov 2, 2007 4:48:08 PM
 */
public interface CountryDAO {
   LexiconCountry findCountryByUNCode(int unCode);
}