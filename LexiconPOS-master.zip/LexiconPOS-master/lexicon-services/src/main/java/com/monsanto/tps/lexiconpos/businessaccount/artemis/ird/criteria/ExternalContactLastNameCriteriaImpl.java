package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    ExternalContactLastNameCriteriaImpl.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class ExternalContactLastNameCriteriaImpl
        implements QueryCriteria {

    private String lastName;

    public ExternalContactLastNameCriteriaImpl(String lastName) {
        this.lastName = lastName;
    }

    public Criterion getCriterion() {
        return Restrictions.like(BusinessAccountSchemaConstants.CONTACT_NAME3, convertWildCards(lastName.toUpperCase()));
    }

    public boolean hasCriteria() {
        return StringUtils.isNotEmpty(lastName);
    }

    private String convertWildCards(String attribute) {
        return new StdWildcardableCriteria(attribute).oracleVersion();
    }
}
