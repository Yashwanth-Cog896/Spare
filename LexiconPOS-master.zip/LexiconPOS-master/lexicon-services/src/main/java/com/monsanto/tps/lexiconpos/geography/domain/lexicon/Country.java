package com.monsanto.tps.lexiconpos.geography.domain.lexicon;

/**
 * nbwald - Aug 27, 2008 3:39:20 PM
 */
public class Country
{
   private long countryId;

   public long getCountryId() {
      return countryId;
   }

   public void setCountryId(long countryId) {
      this.countryId = countryId;
   }

   private String countryPubkey;

   public String getCountryPubkey() {
      return countryPubkey;
   }

   public void setCountryPubkey(String countryPubkey) {
      this.countryPubkey = countryPubkey;
   }

   private String countryAbbr;

   public String getCountryAbbr() {
      return countryAbbr;
   }

   public void setCountryAbbr(String countryAbbr) {
      this.countryAbbr = countryAbbr;
   }

   private String countryName;

   public String getCountryName() {
      return countryName;
   }

   public void setCountryName(String countryName) {
      this.countryName = countryName;
   }

   private String isoCode;

   public String getIsoCode() {
      return isoCode;
   }

   public void setIsoCode(String isoCode) {
      this.isoCode = isoCode;
   }

   private int unCode;

   public int getUnCode() {
      return unCode;
   }

   public void setUnCode(int unCode) {
      this.unCode = unCode;
   }

   private String subCountryLabel;

   public String getSubCountryLabel() {
      return subCountryLabel;
   }

   public void setSubCountryLabel(String subCountryLabel) {
      this.subCountryLabel = subCountryLabel;
   }

   private String subSubCountryLabel;

   public String getSubSubCountryLabel() {
      return subSubCountryLabel;
   }

   public void setSubSubCountryLabel(String subSubCountryLabel) {
      this.subSubCountryLabel = subSubCountryLabel;
   }
}
