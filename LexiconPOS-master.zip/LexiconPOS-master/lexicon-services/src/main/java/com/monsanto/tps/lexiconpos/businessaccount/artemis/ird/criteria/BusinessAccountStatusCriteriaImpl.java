package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;

/**
 * Filename: BusinessAccountStatusCriteriaImpl.java 
 * Last Change: rrchak1 On: Aug 7, 2008
 * 
 * @author: rrchak1
 */
public class BusinessAccountStatusCriteriaImpl
    implements QueryCriteria{

    public Criterion getCriterion() {
        return Restrictions.eq("acctStatusTypeId", BusinessAccountSchemaConstants.ACTIVE_ACCT_STATUS_CD);
    }

    public boolean hasCriteria() {
        return true;
    }
}
