/*
 FindCropsByNameAndScientificNameAction was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.CropNameAndScientificNameRequest;

import java.util.List;

/**
 * @author PNAGAPP - Jul 1, 2008 3:05:35 PM
 */
public class FindCropsByNameAndScientificNameAction extends AbstractArtemisServiceAction {
 private final CropQuerySet cropQuerySet;

   public FindCropsByNameAndScientificNameAction(CropQuerySet cropQuerySet) {
      this.cropQuerySet = cropQuerySet;
   }

   public void process(ServiceProcessContext context) throws Exception {
      CropNameAndScientificNameRequest request = (CropNameAndScientificNameRequest) context.getRequestPayload();
      List<Crop> crops = cropQuerySet.findByNameAndScientificName(request.getName(), request.getScientificName());
      new MultipleResultResponse(crops).saveResponse(context);
   }
}
