package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - Jun 4, 2008 2:31:28 PM
 */
public class FieldIsNotFullyWildcardedRule
   implements Rule<String>
{
   private final String fieldName;
   private final String fieldValue;

   public FieldIsNotFullyWildcardedRule(String fieldName, String fieldValue) {
      this.fieldName = fieldName;
      this.fieldValue = fieldValue;
   }

   public boolean violated() {
      StdWildcardableCriteria fieldCriteria = new StdWildcardableCriteria(fieldValue);
      return fieldCriteria.isOnlyWildcard();
   }

   public String getViolation() {
      return fieldName + " requires at least one non-wildcard character.";
   }
}
