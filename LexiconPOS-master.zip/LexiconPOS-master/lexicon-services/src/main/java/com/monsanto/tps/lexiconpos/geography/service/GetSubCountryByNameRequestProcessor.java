package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconGeographyLookup;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconGeographyLookupDBImpl;
import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.SubCountry;
import com.monsanto.tps.lexiconpos.tps.country.InvalidCountryException;
import com.monsanto.tps.lexiconpos.tps.country.TPSCountry;
import com.monsanto.tps.lexiconpos.tps.country.TPSCountryLookup;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 12, 2006
 * Time: 11:25:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class GetSubCountryByNameRequestProcessor
   implements GeographyRequestProcessor
{
   private LexiconGeographyLookup lookup;

   public GeographicEntity[] getMatchingGeography(
      GeographyRequestModel requestModel, TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      TPSCountry tpsCountry = getTPSCountry(requestModel.getCountryPubkey(), conn);
      SubCountry[] subCountries = (!StringUtils.isNullOrEmpty(requestModel.getSubCountryName())) ?
         getSubCountriesByName(tpsCountry, requestModel, conn) :
         getSubCountriesByAbbr(tpsCountry, requestModel, conn);

      setSubCountryParent(tpsCountry, subCountries);
      return subCountries;
   }

   private SubCountry[] getSubCountriesByName(TPSCountry tpsCountry, GeographyRequestModel requestModel,
      TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      return getGeographyLookup().getSubCountriesByName(tpsCountry.getMidasID(),
         requestModel.getSubCountryName(), conn.getMidasConnection());
   }

   private SubCountry[] getSubCountriesByAbbr(TPSCountry tpsCountry, GeographyRequestModel requestModel,
      TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      return getGeographyLookup().getSubCountriesByAbbr(tpsCountry.getMidasID(),
         requestModel.getSubCountryAbbr(), conn.getMidasConnection());
   }

   private TPSCountry getTPSCountry(String pubkey, TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      try {
         return getTPSCountryLookup().getCountry(pubkey, conn);
      }
      catch (InvalidCountryException e) {
         throw new WrappingException(e);
      }
   }

   private void setSubCountryParent(TPSCountry tpsCountry, SubCountry[] subCountries)
   {
      for (int i = 0; i < subCountries.length; i++) {
         subCountries[i].setCountry((LexiconCountry)tpsCountry);
      }
   }

   protected LexiconGeographyLookup getGeographyLookup() {
      if (lookup == null) {
         lookup = new LexiconGeographyLookupDBImpl();
      }
      return lookup;
   }

   protected TPSCountryLookup getTPSCountryLookup() {
      return TPSCountryLookup.instance();
   }
}
