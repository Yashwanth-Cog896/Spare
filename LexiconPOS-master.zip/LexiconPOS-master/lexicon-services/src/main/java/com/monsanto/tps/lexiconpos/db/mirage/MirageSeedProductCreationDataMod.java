package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 28, 2006
 * Time: 10:20:22 AM
 */
public class MirageSeedProductCreationDataMod
{
   private final int seedProductID;
   private final String productName;
   private final int companyID;
   private final String bayerCode;
   private final String countryCode;
   private final int traitCharacteristicsID;
   private final boolean isEnabled;

   public MirageSeedProductCreationDataMod(
           int seedProductID, String productName, int companyID,
           String bayerCode, String countryCode, int traitCharacteristicsID, boolean isEnabled)
   {
      this.seedProductID = seedProductID;
      this.productName = productName;
      this.companyID = companyID;
      this.bayerCode = bayerCode;
      this.countryCode = countryCode;
      this.traitCharacteristicsID = traitCharacteristicsID;
      this.isEnabled = isEnabled;
   }

   public int performInsert(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return new MirageAuditedAction() {
         @Override
         protected int performAction(PersistentStoreStatement statement)
            throws WrappingException
         {
            return statement.executeInsert();
         }

         @Override
         protected String getSQL()
            throws WrappingException
         {
            SQLPropFile propFile = new SQLPropFile(MirageSeedProductWriterSQL.class);
            return propFile.getSQL(MirageSeedProductWriterSQL.INSERT_PRODUCT);
         }

         @Override
         protected Object[] getBindVariables(int auditId) {
            return new Object[]{ seedProductID, companyID, productName, bayerCode,
               countryCode, getTraitCharacteristicCode(), SQLUtil.booleanToString(isEnabled).toUpperCase(), auditId
            };
         }

         private String getTraitCharacteristicCode() {
            return traitCharacteristicsID == 0 ? "" : String.valueOf(traitCharacteristicsID);
         }

         @Override
         protected int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
            throws WrappingException
         {
            return mirageAuditor.auditCreateSeedProduct(mirageConn);
         }
      }.execute(mirageConn);
   }
}
