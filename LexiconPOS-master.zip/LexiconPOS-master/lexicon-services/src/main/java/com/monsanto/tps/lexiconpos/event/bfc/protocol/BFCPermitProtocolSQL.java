/*
 BFCPermitProtocolSQL was created on Oct 19, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.protocol;

/**
 * nbwald Oct 19, 2006 2:30:39 PM
 */
public interface BFCPermitProtocolSQL {
   String SELECT_PERMITPROTOCOL = "PermitProtocol.Lookup";
   String ALIAS_EUP_ACRES = "EUPAcres";
   String ALIAS_PROTOCOL = "Protocol";
   String ALIAS_PERMIT_PROTOCOL_STATUS = "PermitProtocolStatus";
   String ALIAS_REFERENCE_STATUS = "ReferenceStatus";
}