package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tps.lexiconpos.db.TPSPersistentStoreConnection;
import com.monsanto.tps.lexiconpos.servlet.LexiconPOSController;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 3:49:17 PM
 */
public class GetAphisNumberDataController
   extends LexiconPOSController
{
   protected String getXMLSchemaRelativeToServletContext() {
      return AphisNumberSchemaConstants.SCHEMA_LOC;
   }

   protected Document executeService(Document inputDocument)
      throws Exception
   {
      TPSPersistentStoreConnection conn = getConnection();
      try {
         AphisNumberRequestModel requestModel = getRequestModel(inputDocument);
         AphisNumberDatum[] aphisNumberData = processModel(requestModel, conn);
         return renderResponse(aphisNumberData);
      }
      finally {
         closeConnection(conn);
      }
   }

   private AphisNumberRequestModel getRequestModel(Document inputDocument) {
      AphisNumberRequestParser parser = new AphisNumberRequestParser(inputDocument);
      return parser.parse();
   }

   private AphisNumberDatum[] processModel(
      AphisNumberRequestModel requestModel, TPSPersistentStoreConnection conn)
      throws WrappingException
   {
      AphisNumberRequestProcessor processor = getAphisNumberRequestProcessor();
      return processor.getAphisNubmerData(requestModel, conn);
   }

   private Document renderResponse(AphisNumberDatum[] aphisNumberData) {
      Document response = createResponseDocument();
      AphisNumberDataRenderer renderer = new AphisNumberDataRenderer(aphisNumberData);
      renderer.render(response.getDocumentElement());
      return response;
   }

   private Document createResponseDocument() {
      return new DocumentCreator().createDocument(
         AphisNumberSchemaConstants.NAMESPACE, AphisNumberSchemaConstants.RESPONSE_ELEM_NAME);
   }

   protected AphisNumberRequestProcessor getAphisNumberRequestProcessor() {
      return new AphisNumberRequestProcessor();
   }

   protected TPSPersistentStoreConnection getConnection() {
      return new TPSPersistentStoreConnection();
   }

   protected void closeConnection(TPSPersistentStoreConnection conn) {
      conn.close();
   }
}
