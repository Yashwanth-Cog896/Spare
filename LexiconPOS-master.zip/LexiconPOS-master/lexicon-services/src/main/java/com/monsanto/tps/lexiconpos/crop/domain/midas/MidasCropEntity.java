package com.monsanto.tps.lexiconpos.crop.domain.midas;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Mar 1, 2011
 * Time: 10:59:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasCropEntity {
    private long id;
    private String name;
    private boolean refActive;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }
}
