/*
 GetCountriesArtemisController was created on Nov 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.geography.artemis.controller;

import com.monsanto.tcc.artemis.workflow.service.AbstractXmlServiceProcessController;
import com.monsanto.services.client.geography.GeographyXmlSerializerProvider;

/**
 * nbwald Nov 1, 2007 11:03:38 AM
 */
public class GeographyController
   extends AbstractXmlServiceProcessController
{
   protected Class getXmlSerializerProviderClass() {
      return GeographyXmlSerializerProvider.class;
   }

   protected String getTaskMetricsEnvironmentName() {
      return "Lexicon";
   }
}