package com.monsanto.tps.lexiconpos.event.bfc.permit;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 17, 2006
 * Time: 3:59:11 PM
 */
public interface BFCPermitSQL {
    
    String SELECT_BY_MONSANTO_ID = "SelectByMonsantoId";
    String SELECT_BY_AGENCY_ID = "SelectByAgencyId";

    String APPLICATION_TYPE_CRITERIA = "Criteria.ApplicationType";
    String STATUS_CRITERIA = "Criteria.Status";

    String PERMIT_ID_ALIAS = "PermitId";
    String MONSANTO_ID_ALIAS = "MonsantoId";
    String AGENCY_ID_ALIAS = "AgencyId";
    String APPLICATION_TYPE_ALIAS = "ApplicationType";
    String SUBMISSION_TYPE_ALIAS = "SubmissionType";
    String STATUS_ALIAS = "Status";
    String CROP_NAME_ALIAS = "CropName";
    String CROP_CODE_ALIAS = "CropCode";
    String EFFECTIVE_DATE_ALIAS = "EffectiveDate";
    String EXPIRATION_DATE_ALIAS = "ExpirationDate";
    String HAS_EUP_ALIAS = "EUP";
    String EUP_DOCUMENT_NAME_ALIAS = "EUPDocumentName";
    String REQUESTED_BY = "RequestedBy";
}
