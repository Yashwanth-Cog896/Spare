package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.germplasm.dao.GeneticMaterialPSRowImpl;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.GeneticMaterial;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 3, 2006
 * Time: 9:44:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageGeneticMaterialQuery
{
   private final long midasProductID;

   public MirageGeneticMaterialQuery(long midasProductID) {
      this.midasProductID = midasProductID;
   }

   public GeneticMaterial execute(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(MidasSQL.SELECT_MIRAGE_GM_BY_PROD_ID);
      PersistentStoreStatement stmt = midasConn.prepareStatement(sql);
      try {
         stmt.setParam(1, midasProductID);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         if (iter.next()) {
            return new GeneticMaterialPSRowImpl(iter);
         }
         else {
            return null;
         }
      }
      finally {
         stmt.close();
      }
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MidasSQL.class);
   }
}
