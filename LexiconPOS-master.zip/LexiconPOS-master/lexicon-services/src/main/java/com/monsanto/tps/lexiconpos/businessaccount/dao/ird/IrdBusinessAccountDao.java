package com.monsanto.tps.lexiconpos.businessaccount.dao.ird;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;

/**
 * Filename:    IrdBusinessAccountDao.java
 * Last Change: rrchak1 On:	Aug 5, 2008
 *
 * @author: rrchak1
 */
public interface IrdBusinessAccountDao {

    public Acct[] findByIds(long[] businessAccountIds);

    public Acct[] findBySearchCriteria(BusinessAccountSearchCriteria businessAccountSearchCriteria);
}
