package com.monsanto.tps.lexiconpos.geography.subcountry.query;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconCountryByISOCodeQuery;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

/**
 * nbwald - Jun 8, 2008 3:44:04 PM
 */
public class SubcountryQuerySetImpl
   implements SubcountryQuerySet
{
   public LexiconCountry findCountryByISOCode(String countryISOCode) {
      LexiconCountryByISOCodeQuery query = new LexiconCountryByISOCodeQuery(countryISOCode);
      return query.find();
   }

   public Subcountry[] findSubcountriesByWildcardableSubcountryName(String countryPubkey, String wildcardableSubcountryName) {
      StdWildcardableCriteria subcountryName = new StdWildcardableCriteria(wildcardableSubcountryName);
      SubcountriesByWildcardableNameQuery query = new SubcountriesByWildcardableNameQuery(countryPubkey, subcountryName);
      return query.find();
   }

   public Subcountry[] findSubcountriesByAbbreviation(String countryPubkey, String[] subcountriesAbbreviation) {
      SubcountriesByAbbreviationQuery query = new SubcountriesByAbbreviationQuery(countryPubkey, subcountriesAbbreviation);
      return query.find();
   }
}
