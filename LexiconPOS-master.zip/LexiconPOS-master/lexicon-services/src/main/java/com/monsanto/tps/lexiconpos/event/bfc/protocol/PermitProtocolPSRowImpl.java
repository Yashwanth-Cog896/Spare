/*
 PermitProtocolPSRowImpl was created on Oct 12, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.protocol;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.permit.preplantingvalidation.model.PermitProtocol;

/**
 * nbwald Oct 12, 2006 3:05:39 PM
 */
public class PermitProtocolPSRowImpl
   implements PermitProtocol
{
   private final Double eupAcres;
   private final String protocol;

   public PermitProtocolPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      eupAcres = readAcres(row);
      protocol = readProtocol(row);
   }

   public Double getEupAcres() {
      return eupAcres;
   }

   public String getProtocol() {
      return protocol;
   }

   private Double readAcres(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      Double eupAcres = row.getDOUBLE(getAlias(BFCPermitProtocolSQL.ALIAS_EUP_ACRES));
      Long permitProtocolStatus = row.getLONG(getAlias(BFCPermitProtocolSQL.ALIAS_PERMIT_PROTOCOL_STATUS));

      if(permitProtocolStatus == null || permitProtocolStatus.longValue() != 0) {
         eupAcres = null;
      }

      return eupAcres;
   }

   private String readProtocol(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      String protocol = row.getString(getAlias(BFCPermitProtocolSQL.ALIAS_PROTOCOL));
      long status = row.getLong(getAlias(BFCPermitProtocolSQL.ALIAS_REFERENCE_STATUS));

      return status == 1 ? protocol : null;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(BFCPermitProtocolSQL.class);
      return sqlPropFile.getAlias(propName);
   }

}