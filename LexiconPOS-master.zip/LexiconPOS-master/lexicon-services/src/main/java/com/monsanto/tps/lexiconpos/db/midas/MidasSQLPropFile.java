package com.monsanto.tps.lexiconpos.db.midas;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 7, 2005
 * Time: 10:43:08 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasSQLPropFile
{
    String INSERT_PRODUCT = "Product.Insert";
    String UPDATE_PRODUCT_REF_ACTIVE = "Product.UpdateRefActive";
    String DEACTIVATE_PRODUCT_PC_NAMES = "Product.DeactivatePCNames";
    String INSERT_PRODUCT_GP = "ProductGermplasm.Insert";
    String MOVE_PROD_GP = "ProductGermplasm.Move";
    String INSERT_PRODUCT_NAME = "ProductName.Insert";
    String UPDATE_PRODUCT_NAME = "ProductName.Update";
    String UPDATE_PRODUCT_PC_NAMES = "Product.UpdatePCNames";
    String UPDATE_PRODUCT_NAME_ONLY = "ProductName.UpdateNameOnly";
    String UPDATE_NAME_REF_ACTIVE = "ProductName.UpdateRefActive";
    String UPDATE_NAME_PROD_ID = "ProductName.UpdateProductId";
    String INSERT_GERMPLASM = "Germplasm.Insert";
    String INSERT_MATERIAL = "GeneticMaterial.Insert";
    String REPOINT_MATERIAL = "GeneticMaterial.Repoint";


    String SELECT_PROD_NAME_BY_MODEL = "ProductName.SelectByModel";
    String SELECT_PROD_ID_BY_MODEL = "ProductName.SelectByModelProdId";
    String SELECT_PROD_NAME_BY_NAME_ID = "ProductName.SelectByNameId";
    String SELECT_PROD_NAME_BY_NAME_ID2 = "ProductName.SelectByNameId.TopDown";
    String SELECT_PROD_NAME_BY_PROD_ID = "ProductName.SelectByProdId";
    String SELECT_GLOBAL_PCNAME = "ProductName.SelectGlobalPCName";
    String SELECT_PROD_GP_BY_MODEL = "ProductGermplasm.SelectByModel";
    String SELECT_PROD_GP_BY_PROD_ID = "ProductGermplasm.SelectByProdId";
    String SELECT_PROD_GP_BY_GP_ID = "ProductGermplasm.SelectByGPId";
    String SELECT_PROD_GP_LIST = "ProductGermplasm.ListQuery";
    String SELECT_MIRAGE_USE_ONLY_GM = "GeneticMaterial.SelectMirageUseOnly";

    String ALIAS_PROD_NAME_ID = "ProductName.Id";
    String ALIAS_PROD_NAME = "ProductName.Name";
    String ALIAS_NAME_REF_ACTIVE = "ProductName.Active";
    String ALIAS_BRAND_ID = "Brand.Id";
    String ALIAS_BRAND_NAME = "Brand.Name";
    String ALIAS_COUNTRY_ID = "Country.Id";

    String ALIAS_PROD_ID = "Product.Id";
    String ALIAS_CROP_ID = "Crop.Id";
    String ALIAS_PROD_ACTIVE = "Product.Active";
    String ALIAS_PROD_GP_ID = "ProdGP.Id";
    String ALIAS_GP_ID = "GP.Id";
    String ALIAS_ORIGIN = "GP.Origin";
    String ALIAS_LINE_CODE = "GP.LineCode";
    String ALIAS_PEDIGREE = "GP.Pedigree";
    String ALIAS_LINE_TYPE_ID = "LineType.Id";
    String ALIAS_LINE_TYPE_REF_ID = "LineType.RefId";
    String ALIAS_OWNER_PROD_ID = "GP.OwnerProgramId";
    String ALIAS_IS_TRANSGENIC = "GP.IsTransgenic";
    String ALIAS_IS_FINISHED = "GP.IsFinished";
    String ALIAS_REM_REF_NUM = "GP.RemRefNumber";
    String ALIAS_EVENT_DISPLAY = "GP.EventDisplay";

    String ALIAS_GM_ID = "GM.Id";
    String ALIAS_GM_LINEAGE = "GM.Lineage";
    String ALIAS_GM_SOURCE = "GM.Source";
    String ALIAS_GM_GENERATION = "GM.Generation";
}
