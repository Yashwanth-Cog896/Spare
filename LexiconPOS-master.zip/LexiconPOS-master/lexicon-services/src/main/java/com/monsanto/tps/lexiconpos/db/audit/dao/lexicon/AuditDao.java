package com.monsanto.tps.lexiconpos.db.audit.dao.lexicon;

import com.monsanto.tps.lexiconpos.db.audit.domain.lexicon.AuditHeader;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import java.util.Date;
import java.util.List;

/**
 * nbwald - Aug 25, 2008 4:12:57 PM
 */
public class AuditDao
{
   private final SessionFactory sessionFactory;

   public AuditDao(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public List<AuditHeader> find(Date start, Date end) {
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(AuditHeader.class);
      criteria.add(Restrictions.between("entryDate", start, end));
      return criteria.list();
   }
}
