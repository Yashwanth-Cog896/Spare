package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 30, 2006
 * Time: 2:35:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasSubCountryByAbbrQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String subCountryAbbr;
   private final String lexCtryPubkey;

   public MidasSubCountryByAbbrQuery(String subCountryAbbr, String lexCtryPubkey)
   {
      this.subCountryAbbr = subCountryAbbr;
      this.lexCtryPubkey = lexCtryPubkey;
   }

   public MidasSubCountry getSubCountry() throws WrappingException {
      return (MidasSubCountry) execute();
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MidasGeographicRegionQuerySQL.class).getSQL(
         MidasGeographicRegionQuerySQL.SELECT_SUB_COUNTRY_BY_ABBR);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { StringUtils.toUpperCaseNull(subCountryAbbr), lexCtryPubkey };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new MidasSubCountryPSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
