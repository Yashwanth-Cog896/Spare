package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 23, 2006
 * Time: 4:00:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGeographicRegionPSRowImpl
   implements MidasGeographicRegion
{
   private String countryPubkey;
   private long countryId;
   private long subCountryId;
   private long subSubCountryId;
   private String subCountryAbbreviation;
   private String subSubCountryName;

    private final SQLPropFile sqlPropFile = new SQLPropFile(MidasGeographicRegionQuerySQL.class);

   public MidasGeographicRegionPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.countryPubkey = row.getString(sqlPropFile.getAlias(MidasGeographicRegionQuerySQL.COUNTRY_PUBKEY_ALIAS));
      this.countryId = row.getLong(sqlPropFile.getAlias(MidasGeographicRegionQuerySQL.COUNTRY_ID_ALIAS));
      this.subCountryId = row.getLong(sqlPropFile.getAlias(MidasGeographicRegionQuerySQL.SUB_COUNTRY_ID_ALIAS));
      this.subSubCountryId = row.getLong(sqlPropFile.getAlias(MidasGeographicRegionQuerySQL.SUB_SUB_COUNTRY_ID_ALIAS));
      this.subCountryAbbreviation = row.getString(sqlPropFile.getAlias(MidasGeographicRegionQuerySQL.SUB_COUNTRY_ABBR_ALIAS));
      this.subSubCountryName = row.getString(sqlPropFile.getAlias(MidasGeographicRegionQuerySQL.SUB_SUB_COUNTRY_NAME_ALIAS));
   }

   public String getCountryPubkey() {
      return countryPubkey;
   }

   public long getCountryId() {
      return countryId;
   }

   public long getSubCountryId() {
      return subCountryId;
   }

   public long getSubSubCountryId() {
      return subSubCountryId;
   }

   public String getSubCountryAbbreviation() {
      return subCountryAbbreviation;
   }

   public String getSubSubCountryName() {
      return subSubCountryName;
   }
}
