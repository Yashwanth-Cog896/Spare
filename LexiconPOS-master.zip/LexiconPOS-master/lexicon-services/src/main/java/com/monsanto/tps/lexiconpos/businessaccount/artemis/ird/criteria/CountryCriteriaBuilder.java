package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexicon.contact.SearchableLocation;
import org.hibernate.criterion.Criterion;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    CountryCriteriaBuilder.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class CountryCriteriaBuilder {

    public List<Criterion> getCriterion(SearchableLocation searchableLocation) {
        List<QueryCriteria> countryCriteriaList = buildCriteria(searchableLocation);
        return getCriterion(countryCriteriaList);

    }

    private List<Criterion> getCriterion(List<QueryCriteria> countryCriteriaList) {
        List<Criterion> criterion = new ArrayList<Criterion>();
        for (QueryCriteria countryCriteria : countryCriteriaList) {
            if (countryCriteria.hasCriteria()) {
                criterion.add(countryCriteria.getCriterion());
            }
        }
        return criterion;
    }

    private List<QueryCriteria> buildCriteria(SearchableLocation searchableLocation) {
        QueryCriteria countryNameCriteria = new CountryNameCriteriaImpl(searchableLocation.getCountryName());
        return Arrays.asList(countryNameCriteria);
    }

    public void addCriteria(Criteria geoCriteria, SearchableLocation searchableLocation) {
        List<Criterion> countryCriterion = getCriterion(searchableLocation);
        for (Criterion c : countryCriterion) {
            geoCriteria.add(c);
        }
    }
}
