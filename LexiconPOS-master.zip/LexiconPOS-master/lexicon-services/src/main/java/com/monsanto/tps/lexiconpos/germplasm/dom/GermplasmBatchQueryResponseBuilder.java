/*
 GermplasmBatchQueryResponseBuilder was created on Jan 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmBatchQueryResults;
import org.w3c.dom.Document;

/**
 * nbwald Jan 31, 2007 11:58:25 AM
 */
public class GermplasmBatchQueryResponseBuilder {
   private final GermplasmBatchQueryResults results;

   public GermplasmBatchQueryResponseBuilder(GermplasmBatchQueryResults results) {
      this.results = results;
   }

   public Document build() {
      Document responseDoc = createDocument();
      renderResults(responseDoc);
      return responseDoc;
   }

   private void renderResults(Document responseDoc) {
      GermplasmBatchQueryResultsRenderer renderer = new GermplasmBatchQueryResultsRenderer(responseDoc.getDocumentElement(), results);
      renderer.render();
   }

   private Document createDocument() {
      return DocumentCreator.createDocument(GermplasmDocTags.NS_URI, GermplasmQueryDocTags.QUERY_RESULTS_ELEM_NAME);
   }
}