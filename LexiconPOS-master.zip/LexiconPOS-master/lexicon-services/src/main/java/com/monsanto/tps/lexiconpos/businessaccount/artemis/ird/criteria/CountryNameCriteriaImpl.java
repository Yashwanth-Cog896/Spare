package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    CountryNameCriteriaImpl.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class CountryNameCriteriaImpl implements QueryCriteria {
    private String countryName;

    public CountryNameCriteriaImpl(String countryName) {
        this.countryName = countryName;
    }

    public Criterion getCriterion() {
        return Restrictions.eq(BusinessAccountSchemaConstants.COUNTRY_DESCR, StringUtils.upperCase(countryName));
    }

    public boolean hasCriteria() {
        return StringUtils.isNotEmpty(countryName);
    }

}
