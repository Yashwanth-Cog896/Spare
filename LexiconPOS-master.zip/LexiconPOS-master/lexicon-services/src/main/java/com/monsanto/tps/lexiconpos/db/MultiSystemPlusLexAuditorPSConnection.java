package com.monsanto.tps.lexiconpos.db;

import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tps.lexiconpos.util.log.LogWriter;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jun 8, 2006
 * Time: 1:35:53 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class MultiSystemPlusLexAuditorPSConnection
   extends MultiSystemPersistentStoreConnection
{
   public static final String LEX_CONN = "Lexicon";

   private LexiconAuditor lexiconAuditor;

   public PersistentStoreConnection getLexiconConnection()
      throws WrappingException
   {
      boolean connectionExists = (getConnectionFromMap(LEX_CONN) != null);
      PersistentStoreConnection lexConn = super.getConnection(LEX_CONN);
      if (!connectionExists && lexiconAuditor != null) {
         lexiconAuditor.initializeStaging(lexConn);
      }
      return lexConn;
   }

   public void close() {
      removeAuditStaging();
      super.close();
   }

   public void setLexiconAuditor(LexiconAuditor lexiconAuditor)
      throws WrappingException
   {
      PersistentStoreConnection lexiconConnection = getConnectionFromMap(LEX_CONN);
      if (lexiconConnection != null) {
         if (lexiconAuditor == null) {
            clearLexiconAuditor(lexiconConnection);
         }
         else {
            lexiconAuditor.initializeStaging(lexiconConnection);
         }
      }
      this.lexiconAuditor = lexiconAuditor;
   }

   private void clearLexiconAuditor(PersistentStoreConnection lexiconConnection)
      throws WrappingException
   {
      if (this.lexiconAuditor != null) {
         this.lexiconAuditor.removeStaging(lexiconConnection);
      }
   }

   private void removeAuditStaging() {
      PersistentStoreConnection lexiconConnection = getConnectionFromMap(LEX_CONN);
      try {
         if (lexiconAuditor != null && lexiconConnection != null) {
            lexiconAuditor.removeStaging(lexiconConnection);
         }
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(LogWriter.getCategory(this), e);
      }
   }
}
