package com.monsanto.tps.lexiconpos.geography.zipcode;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 2, 2006
 * Time: 4:30:35 PM
 */
public interface ZipCodeQuerySet
{
	public boolean doesZipCodeExist(String zipCode)
		throws WrappingException;
}
