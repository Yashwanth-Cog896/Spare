package com.monsanto.tps.lexiconpos.chemical.domain.mirage;



/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 10:22:04 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class MirageChemProdImpl
    implements MirageChemProd
{
    private long productID;
    private String productName;
    private String fullName;
    private long formulatedAmount;
    private String formulatedAmountName;
    private String formulationDesignation;
    private String[] activeIngredients;
    private boolean enabled;

    public long getProductID() {
        return productID;
    }
    public void setProductID(long productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public long getFormulatedAmount() {
        return formulatedAmount;
    }
    public void setFormulatedAmount(long formulatedAmount) {
        this.formulatedAmount = formulatedAmount;
    }

    public String getFormulatedAmountName() {
        return formulatedAmountName;
    }
    public void setFormulatedAmountName(String formulatedAmountName) {
        this.formulatedAmountName = formulatedAmountName;
    }

    public String getFormulationDesignation() {
       return formulationDesignation;
    }
    public void setFormulationDesignation(String formulationDesignation) {
       this.formulationDesignation = formulationDesignation;
    }

   public String[] getActiveIngredients() {
       return activeIngredients;
   }
   public void setActiveIngredients(String[] activeIngredients) {
       this.activeIngredients = activeIngredients;
   }
    public boolean isEnabled() {
        return enabled;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
