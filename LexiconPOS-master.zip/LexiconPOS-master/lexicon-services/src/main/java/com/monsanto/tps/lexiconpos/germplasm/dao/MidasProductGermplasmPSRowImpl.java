/*
 ProductGermplasmPSRowImpl was created on Jan 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.tps.lexiconpos.germplasm.model.MidasProductGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Jan 22, 2007 12:01:20 PM
 */
public class MidasProductGermplasmPSRowImpl
   implements MidasProductGermplasm
{
   private final Germplasm germplasm;
   private final long midasProductID;
   private final boolean preferred;
   private final Double relativeMaturity;

   public MidasProductGermplasmPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      germplasm = new GermplasmPSRowImpl(row);
      this.midasProductID = row.getLong(getAlias(MidasSQL.ALIAS_PROD_ID));
      this.relativeMaturity = row.getDOUBLE(getAlias(MidasSQL.ALIAS_REL_MAT));
      this.preferred = "T".equals(row.getString(getAlias(MidasSQL.ALIAS_PRODUCT_GERMPLASM_IS_PREFFERED)))?true:false;
   }

   public long getMidasGermplasmID() {
      return germplasm.getMidasGermplasmID();
   }

   public String getOrigin() {
      return germplasm.getOrigin();
   }

   public String getLineCode() {
      return germplasm.getLineCode();
   }

   public String getPedigree() {
      return germplasm.getPedigree();
   }

   public String getLineType() {
      return germplasm.getLineType();
   }

   public String getCropName() {
      return germplasm.getCropName();
   }

   public String getOwnerProgRefID() {
      return germplasm.getOwnerProgRefID();
   }

   public String getEventDisplay() {
      return germplasm.getEventDisplay();
   }

   public boolean isTransgenic() {
      return germplasm.isTransgenic();
   }

   public boolean isDeleted() {
      return germplasm.isDeleted();
   }

   public boolean isFinished() {
      return germplasm.isFinished();
   }

   public long getMidasProductID() {
      return midasProductID;
   }

   public Double getRelativeMaturity() {
      return relativeMaturity;
   }

   private String getAlias(String ident)
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getAlias(ident);
   }

   public boolean isPreferred() {
      return preferred;
   }
}