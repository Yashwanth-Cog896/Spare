/*
 CountriesByNameQuery was created on Jun 5, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconCountryPSRowImpl;
import com.monsanto.tps.lexicon.geography.country.Country;

import java.util.List;

/**
 * @author GGSHIV - Jun 5, 2008 11:45:02 AM
 */
public class CountriesByNameQuery extends AbstractPersistentStoreMultiRowQuery {

   private final String countryName;

   public CountriesByNameQuery(String countryName) {
      this.countryName = new StdWildcardableCriteria(countryName).oracleVersion();
   }

   public List<Country> findCountries() {
      try {
         return getList();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      CountryBuilder countryBuilder = new CountryBuilder();
      return countryBuilder.build(new LexiconCountryPSRowImpl(row));
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(LexiconSQL.class).getSQL(LexiconSQL.SELECT_COUNTRY_BY_WCNAME);
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]{countryName};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
