package com.monsanto.tps.lexiconpos.db.lexicon;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 4, 2005
 * Time: 11:10:37 AM
 */
public interface LexiconSQL {
    String ALIAS_PROD_PUBKEY = "ProdPubkey";
    String ALIAS_PRE_COML_NAME = "PreComlName";
    String ALIAS_CROP_ID = "Crop.ID";
    String ALIAS_CROP_PUBKEY = "Crop.Pubkey";
    String ALIAS_CROP_NAME = "Crop.Name";
    String ALIAS_CROP_ABBR = "Crop.Abbr";
    String ALIAS_BAYER_CODE = "BayerCode";
    String ALIAS_NAME_ID = "NameID";
    String ALIAS_NAME_PUBKEY = "NamePubkey";
    String ALIAS_PROD_NAME = "ProdName";
    String ALIAS_COUNTRY_ID = "Country.ID";
    String ALIAS_COUNTRY_PUBKEY = "Country.Pubkey";
    String ALIAS_COUNTRY_NAME = "Country.Name";
    String ALIAS_COUNTRY_ABBR = "Country.Abbr";
    String ALIAS_ISO_CODE = "Country.ISOCode";
    String ALIAS_SUBCOUNTRY_DESCRIPTION = "Country.SubCountryDescription";
    String ALIAS_SUBSUBCOUNTRY_DESCRIPTION = "Country.SubSubCountryDescription";
    String ALIAS_UN_CODE = "Country.UNCode";
    String ALIAS_BRAND_ID = "Brand.ID";
    String ALIAS_BRAND_PUBKEY = "Brand.Pubkey";
    String ALIAS_BRAND_NAME = "Brand.Name";
    String ALIAS_MATURITY = "Maturity";
    String ALIAS_ACTIVE = "Active";
    String ALIAS_DELETED = "Deleted";
    String ALIAS_PRODUCT_DELETED = "ProductDeleted";
    String ALIAS_PARENT_PRODUCT_FLAG = "ParentProductFlag";
    String ALIAS_PREFERRED_NAME = "PreferredName";
    String ALIAS_VERIFIED_NAME = "VerifiedName";
    String ALIAS_PRODUCT_KIND_ID = "ProductKindId";

    String ALIAS_VERFIED_DS = "VerfiedDS";
    String ALIAS_DS_YEAR = "DSYear";
    String ALIAS_COMMENTS = "Comments";
    String ALIAS_BAYER_CODE_ID = "BayerCodeID";

    String ALIAS_COMMERCIAL_NAME = "CommercialName";
    String ALIAS_STAGE_TYPE_PUBKEY = "StageType.Pubkey";
    String ALIAS_STAGE_ID = "StageType.ID";
    String ALIAS_STAGE_TYPE_ABBR = "StageType.Abbr";
    String ALIAS_OECD_REQD_NAME = "OecdReqdName";
    String ALIAS_TEST_NAME = "TestName";
    String ALIAS_TAG_VARIETY_NAME = "TagVarietyName";
    String ALIAS_SUPPLY_CHAIN_OWNER = "SupplyChainOwner";
    String ALIAS_PRODUCT_CLASSIFICATION_CODE = "ProductClassificationCode";

    String ALIAS_SUBCOUNTRY_ID = "SubCountry.ID";
    String ALIAS_SUBCOUNTRY_NAME = "SubCountry.Name";
    String ALIAS_SUBCOUNTRY_ABBR = "SubCountry.Abbr";
    String ALIAS_SUBSUBCOUNTRY_ID = "SubSubCountry.ID";
    String ALIAS_SUBSUBCOUNTRY_NAME = "SubSubCountry.Name";

    String ALIAS_TRAIT_STACK_ID = "TraitStack.ID";
    String ALIAS_TRAIT_STACK_PUBKEY = "TraitStack.Pubkey";
    String ALIAS_TRAIT_STACK_ABBR = "TraitStack.Abbr";
    String ALIAS_TRANS_TRAITS = "TraitStack.Transgenic";

    String ALIAS_TRAIT_VERSION = "TraitVersion";
    String ALIAS_PRODUCTION_STATUS = "ProductionStatus";
    String ALIAS_MANF_NAME = "ManfName";
    String ALIAS_RELATIONSHIP_PUBKEY = "Relationship.Pubkey";
    String ALIAS_RELATIONSHIP_ID = "Relationship.ID";

    String SELECT_CP_NAME_PUBKEYS = "CompProdName.SelectNamePubkeys";
    String SELECT_CP_NAME_BY_PUBKEY = "CompProdName.SelectByNamePubkey";
    String SELECT_SIMILAR_CP_NAMES = "CompProdName.SelectSimilarNames";
    String SELECT_CP_NAMES_BY_PRODUCT_PUBKEY = "CompProdName.SelectByProductPubkey";
    //    String SELECT_CP_PROD_BY_PUBKEY = "CompProd.SelectByProdPubkey";
    String SELECT_MP_NAME_PUBKEYS = "MonProdName.SelectNamePubkeys";

    String SELECT_MP_NAME_BY_PUBKEY = "MonProdName.SelectByNamePubkey";
    String SELECT_MP_BY_PRODUCT_PUBKEY = "MonProdName.SelectByProductPubkey";
    String SELECT_MP_PUBKEY_BY_PN_PUBKEY = "MonProdName.SelectProuctPubkey";
    String SELECT_MP_BY_PC_NAME = "MonProd.SelectPubkeyByPCName";
    String SELECT_MP_PUBKEYS_BY_COML_NAME = "MonProd.SelectPubkeysByComlName";

    String SELECT_MP_PUBKEYS_BY_TAG_VARIETY_NAME = "MonProd.SelectPubkeysByTagVarietyName";
    String SELECT_MP_VARIETYNAME_BY_REGEX_TAG_VARIETY_NAME = "MonProd.SelectTagVarietyNamesByREGEXAndCrop";


    String SELECT_MP_NAME_BY_MATCHING = "MonProdName.SelectByCriteria";
    String SELECT_PRODUCT_BY_PRODUCT_PUBKEY = "MonProd.SelectProductByProductPubkey";
    String SELECT_MP_NAME_BY_SIMILAR_COML_NAME = "MonProdName.SelectBySimilarComlName";
    String SELECT_MP_NAME_BY_COML_NAME = "MonProdName.SelectByComlName";

    String SELECT_GEN_PROD_BY_PUBKEY = "GenProd.SelectByProdPubkey";
    String SELECT_GEN_NAME_BY_PUBKEY = "GenProdName.SelectByNamePubkey";
    String SELECT_GEN_NAMES_BY_PROD_PUBKEY = "GenProdName.SelectByProdPubkey";
    String SELECT_GEN_NAMES_BY_NAME = "GenProdName.SelectByName";
    String SELECT_GEN_NAMES_BY_NAME_REGULATORY = "GenProdName.SelectRegulatoryByName";
    String SELECT_GEN_PROD_QUERY = "GenProdName.Query";

    String SELECT_COUNTRY_BY_UN_CODE = "Country.Query.ByUNCode";
    String SELECT_COUNTRY_BY_ISO_CODE = "Country.Query.ByISOCode";
    String SELECT_COUNTRY_BY_ISO_CODES = "Country.Query.ByISOcodes";
    String SELECT_COUNTRY_BY_WCNAME = "Country.Query.ByName";
    String SELECT_COUNTRY_BY_ABBR = "Country.Query.ByAbbr";
    String SELECT_COUNTRY_BY_PUBKEY = "Country.Query.ByPubkey";
    String SELECT_SUBCOUNTRY_BY_WCNAME = "SubCountry.Query.ByName";
    String SELECT_SUBCOUNTRY_BY_ABBR = "SubCountry.Query.ByAbbr";

    String SELECT_SUBSUBCOUNTRY_BY_WCNAME = "SubSubCountry.Query.ByName";
    String SELECT_PROD_REL_BY_PROD_REL_PUBKEY = "ProductRelationship.SelectByRelPubkey";
    String SELECT_PROD_REL_BY_MANFNAME = "ProductRelationship.SelectByManfName";
    String SELECT_PROD_RELS_BY_WC_MANFNAME = "ProductRelationship.SelectByWildCardManfName";
    String SELECT_PROD_RELS_BY_MANF_NAME_BATCH = "ProductRelationship.SelectByManfNameBatch";
    String SELECT_PROD_RELS_BY_WC_PCNAME = "ProductRelationship.SelectByWildCardPCName";
    String SELECT_PROD_REL_BY_PCNAME = "ProductRelationship.SelectByPCName";
    String SELECT_PROD_RELS_BY_PRE_COML_NAME_BATCH = "ProductRelationship.SelectByPreComlNameBatch";
    String SELECT_PROD_REL_BY_PROD_PUBKEY = "ProductRelationship.SelectByProdPubkey";
    String SELECT_PROD_REL_PROD_BY_ID = "ProductRelationshipProduct.SelectByRelId";
    String SELECT_PROD_REL_PROD_BY_REL_PUBKEY = "ProductRelationshipProduct.SelectByRelPubkey";
    String SELECT_PROD_REL_PROD_BY_MANUFACTURING_NAME = "ProductRelationshipProduct.SelectByManufacturingName";

    String SELECT_PROD_REL_PROD_BY_PROD_PUBKEY = "ProductRelationshipProduct.SelectByProductPubkey";

    String SELECT_PRODUCTION_STATUS_ID_BY_NAME = "ProductionStatus.SelectIDByName";
    String SELECT_RELATIONSHIP_PRODUCT_BY_STAGE_PUBKEY = "RelationshipProduct.ByStagePubkey";

    String SELECT_VARIETY_NAME_BY_RELATIONSHIP_PUBKEY = "VarietyName.ByRelationshipPubkey";
    String SELECT_NON_EQUIVALENT_PRODUCTS_BY_VARIETY_NAME = "NonEquivalendLexiconMonsantoProducts.SelectByVarietyName";
    String ALIAS_OWNER_REGION = "OwnerRegion";
    String SELECT_GERMPLASM_EVENT_CONSTRUCT = "EventConstruct.ByProductName";
}
