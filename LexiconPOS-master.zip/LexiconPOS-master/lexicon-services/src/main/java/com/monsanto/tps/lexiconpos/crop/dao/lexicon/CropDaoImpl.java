package com.monsanto.tps.lexiconpos.crop.dao.lexicon;

import com.monsanto.tps.lexiconpos.crop.domain.lexicon.Crop;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * rrchak1 - Feb 13, 2009 12:46:41 PM
 */
public class CropDaoImpl
   implements CropDao
{
   private SessionFactory sessionFactory;

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public Crop findByName(String cropName) {
      Session session = sessionFactory.getCurrentSession();
      return (Crop) session.getNamedQuery("crop.byCropName").setString(0, StringUtils.upperCase(cropName)).uniqueResult();
   }

   public Crop findByPubkey(String cropPubkey)
   {
       Session session = sessionFactory.getCurrentSession();
       return (Crop) session.getNamedQuery("crop.byCropPubkey").setString(0, cropPubkey).uniqueResult();
   }

   public Crop[] findAll() {
      Session session = sessionFactory.getCurrentSession();
      List<Crop> allCrops = session.getNamedQuery("crop.all").list();
      return allCrops.toArray(new Crop[allCrops.size()]);
   }

   public Crop findByCropID(Long cropID) {
      Session session = sessionFactory.getCurrentSession();
      return (Crop) session.getNamedQuery("crop.byCropID").setLong(0, cropID).uniqueResult();
   }
}
