package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * Filename:    SubCountryCriteriaImpl.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class SubCountryCriteriaImpl implements QueryCriteria {
    private String subCountryCode;

    public SubCountryCriteriaImpl(String subCountryCode) {
        this.subCountryCode = subCountryCode;
    }

    public Criterion getCriterion() {
        return Restrictions.eq(BusinessAccountSchemaConstants.STATE_CODE, StringUtils.upperCase(subCountryCode));
    }

    public boolean hasCriteria() {
        return StringUtils.isNotEmpty(subCountryCode);
    }

}
