package com.monsanto.tps.lexiconpos.event.bfc.notificationdetail;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Sep 27, 2006
 * Time: 12:38:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class BFCNotificationDetailLookup implements BFCNotificationDetailLookupSQL
{
   private final SQLPropFile sqlPropFile = new SQLPropFile(BFCNotificationDetailLookupSQL.class);

   public String[] getNotificationDetails(String monsantoId, PersistentStoreConnection bfcConnection)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(SELECT_PERMIT_CONST_TRANS_DETAILS_BY_MONSANTO_ID);
      PersistentStoreStatement stmt = bfcConnection.prepareStatement(sql);
      try {
         stmt.setParam(1, monsantoId);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         return buildDetailsAggregation(iter);
      }
      finally {
         stmt.close();
      }
   }

   private String[] buildDetailsAggregation(PersistentStoreResultSetFwdIterator iter)
      throws WrappingException
   {
      List details = new ArrayList();
      while(iter.next()) {
         details.add(iter.getString(sqlPropFile.getAlias(ALIAS_DETAILS)));
      }
      return (String[])details.toArray(new String[details.size()]);
   }
}
