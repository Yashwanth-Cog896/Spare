/*
 FindCountriesByISOCodesAction was created on Jun 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.geography.country.contract.CountryISOCodesRequest;
import com.monsanto.tps.lexiconpos.geography.country.query.CountryQuerySet;
import com.monsanto.tps.lexiconpos.geography.country.query.CountryQuerySetImpl;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexicon.geography.country.Country;

import java.util.List;

/**
 * @author GGSHIV - Jun 4, 2008 10:06:56 AM
 */
public class FindCountriesByISOCodesAction
        extends AbstractArtemisServiceAction {
   private final CountryQuerySet CountryQuerySet;

   public FindCountriesByISOCodesAction() {
      this(new CountryQuerySetImpl());
   }

   public FindCountriesByISOCodesAction(CountryQuerySet countryQuerySet) {
      this.CountryQuerySet = countryQuerySet;
   }

   public void process(ServiceProcessContext context)
           throws Exception {
      CountryISOCodesRequest request = new CountryISOCodesRequest(context);
      List<Country> countries = CountryQuerySet.findCountriesByISOCodes(request.getCountryISOCodes());
      new MultipleResultResponse(countries).saveResponse(context);
   }
}
