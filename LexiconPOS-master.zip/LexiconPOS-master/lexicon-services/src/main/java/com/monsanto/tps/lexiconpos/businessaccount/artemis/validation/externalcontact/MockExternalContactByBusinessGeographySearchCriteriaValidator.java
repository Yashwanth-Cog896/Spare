package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact;

import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;

/**
 * Filename:    MockExternalContactByBusinessGeographySearchCriteriaValidator.java
 * Last Change: rrchak1 On:	Jul 29, 2008
 *
 * @author: rrchak1
 */
public class MockExternalContactByBusinessGeographySearchCriteriaValidator
    implements ExternalContactByBusinessGeographySearchCriteriaValidator {
    
    public void validate(ExternalContactByBusinessGeographySearchCriteria searchCriteria) {
    }
}
