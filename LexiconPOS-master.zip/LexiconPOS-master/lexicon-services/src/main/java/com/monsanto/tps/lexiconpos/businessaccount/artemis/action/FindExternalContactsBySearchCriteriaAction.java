package com.monsanto.tps.lexiconpos.businessaccount.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact.ContactCollection;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.contract.ExternalContactSearchCriteriaRequest;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service.IrdExternalContactService;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact.ExternalContactSearchCriteriaValidator;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * nbwald - May 15, 2008 2:33:28 PM
 */
public class FindExternalContactsBySearchCriteriaAction
   extends AbstractArtemisServiceAction
{
   private ExternalContactSearchCriteriaValidator validator;
   private IrdExternalContactService service;

   public FindExternalContactsBySearchCriteriaAction(IrdExternalContactService service, ExternalContactSearchCriteriaValidator validator) {
      this.service = service;
      this.validator = validator;
   }

   public void process(ServiceProcessContext context)
      throws Exception
   {
      ExternalContactSearchCriteriaRequest request = new ExternalContactSearchCriteriaRequest(context);
      ExternalContactSearchCriteria searchCriteria = request.getSearchCriteria();
      validator.validate(searchCriteria);
      Contact[] irdContacts = service.findBySearchCriteria(searchCriteria);
      ContactCollection contactCollection = new ContactCollection(irdContacts);
      new MultipleResultResponse(contactCollection.getExternalContacts()).saveResponse(context);
   }
}
