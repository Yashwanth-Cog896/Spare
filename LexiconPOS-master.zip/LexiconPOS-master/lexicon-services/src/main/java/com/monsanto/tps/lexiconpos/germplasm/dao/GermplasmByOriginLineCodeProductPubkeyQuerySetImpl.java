package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 24, 2007
 * Time: 9:30:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class GermplasmByOriginLineCodeProductPubkeyQuerySetImpl
   implements GermplasmByOriginLineCodePedigreeProductPubkeyQuerySet
{
   public Germplasm[] getGermplasmsByCropNameAndLineCode(String lineCode, String cropName)
        throws WrappingException
     {
        GermplasmsByCropNameAndWildcardableLineCodeQuery query = new GermplasmsByCropNameAndWildcardableLineCodeQuery(lineCode, cropName);
        return query.getGermplasms();
     }

     public Germplasm[] getGermplasmsByCropNameAndOrigin(String origin, String cropName)
        throws WrappingException
     {
        GermplasmsByCropNameAndWildcardableOriginQuery query = new GermplasmsByCropNameAndWildcardableOriginQuery(origin, cropName);
        return query.getGermplasms();
     }

     public Germplasm[] getGermplasmsByCropNameAndLexProdPubkey(String lexProdPubkey, String cropName)
        throws WrappingException
     {
        GermplasmsByCropNameAndLexProdPubkeyQuery query = new GermplasmsByCropNameAndLexProdPubkeyQuery(lexProdPubkey, cropName);
        return query.getGermplasms();
     }

   @Override
   public Germplasm[] getGermplasmsByCropNameAndPedigree(String pedigree, String cropName)
      throws WrappingException
   {
      GermplasmsByCropNameAndWildcardablePedigreeQuery query = new GermplasmsByCropNameAndWildcardablePedigreeQuery(pedigree, cropName);
      return query.getGermplasms();

   }
}
