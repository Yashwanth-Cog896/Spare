package com.monsanto.tps.lexiconpos.db.factories.fbs;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * <p>Title: FBSCommonConnectionFactory</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author jlevrae
 * @version $Id
 */
public class FBSCommonConnectionFactory
   extends BasicConnectionFactory
{
   public FBSCommonConnectionFactory() {
      super(new FBSCommonConnectionFactoryProperties());
   }
}

