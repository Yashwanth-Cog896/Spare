package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 24, 2007
 * Time: 9:24:45 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GermplasmByOriginLineCodePedigreeProductPubkeyQuerySet
{
   Germplasm[] getGermplasmsByCropNameAndLineCode(String lineCode, String cropName)
      throws WrappingException;

   Germplasm[] getGermplasmsByCropNameAndOrigin(String origin, String cropName)
      throws WrappingException;

   Germplasm[] getGermplasmsByCropNameAndLexProdPubkey(String lexProdPubkey, String cropName)
      throws WrappingException;

   Germplasm[] getGermplasmsByCropNameAndPedigree(String pedigree, String cropName)
      throws WrappingException;
}
