/*
 CropsByNameAndScientificNameQuery was created on Jul 1, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.SELECT_BY_NAME_AND_SCIENTIFIC_NAME;
import static com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet.CROP_SQL_PROPERTY_FILE;

import java.util.List;

/**
 * @author PNAGAPP - Jul 1, 2008 3:24:04 PM
 */
public class CropsByNameAndScientificNameQuery extends AbstractPersistentStoreMultiRowQuery {

   private final WildcardableCriteria name;
   private final WildcardableCriteria scientificName;

   public CropsByNameAndScientificNameQuery(WildcardableCriteria name, WildcardableCriteria scientificName) {
      this.name = name;
      this.scientificName = scientificName;
   }

   public List<SegregateCrop> find() throws WrappingException {
      return getList();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new SegregateCropBuilder().build(row);
   }

   protected String getSQL() throws WrappingException {
      return CROP_SQL_PROPERTY_FILE.getSQL(SELECT_BY_NAME_AND_SCIENTIFIC_NAME);
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]{scientificName.oracleVersion(), name.oracleVersion()};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
