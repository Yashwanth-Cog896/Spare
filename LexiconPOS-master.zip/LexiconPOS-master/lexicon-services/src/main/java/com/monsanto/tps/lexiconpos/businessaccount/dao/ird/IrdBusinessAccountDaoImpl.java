package com.monsanto.tps.lexiconpos.businessaccount.dao.ird;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.AddressCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.BusinessAccountCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.BusinessAccountIdCriteriaImpl;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.BusinessAccountStatusCriteriaImpl;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.CountryCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.FipsCriteriaBuilder;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;

import java.util.List;

/**
 * Filename:    IrdBusinessAccountDaoImpl.java
 * Last Change: rrchak1 On:	Aug 5, 2008
 *
 * @author: rrchak1
 */
public class IrdBusinessAccountDaoImpl
   implements IrdBusinessAccountDao
{
   private Class<Acct> persistentClass = Acct.class;
   private BusinessAccountCriteriaBuilder businessAccountCriteriaBuilder;
   private CountryCriteriaBuilder countryCriteriaBuilder;
   private AddressCriteriaBuilder addressCriteriaBuilder;
   private FipsCriteriaBuilder fipsCriteriaBuilder;
   private SessionFactory sessionFactory;


   public Acct[] findByIds(long[] businessAccountIds) {
      if (ArrayUtils.isEmpty(businessAccountIds)) {
         return new Acct[0];
      }
      Session session = sessionFactory.getCurrentSession();
      Criteria businessAccountCriteria = session.createCriteria(persistentClass);
      businessAccountCriteria.add(new BusinessAccountIdCriteriaImpl(businessAccountIds).getCriterion());
      businessAccountCriteria.add(new BusinessAccountStatusCriteriaImpl().getCriterion());
      List list = businessAccountCriteria.list();
      return (Acct[]) list.toArray(new Acct[list.size()]);
   }

   public Acct[] findBySearchCriteria(BusinessAccountSearchCriteria businessAccountSearchCriteria) {
      Session session = sessionFactory.getCurrentSession();
      Criteria businessAccountCriteria = session.createCriteria(persistentClass);
      businessAccountCriteria.setProjection(Projections.distinct(Property.forName(BusinessAccountSchemaConstants.ACCT_ID)));
      if (businessAccountSearchCriteria.getMaxResults() != 0) {
         businessAccountCriteria.setMaxResults(businessAccountSearchCriteria.getMaxResults());
      }
      addCriteria(businessAccountSearchCriteria, businessAccountCriteria);
      List list = businessAccountCriteria.list();
      return findByIds(ArrayUtils.toPrimitive((Long[]) list.toArray(new Long[list.size()])));
   }

   private void addCriteria(BusinessAccountSearchCriteria businessAccountSearchCriteria, Criteria businessAccountCriteria) {
      Criteria accountAddressCriteria;
      Criteria geoCriteria;
      Criteria zipCodeCriteria;
      Criteria fipsCriteria;
      SearchableLocation searchableLocation;

      businessAccountCriteriaBuilder.addCriteria(businessAccountCriteria, businessAccountSearchCriteria);

      searchableLocation = businessAccountSearchCriteria.getLocation();
      if (null != searchableLocation) {
         accountAddressCriteria = businessAccountCriteria.createCriteria(BusinessAccountSchemaConstants.ACCT_ADDRS);
         geoCriteria = accountAddressCriteria.createCriteria(BusinessAccountSchemaConstants.GEO);
         zipCodeCriteria = accountAddressCriteria.createCriteria(BusinessAccountSchemaConstants.ZIPCODE);
         fipsCriteria = zipCodeCriteria.createCriteria(BusinessAccountSchemaConstants.FIPS);

         countryCriteriaBuilder.addCriteria(geoCriteria, searchableLocation);
         addressCriteriaBuilder.addCriteria(accountAddressCriteria, searchableLocation);
         fipsCriteriaBuilder.addCriteria(fipsCriteria, searchableLocation);
      }
   }

   public void setBusinessAccountCriteriaBuilder(BusinessAccountCriteriaBuilder businessAccountCriteriaBuilder) {
      this.businessAccountCriteriaBuilder = businessAccountCriteriaBuilder;
   }

   public void setCountryCriteriaBuilder(CountryCriteriaBuilder countryCriteriaBuilder) {
      this.countryCriteriaBuilder = countryCriteriaBuilder;
   }

   public void setAddressCriteriaBuilder(AddressCriteriaBuilder addressCriteriaBuilder) {
      this.addressCriteriaBuilder = addressCriteriaBuilder;
   }

   public void setFipsCriteriaBuilder(FipsCriteriaBuilder fipsCriteriaBuilder) {
      this.fipsCriteriaBuilder = fipsCriteriaBuilder;
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }
}
