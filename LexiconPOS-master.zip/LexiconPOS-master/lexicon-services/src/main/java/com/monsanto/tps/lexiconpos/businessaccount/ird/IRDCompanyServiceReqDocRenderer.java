package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.businessaccount.company.CompanyRequest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:33:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class IRDCompanyServiceReqDocRenderer
{
   private final CompanyRequest request;

   private static final String ACCOUNT_BY_NAME_ATTR_VAL = "ACCTBYNAME";
   private static final String CLIENTID_ATTR_VAL = "CLIENTID";
   private static final String FUNCTION_TYPE_CODE = "FUNCTION_TYPE_CODE";
   private static final String COMPANY_NAME_ATTR_VAL = "NAME_1";

   public IRDCompanyServiceReqDocRenderer(CompanyRequest request)
   {
      this.request = request;
   }

   public Document renderRequest()
   {
      Document doc = DOMUtil.newDocument();
      Element root = DOMUtil.addChildElement(doc, BusinessAccountSchemaConstants.IRDSERVICE_REQ_ELEM_NAME);
      Element requestElem = addRequestElement(root);
      addAcctCodeElem(requestElem);
      addCompanyElem(requestElem);
      return doc;
   }

   private Element addRequestElement(Element root) {
      Element requestElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.REQUEST_ELEM_NAME);
      addKeyAttr(requestElem);
      addIDAttr(requestElem);
      return requestElem;
   }

   private void addKeyAttr(Element requestElem) {
      requestElem.setAttribute(BusinessAccountSchemaConstants.KEY_ATTR_NAME, ACCOUNT_BY_NAME_ATTR_VAL);
   }

   private void addIDAttr(Element requestElem) {
      requestElem.setAttribute(BusinessAccountSchemaConstants.ID_ATTR_NAME, CLIENTID_ATTR_VAL);
   }

   private void addAcctCodeElem(Element root) {
      Element fieldElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.FIELD_ELEM_NAME, request.getAccountType());
      fieldElem.setAttribute(BusinessAccountSchemaConstants.NAME_ATTR_NAME, FUNCTION_TYPE_CODE);
   }

   private void addCompanyElem(Element root) {
      String companyName = StringUtils.isNullOrEmpty(request.getCompanyName()) ? "%" : replaceWCWithIRDWC(request.getCompanyName());
      Element fieldElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.FIELD_ELEM_NAME, companyName);
      fieldElem.setAttribute(BusinessAccountSchemaConstants.NAME_ATTR_NAME, COMPANY_NAME_ATTR_VAL);
   }

   private String replaceWCWithIRDWC(String value) {
      StdWildcardableCriteria criteria = new StdWildcardableCriteria(value);
      return criteria.oracleVersion();
   }
}

