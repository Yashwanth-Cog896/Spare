package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 11:35:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidGeographyRequestException
    extends Exception
{
    public InvalidGeographyRequestException(String message) {
        super(message);
    }
}
