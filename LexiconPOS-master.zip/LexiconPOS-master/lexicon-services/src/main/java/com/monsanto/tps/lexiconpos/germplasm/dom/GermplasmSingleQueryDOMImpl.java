package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.germplasm.OriginRecipricator;
import com.monsanto.tps.lexiconpos.germplasm.model.GermplasmSingleQuery;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 19, 2007
 * Time: 2:26:25 PM
 */
public class GermplasmSingleQueryDOMImpl
   implements GermplasmSingleQuery
{
   private final String cropName;
   private final String origin;
   private final String lineCode;
   private final String productPubkey;
   private final String pedigree;
   private final boolean preferred;
   public GermplasmSingleQueryDOMImpl(Document request)
   {
      Element docElement = request.getDocumentElement();
      this.cropName = parseCropName(docElement);
      this.origin = parseOrigin(docElement);
      this.lineCode = parseLineCode(docElement);
      this.pedigree = parsePedigree(docElement);
      this.productPubkey = parseProductPubkey(docElement);
      this.preferred = parsePreferred(docElement);
   }

   public String getCropName() {
      return cropName;
   }

   public String getOrigin() {
      return origin;
   }

   public String getPedigree() {
      return pedigree;
   }

   public String getOriginReciprocal() {
      OriginRecipricator recipricator = new OriginRecipricator(getOrigin());
      return recipricator.getReciprical();
   }

   public String getLineCode() {
      return lineCode;
   }

   public String getProductPubkey() {
      return productPubkey;
   }

   @Override
   public boolean isPreferred() {
      return preferred;
   }   

   private String parseCropName(Element documentElement) {
      return DOMUtil.getChildValue(documentElement, GermplasmDocTags.CROP_NAME_ELEM_NAME);
   }

   private String parseOrigin(Node node) {
      return DOMUtil.getChildValue(node, GermplasmDocTags.ORIGIN_ELEM_NAME);
   }

   private String parseLineCode(Node node) {
      return DOMUtil.getChildValue(node, GermplasmDocTags.LINE_CODE_ELEM_NAME);
   }

   private String parsePedigree(Node node) {
      return DOMUtil.getChildValue(node, GermplasmDocTags.PEDIGREE_ELEM_NAME);
   }

   private String parseProductPubkey(Node node) {
      return DOMUtil.getChildValue(node, GermplasmDocTags.PRODUCT_PUBKEY_ELEM_NAME);
   }

   private boolean parsePreferred(Node node){
      String element = DOMUtil.getChildValue(node, GermplasmDocTags.IS_PREFERRED_ELEM_NAME);
      boolean returnValue = false;
      if(element!=null){
         returnValue = Boolean.parseBoolean(element);
      }
      return returnValue;
   }


}
