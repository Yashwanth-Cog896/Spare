package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexicon.person.ExternalContact;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jul 30, 2008 3:28:25 PM
 */
public class ContactCollection
{
   private final Contact[] contacts;

   public ContactCollection(Contact[] contacts) {
      this.contacts = contacts;
   }

   public ExternalContact[] getExternalContacts() {
      return contacts == null ? new ExternalContact[0] : getExternalContactsFromNonNullContacts();
   }

   private ExternalContact[] getExternalContactsFromNonNullContacts() {
      List<ExternalContact> externalContacts = new ArrayList<ExternalContact>();
      for (Contact contact : contacts) {
         ExternalContactBuilder builder = new ExternalContactBuilder();
         externalContacts.add(builder.build(contact));
      }
      return externalContacts.toArray(new ExternalContact[externalContacts.size()]);
   }
}
