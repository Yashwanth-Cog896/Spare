package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service;

import com.monsanto.tps.lexiconpos.businessaccount.dao.ird.IrdExternalContactDao;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * Filename:    IrdExternalContactServiceImpl.java
 * Last Change: rrchak1 On:	Jul 28, 2008
 *
 * @author: rrchak1
 */
public class IrdExternalContactServiceImpl
   implements IrdExternalContactService
{

   private IrdExternalContactDao irdExternalContactDao;

   public IrdExternalContactDao getIrdExternalContactDao() {
      return irdExternalContactDao;
   }

   public void setIrdExternalContactDao(IrdExternalContactDao irdExternalContactDao) {
      this.irdExternalContactDao = irdExternalContactDao;
   }

   public Contact[] findByBusinessGeographySearchCriteria(ExternalContactByBusinessGeographySearchCriteria externalContactByBusinessGeographySearchCriteria) {
      return irdExternalContactDao.findByBusinessGeographySearchCriteria(externalContactByBusinessGeographySearchCriteria);
   }

   public Contact[] findByIds(long[] contactIds) {
      return irdExternalContactDao.findByIds(contactIds);
   }

   public Contact[] findByBusinessAccountIds(long[] businessAccountIds) {
      return irdExternalContactDao.findByBusinessAcctIds(businessAccountIds);
   }

   public Contact[] findBySearchCriteria(ExternalContactSearchCriteria externalContactSearchCriteria) {
      return irdExternalContactDao.findBySearchCriteria(externalContactSearchCriteria);
   }

}
