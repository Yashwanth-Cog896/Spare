/*
 SubsubcountriesByAbbreviationQuery was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subsubcountry.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.StringsCriteriaBuilder;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

import java.util.List;

/**
 * @author GGSHIV - Jun 10, 2008 2:39:25 PM
 */
public class SubsubcountriesByAbbreviationQuery extends AbstractPersistentStoreMultiRowQuery {

   private final String lexiconCountryPubkey;
   private final String[] subcountriesAbbreviation;
   private final WildcardableCriteria subsubcountryName;

   public SubsubcountriesByAbbreviationQuery(String lexiconCountryPubkey, String[] subcountriesAbbreviation, StdWildcardableCriteria subsubcountryName) {
      this.lexiconCountryPubkey = lexiconCountryPubkey;
      this.subcountriesAbbreviation = subcountriesAbbreviation;
      this.subsubcountryName = subsubcountryName;
   }

   public Subsubcountry[] find() {
      try {
         List<Subsubcountry> subcountries = getList();
         return subcountries.toArray(new Subsubcountry[subcountries.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      Subsubcountry subsubcountry = new Subsubcountry();
      subsubcountry.setName( row.getString("SubsubCountryName") );
      subsubcountry.setAbbreviation( row.getString("SubCountryAbbr") );
      return subsubcountry;
   }

   protected String getSQL() throws WrappingException {
      return
         "   SELECT SSC.name AS \"SubsubCountryName\", SC.sub_country_abbr AS \"SubCountryAbbr\"" +
         "     FROM FBS_Common.Country_Xref CX," +
         "          Midas.Country C," +
         "          Midas.Sub_Country SC," +
         "          Midas.Sub_Sub_Country SSC" +
         "    WHERE CX.lexicon_country_pubkey = ?" +
         "      AND CX.midas_country_id = C.country_id" +
         "      AND C.country_id = SC.country_id" +
         "      AND SC.sub_country_id = SSC.sub_country_id" + getCriteria() +
         " ORDER BY SSC.name";
   }

   protected Object[] getBindVariables() throws WrappingException {
      return null == subsubcountryName.getCriteria() ? new Object[] { lexiconCountryPubkey }
              : new Object[] { lexiconCountryPubkey, subsubcountryName.oracleVersion() };
   }

   private String getCriteria() {
      if (subcountriesAbbreviation == null) {
         return subsubCountryNameCriteria();
      }
      if (subsubcountryName.getCriteria() == null) {
         return subCountryAbbreviationCriteria();
      }
      return subCountryAbbreviationCriteria() + subsubCountryNameCriteria();
   }

   private String subCountryAbbreviationCriteria() {
      return " AND UPPER(SC.sub_country_abbr) IN (" + new StringsCriteriaBuilder().build(subcountriesAbbreviation) + ")";
   }

   private String subsubCountryNameCriteria() {
      return " AND UPPER(SSC.name) LIKE UPPER(?)";
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}