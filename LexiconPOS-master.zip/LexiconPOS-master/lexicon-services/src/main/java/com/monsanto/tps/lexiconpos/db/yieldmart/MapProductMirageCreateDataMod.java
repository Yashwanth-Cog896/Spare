package com.monsanto.tps.lexiconpos.db.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tps.lexiconpos.db.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 29, 2006
 * Time: 9:40:45 AM
 * To change this template use File | Settings | File Templates.
 */
public class MapProductMirageCreateDataMod
   extends AbstractPersistentStoreInsert
{
   private final int mirageSeedProductID;
   private final long midasGeneticMaterialID;
   private final long midasProductID;
   private final String productName;

   public MapProductMirageCreateDataMod(
      int mirageSeedProductID, long midasGeneticMaterialID,
      long midasProductID, String productName)
   {
      this.mirageSeedProductID = mirageSeedProductID;
      this.midasGeneticMaterialID = midasGeneticMaterialID;
      this.midasProductID = midasProductID;
      this.productName = productName;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MapProductMirageWriterSQL.class);
      return propFile.getSQL(MapProductMirageWriterSQL.INSERT_MAP_PRODUCT_MIRAGE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { Integer.valueOf(mirageSeedProductID), Long.valueOf(midasGeneticMaterialID),
         Long.valueOf(midasProductID), productName
      };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new YieldMartConnectionFactoryProperties();
   }
}
