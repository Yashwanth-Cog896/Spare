package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;

/**
 * Filename:    StubBusinessAccountService.java
 * Last Change: rrchak1 On:	Aug 6, 2008
 *
 * @author: rrchak1
 */
public class StubBusinessAccountService
        implements IrdBusinessAccountService
{
    public Acct[] findByIds(long[] businessAccountIds) {
        return new Acct[]{
                new Acct(),
                new Acct()
        };
    }

    public Acct[] findBySearchCriteria(BusinessAccountSearchCriteria businessAccountSearchCriteria) {
        return new Acct[]{
                new Acct(),
                new Acct()
        };
    }
}
