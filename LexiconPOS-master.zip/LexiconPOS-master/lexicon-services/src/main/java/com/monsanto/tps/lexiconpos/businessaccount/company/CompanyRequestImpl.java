package com.monsanto.tps.lexiconpos.businessaccount.company;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 13, 2007
 * Time: 2:27:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyRequestImpl
   implements CompanyRequest
{
   private final String companyName;
   private final String accountType;

   public CompanyRequestImpl(String companyName, String accountType) {
      this.companyName = companyName;
      this.accountType = accountType;
   }

   public String getCompanyName() {
      return companyName;
   }
   public String getAccountType() {
      return accountType;
   }
}
