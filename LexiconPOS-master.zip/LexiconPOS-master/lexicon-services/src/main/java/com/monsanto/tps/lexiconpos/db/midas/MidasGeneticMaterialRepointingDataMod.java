package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreUpdate;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Sep 13, 2006
 * Time: 11:33:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGeneticMaterialRepointingDataMod
   extends AbstractPersistentStoreUpdate
{
   private final long geneticMaterialID;
   private final long germplasmID;

   public MidasGeneticMaterialRepointingDataMod(long geneticMaterialID, long germplasmID) {
      this.geneticMaterialID = geneticMaterialID;
      this.germplasmID = germplasmID;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MidasWriterSQL.class);
      return propFile.getSQL(MidasWriterSQL.REPOINT_GENETIC_MATERIAL);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(germplasmID), new Long(geneticMaterialID) };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
