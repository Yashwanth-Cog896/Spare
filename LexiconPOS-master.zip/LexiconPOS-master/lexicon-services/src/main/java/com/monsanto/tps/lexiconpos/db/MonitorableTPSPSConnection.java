package com.monsanto.tps.lexiconpos.db;

import com.monsanto.tcc.lexiconcommon.db.factories.PersistentStoreConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.monitor.MonitoredConnectionFactory;
import com.monsanto.tps.lexiconpos.db.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.db.factories.mirage.MirageConnectionFactoryProperties;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 20, 2007
 * Time: 10:32:22 AM
 */
public class MonitorableTPSPSConnection
   extends TPSPersistentStoreConnection
{
   protected PersistentStoreConnectionFactory getLexiconConnectionFactory() {
      return new MonitoredConnectionFactory(new LexiconConnectionFactoryProperties());
   }
   protected PersistentStoreConnectionFactory getMidasConnectionFactory() {
      return new MonitoredConnectionFactory(new MidasConnectionFactoryProperties());
   }
   protected PersistentStoreConnectionFactory getMirageConnectionFactory() {
      return new MonitoredConnectionFactory(new MirageConnectionFactoryProperties());
   }
   protected PersistentStoreConnectionFactory getBFCConnectionFactory() {
      return new MonitoredConnectionFactory(new BFCConnectionFactoryProperties());
   }
}
