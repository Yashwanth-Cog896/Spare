package com.monsanto.tps.lexiconpos.artemis.controller;

import com.monsanto.tcc.artemis.workflow.service.AbstractXmlServiceProcessController;
import com.monsanto.tcc.lexiconcommon.service.artemis.LexiconArtemisServiceXmlSerializerProvider;

/**
 * nbwald - Mar 6, 2008 4:30:38 PM
 */
public class LexiconArtemisController
   extends AbstractXmlServiceProcessController
{
   protected Class getXmlSerializerProviderClass() {
      return LexiconArtemisServiceXmlSerializerProvider.class;
   }

   protected String getTaskMetricsEnvironmentName() {
      return "Lexicon";
   }
}
