package com.monsanto.tps.lexiconpos.businessaccount.artemis.contract;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * nbwald - May 15, 2008 2:46:57 PM
 */
public class ExternalContactSearchCriteriaRequest
{
   private final ServiceProcessContext context;

   public ExternalContactSearchCriteriaRequest(ServiceProcessContext context) {
      this.context = context;
   }

   public ExternalContactSearchCriteria getSearchCriteria() {
      return (ExternalContactSearchCriteria) context.getRequestPayload();
   }
}
