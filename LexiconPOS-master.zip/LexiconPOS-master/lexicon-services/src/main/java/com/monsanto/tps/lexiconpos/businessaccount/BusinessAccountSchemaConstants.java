package com.monsanto.tps.lexiconpos.businessaccount;

import com.monsanto.tps.lexiconpos.businessaccount.ird.IRDServiceSchemaConstants;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 3:31:25 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BusinessAccountSchemaConstants
        extends IRDServiceSchemaConstants {
    String NAMESPACE = "http://www.monsanto.com/lexicon/BusinessAccount";
    String SCHEMA_SRC = "xsd/lexicon/BusinessAccount.xsd";

    String EXTERNAL_CONTACT_REQUEST_ELEM_NAME = "ExternalContactRequest";

    String EXTERNAL_CONTACT_ELEM_NAME = "ExternalContact";
    String ACCOUNT_ID_ELEM_NAME = "AccountId";
    String CONTACT_ID_ELEM_NAME = "ContactId";
    String LAST_NAME_ELEM_NAME = "LastName";
    String FIRST_NAME_ELEM_NAME = "FirstName";
    String MIDDLE_NAME_ELEM_NAME = "MiddleName";
    String COMPANY_ELEM_NAME = "Company";
    String COMPANY_NAME_ELEM_NAME = "CompanyName";
    String ADDRESSES_ELEM_NAME = "Addresses";
    String ADDRESS_ELEM_NAME = "Address";
    String ADDRESS_ID_ATTR_NAME = "AddressId";
    String ADDR_LINE_1_ELEM_NAME = "Address1";
    String ADDR_LINE_2_ELEM_NAME = "Address2";
    String ADDR_LINE_3_ELEM_NAME = "Address3";
    String CITY_ELEM_NAME = "City";
    String COUNTY_ELEM_NAME = "County";
    String STATE_ELEM_NAME = "State";
    String POSTAL_CODE_ELEM_NAME = "PostalCode";
    String COUNTRY_ELEM_NAME = "Country";
    String JOB_TITLE_ELEM_NAME = "JobTitle";
    String EMAIL_ELEM_NAME = "Email";
    String PHONE_NUMBER_ELEM_NAME = "PhoneNumber";
    String FAX_NUMBER_ELEM_NAME = "FaxNumber";
    String CELL_NUMBER_ELEM_NAME = "CellNumber";
    String PAGER_NUMBER_ELEM_NAME = "PagerNumber";

    String EXTERNAL_CONTACT_RESP_ELEM_NAME = "ExternalContactResponse";
    String EXTERNAL_CONTACTS_ELEM_NAME = "ExternalContacts";

    String ACCT_ID_ATTR_NAME = "ACCT_ID";
    String CONTACT_ID_ATTR_NAME = "CONTACT_ID";
    String LAST_NAME_ATTR_NAME = "LAST_NAME";
    String FIRST_NAME_ATTR_NAME = "FIRST_NAME";
    String MIDDLE_NAME_ATTR_NAME = "MIDDLE_NAME";
    String NAME_1_ATTR_NAME = "NAME_1";
    String ACCT_ADDRID_ATTR_NAME = "ACCT_ADDR_ID";
    String CONTACT_ADDRID_ATTR_NAME = "CONTACT_ADDR_ID";
    String ADDR_LINE_1_ATTR_NAME = "ADDR_LINE_1";
    String ADDR_LINE_2_ATTR_NAME = "ADDR_LINE_2";
    String ADDR_LINE_3_ATTR_NAME = "ADDR_LINE_3";
    String CITY_ATTR_NAME = "CITY";
    String STATE_CODE_ATTR_NAME = "STATE_CODE";
    String ZIP_ATTR_NAME = "ZIP_CODE";
    String ZIP4_ATTR_NAME = "ZIP_CODE_4";
    String COUNTY_ATTR_NAME = "COUNTY";
    String COUNTRY_ATTR_NAME = "COUNTRY";
    String PHONE_NUMBER_ATTR_NAME = "PHONE_NUMBER";
    String BUS_NUMBER_ATTR_NAME = "BUS_NUMBER";
    String JOB_TITLE_ATTR_NAME = "JOB_TITLE";
    String EMAIL_ATTR_NAME = "EMAIL";
    String FAX_NUMBER_ATTR_NAME = "FAX_NUMBER";
    String CELL_NUMBER_ATTR_NAME = "CELL_NUMBER";
    String PAGER_NUMBER_ATTR_NAME = "PAGER_NUMBER";

    String BUSINESS_ACCT_RESP_ELEM_NAME = "BusinessAccountResponse";
    String COMPANIES_ELEM_NAME = "Companies";
    String BUSINESS_ACCT_REQ_ELEM_NAME = "BusinessAccountRequest";
    String ACCOUNT_TYPE_ELEM_NAME = "AccountType";
    String CONTACT_TYPE_ELEM_NAME = "ContactType";
    String CONTACT_NAME1 = "name1AI";
    String CONTACT_NAME3 = "name3AI";
    String CONTACT_FUNCTIONS = "contactFunctions";
    String ACCT = "acct";
    String ACCT_ADDRS = "acctAddrs";
    String GEO = "geo";
    String COUNTRY_DESCR = "descr";
    String STATE_US_TERR_NAME = "stateUsTerrName";
    String STATE_CODE = "stateCode";
    String CITY = "city";
    String ZIPCODE = "zipCode";
    String FIPS = "fips";
    String COUNTY_DESCR = "countyDescr";
    String ACCT_NAME1 = "name1";
    String CONTACT_ID = "contactId";
    String CONTACT_ADDRS = "contactAddrs";
    long ACTIVE_ACCT_STATUS_CD = 1;
    String ACCT_ID = "acctId";
}
