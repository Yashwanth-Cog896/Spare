package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.tps.lexiconpos.businessaccount.company.Company;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 15, 2007
 * Time: 9:37:05 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IRDCompanyServiceResponse {
   Company[] getCompanies();

   boolean isErrorResponse();

   String getErrorMsg();
}
