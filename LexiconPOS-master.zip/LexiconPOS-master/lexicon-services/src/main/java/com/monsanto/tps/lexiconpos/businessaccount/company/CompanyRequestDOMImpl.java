package com.monsanto.tps.lexiconpos.businessaccount.company;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:47:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompanyRequestDOMImpl
   implements CompanyRequest
{
   private final Document doc;
   
   public CompanyRequestDOMImpl(Document doc) {
      this.doc = doc;
   }

   public String getCompanyName() {
      return DOMUtil.getChildValue(getRequestElement(), BusinessAccountSchemaConstants.COMPANY_ELEM_NAME);
   }

   public String getAccountType() {
      return DOMUtil.getChildValue(getRequestElement(), BusinessAccountSchemaConstants.ACCOUNT_TYPE_ELEM_NAME);
   }

   private Element getRequestElement() {
      return doc.getDocumentElement();
   }
}
