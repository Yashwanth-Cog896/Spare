package com.monsanto.tps.lexiconpos.db.factories.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 3, 2004
 * Time: 3:27:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class YieldMartConnectionFactory
   extends BasicConnectionFactory
{
   public YieldMartConnectionFactory() {
      super(new YieldMartConnectionFactoryProperties());
   }
}

