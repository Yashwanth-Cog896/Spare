package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.tps.lexiconpos.businessaccount.company.CompanyRequest;
import com.monsanto.tps.lexiconpos.util.service.IRDServiceInvoker;
import com.monsanto.Util.Exceptions.WrappingException;
import org.w3c.dom.Document;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 31, 2007
 * Time: 3:18:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class IRDCompanyService
{
   public IRDCompanyServiceResponseDOMImpl getServiceResult(CompanyRequest companyRequest)
      throws WrappingException
   {
      final Document requestDoc = renderRequest(companyRequest);
      Document responseDoc = invokeService(requestDoc);
      return parseResponse(responseDoc);
   }

   protected Document renderRequest(CompanyRequest request) {
      IRDCompanyServiceReqDocRenderer renderer = new IRDCompanyServiceReqDocRenderer(request);
      return renderer.renderRequest();
   }

   protected Document invokeService(final Document requestDoc) throws WrappingException {
      return new IRDServiceInvoker().call(requestDoc);
   }

   private IRDCompanyServiceResponseDOMImpl parseResponse(Document responseDoc) {
      return new IRDCompanyServiceResponseDOMImpl(responseDoc);
   }
}
