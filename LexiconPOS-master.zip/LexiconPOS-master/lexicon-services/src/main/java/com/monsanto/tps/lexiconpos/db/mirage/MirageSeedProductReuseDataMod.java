package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 28, 2006
 * Time: 3:48:20 PM
 */
public class MirageSeedProductReuseDataMod
{
   private final int seedProductID;
   private final int traitCharacteristicsID;
   private final String enabled;

   public MirageSeedProductReuseDataMod(
      int seedProductID, int traitCharacteristicsID, boolean enabled)
   {
      this.seedProductID = seedProductID;
      this.traitCharacteristicsID = traitCharacteristicsID;
      this.enabled = (enabled) ? "Y" : "N";
   }

   public int performUpdate(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return new MirageAuditedAction() {
         @Override
         protected int performAction(PersistentStoreStatement statement)
            throws WrappingException
         {
            return statement.executeUpdate();
         }

         @Override
         protected String getSQL()
            throws WrappingException
         {
            SQLPropFile propFile = new SQLPropFile(MirageSeedProductWriterSQL.class);
            return propFile.getSQL(MirageSeedProductWriterSQL.REUSE_PRODUCT);
         }

         @Override
         protected Object[] getBindVariables(int auditId) {
            return new Object[]{ getTraitCharacteristicCode(), enabled, enabled, auditId, seedProductID};
         }

         private String getTraitCharacteristicCode() {
            return traitCharacteristicsID == 0 ? "" : String.valueOf(traitCharacteristicsID);
         }

         @Override
         protected int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
            throws WrappingException
         {
            return mirageAuditor.auditUpdateSeedProduct(mirageConn);
         }
      }.execute(mirageConn);
   }
}
