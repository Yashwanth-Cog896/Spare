package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: May 19, 2006
 * Time: 2:44:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasGPLookup
{
   public Germplasm[] getProductGermplams(long productID, PersistentStoreConnection midasConn)
      throws WrappingException;

   public Germplasm getGermplasmByID(long germplasmID, PersistentStoreConnection midasConn)
      throws WrappingException;

   public Germplasm[] getGermplasmsByID(long[] germplasmID, PersistentStoreConnection midasConn)
      throws WrappingException;
}
