/*
 SlimGermplasmsByCropNameAndLexProdPubkeyQuery was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * nbwald Jan 29, 2007 2:54:44 PM
 */
public class SlimGermplasmsByCropNameAndProdPubkeyQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String productPubkey;
   private final String cropName;

   public SlimGermplasmsByCropNameAndProdPubkeyQuery(String productPubkey, String cropName) {
      this.productPubkey = productPubkey;
      this.cropName = cropName;
   }

   public SlimGermplasm[] getGermplasms()
      throws WrappingException
   {
      List germplasms = getList();
      return (SlimGermplasm[]) germplasms.toArray(new SlimGermplasm[germplasms.size()]);
   }

   public SlimGermplasm[] getGermplasms(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      List germplasms = getList(midasConn);
      return (SlimGermplasm[]) germplasms.toArray(new SlimGermplasm[germplasms.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new SlimGermplasmPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_SLIM_GPS_BY_CROP_AND_PROD_PUBKEY);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { productPubkey, cropName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

}