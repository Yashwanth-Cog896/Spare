package com.monsanto.tps.lexiconpos.db.audit.dao.lexicon;

import com.monsanto.tps.lexiconpos.db.audit.domain.lexicon.AuditStaging;

/**
 * rrchak1 - Aug 19, 2008 4:48:44 PM
 */
public interface AuditStagingDao
{
   AuditStaging create(String userLoginId, String processName, String auditComment, String auditRequestor);

   void delete(AuditStaging auditStagingObj);
}
