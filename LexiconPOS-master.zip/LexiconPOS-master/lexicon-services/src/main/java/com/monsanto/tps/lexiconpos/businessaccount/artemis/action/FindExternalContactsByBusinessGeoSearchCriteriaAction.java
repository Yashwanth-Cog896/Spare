package com.monsanto.tps.lexiconpos.businessaccount.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact.ContactCollection;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.contract.ExternalContactByBusinessGeographySearchCriteriaRequest;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service.IrdExternalContactService;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.validation.externalcontact.ExternalContactByBusinessGeographySearchCriteriaValidator;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;

/**
 * Filename:    FindExternalContactsByBusinessGeographySearchCriteriaAction.java
 * Last Change: rrchak1 On:	Jul 29, 2008
 *
 * @author: rrchak1
 */
public class FindExternalContactsByBusinessGeoSearchCriteriaAction
   extends AbstractArtemisServiceAction
{
   private IrdExternalContactService externalContactService;
   private ExternalContactByBusinessGeographySearchCriteriaValidator validator;

   public FindExternalContactsByBusinessGeoSearchCriteriaAction(IrdExternalContactService externalContactService, ExternalContactByBusinessGeographySearchCriteriaValidator validator) {
      this.externalContactService = externalContactService;
      this.validator = validator;
   }

   public void process(ServiceProcessContext context)
      throws Exception
   {
      ExternalContactByBusinessGeographySearchCriteriaRequest request = new ExternalContactByBusinessGeographySearchCriteriaRequest(context);
      ExternalContactByBusinessGeographySearchCriteria searchCriteria = request.getSearchCriteria();
      validator.validate(searchCriteria);
      Contact[] irdContacts = externalContactService.findByBusinessGeographySearchCriteria(searchCriteria);
      ContactCollection contactCollection = new ContactCollection(irdContacts);
      new MultipleResultResponse(contactCollection.getExternalContacts()).saveResponse(context);
   }

   public void setService(IrdExternalContactService externalContactService) {
      this.externalContactService = externalContactService;
   }

   public void setValidator(ExternalContactByBusinessGeographySearchCriteriaValidator validator) {
      this.validator = validator;
   }
}
