package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 10:58:57 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GeographySchemaConstants
{
    String NAMESPACE = "http://www.monsanto.com/lexicon/Geography";
    String SCHEMA_LOC = "xsd/lexicon/Geography.xsd";

    String GET_COUNTRY_REQUEST_ELEM_NAME = "CountryRequest";
    String COUNTRY_NAME_REQUEST_PARAM = "CountryName";
    String COUNTRY_ABBR_REQUEST_PARAM = "UNCode";
    String COUNTRY_PUBKEY_REQUEST_PARAM = "CountryPubkey";
    String SUB_COUNTRY_NAME_REQUEST_PARAM = "SubCountryName";
    String SUB_COUNTRY_ABBR_REQUEST_PARAM = "SubCountryAbbreviation";
    String SUB_COUNTRY_PUBKEY_REQUEST_PARAM = "SubCountryPubkey";
    String SUB_SUB_COUNTRY_NAME_REQUEST_PARAM = "SubSubCountryName";

    String GET_COUNTRY_RESPONSE_ELEM_NAME = "CountryResponse";
    String GET_SUB_COUNTRY_RESPONSE_ELEM_NAME = "SubCountryResponse";
    String GET_SUB_SUB_COUNTRY_RESPONSE_ELEM_NAME = "SubSubCountryResponse";
    String COUNTRY_ELEM_NAME = "Country";
    String SUBCOUNTRY_ELEM_NAME = "SubCountry";
    String SUBSUBCOUNTRY_ELEM_NAME = "SubSubCountry";
    String PUBKEY_ELEM_NAME = "PublicKey";
    String NAME_ELEM_NAME = "Name";
    String ABBR_ELEM_NAME = "Abbreviation";
    String UN_CODE_ELEM_NAME = "UNCode";
    String ISO_CODE_ELEM_NAME = "ISOCode";
    String UN_NUMERIC_CODE_ELEM_NAME = "UNNumericCode";
}
