package com.monsanto.tps.lexiconpos.event.deregulated.dao;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 11, 2006
 * Time: 10:01:57 AM
 * To change this template use File | Settings | File Templates.
 */
public interface RegulatoryStatusSQL
{
   String SELECT_DEREGULATED_STATUSES = "Status.SelectDeregulated";
}
