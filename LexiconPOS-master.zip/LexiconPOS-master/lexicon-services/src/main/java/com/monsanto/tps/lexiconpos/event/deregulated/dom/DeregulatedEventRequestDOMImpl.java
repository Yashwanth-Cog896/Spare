package com.monsanto.tps.lexiconpos.event.deregulated.dom;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tps.lexiconpos.event.deregulated.DeregulatedEventSchemaConstants;
import com.monsanto.tps.lexiconpos.event.deregulated.model.DeregulatedEventRequest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 19, 2006
 * Time: 2:17:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeregulatedEventRequestDOMImpl
   implements DeregulatedEventRequest, DeregulatedEventSchemaConstants
{
   private final Document doc;

   public DeregulatedEventRequestDOMImpl(Document doc) {
      this.doc = doc;
   }

   public String[] getEvents() {
      List events = new ArrayList();
      Node eventsNode = DOMUtil.getChild(getRequestElement(), EVENTS_ELEM_NAME);
      Node[] eventNodes = DOMUtil.getChildren(eventsNode, EVENT_ELEM_NAME);
      for (int i = 0; i < eventNodes.length; i++) {
         events.add(DOMUtil.getTextValue(eventNodes[i]));
      }
      return (String[]) events.toArray(new String[events.size()]);
   }

   public String getCountryPubkey() {
      return DOMUtil.getChildValue(getRequestElement(), COUNTRY_PUBKEY_ELEM_NAME);
   }

   public String getSubCountryPubkey() {
      return DOMUtil.getChildValue(getRequestElement(), SUB_COUNTRY_PUBKEY_ELEM_NAME);
   }

   private Element getRequestElement() {
      return doc.getDocumentElement();
   }
}
