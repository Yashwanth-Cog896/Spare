package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 2:51:25 PM
 */
public class AphisNumberDataRenderer
   implements AphisNumberSchemaConstants
{
   private final AphisNumberDatum[] aphisNumberData;

   public AphisNumberDataRenderer(AphisNumberDatum[] aphisNumberData) {
      this.aphisNumberData = aphisNumberData;
   }

   public void render(Element documentElement)
   {
      Element aphisNumberDataElement = DOMUtil.addChildElementWithNS(NAMESPACE, documentElement, APHIS_NUMBER_DATA_ELEM_NAME);
      for (int i = 0; i < aphisNumberData.length; i++) {
         renderAphisNumberDatum(aphisNumberDataElement, aphisNumberData[i]);
      }
   }

   private void renderAphisNumberDatum(Element aphisNumberDataElement, AphisNumberDatum datum)
   {
      Element element = DOMUtil.addChildElementWithNS(NAMESPACE, aphisNumberDataElement, APHIS_NUMBER_DATUM_ELEM_NAME);
      DOMUtil.addChildElementWithNS(NAMESPACE, element, PLASMID_PVCODE_ELEM_NAME, datum.getTransCode());
      renderNumbersAndDateRange(element, datum);
   }

   private void renderNumbersAndDateRange(Element element, AphisNumberDatum datum)
   {
      String[] aphisNumbers = datum.getAphisNumbers();
      for (int i = 0; i < aphisNumbers.length; i++) {
         Element numAndDateRangeElement = DOMUtil.addChildElementWithNS(NAMESPACE, element, NUMBER_AND_DATE_RANGE_ELEM_NAME);
         String aphisNumber = aphisNumbers[i];
         DOMUtil.addChildElementWithNS(NAMESPACE, numAndDateRangeElement, APHIS_NUMBER_ELEM_NAME, aphisNumber);
         DOMUtil.addChildElementWithNS(NAMESPACE, numAndDateRangeElement, EFFECTIVE_DATE_ELEM_NAME, datum.getEffectiveDate(aphisNumber));
         DOMUtil.addChildElementWithNS(NAMESPACE, numAndDateRangeElement, EXPIRATION_DATE_ELEM_NAME, datum.getExpirationDate(aphisNumber));
      }
   }
}
