package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 12:59:28 PM
 */
public class AphisNumberDatum {

    private final String transCode;
    private final Map numberAndDateRange;

    public AphisNumberDatum(String transCode) {
        this.transCode = transCode;
        this.numberAndDateRange = new LinkedHashMap();
    }

    public String getTransCode() {
        return transCode;
    }

    public void addAphisNumber(String aphisNumber, String effectiveDate, String expirationDate) {
        String[] dateRange = {effectiveDate, expirationDate};
        numberAndDateRange.put(aphisNumber, dateRange);
    }

    public String[] getAphisNumbers() {
        Collection aphisNumbers = numberAndDateRange.keySet();
        return (String[]) aphisNumbers.toArray(new String[aphisNumbers.size()]);
    }

    public String getEffectiveDate(String aphisNumber) {
        String[] dateRange = (String[]) numberAndDateRange.get(aphisNumber);
        return dateRange[0];
    }

    public String getExpirationDate(String aphisNumber) {
        String[] dateRange = (String[]) numberAndDateRange.get(aphisNumber);
        return dateRange[1];
    }
}
