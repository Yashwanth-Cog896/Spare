package com.monsanto.tps.lexiconpos.businessaccount.ird;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.businessaccount.externalcontact.ExternalContactRequest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 23, 2007
 * Time: 9:34:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class IRDExternalContactServiceReqDocRenderer
{
   private final ExternalContactRequest request;

   private static final String REGULATORY_ATTR_VAL = "REGULATORY";
   private static final String CLIENTID_ATTR_VAL = "CLIENTID";
   private static final String LAST_NAME_ATTR_VAL = "LAST_NAME";
   private static final String FIRST_NAME_ATTR_VAL = "FIRST_NAME";
   private static final String COMPANY_NAME_ATTR_VAL = "NAME_1";
   private static final String CONTACT_TYPE_ATTR_VAL = "FUNCTION_TYPE_CODE";

   public IRDExternalContactServiceReqDocRenderer(ExternalContactRequest request)
   {
      this.request = request;
   }

   public Document renderRequest()
   {
      Document doc = DOMUtil.newDocument();
      Element root = DOMUtil.addChildElement(doc, BusinessAccountSchemaConstants.IRDSERVICE_REQ_ELEM_NAME);
      Element requestElem = addRequestElement(root);
      addContactTypeElement(requestElem);
      addLastNameElement(requestElem);
      addFirstNameElement(requestElem);
      addCompanyElement(requestElem);
      return doc;
   }

   private Element addRequestElement(Element root) {
      Element requestElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.REQUEST_ELEM_NAME);
      addKeyAttr(requestElem);
      addIDAttr(requestElem);
      return requestElem;
   }

   private void addKeyAttr(Element requestElem) {
      requestElem.setAttribute(BusinessAccountSchemaConstants.KEY_ATTR_NAME, REGULATORY_ATTR_VAL);
   }

   private void addIDAttr(Element requestElem) {
      requestElem.setAttribute(BusinessAccountSchemaConstants.ID_ATTR_NAME, CLIENTID_ATTR_VAL);
   }

   private void addContactTypeElement(Element root) {
      Element fieldElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.FIELD_ELEM_NAME, request.getContactType());
      fieldElem.setAttribute(BusinessAccountSchemaConstants.NAME_ATTR_NAME, CONTACT_TYPE_ATTR_VAL);
   }

   private void addLastNameElement(Element root) {
      String lastName = StringUtils.isNullOrEmpty(request.getLastName()) ? "%" : replaceWCWithIRDWC(request.getLastName());
      Element fieldElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.FIELD_ELEM_NAME, lastName);
      fieldElem.setAttribute(BusinessAccountSchemaConstants.NAME_ATTR_NAME, LAST_NAME_ATTR_VAL);
   }

   private void addFirstNameElement(Element root) {
      String firstName = StringUtils.isNullOrEmpty(request.getFirstName()) ? "%" : replaceWCWithIRDWC(request.getFirstName());
      Element fieldElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.FIELD_ELEM_NAME, firstName);
      fieldElem.setAttribute(BusinessAccountSchemaConstants.NAME_ATTR_NAME, FIRST_NAME_ATTR_VAL);
   }

   private void addCompanyElement(Element root) {
      String company = StringUtils.isNullOrEmpty(request.getCompany()) ? "%" : replaceWCWithIRDWC(request.getCompany());
      Element fieldElem = DOMUtil.addChildElement(root, BusinessAccountSchemaConstants.FIELD_ELEM_NAME, company);
      fieldElem.setAttribute(BusinessAccountSchemaConstants.NAME_ATTR_NAME, COMPANY_NAME_ATTR_VAL);
   }

   private String replaceWCWithIRDWC(String value) {
      StdWildcardableCriteria criteria = new StdWildcardableCriteria(value);
      return criteria.oracleVersion();
   }
}
