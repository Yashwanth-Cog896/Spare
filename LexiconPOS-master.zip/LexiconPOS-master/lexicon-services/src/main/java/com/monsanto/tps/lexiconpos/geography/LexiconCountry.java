package com.monsanto.tps.lexiconpos.geography;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 4:53:45 PM
 */
public interface LexiconCountry
   extends GeographicEntity
{
   long getLexiconID();
   String getPublicKey();
   String getName();
   String getUNCodeStr();
   String getISOCode();
   int getUNCode();
   String getSubCountryDescription();
   String getSubSubCountryDescription();
}
