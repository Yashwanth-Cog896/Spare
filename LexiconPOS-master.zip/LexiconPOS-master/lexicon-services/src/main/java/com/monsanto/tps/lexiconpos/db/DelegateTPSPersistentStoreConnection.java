package com.monsanto.tps.lexiconpos.db;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;

/**
* rlcasw - Nov 23, 2010 3:38:41 PM
*/
public class DelegateTPSPersistentStoreConnection
   extends TPSPersistentStoreConnection
{
   private final TPSPersistentStoreConnection inDelagatedConnection;

   public DelegateTPSPersistentStoreConnection(TPSPersistentStoreConnection inDelagatedConnection) {
      this.inDelagatedConnection = inDelagatedConnection;
   }

   public TPSPersistentStoreConnection getDelegateConnection(){
      return inDelagatedConnection;
   }
   @Override
   public PersistentStoreConnection getBFCConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getBFCConnection();
   }

   @Override
   public PersistentStoreConnection getFBSCommonConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getFBSCommonConnection();
   }

   @Override
   public PersistentStoreConnection getMidasConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getMidasConnection();
   }

   @Override
   public PersistentStoreConnection getMirageConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getMirageConnection();
   }

   @Override
   public PersistentStoreConnection getVirgoConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getVirgoConnection();
   }

   @Override
   public PersistentStoreConnection getYieldMartConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getYieldMartConnection();
   }

   @Override
   public void close() {
      // Don't close since this is a delegate
      inDelagatedConnection.close();
   }

   @Override
   public PersistentStoreConnection getLexiconConnection()
      throws WrappingException
   {
      return inDelagatedConnection.getLexiconConnection();
   }

   @Override
   public void setLexiconAuditor(LexiconAuditor lexiconAuditor)
      throws WrappingException
   {
      inDelagatedConnection.setLexiconAuditor(lexiconAuditor);
   }

   @Override
   public void beginTransaction()
      throws WrappingException
   {
      inDelagatedConnection.beginTransaction();
   }

   @Override
   public void endTransaction()
      throws WrappingException
   {
      inDelagatedConnection.endTransaction();
   }

   @Override
   public PersistentStoreConnection getConnection(Object key)
      throws WrappingException
   {
      return inDelagatedConnection.getConnection(key);
   }

   @Override
   public void rollbackTransaction() {
      inDelagatedConnection.rollbackTransaction();
   }

   @Override
   public int hashCode() {
      return inDelagatedConnection.hashCode();
   }

   @Override
   public String toString() {
      return inDelagatedConnection.toString();
   }

   @Override
   public boolean equals(Object obj) {
      return inDelagatedConnection.equals(obj);
   }
}
