package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.chemical.domain.mirage.MirageChemProd;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 11:30:18 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageChemProdLookup
{
    public MirageChemProd[] getCommercialProdcts(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException;
    
    public MirageChemProd[] getFormulations(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException;
    
    public MirageChemProd[] getActiveIngredients(
        String wildcardedName,
        PersistentStoreConnection mirageConn)
        throws WrappingException;

    public String[] getActiveIngredientNames(
        MirageChemProd product,
        PersistentStoreConnection mirageConn)
        throws WrappingException;
}
