package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.tps.lexiconpos.geography.GeographicEntity;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 4:54:45 PM
 * To change this template use File | Settings | File Templates.
 */
public interface GeographicEntityRenderer
{
    public void render(
        Element element,
        GeographicEntity entity);
}
