package com.monsanto.tps.lexiconpos.geography;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 6:41:09 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SubCountry
   extends GeographicEntity
{
   long getID();
   String getName();
   String getAbbr();
   LexiconCountry getCountry();
   void setCountry(LexiconCountry country);
}
