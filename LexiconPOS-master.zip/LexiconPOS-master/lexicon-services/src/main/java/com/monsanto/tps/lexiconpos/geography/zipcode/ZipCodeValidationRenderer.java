package com.monsanto.tps.lexiconpos.geography.zipcode;

import org.w3c.dom.Element;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 11:39:57 AM
 */
public class ZipCodeValidationRenderer
	implements ZipCodeValidationSchemaConstants
{
	private final String zipCode;

	public ZipCodeValidationRenderer(String zipCode) {
		this.zipCode = zipCode;
	}

	public void render(Element documentElement) {
		DOMUtil.addChildElementWithNS(NAMESPACE, documentElement, VALIDATED_ZIP_CODE_ELEM_NAME, getZipCode());
	}

	private String getZipCode() {
		return zipCode;
	}
}
