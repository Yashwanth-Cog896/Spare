package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos.AphisNumberDatum;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 1:38:12 PM
 */
public class BFCAphisNumberLookupDBImpl implements BFCAphisNumberLookup, BFCAphisNumberLookupSQL {

    private final SQLPropFile sqlPropFile = new SQLPropFile(BFCAphisNumberLookupSQL.class);

    public AphisNumberDatum[] getAphisNumberData(
            String transCode,
            PersistentStoreConnection bfcConn)
            throws WrappingException {
        String sql = sqlPropFile.getSQL(SELECT_APHIS_NUM_DATA_BY_TRANSCODE);
        PersistentStoreStatement stmt = bfcConn.prepareStatement(sql);
        try {
            stmt.setParam(1, transCode);
            PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
            return buildAphisNumberData(iter);
        }
        finally {
            stmt.close();
        }
    }

    private AphisNumberDatum[] buildAphisNumberData(
            PersistentStoreResultSetFwdIterator iter)
            throws WrappingException {
        ArrayList aphisNumberData = new ArrayList();
        String lastTransCode = null;
        AphisNumberDatum datum = null;
        while (iter.next()) {
            String currentTransCode = iter.getString(ALIAS_TRANSCODE);
            if (!currentTransCode.equals(lastTransCode)) {
                datum = new AphisNumberDatum(currentTransCode);
                aphisNumberData.add(datum);
            }
            datum.addAphisNumber(iter.getString(ALIAS_APHIS_NUM), iter.getString(ALIAS_EFF_DATE), iter.getString(ALIAS_EXPR_DATE));
            lastTransCode = currentTransCode;
        }

        return (AphisNumberDatum[]) aphisNumberData.toArray(new AphisNumberDatum[aphisNumberData.size()]);
    }
}
