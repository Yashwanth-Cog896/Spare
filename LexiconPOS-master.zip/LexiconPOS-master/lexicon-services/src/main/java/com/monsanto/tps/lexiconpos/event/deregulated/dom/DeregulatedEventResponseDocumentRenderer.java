package com.monsanto.tps.lexiconpos.event.deregulated.dom;

import com.monsanto.tps.lexiconpos.event.deregulated.DeregulatedEventSchemaConstants;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 19, 2006
 * Time: 3:52:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeregulatedEventResponseDocumentRenderer
   implements DeregulatedEventSchemaConstants
{
   private final boolean isDeregulated;

   public DeregulatedEventResponseDocumentRenderer(boolean isDeregulated) {
      this.isDeregulated = isDeregulated;
   }

   public Document renderDocument() {
      Document doc = DOMUtil.newDocument();
      Element root = createRootElement(doc);
      renderDeregulatedElement(root);
      return doc;
   }

   private Element createRootElement(Document doc) {
      Element root = DOMUtil.addChildElementWithNS(NAMESPACE, doc, DEREG_EVENT_RESP_ELEM_NAME);
      root.setAttribute("xmlns", NAMESPACE);
      root.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
      return root;
   }

   private void renderDeregulatedElement(Element parent) {
      DOMUtil.addChildElementWithNS(NAMESPACE, parent, DEREGULATED_ELEM_NAME, isDeregulated);
   }
}
