package com.monsanto.tps.lexiconpos.event.bfc.aphisnumber.service.pos;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 12:48:42 PM
 */
public interface AphisNumberSchemaConstants {

    /* We are actually dealing with transformation codes, but the current (and only) 
     * consumer of the service did not want to change their documentation
     * to have transformation code instead of plasmid pv code.  The schema and docs
     * will continue to have plasmid pv code for now.
     */

    String NAMESPACE = "http://www.monsanto.com/lexicon/AphisNumber";
    String SCHEMA_LOC = "xsd/lexicon/AphisNumber.xsd";

    String REQUESTED_TRANSCODE = "RequestedPlasmid_PVCode";

    String RESPONSE_ELEM_NAME = "Response";
    String APHIS_NUMBER_DATA_ELEM_NAME = "AphisNumberData";
    String APHIS_NUMBER_DATUM_ELEM_NAME = "AphisNumberDatum";
    String PLASMID_PVCODE_ELEM_NAME = "Plasmid_PVCode";
    String NUMBER_AND_DATE_RANGE_ELEM_NAME = "NumberAndDateRange";
    String APHIS_NUMBER_ELEM_NAME = "AphisNumber";
    String EFFECTIVE_DATE_ELEM_NAME = "EffectiveDate";
    String EXPIRATION_DATE_ELEM_NAME = "ExpirationDate";

}
