package com.monsanto.tps.lexiconpos.event.bfc.site;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.permit.site.model.BFCSiteSearchRequest;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 24, 2006
 * Time: 4:27:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class SiteSearchQueryBuilder
{
   private final SiteSearchSQLBuilder sqlBuilder;
   private final SiteSearchParamBuilder paramBuilder;

   public SiteSearchQueryBuilder(BFCSiteSearchRequest siteSearchRequest)
      throws WrappingException
   {
      sqlBuilder = new SiteSearchSQLBuilder(siteSearchRequest);
      paramBuilder = new SiteSearchParamBuilder(siteSearchRequest);
   }

   public String getSQL() throws WrappingException {
      return sqlBuilder.buildSql();
   }

   public Object[] getBindVariables()
      throws WrappingException
   {
      return paramBuilder.getParams();
   }
}




