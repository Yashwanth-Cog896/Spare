package com.monsanto.tps.lexiconpos.event.deregulated.util;

import com.monsanto.tcc.lexiconcommon.string.Permutation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 20, 2006
 * Time: 2:45:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class StackAbbrBuilder
{
   public String[] getStackAbbrs(String[] comlTraits)
   {
      List stackAbbrs = new ArrayList();
      Permutation permutation = new Permutation();
      List permutations = permutation.getPermutations(comlTraits);

      for (Iterator iter = permutations.iterator(); iter.hasNext();)
      {
         List traitList = (List) iter.next();
         String stackAbbr = buildStackAbbr(traitList);
         stackAbbrs.add(stackAbbr);
      }
      return (String[]) stackAbbrs.toArray(new String[stackAbbrs.size()]);
   }

   private String buildStackAbbr(List traitList)
   {
      StringBuffer stackAbbr = new StringBuffer();
      for (Iterator iter = traitList.iterator(); iter.hasNext();) {
         stackAbbr.append(iter.next());
         stackAbbr.append("/");
      }
      return stackAbbr.toString().substring(0, stackAbbr.length() -1);
   }
}
