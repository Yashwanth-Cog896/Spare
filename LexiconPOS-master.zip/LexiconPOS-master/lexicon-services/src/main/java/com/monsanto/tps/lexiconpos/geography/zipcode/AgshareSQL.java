package com.monsanto.tps.lexiconpos.geography.zipcode;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 9:44:06 AM
 */
public interface AgshareSQL {
    
	public String SELECT_ZIP_CODE_BY_ZIP_CODE = "ZipCode.SelectByZip";
	public String ALIAS_ZIP_CODE = "ZipCode";
}
