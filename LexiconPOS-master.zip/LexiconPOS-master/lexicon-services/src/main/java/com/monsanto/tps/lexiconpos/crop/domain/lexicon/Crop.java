package com.monsanto.tps.lexiconpos.crop.domain.lexicon;

import com.monsanto.tps.lexiconpos.product.monsanto.domain.lexicon.BaseProduct;
import com.monsanto.tps.lexiconpos.product.monsanto.domain.lexicon.PreComlProduct;

import java.util.Collection;

/**
 * rrchak1 - Aug 19, 2008 2:42:09 PM
 */
public class Crop
{
   private long cropId;

   public long getCropId() {
      return cropId;
   }

   public void setCropId(long cropId) {
      this.cropId = cropId;
   }

   private String cropName;

   public String getCropName() {
      return cropName;
   }

   public void setCropName(String cropName) {
      this.cropName = cropName;
   }

   private String majorCrop;

   public String getMajorCrop() {
      return majorCrop;
   }

   public void setMajorCrop(String majorCrop) {
      this.majorCrop = majorCrop;
   }

   private String cropPubkey;

   public String getCropPubkey() {
      return cropPubkey;
   }

   public void setCropPubkey(String cropPubkey) {
      this.cropPubkey = cropPubkey;
   }

   private String regulatoryCrop;

   public String getRegulatoryCrop() {
      return regulatoryCrop;
   }

   public void setRegulatoryCrop(String regulatoryCrop) {
      this.regulatoryCrop = regulatoryCrop;
   }

   private String complianceShippingStatement;

   public String getComplianceShippingStatement() {
      return complianceShippingStatement;
   }

   public void setComplianceShippingStatement(String complianceShippingStatement) {
      this.complianceShippingStatement = complianceShippingStatement;
   }

   private String abbreviation;

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

   private Collection<BaseProduct> baseProducts;

   public Collection<BaseProduct> getBaseProducts() {
      return baseProducts;
   }

   public void setBaseProducts(Collection<BaseProduct> baseProducts) {
      this.baseProducts = baseProducts;
   }

   private Collection<PreComlProduct> preComlProducts;

   public Collection<PreComlProduct> getPreComlProducts() {
      return preComlProducts;
   }

   public void setPreComlProducts(Collection<PreComlProduct> preComlProducts) {
      this.preComlProducts = preComlProducts;
   }

   private StageCategory stageCategory;

   public StageCategory getStageCategory() {
      return stageCategory;
   }

   public void setStageCategory(StageCategory stageCategory) {
      this.stageCategory = stageCategory;
   }

   private String transgenic;

   public String getTransgenic() {
      return transgenic;
   }

   public void setTransgenic(String transgenic) {
      this.transgenic = transgenic;
   }
}
