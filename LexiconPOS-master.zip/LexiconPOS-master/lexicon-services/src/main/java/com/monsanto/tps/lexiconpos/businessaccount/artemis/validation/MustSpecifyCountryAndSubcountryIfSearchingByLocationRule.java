package com.monsanto.tps.lexiconpos.businessaccount.artemis.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.PreconditionedRule;
import com.monsanto.tps.lexicon.contact.SearchableLocation;

/**
 * nbwald - Jun 4, 2008 4:47:03 PM
 */
public class MustSpecifyCountryAndSubcountryIfSearchingByLocationRule
   extends PreconditionedRule<String>
{
   private final SearchableLocation searchableLocation;

   public MustSpecifyCountryAndSubcountryIfSearchingByLocationRule(SearchableLocation searchableLocation) {
      this.searchableLocation = searchableLocation;
   }

   public boolean preconditionsMet() {
      return someLocationCriteriaSpecified();
   }

   private boolean someLocationCriteriaSpecified() {
      return searchableLocation.getCountryName() != null
         || searchableLocation.getSubcountryCode() != null
         || searchableLocation.getSubsubcountryName() != null
         || searchableLocation.getCity() != null;
   }

   public boolean postconditionViolated() {
      return searchableLocation.getCountryName() == null || searchableLocation.getSubcountryCode() == null;
   }

   public String getViolation() {
      return "Must specify country and subcountry if searching by location criteria.";
   }
}
