package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexiconpos.product.common.domain.mirage.MirageProduct;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Dec 5, 2005
 * Time: 10:51:13 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageSeedProdLookup
{
    public MirageProduct getSeedProduct(
        String productName,
        String bayerCode,
        int companyID,
        String countryCode,
        PersistentStoreConnection mirageConn)
        throws WrappingException;

    public MirageProduct getSeedProduct(
        int seedProductID,
        PersistentStoreConnection mirageConn)
        throws WrappingException;
}
