package com.monsanto.tps.lexiconpos.germplasm.dom;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Apr 21, 2005
 * Time: 5:17:23 PM
 * To change this template use File | Settings | File Templates.
 */
public interface GermplasmQueryDocTags
   extends GermplasmDocTags
{
   String SINGLE_QUERY_ELEM_NAME = "germplasmSingleQuery"; 
   String QUERY_ELEM_NAME = "germplasmQuery";
   String QUERY_ITEM_ELEM_NAME = "queryItem";
   String ITEM_ID_ATTR_NAME = "itemID";

   String QUERY_RESULTS_ELEM_NAME = "queryResults";
   String QUERY_ITEM_RESULT_ELEM_NAME = "queryItemResult";

}
