package com.monsanto.tps.lexiconpos.db.mirage;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 28, 2006
 * Time: 10:29:27 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageSeedProductWriterSQL {
   String INSERT_PRODUCT = "SeedProd.Insert";
   String REUSE_PRODUCT = "SeedProd.Reuse";
   String UPDATE_PRODUCT = "SeedProd.Update";
   String DISABLE_PRODUCT = "SeedProd.Disable";
   String INSERT_MATURITY = "SeedProdMat.Insert";
   String DELETE_MATRUITY = "SeedProdMat.Delete";
   String UPDATE_PRECOMLS = "SeedProd.UpdatePreComls";
}
