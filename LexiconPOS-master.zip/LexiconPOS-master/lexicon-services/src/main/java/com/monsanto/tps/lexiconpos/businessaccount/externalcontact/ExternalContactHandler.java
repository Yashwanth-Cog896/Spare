package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.company.Company;
import com.monsanto.tps.lexiconpos.businessaccount.company.CompanyRequest;
import com.monsanto.tps.lexiconpos.businessaccount.ird.IRDCompanyService;
import com.monsanto.tps.lexiconpos.businessaccount.ird.IRDExternalContactService;
import com.monsanto.tps.lexiconpos.businessaccount.ird.IRDExternalContactServiceResponse;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 12, 2007
 * Time: 4:12:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExternalContactHandler
{
   private final ExternalContactRequest request;

   public ExternalContactHandler(ExternalContactRequest request) {
      this.request = request;
   }

   public ExternalContact[] getExternalContacts()
      throws WrappingException
   {
      ExternalContact[] externalContacts = getExternalContacts(request);
      CompanyRequest[] companyRequests = getCompanyRequests(externalContacts, request.getContactType());
      Company[] companies = getCompanies(companyRequests);
      return getUpdatedExternalContacts(externalContacts, companies);
   }

   private ExternalContact[] getExternalContacts(ExternalContactRequest request)
      throws WrappingException
   {
      IRDExternalContactService service = new IRDExternalContactService();
      IRDExternalContactServiceResponse response = service.getServiceResult(request);
      if (response.isErrorResponse()) {
         throw new WrappingException(new Exception(response.getErrorMsg()));
      }
      else {
         return response.getExternalContacts();
      }
   }

   private CompanyRequest[] getCompanyRequests(ExternalContact[] externalContacts, String contactType) {
      CompanyRequestBuilder process = new CompanyRequestBuilder();
      return process.getUniqueCompanyRequests(externalContacts, contactType);
   }

   private Company[] getCompanies(CompanyRequest[] companyRequests)
      throws WrappingException
   {
      ArrayList<Company> masterList = new ArrayList<Company>();
      for (CompanyRequest companyRequest : companyRequests) {
         IRDCompanyService service = new IRDCompanyService();
         Company[] companies = service.getServiceResult(companyRequest).getCompanies();
         addCompaniesToList(masterList, companies);
      }
      return masterList.toArray(new Company[masterList.size()]);
   }

   private void addCompaniesToList(List<Company> masterList, Company[] companies) {
      for (Company company : companies) {
         masterList.add(company);
      }
   }

   private ExternalContact[] getUpdatedExternalContacts(ExternalContact[] externalContacts, Company[] companies) {
      ExternalContactAddressConsolidator process = new ExternalContactAddressConsolidator(externalContacts, companies);
      return process.getContactsWithConsolidatedAddresses();
   }
}
