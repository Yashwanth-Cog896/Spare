package com.monsanto.tps.lexiconpos.businessaccount.dao.ird;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexiconpos.businessaccount.BusinessAccountSchemaConstants;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.AddressCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.BusinessAccountCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.BusinessAccountIdCriteriaImpl;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.BusinessAccountStatusCriteriaImpl;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.ContactFunctionCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.CountryCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.ExternalContactCriteriaBuilder;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.ExternalContactIdCriteriaImpl;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria.FipsCriteriaBuilder;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;

import java.util.List;

/**
 * Filename:    IrdExternLContactDaoImpl.java
 * Last Change: rrchak1 On:	Jul 23, 2008
 *
 * @author: rrchak1
 */
public class IrdExternalContactDaoImpl
   implements IrdExternalContactDao
{
   private Class<Contact> persistentClass = Contact.class;
   private ExternalContactCriteriaBuilder externalContactCriteriaBuilder;
   private BusinessAccountCriteriaBuilder businessAccountCriteriaBuilder;
   private ContactFunctionCriteriaBuilder contactFunctionCriteriaBuilder;
   private CountryCriteriaBuilder countryCriteriaBuilder;
   private AddressCriteriaBuilder addressCriteriaBuilder;
   private FipsCriteriaBuilder fipsCriteriaBuilder;
   private SessionFactory sessionFactory;

   public Contact[] findByBusinessGeographySearchCriteria(ExternalContactByBusinessGeographySearchCriteria externalContactByBusinessGeographySearchCriteria) {
      Session session = sessionFactory.getCurrentSession();
      Criteria contactCriteria = session.createCriteria(persistentClass);
      contactCriteria.setProjection(Projections.distinct(Property.forName(BusinessAccountSchemaConstants.CONTACT_ID)));
      if (externalContactByBusinessGeographySearchCriteria.getExternalContactSearchCriteria().getMaxResults() != 0) {
         contactCriteria.setMaxResults(externalContactByBusinessGeographySearchCriteria.getExternalContactSearchCriteria().getMaxResults());
      }
      addCriteria(externalContactByBusinessGeographySearchCriteria, contactCriteria);
      List<Long> list = contactCriteria.list();
      return findByIds(ArrayUtils.toPrimitive(list.toArray(new Long[list.size()])));
   }

   public Contact[] findByIds(long[] contactIds) {
      if (ArrayUtils.isEmpty(contactIds)) {
         return new Contact[0];
      }
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(persistentClass);
      criteria.add(new ExternalContactIdCriteriaImpl(contactIds).getCriterion());
      Criteria businessAccountCriteria = criteria.createCriteria(BusinessAccountSchemaConstants.ACCT);
      businessAccountCriteria.add(new BusinessAccountStatusCriteriaImpl().getCriterion());
      List<Contact> contacts = criteria.list();
      return contacts.toArray(new Contact[contacts.size()]);
   }

   public Contact[] findByBusinessAcctIds(long[] accountIds) {
      if (ArrayUtils.isEmpty(accountIds)) {
         return new Contact[0];
      }
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(persistentClass);
      Criteria businessAccountCriteria = criteria.createCriteria(BusinessAccountSchemaConstants.ACCT);
      businessAccountCriteria.add(new BusinessAccountIdCriteriaImpl(accountIds).getCriterion());
      businessAccountCriteria.add(new BusinessAccountStatusCriteriaImpl().getCriterion());
      List<Contact> contacts = criteria.list();
      return contacts.toArray(new Contact[contacts.size()]);
   }

   public Contact[] findBySearchCriteria(ExternalContactSearchCriteria externalContactSearchCriteria) {
      Session session = sessionFactory.getCurrentSession();
      Criteria contactCriteria = session.createCriteria(persistentClass);
      contactCriteria.setProjection(Projections.distinct(Property.forName(BusinessAccountSchemaConstants.CONTACT_ID)));
      if (externalContactSearchCriteria.getMaxResults() != 0) {
         contactCriteria.setMaxResults(externalContactSearchCriteria.getMaxResults());
      }
      addCriteria(externalContactSearchCriteria, contactCriteria);
      List<Long> list = contactCriteria.list();
      return findByIds(ArrayUtils.toPrimitive(list.toArray(new Long[list.size()])));
   }

   private void addCriteria(ExternalContactSearchCriteria externalContactSearchCriteria, Criteria contactCriteria) {

      externalContactCriteriaBuilder.addCriteria(contactCriteria, externalContactSearchCriteria);

      Criteria contactFunctionCriteria = contactCriteria.createCriteria(BusinessAccountSchemaConstants.CONTACT_FUNCTIONS);
      contactFunctionCriteriaBuilder.addCriteria(contactFunctionCriteria, externalContactSearchCriteria.getContactType());

      Criteria accountCriteria = contactCriteria.createCriteria(BusinessAccountSchemaConstants.ACCT);
      BusinessAccountSearchCriteria businessAccountSearchCriteria = new BusinessAccountSearchCriteria();
      businessAccountSearchCriteria.setCompanyName(externalContactSearchCriteria.getCompanyName());
      businessAccountCriteriaBuilder.addCriteria(accountCriteria, businessAccountSearchCriteria);

      SearchableLocation searchableLocation = externalContactSearchCriteria.getLocation();
      if (null != searchableLocation) {
         Criteria contactAddressCriteria = contactCriteria.createCriteria(BusinessAccountSchemaConstants.CONTACT_ADDRS);
         Criteria geoCriteria = contactAddressCriteria.createCriteria(BusinessAccountSchemaConstants.GEO);
         Criteria zipCodeCriteria = contactAddressCriteria.createCriteria(BusinessAccountSchemaConstants.ZIPCODE);
         Criteria fipsCriteria = zipCodeCriteria.createCriteria(BusinessAccountSchemaConstants.FIPS);

         countryCriteriaBuilder.addCriteria(geoCriteria, searchableLocation);
         addressCriteriaBuilder.addCriteria(contactAddressCriteria, searchableLocation);
         fipsCriteriaBuilder.addCriteria(fipsCriteria, searchableLocation);
      }
   }

   private void addCriteria(ExternalContactByBusinessGeographySearchCriteria externalContactByBusinessGeographySearchCriteria, Criteria contactCriteria) {

      ExternalContactSearchCriteria externalContactSearchCriteria = externalContactByBusinessGeographySearchCriteria.getExternalContactSearchCriteria();
      SearchableLocation searchableLocation = externalContactSearchCriteria.getLocation();

      externalContactCriteriaBuilder.addCriteria(contactCriteria, externalContactSearchCriteria);

      Criteria contactFunctionCriteria = contactCriteria.createCriteria(BusinessAccountSchemaConstants.CONTACT_FUNCTIONS);
      contactFunctionCriteriaBuilder.addCriteria(contactFunctionCriteria, externalContactSearchCriteria.getContactType());

      Criteria accountCriteria = contactCriteria.createCriteria(BusinessAccountSchemaConstants.ACCT);
      BusinessAccountSearchCriteria businessAccountSearchCriteria = new BusinessAccountSearchCriteria();
      businessAccountSearchCriteria.setCompanyName(externalContactSearchCriteria.getCompanyName());
      businessAccountCriteriaBuilder.addCriteria(accountCriteria, businessAccountSearchCriteria);

      if (null != searchableLocation) {
         Criteria accountAddressCriteria = accountCriteria.createCriteria(BusinessAccountSchemaConstants.ACCT_ADDRS);
         Criteria geoCriteria = accountAddressCriteria.createCriteria(BusinessAccountSchemaConstants.GEO);
         Criteria zipCodeCriteria = accountAddressCriteria.createCriteria(BusinessAccountSchemaConstants.ZIPCODE);
         Criteria fipsCriteria = zipCodeCriteria.createCriteria(BusinessAccountSchemaConstants.FIPS);

         countryCriteriaBuilder.addCriteria(geoCriteria, searchableLocation);
         addressCriteriaBuilder.addCriteria(accountAddressCriteria, searchableLocation);
         fipsCriteriaBuilder.addCriteria(fipsCriteria, searchableLocation);
      }
   }

   public void setExternalContactCriteriaBuilder(ExternalContactCriteriaBuilder externalContactCriteriaBuilder) {
      this.externalContactCriteriaBuilder = externalContactCriteriaBuilder;
   }

   public void setBusinessAccountCriteriaBuilder(BusinessAccountCriteriaBuilder businessAccountCriteriaBuilder) {
      this.businessAccountCriteriaBuilder = businessAccountCriteriaBuilder;
   }

   public void setContactFunctionCriteriaBuilder(ContactFunctionCriteriaBuilder contactFunctionCriteriaBuilder) {
      this.contactFunctionCriteriaBuilder = contactFunctionCriteriaBuilder;
   }

   public void setCountryCriteriaBuilder(CountryCriteriaBuilder countryCriteriaBuilder) {
      this.countryCriteriaBuilder = countryCriteriaBuilder;
   }

   public void setAddressCriteriaBuilder(AddressCriteriaBuilder addressCriteriaBuilder) {
      this.addressCriteriaBuilder = addressCriteriaBuilder;
   }

   public void setFipsCriteriaBuilder(FipsCriteriaBuilder fipsCriteriaBuilder) {
      this.fipsCriteriaBuilder = fipsCriteriaBuilder;
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }
}
