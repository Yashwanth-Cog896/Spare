package com.monsanto.tps.lexiconpos.event.deregulated.service;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 11, 2006
 * Time: 1:23:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropMismatchException
   extends Exception
{
   public CropMismatchException() {
      super("Events are associated with different crops.");
   }

}
