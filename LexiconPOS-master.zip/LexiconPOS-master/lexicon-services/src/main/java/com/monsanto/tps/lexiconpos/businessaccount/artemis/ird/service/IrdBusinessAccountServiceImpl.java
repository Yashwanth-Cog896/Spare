package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service;

import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexiconpos.businessaccount.dao.ird.IrdBusinessAccountDao;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;

/**
 * Filename:    IrdBusinessAccountServiceImpl.java
 * Last Change: rrchak1 On:	Aug 5, 2008
 *
 * @author: rrchak1
 */
public class IrdBusinessAccountServiceImpl
   implements IrdBusinessAccountService
{
   private IrdBusinessAccountDao irdBusinessAccountDao;

   public Acct[] findByIds(long[] businessAccountIds) {
      return irdBusinessAccountDao.findByIds(businessAccountIds);
   }

   public Acct[] findBySearchCriteria(BusinessAccountSearchCriteria businessAccountSearchCriteria) {
      return irdBusinessAccountDao.findBySearchCriteria(businessAccountSearchCriteria);
   }

   public void setIrdBusinessAccountDao(IrdBusinessAccountDao irdBusinessAccountDao) {
      this.irdBusinessAccountDao = irdBusinessAccountDao;
   }

   public IrdBusinessAccountDao getBusinessAccountDao() {
      return irdBusinessAccountDao;
   }
}
