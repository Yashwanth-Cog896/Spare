package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.germplasm.dao.GermplasmByIDQuery;
import com.monsanto.tps.lexiconpos.germplasm.dao.GermplasmPSRowImpl;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: May 19, 2006
 * Time: 2:49:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGPLookupDBImpl
   implements MidasGPLookup, MidasSQL
{
   public Germplasm[] getProductGermplams(long productID, PersistentStoreConnection midasConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_GERMPLASMS_BY_PROD_ID);
      PersistentStoreStatement statement = midasConn.prepareStatement(sql);
      try {
         statement.setParam(1, productID);
         PersistentStoreResultSetFwdIterator iter = statement.executeQuery().getForwardIterator();
         ArrayList list = new ArrayList();
         while (iter.next()) {
            list.add(new GermplasmPSRowImpl(iter));
         }
         return (Germplasm[])list.toArray(new Germplasm[list.size()]);
      }
      finally {
         statement.close();
      }
   }

   public Germplasm getGermplasmByID(long germplasmID, PersistentStoreConnection midasConn)
      throws WrappingException
   {
      GermplasmByIDQuery query = new GermplasmByIDQuery(germplasmID);
      return query.getGermplasm(midasConn);
   }

   public Germplasm[] getGermplasmsByID(long[] germplasmID, PersistentStoreConnection midasConn)
      throws WrappingException
   {
      List germplasms = new ArrayList();
      for (int i = 0; i < germplasmID.length; i++) {
         Germplasm germplasm = getGermplasmByID(germplasmID[i], midasConn);
         if (germplasm != null) {
            germplasms.add(germplasm);
         }
      }
      return (Germplasm[])germplasms.toArray(new Germplasm[germplasms.size()]);
   }

   protected SQLPropFile getSQLPropFile() {
      return new SQLPropFile(MidasSQL.class);
   }
}
