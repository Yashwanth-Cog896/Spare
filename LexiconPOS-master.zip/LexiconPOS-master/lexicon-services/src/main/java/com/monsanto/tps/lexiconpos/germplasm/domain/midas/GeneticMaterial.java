package com.monsanto.tps.lexiconpos.germplasm.domain.midas;

import com.monsanto.tps.lexiconpos.parentage.domain.midas.Parentage;

import java.util.List;

/**
 * RLCASW - Feb 28, 2010 9:14:38 AM
 */
public class GeneticMaterial
{
   private Long id;
   private List<Parentage> parentages;
   private Germplasm germplasm;

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public List<Parentage> getParentages() {
      return parentages;
   }

   public void setParentages(List<Parentage> parentages) {
      this.parentages = parentages;
   }

   public Germplasm getGermplasm() {
      return germplasm;
   }

   public void setGermplasm(Germplasm germplasm) {
      this.germplasm = germplasm;
   }
}
