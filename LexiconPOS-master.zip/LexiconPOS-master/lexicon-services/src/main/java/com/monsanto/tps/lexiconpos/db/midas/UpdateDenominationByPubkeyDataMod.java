package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreUpdate;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 13, 2006
 * Time: 4:48:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateDenominationByPubkeyDataMod
   extends AbstractPersistentStoreUpdate
{
   private final String productPubkey;
   private final String denomination;

   public UpdateDenominationByPubkeyDataMod(String productPubkey, String denomination) {
      this.productPubkey = productPubkey;
      this.denomination = denomination;
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasWriterSQL.class).getSQL(MidasWriterSQL.UPDATE_DENOM_BY_PUBKEY);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { denomination, productPubkey };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
