package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.Util.Exceptions.WrappingException;

import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 25, 2006
 * Time: 10:51:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGeographicRegionSQLBuilder {

    private String[] countryPubkeys;
    private long[] subCountryIds;
    private long[] subSubCountryIds;
    private String[] subSubCountryNames;

    private final SQLPropFile sqlPropFile = new SQLPropFile(MidasGeographicRegionQuerySQL.class);

    public MidasGeographicRegionSQLBuilder(String[] countryPubkeys, long[] subCountryIds, long[] subSubCountryIds,
            String[] subSubCountryNames) {
        this.countryPubkeys = countryPubkeys;
        this.subCountryIds = subCountryIds;
        this.subSubCountryIds = subSubCountryIds;
        this.subSubCountryNames = subSubCountryNames;
    }

    public String getSQL() throws WrappingException {
        StringBuffer sql = new StringBuffer();
        sql.append(getBaseSQL());
        sql.append(getCountryPubkeyCriteria());
        sql.append(getSubCountryIdCriteria());
        sql.append(getSubSubCountryIdCriteria());
        sql.append(getSubSubCountryNameCriteria());
        return sql.toString();
    }

    private String getBaseSQL() throws WrappingException {
        return sqlPropFile.getSQL(MidasGeographicRegionQuerySQL.GEOGRAPHIC_REGIONS_BY_IDS);
    }

    private String getCountryPubkeyCriteria() throws WrappingException {
        return getInListOfStrings(MidasGeographicRegionQuerySQL.COUNTRY_PUBKEY_COLUMN, countryPubkeys);
    }

    private String getSubCountryIdCriteria() throws WrappingException {
        return getInListOfLongs(MidasGeographicRegionQuerySQL.SUB_COUNTRY_ID_COLUMN, subCountryIds);
    }

    private String getSubSubCountryIdCriteria() throws WrappingException {
        return getInListOfLongs(MidasGeographicRegionQuerySQL.SUB_SUB_COUNTRY_ID_COLUMN, subSubCountryIds);
    }

    private String getSubSubCountryNameCriteria()
            throws WrappingException {
        return (subSubCountryNames.length == 0) ? "" : getSubSubCountryNameLikeClause();
    }

    private String getSubSubCountryNameLikeClause() throws WrappingException {
        String andNameLikeCriteria = buildSubSubCountryNameLikeClause();
        WildcardableCriteria criteria = new StdWildcardableCriteria(andNameLikeCriteria);
        return criteria.oracleVersion();
    }

    private String buildSubSubCountryNameLikeClause() throws WrappingException {
        String subSubCountryNameCriteria = sqlPropFile.getSQL(MidasGeographicRegionQuerySQL.SUB_SUB_COUNTRY_NAME_CRITERIA);
        StringBuffer clause = new StringBuffer(" AND (" + subSubCountryNameCriteria + " '");
        for (int i = 0; i < subSubCountryNames.length; i++) {
            if (i > 0) {
                clause.append(" OR " + subSubCountryNameCriteria + " '");
            }
            clause.append(subSubCountryNames[i].toUpperCase());
            clause.append("'");
        }
        clause.append(")");
        return clause.toString();
    }

    private String getInListOfStrings(String criteriaName, String[] pubkeys) throws WrappingException {
        return (pubkeys.length == 0) ? "" : " AND " + SqlUtilities.makeInListOfStrings(getColumn(criteriaName), Arrays.asList(pubkeys));
    }

    private String getInListOfLongs(String criteriaName, long[] ids) throws WrappingException {
        return (ids.length == 0) ? "" : " AND " + SqlUtilities.makeInListOfLongs(getColumn(criteriaName), ids);
    }

    private String getColumn(String criteriaName) throws WrappingException {
        return sqlPropFile.getSQL(criteriaName);
    }
}
