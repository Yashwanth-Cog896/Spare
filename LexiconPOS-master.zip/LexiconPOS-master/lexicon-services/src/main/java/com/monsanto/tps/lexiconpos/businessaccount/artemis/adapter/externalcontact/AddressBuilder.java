package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactAddr;
import com.monsanto.tps.lexiconpos.geography.domain.ird.Fips;
import com.monsanto.tps.lexiconpos.geography.domain.ird.Geo;
import com.monsanto.tps.lexiconpos.geography.domain.ird.ZipCode;
import com.monsanto.tps.lexicon.contact.Address;

/**
 * nbwald - Jul 31, 2008 6:20:31 PM
 */
public class AddressBuilder
{
   public Address build(ContactAddr contactAddr) {
      Address address = new Address();
      setAddressFields(contactAddr, address);
      setLocationFields(contactAddr, address);
      return address;
   }

   private void setAddressFields(ContactAddr contactAddr, Address address) {
      address.setLine1(contactAddr.getAddrLine1());
      address.setLine2(contactAddr.getAddrLine2());
      address.setLine3(contactAddr.getAddrLine3());
      address.setPostalCode(extractPostalCode(contactAddr));
   }

   private String extractPostalCode(ContactAddr contactAddr) {
      ZipCode zipCode = contactAddr.getZipCode();
      return zipCode == null ? null : zipCode.getZipCode() + extendedZipCode(contactAddr);
   }

   private String extendedZipCode(ContactAddr contactAddr) {
      String extendedZipCode = contactAddr.getZipCode4();
      return StringUtils.isNullOrEmpty(extendedZipCode) ? "" : "-" + extendedZipCode;
   }

   private void setLocationFields(ContactAddr contactAddr, Address address) {
      address.setCity(contactAddr.getCity());
      address.setState(contactAddr.getStateCode());
      address.setCounty(getCounty(contactAddr.getZipCode()));
      address.setCountry(getCountry(contactAddr.getGeo()));
   }

   private String getCounty(ZipCode zipCode) {
      if(zipCode != null) {
         Fips fips = zipCode.getFips();
         if(fips != null) {
            return fips.getCountyDescr();
         }
      }
      return null;
   }

   private String getCountry(Geo geo) {
      return geo == null ? null : geo.getDescr();
   }
}
