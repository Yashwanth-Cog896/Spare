package com.monsanto.tps.lexiconpos.db.tempsession.dao.midas;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.object.BatchSqlUpdate;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.Types;
import java.util.Collection;


public class TempTableDaoImpl implements TempTableDao {

    private static final String INSERT_TEMP_NUMBER = "insert into midas.temp_session_ocd (request_id, number_1) " +
            "values (:sessionId, :number1)";
    private static final String DELETE_ALL_TEMP = "delete from midas.temp_session_ocd";

    @Resource(name = "simpleJdbcTemplate")
    private SimpleJdbcTemplate simpleJdbcTemplate;
    @Resource(name = "midasDataSource")
    private DataSource midasDataSource;

    @Override
    public long insertIdsIntoTempTable(Long requestId, Collection<Long> numbers) {
        clearTempTable();
        insertIntoTempTable(requestId, numbers);
        return requestId;
    }

    private void clearTempTable() {
        simpleJdbcTemplate.update(DELETE_ALL_TEMP);
    }

    private void insertIntoTempTable(long requestId, Collection<Long> numbers) {
        BatchSqlUpdate batchSqlUpdate = buildTempTableNumberBatchUpdate();
        for (Long number : numbers) {
            batchSqlUpdate.update(requestId, number);
        }
        batchSqlUpdate.flush();
    }

    private BatchSqlUpdate buildTempTableNumberBatchUpdate() {
        BatchSqlUpdate batchSqlUpdate = new BatchSqlUpdate(midasDataSource, INSERT_TEMP_NUMBER);
        batchSqlUpdate.declareParameter(new SqlParameter("SESSION_ID", Types.INTEGER));
        batchSqlUpdate.declareParameter(new SqlParameter("NUMBER_1", Types.BIGINT));
        return batchSqlUpdate;
    }
}
