package com.monsanto.tps.lexiconpos.businessaccount.artemis.contract;

import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;

/**
 * nbwald - May 15, 2008 1:59:59 PM
 */
public class BusinessAccountSearchCriteriaRequest
{
   private final ServiceProcessContext context;

   public BusinessAccountSearchCriteriaRequest(ServiceProcessContext context) {
      this.context = context;
   }

   public BusinessAccountSearchCriteria getSearchCriteria() {
      return (BusinessAccountSearchCriteria) context.getRequestPayload();
   }
}
