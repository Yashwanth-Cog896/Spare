package com.monsanto.tps.lexiconpos.businessaccount.externalcontact;

import com.monsanto.tps.lexiconpos.businessaccount.Address;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Jan 22, 2007
 * Time: 3:39:00 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ExternalContact
{
   String getContactId();
   String getAcctId();
   String getCompanyName();
   Address[] getAddresses();
   String getLastName();
   String getFirstName();
   String getMiddleName();
   String getTitle();
   String getAltPhoneNumber();
   String getFaxNumber();
   String getCellNumber();
   String getPagerNumber();
   String getEmailAddress();
   String getActiveStatus();
}
