package com.monsanto.tps.lexiconpos.geography.country.query;

import com.monsanto.tps.lexicon.geography.country.Country;

import java.util.List;

/**
 * @author GGSHIV - Jun 11, 2008 3:31:07 PM
 */
public interface CountryQuerySet {

   List<Country> findCountriesByISOCodes(String[] countryISOCode);

   List<Country> findCountriesByName(String countryName);
}
