package com.monsanto.tps.lexiconpos.businessaccount.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact.ContactCollection;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.contract.IdentifiersRequest;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service.IrdExternalContactService;

/**
 * nbwald - May 14, 2008 3:21:46 PM
 */
public class FindExternalContactsByBusinessAccountIdsAction
   extends AbstractArtemisServiceAction
{
   private final IrdExternalContactService service;

   public FindExternalContactsByBusinessAccountIdsAction(IrdExternalContactService service) {
      this.service = service;
   }

   public void process(ServiceProcessContext context)
      throws Exception
   {
      IdentifiersRequest request = new IdentifiersRequest(context);
      Contact[] externalContacts = service.findByBusinessAccountIds(request.getIds());
      ContactCollection contactCollection = new ContactCollection(externalContacts);
      new MultipleResultResponse(contactCollection.getExternalContacts()).saveResponse(context);
   }
}
