package com.monsanto.tps.lexiconpos.geography.subcountry.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

import java.util.List;

/**
 * nbwald - Jun 8, 2008 3:05:14 PM
 */
public class SubcountriesByWildcardableNameQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String lexiconCountryPubkey;
   private final WildcardableCriteria subcountryName;

   public SubcountriesByWildcardableNameQuery(String lexiconCountryPubkey, WildcardableCriteria subcountryName) {
      this.lexiconCountryPubkey = lexiconCountryPubkey;
      this.subcountryName = subcountryName;
   }

   public Subcountry[] find() {
      try {
         List<Subcountry> subcountries = getList();
         return subcountries.toArray(new Subcountry[subcountries.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      Subcountry subcountry = new Subcountry();
      subcountry.setName( row.getString("SubCountryName") );
      subcountry.setAbbreviation( row.getString("SubCountryAbbr") );
      return subcountry;
   }

   protected String getSQL()
      throws WrappingException
   {
      return
         "   SELECT SC.name AS \"SubCountryName\", SC.sub_country_abbr AS \"SubCountryAbbr\"" +
         "     FROM FBS_Common.Country_Xref CX," +
         "          Midas.Country C," +
         "          Midas.Sub_Country SC" +
         "    WHERE CX.lexicon_country_pubkey = ?" +
         "      AND CX.midas_country_id = C.country_id" +
         "      AND C.country_id = SC.country_id" +
         "      AND UPPER(SC.name) LIKE UPPER(?)" +
         " ORDER BY SC.name";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { lexiconCountryPubkey, subcountryName.oracleVersion() };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
