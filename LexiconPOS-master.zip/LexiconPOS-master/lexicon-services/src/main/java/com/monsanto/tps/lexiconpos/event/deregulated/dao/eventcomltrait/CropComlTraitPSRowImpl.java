package com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.event.deregulated.model.CropComlTrait;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 9, 2006
 * Time: 3:11:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class CropComlTraitPSRowImpl
   implements CropComlTrait
{
   private final String cropName;
   private final String comlTraitName;

   public CropComlTraitPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      cropName = row.getString(getAlias(EventCropComlTraitSQL.ALIAS_CROP_NAME));
      comlTraitName = row.getString(getAlias(EventCropComlTraitSQL.ALIAS_COML_TRAIT_NAME));
   }

   public String getCropName() {
      return cropName;
   }

   public String getComlTraitName() {
      return comlTraitName;
   }

   private String getAlias(String propName)
      throws WrappingException
   {
      return new SQLPropFile(EventCropComlTraitSQL.class).getAlias(propName);
   }
}
