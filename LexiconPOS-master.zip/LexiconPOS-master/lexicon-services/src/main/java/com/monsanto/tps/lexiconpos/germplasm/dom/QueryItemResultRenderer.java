/*
 QueryItemResultRenderer was created on Jan 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import org.w3c.dom.Element;
import com.monsanto.tps.lexiconpos.germplasm.model.QueryItemResult;
import com.monsanto.tps.lexiconpos.germplasm.model.ProductGermplasmWithSources;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * nbwald Jan 31, 2007 10:44:30 AM
 */
public class QueryItemResultRenderer {
   private final Element queryResultsElem;
   private final QueryItemResult queryItemResult;

   public QueryItemResultRenderer(Element queryResultsElem, QueryItemResult queryItemResult) {
      this.queryResultsElem = queryResultsElem;
      this.queryItemResult = queryItemResult;
   }

   public void render() {
      Element queryItemResultElem = renderQueryItemResultElem();
      renderItemID(queryItemResultElem);
      renderItemsMatchedFromGermplasmCriteria(queryItemResultElem);
      renderGermplasms(queryItemResultElem);
   }

   private Element renderQueryItemResultElem() {
      return DOMUtil.addChildElementWithNS(GermplasmDocTags.NS_URI, queryResultsElem, GermplasmQueryDocTags.QUERY_ITEM_RESULT_ELEM_NAME);
   }

   private void renderItemID(Element queryItemResultElem) {
      DOMUtil.setAttribute(queryItemResultElem, GermplasmQueryDocTags.ITEM_ID_ATTR_NAME, queryItemResult.getItemID());
   }

   private void renderItemsMatchedFromGermplasmCriteria(Element queryItemResultElem) {
      DOMUtil.setAttribute(queryItemResultElem, GermplasmQueryDocTags.ITEM_MATCHED_FROM_GP_CRITERIA_ATTR_NAME, queryItemResult.getNumGermplasmFromGermplasmCriteria());
   }

   private void renderGermplasms(Element queryItemResultElem) {
      Element germplasmsElem = DOMUtil.addChildElementWithNS(GermplasmDocTags.NS_URI, queryItemResultElem, GermplasmDocTags.GERMPLASM_LIST_ELEM_NAME);
      ProductGermplasmWithSources[] richGermplasms = queryItemResult.getRichGermplasms();
      renderGermplasms(germplasmsElem, richGermplasms);
   }

   private void renderGermplasms(Element germplasmsElem, ProductGermplasmWithSources[] richGermplasms) {
      for (ProductGermplasmWithSources richGermplasm : richGermplasms) {
         renderGermplasm(germplasmsElem, richGermplasm);
      }
   }

   private void renderGermplasm(Element germplasmsElem, ProductGermplasmWithSources richGermplasm) {
      QueryGermplasmRenderer renderer = new QueryGermplasmRenderer(germplasmsElem, richGermplasm);
      renderer.render();
   }
}