package com.monsanto.tps.lexiconpos.chemical.service.pos;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 23, 2005
 * Time: 12:27:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidMaterialClassificationTypeException
    extends Exception
{
    public InvalidMaterialClassificationTypeException(String classification) {
        super(classification + " is not a valid material classification.");
    }
}
