package com.monsanto.tps.lexiconpos.geography.service;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 11:16:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class GetCountryController
    extends GetGeographicEntitiesController
{
    protected GeographyRequestParser getGeographyRequestParser() {
        return new GetCountryRequestParser();
    }

    protected GeographyRequestProcessor getGeographyRequestProcessor() {
        return new GetCountryRequestProcessor();
    }

    protected GeographicEntityRenderer getEntityRenderer() {
        return new CountryRenderer();
    }

    protected String getResponseDocumentElementName() {
        return GeographySchemaConstants.GET_COUNTRY_RESPONSE_ELEM_NAME;
    }
}
