package com.monsanto.tps.lexiconpos.db.audit.domain.lexicon;

/**
 * nbwald - Aug 20, 2008 5:17:00 PM
 */
public class AuditDetail
{
   private long auditDetailId;

   public long getAuditDetailId() {
      return auditDetailId;
   }

   public void setAuditDetailId(long auditDetailId) {
      this.auditDetailId = auditDetailId;
   }

   private String columnName;

   public String getColumnName() {
      return columnName;
   }

   public void setColumnName(String columnName) {
      this.columnName = columnName;
   }

   private String newValue;

   public String getNewValue() {
      return newValue;
   }

   public void setNewValue(String newValue) {
      this.newValue = newValue;
   }

   private String oldValue;

   public String getOldValue() {
      return oldValue;
   }

   public void setOldValue(String oldValue) {
      this.oldValue = oldValue;
   }

   private AuditHeader auditHeader;

   public AuditHeader getAuditHeader() {
      return auditHeader;
   }

   public void setAuditHeader(AuditHeader auditHeader) {
      this.auditHeader = auditHeader;
   }
}
