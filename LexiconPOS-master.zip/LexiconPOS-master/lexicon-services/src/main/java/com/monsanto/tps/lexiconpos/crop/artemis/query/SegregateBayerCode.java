/*
 SegregateBayerCode was created on Jun 25, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.tps.lexicon.crop.ScientificName;

/**
 * @author PNAGAPP - Jun 25, 2008 1:20:09 PM
 */
public class SegregateBayerCode {

   private String code;
   private String publicKey;
   private ScientificName scientificName;

   public SegregateBayerCode(String code, String publicKey, ScientificName scientificName) {
      this.code = code;
      this.publicKey = publicKey;
      this.scientificName = scientificName;
   }

   public String getCode() {
      return code;
   }

   public String getPublicKey() {
      return publicKey;
   }

   public ScientificName getScientificName() {
      return scientificName;
   }
}
