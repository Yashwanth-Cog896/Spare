package com.monsanto.tps.lexiconpos.event.deregulated.dao;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 29, 2006
 * Time: 2:05:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegulatoryAgencyDTO 
   implements RegulatoryAgency
{
   private long agencyID;
   private String agencyName;

   public RegulatoryAgencyDTO(long agencyID, String agencyName)
   {
      this.agencyID = agencyID;
      this.agencyName = agencyName;
   }

   public long getAgencyID() {
      return agencyID;
   }

   public String getAgencyName() {
      return agencyName;
   }
}
