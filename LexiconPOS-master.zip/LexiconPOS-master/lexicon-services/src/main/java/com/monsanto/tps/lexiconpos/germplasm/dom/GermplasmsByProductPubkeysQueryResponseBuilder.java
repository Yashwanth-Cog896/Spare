/*
 GermplasmsByProductPubkeysQueryResponseBuilder was created on Jun 6, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dom;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tcc.lexiconcommon.service.germplasm.GermplasmsByProductPubkeysQueryDocTags;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.Germplasm;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.Map;

/**
 * nbwald Jun 6, 2007 9:52:16 AM
 */
public class GermplasmsByProductPubkeysQueryResponseBuilder
{
   public Document build(Map<String, Germplasm[]> results) {
      Document response = createResponse();
      renderProducts(results, response.getDocumentElement());
      return response;
   }

   private void renderProducts(Map<String, Germplasm[]> results, Element responseElem) {
      for (String productPubkey : results.keySet()) {
         renderProduct(responseElem, productPubkey, results.get(productPubkey));
      }
   }

   private void renderProduct(Element responseElem, String productPubkey, Germplasm[] germplasms) {
      Element productElem = DOMUtil.addChildElementWithNS(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, responseElem, GermplasmsByProductPubkeysQueryDocTags.PRODUCT_ELEM_NAME);
      DOMUtil.setAttribute(productElem, GermplasmsByProductPubkeysQueryDocTags.PUBKEY_ATTR_NAME, productPubkey);
      renderGermplasms(productElem, germplasms);
   }

   private void renderGermplasms(Element productElem, Germplasm[] germplasms) {
      for (Germplasm germplasm : germplasms) {
         renderGermplasm(productElem, germplasm);
      }
   }

   private void renderGermplasm(Element productElem, Germplasm germplasm) {
      Element germplasmElem = DOMUtil.addChildElementWithNS(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, productElem, GermplasmsByProductPubkeysQueryDocTags.GERMPLASM_ELEM_NAME);
      DOMUtil.setAttribute(germplasmElem, GermplasmsByProductPubkeysQueryDocTags.KEY_ATTR_NAME, Long.toString(germplasm.getMidasGermplasmID()));
      DOMUtil.addChildElementWithNS(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, germplasmElem, GermplasmsByProductPubkeysQueryDocTags.ORIGIN_ELEM_NAME, germplasm.getOrigin());
      DOMUtil.addChildElementWithNS(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, germplasmElem, GermplasmsByProductPubkeysQueryDocTags.LINECODE_ELEM_NAME, germplasm.getLineCode());
      DOMUtil.addChildElementWithNS(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, germplasmElem, GermplasmsByProductPubkeysQueryDocTags.LINETYPE_ELEM_NAME, germplasm.getLineType());
      DOMUtil.addChildElementWithNS(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, germplasmElem, GermplasmsByProductPubkeysQueryDocTags.IS_FINISHED_FLAG_ELEM_NAME, germplasm.isFinished());
   }

   private Document createResponse() {
      return new DocumentCreator().createDocument(GermplasmsByProductPubkeysQueryDocTags.NAMESPACE, GermplasmsByProductPubkeysQueryDocTags.RESPONSE_ELEM_NAME);
   }
}