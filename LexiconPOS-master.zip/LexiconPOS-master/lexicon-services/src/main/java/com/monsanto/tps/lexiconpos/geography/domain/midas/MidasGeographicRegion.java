package com.monsanto.tps.lexiconpos.geography.domain.midas;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Oct 26, 2006
 * Time: 9:12:03 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasGeographicRegion
{
   String getCountryPubkey();
   long getCountryId();
   long getSubCountryId();
   long getSubSubCountryId();
   String getSubCountryAbbreviation();
   String getSubSubCountryName();
}
