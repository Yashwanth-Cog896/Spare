package com.monsanto.tps.lexiconpos.geography.zipcode;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 11:21:10 AM
 */
public interface ZipCodeValidationSchemaConstants
{
	String NAMESPACE = "http://www.monsanto.com/lexicon/ZipCode";
	String SCHEMA_LOC = "xsd/lexicon/ZipCode.xsd";

	String REQUEST_ZIP_CODE_ELEM_NAME = "RequestedZipCode";
	String RESPONSE_ELEM_NAME = "Response";
	String VALIDATED_ZIP_CODE_ELEM_NAME = "ValidatedZipCode";
}
