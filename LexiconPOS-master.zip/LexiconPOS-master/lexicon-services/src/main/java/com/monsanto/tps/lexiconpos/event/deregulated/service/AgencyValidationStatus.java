package com.monsanto.tps.lexiconpos.event.deregulated.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatus;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatusImpl;
import com.monsanto.tps.lexiconpos.event.deregulated.dao.RegulatoryAgency;
import com.monsanto.tps.lexiconpos.event.deregulated.dao.RegulatoryAgencyByCountryPubkeyQuery;
import com.monsanto.tps.lexiconpos.event.deregulated.dao.RegulatoryStatusQuery;
import com.monsanto.tps.lexiconpos.traitstack.dao.GetRegulatoryAgencyStatusQuery;
import com.monsanto.tps.lexiconpos.event.deregulated.DeregulatedEventValidationCondition;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 21, 2006
 * Time: 3:28:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class AgencyValidationStatus
{
   private final String stackAbbr;
   private final String cropName;
   private final String countryPubkey;

   public AgencyValidationStatus(
      String stackAbbr, String cropName, String countryPubkey)
   {
      this.stackAbbr = stackAbbr;
      this.cropName = cropName;
      this.countryPubkey = countryPubkey;
   }

   public ValidationStatus getValidationStatus()
      throws WrappingException
   {
      String[] approvalStatuses = getApprovalStatuses();
      ValidationStatus validationStatus = new ValidationStatusImpl();
      if (!isDeregulated(approvalStatuses)) {
         validationStatus.addCondition(getIsNotDeregulatedCondition(), ValidationConditionSeverity.ERROR);
      }
      return validationStatus;
   }

   private String[] getApprovalStatuses()
      throws WrappingException
   {
      List statuses = new ArrayList();
      RegulatoryAgency[] agencies = getAgencies();
      for (int i = 0; i < agencies.length; i ++) {
         statuses.add(getApprovalStatus(agencies[i].getAgencyID()));
      }
      return (String[])statuses.toArray(new String[statuses.size()]);
   }

   private String getApprovalStatus(long agencyID)
      throws WrappingException
   {
      GetRegulatoryAgencyStatusQuery query = new GetRegulatoryAgencyStatusQuery(stackAbbr, cropName, agencyID);
      return query.getAgencyStatus();
   }

   private RegulatoryAgency[] getAgencies()
      throws WrappingException
   {
      RegulatoryAgencyByCountryPubkeyQuery query = new RegulatoryAgencyByCountryPubkeyQuery(countryPubkey);
      return query.getAgencies();
   }

   private boolean isDeregulated(String[] approvalStatuses)
      throws WrappingException
   {
      if (approvalStatuses.length == 0) {
         return false;
      }
      for (int i = 0; i < approvalStatuses.length; i ++) {
         if (!isApproved(approvalStatuses[i])) {
            return false;
         }
      }
      return true;
   }

   private boolean isApproved(String approvalStatus)
      throws WrappingException
   {
      String[] validDeregStatuses = getValidDeregStatuses();
      for (int i = 0; i < validDeregStatuses.length; i ++) {
         if (validDeregStatuses[i].equalsIgnoreCase(approvalStatus)) {
            return true;
         }
      }
      return false;
   }

   private String[] getValidDeregStatuses()
      throws WrappingException
   {
      RegulatoryStatusQuery query = new RegulatoryStatusQuery();
      return query.getValidDeregulatedStatuses();
   }

   private DeregulatedEventValidationCondition getIsNotDeregulatedCondition() {
      return new DeregulatedEventValidationCondition(DeregulatedEventValidationCondition.EVENT_NOT_DEREGULATED_CODE);
   }
}
