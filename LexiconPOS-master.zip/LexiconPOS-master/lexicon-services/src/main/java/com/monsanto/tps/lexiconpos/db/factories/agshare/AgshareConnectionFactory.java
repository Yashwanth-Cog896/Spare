package com.monsanto.tps.lexiconpos.db.factories.agshare;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 2, 2006
 * Time: 4:21:54 PM
 */
public class AgshareConnectionFactory
   extends BasicConnectionFactory
{
   public AgshareConnectionFactory() {
      super(new AgshareConnectionFactoryProperties());
   }
}

