package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 3:06:05 PM
 */
public class LexiconCountryPSRowImpl
   implements LexiconCountry, LexiconSQL
{
   private final long lexiconID;
   private final String publicKey;
   private final String name;
   private final String UNCodeStr;
   private final String ISOCode;
   private final int UNCode;
   private final String subCountryDescription;
   private final String subSubCountryDescription;

   public LexiconCountryPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      lexiconID = row.getLong(getSQLPropFile().getAlias(ALIAS_COUNTRY_ID));
      publicKey = row.getString(getSQLPropFile().getAlias(ALIAS_COUNTRY_PUBKEY));
      name = row.getString(getSQLPropFile().getAlias(ALIAS_COUNTRY_NAME));
      UNCodeStr = row.getString(getSQLPropFile().getAlias(ALIAS_COUNTRY_ABBR));
      ISOCode = row.getString(getSQLPropFile().getAlias(ALIAS_ISO_CODE));
      UNCode = row.getInt(getSQLPropFile().getAlias(ALIAS_UN_CODE));
      subCountryDescription = row.getString(getSQLPropFile().getAlias(ALIAS_SUBCOUNTRY_DESCRIPTION));
      subSubCountryDescription = row.getString(getSQLPropFile().getAlias(ALIAS_SUBSUBCOUNTRY_DESCRIPTION));
   }

   public long getLexiconID() {
      return lexiconID;
   }
   public String getPublicKey() {
      return publicKey;
   }
   public String getName() {
      return name;
   }
   public String getUNCodeStr() {
      return UNCodeStr;
   }
   public String getISOCode() {
      return ISOCode;
   }
   public int getUNCode() {
      return UNCode;
   }
   public String getSubCountryDescription() {
      return subCountryDescription;
   }
   public String getSubSubCountryDescription() {
      return subSubCountryDescription;
   }

   private SQLPropFile getSQLPropFile() {
       SQLPropFile sqlPropFile = new SQLPropFile(LexiconSQL.class);
       return sqlPropFile;
   }
}
