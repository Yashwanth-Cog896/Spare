/*
 BFCComplianceSiteSQL was created on Oct 19, 2006 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.event.bfc.site;

/**
 * nbwald Oct 19, 2006 2:19:18 PM
 */
public interface BFCComplianceSiteSQL {
   String SELECT_COMPLIANCESITE = "ComplianceSite.Effective.Lookup";

   String ALIAS_SITE_STATUS = "SiteStatus";
   String ALIAS_DROPPED = "Dropped";
   String ALIAS_CANCELLED = "Cancelled";
   String ALIAS_ADDRESS_TYPE = "AddressType";
   String ALIAS_PACKET_SENT = "PacketSent";
   String ALIAS_RELEASESITE_ID = "ReleaseSiteId";
   String ALIAS_COMPLIANCE_SITE_ID = "ComplianceSiteId";
   String ALIAS_EFFECTIVE_SITE_ID = "EffectiveSiteId";
}