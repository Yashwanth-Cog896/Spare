package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jul 18, 2006
 * Time: 12:43:16 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasCreateProductGPDataManip
{
   public int createProductGermplasmAssignment(long productID, long germplasmID,boolean isPreferred, PersistentStoreConnection midasConn)
      throws WrappingException;
}
