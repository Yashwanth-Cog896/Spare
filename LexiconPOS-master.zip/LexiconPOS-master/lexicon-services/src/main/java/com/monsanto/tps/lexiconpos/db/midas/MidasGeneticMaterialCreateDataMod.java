package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Aug 29, 2006
 * Time: 4:37:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGeneticMaterialCreateDataMod
   extends AbstractPersistentStoreInsert
{
   private final long geneticMaterialID;
   private final long germplasmID;
   private final String source;
   private final String generation;
   private final String lineage;

   public MidasGeneticMaterialCreateDataMod(long geneticMaterialID, long germplasmID,
      String source, String generation, String lineage)
   {
      this.geneticMaterialID = geneticMaterialID;
      this.germplasmID = germplasmID;
      this.source = source;
      this.generation = generation;
      this.lineage = lineage;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MidasWriterSQL.class);
      return propFile.getSQL(MidasWriterSQL.INSERT_GENETIC_MATERIAL);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(geneticMaterialID), new Long(germplasmID), source, generation, lineage };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
