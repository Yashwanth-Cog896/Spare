package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.SubSubCountry;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 8:14:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubSubCountryPSRowImpl
   implements SubSubCountry, LexiconSQL
{
   private long id;
   private String name;

   public SubSubCountryPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      id = row.getLong(getSQLPropFile().getAlias(ALIAS_SUBSUBCOUNTRY_ID));
      name = row.getString(getSQLPropFile().getAlias(ALIAS_SUBSUBCOUNTRY_NAME));
   }

   public long getID() {
      return id;
   }
   public String getName() {
      return name;
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(LexiconSQL.class);
   }
}