package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Filename:    ExternalContactCriteriaFactory.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public class ExternalContactCriteriaBuilder
{
   public void addCriteria(Criteria contactCriteria, ExternalContactSearchCriteria searchCriteria) {
      List<Criterion> applicableCriteria = getApplicableCriteria(searchCriteria);
      for (Criterion applicableCriterion : applicableCriteria) {
         contactCriteria.add(applicableCriterion);
      }
   }

   private List<Criterion> getApplicableCriteria(ExternalContactSearchCriteria searchCriteria) {
      List<Criterion> applicableCriteria = new ArrayList<Criterion>();
      for (QueryCriteria contactCriteria : getAllCriteria(searchCriteria)) {
         if (contactCriteria.hasCriteria()) {
            applicableCriteria.add(contactCriteria.getCriterion());
         }
      }
      return applicableCriteria;
   }

   private List<QueryCriteria> getAllCriteria(ExternalContactSearchCriteria externalContactSearchCriteria) {
      return Arrays.asList(
         new ExternalContactFirstNameCriteriaImpl(externalContactSearchCriteria.getFirstName()),
         new ExternalContactLastNameCriteriaImpl(externalContactSearchCriteria.getLastName()));
   }
}
