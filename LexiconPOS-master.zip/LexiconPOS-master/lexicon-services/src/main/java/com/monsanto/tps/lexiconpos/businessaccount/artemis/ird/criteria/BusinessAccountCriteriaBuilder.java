package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author: rrchak1
 */
public class BusinessAccountCriteriaBuilder {

    public List<Criterion> getCriterion(BusinessAccountSearchCriteria businessAccountSearchCriteria) {
        List<QueryCriteria> businessAccountCriteriaList = buildCriteria(businessAccountSearchCriteria);
        return getCriterion(businessAccountCriteriaList);
    }

    private List<Criterion> getCriterion(List<QueryCriteria> businessAccountCriteriaList) {
        List<Criterion> criterion = new ArrayList<Criterion>();
        for (QueryCriteria businessAccountCriteria : businessAccountCriteriaList) {
            if (businessAccountCriteria.hasCriteria()) {
                criterion.add(businessAccountCriteria.getCriterion());
            }
        }
        return criterion;
    }

    private List<QueryCriteria> buildCriteria(BusinessAccountSearchCriteria businessAccountSearchCriteria) {
        return Arrays.asList(
                new BusinessAccountNameCriteriaImpl(businessAccountSearchCriteria.getCompanyName()),
                new BusinessAccountStatusCriteriaImpl()                
        );
    }

    public void addCriteria(Criteria accountCriteria, BusinessAccountSearchCriteria businessAccountSearchCriteria) {
        List<Criterion> businessAccountCriterion = getCriterion(businessAccountSearchCriteria);
        for (Criterion c : businessAccountCriterion) {
            accountCriteria.add(c);
        }
    }
}