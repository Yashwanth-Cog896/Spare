package com.monsanto.tps.lexiconpos.db.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreRecordSync;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreUpdate;
import com.monsanto.tps.lexiconpos.db.factories.yieldmart.YieldMartConnectionFactoryProperties;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jan 8, 2007
 * Time: 2:57:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class MapProductMirageRecordSyncDataMod
   extends AbstractPersistentStoreRecordSync
{
   private final int seedProductId;
   private final long geneticMaterialId;
   private final long midasProductId;
   private final String productName;

   public MapProductMirageRecordSyncDataMod(
      int seedProductId, long geneticMaterialId, long midasProductId, String productName)
   {
      this.seedProductId = seedProductId;
      this.geneticMaterialId = geneticMaterialId;
      this.midasProductId = midasProductId;
      this.productName = productName;
   }

   protected AbstractPersistentStoreInsert getInsertDataMod() {
      return new MapProductMirageCreateDataMod(seedProductId, geneticMaterialId, midasProductId, productName);
   }
   protected AbstractPersistentStoreUpdate getUpdateDataMod() {
      return new MapProductMirageUpdateDataMod(seedProductId, geneticMaterialId, midasProductId, productName);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new YieldMartConnectionFactoryProperties();
   }
}
