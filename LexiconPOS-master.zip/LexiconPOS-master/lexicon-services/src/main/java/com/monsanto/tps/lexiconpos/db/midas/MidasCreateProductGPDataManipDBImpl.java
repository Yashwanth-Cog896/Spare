package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jul 19, 2006
 * Time: 5:26:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasCreateProductGPDataManipDBImpl
   implements MidasCreateProductGPDataManip
{
   public int createProductGermplasmAssignment(long productID, long germplasmID, boolean isPreferred, PersistentStoreConnection midasConn)
      throws WrappingException
   {
      String sql = getSQL(MidasWriterSQL.INSERT_PRODUCT_GERMPLASM);
      PersistentStoreStatement stmt = midasConn.prepareStatement(sql);
      try {
         stmt.setParam(1, productID);
         stmt.setParam(2, germplasmID);
         stmt.setParam(3, isPreferred?"T":"F");
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private String getSQL(String sqlPropName)
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MidasWriterSQL.class);
      return propFile.getSQL(sqlPropName);
   }
}
