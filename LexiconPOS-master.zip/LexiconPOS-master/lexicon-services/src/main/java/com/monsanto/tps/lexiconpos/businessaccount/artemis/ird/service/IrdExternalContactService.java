package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.Contact;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;

/**
 * Filename:    IrdExternalContactService.java
 * Last Change: rrchak1 On:	Jul 29, 2008
 *
 * @author: rrchak1
 */
public interface IrdExternalContactService {

    public Contact[] findByBusinessGeographySearchCriteria(ExternalContactByBusinessGeographySearchCriteria externalContactByBusinessGeographySearchCriteria);

    public Contact[] findByIds(long[] ids);

    public Contact[] findByBusinessAccountIds(long[] ids);

    public Contact[] findBySearchCriteria(ExternalContactSearchCriteria externalContactSearchCriteria);
}
