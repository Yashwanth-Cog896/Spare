/*
 CountryNameRequest was created on Jun 4, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.country.contract;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;

/**
 * @author GGSHIV - Jun 5, 2008 3:44:21 PM
 */
public class CountryNameRequest {

   private final String countryName;

   public CountryNameRequest(ServiceProcessContext context) {
      countryName = (String) context.getRequestPayload();
   }

   public String getName() {
      return countryName;
   }
}