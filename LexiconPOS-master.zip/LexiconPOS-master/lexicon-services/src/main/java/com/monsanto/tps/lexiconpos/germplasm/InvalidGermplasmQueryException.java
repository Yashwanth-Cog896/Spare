package com.monsanto.tps.lexiconpos.germplasm;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Apr 27, 2005
 * Time: 3:16:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class InvalidGermplasmQueryException
   extends Exception
{
   public InvalidGermplasmQueryException(String msg)
   {
      super(msg);
   }
}
