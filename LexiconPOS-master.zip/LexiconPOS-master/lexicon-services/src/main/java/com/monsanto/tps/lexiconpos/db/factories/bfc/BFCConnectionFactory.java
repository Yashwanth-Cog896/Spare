package com.monsanto.tps.lexiconpos.db.factories.bfc;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 12, 2005
 * Time: 6:08:41 PM
 */
public class BFCConnectionFactory
   extends BasicConnectionFactory
{
   public BFCConnectionFactory() {
      super(new BFCConnectionFactoryProperties());
   }
}

