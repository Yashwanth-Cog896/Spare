/*
 CropsByBayerCodesQuery was created on Jun 30, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.crop.artemis.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.StringsCriteriaBuilder;
import static com.monsanto.tps.lexiconpos.tps.crop.dao.CropSQL.SELECT_BY_BAYER_CODES;
import static com.monsanto.tps.lexiconpos.crop.artemis.query.CropQuerySet.CROP_SQL_PROPERTY_FILE;

import java.util.List;

/**
 * @author GGSHIV - Jun 30, 2008 1:21:29 PM
 */
public class CropsByBayerCodesQuery extends AbstractPersistentStoreMultiRowQuery {

   private final String[] bayerCodes;

   public CropsByBayerCodesQuery(String[] bayerCodes) {
      this.bayerCodes = bayerCodes;
   }

   public List<SegregateCrop> find() throws WrappingException {
      return getList();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return new SegregateCropBuilder().build(row);
   }

   protected String getSQL() throws WrappingException {
      return CROP_SQL_PROPERTY_FILE.getSQL(SELECT_BY_BAYER_CODES) + " AND UPPER(BC.BAYER_CODE_NAME) IN ("
              + new StringsCriteriaBuilder().build(bayerCodes) + ") ORDER BY BC.BAYER_CODE_NAME";
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
