package com.monsanto.tps.lexiconpos.db.factories.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryPropertiesLexiconImpl;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 18, 2005
 * Time: 3:25:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasConnectionFactoryProperties
   extends ConnectionFactoryPropertiesLexiconImpl
{
   public static final String INSTANCE_NAME = "Midas";
   private static final String PROP_FILENAME = "MidasDB.properties";

   public String getInstanceName() {
      return INSTANCE_NAME;
   }
   public Properties loadProperties() throws IOException {
      return PropertyManager.getInstance().getNonCachedProperties(getClass(), PROP_FILENAME);
   }

}
