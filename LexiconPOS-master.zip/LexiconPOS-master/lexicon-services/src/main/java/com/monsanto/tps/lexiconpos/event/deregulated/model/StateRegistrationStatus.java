package com.monsanto.tps.lexiconpos.event.deregulated.model;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Nov 6, 2006
 * Time: 11:27:40 AM
 * To change this template use File | Settings | File Templates.
 */
public interface StateRegistrationStatus
{
   String getStackAbbr();
   String getSubCountryKey();
   Date getApprovalDate();
   Date getExpirationDate();
   boolean isRegistration();
}
