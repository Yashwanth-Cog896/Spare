package com.monsanto.tps.lexiconpos.db.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreUpdate;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 13, 2006
 * Time: 3:30:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class UpdateMidasProductDataMod
   extends AbstractPersistentStoreUpdate
{
   private final long productID;
   private final String denomination;

   public UpdateMidasProductDataMod(long productID, String denomination) {
      this.productID = productID;
      this.denomination = denomination;
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile propFile = new SQLPropFile(MidasWriterSQL.class);
      return propFile.getSQL(MidasWriterSQL.UPDATE_PRODUCT_REF_ACTIVE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { denomination, "T", new Long(productID) } ;
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
