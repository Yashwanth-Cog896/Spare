package com.monsanto.tps.lexiconpos.businessaccount.artemis.action;

import com.monsanto.tcc.artemis.workflow.process.ServiceProcessContext;
import com.monsanto.tps.lexiconpos.businessaccount.domain.ird.Acct;
import com.monsanto.tps.lexiconpos.artemis.action.AbstractArtemisServiceAction;
import com.monsanto.tps.lexiconpos.artemis.response.MultipleResultResponse;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.businessaccount.AccountCollection;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.contract.IdentifiersRequest;
import com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.service.IrdBusinessAccountService;

/**
 * nbwald - May 14, 2008 12:35:55 PM
 */
public class FindBusinessAccountsByIdsAction
   extends AbstractArtemisServiceAction
{
    private IrdBusinessAccountService service;

    public FindBusinessAccountsByIdsAction(IrdBusinessAccountService service) {
        this.service = service;
    }

   public void process(ServiceProcessContext context)
      throws Exception
   {
      IdentifiersRequest request = new IdentifiersRequest(context);
      Acct[] irdAccts = service.findByIds(request.getIds());
      AccountCollection accountCollection = new AccountCollection(irdAccts);
      new MultipleResultResponse(accountCollection.getBusinessAccounts()).saveResponse(context);
   }
}