package com.monsanto.tps.lexiconpos.geography.zipcode;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 3, 2006
 * Time: 12:01:37 PM
 */
public class ZipCodeValidationRequestProcessor
{
   private final ZipCodeQuerySet querySet;

   public ZipCodeValidationRequestProcessor() {
      querySet = new ZipCodeQuerySetImpl();
   }

   public ZipCodeValidationRequestProcessor(ZipCodeQuerySet querySet) {
      this.querySet = querySet;
   }

   public String getValidZipCode(ZipCodeValidationRequestModel requestModel)
		throws WrappingException
	{
		String zipCode = requestModel.getZipCode();
		return querySet.doesZipCodeExist(zipCode) ? zipCode : null;
	}
}
