package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;

/**
 * nbwald - Jun 8, 2008 2:41:32 PM
 */
public class LexiconCountryByISOCodeQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String countryISOCode;

   public LexiconCountryByISOCodeQuery(String countryISOCode) {
      this.countryISOCode = countryISOCode;
   }

   public LexiconCountry find() {
      try {
         return (LexiconCountry) execute();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new LexiconCountryPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(LexiconSQL.class).getSQL(LexiconSQL.SELECT_COUNTRY_BY_ISO_CODE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { countryISOCode };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
