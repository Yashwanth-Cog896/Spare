package com.monsanto.tps.lexiconpos.db.mirage;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jan 31, 2007
 * Time: 12:22:50 AM
 */
public class UpdateMiragePreComlsDataMod
{
   private final String newPreComlName;
   private final String oldPreComlName;
   private final String bayerCode;

   public UpdateMiragePreComlsDataMod(String newPreComlName, String oldPreComlName, String bayerCode) {
      this.newPreComlName = newPreComlName;
      this.oldPreComlName = oldPreComlName;
      this.bayerCode = bayerCode + " ";
   }

   public int performUpdate(PersistentStoreConnection mirageConn)
      throws WrappingException
   {
      return new MirageAuditedAction(){
         @Override
         protected int performAction(PersistentStoreStatement statement)
            throws WrappingException
         {
            return statement.executeUpdate();
         }

         @Override
         protected String getSQL()
            throws WrappingException
         {
            return new SQLPropFile(MirageSeedProductWriterSQL.class).getSQL(MirageSeedProductWriterSQL.UPDATE_PRECOMLS);
         }

         @Override
         protected Object[] getBindVariables(int auditId) {
            return new Object[] { newPreComlName, auditId, oldPreComlName, bayerCode };
         }

         @Override
         protected int createAuditRecord(MirageAuditor mirageAuditor, PersistentStoreConnection mirageConn)
            throws WrappingException
         {
            return mirageAuditor.auditUpdateSeedProduct(mirageConn);
         }
      }.execute(mirageConn);
   }
}
