package com.monsanto.tps.lexiconpos.geography.service;

import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 11:07:48 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class GeographyRequestParser
    implements GeographySchemaConstants
{
    public GeographyRequestModel parse(Document requestDoc)
        throws InvalidGeographyRequestException
    {
        Element root = requestDoc.getDocumentElement();
        return parse(root);
    }

    protected abstract GeographyRequestModel parse(Element root)
        throws InvalidGeographyRequestException;

    protected String getCountryName(Element element) {
        return DOMUtil.getChildValue(element, COUNTRY_NAME_REQUEST_PARAM);
    }

    protected String getCountryAbbr(Element element) {
        return DOMUtil.getChildValue(element, COUNTRY_ABBR_REQUEST_PARAM);
    }

    protected String getCountryPubkey(Element element) {
        return DOMUtil.getChildValue(element, COUNTRY_PUBKEY_REQUEST_PARAM);
    }

    protected String getSubCountryName(Element element) {
        return DOMUtil.getChildValue(element, SUB_COUNTRY_NAME_REQUEST_PARAM);
    }

    protected String getSubCountryAbbr(Element element) {
        return DOMUtil.getChildValue(element, SUB_COUNTRY_ABBR_REQUEST_PARAM);
    }

    protected String getSubCountryPubkey(Element element) {
        return DOMUtil.getChildValue(element, SUB_COUNTRY_PUBKEY_REQUEST_PARAM);
    }

    protected String getSubSubCountryName(Element element) {
        return DOMUtil.getChildValue(element, SUB_SUB_COUNTRY_NAME_REQUEST_PARAM);
    }
}
