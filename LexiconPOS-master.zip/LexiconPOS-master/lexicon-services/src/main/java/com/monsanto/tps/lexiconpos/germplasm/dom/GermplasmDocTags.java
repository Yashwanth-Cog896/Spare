package com.monsanto.tps.lexiconpos.germplasm.dom;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Mar 20, 2006
 * Time: 2:46:38 PM
 */
public interface GermplasmDocTags
{
   String SCHEMA_LOC = "xsd/lexicon/Germplasm.xsd";
   String NS_URI = "http://www.monsanto.com/lexicon/germplasm";

   String MAX_ITEMS_ATTR_NAME = "maxItems";
   String ITEMS_MATCHED_ATTR_NAME = "itemsMatched";
   String ITEMS_RETURNED_ATTR_NAME = "itemsReturned";
   String ITEM_MATCHED_FROM_GP_CRITERIA_ATTR_NAME = "itemsMatchedFromGPCriteria";
   
   String GERMPLASM_LIST_ELEM_NAME = "germplasms";
   String GERMPLASM_ELEM_NAME = "germplasm";
   String GP_ID_ATTRIB_NAME = "key";

   String CROP_NAME_ELEM_NAME = "cropName";
   String ORIGIN_ELEM_NAME = "origin";
   String LINE_CODE_ELEM_NAME = "lineCode";
   String LINE_TYPE_ELEM_NAME = "lineType";
   String OWNER_PROG_ELEM_NAME = "ownerProgram";
   String PEDIGREE_ELEM_NAME = "pedigree";
   String SOURCES_ELEM_NAME = "sources";
   String SOURCE_ELEM_NAME = "source";
   String EVENTS_ELEM_NAME = "events";
   String REL_MAT_ELEM_NAME = "relativeMaturity";
   String PRODUCT_PUBKEY_ELEM_NAME = "productPublicKey";
   String IS_FINISHED_ELEM_NAME = "isFinished";
   String IS_PREFERRED_ELEM_NAME = "isPreferred";
}
