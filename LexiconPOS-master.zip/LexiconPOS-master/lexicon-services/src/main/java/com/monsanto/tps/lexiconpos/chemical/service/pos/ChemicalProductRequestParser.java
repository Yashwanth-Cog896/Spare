package com.monsanto.tps.lexiconpos.chemical.service.pos;

import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 21, 2005
 * Time: 11:52:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChemicalProductRequestParser
   implements ChemicalMaterialSchemaConstants
{
   private final Document requestDoc;

   public ChemicalProductRequestParser(Document requestDoc)
   {
      this.requestDoc = requestDoc;
   }

   public ChemicalProductRequest parse()
      throws InvalidMaterialClassificationTypeException
   {
      Element docElement = requestDoc.getDocumentElement();
      String name = getProductName(docElement);
      MaterialClassificationType classification = getClassification(docElement);
      return new ChemicalProductRequest(name, classification);
   }

   private String getProductName(Element docElement)
   {
      String name = DOMUtil.getChildValue(docElement, PROD_NAME_ELEM_NAME);
      return name.toUpperCase();
   }

   private MaterialClassificationType getClassification(Element docElement)
      throws InvalidMaterialClassificationTypeException
   {
      MaterialClassificationType classType = null;
      String classString = DOMUtil.getChildValue(docElement, MAT_CLASS_ELEM_NAME);
      if (!StringUtils.isNullOrEmpty(classString)) {
         classType = MaterialClassificationType.fromString(classString);
      }
      return classType;
   }
}
