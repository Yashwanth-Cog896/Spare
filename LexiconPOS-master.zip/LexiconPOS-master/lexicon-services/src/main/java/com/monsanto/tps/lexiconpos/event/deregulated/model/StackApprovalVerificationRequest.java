package com.monsanto.tps.lexiconpos.event.deregulated.model;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexiconpos.event.deregulated.util.StackAbbrBuilder;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 20, 2006
 * Time: 3:28:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class StackApprovalVerificationRequest
{
   private final String cropName;
   private final String[] individualStacks;
   private final String[] stackedStacks;
   private final String countryPubkey;
   private final String[] subCountryKeys;

   public StackApprovalVerificationRequest(String cropName, String[] individualStacks, String countryPubkey, String subCountryPubkey)
   {
      this.cropName = cropName;
      this.individualStacks = individualStacks;
      this.countryPubkey = countryPubkey;
      this.stackedStacks = initStackedStacks();
      this.subCountryKeys = StringUtils.isNullOrEmpty(subCountryPubkey) ? new String[0] : new String[] {subCountryPubkey};
   }

   public String getCropName() {
      return cropName;
   }

   public String[] getIndividualStacks() {
      return individualStacks == null ? new String[0] : individualStacks;
   }

   public String[] getStackedStacks() {
      return stackedStacks == null ? new String[0] : stackedStacks;
   }

   public String getCountryPubkey() {
      return countryPubkey;
   }

   public String[] getSubCountryKeys() {
      return subCountryKeys;
   }

   private String[] initStackedStacks() {
      StackAbbrBuilder builder = new StackAbbrBuilder();
      return builder.getStackAbbrs(individualStacks);
   }
}
