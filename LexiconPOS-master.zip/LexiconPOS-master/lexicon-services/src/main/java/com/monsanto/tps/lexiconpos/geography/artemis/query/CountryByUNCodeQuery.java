/*
 CountryByUNCodeQuery was created on Nov 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.geography.artemis.query;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.dao.LexiconCountryPSRowImpl;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Nov 2, 2007 12:15:09 PM
 */
public class CountryByUNCodeQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final int unCode;

   public CountryByUNCodeQuery(int unCode) {
      this.unCode = unCode;
   }

   public LexiconCountry findCountry() {
      try {
         return (LexiconCountry) execute();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new LexiconCountryPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(LexiconSQL.class).getSQL(LexiconSQL.SELECT_COUNTRY_BY_UN_CODE);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { unCode };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}