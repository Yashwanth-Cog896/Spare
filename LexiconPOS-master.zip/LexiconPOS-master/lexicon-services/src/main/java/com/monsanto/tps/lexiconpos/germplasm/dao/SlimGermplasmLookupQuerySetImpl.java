/*
 SlimGermplasmLookupQuerySetImpl was created on Jan 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 30, 2007 10:21:15 AM
 */
public class SlimGermplasmLookupQuerySetImpl
   implements SlimGermplasmLookupQuerySet
{
   public SlimGermplasm[] findByOriginAndCropName(String origin, String cropName)
      throws WrappingException
   {
      SlimGermplasmsByCropNameAndOriginQuery query = new SlimGermplasmsByCropNameAndOriginQuery(origin, cropName);
      return query.getGermplasms();
   }

   public SlimGermplasm[] findByLineCodeAndCropName(String lineCode, String cropName
   )
      throws WrappingException
   {
      SlimGermplasmsByCropNameAndLineCodeQuery query = new SlimGermplasmsByCropNameAndLineCodeQuery(lineCode, cropName);
      return query.getGermplasms();
   }

   @Override
   public SlimGermplasm[] findByPedigreeAndCropName(String lineCode, String cropName)
      throws WrappingException
   {
      SlimGermplasmsByCropNameAndPedigreeQuery query = new SlimGermplasmsByCropNameAndPedigreeQuery(lineCode, cropName);
      return query.getGermplasms();
   }

   public SlimGermplasm[] findByProductPubkeyAndCropName(String productPubkey, String cropName
   )
      throws WrappingException
   {
      SlimGermplasmsByCropNameAndProdPubkeyQuery query = new SlimGermplasmsByCropNameAndProdPubkeyQuery(productPubkey, cropName);
      return query.getGermplasms();
   }
}