package com.monsanto.tps.lexiconpos.db.midas;

/**
 * nbwald - Jan 20, 2009 6:20:39 PM
 */
public class MidasBoolean
{
   private final String databaseRepresentation;
   private final boolean value;

   public MidasBoolean(boolean value) {
      this.databaseRepresentation = value ? "T" : "F";
      this.value = value;
   }

   public MidasBoolean(String databaseRepresentation) {
      this.databaseRepresentation = databaseRepresentation;
      this.value = "T".equals(databaseRepresentation);
   }

   public String getDatabaseRepresentation() {
      return databaseRepresentation;
   }

   public boolean getValue() {
      return value;
   }
}
