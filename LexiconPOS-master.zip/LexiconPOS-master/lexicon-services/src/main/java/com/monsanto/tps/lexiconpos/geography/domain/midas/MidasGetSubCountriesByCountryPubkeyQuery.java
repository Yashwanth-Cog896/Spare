package com.monsanto.tps.lexiconpos.geography.domain.midas;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Nov 7, 2006
 * Time: 1:59:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasGetSubCountriesByCountryPubkeyQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String countryPubkey;

   public MidasGetSubCountriesByCountryPubkeyQuery(String countryPubkey)
   {
      this.countryPubkey = countryPubkey;
   }

   public MidasSubCountry[] getSubCountriesByCountryPubkey() throws WrappingException
   {
      List list = (List) execute();
      return (MidasSubCountry[]) list.toArray(new MidasSubCountry[list.size()]);
   }

   protected String getSQL() throws WrappingException
   {
      return new SQLPropFile(MidasGeographicRegionQuerySQL.class).getSQL(
         MidasGeographicRegionQuerySQL.SELECT_SUB_COUNTRY_BY_COUNTRY_PUBKEY);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { countryPubkey };
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException
   {
      return new MidasSubCountryPSRowImpl(row);
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties()
   {
      return new MidasConnectionFactoryProperties();
   }
}
