package com.monsanto.tps.lexiconpos.event.deregulated.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Sep 29, 2006
 * Time: 1:53:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegulatoryAgencyByCountryPubkeyQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String countryPubkey;

   public RegulatoryAgencyByCountryPubkeyQuery(String countryPubkey) {
      this.countryPubkey = countryPubkey;
   }

   public RegulatoryAgency[] getAgencies()
      throws WrappingException
   {
      List regulatoryAgencies = getList();
      return (RegulatoryAgency[])regulatoryAgencies.toArray(new RegulatoryAgency[regulatoryAgencies.size()]);
   }

   protected String getSQL()
      throws WrappingException
   {
      return getSQLPropFile().getSQL(RegulatoryAgencySQL.REGULATORY_AGENCIES_BY_COUNTRY_PUBKEY_SQL);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { countryPubkey };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      long agencyID = row.getLong(getSQLPropFile().getAlias(RegulatoryAgencySQL.ALIAS_REGULATORY_AGENCY_ID));
      String agencyName = row.getString(getSQLPropFile().getAlias(RegulatoryAgencySQL.ALIAS_REGULATORY_AGENCY_NAME));
      return new RegulatoryAgencyDTO(agencyID, agencyName);
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(RegulatoryAgencySQL.class);
   }
}

