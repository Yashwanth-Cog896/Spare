package com.monsanto.tps.lexiconpos.geography;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 10:56:25 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GeographicEntity
{
}
