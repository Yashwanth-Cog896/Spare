/*
 SubsubcountryQuerySet was created on Jun 10, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tps.lexiconpos.geography.subsubcountry.query;

import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

/**
 * @author GGSHIV - Jun 10, 2008 3:39:26 PM
 */
public interface SubsubcountryQuerySet {

   LexiconCountry findCountryByISOCode(String countryISOCode);

   Subsubcountry[] findSubsubcountriesByWildcardableName(String countryPubkey, String wildcardableSubcountryName, String wildcardableSubsubcountryName);

   Subsubcountry[] findSubsubcountriesByAbbreviation(String countryPubkey, String[] subcountriesAbbreviation, String wildcardableSubsubcountryName);
}