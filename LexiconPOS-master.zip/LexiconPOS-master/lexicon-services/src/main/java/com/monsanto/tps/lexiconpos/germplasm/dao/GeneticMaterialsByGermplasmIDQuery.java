/*
 GeneticMaterialsByGermplasmIDQuery was created on Jan 22, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexiconpos.db.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.product.common.domain.midas.GeneticMaterial;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

import java.util.List;

/**
 * nbwald Jan 22, 2007 5:45:18 PM
 */
public class GeneticMaterialsByGermplasmIDQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final long germplasmID;

   public GeneticMaterialsByGermplasmIDQuery(long germplasmID) {
      this.germplasmID = germplasmID;
   }

   public GeneticMaterial[] getGeneticMaterial()
      throws WrappingException
   {
      List geneticMaterials = getList();
      return (GeneticMaterial[]) geneticMaterials.toArray(new GeneticMaterial[geneticMaterials.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new GeneticMaterialPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getSQL(MidasSQL.SELECT_GENETIC_MATERIAL_BY_GP_ID);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { new Long(germplasmID) };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

}