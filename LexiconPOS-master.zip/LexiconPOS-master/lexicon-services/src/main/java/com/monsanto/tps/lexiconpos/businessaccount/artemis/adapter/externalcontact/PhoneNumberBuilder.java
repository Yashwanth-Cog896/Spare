package com.monsanto.tps.lexiconpos.businessaccount.artemis.adapter.externalcontact;

import com.monsanto.tps.lexiconpos.externalcontact.domain.ird.ContactPhone;
import com.monsanto.tps.lexicon.contact.PhoneNumber;

/**
 * nbwald - Aug 1, 2008 12:27:52 PM
 */
public class PhoneNumberBuilder
{
   public PhoneNumber build(ContactPhone contactPhone) {
      PhoneNumber phoneNumber = new PhoneNumber();
      phoneNumber.setNumber(getPhoneNumber(contactPhone));
      return phoneNumber;
   }

   private String getPhoneNumber(ContactPhone contactPhone) {
      return contactPhone == null ? null : contactPhone.getPhoneNumber();
   }
}
