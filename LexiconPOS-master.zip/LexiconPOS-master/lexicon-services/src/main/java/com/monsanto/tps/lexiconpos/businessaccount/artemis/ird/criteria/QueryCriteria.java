package com.monsanto.tps.lexiconpos.businessaccount.artemis.ird.criteria;

import org.hibernate.criterion.Criterion;

/**
 * Filename:    AccountAddressCriteria.java
 * Last Change: rrchak1 On:	Jul 30, 2008
 *
 * @author: rrchak1
 */
public interface QueryCriteria {

    public Criterion getCriterion();

    public boolean hasCriteria();
}
