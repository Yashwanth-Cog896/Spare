package com.monsanto.tps.lexiconpos.event.deregulated.dao.eventcomltrait;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Oct 5, 2006
 * Time: 5:02:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class ComlTraitNotFoundException
   extends Exception
{
   public ComlTraitNotFoundException(String event) {
      super("Coml Trait not found for Event: " + event);
   }
}
