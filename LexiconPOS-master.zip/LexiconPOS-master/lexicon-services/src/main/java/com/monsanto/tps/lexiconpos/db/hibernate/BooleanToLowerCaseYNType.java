package com.monsanto.tps.lexiconpos.db.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.engine.jdbc.LobCreator;
import org.hibernate.engine.jdbc.NonContextualLobCreator;
import org.hibernate.type.AbstractStandardBasicType;
import org.hibernate.type.CharBooleanType;
import org.hibernate.type.descriptor.WrapperOptions;
import org.hibernate.type.descriptor.java.BooleanTypeDescriptor;
import org.hibernate.type.descriptor.sql.CharTypeDescriptor;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 28, 2009
 * Time: 12:22:39 PM
 */
public class BooleanToLowerCaseYNType
   extends AbstractStandardBasicType
{
    public BooleanToLowerCaseYNType() {
        super( CharTypeDescriptor.INSTANCE, new BooleanTypeDescriptor( 'y', 'n' ) );
    }

    public void nullSafeSet(PreparedStatement st, Object value, int index, boolean[] settable, SessionImplementor session) throws HibernateException, SQLException {
        super.nullSafeSet(st, value, index, NO_OPTIONS) ;
    }

    public String getName() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    private static WrapperOptions NO_OPTIONS = new WrapperOptions() {
        public boolean useStreamForLobBinding() {
            return false;
        }

        public LobCreator getLobCreator() {
            return NonContextualLobCreator.INSTANCE;
        }
    };
}
