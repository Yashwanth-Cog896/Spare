/*
 GermplasmSlimPSRowImpl was created on Jan 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexiconpos.germplasm.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tps.lexiconpos.db.midas.MidasSQL;
import com.monsanto.tps.lexiconpos.tps.linetype.LineTypeRef;
import com.monsanto.tps.lexiconpos.germplasm.model.SlimGermplasm;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Jan 29, 2007 12:39:56 PM
 */
public class SlimGermplasmPSRowImpl
   implements SlimGermplasm
{
   private final long germplasmID;
   private final String lineType;
   private final boolean finished;

   public SlimGermplasmPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.germplasmID = row.getLong(getAlias(MidasSQL.ALIAS_GP_ID));
      this.lineType = row.getString(getAlias(MidasSQL.ALIAS_LT_LINE_TYPE));
      this.finished = calculateFinished(row);
   }

   private boolean calculateFinished(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      boolean finishedFlag = "T".equalsIgnoreCase(row.getString(getAlias(MidasSQL.ALIAS_GP_FIN_FLAG)));
      return (LineTypeRef.HYBRID.equals(lineType)) ? finishedFlag : LineTypeRef.FINISHED.equals(lineType);
   }

   public long getGermplasmID() {
      return germplasmID;
   }

   public String getLineType() {
      return lineType;
   }

   public boolean isFinished() {
      return finished;
   }

   private String getAlias(String ident)
      throws WrappingException
   {
      return new SQLPropFile(MidasSQL.class).getAlias(ident);
   }
}