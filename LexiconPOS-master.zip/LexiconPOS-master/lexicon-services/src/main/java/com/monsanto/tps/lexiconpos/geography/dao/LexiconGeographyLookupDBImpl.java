package com.monsanto.tps.lexiconpos.geography.dao;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.WildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.monitor.MonitoredConnectionFactory;
import com.monsanto.tps.lexiconpos.db.lexicon.LexiconSQL;
import com.monsanto.tps.lexiconpos.geography.LexiconCountry;
import com.monsanto.tps.lexiconpos.geography.SubCountry;
import com.monsanto.tps.lexiconpos.geography.SubSubCountry;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;

import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 11, 2006
 * Time: 2:54:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconGeographyLookupDBImpl
   implements LexiconGeographyLookup,
   LexiconSQL
{
   public LexiconCountry[] getCountriesByName(String wildcardableName, PersistentStoreConnection lexConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_COUNTRY_BY_WCNAME);
      WildcardableCriteria criteria = new StdWildcardableCriteria(wildcardableName);
      PersistentStoreStatement stmt = lexConn.prepareStatement(sql);
      try {
         stmt.setParam(1, criteria.oracleVersion());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         ArrayList countries = new ArrayList();
         while (iter.next()) {
            countries.add(new LexiconCountryPSRowImpl(iter));
         }
         return (LexiconCountry[])countries.toArray(new LexiconCountry[countries.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public LexiconCountry[] getCountriesByUNCode(String unCode)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_COUNTRY_BY_ABBR);
      PersistentStoreStatement stmt = getLexConn().prepareStatement(sql);
      try {
         stmt.setParam(1, unCode);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         ArrayList countries = new ArrayList();
         while (iter.next()) {
            countries.add(new LexiconCountryPSRowImpl(iter));
         }
         return (LexiconCountry[])countries.toArray(new LexiconCountry[countries.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public LexiconCountry[] getCountryByPubKey(String pubKey, PersistentStoreConnection lexConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_COUNTRY_BY_PUBKEY);
      PersistentStoreStatement stmt = lexConn.prepareStatement(sql);
      try {
         stmt.setParam(1, pubKey);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         ArrayList countries = new ArrayList();
         while (iter.next()) {
            countries.add(new LexiconCountryPSRowImpl(iter));
         }
         return (LexiconCountry[])countries.toArray(new LexiconCountry[countries.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public SubCountry[] getSubCountriesByName(long countryID, String wildcardableName,
      PersistentStoreConnection midasConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_SUBCOUNTRY_BY_WCNAME);
      WildcardableCriteria criteria = new StdWildcardableCriteria(wildcardableName);
      PersistentStoreStatement stmt = midasConn.prepareStatement(sql);
      try {
         stmt.setParam(1, countryID);
         stmt.setParam(2, criteria.oracleVersion());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         ArrayList subCountries = new ArrayList();
         while (iter.next()) {
            subCountries.add(new SubCountryPSRowImpl(iter));
         }
         return (SubCountry[])subCountries.toArray(new SubCountry[subCountries.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public SubCountry[] getSubCountriesByAbbr(long countryID, String subCountryAbbr,
      PersistentStoreConnection midasConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_SUBCOUNTRY_BY_ABBR);
      PersistentStoreStatement stmt = midasConn.prepareStatement(sql);
      try {
         stmt.setParam(1, countryID);
         stmt.setParam(2, subCountryAbbr);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         ArrayList subCountries = new ArrayList();
         while (iter.next()) {
            subCountries.add(new SubCountryPSRowImpl(iter));
         }
         return (SubCountry[])subCountries.toArray(new SubCountry[subCountries.size()]);
      }
      finally {
         stmt.close();
      }
   }

   public SubSubCountry[] getSubSubCountriesByName(long subCountryID, String wildcardableName,
      PersistentStoreConnection midasConn)
      throws WrappingException
   {
      String sql = getSQLPropFile().getSQL(SELECT_SUBSUBCOUNTRY_BY_WCNAME);
      WildcardableCriteria criteria = new StdWildcardableCriteria(wildcardableName);
      PersistentStoreStatement stmt = midasConn.prepareStatement(sql);
      try {
         stmt.setParam(1, subCountryID);
         stmt.setParam(2, criteria.oracleVersion());
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         ArrayList subSubCountries = new ArrayList();
         while (iter.next()) {
            subSubCountries.add(new SubSubCountryPSRowImpl(iter));
         }
         return (SubSubCountry[])subSubCountries.toArray(new SubSubCountry[subSubCountries.size()]);
      }
      finally {
         stmt.close();
      }
   }

   private SQLPropFile getSQLPropFile() {
      return new SQLPropFile(LexiconSQL.class);
   }

   private PersistentStoreConnection getLexConn()
      throws WrappingException
   {
      MonitoredConnectionFactory factory = new MonitoredConnectionFactory(new LexiconConnectionFactoryProperties());
      return factory.getConnection();
   }
}
