package com.monsanto.tps.automation.serviceClient;

import org.springframework.ws.client.core.WebServiceTemplate;

import javax.annotation.Resource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * Created with IntelliJ IDEA.
 * User: HTRIP
 * Date: 7/3/14
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class WebServiceClient {

    @Resource
    private WebServiceTemplate webServiceTemplate;

    String defaultUri;

    public void setWebServiceTemplate(WebServiceTemplate webServiceTemplate) {
        this.webServiceTemplate = webServiceTemplate;
    }

    // send to an explicit URI
    public String customSendAndReceive(String automationName, String automationEnvironment, String userId) {

        String MESSAGE = "<OnDemandInsertExternalAutomationTest xmlns=\"http://tempuri.org/CertifyCustomService/CertifyCustomService\">\n" +
                "      <AutomationName>" + automationName + "</AutomationName>\n" +
                "      <AutomationEnvironment>" + automationEnvironment + "</AutomationEnvironment>\n" +
                "      <AutomationRunUser>" + userId + "</AutomationRunUser>\n" +
                "    </OnDemandInsertExternalAutomationTest>";

        StreamSource source = new StreamSource(new StringReader(MESSAGE));
        StringWriter writer = new StringWriter();
        StreamResult result = new StreamResult(writer);

        webServiceTemplate.sendSourceAndReceiveToResult("http://tpstestmrc34/WebServices/CertifyCustomService/CertifyCustomService.asmx", source, result);

        StringWriter sw = (StringWriter) result.getWriter();
        StringBuffer sb = sw.getBuffer();
        String finalstring = sb.toString();
        return finalstring;
    }

}
