package com.tps.automation;

import com.monsanto.tps.automation.serviceClient.WebServiceClient;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.StringReader;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

/**
 * Created with IntelliJ IDEA.
 * User: HTRIP
 * Date: 7/4/14
 * Time: 2:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class WebServiceClient_UT {

    @Test
    public void testCustomSendAndReceive() throws Exception {
        WebServiceClient webServiceClient = new WebServiceClient();
        WebServiceTemplate webServiceTemplate = mock(WebServiceTemplate.class);
        webServiceClient.setWebServiceTemplate(webServiceTemplate);
        doReturn(true).when(webServiceTemplate).sendSourceAndReceiveToResult(anyString(), Matchers.<StreamSource>any(), Matchers.<StreamResult>any());
        String result = webServiceClient.customSendAndReceive(anyString(), anyString(), anyString());
        verify(webServiceTemplate) .sendSourceAndReceiveToResult(anyString(), Matchers.<StreamSource>any(), Matchers.<StreamResult>any());
    }
}
