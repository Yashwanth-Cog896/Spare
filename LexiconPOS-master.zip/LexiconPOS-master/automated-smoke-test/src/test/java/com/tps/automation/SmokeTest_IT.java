package com.tps.automation;

/**
 * Created with IntelliJ IDEA.
 * User: HTRIP
 * Date: 7/2/14
 * Time: 12:24 PM
 * To change this template use File | Settings | File Templates.
 */

import com.monsanto.tps.automation.serviceClient.WebServiceClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;

/**
 * Temporary test to see if we can hit the Smoke web service from TeamCity
 */


public class SmokeTest_IT {

    @Test(timeout = 1800000L)
    public void smokeTestCall() throws Exception {
        String CONTEXT_FILE = "test-spring-beans.xml";
        ApplicationContext context = new ClassPathXmlApplicationContext(CONTEXT_FILE);
        WebServiceClient webServiceClient = new WebServiceClient();
        WebServiceTemplate webServiceTemplate = (WebServiceTemplate) context.getBean("webServiceTemplate");
        webServiceClient.setWebServiceTemplate(webServiceTemplate);
        String result = webServiceClient.customSendAndReceive("TCLX","Dev", "HTRIP");
        Assert.assertTrue(result.contains("Pass"));
    }
}
