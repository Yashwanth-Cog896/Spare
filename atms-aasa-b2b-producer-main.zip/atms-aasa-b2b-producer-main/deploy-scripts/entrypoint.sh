#!/usr/bin/bash
export VAULT_ADDR="https://vault.agro.services"
echo "Running on: $ENVIRONMENT"

 CONFIG_FILE="";
 all_key_values=$()
 if [ $ENVIRONMENT = "np" ]; then
     CONFIG_FILE="variables-np.json"
     echo "Getting credentials for non prod"

 else
     CONFIG_FILE="variables-prod.json"
     echo "Getting credentials for prod"
 fi

appName=$(jq --raw-output '.appname' "$CONFIG_FILE")


add_to_array(){
  all_key_values="$all_key_values $1"
}

 vaultRole=$(jq --raw-output '.vaultrole' "$CONFIG_FILE")
 /usr/app/vault login -method=aws role="$vaultRole"


 for VAULT_APP_PATH in $(jq --raw-output '.vaultarray[]' "$CONFIG_FILE"); do
   echo Paths: "$VAULT_APP_PATH"
   VAULT_RESPONSE=$(/usr/app/vault read -format=json "$VAULT_APP_PATH")
   VAULT_PAIRS=$(echo "$VAULT_RESPONSE" | jq ".data" | sed 's/ //g')

    POSTGRES_USER=$(echo "$VAULT_PAIRS" | jq ".pg_username" | sed 's/"//g')
    if  [ "$POSTGRES_USER" != "null" ]; then
		  add_to_array "PG_USERNAME=$POSTGRES_USER"
    fi

    POSTGRES_TOKEN=$(echo "$VAULT_PAIRS" | jq ".pg_password" | sed 's/"//g')
    if  [ "$POSTGRES_TOKEN" != "null" ]; then
	    add_to_array "POSTGRES_TOKEN=$POSTGRES_TOKEN"
    fi

    POSTGRES_ENDPOINT=$(echo "$VAULT_PAIRS" | jq ".pg_endpoint" | sed 's/"//g')
    if  [ "$POSTGRES_ENDPOINT" != "null" ]; then
	     add_to_array "POSTGRES_ENDPOINT=$POSTGRES_ENDPOINT"
    fi

    TRUST_KEY_PASS=$(echo "$VAULT_PAIRS" | jq ".trust_key_pass" | sed 's/"//g')
    if  [ "$TRUST_KEY_PASS" != "null" ]; then
	    add_to_array "TRUST_KEY_PASS=$TRUST_KEY_PASS"
    fi
    PG_PORT=$(echo "$VAULT_PAIRS" | jq ".pg_port" | sed 's/"//g')
    if  [ "$PG_PORT" != "null" ]; then
      add_to_array "PG_PORT=$PG_PORT"
    fi

    PG_DB=$(echo "$VAULT_PAIRS" | jq ".pg_dev_db" | sed 's/"//g')
    if  [ "$PG_DB" != "null" ]; then
      add_to_array "PG_DB=$PG_DB"
    fi

    ASMARK_JWT=$(echo "$VAULT_PAIRS" | jq ".asmark_jwt" | sed 's/"//g')
    if  [ "$ASMARK_JWT" != "null" ]; then
      add_to_array "ASMARK_JWT=$ASMARK_JWT"
    fi

    ASMARK_TOKEN=$(echo "$VAULT_PAIRS" | jq ".asmark_password" | sed 's/"//g')
    if  [ "$ASMARK_TOKEN" != "null" ]; then
      add_to_array "ASMARK_TOKEN=$ASMARK_TOKEN"
    fi

    ASMARK_URL=$(echo "$VAULT_PAIRS" | jq ".asmark_url" | sed 's/"//g')
    if  [ "$ASMARK_URL" != "null" ]; then
      add_to_array "ASMARK_URL=$ASMARK_URL"
    fi
    ASMARK_USERNAME=$(echo "$VAULT_PAIRS" | jq ".asmark_username" | sed 's/"//g')
    if  [ "$ASMARK_USERNAME" != "null" ]; then
      add_to_array "ASMARK_USERNAME=$ASMARK_USERNAME"
    fi
 done
for tokens in $all_key_values; do
	export "$tokens"
done
java -jar -Dspring.profiles.active=$ENVIRONMENT atms-aasa-producer.jar --server.port=80


