const { execSync } = require('child_process')
const packageJSON = require('./package.json')

const gitCommand = 'git rev-parse HEAD'
const gitCommitHash = execSync(gitCommand).toString().trim()

module.exports = {
    appParameters: {
        Cpu: '2048',
        Memory: '4GB',
        AppName: 'atms-aasa-b2b-producer',
        InstanceCount: 1,
        HealthCheckPath: '/actuator/health',
        TaskRoleName: 'fargateappexecrole',
        environmentVars: {
            IS_FARGATE: true,
            ENVIRONMENT: 'prod',
            // VCAP_SERVICES: '{   \"user-provided\": [    {     \"binding_name\": null,     \"credentials\": {      \"alias\": \"phoenix-home\",      \"value\": \"phoenix-tools-np.io\"     },     \"instance_name\": \"phoenix-home\",     \"label\": \"user-provided\",     \"name\": \"phoenix-home\",     \"syslog_drain_url\": \"\",     \"tags\": [],     \"volume_mounts\": []    },    {     \"binding_name\": null,     \"credentials\": {      \"alias\": \"offloading-api\",      \"url\": \"https://offloading-api-t.velocity-np.ag/offloading-api-app/\"     },     \"instance_name\": \"offloading-api-test\",     \"label\": \"user-provided\",     \"name\": \"offloading-api-test\",     \"syslog_drain_url\": \"\",     \"tags\": [],     \"volume_mounts\": []    },{     \"binding_name\": null,     \"credentials\": { },     \"instance_name\": \"syslog\",     \"label\": \"user-provided\",     \"name\": \"syslog\",     \"syslog_drain_url\": \"syslog://cflog.cloudops.local:5000\",     \"tags\": [],     \"volume_mounts\": []    }  ]  }'
        },
        port: 80,
        timeoutInSeconds: 500
    },
    aws: {
        accountId: '511591395876',
        fargateStackName: 'SC-511591395876-pp-fvg63uwfmcmso',
        region: 'us-east-1'
    },
    docker: {
        file: 'Dockerfile',
        tags: [packageJSON.version, gitCommitHash],
    },
    'autoScaling': {
        'enabled': true,
        'maxInstances': 6,
        'scalingPolicies': [
            {
                'scaleBy': 'CPU',
                'targetValue': 75,
                'scaleInCooldown': 600,
                'scaleOutCooldown': 60
            },
            {
                'scaleBy': 'Memory',
                'targetValue': 75,
                'scaleInCooldown': 600,
                'scaleOutCooldown': 60
            },
            {
                'scaleBy': 'RequestCount',
                'targetValue': 200,
                'scaleInCooldown': 600,
                'scaleOutCooldown': 60
            }
        ]
    }
}
