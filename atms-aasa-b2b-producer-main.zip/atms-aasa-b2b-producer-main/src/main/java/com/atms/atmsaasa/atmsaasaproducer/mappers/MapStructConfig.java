package com.atms.atmsaasa.atmsaasaproducer.mappers;

import org.mapstruct.MapperConfig;

@MapperConfig(componentModel = "spring")
public interface MapStructConfig {
}