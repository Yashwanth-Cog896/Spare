package com.atms.atmsaasa.atmsaasaproducer.controllers;

import com.atms.atmsaasa.atmsaasaproducer.dto.ResponseDto;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalException;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.InvalidRequestParameterException;
import com.atms.atmsaasa.atmsaasaproducer.mappers.EntityMappers;
import com.atms.atmsaasa.atmsaasaproducer.service.ProducerService;
import com.atms.atmsaasa.avroschema.*;
import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@Slf4j
@RestController
public class ProducerController {
    ProducerService producerService;

    @Value("${spring.kafka.topic.inspections}")
    private String inspectionsTopic;

    @Value("${external.api.url}")
    private String url;


    private String password;

    @Value("${external.api.jwt}")
    private String jwt;



    private RestTemplate restTemplate;

    private EntityMappers entityMappers;

    public ProducerController(ProducerService producerService, RestTemplate restTemplate, EntityMappers entityMappers){
        this.producerService = producerService;
        this.restTemplate = restTemplate;
        this.entityMappers = entityMappers;

    }
    @PostMapping(value = "/produceInspections", headers = "Accept=application/json")
    public CompletableFuture<ResponseDto> produceInspections(@RequestBody List<InspectionDto> message) throws FunctionalException {

        List<Inspections> inspections = new ArrayList<>();
        for(InspectionDto inspectionDto : message) {

            Set<String> siteIds = new HashSet<>();

            if (!inspectionDto.getMfrSiteIds().isEmpty()){
                siteIds.addAll(inspectionDto.getMfrSiteIds());
            }
            inspectionDto.setMfrSiteIds(new ArrayList<>(siteIds));
            Inspections inspection = entityMappers.mapToInspection(inspectionDto);
            inspections.add(inspection);
        }
        return producerService.sendMessage(inspectionsTopic, inspections);
    }

    @GetMapping(value = "/getInspections", headers = "Accept=application/json")
    @Operation(
            summary = "Fetch and produce inspections",
            description = "Fetches inspections from the external API using the provided filters and produces them to Kafka."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Inspections fetched and produced successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameter")
    })
    public CompletableFuture<ResponseDto> getInspections(
            @Parameter(
                    description = "Only fetch inspections confirmed after this ISO date-time. If omitted, the default is the last 2 weeks.",
                    example = "2024-01-15T10:30:00",
                    schema = @Schema(type = "string", format = "date-time")
            )
            @RequestParam(value = "confirmedAfter", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime confirmedAfter,
            @Parameter(description = "Pagination offset. Must be 0 or greater.", example = "0")
            @RequestParam(value = "skip", defaultValue = "0") int skip,
            @Parameter(description = "Page size. Must be greater than 0.", example = "50")
            @RequestParam(value = "limit", defaultValue = "50") int limit) throws FunctionalException {

        if (skip < 0) {
            throw new InvalidRequestParameterException("skip must be greater than or equal to 0");
        }
        if (limit <= 0) {
            throw new InvalidRequestParameterException("limit must be greater than 0");
        }

        LocalDateTime confirmedAfterDate = confirmedAfter != null ? confirmedAfter : LocalDateTime.now().minusWeeks(2);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(jwt);
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        List<Inspections> inspections = new ArrayList<>();

        while (true) {

            String urlWithParam = UriComponentsBuilder.fromHttpUrl(url)
                    .queryParam("confirmedAfter", confirmedAfterDate)
                    .queryParam("skip", skip)
                    .queryParam("limit", limit)
                    .toUriString();


            log.info("Calling URL: {} | skip={} | limit={}", urlWithParam, skip, limit);

            ResponseEntity<List<InspectionDto>> responseEntity = restTemplate.exchange(
                    urlWithParam,
                    HttpMethod.GET,
                    requestEntity,
                    new ParameterizedTypeReference<>() {
                    });

            if (responseEntity.getBody() == null || responseEntity.getBody().isEmpty()) {
                break;
            }
            for (InspectionDto inspectionDto : Objects.requireNonNull(responseEntity.getBody())) {
                Inspections inspection = entityMappers.mapToInspection(inspectionDto);
                inspections.add(inspection);
            }


            skip += limit;

            if (responseEntity.getBody().size() < limit) {
                break;
            }
        }
            return producerService.sendMessage(inspectionsTopic, inspections);
        
    }

}
