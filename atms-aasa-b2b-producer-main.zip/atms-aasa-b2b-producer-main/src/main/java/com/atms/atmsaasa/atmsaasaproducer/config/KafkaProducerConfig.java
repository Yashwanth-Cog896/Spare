package com.atms.atmsaasa.atmsaasaproducer.config;

import com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalException;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
public class KafkaProducerConfig {


    @Value("${spring.kafka.consumer.bootstrap-servers}")
    private String BOOT_STRAP_SERVER;

    @Value("${spring.kafka.properties.schema.registry.url}")
    private String SCHEMA_REGISTRY;


    @Value("${spring.kafka.properties.ssl.key-store-location}")
    private String KEYSTORE;

    @Value("${spring.kafka.properties.ssl.key-store-password}")
    private String KEYSTORE_PASSWORD;

    @Value("${spring.kafka.properties.ssl.trust-store-location}")
    private String TRUSTSTORE;

    @Value("${spring.kafka.properties.ssl.trust-store-password}")
    private String TRUSTSTORE_PASSWORD;


    @Bean
    public ProducerFactory<Object, Object> producerFactory() throws FunctionalException {

        Map<String, Object> props = new HashMap<>();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,BOOT_STRAP_SERVER);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName());
        props.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG, SCHEMA_REGISTRY);
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, TRUSTSTORE);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,TRUSTSTORE_PASSWORD);
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, KEYSTORE);
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,KEYSTORE_PASSWORD);
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        // Schema compatibility and versioning settings
        props.put("value.subject.name.strategy", "io.confluent.kafka.serializers.subject.TopicRecordNameStrategy");
        props.put("use.latest.version", true);
        props.put("schema.registry.value.subject.name.strategy", "io.confluent.kafka.serializers.subject.TopicRecordNameStrategy");

        return new DefaultKafkaProducerFactory<>(props);
    }

    public KafkaTemplate<Object, Object> kafkaTemplate(){
        return new KafkaTemplate<>(producerFactory());
    }

}
