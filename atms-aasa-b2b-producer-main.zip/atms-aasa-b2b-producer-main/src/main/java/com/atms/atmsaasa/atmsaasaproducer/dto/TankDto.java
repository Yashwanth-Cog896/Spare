package com.atms.atmsaasa.atmsaasaproducer.dto;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Data
public class TankDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private long id;
    private String containment;
    private long containmentId;
    private long number;
    private String type;
    private String shape;
    private long capacity;
    private String product;
    private long displacement;
    private String productId;
    private String measurements;
    private List<QuestionDto> questions;
    private List<PhotosDto> photos;
}
