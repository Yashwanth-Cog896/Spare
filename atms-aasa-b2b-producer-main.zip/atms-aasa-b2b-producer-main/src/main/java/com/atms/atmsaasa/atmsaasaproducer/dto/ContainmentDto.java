package com.atms.atmsaasa.atmsaasaproducer.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ContainmentDto implements Serializable {
    public static final long serialVersionUID = 1L;

    private long id;
    private long number;
    private String type;
    private String shape;
    private String name;
    private long capacity;
    private long netCapacity;
    private long maxTankSize;
    private String measurements;
    private Boolean isBuilding = Boolean.FALSE;
    private List<PhotosDto> photos;
    private List<QuestionDto> questions;

}