package com.atms.atmsaasa.atmsaasaproducer.utils;


import com.atms.atmsaasa.atmsaasaproducer.exceptions.NullFieldException;
import org.apache.avro.Schema;
import org.apache.avro.Schema.Type;
import org.apache.avro.generic.GenericRecord;
import org.springframework.stereotype.Component;

@Component
public class AvroUtils {

    public void checkNullableFields(GenericRecord genericRecord){
        Schema schema = genericRecord.getSchema();
        for (Schema.Field field: schema.getFields()){
            if (!isNullable(field.schema())){
                Object value = genericRecord.get(field.name());
                if (value == null){
                    throw new NullFieldException(field.name());
                }
            }
        }
    }

    private static boolean isNullable(Schema schema) {
        if (schema.getType() == Type.UNION){
            for (Schema type : schema.getTypes()){
                if (type.getType() == Type.NULL){
                    return  true;
                }
            }
        }
        return false;
    }
}