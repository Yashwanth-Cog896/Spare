package com.atms.atmsaasa.atmsaasaproducer.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class ResponseDto implements Serializable {
    private String traceId;
    private String createdAt;
    private String status;
}
