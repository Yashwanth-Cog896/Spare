package com.atms.atmsaasa.model;

import com.atms.atmsaasa.avroschema.Inspections;

import java.util.List;

public class Response {
    private int limit;
    private int start;
    private int size;
    private List<Inspections> data;
    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public List<Inspections> getData() {
        return data;
    }

    public void setData(List<Inspections> data) {
        this.data = data;
    }

}
