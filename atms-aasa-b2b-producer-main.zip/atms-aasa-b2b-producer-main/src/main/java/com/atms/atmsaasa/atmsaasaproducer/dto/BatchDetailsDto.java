package com.atms.atmsaasa.atmsaasaproducer.dto;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class BatchDetailsDto implements Serializable {
    private String batchId;
    private long createdAt;
}