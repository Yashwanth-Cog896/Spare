package com.atms.atmsaasa.atmsaasaproducer.exceptions;

import static com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalErrorCode.INVALID_REQUEST_PARAMETER;

public class InvalidRequestParameterException extends FunctionalException {

    private static final long serialVersionUID = 1L;

    public InvalidRequestParameterException(String parameterMessage) {
        super(INVALID_REQUEST_PARAMETER, parameterMessage);
    }
}

