package com.atms.atmsaasa.atmsaasaproducer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class PhotosDto implements Serializable {
    public static final long serialVersionUID = 1L;

    @JsonProperty("question_id")
    private String questionId;
    private String url;
}
