package com.atms.atmsaasa.atmsaasaproducer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {


    @Bean
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }


//    @Bean
//    public RestTemplate restTemplate() {
//        TrustManager[] trustAllCertificates = new TrustManager[]{
//                new X509TrustManager() {
//                    public X509Certificate[] getAcceptedIssuers() {
//                        return null;
//                    }
//
//                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
//                    }
//
//                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
//                    }
//                }
//        };
//
//        try {
//            SSLContext sslContext = SSLContext.getInstance("SSL");
//            sslContext.init(null, trustAllCertificates, new java.security.SecureRandom());
//            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
//        } catch (Exception e) {
//            throw new RuntimeException("Failed to initialize SSL context", e);
//        }
//        String proxyParam = System.getenv("http_proxy");
//        if(StringUtils.isNotEmpty(proxyParam)) {
//            String[] str = proxyParam.split(":");
//            String host = str[2].split("@")[1];
//            int port = Integer.parseInt(str[3]);
//            Authenticator.setDefault(new Authenticator() {
//                String username = str[1].substring(2);
//                String password = str[2].split("@")[0];
//
//                protected PasswordAuthentication getPasswordAuthenticator() {
//                    return new PasswordAuthentication(username, password.toCharArray());
//                }
//            });
//
//            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
//            requestFactory.setBufferRequestBody(false);
//            requestFactory.setOutputStreaming(false);
//            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port));
//            requestFactory.setProxy(proxy);
//
//            return new RestTemplate(requestFactory);
//        }
//        return null;
//    }

}
