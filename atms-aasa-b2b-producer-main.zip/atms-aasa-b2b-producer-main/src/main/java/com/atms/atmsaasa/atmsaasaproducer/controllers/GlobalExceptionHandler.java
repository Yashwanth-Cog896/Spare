package com.atms.atmsaasa.atmsaasaproducer.controllers;

import com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalErrorCode;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalException;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.errors.SerializationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.ZonedDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {


    private static HttpHeaders genericHeader = new HttpHeaders();

    static {
        genericHeader.setContentType(MediaType.APPLICATION_JSON);
    }

    @ExceptionHandler(FunctionalException.class)
    public ResponseEntity<Object> handleFunctionalExceptions(FunctionalException ex){

        return new ResponseEntity<>(getBody(ex.getErrorCode().getHttpStatus(), ex, ex.getMessage(), ex.getErrorCode().getCode()), genericHeader, ex.getErrorCode().getHttpStatus());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> httpMessageNotReadable(HttpMessageNotReadableException ex){
        return new ResponseEntity<>(getBody(HttpStatus.BAD_REQUEST, ex, FunctionalErrorCode.INVALID_JSON.getMessageTemplate() +" : "+ ex.getMessage(), FunctionalErrorCode.INVALID_JSON.getCode()), genericHeader, HttpStatus.BAD_REQUEST);

    }
    @ExceptionHandler(SerializationException.class)
    public ResponseEntity<Object> httpMessageNotReadable(SerializationException ex){
        return new ResponseEntity<>(getBody(HttpStatus.BAD_REQUEST, ex, FunctionalErrorCode.INVALID_SCHEMA.getMessageTemplate()+" : "+ ex.getMessage(), FunctionalErrorCode.INVALID_SCHEMA.getCode()), genericHeader, HttpStatus.BAD_REQUEST);

    }


    public Map<String, Object> getBody (HttpStatus status, Exception ex, String message, String errorCode){

        log.error(message, ex);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", message);
        body.put("timestamp", ZonedDateTime.now());
        body.put("status", status.value());
        body.put("error", status.getReasonPhrase());
        body.put("errorCode", errorCode);
        return body;
    }

}