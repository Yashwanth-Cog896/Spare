package com.atms.atmsaasa.atmsaasaproducer.exceptions;


import static com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalErrorCode.INVALID_SCHEMA;

public class InvalidSchemaType extends FunctionalException{


    private static final long serialVersionUID = 1L;

    public InvalidSchemaType(String message) {super(INVALID_SCHEMA,message);
    }
}