package com.atms.atmsaasa.atmsaasaproducer.dto;


import lombok.Data;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

@Data
public class InspectionDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private long id;
    private Long siteId;
    private Long ebid;
    private String epaEstNo;
    private List<String> mfrSiteIds;
    private String scheduledAt;
    private String inspectedAt;
    private String confirmedAt;
    private String siteName;
    private String address;
    private String city;
    private String state;
    private String zip;
    private List<PhotosDto> photos;
    private List<QuestionDto> questions;
    private List<ContainmentDto> containments;
    private List<TankDto> tanks;
    private String siteMap;
    BatchDetailsDto batchDetails;


}