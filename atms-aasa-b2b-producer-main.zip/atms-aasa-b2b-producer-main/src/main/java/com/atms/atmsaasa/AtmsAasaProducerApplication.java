package com.atms.atmsaasa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

@EnableKafka
@EnableAsync
@SpringBootApplication
@EnableScheduling
public class AtmsAasaProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtmsAasaProducerApplication.class, args);
	}

	private static final int MAX_POOL_SIZE = 10000;
	private static final int CORE_POOL_SIZE = 200;
	private static final int QUEUE_CAPACITY = 10000;

	@Bean
	public ThreadPoolTaskExecutor taskExecutor(){
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setMaxPoolSize(MAX_POOL_SIZE);
		executor.setCorePoolSize(CORE_POOL_SIZE);
		executor.setQueueCapacity(QUEUE_CAPACITY);
		executor.setThreadNamePrefix("atms-aasa-");
		executor.initialize();
		return executor;
	}


}
