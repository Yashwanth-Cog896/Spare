package com.atms.atmsaasa.atmsaasaproducer.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QuestionDto{

    private String id;
    private String response;
    private String category;
}
