package com.atms.atmsaasa.atmsaasaproducer.mappers;


import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import com.atms.atmsaasa.avroschema.Inspections;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

@Mapper(config = MapStructConfig.class)
public interface EntityMappers {

    @Mapping(target = "scheduledAt", source = "scheduledAt", qualifiedByName = "mapStringToCharSequence")
    @Mapping(target = "inspectedAt", source = "inspectedAt", qualifiedByName = "mapStringToCharSequence")
    @Mapping(target = "confirmedAt", source = "confirmedAt", qualifiedByName = "mapStringToCharSequence")
    @Mapping(target = "mfrSiteIds", source = "mfrSiteIds", defaultExpression = "java(new String[0])")
    Inspections mapToInspection(InspectionDto inspections);


    @Named("mapStringToCharSequence")
    default CharSequence mapStringToCharSequence(String val){
        return val;
    }

    @Named("parseDateFormat")
    default Instant convertToTimeStamp(String dateTimeString) {
        return parseDateFormat(dateTimeString);
    }
    default Instant parseDateFormat(String date){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        if (date.contains(".")){
            date = date.substring(0, date.indexOf("."));
        }

        try{
            LocalDateTime dateTime = LocalDateTime.parse(date, formatter);
            return dateTime.toInstant(ZoneOffset.UTC);
        } catch (DateTimeException e) {
            throw new IllegalArgumentException("Invalid date format: " + date, e);
        }
    }
}