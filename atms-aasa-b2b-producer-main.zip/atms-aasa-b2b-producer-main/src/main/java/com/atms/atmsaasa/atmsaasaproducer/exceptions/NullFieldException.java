package com.atms.atmsaasa.atmsaasaproducer.exceptions;

import static com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalErrorCode.NULL_FIELD_EXCEPTION;

public class NullFieldException extends FunctionalException{


    private static final long serialVersionUID = 1L;

    public NullFieldException(final  String field) {
        super(NULL_FIELD_EXCEPTION, field);
    }
}