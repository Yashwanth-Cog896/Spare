package com.atms.atmsaasa.atmsaasaproducer.exceptions;

import static java.lang.String.format;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public enum FunctionalErrorCode {



      INVALID_SCHEMA(1, HttpStatus.BAD_REQUEST, "Invalid Schema"),
      NULL_FIELD_EXCEPTION(2, HttpStatus.BAD_REQUEST, "Missing Field: %s"),
      INVALID_JSON(3, HttpStatus.BAD_REQUEST, "Invalid Json"),
      INVALID_REQUEST_PARAMETER(4, HttpStatus.BAD_REQUEST, "Invalid request parameter: %s");


    private final String code;
    private final HttpStatus httpStatus;
    private final String messageTemplate;


    FunctionalErrorCode(int code, HttpStatus httpStatus, String messageTemplate) {
        this.code = format("%03d", code);
        this.httpStatus = httpStatus;
        this.messageTemplate = messageTemplate;
    }
}