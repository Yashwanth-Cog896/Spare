package com.atms.atmsaasa.atmsaasaproducer.service;

import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import com.atms.atmsaasa.atmsaasaproducer.dto.ResponseDto;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.FunctionalException;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.InvalidSchemaType;
import com.atms.atmsaasa.atmsaasaproducer.mappers.EntityMappers;
import com.atms.atmsaasa.atmsaasaproducer.utils.AvroUtils;
import com.atms.atmsaasa.avroschema.BatchDetails;
import com.atms.atmsaasa.avroschema.Inspections;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class ProducerService {

    private final AvroUtils avroUtils;

    private final KafkaTemplate<Object, Object> kafkaTemplate;

    private RestTemplate restTemplate;
    @Value("${external.api.url}")
    private String url;

    @Value("${external.api.jwt}")
    private String jwt;

    @Value("${spring.kafka.topic.inspections}")
    private String inspectionsTopic;

    private EntityMappers entityMappers;

    public ProducerService(AvroUtils avroUtils, KafkaTemplate<Object, Object> kafkaTemplate, RestTemplate restTemplate,EntityMappers entityMappers) {
        this.avroUtils = avroUtils;
        this.kafkaTemplate = kafkaTemplate;
        this.restTemplate = restTemplate;
        this.entityMappers = entityMappers;
    }

    @Async("taskExecutor")
    public CompletableFuture<ResponseDto> sendMessage(String topicName, List<Inspections> data) throws FunctionalException {
        BatchDetails details = new BatchDetails();
        details.setCreatedAt(String.valueOf(Instant.now().toEpochMilli()));
        details.setTraceId(UUID.randomUUID().toString());

        for (int i = 0; i < data.size(); i++) {
            Inspections inspection = data.get(i);
            inspection.setBatchDetails(details);

            // Ensure all nullable fields are initialized for schema compatibility
            if (inspection.getPhotos() == null) {
                inspection.setPhotos(new ArrayList<>());
            }
            if (inspection.getQuestions() == null) {
                inspection.setQuestions(new ArrayList<>());
            }
            if (inspection.getContainments() == null) {
                inspection.setContainments(new ArrayList<>());
            }
            if (inspection.getTanks() == null) {
                inspection.setTanks(new ArrayList<>());
            }
        }

        convertObject(topicName, data);

        var response = ResponseDto.builder().traceId(details.getTraceId().toString()).status("Message produced successfully")
                .createdAt(String.valueOf(Instant.now().toEpochMilli())).build();
        return CompletableFuture.completedFuture(response);

    }
    private void convertObject(String topicName, List<?> data) {
        for (Object item : data) {
            GenericRecord genericRecord = (GenericRecord) item;
            avroUtils.checkNullableFields(genericRecord);

            try {
                kafkaTemplate.send(topicName, item);
            } catch (Exception ex) {
                log.error("Error sending record to topic {}: {}", topicName, ex.getMessage(), ex);
                throw new InvalidSchemaType(ex.getMessage());
            }
        }
    }
    @Scheduled(cron = "0 0 23 * * 0")
    public void getAllInspection() throws InterruptedException {
        int skip = 0;
        int limit = 50;
        LocalDateTime currentDateTime = LocalDateTime.now();
        LocalDateTime oneWeekAgo = currentDateTime.minusWeeks(1);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(jwt);
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        List<Inspections> batch = new ArrayList<>();

        while(true) {
            String urlWithParam = UriComponentsBuilder.fromHttpUrl(url)
                    .queryParam("confirmedAfter", oneWeekAgo)
                    .queryParam("skip", skip)
                    .queryParam("limit", limit)
                    .toUriString();
            ResponseEntity<List<InspectionDto>> responseEntity = restTemplate.exchange(
                    urlWithParam,
                    HttpMethod.GET,
                    requestEntity,
                    new ParameterizedTypeReference<>() {});

            if(responseEntity.getBody() == null || responseEntity.getBody().isEmpty()){
                break;
            }

            for(InspectionDto inspectionDto : Objects.requireNonNull(responseEntity.getBody())) {
                Inspections inspection = entityMappers.mapToInspection(inspectionDto);
                batch.add(inspection);
            }

            skip += limit;

            if (responseEntity.getBody().size() < limit){
                break;
            }
        }

        if (batch.isEmpty()) {
            return;
        }

        sendMessage(inspectionsTopic, batch);
    }

}
