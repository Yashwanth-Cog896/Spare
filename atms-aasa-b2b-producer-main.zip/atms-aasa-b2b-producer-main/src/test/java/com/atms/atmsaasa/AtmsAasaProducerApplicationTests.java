package com.atms.atmsaasa;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;


@SpringBootTest
public class AtmsAasaProducerApplicationTests {
	AtmsAasaProducerApplication atmsAasaProducerApplication = new AtmsAasaProducerApplication();

	@Test
	public void taskExecutorTests(){
		ThreadPoolTaskExecutor executor =  atmsAasaProducerApplication.taskExecutor();
		Assert.assertEquals(10000,executor.getMaxPoolSize());
		Assert.assertEquals(200,executor.getCorePoolSize());
		Assert.assertEquals(10000,executor.getQueueCapacity());

	}

}
