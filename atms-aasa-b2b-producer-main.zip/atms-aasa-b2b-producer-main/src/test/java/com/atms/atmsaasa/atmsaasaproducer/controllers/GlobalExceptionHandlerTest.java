package com.atms.atmsaasa.atmsaasaproducer.controllers;

import com.atms.atmsaasa.atmsaasaproducer.exceptions.NullFieldException;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.InvalidRequestParameterException;
import org.apache.kafka.common.errors.SerializationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class GlobalExceptionHandlerTest {
    @InjectMocks
    GlobalExceptionHandler globalExceptionHandler;
    private static HttpHeaders genericHeader = new HttpHeaders();


    @Before
        public void setup(){
            genericHeader.setContentType(MediaType.APPLICATION_JSON);
        }


    @Test
    public void handleFunctionalExceptions(){
        ResponseEntity<Object> responseEntity = globalExceptionHandler.handleFunctionalExceptions(new NullFieldException("testField"));
        Map<String, Object> body = new HashMap<>();

        body.put("message", "Missing Field: testField");
        body.put("timestamp", ZonedDateTime.now());
        body.put("status",HttpStatus.BAD_REQUEST.value());
        body.put("error", HttpStatus.BAD_REQUEST.getReasonPhrase());
        body.put("errorCode", "002");
        ResponseEntity<Object> expected = new ResponseEntity<>(body, genericHeader, HttpStatus.BAD_REQUEST);
        Assert.assertEquals(expected.getStatusCode(),responseEntity.getStatusCode());
        Assert.assertEquals(body.get("message"),((HashMap<String, Object>)responseEntity.getBody()).get("message"));
        Assert.assertEquals(body.get("errorCode"),((HashMap<String, Object>)responseEntity.getBody()).get("errorCode"));
        Assert.assertEquals(body.get("error"),((HashMap<String, Object>)responseEntity.getBody()).get("error"));

    }

    @Test
    public void handleInvalidRequestParameterExceptions(){
        ResponseEntity<Object> responseEntity = globalExceptionHandler.handleFunctionalExceptions(new InvalidRequestParameterException("limit must be greater than 0"));
        Map<String, Object> body = new HashMap<>();

        body.put("message", "Invalid request parameter: limit must be greater than 0");
        body.put("timestamp", ZonedDateTime.now());
        body.put("status",HttpStatus.BAD_REQUEST.value());
        body.put("error", HttpStatus.BAD_REQUEST.getReasonPhrase());
        body.put("errorCode", "004");
        ResponseEntity<Object> expected = new ResponseEntity<>(body, genericHeader, HttpStatus.BAD_REQUEST);
        Assert.assertEquals(expected.getStatusCode(),responseEntity.getStatusCode());
        Assert.assertEquals(body.get("message"),((HashMap<String, Object>)responseEntity.getBody()).get("message"));
        Assert.assertEquals(body.get("errorCode"),((HashMap<String, Object>)responseEntity.getBody()).get("errorCode"));
        Assert.assertEquals(body.get("error"),((HashMap<String, Object>)responseEntity.getBody()).get("error"));

    }

    @Test
    public void httpMessageNotReadableInvalidSchema(){
        ResponseEntity<Object> responseEntity = globalExceptionHandler.httpMessageNotReadable(new SerializationException("Schema is incompatible with earlier schema"));
        Map<String, Object> body = new LinkedHashMap<>();

        body.put("message", "Invalid Schema : Schema is incompatible with earlier schema");
        body.put("timestamp", ZonedDateTime.now());
        body.put("status",HttpStatus.BAD_REQUEST.value());
        body.put("error", HttpStatus.BAD_REQUEST.getReasonPhrase());
        body.put("errorCode", "001");
        ResponseEntity<Object> expected = new ResponseEntity<>(body, genericHeader, HttpStatus.BAD_REQUEST);
        Assert.assertEquals(expected.getStatusCode(),responseEntity.getStatusCode());
        Assert.assertEquals(body.get("message"),((HashMap<String, Object>)responseEntity.getBody()).get("message"));
        Assert.assertEquals(body.get("errorCode"),((HashMap<String, Object>)responseEntity.getBody()).get("errorCode"));
        Assert.assertEquals(body.get("error"),((HashMap<String, Object>)responseEntity.getBody()).get("error"));    }
    @Test
    public void httpMessageNotReadableInvalidJson(){
        ResponseEntity<Object> responseEntity = globalExceptionHandler.httpMessageNotReadable(new HttpMessageNotReadableException("Unexpected end-of-input in VALUE_STRING"));
        Map<String, Object> body = new HashMap<>();

        body.put("message", "Invalid Json : Unexpected end-of-input in VALUE_STRING");
        body.put("timestamp", ZonedDateTime.now());
        body.put("status",HttpStatus.BAD_REQUEST.value());
        body.put("error", HttpStatus.BAD_REQUEST.getReasonPhrase());
        body.put("errorCode", "003");
        ResponseEntity<Object> expected = new ResponseEntity<>(body, genericHeader, HttpStatus.BAD_REQUEST);
        Assert.assertEquals(expected.getStatusCode(),responseEntity.getStatusCode());
        Assert.assertEquals(body.get("message"),((HashMap<String, Object>)responseEntity.getBody()).get("message"));
        Assert.assertEquals(body.get("errorCode"),((HashMap<String, Object>)responseEntity.getBody()).get("errorCode"));
        Assert.assertEquals(body.get("error"),((HashMap<String, Object>)responseEntity.getBody()).get("error"));    }

}

