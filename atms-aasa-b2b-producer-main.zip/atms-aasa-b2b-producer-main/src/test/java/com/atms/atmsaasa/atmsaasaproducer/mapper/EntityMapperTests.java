package com.atms.atmsaasa.atmsaasaproducer.mapper;

import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import com.atms.atmsaasa.atmsaasaproducer.mappers.EntityMappers;
import com.atms.atmsaasa.atmsaasaproducer.mappers.EntityMappersImpl;
import com.atms.atmsaasa.avroschema.Inspections;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class EntityMapperTests {

    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule().addDeserializer(Instant.class, new StdDeserializer<Instant>(Instant.class) {
                @Override
                public Instant deserialize(JsonParser jsonparser, DeserializationContext deserializationcontext) throws IOException, JsonProcessingException {
                    return Instant.ofEpochSecond(jsonparser.readValueAs(Long.class));
                }
            }));
    ObjectMapper objectMapper2 = new ObjectMapper().registerModule(new JavaTimeModule().addDeserializer(LocalDateTime.class, new StdDeserializer<LocalDateTime>(LocalDateTime.class) {
                @Override
                public LocalDateTime deserialize(JsonParser jsonparser, DeserializationContext deserializationcontext) throws IOException, JsonProcessingException {
                    return Instant.ofEpochSecond(jsonparser.readValueAs(Long.class)).atZone(ZoneId.systemDefault()).toLocalDateTime();
                }
            }));


    EntityMappers entityMappers = new EntityMappersImpl();

    @Test
    public void mapToInspectionTest() throws IOException {
       System.out.println(Instant.now().toEpochMilli());
        File file = new File("src/test/resources/inspection.json");
        InspectionDto inspectionDto = objectMapper2.readValue(file, InspectionDto.class);
        Inspections aasaSuplMapper = entityMappers.mapToInspection(inspectionDto);
        Assert.assertEquals(inspectionDto.getInspectedAt(),aasaSuplMapper.getInspectedAt());
        Assert.assertEquals(inspectionDto.getCity(),aasaSuplMapper.getCity());


    }

}
