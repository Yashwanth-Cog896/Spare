package com.atms.atmsaasa.atmsaasaproducer.controllers;

import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import com.atms.atmsaasa.atmsaasaproducer.dto.ResponseDto;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.InvalidRequestParameterException;
import com.atms.atmsaasa.atmsaasaproducer.mappers.EntityMappers;
import com.atms.atmsaasa.atmsaasaproducer.service.ProducerService;
import com.atms.atmsaasa.avroschema.*;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@RunWith(MockitoJUnitRunner.class)

public class ProducerControllerTest {

   // @InjectMocks


    @Mock
    private ProducerService producerService;

    @Mock
    RestTemplate restTemplate;

    @Mock
    EntityMappers mappers;

    @InjectMocks
    ProducerController producerController = new ProducerController(producerService,restTemplate,mappers);

    /*@BeforeEach
            public void setup(){
        producerController
    }*/

    ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new JavaTimeModule().addDeserializer(Instant.class, new StdDeserializer<Instant>(Instant.class) {
                @Override
                public Instant deserialize(JsonParser jsonparser, DeserializationContext deserializationcontext) throws IOException, JsonProcessingException {
                    return Instant.ofEpochSecond(jsonparser.readValueAs(Long.class));
                }
            }));

    @Test
    public void testInspection() throws Exception {
        File file = new File("src/test/resources/inspection.json");
        InspectionDto inspection = objectMapper.readValue(file, InspectionDto.class);

        Mockito.when(producerService.sendMessage(ArgumentMatchers.any(),ArgumentMatchers.any()))
                .thenReturn(CompletableFuture.completedFuture(ResponseDto.builder().traceId(UUID.randomUUID().toString()).status("Message produced successfully").createdAt(String.valueOf(Instant.now().toEpochMilli())).build()));
        CompletableFuture<ResponseDto> responseEntity = producerController.produceInspections(List.of(inspection));
        Assert.assertEquals("Message produced successfully", responseEntity.toCompletableFuture().get().getStatus());
    }

    @Test
    public void testGetInspectionsUsesRequestParams() throws Exception {
        ReflectionTestUtils.setField(producerController, "jwt", "jwt");
        ReflectionTestUtils.setField(producerController, "url", "https://example.com/inspections");
        ReflectionTestUtils.setField(producerController, "inspectionsTopic", "inspections-topic");

        InspectionDto inspectionDto = new InspectionDto();
        Inspections inspection = new Inspections();
        LocalDateTime confirmedAfter = LocalDateTime.of(2024, 1, 15, 10, 30, 0);

        Mockito.when(restTemplate.exchange(
                        ArgumentMatchers.anyString(),
                        ArgumentMatchers.eq(HttpMethod.GET),
                        ArgumentMatchers.any(HttpEntity.class),
                        ArgumentMatchers.<org.springframework.core.ParameterizedTypeReference<List<InspectionDto>>>any()))
                .thenReturn(ResponseEntity.ok(List.of(inspectionDto)));
        Mockito.when(mappers.mapToInspection(inspectionDto)).thenReturn(inspection);
        Mockito.when(producerService.sendMessage(ArgumentMatchers.eq("inspections-topic"), ArgumentMatchers.eq(List.of(inspection))))
                .thenReturn(CompletableFuture.completedFuture(ResponseDto.builder()
                        .traceId(UUID.randomUUID().toString())
                        .status("Message produced successfully")
                        .createdAt(String.valueOf(Instant.now().toEpochMilli()))
                        .build()));

        CompletableFuture<ResponseDto> responseEntity = producerController.getInspections(confirmedAfter, 10, 5);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        Mockito.verify(restTemplate).exchange(
                urlCaptor.capture(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<org.springframework.core.ParameterizedTypeReference<List<InspectionDto>>>any());
        MultiValueMap<String, String> queryParams = UriComponentsBuilder.fromUriString(urlCaptor.getValue())
                .build()
                .getQueryParams();

        Assert.assertEquals(confirmedAfter.toString(), queryParams.getFirst("confirmedAfter"));
        Assert.assertEquals("10", queryParams.getFirst("skip"));
        Assert.assertEquals("5", queryParams.getFirst("limit"));
        Assert.assertEquals("Message produced successfully", responseEntity.toCompletableFuture().get().getStatus());
    }

    @Test
    public void testGetInspectionsUsesDefaultConfirmedAfterWhenMissing() throws Exception {
        ReflectionTestUtils.setField(producerController, "jwt", "jwt");
        ReflectionTestUtils.setField(producerController, "url", "https://example.com/inspections");
        ReflectionTestUtils.setField(producerController, "inspectionsTopic", "inspections-topic");

        Mockito.when(restTemplate.exchange(
                        ArgumentMatchers.anyString(),
                        ArgumentMatchers.eq(HttpMethod.GET),
                        ArgumentMatchers.any(HttpEntity.class),
                        ArgumentMatchers.<org.springframework.core.ParameterizedTypeReference<List<InspectionDto>>>any()))
                .thenReturn(ResponseEntity.ok(Collections.emptyList()));
        Mockito.when(producerService.sendMessage(ArgumentMatchers.eq("inspections-topic"), ArgumentMatchers.eq(Collections.emptyList())))
                .thenReturn(CompletableFuture.completedFuture(ResponseDto.builder()
                        .traceId(UUID.randomUUID().toString())
                        .status("Message produced successfully")
                        .createdAt(String.valueOf(Instant.now().toEpochMilli()))
                        .build()));

        producerController.getInspections(null, 0, 50);

        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        Mockito.verify(restTemplate).exchange(
                urlCaptor.capture(),
                ArgumentMatchers.eq(HttpMethod.GET),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<org.springframework.core.ParameterizedTypeReference<List<InspectionDto>>>any());

        MultiValueMap<String, String> queryParams = UriComponentsBuilder.fromUriString(urlCaptor.getValue())
                .build()
                .getQueryParams();

        Assert.assertNotNull(queryParams.getFirst("confirmedAfter"));
        Assert.assertEquals("0", queryParams.getFirst("skip"));
        Assert.assertEquals("50", queryParams.getFirst("limit"));
    }

    @Test
    public void testGetInspectionsRejectsInvalidLimit() {
        InvalidRequestParameterException exception = Assert.assertThrows(InvalidRequestParameterException.class,
                () -> producerController.getInspections(LocalDateTime.now(), 0, 0));

        Assert.assertEquals("Invalid request parameter: limit must be greater than 0", exception.getMessage());
    }

}
