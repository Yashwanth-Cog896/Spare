package com.atms.atmsaasa.atmsaasaproducer.utils;

import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.NullFieldException;
import com.atms.atmsaasa.avroschema.Inspections;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class AvroUtilsTest {

    AvroUtils avroUtils = new AvroUtils();
    ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new JavaTimeModule().addDeserializer(Instant.class, new StdDeserializer<Instant>(Instant.class) {
                @Override
                public Instant deserialize(JsonParser jsonparser, DeserializationContext deserializationcontext) throws IOException, JsonProcessingException {
                    return Instant.ofEpochSecond(jsonparser.readValueAs(Long.class));
                }
            })).configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);

    @Test
    public void checkNullableFields() throws IOException {
        File file = new File("src/test/resources/inspection.json");
        InspectionDto inspectiondto = objectMapper.readValue(file, InspectionDto.class);
        Inspections inspections = objectMapper.convertValue(inspectiondto, Inspections.class);

        Assertions.assertDoesNotThrow(() ->  avroUtils.checkNullableFields(inspections));

    }
//    @Test
//    public void checkNullableFieldsException() throws IOException {
//        File file = new File("src/test/resources/inspection.json");
//        InspectionDto inspectiondto = objectMapper.readValue(file, InspectionDto.class);
//        inspectiondto.setId(null);
//        Inspections inspections = objectMapper.convertValue(inspectiondto, Inspections.class);
//
//        Assert.assertThrows("", NullFieldException.class,() ->  avroUtils.checkNullableFields(inspections));
//
//    }

    @Test
    public void isNullableSchemaTypeNotNull(){
        Schema booleanSchema = Schema.create(Schema.Type.BOOLEAN);
        Schema nullSchema = Schema.create(Schema.Type.NULL);
        Schema union = Schema.createUnion(List.of(booleanSchema,nullSchema));
        List<Schema.Field> fields = new ArrayList<>();
        fields.add(0,new Schema.Field("siteId",union));
        Schema schema = Schema.createRecord("testRecord","","com.atms.atmsaasa.avroschema",false,fields);
        GenericRecord rec = new GenericData.Record(schema);
        rec.put("siteId","value");
        Assertions.assertDoesNotThrow(() ->  avroUtils.checkNullableFields(rec));
    }
}
