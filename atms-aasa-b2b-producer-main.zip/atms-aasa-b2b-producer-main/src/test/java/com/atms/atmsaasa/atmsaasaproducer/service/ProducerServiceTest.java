package com.atms.atmsaasa.atmsaasaproducer.service;

import com.atms.atmsaasa.atmsaasaproducer.dto.InspectionDto;
import com.atms.atmsaasa.atmsaasaproducer.dto.ResponseDto;
import com.atms.atmsaasa.atmsaasaproducer.exceptions.InvalidSchemaType;
import com.atms.atmsaasa.atmsaasaproducer.mappers.EntityMappers;
import com.atms.atmsaasa.atmsaasaproducer.utils.AvroUtils;
import com.atms.atmsaasa.avroschema.Inspections;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;

import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.client.RestTemplate;

import javax.swing.text.html.parser.Entity;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class ProducerServiceTest {
    AvroUtils avroUtils = new AvroUtils();
    KafkaTemplate<Object,Object> kafkaTemplate = Mockito.mock(KafkaTemplate.class);
    @Mock
    EntityMappers entityMappers;

    @Mock
    RestTemplate restTemplate;

    private String url;


    private String jwt;


    @InjectMocks
    ProducerService producerService ;


    @Before
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);  // Initialize mocks
       producerService = new ProducerService(avroUtils,kafkaTemplate,restTemplate,entityMappers);

        Field serviceNameField = producerService.getClass().getDeclaredField("url");
        serviceNameField.setAccessible(true);
        serviceNameField.set(producerService, "http://example.com");

        Field serviceVersionField = producerService.getClass().getDeclaredField("jwt");
        serviceVersionField.setAccessible(true);
        serviceVersionField.set(producerService, "fefiefjweffjj");
    }


    ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new JavaTimeModule().addDeserializer(Instant.class, new StdDeserializer<Instant>(Instant.class) {
                @Override
                public Instant deserialize(JsonParser jsonparser, DeserializationContext deserializationcontext) throws IOException {
                    return Instant.ofEpochSecond(jsonparser.readValueAs(Long.class));
                }
            })).configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);


    @Test
    public void sendMessage() throws IOException, ExecutionException, InterruptedException {
        File file = new File("src/test/resources/inspection.json");
        InspectionDto inspectiondto = objectMapper.readValue(file, InspectionDto.class);
        Inspections inspections = objectMapper.convertValue(inspectiondto, Inspections.class);
        Mockito.when(kafkaTemplate.send(ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(null);
        List<Inspections> data = List.of(inspections);
        CompletableFuture<ResponseDto> message = producerService.sendMessage("anyTopic", data);
        Assert.assertEquals("Message produced successfully",message.get().getStatus());

    }
    @Test
    public void sendMessageSchemaException() throws IOException{
        File file = new File("src/test/resources/inspection.json");
        InspectionDto inspectiondto = objectMapper.readValue(file, InspectionDto.class);
        Inspections inspections = objectMapper.convertValue(inspectiondto, Inspections.class);
        List<Inspections> data = List.of(inspections);
        Mockito.when(kafkaTemplate.send(ArgumentMatchers.any(),ArgumentMatchers.any())).thenThrow();
        Assert.assertThrows("InvalidSchema", InvalidSchemaType.class,() -> producerService.sendMessage("anyTopic", data));

    }
    @Test
    public void testExternalApiCall() throws Exception {
        // Prepare the mock response
        File file = new File("src/test/resources/inspection.json");
        InspectionDto inspectiondto = objectMapper.readValue(file, InspectionDto.class);
        Inspections inspections = objectMapper.convertValue(inspectiondto, Inspections.class);

        ResponseEntity<List<InspectionDto>> mockResponse = new ResponseEntity<>(List.of(inspectiondto), HttpStatusCode.valueOf(200));
        ResponseEntity<List<InspectionDto>> mockResponse2 = new ResponseEntity<>(null,HttpStatusCode.valueOf(200));
        Mockito.when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), any(ParameterizedTypeReference.class)))
                .thenReturn(mockResponse).thenReturn(mockResponse2);
        Mockito.when(entityMappers.mapToInspection(ArgumentMatchers.any(InspectionDto.class)))
                .thenReturn(inspections);
        producerService.getAllInspection();

        Mockito.verify(entityMappers,Mockito.times(1)).mapToInspection(ArgumentMatchers.any(InspectionDto.class));
    }
//    @Test
//    public void sendMessageNullException() throws IOException{
//        File file = new File("src/test/resources/inspection.json");
//        InspectionDto inspectiondto = objectMapper.readValue(file, InspectionDto.class);
//        Inspections inspections = objectMapper.convertValue(inspectiondto, Inspections.class);
//        inspections.setId(null);
//        List<Inspections> data = List.of(inspections);
//        Assert.assertThrows("", NullFieldException.class,() -> producerService.sendMessage("anyTopic", data));
//
//    }
}
