package com.monsanto.tps.lexicon.regulatory.monnumber.dao;

import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;

import java.util.List;


/**
 * nbwald - Jan 6, 2009 5:18:53 PM
 */
public interface MonNumberDao
{
   MonNumber find(String monNumberValue);

   MonNumber findByEventAndCrop(String eventName, String cropName);

   MonNumber[] findByCrop(String cropPubkey);

   MonNumber[] findByMonNumber(String monNumber);

   MonNumber[] findByMonNumberAndCrop(String monNumber, String cropPubkey);

   MonNumber[] findByConstruct(String[] constructs);

   MonNumber[] findByPvCode(String[] pvCodes);

   MonNumber[] findAll();

   MonNumber save(MonNumber monNumber);

   MonNumberConstruct saveMonNumberConstruct(MonNumberConstruct monNumberConstruct);

   ProteinName findProteinNameByPubkey(String proteinPubkey);

   MonNumber findByEvent(String eventName);

   MonNumber findByOecdNumber(String oecdNumber);

   List<MonNumberInfo> findByEventsAndCrop(String[] events, String cropName);

   List<MonNumberInfo> findByMonNumbers(String[] monNumbers);

    List<MonNumber> getMonNumbersByEventNames(long requestId);

   List<MonNumber> getMonNumbersByMonNumber(long requestId);
}
