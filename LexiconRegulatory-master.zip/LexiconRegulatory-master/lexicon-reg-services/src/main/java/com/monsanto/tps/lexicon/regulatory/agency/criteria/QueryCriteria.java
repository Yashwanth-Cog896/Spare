package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import org.hibernate.criterion.Criterion;

/**
 * rrchak1 - Oct 13, 2008 3:20:21 PM
 */
public interface QueryCriteria
{
   Criterion getCriterion();

   boolean hasCriteria();
}
