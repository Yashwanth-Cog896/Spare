package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;

/**
 * rrchak1 - May 22, 2009 12:58:32 PM
 */
public class SelectConstruct
{
   private EventConstruct[] eventConstructs;

   public SelectConstruct(EventConstruct[] eventConstructs) {
      this.eventConstructs = eventConstructs;
   }

   public boolean hasEventConstruct(String construct) {
      for (EventConstruct eventConstruct : eventConstructs) {
         if (eventConstruct.getConstruct().equalsIgnoreCase(construct)) {
            return true;
         }
      }
      return false;
   }

   public EventConstruct getEventConstruct(String construct) {
      for (EventConstruct eventConstruct : eventConstructs) {
         if (construct.equalsIgnoreCase(eventConstruct.getConstruct())) {
            return eventConstruct;
         }
      }
      return null;
   }

   public boolean hasEventConstructs() {
      return !ArrayUtils.isEmpty(eventConstructs);
   }

   public boolean hasMoreThanOneRegulatoryEvent() {
      return eventConstructs.length > 1;
   }

   public EventConstruct[] getEventConstructs(BindException errors, String objectName, String construct) {
      if (hasMoreThanOneRegulatoryEvent()) {
         if (hasEventConstruct(construct)) {
            return new EventConstruct[]{getEventConstruct(construct)};
         }
         else {
            errors.addError(new FieldError(objectName, "event", "Multiple plasmid PMONs found.  Please select one."));
            return eventConstructs;
         }
      }
      return new EventConstruct[]{eventConstructs[0]};//There will always be only one valid EventConstruct
   }

}
