package com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;

import java.util.List;

/**
 * nbwald - May 21, 2009 4:44:04 PM
 */
public class ConstructsByEventAndCropQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String eventName;
   private final String cropName;

   public ConstructsByEventAndCropQuery(String eventName, String cropName) {
      this.eventName = eventName;
      this.cropName = cropName;
   }

   public String[] find() {
      try {
         List<String> constructs = getList();
         return constructs.toArray(new String[constructs.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      return
         "select unique EC.construct_name" +
            "  from Midas.Event_Construct EC" +
            "     , Midas.Crop C" +
            " where EC.crop_id = C.crop_id" +
            "   and UPPER(EC.event_name) = UPPER(?)" +
            "   and UPPER(C.name) = UPPER(?)" +
            "   and EC.ref_active = 'T'" +
            "   and C.ref_active = 'T'";
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{eventName, cropName};
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
