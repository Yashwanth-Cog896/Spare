package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.PVCode;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 9/19/11
 * Time: 11:26 AM
 */
public class PVCodesTransformer {

    public List<PVCode> formLexiconPVCodeList(List<PvCode> fcmPvCodes) {
        if (fcmPvCodes == null){
            return null;
        }
        List<PVCode> pvCodeStringList = new ArrayList<PVCode>();
        for (PvCode fcmPVCode : fcmPvCodes) {
            PVCode lexiconPVCode = new PVCode();
            lexiconPVCode.setPvCode(fcmPVCode.getPvCode());
            lexiconPVCode.setPhenotypeCategoryCode(fcmPVCode.getPhenotypeCategoryCode());
            lexiconPVCode.setPhenotypeCategoryDescription(fcmPVCode.getPhenotypeCategoryDescription());
            pvCodeStringList.add(lexiconPVCode);
        }
        return pvCodeStringList;
    }
}
