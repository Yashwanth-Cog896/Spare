package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;

import java.util.Collection;

/**
 * nbwald - May 21, 2009 5:41:19 PM
 */
public class HasProteinNameRule
   implements Rule<String>
{
   private final Collection<ProteinName> proteinNames;

   public HasProteinNameRule(Collection<ProteinName> proteinNames) {
      this.proteinNames = proteinNames;
   }

   @Override
   public boolean violated() {
      return proteinNames.isEmpty();
   }

   @Override
   public String getViolation() {
      return "At least one protein name is required.";
   }
}
