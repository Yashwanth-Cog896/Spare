package com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.service;

import com.monsanto.tps.lexicon.additionalmaterialinfo.AdditionalMaterialService;
import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionAdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.business.AdditionalMaterialBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
public class AdditionalMaterialServiceImpl implements AdditionalMaterialService {

    @Resource
    private AdditionalMaterialBusiness additonalMaterialBusiness;

    @Override
    public List<OrionAdditionalMaterial> findAdditionalMaterials(final String materialName) {
        return additonalMaterialBusiness.findAdditionalMaterials(materialName);
    }
}
