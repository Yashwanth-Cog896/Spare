/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;

import java.util.List;

/* vvkalu - 8/5/11 */
public interface GermplasmEventConstructDao {
    List<GermplasmEventConstructEntity> findGermplasmEventConstructs(long germplasmId);
}