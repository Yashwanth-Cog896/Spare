package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;

/**
 * aagosw - Mar 10, 2009 8:05:40 AM
 */
public interface AgencySaveUpdateValidator
{
   ValidationResults validate(AgencySaveUpdateRequest agencySaveUpdateRequest);
}
