package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * rrchak1 - Oct 13, 2008 3:51:23 PM
 */
public class AgencyAbbrCriteriaImpl
   implements QueryCriteria
{
   private String agencyAbbr;

   public AgencyAbbrCriteriaImpl(String agencyAbbr) {
      this.agencyAbbr = agencyAbbr;
   }

   public Criterion getCriterion() {
      return Restrictions.like("agencyAbbr", convertWildCards(agencyAbbr)).ignoreCase();
   }

   private String convertWildCards(String attribute) {
      return new StdWildcardableCriteria(attribute).oracleVersion();
   }

   public boolean hasCriteria() {
      return StringUtils.isNotEmpty(agencyAbbr);
   }
}
