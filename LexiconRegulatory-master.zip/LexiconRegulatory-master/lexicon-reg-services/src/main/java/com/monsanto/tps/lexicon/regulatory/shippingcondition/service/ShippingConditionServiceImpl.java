package com.monsanto.tps.lexicon.regulatory.shippingcondition.service;

import com.monsanto.tps.lexicon.shippingcondition.OrionShippingCondition;
import com.monsanto.tps.lexicon.shippingcondition.ShippingConditionService;
import com.monsanto.tps.lexicon.regulatory.shippingcondition.business.ShippingConditionBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ShippingConditionServiceImpl implements ShippingConditionService {

    @Resource
    private ShippingConditionBusiness shippingConditionBusiness;

    @Override
    public List<OrionShippingCondition> findShippingConditions(final String geneticBackgroundType) {
        return shippingConditionBusiness.findShippingConditions(geneticBackgroundType);
    }
}
