package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventDeregulationStatus;

/**
 * rrchak1 - Jun 23, 2009 11:00:24 AM
 */
public interface EventStatusByEventAgencyAndCropStrategy
{
   public EventDeregulationStatus[] find(String[] events, String cropName, String[] agencyAbbrs);
}
