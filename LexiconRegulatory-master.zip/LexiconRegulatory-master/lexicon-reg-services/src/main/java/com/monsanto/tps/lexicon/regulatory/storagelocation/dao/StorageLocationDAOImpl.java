package com.monsanto.tps.lexicon.regulatory.storagelocation.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/20/12
 * Time: 6:20 PM
 */
public class StorageLocationDAOImpl implements StorageLocationDAO {
    private SessionFactory sessionFactory;

    public List<StorageLocation> findActiveStorageLocations(StorageLocation storageLocation) {
        Session session = sessionFactory.getCurrentSession();
        storageLocation.setActiveStatus(true);
        Example example = Example.create(storageLocation)
                .ignoreCase()
                .enableLike();
        return (List<StorageLocation>) session.createCriteria(StorageLocation.class)
                .add(example)
                .list();
    }


    public List<StorageLocation> findStorageLocationsByList() {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("StorageLocationDAO.findStorageLocationsByListCriteria");
        return (List<StorageLocation>) query.list();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
