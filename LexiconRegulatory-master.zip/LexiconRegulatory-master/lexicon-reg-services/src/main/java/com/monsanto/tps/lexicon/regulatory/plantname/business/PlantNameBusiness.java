package com.monsanto.tps.lexicon.regulatory.plantname.business;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;
import com.monsanto.tps.lexicon.regulatory.plantname.dao.PlantNameDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:39 PM
 */
@Component
public class PlantNameBusiness {

    @Resource
    private PlantNameDAO plantNameDAO;

    public List<OrionPlantProduct> findPlantNames(String productName) {
        final List<PlantName> plantNameTypeList = plantNameDAO.findPlantNames(WildcardUtil.replaceAsteriskWildcardWithPercent(productName));
        final List<OrionPlantProduct> orionPlantNameList = new ArrayList<OrionPlantProduct>();

        for (PlantName type : plantNameTypeList) {
            orionPlantNameList.add(new OrionPlantProduct(type.getMaterialName(),type.getCrop().getCropName()));
        }

        return orionPlantNameList;
    }
}