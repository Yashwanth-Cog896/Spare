package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEvent;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistBatchRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventService;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStagingDataPointEnum;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventDao;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate.NonMonEventCreation;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate.NonMonEventUpdate;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.util.NonMonEventBeanUtil;

import javax.jws.WebParam;
import javax.jws.WebService;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 8, 2009
 * Time: 8:46:55 AM
 */
@WebService(endpointInterface = "com.monsanto.tps.lexicon.nonmonevent.NonMonEventService")
public class NonMonEventServiceImpl
   implements NonMonEventService
{
   private NonMonEventDao nonMonEventDao;
   private NonMonEventBeanUtil nonMonEventBeanUtil;
   private NonMonEventCreation nonMonEventCreation;
   private NonMonEventUpdate nonMonEventUpdate;
   private DataPointHolder dataPointHolder;

   @Override
   @PerformanceMetric(task = "NonMonEventService-findByCrop", comment = "findByCrop")
   public NonMonEvent[] findByCrop(String cropPubkey) {
      return nonMonEventBeanUtil.buildNonMonEvents(nonMonEventDao.findByCrop(cropPubkey));
   }

   @Override
   @PerformanceMetric(task = "NonMonEventService-findByNonMonEvent", comment = "findByNonMonEvent")
   public NonMonEvent[] findByNonMonEvent(String nonMonEvent) {
      return nonMonEventBeanUtil.buildNonMonEvents(nonMonEventDao.findByNonMonEvent(nonMonEvent));
   }

   @Override
   @PerformanceMetric(task = "NonMonEventService-findAll", comment = "findAll")
   public NonMonEvent[] findAll() {
      return nonMonEventBeanUtil.buildNonMonEvents(nonMonEventDao.findAll());
   }

   @Override
   @PerformanceMetric(task = "NonMonEventService-findByNonMonEventAndCrop", comment = "findByNonMonEventAndCrop")
   public NonMonEvent[] findByNonMonEventAndCrop(String nonMonEvent, String cropPubkey) {
      return nonMonEventBeanUtil.buildNonMonEvents(nonMonEventDao.findByNonMonEventAndCrop(nonMonEvent, cropPubkey));
   }

   @Override
   @PerformanceMetric(task = "NonMonEventService-save", comment = "save")
   public NonMonEventPersistResponse[] save(NonMonEventPersistBatchRequest batchRequest) {
      NonMonEventPersistRequest[] requests = getRequests(batchRequest);
      NonMonEventPersistResponse[] responses = new NonMonEventPersistResponse[requests.length];
      for (int i = 0; i < requests.length; i++) {
         saveAuditData(requests[i]);
         responses[i] = nonMonEventCreation.create(requests[i], batchRequest.isValidateOnly());
         clearAuditData();
      }
      return responses;
   }

   @Override
   @PerformanceMetric(task = "NonMonEventService-update", comment = "update")
   public NonMonEventPersistResponse[] update(@WebParam(name = "batchRequest") NonMonEventPersistBatchRequest batchRequest) {
      NonMonEventPersistRequest[] requests = getRequests(batchRequest);
      NonMonEventPersistResponse[] responses = new NonMonEventPersistResponse[requests.length];
      for (int i = 0; i < requests.length; i++) {
         saveAuditData(requests[i]);
         responses[i] = nonMonEventUpdate.update(requests[i], batchRequest.isValidateOnly());
         clearAuditData();
      }
      return responses;
   }

   private NonMonEventPersistRequest[] getRequests(NonMonEventPersistBatchRequest batchRequest) {
      NonMonEventPersistRequest[] requests = batchRequest.getRequests();
      return requests == null ? new NonMonEventPersistRequest[0] : requests;
   }

   private void saveAuditData(NonMonEventPersistRequest request) {
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), request.getAuditComment());
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), request.getAuditRequestor());
   }

   private void clearAuditData() {
      dataPointHolder.clear();
   }

   public void setNonMonEventDao(NonMonEventDao nonMonEventDao) {
      this.nonMonEventDao = nonMonEventDao;
   }

   public void setNonMonEventBeanUtil(NonMonEventBeanUtil nonMonEventBeanUtil) {
      this.nonMonEventBeanUtil = nonMonEventBeanUtil;
   }

   public void setNonMonEventCreation(NonMonEventCreation nonMonEventCreation) {
      this.nonMonEventCreation = nonMonEventCreation;
   }

   public void setNonMonEventUpdate(NonMonEventUpdate nonMonEventUpdate) {
      this.nonMonEventUpdate = nonMonEventUpdate;
   }

   public void setDataPointHolder(DataPointHolder dataPointHolder) {
      this.dataPointHolder = dataPointHolder;
   }
}
