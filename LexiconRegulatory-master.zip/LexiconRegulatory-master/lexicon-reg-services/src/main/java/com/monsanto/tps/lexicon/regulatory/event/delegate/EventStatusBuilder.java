package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * rrchak1 - Jun 23, 2009 12:00:09 PM
 */
public class EventStatusBuilder {
    public List<EventDeregulationStatus> build(EventAgencyAlignment[] agencyAlignments, String cropName) {
        Map<String, List<EventAgencyAlignment>> alignments = buildMapByEvent(agencyAlignments);
        return buildEventDeregulationStatus(alignments, cropName);
    }

    private List<EventDeregulationStatus> buildEventDeregulationStatus(Map<String, List<EventAgencyAlignment>> alignments, String cropName) {
        List<EventDeregulationStatus> eventDeregulationStatusList = new ArrayList<EventDeregulationStatus>();
        for (String event : alignments.keySet()) {
            EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
            eventDeregulationStatus.setEventName(event);
            eventDeregulationStatus.setCrop(cropName);
            List<EventAgencyAlignment> alignmentList = alignments.get(event);
            EventAgencyAlignment[] agencyAlignments = alignmentList.toArray(new EventAgencyAlignment[alignmentList.size()]);
            eventDeregulationStatus.setEventAgencies(new EventAgencies(agencyAlignments).getResponseEventAgencies());
            eventDeregulationStatusList.add(eventDeregulationStatus);
        }
        return eventDeregulationStatusList;
    }

    private Map<String, List<EventAgencyAlignment>> buildMapByEvent(EventAgencyAlignment[] agencyAlignments) {
        Map<String, List<EventAgencyAlignment>> alignments = new HashMap<String, List<EventAgencyAlignment>>();
        List<EventAgencyAlignment> alignmentList;
        for (EventAgencyAlignment agencyAlignment : agencyAlignments) {
            if (alignments.containsKey(agencyAlignment.getMaterialName())) {
                alignmentList = alignments.get(agencyAlignment.getMaterialName());
                alignments.remove(agencyAlignment.getMaterialName());
            } else {
                alignmentList = new ArrayList<EventAgencyAlignment>();
            }
            alignmentList.add(agencyAlignment);
            alignments.put(agencyAlignment.getMaterialName(), alignmentList);
        }
        return alignments;
    }
}