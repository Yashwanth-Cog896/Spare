package com.monsanto.tps.lexicon.regulatory.event.delegate;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * nbwald - Jan 5, 2009 2:24:23 PM
 */
public class TransCodes
{
   private final String displayText;

   public TransCodes(String[] transCodeArray) {
      this.displayText = ArrayUtils.isEmpty(transCodeArray) ? null : sortAndCSV(transCodeArray);
   }

   public String getDisplayText() {
      return displayText;
   }

   private String sortAndCSV(String[] transCodeArray) {
      List<String> transCodeList = Arrays.asList(transCodeArray);
      Collections.sort(transCodeList);
      return StringUtils.join(transCodeList, ',');
   }
}
