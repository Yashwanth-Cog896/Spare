package com.monsanto.tps.lexicon.regulatory.util;

import org.apache.commons.lang.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/5/12
 * Time: 7:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class WildcardUtil {
    public static String replaceEmptyStringWithWildcard(final String inputString) {
        if (StringUtils.isEmpty(inputString)) {
            return "%";
        }
        return inputString;
    }
    public static String replaceAsteriskWildcardWithPercent(final String inputString) {
        if (StringUtils.isNotEmpty(inputString)) {
            return inputString.replace('*', '%');
        }
        return "%";
    }
}
