package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Oct 21, 2008 3:55:27 PM
 */
public class AgencyAbbrMustBeAlphaNumericRule
   implements Rule
{
   private String[] agencyAbbr;

   public AgencyAbbrMustBeAlphaNumericRule(String[] agencyAbbr) {
      this.agencyAbbr = agencyAbbr;
   }

   public boolean violated() {
      if (!ArrayUtils.isEmpty(agencyAbbr)) {
         for (String abbr : agencyAbbr) {
            if (new StdWildcardableCriteria(abbr).isOnlyWildcard()) {
               return true;
            }
            if (!abbr.matches("^[a-zA-Z0-9*]+[a-zA-Z0-9*]+$")) {
               return true;
            }
         }
      }
      return false;
   }

   public Object getViolation() {
      return "Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.";
   }
}
