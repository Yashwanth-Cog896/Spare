package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:16 PM
 */
public class PlantName {
    private long plantNameId;
    private String materialName;
    private String brand;
    private String previousNames;
    private Crop crop;
    private String country;
    private String materialClassification;
    private boolean activeStatus;


    public PlantName() {
    }

    public final long getPlantNameId() {
        return plantNameId;
    }

    public final String getMaterialName() {
        return materialName;
    }

    public final void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public final String getBrand() {
        return brand;
    }

    public final void setBrand(String brand) {
        this.brand = brand;
    }

    public final String getPreviousNames() {
        return previousNames;
    }

    public final void setPreviousNames(String previousNames) {
        this.previousNames = previousNames;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public final String getCountry() {
        return country;
    }

    public final void setCountry(String country) {
        this.country = country;
    }

    public final String getMaterialClassification() {
        return materialClassification;
    }

    public final void setMaterialClassification(String materialClassification) {
        this.materialClassification = materialClassification;
    }

    public final boolean getActiveStatus() {
        return activeStatus;
    }

    public final void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

}



