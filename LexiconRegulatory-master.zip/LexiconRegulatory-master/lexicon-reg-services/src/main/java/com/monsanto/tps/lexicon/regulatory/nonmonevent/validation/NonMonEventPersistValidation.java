package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.AggregatingValidator;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * nbwald - May 26, 2009 10:48:17 AM
 */
public abstract class NonMonEventPersistValidation
{
   public ValidationResults validate(NonMonEventPersistRichRequest richRequest) {
      AggregatingValidator<String> errorValidations = new AggregatingValidator<String>(gatherErrorLevelRules(richRequest));
      List<String> errors = errorValidations.validate();
      AggregatingValidator<String> warningValidations = new AggregatingValidator<String>(new ArrayList<Rule<String>>());
      List<String> warnings = warningValidations.validate();
      return new ValidationResults(errors, warnings);
   }

   protected abstract Collection<? extends Rule<String>> gatherAdditionalErrorRules(NonMonEventPersistRichRequest richRequest);

   private List<Rule<String>> gatherErrorLevelRules(NonMonEventPersistRichRequest richRequest) {
      List<Rule<String>> rules = new ArrayList<Rule<String>>();
      rules.add(new EventExistsRule(richRequest.getConstructs()));
      rules.add(new AuditCommentExistsRule(richRequest.getAuditComment()));
      rules.add(new AuditRequestorExistsRule(richRequest.getAuditRequestor()));
      rules.add(new CropExistsRule(richRequest.getCrop()));
      rules.add(new EventHasSingleConstructRule(richRequest.getConstructs()));
      rules.add(new EventNameSpecifiedRule(richRequest.getEventName()));
      rules.add(new HasProteinNameRule(richRequest.getProteinNames()));
      rules.add(new HasRegulatoryTraitOptionRule(richRequest.getComlTraitNames(), richRequest.getComlTraitTypes()));
      rules.addAll(gatherAdditionalErrorRules(richRequest));
      return rules;
   }

}
