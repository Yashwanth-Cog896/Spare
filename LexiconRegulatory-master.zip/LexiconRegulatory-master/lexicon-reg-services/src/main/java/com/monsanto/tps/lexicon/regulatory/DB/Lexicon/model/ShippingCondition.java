package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/6/12
 * Time: 10:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class ShippingCondition {

    private long shippingConditionId;
    private String shippingCondition;
    private boolean activeStatus;

    public ShippingCondition() {
    }

    public ShippingCondition(String shippingCondition, boolean activeStatus) {
        this.shippingCondition = shippingCondition;
        this.activeStatus = activeStatus;
    }

    public final long getShippingConditionId() {
        return shippingConditionId;
    }

    public final String getShippingCondition() {
        return shippingCondition;
    }

    public final void setShippingCondition(String shippingCondition) {
        this.shippingCondition = shippingCondition;
    }

    public final boolean getActiveStatus() {
        return activeStatus;
    }

    public final void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
