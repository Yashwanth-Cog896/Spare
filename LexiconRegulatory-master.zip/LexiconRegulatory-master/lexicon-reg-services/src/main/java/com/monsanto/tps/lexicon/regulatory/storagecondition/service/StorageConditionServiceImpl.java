package com.monsanto.tps.lexicon.regulatory.storagecondition.service;

import com.monsanto.tps.lexicon.regulatory.storagecondition.business.StorageConditionBusiness;
import com.monsanto.tps.lexicon.storagecondition.OrionStorageCondition;
import com.monsanto.tps.lexicon.storagecondition.StorageConditionService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class StorageConditionServiceImpl implements StorageConditionService {

    @Resource
    private StorageConditionBusiness storageConditionBusiness;

    @Override
    public List<OrionStorageCondition> findStorageConditions(final String geneticBackgroundType) {
        return storageConditionBusiness.findStorageConditions(geneticBackgroundType);
    }
}
