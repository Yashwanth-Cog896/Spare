package com.monsanto.tps.lexicon.regulatory.event.delegate;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.ArrayUtils;

public class EventSplitter
{
   public List<String[]> splitEvents(String[] events) {
      List<String[]> eventList = new ArrayList<String[]>((events.length / 1000) + 1);
      for (int i = 0; i < events.length; i += 1000) {
         eventList.add((String[]) ArrayUtils.subarray(events, i, Math.min(events.length, i + 1000)));
      }
      return eventList;
   }
}