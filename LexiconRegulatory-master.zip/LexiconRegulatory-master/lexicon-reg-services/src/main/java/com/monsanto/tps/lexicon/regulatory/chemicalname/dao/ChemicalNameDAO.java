package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:51 PM
 */
public interface ChemicalNameDAO {
    List<ChemicalName> findChemicalNames(String materialName);

    List<ChemicalName> findChemicalCommercialProduct(String materialName);

    List<ChemicalName> findChemicalFormulation(String materialName);

    List<ChemicalName> findChemicalActiveIngredient(String materialName);

    List<String> findActiveIngredientNames(long productId, String productName);
}
