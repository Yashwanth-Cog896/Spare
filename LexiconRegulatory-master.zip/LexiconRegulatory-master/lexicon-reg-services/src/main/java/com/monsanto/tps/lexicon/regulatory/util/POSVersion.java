package com.monsanto.tps.lexicon.regulatory.util;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 8, 2005
 * Time: 9:54:40 AM
 */
public interface POSVersion
{
   int VERSION_MAJOR = 1;
   int VERSION_MINOR = 1;
   int VERSION_BUILD_NUMBER = 002;
   String VERSION_TEXT = "v" + VERSION_MAJOR + "." + VERSION_MINOR + " (Build " + VERSION_BUILD_NUMBER + ")";
   String BUILD_DATE = "8 September 2009";
   String VERSION_SHORT_TEXT = VERSION_MAJOR + "." + VERSION_MINOR + "." + VERSION_BUILD_NUMBER;
}
