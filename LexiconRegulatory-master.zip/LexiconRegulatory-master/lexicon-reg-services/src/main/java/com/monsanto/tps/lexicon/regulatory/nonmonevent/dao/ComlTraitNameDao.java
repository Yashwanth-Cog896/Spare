package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.util.collection.Sets;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import java.util.Collection;
import java.util.List;

/**
 * nbwald - May 21, 2009 8:28:17 PM
 */
public class ComlTraitNameDao
{
   private final SessionFactory sessionFactory;

   public ComlTraitNameDao(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public Collection<ComlTraitName> findByAbbrs(String... comlTraitNameAbbrs) {
      if (ArrayUtils.isNullOrEmpty(comlTraitNameAbbrs)) {
         return Sets.asSet();
      }
      Session session = sessionFactory.getCurrentSession();
      List results = session.getNamedQuery("comlTraitsByAbbrs").setParameterList("traitNameAbbreviations", comlTraitNameAbbrs).list();
      return (Collection<ComlTraitName>) results;
   }
}
