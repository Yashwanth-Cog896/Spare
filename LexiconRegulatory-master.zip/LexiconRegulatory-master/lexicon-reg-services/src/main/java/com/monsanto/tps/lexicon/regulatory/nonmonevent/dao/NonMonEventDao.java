package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 2:22:39 PM
 */
public interface NonMonEventDao
{
   NonMonEvent[] findByCrop(String cropPubkey);

   NonMonEvent[] findByNonMonEvent(String nonMonEvent);

   NonMonEvent[] findByNonMonEventAndCrop(String nonMonEvent, String cropPubkey);

   NonMonEvent[] findAll();

   void save(NonMonEvent event);

   void update(NonMonEvent event);
}
