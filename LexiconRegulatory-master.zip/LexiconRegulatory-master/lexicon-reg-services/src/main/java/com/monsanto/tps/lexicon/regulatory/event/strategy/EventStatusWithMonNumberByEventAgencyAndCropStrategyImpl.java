package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventSplitter;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventStatusWithMonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Jun 23, 2009 11:23:09 AM
 */
public class EventStatusWithMonNumberByEventAgencyAndCropStrategyImpl
   implements EventStatusWithMonNumberByEventAgencyAndCropStrategy
{
   private final EventAgencyAlignmentDao eventAgencyAlignmentDao;
   private final EventStatusWithMonNumberBuilder eventStatusBuilder;
   private final MonNumberDao monNumberDao;
   private final EventSplitter eventSplitter;

   public EventStatusWithMonNumberByEventAgencyAndCropStrategyImpl(EventAgencyAlignmentDao eventAgencyAlignmentDao, MonNumberDao monNumberDao, EventStatusWithMonNumberBuilder eventStatusBuilder, EventSplitter eventSplitter) {
      this.eventAgencyAlignmentDao = eventAgencyAlignmentDao;
      this.eventStatusBuilder = eventStatusBuilder;
      this.monNumberDao = monNumberDao;
      this.eventSplitter = eventSplitter;
   }

   @Override
   public EventDeregulationStatusWithMonNumber[] find(String[] events, String cropName, String[] agencyAbbrs) {
      List<String[]> eventList = eventSplitter.splitEvents(events);
      List<EventDeregulationStatusWithMonNumber> eventDeregulationStatusList = new ArrayList<EventDeregulationStatusWithMonNumber>(events.length);
      for (String[] eventItems : eventList) {
         EventAgencyAlignment[] eventAgencyAlignments =
            eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(eventItems, cropName, agencyAbbrs);
            List<MonNumberInfo> monNumbers = monNumberDao.findByEventsAndCrop(eventItems,cropName);
         eventDeregulationStatusList.addAll(eventStatusBuilder.build(eventAgencyAlignments,monNumbers, cropName));
      }
      return eventDeregulationStatusList.toArray(new EventDeregulationStatusWithMonNumber[eventDeregulationStatusList.size()]);
   }
}