/*
package com.monsanto.tps.lexicon.regulatory.helpers;

import com.google.common.collect.Lists;
import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionAdditionalMaterialInfo;
import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionMaterialStructureInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialStructureInfo;

import java.util.List;

public class TransformerUtil {
    public TransformerUtil() {
    }

    public static List<OrionAdditionalMaterialInfo> transform(List<AdditionalMaterial> additionalMaterialList) {
        List<OrionAdditionalMaterialInfo> orionAdditionalMaterialInfoList = Lists.newArrayList();
        if (null != additionalMaterialList && !additionalMaterialList.isEmpty()) {
            for (AdditionalMaterial additionalMaterial : additionalMaterialList) {
                orionAdditionalMaterialInfoList.add(transform(additionalMaterial));
            }
        }
        return orionAdditionalMaterialInfoList;
    }

    public static OrionAdditionalMaterialInfo transform(AdditionalMaterial additionalMaterial) {
        OrionAdditionalMaterialInfo orionAdditionalMaterialInfo = new OrionAdditionalMaterialInfo();
        orionAdditionalMaterialInfo.setActiveStatus(additionalMaterial.getActiveStatus());
        orionAdditionalMaterialInfo.setAdditionalMaterialInfoId(additionalMaterial.getAdditionalMaterialInfoId());
        orionAdditionalMaterialInfo.setAlias(additionalMaterial.getAlias());
        orionAdditionalMaterialInfo.setChemicalNameCAS(additionalMaterial.getChemicalNameCAS());
        orionAdditionalMaterialInfo.setCpNumber(additionalMaterial.getCpNumber());
        orionAdditionalMaterialInfo.setChemicalNameIUPAC(additionalMaterial.getChemicalNameIUPAC());
        orionAdditionalMaterialInfo.setMaterialName(additionalMaterial.getMaterialName());
        orionAdditionalMaterialInfo.setStructureInfo(transform(additionalMaterial.getStructureInfo()));
        return orionAdditionalMaterialInfo;
    }

    public static OrionMaterialStructureInfo transform(MaterialStructureInfo materialStructureInfo) {
        OrionMaterialStructureInfo orionMaterialStructureInfo = new OrionMaterialStructureInfo();
        orionMaterialStructureInfo.setElementalTheory(materialStructureInfo.getElementalTheory());
        orionMaterialStructureInfo.setImageId(materialStructureInfo.getImageId());
        orionMaterialStructureInfo.setImageName(materialStructureInfo.getImageName());
        orionMaterialStructureInfo.setMaterialId(materialStructureInfo.getMaterialId());
        orionMaterialStructureInfo.setMolecularFormula(materialStructureInfo.getMolecularFormula());
        orionMaterialStructureInfo.setMolecularWeight(materialStructureInfo.getMolecularWeight());
        return orionMaterialStructureInfo;
    }
}*/
