package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * rrchak1 - Jun 23, 2009 12:00:09 PM
 */
public class EventStatusWithMonNumberBuilder {
    public List<EventDeregulationStatusWithMonNumber> build(EventAgencyAlignment[] agencyAlignments, List<MonNumberInfo> monNumberInfos, String cropName) {
        Map<String, List<EventAgencyAlignment>> alignments = buildMapByEvent(agencyAlignments);
        Map<String, String> monNumbers = buildMonNumberMap(monNumberInfos);
        return buildEventDeregulationStatus(alignments, monNumbers, cropName);
    }

    private Map<String, String> buildMonNumberMap(List<MonNumberInfo> monNumbers) {
        Map monNumberMap = new HashMap<String, String>(monNumbers.size());
        for (MonNumberInfo monNumberInfo : monNumbers) {
            monNumberMap.put(monNumberInfo.getEvent(), monNumberInfo.getMonNumber());
        }
        return monNumberMap;
    }

    private List<EventDeregulationStatusWithMonNumber> buildEventDeregulationStatus(Map<String, List<EventAgencyAlignment>> alignments, Map<String, String> monNumbers, String cropName) {
        List<EventDeregulationStatusWithMonNumber> eventDeregulationStatusList = new ArrayList<EventDeregulationStatusWithMonNumber>(alignments.size());
        Set<String> events = new HashSet<String>(alignments.keySet());
        events.addAll(monNumbers.keySet());
        for (String event : events) {
            EventDeregulationStatusWithMonNumber eventDeregulationStatus = new EventDeregulationStatusWithMonNumber();
            eventDeregulationStatus.setEventName(event);
            eventDeregulationStatus.setCrop(cropName);
            eventDeregulationStatus.setMonNumber(monNumbers.get(event));

            List<EventAgencyAlignment> alignmentList = alignments.get(event);
            if (alignmentList != null) {
                EventAgencyAlignment[] agencyAlignments = alignmentList.toArray(new EventAgencyAlignment[alignmentList.size()]);
                eventDeregulationStatus.setEventAgencies(new EventAgencies(agencyAlignments).getResponseEventAgencies());
            } else {
                eventDeregulationStatus.setEventAgencies(new EventAgency[0]);
            }

            eventDeregulationStatusList.add(eventDeregulationStatus);
        }
        return eventDeregulationStatusList;
    }

    private Map<String, List<EventAgencyAlignment>> buildMapByEvent(EventAgencyAlignment[] agencyAlignments) {
        Map<String, List<EventAgencyAlignment>> alignments = new HashMap<String, List<EventAgencyAlignment>>(1);
        List<EventAgencyAlignment> alignmentList;
        for (EventAgencyAlignment agencyAlignment : agencyAlignments) {
            if (alignments.containsKey(agencyAlignment.getMaterialName())) {
                alignmentList = alignments.get(agencyAlignment.getMaterialName());
                alignments.remove(agencyAlignment.getMaterialName());
            } else {
                alignmentList = new ArrayList<EventAgencyAlignment>(1);
            }
            alignmentList.add(agencyAlignment);
            alignments.put(agencyAlignment.getMaterialName(), alignmentList);
        }
        return alignments;
    }
}