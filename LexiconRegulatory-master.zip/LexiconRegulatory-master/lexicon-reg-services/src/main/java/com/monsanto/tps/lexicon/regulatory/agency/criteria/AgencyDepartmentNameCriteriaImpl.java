package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * rrchak1 - Oct 15, 2008 3:52:34 PM
 */
public class AgencyDepartmentNameCriteriaImpl
   implements QueryCriteria
{
   private String departmentName;

   public AgencyDepartmentNameCriteriaImpl(String departmentName) {
      this.departmentName = departmentName;
   }

   public Criterion getCriterion() {
      return Restrictions.like("agencyDeptName", convertWildCards(departmentName)).ignoreCase();
   }

   public boolean hasCriteria() {
      return StringUtils.isNotEmpty(departmentName);
   }

   private String convertWildCards(String attribute) {
      return new StdWildcardableCriteria(attribute).oracleVersion();
   }
}
