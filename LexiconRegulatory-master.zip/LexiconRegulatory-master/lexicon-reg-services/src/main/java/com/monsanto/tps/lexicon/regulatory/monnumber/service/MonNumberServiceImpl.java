package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexicon.monnumber.MonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveBatchRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveResponse;
import com.monsanto.tps.lexicon.monnumber.MonNumberService;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStagingDataPointEnum;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.util.MonNumberBeanUtil;
import org.apache.commons.lang.ArrayUtils;

import javax.jws.WebService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 22, 2009
 * Time: 2:54:42 PM
 */
@WebService(endpointInterface = "com.monsanto.tps.lexicon.monnumber.MonNumberService")
public class MonNumberServiceImpl
   implements MonNumberService
{
   private MonNumberDao monNumberDao;
   private MonNumberBeanUtil monNumberBeanUtil;
   private DataPointHolder dataPointHolder;
   MonNumberPersistProcessor monNumberPersistProcessor;

   @Override
   @PerformanceMetric(task = "MonNumberService-findByCrop", comment = "findByCrop")
   public MonNumber[] findByCrop(String cropPubkey) {
      return monNumberBeanUtil.buildMonNumbers(monNumberDao.findByCrop(cropPubkey));
   }

   @Override
   @PerformanceMetric(task = "MonNumberService-findByMonNumber", comment = "findByMonNumber")
   public MonNumber[] findByMonNumber(String monNumber) {
      return monNumberBeanUtil.buildMonNumbers(monNumberDao.findByMonNumber(monNumber));
   }

   @Override
   @PerformanceMetric(task = "MonNumberService-findByMonNumberAndCrop", comment = "findByMonNumberAndCrop")
   public MonNumber[] findByMonNumberAndCrop(String monNumber, String cropPubkey) {
      return monNumberBeanUtil.buildMonNumbers(monNumberDao.findByMonNumberAndCrop(monNumber, cropPubkey));
   }

   @Override
   @PerformanceMetric(task = "MonNumberService-findByConstruct", comment = "findByConstruct")
   public MonNumber[] findByConstruct(String[] constructs) {
      return monNumberBeanUtil.buildMonNumbers(monNumberDao.findByConstruct(constructs));
   }

   @Override
   @PerformanceMetric(task = "MonNumberService-findByPvCode", comment = "findByPvCode")
   public MonNumber[] findByPvCode(String[] pvCodes) {
      return monNumberBeanUtil.buildMonNumbers(monNumberDao.findByPvCode(pvCodes));
   }

   @Override
   @PerformanceMetric(task = "MonNumberService-findAll", comment = "findAll")
   public MonNumber[] findAll() {
      return monNumberBeanUtil.buildMonNumbers(monNumberDao.findAll());
   }

   @Override
   @PerformanceMetric(task = "MonNumberService-save", comment = "save")
   public MonNumberSaveResponse[] save(MonNumberSaveBatchRequest monNumberSaveBatchRequest) {
      Collection<MonNumberSaveResponse> responseList = new ArrayList<MonNumberSaveResponse>();
      MonNumberSaveRequest[] monNumberSaveRequests = monNumberSaveBatchRequest.getMonNumberSaveRequests();
      if (!ArrayUtils.isEmpty(monNumberSaveRequests)) {
         addAuditDataPoints(monNumberSaveRequests[0].getAuditComment(),
            monNumberSaveRequests[0].getAuditRequestor());
         for (MonNumberSaveRequest monNumberSaveRequest : monNumberSaveRequests) {
            responseList.add(monNumberPersistProcessor.processSave(monNumberSaveBatchRequest.isValidateOnly(), monNumberSaveRequest));
         }
         dataPointHolder.clear();
         return responseList.toArray(new MonNumberSaveResponse[monNumberSaveRequests.length]);
      }
      return new MonNumberSaveResponse[0];
   }

   private void addAuditDataPoints(String auditComment, String auditRequestor) {
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), auditComment);
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), auditRequestor);
   }

   // @Override
   @PerformanceMetric(task = "MonNumberService-update", comment = "update")
   public MonNumberSaveResponse[] update(MonNumberSaveBatchRequest monNumberSaveBatchRequest) {
      MonNumberSaveRequest[] monNumberSaveRequests =
         monNumberSaveBatchRequest.getMonNumberSaveRequests();
      Collection<MonNumberSaveResponse> responseList = new ArrayList<MonNumberSaveResponse>();
      if (!ArrayUtils.isEmpty(monNumberSaveRequests)) {
         addAuditDataPoints(monNumberSaveRequests[0].getAuditComment(), monNumberSaveRequests[0].getAuditRequestor());
         for (MonNumberSaveRequest monNumberSaveRequest : monNumberSaveRequests) {
            responseList.add(monNumberPersistProcessor.processUpdate(monNumberSaveBatchRequest.isValidateOnly(), monNumberSaveRequest));
         }
         dataPointHolder.clear();
         return responseList.toArray(new MonNumberSaveResponse[monNumberSaveRequests.length]);
      }
      return new MonNumberSaveResponse[0];
   }

   @PerformanceMetric(task = "MonNumberService-findByEventsAndCrop", comment = "findByEventsAndCrop")
   public List<MonNumberInfo> findByEventsAndCrop(String[] events, String cropName) {
      if (ArrayUtils.isEmpty(events)) {
         return new ArrayList<MonNumberInfo>();
      }
      List<String[]> eventList = splitRequestValues(events);
      List<MonNumberInfo> monNumberInfoList = new ArrayList<MonNumberInfo>();
      for (String[] eventArray : eventList) {
         monNumberInfoList.addAll(monNumberDao.findByEventsAndCrop(eventArray, cropName));
      }
      dataPointHolder.add("Num Retrieved", monNumberInfoList.size());
      return monNumberInfoList;
   }

   @PerformanceMetric(task = "MonNumberService-findByMonNumbers", comment = "findByMonNumbers")
   public List<MonNumberInfo> findByMonNumbers(String[] monNumbers) {
      if (ArrayUtils.isEmpty(monNumbers)) {
         return new ArrayList<MonNumberInfo>();
      }
      List<String[]> monNumbersList = splitRequestValues(monNumbers);
      List<MonNumberInfo> monNumberInfoList = new ArrayList<MonNumberInfo>();
      for (String[] monNumArray : monNumbersList) {
         monNumberInfoList.addAll(monNumberDao.findByMonNumbers(monNumArray));
      }
      dataPointHolder.add("Num Retrieved", monNumberInfoList.size());
      return monNumberInfoList;
   }


   private List<String[]> splitRequestValues(String[] strings) {
      List<String[]> requestValueList = new ArrayList<String[]>();
      for (int i = 0; i < strings.length; i += 1000) {
         requestValueList.add((String[]) ArrayUtils.subarray(strings, i, Math.min(strings.length, i + 1000)));
      }
      return requestValueList;
   }

   public void setMonNumberDao(MonNumberDao monNumberDao) {
      this.monNumberDao = monNumberDao;
   }

   public void setMonNumberBeanUtil(MonNumberBeanUtil monNumberBeanUtil) {
      this.monNumberBeanUtil = monNumberBeanUtil;
   }

   public void setDataPointHolder(DataPointHolder dataPointHolder) {
      this.dataPointHolder = dataPointHolder;
   }

   public void setMonNumberPersistProcessor(MonNumberPersistProcessor monNumberPersistProcessor) {
      this.monNumberPersistProcessor = monNumberPersistProcessor;
   }
}