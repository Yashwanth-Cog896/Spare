/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.midas.model;

import java.io.Serializable;

/* vvkalu - 7/22/11 */
public class ProductGermplasmEntity implements Serializable {
    private long id;
    private boolean preferred;
    private GermplasmEntity germplasm;
    private MidasProductEntity product;

    public MidasProductEntity getProduct() {
        return product;
    }

    public void setProduct(MidasProductEntity product) {
        this.product = product;
    }

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public boolean isPreferred() {
        return preferred;
    }

    public void setPreferred(boolean preferred) {
        this.preferred = preferred;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}