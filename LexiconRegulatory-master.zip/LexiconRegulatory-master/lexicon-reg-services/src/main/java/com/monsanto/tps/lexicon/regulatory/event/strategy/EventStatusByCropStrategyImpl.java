package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventSplitter;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventStatusBuilder;
import com.monsanto.tps.lexicon.regulatory.event.delegate.MaterialStatusBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Jun 23, 2009 11:23:09 AM
 */
public class EventStatusByCropStrategyImpl
        implements EventStatusByCropStrategy {
    private final EventAgencyAlignmentDao eventAgencyAlignmentDao;
    private final EventStatusBuilder eventStatusBuilder;
    private final MaterialStatusBuilder materialStatusBuilder;
    private final EventSplitter eventSplitter;

    public EventStatusByCropStrategyImpl(EventAgencyAlignmentDao eventAgencyAlignmentDao, EventStatusBuilder eventStatusBuilder, EventSplitter eventSplitter, MaterialStatusBuilder materialStatusBuilder) {
        this.eventAgencyAlignmentDao = eventAgencyAlignmentDao;
        this.eventStatusBuilder = eventStatusBuilder;
        this.eventSplitter = eventSplitter;
        this.materialStatusBuilder = materialStatusBuilder;
    }

    @Override
    public EventDeregulationStatus[] find(String[] events, String cropName) {
        List<String[]> eventList = eventSplitter.splitEvents(events);
        List<EventDeregulationStatus> eventDeregulationStatusList = new ArrayList<EventDeregulationStatus>();
        for (String[] eventItems : eventList) {
            EventAgencyAlignment[] eventAgencyAlignments =
                    eventAgencyAlignmentDao.findByEventsCrop(eventItems, cropName);
            eventDeregulationStatusList.addAll(eventStatusBuilder.build(eventAgencyAlignments, cropName));
        }
        return eventDeregulationStatusList.toArray(new EventDeregulationStatus[eventDeregulationStatusList.size()]);
    }

    @Override
    public AgencyMaterialDeregulationStatus[] findByMaterialName(String[] materialNames, String cropName) {
        List<String[]> materialList = eventSplitter.splitEvents(materialNames);
        List<AgencyMaterialDeregulationStatus> agencyDeregulationStatusList = new ArrayList<AgencyMaterialDeregulationStatus>();
        for (String[] materials : materialList) {
            EventAgencyAlignment[] eventAgencyAlignments =
                    eventAgencyAlignmentDao.findByMaterialCrop(materials, cropName);
            agencyDeregulationStatusList.addAll(materialStatusBuilder.build(eventAgencyAlignments, cropName));
        }
        return agencyDeregulationStatusList.toArray(new AgencyMaterialDeregulationStatus[agencyDeregulationStatusList.size()]);
    }
}
