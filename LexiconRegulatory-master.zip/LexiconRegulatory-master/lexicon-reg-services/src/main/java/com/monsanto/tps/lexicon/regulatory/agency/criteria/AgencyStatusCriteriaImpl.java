package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import com.monsanto.dbdataservices.SQLUtil;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * rrchak1 - Oct 17, 2008 2:55:06 PM
 */
public class AgencyStatusCriteriaImpl
   implements QueryCriteria
{
   private boolean includeInactive;

   public AgencyStatusCriteriaImpl(boolean includeInactive) {
      this.includeInactive = includeInactive;
   }

   public Criterion getCriterion() {
      return Restrictions.eq("active", SQLUtil.booleanToString(true));
   }

   public boolean hasCriteria() {
      return !includeInactive;
   }
}
