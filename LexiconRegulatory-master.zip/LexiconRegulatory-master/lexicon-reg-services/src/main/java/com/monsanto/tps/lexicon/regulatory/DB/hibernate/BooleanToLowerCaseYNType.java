package com.monsanto.tps.lexicon.regulatory.DB.hibernate;

import org.hibernate.type.CharBooleanType;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 28, 2009
 * Time: 12:22:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class BooleanToLowerCaseYNType
   extends CharBooleanType
{
   protected String getFalseString() {
      return "n";
   }

   protected String getTrueString() {
      return "y";
   }
}
