package com.monsanto.tps.lexicon.regulatory.event.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * nbwald - Jan 7, 2009 4:47:13 PM
 */
public class EventAgencyAlignmentDaoImpl
        implements EventAgencyAlignmentDao {
    private SessionFactory sessionFactory;

    public EventAgencyAlignment[] findByEventAndCrop(String eventName, String crop) {
        Session session = sessionFactory.getCurrentSession();
        List<EventAgencyAlignment> eventAgencyAlignments = new ArrayList<EventAgencyAlignment>(
                session.getNamedQuery("eventAgencyAlignment.byEventAndCrop").
                        setString(0, StringUtils.toUpperCaseNull(eventName)).
                        setString(1, StringUtils.toUpperCaseNull(crop)).
                        list());
        return eventAgencyAlignments.toArray(new EventAgencyAlignment[eventAgencyAlignments.size()]);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public EventAgencyAlignment save(EventAgencyAlignment eventAgencyAlignment)
            throws WrappingException {
        try {
            eventAgencyAlignment.setEventAgencyAlignmentPubkey(getEventAgencyAlignmentPubkey());
            sessionFactory.getCurrentSession().save(eventAgencyAlignment);
        } catch (HibernateException e) {
            throw new WrappingException(e);
        }
        return eventAgencyAlignment;
    }

    private String getEventAgencyAlignmentPubkey() {
        Session session = sessionFactory.getCurrentSession();
        return String.valueOf(session.getNamedQuery("selectEventAgencyAlignmentPubkeySequence").uniqueResult());
    }

    public void update(EventAgencyAlignment eventAgencyAlignment)
            throws WrappingException {
        try {
            sessionFactory.getCurrentSession().update(eventAgencyAlignment);
        } catch (HibernateException e) {
            throw new WrappingException(e);
        }
    }

    public EventAgencyAlignment findByEventCropAndAgencyPubkey(String eventName, String cropName, String agencyPubkey) {
        Session session = sessionFactory.getCurrentSession();
        return (EventAgencyAlignment) session.
                getNamedQuery("eventAgencyAlignment.byEventCropAndAgencyPubkey").
                setString(0, StringUtils.toUpperCaseNull(eventName)).
                setString(1, StringUtils.toUpperCaseNull(cropName)).
                setString(2, agencyPubkey).
                uniqueResult();
    }

    public EventAgencyAlignment[] findByPubkey(String[] eventAgencyAlignmentPubkey) {
        Session session = sessionFactory.getCurrentSession();
        List<EventAgencyAlignment> eventAgencyAlignmentList =
                session.
                        getNamedQuery("eventAgencyAlignment.byPubkey").
                        setParameterList("pubkeyList", eventAgencyAlignmentPubkey).
                        list();
        return eventAgencyAlignmentList.toArray(new EventAgencyAlignment[eventAgencyAlignmentList.size()]);
    }

    public EventAgencyAlignment[] findByAgencyAbbr(String[] agencyAbbreviation) {
        Session session = sessionFactory.getCurrentSession();
        List<EventAgencyAlignment> eventAgencyAlignmentList =
                session.
                        getNamedQuery("eventAgencyAlignment.byAgencyAbbr").
                        setParameterList("agencyAbbrList", toUpperCase(agencyAbbreviation)).
                        list();
        return eventAgencyAlignmentList.toArray(new EventAgencyAlignment[eventAgencyAlignmentList.size()]);
    }

    @Override
    public EventAgencyAlignment[] findByEventsCropAndAgencyAbbrs(String[] events, String cropName, String[] agencyAbbrs) {
        Session session = sessionFactory.getCurrentSession();
        List<EventAgencyAlignment> eventAgencyAlignmentList =
                session.
                        getNamedQuery("eventAgencyAlignment.byEventsCropAndAgencyAbbrs").
                        setParameterList("events", toUpperCase(events)).
                        setParameter("crop", cropName.toUpperCase()).
                        setParameterList("agencyAbbrList", toUpperCase(agencyAbbrs)).
                        list();
        return eventAgencyAlignmentList.toArray(new EventAgencyAlignment[eventAgencyAlignmentList.size()]);

    }


    @Override
    public EventAgencyAlignment[] findByEventsCrop(String[] events, String cropName) {
        Session session = sessionFactory.getCurrentSession();
        List<EventAgencyAlignment> eventAgencyAlignmentList =
                session.
                        getNamedQuery("eventAgencyAlignment.byEventsCrop").
                        setParameterList("events", toUpperCase(events)).
                        setParameter("crop", cropName.toUpperCase()).
                        list();
        return eventAgencyAlignmentList.toArray(new EventAgencyAlignment[eventAgencyAlignmentList.size()]);

    }

    @Override
    public EventAgencyAlignment[] findByMaterialCrop(String[] materials, String cropName) {
        Session session = sessionFactory.getCurrentSession();
        List<EventAgencyAlignment> eventAgencyAlignmentList =
                session.
                        getNamedQuery("eventAgencyAlignment.byMaterialsCrop").
                        setParameterList("materials", toUpperCase(materials)).
                        setParameter("crop", cropName.toUpperCase()).
                        list();
        return eventAgencyAlignmentList.toArray(new EventAgencyAlignment[eventAgencyAlignmentList.size()]);

    }

    @Override
    public AgencyMaterialType getAgencyMaterialTypeIdByName(String agencyMaterialTypeDesc) {

        Session session = sessionFactory.getCurrentSession();
        return (AgencyMaterialType) session.getNamedQuery("agencyMaterialType.byMaterialTypeDesc").
                setString(0, agencyMaterialTypeDesc).uniqueResult();
    }

    private Collection<String> toUpperCase(String[] strings) {
        Collection<String> uppercasedStrings = new ArrayList<String>();
        for (String string : strings) {
            uppercasedStrings.add(StringUtils.toUpperCaseNull(string));
        }
        return uppercasedStrings;
    }
}
