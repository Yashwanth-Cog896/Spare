package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * nbwald - Mar 9, 2009 2:02:51 PM
 */
public class RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl
   implements RegulatoryEventConstructTransformation
{
   private final String event;
   private final String construct;

   public RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.event = row.getString(RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.EVENT_ALIAS);
      this.construct = row.getString(RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.CONSTRUCT_ALIAS);
   }

   public RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(String event, String construct) {
      this.event = event;
      this.construct = construct;
   }

   @Override
   public String getEvent() {
      return event;
   }

   @Override
   public String getConstruct() {
      return construct;
   }

   @Override
   public String getTransformationBackground() {
      return null; // takes too long to look up
   }
}
