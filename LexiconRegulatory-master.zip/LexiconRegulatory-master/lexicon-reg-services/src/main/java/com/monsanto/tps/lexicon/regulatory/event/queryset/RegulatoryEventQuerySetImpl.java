package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.crop.MidasGenusSpeciesByCropNameQuery;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.RegulatoryEventConstructTransformationByEventNameAndCropQuery;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery;
import com.monsanto.tps.lexicon.regulatory.event.dao.productvector.ProductVectorDao;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.io.IOException;
import java.util.List;

/**
 * User: pjberry
 * Date: Jul 30, 2007
 * Time: 1:47:11 PM
 */
public class RegulatoryEventQuerySetImpl
        implements RegulatoryEventQuerySet {
    private ProductVectorDao productVectorDao;

    public RegulatoryEventQuerySetImpl(ProductVectorDao productVectorDao) {
        this.productVectorDao = productVectorDao;
    }

    public RegulatoryEventConstructTransformation[] getEventConstructTransformations(String eventName, String cropGenusSpecies)
            throws WrappingException, IOException {
        RegulatoryEventConstructTransformationByEventNameAndCropQuery query =
                new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(eventName, cropGenusSpecies);
        return query.getEventConstructTransformations();
    }

/*   public String[] getTransCodesForSinglePmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException
   {
      TransCodesByEventSinglePmonConstructAndCropQuery transCodesQuery =
         new TransCodesByEventSinglePmonConstructAndCropQuery(transCodeQueryParams.materialName(), transCodeQueryParams.getConstruct(), transCodeQueryParams.getCropGenusSpecies());
      return transCodesQuery.getTransCodes();
   }

   public String getTransCodeForMultiPmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException
   {
      TransCodeByEventMultiPmonConstructAndCropQuery transCodeQuery =
         new TransCodeByEventMultiPmonConstructAndCropQuery(transCodeQueryParams.materialName(), transCodeQueryParams.getConstruct(), transCodeQueryParams.getCropGenusSpecies());
      return transCodeQuery.getTransCode();
   }*/

    public String getGenusSpecies(String requestedCrop)
            throws WrappingException {
        MidasGenusSpeciesByCropNameQuery genusSpeciesQuery = new MidasGenusSpeciesByCropNameQuery(requestedCrop);
        return genusSpeciesQuery.getGenusSpecies();
    }

    @Override
    public String[] findProductVectorsByCropIdAndConstructNameForCombinedConstructs(long cropPubkey, String[] constructNames) {
        return productVectorDao.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(cropPubkey, constructNames);
    }

    @Override
    public String[] findProductVectorsByCropIdAndConstructNameForSingleConstructs(long cropPubkey, String constructName) {
        return productVectorDao.findProductVectorsByCropIdAndConstructNameForSingleConstructs(cropPubkey, constructName);
    }

    @Override
    public List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers) {
        return productVectorDao.findProductVectorsByCropIdAndConstructs(cropPubkey, constructIdentifiers);
    }

}
