/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.plantname.business;

import com.monsanto.tps.lexicon.commercialtrait.CommercialTraitService;
import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.plantname.comparator.OrionPlantProductComparator;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@Component
public class OrionPlantNameBusiness {
    @Resource
    private PlantNameBusiness plantNameBusiness;
    @Resource
    private RegulatorySeedMaterialBusiness regulatorySeedMaterialBusiness;
    @Resource(name = "lexicon.commercialtraitstack.service")
    private CommercialTraitService commercialTraitService;


    public List<OrionPlantProduct> findPlantNames(String productName) {
        List<OrionPlantProduct> combinedResults = new ArrayList<OrionPlantProduct>();
        combinedResults.addAll(plantNameBusiness.findPlantNames(productName));
        combinedResults.addAll(regulatorySeedMaterialBusiness.findPlantNames(productName));
        combinedResults.addAll(getTraitStackResults(productName));
        filterResults(combinedResults);
        Collections.sort(combinedResults, new OrionPlantProductComparator());
        return combinedResults;
    }

    private List<OrionPlantProduct> getTraitStackResults(String productName) {
        List<OrionPlantProduct> plantNames = commercialTraitService.findCommercialTraitStacksByDesc(productName);
        return plantNames == null ? new ArrayList<OrionPlantProduct>() : plantNames;
    }

    private void filterResults(List<OrionPlantProduct> combinedResults) {
        for (Iterator<OrionPlantProduct> it = combinedResults.iterator(); it.hasNext(); ) {
            OrionPlantProduct info = it.next();
            if (info.getName().length() > 80) {
                it.remove();
            }
        }
    }
}