/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.services.ProductVectorLookupService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/* vvkalu - 8/12/11 */
public class PVCodesBuilder {
    public static final String FORWARD_SLASH = "/";
    public static final String COMMA = ",";
    private ProductVectorLookupService productVectorLookupService;
    private CropDao cropDao;

    public Multimap<Long, ConstructPVCodeAssignment> getConstructIdToPVCodesMap(Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap,
                                                                                Multimap<String, MonNumber> eventToMonNumberMap) {
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();
        for (String eventName : eventsToEventConstructsMap.keySet()) {
            Collection<MonNumber> monNumbers = eventToMonNumberMap.get(eventName);
            Collection<GermplasmEventConstructEntity> eventConstructs = eventsToEventConstructsMap.get(eventName);
            if (eventConstructs != null && !eventConstructs.isEmpty()) {
                List<String> eventConstructForEventName = getEventConstructsForEventName(eventConstructs);
                List<ConstructIdentifier> constructIdentifiers = buildConstructIdentifiers(eventConstructForEventName);
                List<ConstructPVCodeAssignment> vectorsByCropIdAndConstructs = getPVCodesForEventConstructs(monNumbers, eventConstructs, constructIdentifiers);
                if (vectorsByCropIdAndConstructs != null && !vectorsByCropIdAndConstructs.isEmpty()) {
                    for (ConstructPVCodeAssignment pvCodeAssignment : vectorsByCropIdAndConstructs) {
                        constructIdToPVCodesMap.put(eventConstructs.iterator().next().getEventConstruct().getId(), pvCodeAssignment);
                    }
                }
            }
        }
        return constructIdToPVCodesMap;
    }

    private List<ConstructPVCodeAssignment> getPVCodesForEventConstructs(Collection<MonNumber> monNumbers,
                                                                         Collection<GermplasmEventConstructEntity> eventConstructs,
                                                                         List<ConstructIdentifier> constructIdentifiers) {
        List<ConstructPVCodeAssignment> vectorsByCropIdAndConstructs;
        if (monNumbers != null && !monNumbers.isEmpty()) {
            Long cropPubkeyLongVal = Long.valueOf(monNumbers.iterator().next().getCrop().getCropPubkey());
            vectorsByCropIdAndConstructs = productVectorLookupService.findProductVectorsByCropIdAndConstructs(cropPubkeyLongVal, constructIdentifiers);
        } else {
            vectorsByCropIdAndConstructs = getPvCodesForLexiconCrops(eventConstructs.iterator().next(), constructIdentifiers);
        }
        return vectorsByCropIdAndConstructs;
    }

    private List<String> getEventConstructsForEventName(Collection<GermplasmEventConstructEntity> eventConstructs) {
        List<String> eventConstructsForEventName = new ArrayList<String>();
        for (GermplasmEventConstructEntity eventConstruct : eventConstructs) {
            String constructName = eventConstruct.getEventConstruct().getConstructName();
            if (constructName.contains(FORWARD_SLASH) || constructName.contains(COMMA)) {
                eventConstructsForEventName.addAll(Arrays.asList(split(constructName)));
            } else {
                eventConstructsForEventName.add(constructName);
            }
        }
        return eventConstructsForEventName;
    }

    private List<ConstructIdentifier> buildConstructIdentifiers(List<String> constructNames) {
        List<ConstructIdentifier> constructIdentifiers = new ArrayList<ConstructIdentifier>();
        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(constructNames);
        constructIdentifiers.add(constructIdentifier);
        return constructIdentifiers;
    }

    private List<ConstructPVCodeAssignment> getPvCodesForLexiconCrops(GermplasmEventConstructEntity germplasmEventConstruct,
                                                                      List<ConstructIdentifier> constructs) {
        List<ConstructPVCodeAssignment> constructPVCodeAssignments = new ArrayList<ConstructPVCodeAssignment>();
        String cropName = germplasmEventConstruct.getGermplasm().getCrop().getName();
        Crop lexiconCrop = cropDao.findByName(cropName);
        String cropGenusSpecies = lexiconCrop.getAbbreviation();
        List<Crop> cropsInSpecies = cropDao.findByAbbreviation(cropGenusSpecies);
        for (Crop crop : cropsInSpecies) {
            long cropPubkeyLongVal = Long.valueOf(crop.getCropPubkey());
            List<ConstructPVCodeAssignment> pvCodeAssignments = productVectorLookupService.findProductVectorsByCropIdAndConstructs(cropPubkeyLongVal, constructs);
            if (pvCodeAssignments != null && !pvCodeAssignments.isEmpty()) {
                constructPVCodeAssignments.addAll(pvCodeAssignments);
            }
        }
        return constructPVCodeAssignments;
    }

    private String[] split(String construct) {
        if (construct.contains(FORWARD_SLASH)) {
            return StringUtils.split(construct, FORWARD_SLASH);
        } else if (construct.contains(COMMA)) {
            return StringUtils.split(construct, COMMA);
        }
        return new String[]{construct};
    }

    public void setProductVectorLookupService(ProductVectorLookupService productVectorLookupService) {
        this.productVectorLookupService = productVectorLookupService;
    }

    public void setCropDao(CropDao cropDao) {
        this.cropDao = cropDao;
    }
}