package com.monsanto.tps.lexicon.regulatory.monnumber.validation;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import org.apache.commons.lang.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * rrchak1 - May 7, 2009 9:44:28 AM
 */
public class MonNumberSaveRequestValidator
   implements Validator
{
   protected MonNumberDao monNumberDao;

   @Override
   public boolean supports(Class clazz) {
      return MonNumberSaveRequest.class.equals(clazz);
   }

   @Override
   //Todo to refactor
   public void validate(Object target, Errors errors) {
      MonNumberSaveRequest request = (MonNumberSaveRequest) target;
      ValidationUtils.rejectIfEmptyOrWhitespace(
         errors, "monNumber", "monNumber.required", "Mon Number format must be MON 99999(-)."
      );
      if (StringUtils.isNotEmpty(request.getMonNumber())) {
         validateMonNumberFormat(request.getMonNumber(), errors);
         if (errors.getFieldErrorCount("monNumber") == 0) {
            validateMonNumberExists(request.getMonNumber(), errors);
         }
      }

      ValidationUtils.rejectIfEmptyOrWhitespace(
         errors, "cropPubkey", "cropPubkey.required", "Crop Pubkey may not be empty."
      );

      if (StringUtils.isNotEmpty(request.getOecdNumber())) {
         if (request.getOecdNumber().indexOf(" ") != -1) {
            errors.rejectValue("oecdNumber", "oecdNumber.format", "OECD Number cannot have space.");
         }
         if (errors.getFieldErrorCount("oecdNumber") == 0) {
            validateOecdNumberExists(request.getOecdNumber(), request.getMonNumber(), errors);
         }
      }
      if (ArrayUtils.isNullOrEmpty(request.getTraitNameAbbreviations()) && ArrayUtils.isNullOrEmpty(request.getTraitTypeAbbreviations())) {
         errors.rejectValue("traitTypeAbbreviations", "traitTypeAbbreviations.required", "Regulatory Trait Description may not be empty.");
      }

      ValidationUtils.rejectIfEmptyOrWhitespace(
         errors, "regulatoryGenesPresent", "regulatoryGenesPresent.required", "Regulatory Genes Present may not be empty."
      );

      ValidationUtils.rejectIfEmptyOrWhitespace(
         errors, "regulatoryParentalLine", "regulatoryParentalLine.required", "Regulatory Parental Line may not be empty."
      );

      ValidationUtils.rejectIfEmptyOrWhitespace(
         errors, "auditComment", "auditComment.required", "Audit Comment field must not be blank."
      );
      validateEventExists(request.getEvent(), request.getMonNumber(), errors);

      ValidationUtils.rejectIfEmptyOrWhitespace(
         errors, "auditRequestor", "auditRequestor.required", "Audit Requestor must not be blank."
      );
   }

   protected void validateOecdNumberExists(String oecdNumber, String monNumber, Errors errors) {
      if (null != monNumberDao.findByOecdNumber(oecdNumber)) {
         errors.rejectValue("oecdNumber", "oecdNumber.exists", "OECD Number is already defined.");
      }
   }

   protected void validateEventExists(String event, String monNumber, Errors errors) {
      if (null != monNumberDao.findByEvent(event)) {
         errors.rejectValue("event", "event.exists", "Duplicate Event; " + event + " is already defined.");
      }
   }

   protected void validateMonNumberExists(String monNumber, Errors errors) {
      if (null != monNumberDao.find(monNumber)) {
         errors.rejectValue("monNumber", "monNumber.exists", "Mon Number is already defined.");
      }
   }

   private void validateMonNumberFormat(String monNumber, Errors errors) {
      Pattern p = Pattern.compile("MON (([0-9]){5})(\\(-\\))?+");
      Matcher m = p.matcher(monNumber.trim());
      if (!m.matches()) {
         errors.rejectValue("monNumber", "monNumber.format", "Mon Number format must be MON 99999(-).");
      }
   }

   public void setMonNumberDao(MonNumberDao monNumberDao) {
      this.monNumberDao = monNumberDao;
   }
}
