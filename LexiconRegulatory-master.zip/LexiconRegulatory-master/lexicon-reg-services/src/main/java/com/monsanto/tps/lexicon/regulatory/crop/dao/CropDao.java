package com.monsanto.tps.lexicon.regulatory.crop.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;

import java.util.List;

/**
 * rrchak1 - Feb 13, 2009 1:40:11 PM
 */
public interface CropDao
{
   Crop findByName(String cropName);

   Crop findByPubkey(String cropPubkey);

    public List<Crop> findByAbbreviation(String genusSpecies);

   Crop[] findAll();
}
