package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import java.util.List;

/**
 * nbwald - May 28, 2009 4:25:15 PM
 */
public class ValidationResults
{
   private final List<String> errors;
   private final List<String> warnings;

   public ValidationResults(List<String> errors, List<String> warnings) {
      this.errors = errors;
      this.warnings = warnings;
   }

   public boolean isSuccess() {
      return errors.isEmpty();
   }

   public String[] getMessages() {
      List<String> message = errors.isEmpty() ? warnings : errors;
      return message.toArray(new String[message.size()]);
   }
}
