package com.monsanto.tps.lexicon.regulatory.agency.util;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;

import java.util.HashMap;
import java.util.Map;

/**
 * rrchak1 - Oct 20, 2008 3:19:25 PM
 */
public class AgencyBeanUtil
{
   public Agency[] buildAgencies(AgencyDepartment[] departments)
      throws WrappingException
   {
      Map<Long, Agency> agencyMap = new HashMap<Long, Agency>();
      for (AgencyDepartment department : departments) {
         com.monsanto.tps.lexicon.agency.AgencyDepartment dept = new com.monsanto.tps.lexicon.agency.AgencyDepartment();
         Agency ag = new Agency();
         copyAgencyDepartmentProperties(dept, department);
         com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency agency = department.getAgency();
         copyAgencyProperties(ag, agency);
         if (agencyMap.containsKey(ag.getAgencyId())) {
            Agency temp = agencyMap.get(ag.getAgencyId());
            temp.getDepartments().add(dept);
         }
         else {
            ag.getDepartments().add(dept);
            agencyMap.put(ag.getAgencyId(), ag);
         }
      }
      return agencyMap.values().toArray(new Agency[agencyMap.size()]);
   }

   private void copyAgencyProperties(Agency ag, com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency agency) {
      ag.setActive(SQLUtil.stringToBoolean(agency.getActive()));
      ag.setAgencyAbbr(agency.getAgencyAbbr());
      ag.setAgencyId(agency.getAgencyId());
      ag.setAgencyName(agency.getAgencyName());
      ag.setAgencyPubkey(agency.getAgencyPubkey());
      ag.setCountryIsoCode(agency.getCountry().getIsoCode());
      ag.setSurfaceAreaUomCode(agency.getSurfaceAreaUomCode());
   }

   private void copyAgencyDepartmentProperties(com.monsanto.tps.lexicon.agency.AgencyDepartment dept, AgencyDepartment department) {
      dept.setActive(SQLUtil.stringToBoolean(department.getActive()));
      dept.setAddress1(department.getAddress1());
      dept.setAddress2(department.getAddress2());
      dept.setAgencyDeptAbbr(department.getAgencyDeptAbbr());
      dept.setAgencyDeptId(department.getAgencyDeptId());
      dept.setAgencyDeptName(department.getAgencyDeptName());
      dept.setAgencyDeptPubkey(department.getAgencyDeptPubkey());
      dept.setCity(department.getCity());
      dept.setPostalCode(department.getPostalCode());
      dept.setSubCountryAbbr(department.getSubCountryAbbr());
      dept.setSubSubCountryName(department.getSubSubCountryName());
   }

   public AgencyDepartment buildAgencyDepartmentDBObject(AgencySaveUpdateRequest agencySaveUpdateRequest) {
      AgencyDepartment dbdepartment = new AgencyDepartment();
      dbdepartment.setActive("y");
      dbdepartment.setAddress1(agencySaveUpdateRequest.getAddress1());
      dbdepartment.setAddress2(agencySaveUpdateRequest.getAddress2());
      dbdepartment.setAgencyDeptAbbr(agencySaveUpdateRequest.getAgencyDeptAbbr());
      dbdepartment.setAgencyDeptName(agencySaveUpdateRequest.getAgencyDeptName());
      dbdepartment.setCity(agencySaveUpdateRequest.getCity());
      dbdepartment.setPostalCode(agencySaveUpdateRequest.getPostalCode());
      dbdepartment.setSubCountryAbbr(agencySaveUpdateRequest.getSubCountryAbbr());
      dbdepartment.setSubSubCountryName(agencySaveUpdateRequest.getSubSubCountryName());
      dbdepartment.setAgency(buildAgencyDBObject(agencySaveUpdateRequest));
      dbdepartment.setAgencyDeptPubkey(agencySaveUpdateRequest.getAgencyDeptPubkey());
      return dbdepartment;
   }

   private com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency buildAgencyDBObject(AgencySaveUpdateRequest agencySaveUpdateRequest) {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency dbAgency = new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency();
      dbAgency.setActive(SQLUtil.booleanToString(agencySaveUpdateRequest.isActive()));
      dbAgency.setAgencyAbbr(agencySaveUpdateRequest.getAgencyAbbr());
      dbAgency.setAgencyName(agencySaveUpdateRequest.getAgencyName());
      Country country = new Country();
      country.setIsoCode(agencySaveUpdateRequest.getCountryIsoCode());
      dbAgency.setCountry(country);
      dbAgency.setSurfaceAreaUomCode(agencySaveUpdateRequest.getSurfaceAreaUomCode());
      dbAgency.setAgencyPubkey(agencySaveUpdateRequest.getAgencyPubkey());
      return dbAgency;
   }

}
