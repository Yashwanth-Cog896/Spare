/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.service;

import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexicon.eventtraitservice.GermplasmEventTraitService;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitRequest;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.EventTraitBusiness;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.EventTraitServiceBusiness;

import javax.jws.WebParam;
import java.util.List;

/* vvkalu - 7/26/11 */
public class EventTraitServiceImpl implements GermplasmEventTraitService {

    private EventTraitServiceBusiness eventTraitServiceBusiness;
    private EventTraitBusiness eventTraitBusiness;

    @Override
    @PerformanceMetric(task = "EventTraitService-germplasmTraitEventConstructs", comment = "getGermplasmTraitEventConstructs")
    public GermplasmEventTraitResponse getGermplasmTraitEventConstructs(@WebParam(name = "germplasmEventTraitRequest")
                                                                        GermplasmEventTraitRequest germplasmEventTraitRequest) {
        return eventTraitServiceBusiness.getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
    }

    @Override
    @PerformanceMetric(task = "EventTraitService-getComTraitStackIdByEventConstructs", comment = "etComTraitStackIdByEventConstructs")
    public List<Long> getComTraitStackIdByEventConstructs(@WebParam(name = "germplasmId") long germplasmId) {
        return eventTraitBusiness.getComTraitStackIdByEventConstructs(germplasmId);
    }

    public void setEventTraitServiceBusiness(EventTraitServiceBusiness eventTraitServiceBusiness) {
        this.eventTraitServiceBusiness = eventTraitServiceBusiness;
    }

    public void setEventTraitBusiness(EventTraitBusiness eventTraitBusiness) {
        this.eventTraitBusiness = eventTraitBusiness;
    }
}