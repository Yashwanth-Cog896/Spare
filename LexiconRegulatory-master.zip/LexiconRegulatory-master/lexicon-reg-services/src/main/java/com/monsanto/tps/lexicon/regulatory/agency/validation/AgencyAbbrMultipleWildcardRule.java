package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Oct 21, 2008 4:01:02 PM
 */
public class AgencyAbbrMultipleWildcardRule
   implements Rule
{
   private String[] agencyAbbr;

   public AgencyAbbrMultipleWildcardRule(String[] agencyAbbr) {
      this.agencyAbbr = agencyAbbr;
   }

   public boolean violated() {
      if (!ArrayUtils.isEmpty(agencyAbbr)) {
         int wildCardCount = 0;
         for (String abbr : agencyAbbr) {
            if (abbr.contains("*")) {
               ++wildCardCount;
            }
            if (wildCardCount > 1) {
               return true;
            }
         }
      }
      return false;
   }

   public Object getViolation() {
      return "Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.";
   }
}
