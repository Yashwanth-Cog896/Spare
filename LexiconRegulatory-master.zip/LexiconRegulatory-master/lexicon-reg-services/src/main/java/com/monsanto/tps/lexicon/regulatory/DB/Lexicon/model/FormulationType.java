package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class FormulationType {

    private long formulationTypeId;
    private String formulationType;
    private String formulationTypeDescription;
    private boolean activeStatus;

    public FormulationType() {}

    public FormulationType(String containerType, String storageCondition, boolean activeStatus) {
        this.formulationType = containerType;
        this.formulationTypeDescription = storageCondition;
        this.activeStatus = activeStatus;
    }

    public long getFormulationTypeId() {
        return formulationTypeId;
    }

    public String getFormulationType() {
        return formulationType;
    }

    public void setFormulationType(String formulationType) {
        this.formulationType = formulationType;
    }

    public String getFormulationTypeDescription() {
        return formulationTypeDescription;
    }

    public void setFormulationTypeDescription(String formulationTypeDescription) {
        this.formulationTypeDescription = formulationTypeDescription;
    }

    public boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
