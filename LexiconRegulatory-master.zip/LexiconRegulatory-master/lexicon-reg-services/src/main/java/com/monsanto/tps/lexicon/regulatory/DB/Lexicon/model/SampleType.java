package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/6/12
 * Time: 9:18 AM
 * To change this template use File | Settings | File Templates.
 */
public class SampleType {

    private long sampleTypeId;
    private String sampleType;
    private String containerType;
    private String storageCondition;
    private String sampleTypeDescription;
    private boolean activeStatus;

    public SampleType() {
    }

    public SampleType(String sampleType, String containerType, String storageCondition, String sampleTypeDescription, boolean activeStatus) {
        this.sampleType = sampleType;
        this.containerType = containerType;
        this.storageCondition = storageCondition;
        this.sampleTypeDescription = sampleTypeDescription;
        this.activeStatus = activeStatus;
    }

    public long getSampleTypeId() {
        return sampleTypeId;
    }

    public String getSampleType() {
        return sampleType;
    }

    public void setSampleType(String sampleType) {
        this.sampleType = sampleType;
    }

    public String getContainerType() {
        return containerType;
    }

    public void setContainerType(String containerType) {
        this.containerType = containerType;
    }

    public String getStorageCondition() {
        return storageCondition;
    }

    public void setStorageCondition(String storageCondition) {
        this.storageCondition = storageCondition;
    }

    public String getSampleTypeDescription() {
        return sampleTypeDescription;
    }

    public void setSampleTypeDescription(String sampleTypeDescription) {
        this.sampleTypeDescription = sampleTypeDescription;
    }

    public boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
