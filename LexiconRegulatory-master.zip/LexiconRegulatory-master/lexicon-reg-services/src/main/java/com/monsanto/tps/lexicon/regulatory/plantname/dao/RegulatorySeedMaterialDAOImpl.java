package com.monsanto.tps.lexicon.regulatory.plantname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantProduct;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/19/12
 * Time: 10:05 PM
 */
@Component
public class RegulatorySeedMaterialDAOImpl implements RegulatorySeedMaterialDAO {
    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<PlantProduct> findMonsantoProductNames(final String productName) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findMonsantoPlantProduct");
        query.setParameter("productName", WildcardUtil.replaceEmptyStringWithWildcard(productName));

        return (List<PlantProduct>) query.list();
    }

    @Override
    public List<PlantProduct> findCompetitorProductNames(final String productName) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findCompetitorPlantProduct");
        query.setParameter("productName", WildcardUtil.replaceEmptyStringWithWildcard(productName));

        return (List<PlantProduct>) query.list();
    }
}
