package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.query.PreparedStatementAttributes;

/**
 * User: pjberry
 * Date: Jul 27, 2007
 * Time: 10:38:47 AM
 */
public class GermplasmByStackedEventPreparedStatementAttributes
   implements PreparedStatementAttributes
{
   private final String event;

   public GermplasmByStackedEventPreparedStatementAttributes(String event) {
      this.event = event;
   }

   public String getSQL()
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.class);
      return sqlPropFile.getSQL(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.SELECT_GERMPLASM_ID_BY_EVENT);
   }

   public Object[] getBindVariables() {
      return new Object[]{event};
   }
}