package com.monsanto.tps.lexicon.regulatory.eventsreginfo.domain.lexicon;

import java.sql.Timestamp;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Oct 5, 2010
 * Time: 1:19:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconRegEvent {

    private Long monNumberId;
    private String event;
    private String materialName;
    private String previousNames;
    private String plasmIdPmon;
    private String plasmIdPvCode;
    private String transformationBackground;
    private String regulatoryTraitDescription;
    private String regulatoryGenesPresent;
    private String oecdNumber;
    private Timestamp oecdNumberCommunicationDate;
    private Boolean regulatedStatus;
    private String jvNumber;
    private Boolean locked;
    private Boolean activeStatus;
    private String recType;
    private String monNumber;
    private String crop;

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getMonNumber() {
        return monNumber;
    }

    public void setMonNumber(String monNumber) {
        this.monNumber = monNumber;
    }

    public String getRecType() {
        return recType;
    }

    public void setRecType(String recType) {
        this.recType = recType;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Boolean getLocked() {
        return locked;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public String getJvNumber() {
        return jvNumber;
    }

    public void setJvNumber(String jvNumber) {
        this.jvNumber = jvNumber;
    }

    public Boolean getRegulatedStatus() {
        return regulatedStatus;
    }

    public void setRegulatedStatus(Boolean regulatedStatus) {
        this.regulatedStatus = regulatedStatus;
    }

    public Timestamp getOecdNumberCommunicationDate() {
        return oecdNumberCommunicationDate;
    }

    public void setOecdNumberCommunicationDate(Timestamp oecdNumberCommunicationDate) {
        this.oecdNumberCommunicationDate = oecdNumberCommunicationDate;
    }

    public String getOecdNumber() {
        return oecdNumber;
    }

    public void setOecdNumber(String oecdNumber) {
        this.oecdNumber = oecdNumber;
    }

    public String getRegulatoryGenesPresent() {
        return regulatoryGenesPresent;
    }

    public void setRegulatoryGenesPresent(String regulatoryGenesPresent) {
        this.regulatoryGenesPresent = regulatoryGenesPresent;
    }

    public String getRegulatoryTraitDescription() {
        return regulatoryTraitDescription;
    }

    public void setRegulatoryTraitDescription(String regulatoryTraitDescription) {
        this.regulatoryTraitDescription = regulatoryTraitDescription;
    }

    public String getTransformationBackground() {
        return transformationBackground;
    }

    public void setTransformationBackground(String transformationBackground) {
        this.transformationBackground = transformationBackground;
    }

    public String getPlasmIdPvCode() {
        return plasmIdPvCode;
    }

    public void setPlasmIdPvCode(String plasmIdPvCode) {
        this.plasmIdPvCode = plasmIdPvCode;
    }

    public String getPlasmIdPmon() {
        return plasmIdPmon;
    }

    public void setPlasmIdPmon(String plasmIdPmon) {
        this.plasmIdPmon = plasmIdPmon;
    }

    public String getPreviousNames() {
        return previousNames;
    }

    public void setPreviousNames(String previousNames) {
        this.previousNames = previousNames;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Long getMonNumberId() {
        return monNumberId;
    }

    public void setMonNumberId(Long monNumberId) {
        this.monNumberId = monNumberId;
    }
}
