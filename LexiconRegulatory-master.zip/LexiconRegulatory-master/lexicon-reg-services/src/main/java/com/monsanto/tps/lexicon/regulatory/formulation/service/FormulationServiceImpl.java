package com.monsanto.tps.lexicon.regulatory.formulation.service;

import com.monsanto.tps.lexicon.formulation.FormulationService;
import com.monsanto.tps.lexicon.formulation.OrionFormulation;
import com.monsanto.tps.lexicon.regulatory.formulation.business.FormulationBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class FormulationServiceImpl implements FormulationService {

    @Resource
    private FormulationBusiness formulationBusiness;

    @Override
    public List<OrionFormulation> findFormulationTypes(final String formulationType) {
        return formulationBusiness.findFormulationTypes(formulationType);
    }
}
