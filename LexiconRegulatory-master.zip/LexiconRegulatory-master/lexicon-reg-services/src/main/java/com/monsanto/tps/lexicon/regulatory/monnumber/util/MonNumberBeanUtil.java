package com.monsanto.tps.lexicon.regulatory.monnumber.util;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.monnumber.MonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberConstruct;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 22, 2009
 * Time: 3:04:28 PM
 */
public class MonNumberBeanUtil {

   public MonNumber[] buildMonNumbers(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber[] dbMonNumbers) {
      List<MonNumber> monNumbers = new ArrayList<MonNumber>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dbMonNumber : dbMonNumbers) {
         monNumbers.add(buildMonNumber(dbMonNumber));
      }
      return monNumbers.toArray(new MonNumber[monNumbers.size()]);
   }

   public MonNumber buildMonNumber(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dbMonNumber) {
      MonNumber monNumber = new MonNumber();
      monNumber.setMonNumber(dbMonNumber.getMonNumber());
      monNumber.setCropName(dbMonNumber.getCrop().getCropName());
      monNumber.setCropPubkey(dbMonNumber.getCrop().getCropPubkey());
      monNumber.setEvent(dbMonNumber.getEvent());
      monNumber.setMaterialName(dbMonNumber.getMaterialName());
      monNumber.setPreviousNames(dbMonNumber.getPreviousNames());
      monNumber.setRegulatoryGenesPresent(dbMonNumber.getRegulatoryGenesPresent());
      monNumber.setOecdNumber(dbMonNumber.getOecdNumber());
      monNumber.setOecdNumberCommunicationDate(dbMonNumber.getOecdNumberCommunicationDate());
      monNumber.setRegulatedStatus(dbMonNumber.isRegulatedStatus());
      monNumber.setJvNumber(dbMonNumber.getJvNumber());
      monNumber.setLocked(dbMonNumber.isLocked());
      monNumber.setActiveStatus(dbMonNumber.isActiveStatus());
      monNumber.setTransformationBackground(dbMonNumber.getTransformationBackground());
      monNumber.setRegulatoryParentalLine(dbMonNumber.getRegulatoryParentalLine());
      monNumber.setProteinNames(buildProteinNames(dbMonNumber.getProteinNames()));
      monNumber.setComlTraitTypes(buildComlTraitTypes(dbMonNumber.getComlTraitTypes()));
      monNumber.setComlTraitNames(buildComlTraitNames(dbMonNumber.getComlTraitNames()));
      monNumber.setMonNumberConstructs(buildMonNumberConstructs(dbMonNumber.getMonNumberConstructs()));
      return monNumber;
   }

   private Collection<ProteinName> buildProteinNames(Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName> dbProteinNames) {
      Set<ProteinName> proteinNames = new HashSet<ProteinName>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName dbProteinName : dbProteinNames) {
         ProteinName proteinName = new ProteinName();
         proteinName.setProteinName(dbProteinName.getProteinName());
         proteinName.setProteinNamePubkey(dbProteinName.getProteinNamePubkey());
         proteinNames.add(proteinName);
      }

      return proteinNames;
   }

   public Collection<ComlTraitType> buildComlTraitTypes(Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType> dbComlTraitTypes) {
      Set<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dbComlTraitType : dbComlTraitTypes) {
         ComlTraitType comlTraitType = new ComlTraitType();
         comlTraitType.setComlTraitTypeAbbr(dbComlTraitType.getComlTraitTypeAbbr());
         comlTraitType.setComlTraitTypeDesc(dbComlTraitType.getComlTraitTypeDesc());
         comlTraitTypes.add(comlTraitType);
      }
      return comlTraitTypes;
   }

   public Collection<ComlTraitName> buildComlTraitNames(Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName> dbComlTraitNames) {
      Set<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName dbComlTraitName : dbComlTraitNames) {
         ComlTraitName comlTraitName = new ComlTraitName();
         comlTraitName.setTraitAbbr(dbComlTraitName.getTraitAbbr());
         comlTraitName.setTraitDesc(dbComlTraitName.getTraitDesc());
         comlTraitName.setActive(dbComlTraitName.isActive());
         comlTraitName.setCompany(buildCompany(dbComlTraitName.getCompany()));
         comlTraitNames.add(comlTraitName);
      }
      return comlTraitNames;
   }

   private com.monsanto.tps.lexicon.commercialtrait.Company buildCompany(Company dbCompany) {
      com.monsanto.tps.lexicon.commercialtrait.Company company = new com.monsanto.tps.lexicon.commercialtrait.Company();
      company.setActive(SQLUtil.stringToBoolean(dbCompany.getActive()));
      company.setCompanyName(dbCompany.getCompanyName());
      company.setCompanyPubkey(dbCompany.getCompanyPubkey());
      company.setCompetitor(dbCompany.getCompetitor());
      return company;
   }

   private Collection<MonNumberConstruct> buildMonNumberConstructs(Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct> dbMonNumberConstructs) {
      Set<MonNumberConstruct> monNumberConstructs = new HashSet<MonNumberConstruct>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct dbMonNumberConstruct : dbMonNumberConstructs) {
         MonNumberConstruct construct = new MonNumberConstruct();
         construct.setConstructName(dbMonNumberConstruct.getConstructName());
         construct.setPvCode(dbMonNumberConstruct.getPvCode());
         monNumberConstructs.add(construct);
      }
      return monNumberConstructs;
   }
}
