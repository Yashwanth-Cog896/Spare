package com.monsanto.tps.lexicon.regulatory.nonmonevent.model;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import org.apache.commons.lang.StringUtils;

import java.util.Collection;
import java.util.List;
import java.util.ArrayList;

/**
 * nbwald - May 21, 2009 6:33:33 PM
 * <p/>
 * This class has state!  Be sure to not inject it as a singleton.
 */
public class NonMonEventPersistRichRequest
{
   private final NonMonEventPersistQuerySet querySet;
   private String auditComment;
   private String auditRequestor;
   private Crop crop;
   private String[] constructs;
   private Collection<ProteinName> proteinNames;
   private Collection<ComlTraitName> comlTraitNames;
   private Collection<ComlTraitType> comlTraitTypes;
   private NonMonEvent existingNonMonEvent;
   private String eventName;
   private String materialName;

   public NonMonEventPersistRichRequest(NonMonEventPersistQuerySet querySet) {
      this.querySet = querySet;
   }

   public void load(NonMonEventPersistRequest request) {
      this.auditComment = request.getAuditComment();
      this.auditRequestor = request.getAuditRequestor();
      this.crop = querySet.findCropByPubkey(request.getCropPubkey());
      this.constructs = getConstructs(request);
      this.proteinNames = querySet.findProteinNamesByPubkeys(request.getProteinPubkeys());
      this.comlTraitNames = querySet.findRegulatoryTraitNamesByAbbrs(request.getTraitNameAbbreviations());
      this.comlTraitTypes = querySet.findRegulatoryTraitTypesByAbbrs(request.getTraitTypeAbbreviations());
      this.existingNonMonEvent = querySet.findNonMonEventByEventAndCrop(request.getEventName(), request.getCropPubkey());
      this.eventName = request.getEventName();
      this.materialName = request.getMaterialName();
   }

   private String[] getConstructs(NonMonEventPersistRequest request) {
      if (!StringUtils.isEmpty(request.getConstruct())) {
         return new String[]{request.getConstruct()};
      }
      else {
          return filterNullOrEmptyConstructNames(request);
      }

   }

    private String[] filterNullOrEmptyConstructNames(NonMonEventPersistRequest request) {
        List<String> constructs = new ArrayList<String>();
        for(String construct : querySet.findConstructsByEventAndCrop(request.getEventName(), getCropName())){
             if(StringUtils.isNotBlank(construct)){
                 constructs.add(construct);
             }
         }
        return constructs.toArray(new String[constructs.size()]);
    }

    private String getCropName() {
      return crop == null ? null : crop.getCropName();
   }

   public String getAuditComment() {
      return auditComment;
   }

   public String getAuditRequestor() {
      return auditRequestor;
   }

   public Crop getCrop() {
      return crop;
   }

   public String[] getConstructs() {
      return constructs;
   }

   public Collection<ProteinName> getProteinNames() {
      return proteinNames;
   }

   public Collection<ComlTraitName> getComlTraitNames() {
      return comlTraitNames;
   }

   public Collection<ComlTraitType> getComlTraitTypes() {
      return comlTraitTypes;
   }

   public NonMonEvent getExistingNonMonEvent() {
      return existingNonMonEvent;
   }

   public String getEventName() {
      return eventName;
   }

    public String getMaterialName() {
        return materialName;
    }
}
