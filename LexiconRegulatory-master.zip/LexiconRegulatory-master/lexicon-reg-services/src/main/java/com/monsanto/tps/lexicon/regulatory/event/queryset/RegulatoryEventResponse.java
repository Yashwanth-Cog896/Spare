package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Sep 2, 2011
 * Time: 2:55:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class RegulatoryEventResponse {
     private String event;
     private List<EventConstruct> eventConstructs;

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public List<EventConstruct> getEventConstructs() {
        return eventConstructs;
    }

    public void setEventConstructs(List<EventConstruct> eventConstructs) {
        this.eventConstructs = eventConstructs;
    }
}
