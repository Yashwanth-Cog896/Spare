package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Collection;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 30, 2009
 * Time: 1:53:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class ComlTraitStack
{
   private long comlTraitStackId;
   private String reportingName;
   private String stackDesc;
   private Crop crop;
   private String tdName;
   private String stackAbbr;
   private String comlTraitStackPubkey;
   private String manfTraitCode;
   private boolean preComlInd;
   private Collection<ComlTraitName> comlTraitNames;

    public Collection<ComlTraitName> getComlTraitNames() {
        return comlTraitNames;
    }

    public void setComlTraitNames(Collection<ComlTraitName> comlTraitNames) {
        this.comlTraitNames = comlTraitNames;
    }

    public boolean getPreComlInd() {
        return preComlInd;
    }

    public void setPreComlInd(boolean preComlInd) {
        this.preComlInd = preComlInd;
    }

    public long getComlTraitStackId() {
      return comlTraitStackId;
   }

   public void setComlTraitStackId(long comlTraitStackId) {
      this.comlTraitStackId = comlTraitStackId;
   }

   public String getReportingName() {
      return reportingName;
   }

   public void setReportingName(String reportingName) {
      this.reportingName = reportingName;
   }

   public String getStackDesc() {
      return stackDesc;
   }

   public void setStackDesc(String stackDesc) {
      this.stackDesc = stackDesc;
   }

   public Crop getCrop() {
      return crop;
   }

   public void setCrop(Crop crop) {
      this.crop = crop;
   }

   public String getTdName() {
      return tdName;
   }

   public void setTdName(String tdName) {
      this.tdName = tdName;
   }

   public String getStackAbbr() {
      return stackAbbr;
   }

   public void setStackAbbr(String stackAbbr) {
      this.stackAbbr = stackAbbr;
   }

   public String getComlTraitStackPubkey() {
      return comlTraitStackPubkey;
   }

   public void setComlTraitStackPubkey(String comlTraitStackPubkey) {
      this.comlTraitStackPubkey = comlTraitStackPubkey;
   }

   public String getManfTraitCode() {
      return manfTraitCode;
   }

   public void setManfTraitCode(String manfTraitCode) {
      this.manfTraitCode = manfTraitCode;
   }
}
