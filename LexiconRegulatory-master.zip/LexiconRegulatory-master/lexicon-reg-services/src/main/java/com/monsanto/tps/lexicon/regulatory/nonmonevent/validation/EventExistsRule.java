package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - May 21, 2009 6:04:21 PM
 */
public class EventExistsRule
   implements Rule<String>
{
   private final String[] constructNames;

   public EventExistsRule(String... constructNames) {
      this.constructNames = constructNames;
   }

   @Override
   public boolean violated() {
      return constructNames.length == 0;
   }

   @Override
   public String getViolation() {
      return "Invalid Event for Selected Crop.";
   }
}
