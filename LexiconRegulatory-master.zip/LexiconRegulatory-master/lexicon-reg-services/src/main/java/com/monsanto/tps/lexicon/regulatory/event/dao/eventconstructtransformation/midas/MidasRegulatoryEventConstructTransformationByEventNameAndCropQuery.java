package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.RegulatoryEventConstructTransformationByEventNameAndCropQuery;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.RegulatoryEventConstructTransformationPSRowImpl;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.util.List;

/**
 * User: pjberry
 * Date: Jul 25, 2007
 * Time: 11:24:57 AM
 */
public class MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery
   extends AbstractPersistentStoreMultiRowQuery
   implements RegulatoryEventConstructTransformationByEventNameAndCropQuery
{
   private final String event;
   private final String cropGenusSpeices;

   public MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(String event, String cropGenusSpeices) {
      this.event = event;
      this.cropGenusSpeices = cropGenusSpeices;
   }

   public RegulatoryEventConstructTransformation[] getEventConstructTransformations()
      throws WrappingException
   {
      List eventConstructTransformations = getList();
      return (RegulatoryEventConstructTransformation[]) eventConstructTransformations.toArray(new RegulatoryEventConstructTransformation[eventConstructTransformations.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new RegulatoryEventConstructTransformationPSRowImpl(row);
   }

   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.class);
      return sqlPropFile.getSQL(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.SELECT);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{event, cropGenusSpeices};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
