package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;

import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald - May 25, 2009 4:28:06 PM
 */
public class NonMonEventUpdateValidation
{
   private final NonMonEventPersistValidation validation;

   public NonMonEventUpdateValidation() {
      this.validation = new NonMonEventPersistValidation()
      {
         @Override
         protected Collection<? extends Rule<String>> gatherAdditionalErrorRules(NonMonEventPersistRichRequest richRequest) {
            return Arrays.asList(new NonMonEventExistsRule(richRequest.getExistingNonMonEvent()));
         }
      };
   }

   public ValidationResults validate(NonMonEventPersistRichRequest richRequest) {
      return validation.validate(richRequest);
   }
}
