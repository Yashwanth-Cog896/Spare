package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jan 30, 2009 1:46:14 PM
 */
public abstract class EventInfoAggregatingStrategy
{
   public EventInfo[] findAll(String[] aggregateParameters) {
      return aggregateParameters == null ? new EventInfo[0] : findAllByNonNullAggregateParameter(aggregateParameters);
   }

   private EventInfo[] findAllByNonNullAggregateParameter(String[] aggregateParameters) {
      List<EventInfo> eventInfos = new ArrayList<EventInfo>();
      for (String aggregateParameter : aggregateParameters) {
         EventInfo eventInfo = find(aggregateParameter);
         if (eventInfo != null) {
            eventInfos.add(eventInfo);
         }
      }
      return eventInfos.toArray(new EventInfo[eventInfos.size()]);
   }

   public abstract EventInfo find(String aggregateParameter);
}
