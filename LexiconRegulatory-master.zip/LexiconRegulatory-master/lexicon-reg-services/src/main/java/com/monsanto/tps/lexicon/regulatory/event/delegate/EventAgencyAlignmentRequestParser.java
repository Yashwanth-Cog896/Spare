package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

/**
 * rrchak1 - Feb 5, 2009 11:17:57 AM
 */
public interface EventAgencyAlignmentRequestParser
{

   void copyProperties(EventAgencyAlignment eventAgencyAlignment, EventAgencyAlignmentUpdateInfo alignmentUpdateInfo);

   EventAgencyAlignment buildEventAgencyAlignmentFromRequest(EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo, EventAgencyAlignmentRequest eventAgencyAlignmentRequest)
      throws WrappingException;
}
