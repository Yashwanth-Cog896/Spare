package com.monsanto.tps.lexicon.regulatory.event.model;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 8, 2005
 * Time: 11:19:20 AM
 */
public class EventConstructImpl
   implements EventConstruct
{

   private String event;
   private String construct;
   private String crop;
   private String transformationBackground;
   private String[] transCodes;


   public EventConstructImpl(RegulatoryEventConstructTransformation regulatoryECT,String crop, String[] transCodes) {

      this.event = regulatoryECT.getEvent();
      this.construct = regulatoryECT.getConstruct();
      this.transformationBackground = regulatoryECT.getTransformationBackground();
      this.transCodes = transCodes;
      this.crop=crop;
   }

   public String getEvent() {
      return event;
   }

   public String getConstruct() {
      return construct;
   }

   public String[] getTransCodes() {
      return transCodes;
   }

   public String getTransformationBackground() {
      return transformationBackground;
   }

    public String getCrop() {
        return crop;
    }

    public void setTransCodes(String[] transCodes) {
        this.transCodes = transCodes;
    }
}
