package com.monsanto.tps.lexicon.regulatory.chemicalname.service;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.chemicalname.OrionChemicalNameService;
import com.monsanto.tps.lexicon.regulatory.chemicalname.business.OrionChemicalNameBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 7/11/12
 * Time: 11:06 AM
 */
@Component
public class OrionChemicalNameServiceImpl implements OrionChemicalNameService {

    @Resource
    private OrionChemicalNameBusiness orionChemicalNameBusiness;

    @Override
    public List<OrionChemicalName> findChemicalNames(String materialName) {
        return orionChemicalNameBusiness.findChemicalNames(materialName);
    }
}
