package com.monsanto.tps.lexicon.regulatory.DB.factories.mirage;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryPropertiesLexiconImpl;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;

import java.io.IOException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 18, 2005
 * Time: 3:28:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageConnectionFactoryProperties
   extends ConnectionFactoryPropertiesLexiconImpl
{
   public static final String INSTANCE_NAME = "Mirage";
   private static final String PROP_FILENAME = "MirageDB.properties";

   public String getInstanceName() {
      return INSTANCE_NAME;
   }

   public Properties loadProperties()
      throws IOException
   {
      return PropertyManager.getInstance().getNonCachedProperties(getClass(), PROP_FILENAME);
   }
}
