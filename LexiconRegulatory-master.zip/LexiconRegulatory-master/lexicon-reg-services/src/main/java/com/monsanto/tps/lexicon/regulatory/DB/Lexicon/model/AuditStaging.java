package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Date;

/**
 * rrchak1 - Aug 19, 2008 2:42:06 PM
 */
public class AuditStaging
{
   private long oracleSid;

   public long getOracleSid() {
      return oracleSid;
   }

   public void setOracleSid(long oracleSid) {
      this.oracleSid = oracleSid;
   }

   private String processName;

   public String getProcessName() {
      return processName;
   }

   public void setProcessName(String processName) {
      this.processName = processName;
   }

   private String auditComment;

   public String getAuditComment() {
      return auditComment;
   }

   public void setAuditComment(String auditComment) {
      this.auditComment = auditComment;
   }

   private String auditRequestor;

   public String getAuditRequestor() {
      return auditRequestor;
   }

   public void setAuditRequestor(String auditRequestor) {
      this.auditRequestor = auditRequestor;
   }

   private Date creationTimestamp;

   public Date getCreationTimestamp() {
      return creationTimestamp;
   }

   public void setCreationTimestamp(Date creationTimestamp) {
      this.creationTimestamp = creationTimestamp;
   }

   private String osuser;

   public String getOsuser() {
      return osuser;
   }

   public void setOsuser(String osuser) {
      this.osuser = osuser;
   }

   private String machine;

   public String getMachine() {
      return machine;
   }

   public void setMachine(String machine) {
      this.machine = machine;
   }

   private String userLoginId;

   public String getUserLoginId() {
      return userLoginId;
   }

   public void setUserLoginId(String userLoginId) {
      this.userLoginId = userLoginId;
   }
}
