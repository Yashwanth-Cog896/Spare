package com.monsanto.tps.lexicon.regulatory.plantname.comparator;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Apr 27, 2006
 * Time: 2:43:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrionPlantProductComparator implements Comparator<OrionPlantProduct> {

    public final int compare(OrionPlantProduct info1, OrionPlantProduct info2) {

        int nameCompare = 0;
        int dateCompare = 0;

        if (info1 != null && info2 != null) {
            String name1 = info1.getName();
            String name2 = info2.getName();
            if (name1 != null && name2 != null) {
                nameCompare = name1.compareToIgnoreCase(name2);
            }
        }
        return nameCompare != 0 ? nameCompare : dateCompare;
    }
}
