package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.event.AgencyMaterial;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jan 6, 2009 11:56:46 AM
 */
public class MaterialAgencies {
    private EventAgencyAlignment[] models;

    public MaterialAgencies(EventAgencyAlignment[] models) {
        this.models = models;
    }

    public AgencyMaterial[] getResponseEventAgencies() {
        List<AgencyMaterial> responses = new ArrayList<AgencyMaterial>();
        for (EventAgencyAlignment model : models) {
            responses.add(buildResponseFromModel(model));
        }
        return responses.toArray(new AgencyMaterial[responses.size()]);
    }

    private AgencyMaterial buildResponseFromModel(EventAgencyAlignment model) {
        AgencyMaterial response = new AgencyMaterial();
        response.setRegulated(SQLUtil.stringToBoolean(model.getRegulated()));
        setAgencyFields(response, model.getAgency());
        response.setDeregulatedEffectiveDate(model.getDeregulatedEffectiveDate());
        response.setMaxQuantity(model.getMaxQuantity());
        response.setPublicKey(model.getEventAgencyAlignmentPubkey());
        response.setDiscoveryMaterial(model.getDiscoveryMaterial());
        response.setAgencyMaterialType(model.getAgencyMaterialType() != null ? model.getAgencyMaterialType().getMaterialTypeDesc() : null);
        return response;
    }

    private void setAgencyFields(AgencyMaterial response, Agency agency) {
        if (agency != null) {
            response.setAgencyAbbr(agency.getAgencyAbbr());
            response.setCountryName(agency.getCountry().getCountryName());
            response.setSurfaceAreaUomCode(agency.getSurfaceAreaUomCode());
        }
    }
}
