package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.HashSet;
import java.util.Set;

/**
 * rrchak1 - Oct 14, 2008 3:29:04 PM
 */
public class Agency
{
   private long agencyId;

   public long getAgencyId() {
      return agencyId;
   }

   public void setAgencyId(long agencyId) {
      this.agencyId = agencyId;
   }

   private String agencyPubkey;

   public String getAgencyPubkey() {
      return agencyPubkey;
   }

   public void setAgencyPubkey(String agencyPubkey) {
      this.agencyPubkey = agencyPubkey;
   }

   private String agencyAbbr;

   public String getAgencyAbbr() {
      return agencyAbbr;
   }

   public void setAgencyAbbr(String agencyAbbr) {
      this.agencyAbbr = agencyAbbr;
   }

   private String agencyName;

   public String getAgencyName() {
      return agencyName;
   }

   public void setAgencyName(String agencyName) {
      this.agencyName = agencyName;
   }

   private String surfaceAreaUomCode;

   public String getSurfaceAreaUomCode() {
      return surfaceAreaUomCode;
   }

   public void setSurfaceAreaUomCode(String surfaceAreaUomCode) {
      this.surfaceAreaUomCode = surfaceAreaUomCode;
   }

   private String active;

   public String getActive() {
      return active;
   }

   public void setActive(String active) {
      this.active = active;
   }

   private Country country;

   public Country getCountry() {
      return country;
   }

   public void setCountry(Country country) {
      this.country = country;
   }

   private Set<AgencyDepartment> departments = new HashSet<AgencyDepartment>(0);

   public Set<AgencyDepartment> getDepartments() {
      return departments;
   }

   public void setDepartments(Set<AgencyDepartment> departments) {
      this.departments = departments;
   }
}
