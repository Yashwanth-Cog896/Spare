package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 7, 2009
 * Time: 9:38:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class ComlTraitName
{
   private long comlTraitNameId;
   private String traitAbbr;
   private String traitDesc;
   private Company company;
   private boolean active;
   private Collection<DataFilter> dataFilters = new HashSet<DataFilter>();
   private Collection<ComlTraitType> comlTraitTypes;

    public Collection<ComlTraitType> getComlTraitTypes() {
        return comlTraitTypes;
    }

    public void setComlTraitTypes(Collection<ComlTraitType> comlTraitTypes) {
        this.comlTraitTypes = comlTraitTypes;
    }

    public Collection<DataFilter> getDataFilters() {
      return dataFilters;
   }

   public void setDataFilters(Collection<DataFilter> dataFilters) {
      this.dataFilters = dataFilters;
   }

   public long getComlTraitNameId() {
      return comlTraitNameId;
   }

   public void setComlTraitNameId(long comlTraitNameId) {
      this.comlTraitNameId = comlTraitNameId;
   }

   public String getTraitAbbr() {
      return traitAbbr;
   }

   public void setTraitAbbr(String traitAbbr) {
      this.traitAbbr = traitAbbr;
   }

   public String getTraitDesc() {
      return traitDesc;
   }

   public void setTraitDesc(String traitDesc) {
      this.traitDesc = traitDesc;
   }

   public Company getCompany() {
      return company;
   }

   public void setCompany(Company company) {
      this.company = company;
   }

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }
}
