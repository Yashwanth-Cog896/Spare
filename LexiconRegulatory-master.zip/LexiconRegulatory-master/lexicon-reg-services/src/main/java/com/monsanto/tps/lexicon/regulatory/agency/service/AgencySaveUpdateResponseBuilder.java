package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;


/**
 * aagosw - Mar 6, 2009 9:02:36 AM
 */
public interface AgencySaveUpdateResponseBuilder
{
   AgencySaveUpdateResponse buildResponse(AgencySaveUpdateRequest agencySaveUpdateRequest, ValidationResults validationResults);
}