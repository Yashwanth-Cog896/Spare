/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.midas.model;

import java.io.Serializable;
import java.math.BigDecimal;

/* vvkalu - 7/22/11 */
public class MidasCropEntity implements Serializable {
    private long id;
    private String name;
    private boolean refActive;
    private String genusSpecies;
    private boolean remCropId;
    private BigDecimal rmMin;
    private BigDecimal rmMax;
    private BigDecimal rmIncrement;

    public BigDecimal getRmIncrement() {
        return rmIncrement;
    }

    public void setRmIncrement(BigDecimal rmIncrement) {
        this.rmIncrement = rmIncrement;
    }

    public BigDecimal getRmMax() {
        return rmMax;
    }

    public void setRmMax(BigDecimal rmMax) {
        this.rmMax = rmMax;
    }

    public BigDecimal getRmMin() {
        return rmMin;
    }

    public void setRmMin(BigDecimal rmMin) {
        this.rmMin = rmMin;
    }

    public boolean isRemCropId() {
        return remCropId;
    }

    public void setRemCropId(boolean remCropId) {
        this.remCropId = remCropId;
    }

    public String getGenusSpecies() {
        return genusSpecies;
    }

    public void setGenusSpecies(String genusSpecies) {
        this.genusSpecies = genusSpecies;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}