package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;

/**
 * nbwald - May 21, 2009 5:10:18 PM
 */
public class CropExistsRule
   implements Rule<String>
{
   private final Crop crop;

   public CropExistsRule(Crop crop) {
      this.crop = crop;
   }

   @Override
   public boolean violated() {
      return crop == null;
   }

   @Override
   public String getViolation() {
      return "Crop is required.";
   }
}
