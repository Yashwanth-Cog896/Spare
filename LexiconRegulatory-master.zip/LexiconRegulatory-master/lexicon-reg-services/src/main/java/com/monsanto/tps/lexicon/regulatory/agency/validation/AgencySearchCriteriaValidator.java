package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;

/**
 * rrchak1 - Oct 21, 2008 2:54:34 PM
 */
public interface AgencySearchCriteriaValidator
{
   void validate(AgencySearchCriteria agencySearchCriteria)
      throws IllegalArgumentException;
}
