/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductStageEntity;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/* vvkalu - 7/26/11 */
public class ProductStageDaoImpl implements ProductStageDao {
    private SessionFactory sessionFactory;

    @Override
    public LexiconProductStageEntity getFirstProductStageByGermplasmId(long germplasmId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("productStageDao.getFirstProductStageForProduct");
        query.setParameter("germplasmId", germplasmId);
        return (LexiconProductStageEntity) query.uniqueResult();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}