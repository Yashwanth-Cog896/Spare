package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;

import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 6:28:38 PM
 */
public class NonMonEventSaveValidation
{
   private final NonMonEventPersistValidation validation;

   public NonMonEventSaveValidation() {
      this.validation = new NonMonEventPersistValidation()
      {
         @Override
         protected Collection<? extends Rule<String>> gatherAdditionalErrorRules(NonMonEventPersistRichRequest richRequest) {
            return Arrays.asList(new NonMonEventDoesNotExistRule(richRequest.getExistingNonMonEvent()));
         }
      };
   }

   public ValidationResults validate(NonMonEventPersistRichRequest richRequest) {
      return validation.validate(richRequest);
   }
}
