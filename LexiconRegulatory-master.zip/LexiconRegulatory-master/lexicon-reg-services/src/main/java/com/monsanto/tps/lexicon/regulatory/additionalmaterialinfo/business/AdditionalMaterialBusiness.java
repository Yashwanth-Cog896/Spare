package com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.business;

import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionAdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao.AdditionalMaterialDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Component
public class AdditionalMaterialBusiness {
    @Resource
    private AdditionalMaterialDAO additionalMaterialDAO;

    public List<OrionAdditionalMaterial> findAdditionalMaterials(String materialName) {
        List<AdditionalMaterial> additionalMaterials = additionalMaterialDAO.findAdditionalMaterials(WildcardUtil.replaceAsteriskWildcardWithPercent(materialName));
        final List<OrionAdditionalMaterial> orionAdditionalMaterials = new ArrayList<OrionAdditionalMaterial>();

        for (AdditionalMaterial additionalMaterial : additionalMaterials) {
            OrionAdditionalMaterial orionAdditionalMaterial = new OrionAdditionalMaterial();
            orionAdditionalMaterial.setMaterialName(additionalMaterial.getMaterialName());
            orionAdditionalMaterial.setAlias(additionalMaterial.getAlias());
            orionAdditionalMaterial.setChemicalNameCAS(additionalMaterial.getChemicalNameCAS());
            orionAdditionalMaterial.setChemicalNameIUPAC(additionalMaterial.getChemicalNameIUPAC());
            orionAdditionalMaterial.setCpNumber(additionalMaterial.getCpNumber());
            orionAdditionalMaterial.setActiveStatus(additionalMaterial.getActiveStatus());
            orionAdditionalMaterials.add(orionAdditionalMaterial);
        }

        return orionAdditionalMaterials;
    }
}
