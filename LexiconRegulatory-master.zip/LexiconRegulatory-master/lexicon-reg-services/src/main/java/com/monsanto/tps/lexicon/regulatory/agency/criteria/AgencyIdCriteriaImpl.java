package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import org.apache.commons.lang.ArrayUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * rrchak1 - Oct 21, 2008 11:19:14 AM
 */
public class AgencyIdCriteriaImpl
   implements QueryCriteria
{
   private long[] agencyIds;

   public AgencyIdCriteriaImpl(long[] agencyIds) {
      this.agencyIds = agencyIds;
   }

   public Criterion getCriterion() {
      return Restrictions.in("agencyId", ArrayUtils.toObject(agencyIds));
   }

   public boolean hasCriteria() {
      return !ArrayUtils.isEmpty(agencyIds);
   }
}
