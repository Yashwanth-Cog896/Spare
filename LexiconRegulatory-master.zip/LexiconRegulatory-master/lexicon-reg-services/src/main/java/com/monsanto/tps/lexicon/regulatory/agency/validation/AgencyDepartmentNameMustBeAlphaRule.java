package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Oct 21, 2008 4:37:58 PM
 */
public class AgencyDepartmentNameMustBeAlphaRule
   implements Rule<String>
{
   private String[] departmentNames;

   public AgencyDepartmentNameMustBeAlphaRule(String[] departmentNames) {
      this.departmentNames = departmentNames;
   }

   public boolean violated() {
      if (!ArrayUtils.isEmpty(departmentNames)) {
         for (String dept : departmentNames) {
            if (new StdWildcardableCriteria(dept).isOnlyWildcard()) {
               return true;
            }
            if (!dept.matches("^[a-zA-Z*, ]+[a-zA-Z*, ]+$")) {
               return true;
            }
         }
      }
      return false;
   }

   public String getViolation() {
      return "Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.";
   }
}
