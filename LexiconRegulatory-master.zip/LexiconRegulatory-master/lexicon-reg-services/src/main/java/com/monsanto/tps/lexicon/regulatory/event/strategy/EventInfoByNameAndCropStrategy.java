package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;

/**
 * nbwald - Jan 30, 2009 11:16:09 AM
 */
public interface EventInfoByNameAndCropStrategy
{
   EventInfo[] find(String []eventName, String cropName);
}
