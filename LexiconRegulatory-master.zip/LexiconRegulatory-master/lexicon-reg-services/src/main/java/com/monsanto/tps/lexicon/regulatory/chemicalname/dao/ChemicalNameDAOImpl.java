package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:52 PM
 */
@Component
public class ChemicalNameDAOImpl implements ChemicalNameDAO {

    @Resource
     private SessionFactory sessionFactory;

    @Override
    public List<ChemicalName> findChemicalNames(String materialName) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveChemicalNameIgnoreCaseSort");
        query.setParameter("materialName", WildcardUtil.replaceEmptyStringWithWildcard(materialName));

        return (List<ChemicalName>) query.list();
    }

    @Override
    public List<ChemicalName> findChemicalCommercialProduct(String materialName) {
        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findChemicalCommercialProduct");
        query.setParameter("materialName", WildcardUtil.replaceEmptyStringWithWildcard(materialName));
        query.setResultTransformer(new ChemicalNameTransformer());
        return (List<ChemicalName>) query.list();
    }

    @Override
    public List<ChemicalName> findChemicalFormulation(String materialName) {
        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findChemicalFormulation");
        query.setParameter("materialName", WildcardUtil.replaceEmptyStringWithWildcard(materialName));
        query.setResultTransformer(new ChemicalNameTransformer());
        return (List<ChemicalName>) query.list();
    }

    @Override
    public List<ChemicalName> findChemicalActiveIngredient(String materialName) {
        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findChemicalActiveIngredient");
        query.setParameter("materialName", WildcardUtil.replaceEmptyStringWithWildcard(materialName));
        query.setResultTransformer(new ChemicalNameTransformer());
        return (List<ChemicalName>) query.list();
    }

    @Override
    public List<String> findActiveIngredientNames(long productId, String productName) {
        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveIngredients");
        query.setParameter("productId", productId);
        query.setParameter("productName", WildcardUtil.replaceEmptyStringWithWildcard(productName));
        return (List<String>) query.list();
    }

}
