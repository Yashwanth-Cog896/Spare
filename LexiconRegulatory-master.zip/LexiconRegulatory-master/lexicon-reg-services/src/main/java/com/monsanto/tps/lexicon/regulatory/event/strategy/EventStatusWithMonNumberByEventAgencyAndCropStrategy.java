package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;

/**
 * rrchak1 - Jun 23, 2009 11:00:24 AM
 */
public interface EventStatusWithMonNumberByEventAgencyAndCropStrategy
{
   public EventDeregulationStatusWithMonNumber[] find(String[] events, String cropName, String[] agencyAbbrs);
}