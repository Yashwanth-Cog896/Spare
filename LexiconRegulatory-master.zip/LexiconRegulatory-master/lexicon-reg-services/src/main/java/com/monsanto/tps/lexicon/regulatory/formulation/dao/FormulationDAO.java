package com.monsanto.tps.lexicon.regulatory.formulation.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.FormulationType;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:32 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FormulationDAO {
    List<FormulationType> findFormulationTypes(String formulationType);
}
