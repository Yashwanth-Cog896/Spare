package com.monsanto.tps.lexicon.regulatory.event.validation;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

/**
 * rrchak1 - Feb 6, 2009 10:09:38 AM
 */
public interface EventAgencyAlignmentValidator
{
   /*
  Check if eventAgencyAlignment already exists
  with given Event name and Agency pubkey
   */
   void valiateAgencyAlignedToEventAndCrop(String agencyPubkey, EventAgencyAlignmentRequest eventAgencyAlignmentRequest)
      throws WrappingException;

   EventAgencyAlignment validateAlignmentExists(String eventAgencyAlignmentPubkey)
      throws WrappingException;
}
