package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;

import java.util.Collection;

/**
 * nbwald - May 21, 2009 5:27:09 PM
 */
public class HasRegulatoryTraitOptionRule
   implements Rule<String>
{
   private final Collection<ComlTraitName> traitNames;
   private final Collection<ComlTraitType> traitTypes;

   public HasRegulatoryTraitOptionRule(Collection<ComlTraitName> traitNames, Collection<ComlTraitType> traitTypes) {
      this.traitNames = traitNames;
      this.traitTypes = traitTypes;
   }

   @Override
   public boolean violated() {
      return traitNames.size() + traitTypes.size() == 0;
   }

   @Override
   public String getViolation() {
      return "At least one regulatory trait description is required.";
   }
}
