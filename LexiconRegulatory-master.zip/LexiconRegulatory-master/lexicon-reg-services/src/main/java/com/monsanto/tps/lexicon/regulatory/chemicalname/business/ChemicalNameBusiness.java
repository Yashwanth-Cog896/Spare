package com.monsanto.tps.lexicon.regulatory.chemicalname.business;

import com.google.common.base.Joiner;
import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import com.monsanto.tps.lexicon.regulatory.chemicalname.dao.ChemicalNameDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:46 PM
 */
@Component
public class ChemicalNameBusiness {
    @Resource
    private ChemicalNameDAO chemicalNameDAO;

    public List<OrionChemicalName> findChemicalNames(String materialName) {

        final List<ChemicalName> chemmicalNameTypeList = chemicalNameDAO.findChemicalNames(WildcardUtil.replaceAsteriskWildcardWithPercent(materialName));
        return adaptToOrionChemicalNames(chemmicalNameTypeList);
    }

    public List<OrionChemicalName> findChemicalMaterials(String materialName) {

        final List<ChemicalName> chemicalMaterialTypeList = chemicalNameDAO.findChemicalCommercialProduct(WildcardUtil.replaceAsteriskWildcardWithPercent(materialName));
        final List<ChemicalName> chemicalFormulationTypeList = chemicalNameDAO.findChemicalFormulation(WildcardUtil.replaceAsteriskWildcardWithPercent(materialName));
        final List<ChemicalName> chemicalActiveIngredientTypeList = chemicalNameDAO.findChemicalActiveIngredient(WildcardUtil.replaceAsteriskWildcardWithPercent(materialName));

        addActiveIngredients(chemicalMaterialTypeList);
        addActiveIngredients(chemicalFormulationTypeList);

        final List<ChemicalName> chemicalTypeList = chemicalMaterialTypeList;
        chemicalTypeList.addAll(chemicalFormulationTypeList);
        chemicalTypeList.addAll(chemicalActiveIngredientTypeList);

        return adaptToOrionChemicalNames(chemicalTypeList);
    }

    private List<OrionChemicalName> adaptToOrionChemicalNames(List<ChemicalName> chemmicalNameTypeList) {
        final List<OrionChemicalName> orionChemicalNameList = new ArrayList<OrionChemicalName>();

        for (ChemicalName type : chemmicalNameTypeList) {
            orionChemicalNameList.add(new OrionChemicalName(type.getActiveIngredient(), type.getActiveStatus(), type.getAlias(),
                    type.getChemicalNameCAS(), type.getChemicalNameIUPAC(), type.getCpNumber(), type.getFormulatedAmount(),
                    type.getFormulatedAmountUnit(), type.getFormulationDesignation(), type.getMaterialClassification(), type.getMaterialName()));
        }

        return orionChemicalNameList;
    }

    private void addActiveIngredients(List<ChemicalName> chemicalNameList) {
        for(ChemicalName chemicalName : chemicalNameList) {
            List<String> activeIngredientNames = chemicalNameDAO.findActiveIngredientNames(chemicalName.getChemicalNameId(), chemicalName.getMaterialName());
            String ingredients = commaSeparateActiveIngredients(activeIngredientNames);
            chemicalName.setActiveIngredient(ingredients);
        }
    }

    private String commaSeparateActiveIngredients(List<String> activeIngredients) {
        if (activeIngredients != null) {
            Joiner joiner = Joiner.on(',');
            return joiner.join(activeIngredients);
        }
        return null;
    }
}