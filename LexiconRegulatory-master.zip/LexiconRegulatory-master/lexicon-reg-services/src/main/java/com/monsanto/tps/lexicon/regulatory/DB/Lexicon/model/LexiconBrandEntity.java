/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.io.Serializable;

/* vvkalu - 7/26/11 */
public class LexiconBrandEntity implements Serializable {
    private long id;
    private String brandPubkey;
    private String brandName;
    private String brandAbbr;
    private boolean active;
    private boolean tdRestricted;
    private Company company;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public boolean getTdRestricted() {
        return tdRestricted;
    }

    public void setTdRestricted(boolean tdRestricted) {
        this.tdRestricted = tdRestricted;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getBrandAbbr() {
        return brandAbbr;
    }

    public void setBrandAbbr(String brandAbbr) {
        this.brandAbbr = brandAbbr;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getBrandPubkey() {
        return brandPubkey;
    }

    public void setBrandPubkey(String brandPubkey) {
        this.brandPubkey = brandPubkey;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}