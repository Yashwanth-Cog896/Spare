/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.List;

/* vvkalu - 8/8/11 */
public class GermplasmEventConstructDaoImpl implements GermplasmEventConstructDao {
    private SessionFactory sessionFactory;

    @Override
    public List<GermplasmEventConstructEntity> findGermplasmEventConstructs(long germplasmId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("findGermplasmEventConstructs.byGermplasmIds");
        query.setParameter("germplasmId", germplasmId);
        return (List<GermplasmEventConstructEntity>) query.list();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}