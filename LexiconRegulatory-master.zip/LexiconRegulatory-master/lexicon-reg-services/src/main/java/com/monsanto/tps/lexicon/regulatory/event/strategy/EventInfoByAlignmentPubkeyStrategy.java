package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;

/**
 * rrchak1 - Feb 11, 2009 3:15:02 PM
 */
public interface EventInfoByAlignmentPubkeyStrategy
{
   EventInfo[] find(String[] eventAgencyAlignmentPubkey);
}
