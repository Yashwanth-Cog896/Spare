/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import com.monsanto.tps.lexicon.regulatory.DB.fbscommon.model.ProductXrefEntity;

import java.io.Serializable;
import java.util.Collection;

/* vvkalu - 7/25/11 */
public class LexiconProductEntity implements Serializable {
    private long id;
    private String productPubkey;
    private String preComlName;
    private String tagVarietyName;
    private boolean logicalDelete;
    private boolean parentProduct;
    private String justification;
    private String features;
    private String benefits;
    private String limitations;
    private String marketFit;
    private String compareTo;
    private Crop crop;
    private Collection<LexiconProductStageEntity> productStages;
    private Collection<ProductXrefEntity> productXrefs;

    public Collection<ProductXrefEntity> getProductXrefs() {
        return productXrefs;
    }

    public void setProductXrefs(Collection<ProductXrefEntity> productXrefs) {
        this.productXrefs = productXrefs;
    }

    public Collection<LexiconProductStageEntity> getProductStages() {
        return productStages;
    }

    public void setProductStages(Collection<LexiconProductStageEntity> productStages) {
        this.productStages = productStages;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public String getCompareTo() {
        return compareTo;
    }

    public void setCompareTo(String compareTo) {
        this.compareTo = compareTo;
    }

    public String getMarketFit() {
        return marketFit;
    }

    public void setMarketFit(String marketFit) {
        this.marketFit = marketFit;
    }

    public String getLimitations() {
        return limitations;
    }

    public void setLimitations(String limitations) {
        this.limitations = limitations;
    }

    public String getBenefits() {
        return benefits;
    }

    public void setBenefits(String benefits) {
        this.benefits = benefits;
    }

    public String getFeatures() {
        return features;
    }

    public void setFeatures(String features) {
        this.features = features;
    }

    public String getJustification() {
        return justification;
    }

    public void setJustification(String justification) {
        this.justification = justification;
    }

    public boolean getParentProduct() {
        return parentProduct;
    }

    public void setParentProduct(boolean parentProduct) {
        this.parentProduct = parentProduct;
    }

    public boolean getLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public String getTagVarietyName() {
        return tagVarietyName;
    }

    public void setTagVarietyName(String tagVarietyName) {
        this.tagVarietyName = tagVarietyName;
    }

    public String getPreComlName() {
        return preComlName;
    }

    public void setPreComlName(String preComlName) {
        this.preComlName = preComlName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}