package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * rrchak1 - Oct 14, 2008 3:29:05 PM
 */
public class AgencyDepartment
{
   private long agencyDeptId;

   public long getAgencyDeptId() {
      return agencyDeptId;
   }

   public void setAgencyDeptId(long agencyDeptId) {
      this.agencyDeptId = agencyDeptId;
   }

   private String agencyDeptPubkey;

   public String getAgencyDeptPubkey() {
      return agencyDeptPubkey;
   }

   public void setAgencyDeptPubkey(String agencyDeptPubkey) {
      this.agencyDeptPubkey = agencyDeptPubkey;
   }

   private String agencyDeptAbbr;

   public String getAgencyDeptAbbr() {
      return agencyDeptAbbr;
   }

   public void setAgencyDeptAbbr(String agencyDeptAbbr) {
      this.agencyDeptAbbr = agencyDeptAbbr;
   }

   private String agencyDeptName;

   public String getAgencyDeptName() {
      return agencyDeptName;
   }

   public void setAgencyDeptName(String agencyDeptName) {
      this.agencyDeptName = agencyDeptName;
   }

   private String address1;

   public String getAddress1() {
      return address1;
   }

   public void setAddress1(String address1) {
      this.address1 = address1;
   }

   private String address2;

   public String getAddress2() {
      return address2;
   }

   public void setAddress2(String address2) {
      this.address2 = address2;
   }

   private String city;

   public String getCity() {
      return city;
   }

   public void setCity(String city) {
      this.city = city;
   }

   private String postalCode;

   public String getPostalCode() {
      return postalCode;
   }

   public void setPostalCode(String postalCode) {
      this.postalCode = postalCode;
   }

   private String subCountryAbbr;

   public String getSubCountryAbbr() {
      return subCountryAbbr;
   }

   public void setSubCountryAbbr(String subCountryAbbr) {
      this.subCountryAbbr = subCountryAbbr;
   }

   private String subSubCountryName;

   public String getSubSubCountryName() {
      return subSubCountryName;
   }

   public void setSubSubCountryName(String subSubCountryName) {
      this.subSubCountryName = subSubCountryName;
   }

   private String active;

   public String getActive() {
      return active;
   }

   public void setActive(String active) {
      this.active = active;
   }

   private Agency agency;

   public Agency getAgency() {
      return agency;
   }

   public void setAgency(Agency agency) {
      this.agency = agency;
   }
}
