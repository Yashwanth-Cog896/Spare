package com.monsanto.tps.lexicon.regulatory.formulation.business;

import com.monsanto.tps.lexicon.formulation.OrionFormulation;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.FormulationType;
import com.monsanto.tps.lexicon.regulatory.formulation.dao.FormulationDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:32 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class FormulationBusiness {

    @Resource
    FormulationDAO formulationDAO;

    public List<OrionFormulation> findFormulationTypes(final String formulationType) {
        final List<FormulationType> formulationTypeList = formulationDAO.findFormulationTypes(WildcardUtil.replaceAsteriskWildcardWithPercent(formulationType));
        final List<OrionFormulation> orionFormulationList = new ArrayList<OrionFormulation>();

        for (FormulationType type : formulationTypeList) {
            orionFormulationList.add(new OrionFormulation(type.getFormulationType(), type.getFormulationTypeDescription(), type.getActiveStatus()));
        }

        return orionFormulationList;
    }
}
