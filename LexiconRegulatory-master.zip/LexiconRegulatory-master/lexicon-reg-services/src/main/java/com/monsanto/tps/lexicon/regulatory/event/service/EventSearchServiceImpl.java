package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventSearchService;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoAggregatingStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByAgencyAbbrStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByAlignmentPubkeyStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByMonNumberStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByNameAndCropStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventStatusByCropStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventStatusByEventAgencyAndCropStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventStatusWithMonNumberByEventAgencyAndCropStrategy;

import javax.jws.WebParam;
import javax.jws.WebService;

/**
 * rrchak1 - Dec 17, 2008 1:49:34 PM
 */
@WebService(endpointInterface = "com.monsanto.tps.lexicon.event.EventSearchService")
public class EventSearchServiceImpl
        implements EventSearchService {
    private EventInfoByNameAndCropStrategy byNameAndCropStrategy;
    private EventInfoByMonNumberStrategy byMonNumberStrategy;
    private EventInfoByAlignmentPubkeyStrategy byAlignmentPubkeyStrategy;
    private EventInfoByAgencyAbbrStrategy byAgencyAbbrStrategy;
    private EventStatusByEventAgencyAndCropStrategy byEventAgencyAndCropStrategy;
    private EventStatusByCropStrategy byCropStrategy;


    private EventStatusWithMonNumberByEventAgencyAndCropStrategy withMonByEventAgencyAndCropStrategy;
    private DataPointHolder dataPointHolder;

    @PerformanceMetric(task = "EventSearchService-ByEventAndCrop", comment = "findByEventAndCrop")
    public EventInfo findByEventAndCrop(String eventName, String cropName) {
        EventInfo[] eventInfos = byNameAndCropStrategy.find(new String[]{eventName}, cropName);
        return eventInfos.length > 0 ? eventInfos[0] : null;
    }

    @PerformanceMetric(task = "EventSearchService-ByEventsAndCrop", comment = "findByEventsAndCrop")
    public EventInfo[] findByEventsAndCrop(String[] eventNames, final String cropName) {
        return logMetrics(byNameAndCropStrategy.find(eventNames, cropName));
    }

    @PerformanceMetric(task = "EventSearchService-ByMonNumber", comment = "findByMonNumber")
    public EventInfo findByMonNumber(String monNumberValue) {
        return byMonNumberStrategy.find(monNumberValue);
    }

    @PerformanceMetric(task = "EventSearchService-ByMonNumbers", comment = "findByMonNumbers")
    public EventInfo[] findByMonNumbers(String[] monNumberValues) {
        EventInfoAggregatingStrategy aggregator = new EventInfoAggregatingStrategy() {
            public EventInfo find(String monNumberValue) {
                return byMonNumberStrategy.find(monNumberValue);
            }
        };
        return logMetrics(aggregator.findAll(monNumberValues));
    }

    @PerformanceMetric(task = "EventSearchService-ByAlignmentPubkeys", comment = "findByEventAgencyAlignmentPubkey")
    public EventInfo[] findByEventAgencyAlignmentPubkey(String[] eventAgencyAlignmentPubkey) {
        EventInfo[] results = new EventInfo[0];
        if (!ArrayUtils.isNullOrEmpty(eventAgencyAlignmentPubkey)) {
            results = byAlignmentPubkeyStrategy.find(eventAgencyAlignmentPubkey);
        }
        return logMetrics(results);
    }

    @PerformanceMetric(task = "EventSearchService-ByAgencyAbbr", comment = "findByAgencyAbbr")
    public EventInfo[] findByAgencyAbbr(String[] agencyAbbr) {
        EventInfo[] results = new EventInfo[0];
        if (!ArrayUtils.isNullOrEmpty(agencyAbbr)) {
            results = byAgencyAbbrStrategy.find(agencyAbbr);
        }
        return logMetrics(results);
    }

    @PerformanceMetric(task = "EventSearchService-getEventDeregulationStatus", comment = "getEventDeregulationStatus")
    public EventDeregulationStatus[] getEventDeregulationStatus(String[] eventNames, String cropName, String[] agencyAbbrs) {
        EventDeregulationStatus[] results = new EventDeregulationStatus[0];
        if (!ArrayUtils.isNullOrEmpty(eventNames) && !ArrayUtils.isNullOrEmpty(agencyAbbrs)) {
            results = byEventAgencyAndCropStrategy.find(eventNames, cropName, agencyAbbrs);
        }
        return logMetrics(results);
    }

    @Override
    @PerformanceMetric(task = "EventSearchService-getEventDeregulationStatusWithMonNumber", comment = "getEventDeregulationStatusWithMonNumber")
    public EventDeregulationStatusWithMonNumber[] getEventDeregulationStatusWithMonNumber(@WebParam(name = "eventNames") String[] eventNames, @WebParam(name = "cropName") String cropName, @WebParam(name = "agencyAbbrs") String[] agencyAbbrs) {
        EventDeregulationStatusWithMonNumber[] results = new EventDeregulationStatusWithMonNumber[0];
        if (!ArrayUtils.isNullOrEmpty(eventNames) && !ArrayUtils.isNullOrEmpty(agencyAbbrs)) {
            results = withMonByEventAgencyAndCropStrategy.find(eventNames, cropName, agencyAbbrs);
        }
        return logMetrics(results);
    }

    @Override
    @PerformanceMetric(task = "EventSearchService-getEventDeregulationStatusForEventsAndCrops", comment = "getEventDeregulationStatus")
    public EventDeregulationStatus[] getEventDeregulationStatus(@WebParam(name = "eventNames") String[] eventNames, @WebParam(name = "cropName") String cropName) {
        EventDeregulationStatus[] results = new EventDeregulationStatus[0];
        if (!ArrayUtils.isNullOrEmpty(eventNames)) {
            results = byCropStrategy.find(eventNames, cropName);
        }
        return logMetrics(results);
    }

    @Override
    public AgencyMaterialDeregulationStatus[] getAgencyMaterialDeregulationStatus(@WebParam(name = "materialNames") String[] materialNames, @WebParam(name = "cropName") String cropName) {
        AgencyMaterialDeregulationStatus[] results = new AgencyMaterialDeregulationStatus[0];
        if (!ArrayUtils.isNullOrEmpty(materialNames)) {
            results = byCropStrategy.findByMaterialName(materialNames, cropName);
        }
        return logMetrics(results);
    }

    public void setByNameAndCropStrategy(EventInfoByNameAndCropStrategy byNameAndCropStrategy) {
        this.byNameAndCropStrategy = byNameAndCropStrategy;
    }

    public void setByMonNumberStrategy(EventInfoByMonNumberStrategy byMonNumberStrategy) {
        this.byMonNumberStrategy = byMonNumberStrategy;
    }

    public void setByAlignmentPubkeyStrategy(EventInfoByAlignmentPubkeyStrategy byAlignmentPubkeyStrategy) {
        this.byAlignmentPubkeyStrategy = byAlignmentPubkeyStrategy;
    }

    public void setByAgencyAbbrStrategy(EventInfoByAgencyAbbrStrategy byAgencyAbbrStrategy) {
        this.byAgencyAbbrStrategy = byAgencyAbbrStrategy;
    }

    public void setByEventAgencyAndCropStrategy(EventStatusByEventAgencyAndCropStrategy byEventAgencyAndCropStrategy) {
        this.byEventAgencyAndCropStrategy = byEventAgencyAndCropStrategy;
    }

    public void setByCropStrategy(EventStatusByCropStrategy byCropStrategy) {
        this.byCropStrategy = byCropStrategy;
    }

    public void setWithMonByEventAgencyAndCropStrategy(EventStatusWithMonNumberByEventAgencyAndCropStrategy withMonByEventAgencyAndCropStrategy) {
        this.withMonByEventAgencyAndCropStrategy = withMonByEventAgencyAndCropStrategy;
    }

    public void setDataPointHolder(DataPointHolder dataPointHolder) {
        this.dataPointHolder = dataPointHolder;
    }

    private <T> T[] logMetrics(T[] values) {
        dataPointHolder.add("Num Retrieved", values.length);
        return values;
    }
}
