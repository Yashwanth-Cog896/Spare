package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;

/**
 * nbwald - May 21, 2009 5:57:25 PM
 */
public class NonMonEventDoesNotExistRule
   implements Rule<String>
{
   private final NonMonEvent nonMonEvent;

   public NonMonEventDoesNotExistRule(NonMonEvent nonMonEvent) {
      this.nonMonEvent = nonMonEvent;
   }

   @Override
   public boolean violated() {
      return nonMonEvent != null;
   }

   @Override
   public String getViolation() {
      return "Non-Monsanto event already exists.";
   }
}
