package com.monsanto.tps.lexicon.regulatory.event.validation;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;

/**
 * rrchak1 - Feb 5, 2009 4:14:10 PM
 */
public class EventAgencyAlignmentValidatorImpl
   implements EventAgencyAlignmentValidator
{
   private EventSearchServiceQuerySet eventSearchServiceQuerySet;

   /*
   Check if eventAgencyAlignment already exists
   with given Event name and Agency pubkey
    */
   public void valiateAgencyAlignedToEventAndCrop(String agencyPubkey, EventAgencyAlignmentRequest eventAgencyAlignmentRequest)
      throws WrappingException
   {
      EventAgencyAlignment eventAgencyAlignment =
         eventSearchServiceQuerySet.findEventAgencyAlignmentsByEventCropAndAgencyPubkey(eventAgencyAlignmentRequest.getEvent(),
            eventAgencyAlignmentRequest.getCrop(), agencyPubkey);
      if (eventAgencyAlignment != null) {
         throw new WrappingException(new Exception("EventAgencyAlignment already exists"));
      }
   }

   public void setEventSearchServiceQuerySet(EventSearchServiceQuerySet eventSearchServiceQuerySet) {
      this.eventSearchServiceQuerySet = eventSearchServiceQuerySet;
   }

   public EventAgencyAlignment validateAlignmentExists(String eventAgencyAlignmentPubkey)
      throws WrappingException
   {
      EventAgencyAlignment[] eventAgencyAlignments =
         eventSearchServiceQuerySet.findEventAgencyAlignmentByPubkey(new String[]{eventAgencyAlignmentPubkey});
      if (ArrayUtils.isNullOrEmpty(eventAgencyAlignments)) {
         throw new WrappingException(new Exception("EventAgencyAlignment does not exist"));
      }
      return eventAgencyAlignments[0];
   }
}
