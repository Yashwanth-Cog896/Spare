package com.monsanto.tps.lexicon.regulatory.event.model;

/**
 * rrchak1 - Jul 8, 2009 1:37:54 PM
 */
public class RegulatoryEvent
{
   private EventConstruct[] eventConstructs;
   private String monNumber;
   private String eventName;

   public RegulatoryEvent(EventConstruct[] eventConstructs, String monNumber, String eventName) {
      this.eventConstructs = eventConstructs;
      this.monNumber = monNumber;
      this.eventName = eventName;
   }

   public EventConstruct[] getEventConstructs() {
      return eventConstructs;
   }

   public String getMonNumber() {
      return monNumber;
   }

   public String getEventName() {
      return eventName;
   }
}
