package com.monsanto.tps.lexicon.regulatory.shippingcondition.business;

import com.monsanto.tps.lexicon.shippingcondition.OrionShippingCondition;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ShippingCondition;
import com.monsanto.tps.lexicon.regulatory.shippingcondition.dao.ShippingConditionDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ShippingConditionBusiness {

    @Resource
    private ShippingConditionDAO shippingConditionDAO;

    public List<OrionShippingCondition> findShippingConditions(final String shippingConditionType) {
        final List<ShippingCondition> shippingConditionTypeList = shippingConditionDAO.findShippingConditions(WildcardUtil.replaceAsteriskWildcardWithPercent(shippingConditionType));
        final List<OrionShippingCondition> orionShippingConditionList = new ArrayList<OrionShippingCondition>();

        for (ShippingCondition type : shippingConditionTypeList) {
            orionShippingConditionList.add(new OrionShippingCondition(type.getShippingCondition(), type.getActiveStatus()));
        }

        return orionShippingConditionList;
    }


}

