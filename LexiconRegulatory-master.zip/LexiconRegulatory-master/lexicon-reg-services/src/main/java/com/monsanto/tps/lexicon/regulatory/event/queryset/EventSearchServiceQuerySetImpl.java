package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
/**
 * nbwald - Jan 7, 2009 3:13:09 PM
 */
public class EventSearchServiceQuerySetImpl
   implements EventSearchServiceQuerySet
{
   private MonNumberDao monNumberDao;
   private EventAgencyAlignmentDao eventAgencyAlignmentDao;
   private RegulatoryEventRequestProcessor regulatoryEventRequestProcessor;

   public EventSearchServiceQuerySetImpl(MonNumberDao monNumberDao, EventAgencyAlignmentDao eventAgencyDao, RegulatoryEventRequestProcessor regulatoryEventRequestProcessor) {
      this.monNumberDao = monNumberDao;
      this.eventAgencyAlignmentDao = eventAgencyDao;
      this.regulatoryEventRequestProcessor = regulatoryEventRequestProcessor;
   }

   public  List<RegulatoryEventResponse>  findRegulatoryEventByEventAndCrop(Collection<EventCrop> eventCrops) {
      try {
         List<RegulatoryEventRequest> eventRequests = new ArrayList<RegulatoryEventRequest>(eventCrops.size());
         for(EventCrop eventCrop:eventCrops){
             eventRequests.add(new RegulatoryEventRequest(eventCrop.getEvent(),eventCrop.getCrop()));
         }
         return regulatoryEventRequestProcessor.getRegulatoryEvents(eventRequests);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (IOException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   public MonNumber findMonNumberByEventAndCrop(String eventName, String cropName) {
      return monNumberDao.findByEventAndCrop(eventName, cropName);
   }

   public EventAgencyAlignment[] findEventAgencyAlignmentsByEventAndCrop(String eventName, String cropName) {
      return eventAgencyAlignmentDao.findByEventAndCrop(eventName, cropName);
   }

   public MonNumber findMonNumber(String monNumberValue) {
      return monNumberDao.find(monNumberValue);
   }

   public EventAgencyAlignment findEventAgencyAlignmentsByEventCropAndAgencyPubkey(String eventName, String cropName, String agencyPubkey) {
      return eventAgencyAlignmentDao.findByEventCropAndAgencyPubkey(eventName, cropName, agencyPubkey);
   }

   public EventAgencyAlignment[] findEventAgencyAlignmentByPubkey(String[] eventAgencyAlignmentPubkey) {
      return eventAgencyAlignmentDao.findByPubkey(eventAgencyAlignmentPubkey);
   }

   public EventAgencyAlignment[] findByAgencyAbbr(String[] agencyAbbreviations) {
      return eventAgencyAlignmentDao.findByAgencyAbbr(agencyAbbreviations);
   }
}
