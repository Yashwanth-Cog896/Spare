package com.monsanto.tps.lexicon.regulatory.plantname.service;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.plantname.RegulatorySeedMaterialService;
import com.monsanto.tps.lexicon.regulatory.plantname.business.RegulatorySeedMaterialBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/19/12
 * Time: 10:05 PM
 */
@Component
public class RegulatorySeedMaterialServiceImpl implements RegulatorySeedMaterialService {
    @Resource
    private RegulatorySeedMaterialBusiness regulatorySeedMaterialBusiness;

    @Override
    public List<OrionPlantProduct> findPlantNames(String productName) {
        return regulatorySeedMaterialBusiness.findPlantNames(productName);
    }
}
