package com.monsanto.tps.lexicon.regulatory.util.validationresults;

import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionCode;

/**
 * nbwald - Apr 14, 2008 6:48:04 PM
 */
public class SimpleValidationCondition
   implements ValidationCondition
{
   private final String error;

   public SimpleValidationCondition(String error) {
      this.error = error;
   }

   public ValidationConditionCode getCode() {
      return new ValidationConditionCode(error);
   }

   public String getError() {
      return error;
   }
}
