package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * rrchak1 - Jul 13, 2009 4:42:43 PM
 */
public interface EventConstructTransformationsByEventAndCropQuery
{

   public RegulatoryEventConstructTransformation[] find(String eventName, String cropGenusSpecies);
}
