package com.monsanto.tps.lexicon.regulatory.plantname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:42 PM
 */
@Component
public class PlantNameDAOImpl implements PlantNameDAO{

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<PlantName> findPlantNames(final String productName) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActivePlantNameIgnoreCaseSort");
        query.setParameter("productName", WildcardUtil.replaceEmptyStringWithWildcard(productName));

        return (List<PlantName>) query.list();
    }
}
