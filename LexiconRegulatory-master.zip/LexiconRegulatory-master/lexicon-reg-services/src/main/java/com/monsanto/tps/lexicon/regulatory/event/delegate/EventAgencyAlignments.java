package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * rrchak1 - Feb 11, 2009 3:59:06 PM
 */
public class EventAgencyAlignments {
    private EventAgencyAlignment[] aligments;

    public EventAgencyAlignments(EventAgencyAlignment[] alignments) {
        this.aligments = alignments;
    }

    public Map<EventCrop, List<EventAgencyAlignment>> getUniqueEventsAndAssociatedAlignments() {
        Map<EventCrop, List<EventAgencyAlignment>> alignmentsByEvent = new HashMap<EventCrop, List<EventAgencyAlignment>>();
        for (EventAgencyAlignment eventAgencyAlignment : aligments) {
            List<EventAgencyAlignment> alignments;
            EventCrop eventCrop = new EventCrop(eventAgencyAlignment.getMaterialName(), eventAgencyAlignment.getCrop().getCropName());
            if (alignmentsByEvent.containsKey(eventCrop)) {
                alignments = alignmentsByEvent.get(eventCrop);
                alignmentsByEvent.remove(eventCrop);
            } else {
                alignments = new ArrayList<EventAgencyAlignment>();
            }
            alignments.add(eventAgencyAlignment);
            alignmentsByEvent.put(eventCrop, alignments);
        }
        return alignmentsByEvent;
    }
}
