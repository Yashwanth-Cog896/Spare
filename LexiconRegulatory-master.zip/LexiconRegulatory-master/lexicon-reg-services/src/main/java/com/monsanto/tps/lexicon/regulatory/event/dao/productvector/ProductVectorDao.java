package com.monsanto.tps.lexicon.regulatory.event.dao.productvector;

import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;

import java.util.List;

/**
 * rrchak1 - Apr 24, 2009 10:58:46 AM
 */
public interface ProductVectorDao
{
   public String[] findProductVectorsByCropIdAndConstructNameForCombinedConstructs(long cropPubkey, String[] constructNames);

   public String[] findProductVectorsByCropIdAndConstructNameForSingleConstructs(long cropPubkey, String constructName);
    
   public List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers);
}
