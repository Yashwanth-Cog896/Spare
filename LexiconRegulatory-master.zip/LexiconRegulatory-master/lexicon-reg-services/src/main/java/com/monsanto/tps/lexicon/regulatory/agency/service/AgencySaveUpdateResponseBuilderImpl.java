package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;

/**
 * aagosw - Mar 6, 2009 9:03:24 AM
 */
public class AgencySaveUpdateResponseBuilderImpl
   implements AgencySaveUpdateResponseBuilder
{
   public AgencySaveUpdateResponse buildResponse(AgencySaveUpdateRequest agencySaveUpdateRequest, ValidationResults validationResults) {
      AgencySaveUpdateResponse response = new AgencySaveUpdateResponse();
      response.setAgencyAbbvr(agencySaveUpdateRequest.getAgencyAbbr());
      response.setAgencyCountryIsoCode(agencySaveUpdateRequest.getCountryIsoCode());
      response.setDeptAbbvr(agencySaveUpdateRequest.getAgencyDeptAbbr());
      response.setMessages(validationResults.getMessages());
      response.setSuccessful(!validationResults.hasErrors());
      return response;
   }
}
