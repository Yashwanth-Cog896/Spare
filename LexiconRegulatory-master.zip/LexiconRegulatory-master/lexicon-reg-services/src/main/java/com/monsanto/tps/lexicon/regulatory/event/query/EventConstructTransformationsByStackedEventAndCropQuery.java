package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Jul 13, 2009 5:19:49 PM
 */
public class EventConstructTransformationsByStackedEventAndCropQuery
   implements EventConstructTransformationsByEventAndCropQuery
{
   @Override
   public RegulatoryEventConstructTransformation[] find(String eventName, String cropGenusSpecies) {
      MidasGermplasmByStackedEventAndCropQuery germplasmQuery = new MidasGermplasmByStackedEventAndCropQuery(eventName,cropGenusSpecies);
      Long germplasmId = germplasmQuery.getSingleGermplasmId();
      if(germplasmId!=null){
         MidasEventConstructsByStackedEventGermplasmAndCropQuery eventConstructQuery =
            new MidasEventConstructsByStackedEventGermplasmAndCropQuery(germplasmId, cropGenusSpecies);
         RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = eventConstructQuery.find();
         if (eventsMatch(regulatoryEventConstructTransformations, eventName)) {
            return regulatoryEventConstructTransformations;
         }
      }
      return new RegulatoryEventConstructTransformation[0];
   }

   private boolean eventsMatch(RegulatoryEventConstructTransformation[] eventConstructs, String eventName) {
      String[] eventNames = extractEventNames(eventConstructs);

      return ArrayUtils.areEqual(eventNames, StringUtils.splitCsv(StringUtils.toUpperCaseNull(eventName), false));
   }

   private String[] extractEventNames(RegulatoryEventConstructTransformation[] eventConstructs) {
      List<String> eventNameList = new ArrayList<String>();
      for (RegulatoryEventConstructTransformation eventConstruct : eventConstructs) {
         eventNameList.add(StringUtils.toUpperCaseNull(eventConstruct.getEvent()));
      }
      return eventNameList.toArray(new String[eventNameList.size()]);
   }
}
