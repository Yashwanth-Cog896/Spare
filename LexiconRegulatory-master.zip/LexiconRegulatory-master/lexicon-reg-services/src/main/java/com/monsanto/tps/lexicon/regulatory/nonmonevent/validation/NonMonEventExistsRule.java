package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;

/**
 * nbwald - May 25, 2009 4:31:29 PM
 */
public class NonMonEventExistsRule
   implements Rule<String>
{
   private final NonMonEvent nonMonEvent;

   public NonMonEventExistsRule(NonMonEvent nonMonEvent) {
      this.nonMonEvent = nonMonEvent;
   }

   @Override
   public boolean violated() {
      return nonMonEvent == null;
   }

   @Override
   public String getViolation() {
      return "Non-Monsanto event does not exist.";
   }
}
