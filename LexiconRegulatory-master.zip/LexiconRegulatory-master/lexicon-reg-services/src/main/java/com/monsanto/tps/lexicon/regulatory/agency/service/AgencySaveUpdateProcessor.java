package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.regulatory.agency.dao.AgencyDao;
import com.monsanto.tps.lexicon.regulatory.agency.util.AgencyBeanUtil;

import java.util.List;

/**
 * aagosw - Mar 5, 2009 6:54:30 AM
 */
public interface AgencySaveUpdateProcessor
{
   void save(AgencySaveUpdateRequest[] agencySaveUpdateRequests, AgencyDao agencyDao, AgencyBeanUtil agencyBeanUtil, List<AgencySaveUpdateResponse> responseList, boolean commit);

   void update(AgencySaveUpdateRequest[] agencySaveUpdateRequests, AgencyDao agencyDao, AgencyBeanUtil agencyBeanUtil, List<AgencySaveUpdateResponse> responseList, boolean commit);
}
