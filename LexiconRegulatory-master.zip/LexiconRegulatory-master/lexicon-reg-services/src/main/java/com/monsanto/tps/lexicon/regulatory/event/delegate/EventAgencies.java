package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jan 6, 2009 11:56:46 AM
 */
public class EventAgencies
{
   private EventAgencyAlignment[] models;

   public EventAgencies(EventAgencyAlignment[] models) {
      this.models = models;
   }

   public EventAgency[] getResponseEventAgencies() {
      List<EventAgency> responses = new ArrayList<EventAgency>();
      for (EventAgencyAlignment model : models) {
         responses.add(buildResponseFromModel(model));
      }
      return responses.toArray(new EventAgency[responses.size()]);
   }

   private EventAgency buildResponseFromModel(EventAgencyAlignment model) {
      EventAgency response = new EventAgency();
      response.setRegulated(SQLUtil.stringToBoolean(model.getRegulated()));
      setAgencyFields(response, model.getAgency());
      response.setDeregulatedEffectiveDate(model.getDeregulatedEffectiveDate());
      response.setMaxQuantity(model.getMaxQuantity());
      response.setPublicKey(model.getEventAgencyAlignmentPubkey());
      response.setDiscoveryMaterial(model.getDiscoveryMaterial());

      return response;
   }

   private void setAgencyFields(EventAgency response, Agency agency) {
      if (agency != null) {
         response.setAgencyAbbr(agency.getAgencyAbbr());
         response.setCountryName(agency.getCountry().getCountryName());
         response.setSurfaceAreaUomCode(agency.getSurfaceAreaUomCode());
      }
   }
}
