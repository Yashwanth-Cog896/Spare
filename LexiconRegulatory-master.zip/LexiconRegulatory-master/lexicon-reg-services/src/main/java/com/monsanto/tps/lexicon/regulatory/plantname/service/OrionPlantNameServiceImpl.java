package com.monsanto.tps.lexicon.regulatory.plantname.service;

import com.monsanto.tps.lexicon.plantname.OrionPlantNameService;
import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.plantname.business.OrionPlantNameBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:38 PM
 */
@Component
public class OrionPlantNameServiceImpl implements OrionPlantNameService {
    @Resource
    private OrionPlantNameBusiness orionPlantNameBusiness;

    @Override
    public List<OrionPlantProduct> findPlantNames(String productName) {
        return orionPlantNameBusiness.findPlantNames(productName);
    }
}
