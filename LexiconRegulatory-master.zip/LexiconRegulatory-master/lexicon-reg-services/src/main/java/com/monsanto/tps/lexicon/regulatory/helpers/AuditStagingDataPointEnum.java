package com.monsanto.tps.lexicon.regulatory.helpers;

/**
 * rrchak1 - May 15, 2009 3:42:06 PM
 */
public enum AuditStagingDataPointEnum
{
   AUDITCOMMENT,
   AUDITREQUESTOR
}
