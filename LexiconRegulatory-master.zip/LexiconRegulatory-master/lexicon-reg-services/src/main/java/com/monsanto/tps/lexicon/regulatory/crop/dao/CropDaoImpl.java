package com.monsanto.tps.lexicon.regulatory.crop.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * rrchak1 - Feb 13, 2009 12:46:41 PM
 */
public class CropDaoImpl
   implements CropDao
{
   private SessionFactory sessionFactory;

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public Crop findByName(String cropName) {
      Session session = sessionFactory.getCurrentSession();
      return (Crop) session.getNamedQuery("crop.byCropName").setString(0, StringUtils.upperCase(cropName)).uniqueResult();
   }

   public Crop findByPubkey(String cropPubkey) {
      Session session = sessionFactory.getCurrentSession();
      return (Crop) session.getNamedQuery("crop.byCropPubkey").setString(0, cropPubkey).uniqueResult();
   }

   @Override
   public List<Crop> findByAbbreviation(String genusSpecies) {
      Session session = sessionFactory.getCurrentSession();
      return (List<Crop>) session.getNamedQuery("crop.byAbbreviation").setString(0, genusSpecies).list();
   }

   public Crop[] findAll() {
      Session session = sessionFactory.getCurrentSession();
      List<Crop> allCrops = session.getNamedQuery("crop.all").list();
      return allCrops.toArray(new Crop[allCrops.size()]);
   }
}
