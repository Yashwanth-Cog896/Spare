package com.monsanto.tps.lexicon.regulatory.event.queryset;

/**
 * rrchak1 - Feb 16, 2009 11:36:39 AM
 */
public class EventCrop
{
   private String event;
   private String crop;

   public EventCrop(String event, String cropName) {
      this.event = event;
      this.crop = cropName;
   }

   public String getEvent() {
      return event;
   }

   public String getCrop() {
      return crop;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      EventCrop eventCrop = (EventCrop) o;

      if (!crop.equals(eventCrop.crop)) {
         return false;
      }
      if (!event.equals(eventCrop.event)) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result = event.hashCode();
      result = 31 * result + crop.hashCode();
      return result;
   }
}
