package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * User: pjberry
 * Date: Jul 27, 2007
 * Time: 2:58:19 PM
 */
public interface RegulatoryEventConstructTransformationByEventNameAndCropQuery
{
   RegulatoryEventConstructTransformation[] getEventConstructTransformations()
      throws WrappingException;
}
