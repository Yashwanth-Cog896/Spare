package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Collection;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 21, 2009
 * Time: 11:55:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class ComlTraitType
{
   private long comlTraitTypeId;
   private String comlTraitTypeAbbr;
   private String comlTraitTypeDesc;
   private Collection<DataFilter> dataFilters = new HashSet<DataFilter>();

   public Collection<DataFilter> getDataFilters() {
      return dataFilters;
   }

   public void setDataFilters(Collection<DataFilter> dataFilters) {
      this.dataFilters = dataFilters;
   }

   public long getComlTraitTypeId() {
      return comlTraitTypeId;
   }

   public void setComlTraitTypeId(long comlTraitTypeId) {
      this.comlTraitTypeId = comlTraitTypeId;
   }

   public String getComlTraitTypeAbbr() {
      return comlTraitTypeAbbr;
   }

   public void setComlTraitTypeAbbr(String comlTraitTypeAbbr) {
      this.comlTraitTypeAbbr = comlTraitTypeAbbr;
   }

   public String getComlTraitTypeDesc() {
      return comlTraitTypeDesc;
   }

   public void setComlTraitTypeDesc(String comlTraitTypeDesc) {
      this.comlTraitTypeDesc = comlTraitTypeDesc;
   }
}
