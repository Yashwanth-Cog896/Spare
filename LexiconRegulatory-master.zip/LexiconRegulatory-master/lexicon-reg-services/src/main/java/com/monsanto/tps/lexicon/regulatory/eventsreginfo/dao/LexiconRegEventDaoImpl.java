package com.monsanto.tps.lexicon.regulatory.eventsreginfo.dao;

import com.monsanto.tps.lexicon.regulatory.eventsreginfo.domain.lexicon.LexiconRegEvent;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Oct 5, 2010
 * Time: 2:16:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconRegEventDaoImpl
        implements LexiconRegEventDao {

    private SessionFactory sessionFactory;

    @Override
    public List<LexiconRegEvent> findMonNumbersByCollectionCriteria() {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("LexiconRegEventDao.findMonNumbersByCollectionCriteria");
        return (List<LexiconRegEvent>) query.list();
    }

    @Override
    public List<LexiconRegEvent> findMonNumbers(LexiconRegEvent info) {
        Session session = sessionFactory.getCurrentSession();
        Example infoEx = Example.create(info)
                .ignoreCase()
                .enableLike();
        return (List<LexiconRegEvent>) session.createCriteria(LexiconRegEvent.class)
                .add(infoEx)
                .add(Restrictions.eq("activeStatus", true))
                .list();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
