/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.chemicalname.business;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao.AdditionalMaterialDAO;
import com.monsanto.tps.lexicon.regulatory.chemicalname.comparator.AdditionalMaterialComparator;
import com.monsanto.tps.lexicon.regulatory.chemicalname.comparator.OrionChemicalNameComparator;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* NBWALD - 5/10/12 */
@Component
public class OrionChemicalNameBusiness
{
    @Resource
    private ChemicalNameBusiness chemNameBusiness;
    @Resource
    private AdditionalMaterialDAO additionalMaterialDAO;

    public List<OrionChemicalName> findChemicalNames(String materialName) {
        List<OrionChemicalName> combinedResults = new ArrayList<OrionChemicalName>();
        getCombinedResults(materialName, combinedResults);
        List<AdditionalMaterial> additionalResults = getAdditionalResults(materialName);
        mergeResults(combinedResults, additionalResults);
        removeTooLongResults(combinedResults);
        Collections.sort(combinedResults, new OrionChemicalNameComparator());
        return combinedResults;
    }

    private void removeTooLongResults(List<OrionChemicalName> combinedResults) {
        for (Iterator<OrionChemicalName> it = combinedResults.iterator(); it.hasNext(); ) {
            OrionChemicalName info = it.next();
            if (info.getMaterialName().length() > 40) {
                it.remove();
            }
        }
    }

    private void getCombinedResults(String materialName, List<OrionChemicalName> combinedResults) {
        getChemicalNameResults(materialName, combinedResults);
        getChemicalMaterialResults(materialName, combinedResults);
        Collections.sort(combinedResults, new OrionChemicalNameComparator());
    }

    private void getChemicalNameResults(String materialName, List<OrionChemicalName> combinedResults) {
        List<OrionChemicalName> chemNameResults = chemNameBusiness.findChemicalNames(materialName);
        if(chemNameResults != null) {
            combinedResults.addAll(chemNameResults);
        }
    }

    private void getChemicalMaterialResults(String materialName, List<OrionChemicalName> combinedResults) {
        List<OrionChemicalName> chemNameResults = chemNameBusiness.findChemicalMaterials(materialName);
        if(chemNameResults != null) {
            combinedResults.addAll(chemNameResults);
        }
    }

    private List<AdditionalMaterial> getAdditionalResults(String materialName) {
        List<AdditionalMaterial> additionalResults = additionalMaterialDAO.findAdditionalMaterials(WildcardUtil.replaceAsteriskWildcardWithPercent(materialName));
        if(additionalResults == null) {
            additionalResults = new ArrayList<AdditionalMaterial>();
        }
        Collections.sort(additionalResults, new AdditionalMaterialComparator());
        return additionalResults;
    }

    private void mergeResults(List<OrionChemicalName> combinedResults, List<AdditionalMaterial> additionalResults) {
        //FYI,  An AdditionalMaterialInfo can apply to more than one OrionChemicalName
        int indexAdditional=0;
        int indexChem=0;
        while (indexAdditional<additionalResults.size() && indexChem < combinedResults.size()) {
            AdditionalMaterial addlInfo = additionalResults.get(indexAdditional);
            OrionChemicalName chemInfo = combinedResults.get(indexChem);

            if (compareInfo(chemInfo, addlInfo) > 0) {
                indexAdditional++;
            } else {
                if (compareInfo(chemInfo, addlInfo) == 0) {
                    mergeDataFields(chemInfo, addlInfo);
                }
                indexChem++;
            }
        }
    }

    private void mergeDataFields(OrionChemicalName chemInfo, AdditionalMaterial addlInfo) {
        chemInfo.setAlias(addlInfo.getAlias());
        chemInfo.setChemicalNameCAS(addlInfo.getChemicalNameCAS());
        chemInfo.setChemicalNameIUPAC(addlInfo.getChemicalNameIUPAC());
        chemInfo.setCpNumber(addlInfo.getCpNumber());
        if (addlInfo.getStructureInfo() != null) {
//not returned from service
//            chemInfo.setEncodedImage(Base64.encode(addlInfo.getStructureInfo().getMolecularStructure()));
            chemInfo.setImageName(addlInfo.getStructureInfo().getImageName());
            chemInfo.setMolecularWeight(addlInfo.getStructureInfo().getMolecularWeight());
            chemInfo.setMolecularFormula(addlInfo.getStructureInfo().getMolecularFormula());
            chemInfo.setElementalTheory(addlInfo.getStructureInfo().getElementalTheory());
        }
    }

    private int compareInfo(OrionChemicalName chemInfo, AdditionalMaterial addlInfo) {
        String chemName = chemInfo.getMaterialName();
        String addlName = addlInfo.getMaterialName();
        return chemName.compareToIgnoreCase(addlName);
    }
}