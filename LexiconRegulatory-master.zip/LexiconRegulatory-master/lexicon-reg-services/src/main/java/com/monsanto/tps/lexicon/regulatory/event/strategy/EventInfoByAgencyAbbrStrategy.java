package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;

/**
 * rrchak1 - Feb 17, 2009 12:39:10 PM
 */
public interface EventInfoByAgencyAbbrStrategy
{
   EventInfo[] find(String[] agencyAbbr);
}
