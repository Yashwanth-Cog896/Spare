/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductStageEntity;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao.ProductStageDao;

/* vvkalu - 7/26/11 */
public class ComlTraitBusiness {

    private ProductStageDao productStageDao;
    private ComlTraitStackBuilder comlTraitStackBuilder;

    public GermplasmEventTraitResponse getComlTraitForProduct(Long germplasmId, GermplasmEventTraitResponse traitEventConstructs) {
        LexiconProductStageEntity stageByGermplasmId = productStageDao.getFirstProductStageByGermplasmId(germplasmId);
        if (stageByGermplasmId != null && stageByGermplasmId.getComlTraitStack() != null) {
            return comlTraitStackBuilder.buildComlTraitStack(germplasmId,
                    stageByGermplasmId.getComlTraitStack().getComlTraitStackId(),
                    stageByGermplasmId.getComlTraitStack(), traitEventConstructs);
        }
        return traitEventConstructs;
    }

    public void setProductStageDao(ProductStageDao productStageDao) {
        this.productStageDao = productStageDao;
    }

    public void setComlTraitStackBuilder(ComlTraitStackBuilder comlTraitStackBuilder) {
        this.comlTraitStackBuilder = comlTraitStackBuilder;
    }
}