package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * nbwald - Aug 27, 2008 3:39:19 PM
 */
public class Company
{
   private long companyId;

   public long getCompanyId() {
      return companyId;
   }

   public void setCompanyId(long companyId) {
      this.companyId = companyId;
   }

   private String companyPubkey;

   public String getCompanyPubkey() {
      return companyPubkey;
   }

   public void setCompanyPubkey(String companyPubkey) {
      this.companyPubkey = companyPubkey;
   }

   private String companyName;

   public String getCompanyName() {
      return companyName;
   }

   public void setCompanyName(String companyName) {
      this.companyName = companyName;
   }

   private String active;

   public String getActive() {
      return active;
   }

   public void setActive(String active) {
      this.active = active;
   }

   private String competitor;

   public String getCompetitor() {
      return competitor;
   }

   public void setCompetitor(String competitor) {
      this.competitor = competitor;
   }
}
