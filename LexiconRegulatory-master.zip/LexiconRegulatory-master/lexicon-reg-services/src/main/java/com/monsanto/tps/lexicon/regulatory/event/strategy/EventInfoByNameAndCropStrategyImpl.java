package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventInfoBuilder;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEvent;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * nbwald - Jan 30, 2009 10:41:46 AM
 */
public class EventInfoByNameAndCropStrategyImpl
   implements EventInfoByNameAndCropStrategy
{
   private final  EventSearchServiceQuerySet querySet;
   private static final String COMMA = ",";
   private static final String FORWARD_SLASH = "/";

   public EventInfoByNameAndCropStrategyImpl(EventSearchServiceQuerySet querySet) {
      this.querySet = querySet;
   }

   public EventInfo[] find(String[] eventNames, String cropName) {
      List<EventInfo> eventInfos = new ArrayList<EventInfo>();
      List<RegulatoryEventResponse>  eventConstructs = querySet.findRegulatoryEventByEventAndCrop(buildEventCrops(eventNames, cropName));
      if ((eventConstructs!=null)&&(!eventConstructs.isEmpty())) {

         for(RegulatoryEventResponse eventResponse: eventConstructs){
             Map<String, List<EventConstruct>> distinctEvents = findDistinctEvents(eventResponse.getEventConstructs());
             List<RegulatoryEvent> regulatoryEventList = new ArrayList<RegulatoryEvent>();
             for ( Map.Entry<String, List<EventConstruct>> entry : distinctEvents.entrySet()) {
                String distinctEvent = entry.getKey();
                List<EventConstruct> constructList = entry.getValue();
                RegulatoryEvent regulatoryEvent = buildRegulatoryEvent(cropName, distinctEvent, constructList);
                regulatoryEventList.add(regulatoryEvent);
             }
             eventInfos.add(buildEventInfo(regulatoryEventList, cropName, eventResponse.getEvent()));
         }
      }
      return eventInfos.toArray(new EventInfo[eventInfos.size()]);
   }

    private List<EventCrop> buildEventCrops(String[] eventNames, String cropName) {
        if(eventNames!=null){
            List<EventCrop> eventCrops = new ArrayList<EventCrop>(eventNames.length);
            for(String eventName:eventNames){
                eventCrops.add(new EventCrop(getOrderedEvent(eventName.toUpperCase()),cropName));
            }
            return eventCrops;
        }
        else {
            return new ArrayList<EventCrop>();
        }
    }

    private RegulatoryEvent buildRegulatoryEvent(String cropName, String distinctEvent, List<EventConstruct> constructList) {
      MonNumber monNumber = querySet.findMonNumberByEventAndCrop(distinctEvent, cropName);
      String monNumberValue = monNumber == null ? null : monNumber.getMonNumber();
      return new RegulatoryEvent(constructList.toArray(new EventConstruct[constructList.size()]), monNumberValue, distinctEvent);
   }

   private Map<String, List<EventConstruct>> findDistinctEvents(Collection<EventConstruct> eventConstructs) {
      Map<String, List<EventConstruct>> eventMap = new HashMap<String, List<EventConstruct>>();
      List<EventConstruct> eventConstructList;
      for (EventConstruct eventConstruct : eventConstructs) {
         eventConstructList = getEventConstructList(eventMap, eventConstruct);
         eventConstructList.add(eventConstruct);
         eventMap.put(eventConstruct.getEvent(), eventConstructList);
      }
      return eventMap;
   }

   private List<EventConstruct> getEventConstructList(Map<String, List<EventConstruct>> eventMap, EventConstruct eventConstruct) {
      List<EventConstruct> eventConstructList;
      if (eventMap.containsKey(eventConstruct.getEvent())) {
         eventConstructList = eventMap.get(eventConstruct.getEvent());
      }
      else {
         eventConstructList = new ArrayList<EventConstruct>();
      }
      return eventConstructList;
   }

   private EventInfo buildEventInfo(List<RegulatoryEvent> regulatoryEvents, String cropName, String eventName) {
      EventAgencyAlignment[] eventAgencyAlignments = querySet.findEventAgencyAlignmentsByEventAndCrop(getOrderedEvent(eventName), cropName);
      EventInfoBuilder builder = new EventInfoBuilder();
      return builder.build(regulatoryEvents, eventAgencyAlignments, cropName);
   }

   private String getOrderedEvent(String eventName) {
      if (StringUtils.contains(eventName, COMMA) || StringUtils.contains(eventName, FORWARD_SLASH)) {
         return changeOrderOfStackedEvents(eventName);
      }
      return eventName;
   }

   private String changeOrderOfStackedEvents(String eventName) {
      String modifiedEventName = eventName;
      String[] eventArray = new String[]{};
      if (StringUtils.contains(eventName, COMMA)) {
         eventArray = StringUtils.split(eventName, COMMA);
      }
      else if (StringUtils.contains(eventName, FORWARD_SLASH)) {
         eventArray = StringUtils.split(eventName, FORWARD_SLASH);
      }
      if (ArrayUtils.hasItems(eventArray)) {
         List<String> stringList = Arrays.asList(eventArray);
         Collections.sort(stringList);
         eventArray = stringList.toArray(new String[stringList.size()]);
         modifiedEventName = StringUtils.join(eventArray, COMMA);
      }

      return modifiedEventName;
   }
}
