package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.agency.dao.AgencyDao;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;

import java.util.Date;

/**
 * rrchak1 - Feb 3, 2009 5:43:34 PM
 */
public class EventAgencyAlignmentRequestParserImpl
        implements EventAgencyAlignmentRequestParser {
    public static final String TRAIT = "Trait";
    private CropDao cropDao;
    private AgencyDao agencyDao;
    private EventAgencyAlignmentDao eventAgencyAlignmentDao;
    private UserProfile userProfile;

    public void copyProperties(EventAgencyAlignment eventAgencyAlignment, EventAgencyAlignmentUpdateInfo alignmentUpdateInfo) {
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(alignmentUpdateInfo.getRegulated()));
        eventAgencyAlignment.setDeregulatedEffectiveDate(alignmentUpdateInfo.getDeregulatedEffectiveDate());
        eventAgencyAlignment.setMaxQuantity(alignmentUpdateInfo.getMaxQuantity());
    }

    public void setCropDao(CropDao cropDao) {
        this.cropDao = cropDao;
    }

    public void setAgencyDao(AgencyDao agencyDao) {
        this.agencyDao = agencyDao;
    }

    public void setEventAgencyAlignmentDao(EventAgencyAlignmentDao eventAgencyAlignmentDao) {
        this.eventAgencyAlignmentDao = eventAgencyAlignmentDao;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

    public EventAgencyAlignment buildEventAgencyAlignmentFromRequest(EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo, EventAgencyAlignmentRequest eventAgencyAlignmentRequest)
            throws WrappingException {
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setMaterialName(eventAgencyAlignmentRequest.getEvent());
        eventAgencyAlignment.setDeregulatedEffectiveDate(eventAgencyAlignmentRequestInfo.getDeregulatedEffectiveDate());
        eventAgencyAlignment.setMaxQuantity(eventAgencyAlignmentRequestInfo.getMaxQuantity());
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(eventAgencyAlignmentRequestInfo.getRegulated()));
        eventAgencyAlignment.setCrop(getCropByName(eventAgencyAlignmentRequest.getCrop()));
        eventAgencyAlignment.setAgency(getAgencyByPubkey(eventAgencyAlignmentRequestInfo.getAgencyPubkey()));

        eventAgencyAlignment.setAgencyMaterialType(getAgencyMaterialTypeIdByName(TRAIT));
        eventAgencyAlignment.setCreatedDate(new Date());
        eventAgencyAlignment.setModifiedDate(new Date());
        eventAgencyAlignment.setCreatedUserID(userProfile.getUserName());
        eventAgencyAlignment.setModifiedUserId(userProfile.getUserName());
        return eventAgencyAlignment;
    }

    private Agency getAgencyByPubkey(String agencyPubkey)
            throws WrappingException {
        AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
        agencySearchCriteria.setAgencyPubkey(new String[]{agencyPubkey});
        AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
        if (departments == null || departments.length == 0) {
            throw new WrappingException(new Exception("Agency not found for the given pubkey"));
        }
        return departments[0].getAgency();
    }

    private Crop getCropByName(String cropName)
            throws WrappingException {
        Crop crop = cropDao.findByName(cropName);
        if (crop == null) {
            throw new WrappingException(new Exception("Crop not found for the given cropName"));
        }
        return crop;
    }

    private AgencyMaterialType getAgencyMaterialTypeIdByName(String materialTypeDesc)
            throws WrappingException {
        AgencyMaterialType agencyMaterialType = eventAgencyAlignmentDao.getAgencyMaterialTypeIdByName(materialTypeDesc);
        if (agencyMaterialType == null) {
            throw new WrappingException(new Exception("AgencyMaterialType not found for the given materialTypeDesc"));
        }
        return agencyMaterialType;
    }


}
