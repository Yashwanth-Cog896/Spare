package com.monsanto.tps.lexicon.regulatory.container.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ContainerType;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ContainerDAOImpl implements ContainerDAO {

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<ContainerType> findContainerTypes(final String containerType) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveContainerIgnoreCaseSort");
        query.setParameter("containerType", WildcardUtil.replaceEmptyStringWithWildcard(containerType));

        return (List<ContainerType>) query.list();
    }
}
