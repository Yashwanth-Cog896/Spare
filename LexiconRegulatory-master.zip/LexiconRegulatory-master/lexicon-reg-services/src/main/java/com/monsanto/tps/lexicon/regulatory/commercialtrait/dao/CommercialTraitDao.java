package com.monsanto.tps.lexicon.regulatory.commercialtrait.dao;

import com.monsanto.tps.lexicon.commercialtrait.RegulatoryTraitOption;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;

import java.util.Collection;
import java.util.List;

/**
 * rrchak1 - May 4, 2009 5:35:25 PM
 */
public interface CommercialTraitDao
{
   Collection<RegulatoryTraitOption> getRegulatoryTraitTypeOptions();

   ComlTraitType findCommercialTraitTypeByAbbr(String traitAbbreviation);

   ComlTraitName findCommercialTraitByAbbr(String traitAbbr);

   List<String> getComTraitTypeDescByComlTraitStackId(long comlTraitStackId);

   ComlTraitStack getComlTraitStackById(long comlTraitStackId);
}
