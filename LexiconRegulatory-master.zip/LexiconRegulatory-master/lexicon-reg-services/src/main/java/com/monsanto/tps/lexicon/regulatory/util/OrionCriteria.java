package com.monsanto.tps.lexicon.regulatory.util;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/22/12
 * Time: 1:09 PM
 */

public class OrionCriteria {

    public static String format(String inputString) {
        return inputString == null ? "%" : inputString.replace('*', '%');
    }

}
