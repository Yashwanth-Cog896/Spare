package com.monsanto.tps.lexicon.regulatory.formulation.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.FormulationType;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class FormulationDAOImpl implements FormulationDAO {

    private static final String QUERY_FIND_BY_TYPE = "from FormulationType ft where upper(formulation_type) like upper(:formulationType) and active_status = 'y' order by upper(formulation_type)";

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<FormulationType> findFormulationTypes(final String formulationType) {
        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveFormulationIgnoreCaseSort");
        query.setParameter("formulationType", WildcardUtil.replaceEmptyStringWithWildcard(formulationType));

        return (List<FormulationType>) query.list();
    }
}
