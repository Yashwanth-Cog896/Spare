package com.monsanto.tps.lexicon.regulatory.audit.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AuditStaging;

/**
 * rrchak1 - Aug 19, 2008 4:48:44 PM
 */
public interface AuditStagingDao
{
   AuditStaging create(String userLoginId, String processName, String auditComment, String auditRequestor);

   void delete(AuditStaging auditStagingObj);
}
