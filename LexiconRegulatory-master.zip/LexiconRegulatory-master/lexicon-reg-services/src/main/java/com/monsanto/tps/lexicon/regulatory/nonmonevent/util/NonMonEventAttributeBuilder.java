package com.monsanto.tps.lexicon.regulatory.nonmonevent.util;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.commercialtrait.Company;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventConstruct;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 20, 2010
 * Time: 2:25:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class NonMonEventAttributeBuilder {

    public ProteinName buildProteinName(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName dbProteinName) {
        ProteinName proteinName = new ProteinName();
        proteinName.setProteinName(dbProteinName.getProteinName());
        proteinName.setProteinNamePubkey(dbProteinName.getProteinNamePubkey());
        return proteinName;
    }

    public ComlTraitType buildComlTraitType(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dbComlTraitType) {
        ComlTraitType comlTraitType = new ComlTraitType();
        comlTraitType.setComlTraitTypeAbbr(dbComlTraitType.getComlTraitTypeAbbr());
        comlTraitType.setComlTraitTypeDesc(dbComlTraitType.getComlTraitTypeDesc());
        return comlTraitType;
    }

    public ComlTraitName buildComlTraitName(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName dbComlTraitName) {
        ComlTraitName comlTraitName = new ComlTraitName();
        comlTraitName.setTraitAbbr(dbComlTraitName.getTraitAbbr());
        comlTraitName.setTraitDesc(dbComlTraitName.getTraitDesc());
        comlTraitName.setCompany(buildCompany(dbComlTraitName.getCompany()));
        comlTraitName.setActive(dbComlTraitName.isActive());
        return comlTraitName;
    }

    public NonMonEventConstruct buildNonMonEventConstruct(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct dbNonMonEventConstruct) {
        NonMonEventConstruct construct = new NonMonEventConstruct();
        construct.setConstructName(dbNonMonEventConstruct.getConstructName());
        return construct;
    }

    private Company buildCompany(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company dbCompany) {
      Company company = null;
      if (dbCompany != null) {
         company = new Company();
         company.setCompanyName(dbCompany.getCompanyName());
         company.setCompanyPubkey(dbCompany.getCompanyPubkey());
         company.setCompetitor(dbCompany.getCompetitor());
         company.setActive(SQLUtil.stringToBoolean(dbCompany.getActive()));
      }
      return company;
   }
}
