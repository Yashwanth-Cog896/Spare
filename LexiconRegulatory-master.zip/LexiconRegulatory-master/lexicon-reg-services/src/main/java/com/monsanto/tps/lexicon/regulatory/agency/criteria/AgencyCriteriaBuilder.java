package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import org.hibernate.Criteria;

import java.util.Arrays;
import java.util.List;

/**
 * rrchak1 - Oct 13, 2008 11:10:01 AM
 */
public class AgencyCriteriaBuilder
{
   public void addCriteria(Criteria agencyCriteria, AgencySearchCriteria agencySearchCriteria) {
      List<QueryCriteria> queryCriteria = getCriteriaList(agencySearchCriteria);
      for (QueryCriteria criteria : queryCriteria) {
         if (criteria.hasCriteria()) {
            agencyCriteria.add(criteria.getCriterion());
         }
      }
   }

   private List<QueryCriteria> getCriteriaList(AgencySearchCriteria agencySearchCriteria) {
      return Arrays.asList(
         new AgencyPubkeyCriteriaImpl(agencySearchCriteria.getAgencyPubkey()),
         new AgencyStatusCriteriaImpl(agencySearchCriteria.isIncludeInactive())
      );
   }

   public void addIdCriteria(Criteria agencyCriteria, long[] agencyIds) {
      QueryCriteria criteria = new AgencyIdCriteriaImpl(agencyIds);
      if (criteria.hasCriteria()) {
         agencyCriteria.add(criteria.getCriterion());
      }
   }
}
