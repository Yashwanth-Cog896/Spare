package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - May 25, 2009 3:19:06 PM
 */
public class EventNameSpecifiedRule
   implements Rule<String>
{
   private final String eventName;

   public EventNameSpecifiedRule(String eventName) {
      this.eventName = eventName;
   }

   @Override
   public boolean violated() {
      return StringUtils.isNullOrEmpty(eventName);
   }

   @Override
   public String getViolation() {
      return "Event name is required.";
   }
}
