package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * User: pjberry
 * Date: Jul 25, 2007
 * Time: 11:42:59 AM
 */
public class RegulatoryEventConstructTransformationPSRowImpl
   implements RegulatoryEventConstructTransformation
{
   private final String event;
   private final String construct;
   private final String transformationBackground;

   public RegulatoryEventConstructTransformationPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.event = row.getString(RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.EVENT_ALIAS);
      this.construct = row.getString(RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.CONSTRUCT_ALIAS);
      this.transformationBackground = row.getString(RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.TRANSFORMATION_BACKGROUND_ALIAS);
   }

   public String getEvent() {
      return event;
   }

   public String getConstruct() {
      return construct;
   }

   public String getTransformationBackground() {
      return transformationBackground;
   }
}
