package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * rrchak1 - Aug 19, 2008 2:42:09 PM
 */
public class Crop
{
   private long cropId;
   private long stageCategoryId;

    public long getStageCategoryId() {
        return stageCategoryId;
    }

    public void setStageCategoryId(long stageCategoryId) {
        this.stageCategoryId = stageCategoryId;
    }

    public long getCropId() {
      return cropId;
   }

   public void setCropId(long cropId) {
      this.cropId = cropId;
   }

   private String cropName;

   public String getCropName() {
      return cropName;
   }

   public void setCropName(String cropName) {
      this.cropName = cropName;
   }

   private String majorCrop;

   public String getMajorCrop() {
      return majorCrop;
   }

   public void setMajorCrop(String majorCrop) {
      this.majorCrop = majorCrop;
   }

   private String cropPubkey;

   public String getCropPubkey() {
      return cropPubkey;
   }

   public void setCropPubkey(String cropPubkey) {
      this.cropPubkey = cropPubkey;
   }

   private String regulatoryCrop;

   public String getRegulatoryCrop() {
      return regulatoryCrop;
   }

   public void setRegulatoryCrop(String regulatoryCrop) {
      this.regulatoryCrop = regulatoryCrop;
   }

   private String complianceShippingStatement;

   public String getComplianceShippingStatement() {
      return complianceShippingStatement;
   }

   public void setComplianceShippingStatement(String complianceShippingStatement) {
      this.complianceShippingStatement = complianceShippingStatement;
   }

   private String abbreviation;

   public String getAbbreviation() {
      return abbreviation;
   }

   public void setAbbreviation(String abbreviation) {
      this.abbreviation = abbreviation;
   }

}
