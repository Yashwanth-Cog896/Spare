package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;
import java.util.List;
import java.io.IOException;
import java.util.Map;

/**
 * rrchak1 - Dec 19, 2008 2:56:56 PM
 */
public interface RegulatoryEventRequestProcessor
{
      public List<RegulatoryEventResponse> getRegulatoryEvents(List<RegulatoryEventRequest> requests)
      throws WrappingException, IOException;
}
