package com.monsanto.tps.lexicon.regulatory.agency.dao;

import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.agency.criteria.AgencyAbbrCriteriaImpl;
import com.monsanto.tps.lexicon.regulatory.agency.criteria.AgencyCriteriaBuilder;
import com.monsanto.tps.lexicon.regulatory.agency.criteria.AgencyDepartmentCriteriaBuilder;
import com.monsanto.tps.lexicon.regulatory.agency.criteria.AgencyDepartmentNameCriteriaImpl;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * rrchak1 - Oct 13, 2008 10:18:04 AM
 */
public class AgencyDaoImpl
   implements AgencyDao
{
   private SessionFactory sessionFactory;
   private Class<Agency> persistentClass = Agency.class;
   private AgencyCriteriaBuilder agencyCriteriaBuilder;
   private AgencyDepartmentCriteriaBuilder agencyDepartmentCriteriaBuilder;
   private Class<AgencyDepartment> departmentPersistentClass = AgencyDepartment.class;

   public AgencyDepartment[] findDepartmentsBySearchCriteria(AgencySearchCriteria agencySearchCriteria) {
      Session session = sessionFactory.getCurrentSession();
      Criteria agencyDepartmentCriteria = session.createCriteria(departmentPersistentClass);
      agencyDepartmentCriteriaBuilder.addCriteria(agencyDepartmentCriteria, agencySearchCriteria);
      if (!ArrayUtils.isEmpty(agencySearchCriteria.getDepartmentNames())) {
         long[] ids = findDepartmentIdsByWildcardableNames(agencySearchCriteria.getDepartmentNames());
         if (ArrayUtils.isEmpty(ids)) {
            return new AgencyDepartment[0];
         }
         agencyDepartmentCriteriaBuilder.addIdCriteria(agencyDepartmentCriteria, ids);
      }
      Criteria agencyCriteria = agencyDepartmentCriteria.createCriteria("agency");
      agencyCriteriaBuilder.addCriteria(agencyCriteria, agencySearchCriteria);
      if (!ArrayUtils.isEmpty(agencySearchCriteria.getAgencyAbbr())) {
         long[] agencyIds = findAgencyIdsByWildcardableAbbr(agencySearchCriteria.getAgencyAbbr());
         if (ArrayUtils.isEmpty(agencyIds)) {
            return new AgencyDepartment[0];
         }
         agencyCriteriaBuilder.addIdCriteria(agencyCriteria, agencyIds);
      }
      Criteria countryCriteria = agencyCriteria.createCriteria("country");
      if (!ArrayUtils.isEmpty(agencySearchCriteria.getAgencyCountryIsoCode())) {
         countryCriteria.add(Restrictions.in("isoCode", agencySearchCriteria.getAgencyCountryIsoCode()));
      }
      List list = agencyDepartmentCriteria.list();
      return (AgencyDepartment[]) list.toArray(new AgencyDepartment[list.size()]);
   }

   private long[] findAgencyIdsByWildcardableAbbr(String[] agencyAbbr) {
      if (ArrayUtils.isEmpty(agencyAbbr)) {
         return new long[0];
      }
      List<Long> idList = new ArrayList<Long>();
      for (String agencyAbbreviation : agencyAbbr) {
         idList.addAll(Arrays.asList(findAgencyIdsByWildcardableAbbreviation(agencyAbbreviation.toLowerCase())));
      }
      return ArrayUtils.toPrimitive(idList.toArray(new Long[idList.size()]));
   }

   private Long[] findAgencyIdsByWildcardableAbbreviation(String agencyAbbreviation) {
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(persistentClass);
      criteria.setProjection(Projections.distinct(Property.forName("agencyId")));
      criteria.add(new AgencyAbbrCriteriaImpl(agencyAbbreviation).getCriterion());
      List list = criteria.list();
      return (Long[]) list.toArray(new Long[list.size()]);
   }

   private long[] findDepartmentIdsByWildcardableNames(String[] departmentNames) {
      if (ArrayUtils.isEmpty(departmentNames)) {
         return new long[0];
      }
      List<Long> idList = new ArrayList<Long>();
      for (String departmentName : departmentNames) {
         idList.addAll(Arrays.asList(findDeptIdsByWildcardableName(departmentName.toLowerCase())));
      }
      return ArrayUtils.toPrimitive(idList.toArray(new Long[idList.size()]));
   }

   private Long[] findDeptIdsByWildcardableName(String departmentName) {
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(departmentPersistentClass);
      criteria.setProjection(Projections.distinct(Property.forName("agencyDeptId")));
      criteria.add(new AgencyDepartmentNameCriteriaImpl(departmentName).getCriterion());
      List list = criteria.list();
      return (Long[]) list.toArray(new Long[list.size()]);
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public void setAgencyCriteriaBuilder(AgencyCriteriaBuilder agencyCriteriaBuilder) {
      this.agencyCriteriaBuilder = agencyCriteriaBuilder;
   }

   public void setAgencyDepartmentCriteriaBuilder(AgencyDepartmentCriteriaBuilder agencyDepartmentCriteriaBuilder) {
      this.agencyDepartmentCriteriaBuilder = agencyDepartmentCriteriaBuilder;
   }

   public Agency getAgencyByAbbvAndCountry(String agencyAbbr, Country country) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.createQuery("from Agency as agency where agency.agencyAbbr = :abbr and agency.country.isoCode = :coisocode");
      query.setParameter("abbr", agencyAbbr);
      query.setParameter("coisocode", country.getIsoCode());
      return (Agency) query.uniqueResult();
   }

   public void saveAgency(Agency agency) {
      Session session = sessionFactory.getCurrentSession();
      agency.setAgencyPubkey(String.valueOf(session.createSQLQuery("select lexicon.AGENCY_PUBKEY_SEQ.NEXTVAL from dual").uniqueResult()));
      Query query = session.createQuery("from Country as country where country.isoCode = :isocode ");
      query.setParameter("isocode", agency.getCountry().getIsoCode());
      agency.setCountry((Country) query.uniqueResult());
      session.save(agency);
   }

   public void mergeAgency(Agency agency, Agency dbAgency) {
      Session session = sessionFactory.getCurrentSession();
      agency.setAgencyId(dbAgency.getAgencyId());
      agency.setAgencyPubkey(dbAgency.getAgencyPubkey());
      agency.setDepartments(dbAgency.getDepartments());
      Query query = session.createQuery("from Country as country where country.isoCode = :isocode ");
      query.setParameter("isocode", agency.getCountry().getIsoCode());
      agency.setCountry((Country) query.uniqueResult());
      session.merge(agency);
   }

   public void mergeAgencyDepartment(AgencyDepartment agencyDepartment, AgencyDepartment dbAgencyDepartment) {
      Session session = sessionFactory.getCurrentSession();
      agencyDepartment.setAgencyDeptId(dbAgencyDepartment.getAgencyDeptId());
      agencyDepartment.setAgencyDeptPubkey(dbAgencyDepartment.getAgencyDeptPubkey());
      agencyDepartment.setAgency(dbAgencyDepartment.getAgency());
      session.merge(agencyDepartment);
   }

   public void saveAgencyDepartment(AgencyDepartment department) {
      Session session = sessionFactory.getCurrentSession();
      department.setAgencyDeptPubkey(String.valueOf(session.createSQLQuery("select lexicon.AGENCY_DEPARTMENT_PUBKEY_SEQ.NEXTVAL from dual").uniqueResult()));
      session.save(department);
   }

   public AgencyDepartment getAgencyDepartmentByAgencyAndAbbr(Agency agency, String agencyDeptAbbr) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.createQuery("from AgencyDepartment agencyDepartment where agencyDepartment.agency = :agency and agencyDepartment.agencyDeptAbbr = :deptabbr");
      query.setParameter("agency", agency);
      query.setParameter("deptabbr", agencyDeptAbbr);
      return (AgencyDepartment) query.uniqueResult();
   }

   public Agency getAgencyByPubkey(String pubkey) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.createQuery("from Agency as agency where agency.agencyPubkey = :pubkey");
      query.setParameter("pubkey", pubkey);
      return (Agency) query.uniqueResult();
   }

   public AgencyDepartment getAgencyDepartmentByPubkey(String pubkey) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.createQuery("from AgencyDepartment agencyDepartment where agencyDepartment.agencyDeptPubkey = :pubkey");
      query.setParameter("pubkey", pubkey);
      return (AgencyDepartment) query.uniqueResult();
   }
}
