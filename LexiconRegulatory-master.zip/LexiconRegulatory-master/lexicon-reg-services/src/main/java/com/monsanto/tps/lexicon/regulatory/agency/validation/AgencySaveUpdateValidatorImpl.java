package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;

/**
 * aagosw - Mar 10, 2009 8:04:39 AM
 */
public class AgencySaveUpdateValidatorImpl
   implements AgencySaveUpdateValidator
{

   public ValidationResults validate(AgencySaveUpdateRequest agencySaveUpdateRequest) {
      return new ValidationResults(new String[0]);
   }
}
