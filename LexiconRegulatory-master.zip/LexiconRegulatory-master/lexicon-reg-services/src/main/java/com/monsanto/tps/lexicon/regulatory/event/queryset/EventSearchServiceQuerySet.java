package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;

import java.util.Collection;
import java.util.List;

/**
 * nbwald - Jan 7, 2009 1:04:51 PM
 */
public interface EventSearchServiceQuerySet
{
   List<RegulatoryEventResponse> findRegulatoryEventByEventAndCrop(Collection<EventCrop> eventCrops);
    
   MonNumber findMonNumberByEventAndCrop(String eventName, String cropName);

   EventAgencyAlignment[] findEventAgencyAlignmentsByEventAndCrop(String eventName, String cropName);

   MonNumber findMonNumber(String monNumberValue);

   EventAgencyAlignment findEventAgencyAlignmentsByEventCropAndAgencyPubkey(String eventName, String cropName, String agencyPubkey);

   EventAgencyAlignment[] findEventAgencyAlignmentByPubkey(String[] eventAgencyAlignmentPubkey);

   EventAgencyAlignment[] findByAgencyAbbr(String[] agencyAbbreviations);
}
